// tcl-lsp — a language server and toolchain for Tcl
// Copyright (C) 2026 James Deucker (bitwisecook) <https://github.com/bitwisecook>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.
//
// SPDX-License-Identifier: AGPL-3.0-or-later

//! Structured IR lowering for control-flow commands.
//!
//! Each method converts a segmented command into its corresponding
//! structured IR statement (`If`, `For`, `While`, `Foreach`, `Catch`,
//! `Try`, `Switch`, `dict` subcommands).

use std::borrow::Cow;

use tcl_lexer::{Span, Token, TokenType};

use tcl_registry::arg_role::ArgRole;
use tcl_registry::spec::CaseListSpec;
use tcl_registry::{ClauseAbstention, ClausePlan, ClauseRowId, ClauseShapeError, ClauseTiming};

use crate::expr_parser::parse_expr_for_profile;
use crate::ir::{
    ForeachIterator, HandlerMatch, IfClause, Script, Statement, SwitchArm, SwitchMode, TryHandler,
};
use crate::lowering_hooks::word_content_base;
use crate::naming::normalise_var_name;
use crate::segmenter::SegmentedCommand;

use super::{Lowerer, parse_var_list_names};
use tcl_syntax::word_rules::WordValueRules;

/// A single pattern/body pair collected by
/// [`lower_switch`](super::Lowerer::lower_switch) before the
/// final `SwitchArm` list is built. Factored out to keep the
/// pair vector's type signature readable.
struct SwitchPair {
    pattern: String,
    /// Whether the pattern word was braced — literal for every element of a
    /// single braced arm list, and per-word in the multi-word form.
    pattern_braced: bool,
    pattern_span: Span,
    body_text: String,
    body_span: Option<Span>,
    body_arg_idx: Option<usize>,
    body_source: Option<crate::command_binding::ExecutedScriptSource>,
}

/// One element of a switch's braced case list.
struct SwitchElement {
    /// The element's decoded **value** — what C Tcl's list split hands the
    /// pattern comparison (`Tcl_SplitList` semantics: braced content
    /// verbatim, backslashes collapsed in bare / quoted elements, so a bare
    /// `a\ b` pattern is the value `a b`).
    value: String,
    /// The element's raw interior text as written (delimiters stripped,
    /// backslashes untouched) — what a braced body's script lowering reads.
    /// Local span, delimiter-inclusive for `{…}` / `"…"` elements, in the
    /// body text's own offset space — callers relocate it to the full
    /// source buffer by adding the body text's starting offset.
    span: Span,
}

/// Split a switch's braced case list into its elements with the central
/// Tcl **list** grammar ([`tcl_syntax::list::find_element`]).
///
/// A braced case list is a list, not a script: C Tcl's
/// `TclNRSwitchObjCmd` splits it with `TclListObjGetElements`
/// (`generic/tclCmdMZ.c`), so `#` starts no comment there and `;` is an
/// ordinary pattern character.  A script lexer that skips
/// `TokenType::Comment` tokens silently deletes a valid `#` pattern and its
/// body (tclsh 9.0.4: `switch # { # {puts matched} default {puts default} }`
/// prints `matched`).
///
/// A bare or quoted element's backslashes collapse under the document's escape
/// grammar (`escapes`): before Tcl 8.6 a `\x` takes every hex digit that
/// follows and keeps the last two.
///
/// Returns `None` when the text is not a well-formed list — the caller
/// bails the whole `switch` to the runtime command, which reports the
/// error exactly as C Tcl does.
fn switch_body_elements(
    body_text: &str,
    escapes: tcl_lexer::EscapeSyntax,
) -> Option<Vec<SwitchElement>> {
    let bytes = body_text.as_bytes();
    let mut elements = Vec::new();
    let mut scan = 0usize;
    loop {
        match tcl_syntax::list::find_element(body_text, scan) {
            Ok(Some(el)) => {
                let raw = body_text[el.value.clone()].to_owned();
                let value = if el.literal {
                    raw.clone()
                } else {
                    tcl_lexer::backslash_subst_in(&raw, escapes).into_owned()
                };
                let quoted = !el.braced
                    && el.value.start > 0
                    && bytes.get(el.value.start - 1) == Some(&b'"');
                let (start, end) = if el.braced || quoted {
                    (el.value.start - 1, el.value.end + 1)
                } else {
                    (el.value.start, el.value.end)
                };
                let local_span = Span::new(
                    u32::try_from(start).unwrap_or(u32::MAX),
                    u32::try_from(end).unwrap_or(u32::MAX),
                );
                let next = el.next;
                elements.push(SwitchElement {
                    value,
                    span: local_span,
                });
                if next <= scan {
                    break;
                }
                scan = next;
            }
            Ok(None) => break,
            Err(_) => return None,
        }
    }
    Some(elements)
}

/// Whether the `index`-th argument was written as a braced word.
///
/// One predicate, because two callers ask it: the `switch` subject's own flag
/// and the per-argument flags the generic fallback pushes by. `TokenType::Str`
/// is the braced word, and the single-token check excludes a composite word
/// that merely starts with a brace — `arg_single` alone is *not* the question,
/// since `$x` and a bare word satisfy it too.
fn word_is_braced(arg_tokens: &[tcl_lexer::Token], arg_single: &[bool], index: usize) -> bool {
    matches!(
        arg_tokens.get(index).map(|t| t.kind),
        Some(tcl_lexer::TokenType::Str)
    ) && arg_single.get(index).copied().unwrap_or(false)
}

/// [`word_is_braced`] for every argument, for the generic-invoke fallback.
pub(crate) fn braced_word_flags(
    arg_tokens: &[tcl_lexer::Token],
    arg_single: &[bool],
    len: usize,
) -> Vec<bool> {
    (0..len)
        .map(|i| word_is_braced(arg_tokens, arg_single, i))
        .collect()
}

/// Per argument, whether the word was double-quoted: its representative
/// token opens at the `"` (a quoted-opening `Esc` token counts the quote as
/// a delimiter byte) or runs inside the quotes.
pub(crate) fn quoted_word_flags(arg_tokens: &[tcl_lexer::Token], len: usize) -> Vec<bool> {
    (0..len)
        .map(|i| {
            arg_tokens.get(i).is_some_and(|token| {
                token.in_quote || (token.kind == TokenType::Esc && token.content_offset > 0)
            })
        })
        .collect()
}

/// The IR's mode for a case list's own comparison, or `None` for a
/// specialised one the statement cannot carry.
const fn switch_mode_of(mode: tcl_registry::spec::CaseMatchMode) -> Option<SwitchMode> {
    match mode {
        tcl_registry::spec::CaseMatchMode::Exact => Some(SwitchMode::Exact),
        tcl_registry::spec::CaseMatchMode::Glob => Some(SwitchMode::Glob),
        tcl_registry::spec::CaseMatchMode::Regexp => Some(SwitchMode::Regexp),
        tcl_registry::spec::CaseMatchMode::Other => None,
    }
}

/// Where a case list's options end and how its clauses compare, as
/// `(subject_index, mode, nocase)`; `Err` is the reason the whole command
/// defers to the runtime. A command with option rows scans them
/// ([`parse_switch_options`]); one with none (`case`) scans no word as an
/// option — its subject is the first word — and every clause compares as
/// its descriptor states, `Tcl_CaseObjCmd`'s glob for `case`.
fn case_list_head(
    case: &CaseListSpec,
    reads_options: bool,
    args: &[String],
) -> Result<(usize, SwitchMode, bool), &'static str> {
    if !reads_options {
        let mode =
            switch_mode_of(case.default_mode).ok_or("case list with a specialised comparison")?;
        return Ok((0, mode, false));
    }
    let (i, mode, nocase, unknown, _) = parse_switch_options(args);
    // An unrecognised / arg-taking option (`-foo`, `-matchvar`, …): bail to
    // the runtime `switch`, which validates options and does the var writes.
    if unknown {
        return Err("switch with non-inlined option");
    }
    Ok((i, mode, nocase))
}

/// Why the IR's arm cannot hold a clause of a case list, when one cannot:
/// under a descriptor whose pattern words may be lists (`case`), a pattern
/// the command splits as one ([`CaseListSpec::pattern_is_list`]) or whose
/// value the source does not state, which may be one; and, under one whose
/// keyword pattern counts wherever it stands, a keyword before the last
/// clause — the IR keeps the fallback as its default body, which runs only
/// after every arm.
fn case_list_unrepresentable(case: &CaseListSpec, pairs: &[SwitchPair]) -> Option<&'static str> {
    let is_list = |pair: &SwitchPair| {
        case.pattern_is_list(&pair.pattern)
            || (case.pattern_words == tcl_registry::spec::PatternWords::Lists
                && !pair.pattern_braced
                && (pair.pattern.contains('$') || pair.pattern.contains('[')))
    };
    if pairs.iter().any(is_list) {
        return Some("case pattern list");
    }
    let early_keyword = pairs.split_last().is_some_and(|(_, rest)| {
        rest.iter()
            .any(|pair| case.keyword_patterns.contains(&pair.pattern.as_str()))
    });
    if !case.keyword_patterns_require_final && early_keyword {
        return Some("case keyword pattern before the last clause");
    }
    None
}

/// Parse switch options, returning `(first_non_option_index, mode, nocase,
/// unknown, ended)`. `unknown` is set when a leading `-word` is not one of the
/// options the compiler inlines (`-exact`/`-glob`/`-regexp`/`-nocase`/`--`) —
/// an arg-taking `-indexvar`/`-matchvar`, or an invalid option such as `-foo`.
/// The caller bails the whole switch to the runtime command, which validates
/// the option set (tclsh rejects `-foo`) and handles the side-channel writes.
/// `ended` is set when `--` closed the options, so the next word is the
/// subject whatever it spells.
///
/// `pub(crate)` so the dispatch chain's lowering can ask the same question
/// this answers for this lowering — which argument the subject is, and whether
/// `--` stands before it — rather than keeping a second copy of the option
/// rule. There is one owner of "where do the options end", and this is it.
pub(crate) fn parse_switch_options(args: &[String]) -> (usize, SwitchMode, bool, bool, bool) {
    let mut i = 0;
    let mut mode = SwitchMode::Exact;
    let mut nocase = false;
    let mut unknown = false;
    let mut ended = false;
    while i < args.len() && args[i].starts_with('-') {
        match args[i].as_str() {
            "--" => {
                i += 1;
                ended = true;
                break;
            }
            "-exact" => mode = SwitchMode::Exact,
            "-glob" => mode = SwitchMode::Glob,
            "-regexp" => mode = SwitchMode::Regexp,
            "-nocase" => nocase = true,
            _ => {
                unknown = true;
                break;
            }
        }
        i += 1;
    }
    (i, mode, nocase, unknown, ended)
}

/// The pattern/body pairs of `switch`'s multi-word form, from word `start`
/// on; `Err` is the reason the whole `switch` defers to the runtime command.
fn inline_switch_pairs(
    seg: &SegmentedCommand,
    case: &CaseListSpec,
    start: usize,
) -> Result<Vec<SwitchPair>, &'static str> {
    let args = seg.args();
    let arg_tokens = seg.arg_tokens();
    let arg_single = seg.arg_single_token();
    if !(args.len() - start).is_multiple_of(2) {
        return Err("switch odd pattern count");
    }
    let mut pairs = Vec::with_capacity((args.len() - start) / 2);
    for i in (start..args.len()).step_by(2) {
        let body_tok_idx = i + 1;
        // Like if/while/for/catch/try, an arm body that carries substitution
        // (`$handler`, `[cmd]`, a quoted/concatenated word) is evaluated as a
        // script from its *runtime value*, not its unsubstituted spelling.
        // Lowering the literal spelling as a nested script would fabricate a
        // phantom command (e.g. a Call to `${handler}`) that downstream
        // dead-code/taint/def-use/call-graph passes reason about. Defer the
        // whole switch to the runtime command instead. The case list's
        // fall-through body is a literal, not a body, so it is exempt.
        // (`seg.argv` includes the command word, so the body word
        // `args[i + 1]` is index `i + 2`.)
        if case.fallthrough_body != Some(args[body_tok_idx].as_str())
            && !super::seg_word_is_static_literal(seg, i + 2)
        {
            return Err("switch with non-literal arm body");
        }
        pairs.push(SwitchPair {
            pattern: args[i].clone(),
            // Per word here: `{${x}}` is literal, a bare `$pat` substitutes.
            pattern_braced: word_is_braced(arg_tokens, arg_single, i),
            pattern_span: arg_tokens.get(i).map_or(seg.span, |t| t.span),
            body_text: args[body_tok_idx].clone(),
            body_span: arg_tokens.get(body_tok_idx).map(|t| t.span),
            body_arg_idx: Some(body_tok_idx),
            body_source: None,
        });
    }
    Ok(pairs)
}

/// Whether a loop body (or `for` next-clause) redefines `break`/`continue` via
/// `proc break …` / `proc continue …`. Such a loop is compiled through the
/// runtime builtin (a barrier) rather than the inline JUMP fast-path: the
/// builtin dispatches break/continue as commands, honouring the redefinition,
/// whereas the inline JUMP fires unconditionally and would loop forever
/// (proc-7.3, Bug 729692). A conservative substring test — a false positive
/// merely takes the correct (if slower) runtime path.
fn redefines_loop_control(body: &str) -> bool {
    body.contains("proc break") || body.contains("proc continue")
}

/// The expression text a condition word is parsed from: `text` as-is, except
/// a lone *bare* `$name` Var token, whose `word_piece` reconstruction
/// re-braces to `${name}` for multi-piece concatenation safety.  A
/// single-token condition word has no following piece to glue onto, and the
/// re-braced spelling leaks into rendered diagnostics (I230 quoting `${n}`
/// where the source spells `$n`) — restore the source's bare form.  Also
/// re-aligns the text with the token's span so `word_content_base` can
/// anchor it.
fn condition_source_text<'t>(tok: Option<&Token>, single: bool, text: &'t str) -> Cow<'t, str> {
    let Some(tok) = tok else {
        return Cow::Borrowed(text);
    };
    if single
        && tok.kind == TokenType::Var
        && tok.content_offset == 1
        && let Some(inner) = text.strip_prefix("${").and_then(|t| t.strip_suffix('}'))
    {
        return Cow::Owned(format!("${inner}"));
    }
    Cow::Borrowed(text)
}

/// The barrier reason for an `if` whose clause plan has `defect`: the
/// runtime `if`'s own error, in the words the lowering has always used.
fn if_defect_reason(plan: &ClausePlan, defect: ClauseShapeError) -> &'static str {
    let explicit_else = plan
        .clauses
        .last()
        .is_some_and(|clause| clause.row == ClauseRowId::Tail && clause.keyword_index.is_some());
    match defect {
        ClauseShapeError::MissingExpr { after: None } => "malformed if",
        ClauseShapeError::MissingExpr { after: Some(_) } => "if missing elseif expression",
        ClauseShapeError::MissingBody { .. } if explicit_else => "malformed if else clause",
        ClauseShapeError::MissingBody { .. } => "malformed if clause",
        ClauseShapeError::ExtraWords { .. } if explicit_else => "if extra words after else",
        ClauseShapeError::ExtraWords { .. } => "if with extra words",
    }
}

impl Lowerer<'_> {
    // if

    /// The clause walk of `seg` under this lowerer's registry and release:
    /// the command's clause grammar over the words' *values* — a substituted
    /// word is computed, a backslash-escaped one decoded — so every keyword,
    /// noise word and fall-through marker is compared as Tcl compares it
    /// (`\-` is `try`'s marker, `{\-}` is not). `None` when the head resolves
    /// no grammar at this release; `Err` where a computed word stands where
    /// the walk compares one.
    fn clause_walk_of(
        &self,
        seg: &SegmentedCommand,
    ) -> Option<Result<ClausePlan, ClauseAbstention>> {
        let tokens = self.cmd_tokens(seg);
        let context = self.invocation_metadata_context()?;
        let invocation = self.logical_structured_invocation(&tokens)?;
        let realm = tokens
            .source_binding
            .as_ref()
            .and_then(crate::command_binding::SourceInvocationBinding::invocation_realm)
            .unwrap_or(self.invocation_realm);
        invocation.with_metadata_schema(self.registry, context, realm, |selected| {
            selected.clause_walk()
        })
    }

    /// Lower `if cond ?then? body ?elseif cond ?then? body ...? ?else? ?body?`
    /// from the command's clause plan: each clause with a condition becomes
    /// an [`IfClause`], the default clause the `else` body. Keywords and the
    /// `then` noise word are the plan's; nothing here compares a spelling.
    pub(super) fn lower_if(&mut self, seg: &SegmentedCommand, namespace: &str) -> Statement {
        let Some(walk) = self.clause_walk_of(seg) else {
            return self.barrier(seg, "malformed if");
        };
        // A computed word where a keyword could stand (`if $c {a} $w {b}`)
        // leaves the chain to the runtime `if`; the inert reading still says
        // how far the literal clauses go before it defers.
        let (plan, computed) = match walk {
            Ok(plan) => (plan, false),
            Err(abstention) => (abstention.inert, true),
        };
        let args = seg.args();
        let arg_tokens = seg.arg_tokens();
        let arg_single = seg.arg_single_token();

        let mut clauses = Vec::new();
        let mut else_body = None;
        let mut else_span = None;
        // Reachability tracking. Once a clause's condition
        // folds to a static `true`, every later clause + the
        // ``else`` branch is dead. A clause whose own condition
        // is a static `false` is dead this iteration but not
        // necessarily later — track per-clause via the
        // ``dead_code_depth`` counter.
        let mut later_clauses_dead = false;

        let last = plan.clauses.len().saturating_sub(1);
        for (index, clause) in plan.clauses.iter().enumerate() {
            // With a defect, the last clause is the one the defect stopped in
            // or the one extra words follow (`if 0 {a} else {b} junk`): the
            // runtime `if` reports it faithfully (if-2.3, if-3.5), so the
            // construct defers to it before that clause is lowered.
            if plan.defect.is_some() && index == last {
                break;
            }
            let Some(body_idx) = clause.operand(ArgRole::Body) else {
                return self.barrier(seg, "malformed if clause");
            };
            // C's TclCompileIfCmd only inlines a braced-literal body; a body
            // carrying substitutions (`$x`, `[cmd]`, a quoted or concatenated
            // word like `$x1$x2`) must be substituted *then* evaluated as a
            // script — which the runtime `if` command does. Bail the whole
            // construct to that command rather than mis-parsing the unsubstituted
            // word as a literal script at compile time.
            if !super::seg_word_is_static_literal(seg, body_idx + 1) {
                return self.barrier(seg, "if with non-literal body");
            }
            let body_tok = arg_tokens.get(body_idx);
            let Some(cond_idx) = clause.operand(ArgRole::Expr) else {
                // Only the default clause — `else`, or the bare final body its
                // optional keyword allows — runs without a condition.
                if !clause.is_default {
                    return self.barrier(seg, "malformed if clause");
                }
                let dead = later_clauses_dead;
                if dead {
                    self.dead_code_depth += 1;
                }
                else_body = Some(self.lower_body_from_tok(&args[body_idx], body_tok, namespace));
                if dead {
                    self.dead_code_depth -= 1;
                }
                else_span = body_tok.map(|t| t.span);
                continue;
            };
            let cond_tok = arg_tokens.get(cond_idx);
            let static_cond = super::static_bool(&args[cond_idx]);
            let clause_dead = later_clauses_dead || matches!(static_cond, Some(false));
            if clause_dead {
                self.dead_code_depth += 1;
            }
            let body = self.lower_body_from_tok(&args[body_idx], body_tok, namespace);
            if clause_dead {
                self.dead_code_depth -= 1;
            }
            let cond_single = arg_single.get(cond_idx).copied().unwrap_or(false);
            let cond_text = condition_source_text(cond_tok, cond_single, &args[cond_idx]);
            clauses.push(IfClause {
                condition: parse_expr_for_profile(&cond_text, self.dialect),
                condition_span: cond_tok.map_or(seg.span, |t| t.span),
                condition_base: cond_tok
                    .and_then(|t| word_content_base(t.span, cond_single, &cond_text)),
                body,
                body_span: body_tok.map_or(seg.span, |t| self.script_word_span(t)),
            });
            // Static-true condition latches the dead-code flag so
            // remaining clauses + the else branch are suppressed.
            if matches!(static_cond, Some(true)) {
                later_clauses_dead = true;
            }
        }

        if let Some(defect) = plan.defect {
            return self.barrier(seg, if_defect_reason(&plan, defect));
        }
        if computed {
            return self.barrier(seg, "if with a computed clause word");
        }
        if clauses.is_empty() {
            return self.barrier(seg, "malformed if");
        }

        Statement::If {
            span: seg.span,
            clauses,
            else_body,
            else_span,
        }
    }

    // for

    /// Lower `for init cond next body`.
    pub(super) fn lower_for(&mut self, seg: &SegmentedCommand, namespace: &str) -> Statement {
        let args = seg.args();
        let arg_tokens = seg.arg_tokens();
        let arg_single = seg.arg_single_token();

        // `for` takes exactly four arguments; a wrong count barriers to the
        // runtime builtin, which raises `wrong # args` (for-old-1.7). Lowering a
        // ≥4 form would silently drop the extras and run arg[0] as the body.
        if args.len() != 4 || arg_tokens.len() < 4 {
            return self.barrier(seg, "malformed for");
        }
        // `init`, `next`, and `body` are all lowered via `lower_body_from_tok`,
        // which rebases the segmenter-reconstructed word text at the token's
        // span — safe only for a substitution-free literal (`seg_word_is_static_literal`,
        // matching `TclCompileForCmd`'s `TCL_TOKEN_SIMPLE_WORD` check). A single-token
        // but dynamic word (`$body`, `[cmd]`) must barrier rather than be
        // lowered as if it were the literal text.
        if !arg_single[1]
            || !super::seg_word_is_static_literal(seg, 1)
            || !super::seg_word_is_static_literal(seg, 3)
            || !super::seg_word_is_static_literal(seg, 4)
        {
            return self.barrier(seg, "for with dynamic arguments");
        }
        // A body/next that redefines break/continue must run through the runtime
        // builtin, which dispatches them (so the redefinition is honoured) rather
        // than firing the compiled JUMP fast-path unconditionally and looping
        // forever (proc-7.3).
        if redefines_loop_control(&args[2]) || redefines_loop_control(&args[3]) {
            return self.barrier(seg, "for redefines break/continue");
        }

        let init = self.lower_body_from_tok(&args[0], Some(&arg_tokens[0]), namespace);
        let next = self.lower_body_from_tok(&args[2], Some(&arg_tokens[2]), namespace);
        let body = self.lower_body_from_tok(&args[3], Some(&arg_tokens[3]), namespace);

        Statement::For {
            span: seg.span,
            init,
            init_span: self.script_word_span(&arg_tokens[0]),
            condition: parse_expr_for_profile(
                &condition_source_text(arg_tokens.get(1), arg_single[1], &args[1]),
                self.dialect,
            ),
            condition_span: arg_tokens[1].span,
            condition_base: word_content_base(
                arg_tokens[1].span,
                arg_single[1],
                &condition_source_text(arg_tokens.get(1), arg_single[1], &args[1]),
            ),
            next,
            next_span: self.script_word_span(&arg_tokens[2]),
            body,
            body_span: self.script_word_span(&arg_tokens[3]),
            raw_args: args.to_vec(),
            raw_tokens: Some(Box::new(self.cmd_tokens(seg))),
        }
    }

    // while

    /// Lower `while cond body`.
    pub(super) fn lower_while(&mut self, seg: &SegmentedCommand, namespace: &str) -> Statement {
        let args = seg.args();
        let arg_tokens = seg.arg_tokens();
        let arg_single = seg.arg_single_token();

        // `while` takes exactly two arguments; a wrong count barriers to the
        // runtime builtin, which raises `wrong # args` (while-old-4.3).
        if args.len() != 2 || arg_tokens.len() < 2 {
            return self.barrier(seg, "malformed while");
        }
        // The body is lowered via `lower_body_from_tok`, which rebases the
        // segmenter-reconstructed word text at the token's span — safe only
        // for a substitution-free literal (matching `TclCompileWhileCmd`'s
        // `TCL_TOKEN_SIMPLE_WORD` check on the body). A single-token but
        // dynamic body (`$body`, `[cmd]`) must barrier rather than be lowered
        // as if it were the literal text.
        if !arg_single[0] || !super::seg_word_is_static_literal(seg, 2) {
            return self.barrier(seg, "while with dynamic arguments");
        }
        // See `lower_for`: a body redefining break/continue must use the runtime
        // builtin so the redefinition is dispatched (proc-7.3).
        if redefines_loop_control(&args[1]) {
            return self.barrier(seg, "while redefines break/continue");
        }

        let body = self.lower_body_from_tok(&args[1], Some(&arg_tokens[1]), namespace);

        Statement::While {
            span: seg.span,
            condition: parse_expr_for_profile(
                &condition_source_text(arg_tokens.first(), arg_single[0], &args[0]),
                self.dialect,
            ),
            condition_span: arg_tokens[0].span,
            condition_base: word_content_base(
                arg_tokens[0].span,
                arg_single[0],
                &condition_source_text(arg_tokens.first(), arg_single[0], &args[0]),
            ),
            body,
            body_span: self.script_word_span(&arg_tokens[1]),
            raw_args: args.to_vec(),
            raw_tokens: Some(self.cmd_tokens(seg)),
        }
    }

    // foreach / lmap

    /// Lower `foreach varList list ?varList list ...? body`.
    pub(super) fn lower_foreach(
        &mut self,
        seg: &SegmentedCommand,
        namespace: &str,
        is_lmap: bool,
    ) -> Statement {
        let args = seg.args();
        let arg_tokens = seg.arg_tokens();

        if args.len() < 3 || args.len().is_multiple_of(2) {
            return self.barrier(seg, "malformed foreach");
        }

        let body_idx = args.len() - 1;
        let body_tok = arg_tokens.get(body_idx);
        // The body is lowered via `lower_body_from_tok`, which rebases the
        // segmenter-reconstructed word text at the token's span — safe only
        // for a substitution-free literal (matching `TclCompileForeachCmd`'s
        // `TCL_TOKEN_SIMPLE_WORD` check on the body). A single-token but
        // dynamic body (`$body`, `[cmd]`) must barrier rather than be lowered
        // as if it were the literal text.
        if body_tok.is_none() || !super::seg_word_is_static_literal(seg, body_idx + 1) {
            return self.barrier(seg, "foreach with dynamic body");
        }

        // The value word's brace-quoting is a fact only the tokens carry:
        // `foreach n {a $b c}` iterates the three literal elements `a`,
        // `$b`, `c` and reads nothing (tclsh 8.6.14), while `foreach n
        // "a $b c"` substitutes. Both lower to the same `list_arg` text,
        // so the flag is what downstream read-harvesting gates on.
        let cmd_tokens = self.cmd_tokens(seg);
        let mut iterators = Vec::new();
        for i in (0..body_idx).step_by(2) {
            // A varList that is not a well-formed Tcl list binds nothing we can
            // name; the runtime `foreach` raises Tcl's own error.
            let Some(var_names) =
                parse_var_list_names(&args[i], WordValueRules::from_config(&self.config))
            else {
                return self.barrier(seg, "foreach with malformed variable list");
            };
            iterators.push(ForeachIterator {
                vars: var_names,
                list_arg: args[i + 1].clone(),
                list_braced: cmd_tokens.arg_is_braced_literal(i + 1),
            });
        }

        let body = self.lower_body_from_tok(&args[body_idx], body_tok, namespace);

        // Route a loop to its runtime builtin on the bytecode path when the inline
        // codegen can't compile it correctly:
        //   * `lmap` with a *branching* body — the inline collector
        //     (`LMAP_COLLECT` on the body's single fall-through tail) can only
        //     gather from a straight-line body; a body with an `if`/`while`/
        //     `switch`/nested loop or an unwinding `return` compiles to a
        //     multi-block CFG it can't collect from, so it stays on the runtime
        //     `lmap` boundary, whose explicit activation preserves `yield` and
        //     non-local completions. A straight-line `lmap` lowers inline —
        //     yieldable and correctly collecting.
        //   * a `foreach` whose body directly contains another `foreach` or
        //     `lmap`. Inline iterator state is activation-local, but the CFG
        //     layout cannot yet pair the outer step with a nested loop's
        //     back-edge. Routing the outer loop through the runtime command
        //     gives the nested body a fresh activation, preserving both
        //     iterator stacks and non-local loop completions.
        // The runtime builtin evaluates the body transparently. It remains the
        // correct fallback for a collecting loop with branching control flow,
        // whose per-arm result collection cannot be represented by the single
        // inline `LMAP_COLLECT` tail, and for nested iterator layouts pending a
        // dedicated CFG representation.
        let body_nests_foreach = body
            .statements
            .iter()
            .any(|statement| matches!(statement, Statement::Foreach { .. }));
        let lmap_needs_runtime = is_lmap && !body.is_straight_line();
        if self.target.is_bytecode() && (lmap_needs_runtime || body_nests_foreach) {
            return self.barrier(seg, if is_lmap { "lmap" } else { "foreach" });
        }

        Statement::Foreach {
            span: seg.span,
            iterators,
            body,
            body_span: body_tok.map_or(seg.span, |t| self.script_word_span(t)),
            is_lmap,
            raw_args: args.to_vec(),
            is_dict_iteration: false,
            is_array_iteration: false,
            raw_tokens: Some(cmd_tokens),
        }
    }

    /// Lower `foreachLine varName filename body` (Tcl 9.0+, TIP 670)
    /// as a single-iterator [`Statement::Foreach`] so variables
    /// assigned inside the body propagate to the enclosing scope —
    /// matching plain `foreach`'s lattice behaviour rather than the
    /// opaque [`Statement::Barrier`] treatment used for generic
    /// stdlib procs.
    ///
    /// # Analyser IR only
    ///
    /// The resulting [`Statement::Foreach`] is for **static-analysis
    /// dataflow only** — it gives the analyser the same lattice
    /// shape it would see for a real `foreach` loop (body-scope
    /// variable propagation, def-use over the iteration variable,
    /// W-code emitters that walk loop bodies, etc.).  The runtime
    /// semantics of `foreachLine` are different: it reads lines from
    /// a file rather than iterating a Tcl list.
    ///
    /// **Downstream codegen / runtime-emission consumers MUST NOT
    /// treat this IR as a real list-iteration `foreach`.**  A codegen
    /// consumer must detect `raw_args[0] == "foreachLine"` (or
    /// equivalent) before treating this as a list iteration.
    pub(super) fn lower_foreach_line(
        &mut self,
        seg: &SegmentedCommand,
        namespace: &str,
    ) -> Statement {
        let args = seg.args();
        let arg_tokens = seg.arg_tokens();

        // `foreachLine varName filename body` — exactly three args.
        if args.len() != 3 {
            return self.barrier(seg, "malformed foreachLine");
        }

        // Body must be a single static brace-string literal; dynamic
        // bodies (`$body`, `[cmd]`, multi-token) fall through to the
        // runtime command via `Statement::Barrier`.  Mirrors the
        // `lower_catch` body guard — a `Var` / `Cmd` single-token
        // word is still dynamic and must not be compiled as a
        // static loop body.
        let body_tok = arg_tokens.get(2);
        if !self.can_lower_body_word(seg, 3) {
            return self.barrier(seg, "foreachLine with dynamic body");
        }

        // Single iterator binding the loop variable.  `list_arg`
        // semantically carries "the iteration source" — for plain
        // `foreach` that's the list; for `foreachLine` it's the
        // filename (the runtime reads lines from it).  Downstream
        // dataflow doesn't care: the lattice-propagation matters,
        // not the literal value.  See the type-level doc-comment
        // above for the runtime-semantics caveat.
        let cmd_tokens = self.cmd_tokens(seg);
        let Some(vars) = parse_var_list_names(&args[0], WordValueRules::from_config(&self.config))
        else {
            return self.barrier(seg, "foreachLine with malformed variable list");
        };
        let iterators = vec![ForeachIterator {
            vars,
            list_arg: args[1].clone(),
            list_braced: cmd_tokens.arg_is_braced_literal(1),
        }];

        let body = self.lower_body_from_tok(&args[2], body_tok, namespace);

        Statement::Foreach {
            span: seg.span,
            iterators,
            body,
            body_span: body_tok.map_or(seg.span, |t| self.script_word_span(t)),
            is_lmap: false,
            raw_args: args.to_vec(),
            is_dict_iteration: false,
            is_array_iteration: false,
            raw_tokens: Some(cmd_tokens),
        }
    }

    // catch

    /// Lower `catch body ?resultVar? ?optionsVar?`.
    pub(super) fn lower_catch(&mut self, seg: &SegmentedCommand, namespace: &str) -> Statement {
        let args = seg.args();
        let arg_tokens = seg.arg_tokens();

        let arity = self
            .invocation_dialect
            .and_then(tcl_registry::InvocationDialect::catch_positional_arity);
        if arity
            .is_none_or(|arity| !u16::try_from(args.len()).is_ok_and(|count| arity.accepts(count)))
        {
            return self.barrier(seg, "malformed catch");
        }
        // Body must be a single brace-literal (`Str` kind) token to
        // compile statically.  Variable references (`$cmd`) and
        // bracket commands (`[expr ...]`) are single-token but
        // non-`Str` and must fall through to the runtime
        // `eval_catch`, which calls `eval_script` on the substituted
        // value.  Without the kind check, ``catch $cmd res`` would
        // be compiled as "call the proc named by ``$cmd``" — wrong.
        if arg_tokens.is_empty() || !self.can_lower_body_word(seg, 1) {
            return self.barrier(seg, "catch with dynamic body");
        }

        let body = self.lower_body_from_tok(&args[0], Some(&arg_tokens[0]), namespace);
        let result_var = args.get(1).map(|a| normalise_var_name(a).to_owned());
        let options_var = args.get(2).map(|a| normalise_var_name(a).to_owned());

        Statement::Catch {
            span: seg.span,
            body,
            body_span: self.script_word_span(&arg_tokens[0]),
            result_var,
            options_var,
            raw_args: args.to_vec(),
            tokens: Some(self.cmd_tokens(seg)),
        }
    }

    // try

    /// Lower `try body ?handler ...? ?finally finallyBody?` from the command's
    /// clause plan: the protected clause is the body, each clause its
    /// pattern selects becomes a [`TryHandler`] carrying the row's
    /// [`HandlerMatch`], and the clause that runs whatever the outcome is
    /// `finally`. Keywords and the `-` marker are the plan's.
    pub(super) fn lower_try(&mut self, seg: &SegmentedCommand, namespace: &str) -> Statement {
        // The bytecode/VM compile path lowers `try` to a runtime-command barrier:
        // the backend has no exception-range support, so a structured `try` can't
        // be compiled correctly (its handler/finally clauses would be dropped).
        // Analysis callers keep the structured form below. See `CompileTarget`.
        if self.target.is_bytecode() {
            return self.barrier(seg, "try");
        }

        let args = seg.args();
        let arg_tokens = seg.arg_tokens();

        if args.is_empty() {
            return self.barrier(seg, "malformed try");
        }
        let Some(walk) = self.clause_walk_of(seg) else {
            return self.barrier(seg, "malformed try");
        };
        // A computed word where a keyword or the marker could stand leaves
        // the chain to the runtime `try`; the inert reading still says how far
        // the literal clauses go before it defers.
        let (plan, computed) = match walk {
            Ok(plan) => (plan, false),
            Err(abstention) => (abstention.inert, true),
        };
        let Some((protected, rest)) = plan.clauses.split_first() else {
            return self.barrier(seg, "malformed try");
        };
        let Some(body_idx) = protected.operand(ArgRole::Body) else {
            return self.barrier(seg, "malformed try");
        };
        // The body is lowered via `lower_body_from_tok`, which rebases the
        // segmenter-reconstructed word text at the token's span — safe only
        // for a brace-literal (`Str`) token, matching `lower_catch`'s body
        // guard. A single-token but dynamic body (`$body`, `[cmd]`) must
        // barrier rather than be lowered as if it were the literal text.
        let Some(body_tok) = arg_tokens.get(body_idx) else {
            return self.barrier(seg, "try with dynamic body");
        };
        if !self.can_lower_body_word(seg, body_idx + 1) {
            return self.barrier(seg, "try with dynamic body");
        }

        let body = self.lower_body_from_tok(&args[body_idx], Some(body_tok), namespace);
        let mut handlers = Vec::new();
        let mut finally_body = None;
        let mut finally_span = None;

        for (offset, clause) in rest.iter().enumerate() {
            // A clause the defect stopped in has no script word of its own.
            let Some(clause_body) = clause.operand(ArgRole::Body) else {
                break;
            };
            let clause_tok = arg_tokens.get(clause_body);
            match clause.timing {
                ClauseTiming::Always => {
                    // The `finally` word is a body like any other, so it needs
                    // the same static gate as the primary body above:
                    // single-token-ness alone would let `try {} finally $body`
                    // through, and rebasing the reconstructed `${body}` text at
                    // the `$body` token's span puts the inner statement off the
                    // end of the source. C's `TclCompileTryCmd` makes the same
                    // call — a `finally` word that is not a
                    // `TCL_TOKEN_SIMPLE_WORD` is `goto failedToCompile`,
                    // deferring the whole `try` to the runtime command.
                    if clause_tok.is_none() || !self.can_lower_body_word(seg, clause_body + 1) {
                        return self.barrier(seg, "try with dynamic finally body");
                    }
                    finally_body =
                        Some(self.lower_body_from_tok(&args[clause_body], clause_tok, namespace));
                    finally_span = clause_tok.map(|t| t.span);
                }
                ClauseTiming::Selected => {
                    let (Some((pattern_idx, kind)), Some(var_list_idx)) =
                        (clause.handler(), clause.operand(ArgRole::LoopVarList))
                    else {
                        return self.barrier(seg, "malformed try handler");
                    };
                    match self.lower_try_handler(
                        seg,
                        namespace,
                        kind,
                        [pattern_idx, var_list_idx, clause_body],
                        plan.falls_through(offset + 1),
                    ) {
                        Ok(handler) => handlers.push(handler),
                        Err(reason) => return self.barrier(seg, reason),
                    }
                }
                _ => return self.barrier(seg, "malformed try handler"),
            }
        }

        if plan.defect.is_some() || computed {
            return self.barrier(seg, "malformed try handler");
        }

        Statement::Try {
            span: seg.span,
            body,
            body_span: self.script_word_span(body_tok),
            handlers,
            finally_body,
            finally_span,
            raw_args: args.to_vec(),
        }
    }

    /// Decode only a statically selected trap operand through the retained grammar.
    fn try_trap_pattern(
        &self,
        seg: &SegmentedCommand,
        written: usize,
        keyword: &str,
        match_arg: &str,
    ) -> Result<Option<Vec<String>>, ()> {
        if keyword != "trap" || !super::seg_word_is_static_literal(seg, written) {
            return Ok(None);
        }
        let match_tok = seg.arg_tokens().get(written - 1);
        let value = if match_tok.is_some_and(|tok| tok.kind == TokenType::Str) {
            std::borrow::Cow::Borrowed(match_arg)
        } else {
            let bytes =
                tcl_lexer::backslash_subst_bytes_in(match_arg.as_bytes(), self.config.escapes);
            let text = std::str::from_utf8(&bytes).map_err(|_| ())?;
            std::borrow::Cow::Owned(text.to_owned())
        };
        Ok(WordValueRules::from_config(&self.config)
            .split_list(&value)
            .ok()
            .map(|elements| elements.into_iter().map(Into::into).collect()))
    }

    /// One handler clause of [`Self::lower_try`]: `words` are its pattern,
    /// variable-list and script word indices, and `fallthrough` whether the
    /// plan reads the script word as the grammar's fall-through marker. `Err`
    /// is the reason the whole `try` defers to the runtime command.
    fn lower_try_handler(
        &mut self,
        seg: &SegmentedCommand,
        namespace: &str,
        kind: HandlerMatch,
        [pattern_idx, var_list_idx, body_idx]: [usize; 3],
        fallthrough: bool,
    ) -> Result<TryHandler, &'static str> {
        let args = seg.args();
        let arg_tokens = seg.arg_tokens();
        let match_arg = args[pattern_idx].clone();
        // An error-code-prefix selector (`trap`'s) is evaluated as one Tcl
        // word and its value is then parsed as a Tcl list. Preserve the
        // source-level substitution decision here: inspecting the decoded
        // elements for `$` or `[` would reject literal data such as
        // `{A {$B}}` and `{A \$B}`. A substitution-free bare/quoted word still
        // needs backslash substitution before list parsing, whereas a braced
        // word's content is already its literal runtime value.
        let keyword = if kind == HandlerMatch::ErrorCodePrefix {
            "trap"
        } else {
            "on"
        };
        let trap_pattern = self
            .try_trap_pattern(seg, pattern_idx + 1, keyword, &match_arg)
            .map_err(|()| "try trap native byte pattern is not represented")?;
        let Some(var_names) = parse_var_list_names(
            &args[var_list_idx],
            WordValueRules::from_config(&self.config),
        ) else {
            return Err("try with malformed handler variable list");
        };
        let var_name = var_names.first().map(|v| normalise_var_name(v).to_owned());
        let options_var = var_names.get(1).map(|v| normalise_var_name(v).to_owned());
        let handler_tok = arg_tokens.get(body_idx);
        // A handler whose script word is the fall-through marker shares the
        // next handler's body (like `switch`). Tcl recognises the marker by
        // the word's *value*, and so does the plan: the braced `{-}`, quoted
        // `"-"` and backslash-escaped (`\-`, `\x2d`) spellings all evaluate to
        // `-`, while braces suppress backslash substitution, so `{\-}` is the
        // two-character script `\-`. The marker is lowered as an empty script
        // — as a script it would be a zero-arg call of the `-` command and
        // trip a spurious arity error.
        //
        // Every other handler script gets the primary body's static gate:
        // `on error {} $body` is a single VAR token, so an unconditional walk
        // would rebase the reconstructed `${body}` text at that token and
        // emit a span past the end of the source. C's `TclCompileTryCmd`
        // refuses the same shape — a handler body that is not a
        // `TCL_TOKEN_SIMPLE_WORD` is `goto failedToCompile` — so the whole
        // `try` defers to the runtime command, exactly as the primary-body
        // gate does.
        if !fallthrough && (handler_tok.is_none() || !self.can_lower_body_word(seg, body_idx + 1)) {
            return Err("try with dynamic handler body");
        }
        let body = if fallthrough {
            crate::ir::Script::new()
        } else {
            self.lower_body_from_tok(&args[body_idx], handler_tok, namespace)
        };
        Ok(TryHandler {
            kind,
            match_arg,
            trap_pattern,
            var_name,
            options_var,
            body,
            body_span: handler_tok.map_or(seg.span, |t| self.script_word_span(t)),
            fallthrough,
        })
    }

    // switch

    /// Lower `switch ?options? subject pattern body ...`.
    // Sequential `switch` lowering: option parsing, list-form
    // unpacking, body recursion, and case-list build all share
    // local arena state.
    /// The case list `seg`'s command declares — its fall-through body and its
    /// keyword patterns are the registry's, never spellings in the lowering.
    /// The call's case-list descriptor, and whether its command reads any
    /// option rows — `case` has none, so no word of it is an option.
    fn case_list_of(&self, seg: &SegmentedCommand) -> Option<(CaseListSpec, bool)> {
        let tokens = self.cmd_tokens(seg);
        let context = self.invocation_metadata_context()?;
        let invocation = self.logical_structured_invocation(&tokens)?;
        let realm = tokens
            .source_binding
            .as_ref()
            .and_then(crate::command_binding::SourceInvocationBinding::invocation_realm)
            .unwrap_or(self.invocation_realm);
        invocation.with_metadata_schema(self.registry, context, realm, |selected| {
            Some((
                *selected.semantics.options.case_list?,
                !selected.semantics.options.base.is_empty()
                    || !selected.semantics.options.form.is_empty(),
            ))
        })
    }

    /// Build the `(arms, default_body, default_span)` triple from
    /// collected `SwitchPair` entries.  Extracted from
    /// [`Self::lower_switch`] to keep the dispatcher under threshold.
    fn build_switch_arms(
        &mut self,
        case: &CaseListSpec,
        pairs: &[SwitchPair],
        arg_tokens: &[tcl_lexer::Token],
        namespace: &str,
    ) -> (Vec<SwitchArm>, Option<crate::ir::Script>, Option<Span>) {
        let mut arms = Vec::new();
        let mut default_body = None;
        let mut default_span = None;

        for (pair_idx, pair) in pairs.iter().enumerate() {
            // A braced multi-line pattern collapses its `\<newline>`
            // continuations to a single space, like every other braced word
            // (`switch "a b" { {a\<nl>b} … }` must match). A no-op for the
            // common single-line pattern (and for `default` / `-`).
            let pattern = WordValueRules::from_config(&self.config)
                .collapse_braced_word(&pair.pattern)
                .into_owned();
            // The case list's fall-through body shares the next arm's.
            if case.fallthrough_body == Some(pair.body_text.as_str()) {
                arms.push(SwitchArm {
                    pattern,
                    pattern_braced: pair.pattern_braced,
                    pattern_span: pair.pattern_span,
                    body: None,
                    body_span: None,
                    fallthrough: true,
                });
                continue;
            }

            let body_tok = pair.body_arg_idx.and_then(|idx| arg_tokens.get(idx));
            let body = if let Some(source) = &pair.body_source {
                self.lower_retained_script(source.clone())
            } else if let Some(tok) = body_tok {
                self.lower_body_from_tok(&pair.body_text, Some(tok), namespace)
            } else {
                Script::new()
            };

            // A keyword pattern (`default`) matches unconditionally — in the
            // final clause only, where the case list says so.
            let final_clause = pair_idx == pairs.len() - 1;
            if case.keyword_patterns.contains(&pattern.as_str())
                && (final_clause || !case.keyword_patterns_require_final)
            {
                default_body = Some(body);
                default_span = pair.body_span;
            } else {
                arms.push(SwitchArm {
                    pattern,
                    pattern_braced: pair.pattern_braced,
                    pattern_span: pair.pattern_span,
                    body: Some(body),
                    body_span: pair.body_span,
                    fallthrough: false,
                });
            }
        }
        (arms, default_body, default_span)
    }

    fn switch_list_source(
        &self,
        seg: &SegmentedCommand,
        argument: usize,
    ) -> Option<crate::command_binding::ExecutedScriptSource> {
        let bindings = self.source_bindings.as_ref()?;
        let origin = bindings.source_origin()?.clone();
        let tokens = self.cmd_tokens(seg);
        let word = tokens.words().get(argument + 1)?;
        let crate::registry_invocation::EffectiveInvocationWord::Literal(value) =
            crate::registry_invocation::effective_invocation_word(
                word,
                self.config.escapes,
                WordValueRules::from_config(&self.config),
            )
        else {
            return None;
        };
        Some(crate::command_binding::ExecutedScriptSource::from_word(
            crate::command_binding::CommandAllocationSite {
                source: origin,
                offset: seg.span.start(),
            },
            argument,
            word,
            &value,
            self.config,
        ))
    }

    fn switch_list_pairs(
        &self,
        seg: &SegmentedCommand,
        i: usize,
    ) -> Result<Vec<SwitchPair>, &'static str> {
        let arg_tokens = seg.arg_tokens();
        let mut pairs = Vec::new();
        let Some(list_source) = self.switch_list_source(seg, i) else {
            return Err("switch case list value is unproved");
        };
        let body_text = list_source
            .try_text()
            .map_err(|_| "switch case list has no Unicode analysis view")?;
        // Starting offset of the body *content* inside the
        // outer source. For a braced word the content begins
        // one byte after the opening `{`.
        let body_base = list_source.base();

        // Not a well-formed Tcl list — bail to the runtime `switch`,
        // which reports the list error exactly as C Tcl does.
        let Some(elements) = switch_body_elements(body_text, self.config.escapes) else {
            return Err("switch case list is not a list");
        };
        // An empty arm list (`switch x {}`) is a "wrong # args" error, not a
        // no-op — bail to the runtime command, which reports it.
        if elements.is_empty() {
            return Err("switch with no arms");
        }
        if !elements.len().is_multiple_of(2) {
            return Err("switch odd pattern count");
        }
        let relocate = |local: Span| {
            let start = body_base.saturating_add(local.start());
            let end = body_base.saturating_add(local.end());
            Span::new(start, end)
        };
        let mut j = 0;
        while j + 1 < elements.len() {
            let pat = &elements[j];
            let body = &elements[j + 1];
            pairs.push(SwitchPair {
                // The pattern is the element's decoded list VALUE
                // (`a\ b` matches the subject `a b`); the body keeps
                // its raw spelling for script lowering.
                pattern: pat.value.clone(),
                // Every element of a single braced arm list is literal.
                pattern_braced: true,
                pattern_span: relocate(pat.span),
                body_text: body.value.clone(),
                body_span: Some(relocate(body.span)),
                body_arg_idx: None,
                body_source: self
                    .source_bindings
                    .as_ref()
                    .and_then(|bindings| {
                        bindings.executed_script_for_list_element(arg_tokens[i].span, j + 1)
                    })
                    .cloned()
                    .or_else(|| {
                        list_source.list_element(
                            crate::command_binding::CommandAllocationSite {
                                source: self
                                    .source_bindings
                                    .as_ref()
                                    .and_then(|bindings| bindings.source_origin())
                                    .cloned()
                                    .unwrap_or_else(|| list_source.origin.clone()),
                                offset: seg.span.start(),
                            },
                            i,
                            j + 1,
                            WordValueRules::from_config(&self.config),
                        )
                    }),
            });
            j += 2;
        }
        Ok(pairs)
    }

    pub(super) fn lower_switch(&mut self, seg: &SegmentedCommand, namespace: &str) -> Statement {
        let args = seg.args();
        let arg_tokens = seg.arg_tokens();
        let arg_single = seg.arg_single_token();

        if args.len() < 2 {
            return self.lower_default(seg, namespace);
        }
        let Some((case, reads_options)) = self.case_list_of(seg) else {
            return self.barrier(seg, "switch without a case list");
        };

        let (mut i, mode, nocase) = match case_list_head(&case, reads_options, args) {
            Ok(head) => head,
            Err(reason) => return self.barrier(seg, reason),
        };
        if i >= args.len() {
            return self.lower_default(seg, namespace);
        }

        let subject = args[i].clone();
        // Whether the subject word was *braced*, which decides whether its
        // value is literal. `TokenType::Str` is the braced word plus a
        // single-token check, which is the predicate the rest of lowering uses
        // for this question (`braced_at` in `lowering::mod`). `arg_single`
        // alone is not it — it means "one token", which `$x` and a bare word
        // also satisfy, and bracing those would freeze a subject that must
        // substitute.
        let subject_braced = word_is_braced(arg_tokens, arg_single, i);
        i += 1;
        // The descriptor's literal separator (`case string ?in? …`), skipped
        // when the word's value is it, as `Tcl_CaseObjCmd`'s `strcmp` does. A
        // word there whose value the source does not state could be it.
        if let Some(separator) = case.optional_subject_separator
            && i < args.len()
        {
            if !super::seg_word_is_static_literal(seg, i + 1) || args[i].contains('\\') {
                return self.barrier(seg, "case list separator is computed");
            }
            if args[i] == separator {
                i += 1;
            }
        }
        if i >= args.len() {
            return self.lower_default(seg, namespace);
        }

        // Collect pattern/body pairs. Each pair carries a
        // `body_span` resolved in the outer source's offset
        // space plus an optional `body_arg_idx` into
        // `arg_tokens` so the body lowerer can still pick up
        // the right content offset / encoding flags.
        // A single braced list supplies literal patterns; separate words
        // retain their runtime substitutions.
        let (pairs, patterns_braced) =
            if i == args.len() - 1 && i < arg_single.len() && arg_single[i] {
                match self.switch_list_pairs(seg, i) {
                    Ok(pairs) => (pairs, true),
                    Err(_) => return self.lower_default(seg, namespace),
                }
            } else {
                match inline_switch_pairs(seg, &case, i) {
                    Ok(pairs) => (pairs, false),
                    Err(reason) => return self.barrier(seg, reason),
                }
            };

        if let Some(reason) = case_list_unrepresentable(&case, &pairs) {
            return self.barrier(seg, reason);
        }
        let (arms, default_body, default_span) =
            self.build_switch_arms(&case, &pairs, arg_tokens, namespace);

        Statement::Switch {
            span: seg.span,
            subject,
            subject_braced,
            subject_span: arg_tokens.first().map_or(seg.span, |t| t.span),
            arms,
            default_body,
            default_span,
            mode,
            nocase,
            raw_args: args.to_vec(),
            raw_arg_braced: braced_word_flags(arg_tokens, arg_single, args.len()),
            raw_arg_quoted: quoted_word_flags(arg_tokens, args.len()),
            command: seg.name().to_owned(),
            patterns_braced,
        }
    }

    // dict

    /// True when this `dict` invocation's subcommand writes the dict
    /// variable at `args[1]` — the registry's per-subcommand `VarWrite`
    /// role, resolved against the actual argument list.
    fn dict_sub_writes_var(&self, args: &[String]) -> bool {
        let arg_strs: Vec<&str> = args.iter().map(String::as_str).collect();
        self.registry
            .arg_indices_for_role("dict", &arg_strs, tcl_registry::prelude::ArgRole::VarWrite)
            .contains(&1)
    }

    /// Lower `dict` subcommands.
    pub(super) fn lower_dict(&mut self, seg: &SegmentedCommand, namespace: &str) -> Statement {
        let args = seg.args();
        let arg_tokens = seg.arg_tokens();
        let sub = &args[0];
        let sub_args = &args[1..];

        match sub.as_str() {
            "for" | "map" if sub_args.len() >= 3 => {
                let Some(var_names) =
                    parse_var_list_names(&sub_args[0], WordValueRules::from_config(&self.config))
                else {
                    return self.barrier(seg, &format!("dict {sub} with malformed variable list"));
                };
                let body_idx = 3; // index in original args
                let body_tok = arg_tokens.get(body_idx);
                // The body is lowered via `lower_body_from_tok`, which
                // rebases the segmenter-reconstructed word text at the
                // token's span — safe only for a brace-literal (`Str`)
                // token, matching `lower_catch`'s body guard. A
                // single-token but dynamic body (`$body`, `[cmd]`) must
                // barrier rather than be lowered as if it were the literal
                // text.
                if body_tok.is_none() || !self.can_lower_body_word(seg, body_idx + 1) {
                    return self.barrier(seg, &format!("dict {sub} with dynamic body"));
                }
                let body = self.lower_body_from_tok(&sub_args[2], body_tok, namespace);

                Statement::Foreach {
                    span: seg.span,
                    iterators: vec![ForeachIterator {
                        vars: var_names,
                        list_arg: sub_args[1].clone(),
                        // `dict for {k v} {a $b} …` iterates the literal
                        // dictionary; the value word is `args[2]` in the
                        // full argument list.
                        list_braced: self.cmd_tokens(seg).arg_is_braced_literal(2),
                    }],
                    body,
                    body_span: body_tok.map_or(seg.span, |t| self.script_word_span(t)),
                    is_lmap: sub == "map",
                    raw_args: args.to_vec(),
                    is_dict_iteration: true,
                    is_array_iteration: false,
                    raw_tokens: Some(self.cmd_tokens(seg)),
                }
            }

            // The body-carrying mutators barrier (the body's local-var
            // mapping is runtime behaviour) — ordered before the generic
            // sub-mutator arm below, whose registry query also matches
            // their `VarWrite` role.
            "update" | "with" => Statement::Barrier {
                span: seg.span,
                reason: format!("dict {sub}"),
                command: seg.name().into(),
                canonical_command: None,
                args: args.to_vec(),
                tokens: Some(self.cmd_tokens(seg)),
            },

            // A sub-mutator (`dict set/unset/append/lappend/incr …`) tags
            // the lowered call with the dict variable as a def.  Membership
            // comes from the registry's per-subcommand `VarWrite` role on
            // `dict` — the variable is `args[1]` (just past the subcommand
            // word) — never a hardcoded subcommand list.
            _ if !sub_args.is_empty() && self.dict_sub_writes_var(args) => {
                let var_name = normalise_var_name(&sub_args[0]).to_owned();
                Statement::Call {
                    span: seg.span,
                    command: seg.name().into(),
                    canonical_command: None,
                    args: args.to_vec(),
                    defs: vec![var_name],
                    reads: vec![],
                    reads_own_defs: true,
                    safe_on_uninit: self.safe_on_uninit(seg.name(), args),
                    tokens: Some(self.cmd_tokens(seg)),
                    foreach_groups: None,
                }
            }

            _ => Statement::Call {
                span: seg.span,
                command: seg.name().into(),
                canonical_command: None,
                args: args.to_vec(),
                defs: vec![],
                reads: vec![],
                reads_own_defs: false,
                safe_on_uninit: false,
                tokens: Some(self.cmd_tokens(seg)),
                foreach_groups: None,
            },
        }
    }

    // Helpers

    /// Create a barrier statement from a segmented command.
    fn barrier(&self, seg: &SegmentedCommand, reason: &str) -> Statement {
        Statement::Barrier {
            span: seg.span,
            reason: reason.into(),
            command: seg.name().into(),
            canonical_command: None,
            args: seg.args().to_vec(),
            tokens: Some(self.cmd_tokens(seg)),
        }
    }

    /// Whole written script operand, including its closing delimiter.
    /// IR body ranges use this convention even though lexer token spans exclude
    /// nonempty closers. List-form switch elements already supply whole words.
    pub(super) fn script_word_span(&self, token: &tcl_lexer::Token) -> Span {
        tcl_lexer::word_span_at(&self.source, token.span)
    }

    /// Analysis can enter a frozen body with an exact retained source inventory.
    /// Backend compilation still requires its separately authored inline grammar.
    pub(super) fn can_lower_body_word(&self, seg: &SegmentedCommand, word: usize) -> bool {
        super::seg_word_is_static_braced(seg, word)
            || (!self.target.is_bytecode()
                && seg.argv.get(word).is_some_and(|token| {
                    self.source_bindings.as_ref().is_some_and(|bindings| {
                        bindings.executed_script_for_word(token.span).is_some()
                    })
                }))
    }

    /// Lower the executed operand value in its retained source instance.
    /// Escapes and substitutions never receive estimated document offsets.
    pub(super) fn lower_body_from_tok(
        &mut self,
        text: &str,
        tok: Option<&tcl_lexer::Token>,
        _namespace: &str,
    ) -> Script {
        let Some(tok) = tok else {
            return Script::new();
        };
        if let Some(script) = self
            .source_bindings
            .as_ref()
            .and_then(|bindings| bindings.executed_script_for_word(tok.span))
            .cloned()
        {
            return self.lower_retained_script(script);
        }
        // The retained parent owns the argument ordinal and compiler word
        // span. Its shared owner joins the Native whole extent independently;
        // a cooked body never borrows an equal-text written site.
        if let Some(source) = self.structured_source_parent.as_deref().and_then(|parent| {
            parent
                .source_binding
                .as_ref()?
                .original_body_source_for_word(parent, tok.span, self.config)
        }) {
            return self.lower_retained_script(source);
        }
        let Some(origin) = self
            .source_bindings
            .as_ref()
            .and_then(|bindings| bindings.source_origin())
            .cloned()
        else {
            return super::over_depth_script(tok.span.start(), text.len());
        };
        let span = tcl_lexer::word_span_at(&self.source, tok.span);
        let Some(raw) = self.source.get(span.as_range()) else {
            return super::over_depth_script(tok.span.start(), text.len());
        };
        let Some(commands) = self.segment_source(
            raw,
            span.start(),
            super::SourceSegmentationPurpose::NestedScript,
        ) else {
            return super::over_depth_script(tok.span.start(), text.len());
        };
        let Some(command) = commands.first() else {
            return Script::new();
        };
        let tokens = crate::ir::CommandTokens::from_segmented(
            &tcl_lexer::SourceMap::from_bytes_with_channel(
                self.source.as_bytes(),
                self.current_source_channel(),
            ),
            self.config,
            command,
        );
        let Some(word) = tokens.words().first() else {
            return Script::new();
        };
        let crate::registry_invocation::EffectiveInvocationWord::Literal(value) =
            crate::registry_invocation::effective_invocation_word(
                word,
                self.config.escapes,
                WordValueRules::from_config(&self.config),
            )
        else {
            return super::over_depth_script(tok.span.start(), text.len());
        };
        let script = crate::command_binding::ExecutedScriptSource::from_word(
            crate::command_binding::CommandAllocationSite {
                source: origin,
                offset: span.start(),
            },
            0,
            word,
            &value,
            self.config,
        );
        self.lower_retained_script(script)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::lowering::lower_to_ir;
    use tcl_registry::CommandRegistry;

    fn reg() -> CommandRegistry {
        CommandRegistry::build_default()
    }

    #[test]
    fn switch_exact() {
        // Both forms lower to a structured Switch; the multi-arg form
        // and the single-braced form must agree on shape.
        for src in [
            "switch $x { a {puts a} b {puts b} }",
            "switch $x a {puts a} b {puts b}",
        ] {
            let m = lower_to_ir(src, &reg());
            assert!(
                matches!(
                    &m.top_level.statements[0],
                    Statement::Switch { mode, .. } if *mode == SwitchMode::Exact
                ),
                "expected exact Switch for {src:?}",
            );
        }
    }

    #[test]
    fn switch_single_braced_body_is_lowered() {
        // The single-braced arm form `switch $x { a {body} … }` must lower
        // each arm body into real IR statements, not an empty Script.
        let m = lower_to_ir("switch $x { a {puts hi} b {set y 1} }", &reg());
        let Statement::Switch { arms, .. } = &m.top_level.statements[0] else {
            panic!("expected Switch");
        };
        assert_eq!(arms.len(), 2);
        for arm in arms {
            let body = arm.body.as_ref().expect("arm body");
            assert!(
                !body.statements.is_empty(),
                "single-braced arm body should lower to non-empty IR, got {body:?}",
            );
        }
    }

    #[test]
    fn switch_substituted_arm_body_barriers() {
        // A multi-arg arm body that is a substitution
        // (`$handler`, `[cmd]`, a quoted word) must NOT be lowered from its
        // unsubstituted spelling — the switch defers to the runtime command so
        // no phantom Call to `${handler}` is fabricated.
        for src in [
            "switch $x a $handler",
            "switch $x a [get_handler]",
            "switch $x a \"puts $x\"",
            "switch $x a {puts a} b $other",
        ] {
            let m = lower_to_ir(src, &reg());
            super::super::tests::assert_runtime_opaque_call(
                &m.top_level.statements[0],
                &reg(),
                "switch",
            );
        }
    }

    #[test]
    fn switch_static_arm_body_still_lowers() {
        // FP-guard for: genuinely literal arm bodies (braced,
        // and the `-` fallthrough marker) still lower to a structured Switch.
        for src in [
            "switch $x a {puts a} b {puts b}",
            "switch $x a - b {puts b}",
        ] {
            let m = lower_to_ir(src, &reg());
            assert!(
                matches!(&m.top_level.statements[0], Statement::Switch { .. }),
                "expected structured Switch for {src:?}, got {:?}",
                m.top_level.statements[0],
            );
        }
    }

    /// `case` lowers through the switch hook on its own descriptor:
    /// no word is an option, the `in` word is skipped, and every clause is
    /// a glob comparison — an opaque glob `Statement::Switch` naming `case`
    /// in each form, its final `default` the default body.
    #[test]
    fn case_lowers_as_an_opaque_glob_selection() {
        for src in [
            "case abc in a* {puts A} default {puts D}",
            "case abc a* {puts A} default {puts D}",
            "case abc in {a* {puts A} default {puts D}}",
            "case abc {a* {puts A} default {puts D}}",
        ] {
            let m = lower_to_ir(src, &reg());
            let Statement::Switch {
                subject,
                arms,
                default_body,
                mode,
                nocase,
                command,
                ..
            } = &m.top_level.statements[0]
            else {
                panic!(
                    "expected a Switch for {src:?}, got {:?}",
                    m.top_level.statements[0]
                );
            };
            assert_eq!(subject, "abc", "{src:?}");
            assert_eq!(*mode, SwitchMode::Glob, "{src:?}");
            assert!(!nocase, "{src:?}");
            assert_eq!(command, "case", "{src:?}");
            let patterns: Vec<&str> = arms.iter().map(|arm| arm.pattern.as_str()).collect();
            assert_eq!(patterns, ["a*"], "{src:?}");
            assert!(default_body.is_some(), "{src:?}");
        }
    }

    /// A `case` clause the IR arm cannot hold lowers to a barrier, so the
    /// runtime command runs it: a pattern `case` splits as a list, a
    /// substituted pattern that may be one, a `default` before the last
    /// clause (a fallback wherever it stands), and a word after the subject
    /// whose value may be the `in` separator.
    #[test]
    fn case_clauses_the_arm_cannot_hold_are_barriers() {
        for src in [
            "case abc in {x a*} {puts L} default {puts D}",
            "case abc in {a\\*} {puts E}",
            "case abc {{x a*} {puts L}}",
            "case abc in $p {puts P}",
            "case abc in default {puts D} a* {puts A}",
            "case abc $w a* {puts A}",
        ] {
            let m = lower_to_ir(src, &reg());
            assert!(
                matches!(&m.top_level.statements[0], Statement::Barrier { .. }),
                "expected a barrier for {src:?}, got {:?}",
                m.top_level.statements[0],
            );
        }
    }

    /// From 9.0 there is no `case` command, so nothing lowers it.
    #[test]
    fn case_does_not_lower_under_9() {
        let registry = tcl_registry::model::ingress::static_context_for("tcl9.0").commands();
        let profile =
            tcl_registry::model::ingress::resolve_environment("tcl9.0").analyser_profile();
        let m = crate::lowering::lower_to_ir_with_dialect(
            "case abc in a* {puts A}",
            registry,
            tcl_lexer::LexerConfig::default(),
            Some(profile),
        );
        assert!(
            !matches!(&m.top_level.statements[0], Statement::Switch { .. }),
            "{:?}",
            m.top_level.statements[0]
        );
    }

    /// Each word's delimiters reach the statement: per word, whether it was
    /// braced (`raw_arg_braced`) or double-quoted (`raw_arg_quoted`), so a
    /// bare `-` body is told apart from a quoted or braced one.
    #[test]
    fn a_switch_records_how_each_word_was_delimited() {
        let m = lower_to_ir("switch -glob -- $x a \"-\" b - c {-} d {puts d}", &reg());
        let Statement::Switch {
            raw_args,
            raw_arg_braced,
            raw_arg_quoted,
            ..
        } = &m.top_level.statements[0]
        else {
            panic!("expected a Switch, got {:?}", m.top_level.statements[0]);
        };
        assert_eq!(raw_args.len(), 11, "{raw_args:?}");
        let flagged = |flags: &[bool]| -> Vec<usize> {
            flags
                .iter()
                .enumerate()
                .filter_map(|(index, &flag)| flag.then_some(index))
                .collect()
        };
        assert_eq!(flagged(raw_arg_quoted), [4], "{raw_args:?}");
        assert_eq!(flagged(raw_arg_braced), [8, 10], "{raw_args:?}");
    }

    // `patterns_braced` distinguishes a literal-pattern
    // braced block from the substituting separate-words form.

    #[test]
    fn switch_braced_block_sets_patterns_braced_true() {
        let m = lower_to_ir("switch $x { a {puts hi} b {set y 1} }", &reg());
        let Statement::Switch {
            patterns_braced, ..
        } = &m.top_level.statements[0]
        else {
            panic!("expected Switch");
        };
        assert!(
            *patterns_braced,
            "single braced `{{pat body …}}` block → patterns_braced = true",
        );
    }

    #[test]
    fn switch_separate_words_sets_patterns_braced_false() {
        // `switch $s a {body1} b {body2}` — patterns are separate words
        // that substitute at runtime, so patterns_braced must be false.
        let m = lower_to_ir("switch $x a {puts hi} b {set y 1}", &reg());
        let Statement::Switch {
            patterns_braced, ..
        } = &m.top_level.statements[0]
        else {
            panic!("expected Switch");
        };
        assert!(
            !*patterns_braced,
            "separate-words pattern form → patterns_braced = false",
        );
    }

    #[test]
    fn try_with_finally() {
        let m = lower_to_ir("try {error oops} finally {cleanup}", &reg());
        assert!(matches!(
            &m.top_level.statements[0],
            Statement::Try {
                finally_body: Some(_),
                ..
            }
        ));
    }

    #[test]
    fn try_with_handler() {
        let m = lower_to_ir("try {error oops} on error {e opts} {puts $e}", &reg());
        if let Statement::Try { handlers, .. } = &m.top_level.statements[0] {
            assert_eq!(handlers.len(), 1);
            assert_eq!(handlers[0].kind, HandlerMatch::CompletionCode);
        } else {
            panic!("expected Try");
        }
    }

    #[test]
    fn try_trap_pattern_projection_preserves_tcl_word_literalness() {
        let source = r#"try {} \
            trap {A \$B} {m o} {} \
            trap {A {$B}} {m o} {} \
            trap {A \[B\]} {m o} {} \
            trap {A {[B]}} {m o} {} \
            trap {A C:\\tmp} {m o} {} \
            trap {A {C:\tmp}} {m o} {} \
            trap "A \{" {m o} {} \
            trap $pattern {m o} {} \
            trap "A $pattern" {m o} {} \
            trap [list A B] {m o} {}"#;
        let module = lower_to_ir(source, &reg());
        let Statement::Try { handlers, .. } = &module.top_level.statements[0] else {
            panic!("expected structured try");
        };
        let patterns: Vec<_> = handlers
            .iter()
            .map(|handler| handler.trap_pattern.clone())
            .collect();
        assert_eq!(
            patterns,
            vec![
                Some(vec!["A".into(), "$B".into()]),
                Some(vec!["A".into(), "$B".into()]),
                Some(vec!["A".into(), "[B]".into()]),
                Some(vec!["A".into(), "[B]".into()]),
                Some(vec!["A".into(), r"C:\tmp".into()]),
                Some(vec!["A".into(), r"C:\tmp".into()]),
                None,
                None,
                None,
                None,
            ]
        );
    }

    #[test]
    fn try_trap_pattern_projection_uses_the_release_escape_grammar() {
        // Tcl 8.6 consumes the same wide-unicode escape extent as Tcl 9,
        // but its UTF-16-internal build replaces a non-BMP scalar with
        // U+FFFD. Tcl 9 retains the scalar. This is observable in trap's
        // error-code prefix and therefore must follow the lowerer's profile.
        let source = r#"try {} trap "A \U0001F600" {m o} {}"#;
        let pattern = |dialect| {
            let module = crate::lowering::lower_to_ir_with_config(
                source,
                &reg(),
                tcl_lexer::LexerConfig::for_dialect(dialect),
            );
            let Statement::Try { handlers, .. } = &module.top_level.statements[0] else {
                panic!("expected structured try");
            };
            handlers[0].trap_pattern.clone()
        };

        assert_eq!(pattern("tcl8.6"), Some(vec!["A".into(), "\u{fffd}".into()]));
        assert_eq!(pattern("tcl9.0"), Some(vec!["A".into(), "😀".into()]));
    }

    #[test]
    fn try_dash_handler_body_is_fallthrough() {
        // A `-` handler body is a fallthrough marker (shares the
        // next non-`-` handler's body, like `switch`), not a zero-arg `-`
        // command. It must lower to a fallthrough handler with an empty body.
        let m = lower_to_ir(
            "try {set x 1} on ok result - trap NONE result {return 0} on error msg {return 1}",
            &reg(),
        );
        let Statement::Try { handlers, .. } = &m.top_level.statements[0] else {
            panic!("expected Try");
        };
        let shape: Vec<(HandlerMatch, &str, bool)> = handlers
            .iter()
            .map(|h| (h.kind, h.match_arg.as_str(), h.fallthrough))
            .collect();
        assert_eq!(
            shape,
            vec![
                (HandlerMatch::CompletionCode, "ok", true),
                (HandlerMatch::ErrorCodePrefix, "NONE", false),
                (HandlerMatch::CompletionCode, "error", false)
            ],
        );
        // The fallthrough handler carries no statements of its own.
        assert_eq!(handlers[0].body.statements, [] as [crate::ir::Statement; 0]);
        assert_ne!(handlers[1].body.statements, [] as [crate::ir::Statement; 0]);
    }

    #[test]
    fn try_braced_dash_handler_body_is_fallthrough() {
        // Per Tcl's `TclNRTryObjCmd`, a body of `{-}` evaluates to the string
        // `-` and is equally a fallthrough marker.
        let m = lower_to_ir("try {set x 1} on ok a {-} trap NONE b {return $b}", &reg());
        let Statement::Try { handlers, .. } = &m.top_level.statements[0] else {
            panic!("expected Try");
        };
        assert!(handlers[0].fallthrough);
        assert_eq!(handlers[0].body.statements, [] as [crate::ir::Statement; 0]);
    }

    #[test]
    fn try_consecutive_dash_handlers_are_fallthrough() {
        // Several `-` handlers in a row all share the final body.
        let m = lower_to_ir(
            "try {set x 1} on ok a - on return b - trap NONE c {return $c}",
            &reg(),
        );
        let Statement::Try { handlers, .. } = &m.top_level.statements[0] else {
            panic!("expected Try");
        };
        let flags: Vec<bool> = handlers.iter().map(|h| h.fallthrough).collect();
        assert_eq!(flags, vec![true, true, false]);
    }

    #[test]
    fn try_empty_brace_handler_body_is_not_fallthrough() {
        // A genuinely empty `{}` body is valid and distinct from `-`.
        let m = lower_to_ir("try {set x 1} on ok a {} on error b {return $b}", &reg());
        let Statement::Try { handlers, .. } = &m.top_level.statements[0] else {
            panic!("expected Try");
        };
        assert!(!handlers[0].fallthrough);
    }

    #[test]
    fn try_quoted_dash_handler_body_is_fallthrough() {
        // A quoted `"-"` evaluates to the string `-`, like the bare/braced forms.
        let m = lower_to_ir(
            "try {set x 1} on ok a \"-\" trap NONE b {return $b}",
            &reg(),
        );
        let Statement::Try { handlers, .. } = &m.top_level.statements[0] else {
            panic!("expected Try");
        };
        assert!(handlers[0].fallthrough);
        assert_eq!(handlers[0].body.statements, [] as [crate::ir::Statement; 0]);
    }

    #[test]
    fn try_backslash_escaped_dash_handler_body_is_fallthrough() {
        // Tcl applies backslash substitution before `try` sees the word, so a
        // bare `\-` / `\x2d` body evaluates to `-` and is a fallthrough
        // marker.
        for src in [
            "try {set x 1} on ok a \\- trap NONE b {return $b}",
            "try {set x 1} on ok a \\x2d trap NONE b {return $b}",
            "try {set x 1} on ok a \"\\-\" trap NONE b {return $b}",
        ] {
            let m = lower_to_ir(src, &reg());
            let Statement::Try { handlers, .. } = &m.top_level.statements[0] else {
                panic!("expected Try for {src:?}");
            };
            assert!(handlers[0].fallthrough, "expected fallthrough for {src:?}");
            assert_eq!(
                handlers[0].body.statements.len(),
                0,
                "expected empty body for {src:?}",
            );
        }
    }

    #[test]
    fn try_braced_escaped_dash_handler_body_is_not_fallthrough() {
        // Braces suppress backslash substitution: `{\-}` is the literal
        // two-char string `\-`, which is *not* the `-` fallthrough marker.
        let m = lower_to_ir(
            "try {set x 1} on ok a {\\-} trap NONE b {return $b}",
            &reg(),
        );
        let Statement::Try { handlers, .. } = &m.top_level.statements[0] else {
            panic!("expected Try");
        };
        assert!(
            !handlers[0].fallthrough,
            "braced `{{\\-}}` is a literal string, not a fallthrough",
        );
    }

    #[test]
    fn catch_with_vars() {
        let m = lower_to_ir("catch {expr 1/0} result opts", &reg());
        if let Statement::Catch {
            result_var,
            options_var,
            ..
        } = &m.top_level.statements[0]
        {
            assert_eq!(result_var.as_deref(), Some("result"));
            assert_eq!(options_var.as_deref(), Some("opts"));
        } else {
            panic!("expected Catch");
        }
    }

    #[test]
    fn catch_preserves_command_tokens() {
        // ``Statement::Catch`` must carry the full ``CommandTokens``
        // snapshot so the CFG's ``Catch → Call`` lowering
        // (`emit_opaque_catch`) can preserve the brace-vs-bare
        // shape of the body word when reconstructing the script
        // for the runtime's eval-fallback.
        let m = lower_to_ir("catch {set x 1} result", &reg());
        if let Statement::Catch { tokens, .. } = &m.top_level.statements[0] {
            let tokens = tokens.as_ref().expect("tokens populated");
            // 3 words: ``catch`` + ``{set x 1}`` + ``result``.
            assert_eq!(tokens.argv.len(), 3);
        } else {
            panic!("expected Catch");
        }
    }

    #[test]
    fn catch_dollar_var_body_falls_through_to_barrier() {
        // ``catch $cmd res`` has a single VAR token body, not a
        // brace-literal `Str` token.  The lowering must treat it
        // as a dynamic body and emit a Barrier so the runtime
        // ``eval_catch`` evaluates the substituted value.
        let m = lower_to_ir("catch $cmd res", &reg());
        assert!(matches!(
            &m.top_level.statements[0],
            Statement::Barrier { reason, .. } if reason == "catch with dynamic body"
        ));
    }

    #[test]
    fn catch_bracket_command_body_falls_through_to_barrier() {
        // ``catch [build] res`` — single-token but command-subst,
        // not brace-literal.  Must hit the Barrier path.
        let m = lower_to_ir("catch [build] res", &reg());
        super::super::tests::assert_runtime_opaque_call(
            &m.top_level.statements[0],
            &reg(),
            "catch",
        );
    }

    #[test]
    fn dict_set() {
        let m = lower_to_ir("dict set d key value", &reg());
        assert!(matches!(
            &m.top_level.statements[0],
            Statement::Call { command, defs, .. }
                if command == "dict" && defs.contains(&"d".to_string())
        ));
    }

    #[test]
    fn dict_for() {
        let m = lower_to_ir("dict for {k v} $d {puts $k}", &reg());
        assert!(matches!(
            &m.top_level.statements[0],
            Statement::Foreach {
                is_dict_iteration: true,
                ..
            }
        ));
    }

    // `while`/`for`/`foreach`/`try`/`dict for` must gate their body word on
    // the token's kind, not single-token-ness alone. `$body` is a single VAR
    // token, so a single-token gate lowers it as if its reconstructed text
    // (`${body}`) were the literal script — miscompiling, or (when the
    // reconstruction lengthens the word, as `${body}` does over `$body`)
    // panicking in codegen on an out-of-bounds span. Each must barrier
    // instead, mirroring `catch_dollar_var_body_falls_through_to_barrier`.

    #[test]
    fn while_dollar_var_body_falls_through_to_barrier() {
        let m = lower_to_ir("while {1} $body", &reg());
        assert!(matches!(
            &m.top_level.statements[0],
            Statement::Barrier { reason, .. } if reason == "while with dynamic arguments"
        ));
    }

    #[test]
    fn for_dollar_var_body_falls_through_to_barrier() {
        let m = lower_to_ir("for {} {1} {} $body", &reg());
        assert!(matches!(
            &m.top_level.statements[0],
            Statement::Barrier { reason, .. } if reason == "for with dynamic arguments"
        ));
    }

    #[test]
    fn foreach_dollar_var_body_falls_through_to_barrier() {
        let m = lower_to_ir("foreach x $l $body", &reg());
        assert!(matches!(
            &m.top_level.statements[0],
            Statement::Barrier { reason, .. } if reason == "foreach with dynamic body"
        ));
    }

    #[test]
    fn try_dollar_var_body_falls_through_to_barrier() {
        let m = lower_to_ir("try $body", &reg());
        assert!(matches!(
            &m.top_level.statements[0],
            Statement::Barrier { reason, .. } if reason == "try with dynamic body"
        ));
    }

    // …and the `try` bodies: a gate on the primary body alone leaves
    // `finally` and every non-`-` `on`/`trap` handler walking a `$body` word
    // and rebasing its reconstructed text
    // off the end of the source. tclsh 8.6.16 / 9.0.4 run both spellings fine
    // (`set body {puts hi}; try {} finally $body` prints `hi`), so the
    // degraded path must be a barrier — the runtime `try` — not a panic.
    // C's `TclCompileTryCmd` bails on the same words for the same reason.

    #[test]
    fn try_dollar_var_finally_body_falls_through_to_barrier() {
        let m = lower_to_ir("try {} finally $body", &reg());
        assert!(
            matches!(
                &m.top_level.statements[0],
                Statement::Barrier { reason, .. } if reason == "try with dynamic finally body"
            ),
            "got {:?}",
            m.top_level.statements[0],
        );
    }

    #[test]
    fn try_dollar_var_handler_body_falls_through_to_barrier() {
        for src in [
            "try {error x} on error {} $body",
            "try {error x} trap NONE {} $body",
            "try {error x} on error {} [subst $body]",
            "try {error x} on error {} $body finally {puts bye}",
        ] {
            let m = lower_to_ir(src, &reg());
            assert!(
                matches!(
                    &m.top_level.statements[0],
                    Statement::Barrier { reason, .. } if reason == "try with dynamic handler body"
                ),
                "expected a dynamic-handler-body barrier for {src:?}, got {:?}",
                m.top_level.statements[0],
            );
        }
    }

    #[test]
    fn try_static_finally_and_handler_bodies_still_lower() {
        // FP-guard: the gate narrows the walk, it does not switch it off.
        for src in [
            "try {error x} finally {puts bye}",
            "try {error x} on error {} {puts bad}",
            "try {error x} trap NONE {m o} {puts $m} finally {puts bye}",
            // The `-` fallthrough marker is not a body and keeps its own path.
            "try {set x 1} on ok a - trap NONE b {return $b}",
        ] {
            let m = lower_to_ir(src, &reg());
            assert!(
                matches!(&m.top_level.statements[0], Statement::Try { .. }),
                "expected a structured Try for {src:?}, got {:?}",
                m.top_level.statements[0],
            );
        }
    }

    #[test]
    fn dict_for_dollar_var_body_falls_through_to_barrier() {
        let m = lower_to_ir("dict for {k v} $d $body", &reg());
        assert!(matches!(
            &m.top_level.statements[0],
            Statement::Barrier { reason, .. } if reason == "dict for with dynamic body"
        ));
    }

    // A varList word is a Tcl list, not a whitespace split: a splitter that
    // takes only the first word of a braced element, or cuts a
    // backslash-escaped space in two, binds the wrong names for both spellings
    // of a one-variable binding.

    /// Loop-variable names of the single-iterator `foreach` at statement 0.
    fn foreach_vars(src: &str) -> Vec<String> {
        let m = lower_to_ir(src, &reg());
        let Statement::Foreach { iterators, .. } = &m.top_level.statements[0] else {
            panic!("expected Foreach for {src:?}, got {:?}", m.top_level);
        };
        assert_eq!(iterators.len(), 1, "one iterator for {src:?}");
        iterators[0].vars.clone()
    }

    #[test]
    fn foreach_grouped_var_element_binds_one_name() {
        // tclsh 9.0: `proc s {} { foreach {{x y}} {1} {}; info locals }`
        // reports the single local named `x y`.
        assert_eq!(foreach_vars("foreach {{x y}} {1} {puts hi}"), vec!["x y"]);
    }

    #[test]
    fn foreach_escaped_space_var_binds_one_name() {
        // Same for the escaped spelling: `foreach {a\ b} {1} {}` binds
        // the one local `a b`, not the two names `a\` and `b`.
        assert_eq!(foreach_vars("foreach {a\\ b} {1} {puts hi}"), vec!["a b"]);
    }

    #[test]
    fn foreach_plain_var_list_still_binds_every_name() {
        // FP-guard: the ordinary multi-variable list is unchanged.
        assert_eq!(
            foreach_vars("foreach {m n} {1 2} {puts hi}"),
            vec!["m", "n"]
        );
        assert_eq!(foreach_vars("foreach x {1 2} {puts hi}"), vec!["x"]);
    }

    #[test]
    fn dict_for_grouped_var_element_binds_one_name() {
        assert_eq!(
            foreach_vars("dict for {{k 1} v} $d {puts hi}"),
            vec!["k 1", "v"],
        );
    }

    #[test]
    fn malformed_var_list_falls_through_to_barrier() {
        // An unbalanced varList names no binding, so each loop defers to its
        // runtime command, which raises Tcl's own list error.
        for (src, expected) in [
            (
                "foreach {a \"b} {1} {puts hi}",
                "foreach with malformed variable list",
            ),
            (
                "dict for {k \"v} $d {puts hi}",
                "dict for with malformed variable list",
            ),
            (
                "try {puts hi} on error {m \"o} {puts bad}",
                "try with malformed handler variable list",
            ),
        ] {
            let m = lower_to_ir(src, &reg());
            assert!(
                matches!(&m.top_level.statements[0], Statement::Barrier { reason, .. } if reason == expected),
                "expected {expected:?} barrier for {src:?}, got {:?}",
                m.top_level.statements[0],
            );
        }
    }
}

#[cfg(test)]
mod switch_span_tests {
    use crate::compilation_unit::CompilationUnit;
    use crate::ir::Statement;
    use tcl_registry::CommandRegistry;

    #[test]
    fn switch_arm_and_default_spans_point_at_body_text() {
        let src = "switch foo { foo { puts one } bar { puts two } default { puts none } }";
        let r = CommandRegistry::build_default();
        let cu = CompilationUnit::build_for(src, &r, false);

        // Locate the switch statement in the IR (top-level).
        let switch = cu
            .ir_module
            .top_level
            .statements
            .iter()
            .find(|s| matches!(s, Statement::Switch { .. }))
            .expect("switch statement");

        let Statement::Switch {
            arms,
            default_body,
            default_span,
            ..
        } = switch
        else {
            panic!("expected Switch variant");
        };

        assert_eq!(arms.len(), 2);
        for arm in arms {
            let span = arm.body_span.expect("arm body_span populated");
            let text = &src[span.as_range()];
            assert!(
                text.starts_with('{') && text.ends_with('}'),
                "expected braced body, got {text:?}",
            );
            assert!(
                text.contains("puts"),
                "expected body to contain `puts`, got {text:?}",
            );
        }

        assert!(default_body.is_some());
        let dspan = default_span.expect("default_span populated");
        let dtext = &src[dspan.as_range()];
        assert!(
            dtext.contains("puts none"),
            "expected default body to contain `puts none`, got {dtext:?}",
        );
    }

    /// An element of a braced case list collapses its backslashes under the
    /// document's grammar: before Tcl 8.6 a `\x` takes every hex digit that
    /// follows and keeps the last two, so `a\x41b` is `a` and U+001B there
    /// and `aAb` from 8.6.
    #[test]
    fn a_braced_case_list_decodes_its_elements_under_the_documents_escapes() {
        let pattern_under = |dialect: &str, source: &str| -> String {
            let registry = tcl_registry::model::ingress::static_context_for(dialect).commands();
            let module = crate::lowering::lower_to_ir_with_dialect(
                source,
                registry,
                tcl_lexer::LexerConfig::for_profile(registry.profile()),
                registry.profile(),
            );
            let Statement::Switch { arms, .. } = &module.top_level.statements[0] else {
                panic!(
                    "expected a Switch, got {:?}",
                    module.top_level.statements[0]
                );
            };
            arms[0].pattern.clone()
        };
        for source in [
            r#"switch -- aAb {"a\x41b" {puts hit} default {puts miss}}"#,
            r"switch -- aAb {a\x41b {puts hit} default {puts miss}}",
        ] {
            assert_eq!(pattern_under("tcl8.4", source), "a\u{1b}", "{source}");
            assert_eq!(pattern_under("tcl8.5", source), "a\u{1b}", "{source}");
            assert_eq!(pattern_under("tcl8.6", source), "aAb", "{source}");
            assert_eq!(pattern_under("tcl9.0", source), "aAb", "{source}");
        }
    }
}

#[cfg(test)]
mod original_body_word_caller_tests {
    use crate::compilation_unit::{CompilationUnit, UnitBuildOptions};
    use crate::ir::{CommandTokens, Statement};
    use std::sync::Arc;
    use tcl_registry::model::ContextRegistry;

    fn original_unit(
        source: &str,
        environment: &str,
    ) -> (
        Arc<ContextRegistry>,
        crate::environment_ingress::RetainedNativeUnit,
    ) {
        let environment = tcl_registry::model::ingress::resolve_known_environment(environment)
            .expect("actual selected source environment");
        let context = environment.default_context_registry();
        let profile = environment.unit_profile();
        let config = tcl_lexer::LexerConfig::for_profile(Some(profile));
        let input = crate::analyser::ResolvedAnalysisInput::new(
            profile,
            profile,
            Arc::clone(&context),
            config,
        );
        let (owner, native) = crate::environment_ingress::captured_native_entry_with_owner(profile);
        assert_eq!(native.execution_point, environment.point());
        let entry = crate::command_binding::SourceAnalysisEntry {
            metadata_context:
                crate::registry_invocation::OwnedInvocationMetadataContext::for_source_input(Some(
                    &input,
                )),
            native_entry: Some(Arc::new(native)),
            invocation_dialect: Some(tcl_registry::InvocationDialect::of_profile(profile)),
            native_compilation: crate::environment_ingress::authoring_native_compilation(),
            ..Default::default()
        };
        let unit = CompilationUnit::build_with_analysis_input(
            source,
            UnitBuildOptions {
                registry: context.commands(),
                defer_top_level: false,
                config,
                dialect: Some(profile),
                external_call_sites: None,
                declared_commands: None,
            },
            Some(&entry),
            &input,
        );
        (
            context,
            crate::environment_ingress::RetainedNativeUnit::new(unit, owner),
        )
    }

    fn original_parent(unit: &CompilationUnit) -> &CommandTokens {
        let top = &unit.ir_module.top_level;
        top.retained_source_tokens_for_statement(&top.statements[0])
            .expect("actual structured parent source vector")
    }

    #[test]
    fn original_structured_body_caller_keeps_parent_ordinal_and_namespace() {
        // naming.source.original-point-operand-projection
        // docs/design/analysis/name-resolution-proofs/original-point-operand-projection.md
        // Actual software lowering and selected source context; no external
        // provider execution or proof that a conditional body entered.
        for source in [
            "if {$condition} {set first café} else {set second two}",
            "if {$condition} {set first \\\n café} else {set second \\\n two}",
        ] {
            for environment in ["tcl8.4", "tcl9.0"] {
                let (context, unit) = original_unit(source, environment);
                let module = &unit.ir_module;
                let parent = original_parent(&unit);
                let binding = parent.source_binding.as_ref().unwrap();
                let input = module.source_metadata_input.as_ref().unwrap();
                let metadata = crate::registry_invocation::InvocationMetadataContext::for_module(
                    context.commands(),
                    module,
                )
                .unwrap();
                let Statement::If {
                    clauses, else_body, ..
                } = &module.top_level.statements[0]
                else {
                    panic!("actual original source retains its structured If");
                };
                assert_eq!(clauses.len(), 1);
                let bodies = [&clauses[0].body, else_body.as_ref().unwrap()];
                for (body, word) in bodies.into_iter().zip([2, 4]) {
                    let expected = binding
                        .original_body_source_for_word(
                            parent,
                            parent.words()[word].source().span,
                            input.lexer_config(),
                        )
                        .unwrap();
                    assert_eq!(body.executed_source.as_deref(), Some(&expected));
                    if let crate::command_binding::SourceOriginKind::Derived {
                        parent: actual_parent,
                        arguments,
                        source: actual_source,
                        ..
                    } = expected.origin.kind()
                    {
                        assert_eq!(actual_parent, binding.invocation_site().unwrap());
                        assert_eq!(arguments.as_slice(), &[word - 1]);
                        assert_eq!(actual_source, &expected.text);
                        assert_eq!(expected.base(), 0);
                    } else {
                        assert!(!source.contains('\\'));
                    }
                    let namespace = binding
                        .original_body_namespace_context(
                            context.commands(),
                            metadata,
                            parent,
                            &expected,
                        )
                        .expect("authentic selected immediate-body namespace");
                    assert_eq!(body.namespace_context.as_deref(), Some(&namespace));
                    assert!(!body.statements.is_empty());
                    assert!(body.statements.iter().all(|statement| !matches!(
                        statement, Statement::Barrier { reason, .. }
                            if reason == "original body namespace context is unavailable"
                    )));
                    let child = body
                        .retained_source_tokens_for_statement(&body.statements[0])
                        .expect("lowered child keeps its original source tokens");
                    assert_eq!(child.argv_texts.first().map(String::as_str), Some("set"));
                    assert_eq!(child.words().len(), 3);
                    assert_eq!(
                        child
                            .source_binding
                            .as_ref()
                            .unwrap()
                            .original_lexer_config_for_tokens(child),
                        Some(input.lexer_config()),
                    );
                }
            }
        }
    }

    #[test]
    fn original_structured_body_word_caller_refuses_full_extent_and_changed_parent() {
        // naming.source.original-point-operand-projection
        // docs/design/analysis/name-resolution-proofs/original-point-operand-projection.md
        let source = "if {$condition} {set first café} else {set second two}";
        let (_, unit) = original_unit(source, "tcl9.0");
        let parent = original_parent(&unit);
        let config = unit.ir_module.lexer_config;
        let binding = parent.source_binding.as_ref().unwrap();
        let span = parent.words()[2].source().span;
        let whole = tcl_lexer::word_span_at(source, span);
        assert_ne!(
            span, whole,
            "nonempty original braced word has distinct extents"
        );
        assert!(
            binding
                .original_body_source_for_word(parent, span, config)
                .is_some()
        );
        assert!(
            binding
                .original_body_source_for_word(parent, whole, config)
                .is_none()
        );
        let changed = tcl_lexer::Span::new(span.start().checked_add(1).unwrap(), span.end());
        assert!(
            binding
                .original_body_source_for_word(parent, changed, config)
                .is_none()
        );
        let mut changed_vector = parent.clone();
        changed_vector.argv_texts[2] = "set first changed".into();
        assert!(
            binding
                .original_body_source_for_word(&changed_vector, span, config)
                .is_none()
        );
        let (_, foreign) = original_unit(
            "if {$condition} {set first élan} else {set second two}",
            "tcl9.0",
        );
        let mut changed_source = parent.clone();
        changed_source.source_binding = original_parent(&foreign).source_binding.clone();
        assert!(
            changed_source
                .source_binding
                .as_ref()
                .unwrap()
                .original_body_source_for_word(&changed_source, span, config)
                .is_none()
        );
        let mut changed_config = config;
        changed_config.leading_bom = tcl_lexer::LeadingBom::Skip;
        assert!(
            binding
                .original_body_source_for_word(parent, span, changed_config)
                .is_none()
        );
    }
}
