// tcl-lsp — a language server and toolchain for Tcl
// Copyright (C) 2026 James Deucker (bitwisecook) <https://github.com/bitwisecook>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.
//
// SPDX-License-Identifier: AGPL-3.0-or-later

//! Loop-termination index-bounds checks (W230-W242).
//!
//! Covers the **loop-termination** family (W240 / W241 / W242 over
//! `while` / `for`, including the provably-infinite counter heuristic)
//! and the **index-bounds** family (W230 over `lindex` / `lrange` /
//! `lreplace`, W231 over `lset`, W232 over `string index` / `range` /
//! `replace`).  W242 (unprovable termination) is always emitted here; its
//! default-off opt-in is a consuming-layer concern.
//!
//! The walk reads the literal text of the condition and body, and a loop's
//! counter as its iteration plan states it: the bound its condition compares
//! with, and the step every pass adds — a counted loop's step script, or a
//! conditional loop's one increment, each read through the registry's cell
//! update. What else may write the counter, and where it starts, are the
//! flow graph's and the solver's answers, read by the per-function pass for
//! a loop its unit holds and does not decide
//! ([`LoopTerminationCandidate::settle`]); a loop no unit holds keeps what
//! its condition's text says.

mod source_index;
pub(super) use source_index::original_index_diagnostics;

use tcl_core_types::DiagCode;
use tcl_lexer::{ExprToken, ExprTokenType, Token, TokenType, tokenise_expr_checked_with_grammar};

use crate::segmenter::{SegmentedCommand, segment_commands_with_offset_and_config};

use super::types::{Diagnostic, Severity};

/// Metadata for shallow written syntax and numeric advice. Retained analysis
/// callers supply the actual context; explicit standalone controls select
/// their own catalogue. Neither mode supplies Native identity or effects.
#[derive(Clone, Copy)]
pub(crate) enum BoundsMetadataContext<'a> {
    Retained(&'a tcl_registry::model::ContextRegistry),
    #[cfg(test)]
    Standalone(Option<&'a tcl_registry::CommandRegistry>),
}
impl<'a> BoundsMetadataContext<'a> {
    fn commands(self) -> &'a tcl_registry::CommandRegistry {
        match self {
            Self::Retained(context) => context.commands(),
            #[cfg(test)]
            Self::Standalone(registry) => match registry {
                Some(registry) => registry,
                None => tcl_registry::default_registry(),
            },
        }
    }

    fn spec(self, name: &str) -> Option<&'a tcl_registry::CommandSpec> {
        match self {
            Self::Retained(context) => context.context().resolve_spec(context.commands(), name),
            #[cfg(test)]
            Self::Standalone(registry) => registry
                .unwrap_or_else(|| {
                    tcl_registry::model::ingress::static_context_for("tcl8.6").commands()
                })
                .get(name),
        }
    }
    fn argument_indices(
        self,
        head: &str,
        args: &[&str],
        role: tcl_registry::ArgRole,
    ) -> Vec<usize> {
        match self {
            #[cfg(test)]
            Self::Standalone(registry) => registry
                .unwrap_or_else(|| {
                    tcl_registry::model::ingress::static_context_for("tcl8.6").commands()
                })
                .arg_indices_for_role(head, args, role),
            Self::Retained(context) => {
                let values = args
                    .iter()
                    .map(|argument| {
                        if crate::naming::is_dynamic_word(argument) {
                            tcl_registry::InvocationWord::Dynamic
                        } else {
                            tcl_registry::InvocationWord::Literal(argument)
                        }
                    })
                    .collect::<Vec<_>>();
                let resolution = tcl_registry::model::assembly::resolve_structured_invocation_in_resolved_context(
                    context.commands(), Some(context.context()),
                    tcl_registry::InvocationWords::structured(tcl_registry::InvocationWord::Literal(head), &values),
                    tcl_dialect::model::InvocationRealm::RuleLoader,
                );
                let Some(schema) = resolution.resolved() else {
                    return Vec::new();
                };
                let (roles, complete) = schema.authored_source_argument_roles();
                if !complete {
                    return Vec::new();
                }
                roles
                    .into_iter()
                    .filter_map(|(ordinal, found)| {
                        (found == role)
                            .then(|| usize::from(ordinal) + schema.semantics.argument_offset)
                    })
                    .collect()
            }
        }
    }
}

/// The comparison operators a simple `for`-condition may use.
const SIMPLE_CMP_OPS: &[&str] = &["<=", ">=", "<", ">", "==", "!=", "eq", "ne"];

/// Whether `name` in command position ends the current loop's straight-line
/// flow — the set consulted by the W241 "provably infinite" check.
///
/// Selected `BREAKS_LOOP`, `REPLACES_FRAME` and `TERMINATES_BLOCK` traits
/// share the actual metadata context. This is shallow source advice; a
/// written spelling alone supplies no Native control-flow effect.
fn is_loop_exit_command(name: &str, registry: BoundsMetadataContext<'_>) -> bool {
    registry.spec(name).is_some_and(|spec| {
        spec.traits.intersects(
            tcl_registry::Traits::TERMINATES_BLOCK
                .union(tcl_registry::Traits::BREAKS_LOOP)
                .union(tcl_registry::Traits::REPLACES_FRAME),
        )
    })
}

/// Which argument of a conditional-loop invocation is which: the boolean
/// condition and the loop body. Indices exclude the command name.
struct LoopShape {
    cond: usize,
    body: usize,
}

/// The loop shape of `name` invoked with `args`, or `None` when it is not a
/// conditional loop.
///
/// Whether a command *is* a loop is the command surface's answer — the
/// `HAS_LOOP_BODY` trait, which a catalogue command states in its spec and a
/// document's stub states with `-loop` — and the shape is read off its
/// argument roles: the `Expr` word is the condition, and the last `Body` word
/// after it is the loop body. A pack-declared or stub-declared loop therefore
/// reaches W240 / W241 / W242 with no command name written here. A name the
/// document declares answers from its declaration alone (nearest wins), so a
/// stub that redeclares `while` without `-loop` is not a loop.
///
fn loop_shape(
    name: &str,
    args: &[String],
    registry: BoundsMetadataContext<'_>,
    surface: Option<&tcl_registry::model::DocumentCommandSurface<'_>>,
) -> Option<LoopShape> {
    use tcl_registry::ArgRole;
    if let Some(surface) = surface.filter(|surface| surface.declares(name)) {
        if !surface
            .traits(name)
            .is_some_and(|traits| traits.contains(tcl_registry::Traits::HAS_LOOP_BODY))
        {
            return None;
        }
        let words: Vec<_> = args.iter().map(String::as_str).collect();
        return conditional_loop_shape([ArgRole::Expr, ArgRole::Body].into_iter().flat_map(
            |role| {
                surface
                    .arg_indices_for_role(name, &words, role)
                    .into_iter()
                    .map(move |index| (index, role))
            },
        ));
    }
    let Some(spec) = registry.spec(name) else {
        #[cfg(test)]
        if matches!(registry, BoundsMetadataContext::Standalone(_)) {
            return core_loop_shape(name);
        }
        return None;
    };
    spec.traits
        .contains(tcl_registry::Traits::HAS_LOOP_BODY)
        .then(|| {
            conditional_loop_shape(
                spec.arg_roles
                    .iter()
                    .map(|&(index, role)| (usize::from(index), role)),
            )
        })
        .flatten()
}

/// Core syntax positions for standalone test controls without a catalogue.
#[cfg(test)]
fn core_loop_shape(name: &str) -> Option<LoopShape> {
    match name {
        "while" => Some(LoopShape { cond: 0, body: 1 }),
        "for" => Some(LoopShape { cond: 1, body: 3 }),
        _ => None,
    }
}

/// Read a loop's condition / body positions off its argument roles,
/// or `None` when it has no single boolean-condition word — `foreach` and
/// `lmap` iterate a list rather than testing a condition, so nothing here
/// applies to them.
fn conditional_loop_shape(
    roles: impl IntoIterator<Item = (usize, tcl_registry::arg_role::ArgRole)>,
) -> Option<LoopShape> {
    let mut cond = None;
    let mut bodies: Vec<usize> = Vec::new();
    for (index, role) in roles {
        match role {
            tcl_registry::arg_role::ArgRole::Expr if cond.is_some() => return None,
            tcl_registry::arg_role::ArgRole::Expr => cond = Some(index),
            tcl_registry::arg_role::ArgRole::Body => bodies.push(index),
            _ => {}
        }
    }
    let cond = cond?;
    bodies.sort_unstable();
    let body = bodies.iter().copied().rfind(|&i| i > cond)?;
    Some(LoopShape { cond, body })
}

/// What a conditional loop's text says about its termination — the verdict
/// the walk reaches before any solver fact is known — and, for a loop its
/// unit holds and does not decide, what that unit adds
/// ([`LoopTerminationCandidate::settle`]).
#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) enum LexicalVerdict {
    /// The condition is a constant-false literal: the body never executes.
    Dead,
    /// The loop never terminates: a constant-true literal condition over a
    /// body that never leaves the loop (`None`), or a counter that never
    /// reaches its bound (the reason it gives).
    Infinite(Option<String>),
    /// Nothing in the loop may write the variable the condition reads.
    Unprovable(String),
    /// Nothing is said.
    Silent,
}

/// A loop whose termination the walk examined. The per-function pass
/// resolves it against the unit's branch fact at its condition span
/// ([`Self::resolve`]), and reads its counter against what the unit that
/// holds it knows when that unit does not decide it ([`Self::settle`]); a
/// loop no unit decides keeps its verdict.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct LoopTerminationCandidate {
    /// The loop command as the document spells it.
    pub cmd_name: String,
    /// The condition word's span — where every verdict is reported, and the
    /// key of the branch fact.
    pub condition_span: tcl_lexer::Span,
    /// What the loop's text says.
    pub lexical: LexicalVerdict,
    /// Whether the body holds, in command position, a command that leaves
    /// the loop ([`is_loop_exit_command`]) — a path the flow graph cannot see
    /// inside a script it does not lower.
    pub body_may_exit: bool,
    /// The loop's counter, when its plan states one ([`loop_counter`]).
    pub counter: Option<LoopCounter>,
    /// The variable W242 asks after: the condition's first scalar read
    /// ([`extract_counter_name`]), for a condition that is no constant.
    pub progress_var: Option<String>,
}

/// The variables the module may write where no function's statements show
/// it: the names its callback scripts write and the names its variable
/// traces watch ([`crate::ir::Module::deferred_writes`],
/// [`crate::ir::Module::traced_variables`]), each spelled without a leading
/// `::`, and whether a computed name makes it any variable at all.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub(crate) struct ModuleUnseenWrites {
    /// The names.
    names: std::collections::BTreeSet<String>,
    /// A callback or a trace names a variable computed at run time.
    any: bool,
}

impl ModuleUnseenWrites {
    /// What `module`'s callback scripts and variable traces may write.
    pub(crate) fn of(module: &crate::ir::Module) -> Self {
        Self {
            names: module
                .deferred_writes
                .names
                .iter()
                .chain(&module.traced_variables)
                .map(|name| name.trim_start_matches("::").to_owned())
                .collect(),
            any: module.deferred_writes.any || module.has_dynamic_variable_trace,
        }
    }

    /// Whether a callback script or a variable trace of the module may write
    /// `var`.
    pub(crate) fn may_write(&self, var: &str) -> bool {
        self.any || self.names.contains(var.trim_start_matches("::"))
    }
}

/// What may write one variable over a loop's passes, as the unit that holds
/// the loop knows it: the statements of the loop's blocks that define it —
/// a cell update, a write a substitution makes, a binder, a destructuring
/// target, an opaque statement's may-definition, a procedure the call
/// reaches — and whether code those statements do not show may write it.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) struct LoopWrites {
    /// The statements of the loop's blocks that define the variable.
    pub definitions: usize,
    /// Whether code the loop's statements do not show may write it: a call
    /// to code the module cannot see in the loop, a callback script or a
    /// variable trace of the module, or a write to a computed name in the
    /// function.
    pub unseen: bool,
}

impl LoopWrites {
    /// Whether the loop's one write of a counter is its plan's step.
    fn step_alone(self) -> bool {
        self.definitions == 1 && !self.unseen
    }

    /// Whether nothing in the loop may write the variable.
    fn none(self) -> bool {
        self.definitions == 0 && !self.unseen
    }
}

/// A loop's counter, as its iteration plan states it: the condition compares
/// `var` with the literal `bound` by `op`, and every pass adds `step` to it —
/// the counted plan's step script, or a conditional plan's one increment at
/// its body's top level — with nothing in its body leaving the loop. That
/// nothing else writes `var` is the unit's answer ([`LoopWrites`]).
#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct LoopCounter {
    /// The counter's name.
    pub var: String,
    /// The comparison, with the counter on its left.
    op: String,
    /// The literal the counter is compared with.
    bound: i64,
    /// What every pass adds to the counter.
    step: i64,
}

impl LoopCounter {
    /// Why a loop whose counter starts at `start` never terminates, or `None`
    /// when it may: the condition holds on entry and the step is zero, moves
    /// the counter away from its bound, or steps over the one value `!=`
    /// stops at.
    fn never_terminates(&self, start: i64) -> Option<String> {
        let (op, bound, step) = (self.op.as_str(), self.bound, self.step);
        if !cond_true_at(op, start, bound) {
            return None;
        }
        let counter = format!("${}", self.var);
        if step == 0 {
            return Some("step is zero ('incr' with 0) and condition holds on entry".to_string());
        }
        let away = match op {
            "<" | "<=" => step < 0,
            ">" | ">=" => step > 0,
            _ => false,
        };
        if away {
            return Some(format!(
                "counter {counter} starts at {start}, moves by {step} per step, and compares {op} \
                 {bound} (never reached)"
            ));
        }
        if matches!(op, "!=" | "ne") {
            let distance = i128::from(bound) - i128::from(start);
            if distance * i128::from(step) < 0 {
                return Some(format!(
                    "counter {counter} starts at {start}, moves by {step} per step, never \
                     reaches {bound}"
                ));
            }
            if distance % i128::from(step) != 0 {
                return Some(format!(
                    "counter {counter} starts at {start}, moves by {step} per step, never \
                     exactly equals {bound}"
                ));
            }
        }
        None
    }
}

/// What the solver decided about a loop's header condition.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum HeaderFact {
    /// False at entry: the body never runs.
    Never,
    /// True at every test; `exits` says whether an executable path leaves
    /// the loop.
    Always {
        /// An executable `break`, `return` or other exit is reachable.
        exits: bool,
    },
}

impl LoopTerminationCandidate {
    fn diagnostic(&self, code: DiagCode, message: String, severity: Severity) -> Diagnostic {
        crate::analyser::types::Diagnostic::new(code, self.condition_span, message, severity)
    }

    /// W240: the body never executes.
    fn dead(&self) -> Diagnostic {
        self.diagnostic(
            DiagCode::W240,
            format!(
                "{} condition is constant false; body never executes.",
                self.cmd_name
            ),
            Severity::Warning,
        )
    }

    /// W241: the loop never terminates, for the reason its counter gives or
    /// because the condition is constant true and the body never leaves.
    fn infinite(&self, reason: Option<&str>) -> Diagnostic {
        let message = reason.map_or_else(
            || {
                format!(
                    "{} is provably infinite: condition is constant true and the body \
                     never leaves the loop (no break/return/error/exit/throw/tailcall).",
                    self.cmd_name
                )
            },
            |reason| format!("{} loop is provably infinite: {reason}", self.cmd_name),
        );
        self.diagnostic(DiagCode::W241, message, Severity::Warning)
    }

    /// W242 (default-off): a counter variable appears in the condition but
    /// nothing in the loop may write it. The analyser always emits it; the
    /// default-off opt-in is applied by the consuming LSP/config layer.
    fn unprovable(&self, var: &str) -> Diagnostic {
        self.diagnostic(
            DiagCode::W242,
            format!(
                "{} termination cannot be proven: variable '{var}' in the \
                 condition is never modified by the step or body.",
                self.cmd_name
            ),
            Severity::Hint,
        )
    }

    /// Read the loop against what the unit that holds it knows, where that
    /// unit does not decide its header: `writes` answers what may write a
    /// variable over the loop's passes, and `start` the integer the solver
    /// proves the counter holds where they start. A counter the plan's step
    /// alone writes that never reaches its bound from its start is W241, for
    /// the reason the counter gives — so `set i $start` is checked as `set i
    /// 5` is, and a `while` as a `for` is — and else a condition variable
    /// nothing in the loop may write is W242.
    pub(crate) fn settle(
        &mut self,
        writes: impl Fn(&str) -> LoopWrites,
        start: impl Fn(&str) -> Option<i64>,
    ) {
        if self.lexical != LexicalVerdict::Silent {
            return;
        }
        if let Some(counter) = &self.counter
            && writes(&counter.var).step_alone()
            && let Some(reason) = start(&counter.var).and_then(|at| counter.never_terminates(at))
        {
            self.lexical = LexicalVerdict::Infinite(Some(reason));
            return;
        }
        if let Some(var) = &self.progress_var
            && writes(var).none()
        {
            self.lexical = LexicalVerdict::Unprovable(var.clone());
        }
    }

    /// What the loop's text alone says.
    pub(crate) fn lexical_diagnostic(&self) -> Option<Diagnostic> {
        match &self.lexical {
            LexicalVerdict::Dead => Some(self.dead()),
            LexicalVerdict::Infinite(reason) => Some(self.infinite(reason.as_deref())),
            LexicalVerdict::Unprovable(var) => Some(self.unprovable(var)),
            LexicalVerdict::Silent => None,
        }
    }

    /// What the loop draws once the solver's header fact is known: a header
    /// decided false at entry is W240, one decided true with no exit the
    /// flow graph or the body's text finds is W241, and either suppresses
    /// W242; a header the solver did not decide keeps the lexical verdict.
    pub(crate) fn resolve(&self, header: Option<HeaderFact>) -> Option<Diagnostic> {
        match header {
            None => self.lexical_diagnostic(),
            Some(HeaderFact::Never) => Some(self.dead()),
            Some(HeaderFact::Always { exits: false }) if !self.body_may_exit => {
                let reason = match &self.lexical {
                    LexicalVerdict::Infinite(reason) => reason.as_deref(),
                    _ => None,
                };
                Some(self.infinite(reason))
            }
            Some(HeaderFact::Always { .. }) => None,
        }
    }
}

/// The loop-termination candidate of every conditional loop the document's
/// command surface declares — catalogued or stub-declared, see
/// [`loop_shape`] — with what its text says: W240 for a constant-false
/// condition, W241 for a constant-true one whose body never leaves the loop;
/// for any other condition, the counter its plan states and the variable
/// W242 asks after, which the per-function pass reads
/// ([`LoopTerminationCandidate::settle`]). The loop-exit set is the
/// catalogue's — see [`is_loop_exit_command`]. `args` / `arg_tokens` exclude
/// the command name.
pub(crate) fn loop_termination_candidate(
    cmd_name: &str,
    args: &[String],
    arg_tokens: &[Token],
    registry: BoundsMetadataContext<'_>,
    surface: Option<&tcl_registry::model::DocumentCommandSurface<'_>>,
    lexer_config: tcl_lexer::LexerConfig,
    grammar: &tcl_dialect::LexerGrammar,
) -> Option<LoopTerminationCandidate> {
    let shape = loop_shape(cmd_name, args, registry, surface)?;

    // An under-applied call is an arity diagnostic, not a termination one.
    if args.len() <= shape.body || arg_tokens.len() <= shape.body {
        return None;
    }
    let may_exit = body_may_exit(args[shape.body].as_str(), registry, lexer_config);
    let words = plan_words(cmd_name, args, registry);
    let counter = words
        .as_ref()
        .and_then(|words| loop_counter(words, registry, lexer_config, grammar));
    let constant = condition_constant(args[shape.cond].as_str());
    let lexical = match constant {
        Some(false) => LexicalVerdict::Dead,
        Some(true) if !may_exit => LexicalVerdict::Infinite(None),
        Some(true) | None => LexicalVerdict::Silent,
    };
    let progress_var = constant
        .is_none()
        .then(|| extract_counter_name(args[shape.cond].as_str(), grammar))
        .flatten();
    Some(LoopTerminationCandidate {
        cmd_name: cmd_name.to_owned(),
        condition_span: arg_tokens[shape.cond].span,
        lexical,
        body_may_exit: may_exit,
        counter,
        progress_var,
    })
}

/// The words of a conditional loop's iteration plan: the condition and the
/// body, and a counted plan's step script.
struct PlanWords<'a> {
    /// The condition.
    condition: &'a str,
    /// A counted plan's step script.
    next: Option<&'a str>,
    /// The body.
    body: &'a str,
}

/// The words the iteration plan `cmd_name` declares over `args` names, when
/// it declares a counted or a conditional one
/// ([`crate::value_transfer::resolved_iteration_plan`]); the catalogue's
/// registry answers for an analyse with none.
fn plan_words<'a>(
    cmd_name: &str,
    args: &'a [String],
    registry: BoundsMetadataContext<'_>,
) -> Option<PlanWords<'a>> {
    use tcl_registry::value_transfer::IterableKind;
    let head = cmd_name.strip_prefix("::").unwrap_or(cmd_name);
    registry.spec(head)?;
    let plan = crate::value_transfer::resolved_iteration_plan(registry.commands(), head, args)?;
    let word = |id: tcl_registry::value_transfer::OperandId| args.get(id.0).map(String::as_str);
    let body = word(plan.body?.body)?;
    match plan.iterable {
        IterableKind::Counted {
            condition, next, ..
        } => Some(PlanWords {
            condition: word(condition)?,
            next: Some(word(next)?),
            body,
        }),
        IterableKind::Condition(condition) => Some(PlanWords {
            condition: word(condition)?,
            next: None,
            body,
        }),
        _ => None,
    }
}

/// The catalogue's registry, for an analyse with none.
pub(super) fn default_registry<'a>() -> &'a tcl_registry::CommandRegistry {
    tcl_registry::model::ingress::static_context_for("tcl8.6").commands()
}

/// The loop's counter ([`LoopCounter`]): the condition is `$v OP INT`, and
/// either the counted plan's step script is one integer increment of `v`, or
/// the conditional plan's body holds exactly one at its top level; nothing
/// in the body leaves the loop. Whether anything else writes `v` is the
/// unit's answer, read where the loop is settled ([`LoopWrites`]).
fn loop_counter(
    words: &PlanWords<'_>,
    registry: BoundsMetadataContext<'_>,
    lexer_config: tcl_lexer::LexerConfig,
    grammar: &tcl_dialect::LexerGrammar,
) -> Option<LoopCounter> {
    let (var, op, bound) = parse_simple_for_cond(words.condition, grammar)?;
    if body_may_exit(words.body, registry, lexer_config) {
        return None;
    }
    let step = match words.next {
        Some(next) => command_increment(
            &sole_command(next, lexer_config)?,
            &var,
            registry,
            lexer_config,
        )?,
        None => body_increment(words.body, &var, registry, lexer_config)?,
    };
    Some(LoopCounter {
        var,
        op,
        bound,
        step,
    })
}

/// The one integer increment of `var` at `body`'s top level, which runs on
/// every pass that reaches its end.
fn body_increment(
    body: &str,
    var: &str,
    registry: BoundsMetadataContext<'_>,
    lexer_config: tcl_lexer::LexerConfig,
) -> Option<i64> {
    let mut steps = segment_commands_with_offset_and_config(body, 0, lexer_config.nested())
        .into_iter()
        .filter_map(|cmd| command_increment(&cmd, var, registry, lexer_config));
    let step = steps.next()?;
    steps.next().is_none().then_some(step)
}

/// What `cmd` adds to `var` each time it runs, when it is the registry's
/// integer cell update of `var` over literal words: its route, run from 0,
/// stores the amount.
pub(super) fn command_increment(
    cmd: &SegmentedCommand,
    var: &str,
    registry: BoundsMetadataContext<'_>,
    lexer_config: tcl_lexer::LexerConfig,
) -> Option<i64> {
    let head = cmd.name().strip_prefix("::").unwrap_or(cmd.name());
    registry.spec(head)?;
    let (operation, target) =
        crate::value_transfer::resolved_cell_update(registry.commands(), head, cmd.args())?;
    if operation != tcl_registry::native_lowering::CellUpdate::Increment
        || cmd.args().get(target.0).map(String::as_str) != Some(var)
    {
        return None;
    }
    parse_signed_decimal(&literal_store(cmd, var, "0", registry, lexer_config)?)
}

/// What `cmd` stores in `var` when the route its words resolve to runs over
/// them, each one literal token read as Tcl substitutes it and given the role
/// the resolver gives it, with `var` holding `prior` before: `None` when a
/// word substitutes, the route declines or does not complete normally, or
/// the run stores anything but one value in `var`.
fn literal_store(
    cmd: &SegmentedCommand,
    var: &str,
    prior: &str,
    registry: BoundsMetadataContext<'_>,
    lexer_config: tcl_lexer::LexerConfig,
) -> Option<String> {
    use tcl_registry::value_transfer::{
        Budget, CompletionOutcome, EvalAnswer, ExactValue, LiteralInputs, OperandId, StoreOutcome,
    };
    let head = cmd.name().strip_prefix("::").unwrap_or(cmd.name());
    registry.spec(head)?;
    let cooked: Vec<std::borrow::Cow<'_, str>> = cmd
        .args()
        .iter()
        .enumerate()
        .map(|(index, text)| {
            if cmd.arg_single_token().get(index) != Some(&true) {
                return None;
            }
            let token = cmd.arg_tokens().get(index)?;
            crate::value_transfer::literal_token_value(text, token.kind, &lexer_config)
        })
        .collect::<Option<_>>()?;
    let texts: Vec<&str> = cooked.iter().map(AsRef::as_ref).collect();
    let (resolved, roles) =
        crate::value_transfer::resolved_literal_semantics(registry.commands(), head, &texts)?;
    let semantics = resolved.semantics()?;
    let mut inputs = LiteralInputs::new(head, None, &texts, registry.commands().profile())
        .with_prior(var, ExactValue::text(prior));
    for (index, role) in roles {
        inputs = inputs.with_role(OperandId(index), role);
    }
    let EvalAnswer::Evaluated(outcome) = semantics.evaluate(&inputs, &mut Budget::evaluation())
    else {
        return None;
    };
    if outcome.completion != CompletionOutcome::Normal || !outcome.nested_writes.is_empty() {
        return None;
    }
    match outcome.ordered_stores.as_slice() {
        [StoreOutcome::Write { target, value }] if texts.get(target.0.0) == Some(&var) => {
            String::from_utf8(value.bytes.clone()).ok()
        }
        _ => None,
    }
}

/// The lexical loop-termination diagnostics of one command — what the text
/// alone says, with no solver fact.
#[cfg(test)]
pub(crate) fn loop_termination_diagnostics(
    cmd_name: &str,
    args: &[String],
    arg_tokens: &[Token],
    registry: BoundsMetadataContext<'_>,
    lexer_config: tcl_lexer::LexerConfig,
    grammar: &tcl_dialect::LexerGrammar,
) -> Vec<Diagnostic> {
    loop_termination_candidate(
        cmd_name,
        args,
        arg_tokens,
        registry,
        None,
        lexer_config,
        grammar,
    )
    .and_then(|candidate| candidate.lexical_diagnostic())
    .into_iter()
    .collect()
}

/// Return the scalar name of the first variable referenced by a
/// condition expression, or `None`.
///
/// The condition is tokenised with the expression lexer (CST level) and
/// the first `Variable` token is taken; its leading scalar name is then
/// read off the token text.
///
/// Abstains (`None`) when the condition contains a `[cmd ...]` command
/// substitution: a `Variable` token found *outside* it is not necessarily
/// the loop's actual progress variable, since the substitution's own
/// argument words can reference (and the body can update) a variable this
/// shallow scan never sees — `while {[string length $u] > $rest}` picked
/// `rest`, a threshold the loop never touches, over `u`, which the body
/// visibly shrinks each iteration — so abstaining avoids the false positive
/// (corpus example: `tcltest.tcl`'s option-usage word-wrapper).
fn extract_counter_name(cond: &str, grammar: &tcl_dialect::LexerGrammar) -> Option<String> {
    let tokens = tokenise_expr_checked_with_grammar(strip_braces(cond), grammar).0;
    if tokens.iter().any(|t| t.kind == ExprTokenType::Command) {
        return None;
    }
    let var = tokens.iter().find(|t| t.kind == ExprTokenType::Variable)?;
    var_scalar_name(&var.text)
}

/// The leading scalar name of a `Variable` token's text — the `name`
/// portion of `$name`, `${name}`, `$name(idx)`, `$ns::name` (taking the
/// first word run, matching the `\$\{?(\w+)\}?` capture shape).
fn var_scalar_name(text: &str) -> Option<String> {
    let bytes = text.as_bytes();
    if bytes.first() != Some(&b'$') {
        return None;
    }
    let mut i = 1;
    if bytes.get(i) == Some(&b'{') {
        i += 1;
    }
    let start = i;
    while i < bytes.len() && is_word_byte(bytes[i]) {
        i += 1;
    }
    (i > start).then(|| text[start..i].to_string())
}

/// A `\w` byte: ASCII alphanumeric or underscore.
fn is_word_byte(b: u8) -> bool {
    b.is_ascii_alphanumeric() || b == b'_'
}

/// Evaluate a simple comparison at a concrete value.
fn cond_true_at(op: &str, value: i64, bound: i64) -> bool {
    match op {
        "<" => value < bound,
        "<=" => value <= bound,
        ">" => value > bound,
        ">=" => value >= bound,
        "==" | "eq" => value == bound,
        "!=" | "ne" => value != bound,
        _ => false,
    }
}

/// `(var, op, bound)` when `cond` is exactly `$v OP literal` or
/// `literal OP $v` (no compound `&&` / `||` / `?` / `!`).
///
/// The condition is tokenised with the expression lexer.  Exactly one
/// comparison operator must split it into a single-variable side and a
/// signed-integer side; any logical / ternary operator, or a second
/// comparison, disqualifies it as compound.
fn parse_simple_for_cond(
    cond: &str,
    grammar: &tcl_dialect::LexerGrammar,
) -> Option<(String, String, i64)> {
    let all = tokenise_expr_checked_with_grammar(strip_braces(cond), grammar).0;
    let tokens: Vec<&ExprToken> = all
        .iter()
        .filter(|t| !t.kind.is_skipped() && t.kind != ExprTokenType::Eof)
        .collect();
    // Locate the single comparison operator; reject compound conditions.
    let mut split = None;
    for (i, t) in tokens.iter().enumerate() {
        if matches!(t.kind, ExprTokenType::TernaryQ | ExprTokenType::TernaryC) {
            return None;
        }
        if t.kind == ExprTokenType::Operator {
            if matches!(t.text.as_str(), "&&" | "||" | "!") {
                return None;
            }
            if SIMPLE_CMP_OPS.contains(&t.text.as_str()) {
                if split.is_some() {
                    return None; // a second comparison → compound
                }
                split = Some(i);
            }
        }
    }
    let at = split?;
    let (lhs, rhs) = (&tokens[..at], &tokens[at + 1..]);
    let op = tokens[at].text.as_str();
    // `$v OP int`
    if let (Some(v), Some(bound)) = (tokens_as_scalar_var(lhs), tokens_as_int(rhs)) {
        return Some((v, op.to_string(), bound));
    }
    // `int OP $v` — flip the operator so the variable is on the left.
    if let (Some(bound), Some(v)) = (tokens_as_int(lhs), tokens_as_scalar_var(rhs)) {
        return Some((v, flip_comparison(op).to_string(), bound));
    }
    None
}

/// A single `Variable` token slice → its scalar name, but only for a
/// plain `$name` / `${name}` token.  Array (`$a(i)`) and namespace-
/// qualified (`$ns::v`) forms are rejected, accepting only a full match
/// of `\$\{?(\w+)\}?` on the comparison's variable side.
fn tokens_as_scalar_var(tokens: &[&ExprToken]) -> Option<String> {
    match tokens {
        [v] if v.kind == ExprTokenType::Variable => strict_scalar_name(&v.text),
        _ => None,
    }
}

/// The scalar name when `text` is exactly `$name`, `${name}`, `${name`
/// or `$name}` (the `\$\{?(\w+)\}?` fullmatch shape — leading `{` and
/// trailing `}` each independently optional), with nothing trailing.
fn strict_scalar_name(text: &str) -> Option<String> {
    let bytes = text.as_bytes();
    if bytes.first() != Some(&b'$') {
        return None;
    }
    let mut i = 1;
    if bytes.get(i) == Some(&b'{') {
        i += 1;
    }
    let start = i;
    while i < bytes.len() && is_word_byte(bytes[i]) {
        i += 1;
    }
    if i == start {
        return None; // no word
    }
    let name = text[start..i].to_string();
    if bytes.get(i) == Some(&b'}') {
        i += 1;
    }
    (i == bytes.len()).then_some(name) // reject any trailing chars
}

/// A signed-integer token slice — a `Number`, optionally preceded by a
/// unary `-` operator (the expression lexer tokenises `-5` as two
/// tokens).  A leading `+` is *not* accepted, matching the `-?\d+`
/// bound pattern.  Returns the value when the slice is exactly that shape.
fn tokens_as_int(tokens: &[&ExprToken]) -> Option<i64> {
    match tokens {
        [num] if num.kind == ExprTokenType::Number => parse_decimal(&num.text),
        [sign, num]
            if sign.kind == ExprTokenType::Operator
                && sign.text == "-"
                && num.kind == ExprTokenType::Number =>
        {
            parse_decimal(&num.text).map(|value| -value)
        }
        _ => None,
    }
}

/// Parse an unsigned decimal integer literal (`\d+`), rejecting floats
/// and signs (the sign is handled by the caller).
fn parse_decimal(text: &str) -> Option<i64> {
    if text.is_empty() || !text.bytes().all(|b| b.is_ascii_digit()) {
        return None;
    }
    text.parse().ok()
}

/// Flip a comparison operator left-to-right (`<` ↔ `>`, `<=` ↔ `>=`);
/// symmetric operators are unchanged.
fn flip_comparison(op: &str) -> &str {
    match op {
        "<" => ">",
        ">" => "<",
        "<=" => ">=",
        ">=" => "<=",
        other => other,
    }
}

/// The single command in `fragment` (after stripping an enclosing brace
/// pair), or `None` when it segments to zero or more than one command.
fn sole_command(fragment: &str, lexer_config: tcl_lexer::LexerConfig) -> Option<SegmentedCommand> {
    let mut cmds = segment_commands_with_offset_and_config(
        strip_braces(fragment).trim(),
        0,
        lexer_config.nested(),
    );
    match cmds.len() {
        1 => cmds.pop(),
        _ => None,
    }
}

/// Parse a signed decimal integer literal (`-?\d+`); `+`-signs and
/// non-decimal forms are rejected.
fn parse_signed_decimal(word: &str) -> Option<i64> {
    let digits = word.strip_prefix('-').unwrap_or(word);
    parse_decimal(digits).map(|v| if word.starts_with('-') { -v } else { v })
}

/// Walk every command in `script`, descending into each word that may be a
/// nested script, and return `true` as soon as `pred` matches.  A
/// shallow-but-structural body scan.
///
/// A write counts only in command position (a `\bset\s+var\b` flat regex
/// would also match `set var(i)` array writes and matches inside
/// strings), which keeps W241/W242 counts accurate — full-fidelity
/// parsing rather than text matching.
#[cfg(test)]
fn body_writes_var(
    body: &str,
    var: &str,
    registry: BoundsMetadataContext<'_>,
    lexer_config: tcl_lexer::LexerConfig,
) -> bool {
    any_command_recursive(body, registry, lexer_config, &mut |cmd| {
        writes_first_arg(cmd.name(), registry)
            && cmd.args().first().map(String::as_str) == Some(var)
    })
}

/// Whether `name` writes/modifies the variable named by its first argument
/// (`set` / `incr` / `append` / `lappend` / `lset`) — the registry's
/// `writes_first_arg_variable` query, with the cached default registry as
/// an independently selected standalone catalogue. Retained callers use
/// only their actual available schema.
#[cfg(test)]
fn writes_first_arg(name: &str, registry: BoundsMetadataContext<'_>) -> bool {
    registry.spec(name).is_some_and(|spec| {
        spec.traits
            .contains(tcl_registry::Traits::FIRST_ARG_VARNAME)
            && !spec
                .traits
                .contains(tcl_registry::Traits::DESTROYS_VARIABLE)
    })
}

/// Walk every command in `script`, recursing into braced / quoted word
/// arguments (which may be nested scripts), and return `true` as soon as
/// `pred` matches.  A shallow-but-structural body scan.
pub(super) fn any_command_recursive(
    script: &str,
    registry: BoundsMetadataContext<'_>,
    lexer_config: tcl_lexer::LexerConfig,
    pred: &mut impl FnMut(&SegmentedCommand) -> bool,
) -> bool {
    for cmd in segment_commands_with_offset_and_config(script, 0, lexer_config.nested()) {
        if pred(&cmd) {
            return true;
        }
        for inner in script_words(&cmd, registry) {
            if any_command_recursive(inner, registry, lexer_config, pred) {
                return true;
            }
        }
    }
    false
}

/// The words of `cmd` that may be nested scripts: each braced word, and each
/// word the registry gives a `Body` role however it is written.
fn script_words<'c>(
    cmd: &'c SegmentedCommand,
    registry: BoundsMetadataContext<'_>,
) -> Vec<&'c str> {
    let args = cmd.args();
    let words: Vec<&str> = args.iter().map(String::as_str).collect();
    let head = cmd.name().strip_prefix("::").unwrap_or(cmd.name());
    let bodies = registry.argument_indices(head, &words, tcl_registry::ArgRole::Body);
    cmd.arg_tokens()
        .iter()
        .enumerate()
        .filter(|(index, _)| bodies.contains(index))
        .filter_map(|(index, _)| args.get(index).map(String::as_str))
        .collect()
}

/// W231: an `lset` with a constant index known to be out of range.
/// Unlike `lindex` (which silently returns empty), `lset` raises a
/// runtime error; a plain negative literal always errors, and — when the
/// list length is recoverable from a recent literal `set` — an index past
/// the append slot (`> length`) or below zero errors too.
pub(crate) fn lset_index_diagnostics(
    cmd_name: &str,
    args: &[String],
    arg_tokens: &[Token],
    source: &str,
    registry: BoundsMetadataContext<'_>,
    lexer_config: tcl_lexer::LexerConfig,
    numbers: tcl_dialect::NumberSyntax,
) -> Vec<Diagnostic> {
    // value-transfer-ok: arg_roles — the W230–W232 index positions await an index-argument role on the registry
    if cmd_name != "lset" || args.len() < 3 || arg_tokens.len() < 3 {
        return Vec::new();
    }
    // `lset varName ?index ...? value` — index positions are 1..len-1.
    let index_positions: Vec<usize> = (1..args.len() - 1).collect();
    let nested = index_positions.len() > 1;
    // Multi-index (nested-sublist) forms only fire on plain-negative
    // literals; length-based checks need the single-index top-level form.
    let list_len = if nested {
        None
    } else {
        infer_list_length_from_recent_set(
            source,
            &args[0],
            arg_tokens[0].span.start(),
            registry,
            lexer_config,
        )
    };

    let mut out = Vec::new();
    for pos in index_positions {
        let idx_text = &args[pos];
        let Some(idx_tok) = arg_tokens.get(pos) else {
            continue;
        };
        if has_subst(idx_text, idx_tok) || !is_literal_index(idx_text, numbers) {
            continue;
        }
        let stripped = idx_text.trim();
        // Plain negative integer: always errors.
        if let Some(n) = absolute_index(stripped, numbers)
            && n < 0
        {
            out.push(crate::analyser::types::Diagnostic::new(
                DiagCode::W231,
                idx_tok.span,
                format!(
                    "lset index '{stripped}' is negative; \
                         raises 'index out of range' at runtime."
                ),
                Severity::Warning,
            ));
            continue;
        }
        // `lset` accepts the append slot (`index == length`); only
        // indices past it or below zero are runtime errors.
        if let Some(length) = list_len {
            let Some(resolved) = resolve_index(stripped, length, numbers) else {
                continue;
            };
            if resolved < 0 || resolved > length {
                out.push(crate::analyser::types::Diagnostic::new(
                    DiagCode::W231,
                    idx_tok.span,
                    format!(
                        "lset index '{stripped}' {}; \
                         raises 'index out of range' at runtime.",
                        describe_index(resolved, length)
                    ),
                    Severity::Warning,
                ));
            }
        }
    }
    out
}

/// The literal length of the list `var_name` holds when the `lset` at
/// `before_offset` runs, or `None` when it is not statically recoverable.
///
/// Structural, not textual.  The walk segments the document, descends the
/// braced word that *contains* the `lset` one level at a time, and takes the
/// value from the last literal assignment to `var_name` in the innermost
/// script the `lset` shares, carried through every cell update on it whose
/// resolved route evaluates over literal words (`lappend xs a b c` after
/// `set xs {}` leaves three elements, #2054).  Descending resets the
/// accumulator: a `set` in an enclosing (or sibling) script is never trusted
/// for a nested `lset`; a write the walk cannot evaluate forgets the value.
///
/// What that buys over a byte scan:
///
/// * a `set` written inside a comment or a string literal is not a command,
///   so it supplies no length (a false positive a text scan would draw);
/// * an intervening `proc` / `apply` / `try` / `namespace eval` *sibling* does
///   not block recovery — only actually descending into a body does — so the
///   `set x {a b c}` … `proc p {} {…}` … `lset x 9 v` shape still reports;
/// * a `set` not written at a line start, or one whose literal contains a
///   nested `{…}` sublist, still counts, because the segmenter reports words
///   rather than matching a line-anchored `\{[^{}]*\}` regex.
fn infer_list_length_from_recent_set(
    source: &str,
    var_name: &str,
    before_offset: u32,
    registry: BoundsMetadataContext<'_>,
    lexer_config: tcl_lexer::LexerConfig,
) -> Option<i64> {
    if before_offset == 0 || before_offset as usize > source.len() || var_name.is_empty() {
        return None;
    }
    let length_of = |value: &str| {
        i64::try_from(
            crate::tcl_expr_eval::split_tcl_list(
                value,
                tcl_syntax::word_rules::WordValueRules::from_config(&lexer_config),
            )
            .len(),
        )
        .unwrap_or(i64::MAX)
    };
    let mut script: &str = source;
    let mut base: u32 = 0;
    let mut best: Option<String> = None;
    for depth in 0..MAX_SCOPE_DESCENT.0 {
        best = None;
        let mut inner: Option<(&str, u32)> = None;
        for cmd in
            segment_commands_with_offset_and_config(script, base, lexer_config.at_depth(depth))
        {
            if cmd.span.start() >= before_offset {
                break;
            }
            if cmd.span.end() >= before_offset {
                // The `lset` lives inside this command; continue in the
                // braced word that holds it, starting a fresh scope.
                inner = cmd
                    .argv
                    .iter()
                    .find(|tok| {
                        tok.kind == TokenType::Str
                            && tok.span.start() < before_offset
                            && before_offset < tok.span.end()
                    })
                    .and_then(|tok| super::scope::inner_of(source, *tok));
                break;
            }
            if let Some(value) = literal_list_assignment(registry, &cmd, var_name, lexer_config) {
                best = Some(value);
            } else if let Some(write) =
                cell_update_assignment(registry, &lexer_config, &cmd, var_name, best.as_deref())
            {
                best = match write {
                    CellUpdateWrite::Value(value) => Some(value),
                    CellUpdateWrite::Unknown => None,
                };
            } else if writes_the_name(registry, &cmd, var_name) {
                // Any other write this scan cannot turn into a fresh literal
                // value — a `set` whose value is not one literal word —
                // invalidates the value recovered from an earlier literal
                // assignment. Keeping the stale one reported `set xs {}` as
                // the length at a later `lset xs 2 X`, a W231 "list has 0
                // elements" on a list that really has three (#2054).
                // Abstaining matches how the rest of this checker handles a
                // value it cannot pin down.
                best = None;
            }
        }
        match inner {
            Some((text, text_base)) => {
                script = text;
                base = text_base;
            }
            None => return best.as_deref().map(length_of),
        }
    }
    best.map(|value| {
        i64::try_from(
            crate::tcl_expr_eval::split_tcl_list(
                &value,
                tcl_syntax::word_rules::WordValueRules::from_config(&lexer_config),
            )
            .len(),
        )
        .unwrap_or(i64::MAX)
    })
}

/// What a cell update leaves in the variable the length walk follows.
enum CellUpdateWrite {
    /// The registry's route evaluated the update over its literal words.
    Value(String),
    /// The update writes the variable but the walk cannot evaluate it (a
    /// dynamic word, an unknown prior), so the walk forgets the value.
    Unknown,
}

/// What `cmd` leaves in `var_name` when `cmd` is a cell update on it, the
/// route evaluating from `current`; `None` when `cmd` does not write
/// `var_name` at all.
fn cell_update_assignment(
    registry: BoundsMetadataContext<'_>,
    config: &tcl_lexer::LexerConfig,
    cmd: &SegmentedCommand,
    var_name: &str,
    current: Option<&str>,
) -> Option<CellUpdateWrite> {
    use tcl_registry::value_transfer::{EvalAnswer, ExactValue, LiteralInputs, StoreOutcome};
    let head = cmd.name().strip_prefix("::").unwrap_or(cmd.name());
    let args = cmd.args();
    let (_, target) = crate::value_transfer::resolved_cell_update(registry.commands(), head, args)?;
    if args.get(target.0).map(String::as_str) != Some(var_name) {
        return None;
    }
    // Every word is one literal token, read as Tcl substitutes it: `append
    // xs "\tc"` appends a tab, so the list gains an element.
    let cooked: Option<Vec<std::borrow::Cow<'_, str>>> = args
        .iter()
        .enumerate()
        .map(|(index, text)| {
            let token = cmd.arg_tokens().get(index)?;
            if cmd.arg_single_token().get(index) != Some(&true) {
                return None;
            }
            crate::value_transfer::literal_token_value(text, token.kind, config)
        })
        .collect();
    let (Some(current), Some(cooked)) = (current, cooked) else {
        return Some(CellUpdateWrite::Unknown);
    };
    let texts: Vec<&str> = cooked.iter().map(AsRef::as_ref).collect();
    let spec = registry.spec(head)?;
    let semantics = tcl_registry::value_transfer::resolve_semantics(spec, None, None);
    let semantics = semantics.semantics()?;
    let inputs = LiteralInputs::new(head, None, &texts, registry.commands().profile())
        .with_prior(var_name, ExactValue::text(current));
    let value = match semantics.evaluate(
        &inputs,
        &mut tcl_registry::value_transfer::Budget::evaluation(),
    ) {
        EvalAnswer::Evaluated(outcome) => {
            outcome
                .ordered_stores
                .into_iter()
                .find_map(|store| match store {
                    StoreOutcome::Write { target: t, value } if t.0 == target => {
                        String::from_utf8(value.bytes).ok()
                    }
                    _ => None,
                })
        }
        EvalAnswer::Pending | EvalAnswer::Declined(_) => None,
    };
    Some(value.map_or(CellUpdateWrite::Unknown, CellUpdateWrite::Value))
}

/// Whether `cmd` writes `var_name` at all, however it writes it.
///
/// Deliberately weaker than [`literal_list_assignment`]: no
/// `READS_BEFORE_WRITE` / `WHOLE_ARRAY_ARG` exclusion and no single-literal-word
/// requirement, because the question here is only "did this command touch the
/// name", not "what is its new value".
fn writes_the_name(
    registry: BoundsMetadataContext<'_>,
    cmd: &SegmentedCommand,
    var_name: &str,
) -> bool {
    let head = cmd.name().strip_prefix("::").unwrap_or(cmd.name());
    let args: Vec<&str> = cmd.args().iter().map(String::as_str).collect();
    registry
        .argument_indices(head, &args, tcl_registry::ArgRole::VarWrite)
        .into_iter()
        .any(|index| args.get(index) == Some(&var_name))
}

/// Native-stack safety net for [`infer_list_length_from_recent_set`]'s
/// descent through nested braced bodies.
const MAX_SCOPE_DESCENT: tcl_core_types::RecursionLimit = tcl_core_types::RecursionLimit(256);

/// The literal list value `cmd` assigns to `var_name`, or `None`.
///
/// Registry-driven throughout: which argument is written comes from
/// [`tcl_registry::ArgRole::VarWrite`] (so `set`, `variable`, and any
/// spec-declared setter answer alike, and `::set` answers like `set`), and
/// two trait guards keep the answer honest —
/// [`tcl_registry::Traits::READS_BEFORE_WRITE`] excludes `append` / `incr` /
/// `lappend`, whose trailing word is *not* the resulting value, and
/// [`tcl_registry::Traits::WHOLE_ARRAY_ARG`] excludes `array set`, whose
/// target is an array rather than a list-valued scalar.
///
/// The value must be a single braced word, which is what makes it a literal:
/// the segmenter has already stripped the delimiter, so the text splits
/// directly as a Tcl list.
fn literal_list_assignment(
    registry: BoundsMetadataContext<'_>,
    cmd: &SegmentedCommand,
    var_name: &str,
    lexer_config: tcl_lexer::LexerConfig,
) -> Option<String> {
    let head = cmd.name().strip_prefix("::").unwrap_or(cmd.name());
    let spec = registry.spec(head)?;
    if spec.traits.intersects(
        tcl_registry::Traits::READS_BEFORE_WRITE.union(tcl_registry::Traits::WHOLE_ARRAY_ARG),
    ) {
        return None;
    }
    let args: Vec<&str> = cmd.args().iter().map(String::as_str).collect();
    let writes = registry.argument_indices(head, &args, tcl_registry::ArgRole::VarWrite);
    let [name_index] = writes.as_slice() else {
        return None;
    };
    if args.get(*name_index) != Some(&var_name) || args.len() != name_index + 2 {
        return None;
    }
    let value_index = name_index + 1;
    if cmd.arg_tokens().get(value_index)?.kind != TokenType::Str
        || cmd.arg_single_token().get(value_index) != Some(&true)
    {
        return None;
    }
    let value = cmd.args().get(value_index)?;
    Some(
        tcl_syntax::word_rules::WordValueRules::from_config(&lexer_config)
            .collapse_braced_word(value)
            .into_owned(),
    )
}

/// True when a `(first, last)` index pair resolves to a provably-empty
/// slice over `length`: both below, both above, clamped first > clamped
/// last, or an empty container.
fn pair_slice_empty(first: i64, last: i64, length: i64) -> bool {
    if length == 0 {
        return true;
    }
    let both_below = first < 0 && last < 0;
    let both_above = first >= length && last >= length;
    let clamped_first = first.clamp(0, length - 1);
    let clamped_last = last.clamp(0, length - 1);
    both_below || both_above || clamped_first > clamped_last
}

/// Human-readable description of a resolved out-of-range string index.
fn describe_index_string(resolved: i64, length: i64) -> String {
    if resolved < 0 {
        format!("resolves to {resolved} (before start of string)")
    } else {
        format!(
            "resolves to {resolved} (string has {length} character{})",
            if length == 1 { "" } else { "s" }
        )
    }
}

/// Word contains a variable / command substitution.
fn has_subst(text: &str, tok: &Token) -> bool {
    matches!(
        tok.kind,
        tcl_lexer::TokenType::Var | tcl_lexer::TokenType::Cmd
    ) || text.contains('$')
        || text.contains('[')
}

/// `s` is a constant index expression we can evaluate (`end`, an
/// integer, or `end±N`).
fn is_literal_index(s: &str, numbers: tcl_dialect::NumberSyntax) -> bool {
    tcl_cmd_core::index::resolve_opt_with(s.trim(), 0, numbers).is_some()
}

/// Resolve a constant index to an absolute offset given `length`, or
/// `None` when `s` is not a literal index.
fn resolve_index(s: &str, length: i64, numbers: tcl_dialect::NumberSyntax) -> Option<i64> {
    tcl_cmd_core::index::resolve_opt_with(s.trim(), usize::try_from(length).ok()?, numbers)
}

/// Resolve a length-independent (non-`end`) Tcl index expression.
fn absolute_index(s: &str, numbers: tcl_dialect::NumberSyntax) -> Option<i64> {
    let s = s.trim();
    if s.starts_with("end") {
        return None;
    }
    tcl_cmd_core::index::resolve_opt_with(s, 0, numbers)
}

/// Human-readable description of a resolved out-of-range index.
fn describe_index(resolved: i64, length: i64) -> String {
    if resolved < 0 {
        format!("resolves to {resolved} (before start of list)")
    } else {
        format!(
            "resolves to {resolved} (list has {length} element{})",
            if length == 1 { "" } else { "s" }
        )
    }
}

const TRUE_LITERALS: &[&str] = &["1", "true", "yes", "on", "!0"];
const FALSE_LITERALS: &[&str] = &["0", "false", "no", "off", "!1"];

/// Strip a single enclosing `{ … }` and surrounding whitespace.
fn strip_braces(s: &str) -> &str {
    let t = s.trim();
    if t.starts_with('{') && t.ends_with('}') && t.len() >= 2 {
        t[1..t.len() - 1].trim()
    } else {
        t
    }
}

/// `Some(true)` / `Some(false)` when `cond` is a constant-true /
/// constant-false expression; `None` when dynamic.
fn condition_constant(cond: &str) -> Option<bool> {
    let c = strip_braces(cond).to_ascii_lowercase();
    if TRUE_LITERALS.contains(&c.as_str()) {
        return Some(true);
    }
    if FALSE_LITERALS.contains(&c.as_str()) {
        return Some(false);
    }
    c.trim().parse::<f64>().ok().map(|v| v != 0.0)
}

/// True when `body` contains, in command position, any command that leaves
/// the loop (`break` / `tailcall` / a `TERMINATES_BLOCK` command such as
/// `return` / `error` / `exit` / `throw`) — see [`is_loop_exit_command`].
///
/// Resolved via the segmenter (recursing into nested bodies,
/// [`any_command_recursive`]) so only a command in *command position* counts
/// — a `break` appearing as a bare argument of a command that does not run
/// it as a script triggers no false exit, and one an `if` runs as its bare
/// body is an exit.
fn body_may_exit(
    body: &str,
    registry: BoundsMetadataContext<'_>,
    lexer_config: tcl_lexer::LexerConfig,
) -> bool {
    any_command_recursive(body, registry, lexer_config, &mut |cmd| {
        is_loop_exit_command(cmd.name(), registry)
    })
}

#[cfg(test)]
mod tests {
    use super::{
        BoundsMetadataContext, any_command_recursive, infer_list_length_from_recent_set,
        sole_command,
    };
    use crate::analyser::Analyser;
    use tcl_core_types::DiagCode;

    fn config() -> tcl_lexer::LexerConfig {
        tcl_lexer::LexerConfig::default()
    }

    fn codes(src: &str) -> Vec<String> {
        let mut a = Analyser::new();
        a.analyse(src, "tcl8.6")
            .diagnostics
            .iter()
            .filter(|d| matches!(d.code.as_str(), "W240" | "W241"))
            .map(|d| d.code.to_string())
            .collect()
    }

    #[test]
    fn w240_constant_false_condition() {
        assert_eq!(codes("while 0 {puts hi}\n"), vec!["W240"]);
        assert_eq!(codes("for {set i 0} 0 {incr i} {}\n"), vec!["W240"]);
    }

    #[test]
    fn configured_bounds_scanners_cover_each_segmenter_site() {
        // Mutation proof for the three bounds callers: iRules treats `}{` as
        // a ghost separator, whereas the default Tcl lexer keeps the second
        // braced word attached to the first command.
        let config = tcl_lexer::LexerConfig::for_dialect("f5-irules");
        let one = sole_command("cmd {a}{b}", config).expect("one command");
        assert_eq!(one.args().len(), 2, "iRules words: {:?}", one.texts);
        assert!(any_command_recursive(
            "cmd {a}{b}",
            BoundsMetadataContext::Standalone(None),
            config,
            &mut |cmd| { cmd.args().len() == 2 }
        ));

        let source = "set xs {a b}\nlset xs 9 v\n";
        let before = u32::try_from(source.find("lset").expect("lset")).expect("offset");
        assert_eq!(
            infer_list_length_from_recent_set(
                source,
                "xs",
                before,
                super::BoundsMetadataContext::Standalone(None),
                config,
            ),
            Some(2)
        );
    }

    #[test]
    fn w241_constant_true_no_exit() {
        assert_eq!(codes("while 1 {puts hi}\n"), vec!["W241"]);
        // A `break` in the body suppresses W241.
        assert_eq!(codes("while 1 {break}\n"), [] as [std::string::String; 0]);
        assert_eq!(codes("while 1 {return}\n"), [] as [std::string::String; 0]);
    }

    #[test]
    fn w241_throw_and_tailcall_leave_the_loop() {
        // `throw` and `tailcall` both terminate the loop after one
        // iteration (verified against tclsh 9.0.4), so a `while 1` body
        // containing either is NOT provably infinite. `throw` resolves via the
        // registry's TERMINATES_BLOCK trait; `tailcall` is named explicitly.
        assert_eq!(
            codes("while 1 {throw MYERR boom}\n").len(),
            0,
            "throw must suppress W241",
        );
        assert_eq!(
            codes("while 1 {tailcall foo}\n").len(),
            0,
            "tailcall must suppress W241",
        );
        // TP controls: the other block-terminators still suppress, and a body
        // with no exit at all still fires.
        assert_eq!(
            codes("while 1 {error boom}\n"),
            [] as [std::string::String; 0]
        );
        assert_eq!(codes("while 1 {exit 1}\n"), [] as [std::string::String; 0]);
        assert_eq!(codes("while 1 {incr n}\n"), vec!["W241"]);
        // `continue` is NOT an exit — it keeps looping — so W241 still fires.
        assert_eq!(codes("while 1 {continue}\n"), vec!["W241"]);
    }

    /// Every loop-termination verdict (W240, W241, W242) `src` draws, in
    /// source order.
    fn loop_verdicts(src: &str) -> Vec<String> {
        let mut a = Analyser::new();
        let mut found: Vec<(u32, String)> = a
            .analyse(src, "tcl8.6")
            .diagnostics
            .iter()
            .filter(|d| matches!(d.code.as_str(), "W240" | "W241" | "W242"))
            .map(|d| (d.span.start(), d.code.to_string()))
            .collect();
        found.sort();
        found.into_iter().map(|(_, code)| code).collect()
    }

    /// W240 and W241 read the loop header's branch fact instead of the
    /// condition's text: a header the solver decides false at entry is W240,
    /// one it decides true at every test with no executable exit is W241, and
    /// either suppresses W242 — where the text alone can say nothing but the
    /// hint a counter nothing modifies draws. A header it does not decide keeps
    /// the text's verdict, and an exit anywhere the flow graph or the body's
    /// text finds keeps a true header silent.
    #[test]
    fn w240_and_w241_read_the_branch_fact() {
        // `n` is 0 at every test and `go` is 1: the branch fact decides.
        assert_eq!(
            loop_verdicts("set n 0\nwhile {$n} {puts \"never runs\"}\n"),
            ["W240"]
        );
        assert_eq!(loop_verdicts("set go 1\nwhile {$go} {puts x}\n"), ["W241"]);
        assert_eq!(
            loop_verdicts("proc p {} {\n set n 0\n while {$n} {puts x}\n}\n"),
            ["W240"]
        );
        assert_eq!(
            loop_verdicts("proc p {} {\n set go 1\n while {$go} {puts x}\n}\n"),
            ["W241"]
        );
        // A `for` whose counter never moves is infinite whatever its bound
        // says; one whose first test fails never runs.
        assert_eq!(
            loop_verdicts("for {set i 0} {$i < 10} {} {puts hi}\n"),
            ["W241"]
        );
        assert_eq!(
            loop_verdicts("for {set i 0} {$i < 0} {incr i} {puts hi}\n"),
            ["W240"]
        );
        // The literal forms decide too, with the text's own message.
        assert_eq!(loop_verdicts("while 0 {puts hi}\n"), ["W240"]);
        assert_eq!(loop_verdicts("while 1 {puts hi}\n"), ["W241"]);
        // An exit the flow graph finds keeps a true header silent: `break`,
        // `return`, `error`; and so does one it cannot see, inside a `catch`
        // body the graph does not lower.
        for body in ["break", "return", "error boom", "catch {break}"] {
            assert!(
                loop_verdicts(&format!(
                    "proc p {{}} {{\n set go 1\n while {{$go}} {{{body}}}\n}}\n"
                ))
                .is_empty(),
                "{body}"
            );
        }
        // Nothing decides a parameter or an unset variable: the text's
        // verdict stands, W242's hint for a counter nothing modifies.
        assert_eq!(
            loop_verdicts("proc p {n} {\n while {$n} {puts x}\n}\n"),
            ["W242"]
        );
        assert_eq!(loop_verdicts("while {$x < 10} {puts hi}\n"), ["W242"]);
        // A counter the body advances is never proven either way.
        assert!(loop_verdicts("proc p {} {\n set i 0\n while {$i < 3} {incr i}\n}\n").is_empty());
    }

    /// A loop's own test decided false names the loop in its I230, beside the
    /// W240 of a body that never runs; a decided `if` keeps its own wording.
    #[test]
    fn a_loop_test_decided_false_names_the_loop() {
        let i230 = |src: &str| -> Vec<String> {
            Analyser::new()
                .analyse(src, "tcl8.6")
                .diagnostics
                .into_iter()
                .filter(|d| d.code == DiagCode::I230)
                .map(|d| d.message)
                .collect()
        };
        assert_eq!(
            i230("set n 0\nwhile {$n} {puts never}\n"),
            ["Loop condition '$n' is never true; the loop leaves at this test"]
        );
        assert_eq!(
            i230("proc p {} {\n for {set i 0} {$i < 0} {incr i} {puts never}\n}\n"),
            ["Loop condition '$i < 0' is never true; the loop leaves at this test"]
        );
        assert_eq!(
            i230("set n 0\nif {$n} {puts never}\n"),
            ["Condition '$n' is always false; the alternate branch is unreachable"]
        );
    }

    /// A loop inside a proc body reaches the same verdict on the per-item
    /// path, which walks each body in isolation and grafts the candidates
    /// back at their real positions.
    #[test]
    fn loop_verdicts_agree_across_the_whole_file_and_per_item_walks() {
        let src = "proc a {} {\n set n 0\n while {$n} {puts x}\n}\n\
                   proc b {} {\n set go 1\n while {$go} {puts y}\n}\n\
                   proc c {n} {\n while {$n} {puts z}\n}\n\
                   set m 0\nwhile {$m} {puts top}\n";
        let verdicts = |per_item: bool| -> Vec<(u32, String)> {
            let mut a = Analyser::new();
            let result = if per_item {
                a.analyse_per_item(src, "tcl8.6")
            } else {
                a.analyse(src, "tcl8.6")
            };
            let mut found: Vec<(u32, String)> = result
                .diagnostics
                .iter()
                .filter(|d| matches!(d.code.as_str(), "W240" | "W241" | "W242"))
                .map(|d| (d.span.start(), d.code.to_string()))
                .collect();
            found.sort();
            found
        };
        let whole = verdicts(false);
        let codes: Vec<&str> = whole.iter().map(|(_, code)| code.as_str()).collect();
        assert_eq!(codes, ["W240", "W241", "W242", "W240"], "{whole:?}");
        assert_eq!(verdicts(true), whole);
    }

    /// A registry whose loop vocabulary is not Tcl's: `spin` loops, `peek`
    /// has the identical argument shape and does not.
    fn registry_with_a_declared_loop() -> tcl_registry::CommandRegistry {
        use tcl_registry::arg_role::ArgRole;
        use tcl_registry::spec::CommandSpec;

        const ROLES: &[(u8, ArgRole)] = &[(0, ArgRole::Expr), (1, ArgRole::Body)];
        let mut registry = tcl_registry::CommandRegistry::build_default();
        registry.insert(CommandSpec {
            name: "spin",
            traits: tcl_registry::Traits::CONTROL_FLOW
                .union(tcl_registry::Traits::HAS_BOOLEAN_COND)
                .union(tcl_registry::Traits::HAS_LOOP_BODY),
            arity: tcl_registry::arity::Arity::exact(2),
            arg_roles: ROLES,
            ..CommandSpec::DEFAULT
        });
        registry.insert(CommandSpec {
            name: "peek",
            traits: tcl_registry::Traits::HAS_BOOLEAN_COND,
            arity: tcl_registry::arity::Arity::exact(2),
            arg_roles: ROLES,
            ..CommandSpec::DEFAULT
        });
        registry
    }

    fn loop_codes(src: &str, registry: &tcl_registry::CommandRegistry) -> Vec<DiagCode> {
        let command = sole_command(src, config()).expect("one command");
        let name = command.texts.first().expect("a command word").clone();
        super::loop_termination_diagnostics(
            &name,
            command.args(),
            command.arg_tokens(),
            super::BoundsMetadataContext::Standalone(Some(registry)),
            config(),
            &tcl_dialect::LexerGrammar::default(),
        )
        .iter()
        .map(|d| d.code)
        .collect()
    }

    #[test]
    fn a_declared_loop_is_analysed_under_whatever_name_it_has() {
        // The loop question is the registry's: a command carrying
        // HAS_LOOP_BODY reaches W240 / W241 with no name written here, which
        // is what lets a spec pack ship its own loop construct.
        let registry = registry_with_a_declared_loop();
        assert_eq!(loop_codes("spin 0 {puts hi}", &registry), [DiagCode::W240]);
        assert_eq!(loop_codes("spin 1 {puts hi}", &registry), [DiagCode::W241]);
        assert_eq!(
            loop_codes("spin 1 {break}", &registry),
            [] as [tcl_core_types::DiagCode; 0]
        );
        // The control that makes the trait load-bearing: the same argument
        // shape without it runs its body once and is not a loop.
        assert_eq!(
            loop_codes("peek 1 {puts hi}", &registry),
            [] as [tcl_core_types::DiagCode; 0]
        );
    }

    /// The W240 / W241 codes for `src`, under the catalogue plus the one
    /// inline `stub` declaration a document states.
    fn declared_loop_codes(stub: &str, src: &str) -> Vec<DiagCode> {
        let declared = crate::analyser::utils::document_declared_surface(
            &format!("# tcl-lsp: stubs-begin\n# tcl-lsp: stub {stub}\n# tcl-lsp: stubs-end\n"),
            None,
            "tcl8.6",
        );
        let registry = tcl_registry::model::ingress::static_context_for("tcl8.6").commands();
        let surface = tcl_registry::model::DocumentCommandSurface::new(registry, Some(&declared));
        let command = sole_command(src, config()).expect("one command");
        let name = command.texts.first().expect("a command word").clone();
        super::loop_termination_candidate(
            &name,
            command.args(),
            command.arg_tokens(),
            super::BoundsMetadataContext::Standalone(Some(registry)),
            Some(&surface),
            config(),
            &tcl_dialect::LexerGrammar::default(),
        )
        .and_then(|candidate| candidate.lexical_diagnostic())
        .into_iter()
        .map(|diagnostic| diagnostic.code)
        .collect()
    }

    #[test]
    fn a_document_declaration_answers_the_loop_question_for_its_name() {
        // A stub's `-loop` is the `HAS_LOOP_BODY` a pack command states, and
        // its `cond:expr body:body` words are the shape.
        let spin = "spin {cond:expr body:body}";
        assert_eq!(
            declared_loop_codes(&format!("{spin} -loop"), "spin 1 {puts hi}"),
            [DiagCode::W241]
        );
        assert_eq!(
            declared_loop_codes(&format!("{spin} -loop"), "spin 0 {puts hi}"),
            [DiagCode::W240]
        );
        assert!(declared_loop_codes(spin, "spin 1 {puts hi}").is_empty());
        // Nearest wins: a document that redeclares `while` answers for it, so
        // a declaration stating no loop body is not a loop, and one stating
        // it is.
        let redeclared = "while {cond:expr body:body}";
        assert!(declared_loop_codes(redeclared, "while 1 {puts hi}").is_empty());
        assert_eq!(
            declared_loop_codes(&format!("{redeclared} -loop"), "while 1 {puts hi}"),
            [DiagCode::W241]
        );
    }

    #[test]
    fn w241_for_loop_throw_tailcall_suppress() {
        // Same coverage on the `for` provably-infinite counter shape: a body
        // that throws / tailcalls is not an infinite loop.
        assert_eq!(
            codes("for {set i 0} {$i < 10} {incr i 0} {throw E x}\n"),
            [] as [std::string::String; 0]
        );
        assert_eq!(
            codes("for {set i 5} {$i > 0} {incr i} {tailcall done}\n"),
            [] as [std::string::String; 0]
        );
    }

    #[test]
    fn dynamic_condition_is_silent() {
        assert_eq!(
            codes("while {$x < 10} {incr x}\n"),
            [] as [std::string::String; 0]
        );
    }

    #[test]
    fn w241_for_step_provably_infinite() {
        // Step 0, wrong-direction step, increment-away, never-equal-skip.
        assert_eq!(
            codes("for {set i 0} {$i < 10} {incr i 0} {}\n"),
            vec!["W241"]
        );
        assert_eq!(
            codes("for {set i 0} {$i < 10} {incr i -1} {}\n"),
            vec!["W241"]
        );
        assert_eq!(codes("for {set i 5} {$i > 0} {incr i} {}\n"), vec!["W241"]);
        assert_eq!(
            codes("for {set i 0} {$i != 10} {incr i 3} {}\n"),
            vec!["W241"]
        );
        // A correct counting loop is silent.
        assert_eq!(
            codes("for {set i 0} {$i < 10} {incr i} {}\n"),
            [] as [std::string::String; 0]
        );
    }

    #[test]
    fn for_cond_parsers() {
        assert_eq!(
            super::parse_simple_for_cond("$i < 10", &tcl_dialect::LexerGrammar::default()),
            Some(("i".into(), "<".into(), 10)),
        );
        assert_eq!(
            super::parse_simple_for_cond("10 > $i", &tcl_dialect::LexerGrammar::default()),
            Some(("i".into(), "<".into(), 10)), // flipped
        );
        assert_eq!(
            super::parse_simple_for_cond("$i < 10 && 0", &tcl_dialect::LexerGrammar::default()),
            None
        );
        // Negative bound: the expression lexer splits `-5` into a unary
        // `-` plus `5`, which the signed-integer folding reassembles.
        assert_eq!(
            super::parse_simple_for_cond("$i > -5", &tcl_dialect::LexerGrammar::default()),
            Some(("i".into(), ">".into(), -5)),
        );
        assert_eq!(
            super::parse_simple_for_cond("-5 < $i", &tcl_dialect::LexerGrammar::default()),
            Some(("i".into(), ">".into(), -5)), // flipped
        );
        // String comparison operators are accepted; braces are stripped.
        assert_eq!(
            super::parse_simple_for_cond("{$i ne 3}", &tcl_dialect::LexerGrammar::default()),
            Some(("i".into(), "ne".into(), 3)),
        );
        // `${i}` braced variable form and `==`.
        assert_eq!(
            super::parse_simple_for_cond("${i} == 7", &tcl_dialect::LexerGrammar::default()),
            Some(("i".into(), "==".into(), 7)),
        );
        // Compound / logical / ternary / non-integer bounds reject.
        assert_eq!(
            super::parse_simple_for_cond(
                "$i < 10 || $j > 0",
                &tcl_dialect::LexerGrammar::default()
            ),
            None
        );
        assert_eq!(
            super::parse_simple_for_cond("!$done", &tcl_dialect::LexerGrammar::default()),
            None
        );
        assert_eq!(
            super::parse_simple_for_cond("$i ? 1 : 0", &tcl_dialect::LexerGrammar::default()),
            None
        );
        assert_eq!(
            super::parse_simple_for_cond("$i < 10.5", &tcl_dialect::LexerGrammar::default()),
            None
        );
        // The `-?\d+` bound and `\$\{?(\w+)\}?` var shapes mean a leading
        // `+`, an array index, or a namespace qualifier reject.
        assert_eq!(
            super::parse_simple_for_cond("$i < +5", &tcl_dialect::LexerGrammar::default()),
            None
        );
        assert_eq!(
            super::parse_simple_for_cond("$arr(i) < 5", &tcl_dialect::LexerGrammar::default()),
            None
        );
        assert_eq!(
            super::parse_simple_for_cond("$ns::v < 5", &tcl_dialect::LexerGrammar::default()),
            None
        );
    }

    /// A step is what the registry's integer cell update adds, run by its
    /// route over literal words from 0: no command is read by its spelling.
    #[test]
    fn the_step_runs_its_route() {
        let registry = super::default_registry();
        let step = |text: &str| {
            let cmd = sole_command(text, config()).expect("one command");
            super::command_increment(
                &cmd,
                "i",
                super::BoundsMetadataContext::Standalone(Some(registry)),
                config(),
            )
        };
        assert_eq!(step("incr i"), Some(1));
        assert_eq!(step("incr i -2"), Some(-2));
        assert_eq!(step("::incr i 3"), Some(3));
        assert_eq!(step("set i 3"), None);
        assert_eq!(step("incr j"), None);
        assert_eq!(step("incr i $n"), None);
        assert_eq!(step("append i 1"), None);
    }

    /// W241 seeds a loop's counter from its iteration plan's bound and step,
    /// and from the integer the solver proves it starts at, so a counter
    /// started from a variable is checked as one started from a literal is:
    /// `set start 5` then `for {set i $start} {$i < 10} {incr i -1} {}`
    /// never reaches 10, nor does the same counter in a `while` whose body's
    /// one increment moves it away. A start the unit does not prove, a
    /// counter that reaches its bound, a second write of the counter, an
    /// increment that does not run on every pass, and a body that can leave
    /// the loop — here by a `break` written bare, which the body scan reads
    /// as the script it is (#2381) — each keep the loop silent; so do a
    /// write a `[…]` word makes, a binder, and a call to a command the file
    /// does not define, each of which the unit holding the loop knows may
    /// write the counter.
    #[test]
    fn w240_seeds_from_the_iteration_plan() {
        for src in [
            "set start 5\nfor {set i $start} {$i < 10} {incr i -1} {}\n",
            "set start 5\nset i $start\nwhile {$i < 10} {incr i -1}\n",
            "set i 5\nwhile {$i < 10} {puts $i; incr i -1}\n",
            "proc p {} {\n set n 3\n for {set i $n} {$i != 10} {incr i 2} {}\n}\n",
        ] {
            assert_verdicts(src, &["W241"]);
        }
        for src in [
            "proc p {start} {\n set i $start\n while {$i < 10} {incr i}\n}\n",
            "proc p {start} {\n for {set i $start} {$i < 10} {incr i -1} {}\n}\n",
            "set start 5\nset i $start\nwhile {$i < 10} {incr i}\n",
            "set i 5\nwhile {$i < 10} {incr i -1; if {$i < 0} {set i 20}}\n",
            "set i 5\nwhile {$i < 10} {incr i -1; incr i -1}\n",
            "set i 5\nwhile {$i < 10} {if {[gets stdin] eq {x}} {incr i -1}}\n",
            "set i 5\nwhile {$i < 10} {if {$i < 0} break; incr i -1}\n",
            "set i 5\nwhile {$i < 10} {incr i -1; set j [incr i 20]}\n",
            "set i 5\nwhile {$i < 10} {incr i -1; foreach i {100} {}}\n",
            "set i 5\nwhile {$i < 10} {incr i -1; foo i}\n",
        ] {
            assert_verdicts(src, &[]);
        }
        let mut analyser = Analyser::new();
        let messages: Vec<String> = analyser
            .analyse(
                "set start 5\nset i $start\nwhile {$i < 10} {incr i -1}\n",
                "tcl8.6",
            )
            .diagnostics
            .iter()
            .filter(|d| d.code.as_str() == "W241")
            .map(|d| d.message.clone())
            .collect();
        assert_eq!(
            messages,
            [
                "while loop is provably infinite: counter $i starts at 5, moves by -1 per step, \
              and compares < 10 (never reached)"
            ]
        );
    }

    #[test]
    fn body_scans_are_command_structural() {
        // A write counts only in command position, not inside a string.
        assert!(super::body_writes_var(
            "incr i",
            "i",
            super::BoundsMetadataContext::Standalone(None),
            config()
        ));
        assert!(super::body_writes_var(
            "if {$c} {set i 9}",
            "i",
            super::BoundsMetadataContext::Standalone(None),
            config()
        )); // nested body
        assert!(!super::body_writes_var(
            "puts \"set i now\"",
            "i",
            super::BoundsMetadataContext::Standalone(None),
            config()
        )); // inside a string
        assert!(!super::body_writes_var(
            "incr index",
            "i",
            super::BoundsMetadataContext::Standalone(None),
            config()
        )); // word boundary
        // `break` / `return` / `throw` / `tailcall` likewise count only as
        // commands. `return`/`throw` resolve via the registry's
        // TERMINATES_BLOCK trait; `break`/`tailcall` are recognised without it.
        let reg = tcl_registry::model::ingress::static_context_for("tcl8.6").commands();
        assert!(super::body_may_exit(
            "break",
            super::BoundsMetadataContext::Standalone(Some(reg)),
            config()
        ));
        assert!(super::body_may_exit(
            "if {$c} {return}",
            super::BoundsMetadataContext::Standalone(Some(reg)),
            config()
        )); // nested
        assert!(super::body_may_exit(
            "throw MYERR boom",
            super::BoundsMetadataContext::Standalone(Some(reg)),
            config()
        )); // now covered
        assert!(super::body_may_exit(
            "tailcall foo",
            super::BoundsMetadataContext::Standalone(Some(reg)),
            config()
        ));
        assert!(!super::body_may_exit(
            "puts breakfast",
            super::BoundsMetadataContext::Standalone(Some(reg)),
            config()
        )); // not a command
        // `break`/`tailcall` are recognised even without a registry handle.
        assert!(super::body_may_exit(
            "break",
            super::BoundsMetadataContext::Standalone(None),
            config()
        ));
        assert!(super::body_may_exit(
            "tailcall foo",
            super::BoundsMetadataContext::Standalone(None),
            config()
        ));
        // A word the registry names a body is a script however it is
        // written: `if` runs a bare or a quoted body as `{…}`, so the exit
        // inside one counts (#2381). The same word as another command's
        // data is no script.
        assert!(super::body_may_exit(
            "if {$c} break",
            super::BoundsMetadataContext::Standalone(Some(reg)),
            config()
        ));
        assert!(super::body_may_exit(
            "if {$c} \"break\"",
            super::BoundsMetadataContext::Standalone(Some(reg)),
            config()
        ));
        assert!(super::body_may_exit(
            "if {$c} {puts x} else return",
            super::BoundsMetadataContext::Standalone(Some(reg)),
            config()
        ));
        assert!(super::body_may_exit(
            "if {$c} break",
            super::BoundsMetadataContext::Standalone(None),
            config()
        ));
        assert!(!super::body_may_exit(
            "puts break",
            super::BoundsMetadataContext::Standalone(Some(reg)),
            config()
        ));
    }

    fn idx_codes_for(src: &str, dialect: &str) -> Vec<String> {
        // Authored source number syntax and actual catalogue availability are
        // independent of Native body entry or an executed handler.
        let selected = tcl_dialect::DialectProfile::find(dialect).expect("authored bounds grammar");
        let mut profile = tcl_dialect::DialectProfile::plain_tcl().clone();
        profile.grammar = selected.grammar;
        let profile = profile.intern();
        let input = crate::analyser::ResolvedAnalysisInput::new(
            profile,
            profile,
            tcl_registry::model::ingress::resolve_environment(dialect).default_context_registry(),
            tcl_lexer::LexerConfig::for_file_grammar(profile.grammar),
        );
        assert!(input.has_logical_source_name_context());
        let mut a = Analyser::new().with_resolved_input(input);
        a.analyse(src, "tcl")
            .diagnostics
            .iter()
            .filter(|d| matches!(d.code.as_str(), "W230" | "W232"))
            .map(|d| d.code.to_string())
            .collect()
    }

    fn idx_codes(src: &str) -> Vec<String> {
        idx_codes_for(src, "tcl8.6")
    }

    #[test]
    fn w230_list_index_out_of_range() {
        assert_eq!(idx_codes("lindex {a b c} 5\n"), vec!["W230"]);
        assert_eq!(idx_codes("lindex {a b c} -1\n"), vec!["W230"]);
        assert_eq!(idx_codes("lindex {a b c} end-5\n"), vec!["W230"]);
        // In range and dynamic list → none.
        assert_eq!(
            idx_codes("lindex {a b c} 1\n"),
            [] as [std::string::String; 0]
        );
        assert_eq!(
            idx_codes("lindex {a b c} end\n"),
            [] as [std::string::String; 0]
        );
        assert_eq!(idx_codes("lindex $x 5\n"), [] as [std::string::String; 0]);
    }

    #[test]
    fn w230_single_element_nested_list_length() {
        // `{{a b c}}` is a one-element list (the inner `{a b c}` is a
        // single braced element).  The segmenter already strips the outer
        // braces, so its length is 1 — index 2 is out of range.  A
        // double brace-strip would wrongly count three words and miss it.
        assert_eq!(idx_codes("lindex {{a b c}} 2\n"), vec!["W230"]);
        // Index 0 is the lone element → in range.
        assert_eq!(
            idx_codes("lindex {{a b c}} 0\n"),
            [] as [std::string::String; 0]
        );
    }

    #[test]
    fn w232_string_index_out_of_range() {
        assert_eq!(idx_codes("string index abc 10\n"), vec!["W232"]);
        assert_eq!(idx_codes("string index abc -1\n"), vec!["W232"]);
        assert_eq!(
            idx_codes("string index abc 1\n"),
            [] as [std::string::String; 0]
        );
        assert_eq!(
            idx_codes("string index abc end\n"),
            [] as [std::string::String; 0]
        );
    }

    #[test]
    fn w232_braced_literal_string_length() {
        // `{{hello}}` is a braced word whose runtime value is the literal
        // 7-char string `{hello}` (the segmenter strips only the outer
        // braces).  Index 6 is the last char — in range.  A double
        // brace-strip would count five chars and flag it spuriously.
        assert_eq!(
            idx_codes("string index {{hello}} 6\n"),
            [] as [std::string::String; 0]
        );
        // One past the end is still out of range.
        assert_eq!(idx_codes("string index {{hello}} 7\n"), vec!["W232"]);
    }

    #[test]
    fn w230_lrange_lreplace_empty_slice() {
        assert_eq!(idx_codes("lrange {a b c} 5 7\n"), vec!["W230"]);
        assert_eq!(idx_codes("lrange {a b c} -3 -1\n"), vec!["W230"]);
        assert_eq!(idx_codes("lrange {a b c} 2 0\n"), vec!["W230"]); // clamped first>last
        assert_eq!(idx_codes("lreplace {a b c} 5 7 X\n"), vec!["W230"]);
        assert_eq!(
            idx_codes("lrange {a b c} 0 1\n"),
            [] as [std::string::String; 0]
        );
    }

    /// The length W231 checks against is the list's value after every cell
    /// update on it the walk can evaluate: `lappend xs a b c` after `set xs
    /// {}` leaves three elements (#2054).
    #[test]
    fn w231_length_follows_the_cell_updates() {
        assert!(code_msgs("set xs {}\nlappend xs a b c\nlset xs 2 X\n", "W231").is_empty());
        let m = code_msgs("set xs {}\nlappend xs a b c\nlset xs 5 Y\n", "W231");
        assert_eq!(m.len(), 1, "{m:?}");
        assert!(m[0].contains("(list has 3 elements)"), "{}", m[0]);
        assert!(
            code_msgs(
                "set xs {}\nlappend xs a\nlappend xs {b c} d\nlset xs 3 X\n",
                "W231"
            )
            .is_empty()
        );
        let m = code_msgs(
            "set xs {}\nlappend xs a\nlappend xs {b c} d\nlset xs 4 X\n",
            "W231",
        );
        assert!(
            m.len() == 1 && m[0].contains("(list has 3 elements)"),
            "{m:?}"
        );
        // A write the walk cannot evaluate forgets the length rather than
        // reporting against a stale one.
        assert!(code_msgs("set xs {a b}\nlappend xs $v\nlset xs 9 X\n", "W231").is_empty());
        assert!(code_msgs("set xs {a b}\nappend xs $v\nlset xs 9 X\n", "W231").is_empty());
        // A string append changes the list too: `a b` then `append xs c`
        // is `a bc`, two elements.
        let m = code_msgs("set xs {a b}\nappend xs c\nlset xs 5 X\n", "W231");
        assert!(
            m.len() == 1 && m[0].contains("(list has 2 elements)"),
            "{m:?}"
        );
    }

    /// The walk reads a literal word as Tcl substitutes it: `append xs
    /// "\tc"` appends a tab, so `a b<tab>c` has three elements (tclsh 8.6
    /// to 9.1 extend it with `lset xs 3 X` and print `a b c X`). Read raw,
    /// the list had two elements, and W231 reported a raise at index 3.
    #[test]
    fn w231_reads_an_appended_escape_as_tcl_substitutes_it() {
        assert!(code_msgs("set xs {a b}\nappend xs \"\\tc\"\nlset xs 2 X\n", "W231").is_empty());
        let m = code_msgs("set xs {a b}\nappend xs \"\\tc\"\nlset xs 5 X\n", "W231");
        assert!(
            m.len() == 1 && m[0].contains("(list has 3 elements)"),
            "{m:?}"
        );
    }

    #[test]
    fn w232_string_range_replace_empty_slice() {
        assert_eq!(idx_codes("string range abc 5 7\n"), vec!["W232"]);
        assert_eq!(idx_codes("string range abc -3 -1\n"), vec!["W232"]);
        assert_eq!(idx_codes("string replace abc 5 7 X\n"), vec!["W232"]);
        assert_eq!(
            idx_codes("string range abc 0 1\n"),
            [] as [std::string::String; 0]
        );
    }

    #[test]
    fn pair_slice_empty_logic() {
        assert!(super::pair_slice_empty(5, 7, 3)); // both above
        assert!(super::pair_slice_empty(-3, -1, 3)); // both below
        assert!(super::pair_slice_empty(2, 0, 3)); // clamped first>last
        assert!(super::pair_slice_empty(0, 0, 0)); // empty container
        assert!(!super::pair_slice_empty(0, 1, 3)); // valid
    }

    #[test]
    fn index_helpers() {
        let n = tcl_dialect::NumberSyntax::Tcl85;
        assert_eq!(super::resolve_index("end", 3, n), Some(2));
        assert_eq!(super::resolve_index("end-5", 3, n), Some(-3));
        assert_eq!(super::resolve_index("end+1", 3, n), Some(3));
        assert_eq!(super::resolve_index("2", 3, n), Some(2));
        assert_eq!(super::resolve_index("1+1", 3, n), Some(2));
        assert_eq!(super::resolve_index("0x2", 3, n), Some(2));
        assert_eq!(super::resolve_index("+5", 3, n), Some(5));
        assert_eq!(super::resolve_index("$x", 3, n), None);
        assert!(super::is_literal_index("end-2", n));
        assert!(!super::is_literal_index("end - 2", n));
    }

    #[test]
    fn index_diagnostics_use_the_document_number_syntax() {
        let list = "lindex {a b c d e f g h i} 010\n";
        let string = "string index abcdefghi 010\n";
        // Tcl 8.x reads 010 as octal 8 (in range); Tcl 9.x reads it as
        // decimal 10 (out of range). Mutation: replacing the threaded
        // profile syntax with the ambient parser makes these pairs agree.
        for dialect in ["tcl8.4", "tcl8.5", "tcl8.6"] {
            assert_eq!(idx_codes_for(list, dialect).len(), 0, "{dialect}");
            assert_eq!(idx_codes_for(string, dialect).len(), 0, "{dialect}");
        }
        for dialect in ["tcl9.0", "tcl9.1"] {
            assert_eq!(idx_codes_for(list, dialect), vec!["W230"], "{dialect}");
            assert_eq!(idx_codes_for(string, dialect), vec!["W232"], "{dialect}");
        }
    }

    #[test]
    fn condition_constant_classifies() {
        assert_eq!(super::condition_constant("0"), Some(false));
        assert_eq!(super::condition_constant("1"), Some(true));
        assert_eq!(super::condition_constant("{true}"), Some(true));
        assert_eq!(super::condition_constant("$x < 10"), None);
    }

    // W231 (lset out of range) & W242 (unprovable termination).

    fn code_msgs_for(src: &str, dialect: &str, code: &str) -> Vec<String> {
        let mut a = Analyser::new();
        a.analyse(src, dialect)
            .diagnostics
            .iter()
            .filter(|d| d.code.as_str() == code)
            .map(|d| d.message.clone())
            .collect()
    }

    fn code_msgs(src: &str, code: &str) -> Vec<String> {
        code_msgs_for(src, "tcl8.6", code)
    }

    #[test]
    fn w231_lset_negative_index_always_errors() {
        let m = code_msgs("lset L -1 x\n", "W231");
        assert_eq!(m.len(), 1);
        assert!(m[0].contains("lset index '-1' is negative"), "{m:?}");
        // Negative literal fires even for nested (multi-index) forms.
        assert_eq!(code_msgs("lset L i j -1 v\n", "W231").len(), 1);
    }

    #[test]
    fn w231_lset_index_past_append_slot() {
        // List length recovered from the recent literal `set`.
        let m = code_msgs("set L {a b c}\nlset L 5 x\n", "W231");
        assert_eq!(m.len(), 1);
        assert!(
            m[0].contains("resolves to 5 (list has 3 elements)"),
            "{m:?}"
        );
        // The append slot (index == length) and valid indices are fine.
        assert_eq!(
            code_msgs("set L {a b c}\nlset L 3 x\n", "W231"),
            [] as [std::string::String; 0]
        );
        assert_eq!(
            code_msgs("set L {a b c}\nlset L end+1 x\n", "W231"),
            [] as [std::string::String; 0]
        );
        assert_eq!(
            code_msgs("set L {a b c}\nlset L 2 x\n", "W231"),
            [] as [std::string::String; 0]
        );
    }

    #[test]
    fn w231_uses_the_document_number_syntax() {
        let src = "set L {a b c d e f g h i}\nlset L 010 x\n";
        for dialect in ["tcl8.4", "tcl8.5", "tcl8.6"] {
            assert_eq!(
                code_msgs_for(src, dialect, "W231").len(),
                0,
                "{dialect} reads 010 as in-range octal 8"
            );
        }
        for dialect in ["tcl9.0", "tcl9.1"] {
            assert_eq!(
                code_msgs_for(src, dialect, "W231").len(),
                1,
                "{dialect} reads 010 as out-of-range decimal 10"
            );
        }
    }

    /// A write this scan cannot turn into a fresh length invalidates the one
    /// it recovered earlier, instead of reporting the stale figure (#2054).
    ///
    /// `set xs {}` then `lappend xs a b c` leaves a three-element list, and
    /// tclsh 9.0.4 runs `lset xs 2 X` happily, printing `a b X`. W231 used to
    /// report "list has 0 elements" from the initial `set`.
    #[test]
    fn w231_abstains_after_a_write_it_cannot_measure() {
        for src in [
            // The issue's own shape.
            "set xs {}\nlappend xs a b c\nlset xs 2 X\n",
            // Same gap, reached by a non-literal `set` rather than `lappend`.
            "set xs {}\nset y {a b c}\nset xs $y\nlset xs 2 X\n",
            // And by a command substitution.
            "set xs {}\nset xs [list a b c]\nlset xs 2 X\n",
            // `append` is the same class of unmeasurable write.
            "set xs {}\nappend xs \"a b c\"\nlset xs 2 X\n",
        ] {
            assert_eq!(
                code_msgs(src, "W231").len(),
                0,
                "an unmeasurable write must invalidate the earlier length: {src:?}",
            );
        }
    }

    /// The abstention must not silence a genuine out-of-range index: with no
    /// intervening write the literal length still stands.
    #[test]
    fn w231_still_reports_a_real_overrun() {
        assert!(
            !code_msgs("set xs {a b}\nlset xs 5 X\n", "W231").is_empty(),
            "an untouched literal list keeps its length",
        );
    }

    #[test]
    fn w231_silent_without_recoverable_length() {
        // No prior literal `set` → only negative literals would fire.
        assert_eq!(
            code_msgs("lset L 5 x\n", "W231"),
            [] as [std::string::String; 0]
        );
        // A `set` in a deeper scope must not be trusted.
        assert_eq!(
            code_msgs("proc p {} { set L {a b c} }\nlset L 5 x\n", "W231").len(),
            0,
            "deeper-scope set should not leak its length"
        );
    }

    #[test]
    fn w242_counter_not_modified() {
        let m = code_msgs("while {$x < 10} {puts hi}\n", "W242");
        assert_eq!(m.len(), 1);
        assert!(
            m[0].contains("variable 'x' in the condition is never modified"),
            "{m:?}"
        );
        // `for` with an empty step and a body that ignores the counter, over a
        // bound nothing proves: the condition does not decide.
        assert_eq!(
            code_msgs("for {set i 0} {$i < $n} {} {puts hi}\n", "W242").len(),
            1
        );
    }

    #[test]
    fn w242_silent_when_counter_modified() {
        // Body writes the counter via incr / set / lappend → no W242.
        assert_eq!(
            code_msgs("while {$x < 10} {incr x}\n", "W242"),
            [] as [std::string::String; 0]
        );
        assert_eq!(
            code_msgs("while {$x < 10} {set x 5}\n", "W242"),
            [] as [std::string::String; 0]
        );
        // A normal `for` whose step advances the counter is silent.
        assert_eq!(
            code_msgs("for {set i 0} {$i < 10} {incr i} {puts hi}\n", "W242"),
            [] as [std::string::String; 0]
        );
    }

    // Corpus shape (`tcltest.tcl`'s option-usage word-wrapper): a `[cmd $var]`
    // command substitution in the condition hides the loop's real progress
    // variable from the shallow scalar scan, which would then blame whichever
    // *other* bare variable it finds instead.

    #[test]
    fn w242_silent_when_the_progress_variable_is_inside_a_command_substitution() {
        // FP: `u` shrinks every iteration via `string range`/`string trim` in
        // the body — real, provable progress — but the condition's only
        // *bare* variable is `rest` (a fixed threshold the loop never
        // touches), which a first-`Variable`-token scan would pick instead.
        // Exact corpus shape.
        assert_eq!(
            code_msgs(
                "while {[string length $u] > $rest} {\
                     set u [string trim [string range $u 1 end]]\
                 }\n",
                "W242"
            )
            .len(),
            0
        );
    }

    #[test]
    fn w242_silent_for_a_command_substitution_condition_even_when_nothing_is_modified() {
        // FP guard, the genuinely-unprovable case: abstaining is still
        // correct here — the analyser cannot see into `[llength $l]`'s
        // argument to know whether `l` (or anything else) changes, so it
        // must not guess at a bare variable elsewhere in the condition
        // (there is none here) or fabricate a counter name.
        assert_eq!(
            code_msgs("while {[llength $l] > 0} {puts hi}\n", "W242"),
            [] as [std::string::String; 0]
        );
    }

    #[test]
    fn w242_severity_is_hint() {
        let mut a = Analyser::new();
        let r = a.analyse("while {$x < 10} {puts hi}\n", "tcl8.6");
        let w242 = r
            .diagnostics
            .iter()
            .find(|d| d.code == DiagCode::W242)
            .unwrap();
        assert_eq!(w242.severity, super::Severity::Hint);
    }

    fn w231(src: &str) -> usize {
        let mut a = Analyser::new();
        a.analyse(src, "tcl8.6")
            .diagnostics
            .iter()
            .filter(|d| d.code == DiagCode::W231)
            .count()
    }

    #[test]
    fn w231_list_length_recovered_inside_proc_body() {
        // The `set l {a b c}` shares the proc body's flat scope with the
        // `lset`, so its length (3) is recovered and `99` proves OOR —
        // top-level-only segmentation would miss this.
        assert_eq!(
            w231("proc f {} {\n    set l {a b c}\n    lset l 99 X\n}\n"),
            1
        );
        // `end` on an empty list is out of range.
        assert_eq!(w231("proc f {} {\n    set l {}\n    lset l end X\n}\n"), 1);
        // Still fires at top level.
        assert_eq!(w231("set l {a b c}\nlset l 99 X\n"), 1);
        // The append slot (index == length) is accepted.
        assert_eq!(
            w231("proc f {} {\n    set l {a b c}\n    lset l 3 X\n}\n"),
            0
        );
    }

    fn has_code(src: &str, code: &str) -> bool {
        let mut a = Analyser::new();
        a.analyse(src, "tcl8.6")
            .diagnostics
            .iter()
            .any(|d| d.code.as_str() == code)
    }

    #[test]
    fn bounds_checks_recurse_into_command_substitutions() {
        // Original authored nested-source geometry is queried once. This
        // positive Logical fixture grants no Native child body activation.
        assert_eq!(idx_codes("set x [lindex {a b c} 9]\n"), vec!["W230"]);
        assert_eq!(
            idx_codes("proc f {} { return [string index abc 99] }\n"),
            vec!["W232"]
        );
        assert_eq!(
            idx_codes("proc f {} { return [join [string index abc 99]] }\n"),
            vec!["W232"]
        );
    }

    #[test]
    fn security_checks_recurse_into_command_substitutions() {
        // The full per-command dispatch — not just bounds — runs on a
        // substitution command, so `open "|$cmd"` nested in `[…]` still
        // fires the W103 pipeline-injection check.
        assert!(has_code(
            "proc f {cmd} { set fh [open \"|$cmd\" r] }\n",
            "W103"
        ));
    }

    #[test]
    fn w231_length_not_recovered_across_scope_boundary() {
        // A `set` in a *different* proc body must not leak its length to a
        // top-level `lset` — it belongs to a script the `lset` never enters.
        assert_eq!(w231("proc other {} { set l {a b c} }\nlset l 99 X\n"), 0);
        // Descending into a body starts a fresh scope, so an outer `set` is
        // not trusted for an `lset` written inside one.
        assert_eq!(
            w231("set l {a b c}\nnamespace eval ns {\n    lset l 99 X\n}\n"),
            0
        );
        // Nor across an `oo::define` member body.
        assert_eq!(
            w231("set l {a b c}\noo::define C {\n    method m {} { lset l 99 X }\n}\n"),
            0
        );
    }

    #[test]
    fn w231_ignores_a_set_that_is_not_a_command() {
        // The `set` inside the quoted word is text, not an assignment, so it
        // supplies no length and cannot shorten the real one.  A line-anchored
        // byte scan matches it and reports index 4 as out of range for a
        // two-element list.
        let src = "set l {a b c d e f}\nputs \"\nset l {a b}\n\"\nlset l 4 X\n";
        assert_eq!(w231(src), 0);
    }

    #[test]
    fn w231_reports_across_a_sibling_definition() {
        // `proc` here is a *sibling* command, not a scope the `lset` is
        // inside, so the top-level `set`'s length still reaches it.  A
        // `\\b(?:proc|namespace\\s+eval|apply|try)\\b` marker scan sees the
        // word `proc` between the two and goes silent.
        assert_eq!(
            w231("set l {a b c}\nproc helper {} { return 1 }\nlset l 9 X\n"),
            1
        );
    }

    #[test]
    fn w231_recovers_a_length_the_line_anchored_scan_missed() {
        // Not at a line start, and a literal carrying a nested sublist: both
        // are ordinary words to the segmenter, though neither matches
        // `(?:^|\\n)\\s*set\\s+(\\w+)\\s+(\\{[^{}]*\\})`.
        assert_eq!(w231("puts hi; set l {a {b c} d}\nlset l 9 X\n"), 1);
    }
    #[test]
    fn shallow_bounds_metadata_retains_availability_without_default_catalogue_fallback() {
        // naming.compiler.original-analysis-metadata-context
        // docs/design/analysis/name-resolution-proofs/original-analysis-metadata-context.md
        let current = tcl_registry::model::context_for_profile(
            tcl_dialect::DialectProfile::find("tcl9.0").unwrap(),
        );
        let old = tcl_registry::model::context_for_profile(
            tcl_dialect::DialectProfile::find("tcl8.4").unwrap(),
        );
        let old = old.with_command_store(std::sync::Arc::clone(current.commands()));
        assert!(super::is_loop_exit_command(
            "tailcall",
            super::BoundsMetadataContext::Retained(&current)
        ));
        assert!(!super::is_loop_exit_command(
            "tailcall",
            super::BoundsMetadataContext::Retained(&old)
        ));
        assert!(super::is_loop_exit_command(
            "break",
            super::BoundsMetadataContext::Retained(&old)
        ));
        let no_tcl = tcl_registry::model::context_for_profile(
            tcl_dialect::DialectProfile::find("f5-bigip").unwrap(),
        );
        let no_tcl = no_tcl.with_command_store(std::sync::Arc::clone(current.commands()));
        assert!(
            super::loop_shape(
                "while",
                &[],
                super::BoundsMetadataContext::Retained(&no_tcl),
                None
            )
            .is_none()
        );
        assert!(
            super::loop_shape(
                "while",
                &[],
                super::BoundsMetadataContext::Standalone(None),
                None
            )
            .is_some()
        );
    }

    /// The loop-termination verdicts (W240, W241, W242) `src` draws on the
    /// whole-file walk and on the per-item walk, each in source order.
    fn verdicts_on_both_paths(src: &str) -> (Vec<String>, Vec<String>) {
        let verdicts = |per_item: bool| -> Vec<String> {
            let mut a = Analyser::new();
            let result = if per_item {
                a.analyse_per_item(src, "tcl8.6")
            } else {
                a.analyse(src, "tcl8.6")
            };
            let mut found: Vec<(u32, String)> = result
                .diagnostics
                .iter()
                .filter(|d| matches!(d.code.as_str(), "W240" | "W241" | "W242"))
                .map(|d| (d.span.start(), d.code.to_string()))
                .collect();
            found.sort();
            found.into_iter().map(|(_, code)| code).collect()
        };
        (verdicts(false), verdicts(true))
    }

    /// `src` draws exactly `expected` on both paths.
    fn assert_verdicts(src: &str, expected: &[&str]) {
        let (whole, per_item) = verdicts_on_both_paths(src);
        assert_eq!(whole, expected, "whole file: {src}");
        assert_eq!(per_item, expected, "per item: {src}");
    }

    /// `src` draws neither W240 nor W241 on either path: the header is left
    /// undecided, and the text may still draw W242's hint that nothing in the
    /// loop modifies its counter.
    fn assert_undecided(src: &str) {
        let (whole, per_item) = verdicts_on_both_paths(src);
        for (path, found) in [("whole file", &whole), ("per item", &per_item)] {
            assert!(
                found.iter().all(|code| code == "W242"),
                "{path}: {src}\n{found:?}"
            );
        }
        assert_eq!(per_item, whole, "{src}");
    }

    /// A `switch` the flow graph keeps as one statement — `-glob`, `-regexp`,
    /// `-nocase`, a fall-through arm, `case` — defines every name its arms
    /// write, so a loop an arm can end is no infinite loop. tclsh 8.4 to 9.1
    /// with input `q`: `set go 1; while {$go} { switch -glob -- [gets stdin]
    /// { q* { set go 0 } } }; puts done` prints `done`.
    #[test]
    fn a_switch_arm_that_ends_the_loop_keeps_w241_silent() {
        for src in [
            "set go 1; while {$go} { switch -glob -- [gets stdin] { q* { set go 0 } } }; puts done\n",
            "set go 1\nwhile {$go} {\n switch -nocase -- [gets stdin] {\n  q { set go 0 }\n }\n}\n",
            "set go 1\nwhile {$go} {\n switch -regexp -- [gets stdin] {\n  {^q} { set go 0 }\n }\n}\n",
            "set go 1\nwhile {$go} {\n switch -glob -- [gets stdin] {\n  x - q* { set go 0 }\n }\n}\n",
            "set go 1\nwhile {$go} {\n switch -glob -- [gets stdin] {\n  a* {}\n  default { set go 0 }\n }\n}\n",
            "set go 1\nwhile {$go} {\n case [gets stdin] in {\n  q* { set go 0 }\n }\n}\n",
            "set go 1\nfor {} {$go} {} {\n switch -glob -- [gets stdin] { q* { set go 0 } }\n}\n",
            "proc p {} {\n set go 1\n while {$go} {\n  switch -glob -- [gets stdin] { q* { set go 0 } }\n }\n}\n",
            // A write buried in a command the arm runs, and each kind of write.
            "set go 1\nwhile {$go} {\n switch -glob -- [gets stdin] { q* { if {[llength {a}]} { set go 0 } } }\n}\n",
            "set n 3\nwhile {$n} {\n switch -glob -- [gets stdin] { q* { incr n -1 } }\n}\n",
            "set l {}\nwhile {[llength $l] < 1} {\n switch -glob -- [gets stdin] { q* { lappend l x } }\n}\n",
            "set go 1\nwhile {[info exists go]} {\n switch -glob -- [gets stdin] { q* { unset go } }\n}\n",
            // A `global` binding an arm makes, then writes through.
            "proc p {} {\n set go 1\n while {$go} {\n  switch -glob -- [gets stdin] { q* { global go; set go 0 } }\n }\n}\n",
        ] {
            assert_verdicts(src, &[]);
        }
    }

    /// What a command an arm runs does to the frame ends the loop as a write
    /// the arm makes itself would: a callee that writes the caller's name
    /// through `upvar`, and a command that may write any name (`namespace
    /// eval`, `dict with`). A callee that writes only a global leaves a local
    /// loop alone.
    #[test]
    fn a_command_an_arm_runs_that_ends_the_loop_keeps_w241_silent() {
        for src in [
            "proc zero {v} {upvar 1 $v x; set x 0}\nproc p {} {\n set go 1\n while {$go} {\n  switch -glob -- [gets stdin] { q* { zero go } }\n }\n}\n",
            "proc zero {v} {upvar 1 $v x; set x 0}\nset go 1\nwhile {$go} {\n switch -glob -- [gets stdin] { q* { zero go } }\n}\n",
            "set go 1\nwhile {$go} {\n switch -glob -- [gets stdin] { q* { namespace eval :: {set go 0} } }\n}\n",
            "proc p {} {\n set go 1\n while {$go} {\n  switch -glob -- [gets stdin] { q* { dict with d { set go 0 } } }\n }\n}\n",
        ] {
            assert_undecided(src);
        }
        assert_verdicts(
            "proc hit {} {global hits; incr hits}\nproc p {} {\n set go 1\n while {$go} {\n  switch -glob -- [gets stdin] { q* { hit } }\n }\n}\n",
            &["W241"],
        );
    }

    /// The same statement leaves a loop no arm writes for alone: only a name
    /// an arm writes stops being decided.
    #[test]
    fn a_switch_arm_that_writes_another_name_leaves_the_verdict() {
        assert_verdicts(
            "set go 1\nwhile {$go} {\n switch -glob -- [gets stdin] { q* { set other 0 } }\n}\n",
            &["W241"],
        );
        assert_verdicts(
            "proc p {} {\n set go 1\n while {$go} {\n  switch -glob -- [gets stdin] { q* { set other 0 } }\n }\n}\n",
            &["W241"],
        );
    }

    /// A loop nothing else sets is dead until an arm sets it: no W240 for
    /// `set go 0; switch -glob -- [gets stdin] { q* { set go 1 } }; while
    /// {$go} { … }`, which tclsh runs once for input `q`.
    #[test]
    fn a_switch_arm_that_starts_the_loop_keeps_w240_silent() {
        for src in [
            "set go 0\nswitch -glob -- [gets stdin] { q* { set go 1 } }\nwhile {$go} { puts x; set go 0 }\n",
            "set go 0\nswitch -glob -- [gets stdin] { q* { set go 1 } }\nfor {} {$go} {} { puts x; set go 0 }\n",
            "proc p {} {\n set go 0\n switch -glob -- [gets stdin] { q* { set go 1 } }\n while {$go} { puts x; set go 0 }\n}\n",
        ] {
            assert_verdicts(src, &[]);
        }
        assert_verdicts(
            "set n 0\nswitch -glob -- [gets stdin] { q* { set other 1 } }\nwhile {$n} {puts x}\n",
            &["W240"],
        );
    }

    /// A callback script the module stores writes the loop's variable
    /// without any statement of the loop saying so: `after`, `after idle`, a
    /// variable trace, `fileevent`, `chan event`, `bind`, and a callback that
    /// names a procedure writing the name through `::`.
    #[test]
    fn a_callback_that_writes_the_loop_variable_keeps_w241_silent() {
        for src in [
            "set done 0\nafter 100 { set done 1 }\nwhile {!$done} { update }\n",
            "set go 1\nafter idle {set ::go 0}\nwhile {$go} {update}\n",
            "set go 1\ntrace add variable x write { set ::go 0 ;# }\nwhile {$go} { set x 1 }\nputs done\n",
            "set go 1\nfileevent stdin readable { set go 0 }\nwhile {$go} { update }\n",
            "set go 1\nchan event stdin readable { set go 0 }\nwhile {$go} { update }\n",
            "set go 1\nbind . <Key> { set go 0 }\nwhile {$go} { update }\n",
            "proc tick {} { set ::done 1 }\nset done 0\nafter 100 tick\nwhile {!$done} { update }\n",
            // A quoted script, and a command prefix built with `list`.
            "set done 0\nafter 100 \"set done 1\"\nwhile {!$done} { update }\n",
            "set done 0\nafter 100 [list set done 1]\nwhile {!$done} { update }\n",
            "proc tick {n} { set ::done $n }\nset done 0\nafter 100 [list tick 1]\nwhile {!$done} { update }\n",
        ] {
            assert_undecided(src);
        }
    }

    /// A plain top-level name is the global name, so a call to a command the
    /// module cannot see may end the loop as it may one over `::go`, and so may
    /// such a call over a procedure's local, which an autoloaded or
    /// unknown-handled callee reaches with `upvar 1` (tclsh 8.4 to 9.1 end
    /// `while {$go} {stopper}` where `auto_index(stopper)` defines `stopper`
    /// as `upvar 1 go go; set go 0`). A procedure the module defines writes no
    /// global.
    #[test]
    fn a_call_the_module_cannot_see_keeps_a_loop_silent() {
        assert_undecided("set go 1\nwhile {$go} { foo }\n");
        assert_undecided("set ::go 1\nwhile {$::go} { foo }\n");
        assert_undecided("proc p {} {\n set go 1\n while {$go} { foo }\n}\n");
        // A sourced file runs in the frame of the call, a procedure's too.
        assert_undecided("set go 1\nwhile {$go} { source other.tcl }\n");
        assert_undecided("proc p {} {\n set go 1\n while {$go} { source other.tcl }\n}\n");
        assert_verdicts(
            "proc foo {} { puts hi }\nset go 1\nwhile {$go} { foo }\n",
            &["W241"],
        );
    }

    /// A command the module cannot see inside the body of a `catch` the flow
    /// graph keeps as one statement runs as one outside it does, and a
    /// computed head is a command the module cannot see: either may end the
    /// loop as a write to `::go` does, or to a procedure's local through
    /// `upvar 1`. A procedure the module defines is seen, and a body that
    /// writes another name leaves the verdict.
    #[test]
    fn a_catch_body_or_a_computed_head_the_module_cannot_see_keeps_a_loop_silent() {
        for src in [
            "set go 1\ncatch {foo}\nwhile {$go} {puts x}\n",
            "set go 1\ncatch {foo} msg\nwhile {$go} {puts x}\n",
            "set go 1\ncatch {if {1} {foo}}\nwhile {$go} {puts x}\n",
            "set go 1\ncatch {puts [foo]}\nwhile {$go} {puts x}\n",
            "set go 1\ncatch {source other.tcl}\nwhile {$go} {puts x}\n",
            "set go 1\nif {[catch {foo}]} {puts bad}\nwhile {$go} {puts x}\n",
            "set go 1\nset rc [catch {foo} msg]\nwhile {$go} {puts x}\n",
            "set go 1\nwhile {$go} { if {[catch {foo}]} {puts bad} }\n",
            "set go 1\ncatch { namespace eval :: {set go 0} }\nwhile {$go} {puts x}\n",
            "set go 1\ncatch { if {[gets stdin] eq {q}} { set go 0 } }\nwhile {$go} {puts x}\n",
            "set go 1\n$cmd\nwhile {$go} {puts x}\n",
            "set go 1\nputs [$cmd]\nwhile {$go} {puts x}\n",
            "set go 1\nwhile {$go} { $cmd }\n",
            "proc p {} {\n set go 1\n catch { if {1} { source other.tcl } }\n while {$go} {puts x}\n}\n",
            "proc p {} {\n set go 1\n catch { if {1} { foo } }\n while {$go} {puts x}\n}\n",
            "proc p {} {\n set go 1\n $cmd\n while {$go} {puts x}\n}\n",
            "proc p {} {\n set go 1\n if {[catch {foo}]} {puts bad}\n while {$go} {puts x}\n}\n",
        ] {
            assert_undecided(src);
        }
        for src in [
            "proc foo {} { puts hi }\nset go 1\ncatch { if {1} { foo } }\nwhile {$go} {puts x}\n",
            "set go 1\ncatch { if {[gets stdin] eq {q}} { set other 0 } }\nwhile {$go} {puts x}\n",
        ] {
            assert_verdicts(src, &["W241"]);
        }
    }

    /// A callback the scan cannot read may write the loop's variable, so it
    /// ends no verdict it could have drawn: a script spelled as several words
    /// is read as the one they make, and a word the run time computes, a
    /// substitution of any other command, an expansion and a command the module
    /// cannot see are not. A callback that is only cancelled, or stores a
    /// script that writes another name, leaves the loop alone.
    #[test]
    fn a_callback_the_scan_cannot_read_keeps_w241_silent() {
        for src in [
            "set done 0\nafter 100 set done 1\nwhile {!$done} { update }\n",
            "set done 0\nafter idle set done 1\nwhile {!$done} { update }\n",
            "set done 0\nafter 100 incr done\nwhile {!$done} { update }\n",
            "set done 0\nafter 100 $script\nwhile {!$done} { update }\n",
            "set done 0\nafter 100 finish\nwhile {!$done} { update }\n",
            "set done 0\ninterp alias {} fin {} set done 1\nafter 100 fin\nwhile {!$done} { update }\n",
            "set done 0\nafter 100 {*}[list set done 1]\nwhile {!$done} { update }\n",
            "set done 0\nafter 100 [build]\nwhile {!$done} { update }\n",
            "set done 0\nafter 100 {finish now}\nwhile {!$done} { update }\n",
            "proc p {} {\n set done 0\n after 100 $script\n while {!$done} { update }\n}\n",
        ] {
            assert_undecided(src);
        }
        for src in [
            "set done 0\nafter cancel {set done 1}\nwhile {!$done} { update }\n",
            "set done 0\nafter cancel $id\nwhile {!$done} { update }\n",
            "set done 0\nafter 100 {puts hi}\nwhile {!$done} { update }\n",
            "set done 0\nafter 100 set other 1\nwhile {!$done} { update }\n",
            "proc tick {} { puts hi }\nset done 0\nafter 100 tick\nwhile {!$done} { update }\n",
        ] {
            assert_verdicts(src, &["W241"]);
        }
    }
}

#[cfg(test)]
mod original_body_parser_purpose_tests {
    use super::*;

    #[test]
    fn original_loop_body_and_step_parsers_keep_bom_as_command_content() {
        // naming.source.original-configured-script-completeness
        // docs/design/analysis/name-resolution-proofs/source-original-configured-script-completeness.md
        // Retained conditional schema/body syntax; no executed loop/cell effect proof.
        let mut analyser = crate::analyser::Analyser::new();
        let input = analyser.prepare_analysis_input("tcl9.1").unwrap();
        let metadata = BoundsMetadataContext::Retained(input.borrowed_context_registry());
        assert_eq!(
            body_increment("incr counter", "counter", metadata, input.lexer_config()),
            Some(1)
        );
        assert_eq!(
            body_increment(
                "\u{feff}incr counter",
                "counter",
                metadata,
                input.lexer_config()
            ),
            None
        );
        assert_eq!(
            sole_command("incr counter", input.lexer_config())
                .unwrap()
                .texts[0],
            "incr"
        );
        assert_eq!(
            sole_command("\u{feff}incr counter", input.lexer_config())
                .unwrap()
                .texts[0],
            "\u{feff}incr"
        );
        assert!(sole_command("incr counter; incr counter", input.lexer_config()).is_none());
    }

    #[test]
    fn original_body_walk_keeps_leading_bom_as_command_content_at_each_depth() {
        // naming.source.original-configured-script-completeness
        // docs/design/analysis/name-resolution-proofs/source-original-configured-script-completeness.md
        // Retained available schema plus lexical body topology, no entered loop/exit.
        let context = tcl_registry::model::ingress::static_context_for("tcl9.1");
        let config = tcl_lexer::LexerConfig::for_file_grammar(
            crate::environment_ingress::resolve_environment("tcl9.1").grammar(),
        );
        let metadata = BoundsMetadataContext::Retained(&context);
        assert!(body_may_exit("break", metadata, config));
        assert!(!body_may_exit("\u{feff}break", metadata, config));
        assert!(!body_may_exit("if 1 {\u{feff}break}", metadata, config));
        assert!(body_may_exit("if 1 {break}", metadata, config));
    }
}

#[cfg(test)]
mod original_list_descent_purpose_tests {
    use super::*;

    #[test]
    fn original_list_descent_keeps_file_bom_and_extracted_body_marks_distinct() {
        // naming.source.original-configured-script-completeness
        // docs/design/analysis/name-resolution-proofs/source-original-configured-script-completeness.md
        // This lexical list-length projection grants no getter, store or frame.
        let profile = tcl_dialect::DialectProfile::find("tcl9.0").unwrap();
        let config = tcl_lexer::LexerConfig::for_file_grammar(profile.grammar);
        let context = BoundsMetadataContext::Standalone(None);
        for (source, expected) in [
            ("\u{feff}set xs {a b}; lset xs 9 v", Some(2)),
            ("if 1 {\u{feff}set xs {a b}; lset xs 9 v}", None),
            ("if 1 {set xs {a b}; lset xs 9 v}", Some(2)),
        ] {
            let before = u32::try_from(source.find("lset").unwrap()).unwrap();
            assert_eq!(
                infer_list_length_from_recent_set(source, "xs", before, context, config),
                expected,
                "{source:?}"
            );
        }
        let source = "if 1 {puts ${a{b}; set xs {a b}; lset xs 9 v}}";
        let before = u32::try_from(source.find("lset").unwrap()).unwrap();
        let mut first_close = config;
        first_close.braced_var = tcl_lexer::BracedVarStyle::FirstClose;
        assert_eq!(
            infer_list_length_from_recent_set(source, "xs", before, context, first_close),
            Some(2)
        );
        assert_eq!(
            infer_list_length_from_recent_set(source, "xs", before, context, config),
            None
        );
    }
}
