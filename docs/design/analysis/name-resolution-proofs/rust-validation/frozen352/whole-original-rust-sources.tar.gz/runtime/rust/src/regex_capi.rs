// tcl-lsp — a language server and toolchain for Tcl
// Copyright (C) 2026 James Deucker (bitwisecook) <https://github.com/bitwisecook>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.
//
// SPDX-License-Identifier: AGPL-3.0-or-later

//! C-ABI shim: re-export the pure-Rust [`tcl_regex`] ARE engine under the Tcl
//! regex engine's C symbols, so C Tcl code — `tclRegexp.c`, and any C extension
//! that links the engine — can compile and link against it unchanged. This is
//! the producer side that replaces the C Henry-Spencer engine entirely.
//!
//! The companion header is [`include/tcl_regex_capi.h`](../include/tcl_regex_capi.h).
//! We deliberately *hide the impedance mismatch in the shim* (the user's
//! design rule): the safe-Rust engine works in `&[u32]` codepoints, typed
//! errors, and half-open `Span`s, while C wants a `regex_t` with opaque
//! `re_guts`, a `regmatch_t[]` of `size_t` pairs with `(size_t)-1` sentinels,
//! and integer `REG_*` codes. The conversion lives here.
//!
//! ABI notes
//! - `chr` is a 32-bit codepoint (`CHRBITS == 32`, as the engine has always
//!   used); a C caller includes the shim header, which fixes that convention.
//! - Flag values (`REG_ADVANCED`, `REG_ICASE`, …, `REG_NOTBOL`/`REG_NOTEOL`)
//!   are the `regex.h` values, which `tcl-regex` already shares, so cflags /
//!   eflags pass straight through. `TclReComp` adds the flags the pinned
//!   release's C engine implies (`\z` on 9.1), which no `regex.h` caller sets.
//! - `re_endp` (the `REG_PEND` kludge) and `re_fns` are unused; `re_guts` holds
//!   a `Box<tcl_regex::Regex>`.

use core::cell::Cell;
use core::ffi::{c_char, c_int, c_long, c_void};
use tcl_dialect::TclVersion;
use tcl_regex::{ErrorCode, Regex};

thread_local! {
    // C settles these at build time (9.1.0's `regc_lex.c` accepts `\z`
    // unconditionally); this runtime settles them when the interpreter pins its
    // release, so a C caller passing plain `REG_ADVANCED` gets that release's
    // engine. Empty matches the default 9.0 pin.
    static RELEASE_CFLAGS: Cell<c_int> = const { Cell::new(0) };
}

/// Install the compile flags `version`'s C engine applies implicitly — today
/// only `\z` ([`TclVersion::regex_z_anchor`]).
pub(crate) fn set_runtime_release(version: TclVersion) {
    let bits = if version.regex_z_anchor() {
        tcl_regex::defs::REG_ZANCHOR
    } else {
        0
    };
    RELEASE_CFLAGS.with(|c| c.set(bits));
}

/// 32-bit wide character (codepoint) — the engine's `chr`.
pub type Chr = u32;

const REG_OKAY: c_int = 0;
const REG_NOMATCH: c_int = 1;
const REG_INVARG: c_int = 16;
/// Magic number for a live `regex_t` (`REMAGIC` in `regguts.h`).
const REMAGIC: c_int = 0xFED7;
/// `(size_t)-1` — the engine's "subexpression did not participate" sentinel.
const NO_MATCH: usize = usize::MAX;

/// One reported (sub-)match: half-open in the engine, reported as the C
/// `regmatch_t` (`rm_so`/`rm_eo` are `size_t`).
#[repr(C)]
pub struct RegMatchT {
    pub rm_so: usize,
    pub rm_eo: usize,
}

/// `rm_detail_t` — supplementary reporting (the `REG_EXPECT` extent). Unused by
/// this engine, but kept in the ABI for source compatibility.
#[repr(C)]
pub struct RmDetailT {
    pub rm_extend: RegMatchT,
}

/// The public compiled-RE handle. Layout matches `regex.h`'s `regex_t`; only
/// `re_guts` (a boxed [`Regex`]), `re_nsub`, and `re_info` are meaningful here.
#[repr(C)]
pub struct RegexT {
    pub re_magic: c_int,
    pub re_info: c_long,
    pub re_nsub: usize,
    pub re_endp: *const Chr,
    pub re_guts: *mut c_void,
    pub re_fns: *mut c_void,
}

/// `TclReComp` — compile `pattern` (`len` codepoints) with `flags` into `re`.
/// Returns `REG_OKAY` or a `REG_*` error code.
///
/// # Safety
/// `re` must be a valid, writable `*mut RegexT`; `pattern` must point to `len`
/// readable `Chr`s (or be null with `len == 0`).
#[unsafe(no_mangle)]
pub unsafe extern "C" fn TclReComp(
    re: *mut RegexT,
    pattern: *const Chr,
    len: usize,
    flags: c_int,
) -> c_int {
    if re.is_null() || (pattern.is_null() && len != 0) {
        return REG_INVARG;
    }
    let pat: &[Chr] = if len == 0 {
        &[]
    } else {
        unsafe { core::slice::from_raw_parts(pattern, len) }
    };
    match Regex::compile(pat, flags | RELEASE_CFLAGS.with(Cell::get)) {
        Ok(rx) => {
            let nsub = rx.nsub();
            let info = rx.info().bits();
            let guts = Box::into_raw(Box::new(rx)).cast::<c_void>();
            unsafe {
                (*re).re_magic = REMAGIC;
                (*re).re_info = c_long::from(info);
                (*re).re_nsub = nsub;
                (*re).re_endp = core::ptr::null();
                (*re).re_guts = guts;
                (*re).re_fns = core::ptr::null_mut();
            }
            REG_OKAY
        }
        Err(code) => code.code(),
    }
}

/// `TclReExec` — match `re` against `string` (`len` codepoints), filling up to
/// `nmatch` entries of `pmatch` with `[rm_so, rm_eo)` per group (group 0 is the
/// whole match; non-participating groups get `(size_t)-1`). `flags` carries
/// `REG_NOTBOL`/`REG_NOTEOL`. Returns `REG_OKAY`, `REG_NOMATCH`, or
/// `REG_ESPACE` for a search that exhausted its budget or a recursion limit
/// (never a no-match: it established nothing). `details` is
/// accepted for ABI compatibility and ignored (no `REG_EXPECT` support).
///
/// # Safety
/// `re` must be a `regex_t` previously filled by [`TclReComp`]; `string` must
/// point to `len` readable `Chr`s; `pmatch` must point to `nmatch` writable
/// `RegMatchT`s (or be null with `nmatch == 0`).
#[unsafe(no_mangle)]
pub unsafe extern "C" fn TclReExec(
    re: *mut RegexT,
    string: *const Chr,
    len: usize,
    _details: *mut RmDetailT,
    nmatch: usize,
    pmatch: *mut RegMatchT,
    flags: c_int,
) -> c_int {
    if re.is_null() || (string.is_null() && len != 0) {
        return REG_INVARG;
    }
    let guts = unsafe { (*re).re_guts }.cast::<Regex>();
    if guts.is_null() {
        return REG_INVARG;
    }
    let rx: &Regex = unsafe { &*guts };
    let subject: &[Chr] = if len == 0 {
        &[]
    } else {
        unsafe { core::slice::from_raw_parts(string, len) }
    };
    match rx.exec(subject, 0, flags) {
        tcl_regex::ExecOutcome::Matched(groups) => {
            if !pmatch.is_null() && nmatch != 0 {
                let out = unsafe { core::slice::from_raw_parts_mut(pmatch, nmatch) };
                for (slot, group) in out
                    .iter_mut()
                    .zip(groups.iter().chain(core::iter::repeat(&None)))
                {
                    match group {
                        Some(span) => {
                            slot.rm_so = span.start;
                            slot.rm_eo = span.end;
                        }
                        None => {
                            slot.rm_so = NO_MATCH;
                            slot.rm_eo = NO_MATCH;
                        }
                    }
                }
            }
            REG_OKAY
        }
        tcl_regex::ExecOutcome::NoMatch => REG_NOMATCH,
        // A search the engine could not finish proves neither a match nor
        // its absence: it is the regex API's resource failure, never
        // `REG_NOMATCH`.
        tcl_regex::ExecOutcome::Stopped(_) => ErrorCode::Espace.code(),
    }
}

/// `TclReFree` — release the engine state held in `re->re_guts`.
///
/// # Safety
/// `re` must be null or a `regex_t` filled by [`TclReComp`] and not yet freed.
#[unsafe(no_mangle)]
pub unsafe extern "C" fn TclReFree(re: *mut RegexT) {
    if re.is_null() {
        return;
    }
    let guts = unsafe { (*re).re_guts };
    if !guts.is_null() {
        drop(unsafe { Box::from_raw(guts.cast::<Regex>()) });
        unsafe {
            (*re).re_guts = core::ptr::null_mut();
            (*re).re_magic = 0;
        }
    }
}

/// `TclReError` — write the message for `code` into `errbuf` (NUL-terminated,
/// truncated to `errbuf_size`). Returns the full message length plus one (the
/// buffer size that would hold it), per the `regerror` convention.
///
/// # Safety
/// `errbuf` must point to `errbuf_size` writable bytes (or be null with
/// `errbuf_size == 0`).
#[unsafe(no_mangle)]
pub unsafe extern "C" fn TclReError(code: c_int, errbuf: *mut c_char, errbuf_size: usize) -> usize {
    let msg = ErrorCode::from_code(code).map_or("unknown regex error code", ErrorCode::message);
    let bytes = msg.as_bytes();
    if !errbuf.is_null() && errbuf_size != 0 {
        let n = bytes.len().min(errbuf_size - 1);
        unsafe {
            core::ptr::copy_nonoverlapping(bytes.as_ptr(), errbuf.cast::<u8>(), n);
            *errbuf.add(n) = 0;
        }
    }
    bytes.len() + 1
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Drive the C ABI exactly as a C caller would (compile → exec → free) and
    /// check the reported groups, sentinels, and error path.
    #[test]
    fn capi_roundtrip() {
        // `(\w+)@(\w+)` over "user@host" → whole + two groups.
        let pat: Vec<Chr> = r"(\w+)@(\w+)".chars().map(|c| c as u32).collect();
        let mut re = RegexT {
            re_magic: 0,
            re_info: 0,
            re_nsub: 0,
            re_endp: core::ptr::null(),
            re_guts: core::ptr::null_mut(),
            re_fns: core::ptr::null_mut(),
        };
        let rc = unsafe {
            TclReComp(
                &mut re,
                pat.as_ptr(),
                pat.len(),
                tcl_regex::defs::REG_ADVANCED,
            )
        };
        assert_eq!(rc, REG_OKAY);
        assert_eq!(re.re_nsub, 2);

        let subj: Vec<Chr> = "user@host".chars().map(|c| c as u32).collect();
        let mut m = [
            RegMatchT { rm_so: 0, rm_eo: 0 },
            RegMatchT { rm_so: 0, rm_eo: 0 },
            RegMatchT { rm_so: 0, rm_eo: 0 },
        ];
        let rc = unsafe {
            TclReExec(
                &mut re,
                subj.as_ptr(),
                subj.len(),
                core::ptr::null_mut(),
                m.len(),
                m.as_mut_ptr(),
                0,
            )
        };
        assert_eq!(rc, REG_OKAY);
        assert_eq!((m[0].rm_so, m[0].rm_eo), (0, 9)); // "user@host"
        assert_eq!((m[1].rm_so, m[1].rm_eo), (0, 4)); // "user"
        assert_eq!((m[2].rm_so, m[2].rm_eo), (5, 9)); // "host"

        // No match.
        let none: Vec<Chr> = "nope".chars().map(|c| c as u32).collect();
        let rc = unsafe {
            TclReExec(
                &mut re,
                none.as_ptr(),
                none.len(),
                core::ptr::null_mut(),
                0,
                core::ptr::null_mut(),
                0,
            )
        };
        assert_eq!(rc, REG_NOMATCH);

        unsafe { TclReFree(&mut re) };
        assert!(re.re_guts.is_null());

        // A compile error surfaces as a REG_* code with a readable message.
        let bad: Vec<Chr> = "a(".chars().map(|c| c as u32).collect();
        let rc = unsafe {
            TclReComp(
                &mut re,
                bad.as_ptr(),
                bad.len(),
                tcl_regex::defs::REG_ADVANCED,
            )
        };
        assert_ne!(rc, REG_OKAY);
        let mut buf = [0i8; 64];
        let need = unsafe { TclReError(rc, buf.as_mut_ptr(), buf.len()) };
        assert!(need > 1);
    }

    fn compiles(pattern: &str) -> bool {
        let pat: Vec<Chr> = pattern.chars().map(|c| c as u32).collect();
        let mut re = RegexT {
            re_magic: 0,
            re_info: 0,
            re_nsub: 0,
            re_endp: core::ptr::null(),
            re_guts: core::ptr::null_mut(),
            re_fns: core::ptr::null_mut(),
        };
        let rc = unsafe {
            TclReComp(
                &mut re,
                pat.as_ptr(),
                pat.len(),
                tcl_regex::defs::REG_ADVANCED,
            )
        };
        if rc == REG_OKAY {
            unsafe { TclReFree(&mut re) };
        }
        rc == REG_OKAY
    }

    /// A C caller passes plain `REG_ADVANCED`, so `\z` follows the pinned
    /// release as it would in that release's `regc_lex.c`: accepted on 9.1.0,
    /// an invalid escape on 9.0.4.
    #[test]
    fn z_anchor_follows_the_pinned_release() {
        assert!(!compiles(r"a\z"), "the default 9.0 pin rejects \\z");
        set_runtime_release(TclVersion::V9_1);
        assert!(compiles(r"a\z"));
        set_runtime_release(TclVersion::V9_0);
        assert!(!compiles(r"a\z"));
        assert!(compiles(r"a\Z"));
    }
}
