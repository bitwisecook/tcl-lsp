// tcl-lsp — a language server and toolchain for Tcl
// Copyright (C) 2026 James Deucker (bitwisecook) <https://github.com/bitwisecook>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.
//
// SPDX-License-Identifier: AGPL-3.0-or-later

//! `info` — interpreter introspection (toward running tcltest; used ~110× in
//! the library). C ref `tclCmdIL.c` (`Tcl_InfoObjCmd`).
//!
//! Reads **live** runtime state (the T-INFO contract: never compile-time-folded).
//! The implemented subset covers what the library leans on: `exists`,
//! `commands`/`procs`/`vars`/`globals`/`locals` (glob-filtered), `level`
//! (current depth + `level N`), `frame` (the source-location stack, PC-5),
//! `script`, `tclversion`/`patchlevel`, `nameofexecutable`, and proc
//! introspection `body`/`args`/`default`. `info errorstack` (TIP 348) is the
//! remaining `CmdFrame`-adjacent item.

use crate::interp::native_arguments::OriginalArguments;
use crate::interp::{new_string, Code, Interp};
use crate::obj::TclObj;
use tcl_syntax::value::ValueOps;

mod native_jim;
#[cfg(test)]
mod native_jim_inventory_tests;
/// Register `info`.
mod native_oo;
#[cfg(test)]
mod original_argument_tests;

pub fn install(interp: &mut Interp) {
    const NAMES: &[&[u8]] = &[
        b"args".as_slice(),
        b"body".as_slice(),
        b"class".as_slice(),
        b"cmdcount".as_slice(),
        b"cmdtype".as_slice(),
        b"commands".as_slice(),
        b"complete".as_slice(),
        b"constant".as_slice(),
        b"consts".as_slice(),
        b"coroutine".as_slice(),
        b"default".as_slice(),
        b"errorstack".as_slice(),
        b"exists".as_slice(),
        b"frame".as_slice(),
        b"functions".as_slice(),
        b"globals".as_slice(),
        b"hostname".as_slice(),
        b"level".as_slice(),
        b"library".as_slice(),
        b"loaded".as_slice(),
        b"locals".as_slice(),
        b"nameofexecutable".as_slice(),
        b"object".as_slice(),
        b"patchlevel".as_slice(),
        b"procs".as_slice(),
        b"script".as_slice(),
        b"sharedlibextension".as_slice(),
        b"tclversion".as_slice(),
        b"vars".as_slice(),
        b"version".as_slice(),
    ];
    let admitted = crate::environment::release_subcommands(
        interp.native_ensemble_profile_name(),
        "info",
        NAMES,
    );
    interp.register_stock_ensemble(
        tcl_registry::invocation_words::EnsembleImplementationFamily::Info,
        b"info",
        info_cmd,
        STOCK_MEMBERS,
        admitted,
    );
    native_oo::install(interp);
}

const STOCK_MEMBERS: &[(&[u8], crate::interp::BuiltinFn)] = &[
    (b"args", stock_args),
    (b"body", stock_body),
    (b"class", stock_class),
    (b"cmdcount", stock_cmdcount),
    (b"cmdtype", stock_cmdtype),
    (b"commands", stock_commands),
    (b"complete", stock_complete),
    (b"constant", stock_constant),
    (b"consts", stock_consts),
    (b"coroutine", stock_coroutine),
    (b"default", stock_default),
    (b"errorstack", stock_errorstack),
    (b"exists", stock_exists),
    (b"frame", stock_frame),
    (b"functions", stock_functions),
    (b"globals", stock_globals),
    (b"hostname", stock_hostname),
    (b"level", stock_level),
    (b"library", stock_library),
    (b"loaded", stock_loaded),
    (b"locals", stock_locals),
    (b"nameofexecutable", stock_nameofexecutable),
    (b"object", stock_object),
    (b"patchlevel", stock_patchlevel),
    (b"procs", stock_procs),
    (b"script", stock_script),
    (b"sharedlibextension", stock_sharedlibextension),
    (b"tclversion", stock_tclversion),
    (b"vars", stock_vars),
    (b"version", stock_version),
];

fn stock_args(interp: &mut Interp, argv: &[*mut TclObj]) -> Code {
    interp.invoke_stock_worker(argv, &[b"info", b"args"], info_cmd)
}

fn stock_body(interp: &mut Interp, argv: &[*mut TclObj]) -> Code {
    interp.invoke_stock_worker(argv, &[b"info", b"body"], info_cmd)
}

fn stock_class(interp: &mut Interp, argv: &[*mut TclObj]) -> Code {
    interp.invoke_stock_worker(argv, &[b"info", b"class"], info_cmd)
}

fn stock_cmdcount(interp: &mut Interp, argv: &[*mut TclObj]) -> Code {
    interp.invoke_stock_worker(argv, &[b"info", b"cmdcount"], info_cmd)
}

fn stock_cmdtype(interp: &mut Interp, argv: &[*mut TclObj]) -> Code {
    interp.invoke_stock_worker(argv, &[b"info", b"cmdtype"], info_cmd)
}

fn stock_commands(interp: &mut Interp, argv: &[*mut TclObj]) -> Code {
    interp.invoke_stock_worker(argv, &[b"info", b"commands"], info_cmd)
}

fn stock_complete(interp: &mut Interp, argv: &[*mut TclObj]) -> Code {
    interp.invoke_stock_worker(argv, &[b"info", b"complete"], info_cmd)
}

fn stock_constant(interp: &mut Interp, argv: &[*mut TclObj]) -> Code {
    interp.invoke_stock_worker(argv, &[b"info", b"constant"], info_cmd)
}

fn stock_consts(interp: &mut Interp, argv: &[*mut TclObj]) -> Code {
    interp.invoke_stock_worker(argv, &[b"info", b"consts"], info_cmd)
}

fn stock_coroutine(interp: &mut Interp, argv: &[*mut TclObj]) -> Code {
    interp.invoke_stock_worker(argv, &[b"info", b"coroutine"], info_cmd)
}

fn stock_default(interp: &mut Interp, argv: &[*mut TclObj]) -> Code {
    interp.invoke_stock_worker(argv, &[b"info", b"default"], info_cmd)
}

fn stock_errorstack(interp: &mut Interp, argv: &[*mut TclObj]) -> Code {
    interp.invoke_stock_worker(argv, &[b"info", b"errorstack"], info_cmd)
}

fn stock_exists(interp: &mut Interp, argv: &[*mut TclObj]) -> Code {
    interp.invoke_stock_worker(argv, &[b"info", b"exists"], info_cmd)
}

fn stock_frame(interp: &mut Interp, argv: &[*mut TclObj]) -> Code {
    interp.invoke_stock_worker(argv, &[b"info", b"frame"], info_cmd)
}

fn stock_functions(interp: &mut Interp, argv: &[*mut TclObj]) -> Code {
    interp.invoke_stock_worker(argv, &[b"info", b"functions"], info_cmd)
}

fn stock_globals(interp: &mut Interp, argv: &[*mut TclObj]) -> Code {
    interp.invoke_stock_worker(argv, &[b"info", b"globals"], info_cmd)
}

fn stock_hostname(interp: &mut Interp, argv: &[*mut TclObj]) -> Code {
    interp.invoke_stock_worker(argv, &[b"info", b"hostname"], info_cmd)
}

fn stock_level(interp: &mut Interp, argv: &[*mut TclObj]) -> Code {
    interp.invoke_stock_worker(argv, &[b"info", b"level"], info_cmd)
}

fn stock_library(interp: &mut Interp, argv: &[*mut TclObj]) -> Code {
    interp.invoke_stock_worker(argv, &[b"info", b"library"], info_cmd)
}

fn stock_loaded(interp: &mut Interp, argv: &[*mut TclObj]) -> Code {
    interp.invoke_stock_worker(argv, &[b"info", b"loaded"], info_cmd)
}

fn stock_locals(interp: &mut Interp, argv: &[*mut TclObj]) -> Code {
    interp.invoke_stock_worker(argv, &[b"info", b"locals"], info_cmd)
}

fn stock_nameofexecutable(interp: &mut Interp, argv: &[*mut TclObj]) -> Code {
    interp.invoke_stock_worker(argv, &[b"info", b"nameofexecutable"], info_cmd)
}

fn stock_object(interp: &mut Interp, argv: &[*mut TclObj]) -> Code {
    interp.invoke_stock_worker(argv, &[b"info", b"object"], info_cmd)
}

fn stock_patchlevel(interp: &mut Interp, argv: &[*mut TclObj]) -> Code {
    interp.invoke_stock_worker(argv, &[b"info", b"patchlevel"], info_cmd)
}

fn stock_procs(interp: &mut Interp, argv: &[*mut TclObj]) -> Code {
    interp.invoke_stock_worker(argv, &[b"info", b"procs"], info_cmd)
}

fn stock_script(interp: &mut Interp, argv: &[*mut TclObj]) -> Code {
    interp.invoke_stock_worker(argv, &[b"info", b"script"], info_cmd)
}

fn stock_sharedlibextension(interp: &mut Interp, argv: &[*mut TclObj]) -> Code {
    interp.invoke_stock_worker(argv, &[b"info", b"sharedlibextension"], info_cmd)
}

fn stock_version(interp: &mut Interp, argv: &[*mut TclObj]) -> Code {
    interp.invoke_stock_worker(argv, &[b"info", b"version"], info_cmd)
}

fn stock_tclversion(interp: &mut Interp, argv: &[*mut TclObj]) -> Code {
    interp.invoke_stock_worker(argv, &[b"info", b"tclversion"], info_cmd)
}

fn stock_vars(interp: &mut Interp, argv: &[*mut TclObj]) -> Code {
    interp.invoke_stock_worker(argv, &[b"info", b"vars"], info_cmd)
}

fn info_cmd(interp: &mut Interp, argv: &[*mut TclObj]) -> Code {
    let arguments = match OriginalArguments::enter(interp, argv) {
        Ok(arguments) => arguments,
        Err(error) => return interp.report_cmd_error(error),
    };
    let code = info_cmd_original(interp, argv, &arguments);
    arguments.finish(code)
}

fn info_name(
    interp: &mut Interp,
    arguments: &OriginalArguments,
    index: usize,
) -> Result<std::rc::Rc<[u8]>, Code> {
    arguments
        .bytes(index)
        .map_err(|error| interp.report_cmd_error(error))
}

fn info_cmd_original(
    interp: &mut Interp,
    argv: &[*mut TclObj],
    arguments: &OriginalArguments,
) -> Code {
    // `info` is an ensemble: resolve an exact name, else an unambiguous prefix
    // (so `info command` → `commands`, matching tclsh).
    const SUBS: &[&[u8]] = &[
        b"args",
        b"body",
        b"class",
        b"cmdcount",
        b"cmdtype",
        b"commands",
        b"complete",
        b"constant",
        b"consts",
        b"coroutine",
        b"default",
        b"errorstack",
        b"exists",
        b"frame",
        b"functions",
        b"globals",
        b"hostname",
        b"level",
        b"library",
        b"loaded",
        b"locals",
        b"nameofexecutable",
        b"object",
        b"patchlevel",
        b"procs",
        b"script",
        b"stacktrace",
        b"sharedlibextension",
        b"tclversion",
        b"vars",
        b"version",
    ];
    let subs = crate::environment::release_subcommands(
        interp.native_ensemble_profile_name(),
        "info",
        SUBS,
    );
    let mut prepared = Vec::new();
    let sub = if let Some(protocol) = interp
        .native_invocation_dialect()
        .native_jim_info_protocol()
    {
        let dispatch = match protocol.dispatch(argv.len(), |index| arguments.bytes(index)) {
            Ok(dispatch) => dispatch,
            Err(error) => return interp.report_cmd_error(error),
        };
        match dispatch {
            tcl_registry::commands::tcl::NativeJimInfoDispatch::Member {
                name,
                head,
                arguments,
                scope,
            } => {
                if let Some(kind) = protocol.command_inventory_kind(name) {
                    return native_jim::command_inventory(
                        interp,
                        scope,
                        &argv[arguments - 1..],
                        kind,
                    );
                }
                prepared.push(argv[head]);
                prepared.push(argv[arguments - 1]);
                prepared.extend_from_slice(&argv[arguments..]);
                name.as_bytes()
            }
            tcl_registry::commands::tcl::NativeJimInfoDispatch::Report(report) => {
                return native_jim::report(interp, protocol, report, argv);
            }
        }
    } else {
        if argv.len() < 2 {
            let usage = interp
                .native_invocation_dialect()
                .native_info_original_missing_selector_usage()
                .unwrap_or(b"subcommand ?arg ...?");
            return interp.wrong_args_for_invocation(argv, usage);
        }
        let index = if interp
            .native_invocation_dialect()
            .native_info_original_option_protocol()
            .is_some()
        {
            let table =
                tcl_registry::native_index_lookup::NativeStaticIndexTable::supported_backend_bytes(
                    subs,
                );
            let selected = interp.native_index_operand(argv[1], &table, false, "option");
            if let Err(error) = arguments.check() {
                return interp.report_cmd_error(error);
            }
            match selected {
                Ok(index) => index,
                Err(error) => return interp.report_cmd_error(error),
            }
        } else {
            let raw = match info_name(interp, arguments, 1) {
                Ok(raw) => raw,
                Err(code) => return code,
            };
            let Some(index) = tcl_cmd_core::ensemble::resolve_subcommand(subs, &raw, true) else {
                return interp.set_error(&tcl_cmd_core::ensemble::unknown_subcommand_message(
                    subs,
                    &raw,
                    true,
                    b"::tcl::info",
                ));
            };
            index
        };
        subs[index]
    };
    let argv = if prepared.is_empty() { argv } else { &prepared };
    let prepared_arguments = if prepared.is_empty() {
        None
    } else {
        match OriginalArguments::enter(interp, argv) {
            Ok(arguments) => Some(arguments),
            Err(error) => return interp.report_cmd_error(error),
        }
    };
    // Jim's actual -nons shift retains the same headers. Operand positions now
    // belong to that selected vector, while the original entry remains live.
    let arguments = prepared_arguments.as_ref().unwrap_or(arguments);
    match sub {
        b"alias" => match tcl_cmd_core::info::jim_original_alias(interp, &argv[2]) {
            Ok(original) => {
                interp.set_result(original);
                Code::Ok
            }
            Err(error) => interp.report_cmd_error(error),
        },
        b"exists" => info_exists(interp, argv),
        // commands/procs route through the shared namespace-aware core (over the
        // `Namespaces` enumeration rungs). This also fixed a real bug: `info procs`
        // in a namespace wrongly merged the global procs (the old
        // `visible_proc_names`); C's `InfoProcsCmd` lists the current namespace
        // only, while `info commands` does merge global.
        b"commands" => info_command_list(interp, argv, b"info commands ?pattern?", false),
        b"procs" => info_command_list(interp, argv, b"info procs ?pattern?", true),
        // vars/locals/globals route through the shared variable-listing cores
        // (namespace-aware over `Namespaces::vars_in` + the active-frame
        // `Frames::var_names`/`in_proc`); `globals` owns the Bug 1057461 leading-
        // `::` strip in the core.
        b"vars" => info_var_list(interp, argv, b"info vars ?pattern?", VarList::Vars),
        b"globals" => info_var_list(interp, argv, b"info globals ?pattern?", VarList::Globals),
        b"locals" => info_var_list(interp, argv, b"info locals ?pattern?", VarList::Locals),
        b"level" => info_level(interp, argv),
        b"frame" => info_frame(interp, argv),
        b"coroutine" => {
            if argv.len() != 2 {
                return interp.wrong_args_for_prefix(argv, 2, b"");
            }
            interp.set_result_bytes(&crate::cmd_coro::current_coroutine());
            Code::Ok
        }
        b"object" => crate::cmd_oo::info_object(interp, argv),
        b"class" => crate::cmd_oo::info_class(interp, argv),
        // `info tclversion`/`patchlevel` *read* the globals (C reads
        // `tcl_version`/`tcl_patchLevel`), so unsetting them makes these error.
        b"tclversion" | b"patchlevel" | b"version" => info_version_report(interp, argv, sub),
        // The host shared-library suffix (`$::tcl_platform(platform)` is unix).
        b"sharedlibextension" => fixed(
            interp,
            argv,
            b"info sharedlibextension",
            tcl_platform::bootstrap::SHARED_LIBRARY_EXTENSION.as_bytes(),
        ),
        b"complete" => {
            if argv.len() != 3 {
                return interp.wrong_args_for_prefix(argv, 2, b"command");
            }
            let config = interp
                .lexer_config()
                .with_grammar(interp.native_invocation_dialect().lexer_grammar);
            match tcl_cmd_core::info::complete_value(interp, &argv[2], config) {
                Ok(value) => {
                    interp.set_result(value);
                    Code::Ok
                }
                Err(error) => interp.report_cmd_error(error),
            }
        }
        b"body" => info_body(interp, argv),
        b"args" => info_args(interp, argv),
        b"default" => info_default(interp, argv),
        b"cmdtype" => info_cmdtype(interp, argv),
        b"cmdcount" => {
            if argv.len() != 2 {
                return interp.wrong_args_for_prefix(argv, 2, b"");
            }
            interp.set_result(crate::obj::new_wide_int_obj(interp.cmd_count() as i64));
            Code::Ok
        }
        b"functions" => {
            if argv.len() > 3 {
                return interp.wrong_args_for_prefix(argv, 2, b"?pattern?");
            }
            info_functions(interp, argv.get(2).copied())
        }
        b"loaded" => {
            if argv.len() > 4 {
                return interp.wrong_args_for_prefix(argv, 2, b"?interp? ?prefix?");
            }
            if let Some(&original) = argv.get(2) {
                let path = match crate::cmd_alias::interp_path(interp, original) {
                    Ok(path) => path,
                    Err(code) => return code,
                };
                if interp.with_child_path(&path, |_| ()).is_none() {
                    return crate::cmd_alias::not_found_original_path(interp, original);
                }
            }
            interp.set_result_bytes(b"");
            Code::Ok
        }
        b"script" => {
            if interp.native_invocation_dialect().native_string_protocol()
                == Some(tcl_syntax::native_string::NativeStringProtocol::Jim084)
            {
                if argv.len() > 3 {
                    return interp.wrong_args_for_prefix(argv, 2, b"?filename?");
                }
                let context = match interp.native_jim_object_context() {
                    Ok(context) => context,
                    Err(error) => return interp.report_cmd_error(error.into()),
                };
                if let Some(&filename) = argv.get(2) {
                    let result = context.replace_current_filename(filename);
                    if let Err(error) = arguments.check() {
                        return interp.report_cmd_error(error);
                    }
                    if let Err(error) = result {
                        return interp.report_cmd_error(error.into());
                    }
                }
                let filename = context.current_filename_object();
                interp.set_result(filename.as_ptr());
                return Code::Ok;
            }
            if argv.len() > 3 {
                return interp.wrong_args_for_prefix(argv, 2, b"?filename?");
            }
            if argv.len() == 3 {
                // Set the current script name and return it (C's `info script F`).
                let name = match info_name(interp, arguments, 2) {
                    Ok(name) => name,
                    Err(code) => return code,
                };
                interp.set_current_script(&name);
                interp.set_result_bytes(&name);
            } else {
                interp.set_result_bytes(&interp.current_script());
            }
            Code::Ok
        }
        b"nameofexecutable" => {
            if argv.len() != 2 {
                return interp.wrong_args_for_prefix(argv, 2, b"");
            }
            let host = interp.host();
            let environment = host.env();
            if let Err(error) = arguments.check() {
                return interp.report_cmd_error(error);
            }
            let reached = environment.current_exe();
            if let Err(error) = arguments.check() {
                return interp.report_cmd_error(error);
            }
            let exe = reached.unwrap_or_default();
            interp.set_result_bytes(exe.as_bytes());
            Code::Ok
        }
        b"library" => {
            if argv.len() != 2 {
                return interp.wrong_args_for_prefix(argv, 2, b"");
            }
            match interp.var_get(b"::tcl_library") {
                Some(o) => {
                    interp.set_result(o);
                    Code::Ok
                }
                None => interp.set_error(b"no library has been specified for Tcl"),
            }
        }
        b"hostname" => {
            if argv.len() != 2 {
                return interp.wrong_args_for_prefix(argv, 2, b"");
            }
            let h = match hostname(interp, arguments) {
                Ok(value) => value,
                Err(error) => return interp.report_cmd_error(error),
            };
            interp.set_result_bytes(&h);
            Code::Ok
        }
        b"stacktrace" => {
            if argv.len() != 2 {
                return interp.wrong_args_for_prefix(argv, 2, b"");
            }
            let trace = match interp.jim_stacktrace() {
                Ok(trace) => trace,
                Err(first) => return interp.refuse_native_execution(first),
            };
            interp.set_result_bytes(&trace);
            Code::Ok
        }
        b"errorstack" => {
            // TIP 348: the error stack of the last error (`?interp?` accepted but
            // only the current interp is supported).
            if argv.len() > 3 {
                return interp.wrong_args_for_prefix(argv, 2, b"?interp?");
            }
            let scope =
                match crate::interp::native_operation_currency::NativeOperationScope::enter(interp)
                {
                    Ok(scope) => scope,
                    Err(first) => return interp.refuse_native_execution(first),
                };
            let es = match interp.original_error_stack_value_checked(scope.currency()) {
                Ok(value) => value,
                Err(first) => return interp.refuse_native_execution(first),
            };
            interp.set_result(es.as_ptr());
            drop(es);
            if let Err(first) = scope.currency().ensure_current_or_refuse() {
                return interp.refuse_native_execution(first);
            }
            Code::Ok
        }
        b"constant" => {
            // TIP 677: whether `varName` resolves to a `const` scalar.
            if argv.len() != 3 {
                return interp.wrong_args_for_prefix(argv, 2, b"varName");
            }
            let name = match info_name(interp, arguments, 2) {
                Ok(name) => name,
                Err(code) => return code,
            };
            let is_const = interp.is_constant(&name);
            interp.set_result_bytes(if is_const { b"1" } else { b"0" });
            Code::Ok
        }
        b"consts" => info_consts(interp, argv),
        _ if interp
            .native_invocation_dialect()
            .native_jim_info_member_names()
            .is_some() =>
        {
            interp.report_cmd_error(
                tcl_syntax::value::ValueError::CommandProtocolUnavailable(
                    "selected Jim info handler",
                )
                .into(),
            )
        }
        other => interp.set_error(&tcl_cmd_core::ensemble::unknown_subcommand_message(
            SUBS,
            other,
            true,
            b"::tcl::info",
        )),
    }
}

/// The host name (`info hostname`, `Tcl_GetHostName`) — best-effort from
/// `/proc/sys/kernel/hostname`, else `/etc/hostname`, else empty. Read through
/// the host filesystem (empty when the host provides none).
fn hostname(
    interp: &Interp,
    arguments: &OriginalArguments,
) -> Result<Vec<u8>, tcl_cmd_core::CmdError> {
    let host = interp.host();
    let filesystem = host.filesystem();
    arguments.check()?;
    for path in ["/proc/sys/kernel/hostname", "/etc/hostname"] {
        let reached = filesystem.map(|filesystem| filesystem.read(path));
        arguments.check()?;
        if let Some(Ok(bytes)) = reached {
            // Host catalogue presentation preserves the existing lossy/trim policy.
            return Ok(String::from_utf8_lossy(&bytes).trim().as_bytes().to_vec());
        }
    }
    Ok(Vec::new())
}

/// `info cmdtype command` — the kind of command (`native`/`proc`/`alias`/…).
fn info_cmdtype(interp: &mut Interp, argv: &[*mut TclObj]) -> Code {
    let arguments = match OriginalArguments::enter(interp, argv) {
        Ok(arguments) => arguments,
        Err(error) => return interp.report_cmd_error(error),
    };
    let code = info_cmdtype_original(interp, argv, &arguments);
    arguments.finish(code)
}

fn info_cmdtype_original(
    interp: &mut Interp,
    argv: &[*mut TclObj],
    arguments: &OriginalArguments,
) -> Code {
    if argv.len() != 3 {
        return interp.wrong_args_for_prefix(argv, 2, b"commandName");
    }
    let name = match info_name(interp, arguments, 2) {
        Ok(value) => value,
        Err(code) => return code,
    };
    match interp.cmdtype(&name) {
        Some(t) => {
            interp.set_result_bytes(t);
            Code::Ok
        }
        None => {
            let mut m = b"unknown command \"".to_vec();
            m.extend_from_slice(&name);
            m.push(b'"');
            interp.set_error(&m)
        }
    }
}

/// Set the result to a Tcl list of `names` filtered by an optional glob pattern.
fn info_functions(interp: &mut Interp, original_pattern: Option<*mut TclObj>) -> Code {
    let Some(recipe) = tcl_registry::mathfunc::NativeInfoFunctionsRecipe::select(
        interp.native_invocation_dialect(),
    ) else {
        return interp.report_cmd_error(
            tcl_syntax::value::ValueError::CommandProtocolUnavailable(
                "selected math function information recipe",
            )
            .into(),
        );
    };
    let pattern = match original_pattern
        .map(|word| interp.native_string_bytes(&word))
        .transpose()
    {
        Ok(pattern) => pattern,
        Err(error) => return interp.report_cmd_error(error.into()),
    };
    if let Some(bytes) = recipe.script(pattern.as_deref()) {
        let script = crate::obj::Owned::fresh(new_string(&bytes));
        return interp.eval_generic_control_body(script.as_ptr());
    }
    let mut selected = Vec::new();
    for name in interp.mathfunc_names() {
        if let Some(pattern) = &pattern {
            let Some(policy) = interp.name_policy_protocol() else {
                return interp.report_cmd_error(
                    tcl_syntax::value::ValueError::CommandProtocolUnavailable(
                        "fixed math function pattern policy",
                    )
                    .into(),
                );
            };
            match tcl_syntax::native_glob::NativeGlobProtocol::from_name_policy(policy)
                .match_name_pattern(
                    tcl_syntax::native_glob::NativeNameGlobPurpose::InfoFunctions84Scan,
                    pattern,
                    &name,
                ) {
                Ok(true) => {}
                Ok(false) => continue,
                Err(error) => {
                    return interp.report_cmd_error(tcl_cmd_core::CmdError::new(error.to_string()));
                }
            }
        }
        selected.push(new_string(&name));
    }
    let list = interp.new_list_object(&selected);
    interp.set_result(list);
    Code::Ok
}

/// `info commands ?pattern?` / `info procs ?pattern?` — the shared
/// namespace-aware command/proc listing core (over the `Namespaces` enumeration
/// rungs); `procs_only` selects `procs`. The qualified-pattern split,
/// re-qualification, glob filter, and the global-merge asymmetry all live in the
/// core.
fn info_command_list(
    interp: &mut Interp,
    argv: &[*mut TclObj],
    usage: &[u8],
    procs_only: bool,
) -> Code {
    if argv.len() > 3 {
        return interp.wrong_args_for_prefix(
            argv,
            2,
            usage.splitn(3, |byte| *byte == b' ').nth(2).unwrap_or(b""),
        );
    }
    match tcl_cmd_core::info::command_list(interp, argv.get(2), procs_only) {
        Ok(result) => {
            interp.set_result(result);
            Code::Ok
        }
        Err(error) => interp.report_cmd_error(error),
    }
}

/// Which variable-listing core `info_var_list` dispatches to.
enum VarList {
    /// `info vars` — current context (frame locals in a proc, else namespace vars).
    Vars,
    /// `info locals` — the current proc frame's genuine locals.
    Locals,
    /// `info globals` — the global namespace's variables.
    Globals,
}

/// `info vars`/`locals`/`globals` — the shared variable-listing cores (over
/// `Namespaces::vars_in` + the active-frame `Frames` rungs). The whole
/// context/namespace/link logic lives in the core; this adapter only checks
/// arity and maps the result.
fn info_var_list(interp: &mut Interp, argv: &[*mut TclObj], usage: &[u8], which: VarList) -> Code {
    if argv.len() > 3 {
        return interp.wrong_args_for_prefix(
            argv,
            2,
            usage.splitn(3, |byte| *byte == b' ').nth(2).unwrap_or(b""),
        );
    }
    let pattern = argv.get(2);
    let result = match which {
        VarList::Vars => tcl_cmd_core::info::vars(interp, pattern),
        VarList::Locals => tcl_cmd_core::info::locals(interp, pattern),
        VarList::Globals => tcl_cmd_core::info::globals(interp, pattern),
    };
    match result {
        Ok(result) => {
            interp.set_result(result);
            Code::Ok
        }
        Err(error) => interp.report_cmd_error(error),
    }
}

fn info_consts(interp: &mut Interp, argv: &[*mut TclObj]) -> Code {
    if argv.len() > 3 {
        return interp.wrong_args_for_prefix(argv, 2, b"?pattern?");
    }
    match tcl_cmd_core::info::consts(interp, argv.get(2)) {
        Ok(result) => {
            interp.set_result(result);
            Code::Ok
        }
        Err(error) => interp.report_cmd_error(error),
    }
}

fn info_exists(interp: &mut Interp, argv: &[*mut TclObj]) -> Code {
    let arguments = match OriginalArguments::enter(interp, argv) {
        Ok(arguments) => arguments,
        Err(error) => return interp.report_cmd_error(error),
    };
    let code = info_exists_original(interp, argv, &arguments);
    arguments.finish(code)
}

fn info_exists_original(
    interp: &mut Interp,
    argv: &[*mut TclObj],
    arguments: &OriginalArguments,
) -> Code {
    if argv.len() != 3 {
        return interp.wrong_args_for_prefix(argv, 2, b"varName");
    }
    if interp.native_c_variable_name_protocol().is_some() {
        let reached = interp.exists_original_c_parts(argv[2], None);
        if let Err(error) = arguments.check() {
            return interp.report_cmd_error(error);
        }
        return match reached {
            Ok(found) => {
                let result = crate::obj::new_boolean_obj(i32::from(found));
                interp.set_result(result);
                Code::Ok
            }
            Err(code) => code,
        };
    }
    // Tcl's existence query fires read traces and ignores their errors. The
    // resolved variable owner includes native linked-variable callbacks.
    let name = match info_name(interp, arguments, 2) {
        Ok(value) => value,
        Err(code) => return code,
    };
    if interp.observed_name_policy_selected() {
        let level = interp.frames.borrow().current_level();
        let reached = interp.observed_variable_exists(&name, level);
        if let Err(error) = arguments.check() {
            return interp.report_cmd_error(error);
        }
        return match reached {
            Ok(found) => {
                let result = crate::obj::new_boolean_obj(i32::from(found));
                interp.set_result(result);
                Code::Ok
            }
            Err(_) => Code::Error,
        };
    }
    // Guest read-trace errors remain ignored by the existence query; an
    // original Host refusal stops the later table read and result publication.
    let reached_trace = match interp.fire_var_traces_for(&name, b"read") {
        Ok(value) => value,
        Err(first) => return interp.refuse_native_execution(first),
    };
    if let Err(error) = arguments.check() {
        return interp.report_cmd_error(error);
    }
    drop(reached_trace);
    // The shared Family-B core over `VarStore::exists`.
    let result = crate::obj::new_boolean_obj(i32::from(interp.var_exists(&name)));
    interp.set_result(result);
    Code::Ok
}

fn info_level(interp: &mut Interp, argv: &[*mut TclObj]) -> Code {
    // The shared Family-B core over `Introspect` (`tcl_cmd_core::info::level`);
    // the runtime is a thin adapter mapping `Result<*mut TclObj, CmdError>` onto
    // its set-result/`Code` ABI. (`info level 0` is relative — the current call;
    // `N>0` absolute.)
    let number = match argv.len() {
        2 => None,
        3 => Some(&argv[2]),
        _ => return interp.wrong_args_for_prefix(argv, 2, b"?number?"),
    };
    let dialect = interp.native_invocation_dialect();
    let result = if dialect.native_error_log_protocol().is_some()
        && dialect
            .tcl_version
            .is_some_and(|version| version >= tcl_dialect::TclVersion::V8_6)
    {
        interp.native_info_level(number)
    } else {
        tcl_cmd_core::info::level(interp, number)
    };
    match result {
        Ok(v) => {
            interp.set_result(v);
            Code::Ok
        }
        Err(e) => interp.report_cmd_error(e),
    }
}

/// `info frame ?number?` — the source-location stack (PC-5). No arg: the stack
/// depth. With a number: a dict describing that frame (`type`/`line`/`cmd`,
/// `proc`/`file` where applicable, and `level`). C ref `tclCmdIL.c`
/// `InfoFrameCmd`; numbering matches `info level` (N>0 absolute, N<=0 relative).
fn info_frame(interp: &mut Interp, argv: &[*mut TclObj]) -> Code {
    let arguments = match OriginalArguments::enter(interp, argv) {
        Ok(arguments) => arguments,
        Err(error) => return interp.report_cmd_error(error),
    };
    let code = info_frame_original(interp, argv, &arguments);
    arguments.finish(code)
}

fn info_frame_original(
    interp: &mut Interp,
    argv: &[*mut TclObj],
    arguments: &OriginalArguments,
) -> Code {
    match argv.len() {
        2 => {
            interp.set_result_bytes(interp.cmd_frame_depth().to_string().as_bytes());
            Code::Ok
        }
        3 => {
            let spec = match info_name(interp, arguments, 2) {
                Ok(value) => value,
                Err(code) => return code,
            };
            let n = match core::str::from_utf8(&spec)
                .ok()
                .and_then(|s| s.trim().parse::<i64>().ok())
            {
                Some(n) => n,
                None => {
                    let mut m = b"expected integer but got \"".to_vec();
                    m.extend_from_slice(&spec);
                    m.push(b'"');
                    return interp.set_error(&m);
                }
            };
            match interp.cmd_frame_info(n) {
                Ok(Some(pairs)) => {
                    let kv: Vec<(*mut TclObj, *mut TclObj)> = pairs
                        .iter()
                        .map(|(k, v)| (new_string(k), new_string(v)))
                        .collect();
                    interp.set_result(crate::dict::new_dict_obj(&kv));
                    Code::Ok
                }
                Ok(None) => bad_level(interp, &spec),
                Err(error) => interp.report_cmd_error(error.into()),
            }
        }
        _ => interp.wrong_args_for_prefix(argv, 2, b"?number?"),
    }
}

/// Publish the selected info-level selector failure.
fn bad_level(interp: &mut Interp, spec: &[u8]) -> Code {
    let mut m = b"bad level \"".to_vec();
    m.extend_from_slice(spec);
    m.push(b'"');
    interp.set_error(&m)
}

fn fixed(interp: &mut Interp, argv: &[*mut TclObj], usage: &[u8], value: &[u8]) -> Code {
    if argv.len() != 2 {
        return interp.wrong_args_for_prefix(
            argv,
            2,
            usage.splitn(3, |byte| *byte == b' ').nth(2).unwrap_or(b""),
        );
    }
    interp.set_result_bytes(value);
    Code::Ok
}

fn info_version_report(interp: &mut Interp, argv: &[*mut TclObj], member: &[u8]) -> Code {
    let member = std::str::from_utf8(member).expect("selected static info member");
    let usage = format!("info {member}");
    if argv.len() != 2 {
        return interp.wrong_args(usage.as_bytes());
    }
    match interp
        .native_invocation_dialect()
        .native_info_version_source(member)
    {
        Some(tcl_registry::native_info_version::NativeInfoVersionSource::Global(name)) => {
            info_global(interp, argv, usage.as_bytes(), name.as_bytes())
        }
        Some(tcl_registry::native_info_version::NativeInfoVersionSource::CoreRelease(version)) => {
            interp.set_result_bytes(version.as_bytes());
            Code::Ok
        }
        None => interp.report_cmd_error(
            tcl_syntax::value::ValueError::CommandProtocolUnavailable(
                "native info version reporting source is unavailable",
            )
            .into(),
        ),
    }
}

/// `info tclversion`/`patchlevel` — read the **global** `var` (C uses
/// `TCL_GLOBAL_ONLY`), erroring `can't read "VAR": no such variable` if it has
/// been unset (info-14.3/18.3). `var` is the unqualified name (for the message);
/// the read is `::`-qualified so it works inside a proc/eval frame.
fn info_global(interp: &mut Interp, argv: &[*mut TclObj], usage: &[u8], var: &[u8]) -> Code {
    if argv.len() != 2 {
        return interp.wrong_args_for_prefix(
            argv,
            2,
            usage.splitn(3, |byte| *byte == b' ').nth(2).unwrap_or(b""),
        );
    }
    let mut qualified = b"::".to_vec();
    qualified.extend_from_slice(var);
    match interp.var_get(&qualified) {
        Some(o) => {
            interp.set_result(o);
            Code::Ok
        }
        None => {
            let mut m = b"can't read \"".to_vec();
            m.extend_from_slice(var);
            m.extend_from_slice(b"\": no such variable");
            interp.set_error(&m)
        }
    }
}

fn info_body(interp: &mut Interp, argv: &[*mut TclObj]) -> Code {
    if argv.len() != 3 {
        return interp.wrong_args_for_prefix(argv, 2, b"procname");
    }
    match tcl_cmd_core::info::body(interp, &argv[2]) {
        Ok(v) => {
            interp.set_result(v);
            Code::Ok
        }
        Err(e) => interp.report_cmd_error(e),
    }
}

fn info_args(interp: &mut Interp, argv: &[*mut TclObj]) -> Code {
    if argv.len() != 3 {
        return interp.wrong_args_for_prefix(argv, 2, b"procname");
    }
    match tcl_cmd_core::info::args(interp, &argv[2]) {
        Ok(v) => {
            interp.set_result(v);
            Code::Ok
        }
        Err(e) => interp.report_cmd_error(e),
    }
}

fn info_default(interp: &mut Interp, argv: &[*mut TclObj]) -> Code {
    let arguments = match OriginalArguments::enter(interp, argv) {
        Ok(arguments) => arguments,
        Err(error) => return interp.report_cmd_error(error),
    };
    let code = info_default_original(interp, argv, &arguments);
    arguments.finish(code)
}

fn info_default_original(
    interp: &mut Interp,
    argv: &[*mut TclObj],
    arguments: &OriginalArguments,
) -> Code {
    if argv.len() != 5 {
        return interp.wrong_args_for_prefix(argv, 2, b"procname arg varname");
    }
    // The existing core reads procedure/formal and selects their actual
    // declared default before the destination lookup is reached.
    let reached = tcl_cmd_core::info::default(interp, &argv[2], &argv[3]);
    if let Err(error) = arguments.check() {
        if let Ok((fresh, false)) = reached {
            crate::interp::drop_fresh(fresh);
        }
        return interp.report_cmd_error(error);
    }
    let (value, has_default) = match reached {
        Ok(pair) => pair,
        Err(error) => return interp.report_cmd_error(error),
    };
    // Keep the borrowed default allocation safe without the native +1 that
    // would change sharing before the selected destination lookup. This
    // context also outlives failed-assignment cleanup of the new empty object.
    let value_arguments = match OriginalArguments::enter(interp, &[value]) {
        Ok(value_arguments) => value_arguments,
        Err(error) => {
            if !has_default {
                crate::interp::drop_fresh(value);
            }
            return interp.report_cmd_error(error);
        }
    };
    let code = (|| {
        let destination = match arguments.original(4) {
            Ok(destination) => destination,
            Err(error) => return interp.report_cmd_error(error),
        };
        let assigned = interp.assign_original_named_variable(destination, value);
        if let Err(error) = arguments.check() {
            return interp.report_cmd_error(error);
        }
        if let Err(code) = assigned {
            return code;
        }
        if let Err(error) = value_arguments.check() {
            return interp.report_cmd_error(error);
        }
        interp.set_result_bytes(if has_default { b"1" } else { b"0" });
        Code::Ok
    })();
    // Only the new no-default empty object belongs to this adapter. A failed
    // lookup can leave it unowned; borrowed declared values are never retired here.
    if !has_default && crate::obj::allocation_is_live(value) && unsafe { (*value).ref_count } == 0 {
        crate::interp::drop_fresh(value);
    }
    drop(value_arguments);
    arguments.finish(code)
}

#[cfg(test)]
mod tests {
    use crate::counters;
    use crate::interp::{Code, Interp};

    #[test]
    fn original_info_complete_retains_checked_string_worker_and_selected_runtime_grammar() {
        // naming.source.original-configured-script-completeness
        // docs/design/analysis/name-resolution-proofs/source-original-configured-script-completeness.md
        // Form original scalar text through format%c as in the captured String
        // request. Raw source encoding, object/header and entry remain separate.
        for engine in ["tcl8.4", "tcl8.5", "tcl8.6", "tcl9.0", "tcl9.1", "jim"] {
            let mut interp = Interp::with_native_core(
                crate::interp::default_host(),
                crate::environment::profile_for_dialect(engine),
                tcl_registry::special_vars::NativeBootstrapInputs::default(),
            )
            .unwrap();
            let jim = engine == "jim";
            let modern = matches!(engine, "tcl9.0" | "tcl9.1");
            for (original, expected) in [
                ("set x ${a{}", !modern),
                ("set x {*}{", engine == "tcl8.4"),
                ("set x \\", !jim),
                ("set x \\\n", jim),
                ("set x \"a\"b {", !jim),
                ("# c\\\r\n", true),
            ] {
                let points = original
                    .chars()
                    .map(|point| u32::from(point).to_string())
                    .collect::<Vec<_>>()
                    .join(" ");
                let source = format!("set original {{}}; foreach point {{{points}}} {{append original [format %c $point]}}; info complete $original");
                assert_eq!(
                    interp.eval_str(source.as_bytes()),
                    Code::Ok,
                    "{engine}/{original:?}: {:?}",
                    interp.result_bytes()
                );
                assert_eq!(
                    interp.result_bytes(),
                    if expected { b"1" } else { b"0" },
                    "{engine}/{original:?}"
                );
            }
        }
    }

    #[test]
    fn original_info_functions_follow_selected_native_script_and_helpers() {
        // Native controls: naming.info.functions-native-script
        // docs/design/analysis/name-resolution-proofs/info-functions-native-script.md
        for engine in ["tcl8.4", "tcl8.5", "tcl8.6", "tcl9.0", "tcl9.1"] {
            let mut interp = Interp::with_native_core(
                crate::interp::default_host(),
                crate::environment::profile_for_dialect(engine),
                tcl_registry::special_vars::NativeBootstrapInputs::default(),
            )
            .unwrap();
            assert_eq!(interp.eval_str(b"info functions sin"), Code::Ok, "{engine}");
            assert_eq!(interp.result_bytes(), b"sin", "{engine}");
            assert_eq!(interp.eval_str(b"namespace eval ::InfoScope085 {namespace eval tcl::mathfunc {proc local085 {} {return LOCAL}}; info functions local085}"), Code::Ok, "{engine}");
            let expected: &[u8] = if engine == "tcl8.4" { b"" } else { b"local085" };
            assert_eq!(interp.result_bytes(), expected, "{engine}");
            if engine != "tcl8.4" {
                assert_eq!(interp.eval_str(b"rename ::apply ::SavedInfoApply085; proc ::apply args {error APPLY_HELPER085}; info functions sin"), Code::Error, "{engine}");
                assert_eq!(interp.result_bytes(), b"APPLY_HELPER085", "{engine}");
            }
        }
    }

    #[test]
    fn original_info_loaded_uses_counted_interpreter_path_elements() {
        // Native controls: naming.info.loaded-original-interpreter-path
        // docs/design/analysis/name-resolution-proofs/info-loaded-original-interpreter-path.md
        for engine in ["tcl8.4", "tcl8.5", "tcl8.6", "tcl9.0", "tcl9.1"] {
            let mut interp = Interp::with_native_core(
                crate::interp::default_host(),
                crate::environment::profile_for_dialect(engine),
                tcl_registry::special_vars::NativeBootstrapInputs::default(),
            )
            .unwrap();
            for source in [b"info loaded {}".as_slice(), b"interp create InfoParent085; interp eval InfoParent085 {interp create InfoChild085}; info loaded {InfoParent085 InfoChild085}", b"set child [binary format H* 496e666f5a65726f30383500ff]; interp create $child; info loaded $child"] {
                assert_eq!(interp.eval_str(source), Code::Ok, "{engine}: {:?}", interp.result_bytes());
                assert_eq!(interp.result_bytes(), b"", "{engine}");
            }
            assert_eq!(
                interp.eval_str(b"info loaded MissingInfo085"),
                Code::Error,
                "{engine}"
            );
            assert_eq!(
                interp.result_bytes(),
                b"could not find interpreter \"MissingInfo085\"",
                "{engine}"
            );
        }
    }

    fn leak_free(body: impl FnOnce(&mut Interp)) {
        counters::reset();
        {
            let mut interp = Interp::new();
            body(&mut interp);
        }
        assert_eq!(
            counters::finalize(),
            0,
            "residual: {} objs, {} bufs",
            counters::live_objs(),
            counters::live_bufs()
        );
        assert_eq!(counters::double_free_count(), 0);
    }

    fn run(i: &mut Interp, src: &[u8]) -> Vec<u8> {
        let code = i.eval_str(src);
        let result = i.result_bytes();
        let error_info = if code == Code::Ok {
            Vec::new()
        } else {
            let _ = i.eval_str(b"set ::errorInfo");
            i.result_bytes()
        };
        assert_eq!(
            code,
            Code::Ok,
            "eval {:?}: result {:?}, errorInfo {:?}, admission {:?}, native access {:?}",
            String::from_utf8_lossy(src),
            result,
            error_info,
            i.native_compilation_admission_error(),
            i.native_access_refusal()
        );
        result
    }

    /// `info` is a `TclMakeEnsemble` command, so both the prefix
    /// scan and the whole miss sentence belong to `tcl_cmd_core::ensemble`,
    /// rather than a duplicated prefix loop and `unknown or ambiguous
    /// subcommand "` literal beside the owner's `subcommand_choices`.
    ///
    /// tclsh 9.0.4:
    ///   info {}   -> unknown or ambiguous subcommand "": must be args, body,
    ///                class, cmdcount, cmdtype, commands, complete, constant,
    ///                consts, coroutine, default, errorstack, exists, frame,
    ///                functions, globals, hostname, level, library, loaded,
    ///                locals, nameofexecutable, object, patchlevel, procs,
    ///                script, sharedlibextension, tclversion, or vars
    ///   info e x  -> unknown or ambiguous subcommand "e": must be <same>
    ///   info ex x -> 0        (a unique prefix still resolves)
    #[test]
    fn info_ensemble_miss_carries_the_full_option_list() {
        const MUST: &str = "must be args, body, class, cmdcount, cmdtype, commands, complete, \
                            constant, consts, coroutine, default, errorstack, exists, frame, \
                            functions, globals, hostname, level, library, loaded, locals, \
                            nameofexecutable, object, patchlevel, procs, script, \
                            sharedlibextension, tclversion, or vars";
        leak_free(|i| {
            assert_eq!(i.eval_str(b"info {}"), Code::Error);
            assert_eq!(
                i.result_bytes(),
                format!("unknown or ambiguous subcommand \"\": {MUST}").as_bytes()
            );
            assert_eq!(i.eval_str(b"info e x"), Code::Error);
            assert_eq!(
                i.result_bytes(),
                format!("unknown or ambiguous subcommand \"e\": {MUST}").as_bytes()
            );
            assert_eq!(run(i, b"set x 1; info ex x"), b"1");
            assert_eq!(run(i, b"info comm set"), b"set");
        });
    }

    #[test]
    fn info_commands_qualified_pattern() {
        leak_free(|i| {
            run(
                i,
                b"namespace eval ::myns { proc aaa {} {}; proc abb {} {}; proc zzz {} {} }",
            );
            // A namespace-qualified glob lists that namespace's commands,
            // re-qualified, sorted.
            assert_eq!(
                run(i, b"lsort [info commands ::myns::a*]"),
                b"::myns::aaa ::myns::abb"
            );
            assert_eq!(run(i, b"info commands ::myns::zzz"), b"::myns::zzz");
            // A non-existent namespace yields nothing.
            assert_eq!(run(i, b"info commands ::nope::*"), b"");
            // An unqualified pattern still works (global builtin present).
            assert_eq!(run(i, b"info commands ::set"), b"::set");
        });
    }

    #[test]
    fn info_level_reports_call_words() {
        leak_free(|i| {
            assert_eq!(run(i, b"info level"), b"0"); // global scope
            run(i, b"proc outer {a b} {inner $a}");
            run(
                i,
                b"proc inner {x} {list [info level] [info level 0] [info level 1]}",
            );
            // outer 1 2 → inner 1 ; inside inner: level 2, this call, the outer call.
            assert_eq!(run(i, b"outer 1 2"), b"2 {inner 1} {outer 1 2}");
        });
    }

    #[test]
    fn info_frame_stack() {
        // Eval mode (the runtime's tests): `type proc`/`eval` with body-relative
        // lines — verified against tclsh 9.0 (via stdin). A `[info frame]` reports
        // the substituted command but the enclosing line.
        leak_free(|i| {
            // Depth: 1 at top level, 2 inside a proc.
            assert_eq!(run(i, b"info frame"), b"1");
            run(i, b"proc p {} { return [info frame] }");
            assert_eq!(run(i, b"p"), b"2");
            // `info frame 0` inside a proc: type proc, the FQN, level 0, and the
            // substituted command at its (body-relative) line.
            run(i, b"proc q {} {\n    return [info frame 0]\n}");
            assert_eq!(
                run(i, b"q"),
                b"type proc line 2 cmd {info frame 0} proc ::q level 0"
            );
            // Absolute index 1 = the root (top-level) frame: type eval.
            run(i, b"proc r {} { return [info frame 1] }");
            let out = run(i, b"r");
            assert!(
                out.starts_with(b"type eval line ") && out.ends_with(b"cmd r level 1"),
                "got {:?}",
                String::from_utf8_lossy(&out)
            );
            // Relative -1 from a callee names the caller proc.
            run(i, b"proc a {} { b }");
            run(i, b"proc b {} { return [info frame -1] }");
            assert_eq!(run(i, b"a"), b"type proc line 1 cmd {b } proc ::a level 1");
            // Out of range → bad level.
            assert_eq!(i.eval_str(b"info frame 99"), Code::Error);
        });
    }

    #[test]
    fn info_frame_uplevel_is_eval_typed_without_level() {
        // An `uplevel` body is `type eval` (a fresh dynamically-evaluated body),
        // keeps the *invoking* proc's name, and omits the `level` key (its scope
        // is redirected). Byte-verified vs tclsh 9.0.
        leak_free(|i| {
            run(i, b"proc h {} { uplevel 1 { return [info frame 0] } }");
            assert_eq!(
                run(i, b"h"),
                b"type eval line 1 cmd {info frame 0} proc ::h"
            );
        });
    }

    // Needs the numeric tower: `info functions` needs the `::tcl::mathfunc::*` table.
    #[cfg(have_tommath)]
    #[test]
    fn info_cmdtype_loaded_functions() {
        leak_free(|i| {
            assert_eq!(run(i, b"info cmdtype puts"), b"native");
            assert_eq!(run(i, b"proc p {} {}; info cmdtype p"), b"proc");
            assert_eq!(run(i, b"info loaded"), b"");
            assert_eq!(run(i, b"info functions sin"), b"sin");
            // cmdcount increases as commands run.
            assert_eq!(
                run(
                    i,
                    b"set a [info cmdcount]; set b [info cmdcount]; expr {$b > $a}"
                ),
                b"1"
            );
        });
    }

    // Needs the numeric tower: this covers `info functions` and the shared
    // `info commands` namespace enumeration over the math-function table.
    #[cfg(have_tommath)]
    #[test]
    fn math_enumeration_tracks_the_registry_selected_runtime_surface() {
        use tcl_dialect::TclVersion;

        leak_free(|i| {
            i.set_runtime_version(TclVersion::V8_4);
            // TP/TN: Tcl 8.4 introspects its fixed function table, while the
            // later command-table wrapper itself remains absent.
            assert_eq!(run(i, b"info functions sin"), b"sin");
            assert_eq!(run(i, b"info commands ::tcl::mathfunc::sin"), b"");

            i.set_runtime_version(TclVersion::V8_6);
            // FN: the 9.0-only builtin is hidden by both enumerators.
            assert_eq!(run(i, b"info functions isfinite"), b"");
            assert_eq!(run(i, b"info commands ::tcl::mathfunc::isfinite"), b"");
            // TN: the older command-table builtin remains visible.
            assert_eq!(run(i, b"info functions sin"), b"sin");
            assert_eq!(
                run(i, b"info commands ::tcl::mathfunc::sin"),
                b"::tcl::mathfunc::sin"
            );

            i.set_runtime_version(TclVersion::V9_0);
            // TP: the 9.0 surface exposes the builtin consistently.
            assert_eq!(run(i, b"info functions isfinite"), b"isfinite");
            assert_eq!(
                run(i, b"info commands ::tcl::mathfunc::isfinite"),
                b"::tcl::mathfunc::isfinite"
            );

            i.set_runtime_version(TclVersion::V8_6);
            run(
                i,
                b"proc ::tcl::mathfunc::isfinite {x} {return replacement}",
            );
            // FP guard: a user replacement is not a registry builtin and must
            // remain visible even when the native builtin is version-hidden.
            assert_eq!(run(i, b"info functions isfinite"), b"isfinite");
            assert_eq!(
                run(i, b"info commands ::tcl::mathfunc::isfinite"),
                b"::tcl::mathfunc::isfinite"
            );
        });
    }

    #[test]
    fn info_complete_balances() {
        leak_free(|i| {
            assert_eq!(run(i, b"info complete {set x 1}"), b"1");
            assert_eq!(run(i, b"info complete {set x {a b}}"), b"1");
            assert_eq!(run(i, b"info complete \"set x {a\""), b"0"); // open brace
            assert_eq!(run(i, b"info complete {puts [expr 1}"), b"0"); // open bracket
            assert_eq!(run(i, b"info complete {a \"b}"), b"0"); // open quote
        });
    }

    #[test]
    fn info_exists_scalar_and_array() {
        leak_free(|i| {
            assert_eq!(run(i, b"info exists nope"), b"0");
            run(i, b"set x 1");
            assert_eq!(run(i, b"info exists x"), b"1");
            run(i, b"set a(k) v");
            assert_eq!(run(i, b"info exists a(k)"), b"1");
            assert_eq!(run(i, b"info exists a(nope)"), b"0");
            assert_eq!(run(i, b"info exists a"), b"1"); // the array exists
            i.eval_str(b"unset x a");
        });
    }

    #[test]
    fn info_consts_enumerates_bindings_and_namespace_global_fallback() {
        leak_free(|i| {
            assert_eq!(
                run(
                    i,
                    concat!(
                        "const G 1; namespace eval N {const C 2; set ordinary 0}; ",
                        "list [lsort [info consts]] [info consts G] ",
                        "[info consts N::*] [info consts ::N::*]"
                    )
                    .as_bytes(),
                ),
                b"G G ::N::C ::N::C"
            );
            assert_eq!(
                run(
                    i,
                    concat!(
                        "namespace eval N {list [lsort [info consts]] ",
                        "[lsort [info consts *]] [info consts G] [info consts C] ",
                        "[info consts ::*]}"
                    )
                    .as_bytes(),
                ),
                b"{C G} {C G} G C ::G"
            );
            assert_eq!(
                run(
                    i,
                    concat!(
                        "proc p {} {const L 3; set ordinary 0; global G; ",
                        "upvar #0 ::N::C U; list [lsort [info vars]] ",
                        "[lsort [info consts]] [info constant L] [info constant G] ",
                        "[info constant U] [info consts ::*] [info consts N::*]}; p"
                    )
                    .as_bytes(),
                ),
                b"{G L U ordinary} L 1 1 1 ::G ::N::C"
            );
            assert_eq!(
                run(
                    i,
                    concat!(
                        "namespace eval M {const C 4; namespace upvar :: G A; ",
                        "list [lsort [info vars]] [lsort [info consts]] ",
                        "[info constant A] [info consts A] [info consts G]}"
                    )
                    .as_bytes(),
                ),
                b"{A C} {C G} 1 {} G"
            );
            assert_eq!(
                run(
                    i,
                    concat!(
                        "namespace eval S {const C 5; set G shadow; ",
                        "list [lsort [info consts]] [info consts G] ",
                        "[info consts G*] [info constant G] [info constant ::G]}"
                    )
                    .as_bytes(),
                ),
                b"C G {} 0 1"
            );
            assert_eq!(
                run(
                    i,
                    b"const ::x 1; list [info consts :::x] [info consts ::::x] [info consts ::::::*]",
                ),
                b"::x ::x {::G ::x}"
            );
        });
    }

    #[test]
    fn info_consts_includes_only_tcloo_instance_links() {
        // naming.tcloo.original-constant-link-introspection
        // docs/design/analysis/name-resolution-proofs/tcloo-original-constant-link-introspection.md
        leak_free(|i| {
            assert_eq!(
                run(
                    i,
                    concat!(
                        "const G 9; oo::class create C {variable X; ",
                        "constructor {} {const X 1}; method inspect {} {global G; ",
                        "upvar #0 ::G U; list [info consts] [info constant G] ",
                        "[info constant U]}; method retarget {} {upvar #0 ::G X; ",
                        "list [info consts] [info constant X]}; method shadow {X} ",
                        "{list $X [info consts]}}; set o [C new]; ",
                        "oo::object create O; oo::objdefine O {variable P; ",
                        "method init {} {const P 2}; method inspect {} {info consts}}; ",
                        "O init; oo::class create CA {variable X; method inspect {} ",
                        "{list [info consts] [info constant X] $X}}; set oa [CA new]; ",
                        "namespace eval [info object namespace $oa] ",
                        "{namespace upvar :: G X}; oo::class create CP ",
                        "{method inspect {} {info consts}}; CP create op; ",
                        "oo::objdefine op {variable Q; method init {} {const Q 3}}; ",
                        "op init; list [$o inspect] [$o retarget] [$o shadow formal] ",
                        "[O inspect] [$oa inspect] [op inspect] ",
                        "[info constant [info object namespace op]::Q]"
                    )
                    .as_bytes(),
                ),
                b"{X 1 1} {{} 1} {formal {}} P {{} 1 9} {} 1"
            );
        });
    }

    #[test]
    fn fresh_interp_exposes_c_create_interp_versions() {
        leak_free(|i| {
            // C installs these globals in `Tcl_CreateInterp`, before `Tcl_Init`;
            // every fresh Rust interp must expose the same core lifecycle.
            assert_eq!(run(i, b"info tclversion"), b"9.0");
            assert_eq!(run(i, b"info patchlevel"), b"9.0.4");
            assert_eq!(
                run(i, b"info sharedlibextension"),
                tcl_platform::bootstrap::SHARED_LIBRARY_EXTENSION.as_bytes()
            );
        });
    }

    #[test]
    fn info_patchlevel_still_errors_after_global_is_unset() {
        leak_free(|i| {
            // The command still reads the variable rather than hiding a
            // constant: explicitly unsetting it keeps C's error behaviour.
            assert_eq!(
                i.eval_str(b"unset ::tcl_patchLevel; info patchlevel"),
                Code::Error
            );
            assert_eq!(
                i.result_bytes(),
                b"can't read \"tcl_patchLevel\": no such variable"
            );
        });
    }

    #[test]
    fn info_procs() {
        leak_free(|i| {
            run(i, b"proc greet {name {g hi}} {return $g-$name}");
            assert_eq!(run(i, b"info args greet"), b"name g");
            assert_eq!(run(i, b"info body greet"), b"return $g-$name");
            // default: sets the var, returns 1; missing default returns 0.
            assert_eq!(run(i, b"info default greet g d"), b"1");
            assert_eq!(run(i, b"set d"), b"hi");
            assert_eq!(run(i, b"info default greet name d"), b"0");
            // a proc appears in `info procs`; a builtin does not.
            assert_eq!(run(i, b"info procs greet"), b"greet");
            assert_eq!(run(i, b"info procs nosuch*"), b"");
            i.eval_str(b"unset d");
        });
    }

    // Needs the numeric tower: membership asserts go through `expr`.
    #[cfg(have_tommath)]
    #[test]
    fn info_vars_locals_globals() {
        leak_free(|i| {
            run(
                i,
                b"namespace eval foo { variable a 1; variable b 2 }\nset gx 10",
            );
            // In a proc: `info locals` is the genuine locals; `info vars` also
            // lists the linked namespace var by its local alias.
            run(
                i,
                b"proc p {} { set loc 5; variable ::foo::a; \
                  set ::out \"[lsort [info locals]]|[lsort [info vars]]\" }",
            );
            run(i, b"p");
            assert_eq!(run(i, b"set ::out"), b"loc|a loc");
            // `info globals` lists global-namespace vars only (not `foo::a`).
            assert_eq!(run(i, b"lsearch -exact [info globals] foo::a"), b"-1");
            assert_eq!(
                run(i, b"expr {[lsearch -exact [info globals] gx] >= 0}"),
                b"1"
            );
            // A qualified `info vars` lists that namespace re-qualified.
            assert_eq!(run(i, b"lsort [info vars ::foo::*]"), b"::foo::a ::foo::b");
            // At namespace scope, `info vars` lists the namespace's own vars.
            assert_eq!(run(i, b"namespace eval foo { lsort [info vars] }"), b"a b");
        });
    }

    // Needs the numeric tower: membership asserts go through `expr`.
    #[cfg(have_tommath)]
    #[test]
    fn info_commands_procs_namespaced() {
        leak_free(|i| {
            run(
                i,
                b"namespace eval foo { proc bar {} {}; proc baz {} {} }\n\
                  namespace eval foo::sub { proc deep {} {} }\nproc gproc {} {}",
            );
            // A qualified glob lists that namespace re-qualified (direct members
            // only — not `foo::sub::deep`).
            assert_eq!(
                run(i, b"lsort [info commands ::foo::*]"),
                b"::foo::bar ::foo::baz"
            );
            assert_eq!(
                run(i, b"lsort [info procs foo::*]"),
                b"::foo::bar ::foo::baz"
            );
            // A namespaced proc is not in the global listing.
            assert_eq!(run(i, b"lsearch -exact [info commands] foo::bar"), b"-1");
            // The bug this share fixed: inside a namespace, `info procs` lists only
            // that namespace's procs (no global merge), while `info commands` does
            // see the global `gproc`.
            assert_eq!(
                run(i, b"namespace eval foo { lsort [info procs] }"),
                b"bar baz"
            );
            assert_eq!(
                run(
                    i,
                    b"namespace eval foo { expr {[lsearch -exact [info commands] gproc] >= 0} }"
                ),
                b"1"
            );
            // A missing namespace qualifier → the empty list, not an error.
            assert_eq!(run(i, b"info commands ::nope::*"), b"");
        });
    }

    #[test]
    fn info_proc_introspection_errors() {
        leak_free(|i| {
            run(i, b"proc greet {name {g hi}} {return $g-$name}");
            // body/args/default on a non-proc (unknown name or a builtin) → the
            // shared `"name" isn't a procedure` error (pinned vs tclsh 9.0).
            for src in [
                &b"info body nosuch"[..],
                &b"info args nosuch"[..],
                &b"info default nosuch a d"[..],
                &b"info body set"[..],
            ] {
                assert_eq!(i.eval_str(src), Code::Error);
            }
            assert_eq!(i.result_bytes(), b"\"set\" isn't a procedure");
            // An unknown formal parameter.
            assert_eq!(i.eval_str(b"info default greet zz d"), Code::Error);
            assert_eq!(
                i.result_bytes(),
                b"procedure \"greet\" doesn't have an argument \"zz\""
            );
        });
    }

    #[test]
    fn info_level_and_vars() {
        leak_free(|i| {
            assert_eq!(run(i, b"info level"), b"0"); // global scope
            run(i, b"set alpha 1");
            run(i, b"set beta 2");
            // info globals lists global vars (glob-filtered).
            assert_eq!(run(i, b"info globals alpha"), b"alpha");
            assert_eq!(run(i, b"info exists alpha"), b"1");
            i.eval_str(b"unset alpha beta");
        });
    }
}

#[cfg(test)]
#[path = "cmd_info/native_commands_tests.rs"]
mod native_commands_tests;
