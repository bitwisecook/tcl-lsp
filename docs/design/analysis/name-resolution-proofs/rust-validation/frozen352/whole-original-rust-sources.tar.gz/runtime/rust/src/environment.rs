// tcl-lsp — a language server and toolchain for Tcl
// Copyright (C) 2026 James Deucker (bitwisecook) <https://github.com/bitwisecook>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.
//
// SPDX-License-Identifier: AGPL-3.0-or-later

//! The C-ABI runtime's dialect ingress — this engine's face of the one
//! shared seam, [`tcl_registry::model::ingress`].
//!
//! The same three helpers `tcl-vm`'s `crate::environment` carries, for the
//! same reason: resolving a dialect *name* with `DialectProfile::by_name`
//! (or, in `codegen_abi`, with a raw `DialectProfile::find`), reaching the
//! registry with `registry_for_profile`, and reading
//! `profile.availability_mask` independently at each availability question
//! would let the two engines drift apart. All three go through the
//! resolved environment instead.
//!
//! Behaviour is unchanged by construction. The only dialect names this
//! runtime accepts are the closed set [`TclVersion::dialect_profile_name`]
//! spells, whose environments are their same-named catalogue entries, so
//! [`profile_for_dialect`] returns the profile `by_name` returned; the
//! generation's command store is the very `Arc` the old `(profile,
//! overlay)` cache owns; and the document authoring mask is test-pinned
//! equal to the threaded profile's `availability_mask` for every profile
//! an ingress can produce.
//!
//! The `&'static DialectProfile` these helpers take and hand back is
//! narrower than the interpreter's own pin, which carries a
//! [`tcl_registry::model::PinnedContext`] instead: [`pin_context`] resolves a
//! [`tcl_runtime_api::RuntimeContext`] through the same ingress, to any
//! environment it knows, and refuses a context it does not agree with.
//!
//! [`TclVersion::dialect_profile_name`]: tcl_dialect::TclVersion::dialect_profile_name

use std::sync::{Mutex, OnceLock};

use tcl_dialect::model::SurfaceQuery;
use tcl_dialect::DialectProfile;
use tcl_registry::CommandRegistry;

/// Resolve a dialect **name** to the profile this interpreter pins.
///
/// The environment-model form of the retired
/// `DialectProfile::by_name(name)`: the resolved environment's
/// [`unit_profile`], which is its same-named catalogue profile for every
/// release name this runtime pins and the permissive fallback for the
/// lenient and unknown spellings.
///
/// [`unit_profile`]: tcl_registry::model::DocumentEnvironment::unit_profile
pub(crate) fn profile_for_dialect(name: &str) -> &'static DialectProfile {
    tcl_registry::model::resolve_environment(name).unit_profile()
}

/// Resolve a [`tcl_runtime_api::RuntimeContext`] through the ingress — the
/// environment-model form of a pin. An overlay nothing has installed is an
/// error here and never the un-overlaid generation under another name.
pub(crate) fn pin_context(
    context: &tcl_runtime_api::RuntimeContext,
) -> Result<tcl_registry::model::PinnedContext, tcl_registry::model::PinError> {
    tcl_registry::model::pin(context)
}

/// The command **store** for `profile` — the resolved environment's
/// registry generation, replacing the retired
/// `tcl_registry::cache::registry_for_profile(profile)`.
///
/// A profile's canonical name **is** a canonical environment id, so this
/// is an id-keyed generation lookup rather than a re-parse, and the
/// generation's store is the same allocation the old per-profile cache
/// published. The `&'static` promotion leaks a clone of one `Arc` per
/// environment, never a second assembly — which is what lets the
/// interpreter keep caching this handle on its pin.
pub(crate) fn store_for_profile(profile: &'static DialectProfile) -> &'static CommandRegistry {
    tcl_registry::model::static_context_for_profile(profile).commands()
}

/// The availability mask a command-surface, subcommand, or option
/// question about `profile` is answered under — its environment's
/// **document authoring mask**, replacing the direct
/// `profile.availability_mask` read.
///
/// Equal to `profile.surface_query()` for every profile an ingress can
/// produce, pinned by `tcl_registry::model::ingress`'s
/// `the_document_mask_is_the_threaded_profiles_mask`.
pub(crate) fn surface_point(profile: &'static DialectProfile) -> SurfaceQuery<'static> {
    tcl_registry::model::static_document_context_for_profile(profile).authoring_query()
}

/// One memoised answer retains the command, actual release, original handler
/// table and its availability-filtered projection.
type SubcommandCacheEntry = (
    &'static str,
    String,
    Vec<&'static [u8]>,
    &'static [&'static [u8]],
);

/// The subset of an engine ensemble `table` the emulated release actually
/// has, in the table's own order — the WASM runtime's half of the rule
/// `tcl-vm`'s `environment::release_subcommands` states.
///
/// A `TclMakeEnsemble` table is a *release* fact: `dict getwithdefault`,
/// `string insert` and `chan isbinary` arrive in Tcl 9 while `string
/// bytelength` leaves with it, and resolving against one release's table
/// under every pin both dispatches names the pinned release never had and
/// changes prefix verdicts for names that have nothing to do with them
/// (`dict g` is `get` on 8.6, ambiguous on 9.0; `string in` is `index` on
/// 8.6, ambiguous on 9.0). The names and their gates belong to the registry.
///
/// Only *removal* happens: a name the registry does not model (an engine
/// extra) is kept, so a table stays the engine's own list of what it
/// dispatches and its enumeration order.
///
/// Memoised per `(command, release, original table)`: bootstrap worker rosters
/// and monolithic dispatch tables can differ for the same command. Reusing a
/// smaller roster would erase an actual runtime member. The engine's static
/// rosters and selected releases form a bounded set.
fn release_subcommand_cache() -> &'static Mutex<Vec<SubcommandCacheEntry>> {
    static CACHE: OnceLock<Mutex<Vec<SubcommandCacheEntry>>> = OnceLock::new();
    CACHE.get_or_init(|| Mutex::new(Vec::new()))
}

pub(crate) fn release_subcommands(
    dialect_name: &str,
    command: &'static str,
    table: &[&'static [u8]],
) -> &'static [&'static [u8]] {
    if command == "info" {
        let dialect =
            tcl_registry::InvocationDialect::of_profile(profile_for_dialect(dialect_name));
        if let Some(names) = dialect.native_jim_info_member_names() {
            static BYTES: OnceLock<Box<[&'static [u8]]>> = OnceLock::new();
            return BYTES.get_or_init(|| names.iter().map(|name| name.as_bytes()).collect());
        }
    }
    let cache = release_subcommand_cache();
    if let Some((_, _, _, hit)) =
        cache
            .lock()
            .expect("subcommand cache")
            .iter()
            .find(|(cmd, name, input, _)| {
                *cmd == command && name == dialect_name && input.as_slice() == table
            })
    {
        return hit;
    }
    let profile = profile_for_dialect(dialect_name);
    let point = surface_point(profile);
    let filtered: Vec<&'static [u8]> = match store_for_profile(profile).get(command) {
        Some(spec) => table
            .iter()
            .copied()
            .filter(|name| {
                if command == "array"
                    && tcl_registry::InvocationDialect::of_profile(profile)
                        .native_array_search_member_present(name)
                        == Some(false)
                {
                    return false;
                }
                spec.subcommands
                    .iter()
                    .find(|sub| sub.name.as_bytes() == *name)
                    .is_none_or(|sub| {
                        sub.surface.or(spec.surface).is_none_or(|gate| {
                            tcl_dialect::model::surface_admits(gate, Some(&point))
                        })
                    })
            })
            .collect(),
        None => table.to_vec(),
    };
    let leaked: &'static [&'static [u8]] = Vec::leak(filtered);
    cache.lock().expect("subcommand cache").push((
        command,
        dialect_name.to_string(),
        table.to_vec(),
        leaked,
    ));
    leaked
}
