// tcl-lsp — a language server and toolchain for Tcl
// Copyright (C) 2026 James Deucker (bitwisecook) <https://github.com/bitwisecook>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.
//
// SPDX-License-Identifier: AGPL-3.0-or-later

//! Oracle-pinned regression coverage for parser edge cases around word
//! delimiters and array-element writes, plus two lenient cases
//! (`missing "`, `missing close-bracket`). Every expected
//! message/errorCode/value below was taken verbatim from `tclsh9.0` (9.0.4)
//! and/or `tclsh8.6` (8.6.16); a reader can paste the sheet into a real
//! `tclsh` and re-derive the expectation without this harness.

use tcl_runtime::interp::{Code, Interp};

/// Evaluate `sheet` and return `(code, result, errorCode)`. `errorCode` is
/// read from `::errorCode`, which the outermost `eval_str` publishes on an
/// uncaught error — matching how `catch ... opts; dict get $opts -errorcode`
/// observes it in real Tcl.
fn run(sheet: &str) -> (Code, String, String) {
    let mut interp = Interp::new();
    let code = interp.eval_str(sheet.as_bytes());
    let result = String::from_utf8_lossy(&interp.result_bytes()).into_owned();
    let error_code = if code == Code::Error {
        interp.eval_str(b"set ::errorCode");
        String::from_utf8_lossy(&interp.result_bytes()).into_owned()
    } else {
        String::new()
    };
    (code, result, error_code)
}

// An unterminated `{` word must raise `missing close-brace`, not
// tokenise best-effort. Oracle: tclsh 8.6.16/9.0.4 both raise `missing
// close-brace` with `-errorcode NONE` for each of these constructs (`list`,
// `set`, `string length`).

#[test]
fn unterminated_brace_word_raises_missing_close_brace() {
    let (code, result, error_code) = run(r#"eval "list a \{ b""#);
    assert_eq!(code, Code::Error);
    assert_eq!(result, "missing close-brace");
    assert_eq!(error_code, "NONE");
}

#[test]
fn unterminated_brace_word_raises_for_set_too() {
    let (code, result, _) = run(r#"eval "set x \{ b""#);
    assert_eq!(code, Code::Error);
    assert_eq!(result, "missing close-brace");
}

#[test]
fn unterminated_brace_word_raises_for_string_length_too() {
    let (code, result, _) = run(r#"eval "string length \{ b""#);
    assert_eq!(code, Code::Error);
    assert_eq!(result, "missing close-brace");
}

/// A properly closed braced word — including one glued to a second braced
/// word (`{*}{b c}`, no unterminated construct) — parses without error.
#[test]
fn well_formed_braced_words_still_parse() {
    let (code, result, _) = run("list a {hello world} c");
    assert_eq!(code, Code::Ok);
    assert_eq!(result, "a {hello world} c");

    let (code, result, _) = run("list a {*}{b c} d");
    assert_eq!(code, Code::Ok);
    assert_eq!(result, "a b c d");
}

// An unterminated `${` inside a script word (or a script word nested
// in a command substitution) must raise `missing close-brace for variable
// name`, the same message `subst` already raises for the identical
// construct — not the lenient lexer recovery's `${a{` == name `a{` reading
// (which then fails downstream as `can't read "a{"`). Oracle: tclsh
// 8.6.16/9.0.4 both raise `missing close-brace for variable name` with
// `-errorcode NONE`.

#[test]
fn unterminated_braced_var_in_a_script_word_raises_missing_close_brace_for_var() {
    // eval "set x \"${a{\""
    let (code, result, error_code) = run("eval \"set x \\\"\\$\\{a\\{\\\"\"");
    assert_eq!(code, Code::Error);
    assert_eq!(result, "missing close-brace for variable name");
    assert_eq!(error_code, "NONE");
}

/// The same gap, nested inside a command substitution reached through
/// `subst` — `subst $t` where `t` is `[set y ${a{b]` — matching the second
/// row of the issue's table (the C parser reports the same error at every
/// nesting depth, not `can't read "a{b"`).
#[test]
fn unterminated_braced_var_nested_in_a_command_subst_raises_the_same_error() {
    // `t`'s value is the 14-byte string `[set y ${a{b]` — built through
    // `format` rather than a literal `{...}` word, since its raw text has
    // two unmatched `{` and would itself be an unterminated *outer* brace
    // word (a different case from the one this test targets).
    let (code, result, _) = run(r#"set t [format {[set y $%sa%sb]} "{" "{"]
subst $t"#);
    assert_eq!(code, Code::Error);
    assert_eq!(result, "missing close-brace for variable name");
}

/// A well-formed `${name}` (including one immediately followed by more
/// substitution) substitutes without error.
#[test]
fn well_formed_braced_var_still_substitutes() {
    let (code, result, _) = run("set a hi\nsubst {x${a}y}");
    assert_eq!(code, Code::Ok);
    assert_eq!(result, "xhiy");
}

// `lassign`, `catch` (result/options vars), `regexp` match vars,
// `scan`, `binary scan`, and `foreach`/`lmap` loop vars must write `arr(a)`
// as the array *element*, like `set` already does, not as a literal scalar
// named `arr(a)`. Oracle: tclsh 8.6.16/9.0.4 all agree `array get arr` comes
// back `a p b q` (etc.) after each of these commands targets `arr(a)`/
// `arr(b)`.

#[test]
fn lassign_writes_array_elements() {
    let (code, result, _) = run("lassign {p q} arr(a) arr(b)\narray get arr");
    assert_eq!(code, Code::Ok);
    assert_eq!(result, "a p b q");
}

#[test]
fn lassign_into_an_existing_array_scalar_target_still_errors_like_set() {
    let (code, result, _) = run("array set arr {x 1}\ncatch {lassign {1} arr} e\nset e");
    assert_eq!(code, Code::Ok);
    assert_eq!(result, "can't set \"arr\": variable is array");
}

#[test]
fn catch_writes_result_and_options_array_elements() {
    let (code, result, _) =
        run("catch {error boom} arr(a) opts(o)\nlist [array get arr] [dict get $opts(o) -code]");
    assert_eq!(code, Code::Ok);
    assert_eq!(result, "{a boom} 1");
}

#[test]
fn regexp_writes_match_vars_as_array_elements() {
    let (code, result, _) = run("regexp {(a)(b)} xabx m arr(1) arr(2)\narray get arr");
    assert_eq!(code, Code::Ok);
    assert_eq!(result, "1 a 2 b");
}

#[test]
fn scan_writes_vars_as_array_elements() {
    let (code, result, _) = run(r#"scan "12 ab" "%d %s" arr(1) arr(2)
array get arr"#);
    assert_eq!(code, Code::Ok);
    assert_eq!(result, "1 12 2 ab");
}

#[test]
fn binary_scan_writes_vars_as_array_elements() {
    let (code, result, _) = run("binary scan AB cc arr(1) arr(2)\narray get arr");
    assert_eq!(code, Code::Ok);
    assert_eq!(result, "1 65 2 66");
}

#[test]
fn foreach_writes_loop_var_as_array_element() {
    let (code, result, _) = run("foreach arr(a) {1 2} {}\narray get arr");
    assert_eq!(code, Code::Ok);
    assert_eq!(result, "a 2");
}

#[test]
fn lmap_writes_loop_var_as_array_element_too() {
    let (code, result, _) = run("lmap arr(a) {1 2} {set arr(a)}\narray get arr");
    assert_eq!(code, Code::Ok);
    assert_eq!(result, "a 2");
}

/// The zero-length-array-name spelling `(k)` — base name `""` — routes
/// through the same `split_array_ref` owner as every other element write, so
/// it comes along for free; this pins only that these six sites don't
/// bypass that owner.
#[test]
fn zero_length_array_name_spelling_routes_through_the_same_owner() {
    let (code, result, _) = run("lassign {v} (k)\narray get {}");
    assert_eq!(code, Code::Ok);
    assert_eq!(result, "k v");
}

// R10 — the two cases R4 left lenient. Both are word-delimiter failures the
// lexer recovers from (it is shared with the LSP and must keep tokenising
// half-typed source), so the eval-facing parser is the one that must fail
// closed. Before the shared `tcl_lexer::word_parts` owner landed, this
// runtime read `list a "b` as the two-word list `a b` and evaluated the `b`
// of `list a [b` as a command.
//
// Oracle (both interpreters):
//   % eval {list a "b}    => missing "                -errorcode NONE
//   % eval {list a [b}    => missing close-bracket    -errorcode NONE

#[test]
fn unterminated_quoted_word_raises_missing_quote() {
    let (code, result, error_code) = run(r#"eval {list a "b}"#);
    assert_eq!(code, Code::Error);
    assert_eq!(result, "missing \"");
    assert_eq!(error_code, "NONE");
}

#[test]
fn unterminated_quoted_word_raises_for_other_commands_too() {
    for sheet in [r#"eval {puts "a}"#, r#"eval {set x "a}"#] {
        let (code, result, _) = run(sheet);
        assert_eq!(code, Code::Error, "{sheet}");
        assert_eq!(result, "missing \"", "{sheet}");
    }
}

#[test]
fn unterminated_command_substitution_raises_missing_close_bracket() {
    let (code, result, error_code) = run("eval {list a [b}");
    assert_eq!(code, Code::Error);
    assert_eq!(result, "missing close-bracket");
    assert_eq!(error_code, "NONE");
}

/// The same failure through `subst`, where C reports it *after* the earlier
/// bracket in the template has already run and kept its side effects — the
/// left-to-right order `WordPart::ParseError` exists to preserve.
///
/// Oracle: `proc side {} {puts ran; return S}; subst {[side][b}` prints `ran`
/// and then raises `missing close-bracket` on 8.6.16 and 9.0.4.
#[test]
fn subst_reports_the_missing_bracket_after_running_the_earlier_one() {
    let (code, result, _) = run("set ::ran 0\nproc side {} {set ::ran 1; return S}\ncatch {subst {[side][b}} e\nlist $::ran $e");
    assert_eq!(code, Code::Ok);
    assert_eq!(result, "1 {missing close-bracket}");
}

/// An unterminated `$name(` array index is C's `missing )` — the third
/// delimiter failure the same owner spells, rather than being read as a
/// scalar literally named `x(`.
///
/// Oracle: `eval {list a $x(}` and `subst {$x(}` both give `missing )`.
#[test]
fn unterminated_array_index_raises_missing_paren() {
    for sheet in ["eval {list a $x(}", "subst {$x(}"] {
        let (code, result, _) = run(sheet);
        assert_eq!(code, Code::Error, "{sheet}");
        assert_eq!(result, "missing )", "{sheet}");
    }
}

/// Well-formed quoted, bracketed and array-index words are unaffected: the
/// close checks must not fire on a `"` inside a command substitution, a `]`
/// inside a braced or quoted word of the substituted script, or a `)` closing
/// a nested index.
#[test]
fn well_formed_quoted_and_bracketed_words_still_parse() {
    for (sheet, want) in [
        (r#"list a "b c" d"#, "a {b c} d"),
        (r#"set x [string cat "a" "b"]"#, "ab"),
        (r#"subst {[list {a]b}]}"#, r"a\]b"),
        (r#"subst {[list "a]b"]}"#, r"a\]b"),
        (
            "set c(1) inner\nset b(inner) mid\nset a(mid) outer\nsubst {$a($b($c(1)))}",
            "outer",
        ),
    ] {
        let (code, result, _) = run(sheet);
        assert_eq!(code, Code::Ok, "{sheet}: {result}");
        assert_eq!(result, want, "{sheet}");
    }
}

// `regsub`'s target variable has the identical shape: `arr(k)` must write
// the array *element*, not a literal scalar named `arr(k)`. Oracle: tclsh
// 8.6.16/9.0.4 both give `array get arr` => `k xbx` after `regsub -all a $s
// b arr(k)` on `s = xax`.

#[test]
fn regsub_writes_its_target_variable_as_an_array_element() {
    let (code, result, _) = run("set s xax\nregsub -all a $s b arr(k)\narray get arr");
    assert_eq!(code, Code::Ok);
    assert_eq!(result, "k xbx");
}

// Text welded straight onto a `{…}` word's close-brace. The boundary
// question is `tcl_lexer::script::group_commands`'s, which records the
// weld as `WordSpan::welded_after_close`; this eval-facing engine turns it
// into C's hard error. Without that, this crate and the compiler's
// segmenter could disagree on the same input — this crate reading `{a}$b`
// as one welded `Bare` word, the segmenter splitting it into two — even
// though C accepts neither.
//
// Oracle, measured on tclsh 8.4.20 / 8.5.19 / 8.6.16 / 9.0.4 / 9.1b0 — every
// row identical on every release:
//
//   {a}b        {a}$b       {a}[b]      {}x        {a}{b}      {a}{*}$b
//   set x {a}b              set x {a}{*}$y         list {a}{*}$b
//     -> code 1, `extra characters after close-brace`, -errorcode NONE
//
// and it is a *parse*-time failure of the command: `set x {a}[side]` leaves
// `x` unset without running `side`. Earlier commands of the same script have
// already run, since `Tcl_EvalEx` parses one command at a time — pinned below
// by `sfx pre`.
//
// C parses every word of a command before substituting any, so `list [side]
// {a}b` never runs `side` — pinned below by
// `a_command_parses_whole_before_any_of_its_words_substitute`.
//
// Not welded, and still accepted (measured the same on 8.6.16 / 9.0.4):
// `a{b}c`, `x{a}y`, `$a{b}c`, `[b]{c}d` — a `{` away from word start is an
// ordinary literal byte, and the lexer never emits a `Str` token for it — and
// `{a} {b}` / `list a {*}{b c} d`, which have a real separator between them.

/// Every welded shape raises C's message, with `-errorcode NONE`.
#[test]
fn text_welded_onto_a_close_brace_raises_extra_characters() {
    for sheet in [
        "{a}b",
        "{a}$b",
        "{a}[b]",
        "{}x",
        "{a}{b}",
        "{a}{*}$b",
        "set x {a}b",
        "set x {a}{*}$y",
        "list {a}{*}$b",
        "list [list a] {a}b",
    ] {
        let (code, result, error_code) = run(sheet);
        assert_eq!(code, Code::Error, "{sheet}");
        assert_eq!(result, "extra characters after close-brace", "{sheet}");
        assert_eq!(error_code, "NONE", "{sheet}");
    }
}

/// The failure is the *command's*, not the word's: nothing the command would
/// have substituted runs, and the variable it would have written stays unset —
/// while a command earlier in the same script has already run and kept its
/// effect.
#[test]
fn a_welded_close_brace_fails_the_command_before_it_substitutes_anything() {
    let (code, result, _) = run("set ::ran {}\n\
         proc sfx {t} { lappend ::ran $t; return S$t }\n\
         sfx pre\n\
         set ::x {a}[sfx inner]");
    assert_eq!(code, Code::Error);
    assert_eq!(result, "extra characters after close-brace");

    // The same sheet under `catch`, so the interpreter survives to be asked
    // what actually ran: `pre` (an earlier command) yes, `inner` (a word of
    // the failing command) no, and `::x` was never written.
    let (code, result, _) = run("set ::ran {}\n\
         proc sfx {t} { lappend ::ran $t; return S$t }\n\
         sfx pre\n\
         catch {set ::x {a}[sfx inner]} e\n\
         list $e $::ran [info exists ::x]");
    assert_eq!(code, Code::Ok);
    assert_eq!(
        result, "{extra characters after close-brace} pre 0",
        "tclsh 8.6.16/9.0.4: the error, only `pre` ran, `x` unset"
    );
}

/// A `{` that is not at the start of a word is an ordinary literal byte, and a
/// real separator between two braced words is not a weld — neither may trip
/// the new error.
#[test]
fn a_brace_away_from_word_start_or_after_a_separator_is_not_a_weld() {
    for (sheet, want) in [
        ("list a{b}c", "a{b}c"),
        ("list x{a}y", "x{a}y"),
        ("set a A\nlist $a{b}c", "A{b}c"),
        ("list [list q]{c}d", "q{c}d"),
        ("list {a} {b}", "a b"),
        ("list a {*}{b c} d", "a b c d"),
        ("list {a}", "a"),
    ] {
        let (code, result, _) = run(sheet);
        assert_eq!(code, Code::Ok, "{sheet}: {result}");
        assert_eq!(result, want, "{sheet}");
    }
}

// C's script-parsing ORDER. `Tcl_EvalEx` parses one whole command
// (`Tcl_ParseCommand`, every word of it) and only then substitutes and
// dispatches, so a parse failure anywhere in a command is the *command's*
// failure: nothing that command would have substituted runs, however early in
// the command it sits. And `Tcl_ParseCommand`'s `ParseTokens` recurses into a
// `[…]`, parsing the substituted script's own commands, so an error nested
// inside a later bracket also stops an earlier bracket — and stops the earlier
// commands *inside* the failing bracket too.
//
// Property (1) — earlier commands of the script have already run — holds
// through `parse.rs`'s `next`-offset `Command` and the per-command loop in
// `interp.rs`; every row below pins it as well, through the `sfx pre` that
// always shows up in `ran`.
//
// Oracle: `PARSE_ORDER_SHEET` below, saved to a file and run as
// `tclsh sheet.tcl` (FROM A FILE — a stdin-fed tclsh swallows the error text)
// on tclsh 8.6.16 and tclsh 9.0.4. Both shells produced `PARSE_ORDER_ORACLE`
// byte for byte; paste the sheet into either shell to re-derive it without this
// harness. The sheet builds its `${abc` rows with `format` because a sheet that
// spelled `${` inside a braced `catch`/`probe` word would itself be an
// unbalanced brace group.

/// The oracle sheet, verbatim. `$ob` is a literal `{`.
const PARSE_ORDER_SHEET: &str = r#"set ob "\173"
set ::out {}
proc sfx {t} { lappend ::ran $t; return S$t }
proc probe {name script} {
    set ::ran {}
    # `lindex` rather than `expr`/`if`: without libtommath there is no
    # bignum tower, so neither command is registered, and this sheet has
    # nothing to do with arithmetic. `catch` answers 0 or 1 here, and any
    # other completion code would surface as an empty verb rather than
    # being silently folded into "error".
    set verb [lindex {ok error} [catch {uplevel 1 $script} e]]
    lappend ::out "$name -> $verb {$e} ran {$::ran}"
}
probe welded        {sfx pre; list [sfx inner] {a}b}
probe quote         {sfx pre; list [sfx inner] "unterminated}
probe bracket       {sfx pre; list [sfx inner] [sfx two}
probe braced-var    [format {sfx pre; list [sfx inner]pre$%sabc} $ob]
probe nested-quote  {sfx pre; list [sfx inner] [list "oops]}
probe nested-var    [format {sfx pre; list [sfx inner] [set y "a$%sbcd"]} $ob]
probe nested-weld   {sfx pre; list [sfx inner] [set y {a}b]}
probe two-cmd-brkt  [format {sfx pre; list [sfx one; set y "a$%sbcd"]} $ob]
probe var-first     [format {sfx pre; list $nosuchvar [set y "a$%sbcd"]} $ob]
probe runtime-err   {sfx pre; list [sfx inner] [set y $nosuchvar]}
probe all-well      {sfx pre; list [sfx inner] [list ok]}
probe quote-weld    {sfx pre; list [sfx inner] "a"b}
probe empty-quote-weld {sfx pre; list [sfx inner] ""b}
probe nested-quote-weld {sfx pre; list [sfx inner] [set y "a"b]}
join $::out \n"#;

/// tclsh 8.6.16 and tclsh 9.0.4, identical.
const PARSE_ORDER_ORACLE: &str = r#"welded -> error {extra characters after close-brace} ran {pre}
quote -> error {missing "} ran {pre}
bracket -> error {missing close-bracket} ran {pre}
braced-var -> error {missing close-brace for variable name} ran {pre}
nested-quote -> error {missing "} ran {pre}
nested-var -> error {missing close-brace for variable name} ran {pre}
nested-weld -> error {extra characters after close-brace} ran {pre}
two-cmd-brkt -> error {missing close-brace for variable name} ran {pre}
var-first -> error {missing close-brace for variable name} ran {pre}
runtime-err -> error {can't read "nosuchvar": no such variable} ran {pre inner}
all-well -> ok {Sinner ok} ran {pre inner}
quote-weld -> error {extra characters after close-quote} ran {pre}
empty-quote-weld -> error {extra characters after close-quote} ran {pre}
nested-quote-weld -> error {extra characters after close-quote} ran {pre}"#;

/// Every row of the sheet, against the recorded shells.
///
/// The two rows that are *not* parse failures are the guard against
/// over-rejecting: `runtime-err` (a well-formed later bracket that fails at run
/// time) and `all-well` both still run the earlier `[sfx inner]`, so the
/// pre-scan may not turn a runtime error — or a healthy command — into a
/// parse-time abort.
#[test]
fn a_command_parses_whole_before_any_of_its_words_substitute() {
    let (code, result, _) = run(PARSE_ORDER_SHEET);
    assert_eq!(code, Code::Ok, "{result}");
    assert_eq!(result, PARSE_ORDER_ORACLE);
}

/// `subst` is the deliberate non-consumer: it is not a command parse, so C
/// substitutes its template left to right and keeps the side effects of every
/// `[…]` that ran before the failure. Pinned separately above by
/// `subst_reports_the_missing_bracket_after_running_the_earlier_one`; repeated
/// here next to its opposite so the pair cannot drift apart.
///
/// Oracle (8.6.16 / 9.0.4): `1 {missing close-bracket}` — `side` ran.
#[test]
fn subst_is_not_a_command_parse_and_still_runs_the_earlier_bracket() {
    let (code, result, _) = run("set ::ran 0\n\
         proc side {} {set ::ran 1; return S}\n\
         catch {subst {[side][b}} e\n\
         list $::ran $e");
    assert_eq!(code, Code::Ok);
    assert_eq!(result, "1 {missing close-bracket}");
}

// A `$` that starts no variable reference is the text `$`, not an unterminated
// brace. C reads it as `justADollarSign` and keeps parsing
// (`Tcl_ParseVarName` form 3, tmp/tcl9.0.4/generic/tclParse.c:1454); a parser
// that classified it as a brace-delimited fragment — treating `Str` as its
// brace class rather than its literal-fragment class — would instead raise
// `missing close-brace` for ordinary source. Oracle: every row below is the
// plain text on 8.4.20, 8.5.19, 8.6.16, 9.0.4 and 9.1b0.

/// `$` alone, `$` before punctuation, `$` before a space, `$` at end of a
/// word — bare and quoted, since the two take different paths through
/// `build_word`.
const BARE_DOLLAR_SHEET: &str = r#"
set out {}
lappend out [string cat "$"]
lappend out [string cat "50% of $"]
lappend out [string cat "a$ b"]
lappend out [string cat a$%b]
lappend out [string cat "a$%^&b"]
lappend out [string cat {a$%b}]
lappend out [llength [list $ x]]
join $out |
"#;

#[test]
fn a_dollar_that_starts_no_reference_is_literal_text() {
    let (code, result, _) = run(BARE_DOLLAR_SHEET);
    assert_eq!(code, Code::Ok, "{result}");
    assert_eq!(result, "$|50% of $|a$ b|a$%b|a$%^&b|a$%b|2");
}

/// An unterminated quoted word reports what failed *inside* it first.
///
/// `quoted_word_close` steps over complete `[…]` substitutions to find the
/// closer, so an incomplete one makes it give up — but C, parsing the word's
/// tokens left to right, has already failed in the bracket. Oracle, one
/// script per `tclsh` run on 8.6.16 and 9.0.4:
///
/// ```text
/// puts "[foo"        -> missing close-bracket
/// puts "a[foo b"     -> missing close-bracket
/// puts "unterminated -> missing "
/// list a "b          -> missing "
/// ```
#[test]
fn an_unterminated_quote_reports_the_failure_inside_it_first() {
    for (script, want) in [
        ("puts \"[foo\"", "missing close-bracket"),
        ("puts \"a[foo b\"", "missing close-bracket"),
        ("puts \"unterminated", "missing \""),
        ("list a \"b", "missing \""),
    ] {
        let (code, result, _) = run(script);
        assert_eq!((code, result.as_str()), (Code::Error, want), "{script}");
    }
    // A *complete* bracket in an unterminated quote still reaches evaluation
    // before the quote's own error, exactly as C does.
    let (code, result, _) = run("puts \"a[nosuchcmd]b\"");
    assert_eq!(code, Code::Error);
    assert!(result.contains("nosuchcmd"), "{result}");
}

/// The fix must not blunt the real one. Oracle, measured one script per
/// `tclsh` run on 8.6.16 and 9.0.4:
///
/// ```text
/// set y {unclosed  -> missing close-brace
/// list a {b {c     -> missing close-brace
/// set y {a}b       -> extra characters after close-brace
/// set y x{a}{b     -> ok, y is x{a}{b
/// ```
///
/// The last row is the one the opening-byte test has to keep right: a `{`
/// that is not at word start is ordinary data, so `x{a}{b` has nothing to
/// close and must not be read as a brace-delimited fragment at all.
#[test]
fn a_brace_that_really_is_one_still_raises() {
    for (script, want) in [
        ("set y {unclosed", "missing close-brace"),
        ("list a {b {c", "missing close-brace"),
        ("set y {a}b", "extra characters after close-brace"),
    ] {
        let (code, result, _) = run(script);
        assert_eq!((code, result.as_str()), (Code::Error, want), "{script}");
    }
    let (code, result, _) = run("set y x{a}{b");
    assert_eq!((code, result.as_str()), (Code::Ok, "x{a}{b"));
}

// Text welded straight onto a `"…"` word's close-quote, the sibling of
// the close-brace weld above. The boundary owner records it as
// `WordSpan::welded_after_close_quote`; this eval-facing engine turns it into
// C's hard error. This is the one shape `tests/parse_cut_agreement.rs` pins:
// `tcl_lexer::first_parse_cut` reports it from source, and concatenating
// `"a"b` to `ab` instead would be the divergence.
//
// Oracle, measured on tclsh 8.4.20 / 8.5.19 / 8.6.16 / 9.0.4 / 9.1b0, one
// script per file — every row identical on every release:
//
//   "a"b     ""b     "a"$b     "a"[b]     "a"{b}     "a""b"     "a\"b"c
//   "a[list b]"c     "a$x"b     "$x"b     "a$"b     "a"\ b     "a"]     "a"}
//   set y "a"b       set y ""b        list [list a] "a"b       list "q"{*}$z
//     -> code 1, `extra characters after close-quote`, -errorcode NONE
//
// and, as for the brace, it is a *parse*-time failure of the whole command:
// `set ::x "a"[sfx inner]` leaves `x` unset and never runs `sfx`, while the
// earlier `sfx pre` has run (`Tcl_EvalEx` parses one command at a time).
//
// Not welds, and still accepted (measured the same on 8.6.16 / 9.0.4): `"$"`
// is the text `$` (C's `justADollarSign`) — the empty-content clamp the owner
// has to read correctly, since the `"$` token's span sits on the `$`, not on a
// closer; a `"` inside a bare word (`a"b"c`) is literal; a separator or a
// backslash-newline after the `"` starts a new word; an empty `""` on its own
// is the empty string.

/// Every welded shape raises C's message, with `-errorcode NONE`.
#[test]
fn text_welded_onto_a_close_quote_raises_extra_characters() {
    for sheet in [
        "\"a\"b",
        "\"\"b",
        "\"a\"$b",
        "\"a\"[b]",
        "\"a\"{b}",
        "\"a\"\"b\"",
        "\"a\\\"b\"c",
        "\"a[list b]\"c",
        "set x X\n\"a$x\"b",
        "set x X\n\"$x\"b",
        "\"a$\"b",
        "\"a\"\\ b",
        "\"a\"]",
        "\"a\"}",
        "set y \"a\"b",
        "set y \"\"b",
        "list [list a] \"a\"b",
        "list \"q\"{*}$z",
    ] {
        let (code, result, error_code) = run(sheet);
        assert_eq!(code, Code::Error, "{sheet}");
        assert_eq!(result, "extra characters after close-quote", "{sheet}");
        assert_eq!(error_code, "NONE", "{sheet}");
    }
}

/// The failure is the command's: nothing it would have substituted runs and
/// its target stays unset, while the earlier command has run.
///
/// Oracle (8.6.16 / 9.0.4): `{extra characters after close-quote} pre 0` for
/// both the `"a"` and the empty-`""` spelling.
#[test]
fn a_welded_close_quote_fails_the_command_before_it_substitutes_anything() {
    for weld in ["\"a\"", "\"\""] {
        let sheet = format!(
            "set ::ran {{}}\n\
             proc sfx {{t}} {{ lappend ::ran $t; return S$t }}\n\
             sfx pre\n\
             catch {{set ::x {weld}[sfx inner]}} e\n\
             list $e $::ran [info exists ::x]"
        );
        let (code, result, _) = run(&sheet);
        assert_eq!(code, Code::Ok, "{weld}: {result}");
        assert_eq!(
            result, "{extra characters after close-quote} pre 0",
            "{weld}"
        );
    }
}

/// A `"` away from word start, a `$` that names nothing, an empty `""`, and a
/// real separator after the closer are not welds — none may trip the new
/// error.
#[test]
fn a_quote_away_from_word_start_or_after_a_separator_is_not_a_weld() {
    for (sheet, want) in [
        ("string cat a\"b\"c", "a\"b\"c"),
        ("set a A\nstring cat $a\"b\"c", "A\"b\"c"),
        ("list \"a\" \"b\"", "a b"),
        ("list \"a\"", "a"),
        ("string cat \"$\"", "$"),
        ("string cat \"a$ b\"", "a$ b"),
        ("string length \"\"", "0"),
        ("list \"a\"\\\nb", "a b"),
        ("set x X\nstring cat \"$x\"", "X"),
        ("string cat \"a[list b]\"", "ab"),
    ] {
        let (code, result, _) = run(sheet);
        assert_eq!(code, Code::Ok, "{sheet}: {result}");
        assert_eq!(result, want, "{sheet}");
    }
}
