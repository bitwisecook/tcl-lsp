// tcl-lsp — a language server and toolchain for Tcl
// Copyright (C) 2026 James Deucker (bitwisecook) <https://github.com/bitwisecook>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.
//
// SPDX-License-Identifier: AGPL-3.0-or-later

//! The C ABI through which a host that runs this runtime compiled to `wasm32`
//! drives it as an engine (`rust/tcl-engine-wasm`). It offers what
//! `crate::engine` does natively, for a host on the far side of the module
//! boundary that reaches the interpreter only by exports: the limits, the
//! confinement, the whitelist, the pinned release, a unit's procedure, a
//! provided package, and a host command's `return` and error.
//!
//! Every object argument is borrowed; an object answered is owned by the
//! caller.

use core::ffi::{c_char, c_int};

use crate::budget::LimitKind;
use crate::interp::{Code, Interp, new_string};
use crate::obj::{TclObj, decr_ref_count, incr_ref_count};

const TCL_OK: c_int = 0;
const TCL_ERROR: c_int = 1;

/// The limit kinds as the ABI numbers them: 1 the command count, 2 the wall
/// clock, 3 the value size.
fn kind_number(kind: LimitKind) -> c_int {
    match kind {
        LimitKind::Commands => 1,
        LimitKind::WallClock => 2,
        LimitKind::ValueSize => 3,
    }
}

/// The limit kind `number` names, as [`kind_number`] numbers them.
fn kind_of(number: c_int) -> Option<LimitKind> {
    match number {
        1 => Some(LimitKind::Commands),
        2 => Some(LimitKind::WallClock),
        3 => Some(LimitKind::ValueSize),
        _ => None,
    }
}

/// `tcl_engine_set_limits(interp, commands, value_bytes)` — the command count
/// and value-size limits every later evaluation runs under; a negative value
/// leaves that limit off. The wall clock is the host's to keep, by the epoch.
///
/// # Safety
/// `interp` must be live.
#[no_mangle]
pub unsafe extern "C" fn tcl_engine_set_limits(
    interp: *mut Interp,
    commands: i64,
    value_bytes: i64,
) {
    // SAFETY: caller guarantees a live interpreter.
    let interp = unsafe { &*interp };
    interp.set_limits(
        u64::try_from(commands).ok(),
        None,
        u64::try_from(value_bytes).ok(),
    );
}

/// `tcl_engine_begin(interp)` — begin an evaluation under the limits.
///
/// # Safety
/// `interp` must be live.
#[no_mangle]
pub unsafe extern "C" fn tcl_engine_begin(interp: *mut Interp) {
    // SAFETY: caller guarantees a live interpreter.
    unsafe {
        (*interp).reset_native_compilation_admission();
        (*interp).begin_evaluation();
    }
}

/// `tcl_engine_exceeded(interp) -> kind` — the limit the evaluation outran
/// (1 commands, 2 wall clock, 3 value size), or 0.
///
/// # Safety
/// `interp` must be live.
#[no_mangle]
pub unsafe extern "C" fn tcl_engine_exceeded(interp: *mut Interp) -> c_int {
    // SAFETY: caller guarantees a live interpreter.
    unsafe { (*interp).limit_exceeded() }.map_or(0, kind_number)
}

/// `tcl_engine_exceed(interp, kind) -> TCL_ERROR` — record that host work for
/// the evaluation outran the limit `kind` numbers, and raise its error. A
/// number that names no limit is the command count.
///
/// # Safety
/// `interp` must be live.
#[no_mangle]
pub unsafe extern "C" fn tcl_engine_exceed(interp: *mut Interp, kind: c_int) -> c_int {
    let kind = kind_of(kind).unwrap_or(LimitKind::Commands);
    // SAFETY: caller guarantees a live interpreter.
    let code = unsafe { (*interp).exceed_limit(kind) };
    c_int::try_from(code.as_int()).unwrap_or(TCL_ERROR)
}

/// `tcl_engine_commands_spent(interp) -> count` — the commands the evaluation
/// dispatched.
///
/// # Safety
/// `interp` must be live.
#[no_mangle]
pub unsafe extern "C" fn tcl_engine_commands_spent(interp: *mut Interp) -> i64 {
    // SAFETY: caller guarantees a live interpreter.
    i64::try_from(unsafe { (*interp).commands_since_begin() }).unwrap_or(i64::MAX)
}

/// `tcl_engine_confine_stores(interp)` — refuse every store outside the
/// running procedure's frame, and remove the globals the host seeded.
///
/// # Safety
/// `interp` must be live.
#[no_mangle]
pub unsafe extern "C" fn tcl_engine_confine_stores(interp: *mut Interp) {
    // SAFETY: caller guarantees a live interpreter.
    unsafe { (*interp).confine_stores() }
}

/// `tcl_engine_restrict(interp, allowed, kept)` — keep only the commands the
/// list `allowed` names, by the engine's whitelist rule, and those the list
/// `kept` names.
///
/// # Safety
/// `interp` must be live; `allowed` and `kept` live objects.
#[no_mangle]
pub unsafe extern "C" fn tcl_engine_restrict(
    interp: *mut Interp,
    allowed: *mut TclObj,
    kept: *mut TclObj,
) {
    // SAFETY: caller guarantees the live interpreter and original list objects.
    let interp = unsafe { &mut *interp };
    if interp.admit_restriction_purpose().is_err() {
        return;
    }
    let names = interp
        .restriction_unicode_names(allowed)
        .and_then(|allowed| {
            interp
                .restriction_unicode_names(kept)
                .map(|kept| (allowed, kept))
        });
    let (allowed, kept) = match names {
        Ok(names) => names,
        Err(error) => {
            interp.refuse_restriction_input(error);
            return;
        }
    };
    let allowed: Vec<&str> = allowed.iter().map(String::as_str).collect();
    // This compatibility ABI is void: its typed first cause is retained by the
    // interpreter and must be inspected with the host-refusal query.
    let _ = interp.restrict_to(&allowed, &kept);
}

/// `tcl_engine_set_release(interp, profile, length) -> status` — pin the
/// release the profile `profile[..length]` names: `TCL_OK`, or `TCL_ERROR` for
/// a name that is no release the runtime runs.
///
/// # Safety
/// `interp` must be live; `profile` must reference `length` readable bytes.
#[no_mangle]
pub unsafe extern "C" fn tcl_engine_set_release(
    interp: *mut Interp,
    profile: *const c_char,
    length: c_int,
) -> c_int {
    let length = usize::try_from(length).unwrap_or(0);
    // SAFETY: the caller guarantees `length` readable bytes.
    let bytes = unsafe { core::slice::from_raw_parts(profile.cast::<u8>(), length) };
    let Ok(profile) = core::str::from_utf8(bytes) else {
        return TCL_ERROR;
    };
    // SAFETY: caller guarantees a live interpreter.
    match unsafe { (*interp).pin_release(profile) } {
        Some(_) => TCL_OK,
        None => TCL_ERROR,
    }
}

/// `tcl_engine_define_unit(interp, name, params, body) -> status` — define the
/// procedure a compiled unit is, without the `proc` command a whitelist may
/// have removed: `TCL_ERROR` for a parameter list `proc` would refuse.
///
/// # Safety
/// `interp` must be live; `name`, `params` and `body` live objects.
#[no_mangle]
pub unsafe extern "C" fn tcl_engine_define_unit(
    interp: *mut Interp,
    name: *mut TclObj,
    params: *mut TclObj,
    body: *mut TclObj,
) -> c_int {
    // SAFETY: caller guarantees a live interpreter and borrowed original objects.
    match define_unit_original(unsafe { &mut *interp }, name, params, body) {
        Ok(_) => TCL_OK,
        Err(code) => code,
    }
}

/// Read a borrowed ABI original without publishing after a reached Host cause.
fn original_input_bytes(
    interp: &mut Interp,
    original: *mut TclObj,
) -> Result<std::rc::Rc<[u8]>, tcl_runtime_api::NativeExecutionError> {
    if let Some(cause) = interp.native_execution_refusal() {
        return Err(cause);
    }
    crate::obj::check_native_liveness(original)
        .map_err(|error| interp.refuse_completion_value_access(error))?;
    // The allocation lease preserves memory across an updater without adding a
    // native reference or changing the original object's shared/unshared role.
    let original = crate::obj::NativeObjectLifetime::retain(original);
    let bytes = interp
        .native_object_string_bytes(original.as_ptr())
        .map_err(|error| interp.refuse_completion_value_access(error))?;
    crate::obj::check_native_liveness(original.as_ptr())
        .map_err(|error| interp.refuse_completion_value_access(error))?;
    if let Some(cause) = interp.native_execution_refusal() {
        return Err(cause);
    }
    Ok(bytes)
}

/// Common ordinary-procedure producer; status adapters retain its exact cause.
fn define_unit_original(
    interp: &mut Interp,
    name: *mut TclObj,
    params: *mut TclObj,
    body: *mut TclObj,
) -> Result<u64, c_int> {
    let _scope = match crate::interp::native_operation_currency::NativeOperationScope::enter(interp)
    {
        Ok(scope) => scope,
        Err(cause) => {
            interp.refuse_native_execution(cause);
            return Err(TCL_ERROR);
        }
    };
    let name = original_input_bytes(interp, name).map_err(|_| TCL_ERROR)?;
    let chosen_body = interp
        .choose_original_procedure_body(body)
        .map_err(|error| {
            i32::try_from(interp.report_cmd_error(error.into()).as_int()).unwrap_or(TCL_ERROR)
        })?;
    if interp.host_refusal_pending() {
        return Err(TCL_ERROR);
    }
    let parameters =
        crate::cmd_proc::parse_params_object(interp, params, &name).map_err(|error| {
            i32::try_from(interp.report_cmd_error(error).as_int()).unwrap_or(TCL_ERROR)
        })?;
    if interp.host_refusal_pending() {
        return Err(TCL_ERROR);
    }
    let generation = interp.install_proc_chosen_storage(
        &name,
        parameters,
        Some(params),
        (body, chosen_body),
        None,
        None,
    );
    if _scope.currency().ensure_current_or_refuse().is_err() {
        Err(TCL_ERROR)
    } else {
        generation.ok_or(TCL_ERROR)
    }
}

/// `tcl_engine_provide_package(interp, name, version) -> status` — what
/// `package provide name version` does, for a host outside any command or
/// inside one: `TCL_ERROR`, with the result and error code `package provide`
/// gives, for a version that is not one or a package provided at another.
///
/// # Safety
/// `interp` must be live; `name` and `version` live objects.
#[no_mangle]
pub unsafe extern "C" fn tcl_engine_provide_package(
    interp: *mut Interp,
    name: *mut TclObj,
    version: *mut TclObj,
) -> c_int {
    // SAFETY: caller guarantees a live interpreter.
    let interp = unsafe { &mut *interp };
    let _scope = match crate::interp::native_operation_currency::NativeOperationScope::enter(interp)
    {
        Ok(scope) => scope,
        Err(cause) => {
            interp.refuse_native_execution(cause);
            return TCL_ERROR;
        }
    };
    let Ok(name) = original_input_bytes(interp, name) else {
        return TCL_ERROR;
    };
    let Ok(version) = original_input_bytes(interp, version) else {
        return TCL_ERROR;
    };
    match crate::cmd_package::provide_package(interp, &name, &version) {
        Code::Ok => TCL_OK,
        _ => TCL_ERROR,
    }
}

/// Return an owned byte-exact error-code object: implicit absence is `NONE`,
/// while an explicitly empty code remains empty. A getter or existing Host
/// refusal returns null and retains the interpreter's first typed cause.
///
/// # Safety
/// `interp` must be live. A null result must be settled through the Host channel
/// before accessing an object; otherwise the caller releases the returned hold.
#[no_mangle]
pub unsafe extern "C" fn tcl_engine_error_code(interp: *mut Interp) -> *mut TclObj {
    // SAFETY: caller guarantees a live interpreter.
    let code = match unsafe { (*interp).error_code_bytes_checked() } {
        Ok(code) => code,
        Err(_) => return core::ptr::null_mut(),
    };
    let object = new_string(&code);
    // SAFETY: a fresh object; the hold is the caller's.
    unsafe { incr_ref_count(object) };
    object
}

/// `tcl_engine_fail(interp, message, code) -> TCL_ERROR` — the error a host
/// command fails with, as a C command reports one: its message, and its
/// `-errorcode` when `code` is not null (`NONE` when it is).
///
/// # Safety
/// `interp` must be live; `message` a live object, and `code` one or null.
#[no_mangle]
pub unsafe extern "C" fn tcl_engine_fail(
    interp: *mut Interp,
    message: *mut TclObj,
    code: *mut TclObj,
) -> c_int {
    // SAFETY: caller guarantees a live interpreter.
    let interp = unsafe { &mut *interp };
    let _scope = match crate::interp::native_operation_currency::NativeOperationScope::enter(interp)
    {
        Ok(scope) => scope,
        Err(cause) => {
            interp.refuse_native_execution(cause);
            return TCL_ERROR;
        }
    };
    let code = if code.is_null() {
        None
    } else {
        let Ok(code) = original_input_bytes(interp, code) else {
            return TCL_ERROR;
        };
        Some(code)
    };
    let Ok(message) = original_input_bytes(interp, message) else {
        return TCL_ERROR;
    };
    interp.c_api_error(&message, code.as_deref());
    let _ = _scope.currency().ensure_current_or_refuse();
    TCL_ERROR
}

/// `tcl_engine_return(interp, options, value) -> code` — what `return -options
/// options value` does: the completion a host command answers with a
/// `TCL_RETURN` carrying options.
///
/// # Safety
/// `interp` must be live; `options` and `value` live objects.
#[no_mangle]
pub unsafe extern "C" fn tcl_engine_return(
    interp: *mut Interp,
    options: *mut TclObj,
    value: *mut TclObj,
) -> c_int {
    // SAFETY: caller guarantees a live interpreter.
    let interp = unsafe { &mut *interp };
    let words = [
        new_string(b"return"),
        new_string(b"-options"),
        options,
        value,
    ];
    for &word in &words {
        // SAFETY: each word is live; the call holds it.
        unsafe { incr_ref_count(word) };
    }
    let code: Code = crate::builtins::ret(interp, &words);
    for &word in &words {
        // SAFETY: balances the hold above.
        unsafe { decr_ref_count(word) };
    }
    c_int::try_from(code.as_int()).unwrap_or(TCL_ERROR)
}

#[cfg(test)]
mod procedure_publication_tests {
    use super::*;

    thread_local! {
        static PUBLICATION_INTERP: std::cell::RefCell<Option<crate::interp::WeakInterp>> = const { std::cell::RefCell::new(None) };
        static PUBLICATION_UPDATES: std::cell::Cell<usize> = const { std::cell::Cell::new(0) };
        static PUBLICATION_LATER: std::cell::Cell<usize> = const { std::cell::Cell::new(0) };
    }
    extern "C" fn publication_updater(original: *mut TclObj) {
        PUBLICATION_UPDATES.with(|calls| calls.set(calls.get() + 1));
        let mut interpreter = PUBLICATION_INTERP
            .with(|slot| slot.borrow().as_ref().unwrap().upgrade())
            .unwrap();
        let original_context = interpreter.runtime_context();
        let mut changed = original_context.clone();
        changed.packages = vec![("abi-publication".into(), "1.0".into())];
        interpreter.pin_context(&changed).unwrap();
        interpreter.pin_context(&original_context).unwrap();
        // SAFETY: the actual extension updater owns its reached String stage.
        unsafe { crate::obj::set_string_rep(original, b"blocked") };
    }
    extern "C" fn publication_later(original: *mut TclObj) {
        PUBLICATION_LATER.with(|calls| calls.set(calls.get() + 1));
        // SAFETY: this extension updater receives its original live header.
        unsafe { crate::obj::set_string_rep(original, b"1.0") };
    }
    static PUBLICATION_UPDATER: crate::obj::TclObjType = crate::obj::TclObjType {
        name: c"testPublicationEpoch".as_ptr(),
        free_int_rep_proc: None,
        dup_int_rep_proc: None,
        update_string_proc: Some(publication_updater),
        set_from_any_proc: None,
    };
    static PUBLICATION_LATER_TYPE: crate::obj::TclObjType = crate::obj::TclObjType {
        name: c"testPublicationLater".as_ptr(),
        free_int_rep_proc: None,
        dup_int_rep_proc: None,
        update_string_proc: Some(publication_later),
        set_from_any_proc: None,
    };
    #[test]
    fn original_publication_getter_context_change_stops_later_inputs_and_mutation() {
        // naming.embedding.original-host-publication-and-fact-transport
        // docs/design/analysis/name-resolution-proofs/embedding-original-host-publication-and-fact-transport.md
        // Real extension callbacks and original borrowed headers; this is a
        // software currency control, independent of native source admission.
        for route in 0..3 {
            let mut interpreter = Interp::new();
            interpreter.set_runtime_version(tcl_dialect::TclVersion::V8_6);
            PUBLICATION_INTERP.with(|slot| *slot.borrow_mut() = Some(interpreter.downgrade()));
            PUBLICATION_UPDATES.with(|calls| calls.set(0));
            PUBLICATION_LATER.with(|calls| calls.set(0));
            let original =
                crate::obj::Owned::fresh(crate::obj::alloc_typed(&PUBLICATION_UPDATER, 0));
            let later =
                crate::obj::Owned::fresh(crate::obj::alloc_typed(&PUBLICATION_LATER_TYPE, 0));
            let parameters = crate::obj::Owned::fresh(new_string(b""));
            let body = crate::obj::Owned::fresh(new_string(b"return ORIGINAL"));
            let before = unsafe { (*original.as_ptr()).ref_count };
            interpreter.set_result_bytes(b"SEEDED RESULT");
            let result = interpreter.get_obj_result();
            let code = unsafe {
                match route {
                    0 => tcl_engine_define_unit(
                        &mut interpreter,
                        original.as_ptr(),
                        parameters.as_ptr(),
                        body.as_ptr(),
                    ),
                    1 => tcl_engine_provide_package(
                        &mut interpreter,
                        original.as_ptr(),
                        later.as_ptr(),
                    ),
                    2 => {
                        tcl_engine_fail(&mut interpreter, original.as_ptr(), core::ptr::null_mut())
                    }
                    _ => unreachable!(),
                }
            };
            assert_eq!(code, TCL_ERROR);
            assert_eq!(PUBLICATION_UPDATES.with(std::cell::Cell::get), 1);
            assert_eq!(PUBLICATION_LATER.with(std::cell::Cell::get), 0);
            assert_eq!(unsafe { (*original.as_ptr()).ref_count }, before);
            assert_eq!(crate::obj::bytes_of(original.as_ptr()), b"blocked");
            assert!(!crate::obj::has_string_rep(later.as_ptr()));
            assert_eq!(interpreter.get_obj_result(), result);
            assert!(interpreter.resolve_cmd_token(b"blocked").is_none());
            assert_eq!(
                interpreter.native_execution_refusal(),
                Some(tcl_runtime_api::NativeExecutionError::ValueAccessRefusal(
                    tcl_syntax::raw_string::NativeValueAccessRefusal::CommandProtocolUnavailable(
                        "stale entered native operation"
                    )
                ))
            );
            PUBLICATION_INTERP.with(|slot| slot.borrow_mut().take());
        }
    }

    #[test]
    fn abi_definition_uses_original_storage_and_reports_failure_without_later_publication() {
        // Software contract: naming.embedding.original-host-publication-and-fact-transport
        // docs/design/analysis/name-resolution-proofs/embedding-original-host-publication-and-fact-transport.md
        for profile in ["tcl8.4", "tcl8.5", "tcl8.6", "tcl9.0", "tcl9.1"] {
            let mut interp = Interp::new();
            interp.pin_release(profile).unwrap();
            let name = crate::obj::Owned::fresh(new_string(b"unit"));
            let bad_parameters = crate::obj::Owned::fresh(new_string(b"{x y z}"));
            let parameters = crate::obj::Owned::fresh(new_string(b""));
            let body = crate::obj::Owned::fresh(new_string(b"return ORIGINAL"));
            // SAFETY: all borrowed originals and the interpreter remain live.
            assert_eq!(
                unsafe {
                    tcl_engine_define_unit(
                        &mut interp,
                        name.as_ptr(),
                        bad_parameters.as_ptr(),
                        body.as_ptr(),
                    )
                },
                TCL_ERROR
            );
            assert!(interp.resolve_cmd_token(b"unit").is_none());
            // SAFETY: the successful producer uses the same live originals.
            assert_eq!(
                unsafe {
                    tcl_engine_define_unit(
                        &mut interp,
                        name.as_ptr(),
                        parameters.as_ptr(),
                        body.as_ptr(),
                    )
                },
                TCL_OK
            );
            let completion = interp.eval_completion(b"unit").unwrap();
            assert_eq!(completion.code, tcl_runtime_api::Code::Ok);
            assert_eq!(completion.result, b"ORIGINAL");
            let pending_name = crate::obj::Owned::fresh(new_string(b"unentered"));
            interp.refuse_host_command("original ABI host refusal");
            let original = interp.native_execution_refusal().unwrap();
            // SAFETY: a prior host refusal stops before inspecting or publishing originals.
            assert_eq!(
                unsafe {
                    tcl_engine_define_unit(
                        &mut interp,
                        pending_name.as_ptr(),
                        parameters.as_ptr(),
                        body.as_ptr(),
                    )
                },
                TCL_ERROR
            );
            assert_eq!(interp.native_execution_refusal(), Some(original));
            assert!(interp.resolve_cmd_token(b"unentered").is_none());
        }
    }
}

mod command_receipts;
pub use command_receipts::*;

pub(crate) mod value_carriers;
pub use value_carriers::*;

#[cfg(test)]
mod original_input_tests;
