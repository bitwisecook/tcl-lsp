// tcl-lsp — a language server and toolchain for Tcl
// Copyright (C) 2026 James Deucker (bitwisecook) <https://github.com/bitwisecook>
//
// SPDX-License-Identifier: AGPL-3.0-or-later

//! `format` — thin runtime adapter onto [`tcl_cmd_core::format`].
//!
//! The shared command core owns Tcl's format grammar and rendering semantics;
//! this module only translates its result into the runtime command ABI.  This
//! keeps the VM and WASM runtime on the same implementation of
//! `Tcl_AppendFormatToObj` (`generic/tclStringObj.c`).

use crate::interp::{Code, Interp};
use crate::obj::TclObj;

/// Register `format`.
pub fn install(interp: &mut Interp) {
    interp.register_builtin(b"format", format_cmd);
}

fn format_cmd(interp: &mut Interp, argv: &[*mut TclObj]) -> Code {
    let syntax = interp.runtime_version().number_syntax();
    match tcl_cmd_core::format::format_cmd_with_syntax(interp, &argv[1..], syntax) {
        Ok(value) => {
            interp.set_result(value);
            Code::Ok
        }
        Err(error) => interp.report_cmd_error(error),
    }
}

#[cfg(test)]
mod tests {
    use crate::counters;
    use crate::interp::{Code, Interp};

    fn leak_free(body: impl FnOnce(&mut Interp)) {
        counters::reset();
        {
            let mut interp = Interp::new();
            body(&mut interp);
        }
        assert_eq!(
            counters::finalize(),
            0,
            "residual: {} objs, {} bufs",
            counters::live_objs(),
            counters::live_bufs()
        );
        assert_eq!(counters::double_free_count(), 0);
    }

    fn ok(i: &mut Interp, src: &[u8]) -> Vec<u8> {
        assert_eq!(
            i.eval_str(src),
            Code::Ok,
            "eval {:?} -> {:?}",
            String::from_utf8_lossy(src),
            String::from_utf8_lossy(&i.result_bytes())
        );
        i.result_bytes()
    }

    #[test]
    fn format_conversions_flags_width() {
        leak_free(|i| {
            assert_eq!(
                ok(i, b"format {%d %05d %-5d|} 42 42 42"),
                b"42 00042 42   |"
            );
            assert_eq!(ok(i, b"format {%x %#x %X} 255 255 255"), b"ff 0xff FF");
            assert_eq!(ok(i, b"format {%5.2f} 3.14159"), b" 3.14");
            assert_eq!(ok(i, b"format {%.3s %10s|} hello hi"), b"hel         hi|");
            assert_eq!(ok(i, b"format {%c%c%c} 72 105 33"), b"Hi!");
            assert_eq!(ok(i, b"format {%2$s %1$s} a b"), b"b a");
            assert_eq!(ok(i, b"format {%+d % d %o} 5 5 8"), b"+5  5 10");
            assert_eq!(ok(i, b"format {%.*d} -1 0"), b"0");
            assert_eq!(ok(i, b"format {%.*x} -1 0"), b"0");
            assert_eq!(ok(i, b"format {%.0d} 0"), b"0");
            assert_eq!(ok(i, b"format {%.0x} 0"), b"0");
            i.set_runtime_version(tcl_dialect::TclVersion::V8_6);
            assert_eq!(ok(i, b"format {%.*d} -1 0"), b"0");
            assert_eq!(ok(i, b"format {%.*x} -1 0"), b"0");
            i.set_runtime_version(tcl_dialect::TclVersion::V8_4);
            assert_eq!(ok(i, b"format {%.0d} 0"), b"");
            assert_eq!(ok(i, b"format {%.0x} 0"), b"");
        });
    }

    #[test]
    fn alternate_decimal_uses_shared_tcl9_semantics() {
        leak_free(|i| {
            assert_eq!(ok(i, b"format {%#d %#i} 42 42"), b"0d42 0d42");
            i.set_runtime_version(tcl_dialect::TclVersion::V8_6);
            assert_eq!(
                ok(i, b"format {%#d %#i %#o %#X} 42 42 8 12"),
                b"42 42 010 0XC"
            );
            assert_eq!(ok(i, b"format {%#x %#X %#b} 0 0 0"), b"0x0 0X0 0b0");
            assert_eq!(ok(i, b"format {%#.0x %#.0X %#.0b} 0 0 0"), b"0x0 0X0 0b0");
            i.set_runtime_version(tcl_dialect::TclVersion::V8_4);
            assert_eq!(ok(i, b"format {%#.0x %#.0X} 0 0"), b" ");
            i.set_runtime_version(tcl_dialect::TclVersion::V9_0);
            assert_eq!(
                ok(i, b"format {%#d %#i %#o %#X} 42 42 8 12"),
                b"0d42 0d42 0o10 0xC"
            );
        });
    }

    /// #1782: a size modifier and the release pick the integer width, and
    /// the low bits are then read signed for `d`/`i` and unsigned for
    /// `u`/`x`/`o`/`b`. Every expectation here is a transcript from the
    /// matching real tclsh (8.4.20 / 8.5.19 / 8.6.18 / 9.0.4 / 9.1b0).
    ///
    /// Three defects, one rule. Before this, `format %hd 5000000000` gave
    /// `5000000000` on every release, `format %u -1` gave `1`, and the
    /// unmodified width was 64-bit even under Tcl 9.
    #[test]
    fn integer_conversions_honour_width_and_signedness_issue_1782() {
        leak_free(|i| {
            // `h` is C `short` — 16 bits on every release and platform.
            for version in [
                tcl_dialect::TclVersion::V8_4,
                tcl_dialect::TclVersion::V8_6,
                tcl_dialect::TclVersion::V9_0,
            ] {
                i.set_runtime_version(version);
                assert_eq!(ok(i, b"format %hd 5000000000"), b"-3584", "{version:?}");
                assert_eq!(ok(i, b"format %hd 32768"), b"-32768", "{version:?}");
                assert_eq!(ok(i, b"format %hd -32769"), b"32767", "{version:?}");
                assert_eq!(ok(i, b"format %hu 5000000000"), b"61952", "{version:?}");
                assert_eq!(ok(i, b"format %hx 5000000000"), b"f200", "{version:?}");
                assert_eq!(ok(i, b"format %ho 5000000000"), b"171000", "{version:?}");
                // `h` does not reach `%c`.
                assert_eq!(ok(i, b"format %hc 65"), b"A", "{version:?}");
            }

            // The unmodified width is the release's: `long` before Tcl 9,
            // `int` from it.
            i.set_runtime_version(tcl_dialect::TclVersion::V8_6);
            assert_eq!(ok(i, b"format %d 5000000000"), b"5000000000");
            assert_eq!(ok(i, b"format %d 4294967296"), b"4294967296");
            assert_eq!(ok(i, b"format %u -1"), b"18446744073709551615");
            assert_eq!(ok(i, b"format %x -1"), b"ffffffffffffffff");

            i.set_runtime_version(tcl_dialect::TclVersion::V9_0);
            assert_eq!(ok(i, b"format %d 5000000000"), b"705032704");
            assert_eq!(ok(i, b"format %d 4294967296"), b"0");
            assert_eq!(ok(i, b"format %u -1"), b"4294967295");
            assert_eq!(ok(i, b"format %x -1"), b"ffffffff");
            // `l` is the wide path, so it keeps all 64 bits under Tcl 9 too.
            assert_eq!(ok(i, b"format %ld 5000000000"), b"5000000000");

            // Width and precision still apply around the truncated value.
            assert_eq!(ok(i, b"format {%-6hd|} 70000"), b"4464  |");
            assert_eq!(ok(i, b"format %5.3d 7"), b"  007");
        });
    }

    /// Tcl 9 bignum formatting keeps the exact magnitude in each supported
    /// radix, and `u` rejects a negative bignum with C's structured code.
    #[cfg(have_tommath)]
    #[test]
    fn format_bignums_issue_2162() {
        leak_free(|i| {
            // Fixed-width conversions first fold arbitrary magnitudes modulo
            // 2^64, then apply their selected width. These are the runtime
            // adapter's direct libtommath coverage for #2204.
            assert_eq!(
                ok(i, b"format %I64u 18446744073709551615"),
                b"18446744073709551615"
            );
            assert_eq!(ok(i, b"format %I64d 18446744073709551615"), b"-1");
            assert_eq!(ok(i, b"format %I64d 18446744073709551616"), b"0");
            assert_eq!(
                ok(i, b"format %I64d 340282366920938463463374607431768211457"),
                b"1"
            );
            assert_eq!(ok(i, b"format %I64d -18446744073709551617"), b"-1");
            assert_eq!(
                ok(i, b"format %I64u -18446744073709551617"),
                b"18446744073709551615"
            );

            for version in [tcl_dialect::TclVersion::V8_6, tcl_dialect::TclVersion::V9_0] {
                i.set_runtime_version(version);
                assert_eq!(
                    ok(
                        i,
                        b"format {%+u % u %+x % x %+X % X %+o % o %+b % b} 0 0 0 0 0 0 0 0 0 0"
                    ),
                    b"0 0 0 0 0 0 0 0 0 0",
                    "{version:?}"
                );
                assert_eq!(
                    ok(i, b"format {%+u % u %+x % x %+X % X %+o % o %+b % b} 17 17 17 17 17 17 17 17 17 17"),
                    b"17 17 11 11 11 11 21 21 10001 10001",
                    "{version:?}"
                );
                assert_eq!(ok(i, b"format {%+08x %+#08x} 17 17"), b"00000011 0x000011");
                assert_eq!(
                    ok(
                        i,
                        b"format {%+u % x} 18446744073709551616 18446744073709551616"
                    ),
                    b"0 0",
                    "{version:?}"
                );
                let negative = match version {
                    tcl_dialect::TclVersion::V8_6 => {
                        b"18446744073709551599 18446744073709551599 ffffffffffffffef ffffffffffffffef".as_slice()
                    }
                    tcl_dialect::TclVersion::V9_0 => {
                        b"4294967279 4294967279 ffffffef ffffffef".as_slice()
                    }
                    _ => unreachable!(),
                };
                assert_eq!(
                    ok(i, b"format {%+u % u %+x % x} -17 -17 -17 -17"),
                    negative,
                    "{version:?}"
                );
            }
            i.set_runtime_version(tcl_dialect::TclVersion::V8_4);
            assert_eq!(
                ok(
                    i,
                    b"format {%+u % u %+x % x %+X % X %+o % o} 0 0 0 0 0 0 0 0"
                ),
                b"0 0 0 0 0 0 0 0"
            );
            assert_eq!(
                ok(
                    i,
                    b"format {%+u % u %+x % x %+X % X %+o % o} 17 17 17 17 17 17 17 17"
                ),
                b"17 17 11 11 11 11 21 21"
            );
            i.set_runtime_version(tcl_dialect::TclVersion::V9_0);
            assert_eq!(ok(i, b"format {%+08p % 08p} 17 17"), b"0x000011 0x000011");

            assert_eq!(
                ok(i, b"format %lld 18446744073709551616"),
                b"18446744073709551616"
            );
            assert_eq!(
                ok(i, b"format %Lx 18446744073709551616"),
                b"10000000000000000"
            );
            assert_eq!(
                ok(i, b"format %llu 0xabcdef0123456789abcdef"),
                b"207698809136909011942886895"
            );
            assert_eq!(
                ok(i, b"format %llx 0xabcdef0123456789abcdef"),
                b"abcdef0123456789abcdef"
            );
            assert_eq!(
                ok(i, b"format %llX 0xabcdef0123456789abcdef"),
                b"ABCDEF0123456789ABCDEF"
            );
            assert_eq!(
                ok(i, b"format {%+llx % llx %+llx % llx} 18446744073709551616 18446744073709551616 -17 -17"),
                b"+10000000000000000  10000000000000000 -11 -11"
            );
            for format in [
                b"%#.0lld".as_slice(),
                b"%#.0llx",
                b"%#.0llo",
                b"%#.0llb",
                b"%#.0Ld",
                b"%#.0Lx",
                b"%#.0Lo",
                b"%#.0Lb",
            ] {
                let mut source = b"format ".to_vec();
                source.extend_from_slice(format);
                source.extend_from_slice(b" 0");
                assert_eq!(ok(i, &source), b"0", "{format:?}");
            }
            i.set_runtime_version(tcl_dialect::TclVersion::V8_6);
            for (format, expected) in [
                (b"%#.0llx".as_slice(), b"0x0".as_slice()),
                (b"%#.0llX", b"0X0"),
                (b"%#.0llb", b"0b0"),
            ] {
                let mut source = b"format ".to_vec();
                source.extend_from_slice(format);
                source.extend_from_slice(b" 0");
                assert_eq!(ok(i, &source), expected, "{format:?}");
            }
            assert_eq!(ok(i, b"format %#.0o 0"), b"0");
            assert_eq!(ok(i, b"format %#.4o 17"), b"0021");
            assert_eq!(
                ok(i, b"format %#.30llo 18446744073709551616"),
                b"000000002000000000000000000000"
            );
            i.set_runtime_version(tcl_dialect::TclVersion::V9_0);
            assert_eq!(
                ok(i, b"format %#.30llo 18446744073709551616"),
                b"0o000000002000000000000000000000"
            );
            assert_eq!(ok(i, b"format %+.0llu 0"), b"+0");
            assert_eq!(
                ok(i, b"catch {format %llu -9223372036854775808} m o; list $m [dict get $o -errorcode]"),
                b"{unsigned bignum format is invalid} {TCL FORMAT BADUNSIGNED}",
            );
        });
    }

    /// Tcl 8.4 did not admit the `ll` bignum modifier.
    #[test]
    fn format_bignum_modifier_is_rejected_in_tcl84_issue_2162() {
        leak_free(|i| {
            i.set_runtime_version(tcl_dialect::TclVersion::V8_4);
            assert_eq!(i.eval_str(b"format %lld 42"), Code::Error);
            assert_eq!(i.result_bytes(), b"bad field specifier \"l\"");
            assert_eq!(ok(i, b"format %#.0o 0"), b"0");
            i.set_runtime_version(tcl_dialect::TclVersion::V8_6);
            assert_eq!(
                i.eval_str(b"format %lld 0d18446744073709551616"),
                Code::Error
            );
            assert_eq!(
                i.result_bytes(),
                b"expected integer but got \"0d18446744073709551616\""
            );
        });
    }

    #[test]
    fn format_overflow_width_errors_not_panics() {
        leak_free(|i| {
            for width in [b"4294967294".as_slice(), b"18446744073709551614"] {
                let mut source = b"format %".to_vec();
                source.extend_from_slice(width);
                source.extend_from_slice(b"g 0");
                assert_eq!(i.eval_str(&source), Code::Error);
                assert_eq!(i.result_bytes(), b"max size for a Tcl value exceeded");
            }
            assert_eq!(ok(i, b"format %5s hi"), b"   hi");
        });
    }
}
