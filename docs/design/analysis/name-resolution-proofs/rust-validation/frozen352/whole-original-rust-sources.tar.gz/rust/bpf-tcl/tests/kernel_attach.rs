// tcl-lsp — a language server and toolchain for Tcl
// Copyright (C) 2026 James Deucker (bitwisecook) <https://github.com/bitwisecook>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.
//
// SPDX-License-Identifier: AGPL-3.0-or-later

//! Privileged loader / link-lifecycle acceptance tests.
//! **These do not run by default.**
//!
//! Attaching a program to an interface or cgroup calls the `bpf()` syscall and
//! configures live kernel networking state, which needs `CAP_BPF`/`CAP_NET_ADMIN`
//! (root in practice) and a live Linux kernel — none of which exist in the
//! sandbox the rest of the suite runs in. So these are marked `#[ignore]`; run
//! them by hand on a Linux host:
//!
//! ```text
//! sudo -E cargo test -p bpf-tcl --test kernel_attach -- --ignored --nocapture
//! ```
//!
//! Every test is **hermetic and self-cleaning**: it builds a *disposable*
//! network namespace (or an isolated test cgroup), does its work inside, and
//! unconditionally tears the namespace/cgroup down at the end — so it cannot
//! leak links, pins, maps, or interfaces onto the host, and never touches a
//! real host interface. When the required tooling or privilege is missing, the
//! test **skips** with a printed reason rather than failing.
//!
//! The lifecycle *logic* (plan → load → test-run → attach → status → detach,
//! with rollback and ownership) is covered deterministically in userspace by the
//! `bpf-tcl-ir::loader` unit tests over a `ModelKernel`; these privileged tests
//! confirm the modelled contract against a real kernel.

use std::process::Command;

use bpf_tcl_codegen::ebpf::{TargetAbi, emit_program_for_target, write_object};
use bpf_tcl_ir::{DeploymentPlan, compile_module, event_spec};

fn tool_present(name: &str) -> bool {
    Command::new(name)
        .arg("-V")
        .output()
        .is_ok_and(|o| o.status.success() || !o.stdout.is_empty() || !o.stderr.is_empty())
}

fn is_root() -> bool {
    Command::new("id")
        .arg("-u")
        .output()
        .ok()
        .and_then(|o| String::from_utf8(o.stdout).ok())
        .is_some_and(|s| s.trim() == "0")
}

/// A disposable network namespace that deletes itself (and everything inside it
/// — veth pairs, XDP/TC attachments) on drop. Cleanup is unconditional so a
/// panicking test still leaves the host clean.
struct DisposableNetns {
    name: String,
}

impl DisposableNetns {
    fn new(name: &str) -> Option<Self> {
        let ok = Command::new("ip")
            .args(["netns", "add", name])
            .status()
            .is_ok_and(|s| s.success());
        ok.then(|| DisposableNetns {
            name: name.to_owned(),
        })
    }

    /// Run `ip -n <ns> …`, returning success.
    fn ip(&self, args: &[&str]) -> bool {
        let mut full = vec!["-n", &self.name];
        full.extend_from_slice(args);
        Command::new("ip")
            .args(&full)
            .status()
            .is_ok_and(|s| s.success())
    }

    /// Run `tc …` inside the namespace (via `ip netns exec`), returning
    /// success. `tc` (unlike `ip link`) has no `-n <ns>` form of its own.
    fn tc(&self, args: &[&str]) -> bool {
        let mut full = vec!["netns", "exec", &self.name, "tc"];
        full.extend_from_slice(args);
        Command::new("ip")
            .args(&full)
            .status()
            .is_ok_and(|s| s.success())
    }

    /// `tc filter show dev <dev> <direction>` inside the namespace, for
    /// asserting the attached program is actually visible (not just that the
    /// add command exited zero).
    fn tc_filter_show(&self, dev: &str, direction: &str) -> String {
        Command::new("ip")
            .args([
                "netns", "exec", &self.name, "tc", "filter", "show", "dev", dev, direction,
            ])
            .output()
            .ok()
            .and_then(|o| String::from_utf8(o.stdout).ok())
            .unwrap_or_default()
    }
}

impl Drop for DisposableNetns {
    fn drop(&mut self) {
        // Deleting the namespace tears down every veth and every attachment in
        // it — the whole point of using a namespace for isolation.
        let _ = Command::new("ip")
            .args(["netns", "del", &self.name])
            .status();
    }
}

#[test]
#[ignore = "needs root + iproute2 + a live kernel; run with --ignored on a Linux host"]
fn xdp_attach_detach_in_a_disposable_namespace_leaks_nothing() {
    if !is_root() {
        eprintln!("skip: XDP attach needs root/CAP_NET_ADMIN");
        return;
    }
    if !tool_present("ip") {
        eprintln!("skip: iproute2 (`ip`) unavailable");
        return;
    }
    let src = "when XDP { setbuf p ctx\n pass }\n";
    let module = compile_module(src).expect("compiles");
    let plan = DeploymentPlan::from_module("bpftcl-test", &module);
    // Ownership-labelled pin path — detach must remove only this.
    eprintln!("plan pin: {}", plan.programs[0].pin);

    let Some(ns) = DisposableNetns::new("bpftcl-xdp-test") else {
        eprintln!("skip: could not create a disposable netns");
        return;
    };
    // A veth pair inside the namespace gives us an interface to attach to that
    // is destroyed with the namespace.
    assert!(ns.ip(&[
        "link", "add", "veth0", "type", "veth", "peer", "name", "veth1"
    ]));

    // Write the kernel object and attach it to veth0 with `ip link … xdpgeneric`.
    let obj = emit_program_for_target(&module.programs[0].program, TargetAbi::KernelXdp)
        .expect("object emits");
    let bytes = write_object(&obj, "xdp").expect("elf writes");
    let mut obj_path = std::env::temp_dir();
    obj_path.push(format!("bpftcl-xdp-{}.o", std::process::id()));
    std::fs::write(&obj_path, bytes).expect("write object");

    let attached = ns.ip(&[
        "link",
        "set",
        "dev",
        "veth0",
        "xdpgeneric",
        "obj",
        obj_path.to_str().unwrap(),
        "sec",
        "xdp",
    ]);
    if !attached {
        let _ = std::fs::remove_file(&obj_path);
        eprintln!("skip: xdpgeneric attach unsupported on this host");
        return;
    }

    // Detach explicitly (the namespace drop would also remove it, but the
    // deployment owns the detach in production).
    let detached = ns.ip(&["link", "set", "dev", "veth0", "xdpgeneric", "off"]);
    assert!(detached, "detach should succeed");
    let _ = std::fs::remove_file(&obj_path);
    // `ns` drops here, deleting the namespace and proving nothing leaks.
}

#[test]
#[ignore = "needs root + iproute2(tc) + a live kernel; run with --ignored on a Linux host"]
fn tc_ingress_attach_detach_in_a_disposable_namespace_leaks_nothing() {
    // TC (SCHED_CLS) codegen is implemented — this attaches a
    // real classifier to a veth's ingress hook in a disposable namespace,
    // mirroring `xdp_attach_detach_in_a_disposable_namespace_leaks_nothing`
    // above. `__sk_buff` (TC's context) is exactly the socket filter's, so
    // `TargetAbi::KernelTc` reuses that context layout (see `emit.rs`).
    if !is_root() {
        eprintln!("skip: TC attach needs root/CAP_NET_ADMIN");
        return;
    }
    if !tool_present("tc") {
        eprintln!("skip: iproute2 (`tc`) unavailable");
        return;
    }
    let spec = event_spec("TC_INGRESS").expect("TC_INGRESS described");
    assert_eq!(spec.context.struct_name, "__sk_buff");
    assert!(spec.is_codegen_ready(), "TC codegen should be implemented");

    let src = "when TC_INGRESS { pass }\n";
    let module = compile_module(src).expect("TC_INGRESS compiles");
    let plan = DeploymentPlan::from_module("bpftcl-test", &module);
    eprintln!("plan pin: {}", plan.programs[0].pin);

    let Some(ns) = DisposableNetns::new("bpftcl-tc-test") else {
        eprintln!("skip: could not create a disposable netns");
        return;
    };
    assert!(ns.ip(&[
        "link", "add", "veth0", "type", "veth", "peer", "name", "veth1"
    ]));
    assert!(ns.ip(&["link", "set", "dev", "veth0", "up"]));
    // A TC classifier attaches to the `clsact` qdisc's ingress/egress hooks —
    // there is no `xdpgeneric`-style single-command load+attach for TC, so
    // the qdisc is created explicitly first.
    if !ns.tc(&["qdisc", "add", "dev", "veth0", "clsact"]) {
        eprintln!("skip: `tc qdisc add … clsact` unsupported on this host");
        return;
    }

    let obj = emit_program_for_target(&module.programs[0].program, TargetAbi::KernelTc)
        .expect("object emits");
    let bytes = write_object(&obj, "tc").expect("elf writes");
    let mut obj_path = std::env::temp_dir();
    obj_path.push(format!("bpftcl-tc-{}.o", std::process::id()));
    std::fs::write(&obj_path, bytes).expect("write object");

    let attached = ns.tc(&[
        "filter",
        "add",
        "dev",
        "veth0",
        "ingress",
        "bpf",
        "da",
        "obj",
        obj_path.to_str().unwrap(),
        "sec",
        "tc",
    ]);
    if !attached {
        let _ = std::fs::remove_file(&obj_path);
        eprintln!("skip: TC bpf filter attach unsupported on this host");
        return;
    }
    // The verifier only runs (and JITs) at attach time — a non-empty filter
    // listing is the load+attach succeeding, not just the CLI exiting zero.
    let listing = ns.tc_filter_show("veth0", "ingress");
    assert!(
        listing.contains("bpf"),
        "attached filter should be listed: {listing}"
    );

    // Detach explicitly (the namespace drop would also remove it, but the
    // deployment owns the detach in production).
    let detached = ns.tc(&["filter", "del", "dev", "veth0", "ingress"]);
    assert!(detached, "detach should succeed");
    let _ = std::fs::remove_file(&obj_path);
    // `ns` drops here, deleting the namespace (and the clsact qdisc/filter
    // with it) and proving nothing leaks.
}

#[test]
#[ignore = "needs root + bpftool + a live kernel; run with --ignored on a Linux host"]
fn cgroup_connect_attach_detach_on_a_disposable_cgroup_leaks_nothing() {
    // cgroup (CGROUP_SOCK_ADDR) codegen is implemented. Unlike
    // XDP/TC, attaching a cgroup program has no `ip`/`tc` CLI path — it needs
    // `bpftool cgroup attach`, so this additionally gates on `bpftool`, which
    // is not available in every CI/sandbox image, hence a stricter skip
    // condition than the netns-only tests above. Where `bpftool` is
    // unavailable, this exact sequence stays unverified against a real
    // kernel; the TC test above and the unit/e2e codegen suites are not
    // affected by that gap.
    if !is_root() {
        eprintln!("skip: cgroup attach needs root/CAP_BPF");
        return;
    }
    if !tool_present("bpftool") {
        eprintln!("skip: bpftool unavailable (needed for cgroup attach; no ip/tc equivalent)");
        return;
    }
    let spec = event_spec("CGROUP_CONNECT4").expect("CGROUP_CONNECT4 described");
    assert_eq!(spec.context.struct_name, "bpf_sock_addr");
    assert!(spec.context_field("user_port").is_some());
    assert!(
        spec.is_codegen_ready(),
        "cgroup codegen should be implemented"
    );

    // `pass` only (no `setbuf`/context reads — `bpf_sock_addr` has no packet
    // body, and `lower.rs` rejects `setbuf` for this program-type family).
    let src = "when CGROUP_CONNECT4 { pass }\n";
    let module = compile_module(src).expect("CGROUP_CONNECT4 compiles");

    let obj = emit_program_for_target(&module.programs[0].program, TargetAbi::KernelCgroupSockAddr)
        .expect("object emits");
    let bytes = write_object(&obj, "cgroup_connect4").expect("elf writes");
    let mut obj_path = std::env::temp_dir();
    obj_path.push(format!("bpftcl-cgroup-{}.o", std::process::id()));
    std::fs::write(&obj_path, bytes).expect("write object");

    let Some(cg) = DisposableCgroup::new("bpftcl-cgroup-test") else {
        let _ = std::fs::remove_file(&obj_path);
        eprintln!("skip: could not create a disposable test cgroup under /sys/fs/cgroup");
        return;
    };

    // `bpftool cgroup attach` needs a *pinned* program: load-and-pin first,
    // then attach the pin — the same two syscalls (`BPF_PROG_LOAD` then
    // `BPF_PROG_ATTACH`) a real deployment (`bpf-tcl-ir::loader`) drives
    // directly, `bpftool` just wraps them as two CLI steps.
    let pin_path = format!("/sys/fs/bpf/bpftcl-cgroup-test-{}", std::process::id());
    let loaded = Command::new("bpftool")
        .args([
            "prog",
            "load",
            obj_path.to_str().unwrap(),
            &pin_path,
            "type",
            "cgroup/connect4",
        ])
        .status()
        .is_ok_and(|s| s.success());
    if !loaded {
        let _ = std::fs::remove_file(&obj_path);
        eprintln!("skip: `bpftool prog load` unsupported on this host");
        return;
    }
    let attached = Command::new("bpftool")
        .args([
            "cgroup", "attach", &cg.path, "connect4", "pinned", &pin_path,
        ])
        .status()
        .is_ok_and(|s| s.success());
    if !attached {
        let _ = std::fs::remove_file(&pin_path);
        let _ = std::fs::remove_file(&obj_path);
        eprintln!("skip: `bpftool cgroup attach` unsupported on this host");
        return;
    }

    let listing = Command::new("bpftool")
        .args(["cgroup", "show", &cg.path])
        .output()
        .ok()
        .and_then(|o| String::from_utf8(o.stdout).ok())
        .unwrap_or_default();
    assert!(
        listing.contains("connect4"),
        "attached cgroup program should be listed: {listing}"
    );

    let detached = Command::new("bpftool")
        .args([
            "cgroup", "detach", &cg.path, "connect4", "pinned", &pin_path,
        ])
        .status()
        .is_ok_and(|s| s.success());
    assert!(detached, "detach should succeed");
    let _ = std::fs::remove_file(&pin_path);
    let _ = std::fs::remove_file(&obj_path);
    // `cg` drops here, rmdir-ing the test cgroup and proving nothing leaks.
}

/// A disposable cgroup v2 directory under `/sys/fs/cgroup` that removes
/// itself on drop. Cleanup is unconditional so a panicking test still leaves
/// the host clean.
struct DisposableCgroup {
    path: String,
}

impl DisposableCgroup {
    fn new(name: &str) -> Option<Self> {
        let path = format!("/sys/fs/cgroup/{name}-{}", std::process::id());
        std::fs::create_dir(&path).ok()?;
        Some(DisposableCgroup { path })
    }
}

impl Drop for DisposableCgroup {
    fn drop(&mut self) {
        let _ = std::fs::remove_dir(&self.path);
    }
}
