// tcl-lsp — a language server and toolchain for Tcl
// Copyright (C) 2026 James Deucker (bitwisecook) <https://github.com/bitwisecook>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.
//
// SPDX-License-Identifier: AGPL-3.0-or-later

//! Plain-text grammar reference rendered by `f5 query --help-dsl`.
//!
//! The canonical reference lives in `docs/references/f5_query/dsl.md`; this
//! module holds the condensed terminal-friendly version so the grammar is
//! readable without leaving the shell.

/// The condensed informal-EBNF grammar reference.
const GRAMMAR: &str = r#"F5 QUERY DSL — GRAMMAR

A query is a pipeline of stages joined by ``|``.  Each stage transforms
the current value (``.``) into one or more new values.  Pipelines may
be chained with ``;`` to evaluate multiple statements against the same
root.

  program       := pipeline (';' pipeline)*
  pipeline      := comma_expr ('|' comma_expr)*
  comma_expr    := pipe_stage (',' pipe_stage)*
  pipe_stage    := or_expr (ASSIGN_OP pipe_stage)?
  ASSIGN_OP     := '=' | '|=' | '+=' | '-='
  or_expr       := and_expr ('or' and_expr)*
  and_expr      := not_expr ('and' not_expr)*
  not_expr      := 'not' not_expr | cmp_expr
  cmp_expr      := add_expr (('==' | '!=' | '<' | '<=' | '>' | '>=') add_expr)?
  add_expr      := mul_expr (('+' | '-') mul_expr)*
  mul_expr      := unary    (('*' | '/') unary)*
  unary         := '-' unary | postfix
  postfix       := primary path_tail
  primary       := literal | call | path | variable | list_literal
                 | object_literal | if_expr | '(' pipeline ')'
  if_expr       := 'if' pipeline 'then' pipeline
                   ('elif' pipeline 'then' pipeline)*
                   ('else' pipeline)? 'end'
  variable      := '$' IDENT          /* root container of a named
                                         source loaded alongside this
                                         query (`f5 query` accepts
                                         several configs with
                                         filename-stem default names
                                         and an explicit --name N=PATH
                                         override).  Postfix path
                                         steps land afterwards, so
                                         `$gtm.gtm.wideip[]` reads from
                                         the source bound under
                                         `$gtm`.                       */
  object_literal:= '{' (entry (',' entry)*)? '}'
                                       /* jq-style object constructor:
                                          { name, destination: .dest }
                                          builds a dict per input.
                                          Stream values broadcast
                                          element-wise so one stream
                                          field becomes one row per
                                          item.                        */
  entry         := IDENT (':' pipe_stage)?
                 | STRING ':' pipe_stage
                                       /* Bareword shorthand: { name }
                                          desugars to { name: .name }.
                                          Wrap pipe/comma values in
                                          parens: {x: (.a | .b)}.     */
  pipe_stage    := or_expr (ASSIGN_OP pipe_stage)?
                 | or_expr 'as' '$' IDENT '|' pipeline
                                       /* let-binding: bind each
                                          value from `or_expr` to
                                          $IDENT and evaluate the
                                          downstream pipeline with
                                          that binding in scope.
                                          Right-associative so
                                          `.a[] as $x | .b | $x.c +
                                          ...` keeps $x bound across
                                          subsequent pipe stages.     */
  list_literal  := '[' pipeline? ']'        /* jq's array constructor */
  path          := '.'
                 | '.' field path_tail
                 | '.' '[' subscript ']' path_tail
  path_tail     := ('.' field '?'? | '[' subscript ']' '?'?)*
  field         := IDENT | STRING
  subscript     := /* empty -> stream */
                 | NUMBER
                 | STRING                /* exact subscript by string  */
                                         /* STRING starting with "~"
                                            inside [ ] is the regex
                                            subscript form            */
                 | pipeline              /* dynamic subscript          */
  call          := IDENT ('(' (pipe_stage (',' pipe_stage)*)? ')')?
                                         /* parens optional for 1-arg
                                            builtins — bare ``length``
                                            is equivalent to
                                            ``length(.)``               */
  literal       := NUMBER | STRING | 'true' | 'false' | 'null'

Pipelines iterate **streams**, not plain lists.  ``[]`` produces a
stream and stream-returning builtins do too; ``|`` then runs the next
stage once per item.  Plain lists (e.g. the value of ``.rules``) pass
through ``|`` whole — to fold a stream into a list for aggregators
like ``sort`` / ``unique``, wrap it: ``[.ltm.virtual[].name] | sort``.

Comma concatenates streams, matching jq's array-constructor idiom:
``[1, 2, .ltm.virtual[].name]`` evaluates each comma part against the
same input and collects the flattened stream.  Commas inside function
arguments and object entries remain structural separators; wrap a comma
stream in parentheses when it is a single argument or field value.

Assignment is a *trailing operator* on a pipe-stage, not a top-level
statement.  That makes ``.ltm.virtual[] | .destination |= ip(...)``
parse as ``.ltm.virtual[] | (.destination |= ip(...))`` — for each
streamed VS, set its destination to ``ip(...)`` of the current value.

PATH ACCESS

  .                       The current value (identity).
  .ltm.virtual            Field access — chained.
  .ltm.virtual.web_vs     TMSH partition shorthand: bare names resolve to
                          ``/Common/web_vs`` when unambiguous in the
                          target container.  Use the subscript form
                          ``.ltm.virtual["/Common/web_vs"]`` (see below)
                          for an explicit full-path lookup.
  .ltm.virtual["/Common/web_vs"]
                          Exact subscript by full-path.
  .ltm.virtual["~/vs_prod_"]
                          Regex subscript — matches every key whose
                          full-path (including the partition prefix)
                          contains the pattern.  Use the explicit
                          partition prefix in the pattern when you
                          want to anchor the match
                          (``"~^/Common/vs_prod_"``).
  .ltm.virtual[]          Stream every value in the container.
  .ltm.virtual[].pool     A path-ref to the default pool of each VS.
                          PathRefs act as strings AND as the referenced
                          object: ``.ltm.virtual[].pool.members[]`` walks
                          VS -> pool -> member transparently.
                          A deref resolves against the whole view: under
                          ``--merge`` every loaded config is one namespace,
                          so each hop of a chain may land in a different
                          source.  Without ``--merge`` a deref stays inside
                          the config being iterated.
                          A path naming an object that is nowhere in the
                          view is never silent: a field read through it
                          reads as ``null`` (so ``.pool.members`` shows
                          ``null``, not "a pool with no members") while
                          carrying the path that failed, so reading on
                          through it names that path.  Iterating it is
                          empty; iterating or subscripting the reference
                          itself is an error naming the path.  An *empty*
                          ref (no pool set at all) contributes nothing.

MODULES

  Seven modules carry a typed projection.  The kind lists below are
  exhaustive: a kind that is not listed is not navigable, and
  ``.<module>.<kind>`` raises ``no entry``.

  .ltm.<kind>             Local Traffic Manager: ``virtual``,
                          ``virtual-address``, ``pool``, ``node``,
                          ``rule``, ``profile``, ``monitor``,
                          ``persistence``, ``snatpool``, ``policy``,
                          ``data-group``, ``snat-translation``.  Each
                          ``ltm policy`` exposes ``.rules[]`` with
                          nested ``.conditions[]`` and
                          ``.actions[]`` sub-objects — chained
                          access like ``.ltm.policy[].rules[]
                          .actions[].pool`` walks into the target
                          pool via a PathRef.
  .net.<kind>             Network: ``route``, ``vlan``, ``self``,
                          ``route-domain``, ``port-list``,
                          ``interface``, ``dns-resolver``,
                          ``tunnel`` (``net tunnels tunnel``),
                          ``stp``.
                          PathRefs from ``self.vlan``,
                          ``route-domain.vlans[]``, and
                          ``stp.vlans[]`` auto-deref into the target
                          ``net vlan`` so chained access
                          ``.net.self[].vlan.tag`` Just Works.
  .sys.<kind>             System: ``dns``, ``ntp``, ``snmp``,
                          ``global-settings`` (singletons — one entry
                          each, streamed via ``.sys.dns[]``);
                          ``provision``, ``folder``, ``file-ssl-cert``,
                          ``file-ssl-key``, ``management-route``.
                          ``file-ssl-cert`` carries the x509 metadata
                          ``x509_from_config`` projects, and the
                          ``cache-path`` ``ucs_cert`` re-reads the PEM
                          by: ``.sys["file-ssl-cert"][] | ucs_cert(.)``.
  .cm.<kind>              Cluster Manager: ``cert``, ``key``,
                          ``device``, ``device-group``,
                          ``traffic-group``, ``trust-domain``,
                          ``ha-group``.
                          PathRefs from ``device.cert`` /
                          ``device.key`` and ``trust-domain.ca-cert``
                          / ``ca-key`` / ``ca-devices[]`` /
                          ``trust-group`` auto-deref so
                          ``.cm["trust-domain"][].trust-group.devices``
                          walks ``trust-domain -> device-group ->
                          devices`` in one chain.
  .gtm.<kind>             Global Traffic Manager (DNS):
                          ``datacenter``, ``server``, ``pool``,
                          ``wideip``, ``listener``.  ``pool`` and
                          ``wideip`` merge all DNS record types
                          (``a / aaaa / cname / mx / srv / naptr``)
                          into one container; the DNS record type is
                          exposed as ``.record-type``.  PathRefs from
                          ``server.datacenter`` and ``wideip.pools[]``
                          / ``last-resort-pool`` auto-deref so chained
                          queries like ``.gtm.wideip[].pools[].ttl``
                          walk ``wideip -> pool -> ttl`` in one step.
  .apm.<kind>             Access Policy Manager: ``access-policy``,
                          ``policy-item``, ``policy-agent``,
                          ``customization-source``,
                          ``oauth-db-instance``,
                          ``ssh-security-config``,
                          ``default-report`` (singleton).
                          PathRefs from ``access-policy.items[]``,
                          ``start-item`` and ``default-ending``
                          auto-deref into ``policy-item`` so
                          ``.apm["access-policy"][].start-item.caption``
                          Just Works.
  .security.<kind>        Security (AFM): ``firewall-policy``,
                          ``firewall-rule-list``,
                          ``firewall-address-list``,
                          ``firewall-port-list``, ``nat-policy``,
                          ``nat-source-translation``,
                          ``nat-destination-translation``.

  The remaining modules — ``pem``, ``auth``, ``vcmp``, ``cli``,
  ``api-protection``, ``asm``, ``ilx``, ``wom``, ``analytics`` —
  have no typed projection: they appear at the root but hold no
  kinds.

  Any TMSH stanza the parser sees but no typed projection covers
  still lands in ``cfg.generic_objects`` with full byte ranges
  and is reachable via ``rename_partition`` / ``--scf`` source-
  level operations, but it is not navigable from the DSL.

ASSIGNMENT

  path = expr             Set the target field to ``expr`` (evaluated
                          against the outer input).
  path |= expr            "Update": set the target to ``path | expr``;
                          ``.`` inside expr is the current value.
  path += expr            Numeric add, string concat, or list append.
  path -= expr            Numeric sub, or remove items from a list.

Assigning to an object's identity field (``.name`` / ``."full-path"``)
auto-routes through the same engine ``f5 rename`` uses, rewriting
every reference to the object as well as its header.  A line like
``renamed X -> Y (N occurrences)`` is printed to stderr so the
multi-stanza rewrite is visible.

Writing into an iRule body in v1 is restricted to reference slots
(``.refs.pools[]`` etc.).  General command-argument rewriting is
deferred to v2.

OPERATORS AND PRECEDENCE

  Highest -> lowest:
    1. unary  '-', 'not'
    2. '*' '/'
    3. '+' '-'
    4. '==' '!=' '<' '<=' '>' '>='
    5. 'and'
    6. 'or'
    7. '|' (pipe)
    8. '=' '|=' '+=' '-=' (assignment)
    9. ';' (statement separator)

JQ COMPATIBILITY

  Core idioms match jq exactly:
    * ``.X[]`` is a stream-generator; ``|`` iterates it.
    * ``[ ... ]`` collects a stream into an array.
    * Bare builtin names (``length``, ``sort``, ``unique``) operate
      on ``.`` — equivalent to ``length(.)`` etc.
    * Plain lists pass through ``|`` whole — to iterate a list, use
      ``.[]`` (or pass it to a list-aware builtin like ``map``).

  Differences:
    * Function arguments are comma-separated, not semicolon-separated.
      ``sub(.name, "foo", "bar")`` rather than ``sub("foo"; "bar")``.
    * Stream-comma ``,`` and statement-semicolon ``;`` both
      concatenate their LHS and RHS values into one output stream.
      ``,`` joins within a pipeline (``.a, .b | length``); ``;``
      joins separate top-level statements that share the same root
      and observe each other's mutations (``rename(o, n); .x = y``).
    * Identifiers may contain ``-`` so TMSH-spelt keys like
      ``data-group`` and ``source-address-translation`` lex as a
      single bareword token — ``.source-address-translation`` parses
      as one field access, no quotes needed.  Quoting is only useful
      when the key would otherwise tokenise into something else
      (e.g. ``."full-path"`` so the ``.`` after ``full`` is not read
      as a field-access separator).
    * Regex matching has a dedicated subscript form ``["~pattern"]``
      rather than the ``test`` builtin.
    * Object-literal ``{ ... }`` constructors are supported (jq style:
      ``{ name, destination: .dest }`` builds a dict per input,
      ``{name}`` shorthand promotes ``.name``); string-interpolation
      ``"\(.x)"`` is not in v1 — use ``--json`` to render whole
      objects as structured output.

See also:
  --help-builtins      every function this DSL exposes
  --help-examples      a cookbook of common one-liners
"#;

/// Return the DSL grammar reference as a single string.
#[must_use]
pub fn format_grammar() -> String {
    GRAMMAR.to_string()
}

#[cfg(test)]
mod tests {
    use super::format_grammar;

    /// `--help-dsl`'s MODULES section names every kind an operator can
    /// navigate to. The set lives in `projection::KINDS`; this holds the prose
    /// to it, so a kind added there cannot ship undocumented.
    ///
    /// The lookup is scoped to the module's own block, because labels are only
    /// unique within a module: `ltm pool` and `gtm pool` are both ``pool``, so
    /// a global search would let the LTM mention vouch for a missing GTM one.
    #[test]
    fn modules_section_documents_every_projected_kind() {
        let grammar = format_grammar();
        let modules = grammar
            .split_once("\nMODULES\n")
            .expect("the grammar has a MODULES section")
            .1
            .split_once("\nASSIGNMENT\n")
            .expect("MODULES is followed by ASSIGNMENT")
            .0;

        // Each module's prose starts at its `  .<module>.<kind>` line and runs
        // to the next one.
        let mut blocks: Vec<(String, String)> = Vec::new();
        for line in modules.lines() {
            if let Some(rest) = line.strip_prefix("  .")
                && let Some((module, _)) = rest.split_once(".<kind>")
                && !module.is_empty()
                && module.chars().all(|c| c.is_ascii_lowercase() || c == '-')
            {
                blocks.push((module.to_owned(), String::new()));
            }
            if let Some((_, body)) = blocks.last_mut() {
                body.push_str(line);
                body.push('\n');
            }
        }
        assert!(
            blocks.len() >= 7,
            "expected a prose block per projected module, found {}",
            blocks.len()
        );

        let missing: Vec<String> = crate::projection::documented_kind_labels()
            .filter(|(kind, label)| {
                let module = kind.split(' ').next().unwrap_or_default();
                let documented = blocks
                    .iter()
                    .filter(|(m, _)| m == module)
                    .any(|(_, body)| body.contains(&format!("``{label}``")));
                !documented
            })
            .map(|(kind, label)| {
                format!(
                    "{kind} (as ``{label}`` under .{}.<kind>)",
                    kind.split(' ').next().unwrap_or_default()
                )
            })
            .collect();
        assert!(
            missing.is_empty(),
            "--help-dsl's MODULES section does not name these projected kinds \
             in their own module's block: {missing:?}"
        );
    }

    #[test]
    fn grammar_is_non_empty_with_expected_header() {
        let g = format_grammar();
        assert!(!g.is_empty(), "grammar reference must not be empty");
        assert!(
            g.starts_with("F5 QUERY DSL — GRAMMAR"),
            "grammar must start with the expected header, got: {:?}",
            &g[..g.len().min(40)]
        );
    }
}
