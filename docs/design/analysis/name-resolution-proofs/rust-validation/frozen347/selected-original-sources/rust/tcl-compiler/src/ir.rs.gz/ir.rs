// tcl-lsp — a language server and toolchain for Tcl
// Copyright (C) 2026 James Deucker (bitwisecook) <https://github.com/bitwisecook>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.
//
// SPDX-License-Identifier: AGPL-3.0-or-later

//! Intermediate representation (IR) for Tcl analysis.
//!
//! This is a structured IR front-end that keeps source [`Span`]s on all
//! nodes. Later passes lower this to CFG + SSA.
//!
//! **Architectural note:** every IR node carries a [`Span`] (two `u32`
//! byte offsets) rather than inline `(line, character, offset)` pairs.
//! Text and positions are resolved on demand via a
//! [`SourceMap`](tcl_lexer::SourceMap). This mirrors the span-first
//! design established in the lexer crate.

use tcl_lexer::{LexerConfig, SourceMap, Span, Token};
use tcl_registry::definer::{CallableRole, MemberReceiver};
/// A [`TryHandler`]'s selection vocabulary, the registry's clause-row fact.
pub use tcl_registry::value_transfer::HandlerMatch;

use crate::expr_ast::ExprNode;
use crate::segmenter::SegmentedCommand;

// Command tokens

/// A stable, function-local identity for a semantic IR node.
///
/// A node ID is a structural path, not a source offset.  Rebase operations
/// therefore preserve it, which is essential for compilation-unit caching and
/// for eventual guard/deoptimisation maps.  The ID is intentionally local to a
/// executable-semantic function; a procedure name or other function key
/// supplies the enclosing identity.
#[derive(Debug, Clone, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub struct NodeId(Vec<u32>);

impl NodeId {
    /// Create an ID from its deterministic structural path.
    ///
    /// This is public for IR transforms that preserve a node's identity. New
    /// source nodes should be allocated by the semantic-IR builder instead of
    /// manufacturing paths ad hoc.
    #[must_use]
    pub fn from_path(path: Vec<u32>) -> Self {
        Self(path)
    }

    /// Return the path segments that make up this function-local ID.
    #[must_use]
    pub fn path(&self) -> &[u32] {
        &self.0
    }
}

/// Why an IR site exists at a source location.
///
/// The source variant is used by the current lowering compatibility layer.
/// Transforming passes can retain the relationship to their source node(s)
/// through [`Self::Derived`] without inventing a misleading source span.
#[derive(Debug, Clone, PartialEq, Eq, Hash, Default)]
pub enum Provenance {
    /// Directly lowered from user-authored Tcl source.
    #[default]
    Source,
    /// Created by a semantic transform from one or more source nodes.
    Derived {
        /// Category of semantic transform that made this node.
        kind: DerivedKind,
        /// The source nodes that justify this derived node.
        origins: Vec<NodeId>,
    },
    /// A conservative compatibility placeholder for a hand-built or lossy
    /// IR node whose source origin cannot be established.
    Opaque,
}

/// The transform class for [`Provenance::Derived`].
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum DerivedKind {
    /// Desugared from an equivalent source construct.
    Desugared,
    /// Produced by constant folding.
    Folded,
    /// Cloned into a caller by inlining.
    Inlined,
    /// Created by a guarded specialisation.
    Specialised,
    /// Created by another named semantic transform.
    Synthetic,
}

/// A source range together with the reason the IR associates work with it.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct SourceSite {
    /// Byte span in the original source when known.
    pub span: Span,
    /// Origin relationship for this site.
    pub provenance: Provenance,
}

impl SourceSite {
    /// Build a direct user-source site.
    #[must_use]
    pub const fn source(span: Span) -> Self {
        Self {
            span,
            provenance: Provenance::Source,
        }
    }

    /// Build a transformed site while preserving its source relationship.
    #[must_use]
    pub fn derived(span: Span, kind: DerivedKind, origins: Vec<NodeId>) -> Self {
        Self {
            span,
            provenance: Provenance::Derived { kind, origins },
        }
    }

    /// Build an explicitly opaque compatibility site.
    #[must_use]
    pub const fn opaque(span: Span) -> Self {
        Self {
            span,
            provenance: Provenance::Opaque,
        }
    }
}

/// A lexical word expression retained by the semantic-IR compatibility layer.
///
/// This preserves ordering and source ranges for substitutions that the lexer
/// identifies.  It deliberately does **not** claim to fully model Tcl's
/// backslash substitution or all parser recovery forms: those remain
/// [`Self::Opaque`] until a later executable lowering can give them an exact
/// evaluation model.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub enum WordExpr {
    /// A single bare word with no substitutions or backslash processing.
    Literal {
        /// Compatibility argv spelling.
        text: String,
        /// Exact lexical source site.
        source: SourceSite,
    },
    /// A single braced word, whose content undergoes no substitution.
    BracedLiteral {
        /// De-braced word content.
        text: String,
        /// Exact lexical source site.
        source: SourceSite,
    },
    /// A single variable substitution word.
    Variable {
        /// Verbatim source spelling, including its Tcl variable wrapper.
        spelling: String,
        /// Exact lexical source site.
        source: SourceSite,
    },
    /// A single command-substitution word.
    CommandSubstitution {
        /// Compatibility argv spelling, including `[` and `]` where present.
        spelling: String,
        /// Exact lexical source site.
        source: SourceSite,
    },
    /// A compound word whose parts are evaluated left-to-right.
    Template {
        /// Ordered lexical parts.
        parts: Vec<WordPart>,
        /// Full source range of the word.
        source: SourceSite,
        /// C's message where its parser rejects the word for what follows
        /// a closing brace or quote (`{a}b`, `"a"b`, `{*}$x` under 8.4),
        /// which the parts still model leniently so the analyser reads
        /// them; a consumer that must not run past a parse error reads it.
        rejected: Option<&'static str>,
    },
    /// Tcl 8.5+ argument expansion around another word expression.
    Expand {
        /// Source range from the `{*}` marker through the inner word.
        source: SourceSite,
        /// Expanded word.
        word: Box<WordExpr>,
    },
    /// A word whose exact substitution behaviour is not represented by the
    /// legacy token snapshot.
    Opaque {
        /// Compatibility argv text.
        text: String,
        /// Best available source site.
        source: SourceSite,
        /// Why the semantic layer must not infer stronger meaning yet.
        reason: WordOpacity,
    },
}

impl WordExpr {
    /// A sole variable reference, including the reference inside quotes.
    /// The returned site belongs to the read, rather than its enclosing word;
    /// compound, expanded and opaque words provide no single read identity.
    #[must_use]
    pub fn sole_variable_substitution(&self) -> Option<(&str, &SourceSite)> {
        match self {
            Self::Variable { spelling, source } => Some((spelling, source)),
            Self::Template { parts, .. } => match parts.as_slice() {
                [WordPart::Variable { spelling, source }] => Some((spelling, source)),
                _ => None,
            },
            _ => None,
        }
    }

    /// A sole command substitution retains the command result object, including
    /// when quotes surround it. Compound words concatenate their values.
    #[must_use]
    pub fn sole_command_substitution(&self) -> Option<(&str, &SourceSite)> {
        match self {
            Self::CommandSubstitution { spelling, source } => Some((spelling, source)),
            Self::Template { parts, .. } => match parts.as_slice() {
                [WordPart::CommandSubstitution { spelling, source }] => Some((spelling, source)),
                _ => None,
            },
            _ => None,
        }
    }

    /// Return this word's source site.
    #[must_use]
    pub const fn source(&self) -> &SourceSite {
        match self {
            Self::Literal { source, .. }
            | Self::BracedLiteral { source, .. }
            | Self::Variable { source, .. }
            | Self::CommandSubstitution { source, .. }
            | Self::Template { source, .. }
            | Self::Expand { source, .. }
            | Self::Opaque { source, .. } => source,
        }
    }

    /// Recover the compatibility argv text used by existing consumers.
    #[must_use]
    pub fn legacy_text(&self) -> String {
        match self {
            Self::Literal { text, .. }
            | Self::BracedLiteral { text, .. }
            | Self::Opaque { text, .. } => text.clone(),
            Self::Variable { spelling, .. } => {
                crate::word_expr::compatibility_variable_spelling(spelling)
            }
            Self::CommandSubstitution { spelling, .. } => spelling.clone(),
            Self::Template { parts, .. } => parts.iter().map(WordPart::legacy_text).collect(),
            Self::Expand { word, .. } => word.legacy_text(),
        }
    }

    fn from_lossy_snapshot(
        text: &str,
        span: Span,
        kind: tcl_lexer::TokenType,
        single_token: bool,
        expanded: bool,
    ) -> Self {
        let source = SourceSite::opaque(span);
        let word = if single_token {
            match kind {
                tcl_lexer::TokenType::Str => Self::BracedLiteral {
                    text: text.to_owned(),
                    source,
                },
                tcl_lexer::TokenType::Var => Self::Variable {
                    spelling: text.to_owned(),
                    source,
                },
                tcl_lexer::TokenType::Cmd => Self::CommandSubstitution {
                    spelling: text.to_owned(),
                    source,
                },
                _ => Self::Opaque {
                    text: text.to_owned(),
                    source,
                    reason: WordOpacity::LossySnapshot,
                },
            }
        } else {
            Self::Opaque {
                text: text.to_owned(),
                source,
                reason: WordOpacity::LossySnapshot,
            }
        };
        if expanded {
            Self::Expand {
                source: SourceSite::opaque(span),
                word: Box::new(word),
            }
        } else {
            word
        }
    }
}

/// One ordered lexical component of a [`WordExpr::Template`].
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub enum WordPart {
    /// A plain or escaped text fragment. Backslash semantics remain explicit
    /// but unevaluated at this compatibility boundary.
    Text {
        /// Compatibility argv spelling.
        text: String,
        /// Exact lexical source site.
        source: SourceSite,
    },
    /// A variable substitution.
    Variable {
        /// Verbatim source spelling of this individual reference.
        spelling: String,
        /// Exact lexical source site.
        source: SourceSite,
    },
    /// A command substitution.
    CommandSubstitution {
        /// Compatibility argv spelling.
        spelling: String,
        /// Exact lexical source site.
        source: SourceSite,
    },
    /// A recovery or otherwise unmodelled token fragment.
    Opaque {
        /// Compatibility argv spelling.
        text: String,
        /// Exact lexical source site.
        source: SourceSite,
    },
}

impl WordPart {
    fn legacy_text(&self) -> String {
        match self {
            Self::Text { text, .. } | Self::Opaque { text, .. } => text.clone(),
            Self::Variable { spelling, .. } => {
                crate::word_expr::compatibility_variable_spelling(spelling)
            }
            Self::CommandSubstitution { spelling, .. } => spelling.clone(),
        }
    }
}

/// Why a [`WordExpr::Opaque`] node cannot make stronger semantic claims yet.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum WordOpacity {
    /// The compatibility snapshot lacked ordered lexical fragments.
    MissingFragments,
    /// The snapshot was synthetically constructed or retained only its legacy
    /// representative-token fields.
    LossySnapshot,
    /// C Tcl's parser rejects the word; the payload is its exact message
    /// (`missing close-bracket`, `missing )`, …) for diagnostics.
    ParseError(&'static str),
    /// The word carries a dialect substitution the word-component owner does
    /// not model — today only `JimTcl`'s `$(expr)` (`TokenType::ExprSugar`).
    ///
    /// `word_parts::decompose` applies Tcl's `$` rules, under which `$(` is
    /// ordinary text, so such a word would otherwise decompose to a single
    /// `Text` part and be promoted to [`WordExpr::Literal`] — and lowering
    /// would emit the *spelling* `$(1+2)` instead of evaluating it. The word
    /// is opaque instead.
    DialectSubstitution,
}

/// A statement the CFG builder **synthesised**: it models an analysis effect
/// or a codegen placeholder, and is never a Tcl command to run.
///
/// A [`Statement::Barrier`] normally *is* a command whose side effects defeat
/// static analysis (`eval`, a dynamic-body `catch`, `return -code …`), so
/// codegen dispatches it. The CFG builder also inserts statements that carry
/// only a `defs` list or a widening effect, and codegen must never emit an
/// invoke for one of *those*: a caller-frame widening that reused the
/// callee's own name would make
/// `proc p {} { upvar 1 {a b} v ; puts "u=$v" }; p` invoke `p` twice and
/// printed its body's output twice where tclsh 8.6.16 / 9.0.4 print it once.
///
/// The identity has to be **typed**, which is why this enum exists rather than
/// a list of reserved command spellings. A Tcl command name is an arbitrary
/// string, so every spelling the marker set used is a name a script may
/// legally define and call, and a name-based check silently dropped such a
/// call. Verified identical on tclsh 8.4.20, 8.5.19, 8.6.16, 9.0.4 and 9.1:
///
/// ```text
/// proc <cond> {} { puts "hit-cond" }
/// proc <caller-frame-opaque> {} { puts "hit-cfo" }
/// proc <global-frame-script> {} { puts "hit-gfs" }
/// proc <word-effects> {} { puts "hit-we" }
/// proc <empty_clause> {} { puts "hit-ec" }
/// <cond> ; <caller-frame-opaque> ; <global-frame-script>
/// <word-effects> ; <empty_clause>
/// ->  hit-cond / hit-cfo / hit-gfs / hit-we / hit-ec   (all five run)
/// ```
///
/// Not even the empty name is reservable — `proc {} {} { puts EMPTY-NAME-RAN
/// }; {}` prints `EMPTY-NAME-RAN` on all five releases — so no string sentinel
/// can carry this. A marker is recognised only through
/// [`CommandTokens::synthetic`], which both [`CommandTokens`] constructors
/// always leave `None`; nothing a script can write reaches
/// [`CommandTokens::marker`]. The statement keeps a readable `command`
/// spelling for the disassembly and the explorer — it is a label, not the
/// identity.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum SyntheticMarker {
    /// Evaluate a proved wrapper's original words before its script phases.
    /// This boundary performs no direct command invocation effects.
    EvaluatedArguments,
    /// Residual wrapper effects/completion after its semantic script phases.
    /// Original words are provenance and must not substitute again.
    EvaluatedWrapper,
    /// Map frozen dictionary inputs into caller variables before the script.
    DictionaryScopeEntry,
    /// Perform completion-sensitive dictionary writeback without replaying argv.
    DictionaryScopeWriteback(tcl_registry::completion_route::InvocationCompletionRoute),
    /// Bind the next iteration's variables after a proved loop dispatch.
    /// The readable command label and value words are provenance; this node
    /// does not invoke the source command again. Its payload is the input
    /// representation minted by the genuine typed iterator producer; None
    /// means this iterator selects named storage rather than a value operand.
    IterationBindings(Option<tcl_registry::TclType>),
    /// Store a proved catch's output values after its body has completed.
    /// Original argv and binding evidence are retained without reevaluation.
    CapturedCatchOutputs,
    /// The `if` / `while` condition kill-set: a [`Statement::Call`] whose
    /// `defs` are the variables the condition's own substitutions write, so a
    /// value-motion pass cannot carry a stale value across the branch.
    Condition,
    /// An empty `for` init / next clause. Codegen emits the three `nop`s
    /// tclsh's bytecode has there, so the clause keeps its place in the
    /// instruction stream.
    EmptyClause,
    /// Caller-side may-definitions for an embedded upvar procedure. The
    /// original host statement performs the invocation; this node only
    /// invalidates the reached caller variables.
    UpvarInvalidate,
    /// A selected registry invocation can evaluate code or mutate command
    /// bindings. This separate node widens facts without repeating dispatch
    /// or claiming an original native invocation or handler.
    RegistryBarrier,
    /// What the `[…]` substitutions in a statement's words do to the frame —
    /// the names they write, and those they read before writing — as a
    /// definition point of its own: the statement's words read a name before
    /// and after a substitution writes it, and a statement's SSA records one
    /// version of each name it reads. It is paired with the statement whose
    /// words they are by construction, never by span ([`WordEffectsHost`]).
    WordEffects(WordEffectsHost),
    /// A callee that runs an unreadable script at the global frame
    /// (`uplevel #0 $body`): it can write any global or namespace
    /// name, so the site widens instead of enumerating defs.
    GlobalFrameScript,
    /// A callee whose caller-frame `upvar` alias cannot be placed
    /// (`upvar 1 $computed x`): it can write any caller variable, so the call
    /// site widens. It sits *beside* the call it widens for, which is why
    /// naming the callee on it would make codegen run the callee twice.
    CallerFrameOpaque,
    /// A call to code the module cannot see — a head the module cannot name
    /// (a literal it neither defines nor the registry ships, an alias to the
    /// unresolved-command handler, a binding the source-order timeline cannot
    /// name, a computed head), a `source`, or code of that kind a script a
    /// statement keeps inside itself runs. That code may write, unset or read
    /// any name of the frame it is called from: a plain name at the top level
    /// is the global `::name`, and a procedure's local is in the reach of a
    /// callee that runs `upvar 1` or `uplevel 1`, which an autoloaded or
    /// unknown-handled callee can do on every release. The marker sits beside
    /// the call (ahead of the statement for a `[…]` substitution's call), is
    /// no command to run, and widens once: the SSA gives every name live past
    /// it a fresh version ([`crate::ssa::SsaFunction::value_clobbers`]),
    /// whose value is unknown while every proof about the version before it
    /// stands, and records the version each name holds where it sits
    /// ([`crate::ssa::SsaFunction::is_observed_by_unseen_call`]), which the
    /// code it reaches may read.
    UnseenCall,
    /// The names a statement that keeps its scripts inside itself may write
    /// into the frame, carried on a statement of its own beside it because the
    /// scripts are not lowered: what a callee an arm of an opaque `switch`
    /// calls writes (`zero line` with `upvar 1`), after the `switch`, and every
    /// name the body of an opaque `catch` or `try` writes, ahead of the call.
    /// The names are *may*-definitions of the statement, as the writes the arms
    /// of a `switch` make themselves are ([`crate::ssa::switch_may_defs`]).
    ArmWrites,
}

/// Where the statement whose words a [`SyntheticMarker::WordEffects`]
/// definition point states the effects of stands, as the CFG builder puts
/// the two ([`crate::ssa::word_effects_host`]).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum WordEffectsHost {
    /// The statement right after the definition point: an assignment, an
    /// expression or a command whose own words substitute.
    Statement,
    /// A control statement's words — a `return`'s value, a `switch`'s
    /// subject and patterns, a `catch` or `try` header — which run before the
    /// statement dispatches: no statement of the block holds them.
    Dispatch,
}

/// Original parsed tokens for a command invocation.
///
/// Carried on [`Statement::Call`] and [`Statement::Barrier`] so
/// downstream passes (optimiser, compiler checks) can inspect tokens
/// without re-lexing.
///
/// Token references use [`Span`]s into the
/// source buffer. The `argv_texts` and `single_token_word` fields
/// preserve the per-word metadata needed by analysis passes.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct CommandTokens {
    /// Per-word representative token spans.
    pub argv: Vec<Span>,
    /// Per-word text values.
    pub argv_texts: Vec<String>,
    /// Structured per-word syntax derived once during segmentation/lowering.
    ///
    /// [`Self::argv_texts`] and the representative-token arrays remain the
    /// compatibility view consumed by existing analyser and codegen passes.
    /// The semantic IR uses this ordered representation so it never needs to
    /// re-lex a Tcl word or infer substitution order from a flattened string.
    pub word_exprs: Vec<WordExpr>,
    /// Per-word representative token kind. Preserves the [`tcl_lexer::TokenType`]
    /// of each argv entry so analysis passes can distinguish a
    /// brace-string literal (`Str`) from a bareword (`Esc`), a
    /// variable reference (`Var`), or a command substitution
    /// (`Cmd`).
    pub argv_kinds: Vec<tcl_lexer::TokenType>,
    /// Whether each word consists of a single token.
    pub single_token_word: Vec<bool>,
    /// All tokens in the command (including separators).
    pub all_tokens: Vec<Span>,
    /// `{*}` expansion markers per word, if any word uses expansion.
    pub expand_word: Option<Vec<bool>>,
    /// The [`SyntheticMarker`] this statement *is*, when the CFG builder
    /// synthesised it to carry an effect rather than a command to run.
    ///
    /// `None` for everything that came from a Tcl word — both constructors
    /// hard-code it, so the only way to set it is [`Self::marker`], which no
    /// lowering path calls. That is the whole point: command *names* are
    /// forgeable (see [`SyntheticMarker`]), a private constructor is not.
    pub synthetic: Option<SyntheticMarker>,
    /// Proved immediate caller-frame script semantics, retaining runtime argv.
    pub evaluated_body: Option<Box<crate::execution_region::EvaluatedBodyRegion>>,
    /// Point-specific dispatch alternatives after source argument evaluation.
    ///
    /// `None` is an unqueried compatibility snapshot. An explicitly uncertain
    /// answer must never be replaced with a written-head catalogue lookup.
    pub source_binding: Option<crate::command_binding::SourceInvocationBinding>,
    /// Exact nested dispatch proofs keyed by the nested command head's source offset.
    pub nested_bindings: Vec<(u32, crate::command_binding::SourceInvocationBinding)>,
    /// Bindings at reached reads during original argument evaluation or the
    /// selected native expression. Temporal owners distinguish those phases;
    /// executed script bodies are excluded. Reads can differ within one word.
    /// A missing record supplies no proof of the cell read.
    pub variable_accesses: Vec<crate::command_binding::SourceVariableAccess>,
    /// Actual hosted source/context for conditional taint metadata only.
    /// This grants no handler, store, effects, Normal or native compiler facts.
    pub hosted_taint_context:
        Option<std::sync::Arc<crate::registry_invocation::HostedSourceTaintContext>>,
}

impl CommandTokens {
    /// Retained execution grammar for nested source parsing. An unqueried or
    /// dialect-unknown carrier keeps the caller's lexical configuration.
    #[must_use]
    pub fn native_lexer_config(&self, fallback: tcl_lexer::LexerConfig) -> tcl_lexer::LexerConfig {
        self.source_binding
            .as_ref()
            .and_then(|binding| binding.variable_context.invocation_dialect)
            .map_or(fallback, |native| {
                fallback.with_grammar(native.lexer_grammar)
            })
    }

    /// Relocate physical cells in retained source proofs; lexical spans and command allocations remain source-owned.
    pub fn relocate_variable_proofs(
        &mut self,
        relocation: &crate::var_resolve::VariableProofRelocation,
    ) {
        if let Some(binding) = &mut self.source_binding {
            binding.relocate_variable_proofs(relocation);
        }
        for (_, binding) in &mut self.nested_bindings {
            binding.relocate_variable_proofs(relocation);
        }
        for access in &mut self.variable_accesses {
            *access = access.relocated_variables(relocation);
        }
    }

    /// Refresh actual source ownership while preserving the lowered word layout.
    /// Synthetic iteration inputs contain a selected argv projection, rather
    /// than the original command's entire argument vector. Source restoration
    /// must neither replace that projection nor make it execute again.
    pub fn restore_source_proofs(&mut self, original: &Self) {
        self.hosted_taint_context
            .clone_from(&original.hosted_taint_context);
        self.source_binding.clone_from(&original.source_binding);
        self.nested_bindings.clone_from(&original.nested_bindings);
        self.variable_accesses
            .clone_from(&original.variable_accesses);
    }

    /// Build a token snapshot from the segmenter without losing word shape.
    ///
    /// `sm` is the buffer the segment's spans index into — the document, or a
    /// sub-lexed slice carrying its document base
    /// ([`SourceMap::with_base`]) — and `config` is that document's grammar,
    /// resolved once at the ingress and threaded here so every word is
    /// decomposed under the release it is written for.
    #[must_use]
    pub fn from_segmented(sm: &SourceMap<'_>, config: LexerConfig, seg: &SegmentedCommand) -> Self {
        let expand = seg.expand_word.as_deref();
        // One reused buffer: `WordExpr::from_word` takes the word's lexer
        // tokens, and the segmenter keeps them behind its own fragment type.
        let mut fragments: Vec<Token> = Vec::new();
        let mut word_exprs = Vec::with_capacity(seg.argv.len());
        for (idx, token) in seg.argv.iter().enumerate() {
            fragments.clear();
            fragments.extend(
                seg.word_fragments
                    .get(idx)
                    .map_or(&[][..], Vec::as_slice)
                    .iter()
                    .map(|fragment| fragment.token),
            );
            let text = seg.texts.get(idx).map_or("", String::as_str);
            let expanded = expand
                .and_then(|flags| flags.get(idx))
                .copied()
                .unwrap_or(false);
            let expansion_span = expanded
                .then(|| {
                    seg.all_tokens
                        .iter()
                        .rev()
                        .find(|candidate| {
                            candidate.kind == tcl_lexer::TokenType::Expand
                                && candidate.span.end() <= token.span.start()
                        })
                        .map(|candidate| candidate.span)
                })
                .flatten();
            word_exprs.push(WordExpr::from_word(
                sm,
                config,
                &fragments,
                text,
                expanded,
                expansion_span,
            ));
        }
        Self {
            argv: seg.argv.iter().map(|token| token.span).collect(),
            argv_texts: seg.texts.clone(),
            word_exprs,
            argv_kinds: seg.argv.iter().map(|token| token.kind).collect(),
            single_token_word: seg.single_token_word.clone(),
            all_tokens: seg.all_tokens.iter().map(|token| token.span).collect(),
            expand_word: seg.expand_word.clone(),
            // Came from a Tcl word, so it is a command however it is spelled.
            synthetic: None,
            evaluated_body: None,
            source_binding: None,
            nested_bindings: Vec::new(),
            variable_accesses: Vec::new(),
            hosted_taint_context: None,
        }
    }

    /// A token snapshot for a statement the CFG builder synthesised — see
    /// [`SyntheticMarker`] for why the marker has to live here rather than in
    /// the statement's `command` spelling.
    ///
    /// The word vectors are empty: a marker has no words, and
    /// [`Self::words_align_with_argv_text`] holds trivially. Consumers that
    /// need real word data (the WASM source-compatibility view) already
    /// decline a snapshot they cannot line up, which is the conservative
    /// direction.
    #[must_use]
    pub fn marker(kind: SyntheticMarker) -> Self {
        Self {
            argv: Vec::new(),
            argv_texts: Vec::new(),
            word_exprs: Vec::new(),
            argv_kinds: Vec::new(),
            single_token_word: Vec::new(),
            all_tokens: Vec::new(),
            expand_word: None,
            synthetic: Some(kind),
            evaluated_body: None,
            source_binding: None,
            nested_bindings: Vec::new(),
            variable_accesses: Vec::new(),
            hosted_taint_context: None,
        }
    }

    /// Build compatibility token data when only the parallel arrays are
    /// available.
    ///
    /// New source lowering should use [`Self::from_segmented`]. This adapter
    /// intentionally produces opaque word nodes for data that cannot preserve
    /// ordered fragments; it never guesses Tcl substitution semantics.
    #[must_use]
    pub fn from_lossy_parts(
        argv: Vec<Span>,
        argv_texts: Vec<String>,
        argv_kinds: Vec<tcl_lexer::TokenType>,
        single_token_word: Vec<bool>,
        all_tokens: Vec<Span>,
        expand_word: Option<Vec<bool>>,
    ) -> Self {
        let word_exprs = argv_texts
            .iter()
            .enumerate()
            .map(|(idx, text)| {
                let span = argv.get(idx).copied().unwrap_or_else(|| Span::new(0, 0));
                let kind = argv_kinds
                    .get(idx)
                    .copied()
                    .unwrap_or(tcl_lexer::TokenType::Esc);
                let single = single_token_word.get(idx).copied().unwrap_or(false);
                let expanded = expand_word
                    .as_ref()
                    .and_then(|flags| flags.get(idx))
                    .copied()
                    .unwrap_or(false);
                WordExpr::from_lossy_snapshot(text, span, kind, single, expanded)
            })
            .collect();
        Self {
            argv,
            argv_texts,
            word_exprs,
            argv_kinds,
            single_token_word,
            all_tokens,
            expand_word,
            // A lossy snapshot of real words is still a command.
            synthetic: None,
            evaluated_body: None,
            source_binding: None,
            nested_bindings: Vec::new(),
            variable_accesses: Vec::new(),
            hosted_taint_context: None,
        }
    }

    /// Attach proved script semantics without changing invocation tokens.
    #[must_use]
    pub fn with_evaluated_body(
        mut self,
        region: crate::execution_region::EvaluatedBodyRegion,
    ) -> Self {
        self.evaluated_body = region.valid().then(|| Box::new(region));
        self
    }

    /// Retain the shared command owner's answer, including explicit uncertainty.
    #[must_use]
    pub fn with_source_binding(
        mut self,
        binding: crate::command_binding::SourceInvocationBinding,
    ) -> Self {
        self.source_binding = Some(binding);
        self
    }

    /// Resolve a retained read by its exact source reference and spelling.
    /// The invocation context is sampled later and cannot replace this query.
    #[must_use]
    pub fn variable_access_at(
        &self,
        source: &SourceSite,
        spelling: &str,
    ) -> Option<&crate::command_binding::SourceVariableAccess> {
        crate::command_binding::SourceVariableAccess::find_at_source(
            &self.variable_accesses,
            source,
            spelling,
        )
    }

    /// Query a unique original read site without interpreting a compatibility
    /// spelling. Conflicting records at that exact site remain unresolved.
    #[must_use]
    pub fn variable_access_for_site(
        &self,
        source: &SourceSite,
    ) -> Option<&crate::command_binding::SourceVariableAccess> {
        crate::command_binding::SourceVariableAccess::find_at_site(&self.variable_accesses, source)
    }

    /// Inherit exact nested dispatch proofs from the owning source invocation.
    /// A missing or non-source nested site stays explicitly unknown when the
    /// parent was queried; it never recovers meaning from a written head.
    pub fn inherit_nested_bindings(&mut self, parent: &Self) {
        self.hosted_taint_context
            .clone_from(&parent.hosted_taint_context);
        self.nested_bindings.clone_from(&parent.nested_bindings);
        self.variable_accesses.clone_from(&parent.variable_accesses);
        if parent.source_binding.is_none() {
            return;
        }
        let offset = self
            .words()
            .first()
            .filter(|word| word.source().provenance == Provenance::Source)
            .map(|word| word.source().span.start());
        self.source_binding = Some(
            offset
                .and_then(|offset| {
                    parent
                        .nested_bindings
                        .iter()
                        .find(|(site, _)| *site == offset)
                        .map(|(_, binding)| binding.clone())
                })
                .unwrap_or_else(crate::command_binding::SourceInvocationBinding::unknown),
        );
    }

    /// Whether this snapshot explicitly declines a unique registry target.
    ///
    /// This is distinct from an old snapshot that has never been queried.
    #[must_use]
    pub fn has_unproved_source_binding(&self) -> bool {
        self.source_binding.as_ref().is_some_and(|binding| {
            binding
                .proved_execution_target()
                .is_none_or(|target| !target.registry_backed)
        })
    }

    /// Return an attached execution plan only when its routing is complete.
    ///
    /// Consumers use this fact to avoid recovering script effects a second time.
    #[must_use]
    pub fn evaluated_body(&self) -> Option<&crate::execution_region::EvaluatedBodyRegion> {
        self.evaluated_body
            .as_deref()
            .filter(|region| region.valid())
    }

    /// Structured word expressions in argv order.
    #[must_use]
    pub fn words(&self) -> &[WordExpr] {
        &self.word_exprs
    }

    /// Whether this boundary evaluates its written words. Residual wrapper
    /// boundaries refer to the argv already evaluated before entering phases.
    #[must_use]
    pub fn evaluates_words(&self) -> bool {
        !matches!(
            self.synthetic,
            Some(
                SyntheticMarker::EvaluatedWrapper
                    | SyntheticMarker::DictionaryScopeEntry
                    | SyntheticMarker::DictionaryScopeWriteback(_)
                    | SyntheticMarker::IterationBindings(_)
                    | SyntheticMarker::CapturedCatchOutputs
            )
        )
    }

    /// Whether the structured compatibility view still aligns with argv text.
    ///
    /// Synthetic codegen snapshots may intentionally omit representative spans
    /// or argv text, so this checks the one invariant the semantic sidecar
    /// requires rather than imposing a stronger invariant on compatibility
    /// consumers.
    #[must_use]
    pub fn words_align_with_argv_text(&self) -> bool {
        self.word_exprs.len() == self.argv_texts.len()
    }

    /// Complete original-word compatibility presentations agree with this
    /// carrier. This is consistency only: source/config/currentness, synthetic
    /// purpose, Native identity and effective alias/expansion argv are checked
    /// separately by the original owner. Count-only compatibility snapshots
    /// continue to use words_align_with_argv_text.
    pub(crate) fn original_words_match_argv_text(&self) -> bool {
        self.words_align_with_argv_text()
            && self
                .words()
                .iter()
                .zip(&self.argv_texts)
                .all(|(word, text)| word.legacy_text() == *text)
    }

    /// Whether **argument** `idx` (0-based, so `argv[idx + 1]`) is a
    /// brace-quoted literal word — `{…}`, the one word form Tcl leaves
    /// completely unsubstituted.
    ///
    /// The IR stores argument *content*, which cannot tell `{$a}` (the
    /// literal three-character name `$a`) from `$a` (a substitution); the
    /// per-word token kind can.  A `$var` lexes to `Var`, a `[cmd]` to `Cmd`,
    /// a `"…"` (which *does* substitute) to `Esc`, and only a brace-quoted
    /// word to `Str`.
    ///
    /// The single-token conjunct is belt-and-braces: a word that opens with
    /// `{` must be entirely brace-quoted (`set x {a}{b}` is a tclsh parse
    /// error, "extra characters after close-brace"), so a `Str`
    /// representative token already implies a single-token word.
    ///
    /// The one definition of this question in the compiler — the dynamic-name
    /// barrier, the place bridge, the inliner's literal-argument binding and
    /// the def/use naming layer all ask it here rather than re-deriving it.
    #[must_use]
    pub fn arg_is_braced_literal(&self, idx: usize) -> bool {
        let Some(word_index) = idx.checked_add(1) else {
            return false;
        };
        self.argv_kinds.get(word_index) == Some(&tcl_lexer::TokenType::Str)
            && self
                .single_token_word
                .get(word_index)
                .copied()
                .unwrap_or(true)
    }
}

// IR node types
//
// IR node kinds are modelled as a flat enum with struct variants.
// Each variant carries a `Span` for position tracking, plus
// variant-specific fields.

/// Command-resolution context for an executable script root or nested body.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub enum ExecutionNamespace {
    /// The selected frame's defining namespace is statically known.
    Exact(String),
    /// Retained native or reached source-allocation identity and exact geometry.
    SourceContext(crate::command_binding::SourceNamespaceKey),
    /// A receiver- or caller-selected namespace is known only at runtime.
    RuntimeSelected,
}

impl ExecutionNamespace {
    /// Construct an exact command-resolution namespace.
    #[must_use]
    pub fn exact(namespace: impl Into<String>) -> Self {
        Self::Exact(namespace.into())
    }

    /// Select an identity-aware lookup context without parsing a display name.
    #[must_use]
    pub fn for_head_context(
        &self,
        head: &str,
    ) -> Option<std::borrow::Cow<'_, crate::command_binding::SourceNamespaceKey>> {
        use crate::command_binding::SourceNamespaceKey;
        match self {
            Self::SourceContext(context) => Some(std::borrow::Cow::Borrowed(context)),
            Self::Exact(namespace) => Some(std::borrow::Cow::Owned(SourceNamespaceKey::authored(
                if head.starts_with("::") {
                    "::"
                } else {
                    namespace
                },
            ))),
            Self::RuntimeSelected if head.starts_with("::") => {
                Some(std::borrow::Cow::Owned(SourceNamespaceKey::authored("::")))
            }
            Self::RuntimeSelected => None,
        }
    }

    /// Use the original evaluated head with the same identity-aware selector.
    #[must_use]
    pub fn for_invocation_context(
        &self,
        head: &str,
        tokens: Option<&CommandTokens>,
    ) -> Option<std::borrow::Cow<'_, crate::command_binding::SourceNamespaceKey>> {
        let evaluated = tokens
            .and_then(|tokens| tokens.source_binding.as_ref())
            .and_then(crate::command_binding::SourceInvocationBinding::evaluated_command_word);
        self.for_head_context(evaluated.unwrap_or(head))
    }

    /// Select the lookup route from the captured evaluated head. A lowered
    /// implementation name does not replace an absolute original invocation.
    #[must_use]
    pub fn for_invocation(&self, head: &str, tokens: Option<&CommandTokens>) -> Option<&str> {
        let evaluated = tokens
            .and_then(|tokens| tokens.source_binding.as_ref())
            .and_then(crate::command_binding::SourceInvocationBinding::evaluated_command_word);
        self.for_head(evaluated.unwrap_or(head))
    }

    /// Resolve one command head. Absolute names remain exact even in a
    /// runtime-selected frame; relative names do not.
    #[must_use]
    pub fn for_head(&self, head: &str) -> Option<&str> {
        if matches!(self, Self::SourceContext(_)) {
            return None;
        }
        if head.starts_with("::") {
            Some("::")
        } else {
            match self {
                Self::Exact(namespace) => Some(namespace),
                Self::SourceContext(_) | Self::RuntimeSelected => None,
            }
        }
    }

    pub(crate) fn selected_frame(&self, absolute: bool, frame_shift: i32) -> Self {
        match (absolute, frame_shift) {
            (true, 0) => Self::exact("::"),
            (false, 0) => self.clone(),
            _ => Self::RuntimeSelected,
        }
    }
}

/// A script: a sequence of IR statements.
///
/// Using `Vec` rather than a tuple because scripts are built incrementally
/// during lowering.
#[derive(Debug, Clone, PartialEq, Eq, Hash, Default)]
pub struct Script {
    /// Actual namespace owner for this retained executable body.
    pub namespace_context: Option<Box<crate::command_binding::SourceNamespaceKey>>,
    /// Exact evaluated source instance. Absence means no source mapping proof.
    pub executed_source: Option<std::sync::Arc<crate::command_binding::ExecutedScriptSource>>,
    /// Original function occurrences, with reached proofs or conditional
    /// topology retaining an unmet actual binding-validation obligation.
    pub implicit_math_invocations: Vec<crate::command_binding::SourceMathInvocation>,
    /// Successful native expression preparation, before reached operand effects.
    pub expression_preparations: Vec<crate::command_binding::SourceExpressionPreparation>,
    /// Statements in execution order.
    pub statements: Vec<Statement>,
    /// Registry-resolved command heads consumed by typed lowering.
    ///
    /// Keeping these sites beside the script makes the dependency explicit in
    /// IR and lets CFG/codegen preserve it without re-parsing source fragments.
    pub command_binding_sites: CommandBindingSites,
    /// Exact user-procedure definitions whose bodies were copied into this
    /// script by an executable inlining transform.
    pub procedure_binding_requirements: ProcedureBindingRequirements,
    /// Rejection proved at this chunk's actual native compilation entry.
    /// An inventory of possible failures cannot populate this field.
    pub native_compilation_failure:
        Option<Box<crate::command_binding::SourceNativeCompilationFailure>>,
    /// Target-neutral chunk admission, preserving unresolved compiler paths.
    pub native_compilation_admission:
        Option<std::sync::Arc<crate::native_compilation_admission::NativeCompilationAdmission>>,
}

/// Compact storage for the uncommon typed-lowering dependency sidecar.
///
/// Most scripts contain no command whose head disappears during structured
/// lowering. A boxed slice omits `Vec`'s unused capacity word and avoids
/// inflating every recursively nested [`Script`] (and the [`Statement`]
/// variants which contain several of them).
#[derive(Debug, Clone, PartialEq, Eq, Hash, Default)]
pub struct CommandBindingSites(Box<[CommandBindingSite]>);

impl CommandBindingSites {
    /// Iterate over the retained typed-lowering dependencies.
    pub fn iter(&self) -> impl Iterator<Item = &CommandBindingSite> {
        self.0.iter()
    }

    /// Mutably iterate over the retained typed-lowering dependencies.
    pub fn iter_mut(&mut self) -> impl Iterator<Item = &mut CommandBindingSite> {
        self.0.iter_mut()
    }

    /// Unanimous original carrier of one actual statement. A synthetic marker
    /// owns its explicit phase carrier; consumed runtime-command sites at the
    /// same wrapper span cannot donate or contradict that different phase.
    pub(crate) fn unanimous_statement_source_tokens<'a>(
        sites: impl IntoIterator<Item = &'a CommandBindingSite>,
        statement: &'a Statement,
    ) -> Option<&'a CommandTokens> {
        if let Some(tokens) = statement.tokens()
            && tokens.synthetic.is_some()
        {
            return Some(tokens);
        }
        let mut candidates = statement.tokens().into_iter().chain(
            sites
                .into_iter()
                .filter(|site| site.span == statement.span())
                .filter_map(|site| site.source_tokens.as_deref()),
        );
        let first = candidates.next()?;
        candidates
            .all(|candidate| candidate == first)
            .then_some(first)
    }
}

impl CommandBindingSite {
    /// Relocate physical variable proof while retaining the consumed dispatch and lexical site.
    pub fn relocate_variable_proofs(
        &mut self,
        relocation: &crate::var_resolve::VariableProofRelocation,
    ) {
        if let Some(context) = &self.variable_context {
            self.variable_context = Some(std::sync::Arc::new(context.relocated(relocation)));
        }
        if let Some(frame) = &self.variable_frame {
            self.variable_frame = Some(relocation.frame(frame));
        }
        if let Some(tokens) = &mut self.source_tokens {
            tokens.relocate_variable_proofs(relocation);
        }
    }
}

/// Compact storage for user-procedure dependencies introduced by inlining.
#[derive(Debug, Clone, PartialEq, Eq, Hash, Default)]
pub struct ProcedureBindingRequirements(Box<[tcl_runtime_api::ProcedureBindingIdentity]>);

impl ProcedureBindingRequirements {
    /// Iterate over the exact user-procedure dependencies.
    pub fn iter(&self) -> impl Iterator<Item = &tcl_runtime_api::ProcedureBindingIdentity> {
        self.0.iter()
    }
}

impl From<Vec<tcl_runtime_api::ProcedureBindingIdentity>> for ProcedureBindingRequirements {
    fn from(requirements: Vec<tcl_runtime_api::ProcedureBindingIdentity>) -> Self {
        Self(requirements.into_boxed_slice())
    }
}

impl From<Vec<CommandBindingSite>> for CommandBindingSites {
    fn from(sites: Vec<CommandBindingSite>) -> Self {
        Self(sites.into_boxed_slice())
    }
}

/// One command dependency retained after typed lowering consumes its head.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct CommandBindingSite {
    /// Exact source span of the complete owning Tcl command.
    pub span: Span,
    /// Source spelling and registry-resolved implementation identity.
    pub binding: tcl_runtime_api::CommandBindingIdentity,
    /// Namespace objects proved to exist at this exact dispatch site. `None`
    /// denotes a compatibility node with no source-state query.
    pub known_namespaces: Option<Vec<String>>,
    /// Actual variable activation proved at this dispatch site.
    pub variable_frame: Option<crate::var_resolve::VariableExecutionFrame>,
    /// Complete shared variable binding snapshot, including aliases and generations.
    pub variable_context: Option<std::sync::Arc<crate::var_resolve::ResolveContext>>,
    /// Namespace cells allocated on every reaching path at this site.
    pub existing_namespace_cells: Option<Vec<crate::var_resolve::VariableCellKey>>,
    /// Original source words and exact nested/read proofs consumed by typed IR.
    /// Generated dependencies have no source carrier and retain `None`.
    pub source_tokens: Option<Box<CommandTokens>>,
}

/// Whether a command's normal result contributes to its enclosing script.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum StatementResultUse {
    /// A later real command discards the preceding normal result.
    Discarded,
    /// The final command supplies the enclosing completion's result.
    EnclosingCompletion,
    /// The requested command or its source ownership is unavailable.
    Unknown,
}

impl Script {
    /// Prefer a retained namespace owner over a presentation-derived default.
    #[must_use]
    pub fn execution_namespace(&self, fallback: ExecutionNamespace) -> ExecutionNamespace {
        self.namespace_context.as_deref().map_or(fallback, |key| {
            ExecutionNamespace::SourceContext(key.clone())
        })
    }

    /// Original invocation carrier for a statement owned by this script.
    /// Typed lowering can move that carrier into a consumed binding site.
    /// Conflicting retained carriers or synthetic boundaries provide no answer.
    #[must_use]
    pub fn retained_source_tokens_for_statement<'a>(
        &'a self,
        statement: &'a Statement,
    ) -> Option<&'a CommandTokens> {
        if !self
            .statements
            .iter()
            .any(|candidate| std::ptr::eq(candidate, statement))
        {
            return None;
        }
        CommandBindingSites::unanimous_statement_source_tokens(
            self.command_binding_sites.iter(),
            statement,
        )
        .filter(|tokens| tokens.synthetic.is_none())
    }

    /// Classify normal result use without confusing synthetic phase boundaries
    /// with real Tcl commands. Abrupt completion and effects remain separate.
    #[must_use]
    pub fn statement_result_use(&self, index: usize) -> StatementResultUse {
        let Some(statement) = self.statements.get(index) else {
            return StatementResultUse::Unknown;
        };
        if !self.is_authored_source() || statement.source_edit_span().is_none() {
            return StatementResultUse::Unknown;
        }
        if self.statements[index + 1..].iter().any(|statement| {
            statement.source_edit_span().is_some()
                && statement
                    .tokens()
                    .is_none_or(|tokens| tokens.synthetic.is_none())
        }) {
            StatementResultUse::Discarded
        } else {
            StatementResultUse::EnclosingCompletion
        }
    }

    /// Whether every byte belongs to an original authored source instance.
    #[must_use]
    pub fn is_authored_source(&self) -> bool {
        self.executed_source.as_ref().is_some_and(|source| {
            matches!(
                source.origin.kind(),
                crate::command_binding::SourceOriginKind::Authored(_)
            )
        })
    }

    /// Whether this script and every retained child have authored mappings.
    /// Whole structured rewrites cannot insert a derived body's bytes by offset.
    #[must_use]
    pub fn is_fully_authored_source(&self) -> bool {
        let mut pending = vec![self];
        while let Some(script) = pending.pop() {
            if !script.is_authored_source() {
                return false;
            }
            for statement in &script.statements {
                pending.extend(statement.child_scripts());
            }
        }
        true
    }

    /// Project an edit only when this script has an authored source mapping.
    #[must_use]
    pub fn source_edit_span(&self, span: Span) -> Option<Span> {
        self.is_authored_source().then_some(span)
    }

    /// Create an empty script.
    #[must_use]
    pub fn new() -> Self {
        Self {
            statements: Vec::new(),
            command_binding_sites: CommandBindingSites::default(),
            procedure_binding_requirements: ProcedureBindingRequirements::default(),
            native_compilation_failure: None,
            native_compilation_admission: None,
            namespace_context: None,
            executed_source: None,
            implicit_math_invocations: Vec::new(),
            expression_preparations: Vec::new(),
        }
    }

    /// Create a script from a list of statements.
    #[must_use]
    pub fn from_statements(statements: Vec<Statement>) -> Self {
        Self {
            statements,
            command_binding_sites: CommandBindingSites::default(),
            procedure_binding_requirements: ProcedureBindingRequirements::default(),
            native_compilation_failure: None,
            native_compilation_admission: None,
            namespace_context: None,
            executed_source: None,
            implicit_math_invocations: Vec::new(),
            expression_preparations: Vec::new(),
        }
    }

    /// Create a lowered script with explicit typed-lowering dependencies.
    #[must_use]
    pub fn from_lowered_parts(
        statements: Vec<Statement>,
        command_binding_sites: Vec<CommandBindingSite>,
    ) -> Self {
        Self {
            statements,
            command_binding_sites: command_binding_sites.into(),
            procedure_binding_requirements: ProcedureBindingRequirements::default(),
            native_compilation_failure: None,
            native_compilation_admission: None,
            namespace_context: None,
            executed_source: None,
            implicit_math_invocations: Vec::new(),
            expression_preparations: Vec::new(),
        }
    }

    /// Create transformed executable IR with both registry and user-procedure
    /// binding dependencies retained explicitly.
    #[must_use]
    pub fn from_transformed_parts(
        statements: Vec<Statement>,
        command_binding_sites: Vec<CommandBindingSite>,
        procedure_binding_requirements: Vec<tcl_runtime_api::ProcedureBindingIdentity>,
    ) -> Self {
        Self {
            statements,
            command_binding_sites: command_binding_sites.into(),
            procedure_binding_requirements: procedure_binding_requirements.into(),
            native_compilation_failure: None,
            native_compilation_admission: None,
            namespace_context: None,
            executed_source: None,
            implicit_math_invocations: Vec::new(),
            expression_preparations: Vec::new(),
        }
    }

    /// Whether every statement compiles to a single fall-through block — no
    /// branch, join, loop or unwinding `return`. That is the shape the inline
    /// collecting-`lmap` codegen needs: it strips the body's trailing `POP` and
    /// appends the result via one `LMAP_COLLECT` on the fall-through tail, so a
    /// branch or join (an `if`, `while`, `switch` or nested loop) or a `return`
    /// that unwinds past the collect point would drop or mis-gather results.
    /// Lowering keeps such a body's `lmap` on the runtime builtin, and a pass
    /// that rewrites a body afterwards must not give it one.
    #[must_use]
    pub fn is_straight_line(&self) -> bool {
        self.statements.iter().all(|statement| {
            matches!(
                statement,
                Statement::Call { .. }
                    | Statement::AssignConst { .. }
                    | Statement::AssignExpr { .. }
                    | Statement::AssignValue { .. }
                    | Statement::Incr { .. }
                    | Statement::ExprEval { .. }
                    | Statement::Barrier { .. }
            )
        })
    }
}

/// Depth cap for [`for_each_statement`]'s recursion over nested
/// `if`/`for`/`while`/`foreach`/`catch`/`try`/`switch`/`uplevel` bodies.
/// Transitively bounded via `MAX_LOWER_NEST_DEPTH` (every
/// `Script` this crate hands to `for_each_statement` was built by
/// [`crate::lowering`], which already caps its own construction at 256 and
/// emits a `Statement::Barrier` past that point), capped here independently
/// for defence-in-depth and consistency with every other full-tree walker in
/// this crate (`optimiser::MAX_OPTIMISER_WALK_DEPTH`,
/// `codegen::structured::MAX_STRUCTURED_DEPTH`), since this is a `pub`
/// utility any future caller could hand a `Script` built some other way.
const MAX_FOR_EACH_STATEMENT_DEPTH: tcl_core_types::RecursionLimit =
    tcl_core_types::RecursionLimit(256);

/// Recursively visit every statement in `script`, including nested bodies
/// (`if`/`for`/`while`/`foreach`/`catch`/`try`/`switch`), in source order.
/// Each statement is visited before its own nested bodies (pre-order): a
/// compound statement (`If`, `For`, …) is passed to `visit` once for itself,
/// then its nested scripts are walked in turn.
///
/// Shared traversal for whole-module / whole-body scans that need "every
/// statement anywhere in this script" without each re-deriving the same
/// nested-body match arms (e.g. [`crate::var_observability::scan_module_global_names`]).
///
/// Nesting past [`MAX_FOR_EACH_STATEMENT_DEPTH`] (256) is silently not
/// descended into — `visit` still runs for every statement up to and
/// including that depth, matching this function's existing "best-effort
/// scan" contract (callers already tolerate this visitor skipping statements
/// it cannot reach, e.g. inside opaque `Statement::Barrier`s).
pub fn for_each_statement(script: &Script, visit: &mut impl FnMut(&Statement)) {
    for_each_statement_inner(script, visit, 0);
}

/// Visit every retained script, including nested bodies, without native-stack
/// recursion. The visitor may update metadata; it must retain the body tree.
pub fn for_each_script_mut(script: &mut Script, visit: &mut impl FnMut(&mut Script)) {
    let mut pending = vec![script];
    while let Some(script) = pending.pop() {
        visit(script);
        for statement in script.statements.iter_mut().rev() {
            pending.extend(statement.child_scripts_mut().into_iter().rev());
        }
    }
}

fn for_each_statement_inner(script: &Script, visit: &mut impl FnMut(&Statement), depth: u32) {
    if MAX_FOR_EACH_STATEMENT_DEPTH.exceeded(depth) {
        return;
    }
    for stmt in &script.statements {
        visit(stmt);
        for body in stmt.child_scripts() {
            for_each_statement_inner(body, visit, depth + 1);
        }
    }
}

/// An `if` clause: condition + body.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct IfClause {
    /// The parsed condition expression.
    pub condition: ExprNode,
    /// Source span of the condition text.
    pub condition_span: Span,
    /// Absolute source offset of the condition *text*'s first byte, when
    /// the text handed to `parse_expr` is a verbatim source slice (single
    /// braced / bare word).  Expression-AST leaf offsets are relative to
    /// that text, so `condition_base + leaf.start` recovers an absolute
    /// operand span.  `None` when the text was reconstructed (quoted /
    /// multi-token words) — consumers fall back to `condition_span`.
    pub condition_base: Option<u32>,
    /// Body script to execute when the condition is true.
    pub body: Script,
    /// Source span of the body text.
    pub body_span: Span,
}

/// A `try` handler clause — a clause of the command's clause plan that is
/// selected by its pattern word.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct TryHandler {
    /// The vocabulary the handler's pattern word selects it by — the clause
    /// row's [`HandlerMatch`]: a completion code (`try`'s `on`) or an
    /// `-errorcode` prefix (`trap`).
    pub kind: HandlerMatch,
    /// Return code or error class pattern to match.
    pub match_arg: String,
    /// Parsed error-code prefix for a statically literal `trap` selector.
    ///
    /// `None` means either an `on` handler, a selector containing Tcl word
    /// substitutions, or a malformed Tcl list. Literal `$`, `[`, and
    /// backslashes remain ordinary element data when protected by braces or
    /// escapes; lowering decides that from source token shape before the
    /// decoded word loses the distinction.
    pub trap_pattern: Option<Vec<String>>,
    /// Variable bound to the result, if any.
    pub var_name: Option<String>,
    /// Variable bound to the options dict, if any.
    pub options_var: Option<String>,
    /// Handler body.
    pub body: Script,
    /// Source span of the handler body.
    pub body_span: Span,
    /// `true` when the handler body is the literal `-` fallthrough
    /// marker: the handler shares the next non-fallthrough handler's
    /// body (Tcl `try` semantics, mirroring `switch`). `body` is an
    /// empty script in that case — the `-` is *not* a command call.
    pub fallthrough: bool,
}

/// A `switch` arm: pattern + body.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct SwitchArm {
    /// Pattern text: an element of a braced arm list is its decoded value,
    /// and a pattern given as a separate word is its spelling with the
    /// delimiters removed, as the subject of a `Statement::Switch` is —
    /// `value_transfer::recorded_word_value` gives that word's value.
    pub pattern: String,
    /// Whether this arm's pattern word was braced, so its value is literal.
    ///
    /// Per-arm, because the two arm forms differ per *word*: a single braced
    /// `{pat body …}` block holds literal list elements, while the multi-word
    /// form (`switch $s $pat {body}`) is a word each, and `{${x}}` there is
    /// literal while a bare `$pat` substitutes. The whole-switch
    /// `Statement::Switch::patterns_braced` cannot say that, and using it
    /// substituted a braced pattern.
    pub pattern_braced: bool,
    /// Source span of the pattern.
    pub pattern_span: Span,
    /// Body script (`None` for fall-through arms).
    pub body: Option<Script>,
    /// Source span of the body (`None` for fall-through arms).
    pub body_span: Option<Span>,
    /// Whether this arm falls through to the next.
    pub fallthrough: bool,
}

/// An iterator group in a `foreach`/`lmap`/`dict for` loop.
///
/// Each group pairs a list of loop variable names with the list
/// argument text they iterate over.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct ForeachIterator {
    /// Variable names assigned each iteration.
    pub vars: Vec<String>,
    /// Source text of the list argument.
    pub list_arg: String,
    /// Whether the *list* word was a brace-string literal
    /// (`foreach n {a $b c} …`). Braces suppress substitution, so a
    /// `$b` inside such a word is a literal three-character list
    /// element, not a read of `b` — tclsh 8.6.14: `foreach n {a $b c}
    /// {puts $n}` prints `a`, `$b`, `c` with `b` undefined throughout.
    ///
    /// [`list_arg`](Self::list_arg) stores the word's *content* (braces
    /// already stripped), which cannot tell `{$b}` from `$b`; this flag
    /// is the same distinction [`Statement::AssignConst::braced`],
    /// [`Statement::Return::braced`] and
    /// [`CommandTokens::arg_is_braced_literal`] carry for their own
    /// words.
    pub list_braced: bool,
}

/// An IR statement — the building block of the compiler pipeline.
///
/// Each variant
/// carries a [`Span`] for position tracking. The span is resolved
/// to text or `(line, character)` via a `SourceMap` on demand.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub enum Statement {
    /// Exact native words evaluated by the ordinary runtime dispatcher.
    /// Their byte/source identities grant no catalogue or inline authority.
    NativeCall {
        /// Original complete command extent.
        span: Span,
        /// Original operands, including expansion and substitution structure.
        words: Vec<tcl_lexer::word_parts::NativeWord>,
    },
    /// Constant assignment: `set name value` where value is a literal.
    AssignConst {
        /// Source span of the full command.
        span: Span,
        /// Variable name.
        name: String,
        /// Whether the *name* word was a brace-string literal
        /// (`set {a($x)} v`). Braces suppress substitution, so an
        /// array-element target's key (`a($x)`) must be pushed
        /// LITERALLY (`$x` stays `$x`) rather than substituted — and,
        /// conversely, a *non*-braced name word still has its backslash
        /// escapes to decode before it is a variable name.
        /// Mirrors the `braced` precedent on [`Self::Return`].
        /// Defaults to `false` for every construction site except
        /// the `set` lowering hook (only it knows the source token
        /// kind); resolved by codegen's `store_target`, which
        /// `push_var_ref` / `emit_incr` then consume.
        name_braced: bool,
        /// Constant value text.
        value: String,
        /// Content span of the value *word* when `value` is written
        /// verbatim in the source at this statement (the writable
        /// provenance a rename may splice a new command name over).
        /// `None` when the constant has no exact source
        /// representation — a synthesised constant (folding,
        /// desugaring, an optimiser rewrite) or a word whose content
        /// was reconstructed — in which case value-provenance
        /// consumers must abstain rather than guess a span.
        value_span: Option<Span>,
    },

    /// Expression assignment: `set name [expr ...]`.
    AssignExpr {
        /// Source span of the full command.
        span: Span,
        /// Variable name.
        name: String,
        /// Whether the *name* word was a brace-string literal — see
        /// [`Self::AssignConst::name_braced`].
        name_braced: bool,
        /// Parsed expression AST.
        expr: ExprNode,
        /// Live command binding whose registry identity justified fusing the
        /// nested command. This is generic binding metadata (source spelling
        /// plus canonical implementation), not an `expr`-name flag: aliases
        /// therefore carry their own binding identity into bytecode.
        command_binding: Option<tcl_runtime_api::CommandBindingIdentity>,
        /// Original value word (`[expr ...]`) before this statement was
        /// fused. Codegen replays this through the ordinary `set` value path
        /// when the whole-module command-binding summary says `expr` no
        /// longer denotes its registry builtin. Keeping the exact word here
        /// preserves quoting, substitutions, and an overridden command's
        /// argv instead of trying to reconstruct Tcl source from the AST.
        fallback_value: String,
        /// Absolute source offset of the expression text's first byte —
        /// see [`IfClause::condition_base`].  `None` when the expression
        /// text is not a verbatim source slice.
        expr_base: Option<u32>,
    },

    /// General value assignment: `set name value` where value may
    /// contain substitutions.
    AssignValue {
        /// Source span of the full command.
        span: Span,
        /// Variable name.
        name: String,
        /// Whether the *name* word was a brace-string literal — see
        /// [`Self::AssignConst::name_braced`].
        name_braced: bool,
        /// Value text (may contain backslash substitutions).
        value: String,
        /// Whether the value contains backslash substitutions.
        value_needs_backsubst: bool,
        /// Command tokens for downstream analysis.
        tokens: Option<CommandTokens>,
    },

    /// Increment: `incr name ?amount?`.
    Incr {
        /// Source span.
        span: Span,
        /// Variable name.
        name: String,
        /// Whether the *name* word was a brace-string literal — see
        /// [`Self::AssignConst::name_braced`].
        name_braced: bool,
        /// Increment amount (None = 1).
        amount: Option<String>,
        /// Whether the *amount* word was a brace-string literal
        /// (`incr x {$n}`): its text is the amount itself, never a
        /// substitution — the program raises `expected integer but got
        /// "$n"` — mirroring [`Self::AssignConst::name_braced`] for the name.
        amount_braced: bool,
        /// Whether it is safe if the variable is uninitialised.
        safe_on_uninit: bool,
    },

    /// Standalone expression evaluation: `expr ...`.
    ExprEval {
        /// Source span.
        span: Span,
        /// Source binding whose registry implementation this specialised
        /// expression evaluation assumes.
        command_binding: tcl_runtime_api::CommandBindingIdentity,
        /// Parsed expression AST.
        expr: ExprNode,
        /// Absolute source offset of the expression text's first byte —
        /// see [`IfClause::condition_base`].  `None` when the expression
        /// text is not a verbatim source slice.
        expr_base: Option<u32>,
    },

    /// A generic command invocation.
    ///
    /// Optionally annotated with variables it defines/reads.
    Call {
        /// Source span.
        span: Span,
        /// Command name as it appeared in source — preserves the
        /// original spelling for diagnostics ("unknown command
        /// `Foo`" reads better than "unknown command `::Foo`").
        command: String,
        /// Canonical command name resolved against the
        /// registry.  `None` when the lowerer hasn't (yet)
        /// populated it or when the command is unknown to the registry.
        /// This spelling is presentation metadata; semantic consumers resolve
        /// the retained point proof through the shared invocation adapter.
        /// The lowerer populates
        /// it when an alias resolves (`interp alias {} foo {} ::ns::bar; foo
        /// 1 2` lowers to a `Call` with `command="foo"` and
        /// `canonical_command=Some("::ns::bar")`).
        canonical_command: Option<String>,
        /// Argument texts.
        args: Vec<String>,
        /// Variables defined by this command.
        defs: Vec<String>,
        /// Variables read by this command (beyond `$`-references in args).
        reads: Vec<String>,
        /// Whether defined variables are also read (read-before-write).
        reads_own_defs: bool,
        /// Whether it is safe if defined variables are uninitialised.
        safe_on_uninit: bool,
        /// Command tokens for downstream analysis.
        tokens: Option<CommandTokens>,
        /// Per-iterator-group sizes for synthetic `foreach` /
        /// `lmap` / `dict for` / `dict map` header calls produced
        /// by the CFG builder.  ``Some([n0, n1, …])`` encodes that
        /// `defs` is a flattened concatenation of `n0` + `n1` + …
        /// vars per iterator group, so the codegen can reconstruct
        /// the original `var-list` ↔ `list-arg` pairing.  ``None``
        /// for every other call shape.
        foreach_groups: Option<Vec<usize>>,
    },

    /// Return statement: `return ?value?`.
    Return {
        /// Source span.
        span: Span,
        /// Original return invocation and nested substitution lookup proofs.
        tokens: Option<CommandTokens>,
        /// Return value text, if any.
        value: Option<String>,
        /// Canonical source word for [`Self::Return::value`], when the simple
        /// return form retained one. Codegen uses it only to decide whether a
        /// nested local-name opcode can consume a final literal value.
        value_word: Option<WordExpr>,
        /// Return expression, if any (for `return [expr ...]`).
        expr: Option<ExprNode>,
        /// Exact expression source base, absent when decoded bytes lack an affine source mapping.
        expr_base: Option<u32>,
        /// Live command binding whose registry identity justified compiling a
        /// nested command substitution directly into [`expr`](Self::Return::expr).
        ///
        /// This is separate from the outer `return` command's binding: the
        /// latter remains owned by the statement source boundary, while this
        /// dependency belongs to the consumed nested command (`expr`, or a
        /// registry-proved alias for it).
        command_binding: Option<tcl_runtime_api::CommandBindingIdentity>,
        /// Whether the value was braced.
        braced: bool,
    },

    /// A command whose side effects defeat static analysis.
    ///
    /// Commands like `eval`, `uplevel`, and `upvar` can modify
    /// arbitrary variables at runtime, so no constant propagation or
    /// dead-store reasoning can cross a barrier.
    Barrier {
        /// Source span.
        span: Span,
        /// Human-readable reason for the barrier.
        reason: String,
        /// Original command name (source-surface spelling).
        command: String,
        /// Canonical command name resolved against the
        /// registry.  See [`Statement::Call::canonical_command`].
        canonical_command: Option<String>,
        /// Original argument texts.
        args: Vec<String>,
        /// Command tokens for downstream analysis.
        tokens: Option<CommandTokens>,
    },

    /// Inline group of statements to splice into the enclosing
    /// script *without* introducing a separate scope. Produced by
    /// [`crate::inline_uplevel`] when a passthrough callsite is
    /// rewritten — the callee's body runs in the caller's frame, so
    /// it can be flattened directly into the parent block stream.
    /// Also produced by const-propagation when an `eval` /
    /// `uplevel` body resolves to a brace-literal.
    Block {
        /// Source span of the original call that produced this block.
        span: Span,
        /// The pre-lowered body, evaluated in the enclosing scope.
        body: Script,
        /// Fully-qualified namespace the body was lowered in.
        namespace: String,
        /// Original command-tokens snapshot for downstream analysis
        /// (lets diagnostics still report the source surface form).
        tokens: Option<CommandTokens>,
        /// Registry-owned Tcl error context contributed by this inlined body.
        /// `None` for transparent passthrough and synthetic blocks.
        error_context: Option<tcl_registry::InlineBodyErrorContext>,
    },

    /// Static-body uplevel — `uplevel ?level? {body}` where the body
    /// is a brace-string literal so the body's IR can be lowered
    /// inline. Models the "shift the active frame, evaluate body,
    /// restore frame" semantics that `uplevel` provides without the
    /// runtime [`Self::Barrier`] dispatch.
    ///
    /// Codegen emits `frame_depth_stash`
    /// / `frame_depth_restore` around the body.
    UpFrame {
        /// Source span of the original `uplevel` call.
        span: Span,
        /// The level argument's magnitude — `1` for `uplevel 1
        /// {body}` (the canonical form) and for a bare `uplevel
        /// {body}`, `0` for `uplevel #0 {body}` or `uplevel 0
        /// {body}`. Read it together with [`Self::UpFrame::absolute`]:
        /// the same magnitude means two different frames depending on
        /// that flag.
        frame_shift: i32,
        /// `true` when the level was written in the `#N` *absolute*
        /// form, counting down from the global frame (`uplevel #0`
        /// evaluates the body in the global frame). `false` for the
        /// *relative* form, counting up from the current frame
        /// (`uplevel 0` evaluates the body in the current frame,
        /// `uplevel 1` in the caller's).
        ///
        /// The distinction is load-bearing, not cosmetic: `uplevel #0`
        /// and `uplevel 0` are different frames whenever the current
        /// frame is not the global one, so bare command words in the
        /// body resolve against different namespaces
        /// (tclsh8.6/9.0-confirmed).
        absolute: bool,
        /// The pre-lowered body, evaluated at the shifted frame.
        body: Script,
        /// Original command tokens for downstream analysis.
        tokens: Option<CommandTokens>,
    },

    /// Conditional: `if cond body ?elseif cond body ...? ?else body?`.
    If {
        /// Source span.
        span: Span,
        /// `if`/`elseif` clauses in order.
        clauses: Vec<IfClause>,
        /// Optional `else` body.
        else_body: Option<Script>,
        /// Source span of the `else` body.
        else_span: Option<Span>,
    },

    /// `for` loop: `for init cond next body`.
    For {
        /// Source span.
        span: Span,
        /// Initialisation script.
        init: Script,
        /// Source span of the init script.
        init_span: Span,
        /// Loop condition expression.
        condition: ExprNode,
        /// Source span of the condition.
        condition_span: Span,
        /// Absolute source offset of the condition text — see
        /// [`IfClause::condition_base`].
        condition_base: Option<u32>,
        /// Next-iteration script.
        next: Script,
        /// Source span of the next script.
        next_span: Span,
        /// Loop body.
        body: Script,
        /// Source span of the body.
        body_span: Span,
        /// Raw argument texts for generic fallback.
        raw_args: Vec<String>,
        /// Per-word source token metadata for the generic ("frozen") runtime
        /// fallback, when the loop cannot be inlined (a command-substitution
        /// condition). Carries the original word kinds so the fallback pushes
        /// braced `{cond}` / `{body}` words verbatim and substituted words
        /// (`$body`) interpolated — exactly as written. `None` for
        /// synthetically-constructed loops that never take the fallback.
        raw_tokens: Option<Box<CommandTokens>>,
    },

    /// `while` loop: `while cond body`.
    While {
        /// Source span.
        span: Span,
        /// Loop condition expression.
        condition: ExprNode,
        /// Source span of the condition.
        condition_span: Span,
        /// Absolute source offset of the condition text — see
        /// [`IfClause::condition_base`].
        condition_base: Option<u32>,
        /// Loop body.
        body: Script,
        /// Source span of the body.
        body_span: Span,
        /// Raw argument texts for generic fallback.
        raw_args: Vec<String>,
        /// Per-word source token metadata for the generic ("frozen") runtime
        /// fallback — see [`Statement::For::raw_tokens`].
        raw_tokens: Option<CommandTokens>,
    },

    /// `foreach`/`lmap`/`dict for`/`dict map` loop.
    Foreach {
        /// Source span.
        span: Span,
        /// Iterator groups: `(var_list, list_arg)` pairs.
        iterators: Vec<ForeachIterator>,
        /// Loop body.
        body: Script,
        /// Source span of the body.
        body_span: Span,
        /// Whether this is an `lmap` (returns a list).
        is_lmap: bool,
        /// Raw argument texts for generic fallback.
        raw_args: Vec<String>,
        /// Whether this is `dict for`/`dict map`.
        is_dict_iteration: bool,
        /// Whether this is `array for {k v} arr body` (Tcl 9.0). Unlike a plain
        /// `foreach`, the body runs in the caller's frame over an *array* (not a
        /// list value), so analysis inlines it into the caller unit (binding the
        /// loop vars) while codegen barriers it to the `::tcl::array::for`
        /// ensemble invoke — see `lower_foreach_dispatch`.
        is_array_iteration: bool,
        /// Per-word source token metadata for the generic runtime fallback
        /// (the `dict for`/`map` barrier and the runtime `foreach`/`lmap`
        /// call), so braced var-lists / bodies are pushed verbatim and
        /// `$list` arguments substituted — see [`Statement::For::raw_tokens`].
        raw_tokens: Option<CommandTokens>,
    },

    /// `catch script ?resultVar? ?optionsVar?`.
    Catch {
        /// Source span.
        span: Span,
        /// Body script to evaluate.
        body: Script,
        /// Source span of the body.
        body_span: Span,
        /// Variable for the result, if any.
        result_var: Option<String>,
        /// Variable for the options dict, if any.
        options_var: Option<String>,
        /// Raw argument texts for generic fallback.
        raw_args: Vec<String>,
        /// Original parsed tokens, including braced/quoted flags.
        /// Threaded through so the CFG's `Catch → Call` lowering
        /// (`emit_opaque_catch`) can preserve the `{…}` braces
        /// around the body when the codegen falls back to
        /// `tcl_eval`.  Without this, ``catch {$undef} msg`` would
        /// be reconstructed as ``catch $undef msg`` and the
        /// unset-var read would fire before catch could intercept
        /// it.
        tokens: Option<CommandTokens>,
    },

    /// `try body ?on/trap ...? ?finally body?`.
    Try {
        /// Source span.
        span: Span,
        /// Body script.
        body: Script,
        /// Source span of the body.
        body_span: Span,
        /// Handler clauses.
        handlers: Vec<TryHandler>,
        /// Optional `finally` body.
        finally_body: Option<Script>,
        /// Source span of the `finally` body.
        finally_span: Option<Span>,
        /// Raw argument texts for generic fallback.
        raw_args: Vec<String>,
    },

    /// `switch` statement.
    Switch {
        /// Source span.
        span: Span,
        /// The subject word as the source spells it, its delimiters removed:
        /// a bare or quoted word's escapes are not decoded and a braced
        /// word's continuations are not collapsed, so this is a spelling, not
        /// a value. `value_transfer::recorded_word_value` gives the value the
        /// selection and the dispatch chain read it by.
        subject: String,
        /// `true` when the subject came from a braced word, so its value is
        /// literal and suppresses substitution.
        ///
        /// The sibling of [`Self::Switch::patterns_braced`], and asked for the
        /// same reason: codegen hands the subject to the expression emitter as
        /// a word, and a word that lost its braces on the way in is
        /// indistinguishable from a bare one. Without this,
        /// `switch -- {a[nosuchcmd]}` *ran* `nosuchcmd` where both oracles
        /// match the literal and take the default arm. Defaults to `false` —
        /// an unbraced subject substitutes, which is the common form.
        subject_braced: bool,
        /// Source span of the subject.
        subject_span: Span,
        /// Pattern/body arms.
        arms: Vec<SwitchArm>,
        /// Optional default body.
        default_body: Option<Script>,
        /// Source span of the default body.
        default_span: Option<Span>,
        /// Match mode: `"exact"`, `"glob"`, or `"regexp"`.
        mode: SwitchMode,
        /// Whether matching is case-insensitive.
        nocase: bool,
        /// Raw argument texts for generic fallback.
        raw_args: Vec<String>,
        /// Per-[`Self::Switch::raw_args`] "this word was braced" flags, for the
        /// generic-invoke fallback the opaque modes take.
        ///
        /// `raw_args` are *values*, and a value cannot say how it was written,
        /// so the emitter that pushes them has no way to tell a braced word's
        /// literal content from a bare word that still substitutes. Fabricating
        /// the flags — marking only a single braced arm list — sends everything
        /// else out substituting: `switch -glob -- {a[bc]d}` runs `bc`, and the
        /// pattern `{a\[bc\]d}` decodes to `a[bc]d` and matches as a character
        /// class, so it matches `abd` and not the literal both oracles match.
        ///
        /// Empty when the flags are unknown (a hand-built statement), which the
        /// emitter reads as "none braced" — the prior behaviour.
        raw_arg_braced: Vec<bool>,
        /// Per-[`Self::Switch::raw_args`] "this word was double-quoted" flags,
        /// beside [`Self::Switch::raw_arg_braced`]: a word neither braced nor
        /// quoted was spelled bare, which is how 9.1b0's byte-compiled
        /// `switch` recognises a fall-through body — so the selection record
        /// reads a quoted `-` apart from a bare one. Empty when unknown.
        raw_arg_quoted: Vec<bool>,
        /// The command as the source spells it: `switch`, or another
        /// case-list command lowered through the same hook (`case`). The
        /// generic invoke of an opaque form names it.
        command: String,
        /// `true` when the arms came from a single braced
        /// `{pat body …}` block — patterns are literal list elements
        /// with no substitution. `false` when supplied as separate
        /// words (`switch $s $pat {body}`), where each pattern
        /// undergoes normal `$var` / `[cmd]` runtime substitution
        /// before matching. Defaults to `true`, the canonical braced form.
        patterns_braced: bool,
    },
}

/// Traverse only retained child scripts; opaque operands are never reparsed.
pub(crate) fn statements_have_opaque_native_accesses<'a>(
    statements: impl IntoIterator<Item = &'a Statement>,
) -> bool {
    let mut nested = Vec::new();
    for statement in statements {
        if statement.has_opaque_native_accesses() {
            return true;
        }
        nested.extend(statement.child_scripts());
    }
    while let Some(script) = nested.pop() {
        for statement in &script.statements {
            if statement.has_opaque_native_accesses() {
                return true;
            }
            nested.extend(statement.child_scripts());
        }
    }
    false
}

impl Statement {
    /// The statement standing where code the module cannot see runs
    /// ([`SyntheticMarker::UnseenCall`]): it carries no name and is no command
    /// to run. The SSA gives the names live past it fresh versions and records
    /// the version each name holds where it stands.
    #[must_use]
    pub fn unseen_call_marker(span: Span) -> Self {
        Self::Call {
            span,
            command: "<unseen-call>".to_owned(),
            canonical_command: None,
            args: Vec::new(),
            defs: Vec::new(),
            reads: Vec::new(),
            reads_own_defs: false,
            safe_on_uninit: false,
            tokens: Some(CommandTokens::marker(SyntheticMarker::UnseenCall)),
            foreach_groups: None,
        }
    }

    /// The definition point of what the `[…]` substitutions in a statement's
    /// words do to the frame ([`SyntheticMarker::WordEffects`]): the names
    /// they write and those they read before writing, for the statement
    /// `host` places. It carries no command to run.
    #[must_use]
    pub fn word_effects(
        span: Span,
        (defs, reads): (Vec<String>, Vec<String>),
        host: WordEffectsHost,
    ) -> Self {
        Self::Call {
            span,
            command: "<word-effects>".to_owned(),
            canonical_command: None,
            args: Vec::new(),
            defs,
            reads,
            reads_own_defs: false,
            safe_on_uninit: false,
            tokens: Some(CommandTokens::marker(SyntheticMarker::WordEffects(host))),
            foreach_groups: None,
        }
    }

    /// Where the statement whose words this definition point states the
    /// effects of stands, when this is one ([`SyntheticMarker::WordEffects`]).
    #[must_use]
    pub fn word_effects_host(&self) -> Option<WordEffectsHost> {
        match self.synthetic_marker() {
            Some(SyntheticMarker::WordEffects(host)) => Some(host),
            _ => None,
        }
    }

    /// Return the synthetic marker attached to this statement, when it has
    /// one. Markers carry analysis-only effects beside their source command.
    #[must_use]
    pub fn synthetic_marker(&self) -> Option<SyntheticMarker> {
        match self {
            Self::Call { tokens, .. } | Self::Barrier { tokens, .. } => {
                tokens.as_ref().and_then(|tokens| tokens.synthetic)
            }
            _ => None,
        }
    }

    /// Whether native byte operands lack a named-variable/effect projection.
    /// Empty SSA read or definition maps for this statement do not prove that
    /// it leaves variables, command bindings or other runtime state unchanged.
    #[must_use]
    pub const fn has_opaque_native_accesses(&self) -> bool {
        matches!(self, Self::NativeCall { .. })
    }

    /// Retained child scripts in source/phase order. Only the original generic
    /// invocation owns an evaluated region; synthetic phase boundaries carry
    /// provenance without owning another copy of its scripts.
    #[must_use]
    pub fn child_scripts(&self) -> Vec<&Script> {
        match self {
            Self::Block { body, .. }
            | Self::UpFrame { body, .. }
            | Self::While { body, .. }
            | Self::Catch { body, .. }
            | Self::Foreach { body, .. } => vec![body],
            Self::If {
                clauses, else_body, ..
            } => clauses
                .iter()
                .map(|clause| &clause.body)
                .chain(else_body.iter())
                .collect(),
            Self::For {
                init, next, body, ..
            } => vec![init, next, body],
            Self::Try {
                body,
                handlers,
                finally_body,
                ..
            } => std::iter::once(body)
                .chain(handlers.iter().map(|handler| &handler.body))
                .chain(finally_body.iter())
                .collect(),
            Self::Switch {
                arms, default_body, ..
            } => arms
                .iter()
                .filter_map(|arm| arm.body.as_ref())
                .chain(default_body.iter())
                .collect(),
            Self::Call {
                tokens: Some(tokens),
                ..
            }
            | Self::Barrier {
                tokens: Some(tokens),
                ..
            } if tokens.synthetic.is_none() => {
                tokens.evaluated_body().map_or_else(Vec::new, |region| {
                    region.phases.iter().map(|phase| &phase.script).collect()
                })
            }
            _ => Vec::new(),
        }
    }

    /// Mutable projection of the same owned scripts as [`Self::child_scripts`].
    /// Visitors may change metadata while preserving the retained phase graph.
    pub fn child_scripts_mut(&mut self) -> Vec<&mut Script> {
        match self {
            Self::Block { body, .. }
            | Self::UpFrame { body, .. }
            | Self::While { body, .. }
            | Self::Catch { body, .. }
            | Self::Foreach { body, .. } => vec![body],
            Self::If {
                clauses, else_body, ..
            } => clauses
                .iter_mut()
                .map(|clause| &mut clause.body)
                .chain(else_body.iter_mut())
                .collect(),
            Self::For {
                init, next, body, ..
            } => vec![init, next, body],
            Self::Try {
                body,
                handlers,
                finally_body,
                ..
            } => std::iter::once(body)
                .chain(handlers.iter_mut().map(|handler| &mut handler.body))
                .chain(finally_body.iter_mut())
                .collect(),
            Self::Switch {
                arms, default_body, ..
            } => arms
                .iter_mut()
                .filter_map(|arm| arm.body.as_mut())
                .chain(default_body.iter_mut())
                .collect(),
            Self::Call {
                tokens: Some(tokens),
                ..
            }
            | Self::Barrier {
                tokens: Some(tokens),
                ..
            } if tokens.synthetic.is_none() => tokens
                .evaluated_body
                .as_deref_mut()
                .filter(|region| region.valid())
                .map_or_else(Vec::new, |region| {
                    region
                        .phases
                        .iter_mut()
                        .map(|phase| &mut phase.script)
                        .collect()
                }),
            _ => Vec::new(),
        }
    }

    /// Original invocation words when retained by lowering. Typed operations
    /// without this carrier retain their consumed proof in `CommandBindingSite`.
    #[must_use]
    pub fn tokens(&self) -> Option<&CommandTokens> {
        match self {
            Self::AssignValue { tokens, .. }
            | Self::Return { tokens, .. }
            | Self::Call { tokens, .. }
            | Self::Barrier { tokens, .. }
            | Self::Block { tokens, .. }
            | Self::Catch { tokens, .. }
            | Self::UpFrame { tokens, .. }
            | Self::While {
                raw_tokens: tokens, ..
            }
            | Self::Foreach {
                raw_tokens: tokens, ..
            } => tokens.as_ref(),
            Self::For { raw_tokens, .. } => raw_tokens.as_deref(),
            _ => None,
        }
    }

    /// Whether this statement represents an invocation that code generation
    /// and command-effect analyses must execute.
    ///
    /// Unseen calls, registry barriers and upvar invalidations widen facts
    /// only; the original invocation beside them performs dispatch. Other
    /// synthetic statements retain their existing executable semantics.
    #[must_use]
    pub fn is_executable_invocation(&self) -> bool {
        !matches!(
            self.synthetic_marker(),
            Some(
                SyntheticMarker::UnseenCall
                    | SyntheticMarker::RegistryBarrier
                    | SyntheticMarker::UpvarInvalidate
            )
        )
    }

    /// Whether this is the barrier a `return` lowers to when it leaves the
    /// procedure or its completion is not known — `return` with options
    /// ([`crate::lowering::hooks::control::try_lower_return`]) or with an
    /// expanded word. The CFG takes it for a procedure exit, and it writes
    /// no variable.
    #[must_use]
    pub fn is_return_barrier(&self) -> bool {
        matches!(
            self,
            Self::Barrier { reason, .. }
                if matches!(reason.as_str(), "return with options" | "return with expansion")
        )
    }

    /// Mutable invocation carrier, for owner-controlled provenance transfer.
    pub fn tokens_mut(&mut self) -> Option<&mut CommandTokens> {
        match self {
            Self::AssignValue { tokens, .. }
            | Self::Return { tokens, .. }
            | Self::Call { tokens, .. }
            | Self::Barrier { tokens, .. }
            | Self::Block { tokens, .. }
            | Self::Catch { tokens, .. }
            | Self::UpFrame { tokens, .. }
            | Self::While {
                raw_tokens: tokens, ..
            }
            | Self::Foreach {
                raw_tokens: tokens, ..
            } => tokens.as_mut(),
            Self::For { raw_tokens, .. } => raw_tokens.as_deref_mut(),
            _ => None,
        }
    }
    /// A source command range eligible for command-level editing. Typed CFG
    /// boundaries may retain a diagnostic span on an enclosing operand, but
    /// they are not commands and must never delete that operand's delimiters.
    /// Consumers still need their usual reachability/effect and origin proof.
    #[must_use]
    pub fn source_edit_span(&self) -> Option<Span> {
        if self.has_opaque_native_accesses() {
            return None;
        }
        if self.tokens().is_some_and(|tokens| {
            tokens.synthetic.is_some()
                || tokens
                    .source_binding
                    .as_ref()
                    .and_then(|binding| binding.source_origin())
                    .is_some_and(|origin| {
                        matches!(
                            origin.kind(),
                            crate::command_binding::SourceOriginKind::Derived { .. }
                        )
                    })
        }) {
            return None;
        }
        let span = self.span();
        (!span.is_empty()).then_some(span)
    }

    /// Return the source span of this statement, including diagnostic spans
    /// retained by synthetic boundaries. Use `source_edit_span` for editing.
    #[must_use]
    pub fn span(&self) -> Span {
        match self {
            Self::AssignConst { span, .. }
            | Self::AssignExpr { span, .. }
            | Self::AssignValue { span, .. }
            | Self::Incr { span, .. }
            | Self::ExprEval { span, .. }
            | Self::Call { span, .. }
            | Self::Return { span, .. }
            | Self::Barrier { span, .. }
            | Self::NativeCall { span, .. }
            | Self::Block { span, .. }
            | Self::UpFrame { span, .. }
            | Self::If { span, .. }
            | Self::For { span, .. }
            | Self::While { span, .. }
            | Self::Foreach { span, .. }
            | Self::Catch { span, .. }
            | Self::Try { span, .. }
            | Self::Switch { span, .. } => *span,
        }
    }

    /// Return the recorded canonical spelling, or the written head, for display
    /// and compatibility metadata. This does not prove implementation identity.
    /// Semantic consumers must use `registry_invocation::resolved_statement_invocation`
    /// so an unresolved source binding cannot recover catalogue semantics.
    ///
    /// Returns `""` for non-Call / non-Barrier statements.
    #[must_use]
    pub fn canonical_command_or_source(&self) -> &str {
        match self {
            Self::Call {
                command,
                canonical_command,
                ..
            }
            | Self::Barrier {
                command,
                canonical_command,
                ..
            } => canonical_command.as_deref().unwrap_or(command.as_str()),
            _ => "",
        }
    }
}

/// Switch matching mode.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Default)]
pub enum SwitchMode {
    /// Exact string match (default).
    #[default]
    Exact,
    /// Glob pattern match.
    Glob,
    /// Regular expression match.
    Regexp,
}

impl SwitchMode {
    /// Parse a switch mode from its Tcl string form.
    #[must_use]
    pub fn from_str_lossy(s: &str) -> Self {
        match s {
            "glob" => Self::Glob,
            "regexp" => Self::Regexp,
            _ => Self::Exact,
        }
    }

    /// Return the Tcl string form.
    #[must_use]
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::Exact => "exact",
            Self::Glob => "glob",
            Self::Regexp => "regexp",
        }
    }
}

// Procedure and module types

/// A procedure definition.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct Procedure {
    /// Short procedure name.
    pub name: String,
    /// Fully qualified name (e.g. `::ns::proc`).
    pub qualified_name: String,
    /// Parameter names.
    pub params: Vec<String>,
    /// Source span of the definition.
    pub span: Span,
    /// Procedure body.
    pub body: Script,
    /// Raw parameter list text.
    pub params_raw: String,
    /// Source text of the body (`None` for synthetic procs like `when`).
    pub body_source: Option<String>,
    /// Offset of [`Self::body_source`]'s first byte in the unit source.
    ///
    /// A statement of the body carries an absolute span; subtracting this
    /// offset turns it into the body-relative position Tcl counts `errorLine`
    /// and `(procedure "p" line N)` from. `0` for a procedure with no body
    /// text of its own (a synthetic or lambda body unit).
    pub body_offset: u32,
    /// Whether defined inside `namespace eval`.
    pub namespace_scoped: bool,
    /// BIG-IP handler priority (`0..=1000`, default 500).
    pub base_priority: u32,
}

/// A Registry-selected iRules event body retained by its actual lowering
/// producer. This source contract supplies conditional frame policy only;
/// it establishes no worker, epoch, entered event, Normal or current value.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct SourceIrulesEventBody {
    event: String,
    event_word: Option<tcl_lexer::NativeWord>,
    declaration: Span,
    body: std::sync::Arc<Script>,
    image: tcl_lexer::SourceImage,
    config: LexerConfig,
    registry: tcl_registry::RegistrySemanticKey,
}

impl SourceIrulesEventBody {
    pub(crate) fn from_lowering(
        event: &str,
        declaration: Span,
        body: &Script,
        image: tcl_lexer::SourceImage,
        config: LexerConfig,
        registry: &tcl_registry::CommandRegistry,
        event_word: Option<tcl_lexer::NativeWord>,
    ) -> Self {
        let event_word = event_word.filter(|word| {
            word.image() == &image
                && word.config() == config
                && declaration.start() <= word.span().start()
                && word.span().end() <= declaration.end()
        });
        Self {
            event: event.to_owned(),
            event_word,
            declaration,
            body: std::sync::Arc::new(body.clone()),
            image,
            config,
            registry: registry.snapshot().semantic_key(),
        }
    }

    /// Event identity selected at the real declaration, without name parsing.
    #[must_use]
    pub fn event(&self) -> &str {
        &self.event
    }

    /// Original complete event operand under its retained source generation.
    /// This is declaration geometry, without installation, activation or TMM facts.
    #[must_use]
    pub fn event_word(
        &self,
        image: &tcl_lexer::SourceImage,
        config: LexerConfig,
        registry: &tcl_registry::CommandRegistry,
    ) -> Option<&tcl_lexer::NativeWord> {
        (self.matches_source(image, config) && self.registry == registry.snapshot().semantic_key())
            .then_some(self.event_word.as_ref())
            .flatten()
    }

    pub(crate) fn owns_procedure(
        &self,
        procedure: &Procedure,
        image: &tcl_lexer::SourceImage,
        config: LexerConfig,
        registry: &tcl_registry::CommandRegistry,
    ) -> bool {
        self.declaration == procedure.span
            && self.body.as_ref() == &procedure.body
            && self.matches_source(image, config)
            && self.registry == registry.snapshot().semantic_key()
    }

    /// Full original source/configuration correspondence, without event reachability.
    #[must_use]
    pub fn matches_source(&self, image: &tcl_lexer::SourceImage, config: LexerConfig) -> bool {
        &self.image == image && self.config == config
    }

    pub(crate) fn conditional_lattice_entry(
        &self,
        body: &Script,
        config: LexerConfig,
        registry: &tcl_registry::CommandRegistry,
    ) -> Option<crate::var_resolve::ResolveContext> {
        if config != self.config.nested().normalized()
            || self.registry != registry.snapshot().semantic_key()
        {
            return None;
        }
        let mut expected = self.body.as_ref().clone();
        crate::lattice_rebase::rebase_script(&mut expected, -i64::from(self.declaration.start()));
        (expected == *body).then(|| self.conditional_entry())
    }

    pub(crate) fn conditional_entry(&self) -> crate::var_resolve::ResolveContext {
        crate::connection_scope::event_resolve_context(&self.event)
    }
}

/// A method definition within a class body.
///
/// Compiles like [`Procedure`] but carries class context for
/// interprocedural analysis and devirtualisation.
#[derive(Debug, Clone, PartialEq)]
pub struct MethodDef {
    /// Enclosing class name.
    pub class_name: String,
    /// Method name.
    pub method_name: String,
    /// Parameter names.
    pub params: Vec<String>,
    /// Method body.
    pub body: Script,
    /// Current namespace used to resolve command heads in the method body.
    /// `TclOO` selects the receiver's object namespace at runtime; other
    /// registry definer families can name their definition target exactly.
    pub execution_namespace: ExecutionNamespace,
    /// Method kind.
    pub kind: MethodKind,
    /// Source span (may be absent for synthetic methods).
    pub span: Option<Span>,
    /// Instance-variable names in scope for this method (class-level
    /// `variable` declarations + the method's own `variable` decls).
    /// A method that *writes* any of these mutates object state and is
    /// therefore impure for O126 purposes, even though the write looks
    /// like a plain local `set`. Used by interprocedural method-purity.
    pub instance_vars: std::collections::HashSet<String>,
    /// Actual unanimous entered receiver state, independent of lexical class labels.
    pub(crate) original_receiver_context: Option<
        std::sync::Arc<
            crate::command_binding::original_receiver_body_context::OriginalReceiverBodyContext,
        >,
    >,
    /// Original counted `ParamList` producer; it grants no entered activation.
    pub(crate) original_parameters:
        Option<std::sync::Arc<crate::command_binding::formal_topology::OriginalFormalTopology>>,
}

/// The kind of a class method.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Default)]
pub enum MethodKind {
    /// Regular instance method.
    #[default]
    Method,
    /// Class-level method.
    ClassMethod,
    /// Constructor.
    Constructor,
    /// Destructor.
    Destructor,
}

impl MethodKind {
    /// The frame shape a callable member opens, read off its member-effect
    /// facts (`registry-consumer-contracts.md` § *The member-effect
    /// descriptor*): its [`CallableRole`] and the side its row resolves to
    /// after every wrapper shift.
    ///
    /// A method on the instances is a [`Self::Method`] and one on the class or
    /// type object a [`Self::ClassMethod`]; a namespace procedure
    /// ([`CallableRole::Procedure`], snit's `proc`) runs with no instance in
    /// frame, the class-method shape. A constructor or destructor exists only
    /// on the instances: the type-object spelling is no member at all (tclsh
    /// 8.6.18 and 9.0.4: `oo::class create X { self constructor {} {} }` →
    /// `invalid command name "constructor"`). An option accessor or mutator
    /// opens no method frame of its own, and nothing is a method on both
    /// sides at once, so each of those answers `None`.
    #[must_use]
    pub const fn from_effect(role: CallableRole, receiver: MemberReceiver) -> Option<Self> {
        match (role, receiver) {
            (CallableRole::Method, MemberReceiver::Instance) => Some(Self::Method),
            (CallableRole::Method, MemberReceiver::TypeObject) | (CallableRole::Procedure, _) => {
                Some(Self::ClassMethod)
            }
            (CallableRole::Constructor, MemberReceiver::Instance) => Some(Self::Constructor),
            (CallableRole::Destructor, MemberReceiver::Instance) => Some(Self::Destructor),
            (CallableRole::Method, MemberReceiver::Both)
            | (
                CallableRole::Constructor | CallableRole::Destructor,
                MemberReceiver::TypeObject | MemberReceiver::Both,
            )
            | (CallableRole::Accessor | CallableRole::Mutator, _) => None,
        }
    }

    /// Return the string form.
    #[must_use]
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::Method => "method",
            Self::ClassMethod => "classmethod",
            Self::Constructor => "constructor",
            Self::Destructor => "destructor",
        }
    }
}

/// Whole-module evidence about OO definitions the lowering could not
/// statically model, grouped so consumers widen on exactly the right
/// axis.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub struct OoDefinitionEvidence {
    /// An `oo::class create` / `oo::define` targeted a class whose name
    /// is dynamic (`oo::define $cls { … }`): *any* class's methods may
    /// have been touched, so whole-module OO evidence is incomplete.
    pub dynamic_target: bool,
    /// A class-reference member carried a dynamic word (`superclass $b`):
    /// that class's ancestry is unknown, so hierarchy-scoped analysis
    /// must fall back to whole-module widening.
    pub dynamic_class_relations: bool,
    /// At least one executable definition/member body could not be published
    /// through [`Module::executable_script_roots`]. This includes dynamic or
    /// otherwise unsupported definer bodies, accessor/configuration scripts,
    /// and definitions nested in a method frame that the source-root post-pass
    /// does not revisit. Whole-module command-effect consumers must fail closed
    /// when this is set: absence from `methods` is not evidence that the runtime
    /// body cannot mutate the command table.
    pub unretained_executable_roots: bool,
}

/// What a [`Module`]'s top level holds.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum TopLevelKind {
    /// A script's global level — code outside any procedure.
    #[default]
    Script,
    /// A single `proc` or `TclOO` method body, compiled as its own module by
    /// the runtime. It has a local variable table; a script's global level
    /// does not.
    ProcedureBody,
}

/// The variables the scripts a module stores as callbacks write, destroy or
/// bind.
///
/// A script a command stores to run after it returns — an `after` or
/// `fileevent` handler, a `bind`ing, a variable trace's callback, everything
/// the registry states as a callback
/// ([`tcl_registry::CommandRegistry::callback_script_indices`]) — runs at the
/// global level, or in the frame of the code that fires it. A plain name in
/// it can denote a variable the registering code holds, and nothing in that
/// code's text shows the write. Whole-module and position-independent, like
/// [`Module::traced_variables`]: a name in [`Self::names`] is externally
/// mutable in every function, and the solver never refines it.
#[derive(Debug, Clone, Default, PartialEq, Eq, Hash)]
pub struct DeferredWrites {
    /// The literal names a callback script writes, destroys or binds
    /// (`global`, `upvar`, `variable`), the leading `::` stripped and an
    /// element's array beside it.
    pub names: std::collections::BTreeSet<String>,
    /// A callback writes, destroys or binds a name computed at run time, so
    /// any variable may change at any time.
    pub any: bool,
}

impl DeferredWrites {
    /// Whether no callback script of the module writes anything.
    #[must_use]
    pub fn is_clear(&self) -> bool {
        self.names.is_empty() && !self.any
    }
}

/// The fact of a build with no module to scan: no callback writes anything.
pub static NO_DEFERRED_WRITES: DeferredWrites = DeferredWrites {
    names: std::collections::BTreeSet::new(),
    any: false,
};

/// A top-level module: procedures + top-level script.
///
/// This is the only mutable IR type — it accumulates procedures and
/// methods during lowering.
#[derive(Debug, Clone, PartialEq, Default)]
pub struct Module {
    /// Exact source-word grammar used at ingress. A profile name cannot
    /// reconstruct custom or independently selected grammar axes.
    pub lexer_config: tcl_lexer::LexerConfig,
    /// Resolved profile retained by ingress; presentation names cannot recreate it.
    pub dialect_profile: Option<&'static tcl_dialect::DialectProfile>,
    /// Exact command registry snapshot which produced this module.
    pub registry_snapshot: Option<tcl_registry::RegistrySnapshot>,
    /// Original compiler metadata ingress, including the complete availability
    /// generation and word grammar. This supplies no runtime entry or frame.
    pub source_metadata_input: Option<crate::analyser::ResolvedAnalysisInput>,
    /// Execution entry and selected provider provenance shared by source,
    /// CFG, and invocation consumers. It is part of the module cache input.
    pub source_entry: crate::command_binding::SourceAnalysisEntry,
    /// Original source interpretation shared by lowering and command-effect queries.
    /// Its owner checks source, grammar, entry, frame and registry before reuse.
    pub retained_source_bindings:
        Option<std::sync::Arc<crate::command_binding::RetainedSourceModuleBindings>>,
    /// Possible future callers, separate from actual normal document entry.
    /// This inventory only retracts caller assumptions; it grants no execution.
    pub future_call_sites: Vec<crate::command_binding::SourceFutureCallSite>,
    /// Analysis-only body units recovered from actual native installations.
    /// Full allocation/source identity groups their retention limits; neither
    /// the tag nor the body unit installs a callable or licenses compilation.
    pub installed_procedure_body_units:
        std::collections::BTreeMap<String, crate::command_binding::CommandAllocation>,
    /// Analysis-only units for original procedure declarations, independent
    /// of current installation or actual entry. Labels index internal units;
    /// allocation, original source and namespace context retain their identity.
    pub original_declaration_body_units:
        std::collections::BTreeMap<String, crate::command_binding::CommandAllocation>,
    /// Original body metadata for exact procedure implementations, including
    /// retired incarnations. This does not select a callable or grant entry,
    /// completion, compilation or an executable replacement.
    pub procedure_implementation_bodies:
        std::sync::Arc<[crate::command_binding::SourceInstalledProcedureBody]>,
    /// The original source text this module was lowered from. Spans on the
    /// lowered statements index into it, so codegen can recover each command's
    /// surface text for `errorInfo` (`while executing "…"`). Empty when not
    /// supplied (older construction paths / hand-built test modules).
    pub source: tcl_lexer::SourceImage,
    /// Retained native namespace path for executable compilation. Symbolic
    /// analysis names never reconstruct an opaque native namespace.
    pub native_namespace: Option<tcl_core_types::ByteNamespacePath>,
    /// Rooted constructed namespace in which [`Self::top_level`] resolves
    /// command names. This is `"::"` for an ordinary source module and the
    /// procedure's defining namespace for a runtime procedure-body compile.
    pub top_level_namespace: String,
    /// Exact analysis namespace identity. Printed names never reconstruct native
    /// component boundaries or select an actual namespace incarnation.
    pub top_level_namespace_context: Option<crate::command_binding::SourceNamespaceKey>,
    /// The dialect this module was lowered for (`"tcl8.6"`, `"f5-irules"`, …),
    /// `None` for an unnamed/permissive compile.
    ///
    /// The dialect is a top-level property of the compile, threaded from the
    /// entry point down to codegen so the backend emits code *for* a release
    /// rather than deferring release-dependent decisions to run time — a
    /// numeric literal is a case in point: `0755` is 493 under 8.6 and 755
    /// under 9.0, and which one it is settled here.
    pub dialect: Option<String>,
    /// Whether lowering deliberately preserved ordinary command dispatch for
    /// every invocation (trace/invalidation recovery compilation).
    pub plain_command_dispatch: bool,
    /// What [`Self::top_level`] actually is.
    ///
    /// The runtime compiles a `proc` or `TclOO` method body as its own module
    /// whose top level *is* that body, so the name alone cannot tell the two
    /// apart — both are `::top`. Anything that depends on the body having a
    /// local variable table has to ask this instead (#2207: a `catch` is only
    /// inlined where its result variable can have a slot).
    pub top_level_kind: TopLevelKind,
    /// Top-level script (code outside any procedure).
    pub top_level: Script,
    /// Named procedures.
    pub procedures: std::collections::HashMap<String, Procedure>,
    /// Sealed actual event-declaration bodies. Internal procedure labels do
    /// not create an event frame or select a hosted execution context.
    pub irules_event_bodies:
        std::collections::HashMap<String, std::sync::Arc<SourceIrulesEventBody>>,
    /// Named methods (keyed by `class::method`).
    pub methods: std::collections::HashMap<String, MethodDef>,
    /// Synthetic *body units* — the bodies of commands that run their script
    /// argument in a fresh frame but are **not** real named procedures:
    /// `apply` lambdas, `namespace eval` bodies and installed procedure
    /// bodies retained only for analysis (keyed by a synthetic
    /// qualified name like `::apply#0`, or `::NS::namespace-eval#0` — `NS`
    /// *prefixes* the marker, matching every other qname's "everything
    /// before the last `::` is the enclosing namespace" convention, so a
    /// bare call inside the body resolves against the namespace it actually
    /// targets rather than always the global namespace).
    ///
    /// These are lowered into [`Procedure`]s purely so the static-analysis
    /// pipeline (CFG → SSA → SCCP → taint) reaches *inside* the body — the
    /// same coverage a real `proc` gets. They are held in a **separate** map
    /// from [`Self::procedures`] so codegen (which emits `procedures`) never
    /// materialises them as callable procs, and from [`Self::methods`] so the
    /// TclOO-specific consumers (interproc method purity, the O126 optimiser
    /// gate) never mistake them for methods. The body still executes at
    /// runtime via its command's own `Statement::Barrier`, so bytecode is
    /// byte-identical whether or not a body unit is recorded.
    pub body_units: std::collections::HashMap<String, Procedure>,
    /// The subset of [`Self::body_units`] that are **lambda** frames — an
    /// `apply` literal's body, whose parameter list binds real locals exactly
    /// as a `proc`'s does.
    ///
    /// A `namespace eval` body unit is *not* one: its variables are the
    /// namespace's, shared with every other body that opens the same
    /// namespace, so a name it reads without writing is routinely defined
    /// elsewhere.  The read-before-set family (`W210`) therefore runs over
    /// this subset only — a lambda body is a closed frame and an unwritten
    /// read in it is a genuine error.
    pub lambda_body_units: std::collections::BTreeSet<String>,
    /// Procedure names that were defined more than once.
    pub redefined_procedures: std::collections::HashSet<String>,
    /// `TclOO` methods defined more than once (a later `oo::define` /
    /// in-body redefinition replaces the body at runtime), keyed by
    /// method qname. [`Self::methods`] keeps the *first* body
    /// (last-definition-wins stays with the navigation layer); each
    /// **replacement** body is retained here in definition order,
    /// so analysis consumers — the SCCP method-dispatch barrier,
    /// O126 method purity — can scan every body a dispatch may run
    /// instead of abstaining on the mere fact of redefinition. The union
    /// of bodies over-approximates whichever is live at dispatch time,
    /// so scanning all of them is sound where scanning one is not.
    pub redefined_methods: std::collections::HashMap<String, Vec<MethodDef>>,
    /// Class qnames with a member definition the lowering could not
    /// statically model — a dynamic member name (`method $n …`) or a
    /// dynamic member body (`method m {} $body`) inside an `oo::class` /
    /// `oo::define` block. Any method of such a class may have been
    /// (re)defined with an unknown body, so per-class analysis
    /// (purity, the method-dispatch propagation barrier) must abstain
    /// for the whole class.
    pub oo_unanalysed_classes: std::collections::HashSet<String>,
    /// Whole-module OO-definition evidence flags — see
    /// [`OoDefinitionEvidence`].
    pub oo_evidence: OoDefinitionEvidence,
    /// Class-hierarchy relation declarations captured from `oo::class` /
    /// `oo::define` bodies: `(declaring class qname, written related-class
    /// word)` for each argument of a member whose registry grammar marks
    /// every argument as a class reference
    /// ([`tcl_registry::definer::MemberRefKind::Class`] — `superclass`,
    /// `mixin`). The written word is kept as written; consumers resolve it
    /// against the module's class set conservatively — the method-dispatch
    /// propagation barrier scopes itself to hierarchy-connected classes
    /// instead of the whole module.
    pub class_relations: Vec<(String, String)>,
    /// `namespace import` directives captured at lowering time —
    /// `(context_namespace, absolute_pattern)` pairs. Future codegen
    /// passes pattern-match each against the final
    /// `Self::procedures` table to resolve unqualified calls
    /// directly instead of falling back to the runtime
    /// interpreter. Only absolute patterns (`::foo::*` /
    /// `::foo::bar`) are recorded; relative patterns require
    /// runtime namespace-path walking which compile-time
    /// resolution does not model.
    pub namespace_imports: Vec<(String, String)>,
    /// `namespace export` directives captured at lowering time —
    /// `(context_namespace, pattern)` pairs. Codegen consults this
    /// list to gate the import shortcut on actual exportedness so
    /// `namespace import ::foo::*` only resolves names that
    /// `::foo` actually exports.
    pub namespace_exports: Vec<(String, String)>,
    /// Literal command names that have an execution trace
    /// registered (`trace add execution NAME enter|leave HANDLER`).
    /// GVN consults this set to gate purity (a traced call is
    /// never pure because the trace handler composes side effects
    /// in).
    pub traced_commands: std::collections::BTreeSet<String>,
    /// `true` when a `trace add execution` was seen with a
    /// non-literal command target (`trace add execution $cmd ...`).
    /// Forces GVN / partial-redundancy / loop-invariant passes to
    /// treat *every* call as potentially traced.
    pub has_dynamic_trace: bool,
    /// Literal variable names targeted by an active *variable* trace
    /// (`trace add variable NAME ops HANDLER`, or the deprecated
    /// `trace variable`/`vdelete` spellings) anywhere in the module —
    /// top level or any procedure body, regardless of whether the
    /// installing call is reachable before or after a given use.  A
    /// read of a traced variable can run arbitrary handler code, and a
    /// write handler can rewrite the value being stored, so the
    /// propagation optimiser (`O102` load-forwarding) and dead-store
    /// elimination must never treat a use of one of these names as
    /// equivalent to its last literal assignment. Whole-module and
    /// position-independent by design — mirrors [`Self::traced_commands`]
    /// but for `ArgRole::VarWrite`-role variable-trace targets
    /// (`Traits::ESTABLISHES_VARIABLE_TRACE`) rather than execution-trace
    /// command names.
    pub traced_variables: std::collections::BTreeSet<String>,
    /// `true` when a variable-trace install/remove call was seen with a
    /// non-literal variable-name target (`trace add variable $name ...`).
    /// Forces the propagation optimiser to treat *every* variable as
    /// potentially traced.
    pub has_dynamic_variable_trace: bool,
    /// The variables the scripts the module stores as callbacks write — see
    /// [`DeferredWrites`]. Populated after lowering, beside
    /// [`Self::traced_variables`].
    pub deferred_writes: DeferredWrites,
    /// The definitions of pack commands this module's calls were inlined
    /// from, and where [`Self::source`] holds their text — see
    /// [`ReferenceBodies`].
    pub reference_bodies: ReferenceBodies,
    /// The commands the document declares (`# tcl-lsp: stub`) as plain
    /// calls, which the catalogue does not hold — see
    /// [`DeclaredFrameEffects`]. Empty for a module lowered without the
    /// document's declarations.
    pub declared_frame_effects: DeclaredFrameEffects,
}

/// The commands a document declares whose declarations state their frame
/// effect and nothing a reader of the catalogue alone would miss
/// ([`tcl_registry::model::DeclaredCommand::plain_call_frame_effect`]), by
/// normalised qualified name, with the effect each states: `None` for one
/// that crosses no frame (`-frame own`, `-frame none`), `argparse`'s
/// caller-frame effect for `-frame caller`.
///
/// The module's command table holds them as it holds a catalogue command
/// (`ModuleCommandBindings`), so a call to one is a call to a command the
/// module can name, and it brings the stated effect where a catalogue
/// command's call brings the registry's ([`crate::dynamic_names`]). A
/// declaration that states no frame effect leaves its command out, and a call
/// to it stays a call to code the module cannot see; a name the catalogue
/// holds keeps the catalogue's answer, which is what the flow graph reads.
pub type DeclaredFrameEffects =
    std::collections::BTreeMap<String, Option<tcl_registry::FrameEffectSpec>>;

/// The reference bodies a module's calls were inlined from.
///
/// A command a pack declares `TclBody`-backed has its definition in the pack,
/// not in the module that calls it. The inliner lowers that definition on its
/// own and shifts its spans past the end of [`Module::source`], then appends
/// the definition's text there, so every span in the module — the module's own
/// and the borrowed — indexes one text and codegen slices each as it always
/// did. The appended text is no part of the module: [`Module::own_source`]
/// is what an artefact carries as its source, and what a plain recompile
/// reads.
#[derive(Debug, Clone, PartialEq, Eq, Default)]
pub struct ReferenceBodies {
    /// The byte offset in [`Module::source`] at which the appended
    /// definitions start; `None` when nothing was appended.
    pub appendix_start: Option<usize>,
    /// The definitions appended, by what identifies each to the runtime.
    pub imports: Vec<ReferenceImport>,
}

/// One pack command's definition, as copied into a module.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ReferenceImport {
    /// The rooted name the definition creates (`::vendor::double`).
    pub name: String,
    /// The definition's raw parameter list.
    pub parameters: String,
    /// The definition's body text, as the live procedure would hold it.
    pub body: String,
    /// The kind of backing the definition was declared with.
    pub backing: tcl_runtime_api::BackingKind,
    /// The pack facts that declared the backing the definition came from.
    pub facts: tcl_runtime_api::PackFactStamp,
}

fn execution_namespace_for_qname(qname: &str) -> String {
    let (holder, _) = tcl_syntax::naming::key_holder_and_tail(qname);
    if holder.is_empty() {
        "::".to_owned()
    } else {
        holder.to_owned()
    }
}

impl Module {
    /// Checked analytical namespace key. Native component boundaries must
    /// round-trip through the constructed-key owner before advice can use it.
    #[must_use]
    pub fn advisory_top_level_namespace(&self) -> Option<String> {
        if let Some(path) = &self.native_namespace {
            let segments = tcl_syntax::naming::checked_namespace_path_utf8(path).ok()?;
            let key = if segments.is_empty() {
                String::from("::")
            } else {
                format!("::{}", segments.join("::"))
            };
            return (tcl_syntax::naming::key_segments(&key) == segments).then_some(key);
        }
        Some(if self.top_level_namespace.is_empty() {
            String::from("::")
        } else {
            self.top_level_namespace.clone()
        })
    }

    /// Retained resolved profile, with presentation-name compatibility only for
    /// manually constructed modules which predate the explicit ingress carrier.
    #[must_use]
    pub fn resolved_profile(&self) -> Option<&'static tcl_dialect::DialectProfile> {
        self.dialect_profile.or_else(|| {
            self.dialect.as_deref().map(|name| {
                crate::environment_ingress::resolve_environment(name).analyser_profile()
            })
        })
    }

    /// Exact ingress registry, including workspace and custom command metadata.
    /// Compatibility modules fall back to their resolved catalogue profile.
    #[must_use]
    pub fn resolved_registry(&self) -> &tcl_registry::CommandRegistry {
        self.registry_snapshot.as_ref().map_or_else(
            || {
                self.resolved_profile().map_or_else(
                    || tcl_registry::model::ingress::static_context_for("tcl").commands(),
                    |profile| {
                        tcl_registry::model::ingress::static_context_for_profile(profile).commands()
                    },
                )
            },
            tcl_registry::RegistrySnapshot::registry,
        )
    }

    /// Actual source variable/word grammar, independent of assistance metadata.
    /// Preserve source coordinates and parser-mode knobs while selecting native
    /// lexical axes; syntax alone supplies no execution or storage proof.
    #[must_use]
    pub fn native_lexer_config(&self) -> tcl_lexer::LexerConfig {
        self.source_entry
            .options()
            .native_lexer_config(self.lexer_config)
    }

    /// Native numeral ingress retained by this module. Actual invocation axes
    /// precede the assistance profile and its legacy display-name adapter.
    #[must_use]
    pub fn number_syntax(&self) -> tcl_dialect::NumberSyntax {
        self.source_entry.invocation_dialect.map_or_else(
            || tcl_dialect::NumberSyntax::of_profile(self.resolved_profile()),
            |dialect| dialect.numbers,
        )
    }

    /// Native word/list value rules, independent of catalogue display names.
    #[must_use]
    pub fn word_values(&self) -> tcl_syntax::word_rules::WordValueRules {
        self.source_entry.invocation_dialect.map_or_else(
            || tcl_syntax::word_rules::WordValueRules::from_config(&self.lexer_config),
            |dialect| dialect.word_values,
        )
    }

    /// Native parameter activation grammar. Unknown execution axes abstain;
    /// assistance list syntax cannot select a procedure's binding protocol.
    #[must_use]
    pub fn parameter_grammar(&self) -> Option<tcl_dialect::ParameterGrammar> {
        if self.source_entry.native_entry.is_some() {
            return self
                .source_entry
                .options()
                .logical_invocation_dialect()?
                .parameter_grammar();
        }
        self.source_entry.invocation_dialect.map_or_else(
            || {
                self.resolved_profile().and_then(|profile| {
                    tcl_registry::InvocationDialect::of_profile(profile).parameter_grammar()
                })
            },
            tcl_registry::InvocationDialect::parameter_grammar,
        )
    }

    /// The counted original source before appended reference definitions.
    #[must_use]
    pub fn own_source(&self) -> tcl_lexer::SourceImage {
        let bytes = self
            .reference_bodies
            .appendix_start
            .and_then(|end| self.source.bytes().get(..end))
            .unwrap_or_else(|| self.source.bytes());
        tcl_lexer::SourceImage::from_bytes(bytes, self.source.channel())
    }

    /// Executable roots whose invocation is independent of an enclosing
    /// statement: the module load script, retained procedures and methods,
    /// and retained replacement methods.
    ///
    /// Synthetic [`Self::body_units`] are deliberately absent. An `apply` or
    /// `namespace eval` body executes only through its owning invocation, in
    /// that invocation's program-order position; treating the same body as an
    /// independently callable fixpoint root both invents an execution path and
    /// repeatedly replays nested body suffixes. Whole-module static analyses
    /// that need every body in isolation should use
    /// [`Self::executable_script_roots`] instead.
    #[must_use]
    pub(crate) fn independent_executable_script_roots(&self) -> Vec<(&Script, ExecutionNamespace)> {
        let mut roots = vec![(
            &self.top_level,
            self.top_level_namespace_context.as_ref().map_or_else(
                || {
                    self.advisory_top_level_namespace().map_or(
                        ExecutionNamespace::RuntimeSelected,
                        ExecutionNamespace::exact,
                    )
                },
                |context| match context {
                    crate::command_binding::SourceNamespaceKey::Authored(namespace) => {
                        ExecutionNamespace::exact(namespace)
                    }
                    _ => ExecutionNamespace::SourceContext(context.clone()),
                },
            ),
        )];

        let mut procedures: Vec<_> = self.procedures.iter().collect();
        procedures.sort_by(|a, b| a.0.cmp(b.0));
        roots.extend(procedures.into_iter().map(|(qname, procedure)| {
            (
                &procedure.body,
                procedure
                    .body
                    .execution_namespace(ExecutionNamespace::exact(execution_namespace_for_qname(
                        qname,
                    ))),
            )
        }));

        let mut methods: Vec<_> = self.methods.iter().collect();
        methods.sort_by(|a, b| a.0.cmp(b.0));
        roots.extend(methods.into_iter().map(|(_, method)| {
            (
                &method.body,
                method
                    .body
                    .execution_namespace(method.execution_namespace.clone()),
            )
        }));

        let mut redefined_methods: Vec<_> = self.redefined_methods.iter().collect();
        redefined_methods.sort_by(|a, b| a.0.cmp(b.0));
        for (_, replacements) in redefined_methods {
            roots.extend(replacements.iter().map(|method| {
                (
                    &method.body,
                    method
                        .body
                        .execution_namespace(method.execution_namespace.clone()),
                )
            }));
        }

        roots
    }

    /// Every retained executable script root and the namespace in which its
    /// command heads resolve.
    ///
    /// Whole-module semantic scans use this inventory instead of each keeping
    /// a partial copy of the procedure/method/body-unit map traversal. The
    /// ordering is deterministic so monotone state replays and memo inputs do
    /// not depend on `HashMap` seeds. Earlier bodies of a redefined procedure
    /// are not retained; consumers that need them must widen when
    /// [`Self::redefined_procedures`] is non-empty.
    #[must_use]
    pub fn executable_script_roots(&self) -> Vec<(&Script, ExecutionNamespace)> {
        let mut roots = self.independent_executable_script_roots();

        let mut body_units: Vec<_> = self.body_units.iter().collect();
        body_units.sort_by(|a, b| a.0.cmp(b.0));
        roots.extend(
            body_units
                .into_iter()
                .filter(|(qname, _)| {
                    !self.installed_procedure_body_units.contains_key(*qname)
                        && !self.original_declaration_body_units.contains_key(*qname)
                })
                .map(|(qname, unit)| {
                    (
                        &unit.body,
                        unit.body.execution_namespace(ExecutionNamespace::exact(
                            execution_namespace_for_qname(qname),
                        )),
                    )
                }),
        );

        roots
    }
}

/// Extract the event name from a `::when::` qualified name.
///
/// Handles both `::when::HTTP_REQUEST` and indexed forms like
/// `::when::HTTP_REQUEST#1`.
#[must_use]
pub fn when_event_name(qualified_name: &str) -> &str {
    let bare = qualified_name
        .strip_prefix("::when::")
        .unwrap_or(qualified_name);
    match bare.find('#') {
        Some(idx) => &bare[..idx],
        None => bare,
    }
}

#[cfg(test)]
pub(crate) fn native_call_for_test(bytes: &[u8]) -> Statement {
    let image = tcl_lexer::SourceImage::native(bytes);
    let config = tcl_lexer::LexerConfig::default();
    let tokens = tcl_lexer::Lexer::with_source_image(&image, config)
        .tokenise_all()
        .expect("complete original native words");
    let groups = tcl_lexer::group_commands_bytes(&tokens, image.bytes(), config);
    assert_eq!(groups.len(), 1, "one native invocation");
    let words: Vec<_> = groups[0]
        .words
        .iter()
        .map(|word| {
            tcl_lexer::word_parts::NativeWord::from_group(image.clone(), config, &tokens, word)
                .expect("original token word extent")
        })
        .collect();
    let first = words.first().expect("command head");
    let last = words.last().expect("final operand");
    Statement::NativeCall {
        span: Span::new(first.span().start(), last.span().end()),
        words,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn statement_carriers_require_unanimous_ownership_and_keep_synthetic_phases_distinct() {
        let registry = tcl_registry::model::ingress::static_context_for("tcl8.6").commands();
        let profile = tcl_dialect::DialectProfile::find("tcl8.6").unwrap();
        let module = crate::lowering::lower_to_ir_with_dialect(
            "set x 1",
            registry,
            LexerConfig::from_grammar(profile.grammar),
            Some(profile),
        );
        let mut script = module.top_level;
        let original = script.statements[0].clone();
        assert!(original.tokens().is_none(), "typed store consumed its argv");
        let carrier = script
            .retained_source_tokens_for_statement(&script.statements[0])
            .expect("retained typed store carrier")
            .clone();
        assert!(
            script
                .retained_source_tokens_for_statement(&original)
                .is_none()
        );

        let mut function = crate::cfg::Function::new("::top", "entry");
        function.command_binding_sites = script.command_binding_sites.iter().cloned().collect();
        function
            .blocks
            .get_mut(&function.entry)
            .unwrap()
            .statements
            .push(original.clone());
        assert_eq!(
            function.source_input_tokens_at(function.entry, 0),
            Some(&carrier)
        );

        let mut conflict = function.command_binding_sites[0].clone();
        conflict.source_tokens.as_mut().unwrap().argv_texts[0].replace_range(.., "other");
        function.command_binding_sites.push(conflict.clone());
        assert!(function.source_input_tokens_at(function.entry, 0).is_none());
        let mut sites = script
            .command_binding_sites
            .iter()
            .cloned()
            .collect::<Vec<_>>();
        sites.push(conflict);
        script.command_binding_sites = sites.into();
        assert!(
            script
                .retained_source_tokens_for_statement(&script.statements[0])
                .is_none()
        );

        let mut phase = carrier;
        phase.synthetic = Some(SyntheticMarker::EvaluatedArguments);
        let boundary = Statement::Barrier {
            span: original.span(),
            reason: "captured original argv".to_owned(),
            command: "set".to_owned(),
            canonical_command: None,
            args: vec!["x".to_owned(), "1".to_owned()],
            tokens: Some(phase.clone()),
        };
        function.blocks.get_mut(&function.entry).unwrap().statements[0] = boundary.clone();
        assert_eq!(
            function.source_input_tokens_at(function.entry, 0),
            Some(&phase)
        );
        script.statements[0] = boundary;
        assert!(
            script
                .retained_source_tokens_for_statement(&script.statements[0])
                .is_none()
        );
        assert!(function.source_input_tokens_at(function.entry, 1).is_none());
    }

    #[test]
    fn braced_argument_query_rejects_command_head_and_out_of_range_indices() {
        let source = "{lappend} {name} {$value} $other";
        let config = LexerConfig::default();
        let commands = crate::segmenter::segment_commands_with_offset_and_config(source, 0, config);
        let tokens = CommandTokens::from_segmented(&SourceMap::new(source), config, &commands[0]);
        assert!(tokens.arg_is_braced_literal(0));
        assert!(tokens.arg_is_braced_literal(1));
        assert!(!tokens.arg_is_braced_literal(2));
        assert!(!tokens.arg_is_braced_literal(3));
        assert!(!tokens.arg_is_braced_literal(usize::MAX));
    }

    #[test]
    fn original_word_carrier_keeps_actual_quotes_escapes_and_expansion_presentations() {
        // naming.source.original-direct-token-owner
        // docs/design/analysis/name-resolution-proofs/original-direct-token-owner.md
        // This only checks a genuine written token carrier's compatibility
        // projections. It supplies no source provenance or evaluated argv.
        for version in tcl_dialect::TclVersion::ALL {
            let dialect = tcl_registry::InvocationDialect::for_version(version);
            let config = LexerConfig::from_grammar(dialect.lexer_grammar);
            for source in [
                r#"list ONE "λ\u0041" {$value} pre[set v ONE]post"#,
                r#"list $value "$value" {x\y} \u0000"#,
            ] {
                let commands =
                    crate::segmenter::segment_commands_with_offset_and_config(source, 0, config);
                assert_eq!(commands.len(), 1);
                let tokens =
                    CommandTokens::from_segmented(&SourceMap::new(source), config, &commands[0]);
                assert!(
                    tokens.original_words_match_argv_text(),
                    "{version:?}: {source}"
                );
            }
            if dialect.lexer_grammar.expand_syntax {
                let source = "list {*}{ONE TWO}";
                let commands =
                    crate::segmenter::segment_commands_with_offset_and_config(source, 0, config);
                let tokens =
                    CommandTokens::from_segmented(&SourceMap::new(source), config, &commands[0]);
                assert!(matches!(tokens.words()[1], WordExpr::Expand { .. }));
                assert!(tokens.original_words_match_argv_text());
                assert_eq!(
                    tokens.words().len(),
                    2,
                    "written words are not evaluated expansion slots"
                );
            }
        }
    }

    #[test]
    fn original_word_carrier_refuses_same_count_text_and_word_changes() {
        // naming.source.original-direct-token-owner
        // docs/design/analysis/name-resolution-proofs/original-direct-token-owner.md
        let source = "list ONE";
        let config = LexerConfig::default();
        let commands = crate::segmenter::segment_commands_with_offset_and_config(source, 0, config);
        let original = CommandTokens::from_segmented(&SourceMap::new(source), config, &commands[0]);
        assert!(original.original_words_match_argv_text());
        let mut changed = original.clone();
        changed.argv_texts[1] = "OTHER".to_owned();
        assert!(
            changed.words_align_with_argv_text(),
            "count-only compatibility remains distinct"
        );
        assert!(!changed.original_words_match_argv_text());
        let mut changed = original.clone();
        changed.argv_texts.pop();
        assert!(!changed.original_words_match_argv_text());
        let mut changed = original.clone();
        changed.word_exprs.pop();
        assert!(!changed.original_words_match_argv_text());
        let mut changed = original.clone();
        let source = changed.word_exprs[1].source().clone();
        changed.word_exprs[1] = WordExpr::Opaque {
            text: "OTHER".to_owned(),
            source,
            reason: WordOpacity::LossySnapshot,
        };
        assert!(changed.words_align_with_argv_text());
        assert!(!changed.original_words_match_argv_text());
        let mut consistent = original;
        consistent.synthetic = Some(SyntheticMarker::EvaluatedWrapper);
        assert!(
            consistent.original_words_match_argv_text(),
            "consistency alone grants no original purpose"
        );
    }

    #[test]
    fn module_value_rules_retain_actual_axes_before_assistance_names() {
        let assistance =
            crate::environment_ingress::resolve_environment("tcl9.1").analyser_profile();
        let mut module = Module {
            dialect: Some("tcl8.4".into()),
            dialect_profile: Some(assistance),
            lexer_config: tcl_lexer::LexerConfig::for_profile(Some(assistance)),
            ..Module::default()
        };
        assert_eq!(
            module.number_syntax(),
            tcl_dialect::NumberSyntax::of_profile(Some(assistance))
        );
        let actual = tcl_registry::InvocationDialect::for_version(tcl_dialect::TclVersion::V8_4);
        module.source_entry.invocation_dialect = Some(actual);
        assert_eq!(module.number_syntax(), actual.numbers);
        assert_eq!(module.word_values(), actual.word_values);
        let jim = tcl_registry::InvocationDialect::of_point(
            tcl_dialect::model::DialectPoint::canonical(tcl_dialect::model::Release::JIM_0_84),
        );
        module.source_entry.invocation_dialect = Some(jim);
        assert_eq!(module.number_syntax(), jim.numbers);
        assert_eq!(module.word_values(), jim.word_values);
    }

    #[test]
    fn quoted_variable_identity_uses_the_reference_site() {
        let source = "list \"${a}\" \"$a[upvar 0 y a]$a\" {$a}";
        let config = LexerConfig::default();
        let commands = crate::segmenter::segment_commands_with_offset_and_config(source, 0, config);
        let tokens = CommandTokens::from_segmented(&SourceMap::new(source), config, &commands[0]);
        let (spelling, read) = tokens.words()[1]
            .sole_variable_substitution()
            .expect("sole quoted read");
        assert_eq!(spelling, "${a}");
        assert_eq!(read, &SourceSite::source(Span::new(6, 9)));
        assert!(tokens.words()[2].sole_variable_substitution().is_none());
        assert!(tokens.words()[3].sole_variable_substitution().is_none());
    }

    #[test]
    fn structured_variable_references_preserve_original_syntax() {
        let source = r#"list $a "${a}" "$a" $a(k) ${a(k)} "$a($i)" "$a$a" {$a}"#;
        for dialect in ["tcl8.4", "tcl8.5", "tcl8.6", "tcl9.0", "tcl9.1", "jim"] {
            let registry = tcl_registry::model::ingress::static_context_for(dialect).commands();
            let config =
                LexerConfig::for_profile(Some(registry.profile().expect("actual native grammar")));
            let commands =
                crate::segmenter::segment_commands_with_offset_and_config(source, 0, config);
            let tokens =
                CommandTokens::from_segmented(&SourceMap::new(source), config, &commands[0]);
            for (index, expected) in [
                (1, "$a"),
                (2, "${a}"),
                (3, "$a"),
                (4, "$a(k)"),
                (5, "${a(k)}"),
                (6, "$a($i)"),
            ] {
                let (spelling, site) = tokens.words()[index]
                    .sole_variable_substitution()
                    .expect("one original reference");
                assert_eq!(spelling, expected, "{dialect}, word {index}");
                assert_eq!(site.provenance, Provenance::Source);
                let start = site.span.start() as usize;
                assert!(source[start..].starts_with(spelling));
            }
            // Two lexical reads cannot acquire one read identity; a braced
            // data word supplies none, despite containing the same name.
            assert!(tokens.words()[7].sole_variable_substitution().is_none());
            assert!(tokens.words()[8].sole_variable_substitution().is_none());
            assert_eq!(tokens.argv_texts[1], "${a}");
            assert_eq!(tokens.words()[1].legacy_text(), "${a}");
            assert_eq!(
                tokens.words()[1].sole_variable_substitution().unwrap().0,
                "$a"
            );
        }
    }

    #[test]
    fn empty_script() {
        let script = Script::new();
        assert_eq!(script.statements, [] as [crate::ir::Statement; 0]);
    }

    #[test]
    fn script_from_statements() {
        let stmts = vec![Statement::AssignConst {
            span: Span::new(0, 10),
            name: "x".into(),
            name_braced: false,
            value: "1".into(),
            value_span: None,
        }];
        let script = Script::from_statements(stmts);
        assert_eq!(script.statements.len(), 1);
    }

    #[test]
    fn for_each_statement_visits_nested_bodies_in_order() {
        // `if {c} { inner1 } else { inner2 }` — the visitor must see the
        // `If` itself plus both nested-body calls, in source order.
        let inner1 = Statement::Call {
            span: Span::new(0, 0),
            command: "inner1".into(),
            canonical_command: None,
            args: Vec::new(),
            defs: Vec::new(),
            reads: Vec::new(),
            reads_own_defs: false,
            safe_on_uninit: false,
            tokens: None,
            foreach_groups: None,
        };
        let inner2 = Statement::Call {
            span: Span::new(0, 0),
            command: "inner2".into(),
            canonical_command: None,
            args: Vec::new(),
            defs: Vec::new(),
            reads: Vec::new(),
            reads_own_defs: false,
            safe_on_uninit: false,
            tokens: None,
            foreach_groups: None,
        };
        let if_stmt = Statement::If {
            span: Span::new(0, 0),
            clauses: vec![IfClause {
                condition: ExprNode::Raw { text: "c".into() },
                condition_span: Span::new(0, 0),
                body: Script::from_statements(vec![inner1]),
                body_span: Span::new(0, 0),
                condition_base: None,
            }],
            else_body: Some(Script::from_statements(vec![inner2])),
            else_span: None,
        };
        let script = Script::from_statements(vec![if_stmt]);

        let mut seen: Vec<String> = Vec::new();
        for_each_statement(&script, &mut |stmt| {
            let name = match stmt {
                Statement::If { .. } => "if".to_owned(),
                Statement::Call { command, .. } => command.clone(),
                _ => "other".to_owned(),
            };
            seen.push(name);
        });
        assert_eq!(seen, vec!["if", "inner1", "inner2"]);
    }

    #[test]
    fn retained_region_phases_have_one_visitor_owner() {
        use crate::execution_region::{
            EvaluatedBodyRegion, ExecutionRegionDependency, RegionSelection,
        };
        let phase = |name: &str| {
            Script::from_statements(vec![Statement::AssignConst {
                span: Span::new(0, 0),
                name: name.into(),
                name_braced: false,
                value: "1".into(),
                value_span: None,
            }])
        };
        let region = EvaluatedBodyRegion::captured_lifecycle(
            SourceSite::source(Span::new(0, 10)),
            phase("setup"),
            phase("body"),
            phase("cleanup"),
            RegionSelection::MaySkip,
            vec![ExecutionRegionDependency::Implementation("proved".into())],
        );
        let tokens = CommandTokens::from_lossy_parts(
            Vec::new(),
            Vec::new(),
            Vec::new(),
            Vec::new(),
            Vec::new(),
            None,
        )
        .with_evaluated_body(region);
        let original = Statement::Barrier {
            span: Span::new(0, 10),
            reason: "wrapper".into(),
            command: "wrapper".into(),
            canonical_command: None,
            args: Vec::new(),
            tokens: Some(tokens),
        };
        let mut boundary = original.clone();
        boundary.tokens_mut().unwrap().synthetic = Some(SyntheticMarker::EvaluatedWrapper);
        let mut script = Script::from_statements(vec![original, boundary]);
        let mut names = Vec::new();
        for_each_statement(&script, &mut |statement| {
            if let Statement::AssignConst { name, .. } = statement {
                names.push(name.clone());
            }
        });
        assert_eq!(names, ["setup", "body", "cleanup"]);
        let mut scripts = 0;
        for_each_script_mut(&mut script, &mut |_| scripts += 1);
        assert_eq!(scripts, 4);
    }

    /// `for_each_statement` recurses
    /// once per nested `If`/`For`/`While`/`Foreach`/`Catch`/`Try`/`Switch`/
    /// `UpFrame` body, so it needs a depth cap of its own.
    /// Transitively bounded to `MAX_LOWER_NEST_DEPTH` (256) by the lowering
    /// pass today (every `Script` this crate hands to `for_each_statement`
    /// is built by `crate::lowering`), so this is defence-in-depth /
    /// consistency with every other full-tree walker in this crate, not a
    /// currently-reproducible crash. This test builds the nested `Script`
    /// directly (bypassing lowering) so it genuinely exercises
    /// `for_each_statement`'s own new cap rather than lowering's; 2000
    /// levels is comfortably past the new 256-level cap. The assertion is
    /// that the call returns at all, not what it returns.
    #[test]
    fn deeply_nested_if_survives_for_each_statement() {
        const DEPTH: usize = 2000;
        let leaf = Statement::Call {
            span: Span::new(0, 0),
            command: "leaf".into(),
            canonical_command: None,
            args: Vec::new(),
            defs: Vec::new(),
            reads: Vec::new(),
            reads_own_defs: false,
            safe_on_uninit: false,
            tokens: None,
            foreach_groups: None,
        };
        let mut script = Script::from_statements(vec![leaf]);
        for _ in 0..DEPTH {
            script = Script::from_statements(vec![Statement::If {
                span: Span::new(0, 0),
                clauses: vec![IfClause {
                    condition: ExprNode::Raw { text: "1".into() },
                    condition_span: Span::new(0, 0),
                    body: script,
                    body_span: Span::new(0, 0),
                    condition_base: None,
                }],
                else_body: None,
                else_span: None,
            }]);
        }

        let mut count = 0usize;
        for_each_statement(&script, &mut |_| count += 1);
        assert!(count > 0, "must still visit statements within the cap");
        assert!(count <= DEPTH + 1, "must not exceed the number of nodes");
    }

    #[test]
    fn for_each_statement_descends_into_upframe_body() {
        // FN guard: `UpFrame` (a static-body `uplevel
        // ?level? {...}`) has a nested `body: Script` just like `Block` /
        // `While` / `Catch` / `Foreach`, but was missing from the grouped
        // match arm — the visitor stopped at the `UpFrame` statement itself
        // and never walked its body, so a whole-module scan built on this
        // visitor (e.g. `var_observability::scan_module_global_names`)
        // silently missed anything declared inside a static `uplevel` body.
        let inner = Statement::Call {
            span: Span::new(0, 0),
            command: "inner".into(),
            canonical_command: None,
            args: Vec::new(),
            defs: Vec::new(),
            reads: Vec::new(),
            reads_own_defs: false,
            safe_on_uninit: false,
            tokens: None,
            foreach_groups: None,
        };
        let upframe = Statement::UpFrame {
            span: Span::new(0, 0),
            frame_shift: 0,
            absolute: true,
            body: Script::from_statements(vec![inner]),
            tokens: None,
        };
        let script = Script::from_statements(vec![upframe]);

        let mut seen: Vec<String> = Vec::new();
        for_each_statement(&script, &mut |stmt| {
            let name = match stmt {
                Statement::UpFrame { .. } => "upframe".to_owned(),
                Statement::Call { command, .. } => command.clone(),
                _ => "other".to_owned(),
            };
            seen.push(name);
        });
        assert_eq!(seen, vec!["upframe", "inner"]);
    }

    #[test]
    fn statement_span_accessor() {
        let stmt = Statement::Call {
            span: Span::new(5, 20),
            command: "puts".into(),
            canonical_command: None,
            args: vec!["hello".into()],
            defs: Vec::new(),
            reads: Vec::new(),
            reads_own_defs: false,
            safe_on_uninit: false,
            tokens: None,
            foreach_groups: None,
        };
        assert_eq!(stmt.span(), Span::new(5, 20));
    }

    #[test]
    fn assign_const_roundtrip() {
        let stmt = Statement::AssignConst {
            span: Span::new(0, 7),
            name: "x".into(),
            name_braced: false,
            value: "42".into(),
            value_span: None,
        };
        if let Statement::AssignConst { name, value, .. } = &stmt {
            assert_eq!(name, "x");
            assert_eq!(value, "42");
        } else {
            panic!("wrong variant");
        }
    }

    #[test]
    fn barrier_with_tokens() {
        let tokens = CommandTokens::from_lossy_parts(
            vec![Span::new(0, 4), Span::new(5, 10)],
            vec!["eval".into(), "body".into()],
            vec![tcl_lexer::TokenType::Esc, tcl_lexer::TokenType::Str],
            vec![true, true],
            vec![Span::new(0, 4), Span::new(4, 5), Span::new(5, 10)],
            None,
        );
        let stmt = Statement::Barrier {
            span: Span::new(0, 10),
            reason: "eval".into(),
            command: "eval".into(),
            canonical_command: None,
            args: vec!["body".into()],
            tokens: Some(tokens.clone()),
        };
        if let Statement::Barrier {
            tokens: Some(t), ..
        } = &stmt
        {
            assert_eq!(t.argv_texts, vec!["eval", "body"]);
        } else {
            panic!("expected tokens");
        }
    }

    #[test]
    fn if_statement_structure() {
        let stmt = Statement::If {
            span: Span::new(0, 50),
            clauses: vec![IfClause {
                condition: ExprNode::Literal {
                    text: "1".into(),
                    start: 3,
                    end: 4,
                },
                condition_span: Span::new(3, 4),
                body: Script::from_statements(vec![Statement::Call {
                    span: Span::new(6, 15),
                    command: "puts".into(),
                    canonical_command: None,
                    args: vec!["yes".into()],
                    defs: Vec::new(),
                    reads: Vec::new(),
                    reads_own_defs: false,
                    safe_on_uninit: false,
                    tokens: None,
                    foreach_groups: None,
                }]),
                body_span: Span::new(5, 16),
                condition_base: None,
            }],
            else_body: None,
            else_span: None,
        };
        assert_eq!(stmt.span(), Span::new(0, 50));
        if let Statement::If { clauses, .. } = &stmt {
            assert_eq!(clauses.len(), 1);
        }
    }

    #[test]
    fn for_loop_structure() {
        let stmt = Statement::For {
            span: Span::new(0, 40),
            init: Script::from_statements(vec![Statement::AssignConst {
                span: Span::new(5, 12),
                name: "i".into(),
                name_braced: false,
                value: "0".into(),
                value_span: None,
            }]),
            init_span: Span::new(4, 13),
            condition: ExprNode::Binary {
                op: crate::expr_ast::BinOp::Lt,
                left: Box::new(ExprNode::Var {
                    text: "$i".into(),
                    name: "i".into(),
                    start: 0,
                    end: 2,
                }),
                right: Box::new(ExprNode::Literal {
                    text: "10".into(),
                    start: 5,
                    end: 7,
                }),
            },
            condition_span: Span::new(14, 22),
            next: Script::from_statements(vec![Statement::Incr {
                span: Span::new(24, 30),
                name: "i".into(),
                name_braced: false,
                amount: None,
                amount_braced: false,
                safe_on_uninit: false,
            }]),
            next_span: Span::new(23, 31),
            body: Script::new(),
            body_span: Span::new(32, 34),
            raw_args: Vec::new(),
            raw_tokens: None,
            condition_base: None,
        };
        assert_eq!(stmt.span(), Span::new(0, 40));
    }

    #[test]
    fn switch_mode_parse() {
        assert_eq!(SwitchMode::from_str_lossy("exact"), SwitchMode::Exact);
        assert_eq!(SwitchMode::from_str_lossy("glob"), SwitchMode::Glob);
        assert_eq!(SwitchMode::from_str_lossy("regexp"), SwitchMode::Regexp);
        assert_eq!(SwitchMode::from_str_lossy("unknown"), SwitchMode::Exact);
    }

    #[test]
    fn switch_mode_str() {
        assert_eq!(SwitchMode::Exact.as_str(), "exact");
        assert_eq!(SwitchMode::Glob.as_str(), "glob");
        assert_eq!(SwitchMode::Regexp.as_str(), "regexp");
    }

    #[test]
    fn method_kind_from_effect() {
        use tcl_registry::definer::{CallableRole as R, MemberReceiver as S};
        let cases = [
            (R::Method, S::Instance, Some(MethodKind::Method)),
            (R::Method, S::TypeObject, Some(MethodKind::ClassMethod)),
            (R::Procedure, S::TypeObject, Some(MethodKind::ClassMethod)),
            (R::Procedure, S::Instance, Some(MethodKind::ClassMethod)),
            (R::Constructor, S::Instance, Some(MethodKind::Constructor)),
            (R::Destructor, S::Instance, Some(MethodKind::Destructor)),
            (R::Method, S::Both, None),
            (R::Constructor, S::TypeObject, None),
            (R::Destructor, S::TypeObject, None),
            (R::Accessor, S::Instance, None),
            (R::Mutator, S::Instance, None),
        ];
        for (role, receiver, kind) in cases {
            assert_eq!(
                MethodKind::from_effect(role, receiver),
                kind,
                "{role:?} on {receiver:?}"
            );
        }
    }

    #[test]
    fn method_kind_spellings_are_the_analysers() {
        let spellings: Vec<&str> = [
            MethodKind::Method,
            MethodKind::ClassMethod,
            MethodKind::Constructor,
            MethodKind::Destructor,
        ]
        .into_iter()
        .map(MethodKind::as_str)
        .collect();
        assert_eq!(
            spellings,
            ["method", "classmethod", "constructor", "destructor"]
        );
    }

    #[test]
    fn when_event_name_simple() {
        assert_eq!(when_event_name("::when::HTTP_REQUEST"), "HTTP_REQUEST");
    }

    #[test]
    fn when_event_name_indexed() {
        assert_eq!(when_event_name("::when::HTTP_REQUEST#1"), "HTTP_REQUEST");
    }

    #[test]
    fn when_event_name_no_prefix() {
        assert_eq!(when_event_name("HTTP_REQUEST"), "HTTP_REQUEST");
    }

    #[test]
    fn procedure_construction() {
        let proc = Procedure {
            name: "greet".into(),
            qualified_name: "::greet".into(),
            params: vec!["name".into()],
            span: Span::new(0, 50),
            body: Script::from_statements(vec![Statement::Call {
                span: Span::new(20, 40),
                command: "puts".into(),
                canonical_command: None,
                args: vec!["Hello $name".into()],
                defs: Vec::new(),
                reads: Vec::new(),
                reads_own_defs: false,
                safe_on_uninit: false,
                tokens: None,
                foreach_groups: None,
            }]),
            params_raw: "name".into(),
            body_source: Some("puts \"Hello $name\"".into()),
            body_offset: 0,
            namespace_scoped: false,
            base_priority: 500,
        };
        assert_eq!(proc.name, "greet");
        assert_eq!(proc.params, vec!["name"]);
    }

    #[test]
    fn module_default() {
        let module = Module::default();
        assert_eq!(module.top_level.statements, [] as [crate::ir::Statement; 0]);
        assert_eq!(module.procedures.len(), 0);
        assert_eq!(module.methods.len(), 0);
        assert_eq!(module.redefined_procedures.len(), 0);
        assert_eq!(module.redefined_methods.len(), 0);
    }

    #[test]
    fn foreach_with_iterators() {
        let stmt = Statement::Foreach {
            span: Span::new(0, 30),
            iterators: vec![ForeachIterator {
                vars: vec!["k".into(), "v".into()],
                list_arg: "$dict".into(),
                list_braced: false,
            }],
            body: Script::new(),
            body_span: Span::new(25, 28),
            is_lmap: false,
            raw_args: Vec::new(),
            is_dict_iteration: true,
            is_array_iteration: false,
            raw_tokens: None,
        };
        if let Statement::Foreach {
            iterators,
            is_dict_iteration,
            ..
        } = &stmt
        {
            assert_eq!(iterators.len(), 1);
            assert_eq!(iterators[0].vars, vec!["k", "v"]);
            assert!(is_dict_iteration);
        }
    }

    #[test]
    fn catch_statement() {
        let stmt = Statement::Catch {
            span: Span::new(0, 30),
            body: Script::new(),
            body_span: Span::new(6, 12),
            result_var: Some("result".into()),
            options_var: Some("opts".into()),
            raw_args: Vec::new(),
            tokens: None,
        };
        if let Statement::Catch {
            result_var,
            options_var,
            ..
        } = &stmt
        {
            assert_eq!(result_var.as_deref(), Some("result"));
            assert_eq!(options_var.as_deref(), Some("opts"));
        }
    }

    #[test]
    fn try_with_handlers() {
        let stmt = Statement::Try {
            span: Span::new(0, 60),
            body: Script::new(),
            body_span: Span::new(4, 10),
            handlers: vec![TryHandler {
                kind: HandlerMatch::CompletionCode,
                match_arg: "error".into(),
                trap_pattern: None,
                var_name: Some("e".into()),
                options_var: None,
                body: Script::new(),
                body_span: Span::new(30, 40),
                fallthrough: false,
            }],
            finally_body: Some(Script::new()),
            finally_span: Some(Span::new(50, 58)),
            raw_args: Vec::new(),
        };
        if let Statement::Try {
            handlers,
            finally_body,
            ..
        } = &stmt
        {
            assert_eq!(handlers.len(), 1);
            assert_eq!(handlers[0].kind, HandlerMatch::CompletionCode);
            assert!(finally_body.is_some());
        }
    }

    #[test]
    fn switch_statement() {
        let stmt = Statement::Switch {
            subject_braced: false,
            raw_arg_braced: Vec::new(),
            raw_arg_quoted: Vec::new(),
            command: "switch".into(),
            span: Span::new(0, 80),
            subject: "$cmd".into(),
            subject_span: Span::new(7, 11),
            arms: vec![
                SwitchArm {
                    pattern: "start".into(),
                    pattern_braced: true,
                    pattern_span: Span::new(13, 18),
                    body: Some(Script::new()),
                    body_span: Some(Span::new(19, 22)),
                    fallthrough: false,
                },
                SwitchArm {
                    pattern: "stop".into(),
                    pattern_braced: true,
                    pattern_span: Span::new(23, 27),
                    body: None,
                    body_span: None,
                    fallthrough: true,
                },
            ],
            default_body: Some(Script::new()),
            default_span: Some(Span::new(50, 60)),
            mode: SwitchMode::Exact,
            nocase: false,
            raw_args: Vec::new(),
            patterns_braced: true,
        };
        if let Statement::Switch { arms, mode, .. } = &stmt {
            assert_eq!(arms.len(), 2);
            assert!(arms[1].fallthrough);
            assert_eq!(*mode, SwitchMode::Exact);
        }
    }

    #[test]
    fn clone_preserves_equality() {
        let stmt = Statement::AssignConst {
            span: Span::new(0, 10),
            name: "x".into(),
            name_braced: false,
            value: "1".into(),
            value_span: None,
        };
        let cloned = stmt.clone();
        assert_eq!(stmt, cloned);
    }

    #[test]
    fn return_with_expr() {
        let stmt = Statement::Return {
            expr_base: None,
            tokens: None,
            span: Span::new(0, 20),
            value: None,
            value_word: None,
            expr: Some(ExprNode::Binary {
                op: crate::expr_ast::BinOp::Add,
                left: Box::new(ExprNode::Var {
                    text: "$a".into(),
                    name: "a".into(),
                    start: 0,
                    end: 2,
                }),
                right: Box::new(ExprNode::Literal {
                    text: "1".into(),
                    start: 5,
                    end: 6,
                }),
            }),
            command_binding: None,
            braced: false,
        };
        if let Statement::Return { expr: Some(e), .. } = &stmt {
            let vars = e.vars_with_grammar(tcl_dialect::LexerGrammar::default());
            assert!(vars.contains("a"));
        }
    }

    // canonical_command_or_source helper

    #[test]
    fn canonical_command_or_source_falls_back_to_source_when_none() {
        let stmt = Statement::Call {
            span: Span::new(0, 3),
            command: "foo".into(),
            canonical_command: None,
            args: Vec::new(),
            defs: Vec::new(),
            reads: Vec::new(),
            reads_own_defs: false,
            safe_on_uninit: false,
            tokens: None,
            foreach_groups: None,
        };
        assert_eq!(stmt.canonical_command_or_source(), "foo");
    }

    #[test]
    fn canonical_command_or_source_returns_canonical_when_some() {
        let stmt = Statement::Call {
            span: Span::new(0, 3),
            command: "foo".into(),
            canonical_command: Some("::ns::bar".into()),
            args: Vec::new(),
            defs: Vec::new(),
            reads: Vec::new(),
            reads_own_defs: false,
            safe_on_uninit: false,
            tokens: None,
            foreach_groups: None,
        };
        assert_eq!(stmt.canonical_command_or_source(), "::ns::bar");
    }

    #[test]
    fn canonical_command_or_source_works_on_barrier() {
        let stmt = Statement::Barrier {
            span: Span::new(0, 6),
            reason: "eval".into(),
            command: "eval".into(),
            canonical_command: Some("eval".into()),
            args: vec!["body".into()],
            tokens: None,
        };
        assert_eq!(stmt.canonical_command_or_source(), "eval");
    }

    #[test]
    fn canonical_command_or_source_returns_empty_for_non_call_non_barrier() {
        let stmt = Statement::AssignConst {
            span: Span::new(0, 5),
            name: "x".into(),
            name_braced: false,
            value: "1".into(),
            value_span: None,
        };
        assert_eq!(stmt.canonical_command_or_source(), "");
    }
}
