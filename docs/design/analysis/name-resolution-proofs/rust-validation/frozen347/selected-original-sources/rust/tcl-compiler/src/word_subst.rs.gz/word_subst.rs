// tcl-lsp — a language server and toolchain for Tcl
// Copyright (C) 2026 James Deucker (bitwisecook) <https://github.com/bitwisecook>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.
//
// SPDX-License-Identifier: AGPL-3.0-or-later

//! Command substitutions nested inside a statement's words.
//!
//! A `[cmd …]` written as a whole statement is an IR statement the shimmer
//! detectors walk. The same `[cmd …]` written inside another command's word
//! is not: `Statement::Call` keeps its arguments as flat text, so
//! `puts [lindex $x 0]` is one opaque call and the `lindex` inside it is
//! invisible. The runtime draws no such distinction — it evaluates the
//! substitution either way — so the gap costs twice over:
//!
//! 1. the conversion at the nested site is never reported; and
//! 2. worse, it never reaches the commit state, so *every later read of that
//!    variable* is judged against a stale representation. Unlifted,
//!    `set x [llength $l]` then `puts [lindex $x 0]` then `incr x` reports
//!    nothing at all, where the same code with `lindex $x 0` on its own line
//!    reports both halves.
//!
//! Builds on [`crate::word_expr`], which owns splitting one word into its
//! substitution components; this module is the statement-level view of that —
//! which *commands* a statement's words run, and in what order.
//!
//! ## Why this reads `word_exprs` and not the argument text
//!
//! Tcl substitutes `[…]` in bare and `"…"`-quoted words but **not** in braced
//! ones, and `Statement::Call::args` cannot tell them apart: `puts [lindex $x 0]`
//! and `puts {[lindex $x 0]}` both arrive as the single argument text
//! `[lindex $x 0]`. Lifting from that text would report a command Tcl never
//! runs. [`CommandTokens::word_exprs`](crate::ir::CommandTokens::word_exprs) is
//! the structured per-word syntax the segmenter already derived — it models the
//! braced word as [`WordExpr::BracedLiteral`] and the substituted one as
//! [`WordExpr::CommandSubstitution`] — so reading it is both correct and free of
//! any re-lexing.
//!
//! ## Order
//!
//! Substitutions are yielded innermost-first, then left to right — Tcl's own
//! evaluation order, so the commit state moves exactly as the runtime converts.
//! In `foo [bar [baz $x]]` the reads of `baz` land before `bar`'s.

use tcl_lexer::Span;

use tcl_registry::model::DocumentCommandSurface;

use crate::ir::{CommandTokens, Provenance, SourceSite, WordExpr, WordPart};

/// How deep a nest of `[cmd [cmd …]]` this walks before giving up. Tcl's own
/// parser caps nesting far above anything hand-written; this only has to stop
/// a generated pathological input from recursing without bound.
const MAX_SUBSTITUTION_DEPTH: u32 = 8;

/// One `[cmd …]` substitution lifted out of a word, shaped like the direct
/// invocation it behaves as.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct LiftedCall {
    /// The substitution's command word, as spelled. Dispatch identity belongs
    /// to the retained source proof in `tokens`, rather than this spelling.
    pub command: String,
    /// Retained structured command words and their exact dispatch proof, when queried.
    pub tokens: Option<CommandTokens>,
    /// The substitution's argument words, index-aligned with `arg_spans`.
    pub args: Vec<String>,
    /// Absolute source span of each argument word.
    pub arg_spans: Vec<Span>,
    /// The structured syntax of each argument word, index-aligned with
    /// [`Self::args`] — so a consumer can tell a braced literal from a word
    /// that substitutes without re-deciding it from the text.
    ///
    /// Empty when [`nested_command_words`] declined the substitution, or when
    /// its word count disagreed with the argument split; a consumer that reads
    /// this must keep working without it.
    pub arg_words: Vec<WordExpr>,
    /// The substitution's own words as [`nested_command_words`] recovers
    /// them, the command word at `0`; `None` when it declined.
    pub words: Option<CommandTokens>,
    /// Absolute source span of the whole `[…]`.
    pub span: Span,
}

#[derive(Default)]
struct LiftedCallCollection {
    calls: Vec<LiftedCall>,
    incomplete: bool,
}

/// Complete original substitution inventory for effect consumers. A truncated
/// or unsupported word walk must not establish absence of name effects.
pub(crate) fn checked_lifted_calls(
    tokens: &CommandTokens,
    config: tcl_lexer::LexerConfig,
) -> Option<Vec<LiftedCall>> {
    let collected = lift(Some(tokens), config, None);
    (!collected.incomplete).then_some(collected.calls)
}

/// Complete substitutions of the written argv alone. This source walk does
/// not enter the enclosing command's braced expression or script operands.
/// Parent configuration stays unchanged; each extracted child uses its nested
/// parser purpose in the existing collector.
pub(crate) fn checked_argument_lifted_calls(
    tokens: &CommandTokens,
    config: tcl_lexer::LexerConfig,
) -> Option<Vec<LiftedCall>> {
    let mut collected = LiftedCallCollection::default();
    collect_command_words(tokens.words(), config, None, 0, &mut collected);
    if collected.incomplete {
        return None;
    }
    for call in &mut collected.calls {
        let child = call.tokens.as_mut()?;
        child.inherit_nested_bindings(tokens);
        call.words = Some(child.clone());
    }
    Some(collected.calls)
}

/// Source-only original argv inventory under the same retained input. Every
/// child matches its original vector/config/site; this supplies no dispatch.
pub(crate) fn checked_original_argument_lifted_calls(
    tokens: &CommandTokens,
    registry: &tcl_registry::CommandRegistry,
    metadata: crate::registry_invocation::InvocationMetadataContext<'_>,
) -> Option<Vec<LiftedCall>> {
    let input = metadata.source_analysis_input()?;
    metadata.matches_registry(registry).then_some(())?;
    let binding = tokens.source_binding.as_ref()?;
    binding.original_argument_metadata_for_input(tokens, input, registry)?;
    let config = binding.original_argument_lexer_config(tokens)?;
    let calls = checked_argument_lifted_calls(tokens, config)?;
    for call in &calls {
        let child = call.tokens.as_ref()?;
        child
            .source_binding
            .as_ref()?
            .original_argument_metadata_for_input(child, input, registry)?;
    }
    Some(calls)
}

/// Complete original nested-call geometry under the retained source input.
/// Selected expression roles extend lexical substitutions; every child keeps
/// its original sidecar. Missing source/config/roles or incomplete recovery
/// withdraws the inventory, independently of handler or body entry.
pub(crate) fn checked_original_lifted_calls_with_metadata_context(
    tokens: &CommandTokens,
    config: tcl_lexer::LexerConfig,
    registry: &tcl_registry::CommandRegistry,
    metadata: crate::registry_invocation::InvocationMetadataContext<'_>,
) -> Option<Vec<LiftedCall>> {
    let mut pending = vec![(tokens.clone(), 0)];
    let mut seen = std::collections::HashSet::new();
    let mut calls: Vec<LiftedCall> = Vec::new();
    while let Some((parent, depth)) = pending.pop() {
        if depth > MAX_SUBSTITUTION_DEPTH {
            return None;
        }
        let offset = original_call_context(&parent, config, registry, metadata)?;
        if !seen.insert(offset) {
            continue;
        }
        let mut collected = LiftedCallCollection::default();
        collect_command_words(&parent.word_exprs, config, None, 0, &mut collected);
        collect_original_expression_calls(&parent, config, registry, metadata, &mut collected)?;
        if collected.incomplete {
            return None;
        }
        for mut call in collected.calls {
            let child = call.tokens.as_mut()?;
            child.inherit_nested_bindings(&parent);
            call.words = Some(child.clone());
            if let Some(previous) = calls.iter().find(|previous| previous.span == call.span) {
                if previous != &call {
                    return None;
                }
            } else {
                pending.push((child.clone(), depth + 1));
                calls.push(call);
            }
        }
    }
    calls.sort_by_key(|call| (call.span.end(), std::cmp::Reverse(call.span.start())));
    Some(calls)
}

fn original_call_context(
    tokens: &CommandTokens,
    config: tcl_lexer::LexerConfig,
    registry: &tcl_registry::CommandRegistry,
    metadata: crate::registry_invocation::InvocationMetadataContext<'_>,
) -> Option<u32> {
    let input = metadata.source_analysis_input()?;
    if !metadata.matches_registry(registry)
        || config.nested().normalized() != input.lexer_config().nested().normalized()
        || tokens.synthetic.is_some()
    {
        return None;
    }
    let binding = tokens.source_binding.as_ref()?;
    let original_config = binding.original_lexer_config_for_tokens(tokens)?;
    if original_config.nested().normalized() != config.nested().normalized() {
        return None;
    }
    let site = binding.invocation_site()?;
    crate::registry_invocation::original_native_compiler_words(
        site.source.source_image(),
        tokens.words(),
        site.offset,
        original_config,
    )?;
    Some(site.offset)
}

fn collect_original_expression_calls(
    tokens: &CommandTokens,
    config: tcl_lexer::LexerConfig,
    registry: &tcl_registry::CommandRegistry,
    metadata: crate::registry_invocation::InvocationMetadataContext<'_>,
    collected: &mut LiftedCallCollection,
) -> Option<()> {
    let has_braced_commands = tokens
        .words()
        .iter()
        .any(|word| matches!(word, WordExpr::BracedLiteral { text, .. } if text.contains('[')));
    let invocation = if metadata.permits_logical_source_names() {
        crate::registry_invocation::original_logical_operation_invocation_with_metadata_context(
            registry, metadata, tokens,
        )
    } else {
        crate::registry_invocation::resolved_tokens_invocation_with_metadata_context(
            registry,
            Some(metadata),
            tokens,
        )
    };
    let (roles, traits) = if let Some(invocation) = invocation {
        let roles = if metadata.permits_logical_source_names() {
            let realm = tokens
                .source_binding
                .as_ref()?
                .original_source_realm_for_input(
                    tokens,
                    metadata.source_analysis_input()?,
                    registry,
                )?;
            let projection =
                invocation.with_metadata_schema(registry, metadata, realm, |schema| {
                    schema.authored_logical_source_role_projection()
                })?;
            if projection.selection_unknown() {
                return None;
            }
            // Captured Expr words belong to their original producer, rather
            // than this caller's written braced-word inventory.
            if projection.argument_roles().iter().any(|(argument, role)| {
                *role == tcl_registry::ArgRole::Expr
                    && invocation.effective.written_argument(*argument).is_none()
            }) {
                return None;
            }
            projection
                .argument_roles()
                .iter()
                .filter_map(|(argument, role)| {
                    invocation
                        .effective
                        .written_argument(*argument)
                        .map(|written| (written, *role))
                })
                .collect()
        } else {
            // Native inventory keeps its separate complete-role permission.
            if !invocation.facts.arg_roles_complete {
                return None;
            }
            invocation.written_argument_roles()
        };
        if !invocation.effective.binding_prefix.is_empty()
            && (invocation
                .facts
                .traits
                .contains(tcl_registry::Traits::EXPR_CONCATENATES_ARGS)
                || (!metadata.permits_logical_source_names()
                    && invocation
                        .facts
                        .arg_roles
                        .iter()
                        .any(|(_, role)| *role == tcl_registry::ArgRole::Expr)))
        {
            return None;
        }
        (roles, invocation.facts.traits)
    } else if let Some(invocation) = (!metadata.permits_logical_source_names())
        .then(|| {
            crate::registry_invocation::logical_structured_invocation_with_metadata_context(
                registry, metadata, tokens, None,
            )
        })
        .flatten()
    {
        (invocation.written_roles(), invocation.traits())
    } else {
        if tokens
            .source_binding
            .as_ref()?
            .execution_targets()
            .any(|target| target.registry_backed)
        {
            return None;
        }
        return (!has_braced_commands).then_some(());
    };
    let concatenated = traits.contains(tcl_registry::Traits::EXPR_CONCATENATES_ARGS);
    if concatenated && has_braced_commands && tokens.words().len() != 2 {
        return None;
    }
    let site = tokens.source_binding.as_ref()?.invocation_site()?;
    for (ordinal, word) in tokens.words().iter().skip(1).enumerate() {
        if !concatenated && !roles.contains(&(ordinal, tcl_registry::ArgRole::Expr)) {
            continue;
        }
        let WordExpr::BracedLiteral { text, source } = word else {
            continue;
        };
        let base = source.span.start().checked_add(1)?;
        let end = usize::try_from(base).ok()?.checked_add(text.len())?;
        if source.provenance != Provenance::Source
            || site
                .source
                .source_image()
                .bytes()
                .get(usize::try_from(base).ok()?..end)
                != Some(text.as_bytes())
        {
            return None;
        }
        collect_surface_text_with_surface(text, Some(base), config, None, 0, collected);
    }
    Some(())
}

/// Every command substitution nested in `tokens`' words, innermost-first.
///
/// Returns an empty vector for a statement whose words hold no substitution —
/// the overwhelming majority — without allocating beyond the empty `Vec`.
#[must_use]
pub fn lifted_calls(
    tokens: Option<&CommandTokens>,
    config: tcl_lexer::LexerConfig,
) -> Vec<LiftedCall> {
    lift(tokens, config, None).calls
}

/// A reached expression evaluator inside an original written operand.
/// This carries no dispatch or normal-completion authority for its parent.
pub(crate) struct EnteredExpressionEvaluation {
    expression: crate::expr_ast::ExprNode,
    expression_base: u32,
    span: Span,
    numbers: tcl_dialect::NumberSyntax,
    grammar: tcl_dialect::LexerGrammar,
}

impl EnteredExpressionEvaluation {
    pub(crate) fn expression(&self) -> &crate::expr_ast::ExprNode {
        &self.expression
    }

    pub(crate) fn expression_base(&self) -> u32 {
        self.expression_base
    }

    pub(crate) fn span(&self) -> Span {
        self.span
    }

    pub(crate) fn numbers(&self) -> tcl_dialect::NumberSyntax {
        self.numbers
    }

    pub(crate) fn grammar(&self) -> tcl_dialect::LexerGrammar {
        self.grammar
    }
}

/// Recover entered child evaluation independently of the enclosing handler.
/// Only the child's exact source binding supplies its implementation and syntax.
pub(crate) fn entered_expression_evaluations(
    tokens: Option<&CommandTokens>,
    config: tcl_lexer::LexerConfig,
    registry: &tcl_registry::CommandRegistry,
) -> Vec<EnteredExpressionEvaluation> {
    lifted_calls(tokens, config)
        .into_iter()
        .filter_map(|call| entered_expression_evaluation(&call.tokens?, registry))
        .collect()
}

fn entered_expression_evaluation(
    tokens: &CommandTokens,
    registry: &tcl_registry::CommandRegistry,
) -> Option<EnteredExpressionEvaluation> {
    let binding = tokens.source_binding.as_ref()?;
    if binding.runtime_reachability() != crate::command_binding::SourceRuntimeReachability::Reached
    {
        return None;
    }
    let site = binding.invocation_site()?;
    let invocation =
        crate::registry_invocation::resolved_handler_invocation(registry, None, tokens)?;
    if invocation.facts.operation
        != tcl_registry::SemanticOperationId::StructuredLowering(
            tcl_registry::hooks::LoweringHookId::Expr,
        )
        || invocation.facts.argument_offset != 0
        || tokens.words().len() != 2
    {
        return None;
    }
    let word = tokens.words().get(1)?;
    let WordExpr::BracedLiteral { text, source } = word else {
        return None;
    };
    if source.provenance != Provenance::Source {
        return None;
    }
    let head = tokens.words().first()?.source();
    if head.provenance != Provenance::Source || head.span.start() != site.offset {
        return None;
    }
    let base = crate::lowering_hooks::word_content_base(
        *tokens.argv.get(1)?,
        tokens.single_token_word.get(1).copied()?,
        text,
    )?;
    let length = u32::try_from(text.len()).ok()?;
    let end = base.checked_add(length)?;
    if site
        .source
        .source_image()
        .bytes()
        .get(base as usize..end as usize)
        != Some(text.as_bytes())
    {
        return None;
    }
    let dialect = binding.variable_context.invocation_dialect?;
    let parser = dialect.expression_parse_context(None);
    Some(EnteredExpressionEvaluation {
        expression: crate::expr_parser::parse_expr_with_syntax_context(text, &parser),
        expression_base: base,
        span: Span::new(head.span.start(), word.source().span.end()),
        numbers: dialect.numbers,
        grammar: parser.lexer_grammar,
    })
}

/// [`lifted_calls_with_surface`] over one word rather than a whole command.
///
/// A CFG terminator keeps its value as a single [`WordExpr`] —
/// `Terminator::Return::value_word` — not as a `CommandTokens`, and the
/// commands in it run exactly as they would in a statement.
#[must_use]
pub fn lifted_calls_in_word(
    word: Option<&WordExpr>,
    config: tcl_lexer::LexerConfig,
    surface: &DocumentCommandSurface<'_>,
) -> Vec<LiftedCall> {
    let mut out = LiftedCallCollection::default();
    if let Some(word) = word {
        collect_word(word, config, Some(surface), 0, &mut out);
    }
    out.calls
}

/// [`lifted_calls`], plus the substitutions a brace-quoted **expression** word
/// runs.
///
/// A braced word is inert to the command parser, but not to `expr`: it
/// re-parses that text as an expression and a `[…]` in it is a command the
/// statement really runs. Without a command surface there is no way to tell
/// `puts {[f]}` (literal) from `expr {[f]}` (a call), so the plain
/// [`lifted_calls`] has to take the narrow view; a caller that holds one gets
/// the whole set.
///
/// The *surface*, not the bare catalogue: a document's own
/// `# tcl-lsp: stub myexpr {value:expr}` declares an expression word exactly
/// as a shipped command does, and lowering honours that role, so a call
/// `myexpr {[id 9]}` is a call site like any other.
///
/// `return [expr {[fact [expr {$n - 1}] [expr {$n * $acc}]]}]` is the case
/// that matters. Its recursive call was invisible to the caller-evidence scan,
/// so two visible `fact 5 1` / `fact 3 1` sites read as the *complete* caller
/// set and O100 specialised `acc` to `1`: tclsh 9.0.4 prints `120` then `6`,
/// the optimised program printed `1` then `1`, and with a single call site
/// O112 deleted the base case outright and the program no longer terminated
/// (#2118).
#[must_use]
pub fn lifted_calls_with_surface(
    tokens: Option<&CommandTokens>,
    config: tcl_lexer::LexerConfig,
    surface: &DocumentCommandSurface<'_>,
) -> Vec<LiftedCall> {
    lift(tokens, config, Some(surface)).calls
}

/// Checked lexical substitutions in retained original source, independently
/// of whether this declaration was entered. Each child retains its own proof;
/// this inventory grants no reached operand or command dispatch authority.
pub(crate) fn original_lifted_calls_with_surface(
    tokens: &CommandTokens,
    config: tcl_lexer::LexerConfig,
    surface: &DocumentCommandSurface<'_>,
) -> Vec<LiftedCall> {
    let Some(site) = tokens
        .source_binding
        .as_ref()
        .and_then(|binding| binding.invocation_site())
    else {
        return Vec::new();
    };
    if crate::registry_invocation::native_compiler_replay_source(tokens, site).is_none() {
        return Vec::new();
    }
    let config = tokens.native_lexer_config(config);
    let mut out = LiftedCallCollection::default();
    collect_command_words(&tokens.word_exprs, config, Some(surface), 0, &mut out);
    for call in &mut out.calls {
        if let Some(nested) = &mut call.tokens {
            nested.inherit_nested_bindings(tokens);
        }
    }
    out.calls
}

fn lift(
    tokens: Option<&CommandTokens>,
    config: tcl_lexer::LexerConfig,
    surface: Option<&DocumentCommandSurface<'_>>,
) -> LiftedCallCollection {
    let mut out = LiftedCallCollection::default();
    let Some(tokens) = tokens else {
        return out;
    };
    if !tokens.evaluates_words() {
        return out;
    }
    let config = tokens.native_lexer_config(config);
    collect_command_words(&tokens.word_exprs, config, surface, 0, &mut out);
    for lifted in &mut out.calls {
        if let Some(nested) = &mut lifted.tokens {
            nested.inherit_nested_bindings(tokens);
        }
    }
    out
}

/// Push every substitution one command's words evaluate: the `[…]` each
/// substituting word carries, then — when the surface says so — the `[…]`
/// inside a brace-quoted word the head evaluates as an expression.
fn collect_command_words(
    words: &[WordExpr],
    config: tcl_lexer::LexerConfig,
    surface: Option<&DocumentCommandSurface<'_>>,
    depth: u32,
    out: &mut LiftedCallCollection,
) {
    for word in words {
        collect_word(word, config, surface, depth, out);
    }
    let Some(surface) = surface else {
        return;
    };
    // This lexical traversal asks only for assistance roles. Actual nested
    // dispatch proofs are attached to the lifted token carriers afterwards.
    let Some(WordExpr::Literal { text: head, .. }) = words.first() else {
        return;
    };
    let args: Vec<String> = words.iter().skip(1).map(WordExpr::legacy_text).collect();
    let arg_refs: Vec<&str> = args.iter().map(String::as_str).collect();
    for index in crate::ir_helpers::in_frame_expression_arg_indices(head, &arg_refs, surface) {
        // An unbraced expression word already substituted at the command
        // level, so the loop above has seen its `[…]`; descending again would
        // report the same call twice.
        let Some(WordExpr::BracedLiteral { text, source }) = words.get(index + 1) else {
            continue;
        };
        // The word's site covers the `{…}` that quoted it, so its content
        // starts one byte in. A word whose site is not direct source carries
        // no offset worth anchoring to.
        let base = (source.provenance == Provenance::Source)
            .then(|| source.span.start().saturating_add(1));
        collect_surface_text(text, base, config, surface, depth, out);
    }
}

/// Push every `[…]` an evaluated **source surface** runs.
///
/// A surface is text Tcl substitutes but which reached the IR without words of
/// its own: an expression operand, an `incr` amount, a `return` value. It is
/// not a script, so it is not segmented — the lexer's own `Cmd` tokens are
/// exactly its bracket substitutions, spans included, and each is handed to
/// the same [`push_substitution`] a word-level `[…]` takes.
///
/// `base` is the absolute offset of `text`'s first byte when the surface is a
/// verbatim source slice. Without one the recovered spans are relative to the
/// surface, so a consumer that reports positions must supply it.
#[must_use]
pub fn lifted_calls_in_text(
    text: &str,
    base: Option<u32>,
    config: tcl_lexer::LexerConfig,
    surface: &DocumentCommandSurface<'_>,
) -> Vec<LiftedCall> {
    let mut out = LiftedCallCollection::default();
    collect_surface_text(text, base, config, surface, 0, &mut out);
    out.calls
}

fn collect_surface_text(
    text: &str,
    base: Option<u32>,
    config: tcl_lexer::LexerConfig,
    surface: &DocumentCommandSurface<'_>,
    depth: u32,
    out: &mut LiftedCallCollection,
) {
    collect_surface_text_with_surface(text, base, config, Some(surface), depth, out);
}

fn collect_surface_text_with_surface(
    text: &str,
    base: Option<u32>,
    config: tcl_lexer::LexerConfig,
    surface: Option<&DocumentCommandSurface<'_>>,
    depth: u32,
    out: &mut LiftedCallCollection,
) {
    if depth > MAX_SUBSTITUTION_DEPTH {
        out.incomplete = true;
        return;
    }
    let Ok(tokens) = tcl_lexer::Lexer::with_config(text, config.nested()).tokenise_all() else {
        out.incomplete = true;
        return;
    };
    let provenance = if base.is_some() {
        Provenance::Source
    } else {
        Provenance::Opaque
    };
    let base = base.unwrap_or(0);
    for token in tokens
        .iter()
        .filter(|token| token.kind == tcl_lexer::TokenType::Cmd)
    {
        let start = token.span.start() as usize;
        // A `Cmd` token's span runs to the last byte *inside* the brackets;
        // `push_substitution` parses a whole `[…]`, so the closing bracket is
        // taken back. Without one the `[` never closed, which is a parse error
        // Tcl raises rather than a command it runs.
        let end = token.span.end() as usize;
        let close = if text.as_bytes().get(end) == Some(&b']') {
            end + 1
        } else {
            end
        };
        let Some(spelling) = text.get(start..close).filter(|s| s.ends_with(']')) else {
            continue;
        };
        let site = SourceSite {
            span: Span::new(
                base.saturating_add(token.span.start()),
                base.saturating_add(u32::try_from(close).unwrap_or(u32::MAX)),
            ),
            provenance: provenance.clone(),
        };
        push_substitution(spelling, &site, config, surface, depth + 1, out);
    }
}

/// Every command substitution an expression evaluates.
///
/// A fused `AssignExpr` or `ExprEval` statement, and a CFG `Branch`
/// terminator, keep a parsed expression instead of words — `set r [expr {[f]}]`
/// and `if {[f] > 5} …` reach the IR with no `CommandTokens` at all, so a
/// walk that reads only words sees neither the `f` they run nor the caller
/// evidence it carries (#2118).
///
/// `expr_base` is the absolute offset of the expression text's first byte,
/// as [`crate::ir::IfClause::condition_base`] records it; see
/// [`lifted_calls_in_text`] for what its absence costs.
#[must_use]
pub fn lifted_calls_in_expr(
    expr: &crate::expr_ast::ExprNode,
    expr_base: Option<u32>,
    config: tcl_lexer::LexerConfig,
    surface: &DocumentCommandSurface<'_>,
) -> Vec<LiftedCall> {
    let mut out = LiftedCallCollection::default();
    collect_expr_node(expr, expr_base, config, surface, 0, &mut out);
    out.calls
}

fn collect_expr_node(
    expr: &crate::expr_ast::ExprNode,
    expr_base: Option<u32>,
    config: tcl_lexer::LexerConfig,
    surface: &DocumentCommandSurface<'_>,
    depth: u32,
    out: &mut LiftedCallCollection,
) {
    use crate::expr_ast::ExprNode;

    if depth > MAX_SUBSTITUTION_DEPTH {
        out.incomplete = true;
        return;
    }
    let mut descend = |node| collect_expr_node(node, expr_base, config, surface, depth + 1, out);
    match expr {
        ExprNode::Command { text, start, .. } => {
            let site = match expr_base {
                Some(base) => SourceSite::source(Span::new(
                    base.saturating_add(*start),
                    base.saturating_add(*start)
                        .saturating_add(u32::try_from(text.len()).unwrap_or(0)),
                )),
                None => SourceSite::opaque(Span::new(0, 0)),
            };
            push_substitution(text, &site, config, Some(surface), depth, out);
        }
        ExprNode::Binary { left, right, .. } => {
            descend(left);
            descend(right);
        }
        ExprNode::Unary { operand, .. } => descend(operand),
        ExprNode::Ternary {
            condition,
            true_branch,
            false_branch,
        } => {
            descend(condition);
            descend(true_branch);
            descend(false_branch);
        }
        ExprNode::Call { args, .. } => {
            for arg in args {
                descend(arg);
            }
        }
        // A word already reduced to its value: braced, its brackets are data
        // and never run; unbraced, whatever substitution it still owes really
        // is executed. The same split [`crate::ir_helpers`] makes for the
        // variable-effect walk.
        ExprNode::CompiledWord { text, braced } => {
            if !*braced {
                collect_surface_text(text, None, config, surface, depth + 1, out);
            }
        }
        // The parse gave up; its text is still evaluated, so it is read as a
        // surface rather than treated as running nothing.
        ExprNode::Raw { text } => {
            collect_surface_text(text, expr_base, config, surface, depth + 1, out);
        }
        // `"…"` substitutes inside an expression, `{…}` does not, and this
        // variant carries the source text *including* its delimiters — so the
        // delimiter is what decides. Reading every string as inert missed the
        // call in `set r [expr {"[id 9]"}]`: tclsh 8.6.18 prints `7 9` and
        // `--profile standard` folded `id`'s body to `return 7`, printing
        // `7 7` (#2118, found in review).
        ExprNode::String { text, start, .. } => {
            if let Some(inner) = quoted_operand_body(text) {
                let base = expr_base.map(|base| base.saturating_add(*start).saturating_add(1));
                collect_surface_text(inner, base, config, surface, depth + 1, out);
            }
        }
        ExprNode::Literal { .. } | ExprNode::Var { .. } => {}
    }
}

/// The body of a `"…"` expression operand that may run a command, or `None`
/// for a `{…}` one or one with no `[`.
///
/// The quoted/braced rule is [`tcl_syntax::expr::quoted_string_body`]'s:
/// tclsh 8.6.18 and 9.0.4 both print `2` then `2` for
/// `set x 1; puts [expr {"[incr x]"}]; puts $x`, and `1` then `1` for the
/// braced `{[incr x]}`.
pub(crate) fn quoted_operand_body(text: &str) -> Option<&str> {
    tcl_syntax::expr::quoted_string_body(text).filter(|inner| inner.contains('['))
}

/// Walk one word, pushing every substitution it evaluates.
fn collect_word(
    word: &WordExpr,
    config: tcl_lexer::LexerConfig,
    surface: Option<&DocumentCommandSurface<'_>>,
    depth: u32,
    out: &mut LiftedCallCollection,
) {
    if depth > MAX_SUBSTITUTION_DEPTH {
        out.incomplete = true;
        return;
    }
    match word {
        // The whole word is `[cmd …]`.
        WordExpr::CommandSubstitution { spelling, source } => {
            push_substitution(spelling, source, config, surface, depth, out);
        }
        // A compound word — `"[cmd …]"`, `a[cmd …]b`, `$v[cmd …]` — whose
        // parts evaluate left to right.
        WordExpr::Template { parts, .. } => {
            for part in parts {
                match part {
                    WordPart::CommandSubstitution { spelling, source } => {
                        push_substitution(spelling, source, config, surface, depth, out);
                    }
                    WordPart::Opaque { .. } => out.incomplete = true,
                    WordPart::Variable { spelling, .. }
                        if variable_index_may_run_command(spelling, config) =>
                    {
                        out.incomplete = true;
                    }
                    _ => {}
                }
            }
        }
        // `{*}[cmd …]` still evaluates the substitution before expanding it.
        WordExpr::Expand { word, .. } => collect_word(word, config, surface, depth, out),
        // A braced word's `[…]` is literal to the command parser — reading
        // `word_exprs` rather than the argument text is the whole point of
        // knowing that. Whether the command it is an argument *to* re-parses
        // it as an expression is `collect_command_words`' question, not this
        // one. `Literal`, `Variable` and `Opaque` carry no substitution.
        WordExpr::Literal { .. } | WordExpr::BracedLiteral { .. } => {}
        WordExpr::Variable { spelling, .. } => {
            out.incomplete |= variable_index_may_run_command(spelling, config);
        }
        WordExpr::Opaque { .. } => out.incomplete = true,
    }
}

// Only an index is substituted. Braced names may contain a literal `[`.
// Index command traversal is not part of this collector, so retain an opaque
// effect residual when its original extent could contain a command.
fn variable_index_may_run_command(spelling: &str, config: tcl_lexer::LexerConfig) -> bool {
    if !spelling.starts_with('$') {
        return true;
    }
    match tcl_lexer::word_parts::scan_var_ref(spelling.as_bytes(), 0, config) {
        Ok(Some(reference)) if reference.next == spelling.len() => {
            reference.index.is_some_and(|index| index.contains(&b'['))
        }
        _ => true,
    }
}

/// Parse one `[…]` and push it, deepest first, together with any substitution
/// nested in its own arguments.
fn push_substitution(
    spelling: &str,
    source: &SourceSite,
    config: tcl_lexer::LexerConfig,
    surface: Option<&DocumentCommandSurface<'_>>,
    depth: u32,
    out: &mut LiftedCallCollection,
) {
    if depth > MAX_SUBSTITUTION_DEPTH {
        out.incomplete = true;
        return;
    }
    let Some((command, args_with_spans)) =
        crate::value_shapes::parse_command_substitution_with_spans_and_config(spelling, config)
    else {
        out.incomplete = true;
        return;
    };
    let base = source.span.start();
    let leading = u32::try_from(spelling.len() - spelling.trim_start().len()).unwrap_or(0);
    let span = Span::new(
        base + leading,
        base + leading + u32::try_from(spelling.trim().len()).unwrap_or(0),
    );

    // The substitution's own words, recovered by the canonical segmenter. Its
    // structure is what decides which of them evaluate a further substitution
    // — `[list "[a]"]` and `[list b[c]d]` run one, `[list {[a]}]` does not —
    // and no test over the flat argument text can tell those apart.
    let nested = nested_command_words(spelling, source, config).ok();
    out.incomplete |= nested.is_none();
    if let Some(tokens) = nested.as_ref() {
        collect_command_words(&tokens.word_exprs, config, surface, depth + 1, out);
    }
    // Index-aligned with `args` (which start at word 1) or empty: the two
    // recoveries split words under the same `LexerConfig`, so a disagreement
    // means one of them declined the shape and the structure is not safe to
    // pair up positionally.
    let arg_words = nested
        .as_ref()
        .and_then(|tokens| tokens.word_exprs.get(1..))
        .filter(|words| words.len() == args_with_spans.len())
        .map(<[WordExpr]>::to_vec)
        .unwrap_or_default();

    let mut args = Vec::with_capacity(args_with_spans.len());
    let mut arg_spans = Vec::with_capacity(args_with_spans.len());
    for (text, rel) in &args_with_spans {
        args.push(text.clone());
        arg_spans.push(Span::new(base + rel.start(), base + rel.end()));
    }
    out.calls.push(LiftedCall {
        command,
        tokens: nested.clone(),
        args,
        arg_spans,
        arg_words,
        words: nested,
        span,
    });
}

/// Why the words of a `[…]` command substitution could not be recovered.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum NestedWordsDecline {
    /// The spelling is not one complete, non-empty `[…]` command.
    Unmodelled,
    /// It segmented, but carried no words.
    NoWords,
}

/// The structured words of a `[…]` command substitution.
///
/// The word snapshot keeps a command substitution as one opaque spelling, so
/// its inner words are recovered by running the canonical segmenter over the
/// recorded lexical extent — the same segmentation the outer command's words
/// came from, not a bespoke parser. Anything other than exactly one complete
/// command declines.
///
/// The one owner for this: the native and WASM lowerings plan a nested
/// invocation from the same words this module lifts for analysis, and a second
/// recovery that split a word differently would let the two tiers disagree
/// about what a substitution runs.
///
/// # Errors
///
/// Returns [`NestedWordsDecline`] when the spelling is not a single complete
/// `[…]` command, or when it carries no words at all.
pub fn nested_command_words(
    spelling: &str,
    source: &SourceSite,
    config: tcl_lexer::LexerConfig,
) -> Result<CommandTokens, NestedWordsDecline> {
    // Word spellings arrive exact, but a substitution recovered from argument
    // text can carry the whitespace that separated it; the offset the trim
    // drops is added back so spans stay anchored where the word really sits.
    let leading = u32::try_from(spelling.len() - spelling.trim_start().len()).unwrap_or(0);
    let inner = spelling
        .trim()
        .strip_prefix('[')
        .and_then(|text| text.strip_suffix(']'))
        .ok_or(NestedWordsDecline::Unmodelled)?;
    if inner.trim().is_empty() {
        return Err(NestedWordsDecline::Unmodelled);
    }
    let base = if source.provenance == Provenance::Source {
        source
            .span
            .start()
            .saturating_add(leading)
            .saturating_add(1)
    } else {
        0
    };
    let config = config.nested();
    let segments = crate::segmenter::segment_commands_with_offset_and_config(inner, base, config);
    let [segment] = segments.as_slice() else {
        return Err(NestedWordsDecline::Unmodelled);
    };
    if segment.is_partial {
        return Err(NestedWordsDecline::Unmodelled);
    }
    // The nested script is a sub-lex: its own text, segmented at the document
    // offset it sits at, so the word model reads `inner` and still reports
    // document spans (`SourceMap::with_base` is that sub-lexing contract).
    let sm = tcl_lexer::SourceMap::new(inner).with_base(base, 0, 0);
    let mut tokens = CommandTokens::from_segmented(&sm, config, segment);
    if source.provenance != Provenance::Source {
        for word in &mut tokens.word_exprs {
            retain_nested_provenance(word, &source.provenance);
        }
    }
    if tokens.word_exprs.is_empty() {
        return Err(NestedWordsDecline::NoWords);
    }
    Ok(tokens)
}

fn retain_nested_provenance(word: &mut WordExpr, provenance: &Provenance) {
    let source = match word {
        WordExpr::Template { parts, source, .. } => {
            for part in parts {
                let site = match part {
                    WordPart::Text { source, .. }
                    | WordPart::Variable { source, .. }
                    | WordPart::CommandSubstitution { source, .. }
                    | WordPart::Opaque { source, .. } => source,
                };
                site.provenance.clone_from(provenance);
            }
            source
        }
        WordExpr::Expand { source, word } => {
            retain_nested_provenance(word, provenance);
            source
        }
        WordExpr::Literal { source, .. }
        | WordExpr::BracedLiteral { source, .. }
        | WordExpr::Variable { source, .. }
        | WordExpr::CommandSubstitution { source, .. }
        | WordExpr::Opaque { source, .. } => source,
    };
    source.provenance.clone_from(provenance);
}

/// Recover the structured words for a value word that consists solely of one
/// command substitution.
///
/// A bare `[cmd …]` and a quoted `"[cmd …]"` have different outer syntax but
/// both evaluate the same one command substitution.  Values with literal text,
/// variables, expansion, or a braced word deliberately decline: no caller may
/// infer a command's word form from their flattened value text.
#[must_use]
pub fn whole_word_command_tokens(
    word: &WordExpr,
    config: tcl_lexer::LexerConfig,
) -> Option<CommandTokens> {
    match word {
        WordExpr::CommandSubstitution { spelling, source } => {
            nested_command_words(spelling, source, config).ok()
        }
        WordExpr::Template { parts, .. } => {
            let mut substitution = None;
            for part in parts {
                match part {
                    WordPart::Text { text, .. } if text.is_empty() => {}
                    WordPart::CommandSubstitution { spelling, source }
                        if substitution.is_none() =>
                    {
                        substitution = Some((spelling, source));
                    }
                    _ => return None,
                }
            }
            let (spelling, source) = substitution?;
            nested_command_words(spelling, source, config).ok()
        }
        _ => None,
    }
}

/// A proved nested native expression with its verbatim source anchor.
#[derive(Debug, Clone)]
pub struct LiftedSourceExpression {
    /// Parsed expression selected by the shared invocation owner.
    pub expression: crate::expr_ast::ExprNode,
    /// Extent of the enclosing substitution, for diagnostics.
    pub span: Span,
    /// First byte of the original expression text; transformed text has no anchor.
    pub expression_base: Option<u32>,
    /// Exact concatenated expression bytes and piecewise original read sites.
    pub executed_source: Option<crate::command_binding::ExecutedExpressionSource>,
}

/// Select an expression from proved invocation facts, retaining its exact
/// argument source. Dynamic concatenation cannot be projected into authored
/// expression offsets and yields no positioned expression proof.
#[must_use]
pub(crate) fn source_expression_from_invocation(
    invocation: &crate::registry_invocation::ResolvedStatementInvocation,
    profile: Option<&tcl_dialect::DialectProfile>,
    span: Span,
    parent: Option<crate::command_binding::CommandAllocationSite>,
) -> Option<LiftedSourceExpression> {
    source_expression_from_invocation_parsed(invocation, span, parent, |text| {
        tcl_syntax::expr::parser::parse_expr_for_profile(text, profile)
    })
}

pub(crate) fn source_expression_from_invocation_with_syntax_context(
    invocation: &crate::registry_invocation::ResolvedStatementInvocation,
    parser: tcl_syntax::expr::parser::ExprParseContext,
    span: Span,
    parent: Option<crate::command_binding::CommandAllocationSite>,
) -> Option<LiftedSourceExpression> {
    source_expression_from_invocation_parsed(invocation, span, parent, |text| {
        tcl_syntax::expr::parser::parse_expr_with_syntax_context(text, &parser)
    })
}

pub(crate) fn source_expression_from_invocation_parsed(
    invocation: &crate::registry_invocation::ResolvedStatementInvocation,
    span: Span,
    parent: Option<crate::command_binding::CommandAllocationSite>,
    parse: impl Fn(&str) -> crate::expr_ast::ExprNode,
) -> Option<LiftedSourceExpression> {
    if invocation.facts.operation
        != tcl_registry::SemanticOperationId::StructuredLowering(
            tcl_registry::hooks::LoweringHookId::Expr,
        )
    {
        return None;
    }
    if let Some(parent) = parent {
        let values = (0..invocation.arguments.len())
            .map(|index| invocation.argument_literal(index))
            .collect::<Option<Vec<_>>>()?;
        let executed_source = crate::command_binding::ExecutedExpressionSource::from_arguments(
            parent,
            invocation.effective.words.get(1..)?,
            &values,
            invocation.dialect?,
        )?;
        return Some(LiftedSourceExpression {
            expression: parse(&executed_source.text),
            span,
            expression_base: None,
            executed_source: Some(executed_source),
        });
    }
    if invocation.arguments.len() != 1 {
        return None;
    }
    let word = invocation.effective.words.get(1)?;
    let (WordExpr::BracedLiteral { text, .. } | WordExpr::Literal { text, .. }) = word else {
        return None;
    };
    if invocation.argument_literal(0)?.as_str() != text {
        return None;
    }
    Some(LiftedSourceExpression {
        expression: parse(text),
        span,
        expression_base: None,
        executed_source: None,
    })
}

/// Representation expression reads with complete supplied metadata and grammar.
/// Neither input supplies execution, source positions or a native cache by itself.
pub(crate) fn representation_expression_with_metadata_context(
    tokens: &CommandTokens,
    registry: &tcl_registry::CommandRegistry,
    context: Option<crate::registry_invocation::InvocationMetadataContext<'_>>,
    parser: tcl_syntax::expr::parser::ExprParseContext,
    span: Span,
) -> Option<LiftedSourceExpression> {
    let invocation =
        crate::registry_invocation::normal_representation_invocation_with_metadata_context(
            registry, context, tokens,
        )?;
    invocation.source_expression_with_syntax_context(parser, span, expression_parent(tokens))
}

/// Nested normal representation reads using the same actual parent context.
pub(crate) fn lifted_representation_expressions_with_metadata_context(
    tokens: Option<&CommandTokens>,
    registry: &tcl_registry::CommandRegistry,
    context: Option<crate::registry_invocation::InvocationMetadataContext<'_>>,
    config: tcl_lexer::LexerConfig,
    parser: tcl_syntax::expr::parser::ExprParseContext,
) -> Vec<LiftedSourceExpression> {
    lifted_calls(tokens, config)
        .into_iter()
        .filter_map(|lifted| {
            representation_expression_with_metadata_context(
                lifted.tokens.as_ref()?,
                registry,
                context,
                parser,
                lifted.span,
            )
        })
        .collect()
}

fn expression_parent(
    tokens: &CommandTokens,
) -> Option<crate::command_binding::CommandAllocationSite> {
    Some(crate::command_binding::CommandAllocationSite {
        source: std::sync::Arc::clone(tokens.source_binding.as_ref()?.source_origin()?),
        offset: tokens.argv.first()?.start(),
    })
}

/// Nested native expressions selected through actual retained dispatch proofs.
/// Source anchors belong to their effective argument words, including aliases;
/// unresolved commands and computed expression text provide no guessed proof.
#[must_use]
pub fn lifted_source_expressions(
    tokens: Option<&CommandTokens>,
    registry: &tcl_registry::CommandRegistry,
) -> Vec<LiftedSourceExpression> {
    selected_lifted_expressions(tokens, registry)
}

/// Original nested expressions under the supplied full metadata and grammar.
/// Missing or foreign availability cannot borrow the registry's nominal profile.
#[must_use]
pub(crate) fn lifted_source_expressions_with_metadata_context(
    tokens: Option<&CommandTokens>,
    registry: &tcl_registry::CommandRegistry,
    context: Option<crate::registry_invocation::InvocationMetadataContext<'_>>,
    config: tcl_lexer::LexerConfig,
    parser: tcl_syntax::expr::parser::ExprParseContext,
) -> Vec<LiftedSourceExpression> {
    let Some(context) = context.filter(|context| context.matches_registry(registry)) else {
        return Vec::new();
    };
    lifted_calls(tokens, config)
        .into_iter()
        .filter_map(|lifted| {
            let tokens = lifted.tokens.as_ref()?;
            let invocation =
                crate::registry_invocation::resolved_tokens_invocation_with_metadata_context(
                    registry,
                    Some(context),
                    tokens,
                )?;
            source_expression_from_invocation_with_syntax_context(
                &invocation,
                parser,
                lifted.span,
                expression_parent(tokens),
            )
        })
        .collect()
}

fn selected_lifted_expressions(
    tokens: Option<&CommandTokens>,
    registry: &tcl_registry::CommandRegistry,
) -> Vec<LiftedSourceExpression> {
    let context = registry
        .profile()
        .map(tcl_registry::model::semantic::SemanticContext::for_profile);
    lifted_calls(
        tokens,
        tcl_lexer::LexerConfig::for_profile(registry.profile()),
    )
    .into_iter()
    .filter_map(|lifted| {
        let tokens = lifted.tokens.as_ref()?;
        let invocation =
            crate::registry_invocation::resolved_tokens_invocation(registry, context, tokens)?;
        source_expression_from_invocation(
            &invocation,
            registry.profile(),
            lifted.span,
            expression_parent(tokens),
        )
    })
    .collect()
}

/// Every nested `[expr …]` in `tokens`' words, parsed, with the absolute span
/// of the substitution it came from.
///
/// `expr` concatenates its arguments, and only the single braced argument is a
/// verbatim source slice, so any other spelling is skipped rather than guessed
/// at — the same abstention the lowerer makes when it cannot anchor an
/// expression's text. A lifted call is `expr` when its resolved head carries
/// [`Traits::EXPR_CONCATENATES_ARGS`](tcl_registry::Traits::EXPR_CONCATENATES_ARGS),
/// not by comparing the spelling — the same resolution
/// `optimiser::tail_call` and `optimiser::end_offset` already use.
#[must_use]
pub fn lifted_exprs(
    tokens: Option<&CommandTokens>,
    profile: Option<&tcl_dialect::DialectProfile>,
    registry: &tcl_registry::CommandRegistry,
) -> Vec<(crate::expr_ast::ExprNode, Span)> {
    let config = tcl_lexer::LexerConfig::for_profile(profile);
    lifted_calls(tokens, config)
        .into_iter()
        .filter_map(|lifted| {
            let is_expr = registry.get(&lifted.command).is_some_and(|spec| {
                spec.traits
                    .contains(tcl_registry::Traits::EXPR_CONCATENATES_ARGS)
            });
            if !is_expr {
                return None;
            }
            let [only] = lifted.args.as_slice() else {
                return None;
            };
            let trimmed = only.trim();
            let body = trimmed
                .strip_prefix('{')
                .and_then(|t| t.strip_suffix('}'))
                .unwrap_or(trimmed);
            Some((
                tcl_syntax::expr::parser::parse_expr_for_profile(body, profile),
                lifted.span,
            ))
        })
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::compilation_unit::CompilationUnit;
    use crate::ir::Statement;

    fn original_logical_tokens(
        source: &str,
        input: &crate::analyser::ResolvedAnalysisInput,
    ) -> CommandTokens {
        let image = tcl_lexer::SourceImage::document(source);
        let config = input.lexer_config();
        let registry = input.borrowed_context_registry().commands();
        let bindings =
            crate::command_binding::SourceCommandBindings::analyse_image_in_frame_with_options(
                &image,
                &crate::var_resolve::VariableExecutionFrame::Unknown,
                config,
                registry,
                crate::command_binding::SourceAnalysisOptions::for_logical_source(input).unwrap(),
            )
            .unwrap();
        let segments =
            crate::segmenter::segment_commands_image_with_offset_and_config(&image, 0, config)
                .unwrap();
        let [segment] = segments.as_slice() else {
            panic!("one original command")
        };
        let mut tokens = CommandTokens::from_segmented(&image.source_map(), config, segment);
        bindings.stamp_original_tokens(&mut tokens);
        tokens
    }

    #[test]
    fn original_nested_word_parser_keeps_body_bom_parent_metadata_and_child_geometry() {
        // naming.source.original-configured-script-completeness
        // docs/design/analysis/name-resolution-proofs/source-original-configured-script-completeness.md
        // Conditional original geometry/inventory, never Native child dispatch or result.
        let mut prepared = crate::analyser::Analyser::new();
        // The authored Logical owner retains this independently selected grammar.
        let base_input = prepared.prepare_analysis_input("tcl").unwrap();
        let selected_config = tcl_lexer::LexerConfig::for_file_grammar(
            tcl_dialect::DialectProfile::find("tcl9.1").unwrap().grammar,
        );
        for leading_bom in [tcl_lexer::LeadingBom::Skip, tcl_lexer::LeadingBom::Content] {
            let mut config = selected_config;
            config.leading_bom = leading_bom;
            let input = crate::analyser::ResolvedAnalysisInput::new(
                base_input.analyser_profile(),
                base_input.unit_profile(),
                base_input.context_registry(),
                config,
            );
            let config = input.lexer_config();
            let registry = input.borrowed_context_registry().commands();
            let source = "puts [\u{feff}unknown argument]";
            let tokens = original_logical_tokens(source, &input);
            let metadata =
                crate::registry_invocation::InvocationMetadataContext::for_analysis_input(
                    registry, &input,
                )
                .unwrap();
            let calls = checked_original_lifted_calls_with_metadata_context(
                &tokens, config, registry, metadata,
            )
            .unwrap();
            assert_eq!(calls.len(), 1);
            assert_eq!(calls[0].command, "\u{feff}unknown");
            let child = calls[0].tokens.as_ref().unwrap();
            assert_eq!(child.argv_texts, ["\u{feff}unknown", "argument"]);
            assert_eq!(child.argv[0].start(), 6);
            assert_eq!(
                source.get(child.argv[0].as_range()),
                Some("\u{feff}unknown")
            );
            let site = child
                .source_binding
                .as_ref()
                .unwrap()
                .invocation_site()
                .unwrap();
            assert_eq!(site.offset, 6);
            assert_eq!(site.source.source_image().bytes(), source.as_bytes());
            let mut changed = config;
            changed.strict_quoting = !changed.strict_quoting;
            assert!(
                checked_original_lifted_calls_with_metadata_context(
                    &tokens, changed, registry, metadata
                )
                .is_none()
            );
            let mut missing = tokens.clone();
            missing.nested_bindings.clear();
            assert!(
                checked_original_lifted_calls_with_metadata_context(
                    &missing, config, registry, metadata
                )
                .is_none()
            );
        }
        // The explicit opaque utility keeps selected non-BOM grammar axes;
        // a span alone cannot manufacture an original source point.
        let spelling = "[\u{feff}unknown ${outer{inner}}]";
        let site = SourceSite::opaque(Span::new(0, u32::try_from(spelling.len()).unwrap()));
        let nested = nested_command_words(spelling, &site, base_input.lexer_config()).unwrap();
        assert!(matches!(nested.words()[1], WordExpr::Variable { .. }));
        let config = tcl_lexer::LexerConfig {
            braced_var: tcl_lexer::BracedVarStyle::FirstClose,
            ..base_input.lexer_config()
        };
        let first_close = nested_command_words(spelling, &site, config).unwrap();
        assert!(matches!(first_close.words()[1], WordExpr::Template { .. }));
        assert!(first_close.source_binding.is_none());
        assert!(
            first_close
                .words()
                .iter()
                .all(|word| word.source().provenance == Provenance::Opaque)
        );
    }

    #[test]
    fn original_extracted_surface_keeps_bom_before_comment_and_no_point_receipt() {
        // naming.source.original-configured-script-completeness
        // docs/design/analysis/name-resolution-proofs/source-original-configured-script-completeness.md
        // Lexical extracted-surface utility; no original point/ExprBool/Normal receipt.
        let mut prepared = crate::analyser::Analyser::new();
        let input = prepared.prepare_analysis_input("tcl9.1").unwrap();
        let registry = input.borrowed_context_registry().commands();
        let surface = DocumentCommandSurface::new(registry, None);
        let whole = "expr {\u{feff}# [dict size DATA]}";
        let text = whole
            .strip_prefix("expr {")
            .unwrap()
            .strip_suffix('}')
            .unwrap();
        let calls = lifted_calls_in_text(text, Some(6), input.lexer_config(), &surface);
        assert_eq!(calls.len(), 1);
        assert_eq!(calls[0].command, "dict");
        assert_eq!(calls[0].args, ["size", "DATA"]);
        assert_eq!(
            whole.get(calls[0].span.as_range()),
            Some("[dict size DATA]")
        );
        assert!(calls[0].tokens.as_ref().unwrap().source_binding.is_none());
    }

    #[test]
    fn original_nested_call_inventory_keeps_actual_roles_and_availability() {
        // naming.compiler.original-analysis-metadata-context
        // docs/design/analysis/name-resolution-proofs/original-analysis-metadata-context.md
        // Conditional source geometry only: no handler, body entry or result is proved.
        let current =
            tcl_registry::model::ingress::resolve_environment("tcl8.6").default_context_registry();
        let registry = current.commands();
        let profile = tcl_dialect::DialectProfile::plain_tcl();
        let config = tcl_lexer::LexerConfig::for_file_grammar(profile.grammar);
        let input = crate::analyser::ResolvedAnalysisInput::new(
            profile,
            profile,
            std::sync::Arc::clone(&current),
            config,
        );
        let source = "expr {[dict size [dict create key value]]}";
        let tokens = original_logical_tokens(source, &input);
        let metadata = crate::registry_invocation::InvocationMetadataContext::for_analysis_input(
            registry, &input,
        )
        .unwrap();
        let calls = checked_original_lifted_calls_with_metadata_context(
            &tokens, config, registry, metadata,
        )
        .unwrap();
        assert_eq!(calls.len(), 2);
        assert_eq!(calls[0].args.first().map(String::as_str), Some("create"));
        assert_eq!(calls[1].args.first().map(String::as_str), Some("size"));
        assert!(
            calls
                .iter()
                .all(|call| call.tokens.as_ref().is_some_and(|tokens| {
                    tokens
                        .source_binding
                        .as_ref()
                        .and_then(|binding| binding.invocation_site())
                        .is_some()
                }))
        );
        let older = std::sync::Arc::new(
            tcl_registry::model::ingress::static_context_for("tcl8.4")
                .with_command_store(std::sync::Arc::clone(registry)),
        );
        let older_input =
            crate::analyser::ResolvedAnalysisInput::new(profile, profile, older, config);
        let older_metadata =
            crate::registry_invocation::InvocationMetadataContext::for_analysis_input(
                registry,
                &older_input,
            )
            .unwrap();
        assert!(
            checked_original_lifted_calls_with_metadata_context(
                &tokens,
                config,
                registry,
                older_metadata,
            )
            .is_none()
        );
        assert!(
            checked_original_lifted_calls_with_metadata_context(
                &tokens,
                config,
                registry,
                current.as_ref().into(),
            )
            .is_none()
        );
        let foreign =
            tcl_registry::model::ingress::resolve_environment("tcl9.1").default_context_registry();
        assert!(
            checked_original_lifted_calls_with_metadata_context(
                &tokens,
                config,
                registry,
                foreign.as_ref().into(),
            )
            .is_none()
        );
    }

    #[test]
    fn original_logical_inventory_uses_source_roles_without_native_role_completion() {
        // naming.compiler.original-analysis-metadata-context
        // docs/design/analysis/name-resolution-proofs/original-analysis-metadata-context.md
        // Conditional original geometry; no Native frame/handler or result.
        let mut prepared = crate::analyser::Analyser::new();
        let input = prepared.prepare_analysis_input("tcl").unwrap();
        let registry = input.borrowed_context_registry().commands();
        let config = input.lexer_config();
        let metadata = crate::registry_invocation::InvocationMetadataContext::for_analysis_input(
            registry, &input,
        )
        .unwrap();
        let tokens = original_logical_tokens("uplevel #0 {puts VALUE}", &input);
        let selected = crate::registry_invocation::original_logical_operation_invocation_with_metadata_context(registry, metadata, &tokens).unwrap();
        assert!(
            !selected.facts.arg_roles_complete,
            "Native frame grammar is independently unavailable"
        );
        let realm = tokens
            .source_binding
            .as_ref()
            .unwrap()
            .original_source_realm_for_input(&tokens, &input, registry)
            .unwrap();
        let roles = selected
            .with_metadata_schema(registry, metadata, realm, |schema| {
                schema.authored_logical_source_role_projection()
            })
            .unwrap();
        assert!(
            roles
                .argument_roles()
                .contains(&(1, tcl_registry::ArgRole::Body))
        );
        assert!(
            checked_original_lifted_calls_with_metadata_context(
                &tokens, config, registry, metadata
            )
            .unwrap()
            .is_empty()
        );
        assert!(selected.dialect.unwrap().native_name_protocol().is_none());

        // The genuine written Expr producer retains its original child receipt.
        let tokens = original_logical_tokens("expr {[dict size DATA]}", &input);
        let calls = checked_original_lifted_calls_with_metadata_context(
            &tokens, config, registry, metadata,
        )
        .unwrap();
        assert_eq!(calls.len(), 1);
        assert_eq!(calls[0].command, "dict");
        assert_eq!(calls[0].args, ["size", "DATA"]);
        assert_eq!(calls[0].span.start(), 6);
        assert_eq!(
            calls[0]
                .tokens
                .as_ref()
                .unwrap()
                .source_binding
                .as_ref()
                .unwrap()
                .invocation_site()
                .unwrap()
                .source
                .source_image()
                .bytes(),
            b"expr {[dict size DATA]}"
        );
    }

    #[test]
    fn original_logical_inventory_keeps_alias_ordinals_and_uncertain_geometry_refusals() {
        // naming.compiler.original-analysis-metadata-context
        // docs/design/analysis/name-resolution-proofs/original-analysis-metadata-context.md
        let mut prepared = crate::analyser::Analyser::new();
        let input = prepared.prepare_analysis_input("tcl").unwrap();
        let registry = input.borrowed_context_registry().commands();
        let config = input.lexer_config();
        let metadata = crate::registry_invocation::InvocationMetadataContext::for_analysis_input(
            registry, &input,
        )
        .unwrap();
        for (source, expected) in [
            (
                "interp alias {} calculate {} expr; calculate {[dict size DATA]}",
                true,
            ),
            (
                "interp alias {} calculate {} expr {[dict size DATA]}; calculate",
                false,
            ),
            ("proc expr args {}; expr {[dict size DATA]}", false),
            ("switch $option $cmd {foo {[dict size DATA]}}", false),
            ("regexp $option PATTERN TEXT", false),
            ("expr {*}$arguments", false),
        ] {
            let mut lowerer = crate::lowering::Lowerer::with_config(registry, config)
                .with_resolved_analysis_input(input.clone());
            let module = lowerer.lower(source);
            let script = &module.top_level;
            let tokens = script
                .retained_source_tokens_for_statement(script.statements.last().unwrap())
                .unwrap();
            let calls = checked_original_lifted_calls_with_metadata_context(
                tokens, config, registry, metadata,
            );
            assert_eq!(calls.is_some(), expected, "{source}");
            if expected {
                let calls = calls.unwrap();
                assert_eq!(calls.len(), 1);
                assert_eq!(calls[0].command, "dict");
                assert_eq!(
                    calls[0]
                        .tokens
                        .as_ref()
                        .unwrap()
                        .source_binding
                        .as_ref()
                        .unwrap()
                        .invocation_site()
                        .unwrap()
                        .source
                        .source_image()
                        .bytes(),
                    source.as_bytes()
                );
                let mut missing = tokens.clone();
                missing.nested_bindings.clear();
                assert!(
                    checked_original_lifted_calls_with_metadata_context(
                        &missing, config, registry, metadata
                    )
                    .is_none()
                );
            }
        }
    }

    #[test]
    fn original_nested_call_inventory_withdraws_changed_geometry_and_missing_sidecars() {
        // naming.compiler.original-analysis-metadata-context
        // docs/design/analysis/name-resolution-proofs/original-analysis-metadata-context.md
        let current =
            tcl_registry::model::ingress::resolve_environment("tcl8.6").default_context_registry();
        let registry = current.commands();
        let profile = tcl_dialect::DialectProfile::plain_tcl();
        let config = tcl_lexer::LexerConfig::for_file_grammar(profile.grammar);
        let input = crate::analyser::ResolvedAnalysisInput::new(
            profile,
            profile,
            std::sync::Arc::clone(&current),
            config,
        );
        let tokens = original_logical_tokens("expr {[dict size [dict create key value]]}", &input);
        let metadata = crate::registry_invocation::InvocationMetadataContext::for_analysis_input(
            registry, &input,
        )
        .unwrap();
        assert!(
            checked_original_lifted_calls_with_metadata_context(
                &tokens, config, registry, metadata,
            )
            .is_some()
        );
        let mut changed_config = config;
        changed_config.expand_syntax = !changed_config.expand_syntax;
        assert!(
            checked_original_lifted_calls_with_metadata_context(
                &tokens,
                changed_config,
                registry,
                metadata,
            )
            .is_none()
        );
        let mut missing = tokens.clone();
        missing.nested_bindings.clear();
        assert!(
            checked_original_lifted_calls_with_metadata_context(
                &missing, config, registry, metadata,
            )
            .is_none()
        );
        let mut changed = tokens;
        let WordExpr::BracedLiteral { text, .. } = &mut changed.word_exprs[1] else {
            panic!("original braced expression")
        };
        *text = "[dict size OTHER]".into();
        assert!(
            checked_original_lifted_calls_with_metadata_context(
                &changed, config, registry, metadata,
            )
            .is_none()
        );
    }

    fn entered_operand_tokens(
        source: &str,
        command_index: usize,
        dialect: tcl_registry::InvocationDialect,
    ) -> (
        CommandTokens,
        tcl_registry::CommandRegistry,
        tcl_lexer::LexerConfig,
    ) {
        let registry = registry();
        let config = tcl_lexer::LexerConfig::from_grammar(dialect.lexer_grammar);
        let bindings = crate::command_binding::SourceCommandBindings::analyse_with_options(
            source,
            config,
            &registry,
            crate::command_binding::SourceAnalysisOptions {
                invocation_dialect: Some(dialect),
                native_compilation: crate::environment_ingress::authoring_native_compilation(),
                ..crate::command_binding::SourceAnalysisOptions::default()
            },
        );
        let commands = crate::segmenter::segment_commands_with_offset_and_config(source, 0, config);
        let mut tokens = CommandTokens::from_segmented(
            &tcl_lexer::SourceMap::new(source),
            config,
            &commands[command_index],
        );
        bindings.stamp_original_tokens(&mut tokens);
        (tokens, registry, config)
    }

    #[test]
    fn entered_expression_operand_survives_absent_parent_dispatch() {
        let source = "return [expr {1 / 0}]";
        let actual = tcl_registry::InvocationDialect::of_point(
            tcl_dialect::model::DialectPoint::for_tcl_version(tcl_dialect::TclVersion::V8_6),
        );
        let (tokens, registry, config) = entered_operand_tokens(source, 0, actual);
        assert_ne!(
            tokens
                .source_binding
                .as_ref()
                .unwrap()
                .runtime_reachability(),
            crate::command_binding::SourceRuntimeReachability::Reached
        );
        let evaluations = entered_expression_evaluations(Some(&tokens), config, &registry);
        assert_eq!(evaluations.len(), 1);
        let evaluation = &evaluations[0];
        assert_eq!(
            &source[evaluation.expression_base as usize..evaluation.expression_base as usize + 5],
            "1 / 0"
        );
        assert_eq!(&source[evaluation.span.as_range()], "expr {1 / 0}");
        assert_eq!(evaluation.numbers, actual.numbers);
    }

    #[test]
    fn entered_expression_operands_decline_unreached_and_replaced_evaluators() {
        let actual = tcl_registry::InvocationDialect::of_point(
            tcl_dialect::model::DialectPoint::for_tcl_version(tcl_dialect::TclVersion::V8_6),
        );
        for (source, command) in [
            ("error STOP; return [expr {1 / 0}]", 1),
            ("return [error STOP] [expr {1 / 0}]", 0),
            (
                "rename expr saved; proc expr args {return CUSTOM}; return [expr {1 / 0}]",
                2,
            ),
            ("return {[expr {1 / 0}]}", 0),
        ] {
            let (tokens, registry, config) = entered_operand_tokens(source, command, actual);
            assert!(
                entered_expression_evaluations(Some(&tokens), config, &registry).is_empty(),
                "{source}"
            );
        }
    }

    #[test]
    fn entered_expression_operands_retain_actual_grammar_and_original_bytes() {
        let actual = tcl_registry::InvocationDialect::of_point(
            tcl_dialect::model::DialectPoint::for_tcl_version(tcl_dialect::TclVersion::V8_4),
        );
        let (tokens, registry, config) =
            entered_operand_tokens("return [expr {1 / 0o0}]", 0, actual);
        let evaluations = entered_expression_evaluations(
            Some(&tokens),
            tcl_lexer::LexerConfig::for_dialect("tcl9.1"),
            &registry,
        );
        assert_eq!(evaluations.len(), 1);
        assert_eq!(evaluations[0].numbers, tcl_dialect::NumberSyntax::Tcl84);
        assert!(matches!(
            evaluations[0].expression,
            crate::expr_ast::ExprNode::Raw { .. }
        ));

        let (tokens, registry, _) = entered_operand_tokens("return [expr {1 / 0}]", 0, actual);
        let mut child = lifted_calls(Some(&tokens), config)
            .pop()
            .unwrap()
            .tokens
            .unwrap();
        let WordExpr::BracedLiteral { text, .. } = &mut child.word_exprs[1] else {
            panic!("original expression word");
        };
        *text = "5 / 0".into();
        assert!(entered_expression_evaluation(&child, &registry).is_none());
    }

    #[test]
    fn actual_entry_grammar_precedes_assistance_during_lowering_and_nested_lifting() {
        let registry = registry();
        let assistance = tcl_lexer::LexerConfig::for_dialect("tcl8.6");
        let jim = tcl_registry::InvocationDialect::of_point(
            tcl_dialect::model::DialectPoint::canonical(tcl_dialect::model::Release::JIM_0_84),
        );
        let mut lowerer = crate::lowering::Lowerer::with_config(&registry, assistance);
        lowerer.set_source_analysis_options(crate::command_binding::SourceAnalysisOptions {
            invocation_dialect: Some(jim),
            ..crate::command_binding::SourceAnalysisOptions::default()
        });
        let module = lowerer.lower("puts $café [puts $café]");
        assert_eq!(
            module.native_lexer_config(),
            assistance.with_grammar(jim.lexer_grammar)
        );
        let tokens = module.top_level.statements[0]
            .tokens()
            .expect("original words");
        assert_eq!(
            tokens.words()[1]
                .sole_variable_substitution()
                .map(|(text, _)| text),
            Some("$café")
        );
        let lifted = super::lifted_calls(Some(tokens), assistance);
        assert_eq!(lifted.len(), 1);
        assert_eq!(
            lifted[0].arg_words[0]
                .sole_variable_substitution()
                .map(|(text, _)| text),
            Some("$café")
        );
        let nested = lifted[0].tokens.as_ref().expect("nested source carrier");
        assert_eq!(
            nested.native_lexer_config(assistance),
            assistance.with_grammar(jim.lexer_grammar)
        );
    }

    #[test]
    fn unknown_execution_dialect_keeps_the_supplied_lexical_policy() {
        let registry = registry();
        let config = tcl_lexer::LexerConfig::for_dialect("jim");
        let mut lowerer = crate::lowering::Lowerer::with_config(&registry, config);
        lowerer
            .set_source_analysis_options(crate::command_binding::SourceAnalysisOptions::default());
        let module = lowerer.lower("puts $café");
        assert_eq!(module.native_lexer_config(), config);
        let tokens = module.top_level.statements[0]
            .tokens()
            .expect("original words");
        assert_eq!(tokens.native_lexer_config(config), config);
        assert_eq!(
            tokens.words()[1]
                .sole_variable_substitution()
                .map(|(text, _)| text),
            Some("$café")
        );
    }

    fn registry() -> tcl_registry::CommandRegistry {
        tcl_registry::CommandRegistry::build_default()
    }

    /// Every substitution lifted from the single `Call` in a one-statement proc.
    fn lift_calls(body: &str) -> Vec<LiftedCall> {
        let reg = registry();
        let src = format!("proc f {{x}} {{\n {body}\n}}");
        let cu = CompilationUnit::build_for(&src, &reg, false);
        let fu = cu.function("::f").expect("proc lowered");
        let config = tcl_lexer::LexerConfig::for_profile(reg.profile());
        let mut out = Vec::new();
        for block in fu.cfg.blocks.values() {
            for stmt in &block.statements {
                if let Statement::Call { tokens, .. } = stmt {
                    out.extend(lifted_calls(tokens.as_ref(), config));
                }
            }
        }
        out
    }

    /// Lift the substitutions of the single `Call` in a one-statement proc.
    fn lift(body: &str) -> Vec<(String, Vec<String>)> {
        lift_calls(body)
            .into_iter()
            .map(|c| (c.command, c.args))
            .collect()
    }

    /// The whole point of reading `word_exprs` rather than the argument text:
    /// Tcl substitutes `[…]` in a bare or quoted word and **not** in a braced
    /// one, but `Statement::Call::args` renders all three identically as
    /// `[lindex $x 0]`. Lifting from that text would report a command Tcl
    /// never runs.
    #[test]
    fn braced_word_is_not_a_substitution() {
        assert_eq!(
            lift("puts [lindex $x 0]"),
            vec![("lindex".to_owned(), vec!["$x".to_owned(), "0".to_owned()])],
            "a bare `[…]` word runs"
        );
        assert_eq!(
            lift("puts \"[lindex $x 0]\""),
            vec![("lindex".to_owned(), vec!["$x".to_owned(), "0".to_owned()])],
            "a quoted `[…]` runs too"
        );
        assert_eq!(
            lift("puts {[lindex $x 0]}").len(),
            0,
            "a braced `[…]` is literal text, never run"
        );
    }

    /// Lift with a registry, so brace-quoted expression words are descended.
    fn lift_with_registry(body: &str) -> Vec<(String, Vec<String>)> {
        let reg = registry().project_for_profile(
            tcl_registry::model::ingress::resolve_environment("tcl9.0").unit_profile(),
        );
        lift_with_selected_registry(body, &reg)
    }

    fn lift_with_selected_registry(
        body: &str,
        reg: &tcl_registry::CommandRegistry,
    ) -> Vec<(String, Vec<String>)> {
        let surface = tcl_registry::model::DocumentCommandSurface::new(reg, None);
        let src = format!("proc f {{x}} {{\n {body}\n}}");
        let cu = CompilationUnit::build_for(&src, reg, false);
        let fu = cu.function("::f").expect("proc lowered");
        let config = tcl_lexer::LexerConfig::for_profile(reg.profile());
        let mut out = Vec::new();
        for block in fu.cfg.blocks.values() {
            for stmt in &block.statements {
                let tokens = match stmt {
                    Statement::Call { tokens, .. }
                    | Statement::Barrier { tokens, .. }
                    | Statement::AssignValue { tokens, .. } => tokens.as_ref(),
                    _ => None,
                };
                out.extend(
                    lifted_calls_with_surface(tokens, config, &surface)
                        .into_iter()
                        .map(|c| (c.command, c.args)),
                );
            }
        }
        out
    }

    /// A brace-quoted word is inert to the command parser but not to `expr`,
    /// which re-parses it as an expression and runs the `[…]` in it. Which
    /// words those are is the registry's answer, so only the registry-aware
    /// lift takes them — `lifted_calls` has no way to tell `puts {[f]}` from
    /// `expr {[f]}`.
    #[test]
    fn a_braced_expression_word_runs_its_substitutions() {
        assert_eq!(
            lift_with_registry("puts [expr {$x + [incr x]}]"),
            vec![
                ("incr".to_owned(), vec!["x".to_owned()]),
                ("expr".to_owned(), vec!["{$x + [incr x]}".to_owned()]),
            ],
            "the `incr` runs, and innermost-first puts it before its `expr`"
        );
        assert!(
            lift("puts [expr {$x + [incr x]}]")
                .iter()
                .all(|(command, _)| command != "incr"),
            "without a registry the braced word stays literal"
        );
    }

    /// `expr` concatenates its words into one expression before parsing it, so
    /// a braced word anywhere in the list contributes to it. tclsh 8.6.18 and
    /// 9.0.4 both print `3` then `2` for
    /// `set x 1; puts [expr 1 + {[incr x]}]; puts $x`.
    #[test]
    fn a_concatenated_expression_word_runs_its_substitutions() {
        assert_eq!(
            lift_with_registry("puts [expr 1 + {[incr x]}]"),
            vec![
                ("incr".to_owned(), vec!["x".to_owned()]),
                (
                    "expr".to_owned(),
                    vec!["1".to_owned(), "+".to_owned(), "{[incr x]}".to_owned()],
                ),
            ]
        );
    }

    #[test]
    fn jim_does_not_evaluate_a_rejected_variadic_expression_word() {
        let reg = registry().project_for_profile(
            tcl_registry::model::ingress::resolve_environment("jim").unit_profile(),
        );
        assert_eq!(
            lift_with_selected_registry("puts [expr 1 + {[incr x]}]", &reg),
            vec![(
                "expr".to_owned(),
                vec!["1".to_owned(), "+".to_owned(), "{[incr x]}".to_owned()],
            )],
        );
    }

    /// The descent is the registry's rule and not the brace: a braced word a
    /// command does *not* evaluate as an expression is still literal text.
    #[test]
    fn a_braced_word_that_is_not_an_expression_stays_literal() {
        assert_eq!(
            lift_with_registry("puts {[lindex $x 0]}").len(),
            0,
            "`puts` reads its word as a value, so the `[…]` never runs"
        );
        assert!(
            lift_with_registry("puts [list {[lindex $x 0]}]")
                .iter()
                .all(|(command, _)| command != "lindex"),
            "nor does `list`'s"
        );
    }

    /// A `"…"` operand substitutes inside an expression; a `{…}` one does
    /// not. Reading every [`crate::expr_ast::ExprNode::String`] as inert
    /// missed the call in `set r [expr {"[id 9]"}]`: tclsh 8.6.18 prints
    /// `7` then `9` and `--profile standard` folded `id`'s body to
    /// `return 7`, printing `7` twice.
    #[test]
    fn a_quoted_expression_operand_runs_its_substitutions() {
        let reg = registry();
        let surface = tcl_registry::model::DocumentCommandSurface::new(&reg, None);
        let config = tcl_lexer::LexerConfig::for_profile(reg.profile());
        for (why, source, expected) in [
            (
                "a quoted operand substitutes",
                r#""[id 9]""#,
                vec!["id".to_owned()],
            ),
            ("a braced one does not", "{[id 9]}", Vec::new()),
            (
                "and so does one welded into a larger expression",
                r#""[id 9]" eq "9""#,
                vec!["id".to_owned()],
            ),
        ] {
            let expr = tcl_syntax::expr::parser::parse_expr_for_profile(source, reg.profile());
            assert_eq!(
                lifted_calls_in_expr(&expr, None, config, &surface)
                    .iter()
                    .map(|c| c.command.clone())
                    .collect::<Vec<_>>(),
                expected,
                "{why}"
            );
        }
    }

    /// A substitution recovered from inside a brace-quoted word is anchored
    /// back to the real source byte it came from.
    ///
    /// Two offsets have to be right at once and neither shows up as wrong
    /// behaviour, only as a wrong position: the word's site covers the `{…}`
    /// that quoted it, so its content starts one byte in, and a lexer `Cmd`
    /// token's span stops at the last byte *inside* the brackets, so the
    /// closing `]` is taken back before parsing. The second was load-bearing
    /// — without it the spelling came back as `[id 9` and every such
    /// substitution was silently declined — and the first is invisible until
    /// a consumer reports a position.
    #[test]
    fn a_substitution_inside_a_braced_word_keeps_its_source_offset() {
        let reg = registry();
        let surface = tcl_registry::model::DocumentCommandSurface::new(&reg, None);
        let config = tcl_lexer::LexerConfig::for_profile(reg.profile());
        // `puts [expr {…}]` rather than a bare `expr {…}`: the latter fuses
        // into an `ExprEval` that keeps no words at all, which is the
        // `lifted_calls_in_expr` path rather than this one.
        let src = "proc f {x} {\n puts [expr {[id 9] > 5}]\n}";
        let want = src.find("[id 9]").expect("the call is in the source");
        let cu = CompilationUnit::build_for(src, &reg, false);
        let fu = cu.function("::f").expect("proc lowered");
        let lifted: Vec<LiftedCall> = fu
            .cfg
            .blocks
            .values()
            .flat_map(|block| &block.statements)
            .filter_map(|stmt| match stmt {
                Statement::Call { tokens, .. } => tokens.as_ref(),
                _ => None,
            })
            .flat_map(|tokens| lifted_calls_with_surface(Some(tokens), config, &surface))
            .collect();

        // Both are real: `[expr …]` is a substitution the `puts` word runs,
        // and `id` is one the expression inside it runs.
        let mut names: Vec<String> = lifted.iter().map(|c| c.command.clone()).collect();
        names.sort();
        assert_eq!(names, vec!["expr".to_owned(), "id".to_owned()]);
        let span = lifted
            .iter()
            .find(|c| c.command == "id")
            .expect("the nested call is lifted")
            .span;
        assert_eq!(
            (span.start() as usize, span.end() as usize),
            (want, want + "[id 9]".len()),
            "the span covers `[id 9]` exactly, brackets included: src[{}..{}] is {:?}",
            span.start(),
            span.end(),
            src.get(span.start() as usize..span.end() as usize)
        );
    }

    /// An expression surface with no words of its own — what a fused
    /// `AssignExpr` or a `Branch` terminator keeps — still runs its `[…]`.
    #[test]
    fn an_expression_surface_runs_its_substitutions() {
        let reg = registry();
        let config = tcl_lexer::LexerConfig::for_profile(reg.profile());
        let expr = tcl_syntax::expr::parser::parse_expr_for_profile("[id 9] > 5", reg.profile());
        let surface = tcl_registry::model::DocumentCommandSurface::new(&reg, None);
        let lifted = lifted_calls_in_expr(&expr, Some(100), config, &surface);
        assert_eq!(
            lifted
                .iter()
                .map(|c| (c.command.clone(), c.args.clone()))
                .collect::<Vec<_>>(),
            vec![("id".to_owned(), vec!["9".to_owned()])]
        );
        assert_eq!(
            lifted[0].span,
            tcl_lexer::Span::new(100, 106),
            "the base anchors the substitution back to its source offset"
        );
        assert_eq!(
            lifted_calls_in_text("[id 9] > 5", Some(100), config, &surface)
                .iter()
                .map(|c| c.command.clone())
                .collect::<Vec<_>>(),
            vec!["id".to_owned()],
            "the same holds for a surface read as raw text"
        );
    }

    /// Substitutions come back innermost-first — Tcl's evaluation order, so a
    /// consumer replaying them moves its state exactly as the runtime does.
    #[test]
    fn nested_substitutions_are_innermost_first() {
        assert_eq!(
            lift("puts [list [lindex $x 0]]"),
            vec![
                ("lindex".to_owned(), vec!["$x".to_owned(), "0".to_owned()]),
                ("list".to_owned(), vec!["[lindex $x 0]".to_owned()]),
            ]
        );
    }

    /// A substitution embedded in a larger word is still evaluated.
    #[test]
    fn substitution_inside_a_compound_word_is_lifted() {
        assert_eq!(
            lift("puts a[lindex $x 0]b"),
            vec![("lindex".to_owned(), vec!["$x".to_owned(), "0".to_owned()])]
        );
    }

    /// A word with nothing to run costs nothing.
    #[test]
    fn words_without_substitutions_lift_nothing() {
        assert_eq!(
            lift("puts $x"),
            [] as [(std::string::String, std::vec::Vec<std::string::String>); 0]
        );
        assert_eq!(
            lift("puts plain"),
            [] as [(std::string::String, std::vec::Vec<std::string::String>); 0]
        );
    }

    /// A substitution nested in a *quoted* word of another substitution still
    /// runs — Tcl substitutes inside `"…"`. Recovering the nested command's
    /// own words is what sees it; the argument text `"[lindex $x 0]"` starts
    /// with a quote, so no `[`-prefix test over that text ever could.
    ///
    /// Asserted on the commands and the inner call's own arguments; the outer
    /// `list`'s argument *text* keeps the raw spelling.
    #[test]
    fn substitution_inside_a_quoted_nested_word_is_lifted() {
        let calls = lift_calls("puts [list \"[lindex $x 0]\"]");
        assert_eq!(
            calls.iter().map(|c| c.command.as_str()).collect::<Vec<_>>(),
            vec!["lindex", "list"]
        );
        assert_eq!(calls[0].args, vec!["$x".to_owned(), "0".to_owned()]);
    }

    /// The same for a substitution welded into a larger nested word.
    #[test]
    fn substitution_welded_into_a_nested_word_is_lifted() {
        assert_eq!(
            lift("puts [list a[lindex $x 0]b]"),
            vec![
                ("lindex".to_owned(), vec!["$x".to_owned(), "0".to_owned()]),
                ("list".to_owned(), vec!["a[lindex $x 0]b".to_owned()]),
            ]
        );
    }

    /// …and the brace rule holds one level down too: a braced argument of a
    /// nested command is literal text, not a command to run.
    #[test]
    fn braced_word_of_a_nested_substitution_is_not_run() {
        assert_eq!(
            lift("puts [list {[lindex $x 0]}]"),
            vec![("list".to_owned(), vec!["{[lindex $x 0]}".to_owned()])]
        );
    }

    /// A substitution in the *command* position runs before the command it
    /// spells is looked up.
    #[test]
    fn substitution_in_the_command_word_is_lifted() {
        assert_eq!(
            lift("puts [[lindex $x 0] 1]"),
            vec![
                ("lindex".to_owned(), vec!["$x".to_owned(), "0".to_owned()]),
                ("[lindex $x 0]".to_owned(), vec!["1".to_owned()]),
            ]
        );
    }

    /// `arg_words` is the segmenter's structure for the same words `args`
    /// spells, index-aligned, so a consumer can tell a braced literal from a
    /// word that substitutes without re-deciding it from the text.
    #[test]
    fn arg_words_align_with_args() {
        let calls = lift_calls("puts [list {a b} $x [set y] plain]");
        // `[set y]` is evaluated first, so the outer `list` is lifted last.
        let [_, lifted] = calls.as_slice() else {
            panic!("expected the inner `set` then the outer `list`, got {calls:?}");
        };
        assert_eq!(lifted.command, "list");
        assert_eq!(lifted.arg_words.len(), lifted.args.len());
        assert!(matches!(
            lifted.arg_words.as_slice(),
            [
                WordExpr::BracedLiteral { .. },
                WordExpr::Variable { .. },
                WordExpr::CommandSubstitution { .. },
                WordExpr::Literal { .. },
            ]
        ));
    }

    /// The value emitter needs the exact inner word forms for a whole nested
    /// substitution, while a braced outer word must still decline.
    #[test]
    fn unpositioned_nested_words_preserve_their_source_provenance() {
        for engine in ["tcl8.4", "tcl8.5", "tcl8.6", "tcl9.0", "tcl9.1", "jimtcl"] {
            let profile = tcl_registry::model::ingress::resolve_environment(engine).unit_profile();
            let config = tcl_lexer::LexerConfig::for_profile(Some(profile));
            let spelling = r#"[f "$x[child]" [child]]"#;
            let site = SourceSite::opaque(Span::new(400, 424));
            let tokens = nested_command_words(spelling, &site, config).unwrap();
            assert!(
                tokens
                    .words()
                    .iter()
                    .all(|word| word.source().provenance == Provenance::Opaque),
                "{engine}"
            );
            let WordExpr::Template { parts, .. } = &tokens.words()[1] else {
                panic!("{engine}: quoted template")
            };
            for part in parts {
                let source = match part {
                    WordPart::Text { source, .. }
                    | WordPart::Variable { source, .. }
                    | WordPart::CommandSubstitution { source, .. }
                    | WordPart::Opaque { source, .. } => source,
                };
                assert_eq!(source.provenance, Provenance::Opaque, "{engine}");
            }
            let child = whole_word_command_tokens(&tokens.words()[2], config).unwrap();
            assert_eq!(
                child.words()[0].source().provenance,
                Provenance::Opaque,
                "{engine}"
            );
            let original =
                nested_command_words(spelling, &SourceSite::source(site.span), config).unwrap();
            assert!(
                original
                    .words()
                    .iter()
                    .all(|word| word.source().provenance == Provenance::Source),
                "{engine}"
            );
            assert_eq!(original.words()[0].source().span.start(), 401, "{engine}");
        }
    }

    #[test]
    fn whole_word_command_tokens_preserve_nested_word_forms() {
        let reg = registry();
        let config = tcl_lexer::LexerConfig::for_profile(reg.profile());
        for (body, expected) in [
            ("puts [info exists {p\\x75b}]", "p\\x75b"),
            ("puts \"[info exists pub]\"", "pub"),
        ] {
            let src = format!("proc f {{}} {{{body}}}");
            let cu = CompilationUnit::build_for(&src, &reg, false);
            let fu = cu.function("::f").expect("proc lowered");
            let word = fu
                .cfg
                .blocks
                .values()
                .flat_map(|block| &block.statements)
                .find_map(|stmt| match stmt {
                    Statement::Call {
                        tokens: Some(tokens),
                        ..
                    } => tokens.words().get(1),
                    _ => None,
                })
                .expect("puts argument word");
            let nested = whole_word_command_tokens(word, config).expect("nested command words");
            assert_eq!(
                nested.argv_texts,
                vec!["info".to_owned(), "exists".to_owned(), expected.to_owned()]
            );
        }

        let src = "proc f {} {puts {[info exists pub]}}";
        let cu = CompilationUnit::build_for(src, &reg, false);
        let fu = cu.function("::f").expect("proc lowered");
        let word = fu
            .cfg
            .blocks
            .values()
            .flat_map(|block| &block.statements)
            .find_map(|stmt| match stmt {
                Statement::Call {
                    tokens: Some(tokens),
                    ..
                } => tokens.words().get(1),
                _ => None,
            })
            .expect("puts argument word");
        assert!(whole_word_command_tokens(word, config).is_none());
    }
}
