// tcl-lsp — a language server and toolchain for Tcl
// Copyright (C) 2026 James Deucker (bitwisecook)
// SPDX-License-Identifier: AGPL-3.0-or-later

//! Namespace syntax of a genuine original immediate body, without body entry.

use super::{ExecutedScriptSource, SourceInvocationBinding, SourceNamespaceKey};
use crate::ir::CommandTokens;
use crate::registry_invocation::{
    EffectiveInvocationWord, InvocationMetadataContext, InvocationWordOrigin,
    effective_invocation_word, original_structured_invocation_with_metadata_context,
};
use tcl_lexer::{LexerConfig, Span};
use tcl_registry::{ArgRole, BodyInterpreter, BodyKind, CommandRegistry, ScriptTiming};

impl SourceInvocationBinding {
    /// Retain a static whole original operand at its genuine parent allocation
    /// and written ordinal. This lexical projection creates no namespace,
    /// reached body, native parser entry or successful argument evaluation.
    pub(crate) fn original_body_source_for_word(
        &self,
        parent: &CommandTokens,
        span: Span,
        config: LexerConfig,
    ) -> Option<ExecutedScriptSource> {
        if self.original_lexer_config_for_tokens(parent)? != config {
            return None;
        }
        let site = self.invocation_site()?;
        let original = site
            .source
            .original_lexical_command(parent.words(), site.offset, config)?;
        let mut selected = None;
        for (index, (word, native)) in parent
            .words()
            .iter()
            .zip(original.native_words())
            .enumerate()
            .skip(1)
        {
            if native.span() != span || word.source().span != span {
                continue;
            }
            let EffectiveInvocationWord::Literal(value) = effective_invocation_word(
                word,
                config.escapes,
                tcl_syntax::word_rules::WordValueRules::from_config(&config),
            ) else {
                return None;
            };
            let source =
                ExecutedScriptSource::from_word(site.clone(), index - 1, word, &value, config);
            if selected
                .as_ref()
                .is_some_and(|previous| previous != &source)
            {
                return None;
            }
            selected = Some(source);
        }
        selected
    }

    /// Inherit namespace syntax only for an independently selected immediate
    /// Plain body in the Current interpreter. Exact source, full supplied
    /// metadata and the retained namespace incarnation remain prerequisites.
    /// This issues no reached lookup, entered frame, Normal completion,
    /// Native body preparation or inline compiler admission.
    pub(crate) fn original_body_namespace_context(
        &self,
        registry: &CommandRegistry,
        request: InvocationMetadataContext<'_>,
        parent: &CommandTokens,
        source: &ExecutedScriptSource,
    ) -> Option<SourceNamespaceKey> {
        let input = request.source_analysis_input()?;
        let advice = self.declaration_operand_layout_advice(parent)?;
        let metadata = advice
            .original_declaration_metadata_context(registry, parent)
            .ok()??;
        if metadata.source_analysis_input() != Some(input) || !request.matches_registry(registry) {
            return None;
        }
        let namespace = advice.namespace();
        if let Some(native) = namespace.native_context() {
            if !advice.closed_lookup() || advice.has_opaque_handler_alternatives() {
                return None;
            }
            let entry = advice.snapshot.state.baseline.native_entry.as_deref()?;
            if entry.retained_namespace_context(native.token).ok().as_ref() != Some(native) {
                return None;
            }
        } else if !input.has_logical_source_name_context() || !advice.closed_logical_source_lookup()
        {
            return None;
        }
        let invocation =
            original_structured_invocation_with_metadata_context(registry, metadata, parent)?;
        let config = self.original_lexer_config_for_tokens(parent)?;
        let roles = invocation.written_argument_roles();
        let mut selected_body = false;
        for (index, origin) in invocation.effective.origins.iter().enumerate().skip(1) {
            let InvocationWordOrigin::Written(written) = origin else {
                continue;
            };
            let argument = index - 1;
            let written_argument = written.checked_sub(1)?;
            if !roles.contains(&(written_argument, ArgRole::Body)) {
                continue;
            }
            let word = parent.words().get(*written)?;
            let expected =
                self.original_body_source_for_word(parent, word.source().span, config)?;
            if &expected != source {
                continue;
            }
            let immediate =
                invocation.with_metadata_schema(registry, metadata, advice.realm(), |schema| {
                    Some(
                        schema.semantics.body_kind == BodyKind::Plain
                            && schema.semantics.body_interpreter == BodyInterpreter::Current
                            && schema.authored_source_script_timing_at(argument)
                                == Some(ScriptTiming::SameInvocation),
                    )
                })?;
            if !immediate {
                return None;
            }
            selected_body = true;
        }
        selected_body.then(|| namespace.clone())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::analyser::ResolvedAnalysisInput;
    use crate::command_binding::{SourceAnalysisEntry, SourceCommandBindings};
    use crate::registry_invocation::OwnedInvocationMetadataContext;
    use std::sync::Arc;

    struct OriginalBodyFixture {
        context: Arc<tcl_registry::model::ContextRegistry>,
        input: ResolvedAnalysisInput,
        entry: SourceAnalysisEntry,
        bindings: SourceCommandBindings,
        tokens: Vec<CommandTokens>,
        _owner: tcl_vm::Vm,
    }

    fn original_fixture(source: &str, environment: &str) -> OriginalBodyFixture {
        let environment = tcl_registry::model::ingress::resolve_known_environment(environment)
            .expect("actual selected native profile");
        let context = environment.default_context_registry();
        let profile = environment.unit_profile();
        let config = LexerConfig::for_profile(Some(profile));
        let input = ResolvedAnalysisInput::new(profile, profile, Arc::clone(&context), config);
        let (owner, native) = crate::environment_ingress::captured_native_entry_with_owner(profile);
        assert_eq!(native.execution_point, environment.point());
        let entry = SourceAnalysisEntry {
            metadata_context: OwnedInvocationMetadataContext::for_source_input(Some(&input)),
            invocation_dialect: Some(tcl_registry::InvocationDialect::of_profile(profile)),
            native_compilation: crate::environment_ingress::authoring_native_compilation(),
            native_entry: Some(Arc::new(native)),
            ..SourceAnalysisEntry::default()
        };
        let bindings = SourceCommandBindings::analyse_with_options(
            source,
            config,
            context.commands(),
            entry.options(),
        );
        let image = tcl_lexer::SourceImage::document(source);
        let segments =
            crate::segmenter::segment_commands_image_with_offset_and_config(&image, 0, config)
                .expect("original whole-source segmentation");
        let tokens = segments
            .iter()
            .map(|segment| {
                let mut tokens =
                    CommandTokens::from_segmented(&image.source_map(), config, segment);
                bindings.stamp_original_tokens(&mut tokens);
                tokens
            })
            .collect();
        OriginalBodyFixture {
            _owner: owner,
            context,
            input,
            entry,
            bindings,
            tokens,
        }
    }

    fn body_at(
        tokens: &CommandTokens,
        written: usize,
        config: LexerConfig,
    ) -> ExecutedScriptSource {
        tokens
            .source_binding
            .as_ref()
            .unwrap()
            .original_body_source_for_word(tokens, tokens.words()[written].source().span, config)
            .expect("whole original written body")
    }

    #[test]
    fn original_immediate_body_namespace_keeps_actual_native_conditional_and_error_prefix() {
        // naming.compiler.original-analysis-metadata-context
        // docs/design/analysis/name-resolution-proofs/original-analysis-metadata-context.md
        // Namespace syntax is independent of a reached body, compiler child,
        // successful condition, variable frame or executable IR admission.
        let source = "if {$condition} {set result A}; if {[set condition]} {set result B}";
        for environment in ["tcl8.4", "tcl8.5", "tcl8.6", "tcl9.0", "tcl9.1", "jimtcl"] {
            let fixture = original_fixture(source, environment);
            let config = fixture.input.lexer_config();
            let expected = SourceNamespaceKey::from_native_entry(
                fixture.entry.native_entry.as_deref().unwrap(),
            )
            .unwrap();
            let request = InvocationMetadataContext::for_analysis_input(
                fixture.context.commands(),
                &fixture.input,
            )
            .unwrap();
            assert_eq!(fixture.tokens.len(), 2);
            for parent in &fixture.tokens {
                let binding = parent.source_binding.as_ref().unwrap();
                let body = body_at(parent, 2, config);
                assert_eq!(
                    binding.original_body_namespace_context(
                        fixture.context.commands(),
                        request,
                        parent,
                        &body,
                    ),
                    Some(expected.clone()),
                    "{environment}: {parent:?}"
                );
                assert!(binding.native_structured_preparation.is_none());
                assert!(
                    fixture
                        .bindings
                        .executed_script_namespace_context(&body)
                        .is_none()
                );
                assert!(
                    fixture
                        .bindings
                        .compiled_script_namespace_context(&body)
                        .is_none()
                );
            }
            let mut lowerer =
                crate::lowering::Lowerer::with_config(fixture.context.commands(), config)
                    .with_dialect(Some(fixture.input.unit_profile()))
                    .with_resolved_analysis_input(fixture.input.clone());
            lowerer.set_source_analysis_options(fixture.entry.options());
            let module = lowerer.lower(source);
            assert_eq!(module.top_level.statements.len(), 2);
            for statement in &module.top_level.statements {
                let children = statement.child_scripts();
                let [child] = children.as_slice() else {
                    panic!("each original conditional retains one body");
                };
                assert_eq!(child.namespace_context.as_deref(), Some(&expected));
                assert_eq!(child.statements.len(), 1);
                let tokens = child
                    .retained_source_tokens_for_statement(&child.statements[0])
                    .expect("original child vector survives namespace syntax projection");
                assert_eq!(tokens.words().len(), 3);
                assert_eq!(
                    tokens
                        .source_binding
                        .as_ref()
                        .unwrap()
                        .original_lexer_config_for_tokens(tokens),
                    Some(config)
                );
                assert!(
                    !matches!(&child.statements[0], crate::ir::Statement::Barrier { reason, .. }
                    if reason == "original body namespace context is unavailable")
                );
            }
        }
    }

    #[test]
    fn original_immediate_body_namespace_refuses_changed_and_missing_original_owners() {
        // naming.compiler.original-analysis-metadata-context
        // docs/design/analysis/name-resolution-proofs/original-analysis-metadata-context.md
        let fixture = original_fixture("if {$condition} {set result A}", "tcl8.6");
        let parent = &fixture.tokens[0];
        let binding = parent.source_binding.as_ref().unwrap();
        let config = fixture.input.lexer_config();
        let body = body_at(parent, 2, config);
        let request = InvocationMetadataContext::for_analysis_input(
            fixture.context.commands(),
            &fixture.input,
        )
        .unwrap();
        assert!(binding.original_body_namespace_context(
            fixture.context.commands(), request, parent, &body,
        ).is_some());
        let older_context = Arc::new(
            tcl_registry::model::ingress::resolve_environment("tcl8.4")
                .default_context_registry()
                .with_command_store(fixture.context.commands().snapshot().shared_registry()),
        );
        assert_eq!(
            older_context.commands().snapshot().semantic_key(),
            fixture.context.commands().snapshot().semantic_key()
        );
        assert_ne!(older_context.context(), fixture.context.context());
        let older = ResolvedAnalysisInput::new(
            fixture.input.analyser_profile(),
            fixture.input.unit_profile(),
            older_context,
            config,
        );
        let mut foreign_registry = CommandRegistry::build_default();
        foreign_registry.insert(tcl_registry::CommandSpec {
            name: "foreign_original_body_owner",
            ..foreign_registry.get("set").unwrap().clone()
        });
        let foreign_context = Arc::new(
            fixture
                .context
                .with_command_store(foreign_registry.snapshot().shared_registry()),
        );
        let foreign = ResolvedAnalysisInput::new(
            fixture.input.analyser_profile(),
            fixture.input.unit_profile(),
            foreign_context,
            config,
        );
        let grammar = ResolvedAnalysisInput::new(
            fixture.input.analyser_profile(),
            fixture.input.unit_profile(),
            Arc::clone(&fixture.context),
            LexerConfig {
                strict_quoting: !config.strict_quoting,
                ..config
            },
        );
        for changed in [&older, &foreign, &grammar] {
            assert!(
                binding
                    .original_body_namespace_context(
                        fixture.context.commands(),
                        InvocationMetadataContext::for_analysis_input(
                            changed.context_registry().commands(),
                            changed
                        )
                        .unwrap(),
                        parent,
                        &body
                    )
                    .is_none()
            );
        }
        for owner in [
            OwnedInvocationMetadataContext::Unavailable,
            OwnedInvocationMetadataContext::Supplied(Arc::clone(&fixture.context)),
        ] {
            let mut missing = parent.clone();
            let binding = missing.source_binding.as_mut().unwrap();
            binding.lookup_state = None;
            for row in Arc::make_mut(binding.declaration_layout_observations.as_mut().unwrap()) {
                Arc::make_mut(&mut Arc::make_mut(&mut row.snapshot).state.baseline)
                    .metadata_context = owner.clone();
            }
            assert!(
                missing
                    .source_binding
                    .as_ref()
                    .unwrap()
                    .original_body_namespace_context(
                        fixture.context.commands(),
                        request,
                        &missing,
                        &body,
                    )
                    .is_none()
            );
        }
        let mut missing = parent.clone();
        missing
            .source_binding
            .as_mut()
            .unwrap()
            .declaration_layout_observations = None;
        assert!(
            missing
                .source_binding
                .as_ref()
                .unwrap()
                .original_body_namespace_context(
                    fixture.context.commands(),
                    request,
                    &missing,
                    &body,
                )
                .is_none()
        );
        let mut changed = parent.clone();
        changed.word_exprs.pop();
        assert!(
            binding
                .original_body_namespace_context(
                    fixture.context.commands(),
                    request,
                    &changed,
                    &body
                )
                .is_none()
        );
        let foreign_body = body_at(
            &original_fixture("if {$condition} {set result B}", "tcl8.6").tokens[0],
            2,
            config,
        );
        assert!(
            binding
                .original_body_namespace_context(
                    fixture.context.commands(),
                    request,
                    parent,
                    &foreign_body
                )
                .is_none()
        );
        let mut missing_entry = parent.clone();
        let binding = missing_entry.source_binding.as_mut().unwrap();
        binding.lookup_state = None;
        for row in Arc::make_mut(binding.declaration_layout_observations.as_mut().unwrap()) {
            Arc::make_mut(&mut Arc::make_mut(&mut row.snapshot).state.baseline).native_entry = None;
        }
        assert!(
            missing_entry
                .source_binding
                .as_ref()
                .unwrap()
                .original_body_namespace_context(
                    fixture.context.commands(),
                    request,
                    &missing_entry,
                    &body,
                )
                .is_none()
        );
    }

    #[test]
    fn original_immediate_body_namespace_refuses_noncurrent_and_structural_descriptors() {
        // naming.compiler.original-analysis-metadata-context
        // docs/design/analysis/name-resolution-proofs/original-analysis-metadata-context.md
        // Genuine selected body metadata cannot be inferred from a body-like
        // string or from a command's printed namespace.
        for (source, written) in [
            ("proc p {} {set local VALUE}", 3),
            ("interp eval child {set local VALUE}", 3),
            ("set holder {set local VALUE}", 2),
            ("namespace code {set local VALUE}", 2),
        ] {
            let fixture = original_fixture(source, "tcl8.6");
            let parent = &fixture.tokens[0];
            let body = body_at(parent, written, fixture.input.lexer_config());
            let binding = parent.source_binding.as_ref().unwrap();
            assert!(
                binding
                    .original_body_namespace_context(
                        fixture.context.commands(),
                        InvocationMetadataContext::for_analysis_input(
                            fixture.context.commands(),
                            &fixture.input
                        )
                        .unwrap(),
                        parent,
                        &body
                    )
                    .is_none(),
                "{source}"
            );
        }
    }

    #[test]
    fn original_immediate_body_namespace_keeps_logical_source_and_native_entry_separate() {
        // naming.compiler.original-analysis-metadata-context
        // docs/design/analysis/name-resolution-proofs/original-analysis-metadata-context.md
        let source = "if {$condition} {set result VALUE}";
        let context =
            tcl_registry::model::ingress::resolve_environment("tcl8.6").default_context_registry();
        let profile = tcl_dialect::DialectProfile::plain_tcl();
        let config = LexerConfig::for_profile(Some(profile));
        let input = ResolvedAnalysisInput::new(profile, profile, Arc::clone(&context), config);
        let entry = SourceAnalysisEntry::for_logical_source(&input).unwrap();
        assert!(entry.native_entry.is_none());
        let bindings = SourceCommandBindings::analyse_with_options(
            source,
            config,
            context.commands(),
            entry.options(),
        );
        let image = tcl_lexer::SourceImage::document(source);
        let segments =
            crate::segmenter::segment_commands_image_with_offset_and_config(&image, 0, config)
                .unwrap();
        let mut parent = CommandTokens::from_segmented(&image.source_map(), config, &segments[0]);
        bindings.stamp_original_tokens(&mut parent);
        let body = body_at(&parent, 2, config);
        let binding = parent.source_binding.as_ref().unwrap();
        let namespace = binding
            .original_body_namespace_context(
                context.commands(),
                InvocationMetadataContext::for_analysis_input(context.commands(), &input).unwrap(),
                &parent,
                &body,
            )
            .expect("positively retained Logical namespace syntax");
        assert!(matches!(namespace, SourceNamespaceKey::Authored(_)));
        assert!(namespace.native_context().is_none());
        assert!(binding.native_structured_preparation.is_none());
        let native_profile = tcl_registry::model::ingress::resolve_known_environment("tcl8.6")
            .unwrap()
            .unit_profile();
        let native = ResolvedAnalysisInput::new(
            native_profile,
            native_profile,
            Arc::clone(&context),
            config,
        );
        assert!(!native.has_logical_source_name_context());
        assert!(
            binding
                .original_body_namespace_context(
                    context.commands(),
                    InvocationMetadataContext::for_analysis_input(context.commands(), &native)
                        .unwrap(),
                    &parent,
                    &body
                )
                .is_none()
        );
    }

    #[test]
    fn original_immediate_body_namespace_keeps_the_retained_nonroot_incarnation() {
        // naming.compiler.original-analysis-metadata-context
        // docs/design/analysis/name-resolution-proofs/original-analysis-metadata-context.md
        // The original namespace row supplies identity; its presentation is
        // used only to author the software fixture's namespace-eval operand.
        let fixture = original_fixture("if {$condition} {set result VALUE}", "tcl8.6");
        let native = fixture.entry.native_entry.as_deref().unwrap();
        let row = native
            .namespaces
            .iter()
            .find(|row| row.visible && !row.path.is_root())
            .expect("captured native registration includes a nonroot namespace");
        let expected =
            SourceNamespaceKey::Native(native.retained_namespace_context(row.token).unwrap());
        assert_ne!(
            expected,
            SourceNamespaceKey::from_native_entry(native).unwrap()
        );
        let command = "if {$condition} {set result VALUE}";
        let source = format!(
            "namespace eval {} {{{command}}}",
            expected.display().unwrap()
        );
        let config = fixture.input.lexer_config();
        let bindings = SourceCommandBindings::analyse_with_options(
            &source,
            config,
            fixture.context.commands(),
            fixture.entry.options(),
        );
        let offset = u32::try_from(source.find(command).unwrap()).unwrap();
        let part = tcl_lexer::SourceImage::document(command);
        let segments =
            crate::segmenter::segment_commands_image_with_offset_and_config(&part, offset, config)
                .unwrap();
        let image = tcl_lexer::SourceImage::document(&source);
        let mut parent = CommandTokens::from_segmented(&image.source_map(), config, &segments[0]);
        bindings.stamp_original_tokens(&mut parent);
        let body = body_at(&parent, 2, config);
        let binding = parent.source_binding.as_ref().unwrap();
        assert_eq!(
            binding.original_body_namespace_context(
                fixture.context.commands(),
                InvocationMetadataContext::for_analysis_input(
                    fixture.context.commands(),
                    &fixture.input
                )
                .unwrap(),
                &parent,
                &body
            ),
            Some(expected)
        );
    }
}
