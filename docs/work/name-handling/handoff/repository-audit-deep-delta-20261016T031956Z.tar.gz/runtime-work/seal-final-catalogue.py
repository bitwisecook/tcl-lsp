import json,hashlib,sys
from pathlib import Path
from collections import Counter
from datetime import datetime,timezone
sys.path.insert(0,str(Path(__file__).parent));from record import *
raw_bytes=(ROOT/'runtime-consumers.json').read_bytes();raw=json.loads(raw_bytes);c=json.loads((ROOT/'runtime-migration-units.json').read_text());coverage=json.loads((ROOT/'runtime-file-coverage.json').read_text());cover={x['path']:x for x in coverage['files']};errors=[]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
key=lambda r:r['path']+'::'+r['symbol']+'::'+r['site']
assert c['source_rows_sha256']==hashlib.sha256(raw_bytes).hexdigest()
ids={u['id'] for u in c['units']};assert len(ids)==len(c['units'])
for u in c['units']:
 assert u['category_review'] and u['category_review']['canonical_work_kind']==u['work_kind'],u['id']
 assert u['relative_effort'] in ['S','M','L','XL']
 assert len(u['original_indices'])==len(u['original_row_ids'])
 for i,rid in zip(u['original_indices'],u['original_row_ids']):
  assert rid==key(raw['consumers'][i]),(u['id'],i)
  assert u['id'] in c['original_row_mapping'][rid]['unit_ids'],(u['id'],i)
 for s in u['code_change_sites']:
  b=(SRC/s['path']).read_bytes();actual=hashlib.sha256(b).hexdigest()
  assert actual==s['source_sha256']==cover[s['path']]['sourceSHA'],s
  assert b.decode().splitlines()[s['line']-1]==s['source_line'],s
  assert s['source_line'].strip(),s
 for field in ['required_shared_owner_unit','shared_owner_dependency']:
  if field in u:assert u[field] in ids,(u['id'],field,u[field])
for rid,m in c['original_row_mapping'].items():
 assert rid==key(raw['consumers'][m['row_index']])
 for uid in m.get('unit_ids',[]):
  assert uid in ids,(rid,uid)
  unit=next(u for u in c['units'] if u['id']==uid);assert m['row_index'] in unit['original_indices'],(rid,uid)
for f in c['families']:
 for uid in f['unit_ids']:assert uid in ids
assert {uid for f in c['families'] for uid in f['unit_ids']}==ids
assert not c['unmapped_confirmed_change_rows']
assert len(c['original_row_mapping'])==len(raw['consumers'])
register=json.loads((ROOT/'runtime-required-owner-facets.json').read_text())
assert register['runtime_catalogue_sha256']==sha(ROOT/'runtime-migration-units.json')
assert register['source_rows_sha256']==c['source_rows_sha256']
for x in register['records']:
 for uid in x['actual_runtime_adapters']:assert uid in ids,(x['id'],uid)
 for s in x['adapter_source_sites']:
  b=(SRC/s['path']).read_bytes();assert hashlib.sha256(b).hexdigest()==s['source_sha256'];assert b.decode().splitlines()[s['line']-1]==s['source_line']
# Native/source/validation exclusions are required facts, not assertions waived.
for i in [61,62]:assert raw['consumers'][i]['disposition']=='migrated_validation_pending'
for i in [59,63]:assert raw['consumers'][i]['disposition']=='needs_migration'
for i in [620,985,986,591,760,867,864,813]:assert raw['consumers'][i]['disposition']=='pending_audit'
assert len(c['units'])==374 and c['canonical_review_completion']['unexamined_unit_categories']==0
# Primary snapshots are frozen after this exact check, not cyclic references.
paths=['runtime-file-coverage.json','runtime-consumers.json','runtime-migration-units.json','runtime-required-owner-facets.json','runtime-inline-operational-census.json','runtime-progress.json','runtime-work/source-scope-closure.json','runtime-work/canonical-completed-peer-corrections08.json','runtime-work/final-naming-duty-and-conditional-callers.json','runtime-work/canonical-semantic-final08.py','runtime-work/canonical-final-reconciliations.py','runtime-work/build-canonical-units.py','runtime-work/canonical-decisions.py','runtime-work/canonical-splits.py','runtime-work/canonical-splits04.py','runtime-work/canonical-owner-facets.py','runtime-work/finalize-catalogue.py','runtime-work/build-required-owner-register.py','runtime-work/seal-final-catalogue.py','runtime-work/vm-runtime-canonical01-admission.json','runtime-work/db-runtime-canonical02-admission.json','runtime-work/vm-runtime-canonical02-admission.json','vm-runtime-canonical01-review.json','db-runtime-canonical02-review.json','vm-runtime-canonical02-review.json','db-runtime-required-facets-canonical-annex161.json','compiler-cross-owner-required-native-facets.json']
manifest={'baseline':c['baseline'],'utc':datetime.now(timezone.utc).isoformat(),'status':'FROZEN coherent final Runtime assigned audit; source/row/unit/family/exact-line/sourceSHA and required-owner register binding PASS. Source-only, no execution or implementation acceptance.','files':[{'path':p,'bytes':(ROOT/p).stat().st_size,'sha256':sha(ROOT/p)} for p in paths],'counts':{'assigned_paths':10074,'production_shared_files_actual_read':375,'inline_test_support_reviewed':502,'retained_harness_provider_sources_reviewed':287,'unexamined_live_sources':0,'raw_purposes':992,'local_change_units':374,'by_work_kind':c['selected_scope_counts']['by_work_kind'],'effort':c['relative_effort_counts'],'source_sites':c['source_site_counts'],'raw_dispositions':dict(Counter(x['disposition'] for x in raw['consumers'])),'unexamined_canonical_categories':0,'external_requirement_register':register['counts']},'scope':'Local374 is not a global owner count. Twenty-five requirement groups link24 exact DB/Compiler owner IDs; two groups are existing local Core owners.22 groups preserve genuine domain/owner-partition questions, excluded from fabricated extra owner totals. VM public doors/headed adapter links retained separately. Existing current Native validation is not inferred.','limits':['No source/test/Cargo/provider/interpreter/network/Git mutations or execution.','Pending source/domain questions are examined audit conclusions, not unexamined source.','Parent/Text and380 existing implementation purposes remain execution-validation pending. Public original Import entry/live dispatch remains unfinished required work.','All original selectors/assertions/budgets and independent original data/provider observations retained.']}
atomic_write(ROOT/'runtime-final-audit-seal.json',json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'status':'PASS','seal_sha256':sha(ROOT/'runtime-final-audit-seal.json'),'primary':{p:sha(ROOT/p) for p in ['runtime-file-coverage.json','runtime-consumers.json','runtime-migration-units.json','runtime-required-owner-facets.json']},'counts':manifest['counts']},indent=2))
