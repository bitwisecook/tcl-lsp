from record import *
from datetime import datetime,timezone
p=ROOT/'runtime-consumers.json';d=load();fixes=[]
scopes={
687:'Lsearch actual input payload List raw-array/child conformance is not a naming migration merely because candidates can be names. Concrete mutable command-prefix adapter/Regex command name/currentness has separate rows. No new Index array owner required by this observation alone.',
689:'Lsort payload input-array/COW/reference conformance is outside confirmed entirely-naming scope; C84/C85/Jim lifetimes already differ explicitly, and bare Vec type is no proof of missing name authority. Actual comparator invocation and namespace diagnostic-list producers are separately tracked.',
648:'Compiled Switch binary subject conversion is payload semantics. It neither resolves a name nor issues a source/cell identity at the recorded site; generic numeric/String callback parity is not added to naming scale. Selected switch keyword/body/source consumers remain independent.',
659:'Folded expression Number cache constructor is numeric payload/provider conformance, with no actual name/header/source lookup duty demonstrated at this site. Do not infer naming debt merely from possible flow into a name later.',
701:'Literal Number cache adoption is numeric payload/provider construction, not an actual name constructor. Real registered command/source literal action producers remain separate naming units.',
768:'Constant expression Number cache construction is payload-only numerical/provider conformance. Existing selected source/name literal paths and command function heads are recorded separately.',
754:'Binary format field coercions are payload-only. Actual binary selector/format grammar naming and scan variable-name publication have separate units. Generic field String/numeric/header parity is outside entirely-naming migration absent concrete named/source producer dependency.',
690:'Noncommand lsort byte/numeric comparison is payload-order conformance, not name identity/grammar solely because its input may hold names. Actual name roster scheduling and mutable comparator command dispatch retain their own producer requirements.',
694:'Switch integer subject/pattern coercion is payload numeric conformance. Keyword/default and real script/body/variable output naming duties are tracked separately; no extra numeric owner extension from this site.',
686:'Lsearch glob candidate/pattern matching over arbitrary payload Lists does not establish a name input consumer duty. Actual namespace/variable name glob owners are independent; general matcher parity is excluded from confirmed naming count here.'}
for i,reason in scopes.items():
 old=d['consumers'][i].copy();d['consumers'][i].update(disposition='pending_audit',work_kind='validation_only',native_gap_countable=False,missingintegration=reason+' This remains an explicit scope/provider question, not a claim of implementation correctness or semantic acceptance.');fixes.append({'row':i,'before':old,'reason':reason})
# Existing String producer facet is counted once; actual named/frame callers are distinct.
d['consumers'][611]['work_kind']='owner_extension'
atomic_write(p,json.dumps(d,indent=2)+'\n')
q=ROOT/'runtime-work/canonical-decisions.py';s=q.read_text()
import ast
# Do not textual-match numbers in prose: update actual family lists using AST ranges.
t=ast.parse(s)
for node in reversed(t.body):
 if not isinstance(node,(ast.Assign,ast.AugAssign)):continue
 name=node.targets[0].id if isinstance(node,ast.Assign) and isinstance(node.targets[0],ast.Name) else node.target.id if isinstance(node,ast.AugAssign) and isinstance(node.target,ast.Name) else None
 if name!='FAMILIES':continue
 value=node.value
 families=ast.literal_eval(value);families=[(f,e,[i for i in ids if i not in set(scopes)|{697}]) for f,e,ids in families];families=[v for v in families if v[2]]
 lines=s.splitlines(True);a=sum(map(len,lines[:value.lineno-1]))+value.col_offset;b=sum(map(len,lines[:value.end_lineno-1]))+value.end_col_offset
 s=s[:a]+repr(families)+s[b:]
if '# Scope05 shared String producer' not in s:s+='\n# Scope05 shared String producer\nKIND_OVERRIDES[611]="shared_owner_repair"\n'
atomic_write(q,s)
atomic_write(ROOT/'runtime-work/canonical-entirely-naming-scope05.json',json.dumps({'baseline':d['baseline'],'utc':datetime.now(timezone.utc).isoformat(),'corrections':fixes,'scope_authority':'Root explicitly confirmed entirely-naming scope: generic List/String/number parity is not naming solely because a Namespace-valued object could flow through.','deduplication':'697 actual variable-name adapters are already observed by838/839/840; exact actual entrypoints/code changes are mapped once, not duplicated as generic Core payload rewrites.','no_execution':True},indent=2)+'\n')
