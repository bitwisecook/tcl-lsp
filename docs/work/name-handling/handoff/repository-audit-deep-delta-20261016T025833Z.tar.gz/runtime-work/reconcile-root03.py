from record import *
from datetime import datetime,timezone
p=ROOT/'runtime-consumers.json';d=load();before=[]
questions={327:'Generic List parse-error→errorCode conversion has no demonstrated actual naming producer dependency; central cleanup remains a scope question, not confirmed naming migration.',343:'This generic prefix helper owns no Jim child roster. The actual caller969 owns selected choices; if969 adopts the new genuine descriptor directly, helper removal is unchanged/dead cleanup rather than a separate migration. Count only if a genuinely changed independent helper boundary is proved.',676:'This reached C84 precision String getter consumes numeric VALUE after actual receiver selection, not a name operand. No concrete additional naming/cell producer prerequisite proved; generic numeric nested parity is a separate scope question.',681:'Compiled Dictionary Update fresh name is from actual retained local-name/slot, not a demonstrated report inverse. Exact original opcode indexed-versus-name unset contract must be established before declaring wrong producer or adding a migration; source assertion alone is no original proof.',800:'Generated ABI intentionally accepts counted name bytes with no antecedent name Obj header. Compiled slot names come from real bind_compiled_slot storage, not rendered report. Existing named read/store byte ingress is valid; require exact unmet generated ABI duty before a broad rewrite. Separate unbound-slot trace false question remains explicit.'}
for i,reason in questions.items():
 before.append({'row':i,'before':d['consumers'][i].copy(),'reason':reason});d['consumers'][i].update(disposition='pending_audit',work_kind='validation_only',native_gap_countable=False,missingintegration=reason+' Root canonical03 bounded source peer; no implementation/conformance success inferred.')
for i in [63,185,355,270]:
 before.append({'row':i,'before':d['consumers'][i].copy(),'kind':'owner_extension'});d['consumers'][i]['work_kind']='owner_extension'
atomic_write(p,json.dumps(d,indent=2)+'\n')
q=ROOT/'runtime-work/canonical-decisions.py';s=q.read_text();import ast
t=ast.parse(s)
for n in reversed(t.body):
 if not isinstance(n,(ast.Assign,ast.AugAssign)):continue
 name=n.targets[0].id if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) else n.target.id if isinstance(n,ast.AugAssign) and isinstance(n.target,ast.Name) else None
 if name!='FAMILIES':continue
 v=n.value;families=ast.literal_eval(v);families=[(f,e,[i for i in ids if i not in questions and i!=249]) for f,e,ids in families];families=[x for x in families if x[2]];ls=s.splitlines(True);a=sum(map(len,ls[:v.lineno-1]))+v.col_offset;b=sum(map(len,ls[:v.end_lineno-1]))+v.end_col_offset;s=s[:a]+repr(families)+s[b:]
s+='\n# Root canonical03 exact owner corrections\nKIND_OVERRIDES.update({63:"shared_owner_repair",185:"shared_owner_repair",355:"shared_owner_repair",270:"shared_owner_repair"})\n'
atomic_write(q,s)
atomic_write(ROOT/'runtime-work/root03-raw-corrections-beforeimages.json',json.dumps({'baseline':d['baseline'],'utc':datetime.now(timezone.utc).isoformat(),'peer':'root-runtime-canonical03-peer.json','sha256':hashlib.sha256((ROOT/'root-runtime-canonical03-peer.json').read_bytes()).hexdigest(),'corrections':before,'deduplication':'Original body result249 is joined to same actual Body query adapter248:body; new authentic query facet delivers original result, not an independently changed second factory.','limits':'No semantic/execution acceptance or original selector changes.'},indent=2)+'\n')
