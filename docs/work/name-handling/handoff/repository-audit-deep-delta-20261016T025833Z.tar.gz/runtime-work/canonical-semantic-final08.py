"""Exact completed source peer admissions and individually examined own purposes.
No source/build/provider execution. Invoked after prior reviewed reconciliation.
"""
import json,hashlib,copy
from pathlib import Path
R=Path('/workspace/name-session/full-consumer-audit')
OWN={
320:('consumer_api_adoption','Existing vocabulary::declaration("endpoint").member(name) owns exact endpoint roster; apply_endpoint_member781 copies it only for known/open classification. Keep typed operation branch800; actual adapter can use existing declaration without new owner.'),
437:('consumer_api_adoption','Concrete naming inputs are Dict keys optional pattern315/key320 and filter by_key patterns384/key388. Use fallible selected original getter/pattern protocol. Generic values/value-filter payload parity is separate scope; no-pattern keys stays lazy and returned actual key clones retain current purpose.'),
664:('consumer_api_adoption','Compiled Try actual pairs/header/currentness checks450–471 already strong. Remaining controlled -errorcode key463 is semantic key metadata. Pair scan versus original keyed dictionary lookup equivalence is an explicit provider requirement question, not a demonstrated missing physical lookup. Do not replace correct current guards or infer extra cache parity.'),
704:('consumer_api_adoption','Native Return actual pairs_current and per-key string callback485–494 already retain same original backing/header. Repeated known -errorinfo/-errorcode/etc literals should use a selected typed key declaration; no ready input-name extent recognizer is a construction issuer. Exact pair-scan versus selected native lookup is separately unproved, not automatic migration.'),
735:('consumer_api_adoption','Actual carried option key970 invokes default native_object_bytes and only then checks held original header/ticket/backing971–978. Existing native_object_bytes_with_stage_handlers composes this exact caller into reached String stages. Enumeration-versus-keyed lookup physical equivalence remains a separate provider question.'),
666:('consumer_api_adoption','Array get471 and unset563 compare genuine selected array element NAME keys to original pattern using generic matcher495/610. Extend/select exact get/unset NativeGlob purpose as needed; actual array target/read-miss/Guest/Host protocol and mutation schedule already owned. Payload values are not another naming migration.'),
668:('consumer_api_adoption','NativeArrayNamesProtocol50 already owns pure selected names grammar. Actual duplicate metadata is default OPTIONS248 and original NAMES261/OPTIONS262. One actual declaration facet can supply both public pure and original selection consumers while preserving physical static table/cache identity. No replacement for generic prefix algorithm or names-mode grammar.'),
669:('consumer_api_adoption','Actual Runtime SUBCOMMANDS66/STOCK_MEMBERS88 and worker/selector declarations need selected array operation/registration metadata; actual ArrayTarget/strict cell/search producers remain distinct and already guarded. Source registry roster alone is not physical declaration authority.'),
711:('consumer_api_adoption','Explicit scripted library installer63 creates wrapper body84 as ordinary String and calls ordinary Proc storage86 after missing slot. Actual namespace_helper/source metadata must reach genuine Source/prepublication marker path if selected actual helper. Preserve existing user/host bindings and actual provider filename/baseline; equal body/name never issues authority. Known Import refusal cannot be bypassed through an ordinary reinstalled actual helper.'),
720:('consumer_api_adoption','Two actual naming purposes: fresh intrinsic worker head selection246/307 (incr/append/lappend paired with selected worker) and combined element diagnostic209–213. Count separately; generated counted byte-name ABI has no antecedent Obj name, so fresh name construction is legitimate. No generic old-name header reconstruction claim.'),
731:('consumer_api_adoption','Jim require fixed auto_path301 read and actual native candidate load-script332 construction are separate named inputs. Central bare variable metadata and genuine global read purpose must preserve guest-null versus host refusal; exact native getter must match original CString construction rather than inventing an original header. Native file load literal script is evaluated in actual original phase; no object-vector equivalence shortcut.'),
733:('consumer_api_adoption','Actual Package unknown script757–780 owns prefix/default range/exact option invocation construction. Shared list element encoder is ready, selected package semantic invocation recipe is not supplied by that encoder. Extend existing package owner for exact script recipe; retain real eval_uplevel/current frame/mutable command lookup and original script extent.'),
736:('consumer_api_adoption','Actual carried-option duplicate1073 precedes current header/backing checks1075+. Existing duplicate_with_stage_check must receive same original return/header/caller continuation through duplication/free callbacks. Neutral memory leases cannot become Native holds or alter COW recipe.'),
740:('consumer_api_adoption','Concrete regexp output assignment callback108 and regsub selected output429 consume original variable name/frame/cell. Core regex pattern/cache implementation is already real; compose same actual invocation/caller into nested reached name/getter/setter stages. Generic Regex payload/character semantics is outside naming; record two actual output adapters.'),
741:('consumer_api_adoption','Actual Jim fresh matcher helper54 constructs -nocase63 and --65 then original vector74. Shared selected matcher invocation data facet is genuinely distinct from existing native_regex dialect selector. One facet serves default head382/537 and option/vector constructor741; real ordinary mutable lookup/header/lifetime remains caller-owned.')}

def apply(units,mapped,decided,rows,key,SRC):
 def site(path,line,symbol):
  raw=(SRC/path).read_bytes();text=raw.decode().splitlines()[line-1]
  return dict(path=path,line=line,symbol=symbol,source_line=text,semantic_anchor=text.strip(),source_sha256=hashlib.sha256(raw).hexdigest())
 def add(u,path,*lines):
  for line in lines:
   if not any(s['path']==path and s['line']==line for s in u['code_change_sites']):u['code_change_sites'].append(site(path,line,u['purpose']))
 def split(index,parts):
  old=next(u for u in units if u['original_indices']==[index]);units.remove(old);ids=[]
  for suffix,purpose,paths,change in parts:
   u=copy.deepcopy(old);u.update(id=old['id']+':'+suffix,purpose=purpose,code_change_sites=[site(p,n,purpose) for p,n in paths],required_change=change,split_from_original_row=index);units.append(u);ids.append(u['id'])
  mapped[key(rows[index])]['unit_ids']=ids
 # Only genuine separate actual boundaries; all original source lines retained.
 split(790,[('array-search','Actual array-search cache checked installer',[('runtime/rust/src/obj.rs',1894),('runtime/rust/src/obj.rs',1913),('runtime/rust/src/obj.rs',1914)],'Transport actual selected array/header/caller through existing checked primary retirement and cache publication. Frame-reference installation is separate.'),('frame-reference','Actual frame-reference cache checked installer',[('runtime/rust/src/obj.rs',2183),('runtime/rust/src/obj.rs',2205),('runtime/rust/src/obj.rs',2206)],'Transport actual selected frame/header/caller through existing checked primary retirement and cache publication. Preserve specific frame-reference protocol and real cache lifetime.')])
 split(118,[('all','Prefix all actual original List-result adapter',[('runtime/rust/src/cmd_string.rs',548),('runtime/rust/src/cmd_string.rs',559),('runtime/rust/src/cmd_string.rs',560)],'Adopt existing Core prefix::native_all230 preserving actual originals, caller and selected lookup/output member order. No new prefix algorithm owner.'),('longest','Prefix longest actual String/storage result adapter',[('runtime/rust/src/cmd_string.rs',569),('runtime/rust/src/cmd_string.rs',582),('runtime/rust/src/cmd_string.rs',598)],'Adopt existing Core prefix::native_longest270 preserving original table/key and actual selected longest constructor/getter/refcount purpose. No lossy Unicode prefix reconstruction.')])
 split(437,[('keys','Dict keys original name-pattern projection',[('rust/tcl-cmd-core/src/dict.rs',310),('rust/tcl-cmd-core/src/dict.rs',316),('rust/tcl-cmd-core/src/dict.rs',321)],OWN[437][1]),('filter-key','Dict filter key original name-pattern projection',[('rust/tcl-cmd-core/src/dict.rs',373),('rust/tcl-cmd-core/src/dict.rs',379),('rust/tcl-cmd-core/src/dict.rs',383)],OWN[437][1])])
 split(666,[('get','Array get selected element-name matcher',[('rust/tcl-cmd-core/src/array.rs',471),('rust/tcl-cmd-core/src/array.rs',495)],OWN[666][1]),('unset','Array unset selected element-name matcher',[('rust/tcl-cmd-core/src/array.rs',566),('rust/tcl-cmd-core/src/array.rs',611)],OWN[666][1])])
 split(720,[('worker-head','Compiled named-cell intrinsic worker declaration',[('runtime/rust/src/codegen_native.rs',246),('runtime/rust/src/codegen_native.rs',299)],'Consume selected intrinsic operation/head/worker descriptor for actual fresh byte-ABI invocation; retain genuine generated-name bytes and exact selected worker, counts, currentness. Ordinary byte ABI is valid, not a lost original header.'),('element-diagnostic','Compiled element combined diagnostic name',[('runtime/rust/src/codegen_native.rs',209),('runtime/rust/src/codegen_native.rs',210),('runtime/rust/src/codegen_native.rs',212)],'Use existing selected variable diagnostic combined-input/report owner or extend exact element rendering facet if missing, preserving real separate root/key bytes and operation error purpose. This is a report, not variable lookup identity.')])
 split(731,[('auto-path','Jim package genuine fixed global input',[('runtime/rust/src/cmd_package.rs',301),('runtime/rust/src/cmd_package.rs',308)],OWN[731][1]),('load-script','Jim package selected native load literal-script constructor',[('runtime/rust/src/cmd_package.rs',352),('runtime/rust/src/cmd_package.rs',354)],OWN[731][1])])
 split(740,[('regexp-output','Regexp actual original output variable continuation',[('runtime/rust/src/cmd_regex.rs',100),('runtime/rust/src/cmd_regex.rs',108)],OWN[740][1]),('regsub-output','Regsub actual original output variable continuation',[('runtime/rust/src/cmd_regex.rs',417),('runtime/rust/src/cmd_regex.rs',429)],OWN[740][1])])
 # Adjacent Unknown/Defer are one constructor, two distinct physical headers.
 context=next(u for u in units if u['original_indices']==[241]);other=next(u for u in units if u['original_indices']==[242]);units.remove(other)
 context['original_indices'].append(242);context['original_row_ids'].append(key(rows[242]));add(context,rows[242]['path'],rows[242]['line']);mapped[key(rows[242])]={'row_index':242,'canonical_state':'requires_code_change','unit_ids':[context['id']]};decided.add(242)
 context['deduplication_reason']='One actual context constructor with Unknown and Defer role fields, not two independent changed constructors or one merged physical header.'
 # Exact per-unit reviewed requirement boundaries, retaining readiness questions.
 for filename,field in [('vm-runtime-canonical01-review.json','rows'),('db-runtime-canonical02-review.json','reviewed_units'),('vm-runtime-canonical02-review.json','rows')]:
  peer=json.loads((R/filename).read_text());digest=hashlib.sha256((R/filename).read_bytes()).hexdigest()
  for u in units:
   hit=next((x for x in peer[field] if x['unit_id']==u['id']),None)
   if not hit:hit=next((x for x in peer[field] if x['unit_id']==u['id'].rsplit(':',1)[0] and u.get('split_from_original_row') is not None),None)
   if not hit:continue
   reason=hit.get('semantic_source_finding',hit.get('actual_source_reasoning',''))
   u['category_review']={'canonical_work_kind':u['work_kind'],'decision_reason':reason,'state':'actual_bounded_required_change_boundary_read_and_individually_reconciled_no_execution','peer':filename,'peer_sha256':digest,'peer_decision':hit.get('decision',hit.get('verdict'))}
   u['semantic_peer_requirement']=hit.get('recommendation',reason)
   u['actual_existing_guards_and_purpose_limits']=reason
   if u['original_indices'][0] in [517,211,241,745,750,769,801,807,825,870,904,927,929,939,972,973]:
    u['owner_facet_readiness']='Required selected semantic declaration/recipe is not established by source catalogue, DTO or generic table algorithm. Exact shared owner requirement retained separately; actual consumer stays a concrete adapter.'
   # Correct previously overbroad requirement text at reviewed actual sinks.
   if u['original_indices'][0] in [569,723,767,78,119,211,241,743,745,747,750,752,769,773,777,801,806,807,811,812,825,829,830,831,842,865,866,868,870,882,885,895,904,913,926,927,929,934,939,942,954,957,958,964,965,972,973,979]:u['required_change']=hit.get('recommendation',reason)
 # Exact actual site census from completed source challenge.
 extras={825:('runtime/rust/src/cmd_oo/native_context.rs',[323,491]),830:('runtime/rust/src/cmd_control.rs',[194,218,266]),831:('runtime/rust/src/cmd_control.rs',[517,578]),842:('runtime/rust/src/cmd_list.rs',[607,618,628,660,666,690,701,708]),866:('runtime/rust/src/cmd_namespace.rs',[1717,1727,1731]),868:('runtime/rust/src/cmd_namespace.rs',[1245,493,325,1648]),885:('runtime/rust/src/dict.rs',[1160,1174,1207,1233,1283]),934:('runtime/rust/src/interp.rs',[2316,2340]),957:('runtime/rust/src/interp.rs',[13804,13865]),958:('runtime/rust/src/interp.rs',[14347,14362,14375]),964:('runtime/rust/src/interp.rs',[11960,11981,12000,12008]),965:('runtime/rust/src/interp.rs',[15014,15026]),973:('runtime/rust/src/interp.rs',[16959,17026,16892,1851])}
 for u in units:
  i=u['original_indices'][0]
  if i in extras:
   p,lines=extras[i]
   # Locate known file only from actual full-source admitted path (no guesses).
   if not (SRC/p).exists():
    candidates=list(SRC.rglob(Path(p).name));assert len(candidates)==1,(i,p,candidates);p=str(candidates[0].relative_to(SRC))
   add(u,p,*lines)
  if i in OWN:
   kind,reason=OWN[i];u['work_kind']=kind;u['category_review']={'canonical_work_kind':kind,'decision_reason':reason,'state':'individual_actual_source_boundary_required_change_reconciled_no_execution','source':'runtime-work/canonical-semantic-final08.py OWN'}
  if i==668:u['code_change_sites']=[site('rust/tcl-cmd-core/src/array.rs',n,u['purpose']) for n in [244,248,256,261,262]]
  if i==752:
   u['purpose']='Binary decode actual codec/switch original-name inputs';u['required_change']='Transport actual retained original arguments/caller into decode codec390 and optional switch395. Existing selected selector/index/input bytearray policies remain strong. Binary format456 is generic format-program scope, excluded from this naming unit.';u['code_change_sites']=[site('runtime/rust/src/cmd_binary.rs',n,u['purpose']) for n in [390,395]]
  if i in [913] or (i in [927,939] and u['id'].endswith(':methods')) or (i==942 and u['id'].endswith((':core-role',':factory-role'))):
   u['work_kind']='consumer_api_adoption';u['existing_shared_api']='NativeTclooCoreMethod::name/public and NativeTclooMethodPayloadType::object_core_fallback/class_core_fallback; actual target/export/private applicability remains caller-owned.'
  if i in [777,713] and (i==777 or u['id'].endswith(':formals')):u['required_external_owner_unit']='compiler.owner.native.formal-args-default-role'
  if i==590:u['family_id']='oo_private_storage';u['required_external_owner_unit']='compiler.owner.oo_private_storage'
  if i==245:u['required_external_owner_unit']='compiler.owner.native.info-globals-pattern-input'
  if i==555:u['required_external_owner_unit']='db.unit.registry.native-namespace-string-literal-inputs'
  if i==571:u['required_external_owner_unit']='db.unit.registry.native-introspection-namespace-code-literal-inputs'
  if i==985 or i==986:
   u['shared_build_requirement']='native.jim-capture-mask-build-receipt: one actual selected provider/build mask/width recipe facet, shared across Catch/Try; existing Native bounded refusal already integrated, no SourceMeasured64 grant.'
   u['state']='existing_bounded_adoption_requires_one_external_build_recipe_then_conditional_adapter_change'
   u['affected_unchanged_callers']=['Current SupportedRust64Bounded refusal remains valid until genuine selected build recipe exists; shared owner once, not one owner per command.']
 # Shared fqn_glob_ok names matcher is repaired once. Actual callers carry
 # selected target/protocol only if new API requires it.
 target=next(u for u in units if u['original_indices'][0]==929 and u['id'].endswith(':vars-pattern'))
 owner=copy.deepcopy(target);owner.update(id='runtime:native.oo-fqn-name-pattern:shared-matcher',family_id='native.oo-fqn-name-pattern',work_kind='shared_owner_repair',purpose='OO actual qualified name-pattern matching owner',original_indices=[929,939],original_row_ids=[key(rows[i]) for i in [929,939]],code_change_sites=[site('runtime/rust/src/cmd_oo.rs',5801,'fqn_glob_ok shared selected name-pattern owner')],required_change='Extend existing shared actual OO matcher with selected NativeGlob purpose and exact pattern/name input; UTF8 projection failure must not silently become false. Preserve real held object/namespace/class relationship inventories. Actual callers pass authentic selected protocol/target as separate adapters when required.',relative_effort='M',category_review={'canonical_work_kind':'shared_owner_repair','decision_reason':'DB45 actual source confirms one fqn_glob_ok5801 used by vars4782 and class5629/5651. One helper implementation repair, no repeated helper count per caller.','state':'source_confirmed_shared_owner_and_actual_adapters_distinct_no_execution'})
 units.append(owner)
 for i in [929,939]:mapped[key(rows[i])]['unit_ids'].append(owner['id'])
 for u in units:
  if (u['original_indices'][0]==929 and u['id'].endswith(':vars-pattern')) or (u['original_indices'][0]==939 and u['id'].endswith(':patterns')):u['required_shared_owner_unit']=owner['id'];u['required_change']='Pass actual selected naming/pattern purpose through existing held target/namespace or class relation into the repaired common fqn_glob_ok owner. Existing target receipt already present; no report-to-identity allegation.'
 # Every actual record category describes the current unit kind, not an old label.
 for u in units:
  if 'category_review' in u:u['category_review']['canonical_work_kind']=u['work_kind']
 # Missing actual completion key/output recipe facets at already-owned shared
 # completion semantic owners, separate from reached Runtime constructors.
 for suffix,purpose,path,line,indices,change in [
 ('known-key','Selected standard completion-option key declaration','rust/tcl-cmd-core/src/return_options.rs',112,[664,704],'Expose typed standard completion-option key bytes under existing selected return-options owner. Existing name/name_in only projects supplied input extent and does not issue construction/lookup metadata. Preserve input grammar/cache/getter purpose independently; this facet conveys no object/header or lookup execution authority.'),
 ('syntax-literal','Selected rejected-expression private return literal recipe','rust/tcl-runtime-api/src/native_return_literal.rs',18,[769],'Extend existing private return-literal owner with exact selected rejected-expression Syntax construction data: known errorcode word and actual control/size roles. Caller still supplies genuine selected syntax/source context and actual allocation/merge/registration owner. DTO presence alone is no recipe issuer or Native grant.'),
 ('detached-schema','Detached completion dictionary output schema','rust/tcl-runtime-api/src/completion_options.rs',182,[806],'Extend existing pure completion-options schema for no-interpreter detached error transport output fields/values. Preserve codegen ABI-owned handles and genuine no-interpreter boundary; do not import Native option/getter/currentness authority into this pure schema.')]:
  base=next(u for u in units if u['original_indices'][0]==indices[0]);u=copy.deepcopy(base);u.update(id='runtime:completion.selected-key-and-output-facets:owner-'+suffix,family_id='completion.selected-key-and-output-facets',work_kind='shared_owner_repair',purpose=purpose,code_change_sites=[site(path,line,purpose)],original_indices=indices,original_row_ids=[key(rows[i]) for i in indices],required_change=change,relative_effort='M',category_review={'canonical_work_kind':'shared_owner_repair','decision_reason':change,'state':'genuine_required_existing_owner_extension_source_bound_no_execution'});u.pop('semantic_peer_requirement',None);u.pop('owner_facet_readiness',None);units.append(u)
  for i in indices:
   mapped[key(rows[i])]['unit_ids'].append(u['id'])
   for adapter in units:
    if adapter['original_indices'][0]==i and adapter['id']!=u['id']:adapter['required_shared_owner_unit']=u['id'];adapter['work_kind']='consumer_api_adoption';adapter['category_review']['canonical_work_kind']='consumer_api_adoption'
 # Existing Core Array default module is itself the shared declaration/selector
 # owner. Consolidating its two views is one owner repair, with no separately
 # demonstrated changed Runtime caller or extra Registry request.
 default=next(u for u in units if u['original_indices']==[668]);default['work_kind']='shared_owner_repair';default['family_id']='native.array-default-declaration';default['required_change']='Consolidate selected original Array default declaration and pure byte view in this existing Core owner, replacing duplicated OPTIONS248/NAMES261/OPTIONS262. Retain actual original Index table identity and independent selected NativeArrayDefaultProtocol; NativeArrayNamesProtocol grammar is already shared. Existing adapter calls can remain unchanged if signatures stay compatible.';default['affected_unchanged_callers']=['Runtime/VM calls to prepare_default_option_original need no separate speculative edit when selected declaration is repaired inside existing owner.'];default['category_review']={'canonical_work_kind':'shared_owner_repair','decision_reason':default['required_change'],'state':'actual_existing_owner_internal_two_view_declaration_repair_no_execution'}
 for suffix,family,purpose,path,line,index,change in [
 ('string-is','native.string-class-and-option-declarations','Selected StringIs original class/option declaration facet','rust/tcl-cmd-core/src/string_is.rs',34,582,'Extend existing StringIs semantic owner with actual selected immutable original class/option declarations. CLASSES/resolve_class currently own pure portable membership/diagnostic semantics only; selected C/Jim native table/release/availability is independent. Actual Runtime adapter keeps physical original header/cache/flags/noun/getter order. No class payload numeric conformance work inferred.'),
 ('engine-exports','embedding.runtime-export-declaration','Shared Runtime engine ABI export name/signature declaration','rust/tcl-runtime-api/src/engine_interpreter_identity.rs',14,511,'Extend existing shared Runtime engine ABI declaration owner with actual exported name/signature schema and provider drift linkage. Existing EngineInterpreterIdentity::EXPORT is the one already shared exact export. CodegenAbiImportId is imports, not a ready export schema. Actual Wasmtime typed-getter consumer changes separately; raw Rust no_mangle providers may stay unchanged with genuine whole export/signature linkage checks. No Tcl name grammar or Native object authority from ABI metadata.'),
 ('channel-error','native.channel-output-name-diagnostic','Channel output diagnostic exact byte-report facet','rust/tcl-cmd-core/src/channel.rs',845,480,'Extend existing channel_output_error(&str,...) formatter with actual byte-report input and selected output/extent purpose. Existing Unicode formatter remains valid for its callers. Actual Runtime name_for_error adapter supplies reached exact report bytes; formatter cannot select or reconstruct a live channel. Native opaque-byte/error-result semantics remain original-provider validation obligations.')]:
  base=next(u for u in units if u['original_indices'][0]==index);owner=copy.deepcopy(base);owner.update(id='runtime:'+family+':owner-'+suffix,family_id=family,work_kind='shared_owner_repair',purpose=purpose,code_change_sites=[site(path,line,purpose)],original_indices=[index],original_row_ids=[key(rows[index])],required_change=change,relative_effort='M',category_review={'canonical_work_kind':'shared_owner_repair','decision_reason':change,'state':'genuine_existing_owner_extension_and_actual_adapter_distinct_no_execution'});units.append(owner);mapped[key(rows[index])]['unit_ids'].append(owner['id']);base['required_shared_owner_unit']=owner['id']
 for u in units:
  # These older peer states have exact subsequent required boundary/owner/split
  # resolutions above, not unexamined future category work.
  if u.get('category_review',{}).get('state')=='independently_examined_requires_exact_owner_or_split_reconciliation':
   u['category_review']['subsequent_resolution']='Exact changed sites/splits and required owner links are now explicit in current unit plus runtime-required-owner-facets.json. Domain/owner partition questions remain questions; no ready API or final global count inferred.'
   u['category_review']['state']='individually_examined_actual_boundary_with_explicit_owner_requirement_or_question_no_execution'
 # New owner entries describe their own semantic seam and validation debt;
 # copied caller metadata is not an independent owner source/control receipt.
 for u in units:
  if u['id'].startswith('runtime:completion.selected-key-and-output-facets:owner-') or u['id'] in ['runtime:native.string-class-and-option-declarations:owner-string-is','runtime:embedding.runtime-export-declaration:owner-engine-exports','runtime:native.channel-output-name-diagnostic:owner-channel-error']:
   primary=u['code_change_sites'][0]
   u['representation_and_context']='Existing shared semantic owner extension at '+primary['path']+':'+str(primary['line'])+'. '+u['purpose']+'. Actual caller/header/provider/Native operation remains independently required by each linked adapter.'
   u['existing_shared_api']=primary['path']+':'+str(primary['line'])+' existing declaration/semantic owner; exact new facet is required_change, not a ready existing API.'
   u['source_evidence']=['runtime-file-coverage.json: exact owner file full source admitted at fixed baseline; current code_change_sites retain actual source line and whole-file SHA.','runtime-work/canonical-semantic-final08.py: individually interpreted existing owner versus actual linked adapter boundary; bounded VM/source peers establish missing facet purposes, not implementation or execution.']
   u['retained_control_references']=[]
   u['required_validation_purpose']=u['required_change']+' New owner discriminator/drift/selected-input controls remain required; actual caller controls are retained on their adapters and do not donate owner acceptance.'
   u['limitations']='Source-confirmed required semantic owner extension, not implementation or execution. Original provider/setup/currentness and schema-versus-Native purpose controls remain independent.'
   for k in ['root_canonical02_review','root_canonical03_review','independent_boundary_review','semantic_peer_requirement','owner_facet_readiness']:
    u.pop(k,None)
 # Exact DB161 admitted cross-owner facets: selected semantic owner once,
 # actual Runtime adapters preserve independent physical/context duties.
 admitted=json.loads((R/'db-runtime-required-facets-canonical-annex161.json').read_text())
 for extension in admitted['added_owner_units']:
  for uid in extension['actual_external_adopter_ids']:
   u=next((u for u in units if u['id']==uid),None)
   assert u is not None,uid
   u['required_external_owner_unit']=extension['id']
   u['external_owner_source_site']=extension['owner_site']
   u['external_owner_admission']='db-runtime-required-facets-canonical-annex161.json SHA'+hashlib.sha256((R/'db-runtime-required-facets-canonical-annex161.json').read_bytes()).hexdigest()
   u['owner_facet_readiness']='Explicit required extension at existing Registry semantic owner; NOT an implemented or ready physical API. Actual original table/header/context/caller duties remain Runtime.'
 # Engine identity's existing one-export declaration is valid unchanged.
 # New full export schema extends the existing Runtime API module seam;
 # it does not turn the identity type into a generic ABI authority.
 for u in units:
  if u['id']=='runtime:embedding.runtime-export-declaration:owner-engine-exports':
   u['code_change_sites']=[site('rust/tcl-runtime-api/src/lib.rs',719,'Existing shared Runtime engine ABI module declaration seam')]
   u['related_unchanged_owner_evidence']=[site('rust/tcl-runtime-api/src/engine_interpreter_identity.rs',16,'Existing exact identity export constant remains unchanged')]
   u['representation_and_context']='Shared Runtime engine ABI declaration module seam; actual export symbols/signatures are data, distinct from InterpreterIdentity Native authority. Actual Wasmtime getter/adapters remain separate.'
   u['existing_shared_api']='runtime-api lib719 exposes narrow engine_interpreter_identity owner with its exact EXPORT constant16; new complete export declaration facet is required, not already supplied by that type.'
