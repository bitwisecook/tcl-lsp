import json,hashlib,runpy,sys
from collections import Counter
from datetime import datetime,timezone
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent));from record import *
d=load();d['status']='Complete assigned source census and individual purpose classification; explicit unresolved source/provider duties and unexecuted validation retained.'
d['audit_completion']={'production_shared_files':375,'inline_test_support_regions':502,'reopened_retained_harness_sources':287,'unexamined_live_source':0,'limits':'Source-only fixed baseline audit, no execution/Native semantic acceptance.'}
d['consumers'][668]['work_kind']='owner_extension';d['consumers'][668]['work_kind_reason']='Actual existing Core Array default module owns both selected pure/original declaration views; repair internally once, no demonstrated changed caller or extra Registry owner.'
atomic_write(ROOT/'runtime-consumers.json',json.dumps(d,indent=2)+'\n')
runpy.run_path(str(ROOT/'runtime-work/build-canonical-units.py'),run_name='__main__')
p=ROOT/'runtime-migration-units.json';c=json.loads(p.read_text());units=c['units'];assert len(units)==374;assert all(u.get('category_review') for u in units)
c.update(status='COMPLETE assigned source and individual canonical naming-boundary audit. Local confirmed change units below; cross-owner extension assignments and explicit unresolved domain/partition questions remain separate. No implementation or execution acceptance.',remaining_consumer_total=len(units),scope_qa_complete=True,remaining_count_blockers=[])
c['count_scope']='374 actual Runtime-assigned local change units, including owned shared Core/API/Host owners and explicit validation/docs. External DB/Compiler/VM owner units are linked and counted only by their owning lanes. Unresolved domain or conditional future caller questions are excluded from this confirmed local count.'
c['canonical_review_completion']={'unit_categories_examined':len(units),'unexamined_unit_categories':0,'confirmed_raw_purposes_mapped':len([r for r in d['consumers'] if r['disposition']=='needs_migration']),'unmapped_confirmed_raw_purposes':0,'limits':'Presence of an individual review is not provider, original semantic or execution acceptance. Required external facets that remain partition/domain questions do not acquire invented counts.'}
c['source_scope_completion']={'assigned_paths':10074,'production_and_shared_owner_files':375,'inline_test_support_regions':502,'retained_operational_harness_provider_sources':287,'unexamined_live_scope':0,'receipt':'runtime-work/source-scope-closure.json','receipt_sha256':hashlib.sha256((ROOT/'runtime-work/source-scope-closure.json').read_bytes()).hexdigest()}
def area(path):
 if path.startswith('runtime/'):return 'runtime'
 return path.split('/')[1] if path.startswith('rust/') else path.split('/')[0]
c['area_counts']=dict(Counter(area(u['code_change_sites'][0]['path']) for u in units))
c['relative_effort_counts']=dict(Counter(u['relative_effort'] for u in units))
c['source_site_counts']={'changed_source_files':len({s['path'] for u in units for s in u['code_change_sites']}),'distinct_change_sites':len({(s['path'],s['line']) for u in units for s in u['code_change_sites']}),'unit_site_memberships':sum(len(u['code_change_sites']) for u in units)}
c['source_question_and_validation_counts']=dict(Counter(r['disposition'] for r in d['consumers']))
c['explicit_limits']=['Parent and Text62/61 existing checked transports remain migrated_validation_pending with no current Native test acceptance.','Public original Import entry refusal/live manual dispatch is unfinished actual required work59/63; no unconditional enable inferred.','SourceMeasured64 is never Native authority;985/986 are explicit conditional caller/build questions, not counted current edits.','Host cwd/executable/env/bootstrap and generated shell/provider paths retain actual OS encoding/source/provider obligations. Ordinary Unicode APIs remain legitimate distinct facades.','Generic primitive parity and preserved original/fixed oracle inputs are excluded unless an actual naming producer/caller obligation is demonstrated.']
c['required_owner_register']='runtime-required-owner-facets.json'
c['external_owner_boundaries']={'Registry':'db-runtime-required-facets-canonical-annex161.json','Syntax':'compiler-cross-owner-required-native-facets.json','VM public doors':'vm-embedding-owner-facet-annex.json','rule':'Exact external owners counted once there; actual Runtime adapters separately here. Metadata/source declarations never issue actual Native/frame/key/header identity.'}
atomic_write(p,json.dumps(c,indent=2)+'\n')
print(json.dumps({'units':len(units),'work_kinds':c['selected_scope_counts']['by_work_kind'],'effort':c['relative_effort_counts'],'sites':c['source_site_counts'],'raw_sha256':c['source_rows_sha256'],'catalogue_sha256':hashlib.sha256(p.read_bytes()).hexdigest()},indent=2))
