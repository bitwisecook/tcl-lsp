/* ORIGINAL_SOURCE_RANGE 56..57 */
56: #[cfg(test)]
57: use crate::variable_bindings::build_point_resolve_contexts;
/* ORIGINAL_SOURCE_RANGE 4364..4390 */
4364: #[cfg(test)]
4365: #[must_use]
4366: pub(crate) fn compute_idom(
4367:     func: &cfg::Function,
4368:     dom: &HashMap<BlockId, HashSet<BlockId>>,
4369: ) -> HashMap<BlockId, Option<BlockId>> {
4370:     let reachable = func.reachable_blocks();
4371:     let mut idom: HashMap<BlockId, Option<BlockId>> = HashMap::new();
4372: 
4373:     for id in func.blocks.keys() {
4374:         idom.insert(*id, None);
4375:     }
4376: 
4377:     for id in &reachable {
4378:         if *id == func.entry {
4379:             continue;
4380:         }
4381:         let strict: HashSet<BlockId> = dom[id].iter().copied().filter(|d| d != id).collect();
4382:         if strict.is_empty() {
4383:             continue;
4384:         }
4385:         // The idom is the strict dominator with the largest dom set.
4386:         let best = *strict.iter().max_by_key(|d| dom[*d].len()).unwrap();
4387:         idom.insert(*id, Some(best));
4388:     }
4389:     idom
4390: }
/* ORIGINAL_SOURCE_RANGE 4468..4486 */
4468: #[cfg(test)]
4469: pub(crate) fn compute_phi_vars(
4470:     func: &cfg::Function,
4471:     df: &HashMap<BlockId, HashSet<BlockId>>,
4472:     registry: &CommandRegistry,
4473:     elems: &ArrayElems,
4474: ) -> HashMap<BlockId, HashSet<VariableCellKey>> {
4475:     compute_phi_vars_with_config(
4476:         func,
4477:         df,
4478:         SsaInvocationContext::standalone(registry),
4479:         elems,
4480:         tcl_lexer::LexerConfig::for_profile(registry.profile()),
4481:         &build_point_resolve_contexts(func, &func.name, registry),
4482:         &HashMap::new(),
4483:     ).into_iter().map(|(block, identities)| (block, identities.into_iter().filter_map(|identity| match identity {
4484:         SsaVariableIdentity::Location(key) => Some(key), SsaVariableIdentity::Source(_) => None,
4485:     }).collect())).collect()
4486: }
/* ORIGINAL_SOURCE_RANGE 8503..12662 */
8503: #[cfg(test)]
8504: mod tests {
8505: 
8506:     use super::*;
8507:     use crate::cfg::{Block, Function, Terminator};
8508:     use crate::expr_ast::ExprNode;
8509:     use tcl_lexer::Span;
8510: 
8511:     fn logical_role_metadata_fixture() -> (
8512:         std::sync::Arc<tcl_registry::model::ContextRegistry>,
8513:         crate::compilation_unit::CompilationUnit,
8514:     ) {
8515:         logical_metadata_fixture("info exists selected")
8516:     }
8517: 
8518:     fn logical_metadata_fixture(
8519:         source: &str,
8520:     ) -> (
8521:         std::sync::Arc<tcl_registry::model::ContextRegistry>,
8522:         crate::compilation_unit::CompilationUnit,
8523:     ) {
8524:         use std::sync::Arc;
8525:         let baseline = tcl_registry::model::ingress::static_context_for("tcl8.6");
8526:         let mut registry = baseline
8527:             .commands()
8528:             .project_for_profile(tcl_dialect::DialectProfile::find("tcl8.6").unwrap());
8529:         let mut info = registry.get("info").unwrap().clone();
8530:         info.surface = Some(tcl_dialect::model::SpecSurface::TCL86_PLUS);
8531:         registry.insert(info);
8532:         let context = Arc::new(baseline.with_command_store(Arc::new(registry)));
8533:         let profile = tcl_dialect::DialectProfile::plain_tcl();
8534:         let config = tcl_lexer::LexerConfig::for_file_grammar(profile.grammar);
8535:         let input = crate::analyser::ResolvedAnalysisInput::new(
8536:             profile,
8537:             profile,
8538:             Arc::clone(&context),
8539:             config,
8540:         );
8541:         let entry = crate::command_binding::SourceAnalysisEntry::for_logical_source(&input)
8542:             .expect("genuine positive supplied Logical input");
8543:         let unit = crate::compilation_unit::CompilationUnit::build_with_analysis_input(
8544:             source,
8545:             crate::compilation_unit::UnitBuildOptions {
8546:                 registry: context.commands(),
8547:                 defer_top_level: false,
8548:                 config,
8549:                 dialect: Some(profile),
8550:                 external_call_sites: None,
8551:                 declared_commands: None,
8552:             },
8553:             Some(&entry),
8554:             &input,
8555:         );
8556:         (context, unit)
8557:     }
8558: 
8559:     #[test]
8560:     fn supplied_ssa_availability_without_source_cannot_reopen_standalone_ownership() {
8561:         // naming.compiler.original-analysis-metadata-context
8562:         // docs/design/analysis/name-resolution-proofs/original-analysis-metadata-context.md
8563:         // Lexical software advice only, independent of Native frames or stores.
8564:         let context =
8565:             tcl_registry::model::ingress::resolve_environment("tcl9.0").default_context_registry();
8566:         let registry = context.commands();
8567:         let profile = tcl_dialect::DialectProfile::find("tcl9.0").unwrap();
8568:         let config = tcl_lexer::LexerConfig::for_profile(Some(profile));
8569:         let static_context = tcl_registry::model::semantic::SemanticContext::for_profile(profile);
8570:         let standalone = SsaInvocationContext::supplied(registry, Some(static_context.into()));
8571:         let supplied = SsaInvocationContext::supplied(registry, Some(context.as_ref().into()));
8572:         assert!(standalone.standalone);
8573:         assert!(!supplied.standalone);
8574:         assert!(supplied.metadata.unwrap().matches_registry(registry));
8575:         assert!(supplied.metadata.unwrap().source_analysis_input().is_none());
8576:         let owns = |selection| {
8577:             braced_word_owns_name(&BracedWordSite {
8578:                 braced: true,
8579:                 evaluated_in_frame: false,
8580:                 described: false,
8581:                 word: "set x 1; puts $x",
8582:                 name: "x",
8583:                 selection,
8584:                 tokens: None,
8585:                 written_argument: 0,
8586:                 config,
8587:             })
8588:         };
8589:         assert!(owns(standalone));
8590:         assert!(!owns(supplied));
8591:         assert!(!owns(SsaInvocationContext::supplied(registry, None)));
8592:     }
8593: 
8594:     #[test]
8595:     fn original_ssa_body_ownership_exclusion_keeps_literal_roots_and_opaque_residuals() {
8596:         // naming.compiler.original-analysis-metadata-context
8597:         // docs/design/analysis/name-resolution-proofs/original-analysis-metadata-context.md
8598:         // The bridge consumes conditional body names, never actual read exclusion.
8599:         use crate::compilation_unit::{CompilationUnit, UnitBuildOptions};
8600:         use crate::registry_invocation::InvocationMetadataContext;
8601:         use std::sync::Arc;
8602:         let context =
8603:             tcl_registry::model::ingress::resolve_environment("tcl9.0").default_context_registry();
8604:         let registry = context.commands();
8605:         let profile = tcl_dialect::DialectProfile::plain_tcl();
8606:         let config = tcl_lexer::LexerConfig::from_grammar(profile.grammar);
8607:         let input = crate::analyser::ResolvedAnalysisInput::new(
8608:             profile,
8609:             profile,
8610:             Arc::clone(&context),
8611:             config,
8612:         );
8613:         for (body, expected) in [
8614:             ("set {$literal} VALUE; puts ${$literal}", true),
8615:             ("set {$literal} VALUE; operation", false),
8616:         ] {
8617:             let source = format!("catch {{{body}}}");
8618:             let unit = CompilationUnit::build_with_analysis_input(
8619:                 &source,
8620:                 UnitBuildOptions {
8621:                     registry,
8622:                     defer_top_level: false,
8623:                     config,
8624:                     dialect: Some(profile),
8625:                     external_call_sites: None,
8626:                     declared_commands: None,
8627:                 },
8628:                 None,
8629:                 &input,
8630:             );
8631:             let script = &unit.ir_module.top_level;
8632:             let tokens = script
8633:                 .retained_source_tokens_for_statement(
8634:                     script.statements.last().expect("original installer"),
8635:                 )
8636:                 .expect("original whole installer words");
8637:             let metadata = InvocationMetadataContext::for_module(registry, &unit.ir_module);
8638:             let owns = |name, selection| {
8639:                 braced_word_owns_name(&BracedWordSite {
8640:                     braced: true,
8641:                     evaluated_in_frame: false,
8642:                     described: false,
8643:                     word: body,
8644:                     name,
8645:                     selection,
8646:                     tokens: Some(tokens),
8647:                     written_argument: 0,
8648:                     config,
8649:                 })
8650:             };
8651:             let selection = SsaInvocationContext::supplied(registry, metadata);
8652:             assert_eq!(owns("$literal", selection), expected, "{body}");
8653:             assert!(
8654:                 !owns("literal", selection),
8655:                 "the literal sigil is part of the name"
8656:             );
8657:             assert!(!owns(
8658:                 "$literal",
8659:                 SsaInvocationContext::supplied(registry, None)
8660:             ));
8661:         }
8662:     }
8663: 
8664:     #[test]
8665:     fn supplied_ssa_role_scans_keep_actual_availability_grammar_and_missing_input() {
8666:         // naming.compiler.original-analysis-metadata-context
8667:         // docs/design/analysis/name-resolution-proofs/original-analysis-metadata-context.md
8668:         // Selected source roles are independent of Native NamePolicy and actual execution.
8669:         use crate::registry_invocation::InvocationMetadataContext;
8670:         use std::sync::Arc;
8671:         let (context, unit) = logical_role_metadata_fixture();
8672:         let registry = context.commands();
8673:         let function = &unit.top_level;
8674:         let input = function.source_metadata_input().unwrap();
8675:         let statement = function
8676:             .cfg
8677:             .blocks
8678:             .values()
8679:             .flat_map(|body| &body.statements)
8680:             .find(|statement| statement.tokens().is_some())
8681:             .unwrap();
8682:         let scan = |metadata| {
8683:             let mut scanner = VarReferenceScanner::with_config(
8684:                 VarScanOptions {
8685:                     include_var_read_roles: false,
8686:                     ..Default::default()
8687:                 },
8688:                 function.source_lexer_config(),
8689:             );
8690:             uses_of_classified_in_context(
8691:                 statement,
8692:                 &mut scanner,
8693:                 SsaInvocationContext::supplied(registry, metadata),
8694:             )
8695:         };
8696:         let metadata = function.invocation_metadata_context_for_module(registry, &unit.ir_module);
8697:         assert!(metadata.is_some());
8698:         assert!(
8699:             function
8700:                 .ssa
8701:                 .point_contexts
8702:                 .as_ref()
8703:                 .unwrap()
8704:                 .before_statement(function.cfg.entry, 0)
8705:                 .execution_name_policy
8706:                 .is_none()
8707:         );
8708:         assert_eq!(scan(metadata), vec![("selected".into(), UseClass::Name)]);
8709:         assert!(scan(None).is_empty());
8710:         let older = Arc::new(
8711:             tcl_registry::model::ingress::static_context_for("tcl8.4")
8712:                 .with_command_store(Arc::clone(context.commands())),
8713:         );
8714:         assert!(Arc::ptr_eq(older.commands(), registry));
8715:         let older_input = crate::analyser::ResolvedAnalysisInput::new(
8716:             input.analyser_profile(),
8717:             input.unit_profile(),
8718:             older,
8719:             input.lexer_config(),
8720:         );
8721:         let foreign = crate::analyser::ResolvedAnalysisInput::new(
8722:             input.analyser_profile(),
8723:             input.unit_profile(),
8724:             tcl_registry::model::ingress::resolve_environment("tcl9.1").default_context_registry(),
8725:             input.lexer_config(),
8726:         );
8727:         let mut grammar = input.lexer_config();
8728:         grammar.strict_quoting = !grammar.strict_quoting;
8729:         let changed = crate::analyser::ResolvedAnalysisInput::new(
8730:             input.analyser_profile(),
8731:             input.unit_profile(),
8732:             Arc::clone(&context),
8733:             grammar,
8734:         );
8735:         for withheld in [&older_input, &foreign, &changed] {
8736:             assert!(
8737:                 scan(InvocationMetadataContext::for_analysis_input(
8738:                     registry, withheld
8739:                 ))
8740:                 .is_empty()
8741:             );
8742:         }
8743:     }
8744: 
8745:     #[test]
8746:     fn supplied_ssa_definition_and_lexical_reads_do_not_reconstruct_catalogue_roles() {
8747:         // naming.compiler.original-analysis-metadata-context
8748:         // docs/design/analysis/name-resolution-proofs/original-analysis-metadata-context.md
8749:         let (context, unit) = logical_role_metadata_fixture();
8750:         let registry = context.commands();
8751:         let function = &unit.top_level;
8752:         let statement = function
8753:             .cfg
8754:             .blocks
8755:             .values()
8756:             .flat_map(|body| &body.statements)
8757:             .find(|statement| statement.tokens().is_some())
8758:             .unwrap();
8759:         let unavailable = SsaInvocationContext::supplied(registry, None);
8760:         assert!(defs_of_in_context(statement, Some(unavailable)).is_empty());
8761:         let tokens = statement.tokens().unwrap();
8762:         assert!(unavailable.normal(tokens).is_none());
8763:         assert!(unavailable.resolve(tokens).is_none());
8764:         // Pure word substitution remains lexical even when command roles are withheld.
8765:         let mut scanner = VarReferenceScanner::with_config(
8766:             VarScanOptions {
8767:                 include_var_read_roles: false,
8768:                 ..Default::default()
8769:             },
8770:             function.source_lexer_config(),
8771:         );
8772:         assert_eq!(
8773:             scanner.scan_word("$lexical [info exists nominal]", registry),
8774:             BTreeSet::from(["lexical".to_owned()])
8775:         );
8776:         let mut requested = VarReferenceScanner::with_config(
8777:             VarScanOptions {
8778:                 include_var_read_roles: true,
8779:                 ..Default::default()
8780:             },
8781:             function.source_lexer_config(),
8782:         );
8783:         assert_eq!(
8784:             unavailable.word_reads(&mut requested, "$lexical [info exists nominal]"),
8785:             BTreeSet::from(["lexical".to_owned()])
8786:         );
8787:         assert!(
8788:             SsaInvocationContext::standalone(registry)
8789:                 .word_reads(&mut requested, "$lexical [info exists nominal]")
8790:                 .contains("nominal")
8791:         );
8792:         assert_eq!(
8793:             unavailable.word_reads(&mut requested, "$lexical [info exists nominal]"),
8794:             BTreeSet::from(["lexical".to_owned()])
8795:         );
8796:     }
8797: 
8798:     fn original_operand_metadata_fixture() -> (
8799:         std::sync::Arc<tcl_registry::model::ContextRegistry>,
8800:         crate::environment_ingress::RetainedNativeUnit,
8801:     ) {
8802:         use std::sync::Arc;
8803:         let baseline = tcl_registry::model::ingress::static_context_for("tcl8.6");
8804:         let profile = tcl_dialect::DialectProfile::find("tcl8.6").unwrap();
8805:         let mut registry = baseline.commands().project_for_profile(profile);
8806:         let mut setter = registry.get("set").unwrap().clone();
8807:         setter.surface = Some(tcl_dialect::model::SpecSurface::TCL86_PLUS);
8808:         registry.insert(setter);
8809:         let context = Arc::new(baseline.with_command_store(Arc::new(registry)));
8810:         let (owner, captured) =
8811:             crate::environment_ingress::captured_native_entry_with_owner(profile);
8812:         let entry = crate::command_binding::SourceAnalysisEntry {
8813:             native_entry: Some(Arc::new(captured)),
8814:             invocation_dialect: Some(tcl_registry::InvocationDialect::of_profile(profile)),
8815:             native_compilation: crate::environment_ingress::authoring_native_compilation(),
8816:             ..Default::default()
8817:         };
8818:         let unit = crate::compilation_unit::CompilationUnit::build_with_context_registry(
8819:             "set selected VALUE",
8820:             crate::compilation_unit::UnitBuildOptions {
8821:                 registry: context.commands(),
8822:                 config: tcl_lexer::LexerConfig::for_dialect("tcl8.6"),
8823:                 dialect: Some(profile),
8824:                 defer_top_level: false,
8825:                 external_call_sites: None,
8826:                 declared_commands: None,
8827:             },
8828:             Some(&entry),
8829:             Arc::clone(&context),
8830:         );
8831:         (
8832:             context,
8833:             crate::environment_ingress::RetainedNativeUnit::new(unit, owner),
8834:         )
8835:     }
8836: 
8837:     fn original_setter_definition_point(
8838:         function: &crate::compilation_unit::FunctionUnit,
8839:     ) -> (BlockId, usize, Symbol) {
8840:         function
8841:             .ssa
8842:             .blocks
8843:             .iter()
8844:             .find_map(|(&block, body)| {
8845:                 body.statements
8846:                     .iter()
8847:                     .enumerate()
8848:                     .find_map(|(index, statement)| {
8849:                         statement
8850:                             .defs
8851:                             .keys()
8852:                             .next()
8853:                             .map(|&symbol| (block, index, symbol))
8854:                     })
8855:             })
8856:             .expect("genuine selected original setter definition")
8857:     }
8858: 
8859:     #[test]
8860:     fn original_definition_subjects_keep_supplied_availability_and_missing_input_separate() {
8861:         // naming.variable.original-ssa-definition-operand
8862:         // docs/design/analysis/name-resolution-proofs/original-ssa-definition-operand.md
8863:         // naming.compiler.original-analysis-metadata-context
8864:         // docs/design/analysis/name-resolution-proofs/original-analysis-metadata-context.md
8865:         use crate::registry_invocation::InvocationMetadataContext;
8866:         use std::sync::Arc;
8867:         let (context, unit) = original_operand_metadata_fixture();
8868:         let function = &unit.top_level;
8869:         let (block, index, symbol) = original_setter_definition_point(function);
8870:         let view = SsaSourceView::at_statement(&function.ssa, block, index);
8871:         let registry = context.commands();
8872:         let select = |metadata| {
8873:             view.original_definition_name_with_metadata_context(symbol, registry, metadata)
8874:         };
8875:         let metadata = function.invocation_metadata_context_for_module(registry, &unit.ir_module);
8876:         let original =
8877:             select(metadata).expect("actual original receiver under current availability");
8878:         assert_eq!(original.original_name_input().bytes(), b"selected");
8879:         assert_eq!(Some(original.cell()), function.ssa.cell_key(symbol));
8880:         assert!(select(None).is_none());
8881:         let input = function.source_metadata_input().unwrap();
8882:         let older_context = Arc::new(
8883:             tcl_registry::model::ingress::static_context_for("tcl8.4")
8884:                 .with_command_store(Arc::clone(context.commands())),
8885:         );
8886:         assert!(Arc::ptr_eq(older_context.commands(), context.commands()));
8887:         let older = crate::analyser::ResolvedAnalysisInput::new(
8888:             input.analyser_profile(),
8889:             input.unit_profile(),
8890:             older_context,
8891:             input.lexer_config(),
8892:         );
8893:         assert!(
8894:             select(InvocationMetadataContext::for_analysis_input(
8895:                 registry, &older
8896:             ))
8897:             .is_none()
8898:         );
8899:         let foreign = crate::analyser::ResolvedAnalysisInput::new(
8900:             input.analyser_profile(),
8901:             input.unit_profile(),
8902:             tcl_registry::model::ingress::resolve_environment("tcl9.1").default_context_registry(),
8903:             input.lexer_config(),
8904:         );
8905:         assert!(
8906:             select(InvocationMetadataContext::for_analysis_input(
8907:                 registry, &foreign
8908:             ))
8909:             .is_none()
8910:         );
8911:         let mut changed_config = input.lexer_config();
8912:         changed_config.strict_quoting = !changed_config.strict_quoting;
8913:         assert_ne!(
8914:             changed_config.normalized(),
8915:             input.lexer_config().normalized()
8916:         );
8917:         let changed = crate::analyser::ResolvedAnalysisInput::new(
8918:             input.analyser_profile(),
8919:             input.unit_profile(),
8920:             Arc::clone(&context),
8921:             changed_config,
8922:         );
8923:         assert!(
8924:             select(InvocationMetadataContext::for_analysis_input(
8925:                 registry, &changed
8926:             ))
8927:             .is_none()
8928:         );
8929:         let mut unavailable_module = unit.ir_module.clone();
8930:         unavailable_module.source_metadata_input = None;
8931:         assert!(
8932:             select(function.invocation_metadata_context_for_module(registry, &unavailable_module))
8933:                 .is_none()
8934:         );
8935:     }
8936: 
8937:     #[test]
8938:     fn original_operand_symbols_keep_actual_availability_and_source_grammar() {
8939:         // naming.compiler.original-analysis-metadata-context
8940:         // docs/design/analysis/name-resolution-proofs/original-analysis-metadata-context.md
8941:         use crate::registry_invocation::InvocationMetadataContext;
8942:         use std::sync::Arc;
8943:         let (context, unit) = original_operand_metadata_fixture();
8944:         let function = &unit.top_level;
8945:         let input = function.source_metadata_input().unwrap();
8946:         let points = function.ssa.point_contexts.as_ref().unwrap();
8947:         let point = function
8948:             .cfg
8949:             .blocks
8950:             .iter()
8951:             .find_map(|(&block, body)| {
8952:                 body.statements
8953:                     .iter()
8954:                     .enumerate()
8955:                     .find_map(|(index, statement)| {
8956:                         statement
8957:                             .is_executable_invocation()
8958:                             .then_some((block, index))
8959:                     })
8960:             })
8961:             .unwrap();
8962:         let symbols = |metadata, config| {
8963:             let metadata = supplied_ssa_metadata(context.commands(), config, metadata);
8964:             let mut walk = RenameWalk::new(&function.cfg, config, points.clone(), metadata);
8965:             let mut symbols = HashMap::new();
8966:             walk.retain_native_operand_symbols(
8967:                 point,
8968:                 points.context_before(point.0, point.1).unwrap(),
8969:                 context.commands(),
8970:                 &mut symbols,
8971:             );
8972:             symbols
8973:         };
8974:         let metadata = InvocationMetadataContext::for_analysis_input(context.commands(), input);
8975:         assert_eq!(symbols(metadata, function.source_lexer_config()).len(), 1);
8976:         let older = Arc::new(
8977:             tcl_registry::model::ingress::static_context_for("tcl8.4")
8978:                 .with_command_store(Arc::clone(context.commands())),
8979:         );
8980:         assert!(Arc::ptr_eq(older.commands(), context.commands()));
8981:         let older_input = crate::analyser::ResolvedAnalysisInput::new(
8982:             input.analyser_profile(),
8983:             input.unit_profile(),
8984:             older,
8985:             input.lexer_config(),
8986:         );
8987:         assert!(
8988:             symbols(
8989:                 InvocationMetadataContext::for_analysis_input(context.commands(), &older_input,),
8990:                 function.source_lexer_config()
8991:             )
8992:             .is_empty()
8993:         );
8994:         assert!(symbols(None, function.source_lexer_config()).is_empty());
8995:         let foreign = crate::analyser::ResolvedAnalysisInput::new(
8996:             input.analyser_profile(),
8997:             input.unit_profile(),
8998:             tcl_registry::model::ingress::resolve_environment("tcl9.1").default_context_registry(),
8999:             input.lexer_config(),
9000:         );
9001:         assert!(
9002:             symbols(
9003:                 InvocationMetadataContext::for_analysis_input(context.commands(), &foreign,),
9004:                 function.source_lexer_config()
9005:             )
9006:             .is_empty()
9007:         );
9008:         let mut stale_config = function.source_lexer_config();
9009:         stale_config.strict_quoting = !stale_config.strict_quoting;
9010:         assert!(symbols(metadata, stale_config).is_empty());
9011:     }
9012: 
9013:     #[test]
9014:     fn destruction_predecessor_keeps_substituted_operand_use_in_def_use() {
9015:         for substituted in [false, true] {
9016:             let cfg = Function::new("::top", "entry");
9017:             let mut ssa = SsaFunction::trivial("::top", cfg.entry, cfg.block_names().to_vec());
9018:             let symbol = ssa.intern_var("x");
9019:             let mut statement = SsaStatement {
9020:                 statement: Statement::Call {
9021:                     span: Span::new(0, 8),
9022:                     command: "unset".into(),
9023:                     canonical_command: Some("::unset".into()),
9024:                     args: vec![if substituted { "$x" } else { "x" }.into()],
9025:                     defs: Vec::new(),
9026:                     reads: Vec::new(),
9027:                     reads_own_defs: false,
9028:                     safe_on_uninit: false,
9029:                     tokens: None,
9030:                     foreach_groups: None,
9031:                 },
9032:                 uses: if substituted {
9033:                     HashMap::from([(symbol, 1)])
9034:                 } else {
9035:                     HashMap::new()
9036:                 },
9037:                 defs: HashMap::from([(symbol, 2)]),
9038:                 may_defs: HashSet::from([symbol]),
9039:                 destruction_defs: HashSet::from([symbol]),
9040:                 quoted_uses: HashSet::new(),
9041:                 name_only_uses: HashSet::new(),
9042:             };
9043:             record_destruction_predecessor(
9044:                 symbol,
9045:                 1,
9046:                 &mut statement.uses,
9047:                 &mut statement.name_only_uses,
9048:             );
9049:             ssa.blocks.insert(
9050:                 cfg.entry,
9051:                 SsaBlock {
9052:                     name: "entry".into(),
9053:                     phis: Vec::new(),
9054:                     statements: vec![statement],
9055:                     entry_versions: HashMap::new(),
9056:                     exit_versions: HashMap::new(),
9057:                 },
9058:             );
9059:             let chains =
9060:                 crate::def_use::build_def_use_chains(&ssa, None, tcl_lexer::LexerConfig::default());
9061:             let uses = chains.uses_of(ssa.var_symbol("x").unwrap(), 1);
9062:             assert_eq!(uses.len(), 1);
9063:             assert_eq!(
9064:                 uses[0].class,
9065:                 if substituted {
9066:                     UseClass::Substituted
9067:                 } else {
9068:                     UseClass::Name
9069:                 }
9070:             );
9071:             assert_eq!(
9072:                 uses[0].kind,
9073:                 if substituted {
9074:                     crate::def_use::UseKind::Operand
9075:                 } else {
9076:                     crate::def_use::UseKind::VariableName
9077:                 }
9078:             );
9079:         }
9080:     }
9081: 
9082:     /// Intern `name` into `func` and insert a fresh block for it, returning
9083:     /// the [`BlockId`]. The shared test idiom for building a CFG by hand.
9084:     fn block(func: &mut Function, name: &str) -> BlockId {
9085:         let id = func.intern_block(name);
9086:         func.blocks.insert(id, Block::new(name));
9087:         id
9088:     }
9089: 
9090:     fn make_goto(target: BlockId) -> Terminator {
9091:         Terminator::Goto { target, span: None }
9092:     }
9093: 
9094:     fn make_branch(cond: &str, t: BlockId, f: BlockId) -> Terminator {
9095:         Terminator::Branch {
9096:             condition: ExprNode::Raw { text: cond.into() },
9097:             true_target: t,
9098:             false_target: f,
9099:             span: None,
9100:             condition_base: None,
9101:         }
9102:     }
9103: 
9104:     fn make_return() -> Terminator {
9105:         Terminator::Return {
9106:             tokens: None,
9107:             value: None,
9108:             value_word: None,
9109:             span: None,
9110:             expr: None,
9111:             expr_base: None,
9112:             braced: false,
9113:         }
9114:     }
9115: 
9116:     fn call(span: Span, command: &str, args: &[&str], defs: &[&str]) -> Statement {
9117:         Statement::Call {
9118:             span,
9119:             command: command.into(),
9120:             canonical_command: None,
9121:             args: args.iter().map(|arg| (*arg).into()).collect(),
9122:             defs: defs.iter().map(|name| (*name).into()).collect(),
9123:             reads: vec![],
9124:             reads_own_defs: false,
9125:             safe_on_uninit: false,
9126:             tokens: None,
9127:             foreach_groups: None,
9128:         }
9129:     }
9130: 
9131:     /// `(func, [entry, then, else, end])` for a diamond CFG:
9132:     /// entry → branch → then/else → end → return.
9133:     fn diamond_cfg() -> Function {
9134:         let mut func = Function::new("::test", "entry");
9135:         let entry = func.entry;
9136:         let then = block(&mut func, "then");
9137:         let els = block(&mut func, "else");
9138:         let end = block(&mut func, "end");
9139:         func.blocks.get_mut(&entry).unwrap().terminator = Some(make_branch("$x", then, els));
9140:         func.blocks.get_mut(&then).unwrap().terminator = Some(make_goto(end));
9141:         func.blocks.get_mut(&els).unwrap().terminator = Some(make_goto(end));
9142:         func.blocks.get_mut(&end).unwrap().terminator = Some(make_return());
9143:         func
9144:     }
9145: 
9146:     /// Build a loop CFG: entry → header → branch → body → header / end
9147:     fn loop_cfg() -> Function {
9148:         let mut func = Function::new("::test", "entry");
9149:         let entry = func.entry;
9150:         let header = block(&mut func, "header");
9151:         let body = block(&mut func, "body");
9152:         let end = block(&mut func, "end");
9153:         func.blocks.get_mut(&entry).unwrap().terminator = Some(make_goto(header));
9154:         func.blocks.get_mut(&header).unwrap().terminator = Some(make_branch("$i < 10", body, end));
9155:         func.blocks.get_mut(&body).unwrap().terminator = Some(make_goto(header));
9156:         func.blocks.get_mut(&end).unwrap().terminator = Some(make_return());
9157:         func
9158:     }
9159: 
9160:     /// Resolve a block name to its id in `func` (test convenience).
9161:     fn id_of(func: &Function, name: &str) -> BlockId {
9162:         func.block_id(name).expect("block name interned")
9163:     }
9164: 
9165:     // Data structure tests
9166: 
9167:     #[test]
9168:     fn phi_construction() {
9169:         let phi = Phi {
9170:             name: Symbol(0),
9171:             version: 3,
9172:             incoming: HashMap::from([(BlockId(1), 1), (BlockId(2), 2)]),
9173:         };
9174:         assert_eq!(phi.name, Symbol(0));
9175:         assert_eq!(phi.version, 3);
9176:         assert_eq!(phi.incoming.len(), 2);
9177:     }
9178: 
9179:     #[test]
9180:     fn ssa_statement_construction() {
9181:         let stmt = SsaStatement {
9182:             statement: Statement::AssignConst {
9183:                 span: Span::new(0, 10),
9184:                 name: "x".into(),
9185:                 name_braced: false,
9186:                 value: "1".into(),
9187:                 value_span: None,
9188:             },
9189:             uses: HashMap::new(),
9190:             defs: HashMap::from([(Symbol(0), 1)]),
9191:             may_defs: std::collections::HashSet::new(),
9192:             destruction_defs: std::collections::HashSet::new(),
9193:             quoted_uses: std::collections::HashSet::new(),
9194:             name_only_uses: std::collections::HashSet::new(),
9195:         };
9196:         assert_eq!(stmt.defs[&Symbol(0)], 1);
9197:         assert_eq!(stmt.uses.len(), 0);
9198:     }
9199: 
9200:     #[test]
9201:     fn ssa_block_construction() {
9202:         let block = SsaBlock {
9203:             name: "entry".into(),
9204:             phis: vec![],
9205:             statements: vec![],
9206:             entry_versions: HashMap::new(),
9207:             exit_versions: HashMap::from([(Symbol(0), 1)]),
9208:         };
9209:         assert_eq!(block.name, "entry");
9210:         assert_eq!(block.phis, [] as [crate::ssa::Phi; 0]);
9211:     }
9212: 
9213:     #[test]
9214:     fn array_relationships_use_physical_kinds_instead_of_key_text() {
9215:         let mut elements = ArrayElems::default();
9216:         elements.note(crate::place::scalar("literal(parenthesis)", "::", false));
9217:         assert!(elements.elements.is_empty());
9218:         let element = crate::place::array_elem(
9219:             "a",
9220:             crate::place::Index::literal("key"),
9221:             "::N(parenthesis)",
9222:             false,
9223:         );
9224:         let element_key = crate::var_resolve::canonical_binding_value_key(&element).unwrap();
9225:         let mut root = element.clone();
9226:         root.kind = crate::place::PlaceKind::ArrayWhole;
9227:         root.index = None;
9228:         let root_key = crate::var_resolve::canonical_binding_value_key(&root).unwrap();
9229:         elements.note(element);
9230:         assert_eq!(elements.root_for_element(&element_key), Some(&root_key));
9231:         assert_eq!(
9232:             expand_defs(std::slice::from_ref(&element_key), &elements),
9233:             vec![element_key, root_key]
9234:         );
9235:     }
9236: 
9237:     #[test]
9238:     fn array_refresh_preserves_parentheses_in_its_namespace_identity() {
9239:         let registry = tcl_registry::model::ingress::static_context_for("tcl8.6").commands();
9240:         let unit = crate::compilation_unit::CompilationUnit::build_for(
9241:             "namespace eval {::N(parenthesis)} {proc p {} {variable a; set a(key) OLD; set a(key) NEW; return $a(key)}}",
9242:             registry,
9243:             false,
9244:         );
9245:         let function = unit.function("::N(parenthesis)::p").unwrap();
9246:         let root = function
9247:             .ssa
9248:             .cell_symbol("::N(parenthesis)::a")
9249:             .expect("qualified physical root");
9250:         assert!(function.ssa.is_array_root_refresh_symbol(root));
9251:         assert_eq!(function.ssa.cell_symbol("::N"), None);
9252:     }
9253: 
9254:     #[test]
9255:     fn scalar_recreation_does_not_inherit_array_refresh_classification() {
9256:         let registry = tcl_registry::model::ingress::static_context_for("tcl8.6").commands();
9257:         let source = "proc f {} {set a(key) OLD; unset a; set a 5; return $a}";
9258:         let unit = crate::compilation_unit::CompilationUnit::build_for(source, registry, false);
9259:         let function = unit.function("::f").unwrap();
9260:         let mut refreshes = HashSet::new();
9261:         let mut scalar_stores = HashSet::new();
9262:         for statement in function
9263:             .ssa
9264:             .blocks
9265:             .values()
9266:             .flat_map(|block| &block.statements)
9267:         {
9268:             for (&symbol, &version) in &statement.defs {
9269:                 if function.ssa.is_array_root_refresh_version(symbol, version) {
9270:                     assert!(!function.ssa.is_array_root_refresh_symbol(symbol));
9271:                     if source
9272:                         .get(statement.statement.span().start() as usize..)
9273:                         .is_some_and(|written| written.starts_with("set a(key) OLD"))
9274:                     {
9275:                         refreshes.insert(statement.statement.span().start());
9276:                     }
9277:                 }
9278:                 if source
9279:                     .get(statement.statement.span().start() as usize..)
9280:                     .is_some_and(|written| written.starts_with("set a 5"))
9281:                 {
9282:                     scalar_stores.insert(statement.statement.span().start());
9283:                     assert!(!function.ssa.is_array_root_refresh_version(symbol, version));
9284:                 }
9285:             }
9286:         }
9287:         // The element store refreshes its aggregate root, and recreation
9288:         // writes a scalar. Destruction may carry a separate invalidation.
9289:         assert_eq!(refreshes.len(), 1);
9290:         assert_eq!(scalar_stores.len(), 1);
9291:     }
9292: 
9293:     #[test]
9294:     fn synthetic_array_root_refresh_is_not_dictionary_value_contents() {
9295:         for profile in ["tcl8.6", "jim"] {
9296:             let registry = tcl_registry::model::ingress::static_context_for(profile).commands();
9297:             let unit = crate::compilation_unit::CompilationUnit::build_for(
9298:                 "proc f {} {set a(key) OLD; set a(key) NEW; return $a(key)}",
9299:                 registry,
9300:                 false,
9301:             );
9302:             let function = unit.function("::f").unwrap();
9303:             let refreshes: Vec<_> = function
9304:                 .ssa
9305:                 .cell_names()
9306:                 .iter()
9307:                 .enumerate()
9308:                 .filter_map(|(index, name)| {
9309:                     let symbol = Symbol(u32::try_from(index).unwrap());
9310:                     function
9311:                         .ssa
9312:                         .is_array_root_refresh_symbol(symbol)
9313:                         .then_some(name)
9314:                 })
9315:                 .collect();
9316:             if profile == "tcl8.6" {
9317:                 assert_eq!(refreshes.len(), 1, "{refreshes:?}");
9318:             } else {
9319:                 assert!(refreshes.is_empty(), "{refreshes:?}");
9320:             }
9321:         }
9322:     }
9323: 
9324:     #[test]
9325:     fn ssa_function_construction() {
9326:         let func = SsaFunction {
9327:             name: "::test".into(),
9328:             entry: BlockId(0),
9329:             blocks: HashMap::new(),
9330:             value_clobbers: HashMap::new(),
9331:             idom: HashMap::new(),
9332:             dominance_frontier: HashMap::new(),
9333:             dominator_tree: HashMap::new(),
9334:             block_names: vec!["entry".into()],
9335:             var_names: Vec::new(),
9336:             cell_names: Vec::new(),
9337:             cell_keys: Vec::new(),
9338:             cell_indices: Vec::new(),
9339:             source_variables: FxHashMap::default(),
9340:             source_may_effects: HashMap::new(),
9341:             source_topology: HashMap::new(),
9342:             var_to_symbol: rustc_hash::FxHashMap::default(),
9343:             cell_to_symbol: rustc_hash::FxHashMap::default(),
9344:             point_symbols: HashMap::new(),
9345:             point_contexts: None,
9346:             read_references: HashMap::new(),
9347:             source_read_references: HashMap::new(),
9348:             array_root_refresh_symbols: HashSet::new(),
9349:             array_root_refresh_versions: HashSet::new(),
9350:             unseen_call_versions: HashSet::new(),
9351:         };
9352:         assert_eq!(func.name, "::test");
9353:     }
9354: 
9355:     #[test]
9356:     fn var_interner_assigns_first_seen_order_symbols() {
9357:         let mut func = SsaFunction::trivial("::test", BlockId(0), vec!["entry".into()]);
9358:         let x = func.intern_var("x");
9359:         let y = func.intern_var("y");
9360:         assert_eq!(x, Symbol(0));
9361:         assert_eq!(y, Symbol(1));
9362:         // Re-interning a known name returns the existing symbol.
9363:         assert_eq!(func.intern_var("x"), x);
9364:         assert_eq!(func.var_symbol("y"), Some(y));
9365:         assert_eq!(func.var_symbol("missing"), None);
9366:         assert_eq!(func.var_name(x), "x");
9367:         assert_eq!(func.var_names(), ["x".to_string(), "y".to_string()]);
9368:     }
9369: 
9370:     // defs_of tests
9371: 
9372:     #[test]
9373:     fn defs_of_assign_const() {
9374:         let stmt = Statement::AssignConst {
9375:             span: Span::new(0, 10),
9376:             name: "x".into(),
9377:             name_braced: false,
9378:             value: "1".into(),
9379:             value_span: None,
9380:         };
9381:         assert_eq!(defs_of(&stmt), vec!["x"]);
9382:     }
9383: 
9384:     #[test]
9385:     fn defs_of_dynamic_target_name_has_no_static_def() {
9386:         // `set $p 1` / `set ${p} 1` write the variable *named by* `$p`, not
9387:         // `p` itself — an opaque place, so there is no static def.
9388:         for name in ["$p", "${p}", "a$b", "[gen]"] {
9389:             let stmt = Statement::AssignValue {
9390:                 span: Span::new(0, 10),
9391:                 name: name.into(),
9392:                 name_braced: false,
9393:                 value: "1".into(),
9394:                 value_needs_backsubst: false,
9395:                 tokens: None,
9396:             };
9397:             assert_eq!(
9398:                 defs_of(&stmt).len(),
9399:                 0,
9400:                 "dynamic target {name:?} must not be a static def"
9401:             );
9402:         }
9403:         // A constant-keyed array element defs its own per-element variable
9404:         // (the rename walk adds the base def alongside); a dynamic key
9405:         // stays on the base.
9406:         let arr = Statement::AssignValue {
9407:             span: Span::new(0, 10),
9408:             name: "arr(idx)".into(),
9409:             name_braced: false,
9410:             value: "1".into(),
9411:             value_needs_backsubst: false,
9412:             tokens: None,
9413:         };
9414:         assert_eq!(defs_of(&arr), vec!["arr(idx)"]);
9415:         let dyn_key = Statement::AssignValue {
9416:             span: Span::new(0, 10),
9417:             name: "arr($i)".into(),
9418:             name_braced: false,
9419:             value: "1".into(),
9420:             value_needs_backsubst: false,
9421:             tokens: None,
9422:         };
9423:         assert_eq!(defs_of(&dyn_key), vec!["arr"]);
9424:         // Braces suppress substitution: the key is the literal text `$i`.
9425:         let braced = Statement::AssignValue {
9426:             span: Span::new(0, 10),
9427:             name: "arr($i)".into(),
9428:             name_braced: true,
9429:             value: "1".into(),
9430:             value_needs_backsubst: false,
9431:             tokens: None,
9432:         };
9433:         assert_eq!(defs_of(&braced), vec!["arr($i)"]);
9434:     }
9435: 
9436:     #[test]
9437:     fn is_dynamic_write_target_classifies_names() {
9438:         assert!(is_dynamic_write_target("$p", false));
9439:         assert!(is_dynamic_write_target("${p}", false));
9440:         assert!(is_dynamic_write_target("a$b", false));
9441:         assert!(is_dynamic_write_target("[gen]", false));
9442:         assert!(!is_dynamic_write_target("p", false));
9443:         assert!(!is_dynamic_write_target("arr(idx)", false));
9444:         assert!(!is_dynamic_write_target("ns::var", false));
9445:     }
9446: 
9447:     #[test]
9448:     fn brace_quoted_write_target_is_not_dynamic() {
9449:         // `set {$n} 1` names the literal variable `$n`; the braces suppress
9450:         // every substitution, so nothing about the target is computed.
9451:         // tclsh 9.0.4 / 8.6.14 (identical):
9452:         //   set {$n} v; info exists {$n} → 1 ; info exists n → 0
9453:         assert!(!is_dynamic_write_target("$n", true));
9454:         assert!(!is_dynamic_write_target("${n}", true));
9455:         assert!(!is_dynamic_write_target("[gen]", true));
9456:         assert!(!is_dynamic_write_target("$a(k)", true));
9457:         // TN control: the same spellings *unbraced* are still dynamic.
9458:         assert!(is_dynamic_write_target("$n", false));
9459:         assert!(is_dynamic_write_target("[gen]", false));
9460:     }
9461: 
9462:     #[test]
9463:     fn defs_of_incr() {
9464:         let stmt = Statement::Incr {
9465:             span: Span::new(0, 10),
9466:             name: "i".into(),
9467:             name_braced: false,
9468:             amount: None,
9469:             amount_braced: false,
9470:             safe_on_uninit: false,
9471:         };
9472:         assert_eq!(defs_of(&stmt), vec!["i"]);
9473:     }
9474: 
9475:     #[test]
9476:     fn defs_of_call_with_defs() {
9477:         let stmt = Statement::Call {
9478:             span: Span::new(0, 20),
9479:             command: "lappend".into(),
9480:             canonical_command: None,
9481:             args: vec!["list".into(), "item".into()],
9482:             defs: vec!["list".into()],
9483:             reads: vec![],
9484:             reads_own_defs: true,
9485:             safe_on_uninit: false,
9486:             tokens: None,
9487:             foreach_groups: None,
9488:         };
9489:         assert_eq!(defs_of(&stmt), vec!["list"]);
9490:     }
9491: 
9492:     #[test]
9493:     fn defs_of_call_no_defs() {
9494:         let stmt = Statement::Call {
9495:             span: Span::new(0, 10),
9496:             command: "puts".into(),
9497:             canonical_command: None,
9498:             args: vec!["hello".into()],
9499:             defs: vec![],
9500:             reads: vec![],
9501:             reads_own_defs: false,
9502:             safe_on_uninit: false,
9503:             tokens: None,
9504:             foreach_groups: None,
9505:         };
9506:         assert_eq!(defs_of(&stmt), [] as [std::string::String; 0]);
9507:     }
9508: 
9509:     #[test]
9510:     fn defs_of_return() {
9511:         let stmt = Statement::Return {
9512:             tokens: None,
9513:             span: Span::new(0, 10),
9514:             value: Some("1".into()),
9515:             value_word: None,
9516:             expr: None,
9517:             expr_base: None,
9518:             command_binding: None,
9519:             braced: false,
9520:         };
9521:         assert_eq!(defs_of(&stmt), [] as [std::string::String; 0]);
9522:     }
9523: 
9524:     #[test]
9525:     fn defs_of_barrier_trace() {
9526:         let stmt = Statement::Barrier {
9527:             span: Span::new(0, 30),
9528:             reason: "trace".into(),
9529:             command: "trace".into(),
9530:             canonical_command: None,
9531:             args: vec!["add".into(), "variable".into(), "$x".into()],
9532:             tokens: None,
9533:         };
9534:         assert_eq!(defs_of(&stmt), vec!["x"]);
9535:     }
9536: 
9537:     #[test]
9538:     fn defs_of_barrier_dict_for() {
9539:         let stmt = Statement::Barrier {
9540:             span: Span::new(0, 30),
9541:             reason: "dict for".into(),
9542:             command: "dict::for".into(),
9543:             canonical_command: None,
9544:             args: vec!["k v".into(), "$d".into()],
9545:             tokens: None,
9546:         };
9547:         assert_eq!(defs_of(&stmt), vec!["k", "v"]);
9548:     }
9549: 
9550:     /// Loop-header barriers resolve via the registry's `loop_list_header`
9551:     /// flag — the ensemble-rewritten spellings work, and a user proc that
9552:     /// merely ENDS in `::for` does not have its first argument misread as
9553:     /// loop variables (the old suffix match did exactly that).
9554:     #[test]
9555:     fn defs_of_barrier_loop_header_via_registry() {
9556:         let reg = CommandRegistry::build_default();
9557:         let barrier = |command: &str| Statement::Barrier {
9558:             span: Span::new(0, 30),
9559:             reason: "loop".into(),
9560:             command: command.into(),
9561:             canonical_command: None,
9562:             args: vec!["k v".into(), "$d".into()],
9563:             tokens: None,
9564:         };
9565:         for cmd in ["::tcl::dict::for", "dict::for", "::tcl::dict::map"] {
9566:             assert_eq!(
9567:                 defs_of_with_registry(&barrier(cmd), Some(&reg)),
9568:                 vec!["k", "v"],
9569:                 "{cmd} is a registry loop-list-header subcommand"
9570:             );
9571:         }
9572:         assert_eq!(
9573:             defs_of_with_registry(&barrier("::tcl::array::for"), Some(&reg)),
9574:             vec!["k", "v"],
9575:             "array for shares the loop-list-header shape"
9576:         );
9577:         assert!(
9578:             !defs_of_with_registry(&barrier("my::for"), Some(&reg))
9579:                 .iter()
9580:                 .any(|d| d == "k" || d == "v"),
9581:             "a user proc ending in ::for must not be misread as a loop header"
9582:         );
9583:     }
9584: 
9585:     #[test]
9586:     fn defs_of_barrier_loop_header_uses_tcl_list_grammar() {
9587:         let reg = CommandRegistry::build_default();
9588:         let barrier = |var_list: &str| Statement::Barrier {
9589:             span: Span::new(0, 30),
9590:             reason: "loop".into(),
9591:             command: "::tcl::dict::for".into(),
9592:             canonical_command: None,
9593:             args: vec![var_list.into(), "$d".into()],
9594:             tokens: None,
9595:         };
9596: 
9597:         assert_eq!(
9598:             defs_of_with_registry(
9599:                 &barrier(r#"{one name} "two name" three\ name plain"#),
9600:                 Some(&reg),
9601:             ),
9602:             vec!["one name", "two name", "three name", "plain"],
9603:         );
9604:         assert_eq!(
9605:             defs_of_with_registry(&barrier("{unterminated"), Some(&reg)).len(),
9606:             0,
9607:             "a malformed var-list fails before defining loop variables"
9608:         );
9609:     }
9610: 
9611:     /// `tcltest::test` body indices come from the spec's arg-role resolver
9612:     /// (option-keyed `-setup`/`-body`/`-cleanup` values plus the legacy
9613:     /// positional body) via the generic `ArgRole::Body` walk, not a
9614:     /// `command == "test"` special case.
9615:     #[test]
9616:     fn structural_body_indices_tcltest_via_registry() {
9617:         use tcl_registry::ArgRole;
9618:         // This is a role-metadata query, not proof of a loaded source command.
9619:         let mut reg = CommandRegistry::build_default()
9620:             .project_for_profile(tcl_dialect::DialectProfile::find("tcl9.1").unwrap());
9621:         let unprovided = CommandRegistry::build_default()
9622:             .project_for_profile(tcl_dialect::DialectProfile::find("tcl9.1").unwrap());
9623:         reg.insert_ambient_package("tcltest", "2.5.8");
9624:         // Option form: -setup and -body values are Body roles; -result's is
9625:         // not. Both the qualified and the exported bare spelling resolve.
9626:         let option_form = [
9627:             "n",
9628:             "d",
9629:             "-setup",
9630:             "{set x 1}",
9631:             "-body",
9632:             "{incr x}",
9633:             "-result",
9634:             "2",
9635:         ];
9636:         let got = reg.arg_indices_for_role("tcltest::test", &option_form, ArgRole::Body);
9637:         assert_eq!(got, vec![3, 5], "option-form bodies via the option model");
9638:         assert_eq!(
9639:             unprovided.arg_indices_for_role("tcltest::test", &option_form, ArgRole::Body),
9640:             vec![3, 5],
9641:             "package assistance advertises roles without proving a loaded handler"
9642:         );
9643:         let unit = crate::compilation_unit::CompilationUnit::build_for(
9644:             "tcltest::test n d -body {set package_only 1}",
9645:             &unprovided,
9646:             false,
9647:         );
9648:         assert!(
9649:             unit.top_level.ssa.blocks.values().all(|block| block
9650:                 .statements
9651:                 .iter()
9652:                 .all(|statement| statement.defs.is_empty())),
9653:             "unprovided package role inventory cannot donate physical definitions"
9654:         );
9655:         // The bare `test` spelling is NOT a registry key: it resolves only
9656:         // through the lowering's namespace-import canonicalisation (which
9657:         // stamps `canonical_command` — threaded into the SSA lookups). A
9658:         // user proc that merely happens to be called `test` must not pick
9659:         // up tcltest body semantics, which the old string match caused.
9660:         assert_eq!(
9661:             reg.arg_indices_for_role("test", &option_form, ArgRole::Body)
9662:                 .len(),
9663:             0
9664:         );
9665:         // Legacy positional form: body is the penultimate argument.
9666:         let legacy = ["n", "d", "{incr x}", "1"];
9667:         let got = reg.arg_indices_for_role("tcltest::test", &legacy, ArgRole::Body);
9668:         assert_eq!(got, vec![2], "legacy positional body");
9669:         // Option form with NO body options marks nothing (and must not fall
9670:         // back to the positional branch: `-result` is not a body).
9671:         let no_body = ["n", "d", "-result", "2"];
9672:         let got = reg.arg_indices_for_role("tcltest::test", &no_body, ArgRole::Body);
9673:         assert_eq!(got.len(), 0, "no body options → no body roles: {got:?}");
9674:         // The generic structural walk consumes the same roles (braced-token
9675:         // filtering applies on real token streams; `None` tokens filter all,
9676:         // so only the empty expectation is assertable here).
9677:         let no_body_args: Vec<String> = no_body.iter().map(|s| (*s).to_string()).collect();
9678:         assert_eq!(
9679:             structural_body_indices("tcltest::test", &no_body_args, None, &reg).len(),
9680:             0
9681:         );
9682:     }
9683: 
9684:     /// `trace add variable` defs route through the registry's
9685:     /// `ArgRole::VarWrite` query rather than a string match.
9686:     #[test]
9687:     fn defs_of_barrier_trace_via_registry() {
9688:         let reg = CommandRegistry::build_default();
9689:         let stmt = Statement::Barrier {
9690:             span: Span::new(0, 30),
9691:             reason: "trace".into(),
9692:             command: "trace".into(),
9693:             canonical_command: None,
9694:             args: vec!["add".into(), "variable".into(), "$x".into()],
9695:             tokens: None,
9696:         };
9697:         assert_eq!(defs_of_with_registry(&stmt, Some(&reg)), vec!["x"]);
9698:     }
9699: 
9700:     /// `trace add execution` does NOT define a variable — the
9701:     /// command name being traced is not a `VarWrite` target.
9702:     #[test]
9703:     fn defs_of_barrier_trace_add_execution_no_def() {
9704:         let reg = CommandRegistry::build_default();
9705:         let stmt = Statement::Barrier {
9706:             span: Span::new(0, 30),
9707:             reason: "trace".into(),
9708:             command: "trace".into(),
9709:             canonical_command: None,
9710:             args: vec!["add".into(), "execution".into(), "foo".into()],
9711:             tokens: None,
9712:         };
9713:         assert_eq!(
9714:             defs_of_with_registry(&stmt, Some(&reg)),
9715:             [] as [std::string::String; 0]
9716:         );
9717:     }
9718: 
9719:     /// `global x y z` produces NO defs from the registry path
9720:     /// (`var_scoping` handles the per-arg list).  Without the
9721:     /// `CREATES_DYNAMIC_BARRIER` skip, the role-driven walk would
9722:     /// only mark `x` (partial defs) and miss `y` / `z`.
9723:     #[test]
9724:     fn defs_of_barrier_global_vararg_no_partial_defs() {
9725:         let reg = CommandRegistry::build_default();
9726:         let stmt = Statement::Barrier {
9727:             span: Span::new(0, 30),
9728:             reason: "global".into(),
9729:             command: "global".into(),
9730:             canonical_command: None,
9731:             args: vec!["x".into(), "y".into(), "z".into()],
9732:             tokens: None,
9733:         };
9734:         assert_eq!(
9735:             defs_of_with_registry(&stmt, Some(&reg)),
9736:             [] as [std::string::String; 0]
9737:         );
9738:     }
9739: 
9740:     /// `variable a b c` — same vararg-list shape as
9741:     /// `global`, same skip.
9742:     #[test]
9743:     fn defs_of_barrier_variable_vararg_no_partial_defs() {
9744:         let reg = CommandRegistry::build_default();
9745:         let stmt = Statement::Barrier {
9746:             span: Span::new(0, 30),
9747:             reason: "variable".into(),
9748:             command: "variable".into(),
9749:             canonical_command: None,
9750:             args: vec!["a".into(), "b".into(), "c".into()],
9751:             tokens: None,
9752:         };
9753:         assert_eq!(
9754:             defs_of_with_registry(&stmt, Some(&reg)),
9755:             [] as [std::string::String; 0]
9756:         );
9757:     }
9758: 
9759:     // Dominator tests
9760: 
9761:     #[test]
9762:     fn dominators_linear() {
9763:         // entry → b1 → b2 → return
9764:         let mut func = Function::new("::test", "entry");
9765:         let entry = func.entry;
9766:         let b1 = block(&mut func, "b1");
9767:         let b2 = block(&mut func, "b2");
9768:         func.blocks.get_mut(&entry).unwrap().terminator = Some(make_goto(b1));
9769:         func.blocks.get_mut(&b1).unwrap().terminator = Some(make_goto(b2));
9770:         func.blocks.get_mut(&b2).unwrap().terminator = Some(make_return());
9771: 
9772:         let dom = compute_dominators(&func);
9773:         assert_eq!(dom[&entry], HashSet::from([entry]));
9774:         assert_eq!(dom[&b1], HashSet::from([entry, b1]));
9775:         assert_eq!(dom[&b2], HashSet::from([entry, b1, b2]));
9776:     }
9777: 
9778:     #[test]
9779:     fn dominators_diamond() {
9780:         let func = diamond_cfg();
9781:         let entry = func.entry;
9782:         let (then, els, end) = (
9783:             id_of(&func, "then"),
9784:             id_of(&func, "else"),
9785:             id_of(&func, "end"),
9786:         );
9787:         let dom = compute_dominators(&func);
9788: 
9789:         // entry dominates everything
9790:         for id in func.blocks.keys() {
9791:             assert!(dom[id].contains(&entry));
9792:         }
9793:         // then and else are not dominated by each other
9794:         assert!(!dom[&then].contains(&els));
9795:         assert!(!dom[&els].contains(&then));
9796:         // end is dominated by entry but not by then or else
9797:         assert!(dom[&end].contains(&entry));
9798:         assert!(!dom[&end].contains(&then));
9799:         assert!(!dom[&end].contains(&els));
9800:     }
9801: 
9802:     #[test]
9803:     fn idom_diamond() {
9804:         let func = diamond_cfg();
9805:         let entry = func.entry;
9806:         let (then, els, end) = (
9807:             id_of(&func, "then"),
9808:             id_of(&func, "else"),
9809:             id_of(&func, "end"),
9810:         );
9811:         let dom = compute_dominators(&func);
9812:         let idom = compute_idom(&func, &dom);
9813: 
9814:         assert_eq!(idom[&entry], None);
9815:         assert_eq!(idom[&then], Some(entry));
9816:         assert_eq!(idom[&els], Some(entry));
9817:         assert_eq!(idom[&end], Some(entry));
9818:     }
9819: 
9820:     #[test]
9821:     fn idom_loop() {
9822:         let func = loop_cfg();
9823:         let entry = func.entry;
9824:         let (header, body, end) = (
9825:             id_of(&func, "header"),
9826:             id_of(&func, "body"),
9827:             id_of(&func, "end"),
9828:         );
9829:         let dom = compute_dominators(&func);
9830:         let idom = compute_idom(&func, &dom);
9831: 
9832:         assert_eq!(idom[&entry], None);
9833:         assert_eq!(idom[&header], Some(entry));
9834:         assert_eq!(idom[&body], Some(header));
9835:         assert_eq!(idom[&end], Some(header));
9836:     }
9837: 
9838:     #[test]
9839:     fn compute_idom_fast_matches_reference() {
9840:         // The production CHK path (`compute_idom_fast`) must produce
9841:         // exactly the same immediate dominators as the set-based
9842:         // reference (`compute_idom` over `compute_dominators`) across
9843:         // linear / diamond / loop shapes.
9844:         let mut linear = Function::new("::test", "entry");
9845:         let entry = linear.entry;
9846:         let b1 = block(&mut linear, "b1");
9847:         let b2 = block(&mut linear, "b2");
9848:         linear.blocks.get_mut(&entry).unwrap().terminator = Some(make_goto(b1));
9849:         linear.blocks.get_mut(&b1).unwrap().terminator = Some(make_goto(b2));
9850:         linear.blocks.get_mut(&b2).unwrap().terminator = Some(make_return());
9851: 
9852:         for func in [linear, diamond_cfg(), loop_cfg()] {
9853:             let reference = compute_idom(&func, &compute_dominators(&func));
9854:             let fast = compute_idom_fast(&func);
9855:             assert_eq!(fast, reference, "CHK idom diverged for {:?}", func.entry);
9856:         }
9857:     }
9858: 
9859:     #[test]
9860:     fn compute_idom_fast_handles_long_chain_without_blowup() {
9861:         // Generated dispatch procedures form long diamond chains; dominator
9862:         // computation must remain bounded on this shape.
9863:         let mut func = Function::new("::big", "b0");
9864:         let n = 4000;
9865:         for i in 0..n {
9866:             let cur = func.intern_block(format!("b{i}"));
9867:             func.blocks
9868:                 .entry(cur)
9869:                 .or_insert_with(|| Block::new(format!("b{i}")));
9870:             let then = block(&mut func, &format!("t{i}"));
9871:             let next = block(&mut func, &format!("b{}", i + 1));
9872:             func.blocks.get_mut(&then).unwrap().terminator = Some(make_return());
9873:             func.blocks.get_mut(&cur).unwrap().terminator = Some(make_branch("c", then, next));
9874:         }
9875:         let bn = id_of(&func, &format!("b{n}"));
9876:         func.blocks.get_mut(&bn).unwrap().terminator = Some(make_return());
9877:         let idom = compute_idom_fast(&func);
9878:         // Each chain block's idom is the previous chain block.
9879:         assert_eq!(idom[&id_of(&func, "b1")], Some(id_of(&func, "b0")));
9880:         assert_eq!(idom[&bn], Some(id_of(&func, &format!("b{}", n - 1))));
9881:         assert_eq!(idom[&id_of(&func, "b0")], None);
9882:     }
9883: 
9884:     #[test]
9885:     fn dominance_frontier_diamond() {
9886:         let func = diamond_cfg();
9887:         let entry = func.entry;
9888:         let (then, els, end) = (
9889:             id_of(&func, "then"),
9890:             id_of(&func, "else"),
9891:             id_of(&func, "end"),
9892:         );
9893:         let dom = compute_dominators(&func);
9894:         let idom = compute_idom(&func, &dom);
9895:         let df = compute_dominance_frontier(&func, &idom);
9896: 
9897:         // then and else have "end" in their dominance frontier
9898:         assert!(df[&then].contains(&end));
9899:         assert!(df[&els].contains(&end));
9900:         // entry has no dominance frontier
9901:         assert_eq!(df[&entry].len(), 0);
9902:     }
9903: 
9904:     #[test]
9905:     fn dominance_frontier_loop() {
9906:         let func = loop_cfg();
9907:         let entry = func.entry;
9908:         let (header, body) = (id_of(&func, "header"), id_of(&func, "body"));
9909:         let dom = compute_dominators(&func);
9910:         let idom = compute_idom(&func, &dom);
9911:         let df = compute_dominance_frontier(&func, &idom);
9912: 
9913:         // body has "header" in its dominance frontier (back edge)
9914:         assert!(df[&body].contains(&header));
9915:         // entry strictly dominates header, so header is NOT in entry's DF
9916:         assert_eq!(
9917:             df[&entry].len(),
9918:             0,
9919:             "entry's DF should be empty; got {:?}",
9920:             df[&entry]
9921:         );
9922:     }
9923: 
9924:     #[test]
9925:     fn dom_tree_diamond() {
9926:         let func = diamond_cfg();
9927:         let entry = func.entry;
9928:         let (then, els, end) = (
9929:             id_of(&func, "then"),
9930:             id_of(&func, "else"),
9931:             id_of(&func, "end"),
9932:         );
9933:         let dom = compute_dominators(&func);
9934:         let idom = compute_idom(&func, &dom);
9935:         let tree = build_dom_tree(&idom);
9936: 
9937:         // entry's children include then, else, end (all directly dominated)
9938:         let entry_children = &tree[&entry];
9939:         assert!(entry_children.contains(&els));
9940:         assert!(entry_children.contains(&end));
9941:         assert!(entry_children.contains(&then));
9942:     }
9943: 
9944:     // Phi placement tests
9945: 
9946:     #[test]
9947:     fn phi_vars_diamond_with_defs() {
9948:         // x defined in both then and else → phi needed at end
9949:         let mut func = diamond_cfg();
9950:         let entry = func.entry;
9951:         let (then, els, end) = (
9952:             id_of(&func, "then"),
9953:             id_of(&func, "else"),
9954:             id_of(&func, "end"),
9955:         );
9956:         func.blocks
9957:             .get_mut(&then)
9958:             .unwrap()
9959:             .statements
9960:             .push(Statement::AssignConst {
9961:                 span: Span::new(10, 20),
9962:                 name: "x".into(),
9963:                 name_braced: false,
9964:                 value: "1".into(),
9965:                 value_span: None,
9966:             });
9967:         func.blocks
9968:             .get_mut(&els)
9969:             .unwrap()
9970:             .statements
9971:             .push(Statement::AssignConst {
9972:                 span: Span::new(30, 40),
9973:                 name: "x".into(),
9974:                 name_braced: false,
9975:                 value: "2".into(),
9976:                 value_span: None,
9977:             });
9978: 
9979:         let dom = compute_dominators(&func);
9980:         let idom = compute_idom(&func, &dom);
9981:         let df = compute_dominance_frontier(&func, &idom);
9982:         let phi = compute_phi_vars(
9983:             &func,
9984:             &df,
9985:             &CommandRegistry::build_default(),
9986:             &ArrayElems::default(),
9987:         );
9988: 
9989:         let x = crate::var_resolve::canonical_literal_variable_key(
9990:             "x",
9991:             &ResolveContext::for_function(&func.name),
9992:             &CommandRegistry::build_default(),
9993:         )
9994:         .unwrap();
9995:         assert!(phi[&end].contains(&x), "x should need a phi at 'end'");
9996:         assert!(
9997:             !phi[&entry].contains(&x),
9998:             "x should not need a phi at entry"
9999:         );
10000:     }
10001: 
10002:     #[test]
10003:     fn phi_vars_single_def_no_phi() {
10004:         // x defined only in entry → no phi needed anywhere
10005:         let mut func = diamond_cfg();
10006:         let entry = func.entry;
10007:         func.blocks
10008:             .get_mut(&entry)
10009:             .unwrap()
10010:             .statements
10011:             .push(Statement::AssignConst {
10012:                 span: Span::new(0, 10),
10013:                 name: "x".into(),
10014:                 name_braced: false,
10015:                 value: "1".into(),
10016:                 value_span: None,
10017:             });
10018: 
10019:         let dom = compute_dominators(&func);
10020:         let idom = compute_idom(&func, &dom);
10021:         let df = compute_dominance_frontier(&func, &idom);
10022:         let phi = compute_phi_vars(
10023:             &func,
10024:             &df,
10025:             &CommandRegistry::build_default(),
10026:             &ArrayElems::default(),
10027:         );
10028: 
10029:         let x = crate::var_resolve::canonical_literal_variable_key(
10030:             "x",
10031:             &ResolveContext::for_function(&func.name),
10032:             &CommandRegistry::build_default(),
10033:         )
10034:         .unwrap();
10035:         for vars in phi.values() {
10036:             assert!(!vars.contains(&x), "x should not need a phi anywhere");
10037:         }
10038:     }
10039: 
10040:     #[test]
10041:     fn phi_vars_loop_def() {
10042:         // i defined in entry and body → phi at header
10043:         let mut func = loop_cfg();
10044:         let entry = func.entry;
10045:         let (header, body) = (id_of(&func, "header"), id_of(&func, "body"));
10046:         func.blocks
10047:             .get_mut(&entry)
10048:             .unwrap()
10049:             .statements
10050:             .push(Statement::AssignConst {
10051:                 span: Span::new(0, 10),
10052:                 name: "i".into(),
10053:                 name_braced: false,
10054:                 value: "0".into(),
10055:                 value_span: None,
10056:             });
10057:         func.blocks
10058:             .get_mut(&body)
10059:             .unwrap()
10060:             .statements
10061:             .push(Statement::Incr {
10062:                 span: Span::new(30, 40),
10063:                 name: "i".into(),
10064:                 name_braced: false,
10065:                 amount: None,
10066:                 amount_braced: false,
10067:                 safe_on_uninit: false,
10068:             });
10069: 
10070:         let dom = compute_dominators(&func);
10071:         let idom = compute_idom(&func, &dom);
10072:         let df = compute_dominance_frontier(&func, &idom);
10073:         let phi = compute_phi_vars(
10074:             &func,
10075:             &df,
10076:             &CommandRegistry::build_default(),
10077:             &ArrayElems::default(),
10078:         );
10079: 
10080:         let i = crate::var_resolve::canonical_literal_variable_key(
10081:             "i",
10082:             &ResolveContext::for_function(&func.name),
10083:             &CommandRegistry::build_default(),
10084:         )
10085:         .unwrap();
10086:         assert!(phi[&header].contains(&i), "i should need a phi at 'header'");
10087:     }
10088: 
10089:     #[test]
10090:     fn phi_vars_no_defs_no_phis() {
10091:         let func = diamond_cfg();
10092:         let dom = compute_dominators(&func);
10093:         let idom = compute_idom(&func, &dom);
10094:         let df = compute_dominance_frontier(&func, &idom);
10095:         let phi = compute_phi_vars(
10096:             &func,
10097:             &df,
10098:             &CommandRegistry::build_default(),
10099:             &ArrayElems::default(),
10100:         );
10101: 
10102:         for vars in phi.values() {
10103:             assert_eq!(vars.len(), 0, "no defs → no phis");
10104:         }
10105:     }
10106: 
10107:     // uses_of tests
10108: 
10109:     fn default_registry() -> CommandRegistry {
10110:         CommandRegistry::build_default()
10111:     }
10112: 
10113:     #[test]
10114:     fn lowered_literal_read_names_keep_empty_and_dollar_data() {
10115:         // Public native literal-name cases: experiments/name-handling/results/frame-local-name-geometry.
10116:         let (context, unit) = logical_metadata_fixture("info exists {}; info exists {$name}");
10117:         let registry = context.commands();
10118:         let metadata = unit
10119:             .top_level
10120:             .invocation_metadata_context_for_module(registry, &unit.ir_module)
10121:             .expect("actual retained Logical source input");
10122:         let selection = SsaInvocationContext::supplied(registry, Some(metadata));
10123:         let mut scanner = VarReferenceScanner::with_config(
10124:             VarScanOptions::default(),
10125:             unit.top_level.source_lexer_config(),
10126:         );
10127:         let reads: Vec<_> = unit
10128:             .ir_module
10129:             .top_level
10130:             .statements
10131:             .iter()
10132:             .map(|statement| uses_of_classified_in_context(statement, &mut scanner, selection))
10133:             .collect();
10134:         assert!(
10135:             reads[0].contains(&(String::new(), UseClass::Name)),
10136:             "{reads:?}"
10137:         );
10138:         assert!(
10139:             reads[1].contains(&("$name".to_owned(), UseClass::Name)),
10140:             "{reads:?}"
10141:         );
10142:         assert!(
10143:             !reads[1].iter().any(|(name, _)| name == "name"),
10144:             "{reads:?}"
10145:         );
10146:     }
10147: 
10148:     #[test]
10149:     fn readonly_logical_roles_retain_source_reads_without_normal_or_native_ownership() {
10150:         let (context, unit) = logical_metadata_fixture("info exists {}; info exists {$name}");
10151:         let registry = context.commands();
10152:         let metadata = unit
10153:             .top_level
10154:             .invocation_metadata_context_for_module(registry, &unit.ir_module)
10155:             .unwrap();
10156:         let selection = SsaInvocationContext::supplied(registry, Some(metadata));
10157:         for statement in &unit.ir_module.top_level.statements {
10158:             let tokens = statement.tokens().unwrap();
10159:             assert!(selection.logical_structure(tokens).is_some());
10160:             assert!(selection.normal(tokens).is_none());
10161:             assert!(
10162:                 tokens
10163:                     .source_binding
10164:                     .as_ref()
10165:                     .unwrap()
10166:                     .variable_context
10167:                     .interpreter
10168:                     .is_none()
10169:             );
10170:             assert!(
10171:                 tokens
10172:                     .source_binding
10173:                     .as_ref()
10174:                     .unwrap()
10175:                     .variable_context
10176:                     .execution
10177:                     .is_none()
10178:             );
10179:         }
10180:     }
10181: 
10182:     #[test]
10183:     fn readonly_logical_roles_keep_unknown_read_hazards_after_unclosed_commands() {
10184:         let (context, unit) =
10185:             logical_metadata_fixture("info exists {}; opaque_reader; info exists {$name}");
10186:         let registry = context.commands();
10187:         let metadata = unit
10188:             .top_level
10189:             .invocation_metadata_context_for_module(registry, &unit.ir_module)
10190:             .unwrap();
10191:         let selection = SsaInvocationContext::supplied(registry, Some(metadata));
10192:         let statement = unit.ir_module.top_level.statements.last().unwrap();
10193:         assert!(
10194:             selection
10195:                 .logical_structure(statement.tokens().unwrap())
10196:                 .is_none()
10197:         );
10198:         let mut scanner = VarReferenceScanner::with_config(
10199:             VarScanOptions::default(),
10200:             unit.top_level.source_lexer_config(),
10201:         );
10202:         assert!(
10203:             uses_of_classified_in_context(statement, &mut scanner, selection)
10204:                 .iter()
10205:                 .any(|(name, _)| name == "name")
10206:         );
10207:     }
10208: 
10209:     #[test]
10210:     fn quiet_logical_scalar_mutations_keep_original_names_without_numeric_or_normal_results() {
10211:         let (context, unit) =
10212:             logical_metadata_fixture("incr {}; incr {$counter}; info exists {$counter}");
10213:         let registry = context.commands();
10214:         let metadata = unit
10215:             .top_level
10216:             .invocation_metadata_context_for_module(registry, &unit.ir_module)
10217:             .unwrap();
10218:         let selection = SsaInvocationContext::supplied(registry, Some(metadata));
10219:         let mut scanner = VarReferenceScanner::with_config(
10220:             VarScanOptions::default(),
10221:             unit.top_level.source_lexer_config(),
10222:         );
10223:         for (statement, expected) in unit
10224:             .ir_module
10225:             .top_level
10226:             .statements
10227:             .iter()
10228:             .zip(["", "$counter", "$counter"])
10229:         {
10230:             let tokens = unit
10231:                 .ir_module
10232:                 .top_level
10233:                 .retained_source_tokens_for_statement(statement)
10234:                 .expect("original consumed or direct source words");
10235:             assert!(selection.logical_structure(tokens).is_some());
10236:             assert!(selection.normal(tokens).is_none());
10237:             let variables = &tokens.source_binding.as_ref().unwrap().variable_context;
10238:             assert!(variables.interpreter.is_none());
10239:             assert!(variables.execution.is_none());
10240:             assert!(variables.literal_value(expected, registry).is_none());
10241:             let reads =
10242:                 uses_of_classified_with_source(statement, &mut scanner, selection, Some(tokens));
10243:             assert!(
10244:                 reads.contains(&(expected.to_owned(), UseClass::Name)),
10245:                 "{reads:?}"
10246:             );
10247:             assert!(
10248:                 !reads.iter().any(|(name, _)| name == "counter"),
10249:                 "{reads:?}"
10250:             );
10251:         }
10252:     }
10253: 
10254:     #[test]
10255:     fn dynamic_scalar_targets_keep_later_unknown_read_hazards() {
10256:         let (context, unit) = logical_metadata_fixture("incr {}; incr $name; incr {$counter}");
10257:         let registry = context.commands();
10258:         let metadata = unit
10259:             .top_level
10260:             .invocation_metadata_context_for_module(registry, &unit.ir_module)
10261:             .unwrap();
10262:         let selection = SsaInvocationContext::supplied(registry, Some(metadata));
10263:         let statement = unit.ir_module.top_level.statements.last().unwrap();
10264:         assert!(
10265:             selection
10266:                 .logical_structure(statement.tokens().unwrap())
10267:                 .is_none()
10268:         );
10269:         let mut scanner = VarReferenceScanner::with_config(
10270:             VarScanOptions::default(),
10271:             unit.top_level.source_lexer_config(),
10272:         );
10273:         assert!(
10274:             uses_of_classified_in_context(statement, &mut scanner, selection)
10275:                 .iter()
10276:                 .any(|(name, _)| name == "counter")
10277:         );
10278:     }
10279: 
10280:     #[test]
10281:     fn quiet_logical_scalar_mutation_withdraws_prior_literal_contents() {
10282:         let (context, unit) =
10283:             logical_metadata_fixture("set counter 9; incr counter; info exists counter");
10284:         let registry = context.commands();
10285:         let statements = &unit.ir_module.top_level.statements;
10286:         let before_update = &unit
10287:             .ir_module
10288:             .top_level
10289:             .retained_source_tokens_for_statement(&statements[1])
10290:             .expect("original scalar update source words")
10291:             .source_binding
10292:             .as_ref()
10293:             .unwrap()
10294:             .variable_context;
10295:         assert_eq!(before_update.literal_value("counter", registry), Some("9"));
10296:         let after_update = &unit
10297:             .ir_module
10298:             .top_level
10299:             .retained_source_tokens_for_statement(&statements[2])
10300:             .expect("original post-update source words")
10301:             .source_binding
10302:             .as_ref()
10303:             .unwrap()
10304:             .variable_context;
10305:         assert!(after_update.literal_value("counter", registry).is_none());
10306:         assert!(!after_update.dynamic_bindings);
10307:         assert!(!after_update.dynamic_traces);
10308:     }
10309: 
10310:     #[test]
10311:     fn empty_dictionary_scope_source_phases_keep_original_names_and_unknown_alias_contents() {
10312:         let (context, unit) = logical_metadata_fixture(
10313:             "set protected VALUE; dict with {} {}; dict with {$dict} {# comment only\n}; info exists {$dict}",
10314:         );
10315:         let registry = context.commands();
10316:         let metadata = unit
10317:             .top_level
10318:             .invocation_metadata_context_for_module(registry, &unit.ir_module)
10319:             .unwrap();
10320:         let selection = SsaInvocationContext::supplied(registry, Some(metadata));
10321:         let script = &unit.ir_module.top_level;
10322:         let before = script
10323:             .retained_source_tokens_for_statement(&script.statements[1])
10324:             .unwrap();
10325:         assert_eq!(
10326:             before
10327:                 .source_binding
10328:                 .as_ref()
10329:                 .unwrap()
10330:                 .variable_context
10331:                 .literal_value("protected", registry),
10332:             Some("VALUE")
10333:         );
10334:         let mut scanner = VarReferenceScanner::with_config(
10335:             VarScanOptions::default(),
10336:             unit.top_level.source_lexer_config(),
10337:         );
10338:         for (statement, expected) in script.statements[1..].iter().zip(["", "$dict", "$dict"]) {
10339:             let tokens = script
10340:                 .retained_source_tokens_for_statement(statement)
10341:                 .unwrap();
10342:             assert!(selection.logical_structure(tokens).is_some());
10343:             assert!(selection.normal(tokens).is_none());
10344:             let reads = uses_of_classified_in_context(statement, &mut scanner, selection);
10345:             assert!(
10346:                 reads.contains(&(expected.to_owned(), UseClass::Name)),
10347:                 "{reads:?}"
10348:             );
10349:             assert!(!reads.iter().any(|(name, _)| name == "dict"));
10350:         }
10351:         let tokens = script
10352:             .retained_source_tokens_for_statement(script.statements.last().unwrap())
10353:             .unwrap();
10354:         let variables = &tokens.source_binding.as_ref().unwrap().variable_context;
10355:         assert!(variables.literal_value("protected", registry).is_none());
10356:         assert!(!variables.dynamic_bindings);
10357:         assert!(!variables.dynamic_traces);
10358:         assert!(variables.interpreter.is_none());
10359:         assert!(variables.execution.is_none());
10360:     }
10361: 
10362:     fn dictionary_effect_fixture(
10363:         access: tcl_registry::world_effect::StaticEffectAccess,
10364:     ) -> (
10365:         std::sync::Arc<tcl_registry::model::ContextRegistry>,
10366:         crate::compilation_unit::CompilationUnit,
10367:     ) {
10368:         use std::sync::Arc;
10369:         use tcl_registry::world_effect::{
10370:             CallbackEffect, StaticEffectFootprint, WorldEffectDescriptor,
10371:         };
10372:         let baseline = tcl_registry::model::ingress::static_context_for("tcl8.6");
10373:         let mut registry = baseline
10374:             .commands()
10375:             .project_for_profile(tcl_dialect::DialectProfile::find("tcl8.6").unwrap());
10376:         let mut info = registry.get("info").unwrap().clone();
10377:         info.surface = Some(tcl_dialect::model::SpecSurface::TCL86_PLUS);
10378:         registry.insert(info);
10379:         let mut dictionary = registry.get("dict").unwrap().clone();
10380:         let mut subcommands = dictionary.subcommands.to_vec();
10381:         subcommands
10382:             .iter_mut()
10383:             .find(|subcommand| subcommand.name == "with")
10384:             .unwrap()
10385:             .world_effects = Some(WorldEffectDescriptor {
10386:             static_footprint: StaticEffectFootprint {
10387:                 accesses: Box::leak(vec![access].into_boxed_slice()),
10388:                 callback: CallbackEffect::NONE,
10389:             },
10390:             ..WorldEffectDescriptor::EMPTY
10391:         });
10392:         dictionary.subcommands = Box::leak(subcommands.into_boxed_slice());
10393:         registry.insert(dictionary);
10394:         let context = Arc::new(baseline.with_command_store(Arc::new(registry)));
10395:         let profile = tcl_dialect::DialectProfile::plain_tcl();
10396:         let config = tcl_lexer::LexerConfig::for_file_grammar(profile.grammar);
10397:         let input = crate::analyser::ResolvedAnalysisInput::new(
10398:             profile,
10399:             profile,
10400:             Arc::clone(&context),
10401:             config,
10402:         );
10403:         let entry =
10404:             crate::command_binding::SourceAnalysisEntry::for_logical_source(&input).unwrap();
10405:         let unit = crate::compilation_unit::CompilationUnit::build_with_analysis_input(
10406:             "dict with {} {}; info exists {$name}",
10407:             crate::compilation_unit::UnitBuildOptions {
10408:                 registry: context.commands(),
10409:                 defer_top_level: false,
10410:                 config,
10411:                 dialect: Some(profile),
10412:                 external_call_sites: None,
10413:                 declared_commands: None,
10414:             },
10415:             Some(&entry),
10416:             &input,
10417:         );
10418:         (context, unit)
10419:     }
10420: 
10421:     #[test]
10422:     fn dictionary_source_phases_refuse_unrepresented_explicit_writes() {
10423:         use tcl_registry::world_effect::{
10424:             EffectAccessMode, StaticEffectAccess, StaticInterpreterScope, StaticNamespaceScope,
10425:             StaticSubjectScope, WorldStateDomain,
10426:         };
10427:         for (domain, mode, namespace, subject) in [
10428:             (
10429:                 WorldStateDomain::VariableTraces,
10430:                 EffectAccessMode::Write,
10431:                 StaticNamespaceScope::Current,
10432:                 StaticSubjectScope::Wildcard,
10433:             ),
10434:             (
10435:                 WorldStateDomain::VariableTraces,
10436:                 EffectAccessMode::ReadWrite,
10437:                 StaticNamespaceScope::Current,
10438:                 StaticSubjectScope::Wildcard,
10439:             ),
10440:             (
10441:                 WorldStateDomain::VariableStore,
10442:                 EffectAccessMode::Write,
10443:                 StaticNamespaceScope::Named("::foreign"),
10444:                 StaticSubjectScope::Named("extra"),
10445:             ),
10446:             (
10447:                 WorldStateDomain::VariableStore,
10448:                 EffectAccessMode::Write,
10449:                 StaticNamespaceScope::Any,
10450:                 StaticSubjectScope::Wildcard,
10451:             ),
10452:             (
10453:                 WorldStateDomain::VariableStore,
10454:                 EffectAccessMode::Write,
10455:                 StaticNamespaceScope::Current,
10456:                 StaticSubjectScope::Wildcard,
10457:             ),
10458:         ] {
10459:             let (context, unit) = dictionary_effect_fixture(StaticEffectAccess::new(
10460:                 domain,
10461:                 mode,
10462:                 StaticInterpreterScope::Current,
10463:                 namespace,
10464:                 subject,
10465:             ));
10466:             let registry = context.commands();
10467:             let metadata = unit
10468:                 .top_level
10469:                 .invocation_metadata_context_for_module(registry, &unit.ir_module)
10470:                 .unwrap();
10471:             let selection = SsaInvocationContext::supplied(registry, Some(metadata));
10472:             let script = &unit.ir_module.top_level;
10473:             let before = script
10474:                 .retained_source_tokens_for_statement(&script.statements[0])
10475:                 .unwrap();
10476:             assert!(
10477:                 selection.logical_structure(before).is_some(),
10478:                 "{domain:?} {namespace:?} {subject:?}"
10479:             );
10480:             let after = script
10481:                 .retained_source_tokens_for_statement(script.statements.last().unwrap())
10482:                 .unwrap();
10483:             assert!(
10484:                 selection.logical_structure(after).is_none(),
10485:                 "{domain:?} {namespace:?} {subject:?}"
10486:             );
10487:             assert!(selection.normal(after).is_none());
10488:         }
10489:     }
10490: 
10491:     #[test]
10492:     fn dictionary_scope_bodies_and_variable_observers_keep_lookup_hazards() {
10493:         for source in [
10494:             "dict with {} {opaque_body}; info exists {$name}",
10495:             "trace add variable protected write observer; dict with {} {}; info exists {$name}",
10496:             "dict with $target {}; info exists {$name}",
10497:         ] {
10498:             let (context, unit) = logical_metadata_fixture(source);
10499:             let registry = context.commands();
10500:             let metadata = unit
10501:                 .top_level
10502:                 .invocation_metadata_context_for_module(registry, &unit.ir_module)
10503:                 .unwrap();
10504:             let selection = SsaInvocationContext::supplied(registry, Some(metadata));
10505:             let script = &unit.ir_module.top_level;
10506:             let tokens = script
10507:                 .retained_source_tokens_for_statement(script.statements.last().unwrap())
10508:                 .unwrap();
10509:             assert!(selection.logical_structure(tokens).is_none(), "{source}");
10510:             assert!(selection.normal(tokens).is_none(), "{source}");
10511:         }
10512:     }
10513: 
10514:     #[test]
10515:     fn original_source_may_definitions_keep_source_identity_separate_from_locations() {
10516:         let (_, unit) = crate::interprocedural::logical_completion_unit(
10517:             "proc p {} {global g; set g 1}\np", "tcl8.6",
10518:         );
10519:         let function = &unit.top_level;
10520:         let sources: Vec<_> = function.ssa.source_variable_symbols().collect();
10521:         assert!(!sources.is_empty(), "actual retained hidden write must issue source geometry");
10522:         assert_eq!(function.ssa.cell_keys().len() + sources.len(), function.ssa.var_names().len());
10523:         for (symbol, source) in sources {
10524:             assert!(function.ssa.cell_key(symbol).is_none());
10525:             assert!(function.ssa.cell_name(symbol).is_none());
10526:             assert!(function.ssa.variable_symbols().any(|held| held == symbol));
10527:             assert!(function.ssa.cell_symbols().all(|(held, _)| held != symbol));
10528:             assert_eq!(function.def_use.source_variable_symbol(&function.ssa, symbol), Some(source));
10529:             assert!(function.ssa.source_variable_snapshot(symbol).is_some());
10530:             let mut reached = false;
10531:             for (&block, body) in &function.ssa.blocks {
10532:                 for (index, statement) in body.statements.iter().enumerate() {
10533:                     if let Some(&version) = statement.defs.get(&symbol) {
10534:                         reached = true;
10535:                         assert!(statement.may_defs.contains(&symbol));
10536:                         assert!(function.ssa.source_may_requires_unknown_at(block, index));
10537:                         assert_eq!(function.sccp.values.get(&(symbol, version)), Some(&crate::analyses::LatticeValue::Overdefined));
10538:                         assert_eq!(function.sccp.existence.get(&(symbol, version)), Some(&tcl_registry::value_transfer::Existence::MayBound));
10539:                         let mut stale = function.ssa.clone();
10540:                         let statement = &mut stale.blocks.get_mut(&block).unwrap().statements[index].statement;
10541:                         let Statement::Call { command, .. } = statement else { panic!("actual original call"); };
10542:                         command.push_str("-report-changed");
10543:                         assert!(stale.source_variable_snapshot(symbol).is_none());
10544:                         assert!(function.def_use.source_variable_symbol(&stale, symbol).is_none());
10545:                         assert!(stale.source_may_requires_unknown_at(block, index));
10546:                     }
10547:                 }
10548:             }
10549:             assert!(reached, "source identity must retain its actual definition point/version");
10550:         }
10551:     }
10552: 
10553:     #[test]
10554:     fn original_source_may_clobber_receipts_refuse_removed_or_changed_maps() {
10555:         let (_, unit) = crate::interprocedural::logical_completion_unit(
10556:             "proc p {} {global g; set g 1}\nset local before\np\nreturn [unknown_read]", "tcl8.6",
10557:         );
10558:         let ssa = &unit.top_level.ssa;
10559:         let mut reached = false;
10560:         for (&(block, index), effect) in &ssa.source_may_effects {
10561:             if effect.original.as_ref().is_none_or(|original| original.writes().is_empty()) { continue; }
10562:             reached = true;
10563:             assert!(ssa.source_may_clobber_is_current_at(block, index), "actual live location must have a producer-issued marker/clobber relation");
10564:             let held = effect.clobber.as_ref().unwrap();
10565:             assert!(!held.versions.is_empty());
10566:             assert!(is_unseen_call_marker(&ssa.blocks[&block].statements[held.marker_index].statement));
10567:             let mut stale = ssa.clone();
10568:             stale.value_clobbers.get_mut(&block).unwrap().remove(&held.marker_index);
10569:             assert!(is_unseen_call_marker(&stale.blocks[&block].statements[held.marker_index].statement));
10570:             assert!(!stale.source_may_clobber_is_current_at(block, index));
10571:             assert!(stale.source_may_requires_unknown_at(block, index));
10572:             let mut stale = ssa.clone();
10573:             stale.value_clobbers.get_mut(&block).unwrap().get_mut(&held.marker_index).unwrap().clear();
10574:             assert!(!stale.source_may_clobber_is_current_at(block, index), "empty clobber inventory is not closed coverage");
10575:             let mut stale = ssa.clone();
10576:             let versions = stale.value_clobbers.get_mut(&block).unwrap().get_mut(&held.marker_index).unwrap();
10577:             let (&symbol, &pair) = versions.iter().next().unwrap();
10578:             versions.insert(symbol, (pair.0, pair.1 + 1));
10579:             assert!(!stale.source_may_clobber_is_current_at(block, index));
10580:         }
10581:         assert!(reached, "genuine call source-MAY producer must be exercised");
10582:     }
10583: 
10584:     fn assert_original_source_may_joins(source: &str, minimum_calls: usize, has_loop: bool) {
10585:         let (_, unit) = crate::interprocedural::logical_completion_unit(source, "tcl8.6");
10586:         let function = &unit.top_level;
10587:         let sources: Vec<_> = function.ssa.source_variable_symbols().collect();
10588:         assert!(!sources.is_empty(), "actual hidden writes must issue source identities");
10589:         let mut cyclic = false;
10590:         for &start in function.cfg.blocks.keys() {
10591:             let mut pending = function.cfg.block_successors(start);
10592:             let mut seen = HashSet::new();
10593:             while let Some(next) = pending.pop() {
10594:                 if next == start { cyclic = true; break; }
10595:                 if seen.insert(next) { pending.extend(function.cfg.block_successors(next)); }
10596:             }
10597:         }
10598:         assert_eq!(cyclic, has_loop, "control must retain its actual CFG branch/backedge geometry");
10599:         for (symbol, variable) in sources {
10600:             assert!(function.ssa.cell_key(symbol).is_none());
10601:             assert_eq!(function.def_use.source_variable_symbol(&function.ssa, symbol), Some(variable));
10602:             let definitions: HashSet<_> = function.ssa.blocks.values().flat_map(|body| {
10603:                 body.statements.iter().filter_map(|statement| statement.defs.get(&symbol).copied())
10604:             }).collect();
10605:             assert!(definitions.len() >= minimum_calls, "each genuine call point must retain its own source MAY version");
10606:             let mut phis = HashMap::new();
10607:             for (&block, body) in &function.ssa.blocks {
10608:                 for phi in body.phis.iter().filter(|phi| phi.name == symbol) {
10609:                     assert!(!phi.incoming.is_empty());
10610:                     for (&predecessor, &version) in &phi.incoming {
10611:                         assert!(function.cfg.block_successors(predecessor).contains(&block));
10612:                         assert!(function.def_use.uses_of(symbol, version).iter().any(|use_site| {
10613:                             use_site.kind == crate::def_use::UseKind::PhiIncoming
10614:                                 && use_site.phi_version == phi.version && use_site.class == UseClass::Quoted
10615:                         }));
10616:                     }
10617:                     phis.insert(phi.version, (block, phi));
10618:                 }
10619:             }
10620:             assert!(!phis.is_empty(), "source definitions must use the existing SSA join algorithm");
10621:             let mut observed = false;
10622:             for (&block, body) in &function.ssa.blocks {
10623:                 if !matches!(&function.cfg.blocks[&block].terminator, Some(cfg::Terminator::Return { .. })) { continue; }
10624:                 let Some(&exit) = body.exit_versions.get(&symbol) else { continue; };
10625:                 if exit == 0 { continue; }
10626:                 let mut pending = vec![exit];
10627:                 let mut reaching = HashSet::new();
10628:                 while let Some(version) = pending.pop() {
10629:                     if !reaching.insert(version) { continue; }
10630:                     if let Some((_, phi)) = phis.get(&version) { pending.extend(phi.incoming.values().copied()); }
10631:                 }
10632:                 if !definitions.is_subset(&reaching) { continue; }
10633:                 observed = true;
10634:                 assert!(function.def_use.uses_of(symbol, exit).iter().any(|use_site| {
10635:                     use_site.kind == crate::def_use::UseKind::Terminator
10636:                         && use_site.block == body.name && use_site.class == UseClass::Quoted
10637:                 }));
10638:             }
10639:             assert!(observed, "the actual post-join observer must retain every reaching source definition");
10640:             let (&version, &(block, _)) = phis.iter().next().unwrap();
10641:             let mut stale = function.ssa.clone();
10642:             let phi = stale.blocks.get_mut(&block).unwrap().phis.iter_mut().find(|phi| phi.name == symbol && phi.version == version).unwrap();
10643:             phi.incoming.clear();
10644:             assert!(function.def_use.source_variable_symbol(&stale, symbol).is_none(), "same-source changed phi graph cannot reuse old chains");
10645:             let mut stale = function.ssa.clone();
10646:             let (_, body) = stale.blocks.iter_mut().find(|(_, body)| body.statements.iter().any(|statement| statement.uses.contains_key(&symbol))).unwrap();
10647:             let statement = body.statements.iter_mut().find(|statement| statement.uses.contains_key(&symbol)).unwrap();
10648:             statement.uses.remove(&symbol);
10649:             assert!(function.def_use.source_variable_symbol(&stale, symbol).is_none(), "same-source changed source use cannot reuse old chains");
10650:             let mut stale = function.ssa.clone();
10651:             stale.source_topology.get_mut(&block).unwrap().terminator = None;
10652:             assert!(function.def_use.source_variable_symbol(&stale, symbol).is_none(), "changed retained source topology cannot reuse old chains");
10653:             let mut stale = function.ssa.clone();
10654:             stale.idom.clear();
10655:             assert!(function.def_use.source_variable_symbol(&stale, symbol).is_none(), "changed SSA topology cannot reuse old chains");
10656:         }
10657:     }
10658: 
10659:     #[test]
10660:     fn original_source_may_branch_versions_reach_post_join_observers() {
10661:         assert_original_source_may_joins(
10662:             "proc p {} {global g; set g 1}\nif {$condition} {p} else {p}\nreturn [unknown_read]", 2, false,
10663:         );
10664:     }
10665: 
10666:     #[test]
10667:     fn original_source_may_loop_versions_reach_post_join_observers() {
10668:         assert_original_source_may_joins(
10669:             "proc p {} {global g; set g 1}\nwhile {$condition} {p}\nreturn [unknown_read]", 1, true,
10670:         );
10671:     }
10672: 
10673:     #[test]
10674:     fn conditional_logical_store_symbols_keep_original_empty_and_dollar_names() {
10675:         let (context, unit) = logical_metadata_fixture("set {$literal} 9; set {} 8");
10676:         let registry = context.commands();
10677:         let function = &unit.top_level;
10678:         let points = function.ssa.point_contexts.as_ref().unwrap();
10679:         let mut found = HashSet::new();
10680:         for (&block, data) in &function.cfg.blocks {
10681:             for (index, _) in data.statements.iter().enumerate() {
10682:                 let Some(store) =
10683:                     points.conditional_logical_scalar_store_at(block, index, registry)
10684:                 else {
10685:                     continue;
10686:                 };
10687:                 let place = store.definition_place(registry).unwrap();
10688:                 let key = crate::var_resolve::canonical_binding_value_key(&place).unwrap();
10689:                 let source = function.ssa.source_symbols_at(block, index).unwrap();
10690:                 let symbol = source
10691:                     .get(store.source_name())
10692:                     .expect("original conditional store name");
10693:                 assert_eq!(function.ssa.cell_key(*symbol), Some(&key));
10694:                 assert!(place.cell.as_ref().unwrap().interpreter.is_none());
10695:                 assert!(place.cell.as_ref().unwrap().execution.is_none());
10696:                 assert!(!source.contains_key("literal"));
10697:                 let tokens = points.source_tokens_at(block, index).unwrap();
10698:                 let metadata = function
10699:                     .invocation_metadata_context_for_module(registry, &unit.ir_module)
10700:                     .unwrap();
10701:                 assert!(
10702:                     SsaInvocationContext::supplied(registry, Some(metadata))
10703:                         .normal(tokens)
10704:                         .is_none()
10705:                 );
10706:                 found.insert(store.source_name().to_owned());
10707:             }
10708:         }
10709:         assert_eq!(found, HashSet::from(["$literal".to_owned(), String::new()]));
10710:     }
10711: 
10712:     #[test]
10713:     fn conditional_store_symbol_owner_refuses_after_dynamic_target_and_unknown_command() {
10714:         let (context, unit) = logical_metadata_fixture(
10715:             "set {$literal} 9; set $target 8; opaque_writer; set {$later} 7",
10716:         );
10717:         let registry = context.commands();
10718:         let function = &unit.top_level;
10719:         let points = function.ssa.point_contexts.as_ref().unwrap();
10720:         let mut checked = 0;
10721:         for (&block, data) in &function.cfg.blocks {
10722:             for (index, statement) in data.statements.iter().enumerate() {
10723:                 let Some(tokens) = statement.tokens() else {
10724:                     continue;
10725:                 };
10726:                 if tokens
10727:                     .argv_texts
10728:                     .get(1)
10729:                     .is_some_and(|name| name == "$later")
10730:                 {
10731:                     checked += 1;
10732:                     assert!(
10733:                         points
10734:                             .conditional_logical_scalar_store_at(block, index, registry)
10735:                             .is_none()
10736:                     );
10737:                     assert!(
10738:                         !function
10739:                             .ssa
10740:                             .source_symbols_at(block, index)
10741:                             .unwrap()
10742:                             .contains_key("$later")
10743:                     );
10744:                 }
10745:             }
10746:         }
10747:         assert_eq!(checked, 1);
10748:     }
10749: 
10750:     #[test]
10751:     fn original_literal_empty_reads_and_mutations_keep_name_data() {
10752:         // Native cases: experiments/name-handling/results/ssa-empty-read-write-names.
10753:         let source = "info exists {}; info exists {$name}; incr {}; incr {$counter}; dict with {} {}; dict with {$dict} {}";
10754:         let (context, unit) = logical_metadata_fixture(source);
10755:         let registry = context.commands();
10756:         let function = &unit.top_level;
10757:         let metadata = function
10758:             .invocation_metadata_context_for_module(registry, &unit.ir_module)
10759:             .expect("actual retained Logical source input");
10760:         let selection = SsaInvocationContext::supplied(registry, Some(metadata));
10761:         let mut scanner = VarReferenceScanner::with_config(
10762:             VarScanOptions::default(),
10763:             function.source_lexer_config(),
10764:         );
10765:         let statements = &unit.ir_module.top_level.statements;
10766:         assert_eq!(statements.len(), 6);
10767:         for (statement, expected) in statements
10768:             .iter()
10769:             .zip(["", "$name", "", "$counter", "", "$dict"])
10770:         {
10771:             let reads = uses_of_classified_in_context(statement, &mut scanner, selection);
10772:             assert!(
10773:                 reads.contains(&(expected.to_owned(), UseClass::Name)),
10774:                 "{expected:?}: {reads:?}"
10775:             );
10776:             if let Some(unprefixed) = expected.strip_prefix('$') {
10777:                 assert!(!reads.iter().any(|(name, _)| name == unprefixed));
10778:             }
10779:         }
10780:     }
10781: 
10782:     #[test]
10783:     fn original_loop_name_lists_keep_empty_and_dollar_elements() {
10784:         // Native foreach cases: experiments/name-handling/results/ssa-empty-read-write-names.
10785:         let source = "foreach {{} {$name}} $values {}";
10786:         let (context, unit) = logical_metadata_fixture(source);
10787:         let registry = context.commands();
10788:         let function = &unit.top_level;
10789:         let script = &unit.ir_module.top_level;
10790:         let tokens = script
10791:             .retained_source_tokens_for_statement(&script.statements[0])
10792:             .expect("actual original loop words");
10793:         let metadata = function
10794:             .invocation_metadata_context_for_module(registry, &unit.ir_module)
10795:             .expect("actual retained Logical source input");
10796:         let selected = selected_barrier_defs(
10797:             SsaInvocationContext::supplied(registry, Some(metadata)),
10798:             tokens,
10799:         );
10800:         assert!(selected.contains(&String::new()), "{selected:?}");
10801:         assert!(selected.contains(&"$name".to_owned()), "{selected:?}");
10802:         assert!(!selected.contains(&"name".to_owned()), "{selected:?}");
10803:         assert!(
10804:             selected_barrier_defs(SsaInvocationContext::supplied(registry, None), tokens)
10805:                 .is_empty()
10806:         );
10807:     }
10808: 
10809:     #[test]
10810:     fn uses_of_assign_const() {
10811:         let reg = default_registry();
10812:         let mut scanner = VarReferenceScanner::new(VarScanOptions::default());
10813:         let stmt = Statement::AssignConst {
10814:             span: Span::new(0, 10),
10815:             name: "x".into(),
10816:             name_braced: false,
10817:             value: "1".into(),
10818:             value_span: None,
10819:         };
10820:         let uses = uses_of(&stmt, &mut scanner, &reg);
10821:         assert_eq!(uses.len(), 0, "constant assignment reads nothing");
10822:     }
10823: 
10824:     #[test]
10825:     fn uses_of_assign_value_with_var() {
10826:         let reg = default_registry();
10827:         let mut scanner = VarReferenceScanner::new(VarScanOptions {
10828:             include_var_read_roles: true,
10829:             recurse_cmd_substitutions: true,
10830:             include_reads_before_write: false,
10831:             element_qualified: false,
10832:         });
10833:         let stmt = Statement::AssignValue {
10834:             span: Span::new(0, 15),
10835:             name: "y".into(),
10836:             name_braced: false,
10837:             value: "$x".into(),
10838:             value_needs_backsubst: false,
10839:             tokens: None,
10840:         };
10841:         let uses = uses_of(&stmt, &mut scanner, &reg);
10842:         assert!(uses.contains(&"x".to_string()), "should read $x");
10843:         assert!(
10844:             !uses.contains(&"y".to_string()),
10845:             "should not read $y (it's defined)"
10846:         );
10847:     }
10848: 
10849:     #[test]
10850:     fn uses_of_incr() {
10851:         let reg = default_registry();
10852:         let mut scanner = VarReferenceScanner::new(VarScanOptions::default());
10853:         let stmt = Statement::Incr {
10854:             span: Span::new(0, 10),
10855:             name: "i".into(),
10856:             name_braced: false,
10857:             amount: None,
10858:             amount_braced: false,
10859:             safe_on_uninit: false,
10860:         };
10861:         let uses = uses_of(&stmt, &mut scanner, &reg);
10862:         // incr reads and writes — reads_own_def
10863:         assert!(uses.contains(&"i".to_string()), "incr reads the variable");
10864:     }
10865: 
10866:     #[test]
10867:     fn uses_of_return_with_value() {
10868:         let reg = default_registry();
10869:         let mut scanner = VarReferenceScanner::new(VarScanOptions::default());
10870:         let stmt = Statement::Return {
10871:             tokens: None,
10872:             span: Span::new(0, 15),
10873:             value: Some("$result".into()),
10874:             value_word: None,
10875:             expr: None,
10876:             expr_base: None,
10877:             command_binding: None,
10878:             braced: false,
10879:         };
10880:         let uses = uses_of(&stmt, &mut scanner, &reg);
10881:         assert!(uses.contains(&"result".to_string()));
10882:     }
10883: 
10884:     #[test]
10885:     fn uses_of_expr_eval() {
10886:         let reg = default_registry();
10887:         let mut scanner = VarReferenceScanner::new(VarScanOptions::default());
10888:         let stmt = Statement::ExprEval {
10889:             span: Span::new(0, 20),
10890:             command_binding: tcl_runtime_api::CommandBindingIdentity::new("expr", "expr"),
10891:             expr: ExprNode::Binary {
10892:                 op: crate::expr_ast::BinOp::Add,
10893:                 left: Box::new(ExprNode::Var {
10894:                     text: "$a".into(),
10895:                     name: "a".into(),
10896:                     start: 0,
10897:                     end: 2,
10898:                 }),
10899:                 right: Box::new(ExprNode::Var {
10900:                     text: "$b".into(),
10901:                     name: "b".into(),
10902:                     start: 5,
10903:                     end: 7,
10904:                 }),
10905:             },
10906:             expr_base: None,
10907:         };
10908:         let uses = uses_of(&stmt, &mut scanner, &reg);
10909:         assert!(uses.contains(&"a".to_string()));
10910:         assert!(uses.contains(&"b".to_string()));
10911:     }
10912: 
10913:     // UseClass classification
10914: 
10915:     /// A `Call` whose argument words are `args`, with per-word token kinds
10916:     /// derived from the word text: `{…}` lexes to `Str` (brace-quoted, the one
10917:     /// form Tcl leaves wholly unsubstituted), everything else to `Esc`.
10918:     fn call_with_words(command: &str, args: &[&str]) -> Statement {
10919:         let source = std::iter::once(command)
10920:             .chain(args.iter().copied())
10921:             .collect::<Vec<_>>()
10922:             .join(" ");
10923:         let segment = crate::segmenter::segment_commands(&source).remove(0);
10924:         let tokens = crate::ir::CommandTokens::from_segmented(
10925:             &tcl_lexer::SourceMap::new(&source),
10926:             tcl_lexer::LexerConfig::default(),
10927:             &segment,
10928:         );
10929:         Statement::Call {
10930:             span: segment.span,
10931:             command: command.to_owned(),
10932:             canonical_command: None,
10933:             args: segment.texts.into_iter().skip(1).collect(),
10934:             defs: Vec::new(),
10935:             reads: Vec::new(),
10936:             reads_own_defs: false,
10937:             safe_on_uninit: false,
10938:             tokens: Some(tokens),
10939:             foreach_groups: None,
10940:         }
10941:     }
10942: 
10943:     fn classify(stmt: &Statement, reg: &CommandRegistry, name: &str) -> Option<UseClass> {
10944:         let mut scanner = VarReferenceScanner::new(VarScanOptions::default());
10945:         uses_of_classified(stmt, &mut scanner, reg)
10946:             .into_iter()
10947:             .find(|(n, _)| n == name)
10948:             .map(|(_, class)| class)
10949:     }
10950: 
10951:     /// A braced word at a role the callee does **not** evaluate in this frame
10952:     /// is a `Quoted` use: still recorded (liveness must assume it may be
10953:     /// evaluated later) but not a read here.
10954:     /// tclsh-proof: tclsh8.6.14 — `puts {$y}` prints `$y` with `y` undefined.
10955:     #[test]
10956:     fn uses_of_classified_braced_data_word_is_quoted() {
10957:         let reg = default_registry();
10958:         let stmt = call_with_words("puts", &["{$y}"]);
10959:         assert_eq!(classify(&stmt, &reg, "y"), Some(UseClass::Quoted));
10960:     }
10961: 
10962:     /// The same name in an unbraced word is a definite read.
10963:     #[test]
10964:     fn uses_of_classified_unbraced_word_is_substituted() {
10965:         let reg = default_registry();
10966:         let stmt = call_with_words("puts", &["$y"]);
10967:         assert_eq!(classify(&stmt, &reg, "y"), Some(UseClass::Substituted));
10968:     }
10969: 
10970:     /// A braced `Expr`-role word really does substitute — `expr` evaluates it
10971:     /// against the caller's variables — so it stays `Substituted`.
10972:     #[test]
10973:     fn uses_of_classified_braced_expr_word_is_substituted() {
10974:         let reg = default_registry();
10975:         let stmt = call_with_words("expr", &["{$a + $b}"]);
10976:         assert_eq!(classify(&stmt, &reg, "a"), Some(UseClass::Substituted));
10977:         assert_eq!(classify(&stmt, &reg, "b"), Some(UseClass::Substituted));
10978:     }
10979: 
10980:     /// A command the registry does not describe carries no role information,
10981:     /// so its braced word is *unclassified*: it may be a script that runs in
10982:     /// this frame. A name the word sets itself is that script's own local —
10983:     /// the un-hooked definer shape — so it is `Quoted`.
10984:     #[test]
10985:     fn uses_of_classified_unknown_definer_body_local_is_quoted() {
10986:         let reg = default_registry();
10987:         let stmt = call_with_words(
10988:             "mydefiner",
10989:             &["::foo::bar", "{optlist}", "{set y 1; return $y}"],
10990:         );
10991:         assert_eq!(classify(&stmt, &reg, "y"), Some(UseClass::Quoted));
10992:     }
10993: 
10994:     /// TN control — a name the unclassified word does **not** set stays a
10995:     /// read: a wrapper handing the word to an `uplevel`-ing worker really does
10996:     /// evaluate it in this frame, and tclsh errors on the unset name.
10997:     #[test]
10998:     fn uses_of_classified_unknown_command_free_read_stays_substituted() {
10999:         let reg = default_registry();
11000:         let stmt = call_with_words("wrapper", &["myf", "{puts $myf}"]);
11001:         assert_eq!(classify(&stmt, &reg, "myf"), Some(UseClass::Substituted));
11002:     }
11003: 
11004:     #[test]
11005:     fn source_ownership_classification_uses_the_retained_lexical_config() {
11006:         // naming.variable.ssa-retained-lexical-config
11007:         // docs/design/analysis/name-resolution-proofs/variable-ssa-retained-lexical-config.md
11008:         let registry = default_registry();
11009:         let tcl = tcl_lexer::LexerConfig::for_dialect("tcl9.0");
11010:         let jim = tcl_lexer::LexerConfig {
11011:             base_offset: 87,
11012:             base_line: 4,
11013:             base_col: 12,
11014:             leading_bom: tcl_lexer::LeadingBom::Skip,
11015:             ..tcl_lexer::LexerConfig::for_dialect("jim")
11016:         };
11017:         // These unchanged, brace-balanced source words exercise command
11018:         // separators and list parsing. They are lexical classification controls,
11019:         // not a proof that the unknown wrapper executes either body.
11020:         for (body, tcl_class, jim_class) in [
11021:             (
11022:                 "{set\u{000b}x 1; puts $x}",
11023:                 UseClass::Quoted,
11024:                 UseClass::Substituted,
11025:             ),
11026:             (
11027:                 "{foreach \"{x}y\" {1 2} {}; puts $x}",
11028:                 UseClass::Substituted,
11029:                 UseClass::Quoted,
11030:             ),
11031:         ] {
11032:             let statement = call_with_words("wrapper", &[body]);
11033:             for (config, expected) in [(tcl, tcl_class), (jim, jim_class)] {
11034:                 let mut scanner =
11035:                     VarReferenceScanner::with_config(VarScanOptions::default(), config);
11036:                 let class = uses_of_classified(&statement, &mut scanner, &registry)
11037:                     .into_iter()
11038:                     .find(|(name, _)| name == "x")
11039:                     .map(|(_, class)| class);
11040:                 assert_eq!(class, Some(expected), "{body:?}, {config:?}");
11041:                 assert_eq!(scanner.lexer_config(), config.nested().normalized());
11042:             }
11043:         }
11044:     }
11045: 
11046:     #[test]
11047:     fn nested_source_expression_roles_use_the_retained_lexical_config() {
11048:         // naming.variable.ssa-retained-lexical-config
11049:         // docs/design/analysis/name-resolution-proofs/variable-ssa-retained-lexical-config.md
11050:         let registry = default_registry();
11051:         let statement = call_with_words("puts", &["[expr\u{000b} {$nested}]"]);
11052:         for (config, expected) in [
11053:             (tcl_lexer::LexerConfig::for_dialect("tcl9.0"), true),
11054:             (tcl_lexer::LexerConfig::for_dialect("jim"), false),
11055:         ] {
11056:             // Jim's actual head is `expr` followed by a vertical-tab byte.
11057:             // Registry source roles cannot replace that head with `expr`.
11058:             let mut scanner = VarReferenceScanner::with_config(VarScanOptions::default(), config);
11059:             let names = uses_of_classified(&statement, &mut scanner, &registry);
11060:             assert_eq!(
11061:                 names
11062:                     .iter()
11063:                     .any(|(name, class)| name == "nested" && *class == UseClass::Substituted),
11064:                 expected,
11065:                 "{config:?}: {names:?}",
11066:             );
11067:         }
11068:     }
11069: 
11070:     /// A name reached both ways in one statement is a definite read.
11071:     #[test]
11072:     fn uses_of_classified_substituted_wins_over_quoted() {
11073:         let reg = default_registry();
11074:         let stmt = call_with_words("puts", &["{$y}", "$y"]);
11075:         assert_eq!(classify(&stmt, &reg, "y"), Some(UseClass::Substituted));
11076:     }
11077: 
11078:     /// A braced `return` value is literal.
11079:     /// tclsh-proof: tclsh8.6.14 — `proc f {} { return {$y} }; puts [f]` prints
11080:     /// `$y` with `y` undefined.
11081:     #[test]
11082:     fn uses_of_classified_braced_return_value_is_quoted() {
11083:         let reg = default_registry();
11084:         let stmt = Statement::Return {
11085:             tokens: None,
11086:             span: Span::new(0, 15),
11087:             value: Some("$y".into()),
11088:             value_word: None,
11089:             expr: None,
11090:             expr_base: None,
11091:             command_binding: None,
11092:             braced: true,
11093:         };
11094:         assert_eq!(classify(&stmt, &reg, "y"), Some(UseClass::Quoted));
11095:     }
11096: 
11097:     /// Build a one-arm opaque `switch` around `body`, with `pattern` as the
11098:     /// arm's pattern and the canonical braced arm block.
11099:     fn opaque_switch(subject: &str, pattern: &str, body: crate::ir::Script) -> Statement {
11100:         Statement::Switch {
11101:             subject_braced: false,
11102:             raw_arg_braced: Vec::new(),
11103:             raw_arg_quoted: Vec::new(),
11104:             command: "switch".into(),
11105:             span: Span::new(0, 40),
11106:             subject: subject.into(),
11107:             subject_span: Span::new(0, 1),
11108:             arms: vec![crate::ir::SwitchArm {
11109:                 pattern: pattern.into(),
11110:                 pattern_braced: true,
11111:                 pattern_span: Span::new(0, 1),
11112:                 body: Some(body),
11113:                 body_span: Some(Span::new(0, 1)),
11114:                 fallthrough: false,
11115:             }],
11116:             default_body: None,
11117:             default_span: None,
11118:             mode: crate::ir::SwitchMode::Glob,
11119:             nocase: false,
11120:             raw_args: Vec::new(),
11121:             patterns_braced: true,
11122:         }
11123:     }
11124: 
11125:     /// An arm body is the one script that reaches SSA
11126:     /// un-lowered, and its reads must arrive classified exactly as the same
11127:     /// word would be outside the arm. A braced data word is `Quoted`.
11128:     /// tclsh-proof: tclsh 9.0.4 — `proc f {z} { switch -glob $z { a* { puts
11129:     /// {$b} } } }; f abc` prints `$b` with `b` undefined.
11130:     #[test]
11131:     fn uses_of_classified_opaque_switch_arm_braced_data_word_is_quoted() {
11132:         let reg = default_registry();
11133:         let mut body = crate::ir::Script::new();
11134:         body.statements.push(call_with_words("puts", &["{$y}"]));
11135:         let stmt = opaque_switch("$z", "a*", body);
11136:         assert_eq!(classify(&stmt, &reg, "y"), Some(UseClass::Quoted));
11137:         // The subject is a genuine read of this frame.
11138:         assert_eq!(classify(&stmt, &reg, "z"), Some(UseClass::Substituted));
11139:     }
11140: 
11141:     /// TP control — the substituting spelling of the same arm word stays a
11142:     /// definite read, so the classification is threaded, not dropped.
11143:     #[test]
11144:     fn uses_of_classified_opaque_switch_arm_unbraced_word_is_substituted() {
11145:         let reg = default_registry();
11146:         let mut body = crate::ir::Script::new();
11147:         body.statements.push(call_with_words("puts", &["$y"]));
11148:         let stmt = opaque_switch("$z", "a*", body);
11149:         assert_eq!(classify(&stmt, &reg, "y"), Some(UseClass::Substituted));
11150:     }
11151: 
11152:     /// A `Statement::Foreach` inside an opaque arm is walked by
11153:     /// `reads_in_stmt` rather than lowered, so `ForeachIterator::list_braced`
11154:     /// is the extra fact that walk needs: a braced value word is
11155:     /// literal list text, recorded `Quoted` so liveness still honours it.
11156:     #[test]
11157:     fn uses_of_classified_opaque_switch_arm_braced_foreach_list_is_quoted() {
11158:         let reg = default_registry();
11159:         let mut body = crate::ir::Script::new();
11160:         body.statements.push(Statement::Foreach {
11161:             span: Span::new(0, 20),
11162:             iterators: vec![crate::ir::ForeachIterator {
11163:                 vars: vec!["n".into()],
11164:                 list_arg: "a $y c".into(),
11165:                 list_braced: true,
11166:             }],
11167:             body: crate::ir::Script::new(),
11168:             body_span: Span::new(0, 1),
11169:             is_lmap: false,
11170:             raw_args: Vec::new(),
11171:             is_dict_iteration: false,
11172:             is_array_iteration: false,
11173:             raw_tokens: None,
11174:         });
11175:         let stmt = opaque_switch("$z", "a*", body);
11176:         assert_eq!(classify(&stmt, &reg, "y"), Some(UseClass::Quoted));
11177:     }
11178: 
11179:     /// TP control for the loop value word — the substituting spelling is a
11180:     /// definite read even inside an opaque arm.
11181:     #[test]
11182:     fn uses_of_classified_opaque_switch_arm_substituted_foreach_list_is_substituted() {
11183:         let reg = default_registry();
11184:         let mut body = crate::ir::Script::new();
11185:         body.statements.push(Statement::Foreach {
11186:             span: Span::new(0, 20),
11187:             iterators: vec![crate::ir::ForeachIterator {
11188:                 vars: vec!["n".into()],
11189:                 list_arg: "a $y c".into(),
11190:                 list_braced: false,
11191:             }],
11192:             body: crate::ir::Script::new(),
11193:             body_span: Span::new(0, 1),
11194:             is_lmap: false,
11195:             raw_args: Vec::new(),
11196:             is_dict_iteration: false,
11197:             is_array_iteration: false,
11198:             raw_tokens: None,
11199:         });
11200:         let stmt = opaque_switch("$z", "a*", body);
11201:         assert_eq!(classify(&stmt, &reg, "y"), Some(UseClass::Substituted));
11202:     }
11203: 
11204:     /// A pattern from the canonical braced arm block is a
11205:     /// literal list element; supplied as separate words it substitutes.
11206:     #[test]
11207:     fn uses_of_classified_switch_pattern_class_follows_patterns_braced() {
11208:         let reg = default_registry();
11209:         let braced = opaque_switch("$z", "$p*", crate::ir::Script::new());
11210:         assert_eq!(classify(&braced, &reg, "p"), Some(UseClass::Quoted));
11211:         let mut worded = opaque_switch("$z", "$p*", crate::ir::Script::new());
11212:         if let Statement::Switch {
11213:             patterns_braced, ..
11214:         } = &mut worded
11215:         {
11216:             *patterns_braced = false;
11217:         }
11218:         assert_eq!(classify(&worded, &reg, "p"), Some(UseClass::Substituted));
11219:     }
11220: 
11221:     // build_ssa tests
11222: 
11223:     #[test]
11224:     fn build_ssa_linear() {
11225:         let reg = default_registry();
11226:         // entry: set x 1; set y $x; return
11227:         let mut func = Function::new("::test", "entry");
11228:         let entry = func.entry;
11229:         func.blocks.get_mut(&entry).unwrap().statements = vec![
11230:             Statement::AssignConst {
11231:                 span: Span::new(0, 7),
11232:                 name: "x".into(),
11233:                 name_braced: false,
11234:                 value: "1".into(),
11235:                 value_span: None,
11236:             },
11237:             Statement::AssignValue {
11238:                 span: Span::new(8, 16),
11239:                 name: "y".into(),
11240:                 name_braced: false,
11241:                 value: "$x".into(),
11242:                 value_needs_backsubst: false,
11243:                 tokens: None,
11244:             },
11245:         ];
11246:         func.blocks.get_mut(&entry).unwrap().terminator = Some(make_return());
11247: 
11248:         let ssa = build_ssa(&func, &reg);
11249:         assert_eq!(ssa.name, "::test");
11250:         assert_eq!(ssa.entry, entry);
11251: 
11252:         let sx = ssa.var_symbol("x").expect("x interned");
11253:         let sy = ssa.var_symbol("y").expect("y interned");
11254:         let entry_blk = &ssa.blocks[&entry];
11255:         // First statement (set x 1): defs x=1
11256:         assert_eq!(entry_blk.statements[0].defs.get(&sx), Some(&1));
11257:         // Second statement (set y $x): uses x=1, defs y=1
11258:         assert_eq!(entry_blk.statements[1].uses.get(&sx), Some(&1));
11259:         assert_eq!(entry_blk.statements[1].defs.get(&sy), Some(&1));
11260:     }
11261: 
11262:     #[test]
11263:     fn linked_option_original_values_preserve_literal_dollars_and_element_roots() {
11264:         let (context, unit) = logical_metadata_fixture(
11265:             "info exists {$literal}; info exists {items(key)}; info exists {(key)}; info exists {}",
11266:         );
11267:         let registry = context.commands();
11268:         let metadata = unit
11269:             .top_level
11270:             .invocation_metadata_context_for_module(registry, &unit.ir_module)
11271:             .unwrap();
11272:         for (statement, expected) in unit.ir_module.top_level.statements.iter().zip([
11273:             Some("::$literal"),
11274:             Some("::items"),
11275:             Some("::"),
11276:             None,
11277:         ]) {
11278:             let tokens = statement.tokens().unwrap();
11279:             assert_eq!(
11280:                 linked_option_definition_name(tokens, 1, true, metadata, registry).as_deref(),
11281:                 expected,
11282:             );
11283:             assert!(original_global_root_frame(tokens, metadata, registry).is_none());
11284:             let mut changed = tokens.clone();
11285:             changed.argv_texts[2] = "different_name".to_owned();
11286:             assert!(linked_option_definition_name(&changed, 1, true, metadata, registry).is_none());
11287:             let mut detached = tokens.clone();
11288:             detached.source_binding = None;
11289:             assert!(
11290:                 linked_option_definition_name(&detached, 1, true, metadata, registry).is_none()
11291:             );
11292:         }
11293:     }
11294: 
11295:     #[test]
11296:     fn logical_linked_option_unicode_nul_retains_complete_qualified_name_data() {
11297:         for (source, expected) in [
11298:             (
11299:                 "info exists \"original_scope::literal\\u0000tail\"",
11300:                 "::original_scope::literal\0tail",
11301:             ),
11302:             (
11303:                 "info exists \"original_scope::items\\u0000tail(key)\"",
11304:                 "::original_scope::items\0tail",
11305:             ),
11306:         ] {
11307:             let (context, unit) = logical_metadata_fixture(source);
11308:             let registry = context.commands();
11309:             let metadata = unit
11310:                 .top_level
11311:                 .invocation_metadata_context_for_module(registry, &unit.ir_module)
11312:                 .unwrap();
11313:             let tokens = unit.ir_module.top_level.statements[0].tokens().unwrap();
11314:             assert_eq!(
11315:                 linked_option_definition_name(tokens, 1, true, metadata, registry).as_deref(),
11316:                 Some(expected)
11317:             );
11318:             let binding = tokens.source_binding.as_ref().unwrap();
11319:             let input = binding.original_written_name_input(tokens, 2).unwrap();
11320:             let key = input.original_word_key().unwrap();
11321:             assert!(key.bytes().contains(&0));
11322:             assert_ne!(
11323:                 key.policy()
11324:                     .recipe()
11325:                     .combined_variable_input(key.bytes())
11326:                     .root()
11327:                     .selected(),
11328:                 key.bytes()
11329:             );
11330:             assert!(
11331:                 SsaInvocationContext::supplied(registry, Some(metadata))
11332:                     .normal(tokens)
11333:                     .is_none()
11334:             );
11335:         }
11336:     }
11337: 
11338:     #[test]
11339:     fn top_label_and_option_definition_cannot_supply_global_frame_ownership() {
11340:         let registry = tcl_registry::model::ingress::static_context_for("tk").commands();
11341:         let mut function = Function::new("::top", "entry");
11342:         let block = function.blocks.get_mut(&function.entry).unwrap();
11343:         block.statements.push(call(
11344:             Span::new(0, 34),
11345:             "entry",
11346:             &[".e", "-textvariable", "value"],
11347:             &["::value"],
11348:         ));
11349:         assert!(!mirror_top_level_global_option_defs(
11350:             &mut function,
11351:             registry
11352:         ));
11353:         let Statement::Call { defs, .. } = &function.blocks[&function.entry].statements[0] else {
11354:             panic!("original option statement");
11355:         };
11356:         assert_eq!(defs, &["::value".to_owned()]);
11357:     }
11358: 
11359:     #[test]
11360:     fn catalogue_widget_option_roles_do_not_donate_physical_store_proof() {
11361:         let registry = tcl_registry::model::ingress::static_context_for("tk").commands();
11362:         let arguments = [".e", "-textvariable", "value"];
11363:         let option = registry
11364:             .get("entry")
11365:             .unwrap()
11366:             .options
11367:             .iter()
11368:             .find(|option| option.name == "-textvariable")
11369:             .unwrap();
11370:         assert!(
11371:             matches!(option.value, tcl_registry::hover::OptionValue::Takes(argument)
11372:             if argument.role == tcl_registry::ArgRole::VarWrite)
11373:         );
11374:         assert_eq!(
11375:             registry.option_variable_scope("entry", &arguments, 2, registry.own_surface_query()),
11376:             Some(tcl_registry::VariableScope::Global)
11377:         );
11378:         let unit = crate::compilation_unit::CompilationUnit::build_for(
11379:             "entry .e -textvariable value",
11380:             registry,
11381:             false,
11382:         );
11383:         assert!(
11384:             unit.top_level
11385:                 .ssa
11386:                 .blocks
11387:                 .values()
11388:                 .flat_map(|block| &block.statements)
11389:                 .all(|statement| statement.defs.is_empty())
11390:         );
11391:     }
11392: 
11393:     #[test]
11394:     fn catalogue_instance_options_do_not_manufacture_live_widget_handlers() {
11395:         let registry = tcl_registry::model::ingress::static_context_for("tk").commands();
11396:         let invocation = registry
11397:             .resolve_instance_invocation(
11398:                 "entry",
11399:                 ".e",
11400:                 &["configure", "-textvariable", "value"],
11401:                 registry.own_surface_query(),
11402:             )
11403:             .expect("catalogue instance assistance");
11404:         assert!(
11405:             invocation
11406:                 .semantics
11407:                 .traits
11408:                 .contains(tcl_registry::Traits::CONFIGURES_INSTANCE_OPTIONS)
11409:         );
11410:         let unit = crate::compilation_unit::CompilationUnit::build_for(
11411:             "entry .e; .e configure -textvariable value",
11412:             registry,
11413:             false,
11414:         );
11415:         assert!(
11416:             unit.top_level
11417:                 .ssa
11418:                 .blocks
11419:                 .values()
11420:                 .flat_map(|block| &block.statements)
11421:                 .all(|statement| statement.defs.is_empty())
11422:         );
11423:     }
11424: 
11425:     #[test]
11426:     fn build_ssa_top_level_ordinary_global_set_has_no_bare_alias() {
11427:         let reg = default_registry();
11428:         let mut func = Function::new("::top", "entry");
11429:         let entry = func.entry;
11430:         func.blocks
11431:             .get_mut(&entry)
11432:             .unwrap()
11433:             .statements
11434:             .push(Statement::AssignConst {
11435:                 span: Span::new(0, 13),
11436:                 name: "::value".into(),
11437:                 name_braced: false,
11438:                 value: "1".into(),
11439:                 value_span: None,
11440:             });
11441:         func.blocks.get_mut(&entry).unwrap().terminator = Some(make_return());
11442: 
11443:         let ssa = build_ssa(&func, &reg);
11444:         let absolute = ssa.var_symbol("::value").expect("global spelling interned");
11445:         assert_eq!(
11446:             ssa.blocks[&entry].statements[0].defs.get(&absolute),
11447:             Some(&1)
11448:         );
11449:         assert_eq!(ssa.var_symbol("value"), None);
11450:     }
11451: 
11452:     #[test]
11453:     fn qualified_catalogue_option_keeps_scope_assistance_without_a_store() {
11454:         let registry = tcl_registry::model::ingress::static_context_for("tk").commands();
11455:         let arguments = [".e", "-textvariable", "::ns::value"];
11456:         assert_eq!(
11457:             registry.option_variable_scope("entry", &arguments, 2, registry.own_surface_query()),
11458:             Some(tcl_registry::VariableScope::Global)
11459:         );
11460:         let unit = crate::compilation_unit::CompilationUnit::build_for(
11461:             "namespace eval ns {}; entry .e -textvariable ::ns::value",
11462:             registry,
11463:             false,
11464:         );
11465:         assert!(
11466:             unit.top_level
11467:                 .ssa
11468:                 .blocks
11469:                 .values()
11470:                 .flat_map(|block| &block.statements)
11471:                 .all(|statement| statement.defs.is_empty())
11472:         );
11473:         assert_eq!(unit.top_level.ssa.var_symbol("value"), None);
11474:     }
11475: 
11476:     #[test]
11477:     fn build_ssa_global_option_without_absolute_def_has_no_bare_alias() {
11478:         let reg = default_registry();
11479:         let mut func = Function::new("::top", "entry");
11480:         let entry = func.entry;
11481:         func.blocks.get_mut(&entry).unwrap().statements.push(call(
11482:             Span::new(0, 34),
11483:             "entry",
11484:             &[".e", "-textvariable", "value"],
11485:             &[],
11486:         ));
11487:         func.blocks.get_mut(&entry).unwrap().terminator = Some(make_return());
11488: 
11489:         let ssa = build_ssa(&func, &reg);
11490:         assert_eq!(ssa.var_symbol("::value"), None);
11491:         assert_eq!(ssa.var_symbol("value"), None);
11492:     }
11493: 
11494:     #[test]
11495:     fn procedure_widget_catalogue_does_not_write_global_or_local_values() {
11496:         let registry = tcl_registry::model::ingress::static_context_for("tk").commands();
11497:         let unit = crate::compilation_unit::CompilationUnit::build_for(
11498:             "proc make_entry {} {entry .e -textvariable value; .e configure -textvariable value}",
11499:             registry,
11500:             false,
11501:         );
11502:         let function = unit.function("::make_entry").unwrap();
11503:         assert!(
11504:             function
11505:                 .ssa
11506:                 .blocks
11507:                 .values()
11508:                 .flat_map(|block| &block.statements)
11509:                 .all(|statement| statement.defs.is_empty())
11510:         );
11511:     }
11512: 
11513:     #[test]
11514:     fn build_ssa_diamond_phi() {
11515:         let reg = default_registry();
11516:         // entry → branch on $x → then: set x 1 → end
11517:         //                       → else: set x 2 → end
11518:         let mut func = diamond_cfg();
11519:         let entry = func.entry;
11520:         let (then, els, end) = (
11521:             id_of(&func, "then"),
11522:             id_of(&func, "else"),
11523:             id_of(&func, "end"),
11524:         );
11525: 
11526:         // Define x in entry first so it's used in the condition.
11527:         func.blocks
11528:             .get_mut(&entry)
11529:             .unwrap()
11530:             .statements
11531:             .push(Statement::AssignConst {
11532:                 span: Span::new(0, 7),
11533:                 name: "x".into(),
11534:                 name_braced: false,
11535:                 value: "0".into(),
11536:                 value_span: None,
11537:             });
11538: 
11539:         func.blocks
11540:             .get_mut(&then)
11541:             .unwrap()
11542:             .statements
11543:             .push(Statement::AssignConst {
11544:                 span: Span::new(10, 18),
11545:                 name: "x".into(),
11546:                 name_braced: false,
11547:                 value: "1".into(),
11548:                 value_span: None,
11549:             });
11550:         func.blocks
11551:             .get_mut(&els)
11552:             .unwrap()
11553:             .statements
11554:             .push(Statement::AssignConst {
11555:                 span: Span::new(20, 28),
11556:                 name: "x".into(),
11557:                 name_braced: false,
11558:                 value: "2".into(),
11559:                 value_span: None,
11560:             });
11561:         // Read `x` after the join so it is upward-exposed at `end` — under
11562:         // semi-pruned SSA a phi is placed only for a name with a downstream
11563:         // reader (a dead phi for an unread merge is correctly dropped).
11564:         func.blocks
11565:             .get_mut(&end)
11566:             .unwrap()
11567:             .statements
11568:             .push(Statement::Call {
11569:                 span: Span::new(30, 38),
11570:                 command: "puts".into(),
11571:                 canonical_command: None,
11572:                 args: vec!["$x".into()],
11573:                 defs: vec![],
11574:                 reads: vec![],
11575:                 reads_own_defs: false,
11576:                 safe_on_uninit: false,
11577:                 tokens: None,
11578:                 foreach_groups: None,
11579:             });
11580: 
11581:         let ssa = build_ssa(&func, &reg);
11582: 
11583:         // x is defined in both then and else and read at end, so the end block
11584:         // should have a phi for x.
11585:         let sx = ssa.var_symbol("x").expect("x interned");
11586:         let end_block = &ssa.blocks[&end];
11587:         assert!(
11588:             end_block.phis.iter().any(|phi| phi.name == sx),
11589:             "end block should have a phi for x"
11590:         );
11591: 
11592:         // The phi should have incoming edges from then and else.
11593:         if let Some(phi) = end_block.phis.iter().find(|p| p.name == sx) {
11594:             assert!(
11595:                 phi.incoming.contains_key(&then),
11596:                 "phi should have incoming from then"
11597:             );
11598:             assert!(
11599:                 phi.incoming.contains_key(&els),
11600:                 "phi should have incoming from else"
11601:             );
11602:         }
11603:     }
11604: 
11605:     #[test]
11606:     fn exact_jim_config_places_and_versions_phi_for_expr_sugar_return() {
11607:         let reg = default_registry();
11608:         let mut func = diamond_cfg();
11609:         let (then, els, end) = (
11610:             id_of(&func, "then"),
11611:             id_of(&func, "else"),
11612:             id_of(&func, "end"),
11613:         );
11614:         for (block, value) in [(then, "1"), (els, "2")] {
11615:             func.blocks
11616:                 .get_mut(&block)
11617:                 .unwrap()
11618:                 .statements
11619:                 .push(Statement::AssignConst {
11620:                     span: Span::new(10, 20),
11621:                     name: "a".into(),
11622:                     name_braced: false,
11623:                     value: value.into(),
11624:                     value_span: None,
11625:                 });
11626:         }
11627:         func.blocks.get_mut(&end).unwrap().terminator = Some(Terminator::Return {
11628:             tokens: None,
11629:             value: Some("$($a)".into()),
11630:             value_word: None,
11631:             span: None,
11632:             expr: None,
11633:             expr_base: None,
11634:             braced: false,
11635:         });
11636: 
11637:         // Jim is an environment grammar without a catalogue profile. Its
11638:         // `$()` expression sugar must therefore come from the exact config,
11639:         // not the default registry's profile. Deliberately include file/offset
11640:         // state: SSA re-scans detached words in local nested coordinates.
11641:         let jim = tcl_lexer::LexerConfig {
11642:             base_offset: 91,
11643:             base_line: 7,
11644:             base_col: 13,
11645:             leading_bom: tcl_lexer::LeadingBom::Skip,
11646:             ..tcl_lexer::LexerConfig::for_dialect("jim")
11647:         };
11648:         let ssa = build_ssa_with_config(&func, &reg, jim);
11649:         let a = ssa.var_symbol("a").expect("Jim return read interns a");
11650:         let phi = ssa.blocks[&end]
11651:             .phis
11652:             .iter()
11653:             .find(|phi| phi.name == a)
11654:             .expect("Jim-only return read keeps the merge phi live");
11655:         assert!(phi.incoming.contains_key(&then));
11656:         assert!(phi.incoming.contains_key(&els));
11657: 
11658:         let def_use = crate::def_use::build_def_use_chains(&ssa, Some(&func), jim);
11659:         let chain = def_use
11660:             .chain_for(ssa.var_symbol("a").unwrap(), phi.version)
11661:             .expect("the phi definition has a chain");
11662:         assert!(
11663:             chain
11664:                 .uses
11665:                 .iter()
11666:                 .any(|use_site| use_site.kind == crate::def_use::UseKind::Terminator),
11667:             "the Jim return must read the merged SSA version: {chain:?}"
11668:         );
11669: 
11670:         let tcl = build_ssa_with_config(&func, &reg, tcl_lexer::LexerConfig::for_dialect("tcl9.0"));
11671:         assert!(
11672:             tcl.var_symbol("a").is_none_or(|symbol| {
11673:                 !tcl.blocks[&end].phis.iter().any(|phi| phi.name == symbol)
11674:             }),
11675:             "Tcl must not reinterpret Jim's `$()` expression sugar as a read"
11676:         );
11677:     }
11678: 
11679:     #[test]
11680:     fn build_ssa_loop() {
11681:         let reg = default_registry();
11682:         // entry: set i 0 → header: branch $i<10 → body: incr i → header
11683:         //                                        → end: return
11684:         let mut func = loop_cfg();
11685:         let entry = func.entry;
11686:         let (header, body) = (id_of(&func, "header"), id_of(&func, "body"));
11687: 
11688:         func.blocks
11689:             .get_mut(&entry)
11690:             .unwrap()
11691:             .statements
11692:             .push(Statement::AssignConst {
11693:                 span: Span::new(0, 8),
11694:                 name: "i".into(),
11695:                 name_braced: false,
11696:                 value: "0".into(),
11697:                 value_span: None,
11698:             });
11699:         func.blocks
11700:             .get_mut(&body)
11701:             .unwrap()
11702:             .statements
11703:             .push(Statement::Incr {
11704:                 span: Span::new(20, 28),
11705:                 name: "i".into(),
11706:                 name_braced: false,
11707:                 amount: None,
11708:                 amount_braced: false,
11709:                 safe_on_uninit: false,
11710:             });
11711: 
11712:         let ssa = build_ssa(&func, &reg);
11713: 
11714:         // header should have a phi for i (from entry and body).
11715:         let si = ssa.var_symbol("i").expect("i interned");
11716:         let header_blk = &ssa.blocks[&header];
11717:         assert!(
11718:             header_blk.phis.iter().any(|p| p.name == si),
11719:             "header should have a phi for i"
11720:         );
11721:     }
11722: 
11723:     #[test]
11724:     fn aliased_set_preserves_aliased_nested_expr_read_in_call_ir_for_ssa() {
11725:         let profile = tcl_dialect::DialectProfile::find("tcl9.0").unwrap();
11726:         let reg = tcl_registry::CommandRegistry::build_default().project_for_profile(profile);
11727:         let entry: crate::environment_ingress::CapturedNativeEntry =
11728:             crate::environment_ingress::captured_native_entry(profile);
11729:         let lower = |source: &str| {
11730:             let mut lowerer = crate::lowering::Lowerer::new(&reg);
11731:             lowerer.set_source_analysis_options(crate::command_binding::SourceAnalysisOptions {
11732:                 native_entry: Some(&entry),
11733:                 invocation_dialect: Some(tcl_registry::InvocationDialect::of_profile(profile)),
11734:                 native_compilation: tcl_registry::native_compilation::NativeCompilationContext {
11735:                     mode: tcl_registry::native_compilation::NativeCompilationMode::Direct,
11736:                     ..Default::default()
11737:                 },
11738:                 ..Default::default()
11739:             });
11740:             crate::lowering::lower_to_ir_with(lowerer, source)
11741:         };
11742:         let module = lower(
11743:             "set x 1\ninterp alias {} myset {} set\ninterp alias {} e {} expr\nmyset y [e {$x+1}]\n",
11744:         );
11745:         let call = module
11746:             .top_level
11747:             .statements
11748:             .last()
11749:             .expect("aliased set call");
11750:         assert!(
11751:             defs_of_with_registry(call, Some(&reg)).contains(&"y".to_owned()),
11752:             "aliased set must define y: {call:?}"
11753:         );
11754:         let mut scanner = VarReferenceScanner::new(VarScanOptions::default());
11755:         assert!(
11756:             uses_of(call, &mut scanner, &reg).contains(&"x".to_owned()),
11757:             "SSA must consume the proved aliased expression read"
11758:         );
11759:         let failed =
11760:             lower("interp alias {} myset {} set\ninterp alias {} e {} expr\nmyset y [e {$x+1}]\n");
11761:         assert!(
11762:             defs_of_with_registry(failed.top_level.statements.last().unwrap(), Some(&reg))
11763:                 .is_empty(),
11764:             "an argument read failure cannot define the setter's output"
11765:         );
11766:     }
11767: 
11768:     #[test]
11769:     fn setter_source_reads_use_selected_child_expression_owners() {
11770:         // naming.variable.selected-setter-expression-reads
11771:         // docs/design/analysis/name-resolution-proofs/variable-selected-setter-expression-reads.md
11772:         for dialect in ["tcl8.4", "tcl8.5", "tcl8.6", "tcl9.0", "tcl9.1"] {
11773:             let profile = tcl_dialect::DialectProfile::find(dialect).unwrap();
11774:             let registry =
11775:                 tcl_registry::CommandRegistry::build_default().project_for_profile(profile);
11776:             let (_owner, entry) =
11777:                 crate::environment_ingress::captured_native_entry_with_owner(profile);
11778:             for (source, read, expected) in [
11779:                 (
11780:                     "set input 3; interp alias {} setter {} set; setter output [expr {$input + 1}]",
11781:                     "input",
11782:                     true,
11783:                 ),
11784:                 (
11785:                     "proc expr args {return VALUE}; interp alias {} setter {} set; setter output [expr {$missing}]",
11786:                     "missing",
11787:                     false,
11788:                 ),
11789:                 (
11790:                     "set input 3; interp alias {} calc {} expr; interp alias {} setter {} set; setter output [calc {$input + 1}]",
11791:                     "input",
11792:                     true,
11793:                 ),
11794:             ] {
11795:                 let mut lowerer = crate::lowering::Lowerer::new(&registry);
11796:                 lowerer.set_source_analysis_options(
11797:                     crate::command_binding::SourceAnalysisOptions {
11798:                         native_entry: Some(&entry),
11799:                         invocation_dialect: Some(tcl_registry::InvocationDialect::of_profile(
11800:                             profile,
11801:                         )),
11802:                         native_compilation:
11803:                             crate::environment_ingress::authoring_native_compilation(),
11804:                         ..Default::default()
11805:                     },
11806:                 );
11807:                 let module = crate::lowering::lower_to_ir_with(lowerer, source);
11808:                 let call = module
11809:                     .top_level
11810:                     .statements
11811:                     .last()
11812:                     .expect("actual setter call");
11813:                 let tokens = module
11814:                     .top_level
11815:                     .retained_source_tokens_for_statement(call)
11816:                     .unwrap_or_else(|| {
11817:                         panic!("{dialect}: original aliased setter carrier missing: {call:?}")
11818:                     });
11819:                 assert!(tokens.source_binding.is_some(), "{dialect}: {source}");
11820:                 assert!(
11821:                     defs_of_with_registry(call, Some(&registry)).contains(&"output".to_owned()),
11822:                     "{dialect}: actual setter definition is an independent positive: {call:?}",
11823:                 );
11824:                 let mut scanner = VarReferenceScanner::with_config(
11825:                     VarScanOptions::default(),
11826:                     module.native_lexer_config(),
11827:                 );
11828:                 let names = uses_of(call, &mut scanner, &registry);
11829:                 assert_eq!(
11830:                     names.iter().any(|name| name == read),
11831:                     expected,
11832:                     "{dialect}: {source}: {names:?}"
11833:                 );
11834:             }
11835:         }
11836:     }
11837: 
11838:     #[test]
11839:     fn set_value_reads_preserves_scanner_element_qualification() {
11840:         let reg = default_registry();
11841:         let mut scanner = VarReferenceScanner::new(VarScanOptions {
11842:             element_qualified: true,
11843:             ..VarScanOptions::default()
11844:         });
11845:         assert!(
11846:             set_value_reads(
11847:                 "[::expr {$array(key) + 1}]",
11848:                 None,
11849:                 &mut scanner,
11850:                 SsaInvocationContext::standalone(&reg)
11851:             )
11852:             .contains("array(key)")
11853:         );
11854:     }
11855: 
11856:     #[test]
11857:     fn build_ssa_empty_function() {
11858:         let reg = default_registry();
11859:         let mut func = Function::new("::empty", "entry");
11860:         let entry = func.entry;
11861:         func.blocks.get_mut(&entry).unwrap().terminator = Some(make_return());
11862: 
11863:         let ssa = build_ssa(&func, &reg);
11864:         assert_eq!(ssa.blocks.len(), 1);
11865:         assert_eq!(ssa.blocks[&entry].phis, [] as [crate::ssa::Phi; 0]);
11866:         assert_eq!(
11867:             ssa.blocks[&entry].statements,
11868:             [] as [crate::ssa::SsaStatement; 0]
11869:         );
11870:     }
11871: 
11872:     #[test]
11873:     fn complexity_guard_skips_oversized_ssa() {
11874:         let reg = default_registry();
11875:         // A small function is below the ceiling and analysed normally.
11876:         let small = Function::new("::small", "entry");
11877:         assert!(!is_complexity_guarded(&small));
11878: 
11879:         // A function above the block ceiling is guarded: `build_ssa` returns a
11880:         // trivial SSA without running the O(blocks·vars) dominator + phi walk
11881:         // that would cost seconds on a pathological generated body.
11882:         let mut big = Function::new("::big", "b0");
11883:         let b0 = big.entry;
11884:         for i in 0..=COMPLEXITY_GUARD_BLOCKS {
11885:             let id = big.intern_block(format!("b{i}"));
11886:             big.blocks.insert(id, Block::new(format!("b{i}")));
11887:         }
11888:         assert!(big.blocks.len() > COMPLEXITY_GUARD_BLOCKS);
11889:         assert!(is_complexity_guarded(&big));
11890: 
11891:         let ssa = build_ssa(&big, &reg);
11892:         assert_eq!(ssa.blocks.len(), 0, "guarded SSA must be trivial");
11893:         assert_eq!(ssa.name, "::big");
11894:         assert_eq!(ssa.entry, b0);
11895:     }
11896: 
11897:     /// `collapsed_extra_defs` recurses once per nested
11898:     /// `If`/`While`/`For`/`Foreach`/`Catch`/`Try`/`Switch` body, with no
11899:     /// depth cap of its own. Transitively
11900:     /// bounded to `MAX_LOWER_NEST_DEPTH` (256) by the lowering pass,
11901:     /// so this is defence-in-depth / consistency with every other
11902:     /// full-tree walker in this crate, not a currently-reproducible crash.
11903:     /// 2000 levels is comfortably past this new cap; the assertion is that
11904:     /// the call returns at all, not what it returns.
11905:     #[test]
11906:     fn deeply_nested_if_survives_collapsed_extra_defs() {
11907:         use crate::ir::{IfClause, Script};
11908: 
11909:         const DEPTH: usize = 2000;
11910:         let leaf = Statement::AssignConst {
11911:             span: Span::new(0, 0),
11912:             name: "leaf".into(),
11913:             name_braced: false,
11914:             value: "1".into(),
11915:             value_span: None,
11916:         };
11917:         let mut script = Script::from_statements(vec![leaf]);
11918:         for _ in 0..DEPTH {
11919:             script = Script::from_statements(vec![Statement::If {
11920:                 span: Span::new(0, 0),
11921:                 clauses: vec![IfClause {
11922:                     condition: ExprNode::Raw { text: "1".into() },
11923:                     condition_span: Span::new(0, 0),
11924:                     body: script,
11925:                     body_span: Span::new(0, 0),
11926:                     condition_base: None,
11927:                 }],
11928:                 else_body: None,
11929:                 else_span: None,
11930:             }]);
11931:         }
11932: 
11933:         let reg = CommandRegistry::build_default();
11934:         let extra = collapsed_extra_defs(&script, &reg, 0);
11935:         // Nothing but the leaf `AssignConst` here is a def source visible to
11936:         // this helper (it only recovers `for`/condition-command-sub defs) —
11937:         // the assertion is that this returns at all without overflowing the
11938:         // stack, not what it returns.
11939:         let _ = extra;
11940:     }
11941: 
11942:     /// The classified uses of every `Call` in a one-statement proc, lowered
11943:     /// from source so the statement carries the real word snapshot.
11944:     fn classified_call_uses(body: &str) -> Vec<(String, UseClass)> {
11945:         let reg = CommandRegistry::build_default();
11946:         let src = format!("proc f {{tainted}} {{\n {body}\n}}");
11947:         let cu = crate::compilation_unit::CompilationUnit::build_for(&src, &reg, false);
11948:         let fu = cu.function("::f").expect("proc lowered");
11949:         let mut scanner = VarReferenceScanner::new(VarScanOptions::default());
11950:         let mut out = Vec::new();
11951:         for block in fu.cfg.blocks.values() {
11952:             for stmt in &block.statements {
11953:                 if matches!(stmt, Statement::Call { .. }) {
11954:                     out.extend(uses_of_classified(stmt, &mut scanner, &reg));
11955:                 }
11956:             }
11957:         }
11958:         out
11959:     }
11960: 
11961:     /// A braced word of a *nested* command is read exactly as the same word of
11962:     /// a direct call is, when the registry says the callee evaluates it in
11963:     /// this frame. Only a pair of braces separated `[expr $tainted]` (whose
11964:     /// read the enclosing word's own scan already saw) from
11965:     /// `[expr {$tainted}]`, which would otherwise be invisible to every
11966:     /// consumer of the use map.
11967:     #[test]
11968:     fn braced_word_of_a_nested_substitution_is_read_in_an_evaluated_role() {
11969:         let uses = classified_call_uses("puts [expr {$tainted}]");
11970:         assert!(
11971:             uses.contains(&("tainted".to_owned(), UseClass::Substituted)),
11972:             "an `Expr` role's braced word substitutes in this frame: {uses:?}"
11973:         );
11974:     }
11975: 
11976:     #[test]
11977:     fn conditional_nested_expression_reads_keep_original_tokens_without_entry() {
11978:         let registry = default_registry();
11979:         let source = "proc f {tainted} {puts [expr {$tainted + 1}]}";
11980:         let unit = crate::compilation_unit::CompilationUnit::build_for(source, &registry, false);
11981:         let function = unit.function("::f").unwrap();
11982:         let child = function
11983:             .cfg
11984:             .blocks
11985:             .values()
11986:             .flat_map(|block| &block.statements)
11987:             .filter_map(Statement::tokens)
11988:             .flat_map(|tokens| {
11989:                 crate::word_subst::lifted_calls(Some(tokens), unit.ir_module.lexer_config)
11990:             })
11991:             .find(|call| call.command == "expr")
11992:             .and_then(|call| call.tokens)
11993:             .expect("original nested expression");
11994:         let binding = child.source_binding.as_ref().unwrap();
11995:         assert_eq!(
11996:             binding.runtime_reachability(),
11997:             crate::command_binding::SourceRuntimeReachability::Conditional,
11998:         );
11999:         assert!(binding.proved_execution_target().is_none());
12000:         let scanner = VarReferenceScanner::new(VarScanOptions::default());
12001:         let mut reads = BTreeSet::new();
12002:         scan_selected_expression_roles(
12003:             &child,
12004:             &scanner,
12005:             SsaInvocationContext::standalone(&registry),
12006:             &mut reads,
12007:         );
12008:         assert_eq!(reads, BTreeSet::from(["tainted".to_owned()]));
12009: 
12010:         let mut foreign = child.clone();
12011:         foreign.argv_texts[1] = "$other + 1".to_owned();
12012:         foreign.word_exprs[1] = WordExpr::BracedLiteral {
12013:             text: "$other + 1".to_owned(),
12014:             source: foreign.word_exprs[1].source().clone(),
12015:         };
12016:         reads.clear();
12017:         scan_selected_expression_roles(
12018:             &foreign,
12019:             &scanner,
12020:             SsaInvocationContext::standalone(&registry),
12021:             &mut reads,
12022:         );
12023:         assert!(
12024:             reads.is_empty(),
12025:             "foreign source cannot borrow May-read topology"
12026:         );
12027:     }
12028: 
12029:     /// …and a braced word in a role the callee does *not* evaluate stays the
12030:     /// literal it is. `list` builds a value; `{$tainted}` is one of its
12031:     /// elements, not a script.
12032:     #[test]
12033:     fn braced_word_of_a_nested_substitution_stays_literal_in_a_data_role() {
12034:         let uses = classified_call_uses("puts [list {$tainted}]");
12035:         assert!(
12036:             !uses.contains(&("tainted".to_owned(), UseClass::Substituted)),
12037:             "`list` does not evaluate its arguments in the calling frame: {uses:?}"
12038:         );
12039:     }
12040: 
12041:     /// A nested command's **body** must not be read as a frame use, even
12042:     /// though a body written on a *statement* is. The difference is the
12043:     /// lowering: a statement's body becomes its own CFG block, so `lmap`'s
12044:     /// loop variable is defined where the body's reads are seen, while a
12045:     /// nested substitution gets no block at all — so its body's reads arrive
12046:     /// with none of its own definitions and `x` looks read-before-set.
12047:     #[test]
12048:     fn body_word_of_a_nested_substitution_is_not_a_frame_read() {
12049:         let uses = classified_call_uses("puts [join [lmap x $tainted {string toupper $x}] ,]");
12050:         assert!(
12051:             !uses.iter().any(|(name, _)| name == "x"),
12052:             "`lmap` binds its own loop variable; the frame never reads it: {uses:?}"
12053:         );
12054:     }
12055: 
12056:     /// A script a substitution runs in this frame — `catch`'s — shares the
12057:     /// frame's names, so `inner` is the frame's: its write is the effect
12058:     /// call's. The walk cannot order the script's read of it after the
12059:     /// script's own write, so the effect call reads it by name beside that
12060:     /// write, and nothing the host substitutes names it.
12061:     #[test]
12062:     fn a_protected_scripts_local_is_read_by_name_beside_its_write() {
12063:         let uses = classified_call_uses("puts [catch {set inner 1; expr {$inner + 1}}]");
12064:         let inner: Vec<_> = uses.iter().filter(|(name, _)| name == "inner").collect();
12065:         assert_eq!(inner, [&("inner".to_owned(), UseClass::Name)], "{uses:?}");
12066:     }
12067: 
12068:     /// The classified uses of every `AssignValue` in a one-statement proc —
12069:     /// the assignment twin of [`classified_call_uses`].
12070:     fn classified_assign_uses(body: &str) -> Vec<(String, UseClass)> {
12071:         let reg = CommandRegistry::build_default();
12072:         let src = format!("proc f {{tainted}} {{\n {body}\n}}");
12073:         let cu = crate::compilation_unit::CompilationUnit::build_for(&src, &reg, false);
12074:         let fu = cu.function("::f").expect("proc lowered");
12075:         let mut scanner = VarReferenceScanner::new(VarScanOptions::default());
12076:         let mut out = Vec::new();
12077:         for block in fu.cfg.blocks.values() {
12078:             for stmt in &block.statements {
12079:                 if matches!(stmt, Statement::AssignValue { .. }) {
12080:                     out.extend(uses_of_classified(stmt, &mut scanner, &reg));
12081:                 }
12082:             }
12083:         }
12084:         out
12085:     }
12086: 
12087:     /// An assignment's value word substitutes by exactly the rules a call's
12088:     /// word does, so the braced body of a nested `[expr …]`
12089:     /// is a read there too. Without it the expression's operands are absent
12090:     /// from `uses` and every consumer of that map — the expr shimmer detector
12091:     /// included — is blind to `set r [list [expr {$tainted + 1}]]`.
12092:     #[test]
12093:     fn braced_word_of_a_nested_substitution_is_read_in_an_assignment_value() {
12094:         let uses = classified_assign_uses("set r [list [expr {$tainted + 1}]]");
12095:         assert!(
12096:             uses.contains(&("tainted".to_owned(), UseClass::Substituted)),
12097:             "an `Expr` role's braced word substitutes in this frame: {uses:?}"
12098:         );
12099:     }
12100: 
12101:     /// …and the body exclusion holds on the assignment path too — this is the
12102:     /// spelling the repository's own corpus actually contains.
12103:     #[test]
12104:     fn body_word_of_a_nested_substitution_in_an_assignment_is_not_a_frame_read() {
12105:         let uses = classified_assign_uses("set r [join [lmap x $tainted {string toupper $x}] ,]");
12106:         assert!(
12107:             !uses.iter().any(|(name, _)| name == "x"),
12108:             "`lmap` binds its own loop variable; the frame never reads it: {uses:?}"
12109:         );
12110:     }
12111: 
12112:     /// The SSA of `source`'s function `name`, built as a unit builds it.
12113:     fn ssa_of_function(source: &str, name: &str) -> SsaFunction {
12114:         let reg = CommandRegistry::build_default();
12115:         let cu = crate::compilation_unit::CompilationUnit::build_for(source, &reg, false);
12116:         cu.function(name).expect("function analysed").ssa.clone()
12117:     }
12118: 
12119:     /// The SSA statements of `ssa` whose statement satisfies `wanted`.
12120:     fn statements_where(
12121:         ssa: &SsaFunction,
12122:         wanted: impl Fn(&Statement) -> bool,
12123:     ) -> Vec<&SsaStatement> {
12124:         ssa.blocks
12125:             .values()
12126:             .flat_map(|block| &block.statements)
12127:             .filter(|statement| wanted(&statement.statement))
12128:             .collect()
12129:     }
12130: 
12131:     /// The definition point the CFG builder puts ahead of a statement for
12132:     /// what the statement's `[…]` substitutions write.
12133:     fn is_effect_call(stmt: &Statement) -> bool {
12134:         stmt.word_effects_host().is_some()
12135:     }
12136: 
12137:     /// A statement's word effects are paired with the statement whose words
12138:     /// they are by construction: the statement right after the definition
12139:     /// point, whatever its span, and no other statement has a host. A control
12140:     /// statement's words have no statement of their own, so their definition
12141:     /// point has none.
12142:     #[test]
12143:     fn word_effects_stand_ahead_of_the_statement_whose_words_they_are() {
12144:         let effect_block = |source: &str, name: &str| {
12145:             let ssa = ssa_of_function(source, name);
12146:             let block = ssa
12147:                 .blocks
12148:                 .values()
12149:                 .find(|block| {
12150:                     block
12151:                         .statements
12152:                         .iter()
12153:                         .any(|info| is_effect_call(&info.statement))
12154:                 })
12155:                 .expect("a block with an effect call");
12156:             let call = block
12157:                 .statements
12158:                 .iter()
12159:                 .position(|info| is_effect_call(&info.statement))
12160:                 .expect("the effect call");
12161:             (block.statements.clone(), call)
12162:         };
12163:         for (source, name) in [
12164:             (
12165:                 "proc p {} {set x 1; set r [expr {$x + [incr x]}]; return $x}\n",
12166:                 "::p",
12167:             ),
12168:             ("set x 1\nset r [expr {[incr x] + [foo]}]\n", "::top"),
12169:             ("set x 1\nexpr {$x + [incr x]}\n", "::top"),
12170:         ] {
12171:             let (statements, call) = effect_block(source, name);
12172:             let host = word_effects_host(&statements, call).expect("the call has a host");
12173:             assert_eq!(host, call + 1, "{source}");
12174:             assert!(
12175:                 !is_synthetic_statement(&statements[host].statement),
12176:                 "{source}"
12177:             );
12178:             assert_eq!(
12179:                 statements[host].statement.span(),
12180:                 statements[call].statement.span(),
12181:                 "{source}"
12182:             );
12183:             for other in (0..statements.len()).filter(|&index| index != call) {
12184:                 assert_eq!(word_effects_host(&statements, other), None, "{source}");
12185:             }
12186:         }
12187:         let (mut statements, call) = effect_block(
12188:             "proc p {} {set x 1; set r [expr {$x + [incr x]}]; return $x}\n",
12189:             "::p",
12190:         );
12191:         let host = word_effects_host(&statements, call).expect("the call has a host");
12192:         let Statement::AssignExpr { span, .. } = &mut statements[host].statement else {
12193:             panic!("an assignment of an expression hosts the call");
12194:         };
12195:         *span = tcl_lexer::Span::new(span.start() + 1, span.end());
12196:         assert_eq!(word_effects_host(&statements, call), Some(host));
12197:         let (statements, call) = effect_block(
12198:             "proc p {} {set x 1; return [expr {$x + [incr x]}]}\n",
12199:             "::p",
12200:         );
12201:         assert_eq!(word_effects_host(&statements, call), None);
12202:     }
12203: 
12204:     /// The words of a statement whose `[…]` substitutions write a place read it
12205:     /// before, between and after the write. The effect call ahead of the
12206:     /// statement reads the version before the write, by name, so the store
12207:     /// feeding the word that runs first stays live, and the statement's own use
12208:     /// names the version after the write by name as well: no word of it is an
12209:     /// operand something may forward.
12210:     #[test]
12211:     fn an_effect_call_reads_the_version_before_the_write_its_statement_reads() {
12212:         for (body, reads_it) in [
12213:             ("set r [expr {$x + [set x 10] + $x}]", true),
12214:             ("expr {$x + [set x 10] + $x}", true),
12215:             ("set r \"$x [set x 10] $x\"", true),
12216:             ("incr r [expr {$x + [set x 10]}]", false),
12217:             ("set r [expr {[string length $x] + [set x 10]}]", false),
12218:             ("set r [expr {[expr {$x + 1}] + [set x 10]}]", false),
12219:         ] {
12220:             let source = format!("proc p {{}} {{\n set x 1\n set r 5\n {body}\n puts $x\n}}\n");
12221:             let ssa = ssa_of_function(&source, "::p");
12222:             let x = ssa.var_symbol("x").expect("x");
12223:             let call = statements_where(&ssa, is_effect_call)[0];
12224:             assert_eq!(call.defs[&x], 2, "{body}");
12225:             assert_eq!(call.uses.get(&x), Some(&1), "{body}");
12226:             assert!(call.name_only_uses.contains(&x), "{body}");
12227:             if reads_it {
12228:                 let host = statements_where(&ssa, |stmt| {
12229:                     matches!(
12230:                         stmt,
12231:                         Statement::AssignExpr { .. }
12232:                             | Statement::ExprEval { .. }
12233:                             | Statement::AssignValue { .. }
12234:                     ) && stmt.span() == call.statement.span()
12235:                 })[0];
12236:                 assert_eq!(host.uses.get(&x), Some(&2), "{body}");
12237:                 assert!(host.name_only_uses.contains(&x), "{body}");
12238:             }
12239:         }
12240:     }
12241: 
12242:     /// A place no word of the statement reads is not read by the call that
12243:     /// carries its write, so the store the write overwrites stays dead: the
12244:     /// call's read is for the words, not for every place it defines.
12245:     #[test]
12246:     fn an_effect_call_leaves_a_place_its_statement_never_reads_alone() {
12247:         for body in [
12248:             "set r [expr {[set x 10] + 1}]",
12249:             "set r \"[set x 10]\"",
12250:             "set r [expr {[gets $fd x] + 1}]",
12251:         ] {
12252:             let source = format!("proc p {{fd}} {{\n set x 1\n {body}\n puts $x\n}}\n");
12253:             let ssa = ssa_of_function(&source, "::p");
12254:             let x = ssa.var_symbol("x").expect("x");
12255:             let call = statements_where(&ssa, is_effect_call)[0];
12256:             assert_eq!(call.defs[&x], 2, "{body}");
12257:             assert_eq!(call.uses.get(&x), None, "{body}");
12258:         }
12259:     }
12260: 
12261:     /// A call that embeds the write holds it among its own definitions, and its
12262:     /// words read the place before, between and after it. It reads the version
12263:     /// before the write by name, and none of its words is an operand to forward;
12264:     /// a place the call names itself, in the position its command reads or
12265:     /// writes, stays what it was.
12266:     #[test]
12267:     fn a_call_reads_a_place_its_embedded_command_writes_by_name() {
12268:         for (command, body) in [
12269:             ("puts", "puts [expr {$x + [set x 10] + $x}]"),
12270:             ("puts", "puts \"$x [incr x] $x\""),
12271:             ("foo", "foo $x [incr x] $x"),
12272:             ("lappend", "lappend l [incr x] $x"),
12273:         ] {
12274:             let source = format!("proc p {{}} {{\n set x 1\n set l {{}}\n {body}\n puts $x\n}}\n");
12275:             let ssa = ssa_of_function(&source, "::p");
12276:             let x = ssa.var_symbol("x").expect("x");
12277:             let host = statements_where(
12278:                 &ssa,
12279:                 |stmt| matches!(stmt, Statement::Call { command: name, .. } if name == command),
12280:             )[0];
12281:             assert_eq!(host.uses.get(&x), Some(&1), "{body}");
12282:             assert_eq!(host.defs[&x], 2, "{body}");
12283:             assert!(host.name_only_uses.contains(&x), "{body}");
12284:         }
12285:         let ssa = ssa_of_function(
12286:             "proc p {} {\n set l {}\n lappend l $l\n puts $l\n}\n",
12287:             "::p",
12288:         );
12289:         let l = ssa.var_symbol("l").expect("l");
12290:         let host = statements_where(
12291:             &ssa,
12292:             |stmt| matches!(stmt, Statement::Call { command, .. } if command == "lappend"),
12293:         )[0];
12294:         assert!(
12295:             !host.name_only_uses.contains(&l),
12296:             "the command's own target is read before it writes it: its word is an operand"
12297:         );
12298:     }
12299: 
12300:     /// A `switch` the flow graph keeps as one statement defines, as may-defs,
12301:     /// every name its arms write or bind — the default arm's, a fall-through
12302:     /// arm's, a nested command's, an `incr`'s, a `lappend`'s and a `global`
12303:     /// binding's — and uses the prior version of each, quoted, so liveness
12304:     /// keeps the store that feeds it and no read-before-set is invented.
12305:     #[test]
12306:     fn an_opaque_switch_defines_every_name_its_arms_write() {
12307:         let ssa = ssa_of_function(
12308:             "proc p {s} {\n set x 1\n set n 0\n\
12309:              switch -glob -- $s {\n  a* - b* { set x 2 }\n  c* { if {[gets stdin line]} { incr n } }\n  default { lappend l 1; global g }\n }\n puts $x\n}\n",
12310:             "::p",
12311:         );
12312:         let statement = ssa
12313:             .blocks
12314:             .values()
12315:             .flat_map(|block| &block.statements)
12316:             .find(|statement| matches!(statement.statement, Statement::Switch { .. }))
12317:             .expect("the switch stays one statement");
12318:         let mut written: Vec<&str> = statement
12319:             .may_defs
12320:             .iter()
12321:             .map(|&symbol| ssa.var_name(symbol))
12322:             .collect();
12323:         written.sort_unstable();
12324:         assert_eq!(written, ["g", "l", "line", "n", "x"]);
12325:         for &symbol in &statement.may_defs {
12326:             assert!(statement.defs.contains_key(&symbol));
12327:             assert!(statement.quoted_uses.contains(&symbol));
12328:         }
12329:         // The read after the switch reads the version the switch defines.
12330:         let x = ssa.var_symbol("x").expect("x");
12331:         assert_eq!(statement.defs[&x], 2);
12332:         assert_eq!(statement.uses[&x], 1);
12333:     }
12334: 
12335:     /// The version each name holds where a call to a command the module cannot
12336:     /// see sits is recorded, in a procedure as at the top level; a version a
12337:     /// later definition makes is not.
12338:     #[test]
12339:     fn an_unseen_call_records_the_versions_live_where_it_sits() {
12340:         let ssa = ssa_of_function("set x 1\nset y 2\nfoo\nset x 3\nputs $x$y\n", "::top");
12341:         let x = ssa.var_symbol("x").expect("x");
12342:         let y = ssa.var_symbol("y").expect("y");
12343:         assert!(ssa.is_observed_by_unseen_call(x, 1));
12344:         assert!(ssa.is_observed_by_unseen_call(y, 1));
12345:         assert!(!ssa.is_observed_by_unseen_call(x, 2));
12346:         assert!(ssa.name_is_observed_by_unseen_call("x", 1));
12347:         assert!(!ssa.name_is_observed_by_unseen_call("nothing", 1));
12348:         let ssa = ssa_of_function("proc p {} {\n set x 1\n foo\n puts $x\n}\n", "::p");
12349:         assert!(ssa.name_is_observed_by_unseen_call("x", 1));
12350:         // A call the module resolves records nothing.
12351:         for (source, name) in [
12352:             ("proc foo {} { puts hi }\nset x 1\nfoo\nputs $x\n", "::top"),
12353:             ("set x 1\nputs $x\n", "::top"),
12354:         ] {
12355:             let ssa = ssa_of_function(source, name);
12356:             assert!(!ssa.name_is_observed_by_unseen_call("x", 1), "{source}");
12357:         }
12358:         // A command a substitution runs, a condition's and an arm's count too.
12359:         for source in [
12360:             "set x 1\nputs [foo]\n",
12361:             "set x 1\nwhile {[foo]} { puts hi }\n",
12362:             "set x 1\nswitch -glob -- $s { q* { foo } }\n",
12363:         ] {
12364:             let ssa = ssa_of_function(source, "::top");
12365:             assert!(ssa.name_is_observed_by_unseen_call("x", 1), "{source}");
12366:         }
12367:     }
12368: 
12369:     /// A sourced file runs in the frame of the call, so it may write or read
12370:     /// any name there: a top-level name, and a procedure's local too.
12371:     #[test]
12372:     fn a_sourced_file_records_the_versions_live_where_it_sits_in_a_procedure_too() {
12373:         for (source, name) in [
12374:             ("set x 1\nsource other.tcl\nputs $x\n", "::top"),
12375:             ("set x 1\nputs [source other.tcl]\n", "::top"),
12376:             (
12377:                 "proc p {} {\n set x 1\n source other.tcl\n puts $x\n}\n",
12378:                 "::p",
12379:             ),
12380:             (
12381:                 "proc p {s} {\n set x 1\n switch -glob -- $s { q* { source other.tcl } }\n puts $x\n}\n",
12382:                 "::p",
12383:             ),
12384:         ] {
12385:             let ssa = ssa_of_function(source, name);
12386:             assert!(ssa.name_is_observed_by_unseen_call("x", 1), "{source}");
12387:         }
12388:     }
12389: 
12390:     /// The statements of `function` in `source`, in block order.
12391:     fn ssa_statements(ssa: &SsaFunction) -> Vec<&SsaStatement> {
12392:         ssa.blocks
12393:             .values()
12394:             .flat_map(|block| &block.statements)
12395:             .collect()
12396:     }
12397: 
12398:     /// A callee an arm of an opaque `switch` calls writes the caller's name
12399:     /// through `upvar`, as it would at a call the graph lowers: the statement
12400:     /// that follows the `switch` defines the name as a *may*-definition that
12401:     /// uses the version before it, so the value the name held when no arm runs
12402:     /// survives into the join.
12403:     #[test]
12404:     fn an_opaque_switch_arm_that_calls_a_writer_may_define_the_name_it_writes() {
12405:         let ssa = ssa_of_function(
12406:             "proc zero {v} {upvar 1 $v x; set x 0}\nproc p {s} {\n set line 5\n\
12407:              switch -glob -- $s { g* { zero line } }\n puts $line\n}\n",
12408:             "::p",
12409:         );
12410:         let marker = ssa_statements(&ssa)
12411:             .into_iter()
12412:             .find(|statement| is_arm_writes_marker(&statement.statement))
12413:             .expect("the switch is followed by the marker for what its callee writes");
12414:         let line = ssa.var_symbol("line").expect("line");
12415:         assert_eq!(marker.may_defs, HashSet::from([line]));
12416:         assert_eq!(marker.defs[&line], 2);
12417:         assert_eq!(marker.uses[&line], 1);
12418:         assert!(marker.quoted_uses.contains(&line));
12419:         // A callee that writes a global, not this frame's name, adds no
12420:         // may-definition of a local, and an arm that calls nothing adds no
12421:         // marker.
12422:         for source in [
12423:             "proc hit {} {global hits; incr hits}\nproc p {s} {\n set n 5\n\
12424:              switch -glob -- $s { g* { hit } }\n puts $n\n}\n",
12425:             "proc p {s} {\n set n 5\n switch -glob -- $s { g* { set m 1 } }\n puts $n\n}\n",
12426:         ] {
12427:             let ssa = ssa_of_function(source, "::p");
12428:             let n = ssa.var_symbol("n").expect("n");
12429:             assert!(
12430:                 ssa_statements(&ssa)
12431:                     .into_iter()
12432:                     .filter(|statement| is_arm_writes_marker(&statement.statement))
12433:                     .all(|statement| !statement.may_defs.contains(&n)),
12434:                 "{source}"
12435:             );
12436:         }
12437:     }
12438: 
12439:     /// The body of an opaque `catch` stays inside the call, so what it writes is
12440:     /// a *may*-definition the marker ahead of the call states: it reads the
12441:     /// version before it, the solver joins the two, and the call itself defines
12442:     /// only its result variable.
12443:     #[test]
12444:     fn an_opaque_catch_may_define_the_names_its_body_writes() {
12445:         let ssa = ssa_of_function(
12446:             "set g 5\ncatch { if {[gets stdin] eq {q}} { set g 0 } } msg\nputs $g$msg\n",
12447:             "::top",
12448:         );
12449:         let statements = ssa_statements(&ssa);
12450:         let marker = statements
12451:             .iter()
12452:             .find(|statement| is_arm_writes_marker(&statement.statement))
12453:             .expect("the catch body's writes are stated ahead of the call");
12454:         let g = ssa.var_symbol("g").expect("g");
12455:         let msg = ssa.var_symbol("msg").expect("msg");
12456:         assert_eq!(marker.may_defs, HashSet::from([g]));
12457:         assert_eq!(marker.defs[&g], 2);
12458:         assert_eq!(marker.uses[&g], 1);
12459:         assert!(marker.quoted_uses.contains(&g));
12460:         let call = statements
12461:             .iter()
12462:             .find(|statement| {
12463:                 matches!(&statement.statement, Statement::Call { command, .. } if command == "catch")
12464:             })
12465:             .expect("the catch call");
12466:         assert!(call.defs.contains_key(&msg));
12467:         assert!(
12468:             !call.defs.contains_key(&g),
12469:             "the call defines no name its body writes"
12470:         );
12471:     }
12472: 
12473:     /// The call reads a name its body writes as the body's own: what the body
12474:     /// consumes of the frame is its reads less its writes, as an opaque
12475:     /// `switch`'s arms are read, so `catch {set i 0; puts $i}` reads nothing
12476:     /// of `i`, while a name the body only reads is still a read of the frame.
12477:     #[test]
12478:     fn an_opaque_catch_reads_its_own_writes_as_its_own() {
12479:         let ssa = ssa_of_function("catch {set i 0; puts $i; puts $j}\n", "::top");
12480:         let statements = ssa_statements(&ssa);
12481:         let call = statements
12482:             .iter()
12483:             .find(|statement| {
12484:                 matches!(&statement.statement, Statement::Call { command, .. } if command == "catch")
12485:             })
12486:             .expect("the catch call");
12487:         let i = ssa.var_symbol("i").expect("i");
12488:         let j = ssa.var_symbol("j").expect("j");
12489:         assert!(!call.uses.contains_key(&i), "{:?}", call.uses);
12490:         assert_eq!(call.uses.get(&j), Some(&0), "{:?}", call.uses);
12491:     }
12492: 
12493:     /// A call to a command the module cannot see reads its words before its
12494:     /// head runs, so the version each word reads is the one the call holds,
12495:     /// which is recorded — the code the call reaches may read it — and the code
12496:     /// may rewrite the name, so a read after the call is of the fresh version
12497:     /// the marker leaves, which is not, and whose binding is the version the
12498:     /// call held. A name only a braced word carries, which the code may
12499:     /// evaluate, is recorded as well.
12500:     #[test]
12501:     fn a_call_the_module_cannot_see_holds_the_versions_its_words_read() {
12502:         for (source, names) in [
12503:             ("set cmd puts\n$cmd hi\nputs $cmd\n", vec!["cmd"]),
12504:             ("set a 1\nset b 2\n$cmd $a $b\nputs $a$b\n", vec!["a", "b"]),
12505:             ("set a 1\nset b 2\nget $a $b\nputs $a$b\n", vec!["a", "b"]),
12506:             ("set f x.tcl\nsource $f\nputs $f\n", vec!["f"]),
12507:         ] {
12508:             let ssa = ssa_of_function(source, "::top");
12509:             for name in names {
12510:                 let symbol = ssa.var_symbol(name).expect("the name is an SSA symbol");
12511:                 assert!(
12512:                     ssa.name_is_observed_by_unseen_call(name, 1),
12513:                     "{source}: {name}#1"
12514:                 );
12515:                 assert!(
12516:                     !ssa.name_is_observed_by_unseen_call(name, 2),
12517:                     "{source}: {name}#2"
12518:                 );
12519:                 assert_eq!(ssa.binding_version(symbol, 2), 1, "{source}: {name}#2");
12520:             }
12521:         }
12522:         for source in [
12523:             "set cmd puts\nset x 1\n$cmd hi\nputs $x\n",
12524:             "set x 1\nget {$x}\nputs $x\n",
12525:             "set x 1\nputs [get $x]\nputs $x\n",
12526:         ] {
12527:             let ssa = ssa_of_function(source, "::top");
12528:             assert!(ssa.name_is_observed_by_unseen_call("x", 1), "{source}");
12529:         }
12530:     }
12531: 
12532:     /// The marker beside such a call defines no name: each name live past it
12533:     /// takes a fresh version where it stands
12534:     /// ([`SsaFunction::value_clobbers`]), whose binding is the version before
12535:     /// it, and a loop that holds the call places the φ the fresh version
12536:     /// needs. A name no read after the marker reaches takes none.
12537:     #[test]
12538:     fn the_marker_beside_a_call_the_module_cannot_see_gives_live_names_fresh_versions() {
12539:         let fresh = |ssa: &SsaFunction, symbol: Symbol| -> Vec<(Version, Version)> {
12540:             ssa.value_clobbers
12541:                 .values()
12542:                 .flat_map(HashMap::values)
12543:                 .filter_map(|versions| versions.get(&symbol).copied())
12544:                 .collect()
12545:         };
12546:         let ssa = ssa_of_function("set a 1\nget $a\nputs $a\n", "::top");
12547:         let marker = ssa_statements(&ssa)
12548:             .into_iter()
12549:             .find(|statement| is_unseen_call_marker(&statement.statement))
12550:             .expect("the call is followed by its marker");
12551:         assert!(marker.defs.is_empty() && marker.may_defs.is_empty());
12552:         let a = ssa.var_symbol("a").expect("a");
12553:         assert_eq!(fresh(&ssa, a), [(1, 2)]);
12554:         assert_eq!(ssa.binding_version(a, 2), 1);
12555: 
12556:         let ssa = ssa_of_function(
12557:             "set a 1\nwhile {[gets stdin line] >= 0} { get $a }\nputs $a\n",
12558:             "::top",
12559:         );
12560:         assert!(
12561:             ssa.blocks
12562:                 .values()
12563:                 .any(|block| block.phis.iter().any(|phi| ssa.var_name(phi.name) == "a")),
12564:             "the loop joins the fresh version `a` takes where the call sits"
12565:         );
12566: 
12567:         let ssa = ssa_of_function("set a 1\nget $a\nset a 2\nputs $a\n", "::top");
12568:         let a = ssa.var_symbol("a").expect("a");
12569:         assert!(fresh(&ssa, a).is_empty());
12570:     }
12571: 
12572:     /// A call to a command the module cannot see inside a `catch` body, or with
12573:     /// a computed head, records the versions live where it sits, as a call the
12574:     /// graph lowers does, in a procedure as at the top level; a call the module
12575:     /// resolves records nothing.
12576:     #[test]
12577:     fn a_catch_body_and_a_computed_head_record_the_versions_live_where_they_sit() {
12578:         for source in [
12579:             "set x 1\ncatch {foo}\nputs $x\n",
12580:             "set x 1\ncatch {foo} msg\nputs $x\n",
12581:             "set x 1\ncatch { if {1} { foo } }\nputs $x\n",
12582:             "set x 1\ncatch { puts [foo] }\nputs $x\n",
12583:             "set x 1\ncatch { source other.tcl }\nputs $x\n",
12584:             "set x 1\n$cmd\nputs $x\n",
12585:             "set x 1\n$cmd arg\nputs $x\n",
12586:             "set x 1\nputs [$cmd]\n",
12587:             "set x 1\nif {[$cmd]} { puts hi }\n",
12588:             "set x 1\nif {[catch {foo}]} { puts hi }\n",
12589:             "set x 1\nset rc [catch {foo}]\nputs $x\n",
12590:             "set x 1\nputs [catch { puts [foo] }]\n",
12591:             "set x 1\nif {[catch $script]} { puts hi }\n",
12592:         ] {
12593:             let ssa = ssa_of_function(source, "::top");
12594:             assert!(ssa.name_is_observed_by_unseen_call("x", 1), "{source}");
12595:         }
12596:         for (source, name, observed) in [
12597:             (
12598:                 "proc p {} {\n set x 1\n catch { if {1} { foo } }\n puts $x\n}\n",
12599:                 "::p",
12600:                 true,
12601:             ),
12602:             ("proc p {} {\n set x 1\n $cmd\n puts $x\n}\n", "::p", true),
12603:             ("proc p {} {\n set x 1\n puts [$cmd]\n}\n", "::p", true),
12604:             (
12605:                 "proc p {} {\n set x 1\n catch { if {1} { source other.tcl } }\n puts $x\n}\n",
12606:                 "::p",
12607:                 true,
12608:             ),
12609:             (
12610:                 "proc foo {} { puts hi }\nset x 1\ncatch { if {1} { foo } }\nputs $x\n",
12611:                 "::top",
12612:                 false,
12613:             ),
12614:         ] {
12615:             let ssa = ssa_of_function(source, name);
12616:             assert_eq!(
12617:                 ssa.name_is_observed_by_unseen_call("x", 1),
12618:                 observed,
12619:                 "{source}"
12620:             );
12621:         }
12622:     }
12623: 
12624:     /// A command an arm runs that may write any name — `namespace eval`,
12625:     /// `dict with`, `eval $script`, an `uplevel` — is followed by the barrier
12626:     /// the graph puts after such a command it lowers; an arm that holds none
12627:     /// has no barrier after it.
12628:     #[test]
12629:     fn an_opaque_switch_arm_that_may_write_any_name_is_followed_by_a_barrier() {
12630:         let barrier_after_switch = |source: &str, name: &str| {
12631:             let ssa = ssa_of_function(source, name);
12632:             let statements = ssa_statements(&ssa);
12633:             statements.iter().any(|statement| {
12634:                 matches!(
12635:                     &statement.statement,
12636:                     Statement::Barrier { tokens: Some(tokens), .. }
12637:                         if tokens.synthetic == Some(crate::ir::SyntheticMarker::CallerFrameOpaque)
12638:                 )
12639:             })
12640:         };
12641:         for (source, name) in [
12642:             (
12643:                 "set go 1\nswitch -glob -- [gets stdin] { q* { namespace eval :: {set go 0} } }\n",
12644:                 "::top",
12645:             ),
12646:             (
12647:                 "proc p {s} {\n set go 1\n switch -glob -- $s { q* { dict with d { set go 0 } } }\n}\n",
12648:                 "::p",
12649:             ),
12650:             (
12651:                 "proc p {s} {\n set go 1\n switch -glob -- $s { q* { eval $s } }\n}\n",
12652:                 "::p",
12653:             ),
12654:         ] {
12655:             assert!(barrier_after_switch(source, name), "{source}");
12656:         }
12657:         assert!(!barrier_after_switch(
12658:             "proc p {s} {\n set go 1\n switch -glob -- $s { q* { set go 0 } }\n}\n",
12659:             "::p"
12660:         ));
12661:     }
12662: }
/* ORIGINAL_SOURCE_RANGE 12697..14023 */
12697: #[cfg(test)]
12698: mod cell_resolution_tests {
12699:     use crate::interprocedural::test_body_identity::fixture_id;
12700: 
12701:     use super::*;
12702:     use crate::cfg::Terminator;
12703:     use tcl_lexer::Span;
12704: 
12705:     #[test]
12706:     fn caller_ssa_read_key_uses_typed_activation_identity() {
12707:         // Implementation contract: naming.variable.invocation-caller-ssa-frame
12708:         // docs/design/analysis/name-resolution-proofs/variable-invocation-caller-ssa-frame.md
12709:         let context = ResolveContext::default().in_frame(
12710:             &crate::var_resolve::VariableExecutionFrame::Procedure {
12711:                 namespace: "::".to_owned(),
12712:                 identity: "caller".to_owned(),
12713:             },
12714:         );
12715:         let caller = VariableCellKey::Activation {
12716:             identity: "caller".to_owned(),
12717:             simple: "shared".into(),
12718:         }
12719:         .with_lifetime(11)
12720:         .with_index("member");
12721:         let foreign = VariableCellKey::Activation {
12722:             identity: "callee".to_owned(),
12723:             simple: "local".into(),
12724:         };
12725:         assert_eq!(
12726:             invocation_read_key_in_context(caller.clone(), &context),
12727:             Some(caller)
12728:         );
12729:         assert!(invocation_read_key_in_context(foreign.clone(), &context).is_none());
12730:         assert!(
12731:             invocation_read_key_in_context(
12732:                 foreign.clone(),
12733:                 &ResolveContext::default()
12734:                     .in_frame(&crate::var_resolve::VariableExecutionFrame::Global)
12735:             )
12736:             .is_none()
12737:         );
12738:         let written = VariableCellKey::Authored(foreign.compatibility_name());
12739:         assert_eq!(
12740:             invocation_read_key_in_context(written.clone(), &context),
12741:             Some(written)
12742:         );
12743:         let shared = VariableCellKey::Namespace {
12744:             identity: crate::command_binding::SourceNamespaceKey::authored("::"),
12745:             simple: "shared".into(),
12746:         };
12747:         assert_eq!(
12748:             invocation_read_key_in_context(shared.clone(), &context),
12749:             Some(shared)
12750:         );
12751:     }
12752: 
12753:     #[test]
12754:     fn invocation_read_projection_keeps_physical_inventory_and_root_alias_reads() {
12755:         // Implementation contract: naming.variable.invocation-caller-ssa-frame
12756:         // docs/design/analysis/name-resolution-proofs/variable-invocation-caller-ssa-frame.md
12757:         let registry = tcl_registry::model::ingress::static_context_for("tcl8.6").commands();
12758:         for (source, foreign) in [
12759:             ("proc child {} {set local 1; set copy $local}; child", true),
12760:             (
12761:                 "set shared 1; proc child {} {upvar #0 shared alias; set copy $alias}; child",
12762:                 false,
12763:             ),
12764:         ] {
12765:             let unit = crate::compilation_unit::CompilationUnit::build_for_dialect(
12766:                 source, registry, false, "tcl8.6",
12767:             );
12768:             let ssa = &unit.top_level.ssa;
12769:             let mut seen = false;
12770:             for block in ssa.blocks.values() {
12771:                 for statement in &block.statements {
12772:                     let Some(tokens) = statement.statement.tokens() else {
12773:                         continue;
12774:                     };
12775:                     for place in
12776:                         crate::place_bridge::invocation_execution_read_places(tokens, registry)
12777:                     {
12778:                         let Some(key) = crate::var_resolve::canonical_binding_value_key(&place)
12779:                         else {
12780:                             continue;
12781:                         };
12782:                         if key.activation_identity().is_some() != foreign {
12783:                             continue;
12784:                         }
12785:                         seen = true;
12786:                         let used = statement
12787:                             .uses
12788:                             .keys()
12789:                             .any(|symbol| ssa.cell_key(*symbol) == Some(&key));
12790:                         assert_eq!(used, !foreign, "{source}/{key:?}");
12791:                     }
12792:                 }
12793:             }
12794:             assert!(
12795:                 seen,
12796:                 "original physical read inventory missing for {source}"
12797:             );
12798:         }
12799:     }
12800: 
12801:     #[test]
12802:     fn word_read_requires_original_spelling_as_well_as_site() {
12803:         let registry = tcl_registry::model::ingress::static_context_for("tcl8.6").commands();
12804:         let unit = crate::compilation_unit::CompilationUnit::build_for_dialect(
12805:             "set constructor list; set x [$constructor a b]; set out $x",
12806:             registry,
12807:             false,
12808:             "tcl8.6",
12809:         );
12810:         let ssa = &unit.top_level.ssa;
12811:         let mut reached = false;
12812:         for (&block, data) in &ssa.blocks {
12813:             for index in 0..data.statements.len() {
12814:                 let view = SsaSourceView::at_statement(ssa, block, index);
12815:                 let Some(tokens) = view.source_tokens() else {
12816:                     continue;
12817:                 };
12818:                 for original in tokens.words().iter().filter(|word| {
12819:                     word.sole_variable_substitution()
12820:                         .is_some_and(|(spelling, _)| spelling == "$x")
12821:                 }) {
12822:                     assert!(view.read_word(original).is_some());
12823:                     assert!(view.read_word_produces_value(original, registry));
12824:                     assert!(view.read_word_place(original, registry).is_some());
12825:                     assert_eq!(
12826:                         view.read_word_representation(original, registry),
12827:                         Some(tcl_syntax::value::ValueRepresentation::List)
12828:                     );
12829:                     let (_, source) = original.sole_variable_substitution().unwrap();
12830:                     let changed = WordExpr::Variable {
12831:                         spelling: "$z".into(),
12832:                         source: source.clone(),
12833:                     };
12834:                     assert!(view.read_word(&changed).is_none());
12835:                     assert!(!view.read_word_produces_value(&changed, registry));
12836:                     assert!(view.read_word_place(&changed, registry).is_none());
12837:                     assert!(view.read_word_contents(&changed, registry).is_none());
12838:                     assert!(view.read_word_representation(&changed, registry).is_none());
12839:                     assert!(
12840:                         view.read_word_representation_alternatives(&changed, registry)
12841:                             .is_none()
12842:                     );
12843:                     assert!(
12844:                         !view
12845:                             .read_word_representation_advice(&changed, registry)
12846:                             .already_numeric
12847:                     );
12848:                     reached = true;
12849:                 }
12850:             }
12851:         }
12852:         assert!(reached, "original physical read must be present");
12853:     }
12854: 
12855:     #[test]
12856:     fn expression_read_requires_original_spelling_as_well_as_extent() {
12857:         let registry = tcl_registry::model::ingress::static_context_for("tcl8.6").commands();
12858:         let unit = crate::compilation_unit::CompilationUnit::build_for_dialect(
12859:             "proc p {x} {expr {$x + 1}}",
12860:             registry,
12861:             false,
12862:             "tcl8.6",
12863:         );
12864:         let ssa = &unit
12865:             .procedures
12866:             .get(&fixture_id(&unit.procedures, "::p"))
12867:             .expect("authored fixture body")
12868:             .ssa;
12869:         let mut reached = false;
12870:         for (&block, data) in &ssa.blocks {
12871:             for index in (0..data.statements.len()).chain(std::iter::once(usize::MAX)) {
12872:                 let view = SsaSourceView::at_statement(ssa, block, index);
12873:                 let Some(tokens) = view.source_tokens() else {
12874:                     continue;
12875:                 };
12876:                 for access in tokens
12877:                     .variable_accesses
12878:                     .iter()
12879:                     .filter(|read| read.original_spelling == "$x")
12880:                 {
12881:                     let original = crate::expr_ast::ExprNode::Var {
12882:                         text: "$x".into(),
12883:                         name: "x".into(),
12884:                         start: 0,
12885:                         end: 1,
12886:                     };
12887:                     let base = Some(access.source.span.start());
12888:                     assert!(
12889:                         view.read_expression_variable_place(&original, base, registry)
12890:                             .is_some()
12891:                     );
12892:                     let changed = crate::expr_ast::ExprNode::Var {
12893:                         text: "$z".into(),
12894:                         name: "z".into(),
12895:                         start: 0,
12896:                         end: 1,
12897:                     };
12898:                     assert!(
12899:                         view.read_expression_variable_place(&changed, base, registry)
12900:                             .is_none()
12901:                     );
12902:                     assert!(
12903:                         view.read_expression_representation(&changed, base, None, registry)
12904:                             .is_none()
12905:                     );
12906:                     assert!(
12907:                         view.read_expression_representation_alternatives(
12908:                             &changed, base, None, registry
12909:                         )
12910:                         .is_none()
12911:                     );
12912:                     assert!(
12913:                         view.read_expression_variable_place(&original, None, registry)
12914:                             .is_none()
12915:                     );
12916:                     reached = true;
12917:                 }
12918:             }
12919:         }
12920:         assert!(reached, "the original expression read must be retained");
12921:     }
12922: 
12923:     #[test]
12924:     fn potential_missing_read_retains_closed_presence_alternatives() {
12925:         let registry = tcl_registry::model::ingress::static_context_for("tcl8.6").commands();
12926:         let unit = crate::compilation_unit::CompilationUnit::build_for_dialect(
12927:             "proc p {flag} {if {$flag} {set x 1}; set out $x}",
12928:             registry,
12929:             false,
12930:             "tcl8.6",
12931:         );
12932:         let ssa = &unit
12933:             .procedures
12934:             .get(&fixture_id(&unit.procedures, "::p"))
12935:             .expect("authored fixture body")
12936:             .ssa;
12937:         let mut reached = false;
12938:         for (&block, data) in &ssa.blocks {
12939:             for index in (0..data.statements.len()).chain(std::iter::once(usize::MAX)) {
12940:                 let view = SsaSourceView::at_statement(ssa, block, index);
12941:                 let Some(tokens) = view.source_tokens() else {
12942:                     continue;
12943:                 };
12944:                 for access in tokens
12945:                     .variable_accesses
12946:                     .iter()
12947:                     .filter(|read| read.original_spelling == "$x")
12948:                 {
12949:                     assert!(
12950:                         view.read_contents_presence_alternatives_at(&access.source, "$x", registry)
12951:                             .is_some_and(SsaReadPresenceAlternatives::may_be_undefined),
12952:                         "source={:?}; residual={:?}; presence={:?}",
12953:                         access.source,
12954:                         access.context_residual(),
12955:                         access
12956:                             .context_alternatives()
12957:                             .iter()
12958:                             .map(|context| {
12959:                                 let place = crate::var_resolve::resolve_substitution_access(
12960:                                     "$x",
12961:                                     context,
12962:                                     registry,
12963:                                     tcl_registry::TraceOperation::Read,
12964:                                 );
12965:                                 (place.observed, context.contents_presence(&place))
12966:                             })
12967:                             .collect::<Vec<_>>()
12968:                     );
12969:                     assert_eq!(
12970:                         view.read_contents_presence_at(&access.source, "$x", registry),
12971:                         Some(crate::var_resolve::ContentsPresence::Unknown)
12972:                     );
12973:                     assert_eq!(
12974:                         view.read_completion_at(&access.source, "$x", registry),
12975:                         Some(crate::var_resolve::VariableReadCompletion::Unknown)
12976:                     );
12977:                     assert!(
12978:                         view.read_reference(&access.source, "$x")
12979:                             .is_none_or(|read| read.version.is_none())
12980:                     );
12981:                     reached = true;
12982:                 }
12983:             }
12984:         }
12985:         assert!(reached);
12986:         assert!(
12987:             SsaSourceView::unpositioned(ssa)
12988:                 .read_contents_presence_alternatives_at(
12989:                     &SourceSite::source(Span::new(0, 2)),
12990:                     "$x",
12991:                     registry,
12992:                 )
12993:                 .is_none()
12994:         );
12995:     }
12996: 
12997:     #[test]
12998:     fn missing_read_completion_does_not_require_a_value_version() {
12999:         use crate::var_resolve::VariableReadCompletion;
13000: 
13001:         let registry = tcl_registry::model::ingress::static_context_for("tcl8.6").commands();
13002:         let unit = crate::compilation_unit::CompilationUnit::build_for_dialect(
13003:             "proc p {known} {set copy $known; set copy $missing}",
13004:             registry,
13005:             false,
13006:             "tcl8.6",
13007:         );
13008:         let ssa = &unit
13009:             .procedures
13010:             .get(&fixture_id(&unit.procedures, "::p"))
13011:             .expect("authored fixture body")
13012:             .ssa;
13013:         let mut missing = false;
13014:         let mut incoming = false;
13015:         for (&block, data) in &ssa.blocks {
13016:             for index in (0..data.statements.len()).chain(std::iter::once(usize::MAX)) {
13017:                 let view = SsaSourceView::at_statement(ssa, block, index);
13018:                 let Some(tokens) = view.source_tokens() else {
13019:                     continue;
13020:                 };
13021:                 for access in &tokens.variable_accesses {
13022:                     let completion = view.read_completion_at(
13023:                         &access.source,
13024:                         &access.original_spelling,
13025:                         registry,
13026:                     );
13027:                     match access.original_spelling.as_str() {
13028:                         "$missing" => {
13029:                             assert_eq!(completion, Some(VariableReadCompletion::Error));
13030:                             assert_eq!(
13031:                                 view.read_contents_presence_at(
13032:                                     &access.source,
13033:                                     &access.original_spelling,
13034:                                     registry,
13035:                                 ),
13036:                                 Some(crate::var_resolve::ContentsPresence::Undefined)
13037:                             );
13038:                             assert!(
13039:                                 view.read_reference(&access.source, &access.original_spelling)
13040:                                     .is_none_or(|read| read.version.is_none())
13041:                             );
13042:                             missing = true;
13043:                         }
13044:                         "$known" => {
13045:                             assert_eq!(completion, Some(VariableReadCompletion::Unknown));
13046:                             incoming = true;
13047:                         }
13048:                         _ => {}
13049:                     }
13050:                 }
13051:             }
13052:         }
13053:         assert!(
13054:             missing && incoming,
13055:             "both actual read contexts are retained"
13056:         );
13057:         assert!(SsaSourceView::unpositioned(ssa).source_tokens().is_none());
13058:     }
13059: 
13060:     #[test]
13061:     fn retained_word_read_success_is_separate_from_an_address_or_version() {
13062:         for (profile, body, expected) in [
13063:             ("tcl8.6", "set x 1; set copy $x", true),
13064:             ("tcl8.6", "set copy $missing", false),
13065:             ("tcl8.6", "array set a {k VALUE}; set copy $a", false),
13066:             ("tcl8.6", "set a(k) VALUE; set copy $a(k)", true),
13067:             ("jim", "set d odd; set copy $d(k)", false),
13068:         ] {
13069:             let registry = tcl_registry::model::ingress::static_context_for(profile).commands();
13070:             let source = format!("proc p {{}} {{{body}}}");
13071:             let unit = crate::compilation_unit::CompilationUnit::build_for_dialect(
13072:                 &source, registry, false, profile,
13073:             );
13074:             let ssa = &unit
13075:                 .procedures
13076:                 .get(&fixture_id(&unit.procedures, "::p"))
13077:                 .expect("authored fixture body")
13078:                 .ssa;
13079:             let mut reached = false;
13080:             for (&block, data) in &ssa.blocks {
13081:                 for index in 0..data.statements.len() {
13082:                     let view = SsaSourceView::at_statement(ssa, block, index);
13083:                     let Some(tokens) = view.source_tokens() else {
13084:                         continue;
13085:                     };
13086:                     for word in tokens.words() {
13087:                         if word.sole_variable_substitution().is_some() {
13088:                             assert_eq!(
13089:                                 view.read_word_produces_value(word, registry),
13090:                                 expected,
13091:                                 "{profile}: {body}"
13092:                             );
13093:                             reached = true;
13094:                         }
13095:                     }
13096:                 }
13097:             }
13098:             assert!(reached, "actual original read retained: {profile}: {body}");
13099:         }
13100:     }
13101: 
13102:     #[test]
13103:     fn scalar_read_of_an_array_is_not_a_missing_contents_proof() {
13104:         let registry = tcl_registry::model::ingress::static_context_for("tcl8.6").commands();
13105:         let unit = crate::compilation_unit::CompilationUnit::build_for_dialect(
13106:             "proc p {} {array set a {k VALUE}; puts $a}",
13107:             registry,
13108:             false,
13109:             "tcl8.6",
13110:         );
13111:         let ssa = &unit
13112:             .procedures
13113:             .get(&fixture_id(&unit.procedures, "::p"))
13114:             .expect("authored fixture body")
13115:             .ssa;
13116:         let mut reached = false;
13117:         for (&block, data) in &ssa.blocks {
13118:             for index in (0..data.statements.len()).chain(std::iter::once(usize::MAX)) {
13119:                 let view = SsaSourceView::at_statement(ssa, block, index);
13120:                 let Some(tokens) = view.source_tokens() else {
13121:                     continue;
13122:                 };
13123:                 for access in tokens
13124:                     .variable_accesses
13125:                     .iter()
13126:                     .filter(|read| read.original_spelling == "$a")
13127:                 {
13128:                     assert_eq!(
13129:                         view.read_completion_at(&access.source, "$a", registry),
13130:                         Some(crate::var_resolve::VariableReadCompletion::Error)
13131:                     );
13132:                     assert_eq!(
13133:                         view.read_contents_presence_at(&access.source, "$a", registry),
13134:                         Some(crate::var_resolve::ContentsPresence::Defined)
13135:                     );
13136:                     assert!(
13137:                         view.read_reference(&access.source, "$a")
13138:                             .is_none_or(|read| read.version.is_none()),
13139:                         "a rejected scalar read cannot supply an SSA value"
13140:                     );
13141:                     reached = true;
13142:                 }
13143:             }
13144:         }
13145:         assert!(reached, "the failing scalar read is retained");
13146:     }
13147: 
13148:     #[test]
13149:     fn caught_missing_catalogue_command_does_not_hide_unknown_fallback_mutations() {
13150:         let registry = tcl_registry::model::ingress::static_context_for("tcl8.4").commands();
13151:         let source = "set a old\ncatch {lassign {new second} a b} m\nputs $a\n";
13152:         let cu = crate::compilation_unit::CompilationUnit::build_for_profile(
13153:             source,
13154:             registry,
13155:             false,
13156:             registry.profile().unwrap(),
13157:         );
13158:         let function = &cu.top_level;
13159:         let point = function
13160:             .cfg
13161:             .blocks
13162:             .iter()
13163:             .find_map(|(&block, body)| {
13164:                 body.statements
13165:                     .iter()
13166:                     .enumerate()
13167:                     .find_map(|(index, statement)| {
13168:                         matches!(statement, Statement::Call {command, ..} if command == "puts")
13169:                             .then_some((block, index))
13170:                     })
13171:             })
13172:             .unwrap();
13173:         let view = SsaSourceView::at_statement(&function.ssa, point.0, point.1);
13174:         let read = view.read_spelling("a");
13175:         let contexts = function.ssa.point_contexts.as_ref().unwrap();
13176:         let context = contexts.before_statement(point.0, point.1);
13177:         assert!(
13178:             read.is_none_or(|read| read.version.is_none()),
13179:             "read={read:?} constants={:?} dynamic_bindings={} dynamic_traces={} source_reads={} point_names={:?}",
13180:             context.constant_values,
13181:             context.dynamic_bindings,
13182:             context.dynamic_traces,
13183:             contexts.source_reads_at(point.0, point.1).len(),
13184:             view.source_symbols().collect::<Vec<_>>(),
13185:         );
13186:     }
13187: 
13188:     #[test]
13189:     fn caught_error_only_fallback_preserves_the_reaching_cell_contents() {
13190:         let registry = tcl_registry::model::ingress::static_context_for("tcl8.4").commands();
13191:         let source = "proc unknown {args} {return -code error absent}\nset a old\ncatch {lassign {new second} a b} m\nputs $a\n";
13192:         let cu = crate::compilation_unit::CompilationUnit::build_for_profile(
13193:             source,
13194:             registry,
13195:             false,
13196:             registry.profile().unwrap(),
13197:         );
13198:         let function = &cu.top_level;
13199:         let read = function
13200:             .cfg
13201:             .blocks
13202:             .iter()
13203:             .find_map(|(&block, body)| {
13204:                 body.statements
13205:                     .iter()
13206:                     .enumerate()
13207:                     .find_map(|(index, statement)| {
13208:                         matches!(statement, Statement::Call {command, ..} if command == "puts")
13209:                             .then(|| {
13210:                                 SsaSourceView::at_statement(&function.ssa, block, index)
13211:                                     .read_spelling("a")
13212:                             })
13213:                     })
13214:             })
13215:             .flatten();
13216:         assert!(
13217:             read.is_some_and(|read| read.version.is_some()),
13218:             "read={read:?}"
13219:         );
13220:     }
13221: 
13222:     #[test]
13223:     fn scalar_clobber_keeps_contents_lineage_without_creating_a_store() {
13224:         let registry = tcl_registry::CommandRegistry::build_default();
13225:         let mut function = crate::cfg::Function::new("::f", "entry");
13226:         function
13227:             .blocks
13228:             .get_mut(&function.entry)
13229:             .unwrap()
13230:             .statements
13231:             .push(assignment("x"));
13232:         let mut ssa = build_ssa(&function, &registry);
13233:         let symbol = *ssa.blocks[&function.entry].statements[0]
13234:             .defs
13235:             .keys()
13236:             .next()
13237:             .unwrap();
13238:         let prior = ssa.blocks[&function.entry].statements[0].defs[&symbol];
13239:         let fresh = prior + 1;
13240:         ssa.value_clobbers.insert(
13241:             function.entry,
13242:             HashMap::from([(1, HashMap::from([(symbol, (prior, fresh))]))]),
13243:         );
13244:         let origins = represented_contents_origins(&ssa.blocks, &ssa.value_clobbers);
13245:         assert_eq!(origins[&(symbol, fresh)], ContentsOrigin::WrittenAt(0));
13246:         assert_eq!(ssa.binding_version(symbol, fresh), prior);
13247:         assert!(
13248:             !ssa.blocks[&function.entry]
13249:                 .statements
13250:                 .iter()
13251:                 .any(|statement| { statement.defs.get(&symbol) == Some(&fresh) })
13252:         );
13253:         // Destruction invalidates contents even though its predecessor has a
13254:         // real store. A later scalar clobber cannot revive that old value.
13255:         let statement = &mut ssa.blocks.get_mut(&function.entry).unwrap().statements[0];
13256:         statement.destruction_defs.insert(symbol);
13257:         let origins = represented_contents_origins(&ssa.blocks, &ssa.value_clobbers);
13258:         assert_eq!(origins[&(symbol, fresh)], ContentsOrigin::Unknown);
13259:     }
13260: 
13261:     #[test]
13262:     fn scalar_copy_cycles_defer_uncomputed_results_without_losing_the_store() {
13263:         let registry = tcl_registry::CommandRegistry::build_default();
13264:         let mut function = crate::cfg::Function::new("::f", "entry");
13265:         let mut store = assignment("x");
13266:         let Statement::AssignConst { span, .. } = &mut store else {
13267:             unreachable!();
13268:         };
13269:         *span = Span::new(5, 6);
13270:         function
13271:             .blocks
13272:             .get_mut(&function.entry)
13273:             .unwrap()
13274:             .statements
13275:             .push(store);
13276:         let ssa = build_ssa(&function, &registry);
13277:         let entry = ssa.blocks[&function.entry].clone();
13278:         let (&symbol, &written) = entry.statements[0].defs.iter().next().unwrap();
13279:         let empty = |name: &str| SsaBlock {
13280:             name: name.to_owned(),
13281:             phis: Vec::new(),
13282:             statements: Vec::new(),
13283:             entry_versions: HashMap::new(),
13284:             exit_versions: HashMap::new(),
13285:         };
13286:         // Four unique definitions cycle through an analysis-only copy:
13287:         // x1 = store(5), x3 = copy(x2), x2 = join(x1, x4, x4),
13288:         // x4 = join(x1, x3). Both phis have an independent store edge.
13289:         let mut blocks = HashMap::from([(function.entry, entry)]);
13290:         for id in 1..8 {
13291:             blocks.insert(BlockId(id), empty("retained"));
13292:         }
13293:         // Evaluate the header phi before the backedge phi under the actual
13294:         // map walk so a premature Unknown would circulate around the cycle.
13295:         let order: Vec<_> = blocks
13296:             .keys()
13297:             .copied()
13298:             .filter(|id| *id != function.entry)
13299:             .collect();
13300:         let (header, backedge) = (order[0], order[1]);
13301:         blocks.get_mut(&header).unwrap().phis.push(Phi {
13302:             name: symbol,
13303:             version: written + 1,
13304:             incoming: HashMap::from([
13305:                 (BlockId(0), written),
13306:                 (BlockId(4), written + 3),
13307:                 (BlockId(6), written + 3),
13308:             ]),
13309:         });
13310:         blocks.get_mut(&backedge).unwrap().phis.push(Phi {
13311:             name: symbol,
13312:             version: written + 3,
13313:             incoming: HashMap::from([(BlockId(0), written), (BlockId(1), written + 2)]),
13314:         });
13315:         let copies = HashMap::from([(
13316:             header,
13317:             HashMap::from([(0, HashMap::from([(symbol, (written + 1, written + 2))]))]),
13318:         )]);
13319:         let origins = represented_contents_origins(&blocks, &copies);
13320:         for version in written..=written + 3 {
13321:             assert_eq!(origins[&(symbol, version)], ContentsOrigin::WrittenAt(5));
13322:         }
13323:         // An actually absent predecessor remains unknown, independently of
13324:         // the deferred derived keys above.
13325:         blocks.get_mut(&backedge).unwrap().phis[0]
13326:             .incoming
13327:             .insert(BlockId(1), written + 4);
13328:         let origins = represented_contents_origins(&blocks, &copies);
13329:         assert_eq!(origins[&(symbol, written + 3)], ContentsOrigin::Unknown);
13330:         assert_eq!(origins[&(symbol, written + 1)], ContentsOrigin::Unknown);
13331:         blocks.get_mut(&backedge).unwrap().phis[0]
13332:             .incoming
13333:             .insert(BlockId(1), written + 2);
13334:         let copies = HashMap::from([(
13335:             header,
13336:             HashMap::from([(0, HashMap::from([(symbol, (written + 4, written + 2))]))]),
13337:         )]);
13338:         let origins = represented_contents_origins(&blocks, &copies);
13339:         assert_eq!(origins[&(symbol, written + 2)], ContentsOrigin::Unknown);
13340:         assert_eq!(origins[&(symbol, written + 3)], ContentsOrigin::Unknown);
13341:     }
13342: 
13343:     #[test]
13344:     fn computed_value_store_keeps_its_exact_following_read_origin() {
13345:         let registry = tcl_registry::model::ingress::static_context_for("tcl8.6").commands();
13346:         let source = "proc f {} {\n set b [binary format a* hello]\n set u [string toupper $b]\n}";
13347:         let unit = crate::compilation_unit::CompilationUnit::build_for(source, registry, false);
13348:         let function = unit.function("::f").unwrap();
13349:         let origins =
13350:             represented_contents_origins(&function.ssa.blocks, &function.ssa.value_clobbers);
13351:         let mut checked = 0;
13352:         for (&block, body) in &function.ssa.blocks {
13353:             for (index, statement) in body.statements.iter().enumerate() {
13354:                 let view = SsaSourceView::at_statement(&function.ssa, block, index);
13355:                 let Some(tokens) = view.source_tokens() else {
13356:                     continue;
13357:                 };
13358:                 for access in &tokens.variable_accesses {
13359:                     if access.original_spelling != "$b" && access.original_spelling != "${b}" {
13360:                         continue;
13361:                     }
13362:                     let target = source_read_place(access, registry);
13363:                     let read = view.read_reference(&access.source, &access.original_spelling);
13364:                     let origin = access
13365:                         .variable_context
13366:                         .read_contents_origin(&target, registry);
13367:                     assert!(
13368:                         read.is_some_and(|read| read.version.is_some()),
13369:                         "read={read:?} source_origin={origin:?} target={target:?} uses={:?} represented={origins:?} statement_span={:?}",
13370:                         statement.uses,
13371:                         statement.statement.span()
13372:                     );
13373:                     checked += 1;
13374:                 }
13375:             }
13376:         }
13377:         assert_eq!(checked, 1);
13378:     }
13379: 
13380:     fn assignment(name: &str) -> Statement {
13381:         Statement::AssignConst {
13382:             span: Span::new(0, 1),
13383:             name: name.to_owned(),
13384:             name_braced: false,
13385:             value: "10".to_owned(),
13386:             value_span: None,
13387:         }
13388:     }
13389: 
13390:     fn variable_return(name: &str) -> Terminator {
13391:         Terminator::Return {
13392:             tokens: None,
13393:             value: Some(format!("${name}")),
13394:             value_word: None,
13395:             span: None,
13396:             expr: None,
13397:             expr_base: None,
13398:             braced: false,
13399:         }
13400:     }
13401: 
13402:     #[test]
13403:     fn relative_qualified_write_and_absolute_read_share_symbol() {
13404:         let registry = tcl_registry::model::ingress::static_context_for("tcl8.6").commands();
13405:         let mut cfg = cfg::Function::new("::N::p", "entry");
13406:         let block = cfg.blocks.get_mut(&cfg.entry).expect("entry");
13407:         block.statements.push(assignment("R::x"));
13408:         block.terminator = Some(variable_return("::N::R::x"));
13409:         let mut entry = ResolveContext::for_function(&cfg.name);
13410:         entry.known_namespaces.insert("::N::R".to_owned());
13411:         entry.namespace_cells.present.insert("::N::R::x".to_owned());
13412:         let ssa = build_ssa_with_context(
13413:             &cfg,
13414:             registry,
13415:             tcl_lexer::LexerConfig::for_profile(registry.profile()),
13416:             entry,
13417:         );
13418:         let relative = ssa
13419:             .var_symbol_at(cfg.entry, 0, "R::x")
13420:             .expect("bound relative access");
13421:         assert_eq!(Some(relative), ssa.var_symbol("::N::R::x"));
13422:         assert!(
13423:             ssa.blocks[&cfg.entry].statements[0]
13424:                 .defs
13425:                 .contains_key(&relative)
13426:         );
13427:     }
13428: 
13429:     #[test]
13430:     fn top_level_global_and_bare_spelling_share_identity_and_keep_display_name() {
13431:         let registry = CommandRegistry::build_default();
13432:         let mut cfg = cfg::Function::new("::top", "entry");
13433:         let block = cfg.blocks.get_mut(&cfg.entry).expect("entry");
13434:         block.statements.push(assignment("g"));
13435:         block.terminator = Some(variable_return("::g"));
13436:         let ssa = build_ssa(&cfg, &registry);
13437:         let symbol = ssa.var_symbol("g").expect("source name");
13438:         assert_eq!(Some(symbol), ssa.var_symbol("::g"));
13439:         assert_eq!(ssa.var_name(symbol), "g");
13440:     }
13441:     #[test]
13442:     fn scalar_alias_write_after_unset_reaches_both_spellings() {
13443:         let registry = tcl_registry::model::ingress::static_context_for("tcl9.0").commands();
13444:         let source = "proc p {} {set x OLD; upvar 0 x y; unset x; set y NEW; puts $x; puts $y}; p";
13445:         let unit = crate::compilation_unit::CompilationUnit::build_for_dialect(
13446:             source, registry, false, "tcl9.0",
13447:         );
13448:         let ssa = &unit
13449:             .procedures
13450:             .get(&fixture_id(&unit.procedures, "::p"))
13451:             .expect("authored fixture body")
13452:             .ssa;
13453:         let mut written = None;
13454:         let mut read = Vec::new();
13455:         for (&block, body) in &ssa.blocks {
13456:             for (index, statement) in body.statements.iter().enumerate() {
13457:                 match &statement.statement {
13458:                     operation
13459:                         if source
13460:                             .get(operation.span().start() as usize..operation.span().end() as usize)
13461:                             .is_some_and(|text| text.starts_with("set y NEW")) =>
13462:                     {
13463:                         written = ssa.var_symbol_at(block, index, "y").and_then(|symbol| {
13464:                             statement
13465:                                 .defs
13466:                                 .get(&symbol)
13467:                                 .map(|&version| (symbol, version))
13468:                         });
13469:                     }
13470:                     Statement::Call { args, .. }
13471:                         if args.iter().any(|arg| {
13472:                             arg == "${x}" || arg == "${y}" || arg == "$x" || arg == "$y"
13473:                         }) =>
13474:                     {
13475:                         read.push((block, index, statement.uses.clone()));
13476:                     }
13477:                     _ => {}
13478:                 }
13479:             }
13480:         }
13481:         let (symbol, version) =
13482:             written.unwrap_or_else(|| panic!("alias store contents definition: {ssa:#?}"));
13483:         assert_eq!(read.len(), 2, "both puts reads: {ssa:#?}");
13484:         assert!(
13485:             read.iter()
13486:                 .all(|(_, _, uses)| uses.get(&symbol) == Some(&version)),
13487:             "scalar alias store must reach both spellings: {ssa:#?}"
13488:         );
13489:     }
13490:     #[test]
13491:     fn exact_reads_keep_alias_retargeting_within_one_word_separate() {
13492:         let registry = tcl_registry::model::ingress::static_context_for("tcl8.6").commands();
13493:         let source = "proc p {} {set x OLD; set y NEW; upvar 0 x a; puts \"$a[upvar 0 y a]$a\"}; p";
13494:         let unit = crate::compilation_unit::CompilationUnit::build_for_dialect(
13495:             source, registry, false, "tcl8.6",
13496:         );
13497:         let ssa = &unit
13498:             .procedures
13499:             .get(&fixture_id(&unit.procedures, "::p"))
13500:             .expect("authored fixture body")
13501:             .ssa;
13502:         let mut pairs = Vec::new();
13503:         for (&block, body) in &ssa.blocks {
13504:             for index in 0..body.statements.len() {
13505:                 let view = SsaSourceView::at_statement(ssa, block, index);
13506:                 let Some(tokens) = view.source_tokens() else {
13507:                     continue;
13508:                 };
13509:                 let reads: Vec<_> = tokens
13510:                     .variable_accesses
13511:                     .iter()
13512:                     .filter(|access| access.original_spelling == "$a")
13513:                     .filter_map(|access| {
13514:                         view.read_reference(&access.source, &access.original_spelling)
13515:                     })
13516:                     .collect();
13517:                 if reads.len() == 2 {
13518:                     assert!(view.is_positioned());
13519:                     assert!(view.read_spelling("a").is_none());
13520:                     assert!(
13521:                         view.symbol("a").is_none(),
13522:                         "one source name cannot select two cells"
13523:                     );
13524:                     pairs.push(reads);
13525:                 }
13526:             }
13527:         }
13528:         assert_eq!(pairs.len(), 1, "{ssa:#?}");
13529:         assert_ne!(pairs[0][0].symbol, pairs[0][1].symbol);
13530:         assert!(pairs[0].iter().all(|read| read.version.is_some()));
13531:     }
13532: 
13533:     #[test]
13534:     fn incoming_slot_projection_keeps_distinct_call_activations() {
13535:         let registry = tcl_registry::model::ingress::static_context_for("tcl8.6").commands();
13536:         let source = "proc p {n} {return [expr {$n + 0}]}; p 20; p 21";
13537:         let unit = crate::compilation_unit::CompilationUnit::build_for_dialect(
13538:             source, registry, false, "tcl8.6",
13539:         );
13540:         let ssa = &unit
13541:             .procedures
13542:             .get(&fixture_id(&unit.procedures, "::p"))
13543:             .expect("authored fixture body")
13544:             .ssa;
13545:         let node = tcl_syntax::expr::parser::parse_expr("$n", Some("tcl8.6"));
13546:         let base = Some(u32::try_from(source.find("$n").unwrap()).unwrap());
13547:         let mut proofs = Vec::new();
13548:         for (&block, data) in &ssa.blocks {
13549:             for index in (0..data.statements.len()).chain(std::iter::once(usize::MAX)) {
13550:                 let view = SsaSourceView::at_statement(ssa, block, index);
13551:                 if let Some(proof) = view.read_expression_incoming_slot(&node, base, "n", registry)
13552:                 {
13553:                     proofs.push(proof);
13554:                 }
13555:             }
13556:         }
13557:         assert!(
13558:             !proofs.is_empty(),
13559:             "the reached ordinary formal has an input proof"
13560:         );
13561:         assert!(proofs.iter().all(|proof| proof.slot == "n"));
13562:         assert!(
13563:             proofs.iter().any(|proof| proof.cells.len() >= 2),
13564:             "separate callers retain separate physical owners: {proofs:?}"
13565:         );
13566:     }
13567: 
13568:     #[test]
13569:     fn incoming_slot_projection_rejects_a_formal_rebound_to_global_storage() {
13570:         let registry = tcl_registry::model::ingress::static_context_for("tcl8.6").commands();
13571:         let source =
13572:             "set n 100; proc p {n} {unset n; global n; return [expr {$n + 0}]}; p 20; p 21";
13573:         let unit = crate::compilation_unit::CompilationUnit::build_for_dialect(
13574:             source, registry, false, "tcl8.6",
13575:         );
13576:         let ssa = &unit
13577:             .procedures
13578:             .get(&fixture_id(&unit.procedures, "::p"))
13579:             .expect("authored fixture body")
13580:             .ssa;
13581:         let node = tcl_syntax::expr::parser::parse_expr("$n", Some("tcl8.6"));
13582:         let base = Some(u32::try_from(source.find("$n").unwrap()).unwrap());
13583:         let mut reached = false;
13584:         for (&block, data) in &ssa.blocks {
13585:             for index in (0..data.statements.len()).chain(std::iter::once(usize::MAX)) {
13586:                 let view = SsaSourceView::at_statement(ssa, block, index);
13587:                 reached |= view.expression_variable_access(&node, base).is_some();
13588:                 assert!(
13589:                     view.read_expression_incoming_slot(&node, base, "n", registry)
13590:                         .is_none()
13591:                 );
13592:             }
13593:         }
13594:         assert!(
13595:             reached,
13596:             "the global read is retained but is not a formal input"
13597:         );
13598:     }
13599: 
13600:     fn iteration_read_summary(
13601:         function: &crate::compilation_unit::FunctionUnit,
13602:         registry: &CommandRegistry,
13603:     ) -> String {
13604:         let mut original = Vec::new();
13605:         for (&block, data) in &function.ssa.blocks {
13606:             for (index, statement) in data.statements.iter().enumerate() {
13607:                 let view = SsaSourceView::at_statement(&function.ssa, block, index);
13608:                 let Some(tokens) = view.source_tokens() else {
13609:                     continue;
13610:                 };
13611:                 for access in tokens
13612:                     .variable_accesses
13613:                     .iter()
13614:                     .filter(|access| access.original_spelling == "$l")
13615:                 {
13616:                     let place = source_read_place(access, registry);
13617:                     original.push((
13618:                         block,
13619:                         index,
13620:                         tokens.synthetic,
13621:                         &statement.defs,
13622:                         &statement.uses,
13623:                         access.source.span,
13624:                         place.clone(),
13625:                         access
13626:                             .variable_context
13627:                             .read_contents_origin(&place, registry),
13628:                         view.read_reference(&access.source, &access.original_spelling),
13629:                     ));
13630:                 }
13631:             }
13632:         }
13633:         format!("{original:?}")
13634:     }
13635: 
13636:     #[test]
13637:     fn entered_iteration_store_provides_the_body_read_version() {
13638:         let registry = tcl_registry::model::ingress::static_context_for("tcl8.6").commands();
13639:         // The stock outer List closes iteration callbacks without normalising
13640:         // its unknown element before the retained original body read.
13641:         let source = "proc p {item} {set l [list $item]; foreach x $l {set y [expr {$x + 1}]}}";
13642:         let unit = crate::compilation_unit::CompilationUnit::build_for_dialect(
13643:             source, registry, false, "tcl8.6",
13644:         );
13645:         let ssa = &unit
13646:             .procedures
13647:             .get(&fixture_id(&unit.procedures, "::p"))
13648:             .expect("authored fixture body")
13649:             .ssa;
13650:         let mut reads = Vec::new();
13651:         let mut inventory = Vec::new();
13652:         for (&block, data) in &ssa.blocks {
13653:             for index in (0..data.statements.len()).chain(std::iter::once(usize::MAX)) {
13654:                 let view = SsaSourceView::at_statement(ssa, block, index);
13655:                 let Some(tokens) = view.source_tokens() else {
13656:                     continue;
13657:                 };
13658:                 inventory.push((
13659:                     block,
13660:                     index,
13661:                     tokens.argv_texts.first().cloned(),
13662:                     tokens.source_binding.as_ref().map(|binding| {
13663:                         (
13664:                             binding.unknown,
13665:                             binding.may_be_absent,
13666:                             binding
13667:                                 .targets
13668:                                 .iter()
13669:                                 .map(|target| target.command.as_str())
13670:                                 .collect::<Vec<_>>(),
13671:                         )
13672:                     }),
13673:                     tokens
13674:                         .nested_bindings
13675:                         .iter()
13676:                         .map(|(site, binding)| {
13677:                             (
13678:                                 site,
13679:                                 binding.unknown,
13680:                                 binding.may_be_absent,
13681:                                 binding
13682:                                     .targets
13683:                                     .iter()
13684:                                     .map(|target| target.command.as_str())
13685:                                     .collect::<Vec<_>>(),
13686:                                 binding.compiled_execution_residual,
13687:                             )
13688:                         })
13689:                         .collect::<Vec<_>>(),
13690:                     tokens
13691:                         .variable_accesses
13692:                         .iter()
13693:                         .map(|access| (&access.source, &access.original_spelling))
13694:                         .collect::<Vec<_>>(),
13695:                 ));
13696:                 for access in tokens
13697:                     .variable_accesses
13698:                     .iter()
13699:                     .filter(|access| source_read_name(access) == "x")
13700:                 {
13701:                     let place = source_read_place(access, registry);
13702:                     let origin = access
13703:                         .variable_context
13704:                         .read_contents_origin(&place, registry);
13705:                     let read = view.read_reference(&access.source, &access.original_spelling);
13706:                     assert!(
13707:                         read.is_some_and(|read| read.version.is_some_and(|version| version > 0)),
13708:                         "entered iterator value has a represented store: place={place:?}, origin={origin:?}, read={read:?}"
13709:                     );
13710:                     reads.push(read.unwrap());
13711:                 }
13712:             }
13713:         }
13714:         assert!(
13715:             !reads.is_empty(),
13716:             "the reached expression read is retained: {inventory:?}"
13717:         );
13718:     }
13719: 
13720:     #[test]
13721:     fn iteration_input_reference_keeps_preloop_version_when_body_mutates_list() {
13722:         let registry = tcl_registry::model::ingress::static_context_for("tcl8.6").commands();
13723:         let source = "proc p {} {set l BEFORE; foreach x $l {set l AFTER}; return $x}; p";
13724:         let unit = crate::compilation_unit::CompilationUnit::build_for_dialect(
13725:             source, registry, false, "tcl8.6",
13726:         );
13727:         let function = unit
13728:             .procedures
13729:             .get(&fixture_id(&unit.procedures, "::p"))
13730:             .expect("authored fixture body");
13731:         let mut cached = Vec::new();
13732:         for (&block, data) in &function.ssa.blocks {
13733:             for (index, statement) in data.statements.iter().enumerate() {
13734:                 if statement.statement.tokens().is_none_or(|tokens| {
13735:                     !matches!(
13736:                         tokens.synthetic,
13737:                         Some(crate::ir::SyntheticMarker::IterationBindings(_))
13738:                     )
13739:                 }) {
13740:                     continue;
13741:                 }
13742:                 assert!(function.cfg.source_tokens_at(block, index).is_none());
13743:                 assert!(function.cfg.source_tokens_at(block, usize::MAX).is_none());
13744:                 let input = function.cfg.source_input_tokens_at(block, index).unwrap();
13745:                 let view = SsaSourceView::at_statement(&function.ssa, block, index);
13746:                 cached.push(view.read_word(&input.words()[1]).unwrap_or_else(|| {
13747:                     let accesses: Vec<_> = input
13748:                         .variable_accesses
13749:                         .iter()
13750:                         .map(|access| {
13751:                             (
13752:                                 access.source.span,
13753:                                 &access.original_spelling,
13754:                                 source_read_place(access, registry),
13755:                                 view.read_reference(&access.source, &access.original_spelling),
13756:                             )
13757:                         })
13758:                         .collect();
13759:                     let original = iteration_read_summary(function, registry);
13760:                     panic!(
13761:                         "original captured input read: word={:?}, accesses={accesses:?}, evaluated={original:?}",
13762:                         input.words()[1]
13763:                     )
13764:                 }));
13765:                 assert!(
13766:                     !statement.uses.contains_key(&cached.last().unwrap().symbol),
13767:                     "cached list is not reevaluated"
13768:                 );
13769:             }
13770:         }
13771:         assert_eq!(cached.len(), 1);
13772:         for (&block, data) in &function.cfg.blocks {
13773:             if matches!(data.terminator, Some(Terminator::Goto { .. })) {
13774:                 assert!(function.cfg.source_tokens_at(block, usize::MAX).is_none());
13775:                 assert_eq!(
13776:                     function
13777:                         .ssa
13778:                         .point_contexts
13779:                         .as_ref()
13780:                         .unwrap()
13781:                         .source_reads_at(block, usize::MAX),
13782:                     [] as [crate::command_binding::SourceVariableAccess; 0]
13783:                 );
13784:             }
13785:         }
13786:         let version = cached[0].version.expect("represented preloop definition");
13787:         let (block, index, _) = function
13788:             .ssa
13789:             .blocks
13790:             .iter()
13791:             .flat_map(|(&block, data)| {
13792:                 data.statements
13793:                     .iter()
13794:                     .enumerate()
13795:                     .map(move |(index, statement)| (block, index, statement))
13796:             })
13797:             .find(|(_, _, statement)| statement.defs.get(&cached[0].symbol) == Some(&version))
13798:             .unwrap();
13799:         let source = SsaSourceView::at_statement(&function.ssa, block, index);
13800:         assert!(
13801:             matches!(source.source_tokens().and_then(|tokens| tokens.words().get(2)),
13802:             Some(crate::ir::WordExpr::Literal { text, .. }) if text == "BEFORE")
13803:         );
13804:     }
13805: 
13806:     #[test]
13807:     fn terminator_read_consensus_declines_retargeted_source_spelling() {
13808:         let registry = tcl_registry::model::ingress::static_context_for("tcl8.6").commands();
13809:         let source =
13810:             "proc p {} {set x OLD; set y NEW; upvar 0 x a; return \"$a[upvar 0 y a]$a\"}; p";
13811:         let unit = crate::compilation_unit::CompilationUnit::build_for_dialect(
13812:             source, registry, false, "tcl8.6",
13813:         );
13814:         let ssa = &unit
13815:             .procedures
13816:             .get(&fixture_id(&unit.procedures, "::p"))
13817:             .expect("authored fixture body")
13818:             .ssa;
13819:         let mut pairs = Vec::new();
13820:         for &block in ssa.blocks.keys() {
13821:             let view = SsaSourceView::at_terminator(ssa, block);
13822:             let Some(tokens) = view.source_tokens() else {
13823:                 continue;
13824:             };
13825:             let reads: Vec<_> = tokens
13826:                 .variable_accesses
13827:                 .iter()
13828:                 .filter(|access| access.original_spelling == "$a")
13829:                 .filter_map(|access| view.read_reference(&access.source, &access.original_spelling))
13830:                 .collect();
13831:             if reads.len() == 2 {
13832:                 assert!(view.symbol("a").is_none());
13833:                 assert!(view.read_spelling("a").is_none());
13834:                 pairs.push(reads);
13835:             }
13836:         }
13837:         assert_eq!(pairs.len(), 1);
13838:         assert_ne!(pairs[0][0].symbol, pairs[0][1].symbol);
13839:         assert!(pairs[0].iter().all(|read| read.version.is_some()));
13840:     }
13841: 
13842:     #[test]
13843:     fn reaching_binding_resolves_contents_at_a_goto_without_inventing_a_read() {
13844:         let registry = tcl_registry::model::ingress::static_context_for("tcl9.1").commands();
13845:         let unit = crate::compilation_unit::CompilationUnit::build_for_profile(
13846:             "proc a {} {set j 0; for {set k 5} {$k > 0} {incr k -1} {incr j}}",
13847:             registry,
13848:             false,
13849:             registry.profile().unwrap(),
13850:         );
13851:         let function = unit.function("::a").unwrap();
13852:         let node = function.cfg.loop_nodes.values().next().unwrap();
13853:         let view = SsaSourceView::at_terminator(&function.ssa, node.entry_block);
13854:         assert!(view.source_symbols().next().is_none());
13855:         let reaching = view.reaching_binding("j", registry).unwrap();
13856:         let version = reaching.version.expect("the literal store is represented");
13857:         assert_eq!(
13858:             function.sccp.values.get(&(reaching.symbol, version)),
13859:             Some(&crate::analyses::LatticeValue::Const(
13860:                 crate::analyses::ConstValue::Int(0)
13861:             )),
13862:         );
13863:         assert!(view.reaching_binding("missing", registry).is_none());
13864:         assert!(
13865:             SsaSourceView::unpositioned(&function.ssa)
13866:                 .reaching_binding("j", registry)
13867:                 .is_none()
13868:         );
13869:         assert!(
13870:             SsaSourceView::at_terminator(&function.ssa, BlockId(u32::MAX))
13871:                 .reaching_binding("j", registry)
13872:                 .is_none()
13873:         );
13874:     }
13875: 
13876:     #[test]
13877:     fn reaching_binding_declines_contents_after_an_unrepresented_mutation() {
13878:         let registry = tcl_registry::model::ingress::static_context_for("tcl9.1").commands();
13879:         let unit = crate::compilation_unit::CompilationUnit::build_for_profile(
13880:             "proc a {cmd} {set x OLD; $cmd}",
13881:             registry,
13882:             false,
13883:             registry.profile().unwrap(),
13884:         );
13885:         let function = unit.function("::a").unwrap();
13886:         let block = function
13887:             .ssa
13888:             .blocks
13889:             .iter()
13890:             .find(|(_, block)| {
13891:                 block.statements.iter().any(|statement| {
13892:                     statement
13893:                         .statement
13894:                         .tokens()
13895:                         .and_then(|tokens| tokens.words().first())
13896:                         .is_some_and(|head| matches!(head, crate::ir::WordExpr::Variable { .. }))
13897:                 })
13898:             })
13899:             .unwrap()
13900:             .0;
13901:         let view = SsaSourceView::at_terminator(&function.ssa, *block);
13902:         assert!(
13903:             view.reaching_binding("x", registry)
13904:                 .is_none_or(|reaching| reaching.version.is_none()),
13905:             "unknown contents cannot borrow the prior store",
13906:         );
13907:     }
13908: 
13909:     #[test]
13910:     fn nested_contents_store_does_not_borrow_an_earlier_ssa_version() {
13911:         let registry = tcl_registry::model::ingress::static_context_for("tcl8.6").commands();
13912:         let source = "proc p {} {set x OLD; puts \"$x[set x NEW]$x\"}; p";
13913:         let unit = crate::compilation_unit::CompilationUnit::build_for_dialect(
13914:             source, registry, false, "tcl8.6",
13915:         );
13916:         let ssa = &unit
13917:             .procedures
13918:             .get(&fixture_id(&unit.procedures, "::p"))
13919:             .expect("authored fixture body")
13920:             .ssa;
13921:         let mut pairs = Vec::new();
13922:         for (&block, body) in &ssa.blocks {
13923:             for index in 0..body.statements.len() {
13924:                 let view = SsaSourceView::at_statement(ssa, block, index);
13925:                 let Some(tokens) = view.source_tokens() else {
13926:                     continue;
13927:                 };
13928:                 let reads: Vec<_> = tokens
13929:                     .variable_accesses
13930:                     .iter()
13931:                     .filter(|access| access.original_spelling == "$x")
13932:                     .filter_map(|access| {
13933:                         view.read_reference(&access.source, &access.original_spelling)
13934:                     })
13935:                     .collect();
13936:                 if reads.len() == 2 {
13937:                     assert!(view.read_spelling("x").is_none());
13938:                     pairs.push(reads);
13939:                 }
13940:             }
13941:         }
13942:         assert_eq!(pairs.len(), 1, "{ssa:#?}");
13943:         assert_eq!(pairs[0][0].symbol, pairs[0][1].symbol);
13944:         assert!(pairs[0][0].version.is_some());
13945:         assert!(pairs[0][1].version.is_none());
13946:     }
13947: 
13948:     #[test]
13949:     fn name_only_read_projection_requires_reached_consensus() {
13950:         let registry = tcl_registry::model::ingress::static_context_for("tcl8.6").commands();
13951:         let unit = crate::compilation_unit::CompilationUnit::build_for_dialect(
13952:             "proc p {} {set x OLD; puts \"$x$x\"}; p",
13953:             registry,
13954:             false,
13955:             "tcl8.6",
13956:         );
13957:         let ssa = &unit
13958:             .procedures
13959:             .get(&fixture_id(&unit.procedures, "::p"))
13960:             .expect("authored fixture body")
13961:             .ssa;
13962:         let mut projected = Vec::new();
13963:         for (&block, body) in &ssa.blocks {
13964:             for index in 0..body.statements.len() {
13965:                 let view = SsaSourceView::at_statement(ssa, block, index);
13966:                 assert!(view.read_spelling("unreached").is_none());
13967:                 if let Some(read) = view.read_spelling("x") {
13968:                     assert!(read.version.is_some());
13969:                     projected.push(read);
13970:                 }
13971:             }
13972:         }
13973:         assert_eq!(projected.len(), 1);
13974:         assert!(!SsaSourceView::unpositioned(ssa).is_positioned());
13975:         assert!(
13976:             SsaSourceView::unpositioned(ssa)
13977:                 .read_spelling("x")
13978:                 .is_none()
13979:         );
13980:     }
13981: 
13982:     #[test]
13983:     fn computed_command_head_keeps_its_captured_read_inside_dictionary_iteration() {
13984:         let registry = tcl_registry::model::ingress::static_context_for("tcl8.6").commands();
13985:         let unit = crate::compilation_unit::CompilationUnit::build_for(
13986:             "proc demo {} {\n    set x set\n    set d [dict create a true b false c true]\n    dict for {key value} $d {\n        if {$value} {\n            $x a $key\n        }\n    }\n}\n",
13987:             registry,
13988:             false,
13989:         );
13990:         let ssa = &unit.function("::demo").unwrap().ssa;
13991:         let mut inventory = Vec::new();
13992:         let mut reads = Vec::new();
13993:         for (&block, body) in &ssa.blocks {
13994:             for index in 0..body.statements.len() {
13995:                 let view = SsaSourceView::at_statement(ssa, block, index);
13996:                 let Some(tokens) = view.source_tokens() else {
13997:                     continue;
13998:                 };
13999:                 inventory.push((
14000:                     tokens.words().first().map(WordExpr::legacy_text),
14001:                     tokens
14002:                         .variable_accesses
14003:                         .iter()
14004:                         .map(|access| access.original_spelling.clone())
14005:                         .collect::<Vec<_>>(),
14006:                 ));
14007:                 for access in tokens
14008:                     .variable_accesses
14009:                     .iter()
14010:                     .filter(|access| source_read_name(access) == "x")
14011:                 {
14012:                     reads.push(view.read_reference(&access.source, &access.original_spelling));
14013:                 }
14014:             }
14015:         }
14016:         assert!(
14017:             reads.iter().any(|read| {
14018:                 read.is_some_and(|read| read.version.is_some_and(|version| version > 0))
14019:             }),
14020:             "computed command-head reads retain their actual producer: reads={reads:?}, inventory={inventory:?}"
14021:         );
14022:     }
14023: }
/* ORIGINAL_SOURCE_RANGE 14025..14110 */
14025: #[cfg(test)]
14026: mod external_mutability_tests {
14027: 
14028:     use super::*;
14029: 
14030:     #[test]
14031:     fn named_external_dependencies_use_actual_point_bindings_and_ignore_display_labels() {
14032:         let registry = tcl_registry::model::ingress::static_context_for("tcl8.6").commands();
14033:         let unit = crate::compilation_unit::CompilationUnit::build_for(
14034:             "proc p {} {set dictionary [dict create k 1]; upvar 0 dictionary view; set dictionary [dict create k 2]}",
14035:             registry,
14036:             false,
14037:         );
14038:         let mut ssa = unit.function("::p").unwrap().ssa.clone();
14039:         let mut writes = Vec::new();
14040:         for (&block, body) in &ssa.blocks {
14041:             for (index, statement) in body.statements.iter().enumerate() {
14042:                 if matches!(&statement.statement, Statement::AssignValue { name, .. } if name == "dictionary")
14043:                 {
14044:                     writes.push((
14045:                         statement.statement.span().start(),
14046:                         block,
14047:                         index,
14048:                         *statement.defs.keys().next().unwrap(),
14049:                     ));
14050:                 }
14051:             }
14052:         }
14053:         writes.sort_by_key(|(offset, ..)| *offset);
14054:         assert_eq!(writes.len(), 2);
14055:         assert_eq!(writes[0].3, writes[1].3);
14056:         let symbol = writes[0].3;
14057:         let names = HashSet::from(["view".to_owned()]);
14058:         for label in ["view", "dictionary", "unrelated"] {
14059:             ssa.var_names[symbol.0 as usize] = label.to_owned();
14060:             for (point, expected) in [(writes[0], false), (writes[1], true)] {
14061:                 let source = SsaSourceView::at_statement(&ssa, point.1, point.2);
14062:                 assert_eq!(
14063:                     source.externally_mutable_by(symbol, &names, false, registry),
14064:                     Some(expected),
14065:                     "{label}; canonical={}; before={:?}; carrier={:?}",
14066:                     ssa.cell_name(symbol).expect("original location symbol"),
14067:                     ssa.point_contexts
14068:                         .as_ref()
14069:                         .and_then(|points| points.context_before(point.1, point.2))
14070:                         .map(|context| canonical_variable_key("view", context, registry)),
14071:                     source
14072:                         .source_tokens()
14073:                         .and_then(|tokens| tokens.source_binding.as_ref())
14074:                         .map(|binding| canonical_variable_key(
14075:                             "view",
14076:                             &binding.variable_context,
14077:                             registry
14078:                         )),
14079:                 );
14080:                 assert_eq!(
14081:                     source.externally_mutable_by(symbol, &names, true, registry),
14082:                     Some(true)
14083:                 );
14084:                 assert_eq!(
14085:                     source.externally_mutable_by(
14086:                         symbol,
14087:                         &HashSet::from([ssa.cell_name(symbol).expect("original location symbol").to_owned()]),
14088:                         false,
14089:                         registry
14090:                     ),
14091:                     Some(false)
14092:                 );
14093:             }
14094:         }
14095:         assert_eq!(
14096:             SsaSourceView::unpositioned(&ssa)
14097:                 .externally_mutable_by(symbol, &names, false, registry),
14098:             None
14099:         );
14100:         assert_eq!(
14101:             SsaSourceView::unpositioned(&ssa).externally_mutable_by(
14102:                 symbol,
14103:                 &HashSet::new(),
14104:                 false,
14105:                 registry
14106:             ),
14107:             Some(false)
14108:         );
14109:     }
14110: }
/* ORIGINAL_SOURCE_RANGE 14112..14187 */
14112: #[cfg(test)]
14113: mod original_definition_name_tests {
14114: 
14115:     use super::*;
14116: 
14117:     #[test]
14118:     // Implementation contract: naming.variable.original-ssa-definition-operand
14119:     // docs/design/analysis/name-resolution-proofs/original-ssa-definition-operand.md
14120:     fn original_ssa_definition_names_preserve_exact_operands_and_distinct_cells() {
14121:         let source = r"set v\uD800 42; set v\uD801 TEXT; set a(k) 7";
14122:         let registry = tcl_registry::model::ingress::static_context_for("tcl8.6").commands();
14123:         let unit = crate::compilation_unit::CompilationUnit::build_for_dialect(
14124:             source, registry, false, "tcl8.6",
14125:         );
14126:         let function = &unit.top_level;
14127:         let specialised = function
14128:             .ssa
14129:             .blocks
14130:             .iter()
14131:             .find_map(|(&block, body)| {
14132:                 body.statements
14133:                     .iter()
14134:                     .enumerate()
14135:                     .find_map(|(index, statement)| {
14136:                         (statement.statement.span().start() == 0).then_some((
14137:                             block,
14138:                             index,
14139:                             &statement.statement,
14140:                         ))
14141:                     })
14142:             })
14143:             .expect("first original assignment");
14144:         assert!(matches!(specialised.2, Statement::AssignConst { .. }));
14145:         assert!(specialised.2.tokens().is_none());
14146:         assert!(
14147:             function
14148:                 .ssa
14149:                 .point_contexts
14150:                 .as_ref()
14151:                 .expect("source points")
14152:                 .source_tokens_at(specialised.0, specialised.1)
14153:                 .is_some()
14154:         );
14155:         let mut definitions = Vec::new();
14156:         for (&block, body) in &function.ssa.blocks {
14157:             for (index, statement) in body.statements.iter().enumerate() {
14158:                 let view = SsaSourceView::at_statement(&function.ssa, block, index);
14159:                 for &symbol in statement.defs.keys() {
14160:                     if let Some(definition) = view.original_definition_name(symbol, registry) {
14161:                         assert_eq!(Some(definition.cell()), function.ssa.cell_key(symbol));
14162:                         definitions.push(definition);
14163:                     }
14164:                 }
14165:             }
14166:         }
14167:         let select = |spelling: &str| {
14168:             definitions
14169:                 .iter()
14170:                 .find(|definition| &source[definition.span().as_range()] == spelling)
14171:                 .unwrap_or_else(|| {
14172:                     panic!(
14173:                         "missing original definition for {spelling}; count={}",
14174:                         definitions.len()
14175:                     )
14176:                 })
14177:         };
14178:         let first = select(r"v\uD800");
14179:         let second = select(r"v\uD801");
14180:         assert_ne!(
14181:             first.original_name_input().bytes(),
14182:             second.original_name_input().bytes()
14183:         );
14184:         assert_ne!(first.cell(), second.cell());
14185:         assert_eq!(select("a(k)").original_name_input().bytes(), b"a(k)");
14186:     }
14187: }
/* ORIGINAL_SOURCE_RANGE 14189..14329 */
14189: #[cfg(test)]
14190: mod native_source_definition_tests {
14191:     use super::*;
14192: 
14193:     #[test]
14194:     fn native_source_definitions_select_actual_body_symbols_without_physical_store_grants() {
14195:         let source =
14196:             "proc a {} {set same 1; return $same}\nproc b {} {set same TWO; return $same}\n";
14197:         let context =
14198:             tcl_registry::model::ingress::resolve_environment("tcl8.6").default_context_registry();
14199:         let profile = context.commands().profile().unwrap();
14200:         let config = tcl_lexer::LexerConfig::for_file_grammar(profile.grammar);
14201:         let input = crate::analyser::ResolvedAnalysisInput::new(
14202:             profile,
14203:             profile,
14204:             std::sync::Arc::clone(&context),
14205:             config,
14206:         );
14207:         let options = crate::compilation_unit::UnitBuildOptions {
14208:             registry: context.commands(),
14209:             defer_top_level: false,
14210:             config,
14211:             dialect: Some(profile),
14212:             external_call_sites: None,
14213:             declared_commands: None,
14214:         };
14215:         let unit = crate::compilation_unit::CompilationUnit::build_with_analysis_input(
14216:             source, options, None, &input,
14217:         );
14218:         assert_eq!(
14219:             unit.ir_module.original_native_declaration_body_units.len(),
14220:             2
14221:         );
14222:         let offsets = source
14223:             .match_indices("same ")
14224:             .map(|(offset, _)| u32::try_from(offset).unwrap())
14225:             .collect::<Vec<_>>();
14226:         assert_eq!(offsets.len(), 2);
14227:         let selected = offsets
14228:             .iter()
14229:             .map(|&offset| {
14230:                 original_source_definition_at_unit(
14231:                     &unit,
14232:                     tcl_lexer::Span::new(offset, offset + 4),
14233:                     context.commands(),
14234:                 )
14235:                 .unwrap()
14236:             })
14237:             .collect::<Vec<_>>();
14238:         assert_ne!(selected[0].name().body_id(), selected[1].name().body_id());
14239:         assert!(!std::ptr::eq(
14240:             selected[0].function(),
14241:             selected[1].function()
14242:         ));
14243:         for definition in &selected {
14244:             assert_eq!(definition.name().original_name_input().bytes(), b"same");
14245:             let function = definition.function();
14246:             let body = definition.name().body_id();
14247:             assert_eq!(function.body_id, Some(body));
14248:             let mut accepted = 0;
14249:             for (&block, statements) in &function.ssa.blocks {
14250:                 for (index, statement) in statements.statements.iter().enumerate() {
14251:                     if !statement.defs.contains_key(&definition.symbol()) {
14252:                         continue;
14253:                     }
14254:                     let view = SsaSourceView::at_statement(&function.ssa, block, index);
14255:                     if view
14256:                         .original_source_definition_for_body(
14257:                             definition.symbol(),
14258:                             &unit,
14259:                             body,
14260:                             context.commands(),
14261:                         )
14262:                         .is_some()
14263:                     {
14264:                         accepted += 1;
14265:                         assert!(
14266:                             view.original_definition_name_with_metadata_context(
14267:                                 definition.symbol(),
14268:                                 context.commands(),
14269:                                 function.invocation_metadata_context_for_module(
14270:                                     context.commands(),
14271:                                     &unit.ir_module
14272:                                 )
14273:                             )
14274:                             .is_none()
14275:                         );
14276:                         let other = selected
14277:                             .iter()
14278:                             .find(|other| other.name().body_id() != body)
14279:                             .unwrap();
14280:                         assert!(
14281:                             view.original_source_definition_for_body(
14282:                                 definition.symbol(),
14283:                                 &unit,
14284:                                 other.name().body_id(),
14285:                                 context.commands()
14286:                             )
14287:                             .is_none()
14288:                         );
14289:                     }
14290:                 }
14291:             }
14292:             assert_eq!(accepted, 1);
14293:         }
14294:         for stale in [false, true] {
14295:             let mut changed = unit.clone();
14296:             let function = changed
14297:                 .body_units
14298:                 .get_mut(&selected[0].name().body_id())
14299:                 .unwrap();
14300:             if stale {
14301:                 function.source_config = tcl_lexer::LexerConfig::for_file_grammar(
14302:                     tcl_registry::model::ingress::resolve_environment("tcl8.4")
14303:                         .unit_profile()
14304:                         .grammar,
14305:                 );
14306:             } else {
14307:                 function.source_metadata_input = None;
14308:             }
14309:             assert!(
14310:                 original_source_definition_at_unit(
14311:                     &changed,
14312:                     selected[0].name().span(),
14313:                     context.commands()
14314:                 )
14315:                 .is_none()
14316:             );
14317:         }
14318:         let mut missing = unit.clone();
14319:         missing.ir_module.source_metadata_input = None;
14320:         assert!(
14321:             original_source_definition_at_unit(
14322:                 &missing,
14323:                 selected[0].name().span(),
14324:                 context.commands()
14325:             )
14326:             .is_none()
14327:         );
14328:     }
14329: }
/* ORIGINAL_SOURCE_RANGE 14331..14426 */
14331: #[cfg(test)]
14332: mod original_source_read_selector_tests {
14333:     use super::*;
14334: 
14335:     #[test]
14336:     fn source_read_selector_uses_original_occurrence_and_current_function_owner() {
14337:         let source = "set same TOP; puts $same\nproc a {} {set same 123; return $same}\nproc b {} {set same TEXT; return $same}\n";
14338:         let context =
14339:             tcl_registry::model::ingress::resolve_environment("tcl8.6").default_context_registry();
14340:         let profile = tcl_dialect::DialectProfile::plain_tcl();
14341:         let config = tcl_lexer::LexerConfig::for_file_grammar(profile.grammar);
14342:         let input = crate::analyser::ResolvedAnalysisInput::new(
14343:             profile,
14344:             profile,
14345:             std::sync::Arc::clone(&context),
14346:             config,
14347:         );
14348:         let entry = crate::command_binding::SourceAnalysisEntry::for_logical_source(&input)
14349:             .expect("actual complete Logical source input");
14350:         let unit = crate::compilation_unit::CompilationUnit::build_with_analysis_input(
14351:             source,
14352:             crate::compilation_unit::UnitBuildOptions {
14353:                 registry: context.commands(),
14354:                 config,
14355:                 dialect: Some(profile),
14356:                 defer_top_level: false,
14357:                 external_call_sites: None,
14358:                 declared_commands: None,
14359:             },
14360:             Some(&entry),
14361:             &input,
14362:         );
14363:         assert_eq!(unit.ir_module.source_metadata_input.as_ref(), Some(&input));
14364:         let reads = source
14365:             .match_indices("$same")
14366:             .map(|(offset, _)| {
14367:                 original_source_read_at_unit(
14368:                     &unit,
14369:                     tcl_lexer::Span::new(offset as u32, offset as u32 + 5),
14370:                     context.commands(),
14371:                 )
14372:                 .expect("actual original read has its own current source/SSA producer")
14373:             })
14374:             .collect::<Vec<_>>();
14375:         assert_eq!(reads.len(), 3);
14376:         assert!(std::ptr::eq(reads[0].function(), &unit.top_level));
14377:         assert!(!std::ptr::eq(reads[0].function(), reads[1].function()));
14378:         assert!(!std::ptr::eq(reads[1].function(), reads[2].function()));
14379:         for read in &reads {
14380:             assert_eq!(read.function().ssa.var_name(read.symbol()), "same");
14381:             assert!(std::ptr::eq(
14382:                 unit.function_for_body(read.function().body_id).unwrap(),
14383:                 read.function()
14384:             ));
14385:         }
14386:         let span = reads[1].span();
14387:         let body = reads[1].function().body_id.unwrap();
14388:         assert!(
14389:             original_source_read_at_unit(
14390:                 &unit,
14391:                 tcl_lexer::Span::new(span.start() + 1, span.end()),
14392:                 context.commands()
14393:             )
14394:             .is_none()
14395:         );
14396:         let mut stale = unit.clone();
14397:         stale.source.push(' ');
14398:         assert!(original_source_read_at_unit(&stale, span, context.commands()).is_none());
14399:         for formals in [false, true] {
14400:             let mut changed = unit.clone();
14401:             let procedure = changed
14402:                 .ir_module
14403:                 .procedures
14404:                 .get_mut(&body)
14405:                 .or_else(|| changed.ir_module.body_units.get_mut(&body))
14406:                 .unwrap();
14407:             if formals {
14408:                 procedure.params.push("added".into());
14409:             } else {
14410:                 procedure.body_source = Some("return OTHER".into());
14411:             }
14412:             assert!(original_source_read_at_unit(&changed, span, context.commands()).is_none());
14413:         }
14414:         let mut missing = unit.clone();
14415:         if let Some(function) = missing
14416:             .procedures
14417:             .get_mut(&body)
14418:             .or_else(|| missing.body_units.get_mut(&body))
14419:         {
14420:             function.source_metadata_input = None;
14421:         } else {
14422:             panic!("actual original procedure function");
14423:         }
14424:         assert!(original_source_read_at_unit(&missing, span, context.commands()).is_none());
14425:     }
14426: }
/* ORIGINAL_SOURCE_RANGE 14428..14823 */
14428: #[cfg(test)]
14429: mod original_analysis_definition_selector_tests {
14430:     use super::*;
14431: 
14432:     fn unit(
14433:         source: &str,
14434:     ) -> (
14435:         crate::compilation_unit::CompilationUnit,
14436:         std::sync::Arc<tcl_registry::model::ContextRegistry>,
14437:     ) {
14438:         let context =
14439:             tcl_registry::model::ingress::resolve_environment("tcl8.6").default_context_registry();
14440:         let profile = tcl_dialect::DialectProfile::plain_tcl();
14441:         let config = tcl_lexer::LexerConfig::for_file_grammar(profile.grammar);
14442:         let input = crate::analyser::ResolvedAnalysisInput::new(
14443:             profile,
14444:             profile,
14445:             std::sync::Arc::clone(&context),
14446:             config,
14447:         );
14448:         let entry =
14449:             crate::command_binding::SourceAnalysisEntry::for_logical_source(&input).unwrap();
14450:         let unit = crate::compilation_unit::CompilationUnit::build_with_analysis_input(
14451:             source,
14452:             crate::compilation_unit::UnitBuildOptions {
14453:                 registry: context.commands(),
14454:                 config,
14455:                 dialect: Some(profile),
14456:                 defer_top_level: false,
14457:                 external_call_sites: None,
14458:                 declared_commands: None,
14459:             },
14460:             Some(&entry),
14461:             &input,
14462:         );
14463:         (unit, context)
14464:     }
14465: 
14466:     #[test]
14467:     fn original_analysis_word_geometry_keeps_current_input_vector_and_owner() {
14468:         let source = "set value 42\n";
14469:         let (unit, context) = unit(source);
14470:         let function = &unit.top_level;
14471:         let (block, index) = function
14472:             .ssa
14473:             .blocks
14474:             .iter()
14475:             .find_map(|(&block, body)| {
14476:                 body.statements.iter().enumerate().find_map(|(index, _)| {
14477:                     SsaSourceView::at_statement(&function.ssa, block, index)
14478:                         .source_tokens()
14479:                         .filter(|tokens| tokens.synthetic.is_none())
14480:                         .map(|_| (block, index))
14481:                 })
14482:             })
14483:             .expect("genuine original source operation");
14484:         let original = original_analysis_words_for_statement(
14485:             &unit,
14486:             function,
14487:             block,
14488:             index,
14489:             context.commands(),
14490:         )
14491:         .expect("genuine current original word geometry");
14492:         assert_eq!(
14493:             original
14494:                 .words()
14495:                 .iter()
14496:                 .map(|word| word.bytes())
14497:                 .collect::<Vec<_>>(),
14498:             vec![b"set".as_slice(), b"value".as_slice(), b"42".as_slice()]
14499:         );
14500:         assert_eq!(
14501:             original.config(),
14502:             unit.ir_module
14503:                 .source_metadata_input
14504:                 .as_ref()
14505:                 .unwrap()
14506:                 .lexer_config()
14507:         );
14508:         assert!(
14509:             original_analysis_words_for_statement(
14510:                 &unit,
14511:                 function,
14512:                 block,
14513:                 usize::MAX,
14514:                 context.commands()
14515:             )
14516:             .is_none()
14517:         );
14518:         assert!(
14519:             original_analysis_words_for_statement(
14520:                 &unit,
14521:                 function,
14522:                 block,
14523:                 index,
14524:                 &CommandRegistry::build_default()
14525:             )
14526:             .is_none()
14527:         );
14528:         let mut missing = unit.clone();
14529:         missing.top_level.source_metadata_input = None;
14530:         assert!(
14531:             original_analysis_words_for_statement(
14532:                 &missing,
14533:                 &missing.top_level,
14534:                 block,
14535:                 index,
14536:                 context.commands()
14537:             )
14538:             .is_none()
14539:         );
14540:         let mut stale = unit.clone();
14541:         stale.source.push(' ');
14542:         assert!(
14543:             original_analysis_words_for_statement(
14544:                 &stale,
14545:                 &stale.top_level,
14546:                 block,
14547:                 index,
14548:                 context.commands()
14549:             )
14550:             .is_none()
14551:         );
14552:         let (other, _) = self::unit(source);
14553:         let originals = other
14554:             .top_level
14555:             .ssa
14556:             .point_contexts
14557:             .as_ref()
14558:             .unwrap()
14559:             .source_token_inventory()
14560:             .values()
14561:             .filter_map(|tokens| {
14562:                 tokens
14563:                     .words()
14564:                     .first()
14565:                     .map(|word| (word.source().span.start(), tokens.clone()))
14566:             })
14567:             .collect();
14568:         let mut foreign = unit.clone();
14569:         assert!(
14570:             foreign
14571:                 .top_level
14572:                 .ssa
14573:                 .point_contexts
14574:                 .as_mut()
14575:                 .unwrap()
14576:                 .restore_source_tokens(&originals)
14577:         );
14578:         assert!(
14579:             original_analysis_words_for_statement(
14580:                 &foreign,
14581:                 &foreign.top_level,
14582:                 block,
14583:                 index,
14584:                 context.commands()
14585:             )
14586:             .is_none()
14587:         );
14588:     }
14589: 
14590:     #[test]
14591:     fn original_analysis_definitions_preserve_occurrence_versions_and_current_body_owner() {
14592:         let source = "set value TOP\nproc p {} {set value 123; set value TEXT; return $value}\n";
14593:         let (unit, context) = unit(source);
14594:         let definitions = source
14595:             .match_indices("set value")
14596:             .map(|(offset, _)| {
14597:                 let span = tcl_lexer::Span::new(offset as u32 + 4, offset as u32 + 9);
14598:                 original_analysis_definition_at_unit(&unit, span, context.commands())
14599:                     .expect("exact genuine source definition")
14600:             })
14601:             .collect::<Vec<_>>();
14602:         assert_eq!(definitions.len(), 3);
14603:         assert!(std::ptr::eq(definitions[0].function(), &unit.top_level));
14604:         assert!(std::ptr::eq(
14605:             definitions[1].function(),
14606:             definitions[2].function()
14607:         ));
14608:         assert!(!std::ptr::eq(
14609:             definitions[0].function(),
14610:             definitions[1].function()
14611:         ));
14612:         assert_eq!(definitions[1].symbol(), definitions[2].symbol());
14613:         assert_ne!(definitions[1].version(), definitions[2].version());
14614:         let span = definitions[1].span();
14615:         assert!(
14616:             original_analysis_definition_at_unit(
14617:                 &unit,
14618:                 tcl_lexer::Span::new(span.start() + 1, span.end()),
14619:                 context.commands()
14620:             )
14621:             .is_none()
14622:         );
14623:         let body = definitions[1].function().body_id.unwrap();
14624:         for formals in [false, true] {
14625:             let mut changed = unit.clone();
14626:             let procedure = changed
14627:                 .ir_module
14628:                 .procedures
14629:                 .get_mut(&body)
14630:                 .or_else(|| changed.ir_module.body_units.get_mut(&body))
14631:                 .unwrap();
14632:             if formals {
14633:                 procedure.params.push("added".into());
14634:             } else {
14635:                 procedure.body_source = Some("return OTHER".into());
14636:             }
14637:             assert!(
14638:                 original_analysis_definition_at_unit(&changed, span, context.commands()).is_none()
14639:             );
14640:         }
14641:         let mut missing = unit.clone();
14642:         missing
14643:             .procedures
14644:             .get_mut(&body)
14645:             .or_else(|| missing.body_units.get_mut(&body))
14646:             .unwrap()
14647:             .source_metadata_input = None;
14648:         assert!(original_analysis_definition_at_unit(&missing, span, context.commands()).is_none());
14649:         let mut stale = unit.clone();
14650:         stale.source.push(' ');
14651:         assert!(original_analysis_definition_at_unit(&stale, span, context.commands()).is_none());
14652:     }
14653: 
14654:     #[test]
14655:     fn named_source_body_tokens_require_the_actual_header_body_and_attachment() {
14656:         let source = "proc p {} {set value TEXT; return $value}\n";
14657:         let (unit, context) = unit(source);
14658:         let retained = unit.ir_module.retained_source_bindings.as_deref().unwrap();
14659:         let actual_bodies = unit
14660:             .ir_module
14661:             .original_source_procedure_bodies()
14662:             .map(|(id, _)| *id)
14663:             .collect::<Vec<_>>();
14664:         let [body] = actual_bodies.as_slice() else {
14665:             panic!("one actual Module-issued original declaration in this fixture");
14666:         };
14667:         let body = *body;
14668:         let function = unit.function_for_body(Some(body)).unwrap();
14669:         let tokens = function
14670:             .ssa
14671:             .point_contexts
14672:             .as_ref()
14673:             .unwrap()
14674:             .source_token_inventory()
14675:             .values()
14676:             .map(|tokens| {
14677:                 let mut original = tokens.clone();
14678:                 crate::lattice_rebase::rebase_command_tokens(&mut original, function.base_offset);
14679:                 original
14680:             })
14681:             .collect::<Vec<_>>();
14682:         assert_eq!(tokens.len(), 2);
14683:         for original in &tokens {
14684:             assert!(retained.owns_original_body_tokens(
14685:                 &unit.ir_module,
14686:                 body,
14687:                 original,
14688:                 context.commands()
14689:             ));
14690:             let mut missing = original.clone();
14691:             missing.source_binding = None;
14692:             assert!(!retained.owns_original_body_tokens(
14693:                 &unit.ir_module,
14694:                 body,
14695:                 &missing,
14696:                 context.commands()
14697:             ));
14698:         }
14699:         let (other, _) = self::unit(source);
14700:         let actual_bodies = other
14701:             .ir_module
14702:             .original_source_procedure_bodies()
14703:             .map(|(id, _)| *id)
14704:             .collect::<Vec<_>>();
14705:         let [foreign_body] = actual_bodies.as_slice() else {
14706:             panic!("one actual Module-issued original declaration in this fixture");
14707:         };
14708:         let foreign_body = *foreign_body;
14709:         assert!(!retained.owns_original_body_tokens(
14710:             &unit.ir_module,
14711:             foreign_body,
14712:             &tokens[0],
14713:             context.commands()
14714:         ));
14715:         let foreign_function = other.function_for_body(Some(foreign_body)).unwrap();
14716:         for original in foreign_function
14717:             .ssa
14718:             .point_contexts
14719:             .as_ref()
14720:             .unwrap()
14721:             .source_token_inventory()
14722:             .values()
14723:         {
14724:             let mut original = original.clone();
14725:             crate::lattice_rebase::rebase_command_tokens(
14726:                 &mut original,
14727:                 foreign_function.base_offset,
14728:             );
14729:             assert!(!retained.owns_original_body_tokens(
14730:                 &unit.ir_module,
14731:                 body,
14732:                 &original,
14733:                 context.commands()
14734:             ));
14735:         }
14736:         for formals in [false, true] {
14737:             let mut changed = unit.ir_module.clone();
14738:             let procedure = changed.procedures.get_mut(&body).unwrap();
14739:             if formals {
14740:                 procedure.params.push("added".into());
14741:             } else {
14742:                 procedure.body_source = Some("return OTHER".into());
14743:             }
14744:             assert!(!retained.owns_original_body_tokens(
14745:                 &changed,
14746:                 body,
14747:                 &tokens[0],
14748:                 context.commands()
14749:             ));
14750:         }
14751:     }
14752: 
14753:     #[test]
14754:     fn logical_card_body_tokens_refuse_a_different_current_declaration() {
14755:         let source = "proc p {} {set value TEXT; return $value}\nproc q {} {set value TEXT; return $value}\n";
14756:         let (unit, context) = unit(source);
14757:         let retained = unit.ir_module.retained_source_bindings.as_deref().unwrap();
14758:         let mut bodies = unit
14759:             .ir_module
14760:             .original_source_procedure_bodies()
14761:             .map(|(id, _)| *id)
14762:             .collect::<Vec<_>>();
14763:         bodies.sort_unstable();
14764:         let [first, second] = bodies.as_slice() else {
14765:             panic!("two real current declarations");
14766:         };
14767:         for (actual, other) in [(*first, *second), (*second, *first)] {
14768:             let function = unit.function_for_body(Some(actual)).unwrap();
14769:             for tokens in function
14770:                 .ssa
14771:                 .point_contexts
14772:                 .as_ref()
14773:                 .unwrap()
14774:                 .source_token_inventory()
14775:                 .values()
14776:             {
14777:                 let mut original = tokens.clone();
14778:                 crate::lattice_rebase::rebase_command_tokens(&mut original, function.base_offset);
14779:                 assert!(
14780:                     original
14781:                         .source_binding
14782:                         .as_ref()
14783:                         .unwrap()
14784:                         .has_original_logical_source_advice()
14785:                 );
14786:                 assert!(retained.owns_original_body_tokens(
14787:                     &unit.ir_module,
14788:                     actual,
14789:                     &original,
14790:                     context.commands()
14791:                 ));
14792:                 assert!(!retained.owns_original_body_tokens(
14793:                     &unit.ir_module,
14794:                     other,
14795:                     &original,
14796:                     context.commands()
14797:                 ));
14798:             }
14799:         }
14800:     }
14801: 
14802:     #[test]
14803:     fn readonly_source_reads_withhold_unrepresented_contents_versions() {
14804:         let source = "proc p {} {set value TEXT; return $value}\n";
14805:         let (unit, context) = unit(source);
14806:         let offset = source.find("$value").unwrap() as u32;
14807:         let read = original_source_read_at_unit(
14808:             &unit,
14809:             tcl_lexer::Span::new(offset, offset + 6),
14810:             context.commands(),
14811:         )
14812:         .expect("genuine readonly source read occurrence");
14813:         assert!(read.function().body_id.is_some());
14814:         assert_eq!(read.version(), None);
14815:         assert!(
14816:             read.function()
14817:                 .ssa
14818:                 .source_read_references
14819:                 .values()
14820:                 .any(|reference| reference.symbol == read.symbol())
14821:         );
14822:     }
14823: }
/* ORIGINAL_SOURCE_RANGE 14825..15003 */
14825: #[cfg(test)]
14826: mod original_authored_analysis_definition_selector_tests {
14827:     use super::*;
14828: 
14829:     fn unit(source: &str, registry: &CommandRegistry) -> crate::compilation_unit::CompilationUnit {
14830:         crate::compilation_unit::CompilationUnit::build_for_with_config(
14831:             source,
14832:             registry,
14833:             false,
14834:             tcl_lexer::LexerConfig::default(),
14835:         )
14836:     }
14837: 
14838:     #[test]
14839:     fn authored_source_definition_owner_requires_current_module_body_and_standalone_purpose() {
14840:         let registry = CommandRegistry::build_default();
14841:         let source = "set value TOP\nproc p {} {set value BODY}\n";
14842:         let original = unit(source, &registry);
14843:         assert!(original.ir_module.source_metadata_input.is_none());
14844:         assert!(
14845:             original
14846:                 .ir_module
14847:                 .source_entry
14848:                 .metadata_context
14849:                 .is_standalone()
14850:         );
14851:         assert!(current_authored_analysis_function(
14852:             &original,
14853:             &original.top_level,
14854:             &registry
14855:         ));
14856:         assert_eq!(
14857:             original
14858:                 .ir_module
14859:                 .original_authored_declaration_body_units
14860:                 .len(),
14861:             1
14862:         );
14863:         let id = *original
14864:             .ir_module
14865:             .original_authored_declaration_body_units
14866:             .keys()
14867:             .next()
14868:             .unwrap();
14869:         let function = original.function_for_body(Some(id)).unwrap();
14870:         assert!(current_authored_analysis_function(
14871:             &original, function, &registry
14872:         ));
14873:         let mut missing = original.clone();
14874:         missing.ir_module.source_entry.metadata_context =
14875:             crate::registry_invocation::OwnedInvocationMetadataContext::for_source_input(None);
14876:         assert!(!current_authored_analysis_function(
14877:             &missing,
14878:             &missing.top_level,
14879:             &registry
14880:         ));
14881:         let mut stale = original.clone();
14882:         stale.source.push(' ');
14883:         assert!(!current_authored_analysis_function(
14884:             &stale,
14885:             &stale.top_level,
14886:             &registry
14887:         ));
14888:         let mut changed = original.clone();
14889:         changed
14890:             .ir_module
14891:             .body_units
14892:             .get_mut(&id)
14893:             .unwrap()
14894:             .params
14895:             .push("foreign".into());
14896:         assert!(!current_authored_analysis_function(
14897:             &changed,
14898:             changed.function_for_body(Some(id)).unwrap(),
14899:             &registry,
14900:         ));
14901:         let other = unit(source, &registry);
14902:         assert!(!current_authored_analysis_function(
14903:             &original,
14904:             &other.top_level,
14905:             &registry
14906:         ));
14907:     }
14908: 
14909:     #[test]
14910:     fn authored_body_tokens_keep_the_actual_original_header_attachment() {
14911:         let registry = CommandRegistry::build_default();
14912:         let source = "proc p {} {puts BODY}\n";
14913:         let original = unit(source, &registry);
14914:         let module = &original.ir_module;
14915:         assert!(module.source_metadata_input.is_none());
14916:         let retained = module.retained_source_bindings.as_deref().unwrap();
14917:         let (id, card) = module
14918:             .original_authored_declaration_body_units
14919:             .iter()
14920:             .next()
14921:             .unwrap();
14922:         let body = &module.body_units.get(id).unwrap().body;
14923:         assert!(card.matches_procedure(module, module.body_units.get(id).unwrap()));
14924:         let tokens = body
14925:             .retained_source_tokens_for_statement(body.statements.first().unwrap())
14926:             .unwrap();
14927:         let scope = tokens
14928:             .source_binding
14929:             .as_ref()
14930:             .unwrap()
14931:             .original_authored_source_body_scope_for_name_roles(tokens, &registry)
14932:             .unwrap();
14933:         assert!(scope.matches_module(module));
14934:         assert!(card.owns_original_source_scope(scope));
14935:         assert!(retained.owns_original_analysis_attachment(tokens));
14936:         let mut missing = tokens.clone();
14937:         missing.source_binding = Some(crate::command_binding::SourceInvocationBinding::default());
14938:         assert!(!retained.owns_original_analysis_attachment(&missing));
14939:         let foreign = unit(source, &registry);
14940:         let (_, foreign_card) = foreign
14941:             .ir_module
14942:             .original_authored_declaration_body_units
14943:             .iter()
14944:             .next()
14945:             .unwrap();
14946:         let foreign_id = *foreign
14947:             .ir_module
14948:             .original_authored_declaration_body_units
14949:             .keys()
14950:             .next()
14951:             .unwrap();
14952:         let foreign_body = &foreign.ir_module.body_units.get(&foreign_id).unwrap().body;
14953:         let foreign_tokens = foreign_body
14954:             .retained_source_tokens_for_statement(foreign_body.statements.first().unwrap())
14955:             .unwrap();
14956:         let foreign_scope = foreign_tokens
14957:             .source_binding
14958:             .as_ref()
14959:             .unwrap()
14960:             .original_authored_source_body_scope_for_name_roles(foreign_tokens, &registry)
14961:             .unwrap();
14962:         assert!(foreign_card.owns_original_source_scope(foreign_scope));
14963:         assert!(!card.owns_original_source_scope(foreign_scope));
14964:         assert!(!retained.owns_original_analysis_attachment(foreign_tokens));
14965:     }
14966: 
14967:     #[test]
14968:     fn authored_source_definitions_select_exact_represented_versions() {
14969:         let registry = CommandRegistry::build_default();
14970:         let source = "set value 123\nset value TEXT\n";
14971:         let original = unit(source, &registry);
14972:         assert!(original.ir_module.source_metadata_input.is_none());
14973:         let definitions = source
14974:             .match_indices("set value")
14975:             .map(|(offset, _)| {
14976:                 let span = tcl_lexer::Span::new(offset as u32 + 4, offset as u32 + 9);
14977:                 original_analysis_definition_at_unit(&original, span, &registry)
14978:                     .expect("authentic represented Authored source definition")
14979:             })
14980:             .collect::<Vec<_>>();
14981:         assert_eq!(definitions.len(), 2);
14982:         assert!(
14983:             definitions
14984:                 .iter()
14985:                 .all(|definition| std::ptr::eq(definition.function(), &original.top_level))
14986:         );
14987:         assert_eq!(definitions[0].symbol(), definitions[1].symbol());
14988:         assert_ne!(definitions[0].version(), definitions[1].version());
14989:         let span = definitions[1].span();
14990:         assert!(
14991:             original_analysis_definition_at_unit(
14992:                 &original,
14993:                 tcl_lexer::Span::new(span.start() + 1, span.end()),
14994:                 &registry,
14995:             )
14996:             .is_none()
14997:         );
14998:         let mut malformed = original.clone();
14999:         malformed.top_level.source_config.strict_quoting =
15000:             !malformed.top_level.source_config.strict_quoting;
15001:         assert!(original_analysis_definition_at_unit(&malformed, span, &registry).is_none());
15002:     }
15003: }
/* ORIGINAL_SOURCE_RANGE 15005..15050 */
15005: #[cfg(test)]
15006: mod retained_host_grammar_tests {
15007:     use super::*;
15008: 
15009:     #[test]
15010:     fn public_ssa_reborrows_the_supplied_host_grammar_for_return_reads() {
15011:         let profile = tcl_dialect::DialectProfile::plain_tcl();
15012:         let context = tcl_registry::model::ingress::context_for_profile(profile);
15013:         let registry = context.commands();
15014:         let config = tcl_lexer::LexerConfig::for_dialect("jim");
15015:         assert_ne!(
15016:             config.normalized(),
15017:             tcl_lexer::LexerConfig::for_profile(registry.profile()).normalized()
15018:         );
15019:         let input =
15020:             crate::analyser::ResolvedAnalysisInput::new(profile, profile, context.clone(), config);
15021:         let source = "return $($::value)";
15022:         let unit = crate::compilation_unit::CompilationUnit::build_with_analysis_input(
15023:             source,
15024:             crate::compilation_unit::UnitBuildOptions {
15025:                 registry,
15026:                 config,
15027:                 dialect: Some(profile),
15028:                 defer_top_level: false,
15029:                 external_call_sites: None,
15030:                 declared_commands: None,
15031:             },
15032:             None,
15033:             &input,
15034:         );
15035:         let cfg = &unit.top_level.cfg;
15036:         assert_eq!(cfg.metadata_context.source_analysis_input(), Some(&input));
15037:         assert!(cfg.blocks.values().any(|block| matches!(
15038:             &block.terminator,
15039:             Some(crate::cfg::Terminator::Return { value: Some(value), .. }) if value == "$($::value)"
15040:         )));
15041:         let explicit = build_ssa_with_config(cfg, registry, config);
15042:         assert!(
15043:             explicit
15044:                 .point_symbols
15045:                 .values()
15046:                 .any(|symbols| symbols.contains_key("::value"))
15047:         );
15048:         assert_eq!(build_ssa(cfg, registry), explicit);
15049:     }
15050: }
