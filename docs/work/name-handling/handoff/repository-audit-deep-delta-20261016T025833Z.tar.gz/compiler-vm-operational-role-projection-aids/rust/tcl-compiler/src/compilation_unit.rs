/* ORIGINAL_SOURCE_RANGE 3210..3277 */
3210:     #[cfg(test)]
3211:     pub(crate) fn from_branch_folding_fixture(source: &str, fu: FunctionUnit) -> Self {
3212:         CompilationUnit {
3213:             source: source.into(),
3214:             ir_module: crate::ir::Module {
3215:                 retained_source_bindings: None,
3216:                 source_metadata_input: None,
3217:                 lexer_config: tcl_lexer::LexerConfig::default(),
3218:                 source_entry: crate::command_binding::SourceAnalysisEntry::default(),
3219:                 future_call_sites: Vec::new(),
3220:                 installed_procedure_body_units: std::collections::BTreeMap::default(),
3221:                 original_declaration_body_units: std::collections::BTreeMap::default(),
3222:                 original_native_declaration_body_units: std::collections::BTreeMap::default(),
3223:                 original_logical_declaration_body_units: std::collections::BTreeMap::default(),
3224:                 original_hosted_declaration_body_units: std::collections::BTreeMap::default(),
3225:                 original_authored_declaration_body_units: std::collections::BTreeMap::default(),
3226:                 irules_event_bodies: HashMap::new(),
3227:                 procedure_implementation_bodies: std::sync::Arc::from([]),
3228:                 top_level_kind: crate::ir::TopLevelKind::Script,
3229:                 source: tcl_lexer::SourceImage::default(),
3230:                 native_namespace: None,
3231:                 original_byte_source_namespace: None,
3232:                 top_level_namespace: "::".to_owned(),
3233:                 top_level_namespace_context: None,
3234:                 dialect: None,
3235:                 dialect_profile: None,
3236:                 registry_snapshot: None,
3237:                 plain_command_dispatch: false,
3238:                 top_level: crate::ir::Script::new(),
3239:                 procedure_ids: crate::ir::ProcedureIdIssuer::default(),
3240:                 original_definition_scripts: std::collections::BTreeMap::new(),
3241:                 procedures: crate::ir::ProcedureInventory::default(),
3242:                 methods: crate::ir::MethodInventory::default(),
3243:                 body_units: crate::ir::ProcedureInventory::default(),
3244:                 lambda_body_units: std::collections::BTreeSet::new(),
3245:                 redefined_procedures: std::collections::HashSet::new(),
3246:                 redefined_methods: HashMap::new(),
3247:                 oo_unanalysed_classes: std::collections::HashSet::new(),
3248:                 oo_evidence: crate::ir::OoDefinitionEvidence::default(),
3249:                 class_relations: Vec::new(),
3250:                 namespace_imports: Vec::new(),
3251:                 namespace_exports: Vec::new(),
3252:                 traced_commands: std::collections::BTreeSet::new(),
3253:                 has_dynamic_trace: false,
3254:                 traced_variables: std::collections::BTreeSet::new(),
3255:                 has_dynamic_variable_trace: false,
3256:                 deferred_writes: crate::ir::DeferredWrites::default(),
3257:                 reference_bodies: crate::ir::ReferenceBodies::default(),
3258:                 declared_frame_effects: std::collections::BTreeMap::new(),
3259:             },
3260:             cfg_module: crate::cfg::CfgModule {
3261:                 top_level: fu.cfg.clone(),
3262:                 procedures: HashMap::new(),
3263:             },
3264:             command_mutations: crate::command_binding::ModuleCommandMutations::default(),
3265:             source_class_facts: None,
3266:             top_level: fu,
3267:             procedures: HashMap::new(),
3268:             methods: HashMap::new(),
3269:             body_units: HashMap::new(),
3270:             source_body_cfgs: HashMap::new(),
3271:             interproc: None,
3272:             connection_scope: None,
3273:             caller_scope: crate::compilation_unit::UnitCallerScope::default(),
3274:             declared_commands: tcl_registry::model::DeclaredSurface::new(),
3275:             transfers: crate::interprocedural::TransferSummaries::default(),
3276:         }
3277:     }
/* ORIGINAL_SOURCE_RANGE 4622..4631 */
4622:     #[cfg(test)]
4623:     pub(crate) fn function(&self, name: &str) -> Option<&FunctionUnit> {
4624:         if name == "::top" {
4625:             return (!self.ir_module.procedures.has_display(name))
4626:                 .then(|| self.function_for_body(None))
4627:                 .flatten();
4628:         }
4629:         let (id, _) = self.ir_module.procedures.unique_display(name)?;
4630:         self.function_for_body(Some(*id))
4631:     }
/* ORIGINAL_SOURCE_RANGE 4719..4720 */
4719:         #[cfg(test)]
4720:         let trace_enabled = std::env::var_os("TCL_LSP_TRACE_ORIGINAL_FACTORY_GUARDS").is_some();
/* ORIGINAL_SOURCE_RANGE 4721..4727 */
4721:         #[cfg(test)]
4722:         let trace = |stage: &str, passed: bool| {
4723:             if std::env::var_os("TCL_LSP_TRACE_ORIGINAL_FACTORY_GUARDS").is_some() {
4724:                 let offset = parent.argv.first().map(|span| span.start());
4725:                 eprintln!("ORIGINAL_FACTORY_GUARD stage={stage} offset={offset:?} passed={passed}");
4726:             }
4727:         };
/* ORIGINAL_SOURCE_RANGE 4729..4735 */
4729:         #[cfg(test)]
4730:         if trace_enabled {
4731:             trace(
4732:                 "conditional_body.document",
4733:                 module.source == tcl_lexer::SourceImage::document(&self.source),
4734:             );
4735:         }
/* ORIGINAL_SOURCE_RANGE 4741..4744 */
4741:         #[cfg(test)]
4742:         if trace_enabled {
4743:             trace("conditional_body.module_metadata", metadata.is_some());
4744:         }
/* ORIGINAL_SOURCE_RANGE 4747..4753 */
4747:         #[cfg(test)]
4748:         if trace_enabled {
4749:             trace(
4750:                 "conditional_body.input_config",
4751:                 input.lexer_config() == module.lexer_config,
4752:             );
4753:         }
/* ORIGINAL_SOURCE_RANGE 4757..4763 */
4757:         #[cfg(test)]
4758:         if trace_enabled {
4759:             trace(
4760:                 "conditional_body.retained",
4761:                 module.retained_source_bindings.is_some(),
4762:             );
4763:         }
/* ORIGINAL_SOURCE_RANGE 4768..4771 */
4768:         #[cfg(test)]
4769:         if trace_enabled {
4770:             trace("conditional_body.positioned", positioned.is_some());
4771:         }
/* ORIGINAL_SOURCE_RANGE 4775..4781 */
4775:         #[cfg(test)]
4776:         if trace_enabled {
4777:             trace(
4778:                 "conditional_body.function_metadata",
4779:                 function_metadata.is_some(),
4780:             );
4781:         }
/* ORIGINAL_SOURCE_RANGE 4783..4790 */
4783:         #[cfg(test)]
4784:         if trace_enabled {
4785:             trace(
4786:                 "conditional_body.original_function",
4787:                 self.all_body_function_units()
4788:                     .any(|owned| std::ptr::eq(owned, original_function)),
4789:             );
4790:         }
/* ORIGINAL_SOURCE_RANGE 4799..4802 */
4799:         #[cfg(test)]
4800:         if trace_enabled {
4801:             trace("conditional_body.script", script.is_some());
4802:         }
/* ORIGINAL_SOURCE_RANGE 4818..4821 */
4818:         #[cfg(test)]
4819:         if trace_enabled {
4820:             trace("conditional_body.class_facts", known_classes.is_some());
4821:         }
/* ORIGINAL_SOURCE_RANGE 5005..5006 */
5005:     #[cfg(test)]
5006:     let trace_enabled = std::env::var_os("TCL_LSP_TRACE_ORIGINAL_FACTORY_GUARDS").is_some();
/* ORIGINAL_SOURCE_RANGE 5007..5012 */
5007:     #[cfg(test)]
5008:     let trace = |stage: &str, passed: bool| {
5009:         if std::env::var_os("TCL_LSP_TRACE_ORIGINAL_FACTORY_GUARDS").is_some() {
5010:             eprintln!("ORIGINAL_FACTORY_GUARD stage={stage} offset=none passed={passed}");
5011:         }
5012:     };
/* ORIGINAL_SOURCE_RANGE 5013..5019 */
5013:     #[cfg(test)]
5014:     if trace_enabled {
5015:         trace(
5016:             "class_roster.document",
5017:             module.source == tcl_lexer::SourceImage::document(source),
5018:         );
5019:     }
/* ORIGINAL_SOURCE_RANGE 5025..5028 */
5025:         #[cfg(test)]
5026:         if trace_enabled {
5027:             trace("class_roster.positioned", bindings.is_some());
5028:         }
/* ORIGINAL_SOURCE_RANGE 5032..5038 */
5032:         #[cfg(test)]
5033:         if trace_enabled {
5034:             trace(
5035:                 "class_roster.input_config",
5036:                 bindings.matches_original_source_image(&module.source, module.lexer_config),
5037:             );
5038:         }
/* ORIGINAL_SOURCE_RANGE 5055..5066 */
5055:     #[cfg(test)]
5056:     if std::env::var_os("TCL_LSP_TRACE_ORIGINAL_FACTORY_GUARDS").is_some() {
5057:         let declared = signatures.class_declarations.len();
5058:         let named = signatures
5059:             .class_declarations
5060:             .iter()
5061:             .filter(|declaration| declaration.source_spelling().is_some())
5062:             .count();
5063:         eprintln!(
5064:             "ORIGINAL_FACTORY_GUARD stage=class_roster.selected_result declared={declared} named={named}"
5065:         );
5066:     }
/* ORIGINAL_SOURCE_RANGE 5130..8262 */
5130: #[cfg(test)]
5131: mod tests {
5132:     use crate::interprocedural::test_body_identity::{fixture_id, fixture_id_if_present};
5133: 
5134:     fn fixture_method<'a>(unit: &'a CompilationUnit, label: &str) -> Option<&'a FunctionUnit> {
5135:         let (id, _) = unit.ir_module.methods.unique_display(label)?;
5136:         unit.methods.get(&id)
5137:     }
5138: 
5139:     use super::*;
5140: 
5141:     #[test]
5142:     fn function_consumers_keep_the_actual_generation_and_grammar() {
5143:         // naming.compiler.original-analysis-metadata-context
5144:         // docs/design/analysis/name-resolution-proofs/original-analysis-metadata-context.md
5145:         let registry = Arc::new(CommandRegistry::build_default());
5146:         let profile = tcl_dialect::DialectProfile::plain_tcl();
5147:         let actual = Arc::new(
5148:             tcl_registry::model::ingress::static_context_for("tcl8.4")
5149:                 .with_command_store(Arc::clone(&registry)),
5150:         );
5151:         let config = tcl_lexer::LexerConfig {
5152:             braced_var: tcl_dialect::BracedVarStyle::FirstClose,
5153:             ..tcl_lexer::LexerConfig::for_file_grammar(profile.grammar)
5154:         };
5155:         let unit = CompilationUnit::build_with_context_registry(
5156:             "proc p {x} {set y $x; return $y}; namespace eval n {set z 1}",
5157:             UnitBuildOptions {
5158:                 registry: &registry,
5159:                 defer_top_level: false,
5160:                 config,
5161:                 dialect: Some(profile),
5162:                 external_call_sites: None,
5163:                 declared_commands: None,
5164:             },
5165:             None,
5166:             Arc::clone(&actual),
5167:         );
5168:         let input = unit.ir_module.source_metadata_input.as_ref().unwrap();
5169:         assert!(Arc::ptr_eq(&input.context_registry(), &actual));
5170:         assert!(!unit.procedures.is_empty());
5171:         let body_id = fixture_id(&unit.ir_module.procedures, "::p");
5172:         assert!(std::ptr::eq(
5173:             unit.function_for_body(Some(body_id)).unwrap(),
5174:             &unit.procedures[&body_id]
5175:         ));
5176:         assert!(std::ptr::eq(
5177:             unit.function_for_body(None).unwrap(),
5178:             &unit.top_level
5179:         ));
5180:         let mut wrong_stamp = unit.clone();
5181:         wrong_stamp.procedures.get_mut(&body_id).unwrap().body_id = None;
5182:         assert!(wrong_stamp.function_for_body(Some(body_id)).is_none());
5183:         wrong_stamp.top_level.body_id = Some(body_id);
5184:         assert!(wrong_stamp.function_for_body(None).is_none());
5185:         let foreign_unit = CompilationUnit::build_with_context_registry(
5186:             &unit.source,
5187:             UnitBuildOptions {
5188:                 registry: &registry,
5189:                 defer_top_level: false,
5190:                 config,
5191:                 dialect: Some(profile),
5192:                 external_call_sites: None,
5193:                 declared_commands: None,
5194:             },
5195:             None,
5196:             Arc::clone(&actual),
5197:         );
5198:         let foreign_id = fixture_id(&foreign_unit.ir_module.procedures, "::p");
5199:         let mut foreign_owner = unit.clone();
5200:         foreign_owner.ir_module.procedure_ids = foreign_unit.ir_module.procedure_ids.clone();
5201:         for (&id, function) in unit.methods.iter().chain(unit.body_units.iter()) {
5202:             assert!(std::ptr::eq(
5203:                 unit.function_for_body(Some(id))
5204:                     .expect("actual retained body unit"),
5205:                 function
5206:             ));
5207:             assert!(foreign_owner.function_for_body(Some(id)).is_none());
5208:         }
5209:         assert!(foreign_owner.function_for_body(Some(body_id)).is_none());
5210:         assert!(unit.function_for_body(Some(foreign_id)).is_none());
5211:         for function in std::iter::once(&unit.top_level)
5212:             .chain(unit.procedures.values())
5213:             .chain(unit.methods.values())
5214:             .chain(unit.body_units.values())
5215:         {
5216:             assert_eq!(function.source_metadata_input(), Some(input));
5217:             assert_eq!(function.source_lexer_config(), config);
5218:             let selected = function.invocation_metadata_context(&registry).unwrap();
5219:             assert!(std::ptr::eq(selected.context(), actual.context()));
5220:             let foreign = CommandRegistry::build_default().project_for_profile(
5221:                 tcl_registry::model::ingress::resolve_environment("tcl9.1").unit_profile(),
5222:             );
5223:             assert!(function.invocation_metadata_context(&foreign).is_none());
5224:             let mut missing = function.clone();
5225:             missing.source_metadata_input = None;
5226:             assert!(missing.invocation_metadata_context(&registry).is_none());
5227:         }
5228:     }
5229: 
5230:     #[test]
5231:     fn original_module_taint_replay_preserves_receivers_and_refuses_foreign_owners() {
5232:         let context =
5233:             tcl_registry::model::ingress::resolve_environment("tk").default_context_registry();
5234:         let registry = context.commands();
5235:         let profile = tcl_registry::model::ingress::resolve_environment("tk").unit_profile();
5236:         let config = tcl_lexer::LexerConfig::for_file_grammar(profile.grammar);
5237:         let input = crate::analyser::ResolvedAnalysisInput::new(
5238:             profile,
5239:             profile,
5240:             Arc::clone(&context),
5241:             config,
5242:         );
5243:         let source = "entry .e; proc danger {} {set value [.e get]; exec $value}";
5244:         let build = |source| {
5245:             CompilationUnit::build_with_analysis_input(
5246:                 source,
5247:                 UnitBuildOptions {
5248:                     registry,
5249:                     defer_top_level: false,
5250:                     config,
5251:                     dialect: Some(profile),
5252:                     external_call_sites: None,
5253:                     declared_commands: None,
5254:                 },
5255:                 None,
5256:                 &input,
5257:             )
5258:         };
5259:         let unit = build(source);
5260:         let body = *unit
5261:             .ir_module
5262:             .original_source_procedure_bodies()
5263:             .next()
5264:             .unwrap()
5265:             .0;
5266:         let direct = unit.clone().with_interprocedural(registry, Some(profile));
5267:         let analysis = direct.interproc.as_ref().unwrap();
5268:         assert!(analysis.global_instance_classes[&body].contains_key(".e"));
5269:         let expected = direct.function_for_body(Some(body)).unwrap();
5270:         assert!(expected.taints.values().any(|taint| taint.is_tainted()));
5271:         assert_eq!(
5272:             unit.original_interproc_taints_for_body(Some(body), registry, analysis),
5273:             Some(expected.taints.as_ref().clone()),
5274:         );
5275:         let mut observed = 0;
5276:         let memoised = unit.clone().with_interprocedural_memoized(
5277:             registry,
5278:             Some(profile),
5279:             &mut |actual_body, _, _| {
5280:                 assert_eq!(actual_body, body);
5281:                 observed += 1;
5282:                 None
5283:             },
5284:         );
5285:         assert_eq!(observed, 1);
5286:         assert_eq!(memoised.top_level.taints, direct.top_level.taints);
5287:         assert_eq!(
5288:             memoised.function_for_body(Some(body)).unwrap().taints,
5289:             expected.taints
5290:         );
5291: 
5292:         let other = build("entry .other; proc danger {} {set value [.other get]; exec $value}");
5293:         let foreign_body = *other
5294:             .ir_module
5295:             .original_source_procedure_bodies()
5296:             .next()
5297:             .unwrap()
5298:             .0;
5299:         assert!(
5300:             unit.original_interproc_taints_for_body(Some(foreign_body), registry, analysis)
5301:                 .is_none()
5302:         );
5303:         let other = other.with_interprocedural(registry, Some(profile));
5304:         assert!(
5305:             unit.original_interproc_taints_for_body(
5306:                 Some(body),
5307:                 registry,
5308:                 other.interproc.as_ref().unwrap()
5309:             )
5310:             .is_none()
5311:         );
5312:         let mut missing = unit.clone();
5313:         missing.ir_module.retained_source_bindings = None;
5314:         assert!(
5315:             missing
5316:                 .original_interproc_taints_for_body(Some(body), registry, analysis)
5317:                 .is_none()
5318:         );
5319:         let mut missing = unit.clone();
5320:         missing.ir_module.source_metadata_input = None;
5321:         assert!(
5322:             missing
5323:                 .original_interproc_taints_for_body(Some(body), registry, analysis)
5324:                 .is_none()
5325:         );
5326:         let mut missing = unit.clone();
5327:         missing.top_level.source_metadata_input = None;
5328:         assert!(
5329:             missing
5330:                 .original_interproc_taints_for_body(None, registry, analysis)
5331:                 .is_none()
5332:         );
5333:         let mut changed = unit.clone();
5334:         changed.ir_module.source =
5335:             tcl_lexer::SourceImage::document(&format!("{source}; puts CHANGED"));
5336:         assert!(
5337:             changed
5338:                 .original_interproc_taints_for_body(Some(body), registry, analysis)
5339:                 .is_none()
5340:         );
5341:         let mut foreign_registry = registry.project_for_profile(profile);
5342:         let mut extra = registry.get("puts").unwrap().clone();
5343:         extra.name = "taint_source_owner_control";
5344:         foreign_registry.insert(extra);
5345:         assert!(
5346:             unit.original_interproc_taints_for_body(Some(body), &foreign_registry, analysis)
5347:                 .is_none()
5348:         );
5349:         let mut missing_analysis = analysis.clone();
5350:         missing_analysis.global_instance_class_owner = None;
5351:         assert!(
5352:             unit.original_interproc_taints_for_body(Some(body), registry, &missing_analysis)
5353:                 .is_none()
5354:         );
5355:     }
5356: 
5357:     #[test]
5358:     fn module_realm_refusal_withholds_caller_seeds_and_retires_interprocedural_results() {
5359:         // naming.source.retained-positioned-command-realm
5360:         // docs/design/analysis/name-resolution-proofs/retained-positioned-command-realm.md
5361:         let registry = tcl_registry::model::ingress::static_context_for("tcl9.0").commands();
5362:         let profile = tcl_dialect::DialectProfile::find("tcl9.0").unwrap();
5363:         let config = tcl_lexer::LexerConfig::for_file_grammar(profile.grammar);
5364:         let source = "proc retained {x} {list $x}; retained VALUE";
5365:         let options = UnitBuildOptions {
5366:             registry,
5367:             defer_top_level: false,
5368:             config,
5369:             dialect: Some(profile),
5370:             external_call_sites: None,
5371:             declared_commands: None,
5372:         };
5373:         let (module, cfg, _, prepared) =
5374:             lower_and_build_cfg(source, options, None, None, None, None, None);
5375:         assert!(crate::realm::document_realm_bindings_for_module(&module, registry).is_some());
5376:         let (actual, _, _) = resolve_unit_scope(&module, &cfg, Some(&prepared), options);
5377:         assert_eq!(
5378:             actual.get("::retained").unwrap().uniform_literal_at(0),
5379:             Some("VALUE")
5380:         );
5381:         let mut missing = module.clone();
5382:         missing.retained_source_bindings = None;
5383:         let mut changed = module.clone();
5384:         changed.source = tcl_lexer::SourceImage::document("proc other {} {};");
5385:         let mut missing_snapshot = module;
5386:         missing_snapshot.registry_snapshot = None;
5387:         for refused in [missing, changed, missing_snapshot] {
5388:             let (unknown, _, _) = resolve_unit_scope(&refused, &cfg, Some(&prepared), options);
5389:             let caller = unknown.get("::retained").unwrap();
5390:             assert!(caller.opaque_caller);
5391:             assert_eq!(caller.uniform_literal_at(0), None);
5392:         }
5393:         let completed = CompilationUnit::build_for_profile(source, registry, false, profile)
5394:             .with_interprocedural(registry, Some(profile));
5395:         assert!(completed.interproc.is_some());
5396:         let mut missing = completed.clone();
5397:         missing.ir_module.retained_source_bindings = None;
5398:         let ordinary = missing
5399:             .clone()
5400:             .with_interprocedural(registry, Some(profile));
5401:         assert!(ordinary.interproc.is_none());
5402:         let mut callbacks = 0;
5403:         let mut callback = |_: crate::ir::ProcedureId, _: &str, _: &InterproceduralAnalysis| {
5404:             callbacks += 1;
5405:             None
5406:         };
5407:         let memoised =
5408:             missing.with_interprocedural_memoized(registry, Some(profile), &mut callback);
5409:         assert!(memoised.interproc.is_none());
5410:         assert_eq!(callbacks, 0);
5411:     }
5412: 
5413:     fn semantic_bundle_has_source_metadata(unit: &crate::compilation_unit::FunctionUnit) -> bool {
5414:         unit.semantic_facts
5415:             .conditional_source_metadata()
5416:             .invocations()
5417:             .next()
5418:             .is_some()
5419:     }
5420: 
5421:     #[test]
5422:     fn semantic_bundle_requires_retained_availability_and_source_grammar() {
5423:         // naming.compiler.original-analysis-metadata-context
5424:         // docs/design/analysis/name-resolution-proofs/original-analysis-metadata-context.md
5425:         // These are source metadata and availability assertions, not Native entry facts.
5426:         let baseline = tcl_registry::model::ingress::static_context_for("tcl8.6");
5427:         let mut registry = baseline
5428:             .commands()
5429:             .project_for_profile(tcl_dialect::DialectProfile::find("tcl8.6").unwrap());
5430:         let mut puts = registry.get("puts").unwrap().clone();
5431:         puts.name = "metadata_current";
5432:         puts.surface = Some(tcl_dialect::model::SpecSurface::TCL86_PLUS);
5433:         registry.insert(puts);
5434:         let current = Arc::new(baseline.with_command_store(Arc::new(registry)));
5435:         let registry = current.commands();
5436:         let profile = tcl_dialect::DialectProfile::plain_tcl();
5437:         let input = crate::analyser::ResolvedAnalysisInput::new(
5438:             profile,
5439:             profile,
5440:             Arc::clone(&current),
5441:             tcl_lexer::LexerConfig::for_file_grammar(profile.grammar),
5442:         );
5443:         let unit = CompilationUnit::build_with_analysis_input(
5444:             "metadata_current VALUE",
5445:             UnitBuildOptions {
5446:                 registry,
5447:                 defer_top_level: false,
5448:                 config: tcl_lexer::LexerConfig::for_file_grammar(profile.grammar),
5449:                 dialect: Some(profile),
5450:                 external_call_sites: None,
5451:                 declared_commands: None,
5452:             },
5453:             None,
5454:             &input,
5455:         );
5456:         let selected = &unit.top_level;
5457:         assert_eq!(
5458:             selected.semantic_facts.metadata_context(),
5459:             Some(current.context())
5460:         );
5461:         assert!(semantic_bundle_has_source_metadata(selected));
5462:         let input = selected.source_metadata_input().unwrap();
5463:         let older = Arc::new(
5464:             tcl_registry::model::ingress::static_context_for("tcl8.4")
5465:                 .with_command_store(Arc::clone(registry)),
5466:         );
5467:         assert!(Arc::ptr_eq(older.commands(), registry));
5468:         let mut unavailable = selected.clone();
5469:         unavailable.source_metadata_input = Some(crate::analyser::ResolvedAnalysisInput::new(
5470:             input.analyser_profile(),
5471:             input.unit_profile(),
5472:             older,
5473:             input.lexer_config(),
5474:         ));
5475:         let unavailable = unavailable.with_retained_semantic_analysis(
5476:             registry,
5477:             Some(&unit.ir_module.top_level),
5478:             crate::dispatch_proof::DispatchEntryAssumption::PristineRegistryWorld,
5479:         );
5480:         assert!(!semantic_bundle_has_source_metadata(&unavailable));
5481:         let mut foreign = selected.clone();
5482:         foreign.source_metadata_input = Some(crate::analyser::ResolvedAnalysisInput::new(
5483:             input.analyser_profile(),
5484:             input.unit_profile(),
5485:             tcl_registry::model::ingress::resolve_environment("tcl9.1").default_context_registry(),
5486:             input.lexer_config(),
5487:         ));
5488:         let mut missing = selected.clone();
5489:         missing.source_metadata_input = None;
5490:         let mut different_grammar = selected.clone();
5491:         different_grammar.source_config.strict_quoting =
5492:             !different_grammar.source_config.strict_quoting;
5493:         for negative in [foreign, missing, different_grammar] {
5494:             let refused = negative.with_retained_semantic_analysis(
5495:                 registry,
5496:                 Some(&unit.ir_module.top_level),
5497:                 crate::dispatch_proof::DispatchEntryAssumption::PristineRegistryWorld,
5498:             );
5499:             assert!(matches!(
5500:                 refused.semantic_facts.executable(),
5501:                 crate::semantic_analysis::ExecutableAnalysisAvailability::ContextUnavailable
5502:             ));
5503:         }
5504:     }
5505: 
5506:     #[test]
5507:     fn retained_deep_sidecars_keep_availability_and_refuse_missing_function_input() {
5508:         // naming.compiler.original-analysis-metadata-context
5509:         // docs/design/analysis/name-resolution-proofs/original-analysis-metadata-context.md
5510:         let baseline = tcl_registry::model::ingress::static_context_for("tcl8.6");
5511:         let profile = tcl_dialect::DialectProfile::plain_tcl();
5512:         let mut registry = baseline.commands().project_for_profile(profile);
5513:         let mut puts = registry.get("puts").unwrap().clone();
5514:         puts.name = "metadata_current";
5515:         puts.surface = Some(tcl_dialect::model::SpecSurface::TCL86_PLUS);
5516:         registry.insert(puts);
5517:         let current = Arc::new(baseline.with_command_store(Arc::new(registry)));
5518:         let registry = current.commands();
5519:         let input = crate::analyser::ResolvedAnalysisInput::new(
5520:             profile,
5521:             profile,
5522:             Arc::clone(&current),
5523:             tcl_lexer::LexerConfig::for_file_grammar(profile.grammar),
5524:         );
5525:         let unit = CompilationUnit::build_with_analysis_input(
5526:             "metadata_current VALUE",
5527:             UnitBuildOptions {
5528:                 registry,
5529:                 defer_top_level: false,
5530:                 config: tcl_lexer::LexerConfig::for_file_grammar(profile.grammar),
5531:                 dialect: Some(profile),
5532:                 external_call_sites: None,
5533:                 declared_commands: None,
5534:             },
5535:             None,
5536:             &input,
5537:         );
5538:         let selected = unit.clone().with_retained_deep_semantic_analysis(registry);
5539:         assert!(semantic_bundle_has_source_metadata(&selected.top_level));
5540:         assert!(
5541:             selected
5542:                 .top_level
5543:                 .semantic_facts
5544:                 .executable()
5545:                 .world_state_ssa()
5546:                 .is_some()
5547:         );
5548:         let input = unit.top_level.source_metadata_input().unwrap();
5549:         let older = Arc::new(
5550:             tcl_registry::model::ingress::static_context_for("tcl8.4")
5551:                 .with_command_store(Arc::clone(registry)),
5552:         );
5553:         let mut unavailable = unit.clone();
5554:         unavailable.top_level.source_metadata_input =
5555:             Some(crate::analyser::ResolvedAnalysisInput::new(
5556:                 input.analyser_profile(),
5557:                 input.unit_profile(),
5558:                 older,
5559:                 input.lexer_config(),
5560:             ));
5561:         unavailable.ir_module.source_metadata_input =
5562:             unavailable.top_level.source_metadata_input.clone();
5563:         let unavailable = unavailable.with_retained_deep_semantic_analysis(registry);
5564:         assert!(!semantic_bundle_has_source_metadata(&unavailable.top_level));
5565:         let mut missing = unit.clone();
5566:         missing.top_level.source_metadata_input = None;
5567:         let mut foreign = unit.clone();
5568:         foreign.top_level.source_metadata_input =
5569:             Some(crate::analyser::ResolvedAnalysisInput::new(
5570:                 input.analyser_profile(),
5571:                 input.unit_profile(),
5572:                 tcl_registry::model::ingress::resolve_environment("tcl9.1")
5573:                     .default_context_registry(),
5574:                 input.lexer_config(),
5575:             ));
5576:         let mut stale = unit.clone();
5577:         stale.top_level.source_config.strict_quoting =
5578:             !stale.top_level.source_config.strict_quoting;
5579:         for negative in [missing, foreign, stale] {
5580:             let refused = negative.with_retained_deep_semantic_analysis(registry);
5581:             assert!(matches!(
5582:                 refused.top_level.semantic_facts.executable(),
5583:                 crate::semantic_analysis::ExecutableAnalysisAvailability::ContextUnavailable
5584:             ));
5585:         }
5586:     }
5587: 
5588:     #[test]
5589:     fn retained_deep_sidecars_require_the_module_source_owner() {
5590:         // naming.compiler.original-analysis-metadata-context
5591:         // docs/design/analysis/name-resolution-proofs/original-analysis-metadata-context.md
5592:         // Full source sidecars borrow Module scripts; no Native entry is established.
5593:         let current =
5594:             tcl_registry::model::ingress::resolve_environment("tcl8.6").default_context_registry();
5595:         let registry = current.commands();
5596:         let mut unit = retained_memory_fixture(&current);
5597:         let input = unit.ir_module.source_metadata_input.as_ref().unwrap();
5598:         let mut missing = unit.clone();
5599:         missing.ir_module.source_metadata_input = None;
5600:         let mut stale = unit.clone();
5601:         stale.ir_module.lexer_config.strict_quoting = !stale.ir_module.lexer_config.strict_quoting;
5602:         let mut different_owner = unit.clone();
5603:         different_owner.ir_module.source_metadata_input =
5604:             Some(crate::analyser::ResolvedAnalysisInput::new(
5605:                 input.analyser_profile(),
5606:                 input.unit_profile(),
5607:                 Arc::new(current.with_command_store(Arc::clone(registry))),
5608:                 input.lexer_config(),
5609:             ));
5610:         assert!(semantic_bundle_has_source_metadata(
5611:             &unit
5612:                 .clone()
5613:                 .with_retained_deep_semantic_analysis(registry)
5614:                 .top_level
5615:         ));
5616:         for refused in [missing, stale, different_owner] {
5617:             let refused = refused.with_retained_deep_semantic_analysis(registry);
5618:             assert!(matches!(
5619:                 refused.top_level.semantic_facts.executable(),
5620:                 crate::semantic_analysis::ExecutableAnalysisAvailability::ContextUnavailable
5621:             ));
5622:         }
5623:         // FU's explicit API owns its own supplied script independently of a Module.
5624:         unit.ir_module.source_metadata_input = None;
5625:         let standalone = unit.top_level.clone().with_retained_semantic_analysis(
5626:             registry,
5627:             Some(&unit.ir_module.top_level),
5628:             crate::dispatch_proof::DispatchEntryAssumption::PristineRegistryWorld,
5629:         );
5630:         assert!(semantic_bundle_has_source_metadata(&standalone));
5631:     }
5632: 
5633:     fn retained_memory_fixture(
5634:         context: &Arc<tcl_registry::model::ContextRegistry>,
5635:     ) -> CompilationUnit {
5636:         let profile = tcl_dialect::DialectProfile::find("tcl8.6").unwrap();
5637:         CompilationUnit::build_with_context_registry(
5638:             "dict create key value",
5639:             UnitBuildOptions {
5640:                 registry: context.commands(),
5641:                 defer_top_level: false,
5642:                 config: tcl_lexer::LexerConfig::for_file_grammar(profile.grammar),
5643:                 dialect: Some(profile),
5644:                 external_call_sites: None,
5645:                 declared_commands: None,
5646:             },
5647:             None,
5648:             Arc::clone(context),
5649:         )
5650:     }
5651: 
5652:     #[test]
5653:     fn retained_memory_facts_require_matching_module_and_function_owners() {
5654:         // naming.compiler.original-analysis-metadata-context
5655:         // docs/design/analysis/name-resolution-proofs/original-analysis-metadata-context.md
5656:         // This checks metadata admission and opaque memory obligations, not Native entry.
5657:         let current =
5658:             tcl_registry::model::ingress::resolve_environment("tcl8.6").default_context_registry();
5659:         let registry = current.commands();
5660:         let unit = retained_memory_fixture(&current);
5661:         let original = unit.top_level.source_metadata_input().unwrap();
5662:         let annotated = unit.clone().with_retained_memory_ssa(registry);
5663:         assert!(
5664:             !annotated
5665:                 .top_level
5666:                 .memory_ssa
5667:                 .unwrap()
5668:                 .has_wildcard_aliasing
5669:         );
5670:         let older = Arc::new(
5671:             tcl_registry::model::ingress::static_context_for("tcl8.4")
5672:                 .with_command_store(Arc::clone(registry)),
5673:         );
5674:         let mut unavailable = unit.clone();
5675:         let input = crate::analyser::ResolvedAnalysisInput::new(
5676:             original.analyser_profile(),
5677:             original.unit_profile(),
5678:             Arc::clone(&older),
5679:             original.lexer_config(),
5680:         );
5681:         unavailable.ir_module.source_metadata_input = Some(input.clone());
5682:         unavailable.top_level.source_metadata_input = Some(input);
5683:         assert!(
5684:             unavailable
5685:                 .top_level
5686:                 .invocation_metadata_context_for_module(registry, &unavailable.ir_module)
5687:                 .is_some()
5688:         );
5689:         let mut missing_module = unit.clone();
5690:         missing_module.ir_module.source_metadata_input = None;
5691:         let mut missing_function = unit.clone();
5692:         missing_function.top_level.source_metadata_input = None;
5693:         let mut stale_module = unit.clone();
5694:         stale_module.ir_module.lexer_config.strict_quoting =
5695:             !stale_module.ir_module.lexer_config.strict_quoting;
5696:         let mut stale_function = unit.clone();
5697:         stale_function.top_level.source_config.strict_quoting =
5698:             !stale_function.top_level.source_config.strict_quoting;
5699:         let mut different_owner = unit.clone();
5700:         different_owner.ir_module.source_metadata_input =
5701:             Some(crate::analyser::ResolvedAnalysisInput::new(
5702:                 original.analyser_profile(),
5703:                 original.unit_profile(),
5704:                 older,
5705:                 original.lexer_config(),
5706:             ));
5707:         let mut foreign = unit.clone();
5708:         foreign.top_level.source_metadata_input =
5709:             Some(crate::analyser::ResolvedAnalysisInput::new(
5710:                 original.analyser_profile(),
5711:                 original.unit_profile(),
5712:                 tcl_registry::model::ingress::resolve_environment("tcl9.1")
5713:                     .default_context_registry(),
5714:                 original.lexer_config(),
5715:             ));
5716:         let mut different_profile = unit.clone();
5717:         different_profile.top_level.source_metadata_input =
5718:             Some(crate::analyser::ResolvedAnalysisInput::new(
5719:                 tcl_dialect::DialectProfile::find("tcl8.4").unwrap(),
5720:                 original.unit_profile(),
5721:                 Arc::clone(&current),
5722:                 original.lexer_config(),
5723:             ));
5724:         for refused in [
5725:             missing_module,
5726:             missing_function,
5727:             stale_module,
5728:             stale_function,
5729:             different_owner,
5730:             foreign,
5731:             different_profile,
5732:         ] {
5733:             assert!(
5734:                 refused
5735:                     .top_level
5736:                     .invocation_metadata_context_for_module(registry, &refused.ir_module)
5737:                     .is_none()
5738:             );
5739:             let refused = refused.with_retained_memory_ssa(registry);
5740:             assert!(refused.top_level.memory_ssa.unwrap().has_wildcard_aliasing);
5741:         }
5742:         let unavailable = unavailable.with_retained_memory_ssa(registry);
5743:         assert!(
5744:             unavailable
5745:                 .top_level
5746:                 .memory_ssa
5747:                 .unwrap()
5748:                 .has_wildcard_aliasing
5749:         );
5750:     }
5751: 
5752:     fn retained_memo_fixture_unit(
5753:         req: &LatticeRequest<'_>,
5754:         registry: &CommandRegistry,
5755:     ) -> FunctionUnit {
5756:         let prepared = PreparedCfgContext::from_source_input(
5757:             (
5758:                 req.upvar_procs.clone(),
5759:                 req.proc_params.clone(),
5760:                 req.global_write_procs.clone(),
5761:                 req.command_bindings.clone(),
5762:                 req.procedure_summary_owners.clone(),
5763:             ),
5764:             registry,
5765:             req.source_metadata_input,
5766:         );
5767:         let cfg = crate::cfg_builder::build_cfg_function_with_prepared_context(
5768:             req.qname,
5769:             req.body,
5770:             true,
5771:             registry,
5772:             req.plain_command_dispatch,
5773:             &prepared,
5774:             req.lexer_config,
5775:         );
5776:         let known_classes = req.known_classes.iter().cloned().collect();
5777:         let traced_variables = req.traced_variables.iter().cloned().collect();
5778:         let parameters = decode_param_constants(req.param_constants);
5779:         FunctionUnit::build_for_lattice(
5780:             req.qname,
5781:             cfg,
5782:             req.params,
5783:             FunctionLatticeInputs {
5784:                 dialect: UnitDialect {
5785:                     registry,
5786:                     config: req.lexer_config,
5787:                     source_metadata_input: req.source_metadata_input,
5788:                 },
5789:                 param_constants: parameters.as_ref(),
5790:                 known_classes: &known_classes,
5791:                 trace_facts: ModuleTraceFacts {
5792:                     traced_variables: &traced_variables,
5793:                     has_dynamic_variable_trace: req.has_dynamic_variable_trace,
5794:                     deferred_writes: &req.analysis_context.deferred_writes,
5795:                 },
5796:                 analysis_context: req.analysis_context,
5797:                 command_trust: req.command_trust,
5798:                 event_body: req.irules_event_body.map(|event| (event, req.body)),
5799:             },
5800:         )
5801:         .with_retained_semantic_analysis(
5802:             registry,
5803:             Some(req.body),
5804:             crate::dispatch_proof::DispatchEntryAssumption::UnknownWorld,
5805:         )
5806:     }
5807: 
5808:     #[test]
5809:     fn memoised_source_facts_retain_nested_bom_and_lexer_overlays() {
5810:         // naming.compiler.original-analysis-metadata-context
5811:         // docs/design/analysis/name-resolution-proofs/original-analysis-metadata-context.md
5812:         let current =
5813:             tcl_registry::model::ingress::resolve_environment("tcl8.6").default_context_registry();
5814:         let registry = current.commands();
5815:         let profile = tcl_dialect::DialectProfile::plain_tcl();
5816:         let config = tcl_lexer::LexerConfig {
5817:             escapes: tcl_dialect::EscapeSyntax::Tcl84,
5818:             ..tcl_lexer::LexerConfig::for_file_grammar(profile.grammar)
5819:         };
5820:         let mut requests = 0;
5821:         let mut memo = |req: &LatticeRequest<'_>| {
5822:             requests += 1;
5823:             let input = req.source_metadata_input.unwrap();
5824:             assert!(Arc::ptr_eq(&input.context_registry(), &current));
5825:             assert_eq!(input.lexer_config(), config.nested().normalized());
5826:             assert_eq!(input.lexer_config(), req.lexer_config);
5827:             assert_eq!(input.unit_profile().cache_key(), profile.cache_key());
5828:             assert_eq!(
5829:                 req.original_metadata_context(registry),
5830:                 crate::registry_invocation::OwnedInvocationMetadataContext::for_source_input(Some(
5831:                     input
5832:                 )),
5833:             );
5834:             let wrong_config = LatticeRequest {
5835:                 lexer_config: tcl_lexer::LexerConfig {
5836:                     strict_quoting: !req.lexer_config.strict_quoting,
5837:                     ..req.lexer_config
5838:                 },
5839:                 ..*req
5840:             };
5841:             assert!(matches!(
5842:                 wrong_config.original_metadata_context(registry),
5843:                 crate::registry_invocation::OwnedInvocationMetadataContext::Unavailable
5844:             ));
5845:             let wrong_profile = LatticeRequest {
5846:                 dialect: Some(tcl_dialect::DialectProfile::find("tcl9.1").unwrap()),
5847:                 ..*req
5848:             };
5849:             assert!(matches!(
5850:                 wrong_profile.original_metadata_context(registry),
5851:                 crate::registry_invocation::OwnedInvocationMetadataContext::Unavailable
5852:             ));
5853:             let selected = retained_memo_fixture_unit(req, registry);
5854:             assert!(semantic_bundle_has_source_metadata(&selected));
5855:             let mut stale = selected.clone();
5856:             stale.source_config.escapes = tcl_dialect::EscapeSyntax::Tcl86;
5857:             assert!(stale.invocation_metadata_context(registry).is_none());
5858:             let stale = stale.with_retained_semantic_analysis(
5859:                 registry,
5860:                 Some(req.body),
5861:                 crate::dispatch_proof::DispatchEntryAssumption::UnknownWorld,
5862:             );
5863:             assert!(matches!(
5864:                 stale.semantic_facts.executable(),
5865:                 crate::semantic_analysis::ExecutableAnalysisAvailability::ContextUnavailable
5866:             ));
5867:             selected
5868:         };
5869:         let unit = CompilationUnit::build_with_entry(
5870:             r"proc p {} {::puts \U00000041}",
5871:             UnitBuildOptions {
5872:                 registry,
5873:                 defer_top_level: false,
5874:                 config,
5875:                 dialect: Some(profile),
5876:                 external_call_sites: None,
5877:                 declared_commands: None,
5878:             },
5879:             Some(&mut memo),
5880:             None,
5881:             None,
5882:             Some(Arc::clone(&current)),
5883:         );
5884:         assert_eq!(requests, 1);
5885:         assert!(semantic_bundle_has_source_metadata(
5886:             unit.procedures
5887:                 .get(&fixture_id(&unit.procedures, "::p"))
5888:                 .expect("authored fixture body")
5889:         ));
5890:         assert!(
5891:             unit.procedures
5892:                 .get(&fixture_id(&unit.procedures, "::p"))
5893:                 .expect("authored fixture body")
5894:                 .invocation_metadata_context_for_module(registry, &unit.ir_module)
5895:                 .is_some()
5896:         );
5897:         let deep = unit.with_retained_deep_semantic_analysis(registry);
5898:         assert!(semantic_bundle_has_source_metadata(
5899:             deep.procedures
5900:                 .get(&fixture_id(&deep.procedures, "::p"))
5901:                 .expect("authored fixture body")
5902:         ));
5903:     }
5904: 
5905:     #[test]
5906:     fn supplied_source_input_retains_axes_and_independent_logical_entry() {
5907:         // naming.compiler.original-analysis-metadata-context
5908:         // docs/design/analysis/name-resolution-proofs/original-analysis-metadata-context.md
5909:         // Source declarations and aliases are conditional authored facts, not Native entry.
5910:         let current =
5911:             tcl_registry::model::ingress::resolve_environment("tcl8.6").default_context_registry();
5912:         let profile = tcl_dialect::DialectProfile::plain_tcl();
5913:         let input = crate::analyser::ResolvedAnalysisInput::new(
5914:             profile,
5915:             profile,
5916:             Arc::clone(&current),
5917:             tcl_lexer::LexerConfig::for_file_grammar(profile.grammar),
5918:         );
5919:         let options = UnitBuildOptions {
5920:             registry: current.commands(),
5921:             defer_top_level: false,
5922:             config: input.lexer_config(),
5923:             dialect: Some(input.unit_profile()),
5924:             external_call_sites: None,
5925:             declared_commands: None,
5926:         };
5927:         let unit = CompilationUnit::build_with_analysis_input(
5928:             "proc aliaser {} {global ::n::shared; set shared 1}",
5929:             options,
5930:             None,
5931:             &input,
5932:         );
5933:         assert_eq!(unit.ir_module.source_metadata_input.as_ref(), Some(&input));
5934:         assert_eq!(
5935:             unit.ir_module.source_entry.logical_source_input.as_ref(),
5936:             Some(&input)
5937:         );
5938:         assert!(unit.ir_module.source_entry.native_entry.is_none());
5939:         assert!(fixture_id_if_present(&unit.procedures, "::aliaser").is_some());
5940:         let explicit = crate::command_binding::SourceAnalysisEntry::default();
5941:         let unknown = CompilationUnit::build_with_analysis_input(
5942:             "proc aliaser {} {global ::n::shared; set shared 1}",
5943:             options,
5944:             Some(&explicit),
5945:             &input,
5946:         );
5947:         assert!(
5948:             unknown
5949:                 .ir_module
5950:                 .source_entry
5951:                 .logical_source_input
5952:                 .is_none()
5953:         );
5954:         assert!(unknown.ir_module.source_entry.native_entry.is_none());
5955:         assert_eq!(
5956:             unknown.ir_module.source_metadata_input.as_ref(),
5957:             Some(&input)
5958:         );
5959:         let native_profile = tcl_dialect::DialectProfile::find("tcl8.6").unwrap();
5960:         let native = crate::analyser::ResolvedAnalysisInput::new(
5961:             native_profile,
5962:             native_profile,
5963:             Arc::clone(&current),
5964:             input.lexer_config(),
5965:         );
5966:         let native_unit = CompilationUnit::build_with_analysis_input(
5967:             "puts VALUE",
5968:             UnitBuildOptions {
5969:                 dialect: Some(native_profile),
5970:                 ..options
5971:             },
5972:             None,
5973:             &native,
5974:         );
5975:         assert!(
5976:             native_unit
5977:                 .ir_module
5978:                 .source_entry
5979:                 .logical_source_input
5980:                 .is_none()
5981:         );
5982:         assert!(native_unit.ir_module.source_entry.native_entry.is_none());
5983:         assert!(native_unit.ir_module.source_entry.unknown_entry);
5984:         assert_eq!(
5985:             native_unit.ir_module.source_metadata_input.as_ref(),
5986:             Some(&native)
5987:         );
5988:     }
5989: 
5990:     #[test]
5991:     fn default_unit_source_profile_keeps_explicit_standalone_authoring_purpose() {
5992:         let context =
5993:             tcl_registry::model::ingress::resolve_environment("tcl8.6").default_context_registry();
5994:         let profile = context.commands().profile().unwrap();
5995:         let config = tcl_lexer::LexerConfig::for_file_grammar(profile.grammar);
5996:         let options = UnitBuildOptions {
5997:             registry: context.commands(),
5998:             config,
5999:             dialect: Some(profile),
6000:             defer_top_level: false,
6001:             external_call_sites: None,
6002:             declared_commands: None,
6003:         };
6004:         let source = "proc local {value} {set result $value; return $result}";
6005:         let unit = CompilationUnit::build_with_options(source, options);
6006:         let module = &unit.ir_module;
6007:         assert!(module.source_entry.metadata_context.is_standalone());
6008:         assert!(module.source_metadata_input.is_none());
6009:         assert!(module.source_entry.native_entry.is_none());
6010:         assert_eq!(module.original_authored_declaration_body_units.len(), 1);
6011:         assert!(module.original_native_declaration_body_units.is_empty());
6012:         let (id, card) = module
6013:             .original_authored_declaration_body_units
6014:             .iter()
6015:             .next()
6016:             .unwrap();
6017:         let procedure = module.body_units.get(id).unwrap();
6018:         assert!(card.matches_procedure(module, procedure));
6019:         assert!(procedure.publication.is_none());
6020:         assert!(procedure.body.executed_source.is_none());
6021:         assert!(procedure.body.native_compilation_admission.is_none());
6022:         let header = module
6023:             .top_level
6024:             .retained_source_tokens_for_statement(&module.top_level.statements[0])
6025:             .unwrap();
6026:         assert!(
6027:             crate::registry_invocation::admitted_native_compiler_invocation(
6028:                 context.commands(),
6029:                 None,
6030:                 header
6031:             )
6032:             .is_none()
6033:         );
6034:     }
6035: 
6036:     #[test]
6037:     fn default_source_purpose_does_not_replace_supplied_input_or_unknown_driver_entry() {
6038:         let context =
6039:             tcl_registry::model::ingress::resolve_environment("tcl8.6").default_context_registry();
6040:         let profile = context.commands().profile().unwrap();
6041:         let config = tcl_lexer::LexerConfig::for_file_grammar(profile.grammar);
6042:         let options = UnitBuildOptions {
6043:             registry: context.commands(),
6044:             config,
6045:             dialect: Some(profile),
6046:             defer_top_level: false,
6047:             external_call_sites: None,
6048:             declared_commands: None,
6049:         };
6050:         let input = crate::analyser::ResolvedAnalysisInput::new(
6051:             profile,
6052:             profile,
6053:             Arc::clone(&context),
6054:             config,
6055:         );
6056:         let source = "proc original {value} {return $value}";
6057:         let supplied = CompilationUnit::build_with_analysis_input(source, options, None, &input);
6058:         assert_eq!(
6059:             supplied.ir_module.source_metadata_input.as_ref(),
6060:             Some(&input)
6061:         );
6062:         assert!(
6063:             !supplied
6064:                 .ir_module
6065:                 .source_entry
6066:                 .metadata_context
6067:                 .is_standalone()
6068:         );
6069:         assert!(
6070:             supplied
6071:                 .ir_module
6072:                 .original_authored_declaration_body_units
6073:                 .is_empty()
6074:         );
6075:         assert_eq!(
6076:             supplied
6077:                 .ir_module
6078:                 .original_native_declaration_body_units
6079:                 .len(),
6080:             1
6081:         );
6082:         let entry = crate::command_binding::SourceAnalysisEntry {
6083:             unknown_entry: true,
6084:             ..Default::default()
6085:         };
6086:         let unknown = CompilationUnit::build_with_source_entry(source, options, &entry);
6087:         assert!(unknown.ir_module.source_entry.unknown_entry);
6088:         assert!(
6089:             unknown
6090:                 .ir_module
6091:                 .original_authored_declaration_body_units
6092:                 .is_empty()
6093:         );
6094:     }
6095: 
6096:     #[test]
6097:     fn supplied_source_producer_refuses_changed_profile_and_lexer_metadata() {
6098:         // naming.compiler.original-analysis-metadata-context
6099:         // docs/design/analysis/name-resolution-proofs/original-analysis-metadata-context.md
6100:         // Actual input is retained for reporting; unrelated producer options grant no facts.
6101:         let context =
6102:             tcl_registry::model::ingress::resolve_environment("tcl8.6").default_context_registry();
6103:         let profile = tcl_dialect::DialectProfile::plain_tcl();
6104:         let input = crate::analyser::ResolvedAnalysisInput::new(
6105:             profile,
6106:             profile,
6107:             Arc::clone(&context),
6108:             tcl_lexer::LexerConfig::for_file_grammar(profile.grammar),
6109:         );
6110:         let options = UnitBuildOptions {
6111:             registry: context.commands(),
6112:             defer_top_level: false,
6113:             config: input.lexer_config(),
6114:             dialect: Some(profile),
6115:             external_call_sites: None,
6116:             declared_commands: None,
6117:         };
6118:         let selected =
6119:             CompilationUnit::build_with_analysis_input("puts VALUE", options, None, &input);
6120:         assert!(
6121:             selected
6122:                 .top_level
6123:                 .invocation_metadata_context_for_module(context.commands(), &selected.ir_module,)
6124:                 .is_some()
6125:         );
6126:         let mut wrong_config = options;
6127:         wrong_config.config.strict_quoting = !wrong_config.config.strict_quoting;
6128:         let wrong_profile = UnitBuildOptions {
6129:             dialect: Some(tcl_dialect::DialectProfile::find("tcl8.6").unwrap()),
6130:             ..options
6131:         };
6132:         for options in [wrong_config, wrong_profile] {
6133:             let refused =
6134:                 CompilationUnit::build_with_analysis_input("puts VALUE", options, None, &input);
6135:             assert_eq!(
6136:                 refused.ir_module.source_metadata_input.as_ref(),
6137:                 Some(&input)
6138:             );
6139:             assert!(refused.ir_module.source_entry.unknown_entry);
6140:             assert!(
6141:                 refused
6142:                     .ir_module
6143:                     .source_entry
6144:                     .logical_source_input
6145:                     .is_none()
6146:             );
6147:             assert!(refused.top_level.source_metadata_input().is_none());
6148:             assert!(
6149:                 refused
6150:                     .top_level
6151:                     .invocation_metadata_context_for_module(context.commands(), &refused.ir_module,)
6152:                     .is_none()
6153:             );
6154:             assert!(matches!(
6155:                 refused.top_level.semantic_facts.executable(),
6156:                 crate::semantic_analysis::ExecutableAnalysisAvailability::ContextUnavailable
6157:             ));
6158:         }
6159:         let mut stale_module = selected.ir_module.clone();
6160:         stale_module.dialect_profile = wrong_profile.dialect;
6161:         assert!(
6162:             selected
6163:                 .top_level
6164:                 .invocation_metadata_context_for_module(context.commands(), &stale_module,)
6165:                 .is_none()
6166:         );
6167:     }
6168: 
6169:     #[test]
6170:     fn supplied_hosted_source_entry_retains_advice_without_activation() {
6171:         // naming.compiler.original-analysis-metadata-context
6172:         // docs/design/analysis/name-resolution-proofs/original-analysis-metadata-context.md
6173:         for environment in ["f5-irules", "f5-iapps"] {
6174:             let environment = tcl_registry::model::ingress::resolve_environment(environment);
6175:             let profile = environment.unit_profile();
6176:             let context = environment.default_context_registry();
6177:             let input = crate::analyser::ResolvedAnalysisInput::new(
6178:                 profile,
6179:                 profile,
6180:                 Arc::clone(&context),
6181:                 tcl_lexer::LexerConfig::for_file_grammar(profile.grammar),
6182:             );
6183:             let unit = CompilationUnit::build_with_analysis_input(
6184:                 "set source_value VALUE",
6185:                 UnitBuildOptions {
6186:                     registry: context.commands(),
6187:                     defer_top_level: false,
6188:                     config: input.lexer_config(),
6189:                     dialect: Some(profile),
6190:                     external_call_sites: None,
6191:                     declared_commands: None,
6192:                 },
6193:                 None,
6194:                 &input,
6195:             );
6196:             let entry = &unit.ir_module.source_entry;
6197:             assert_eq!(entry.vendor_source_input.as_ref(), Some(&input));
6198:             assert!(entry.unknown_entry);
6199:             assert!(entry.native_entry.is_none());
6200:             assert!(entry.logical_source_input.is_none());
6201:             assert!(entry.hosted_execution_context.is_none());
6202:             assert!(entry.execution_name_policy.is_none());
6203:         }
6204:     }
6205: 
6206:     fn test_context() -> SemanticContext {
6207:         SemanticContext::for_environment("tcl8.6")
6208:     }
6209: 
6210:     fn registry() -> CommandRegistry {
6211:         // These fixtures assert concrete C Tcl behaviour, including 9.1 grammar.
6212:         CommandRegistry::build_default().project_for_profile(
6213:             tcl_registry::model::ingress::resolve_environment("tcl9.1").analyser_profile(),
6214:         )
6215:     }
6216: 
6217:     #[test]
6218:     fn semantic_value_projection_uses_actual_jim_entry_over_c_catalogue() {
6219:         let registry = registry();
6220:         // The actual interpreter entry selects Jim independently of the C catalogue.
6221:         // This software fixture observes no external provider execution.
6222:         let profile = tcl_registry::model::ingress::resolve_environment("jim").unit_profile();
6223:         let context = Arc::new(
6224:             tcl_registry::model::ingress::static_context_for("jim")
6225:                 .with_command_store(registry.snapshot().shared_registry()),
6226:         );
6227:         let config = tcl_lexer::LexerConfig::from_grammar(profile.grammar);
6228:         let input = crate::analyser::ResolvedAnalysisInput::new(
6229:             profile,
6230:             profile,
6231:             Arc::clone(&context),
6232:             config,
6233:         );
6234:         let (_runtime_owner, captured) =
6235:             crate::environment_ingress::captured_native_entry_with_owner(profile);
6236:         let entry = crate::command_binding::SourceAnalysisEntry {
6237:             metadata_context:
6238:                 crate::registry_invocation::OwnedInvocationMetadataContext::for_source_input(Some(
6239:                     &input,
6240:                 )),
6241:             native_entry: Some(Arc::new(captured)),
6242:             invocation_dialect: Some(tcl_registry::InvocationDialect::of_profile(profile)),
6243:             native_compilation: tcl_registry::native_compilation::NativeCompilationContext {
6244:                 mode: tcl_registry::native_compilation::NativeCompilationMode::Direct,
6245:                 ..Default::default()
6246:             },
6247:             ..Default::default()
6248:         };
6249:         let source =
6250:             "set x 003; set y [expr {$x}]; set z [expr {9223372036854775807 + 1}]; expr {$z + 1}";
6251:         let compiled = CompilationUnit::build_with_analysis_input(
6252:             source,
6253:             UnitBuildOptions {
6254:                 registry: &registry,
6255:                 defer_top_level: false,
6256:                 config,
6257:                 dialect: Some(profile),
6258:                 external_call_sites: None,
6259:                 declared_commands: None,
6260:             },
6261:             Some(&entry),
6262:             &input,
6263:         );
6264:         assert!(compiled.ir_module.source_entry.native_entry.is_some());
6265:         assert_eq!(
6266:             compiled.ir_module.source_metadata_input.as_ref(),
6267:             Some(&input)
6268:         );
6269:         let unit = &compiled.top_level;
6270:         let facts = unit
6271:             .semantic_values()
6272:             .expect("retained actual engine inputs");
6273:         assert!(facts.contents_iter().any(|(_, value)| {
6274:             *value
6275:                 == crate::analyses::LatticeValue::Const(crate::analyses::ConstValue::String(
6276:                     "003".to_owned(),
6277:                 ))
6278:         }));
6279:         assert!(facts.expression_iter().any(|(_, analysis)| {
6280:             analysis.evaluation.value == crate::tcl_expr_eval::TclValue::Int(i64::MIN)
6281:         }));
6282:         assert!(facts.expression_iter().any(|(_, analysis)| {
6283:             analysis.evaluation.value == crate::tcl_expr_eval::TclValue::Int(i64::MIN + 1)
6284:         }));
6285:         assert_eq!(
6286:             unit.semantic_value_projection,
6287:             Arc::new(unit.semantic_value_projection.uncached())
6288:         );
6289:         assert!(std::ptr::eq(facts, unit.semantic_values().unwrap()));
6290:     }
6291: 
6292:     #[test]
6293:     fn prepare_cfg_context_retains_same_tailed_body_parameters() {
6294:         let reg = registry();
6295:         let src = "namespace eval ::a { proc x {p1} { set q $p1 } }
6296: namespace eval ::b { proc x {p2 extra} { set q $p2 } }
6297: ";
6298:         let m =
6299:             crate::lowering::lower_to_ir_with_config(src, &reg, tcl_lexer::LexerConfig::default());
6300:         let (_, proc_params, _, _, _) = crate::cfg_builder::prepare_cfg_context(&m);
6301:         let a = fixture_id(&m.procedures, "::a::x");
6302:         let b = fixture_id(&m.procedures, "::b::x");
6303:         assert_ne!(a, b);
6304:         assert_eq!(proc_params.len(), 2);
6305:         assert_eq!(proc_params.get(&a), Some(&vec!["p1".to_string()]));
6306:         assert_eq!(
6307:             proc_params.get(&b),
6308:             Some(&vec!["p2".to_string(), "extra".to_string()])
6309:         );
6310:     }
6311: 
6312:     #[test]
6313:     fn build_for_empty_source() {
6314:         let cu = CompilationUnit::build_for("", &registry(), false);
6315:         assert_eq!(cu.source, "");
6316:         assert_eq!(cu.top_level.name, "::top");
6317:         assert!(cu.procedures.is_empty());
6318:     }
6319: 
6320:     #[test]
6321:     fn prepared_binding_mutation_projection_matches_compatibility_scan() {
6322:         let reg = registry();
6323:         let cu = CompilationUnit::build_for(
6324:             "rename string saved-string\nrename saved-string string\n",
6325:             &reg,
6326:             false,
6327:         );
6328:         assert_eq!(
6329:             cu.command_mutations,
6330:             crate::command_binding::scan_module_command_mutations(&cu.ir_module, &reg),
6331:         );
6332:     }
6333: 
6334:     /// Every method unit carries exactly one instance-state carrier
6335:     /// (`method_facts`), and its content matches the typed IR — the
6336:     /// invariant that keeps the existence fold (I230/O100/O101), the
6337:     /// W210/W211/W220 `known_bound` set, and the optimiser's method-constants
6338:     /// escaping set reading the same struct.
6339:     #[test]
6340:     fn method_units_carry_the_single_method_facts_carrier() {
6341:         let src = "oo::class create C {\n\
6342:                        variable state\n\
6343:                        method m {arg} { ::return $arg }\n\
6344:                    }\n";
6345:         let cu = CompilationUnit::build_for(src, &registry(), false);
6346:         let fu = fixture_method(&cu, "::C::m").expect("method unit built");
6347:         let facts = fu
6348:             .method_facts
6349:             .as_deref()
6350:             .expect("a method unit must carry method_facts");
6351:         assert_eq!(facts.params, vec!["arg".to_string()]);
6352:         assert!(facts.instance_vars.contains("state"));
6353:         let known = facts.known_bound_at_entry();
6354:         assert!(known.contains("arg") && known.contains("state"));
6355:         // The IR the carrier was built from agrees (same construction site).
6356:         let ir = cu
6357:             .ir_module
6358:             .methods
6359:             .unique_display("::C::m")
6360:             .map(|(_, method)| method)
6361:             .expect("method IR");
6362:         assert_eq!(facts.instance_vars, ir.instance_vars);
6363:         assert_eq!(facts.params, ir.params);
6364:     }
6365: 
6366:     /// TN: bodies with no object state — the top level and plain
6367:     /// procedures — carry no `method_facts`, so no consumer can mistake a
6368:     /// proc frame for a method frame.
6369:     #[test]
6370:     fn non_method_units_carry_no_method_facts() {
6371:         let src = "proc p {a} { return $a }\nset x 1\n";
6372:         let cu = CompilationUnit::build_for(src, &registry(), false);
6373:         assert!(cu.top_level.method_facts.is_none());
6374:         let fu = fixture_id_if_present(&cu.procedures, "::p")
6375:             .and_then(|id| cu.procedures.get(&id))
6376:             .expect("proc unit built");
6377:         assert!(fu.method_facts.is_none());
6378:     }
6379: 
6380:     #[test]
6381:     fn build_for_single_statement() {
6382:         let cu = CompilationUnit::build_for("set x 1", &registry(), false);
6383:         assert!(!cu.top_level.cfg.blocks.is_empty());
6384:         // SCCP should mark entry executable for a non-empty CFG.
6385:         assert!(
6386:             cu.top_level
6387:                 .sccp
6388:                 .executable_blocks
6389:                 .contains(&cu.top_level.ssa.entry)
6390:         );
6391:     }
6392: 
6393:     /// A reached callee write withdraws the old value at later reads without
6394:     /// poisoning the value that existed before the call.
6395:     fn assert_callee_global_write_is_positioned(name: &str) {
6396:         use crate::analyses::{ConstValue, LatticeValue};
6397:         let src = format!(
6398:             "set {name} 4\nset before ${name}\nproc helper {{}} {{global {name}; set {name} 17}}\nhelper\nset after ${name}\nif {{${name} == 4}} {{set stale BAD}}\n"
6399:         );
6400:         let cu = CompilationUnit::build_for(&src, &registry(), false);
6401:         let before = cu
6402:             .top_level
6403:             .sccp
6404:             .values
6405:             .iter()
6406:             .filter(|((symbol, _), _)| cu.top_level.ssa.var_name(*symbol) == "before")
6407:             .collect::<Vec<_>>();
6408:         assert!(
6409:             before.iter().any(|(_, value)| matches!(
6410:                 value,
6411:                 LatticeValue::Const(ConstValue::Int(4))
6412:             ) || matches!(value, LatticeValue::Const(ConstValue::String(value)) if value == "4")),
6413:             "prior value must remain represented: {before:?}"
6414:         );
6415:         let after = cu
6416:             .top_level
6417:             .sccp
6418:             .values
6419:             .iter()
6420:             .filter(|((symbol, _), _)| cu.top_level.ssa.var_name(*symbol) == "after")
6421:             .collect::<Vec<_>>();
6422:         assert!(!after.is_empty(), "post-call read must remain represented");
6423:         assert!(
6424:             after.iter().all(|(_, value)| !matches!(
6425:                 value,
6426:                 LatticeValue::Const(ConstValue::Int(4))
6427:             ) && !matches!(value, LatticeValue::Const(ConstValue::String(value)) if value == "4")),
6428:             "post-call read must not reuse the stale value: {after:?}"
6429:         );
6430:         assert!(
6431:             cu.top_level
6432:                 .sccp
6433:                 .constant_branches
6434:                 .iter()
6435:                 .all(|selected| !selected.value),
6436:             "stale condition cannot select its true body"
6437:         );
6438:     }
6439: 
6440:     #[test]
6441:     fn top_level_var_touched_by_callee_global_is_overdefined() {
6442:         assert_callee_global_write_is_positioned("g");
6443:     }
6444: 
6445:     #[test]
6446:     fn top_level_dual_ported_var_touched_by_callee_global_is_overdefined() {
6447:         assert_callee_global_write_is_positioned("tcl_precision");
6448:     }
6449: 
6450:     /// Control: a top-level name *no* procedure ever `global`-declares must
6451:     /// still fold to a genuine `Const` — the whole-module scan must not
6452:     /// over-widen every top-level variable (that would be a precision
6453:     /// regression, not a soundness fix).
6454:     #[test]
6455:     fn top_level_var_untouched_by_any_callee_still_folds() {
6456:         let reg = registry();
6457:         let src = "set safe_const 42\nproc other {} { puts unrelated }\nother\n";
6458:         let cu = CompilationUnit::build_for(src, &reg, false);
6459:         let sym = cu
6460:             .top_level
6461:             .ssa
6462:             .var_symbol("safe_const")
6463:             .expect("top-level `safe_const` should be interned");
6464:         let has_const =
6465:             cu.top_level.sccp.values.iter().any(|((s, _), lv)| {
6466:                 *s == sym && matches!(lv, crate::analyses::LatticeValue::Const(_))
6467:             });
6468:         assert!(has_const, "expected `safe_const` to still fold to a Const");
6469:     }
6470: 
6471:     /// Existence is a deep-tier fact: a procedure lattice requested
6472:     /// at the fast tier runs no rung, so every read of it answers
6473:     /// `Unavailable(Fast)` — neither bound nor unbound — and W210 and W213
6474:     /// stay silent where the deep build reports both; a unit over the
6475:     /// complexity ceiling answers `Unavailable(ComplexityGuarded)`.
6476:     #[test]
6477:     fn existence_is_unavailable_at_the_fast_tier() {
6478:         use tcl_core_types::DiagCode;
6479:         let reg = tcl_registry::model::ingress::static_context_for("tcl8.6").commands();
6480:         let src = "proc p {} {set x 1; unset x; unset x; puts $x}\n";
6481:         let lifecycle = |cu: CompilationUnit| -> Vec<DiagCode> {
6482:             let mut analyser = crate::analyser::Analyser::new();
6483:             analyser.set_cu_override(Arc::new(cu));
6484:             analyser
6485:                 .analyse(src, "tcl8.6")
6486:                 .diagnostics
6487:                 .into_iter()
6488:                 .map(|d| d.code)
6489:                 .filter(|code| matches!(code, DiagCode::W210 | DiagCode::W213))
6490:                 .collect()
6491:         };
6492:         let deep = CompilationUnit::build_for_dialect(src, reg, false, "tcl8.6");
6493:         let deep_p = deep.function("::p").expect("::p built");
6494:         assert_eq!(deep_p.tier, AnalysisTier::Deep);
6495:         let x = deep_p.ssa.var_symbol("x").expect("x interned");
6496:         let entry = deep_p.cfg.entry;
6497:         let cfg = deep_p.cfg.clone();
6498:         assert!(matches!(
6499:             deep_p.existence(x, ExistencePoint::Exit(entry)),
6500:             FactView::Domain(DomainFact::Existence(_))
6501:         ));
6502: 
6503:         let key = crate::value_transfer::AnalysisContextKey::detached().at_tier(AnalysisTier::Fast);
6504:         let fast_p = FunctionUnit::build_with_param_constants_and_classes_under(
6505:             "::p",
6506:             cfg.clone(),
6507:             &[],
6508:             UnitDialect {
6509:                 registry: reg,
6510:                 config: tcl_lexer::LexerConfig::default(),
6511:                 source_metadata_input: None,
6512:             },
6513:             None,
6514:             &HashSet::new(),
6515:             ModuleAnalysisFacts {
6516:                 trace: ModuleTraceFacts::none(),
6517:                 analysis_context: &key,
6518:                 command_trust: &crate::command_binding::ModuleCommandMutations::default(),
6519:             },
6520:         );
6521:         assert_eq!(fast_p.tier, AnalysisTier::Fast);
6522:         assert!(fast_p.sccp.existence.is_empty());
6523:         for point in [
6524:             ExistencePoint::Exit(entry),
6525:             ExistencePoint::Before(entry, 0),
6526:             ExistencePoint::Version(1),
6527:         ] {
6528:             assert_eq!(
6529:                 fast_p.existence(x, point),
6530:                 FactView::Top(DeclineReason::Unavailable(AnalysisTier::Fast))
6531:             );
6532:         }
6533:         let mut fast = deep.clone();
6534:         let p_id = fixture_id(&deep.ir_module.procedures, "::p");
6535:         fast.procedures.insert(p_id, fast_p);
6536: 
6537:         let found = lifecycle(deep);
6538:         assert!(
6539:             found.contains(&DiagCode::W213) && found.contains(&DiagCode::W210),
6540:             "{found:?}"
6541:         );
6542:         assert_eq!(lifecycle(fast), Vec::<DiagCode>::new());
6543: 
6544:         let guarded = FunctionUnit::trivial_guarded("::p", cfg);
6545:         assert_eq!(
6546:             guarded.existence(x, ExistencePoint::Exit(entry)),
6547:             FactView::Top(DeclineReason::Unavailable(AnalysisTier::ComplexityGuarded))
6548:         );
6549:     }
6550: 
6551:     #[test]
6552:     fn complexity_guard_flags_byte_huge_proc() {
6553:         // A normal proc is analysed (not guarded), with real SSA + SCCP.
6554:         let normal = CompilationUnit::build_for("proc small {} { set x 1 }", &registry(), false);
6555:         let small = normal.function("::small").expect("::small built");
6556:         assert!(!small.complexity_guarded);
6557:         assert!(!small.ssa.blocks.is_empty());
6558: 
6559:         // A block-light but byte-huge body (one statement with a ~270 KB
6560:         // literal) trips the body-byte half of the complexity guard: the unit
6561:         // is flagged and carries a trivial SSA, so the O(blocks·vars) walk and
6562:         // the dataflow passes never run on it.
6563:         let big_literal = "A".repeat(270_000);
6564:         let src = format!("proc big {{}} {{ set x \"{big_literal}\" }}");
6565:         let cu = CompilationUnit::build_for(&src, &registry(), false);
6566:         let big = cu.function("::big").expect("::big built");
6567:         assert!(big.complexity_guarded, "byte-huge body must be guarded");
6568:         assert!(big.ssa.blocks.is_empty(), "guarded unit has trivial SSA");
6569:         assert!(big.sccp.values.is_empty());
6570:         // Guarded functions are excluded from the analysable-function view the
6571:         // per-proc diagnostic and optimiser passes iterate.
6572:         assert!(
6573:             cu.analysable_functions().all(|fu| fu.name != "::big"),
6574:             "guarded ::big must be skipped by analysable_functions"
6575:         );
6576:     }
6577: 
6578:     #[test]
6579:     fn build_for_captures_procedures() {
6580:         let cu = CompilationUnit::build_for("proc greet {name} {puts $name}", &registry(), false);
6581:         assert!(!cu.procedures.is_empty());
6582:         assert!(cu.function("::greet").is_some());
6583:         assert!(cu.function("::top").is_some());
6584:         // No OO methods in a plain proc source.
6585:         assert!(cu.methods.is_empty());
6586:     }
6587: 
6588:     #[test]
6589:     fn colliding_method_reports_keep_independent_analysis_units() {
6590:         let source = "namespace eval A {}\noo::class create A::B {method c {} {return LEFT}}\noo::class create A {method B::c {} {return RIGHT}; method <constructor> {} {return NAMED}; constructor {} {set local ACTUAL}; export B::c <constructor>}\n";
6591:         let unit = CompilationUnit::build_for(source, &registry(), false);
6592:         assert_eq!(unit.ir_module.methods.len(), 4);
6593:         assert_eq!(unit.methods.len(), 4);
6594:         for (id, method) in &unit.ir_module.methods {
6595:             let function = unit
6596:                 .methods
6597:                 .get(id)
6598:                 .expect("every retained method has its own analysis unit");
6599:             assert_eq!(function.body_id, Some(*id));
6600:             assert_eq!(function.name, method.reporting_label());
6601:         }
6602:     }
6603: 
6604:     #[test]
6605:     fn build_for_lowers_oo_methods_to_function_units() {
6606:         // TclOO method bodies get their own
6607:         // FunctionUnit (CFG → SSA → analysis) in `cu.methods`, kept
6608:         // separate from `procedures` so the optimiser's O126 gate can
6609:         // iterate them. `procedures` stays free of method qnames.
6610:         let src = "oo::class create Counter {\n\
6611:                    \x20   variable n\n\
6612:                    \x20   method bump {} { ::incr n }\n\
6613:                    \x20   method get {} { ::return $n }\n\
6614:                    }\n";
6615:         let cu = CompilationUnit::build_for(src, &registry(), false);
6616:         let mut keys: Vec<&String> = cu.methods.values().map(|method| &method.name).collect();
6617:         keys.sort();
6618:         assert_eq!(
6619:             keys,
6620:             vec![
6621:                 &"::Counter::bump".to_string(),
6622:                 &"::Counter::get".to_string()
6623:             ],
6624:             "method units: {keys:?}",
6625:         );
6626:         // Each method unit carries a real analysis pipeline (its CFG
6627:         // has the entry block at minimum).
6628:         let get = fixture_method(&cu, "::Counter::get").expect("unique retained fixture method");
6629:         assert_eq!(get.name, "::Counter::get");
6630:         assert!(!get.cfg.blocks.is_empty());
6631:         // Methods are NOT mixed into the per-proc map.
6632:         assert!(
6633:             !cu.procedures
6634:                 .values()
6635:                 .any(|procedure| procedure.name == "::Counter::get")
6636:         );
6637:     }
6638: 
6639:     #[test]
6640:     fn runtime_selected_method_commands_guard_deep_cfg_analysis() {
6641:         let cu = CompilationUnit::build_for(
6642:             "interp alias {} e {} expr\n\
6643:              oo::class create C {\n\
6644:                  method relative {} {set x 1}\n\
6645:                  method absolute {} {::set x 1}\n\
6646:                  method absolute_dispatch {} {::set x [my absolute]}\n\
6647:                  method absolute_expr {p} {::return [::expr {$p + 1}]}\n\
6648:                  method absolute_info {p} {::if {[::info exists p]} {::puts yes}}\n\
6649:                  method absolute_regex {s} {::set re {a+}; ::regexp $re $s}\n\
6650:                  method nested_alias {p} {::set x [e {$p + 1}]}\n\
6651:              }",
6652:             &registry(),
6653:             false,
6654:         );
6655:         assert!(
6656:             fixture_method(&cu, "::C::relative")
6657:                 .expect("unique retained fixture method")
6658:                 .complexity_guarded,
6659:             "a receiver-local command may shadow the lexical builtin"
6660:         );
6661:         assert!(
6662:             !fixture_method(&cu, "::C::absolute")
6663:                 .expect("unique retained fixture method")
6664:                 .complexity_guarded,
6665:             "an absolute-only method is independent of the receiver namespace"
6666:         );
6667:         assert!(
6668:             fixture_method(&cu, "::C::absolute_dispatch")
6669:                 .expect("unique retained fixture method")
6670:                 .complexity_guarded,
6671:             "the receiver namespace can shadow TclOO's injected dispatch commands"
6672:         );
6673:         for name in [
6674:             "::C::absolute_expr",
6675:             "::C::absolute_info",
6676:             "::C::absolute_regex",
6677:         ] {
6678:             assert!(
6679:                 !fixture_method(&cu, name)
6680:                     .expect("unique retained fixture method")
6681:                     .complexity_guarded,
6682:                 "absolute-only method {name} must retain deep analysis: {:#?}",
6683:                 fixture_method(&cu, name).expect("unique retained fixture method")
6684:             );
6685:         }
6686:         assert!(
6687:             fixture_method(&cu, "::C::nested_alias")
6688:                 .expect("unique retained fixture method")
6689:                 .complexity_guarded,
6690:             "a relative nested binding consumed by typed lowering remains runtime-selected"
6691:         );
6692:     }
6693: 
6694:     #[test]
6695:     fn switch_subject_counts_as_param_use() {
6696:         // The `switch -- $col` subject lowers to an
6697:         // `ExprNode::Raw` branch condition.  The expr var-scan now
6698:         // recovers `$col`, so the parameter's def-use chain has a
6699:         // live (terminator) use instead of looking dead — the precise
6700:         // path behind W214 (unused parameter).  `col` is referenced
6701:         // *only* as the switch subject here, so a live chain proves
6702:         // the Raw scan reached the def-use builder.
6703:         let cu = CompilationUnit::build_for(
6704:             "proc p {col} { switch -- $col { a {set y 1} } }",
6705:             &registry(),
6706:             false,
6707:         );
6708:         let fu = cu.function("::p").expect("proc ::p should exist");
6709:         let col_live = fu.def_use.chains.iter().any(|(key, chain)| {
6710:             fu.def_use
6711:                 .symbol(&fu.ssa, key.0)
6712:                 .is_some_and(|symbol| fu.ssa.var_name(symbol) == "col")
6713:                 && !chain.is_dead()
6714:         });
6715:         assert!(
6716:             col_live,
6717:             "switch subject `$col` should register a live use; chains: {:?}",
6718:             fu.def_use.chains.keys().collect::<Vec<_>>(),
6719:         );
6720:     }
6721: 
6722:     #[test]
6723:     fn switch_glob_arm_body_read_counts_as_param_use() {
6724:         // A `switch -glob`/`-regexp` arm body is a real analysed CFG region,
6725:         // so a parameter referenced *only* inside a glob-arm body has a live
6726:         // def-use chain — the precise path behind W214.
6727:         // Multi-arg arm form (the single-braced-body form is a separate,
6728:         // pre-existing lowering gap affecting every mode equally).
6729:         for (mode, pat) in [("-glob", "a*"), ("-regexp", "a.*")] {
6730:             let src = format!("proc p {{val}} {{ switch {mode} -- $col {pat} {{puts $val}} }}");
6731:             let cu = CompilationUnit::build_for(&src, &registry(), false);
6732:             let fu = cu.function("::p").expect("proc ::p should exist");
6733:             let val_live = fu.def_use.chains.iter().any(|(key, chain)| {
6734:                 fu.def_use
6735:                     .symbol(&fu.ssa, key.0)
6736:                     .is_some_and(|symbol| fu.ssa.var_name(symbol) == "val")
6737:                     && !chain.is_dead()
6738:             });
6739:             assert!(
6740:                 val_live,
6741:                 "{mode} arm-body read `$val` should register a live use; chains: {:?}",
6742:                 fu.def_use.chains.keys().collect::<Vec<_>>(),
6743:             );
6744:         }
6745:     }
6746: 
6747:     #[test]
6748:     fn return_type_infers_int_literal() {
6749:         let cu = CompilationUnit::build_for("proc f {} { return 1 }", &registry(), false);
6750:         let fu = cu.function("::f").expect("proc ::f");
6751:         assert_eq!(fu.return_type, TypeLattice::of(tcl_registry::TclType::Int));
6752:     }
6753: 
6754:     #[test]
6755:     fn return_type_infers_string_literal() {
6756:         let cu = CompilationUnit::build_for("proc f {} { return \"hi\" }", &registry(), false);
6757:         let fu = cu.function("::f").expect("proc ::f");
6758:         assert_eq!(
6759:             fu.return_type,
6760:             TypeLattice::of(tcl_registry::TclType::String)
6761:         );
6762:     }
6763: 
6764:     #[test]
6765:     fn return_type_follows_local_var() {
6766:         let cu = CompilationUnit::build_for("proc f {} { set x 1; return $x }", &registry(), false);
6767:         let fu = cu.function("::f").expect("proc ::f");
6768:         assert_eq!(fu.return_type, TypeLattice::of(tcl_registry::TclType::Int));
6769:     }
6770: 
6771:     #[test]
6772:     fn return_type_joins_branches_to_common_int() {
6773:         let cu = CompilationUnit::build_for(
6774:             "proc f {a} { if {$a} { return 1 } else { return 2 } }",
6775:             &registry(),
6776:             false,
6777:         );
6778:         let fu = cu.function("::f").expect("proc ::f");
6779:         assert_eq!(fu.return_type, TypeLattice::of(tcl_registry::TclType::Int));
6780:     }
6781: 
6782:     #[test]
6783:     fn return_type_partial_return_widens_via_fallthrough() {
6784:         // `if {$a} { return 1 }` with no else: the false path falls off
6785:         // the end of the body (Tcl returns the last command's result),
6786:         // so the joined return type must not be a confident `Int` — the
6787:         // fall-through exit widens it to Overdefined.
6788:         let cu =
6789:             CompilationUnit::build_for("proc f {a} { if {$a} { return 1 } }", &registry(), false);
6790:         let fu = cu.function("::f").expect("proc ::f");
6791:         assert_eq!(
6792:             fu.return_type,
6793:             TypeLattice::overdefined(),
6794:             "partial-return proc must widen, got {:?}",
6795:             fu.return_type,
6796:         );
6797:     }
6798: 
6799:     #[test]
6800:     fn with_memory_ssa_populates_optional() {
6801:         let cu = CompilationUnit::build_for("set x 1", &registry(), false)
6802:             .with_memory_ssa(&registry(), Some(test_context()));
6803:         assert!(cu.top_level.memory_ssa.is_some());
6804:     }
6805: 
6806:     #[test]
6807:     fn semantic_bundle_keeps_dialect_and_defers_unneeded_world_state() {
6808:         let linear = CompilationUnit::build_for_profile(
6809:             "puts hello",
6810:             &registry(),
6811:             false,
6812:             tcl_registry::model::ingress::resolve_environment("tcl8.6").analyser_profile(),
6813:         );
6814:         let facts = &linear.top_level.semantic_facts;
6815:         assert_eq!(
6816:             facts.metadata_context(),
6817:             linear
6818:                 .top_level
6819:                 .source_metadata_input()
6820:                 .map(|input| { input.borrowed_context_registry().context() }),
6821:         );
6822:         let executable = facts.executable();
6823:         assert_eq!(executable.invocations().count(), 1);
6824:         assert!(executable.world_state_ssa().is_none());
6825:         assert!(matches!(
6826:             executable,
6827:             crate::semantic_analysis::ExecutableAnalysisAvailability::WorldStateNotRequired { .. }
6828:         ));
6829:         assert_eq!(executable.completion_inputs().count(), 1);
6830:         assert_eq!(executable.effect_inputs().count(), 1);
6831: 
6832:         let structured = CompilationUnit::build_for_profile(
6833:             "if {1} { puts hello }",
6834:             &registry(),
6835:             false,
6836:             tcl_registry::model::ingress::resolve_environment("tcl8.6").analyser_profile(),
6837:         );
6838:         let structured = structured.top_level.semantic_facts.executable();
6839:         assert!(structured.function().is_some());
6840:         // `if` is projected into executable edges, so it is a structured
6841:         // region rather than an opaque compatibility barrier.
6842:         assert_eq!(structured.opaque_regions().count(), 0);
6843:         assert_eq!(structured.structured_regions().count(), 1);
6844:         assert!(structured.world_state_ssa().is_none());
6845: 
6846:         let ir = crate::lowering::lower_to_ir("puts hello", &registry());
6847:         let explicit = crate::semantic_analysis::SemanticAnalysisBundle::build(
6848:             &registry(),
6849:             Some(test_context()),
6850:             &ir.top_level,
6851:             crate::dispatch_proof::DispatchEntryAssumption::PristineRegistryWorld,
6852:         );
6853:         assert!(explicit.executable().world_state_ssa().is_some());
6854: 
6855:         let legacy = CompilationUnit::build_for("puts hello", &registry(), false);
6856:         assert!(matches!(
6857:             legacy.top_level.semantic_facts.executable(),
6858:             crate::semantic_analysis::ExecutableAnalysisAvailability::ContextUnavailable
6859:         ));
6860:     }
6861: 
6862:     #[test]
6863:     fn deep_semantic_analysis_materialises_every_retained_body_sidecar() {
6864:         let deep = CompilationUnit::build_for_profile(
6865:             "proc p {} { puts hello }\nnamespace eval ::n { puts body }\n",
6866:             &registry(),
6867:             false,
6868:             tcl_registry::model::ingress::resolve_environment("tcl8.6").analyser_profile(),
6869:         )
6870:         .with_deep_semantic_analysis(&registry(), Some(test_context()));
6871:         // The top-level source contains a structural `namespace eval` whose
6872:         // completion switch is not yet representable by the common world-SSA
6873:         // planner. Deep inspection must still retain executable facts and the
6874:         // typed `WorldStateDeclined` outcome rather than requiring a graph.
6875:         assert!(
6876:             deep.top_level
6877:                 .semantic_facts
6878:                 .executable()
6879:                 .function()
6880:                 .is_some()
6881:         );
6882:         assert!(
6883:             fixture_id_if_present(&deep.procedures, "::p")
6884:                 .and_then(|id| deep.procedures.get(&id))
6885:                 .unwrap()
6886:                 .semantic_facts
6887:                 .executable()
6888:                 .function()
6889:                 .is_some()
6890:         );
6891:         assert!(
6892:             deep.body_units.values().all(|unit| unit
6893:                 .semantic_facts
6894:                 .executable()
6895:                 .function()
6896:                 .is_some())
6897:         );
6898:     }
6899: 
6900:     #[test]
6901:     fn functions_iterator_yields_top_plus_procs() {
6902:         let cu = CompilationUnit::build_for(
6903:             "proc foo {} {return 1}\nproc bar {} {return 2}",
6904:             &registry(),
6905:             false,
6906:         );
6907:         let count = cu.functions().count();
6908:         assert_eq!(count, cu.procedures.len() + 1);
6909:     }
6910: 
6911:     /// Interprocedural call-site literal seeding (TP/FP/TN/FN suite for
6912:     /// [`collect_call_site_constants`] / [`params_constants_from_native_call_sites`]).
6913:     mod call_site_param_constants {
6914:         use super::*;
6915:         use crate::analyses::LatticeValue;
6916: 
6917:         /// FN regression: a call from inside a `TclOO` method body to an
6918:         /// ordinary user proc is a real caller with a differing argument,
6919:         /// but methods are built in a *separate* pass that runs after the
6920:         /// call-site scan. Without
6921:         /// `build_extra_call_site_scan_contexts` the scan sees only the one
6922:         /// external `helper a` call and wrongly seeds `mode` as the constant
6923:         /// `"a"`.
6924:         #[test]
6925:         fn call_site_inside_tcloo_method_body_is_not_missed() {
6926:             let reg = registry();
6927:             let src = "
6928:                 proc helper {mode} {
6929:                     if {$mode eq \"a\"} { set r 1 } else { set r 2 }
6930:                 }
6931:                 oo::class create Widget {
6932:                     method go {} { helper b }
6933:                 }
6934:                 helper a
6935:                 [Widget new] go
6936:             ";
6937:             let cu = CompilationUnit::build_for(src, &reg, false);
6938:             let f = fixture_id_if_present(&cu.procedures, "::helper")
6939:                 .and_then(|id| cu.procedures.get(&id))
6940:                 .expect("helper analysed");
6941:             assert!(
6942:                 !knows_condition_mentioning(f, "mode"),
6943:                 "helper is called with both \"a\" (external) and \"b\" (from the method body); must not fold: {:?}",
6944:                 f.sccp.constant_branches,
6945:             );
6946:         }
6947: 
6948:         /// Imported calls retain the original implementation allocation and
6949:         /// contribute their differing arguments to the shared caller evidence.
6950:         #[test]
6951:         fn call_site_via_namespace_import_alias_is_not_missed() {
6952:             let reg = registry();
6953:             let src = "
6954:                 namespace eval ::lib {
6955:                     namespace export helper
6956:                     proc helper {mode} {
6957:                         if {$mode eq \"a\"} { set r 1 } else { set r 2 }
6958:                     }
6959:                 }
6960:                 namespace eval ::app {
6961:                     namespace import ::lib::helper
6962:                     proc go {} { helper b }
6963:                 }
6964:                 ::lib::helper a
6965:                 ::app::go
6966:             ";
6967:             let cu = CompilationUnit::build_for(src, &reg, false);
6968:             let f = fixture_id_if_present(&cu.procedures, "::lib::helper")
6969:                 .and_then(|id| cu.procedures.get(&id))
6970:                 .expect("helper analysed");
6971:             assert!(
6972:                 !knows_condition_mentioning(f, "mode"),
6973:                 "helper is called with both \"a\" (direct) and \"b\" (via the ::app import); must not fold: {:?}",
6974:                 f.sccp.constant_branches,
6975:             );
6976:         }
6977: 
6978:         /// A real wildcard import requires the source namespace to export
6979:         /// its procedure. Publishing that command retains an open caller set.
6980:         const WILDCARD_IMPORT_SRC: &str = "
6981:             namespace eval ::lib {
6982:                 namespace export helper
6983:                 proc helper {mode} {
6984:                     if {$mode eq \"prod\"} { set r 1 } else { set r 2 }
6985:                 }
6986:             }
6987:             namespace eval ::app {
6988:                 namespace import ::lib::*
6989:                 proc go {} { helper prod }
6990:             }
6991:             ::lib::helper prod
6992:             ::app::go
6993:         ";
6994: 
6995:         #[test]
6996:         fn wildcard_namespace_import_preserves_actual_identity_and_open_callers() {
6997:             let reg = registry();
6998:             let cu = CompilationUnit::build_for(WILDCARD_IMPORT_SRC, &reg, false);
6999:             let bindings = crate::command_binding::SourceCommandBindings::analyse(
7000:                 WILDCARD_IMPORT_SRC,
7001:                 tcl_lexer::LexerConfig::default(),
7002:                 &reg,
7003:             );
7004:             let imported = bindings.invocation_at(
7005:                 "helper",
7006:                 "::app",
7007:                 u32::try_from(WILDCARD_IMPORT_SRC.find("helper prod").unwrap()).unwrap(),
7008:             );
7009:             let direct = bindings.invocation_at(
7010:                 "::lib::helper",
7011:                 "::",
7012:                 u32::try_from(WILDCARD_IMPORT_SRC.find("::lib::helper prod").unwrap()).unwrap(),
7013:             );
7014:             let imported_target = imported
7015:                 .proved_handler_target()
7016:                 .expect("reached imported proc");
7017:             let direct_target = direct.proved_handler_target().expect("reached direct proc");
7018:             assert_eq!(imported_target.command, "::lib::helper");
7019:             assert_eq!(imported_target.identity, direct_target.identity);
7020:             assert_eq!(
7021:                 imported_target.implementation_allocation,
7022:                 direct_target.implementation_allocation,
7023:             );
7024:             assert_eq!(imported.evaluated_written_argument_value(0), Some("prod"));
7025:             assert_eq!(direct.evaluated_written_argument_value(0), Some("prod"));
7026:             let function = fixture_id_if_present(&cu.procedures, "::lib::helper")
7027:                 .and_then(|id| cu.procedures.get(&id))
7028:                 .expect("helper analysed");
7029:             assert!(!knows_condition_mentioning(function, "mode"));
7030:             assert_eq!(
7031:                 function.sccp.constant_branches,
7032:                 [] as [crate::sccp::ConstantBranch; 0]
7033:             );
7034:         }
7035: 
7036:         #[test]
7037:         fn wildcard_import_without_export_does_not_manufacture_a_caller() {
7038:             let reg = registry();
7039:             let source = WILDCARD_IMPORT_SRC.replace("namespace export helper", "");
7040:             let bindings = crate::command_binding::SourceCommandBindings::analyse(
7041:                 &source,
7042:                 tcl_lexer::LexerConfig::default(),
7043:                 &reg,
7044:             );
7045:             let imported = bindings.invocation_at(
7046:                 "helper",
7047:                 "::app",
7048:                 u32::try_from(source.find("helper prod").unwrap()).unwrap(),
7049:             );
7050:             assert!(imported.proved_handler_target().is_none());
7051:             assert!(
7052:                 imported
7053:                     .targets
7054:                     .iter()
7055:                     .all(|target| target.command != "::lib::helper")
7056:             );
7057:         }
7058: 
7059:         /// Wildcard publication retains an open caller set even when a host
7060:         /// supplies a closed view of the files in its current workspace.
7061:         /// An export publishes `::lib::helper` for *any* other unit to import
7062:         /// and call with a different literal, including one in a different
7063:         /// checkout that no project enumeration can reach.
7064:         #[test]
7065:         fn exported_namespace_declines_the_seed_even_with_a_workspace_view() {
7066:             let reg = registry();
7067:             let exported = WILDCARD_IMPORT_SRC.replace(
7068:                 "namespace eval ::lib {",
7069:                 "namespace eval ::lib {\n                namespace export *",
7070:             );
7071:             for cu in [
7072:                 CompilationUnit::build_for(&exported, &reg, false),
7073:                 build_closed_world(&exported, &reg),
7074:             ] {
7075:                 let f = fixture_id_if_present(&cu.procedures, "::lib::helper")
7076:                     .and_then(|id| cu.procedures.get(&id))
7077:                     .expect("helper analysed");
7078:                 assert!(
7079:                     !knows_condition_mentioning(f, "mode"),
7080:                     "`namespace export *` publishes helper beyond any enumerable project: {:?}",
7081:                     f.sccp.constant_branches,
7082:                 );
7083:             }
7084:         }
7085: 
7086:         /// A proc reached only through a
7087:         /// `namespace ensemble` `-map` redirection is a real caller the
7088:         /// call-site scan cannot resolve — it has no model of ensemble
7089:         /// dispatch. tclsh8.6/9.0-confirmed: with `namespace ensemble
7090:         /// create -command myens -map {go helper}`, `myens go dev` prints
7091:         /// `helper mode=dev`, so `mode` genuinely varies and must not fold.
7092:         ///
7093:         /// Nothing pinned that today. What makes it safe is *indirect*: the
7094:         /// registry marks `namespace ensemble` with `Traits::EXPORTS_COMMAND`,
7095:         /// which `params_constants_from_call_sites` treats as a boundary
7096:         /// publishing the file's commands to callers it cannot enumerate, so
7097:         /// the whole module declines seeding. Sound but blunt — narrowing
7098:         /// that trait, or resolving *some* ensemble maps, would silently
7099:         /// reopen the false-fold shape here. This test guards the mechanism,
7100:         /// whatever replaces it: the fold must stay off unless a real
7101:         /// ensemble-map resolution exists.
7102:         #[test]
7103:         fn ensemble_map_redirected_caller_does_not_fold_issue_979() {
7104:             let reg = registry();
7105:             let src = "
7106:                 proc helper {mode} {
7107:                     if {$mode eq \"prod\"} { set r 1 } else { set r 2 }
7108:                 }
7109:                 helper prod
7110:                 helper prod
7111:                 namespace ensemble create -command myens -map {go helper}
7112:                 myens go dev
7113:             ";
7114:             for cu in [
7115:                 CompilationUnit::build_for(src, &reg, false),
7116:                 build_closed_world(src, &reg),
7117:             ] {
7118:                 let f = fixture_id_if_present(&cu.procedures, "::helper")
7119:                     .and_then(|id| cu.procedures.get(&id))
7120:                     .expect("helper analysed");
7121:                 assert!(
7122:                     !knows_condition_mentioning(f, "mode"),
7123:                     "`myens go dev` reaches helper with \"dev\" (tclsh8.6/9.0-confirmed), \
7124:                      so mode is not caller-invariant: {:?}",
7125:                     f.sccp.constant_branches,
7126:                 );
7127:             }
7128:         }
7129: 
7130:         /// FP guard: a `TclOO` method body resolves
7131:         /// bare commands against the GLOBAL namespace, never the class's own
7132:         /// namespace — tclsh8.6-confirmed live: `[::foo::Widget new] go`
7133:         /// (method body `helper b`) calls `::helper`, never
7134:         /// `::foo::Widget::helper`, even though the latter exists and is
7135:         /// exactly what naively deriving the caller's namespace from the
7136:         /// method's own qualified name (`::foo::Widget::go` → `::foo::Widget`)
7137:         /// would try first. Before forcing method bodies to resolve against
7138:         /// global, this misattributed the method's call to
7139:         /// `::foo::Widget::helper` (folding a condition on a call that never
7140:         /// actually happens) while simultaneously losing it as evidence for
7141:         /// the real target `::helper` (which then wrongly folded on its one
7142:         /// remaining, external-only literal).
7143:         #[test]
7144:         fn method_body_bare_call_resolves_against_global_not_class_namespace() {
7145:             let reg = registry();
7146:             let src = "
7147:                 namespace eval ::foo {
7148:                     oo::class create Widget {
7149:                         method go {} { helper b }
7150:                     }
7151:                 }
7152:                 namespace eval ::foo::Widget {
7153:                     proc helper {mode} {
7154:                         if {$mode eq \"WRONG\"} { set r 1 } else { set r 2 }
7155:                     }
7156:                 }
7157:                 proc helper {mode} {
7158:                     if {$mode eq \"a\"} { set r 1 } else { set r 2 }
7159:                 }
7160:                 helper a
7161:                 [::foo::Widget new] go
7162:             ";
7163:             let cu = CompilationUnit::build_for(src, &reg, false);
7164:             let global_helper = fixture_id_if_present(&cu.procedures, "::helper")
7165:                 .and_then(|id| cu.procedures.get(&id))
7166:                 .expect("::helper analysed");
7167:             let ns_helper = fixture_id_if_present(&cu.procedures, "::foo::Widget::helper")
7168:                 .and_then(|id| cu.procedures.get(&id))
7169:                 .expect("::foo::Widget::helper analysed");
7170:             assert!(
7171:                 !knows_condition_mentioning(global_helper, "mode"),
7172:                 "::helper is called with both \"a\" and \"b\" (the method body, once \
7173:                  correctly resolved to global): {:?}",
7174:                 global_helper.sccp.constant_branches,
7175:             );
7176:             assert!(
7177:                 !knows_condition_mentioning(ns_helper, "mode"),
7178:                 "::foo::Widget::helper is never actually called by real Tcl semantics, \
7179:                  so no call-site evidence should ever reach it: {:?}",
7180:                 ns_helper.sccp.constant_branches,
7181:             );
7182:         }
7183: 
7184:         /// FN regression: `uplevel #0
7185:         /// { … }`'s body resolves bare commands against the GLOBAL
7186:         /// namespace — tclsh8.6/9.0-confirmed live: `uplevel #0 { helper b
7187:         /// }` inside `::foo::runIt` prints `GLOBAL helper mode=b`, never the
7188:         /// `::foo::helper` sitting in the enclosing namespace.
7189:         /// `Statement::UpFrame`'s body survives CFG construction as a block
7190:         /// *statement*, which `scan_cfg_callers` (walking only
7191:         /// `Call`/`Barrier`) skips entirely, so this real, differing call
7192:         /// site would vanish from `::helper`'s evidence, leaving its one
7193:         /// remaining caller's `"a"` to fold the condition.
7194:         ///
7195:         /// `build_extra_call_site_scan_contexts` builds a bare CFG for
7196:         /// every *absolute* shift-`0` `UpFrame` body, resolved as `"::top"`
7197:         /// — mirroring how a `TclOO` method body is forced global.
7198:         ///
7199:         /// `uplevel N` for any relative (non-`#0`) level stays out of scope:
7200:         /// the target frame's namespace depends on the live call stack,
7201:         /// which single-file static analysis cannot decide — a documented,
7202:         /// permanent approximation.
7203:         #[test]
7204:         fn uplevel_zero_body_resolves_against_global_not_enclosing_namespace() {
7205:             let reg = registry();
7206:             let src = "
7207:                 namespace eval ::foo {
7208:                     proc helper {mode} {
7209:                         if {$mode eq \"WRONG\"} { set r 1 } else { set r 2 }
7210:                     }
7211:                     proc runIt {} {
7212:                         uplevel #0 { helper b }
7213:                     }
7214:                 }
7215:                 proc helper {mode} {
7216:                     if {$mode eq \"a\"} { set r 1 } else { set r 2 }
7217:                 }
7218:                 helper a
7219:                 ::foo::runIt
7220:             ";
7221:             let cu = CompilationUnit::build_for(src, &reg, false);
7222:             let global_helper = fixture_id_if_present(&cu.procedures, "::helper")
7223:                 .and_then(|id| cu.procedures.get(&id))
7224:                 .expect("::helper analysed");
7225:             let ns_helper = fixture_id_if_present(&cu.procedures, "::foo::helper")
7226:                 .and_then(|id| cu.procedures.get(&id))
7227:                 .expect("::foo::helper analysed");
7228:             assert!(
7229:                 !knows_condition_mentioning(global_helper, "mode"),
7230:                 "::helper is called with both \"a\" and \"b\" (uplevel #0, once correctly \
7231:                  resolved to global): {:?}",
7232:                 global_helper.sccp.constant_branches,
7233:             );
7234:             assert!(
7235:                 !knows_condition_mentioning(ns_helper, "mode"),
7236:                 "::foo::helper is never actually called by real Tcl semantics: {:?}",
7237:                 ns_helper.sccp.constant_branches,
7238:             );
7239:         }
7240: 
7241:         /// MISCOMPILE regression: `uplevel 0 { … }` is the *relative*
7242:         /// current-frame form and must NOT be treated as the absolute global
7243:         /// form. Encoding `#0` and `0` as the same `frame_shift == 0` resolves
7244:         /// this body against `"::top"`, losing `::foo::helper`'s only varying
7245:         /// call site — folding a branch that real Tcl reaches both ways.
7246:         ///
7247:         /// On tclsh8.6 and tclsh9.0: inside
7248:         /// `::foo::runIt`, `uplevel #0 { helper b }` prints `GLOBAL helper`
7249:         /// while `uplevel 0 { helper c }` prints `FOO helper`.
7250:         #[test]
7251:         fn uplevel_bare_zero_body_resolves_against_the_enclosing_namespace() {
7252:             let reg = registry();
7253:             let src = "
7254:                 namespace eval ::foo {
7255:                     proc helper {mode} {
7256:                         if {$mode eq \"a\"} { set r 1 } else { set r 2 }
7257:                     }
7258:                     proc runIt {} {
7259:                         uplevel 0 { helper b }
7260:                     }
7261:                 }
7262:                 ::foo::helper a
7263:                 ::foo::runIt
7264:             ";
7265:             let cu = CompilationUnit::build_for(src, &reg, false);
7266:             let helper = fixture_id_if_present(&cu.procedures, "::foo::helper")
7267:                 .and_then(|id| cu.procedures.get(&id))
7268:                 .expect("::foo::helper analysed");
7269:             assert!(
7270:                 !knows_condition_mentioning(helper, "mode"),
7271:                 "`uplevel 0` runs in the current frame, so ::foo::helper sees both \
7272:                  \"a\" (direct) and \"b\" (the uplevel body): {:?}",
7273:                 helper.sccp.constant_branches,
7274:             );
7275:         }
7276: 
7277:         /// Approximation pin: a *relative* `uplevel N { … }`
7278:         /// keeps resolving against the enclosing unit's own namespace. The
7279:         /// target frame's namespace depends on the live call stack, so this
7280:         /// is a deliberate, permanent approximation — but it must stay an
7281:         /// approximation that still *counts* the call site, not one that
7282:         /// drops it. `::foo::helper` here sees both `"a"` and `"b"`.
7283:         #[test]
7284:         fn uplevel_relative_body_keeps_the_enclosing_units_namespace() {
7285:             let reg = registry();
7286:             let src = "
7287:                 namespace eval ::foo {
7288:                     proc helper {mode} {
7289:                         if {$mode eq \"a\"} { set r 1 } else { set r 2 }
7290:                     }
7291:                     proc runIt {} {
7292:                         uplevel 1 { helper b }
7293:                     }
7294:                 }
7295:                 ::foo::helper a
7296:                 ::foo::runIt
7297:             ";
7298:             let cu = CompilationUnit::build_for(src, &reg, false);
7299:             let helper = fixture_id_if_present(&cu.procedures, "::foo::helper")
7300:                 .and_then(|id| cu.procedures.get(&id))
7301:                 .expect("::foo::helper analysed");
7302:             assert!(
7303:                 !knows_condition_mentioning(helper, "mode"),
7304:                 "::foo::helper sees both \"a\" (direct) and \"b\" (the relative uplevel \
7305:                  body, approximated to the enclosing namespace): {:?}",
7306:                 helper.sccp.constant_branches,
7307:             );
7308:         }
7309: 
7310:         /// FN guard for the `Traits::DEFINES_PROCEDURE` body-recursion skip
7311:         /// a definition body is not re-walked from the
7312:         /// definition site, so its call sites must still arrive through the
7313:         /// defined procedure's *own* CFG. A conditionally-defined proc is
7314:         /// the shape most at risk — its `proc` call is not a plain top-level
7315:         /// statement.
7316:         #[test]
7317:         fn conditionally_defined_proc_body_call_sites_are_still_counted() {
7318:             let reg = registry();
7319:             let src = "
7320:                 proc helper {mode} {
7321:                     if {$mode eq \"a\"} { set r 1 } else { set r 2 }
7322:                 }
7323:                 if {[info exists ::env(X)]} {
7324:                     proc runIt {} { helper b }
7325:                 }
7326:                 helper a
7327:                 runIt
7328:             ";
7329:             let cu = CompilationUnit::build_for(src, &reg, false);
7330:             let helper = fixture_id_if_present(&cu.procedures, "::helper")
7331:                 .and_then(|id| cu.procedures.get(&id))
7332:                 .expect("::helper analysed");
7333:             assert!(
7334:                 !knows_condition_mentioning(helper, "mode"),
7335:                 "::helper is called with both \"a\" and \"b\" (the conditionally-defined \
7336:                  runIt's body): {:?}",
7337:                 helper.sccp.constant_branches,
7338:             );
7339:         }
7340: 
7341:         /// FP guard: `namespace eval ::other { … }`
7342:         /// runs its body in `::other`, never the enclosing proc's own
7343:         /// namespace — tclsh8.6-confirmed live: a bare call inside such a
7344:         /// block, nested arbitrarily deep inside an unrelated proc, still
7345:         /// resolves against `::other`. Before threading the block's real
7346:         /// target namespace into its body-unit qname
7347:         /// (`register_body_unit`/`lower_namespace_eval`), every
7348:         /// `namespace eval` body unit's qname reduced to the *global*
7349:         /// namespace regardless of its actual target, so this call would
7350:         /// have resolved (or misattributed) against global instead of
7351:         /// `::other`.
7352:         #[test]
7353:         fn namespace_eval_body_nested_in_a_proc_resolves_against_its_own_namespace() {
7354:             let reg = registry();
7355:             let src = "
7356:                 namespace eval ::other {
7357:                     proc helper {mode} {
7358:                         if {$mode eq \"a\"} { set r 1 } else { set r 2 }
7359:                     }
7360:                 }
7361:                 proc runIt {} {
7362:                     namespace eval ::other { helper b }
7363:                 }
7364:                 ::other::helper a
7365:                 runIt
7366:             ";
7367:             let cu = CompilationUnit::build_for(src, &reg, false);
7368:             let helper = fixture_id_if_present(&cu.procedures, "::other::helper")
7369:                 .and_then(|id| cu.procedures.get(&id))
7370:                 .expect("::other::helper analysed");
7371:             assert!(
7372:                 !knows_condition_mentioning(helper, "mode"),
7373:                 "::other::helper is called with both \"a\" (direct) and \"b\" (via the \
7374:                  namespace eval block nested inside runIt): {:?}",
7375:                 helper.sccp.constant_branches,
7376:             );
7377:         }
7378: 
7379:         /// Namespace-resolution regression: `apply {params body
7380:         /// ns}`'s third element names the namespace the body runs in, so a
7381:         /// bare command word inside it resolves against *that* namespace.
7382:         /// `lower_apply` computed the right `body_ns` and lowered the body
7383:         /// against it, then registered the body unit under the bare `apply`
7384:         /// marker — whose qname puts it in the global namespace. The call
7385:         /// site was attributed to a `::helper` that does not exist and
7386:         /// vanished from `::foo::helper`'s evidence, folding a branch real
7387:         /// Tcl reaches both ways.
7388:         ///
7389:         /// On tclsh8.6 and tclsh9.0: inside `::foo::runIt`,
7390:         /// `apply {{x} { helper $x } ::foo} b`
7391:         /// returns 2 — the `else` arm of `::foo::helper` — while the direct
7392:         /// `::foo::helper a` returns 1.
7393:         #[test]
7394:         fn apply_with_a_namespace_element_resolves_the_body_against_it() {
7395:             let reg = registry();
7396:             let src = "
7397:                 namespace eval ::foo {
7398:                     proc helper {mode} {
7399:                         if {$mode eq \"a\"} { set r 1 } else { set r 2 }
7400:                     }
7401:                     proc runIt {} {
7402:                         apply {{x} { helper $x } ::foo} b
7403:                     }
7404:                 }
7405:                 ::foo::helper a
7406:                 ::foo::runIt
7407:             ";
7408:             let cu = CompilationUnit::build_for(src, &reg, false);
7409:             let helper = fixture_id_if_present(&cu.procedures, "::foo::helper")
7410:                 .and_then(|id| cu.procedures.get(&id))
7411:                 .expect("::foo::helper analysed");
7412:             assert!(
7413:                 !knows_condition_mentioning(helper, "mode"),
7414:                 "::foo::helper is called with both \"a\" (direct) and \"b\" (through the \
7415:                  ::foo-pinned lambda): {:?}",
7416:                 helper.sccp.constant_branches,
7417:             );
7418:         }
7419: 
7420:         /// The two-element form is unchanged: with no namespace element,
7421:         /// `apply` runs the body in the *global* namespace, not the caller's
7422:         /// (Tcl `apply` manual). So the enclosing namespace's `helper` is
7423:         /// genuinely never called from the lambda and keeps its fold.
7424:         #[test]
7425:         fn apply_without_a_namespace_element_still_resolves_globally() {
7426:             let reg = registry();
7427:             let src = "
7428:                 proc ::helper {x} {return $x}
7429:                 namespace eval ::foo {
7430:                     proc helper {mode} {
7431:                         if {$mode eq \"a\"} { set r 1 } else { set r 2 }
7432:                     }
7433:                     proc runIt {} {
7434:                         apply {{x} { helper $x }} b
7435:                     }
7436:                 }
7437:                 ::foo::helper a
7438:                 ::foo::runIt
7439:             ";
7440:             let cu = CompilationUnit::build_for(src, &reg, false);
7441:             let helper = fixture_id_if_present(&cu.procedures, "::foo::helper")
7442:                 .and_then(|id| cu.procedures.get(&id))
7443:                 .expect("::foo::helper analysed");
7444:             assert!(
7445:                 knows_condition_mentioning(helper, "mode"),
7446:                 "an unpinned lambda body resolves globally, so ::foo::helper only ever \
7447:                  sees the direct \"a\": {:?}",
7448:                 helper.sccp.constant_branches,
7449:             );
7450:         }
7451: 
7452:         /// Test diagnostic branch knowledge without donating caller contents
7453:         /// to an executable replacement of retained native object coercions.
7454:         /// Build `src` under a **closed world**: an empty cross-file evidence
7455:         /// set, which is the host asserting "I enumerated the project and no
7456:         /// other file calls into this one" — the semantics for a file that is
7457:         /// genuinely the whole program.
7458:         fn build_closed_world(src: &str, reg: &CommandRegistry) -> CompilationUnit {
7459:             let empty = crate::unit_scope::CallSiteEvidence::default();
7460:             CompilationUnit::build_with_options(
7461:                 src,
7462:                 UnitBuildOptions {
7463:                     registry: reg,
7464:                     defer_top_level: false,
7465:                     config: tcl_lexer::LexerConfig::default(),
7466:                     dialect: None,
7467:                     external_call_sites: Some(&empty),
7468:                     declared_commands: None,
7469:                 },
7470:             )
7471:         }
7472: 
7473:         fn knows_condition_mentioning(fu: &FunctionUnit, needle: &str) -> bool {
7474:             fu.diagnostic_value_facts()
7475:                 .constant_branches()
7476:                 .iter()
7477:                 .any(|branch| branch.condition.contains(needle))
7478:         }
7479: 
7480:         #[test]
7481:         fn caller_contents_do_not_license_erasing_retained_parameter_coercions() {
7482:             let reg = registry();
7483:             let source = "proc helper {n} {if {$n + 0 == 7} {set result yes} else {set result no}}; helper 007";
7484:             let unit = CompilationUnit::build_for(source, &reg, false);
7485:             let function = fixture_id_if_present(&unit.procedures, "::helper")
7486:                 .and_then(|id| unit.procedures.get(&id))
7487:                 .expect("helper analysed");
7488:             assert!(
7489:                 knows_condition_mentioning(function, "n"),
7490:                 "caller_scope={:?} names={:?} preparations={} branch_bindings={} semantic_expressions={}",
7491:                 unit.caller_scope,
7492:                 function.ssa.var_names(),
7493:                 function.cfg.expression_preparations.len(),
7494:                 function.cfg.condition_binding_sites.len(),
7495:                 function
7496:                     .semantic_values()
7497:                     .map_or(0, |facts| facts.expression_iter().count())
7498:             );
7499:             assert_eq!(
7500:                 function.sccp.constant_branches,
7501:                 [] as [crate::sccp::ConstantBranch; 0]
7502:             );
7503:             let symbol = function.ssa.var_symbol("n").expect("retained formal slot");
7504:             assert_eq!(
7505:                 function.semantic_values().unwrap().contents((symbol, 0)),
7506:                 Some(&crate::analyses::LatticeValue::Const(
7507:                     crate::analyses::ConstValue::String("007".to_owned())
7508:                 ))
7509:             );
7510:         }
7511: 
7512:         /// FN: a proc declared inside a `namespace eval` block recurses into
7513:         /// itself by its *bare* name. A resolver that only tries
7514:         /// global-qualified spellings of the command word can never match the
7515:         /// proc's namespaced qualified name — the recursive call (whose
7516:         /// argument necessarily varies call to call) vanishes from the
7517:         /// call-site scan, leaving only the one external caller's literal `0`
7518:         /// visible. `params_constants_from_call_sites` would then seed `count`
7519:         /// as the compile-time constant `0`, folding the always-alternating
7520:         /// `$count & 1` parity check to a fixed `false` — exactly the
7521:         /// reported false positive.
7522:         #[test]
7523:         fn namespaced_recursive_proc_parity_check_is_not_constant_folded() {
7524:             let reg = registry();
7525:             let src = "
7526:                 namespace eval ::graph {
7527:                     proc dfs {count} {
7528:                         if {$count & 1} {
7529:                             set parity odd
7530:                         } else {
7531:                             set parity even
7532:                         }
7533:                         if {$count < 3} {
7534:                             dfs [expr {$count + 1}]
7535:                         }
7536:                     }
7537:                 }
7538:                 ::graph::dfs 0
7539:             ";
7540:             let cu = CompilationUnit::build_for(src, &reg, false);
7541:             let dfs = fixture_id_if_present(&cu.procedures, "::graph::dfs")
7542:                 .and_then(|id| cu.procedures.get(&id))
7543:                 .expect("dfs analysed");
7544:             assert!(
7545:                 !knows_condition_mentioning(dfs, "count"),
7546:                 "recursive parity check on `count` must not fold to a constant: {:?}",
7547:                 dfs.sccp.constant_branches,
7548:             );
7549:         }
7550: 
7551:         /// TN control: the same shape at the *top level* (no namespace),
7552:         /// where a bare recursive call resolves to the right un-namespaced
7553:         /// qualified name on its own, must stay sound.
7554:         #[test]
7555:         fn top_level_recursive_proc_parity_check_is_not_constant_folded() {
7556:             let reg = registry();
7557:             let src = "
7558:                 proc count_up {n} {
7559:                     if {$n & 1} { set p odd } else { set p even }
7560:                     if {$n < 3} { count_up [expr {$n + 1}] }
7561:                 }
7562:                 count_up 0
7563:             ";
7564:             let cu = CompilationUnit::build_for(src, &reg, false);
7565:             let f = fixture_id_if_present(&cu.procedures, "::count_up")
7566:                 .and_then(|id| cu.procedures.get(&id))
7567:                 .expect("count_up analysed");
7568:             assert!(
7569:                 !knows_condition_mentioning(f, "n"),
7570:                 "recursive parity check on `n` must not fold to a constant: {:?}",
7571:                 f.sccp.constant_branches,
7572:             );
7573:         }
7574: 
7575:         /// TP control: the interprocedural seed must still fire for a
7576:         /// genuinely proc-call-invariant parameter — two callers (one via a
7577:         /// same-namespace bare call, proving the namespace-aware resolver
7578:         /// still positively resolves, not just negatively declines) passing
7579:         /// the identical literal.
7580:         #[test]
7581:         fn two_same_namespace_callers_with_uniform_literal_still_folds() {
7582:             let reg = registry();
7583:             let src = "
7584:                 namespace eval ::a {
7585:                     proc go {mode} {
7586:                         if {$mode eq \"prod\"} { set r 1 } else { set r 2 }
7587:                     }
7588:                     proc caller1 {} { go prod }
7589:                     proc caller2 {} { go prod }
7590:                 }
7591:             ";
7592:             let cu = CompilationUnit::build_for(src, &reg, false);
7593:             let go = fixture_id_if_present(&cu.procedures, "::a::go")
7594:                 .and_then(|id| cu.procedures.get(&id))
7595:                 .expect("go analysed");
7596:             assert!(
7597:                 knows_condition_mentioning(go, "mode"),
7598:                 "two same-namespace callers passing the identical literal should still fold: caller_scope={:?}, contents={:?}, preparations={}, condition_bindings={}",
7599:                 cu.caller_scope,
7600:                 go.semantic_values()
7601:                     .map(|facts| facts.contents_iter().collect::<Vec<_>>()),
7602:                 go.cfg.expression_preparations.len(),
7603:                 go.cfg.condition_binding_sites.len(),
7604:             );
7605:             assert!(
7606:                 go.sccp.constant_branches.is_empty(),
7607:                 "logical incoming contents do not prove erasure of native operand conversion",
7608:             );
7609:         }
7610: 
7611:         /// FP guard: two same-leaf-name procs in different namespaces must
7612:         /// never be conflated by a bare same-namespace call — `::a::go`'s
7613:         /// only caller passes `"same"`; `::b::go`'s only caller passes
7614:         /// `"different"`. Each must fold to *its own* literal, not the
7615:         /// other's — a namespace-blind resolver matches neither bare call to a
7616:         /// real proc.
7617:         #[test]
7618:         fn sibling_namespace_procs_with_same_leaf_name_are_not_conflated() {
7619:             let reg = registry();
7620:             let src = "
7621:                 namespace eval ::a {
7622:                     proc go {mode} {
7623:                         if {$mode eq \"same\"} { set r 1 } else { set r 2 }
7624:                     }
7625:                     proc caller {} { go same }
7626:                 }
7627:                 namespace eval ::b {
7628:                     proc go {mode} {
7629:                         if {$mode eq \"same\"} { set r 1 } else { set r 2 }
7630:                     }
7631:                 }
7632:                 ::b::go different
7633:             ";
7634:             let cu = CompilationUnit::build_for(src, &reg, false);
7635:             let a_go = fixture_id_if_present(&cu.procedures, "::a::go")
7636:                 .and_then(|id| cu.procedures.get(&id))
7637:                 .expect("::a::go analysed");
7638:             let b_go = fixture_id_if_present(&cu.procedures, "::b::go")
7639:                 .and_then(|id| cu.procedures.get(&id))
7640:                 .expect("::b::go analysed");
7641:             assert!(
7642:                 knows_condition_mentioning(a_go, "mode"),
7643:                 "::a::go's sole caller passes a uniform literal, should fold: {:?}",
7644:                 a_go.sccp.constant_branches,
7645:             );
7646:             assert!(
7647:                 b_go.sccp
7648:                     .constant_branches
7649:                     .iter()
7650:                     .any(|b| b.condition.contains("mode") && !b.value),
7651:                 "::b::go's sole caller passes \"different\", condition should fold false: {:?}",
7652:                 b_go.sccp.constant_branches,
7653:             );
7654:         }
7655: 
7656:         /// FP guard: a `rename` that could redirect a *different* command
7657:         /// onto the callee's own name must disqualify the seed, even though
7658:         /// every call site this scan can see (all made before the rename,
7659:         /// textually) passes a uniform literal — `trusts_proc_binding` is
7660:         /// flow-insensitive/whole-module by design (matching the identical
7661:         /// gate already trusted for the optimiser's O103 proc-call fold), so
7662:         /// it can't assume the calls happen before the rename takes effect.
7663:         #[test]
7664:         fn rename_onto_callee_name_disqualifies_call_site_seed() {
7665:             let reg = registry();
7666:             let src = "
7667:                 proc helper {mode} {
7668:                     if {$mode eq \"prod\"} { set x 1 } else { set x 2 }
7669:                 }
7670:                 proc other {mode} {
7671:                     if {$mode eq \"prod\"} { set y 3 } else { set y 4 }
7672:                 }
7673:                 helper prod
7674:                 helper prod
7675:                 rename other helper
7676:             ";
7677:             let cu = CompilationUnit::build_for(src, &reg, false);
7678:             let helper = fixture_id_if_present(&cu.procedures, "::helper")
7679:                 .and_then(|id| cu.procedures.get(&id))
7680:                 .expect("helper analysed");
7681:             assert!(
7682:                 !knows_condition_mentioning(helper, "mode"),
7683:                 "a callee whose name is later rebound must not fold on stale call-site evidence: {:?}",
7684:                 helper.sccp.constant_branches,
7685:             );
7686:         }
7687: 
7688:         /// TN control and documented scope boundary: a dynamic (non-literal)
7689:         /// call-site head elsewhere in the module is simply unresolvable —
7690:         /// it contributes no evidence for or against any proc's params,
7691:         /// exactly like any other call this scan can't attribute to a
7692:         /// specific callee. `helper`'s own two uniform-literal callers still
7693:         /// fold. Closing the residual "the dynamic call might secretly
7694:         /// target `helper` too" gap would need a value-set fact for `$cmd`
7695:         /// this pass runs too early in the pipeline to have (it produces
7696:         /// the very SCCP seed such a fact would depend on) — a pre-existing
7697:         /// limitation of this call-site scan, not a regression.
7698:         #[test]
7699:         fn dynamic_dispatch_elsewhere_does_not_disqualify_an_unrelated_seed() {
7700:             let reg = registry();
7701:             let src = "
7702:                 proc helper {mode} {
7703:                     if {$mode eq \"prod\"} { set x 1 } else { set x 2 }
7704:                 }
7705:                 helper prod
7706:                 helper prod
7707:                 set cmd helper
7708:                 $cmd prod
7709:             ";
7710:             let cu = CompilationUnit::build_for(src, &reg, false);
7711:             let helper = fixture_id_if_present(&cu.procedures, "::helper")
7712:                 .and_then(|id| cu.procedures.get(&id))
7713:                 .expect("helper analysed");
7714:             assert!(
7715:                 knows_condition_mentioning(helper, "mode"),
7716:                 "an unrelated dynamic call site must not disqualify helper's own uniform-literal seed: {:?}",
7717:                 helper.sccp.constant_branches,
7718:             );
7719:         }
7720: 
7721:         /// FN regression: a call site embedded inside a `catch { … }` body is
7722:         /// a real caller with a differing argument, but `catch`'s body is an
7723:         /// `ArgRole::Body` argument of the *builtin* `catch` — never a user
7724:         /// proc — so a flat, one-level call-site walk resolves `catch`,
7725:         /// finds no matching proc, and moves on without ever noticing the
7726:         /// `isEven 4` sitting inside it. Before recursing into `ArgRole::Body`
7727:         /// arguments, this scan only ever saw the one external `isEven 3`
7728:         /// call, so it wrongly seeded `n` as the constant `3`.
7729:         #[test]
7730:         fn call_site_inside_catch_body_is_not_missed() {
7731:             let reg = registry();
7732:             let src = "
7733:                 proc is_even {n} {
7734:                     if {$n % 2 == 0} { return 1 } else { return 0 }
7735:                 }
7736:                 proc main {} {
7737:                     is_even 3
7738:                     catch { is_even 4 }
7739:                 }
7740:             ";
7741:             let cu = CompilationUnit::build_for(src, &reg, false);
7742:             let f = fixture_id_if_present(&cu.procedures, "::is_even")
7743:                 .and_then(|id| cu.procedures.get(&id))
7744:                 .expect("is_even analysed");
7745:             assert!(
7746:                 !knows_condition_mentioning(f, "n"),
7747:                 "is_even is called with both 3 and 4 (the latter inside `catch`); must not fold: {:?}",
7748:                 f.sccp.constant_branches,
7749:             );
7750:         }
7751: 
7752:         /// FN regression, `uplevel` flavour: a literal `uplevel {…}` body is
7753:         /// an `ArgRole::Body` argument of the builtin `uplevel`, exactly like
7754:         /// `catch`'s.
7755:         #[test]
7756:         fn call_site_inside_uplevel_body_is_not_missed() {
7757:             let reg = registry();
7758:             let src = "
7759:                 proc is_even {n} {
7760:                     if {$n % 2 == 0} { return 1 } else { return 0 }
7761:                 }
7762:                 proc main {} {
7763:                     is_even 3
7764:                     uplevel 1 { is_even 4 }
7765:                 }
7766:             ";
7767:             let cu = CompilationUnit::build_for(src, &reg, false);
7768:             let f = fixture_id_if_present(&cu.procedures, "::is_even")
7769:                 .and_then(|id| cu.procedures.get(&id))
7770:                 .expect("is_even analysed");
7771:             assert!(
7772:                 !knows_condition_mentioning(f, "n"),
7773:                 "is_even is called with both 3 and 4 (the latter inside `uplevel`); must not fold: {:?}",
7774:                 f.sccp.constant_branches,
7775:             );
7776:         }
7777: 
7778:         /// TN control: an unrelated call inside a `catch` body must not
7779:         /// disqualify a *different*, genuinely call-site-invariant proc's
7780:         /// seed — the recursive Body-arg scan must attribute evidence to the
7781:         /// right callee, not blanket-disqualify everything the way the
7782:         /// (reverted) dynamic-dispatch wildcard did.
7783:         #[test]
7784:         fn unrelated_catch_body_does_not_disqualify_a_different_proc() {
7785:             let reg = registry();
7786:             let src = "
7787:                 proc helper {mode} {
7788:                     if {$mode eq \"prod\"} { set x 1 } else { set x 2 }
7789:                 }
7790:                 proc noisy {} {
7791:                     catch { error expected_failure }
7792:                 }
7793:                 helper prod
7794:                 helper prod
7795:                 noisy
7796:             ";
7797:             let cu = CompilationUnit::build_for(src, &reg, false);
7798:             let helper = fixture_id_if_present(&cu.procedures, "::helper")
7799:                 .and_then(|id| cu.procedures.get(&id))
7800:                 .expect("helper analysed");
7801:             assert!(
7802:                 knows_condition_mentioning(helper, "mode"),
7803:                 "an unrelated catch body must not disqualify helper's own uniform-literal seed: {:?}",
7804:                 helper.sccp.constant_branches,
7805:             );
7806:         }
7807: 
7808:         #[test]
7809:         fn caught_unresolved_command_keeps_its_callback_mutation_boundary() {
7810:             let reg = registry();
7811:             let src = "
7812:                 proc helper {mode} {
7813:                     if {$mode eq \"prod\"} { set x 1 } else { set x 2 }
7814:                 }
7815:                 proc noisy {} {catch {unresolved_command}}
7816:                 helper prod
7817:                 noisy
7818:             ";
7819:             let cu = CompilationUnit::build_for(src, &reg, false);
7820:             let helper = fixture_id_if_present(&cu.procedures, "::helper")
7821:                 .and_then(|id| cu.procedures.get(&id))
7822:                 .expect("helper analysed");
7823:             assert!(!knows_condition_mentioning(helper, "mode"));
7824:             assert_eq!(
7825:                 helper.sccp.constant_branches,
7826:                 [] as [crate::sccp::ConstantBranch; 0]
7827:             );
7828:         }
7829: 
7830:         /// FP guard: a `package provide` file may export procs another file
7831:         /// calls with a different literal — this (single-file) compilation
7832:         /// unit can never see that caller, so it must never seed from the
7833:         /// call sites it happens to see locally.
7834:         #[test]
7835:         fn package_provide_file_disqualifies_every_seed() {
7836:             let reg = registry();
7837:             let src = "
7838:                 package provide mylib 1.0
7839:                 proc helper {mode} {
7840:                     if {$mode eq \"prod\"} { set x 1 } else { set x 2 }
7841:                 }
7842:                 helper prod
7843:                 helper prod
7844:             ";
7845:             let cu = CompilationUnit::build_for(src, &reg, false);
7846:             let helper = fixture_id_if_present(&cu.procedures, "::helper")
7847:                 .and_then(|id| cu.procedures.get(&id))
7848:                 .expect("helper analysed");
7849:             assert!(
7850:                 !knows_condition_mentioning(helper, "mode"),
7851:                 "a package-providing file must not seed from locally-visible call sites: {:?}",
7852:                 helper.sccp.constant_branches,
7853:             );
7854:         }
7855: 
7856:         /// TN control: a plain script with no `package provide` keeps
7857:         /// folding — the guard above must be scoped to the specific
7858:         /// evidence (`package provide` presence), not silently disable the
7859:         /// whole mechanism.
7860:         #[test]
7861:         fn non_package_file_is_unaffected_by_package_provide_guard() {
7862:             let reg = registry();
7863:             let src = "
7864:                 proc helper {mode} {
7865:                     if {$mode eq \"prod\"} { set x 1 } else { set x 2 }
7866:                 }
7867:                 helper prod
7868:                 helper prod
7869:             ";
7870:             let cu = CompilationUnit::build_for(src, &reg, false);
7871:             let helper = fixture_id_if_present(&cu.procedures, "::helper")
7872:                 .and_then(|id| cu.procedures.get(&id))
7873:                 .expect("helper analysed");
7874:             assert!(
7875:                 knows_condition_mentioning(helper, "mode"),
7876:                 "no package-provide in this file, seed should still fold: {:?}",
7877:                 helper.sccp.constant_branches,
7878:             );
7879:         }
7880: 
7881:         /// FP guard: `package provide` merely *mentioned* in a comment must
7882:         /// not disable the interprocedural seed — the guard checks the lowered
7883:         /// IR for a real, resolved invocation, not a raw-text substring match
7884:         /// over the whole file.
7885:         #[test]
7886:         fn package_provide_mentioned_only_in_a_comment_does_not_disqualify() {
7887:             let reg = registry();
7888:             let src = "
7889:                 # this file does not package provide anything itself
7890:                 proc helper {mode} {
7891:                     if {$mode eq \"prod\"} { set x 1 } else { set x 2 }
7892:                 }
7893:                 helper prod
7894:                 helper prod
7895:             ";
7896:             let cu = CompilationUnit::build_for(src, &reg, false);
7897:             let helper = fixture_id_if_present(&cu.procedures, "::helper")
7898:                 .and_then(|id| cu.procedures.get(&id))
7899:                 .expect("helper analysed");
7900:             assert!(
7901:                 knows_condition_mentioning(helper, "mode"),
7902:                 "a comment merely mentioning the phrase must not disqualify: {:?}",
7903:                 helper.sccp.constant_branches,
7904:             );
7905:         }
7906: 
7907:         /// FN guard: a real `package provide` invocation must still
7908:         /// disqualify the seed even when it is spelled with unusual
7909:         /// whitespace or fully namespace-qualified — cases a
7910:         /// `source.contains("package provide")` substring check would miss.
7911:         #[test]
7912:         fn package_provide_with_unusual_spelling_still_disqualifies() {
7913:             let reg = registry();
7914:             let src = "
7915:                 ::package\tprovide mylib 1.0
7916:                 proc helper {mode} {
7917:                     if {$mode eq \"prod\"} { set x 1 } else { set x 2 }
7918:                 }
7919:                 helper prod
7920:                 helper prod
7921:             ";
7922:             let cu = CompilationUnit::build_for(src, &reg, false);
7923:             let helper = fixture_id_if_present(&cu.procedures, "::helper")
7924:                 .and_then(|id| cu.procedures.get(&id))
7925:                 .expect("helper analysed");
7926:             assert!(
7927:                 !knows_condition_mentioning(helper, "mode"),
7928:                 "a real (if oddly-spelled) package provide must still disqualify: {:?}",
7929:                 helper.sccp.constant_branches,
7930:             );
7931:         }
7932: 
7933:         /// Two-file repro: `lib.tcl` has **no** `package provide`, so the
7934:         /// provide guard never fires; its only two visible callers both pass
7935:         /// `"prod"`, so seeding `mode` as that constant folds the condition —
7936:         /// even though `main.tcl` `source`s it and calls `helper dev`.
7937:         mod cross_file {
7938:             use super::*;
7939:             use crate::unit_scope::CallSiteEvidence;
7940: 
7941:             /// A plain library file, no `package provide`, whose in-file
7942:             /// callers agree.
7943:             const LIB: &str = "
7944:                 proc helper {mode} {
7945:                     if {$mode eq \"prod\"} { set r 1 } else { set r 2 }
7946:                 }
7947:                 helper prod
7948:                 helper prod
7949:             ";
7950: 
7951:             /// Sources the library and calls its proc with a literal
7952:             /// `lib.tcl` never sees.
7953:             const MAIN: &str = "
7954:                 source lib.tcl
7955:                 helper dev
7956:             ";
7957: 
7958:             /// Cross-file evidence a host builds from `other`, resolved
7959:             /// against the procedures `LIB` declares.
7960:             fn library_entry() -> crate::command_binding::SourceAnalysisEntry {
7961:                 let profile = tcl_dialect::DialectProfile::find("tcl9.0").expect("native profile");
7962:                 crate::command_binding::SourceAnalysisEntry {
7963:                     invocation_dialect: Some(tcl_registry::InvocationDialect::of_profile(profile)),
7964:                     native_compilation: crate::environment_ingress::authoring_native_compilation(),
7965:                     trusted_source_modules: vec![
7966:                         crate::command_binding::TrustedSourceModuleLoader::new(
7967:                             tcl_dialect::model::Family::Tcl,
7968:                             "lib.tcl".into(),
7969:                             None,
7970:                             "workspace/library/revision-one".into(),
7971:                             &Arc::from(LIB),
7972:                         ),
7973:                     ],
7974:                     ..crate::command_binding::SourceAnalysisEntry::default()
7975:                 }
7976:             }
7977: 
7978:             fn evidence_from(other: &str, reg: &CommandRegistry) -> CallSiteEvidence {
7979:                 let known: HashSet<String> = ["::helper".to_owned()].into_iter().collect();
7980:                 let profile = tcl_dialect::DialectProfile::find("tcl9.0").expect("native profile");
7981:                 let entry = library_entry();
7982:                 // The driver actually loads the library before this caller file.
7983:                 // MAIN already performs that read at its authored source site.
7984:                 let loaded;
7985:                 let source = if other == MAIN || other.starts_with("source lib.tcl") {
7986:                     other
7987:                 } else {
7988:                     loaded = format!("source lib.tcl\n{other}");
7989:                     &loaded
7990:                 };
7991:                 let context = Arc::new(
7992:                     crate::environment_ingress::context_for_profile(profile)
7993:                         .with_command_store(reg.snapshot().shared_registry()),
7994:                 );
7995:                 let input = crate::analyser::ResolvedAnalysisInput::new(
7996:                     profile,
7997:                     profile,
7998:                     context,
7999:                     tcl_lexer::LexerConfig::from_grammar(profile.grammar),
8000:                 );
8001:                 crate::unit_scope::scan_source_call_sites_with_source_input(
8002:                     source,
8003:                     None,
8004:                     &known,
8005:                     &[],
8006:                     &input,
8007:                     &entry,
8008:                 )
8009:             }
8010: 
8011:             fn build_with_evidence(
8012:                 src: &str,
8013:                 reg: &CommandRegistry,
8014:                 evidence: &CallSiteEvidence,
8015:             ) -> CompilationUnit {
8016:                 build_with_source_evidence(src, reg, Some(evidence))
8017:             }
8018: 
8019:             fn build_with_source_evidence(
8020:                 src: &str,
8021:                 reg: &CommandRegistry,
8022:                 evidence: Option<&CallSiteEvidence>,
8023:             ) -> CompilationUnit {
8024:                 let profile = tcl_dialect::DialectProfile::find("tcl9.0").expect("native profile");
8025:                 let context = Arc::new(
8026:                     crate::environment_ingress::context_for_profile(profile)
8027:                         .with_command_store(reg.snapshot().shared_registry()),
8028:                 );
8029:                 CompilationUnit::build_with_context_registry(
8030:                     src,
8031:                     UnitBuildOptions {
8032:                         registry: reg,
8033:                         defer_top_level: false,
8034:                         config: tcl_lexer::LexerConfig::from_grammar(profile.grammar),
8035:                         dialect: Some(profile),
8036:                         external_call_sites: evidence,
8037:                         declared_commands: None,
8038:                     },
8039:                     Some(&library_entry()),
8040:                     context,
8041:                 )
8042:             }
8043: 
8044:             /// FP guard — the reported bug. With `main.tcl`'s `helper dev`
8045:             /// merged in, `mode` has two distinct literals and must not fold.
8046:             #[test]
8047:             fn sourcing_file_with_a_differing_literal_retracts_the_fold() {
8048:                 let reg = registry();
8049:                 let evidence = evidence_from(MAIN, &reg);
8050:                 let cu = build_with_evidence(LIB, &reg, &evidence);
8051:                 let helper = fixture_id_if_present(&cu.procedures, "::helper")
8052:                     .and_then(|id| cu.procedures.get(&id))
8053:                     .expect("helper analysed");
8054:                 assert!(
8055:                     !knows_condition_mentioning(helper, "mode"),
8056:                     "main.tcl calls helper with \"dev\"; lib.tcl must not fold on \"prod\": {:?}",
8057:                     helper.sccp.constant_branches,
8058:                 );
8059:             }
8060: 
8061:             /// The evidence itself, before any lattice: the cross-file scan
8062:             /// must attribute `helper dev` to `::helper` at position 0.
8063:             #[test]
8064:             fn cross_file_scan_attributes_the_call_to_the_library_proc() {
8065:                 let reg = registry();
8066:                 let evidence = evidence_from(MAIN, &reg);
8067:                 let helper = evidence.get("::helper").expect("helper call recorded");
8068:                 assert_eq!(helper.uniform_literal_at(0), Some("dev"));
8069:             }
8070: 
8071:             /// TP control — the mechanism must still fold when the other file
8072:             /// agrees. `main.tcl` passing `prod` too leaves one literal
8073:             /// across the whole project, so the seed is sound and fires.
8074:             #[test]
8075:             fn sourcing_file_agreeing_on_the_literal_still_folds() {
8076:                 let reg = registry();
8077:                 let evidence = evidence_from("source lib.tcl\nhelper prod\n", &reg);
8078:                 let cu = build_with_evidence(LIB, &reg, &evidence);
8079:                 let helper = fixture_id_if_present(&cu.procedures, "::helper")
8080:                     .and_then(|id| cu.procedures.get(&id))
8081:                     .expect("helper analysed");
8082:                 assert!(
8083:                     knows_condition_mentioning(helper, "mode"),
8084:                     "every caller in the project passes \"prod\"; the seed is sound: {:?}",
8085:                     helper.sccp.constant_branches,
8086:                 );
8087:             }
8088: 
8089:             /// TN control — a workspace file that never mentions `helper`
8090:             /// contributes no evidence and must not disturb the fold.
8091:             #[test]
8092:             fn unrelated_workspace_file_contributes_nothing() {
8093:                 let reg = registry();
8094:                 let known = HashSet::from(["::helper".to_owned()]);
8095:                 let evidence = crate::unit_scope::scan_source_call_sites(
8096:                     "proc other {x} { return $x }\nother 1\n",
8097:                     &reg,
8098:                     None,
8099:                     tcl_dialect::DialectProfile::find("tcl9.0").expect("native profile"),
8100:                     &known,
8101:                     &[],
8102:                 );
8103:                 assert!(
8104:                     evidence.get("::helper").is_none(),
8105:                     "an unrelated file supplies no caller of ::helper: {evidence:?}",
8106:                 );
8107:                 let cu = build_with_evidence(LIB, &reg, &evidence);
8108:                 let helper = fixture_id_if_present(&cu.procedures, "::helper")
8109:                     .and_then(|id| cu.procedures.get(&id))
8110:                     .expect("helper analysed");
8111:                 assert!(
8112:                     knows_condition_mentioning(helper, "mode"),
8113:                     "an unrelated file must not retract a sound fold: {:?}",
8114:                     helper.sccp.constant_branches,
8115:                 );
8116:             }
8117: 
8118:             /// FN guard — a cross-file caller reached through a *dynamic*
8119:             /// argument is still a caller. `helper $mode` in `main.tcl`
8120:             /// poisons position 0, so the fold is retracted even though no
8121:             /// second literal was ever written.
8122:             #[test]
8123:             fn cross_file_dynamic_argument_poisons_the_position() {
8124:                 let reg = registry();
8125:                 let evidence = evidence_from("set m dev\nhelper $m\n", &reg);
8126:                 let cu = build_with_evidence(LIB, &reg, &evidence);
8127:                 let helper = fixture_id_if_present(&cu.procedures, "::helper")
8128:                     .and_then(|id| cu.procedures.get(&id))
8129:                     .expect("helper analysed");
8130:                 assert!(
8131:                     !knows_condition_mentioning(helper, "mode"),
8132:                     "a cross-file caller with a non-literal argument must retract the fold: {:?}",
8133:                     helper.sccp.constant_branches,
8134:                 );
8135:             }
8136: 
8137:             /// FN guard — a deferred script reads an unknown value when the
8138:             /// callback runs. Its possible caller cannot inherit the immediate
8139:             /// file's uniform argument. The body role and future frame come
8140:             /// from the selected native descriptor, independently of spelling.
8141:             #[test]
8142:             fn cross_file_command_prefix_callback_poisons_every_position() {
8143:                 let reg = registry();
8144:                 let evidence = evidence_from("after 0 {helper $::runtime_mode}\n", &reg);
8145:                 let cu = build_with_evidence(LIB, &reg, &evidence);
8146:                 let helper = fixture_id_if_present(&cu.procedures, "::helper")
8147:                     .and_then(|id| cu.procedures.get(&id))
8148:                     .expect("helper analysed");
8149:                 assert!(
8150:                     !knows_condition_mentioning(helper, "mode"),
8151:                     "a deferred cross-file callback reads an unknown argument: {:?}",
8152:                     helper.sccp.constant_branches,
8153:                 );
8154:             }
8155: 
8156:             /// FN guard — a cross-file `rename` moves `helper`'s binding, so
8157:             /// a call reaching it need not be one any scan attributed to it.
8158:             /// `command_mutations` only sees the file being compiled, so
8159:             /// without this the rebinding is invisible across files.
8160:             #[test]
8161:             fn cross_file_rename_poisons_the_callee() {
8162:                 let reg = registry();
8163:                 let evidence = evidence_from("rename helper legacy_helper\n", &reg);
8164:                 let cu = build_with_evidence(LIB, &reg, &evidence);
8165:                 let helper = fixture_id_if_present(&cu.procedures, "::helper")
8166:                     .and_then(|id| cu.procedures.get(&id))
8167:                     .expect("helper analysed");
8168:                 assert!(
8169:                     !knows_condition_mentioning(helper, "mode"),
8170:                     "another file renamed helper; its binding has moved: {:?}",
8171:                     helper.sccp.constant_branches,
8172:                 );
8173:             }
8174: 
8175:             /// A `source`ing file is itself a boundary: `lib.tcl` on its own
8176:             /// (no workspace view) has no boundary at all and still folds —
8177:             /// the documented, accepted limit of a standalone single-file
8178:             /// build — but the *sourcing* file's own procs do not, because
8179:             /// `source` declares `LOADS_EXTERNAL_UNIT`.
8180:             #[test]
8181:             fn a_file_that_sources_another_declines_the_seed_on_its_own() {
8182:                 let reg = registry();
8183:                 let src = "
8184:                     source lib.tcl
8185:                     proc local {mode} {
8186:                         if {$mode eq \"prod\"} { set r 1 } else { set r 2 }
8187:                     }
8188:                     local prod
8189:                     local prod
8190:                 ";
8191:                 let cu = build_with_source_evidence(src, &reg, None);
8192:                 let f = fixture_id_if_present(&cu.procedures, "::local")
8193:                     .and_then(|id| cu.procedures.get(&id))
8194:                     .expect("local analysed");
8195:                 assert!(
8196:                     !knows_condition_mentioning(f, "mode"),
8197:                     "the sourced file's script can call ::local with anything: {:?}",
8198:                     f.sccp.constant_branches,
8199:                 );
8200:                 // …and with a workspace view that says otherwise, it folds.
8201:                 let empty = CallSiteEvidence::default();
8202:                 let closed = build_with_evidence(src, &reg, &empty);
8203:                 let f = fixture_id_if_present(&closed.procedures, "::local")
8204:                     .and_then(|id| closed.procedures.get(&id))
8205:                     .expect("local analysed");
8206:                 assert!(
8207:                     knows_condition_mentioning(f, "mode"),
8208:                     "with the project enumerated, the boundary is no longer a blind spot: {:?}",
8209:                     f.sccp.constant_branches,
8210:                 );
8211:             }
8212:         }
8213: 
8214:         /// FN regression pinned at the `LatticeValue` level (not just
8215:         /// "no constant branch"): the seed for a genuinely-recursive
8216:         /// parameter must never even reach `Const` for the parameter's
8217:         /// version-0 lattice entry, confirming the fix operates at the SCCP
8218:         /// seed itself (the deepest layer), not merely suppressing the
8219:         /// downstream diagnostic.
8220:         #[test]
8221:         fn recursive_param_version_zero_is_never_const_in_lattice() {
8222:             let reg = registry();
8223:             let src = "
8224:                 namespace eval ::graph {
8225:                     proc dfs {count} {
8226:                         if {$count & 1} { set p odd } else { set p even }
8227:                         if {$count < 3} { dfs [expr {$count + 1}] }
8228:                     }
8229:                 }
8230:                 ::graph::dfs 0
8231:             ";
8232:             let cu = CompilationUnit::build_for(src, &reg, false);
8233:             let dfs = fixture_id_if_present(&cu.procedures, "::graph::dfs")
8234:                 .and_then(|id| cu.procedures.get(&id))
8235:                 .expect("dfs analysed");
8236:             // Incoming activation alternatives do not manufacture one scalar
8237:             // SSA symbol. If a physical template slot exists, its entry value
8238:             // must still refuse a recursive caller's constant seed.
8239:             let v0 = dfs
8240:                 .ssa
8241:                 .var_symbol("count")
8242:                 .and_then(|sym| dfs.sccp.values.get(&(sym, 0)));
8243:             assert_eq!(
8244:                 dfs.sccp.constant_branches,
8245:                 [] as [crate::sccp::ConstantBranch; 0]
8246:             );
8247:             assert!(
8248:                 cu.caller_scope
8249:                     .call_sites
8250:                     .get("::graph::dfs")
8251:                     .is_some_and(|calls| calls
8252:                         .slots
8253:                         .get(&0)
8254:                         .is_some_and(|slot| slot.unknown || slot.values.len() > 1))
8255:             );
8256:             assert!(
8257:                 !matches!(v0, Some(LatticeValue::Const(_))),
8258:                 "recursive param's version-0 lattice entry must not be Const, got {v0:?}",
8259:             );
8260:         }
8261:     }
8262: }
/* ORIGINAL_SOURCE_RANGE 8264..8290 */
8264: #[cfg(test)]
8265: mod smoke {
8266:     use crate::interprocedural::test_body_identity::fixture_id_if_present;
8267: 
8268:     use tcl_registry::CommandRegistry;
8269: 
8270:     use super::CompilationUnit;
8271: 
8272:     /// The canonical "lex -> parse -> segment -> IR -> CFG -> codegen-ready"
8273:     /// pipeline on one tiny script, exercised through the same top-level
8274:     /// entry point every real caller (analyser, optimiser, explorer) uses.
8275:     #[test]
8276:     fn smoke_compile_canonical_snippet() {
8277:         let registry = CommandRegistry::build_default();
8278:         let src = "proc double {n} { return [expr {$n * 2}] }\nset r [double 21]\n";
8279:         let unit = CompilationUnit::build_for(src, &registry, false);
8280:         assert!(
8281:             fixture_id_if_present(&unit.procedures, "::double").is_some(),
8282:             "expected a lowered ::double procedure, got {:?}",
8283:             unit.procedures.keys().collect::<Vec<_>>()
8284:         );
8285:         assert!(
8286:             !unit.top_level.cfg.blocks.is_empty(),
8287:             "top-level script must lower to a non-empty CFG"
8288:         );
8289:     }
8290: }
/* ORIGINAL_SOURCE_RANGE 8295..8325 */
8295: #[cfg(test)]
8296: mod jim_ingress_tests {
8297: 
8298:     use super::*;
8299: 
8300:     #[test]
8301:     fn a_jim_unit_is_built_as_jim_end_to_end() {
8302:         let registry = CommandRegistry::build_default();
8303:         let unit = CompilationUnit::build_for_dialect("set x 1\n", &registry, false, "jim");
8304:         assert_eq!(
8305:             unit.ir_module.dialect.as_deref(),
8306:             Some("jim"),
8307:             "lowering hands codegen the document's own dialect name"
8308:         );
8309:         // (the unit does not expose its lexer config; the ingress test pins it)
8310:         // And codegen, resolving that name, lands on Jim's grammar.
8311:         let grammar = tcl_dialect::grammar_of_dialect_name(unit.ir_module.dialect.as_deref());
8312:         assert_eq!(grammar.numbers, tcl_dialect::NumberSyntax::Jim080);
8313:         assert_eq!(grammar.list_parse, tcl_dialect::ListParse::Lenient);
8314:     }
8315: 
8316:     /// The alias spellings reach the same place.
8317:     #[test]
8318:     fn jim_aliases_build_the_same_unit() {
8319:         let registry = CommandRegistry::build_default();
8320:         for spelling in ["jimsh", "jimtcl"] {
8321:             let unit = CompilationUnit::build_for_dialect("set x 1\n", &registry, false, spelling);
8322:             assert_eq!(unit.ir_module.dialect.as_deref(), Some("jim"), "{spelling}");
8323:         }
8324:     }
8325: }
/* ORIGINAL_SOURCE_RANGE 8327..8389 */
8327: #[cfg(test)]
8328: mod original_receiver_method_facts_tests {
8329:     use crate::interprocedural::test_body_identity::fixture_id_if_present;
8330: 
8331:     use super::*;
8332: 
8333:     #[test]
8334:     // Implementation contract: naming.variable.original-entered-receiver-body-context
8335:     // docs/design/analysis/name-resolution-proofs/original-entered-receiver-body-context.md
8336:     fn original_method_facts_keep_counted_formals_without_class_label_variable_union() {
8337:         let source = r"oo::class create C {variable state; method m {arg\uD800} {return ${arg\uD800}}}; oo::define C variable later";
8338:         let registry = tcl_registry::model::ingress::static_context_for("tcl8.6").commands();
8339:         let unit = CompilationUnit::build_for_dialect(source, registry, false, "tcl8.6");
8340:         let method = fixture_id_if_present(&unit.ir_module.methods, "::C::m")
8341:             .and_then(|id| unit.ir_module.methods.get(&id))
8342:             .expect("original method");
8343:         assert!(method.body.executed_source.is_some());
8344:         let facts = MethodBodyFacts::from_method(method);
8345:         let formals = facts
8346:             .original_parameters
8347:             .as_ref()
8348:             .expect("exact original ParamList");
8349:         assert_eq!(formals.parameters()[0].name, b"arg\xed\xa0\x80");
8350:         assert!(method.instance_vars.is_empty());
8351:         assert!(facts.instance_vars.is_empty());
8352:         assert!(!facts.known_bound_at_entry().contains("state"));
8353:         assert!(!facts.known_bound_at_entry().contains("later"));
8354:         assert!(facts.original_receiver_context.is_none());
8355:     }
8356: 
8357:     #[test]
8358:     // Implementation contract: naming.variable.original-entered-receiver-body-context
8359:     // docs/design/analysis/name-resolution-proofs/original-entered-receiver-body-context.md
8360:     fn original_source_context_never_inherits_compatibility_instance_or_execution_fields() {
8361:         let registry = tcl_registry::model::ingress::static_context_for("tcl8.6").commands();
8362:         let unit = CompilationUnit::build_for_dialect("set x 1", registry, false, "tcl8.6");
8363:         let mut cfg = unit.top_level.cfg.clone();
8364:         let mut original = cfg
8365:             .command_binding_sites
8366:             .iter()
8367:             .find_map(|site| site.variable_context.as_ref())
8368:             .expect("original point")
8369:             .as_ref()
8370:             .clone();
8371:         assert!(original.execution_name_policy.is_some());
8372:         original.execution = None;
8373:         original.instance_vars.clear();
8374:         original.instance_owner.clear();
8375:         let mut overlay = crate::var_resolve::ResolveContext::default();
8376:         overlay
8377:             .instance_vars
8378:             .insert("compatibility_donor".to_owned());
8379:         overlay.instance_owner = "::WrongProvider".to_owned();
8380:         for site in &mut cfg.command_binding_sites {
8381:             site.variable_context = Some(Arc::new(original.clone()));
8382:         }
8383:         let entry = function_source_entry(&cfg, Some(&overlay));
8384:         assert!(entry.instance_vars.is_empty());
8385:         assert!(entry.instance_owner.is_empty());
8386:         assert_eq!(entry.execution, original.execution);
8387:         assert_eq!(entry.interpreter, original.interpreter);
8388:     }
8389: }
/* ORIGINAL_SOURCE_RANGE 8391..8818 */
8391: #[cfg(test)]
8392: mod conditional_original_body_tests {
8393: 
8394:     use super::*;
8395: 
8396:     fn supplied(
8397:         source: &str,
8398:         dialect: &str,
8399:         config: tcl_lexer::LexerConfig,
8400:     ) -> (CompilationUnit, Arc<tcl_registry::model::ContextRegistry>) {
8401:         let environment = tcl_registry::model::resolve_known_environment(dialect).unwrap();
8402:         let context = environment.default_context_registry();
8403:         let input = crate::analyser::ResolvedAnalysisInput::new(
8404:             environment.analyser_profile(),
8405:             environment.unit_profile(),
8406:             Arc::clone(&context),
8407:             config,
8408:         );
8409:         let unit = CompilationUnit::build_with_analysis_input(
8410:             source,
8411:             UnitBuildOptions {
8412:                 registry: context.commands(),
8413:                 defer_top_level: false,
8414:                 config,
8415:                 dialect: Some(environment.unit_profile()),
8416:                 external_call_sites: None,
8417:                 declared_commands: None,
8418:             },
8419:             None,
8420:             &input,
8421:         );
8422:         (unit, context)
8423:     }
8424: 
8425:     fn side_parent(unit: &CompilationUnit) -> (&FunctionUnit, &crate::ir::CommandTokens) {
8426:         let function = unit
8427:             .procedures
8428:             .values()
8429:             .find(|fu| fu.name.starts_with("::when::"))
8430:             .expect("actual event function");
8431:         let tokens = function
8432:             .cfg
8433:             .blocks
8434:             .values()
8435:             .flat_map(|block| &block.statements)
8436:             .filter_map(|statement| statement.tokens())
8437:             .find(|tokens| {
8438:                 tokens
8439:                     .argv_texts
8440:                     .first()
8441:                     .is_some_and(|head| head == "clientside")
8442:             })
8443:             .expect("original side-switch vector");
8444:         (function, tokens)
8445:     }
8446: 
8447:     #[test]
8448:     fn conditional_original_child_keeps_source_config_namespace_and_has_no_event_grant() {
8449:         // naming.source.original-collection-body-owner
8450:         // docs/design/analysis/name-resolution-proofs/original-collection-body-owner.md
8451:         // Conditional original syntax/CFG only; no BIG-IP entry or worker claim.
8452:         let environment = tcl_registry::model::resolve_known_environment("f5-irules").unwrap();
8453:         let config = tcl_lexer::LexerConfig {
8454:             leading_bom: tcl_lexer::LeadingBom::Skip,
8455:             base_line: 11,
8456:             ..tcl_lexer::LexerConfig::from_grammar(environment.grammar())
8457:         };
8458:         let (unit, context) = supplied(
8459:             "when HTTP_REQUEST {clientside {HTTP::collect}; HTTP::release}",
8460:             "f5-irules",
8461:             config,
8462:         );
8463:         let (function, tokens) = side_parent(&unit);
8464:         let script = crate::lowering::Lowerer::original_body_for_module(
8465:             &unit.ir_module,
8466:             context.commands(),
8467:             tokens,
8468:             0,
8469:         )
8470:         .expect("genuine retained child source");
8471:         assert!(script.namespace_context.is_some());
8472:         let original_source = script.executed_source.as_ref().unwrap();
8473:         assert_eq!(original_source.try_text().unwrap(), "HTTP::collect");
8474:         let child = unit
8475:             .conditional_original_body_unit(context.commands(), function, tokens, 0)
8476:             .expect("conditional original child");
8477:         assert_eq!(
8478:             child.source_lexer_config(),
8479:             function.source_lexer_config().nested()
8480:         );
8481:         assert_eq!(
8482:             child.source_metadata_input(),
8483:             Some(
8484:                 &unit
8485:                     .ir_module
8486:                     .source_metadata_input
8487:                     .as_ref()
8488:                     .unwrap()
8489:                     .for_nested_source()
8490:             )
8491:         );
8492:         assert_eq!(child.cfg.executed_source.as_ref(), Some(original_source));
8493:         assert!(child.irules_event_body.is_none());
8494:         assert!(
8495:             child
8496:                 .invocation_metadata_context(context.commands())
8497:                 .is_some()
8498:         );
8499:         assert!(
8500:             child
8501:                 .invocation_metadata_context_for_module(context.commands(), &unit.ir_module)
8502:                 .is_some()
8503:         );
8504:         assert_eq!(child.cfg.namespace_context, script.namespace_context);
8505:         assert!(
8506:             unit.conditional_original_body_unit(context.commands(), &child, tokens, 0)
8507:                 .is_none()
8508:         );
8509:         let detached = function.clone();
8510:         assert!(
8511:             unit.conditional_original_body_unit(context.commands(), &detached, tokens, 0)
8512:                 .is_none()
8513:         );
8514:         let mut changed = tokens.clone();
8515:         changed.argv_texts[1].push_str("foreign");
8516:         assert!(
8517:             unit.conditional_original_body_unit(context.commands(), function, &changed, 0)
8518:                 .is_none()
8519:         );
8520:         assert!(
8521:             unit.conditional_original_body_unit(context.commands(), function, tokens, 1)
8522:                 .is_none()
8523:         );
8524:     }
8525: 
8526:     #[test]
8527:     fn nested_original_children_share_the_actual_root_function_owner() {
8528:         // naming.source.original-collection-body-owner
8529:         // docs/design/analysis/name-resolution-proofs/original-collection-body-owner.md
8530:         let environment = tcl_registry::model::resolve_known_environment("f5-irules").unwrap();
8531:         let config = tcl_lexer::LexerConfig::from_grammar(environment.grammar());
8532:         let (unit, context) = supplied(
8533:             "when HTTP_REQUEST {clientside {serverside {TCP::collect}}}",
8534:             "f5-irules",
8535:             config,
8536:         );
8537:         let (original_function, parent) = side_parent(&unit);
8538:         let child = unit
8539:             .conditional_original_body_unit(context.commands(), original_function, parent, 0)
8540:             .expect("first original child");
8541:         let nested = child
8542:             .cfg
8543:             .blocks
8544:             .values()
8545:             .flat_map(|block| &block.statements)
8546:             .filter_map(|statement| statement.tokens())
8547:             .find(|tokens| {
8548:                 tokens
8549:                     .argv_texts
8550:                     .first()
8551:                     .is_some_and(|head| head == "serverside")
8552:             })
8553:             .expect("actual nested parent vector");
8554:         let grandchild = unit
8555:             .conditional_original_body_unit(context.commands(), original_function, nested, 0)
8556:             .expect("nested original child");
8557:         assert_eq!(
8558:             grandchild
8559:                 .cfg
8560:                 .executed_source
8561:                 .as_ref()
8562:                 .unwrap()
8563:                 .try_text()
8564:                 .unwrap(),
8565:             "TCP::collect"
8566:         );
8567:         assert_eq!(
8568:             grandchild.source_metadata_input(),
8569:             original_function.source_metadata_input()
8570:         );
8571:         assert!(grandchild.irules_event_body.is_none());
8572:         assert!(
8573:             unit.conditional_original_body_unit(context.commands(), &child, nested, 0)
8574:                 .is_none()
8575:         );
8576:     }
8577: 
8578:     #[test]
8579:     fn original_child_withdraws_missing_foreign_and_changed_complete_owners() {
8580:         // naming.source.original-collection-body-owner
8581:         // docs/design/analysis/name-resolution-proofs/original-collection-body-owner.md
8582:         let environment = tcl_registry::model::resolve_known_environment("f5-irules").unwrap();
8583:         let config = tcl_lexer::LexerConfig::from_grammar(environment.grammar());
8584:         let source = "when HTTP_REQUEST {clientside {HTTP::collect}}";
8585:         let (original, context) = supplied(source, "f5-irules", config);
8586:         let (function, tokens) = side_parent(&original);
8587:         assert!(
8588:             original
8589:                 .conditional_original_body_unit(context.commands(), function, tokens, 0)
8590:                 .is_some()
8591:         );
8592:         for axis in 0..6 {
8593:             let mut changed = original.clone();
8594:             match axis {
8595:                 0 => changed.source.push_str("foreign"),
8596:                 1 => changed.ir_module.source_metadata_input = None,
8597:                 2 => changed.ir_module.retained_source_bindings = None,
8598:                 3 => changed.ir_module.lexer_config.leading_bom = tcl_lexer::LeadingBom::Skip,
8599:                 4 => changed.source_class_facts = None,
8600:                 _ => {
8601:                     for function in changed.procedures.values_mut() {
8602:                         function.source_metadata_input = None;
8603:                     }
8604:                 }
8605:             }
8606:             let (function, tokens) = side_parent(&changed);
8607:             assert!(
8608:                 changed
8609:                     .conditional_original_body_unit(context.commands(), function, tokens, 0)
8610:                     .is_none(),
8611:                 "axis {axis}"
8612:             );
8613:         }
8614:         let foreign = tcl_registry::model::resolve_known_environment("tcl9.1")
8615:             .unwrap()
8616:             .default_context_registry();
8617:         assert!(
8618:             original
8619:                 .conditional_original_body_unit(foreign.commands(), function, tokens, 0)
8620:                 .is_none()
8621:         );
8622:         let foreign_config = tcl_lexer::LexerConfig {
8623:             leading_bom: tcl_lexer::LeadingBom::Skip,
8624:             ..config
8625:         };
8626:         let (fresh, _) = supplied(source, "f5-irules", foreign_config);
8627:         let mut donated = original.clone();
8628:         donated.source_class_facts = fresh.source_class_facts;
8629:         let (function, tokens) = side_parent(&donated);
8630:         assert!(
8631:             donated
8632:                 .conditional_original_body_unit(context.commands(), function, tokens, 0)
8633:                 .is_none()
8634:         );
8635:     }
8636: 
8637:     #[test]
8638:     fn genuine_roster_retains_empty_classes_and_refuses_owner_donation() {
8639:         // naming.source.original-collection-body-owner
8640:         // docs/design/analysis/name-resolution-proofs/original-collection-body-owner.md
8641:         // Descriptive class spelling only; no Native class allocation/constructor.
8642:         let environment = tcl_registry::model::resolve_known_environment("tcl").unwrap();
8643:         let config = tcl_lexer::LexerConfig {
8644:             leading_bom: tcl_lexer::LeadingBom::Skip,
8645:             base_line: 9,
8646:             ..tcl_lexer::LexerConfig::from_grammar(environment.grammar())
8647:         };
8648:         let source = "oo::class create Empty {}";
8649:         let (unit, context) = supplied(source, "tcl", config);
8650:         assert!(unit.ir_module.methods.is_empty());
8651:         let facts = unit.source_class_facts.as_ref().expect("actual roster");
8652:         assert!(
8653:             facts
8654:                 .for_module(&unit.ir_module, context.commands())
8655:                 .unwrap()
8656:                 .contains("::Empty")
8657:         );
8658:         let same = unit.clone();
8659:         assert!(Arc::ptr_eq(
8660:             facts,
8661:             same.source_class_facts.as_ref().unwrap()
8662:         ));
8663:         assert!(
8664:             facts
8665:                 .for_module(&same.ir_module, context.commands())
8666:                 .is_some()
8667:         );
8668:         // A semantic Eq source owner is descriptive, not an allocation or
8669:         // lifetime receipt. Fresh-vs-memo CU equality must not depend on Arc addresses.
8670:         let fresh = CompilationUnit::build_with_analysis_input(
8671:             source,
8672:             UnitBuildOptions {
8673:                 registry: context.commands(),
8674:                 defer_top_level: false,
8675:                 config,
8676:                 dialect: Some(environment.unit_profile()),
8677:                 external_call_sites: None,
8678:                 declared_commands: None,
8679:             },
8680:             None,
8681:             unit.ir_module.source_metadata_input.as_ref().unwrap(),
8682:         );
8683:         assert_eq!(
8684:             unit.ir_module.retained_source_bindings,
8685:             fresh.ir_module.retained_source_bindings
8686:         );
8687:         assert_eq!(unit.source_class_facts, fresh.source_class_facts);
8688:         assert!(
8689:             facts
8690:                 .for_module(&fresh.ir_module, context.commands())
8691:                 .is_some()
8692:         );
8693:         let (foreign, _) = supplied("oo::class create Foreign {}", "tcl", config);
8694:         assert!(
8695:             facts
8696:                 .for_module(&foreign.ir_module, context.commands())
8697:                 .is_none()
8698:         );
8699:         let mut changed = unit.ir_module.clone();
8700:         changed.lexer_config.base_line += 1;
8701:         assert!(facts.for_module(&changed, context.commands()).is_none());
8702:         changed = unit.ir_module.clone();
8703:         changed.source = tcl_lexer::SourceImage::native(source.as_bytes());
8704:         assert!(facts.for_module(&changed, context.commands()).is_none());
8705:         changed = unit.ir_module.clone();
8706:         changed.source_metadata_input = None;
8707:         assert!(facts.for_module(&changed, context.commands()).is_none());
8708:     }
8709: 
8710:     #[test]
8711:     fn conditional_original_child_inherits_unknown_presence_and_refines_local_stores() {
8712:         // naming.source.original-collection-body-owner
8713:         // docs/design/analysis/name-resolution-proofs/original-collection-body-owner.md
8714:         // Conditional source/lattice facts only; no provider or physical frame claim.
8715:         let environment = tcl_registry::model::resolve_known_environment("tcl8.6").unwrap();
8716:         let config = tcl_lexer::LexerConfig::from_grammar(environment.grammar());
8717:         let source = "proc p {} {set inherited prior; eval {set copy $inherited; set own fresh; set before $own; unset own; set after $own}}; p";
8718:         let (unit, context) = supplied(source, "tcl8.6", config);
8719:         let original = unit.function("::p").expect("actual caller function");
8720:         let tokens = original
8721:             .cfg
8722:             .blocks
8723:             .values()
8724:             .flat_map(|block| &block.statements)
8725:             .filter_map(|statement| statement.tokens())
8726:             .find(|tokens| tokens.argv_texts.first().is_some_and(|head| head == "eval"))
8727:             .expect("original eval parent");
8728:         let child = unit
8729:             .conditional_original_body_unit(context.commands(), original, tokens, 0)
8730:             .expect("actual conditional eval body");
8731:         let inherited = child.ssa.var_symbol("inherited").expect("inherited read");
8732:         let own = child.ssa.var_symbol("own").expect("written local");
8733:         assert_eq!(
8734:             child.sccp.existence.get(&(inherited, 0)),
8735:             Some(&tcl_registry::value_transfer::Existence::MayBound)
8736:         );
8737:         assert_eq!(
8738:             child.sccp.existence.get(&(own, 0)),
8739:             Some(&tcl_registry::value_transfer::Existence::MayBound)
8740:         );
8741:         let mut reads: Vec<_> = child.sccp.existence_reads.iter()
8742:             .filter(|((_, _, symbol), _)| *symbol == own)
8743:             .filter_map(|(&(block, index, _), &fact)| {
8744:                 let statement = &child.cfg.blocks[&block].statements[index as usize];
8745:                 matches!(statement, crate::ir::Statement::AssignValue { value, .. } if value == "$own")
8746:                     .then_some((statement.span().start(), fact))
8747:             }).collect();
8748:         reads.sort_by_key(|(offset, _)| *offset);
8749:         assert_eq!(
8750:             reads.iter().map(|(_, fact)| *fact).collect::<Vec<_>>(),
8751:             vec![
8752:                 tcl_registry::value_transfer::Existence::Bound(
8753:                     tcl_registry::value_transfer::BindingKind::Scalar
8754:                 ),
8755:                 tcl_registry::value_transfer::Existence::Unbound,
8756:             ]
8757:         );
8758:         assert!(child.irules_event_body.is_none());
8759:         assert!(
8760:             !child
8761:                 .sccp
8762:                 .values
8763:                 .get(&(inherited, 0))
8764:                 .is_some_and(|value| matches!(value, crate::analyses::LatticeValue::Const(_)))
8765:         );
8766:     }
8767: 
8768:     #[test]
8769:     fn conditional_empty_child_has_no_report_selected_frame_or_parent_entry_donation() {
8770:         // naming.source.original-collection-body-owner
8771:         // docs/design/analysis/name-resolution-proofs/original-collection-body-owner.md
8772:         // Source entry/API control only; no entered caller, event or Native frame.
8773:         let environment = tcl_registry::model::resolve_known_environment("tcl8.6").unwrap();
8774:         let config = tcl_lexer::LexerConfig::from_grammar(environment.grammar());
8775:         let (unit, context) = supplied("eval {}", "tcl8.6", config);
8776:         let tokens = unit
8777:             .top_level
8778:             .cfg
8779:             .blocks
8780:             .values()
8781:             .flat_map(|block| &block.statements)
8782:             .filter_map(|statement| statement.tokens())
8783:             .find(|tokens| tokens.argv_texts.first().is_some_and(|head| head == "eval"))
8784:             .expect("original empty body parent");
8785:         let child = unit
8786:             .conditional_original_body_unit(context.commands(), &unit.top_level, tokens, 0)
8787:             .expect("genuine empty conditional body");
8788:         let fallback = conditional_function_source_entry(&child.cfg, child.source_metadata_input());
8789:         assert_eq!(
8790:             fallback.frame_kind,
8791:             crate::var_resolve::VariableFrameKind::Unknown
8792:         );
8793:         assert!(fallback.activation.is_none());
8794:         assert!(fallback.execution.is_none());
8795:         assert!(fallback.instance_vars.is_empty());
8796:         assert!(fallback.execution_name_policy.is_none());
8797:         assert_eq!(
8798:             fallback.namespace_identity.as_ref(),
8799:             child.cfg.namespace_context.as_deref()
8800:         );
8801:         let selected = function_source_entry(&child.cfg, Some(&fallback));
8802:         assert_eq!(
8803:             selected.frame_kind,
8804:             crate::var_resolve::VariableFrameKind::Unknown
8805:         );
8806:         assert!(selected.activation.is_none());
8807:         let mut renamed = child.cfg.clone();
8808:         renamed.name = "::invented::procedure".to_owned();
8809:         assert_eq!(function_source_entry(&renamed, Some(&fallback)), selected);
8810:         let mut changed = unit.clone();
8811:         changed.ir_module.source_entry.unknown_entry = true;
8812:         assert!(
8813:             changed
8814:                 .conditional_original_body_unit(context.commands(), &changed.top_level, tokens, 0)
8815:                 .is_none()
8816:         );
8817:     }
8818: }
/* ORIGINAL_SOURCE_RANGE 8820..9120 */
8820: #[cfg(test)]
8821: mod selected_class_roster_tests {
8822: 
8823:     use super::*;
8824:     use crate::analyser::ResolvedAnalysisInput;
8825: 
8826:     fn context(class_grammar: bool) -> Arc<tcl_registry::model::ContextRegistry> {
8827:         let mut store = CommandRegistry::build_default();
8828:         let spec = if class_grammar {
8829:             store.get("oo::class").unwrap().clone()
8830:         } else {
8831:             tcl_registry::CommandSpec::DEFAULT
8832:         };
8833:         store.insert(tcl_registry::CommandSpec {
8834:             name: "forge",
8835:             ..spec
8836:         });
8837:         Arc::new(
8838:             tcl_registry::model::ingress::static_context_for("tcl")
8839:                 .with_command_store(Arc::new(store)),
8840:         )
8841:     }
8842: 
8843:     fn unit(source: &str, context: &Arc<tcl_registry::model::ContextRegistry>) -> CompilationUnit {
8844:         let profile = tcl_dialect::DialectProfile::plain_tcl();
8845:         let config = tcl_lexer::LexerConfig::for_file_grammar(profile.grammar);
8846:         let input = ResolvedAnalysisInput::new(profile, profile, Arc::clone(context), config);
8847:         CompilationUnit::build_with_analysis_input(
8848:             source,
8849:             UnitBuildOptions {
8850:                 registry: context.commands(),
8851:                 defer_top_level: false,
8852:                 config,
8853:                 dialect: Some(profile),
8854:                 external_call_sites: None,
8855:                 declared_commands: None,
8856:             },
8857:             None,
8858:             &input,
8859:         )
8860:     }
8861: 
8862:     #[test]
8863:     fn genuine_cu_roster_uses_selected_custom_renamed_and_direct_aliased_definers() {
8864:         // naming.source.original-collection-body-owner
8865:         // docs/design/analysis/name-resolution-proofs/original-collection-body-owner.md
8866:         let context = context(true);
8867:         for source in [
8868:             "forge create Empty {}",
8869:             "rename forge moved; moved create Empty {}",
8870:             "interp alias {} build {} forge; build create Empty {}",
8871:             "namespace eval ns {forge create Empty {}}",
8872:         ] {
8873:             assert!(
8874:                 !source.contains("class") && !source.contains("oo::") && !source.contains("snit::")
8875:             );
8876:             let unit = unit(source, &context);
8877:             let expected = if source.starts_with("namespace") {
8878:                 "::ns::Empty"
8879:             } else {
8880:                 "::Empty"
8881:             };
8882:             let facts = unit
8883:                 .source_class_facts
8884:                 .as_ref()
8885:                 .expect("genuine produced roster");
8886:             assert!(
8887:                 facts
8888:                     .for_module(&unit.ir_module, context.commands())
8889:                     .unwrap()
8890:                     .contains(expected),
8891:                 "{source}"
8892:             );
8893:             assert!(
8894:                 unit.methods.is_empty(),
8895:                 "the empty class has no method-derived roster"
8896:             );
8897:             let actual =
8898:                 collect_known_classes(source, &unit.ir_module, context.commands()).unwrap();
8899:             let bindings = unit
8900:                 .ir_module
8901:                 .retained_source_bindings
8902:                 .as_ref()
8903:                 .unwrap()
8904:                 .positioned_for_module(&unit.ir_module, context.commands())
8905:                 .unwrap();
8906:             let expected_scan: HashSet<_> =
8907:                 crate::signature_scan::extract_signatures_with_original_bindings(
8908:                     source,
8909:                     unit.ir_module.lexer_config,
8910:                     context.commands(),
8911:                     bindings,
8912:                 )
8913:                 .class_declarations
8914:                 .into_iter()
8915:                 .filter_map(|declaration| declaration.source_spelling())
8916:                 .collect();
8917:             assert_eq!(actual, expected_scan);
8918:         }
8919:     }
8920: 
8921:     #[test]
8922:     fn selected_roster_preserves_changed_definition_and_captured_prefix_refusals() {
8923:         // naming.source.original-collection-body-owner
8924:         // docs/design/analysis/name-resolution-proofs/original-collection-body-owner.md
8925:         let selected = context(true);
8926:         for source in [
8927:             "proc forge args {}; forge create Empty {}",
8928:             "rename forge {}; forge create Empty {}",
8929:             "interp alias {} build {} forge create; build Empty {}",
8930:         ] {
8931:             let unit = unit(source, &selected);
8932:             assert!(
8933:                 !collect_known_classes(source, &unit.ir_module, selected.commands())
8934:                     .unwrap()
8935:                     .contains("::Empty"),
8936:                 "{source}"
8937:             );
8938:         }
8939:         let other = context(false);
8940:         let source = "forge create Empty {}";
8941:         let unit = unit(source, &other);
8942:         assert!(
8943:             collect_known_classes(source, &unit.ir_module, other.commands())
8944:                 .unwrap()
8945:                 .is_empty()
8946:         );
8947:     }
8948: 
8949:     #[test]
8950:     fn class_source_producer_withdraws_foreign_missing_and_changed_full_owners() {
8951:         // naming.source.original-collection-body-owner
8952:         // docs/design/analysis/name-resolution-proofs/original-collection-body-owner.md
8953:         let context = context(true);
8954:         let source = "forge create Empty {}";
8955:         let unit = unit(source, &context);
8956:         assert!(collect_known_classes(source, &unit.ir_module, context.commands()).is_some());
8957:         assert!(
8958:             collect_known_classes("forge create Other {}", &unit.ir_module, context.commands())
8959:                 .is_none()
8960:         );
8961:         assert!(
8962:             collect_known_classes(source, &unit.ir_module, self::context(false).commands())
8963:                 .is_none()
8964:         );
8965:         for axis in 0..4 {
8966:             let mut module = unit.ir_module.clone();
8967:             match axis {
8968:                 0 => module.retained_source_bindings = None,
8969:                 1 => module.lexer_config.strict_quoting ^= true,
8970:                 2 => module.source_metadata_input = None,
8971:                 _ => {
8972:                     module.source =
8973:                         tcl_lexer::SourceImage::native(Arc::<[u8]>::from(source.as_bytes()))
8974:                 }
8975:             }
8976:             assert!(
8977:                 collect_known_classes(source, &module, context.commands()).is_none(),
8978:                 "axis {axis}"
8979:             );
8980:         }
8981:         assert!(
8982:             collect_known_classes("", &self::unit("", &context).ir_module, context.commands())
8983:                 .unwrap()
8984:                 .is_empty()
8985:         );
8986:     }
8987: 
8988:     #[test]
8989:     fn retained_roster_projection_shares_empty_custom_and_selected_source_classes() {
8990:         // naming.source.original-collection-body-owner
8991:         // docs/design/analysis/name-resolution-proofs/original-collection-body-owner.md
8992:         let context = context(true);
8993:         for source in [
8994:             "forge create Empty {}",
8995:             "rename forge moved; moved create Empty {}",
8996:             "interp alias {} build {} forge; build create Empty {}",
8997:         ] {
8998:             let unit = unit(source, &context);
8999:             assert!(unit.ir_module.methods.is_empty());
9000:             let names = unit
9001:                 .retained_source_class_names(context.commands())
9002:                 .unwrap();
9003:             assert_eq!(names, &HashSet::from(["::Empty".to_owned()]));
9004:             assert!(std::ptr::eq(
9005:                 names,
9006:                 unit.source_class_facts
9007:                     .as_ref()
9008:                     .unwrap()
9009:                     .for_module(&unit.ir_module, context.commands())
9010:                     .unwrap()
9011:             ));
9012:         }
9013:         let empty = unit("", &context);
9014:         assert!(
9015:             empty
9016:                 .retained_source_class_names(context.commands())
9017:                 .unwrap()
9018:                 .is_empty()
9019:         );
9020:     }
9021: 
9022:     #[test]
9023:     fn retained_roster_projection_withdraws_changed_cu_module_input_and_store() {
9024:         // naming.source.original-collection-body-owner
9025:         // docs/design/analysis/name-resolution-proofs/original-collection-body-owner.md
9026:         let context = context(true);
9027:         let source = "forge create Empty {}";
9028:         let original = unit(source, &context);
9029:         assert!(
9030:             original
9031:                 .retained_source_class_names(context.commands())
9032:                 .is_some()
9033:         );
9034:         for axis in 0..8 {
9035:             let mut changed = original.clone();
9036:             match axis {
9037:                 0 => changed.source = "forge create Other {}".to_owned(),
9038:                 1 => {
9039:                     changed.ir_module.source =
9040:                         tcl_lexer::SourceImage::native(Arc::<[u8]>::from(source.as_bytes()))
9041:                 }
9042:                 2 => changed.ir_module.lexer_config.strict_quoting ^= true,
9043:                 3 => changed.ir_module.source_metadata_input = None,
9044:                 4 => changed.ir_module.source_entry.unknown_entry = true,
9045:                 5 => changed.ir_module.retained_source_bindings = None,
9046:                 6 => changed.source_class_facts = None,
9047:                 _ => {
9048:                     changed.source_class_facts =
9049:                         unit("forge create Other {}", &context).source_class_facts
9050:                 }
9051:             }
9052:             assert!(
9053:                 changed
9054:                     .retained_source_class_names(context.commands())
9055:                     .is_none(),
9056:                 "axis {axis}"
9057:             );
9058:         }
9059:         assert!(
9060:             original
9061:                 .retained_source_class_names(self::context(false).commands())
9062:                 .is_none()
9063:         );
9064:     }
9065: 
9066:     #[test]
9067:     fn source_ssa_missing_entry_never_infers_activation_from_the_report_name() {
9068:         let mut analyser = crate::analyser::Analyser::new();
9069:         let input = analyser
9070:             .prepare_analysis_input(tcl_dialect::DialectProfile::plain_tcl().name)
9071:             .unwrap();
9072:         let registry = input.borrowed_context_registry().commands();
9073:         let source = "set value TEXT; puts $value";
9074:         let unit = CompilationUnit::build_with_analysis_input(
9075:             source,
9076:             UnitBuildOptions {
9077:                 registry,
9078:                 config: input.lexer_config(),
9079:                 dialect: Some(input.unit_profile()),
9080:                 defer_top_level: false,
9081:                 external_call_sites: None,
9082:                 declared_commands: None,
9083:             },
9084:             None,
9085:             &input,
9086:         );
9087:         let mut cfg = unit.top_level.cfg.clone();
9088:         cfg.command_binding_sites = Default::default();
9089:         cfg.namespace_context = None;
9090:         cfg.name = "::invented::procedure".to_owned();
9091:         let entry = function_source_entry(&cfg, None);
9092:         assert_eq!(
9093:             entry.frame_kind,
9094:             crate::var_resolve::VariableFrameKind::Unknown
9095:         );
9096:         assert!(entry.activation.is_none());
9097:         assert!(!entry.namespace_known);
9098:         let first = crate::ssa::build_ssa_with_config(&cfg, registry, input.lexer_config());
9099:         cfg.name = "::top".to_owned();
9100:         assert_eq!(function_source_entry(&cfg, None), entry);
9101:         let second = crate::ssa::build_ssa_with_config(&cfg, registry, input.lexer_config());
9102:         assert_eq!(first.cell_keys(), second.cell_keys());
9103:         cfg.metadata_context =
9104:             crate::registry_invocation::OwnedInvocationMetadataContext::Unavailable;
9105:         assert_eq!(
9106:             function_source_entry(&cfg, None).frame_kind,
9107:             crate::var_resolve::VariableFrameKind::Unknown
9108:         );
9109:         let standalone = crate::cfg::Function::new("::standalone::model", "entry");
9110:         let compatibility = function_source_entry(&standalone, None);
9111:         assert_eq!(
9112:             compatibility.frame_kind,
9113:             crate::var_resolve::VariableFrameKind::Local
9114:         );
9115:         assert_eq!(
9116:             compatibility.activation.as_deref(),
9117:             Some("::standalone::model")
9118:         );
9119:     }
9120: }
