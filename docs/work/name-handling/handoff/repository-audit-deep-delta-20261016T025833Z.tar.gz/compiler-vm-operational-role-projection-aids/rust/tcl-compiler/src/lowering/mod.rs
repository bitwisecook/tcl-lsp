/* ORIGINAL_SOURCE_RANGE 61..62 */
61: #[cfg(test)]
62: mod native_body_context_tests;
/* ORIGINAL_SOURCE_RANGE 63..64 */
63: #[cfg(test)]
64: mod native_control_carrier_tests;
/* ORIGINAL_SOURCE_RANGE 65..66 */
65: #[cfg(test)]
66: mod original_body_word_geometry_tests;
/* ORIGINAL_SOURCE_RANGE 67..68 */
67: #[cfg(test)]
68: mod passive_metadata_tests;
/* ORIGINAL_SOURCE_RANGE 571..579 */
571: #[cfg(test)]
572: fn proc_body_namespace(qualified: &str, lexical_fallback: &str) -> String {
573:     let (holder, _) = tcl_syntax::naming::key_holder_and_tail(qualified);
574:     if holder.is_empty() {
575:         lexical_fallback.to_string()
576:     } else {
577:         holder.to_string()
578:     }
579: }
/* ORIGINAL_SOURCE_RANGE 582..585 */
582: #[cfg(test)]
583: fn parse_var_list_names(list_text: &str, rules: WordValueRules) -> Option<Vec<String>> {
584:     rules.split_word_names(list_text)
585: }
/* ORIGINAL_SOURCE_RANGE 1180..1229 */
1180:     #[cfg(test)]
1181:     verify_source_body_syntax_cache: bool,
1182:     /// Current `lower_script` / `lower_body` recursion depth, bounded by
1183:     /// [`MAX_LOWER_NEST_DEPTH`] so deeply-nested bodies cannot overflow the
1184:     /// stack. Mirrors [`crate::cfg_builder::CfgBuilder`]'s `depth` field —
1185:     /// lowering runs *before* CFG construction, so an unguarded recursion
1186:     /// here reaches the same crash first and makes the CFG builder's own
1187:     /// cap moot.
1188:     nest_depth: u32,
1189:     /// The buffer every span this lowering emits indexes into — the document
1190:     /// text for an ordinary lowering, and the *materialised literal* while a
1191:     /// synthesised script is lowered at offset `0` inside one (the `eval
1192:     /// $const` / factory-body paths that re-enter [`Self::lower_script`]).
1193:     /// [`Self::lower_script`] swaps it for the duration of each such
1194:     /// re-entry, because that is exactly where a new span space begins;
1195:     /// [`Self::lower_body`] does not, since a body's spans are rebased into
1196:     /// the space it inherits.
1197:     ///
1198:     /// Held so the lowerer can *check* a body word's rebase against the text
1199:     /// it claims to slice ([`crate::segmenter::body_text_in_region`] in
1200:     /// [`Self::lower_body_from_tok`]) rather than trusting the arithmetic —
1201:     /// the same guard the analyser applies.  Empty until a
1202:     /// script is lowered, which the guard reads as "nothing to compare
1203:     /// against" and leaves every body text alone.
1204:     source: String,
1205:     /// The buffer each word model is read from — see [`WordSpace`].
1206:     word_space: WordSpace,
1207: }
1208: 
1209: /// The text a [`crate::ir::WordExpr`] is decomposed from, and the offset its
1210: /// first byte sits at in the span space the segmentation used.
1211: ///
1212: /// Deliberately *not* [`Lowerer::source`]: a word is read from the very text
1213: /// that was segmented into it, which is not always a slice of the enclosing
1214: /// buffer.  A `{body}x` word's body is clamped to the part that does map;
1215: /// an `eval $const` / `eval [list …]` body is a literal
1216: /// materialised at lowering time and lives in a span space of its own; and
1217: /// the `TclOO` method extraction runs as a post-pass, after the document's
1218: /// span space has been restored to the (empty) enclosing one.  Reading the
1219: /// segmented text itself makes the word model right in all three, and the
1220: /// base keeps every span it reports in the space the statements' spans are
1221: /// in.
1222: struct WordSpace {
1223:     text: String,
1224:     base: u32,
1225:     /// `text`'s line index, held so the per-command [`tcl_lexer::SourceMap`]
1226:     /// is a refcount bump (`LineIndex` is `Arc`-backed) rather than a rescan.
1227:     lines: tcl_lexer::LineIndex,
1228:     channel: tcl_lexer::SourceChannel,
1229: }
/* ORIGINAL_SOURCE_RANGE 1368..1389 */
1368:             #[cfg(test)]
1369:             verify_source_body_syntax_cache: false,
1370:             nest_depth: 0,
1371:             source: String::new(),
1372:             word_space: WordSpace::new("", 0, tcl_lexer::SourceChannel::Document),
1373:         }
1374:     }
1375: 
1376:     /// Install the document's own command declarations (see
1377:     /// [`declared_commands`](Self::declared_commands)).
1378:     ///
1379:     /// A stub declares the same kind of fact a `CommandSpec` states, so it
1380:     /// reaches lowering through the same argument-role query the catalogue
1381:     /// does — [`Self::command_surface`] — rather than a parallel table.
1382:     #[must_use]
1383:     pub fn with_declared_commands(
1384:         mut self,
1385:         declared: Option<&'r tcl_registry::model::DeclaredSurface>,
1386:     ) -> Self {
1387:         self.declared_commands = declared;
1388:         self
1389:     }
/* ORIGINAL_SOURCE_RANGE 1913..1914 */
1913:         #[cfg(test)]
1914:         let trace_enabled = std::env::var_os("TCL_LSP_TRACE_ORIGINAL_FACTORY_GUARDS").is_some();
/* ORIGINAL_SOURCE_RANGE 1915..1921 */
1915:         #[cfg(test)]
1916:         let trace = |stage: &str, passed: bool| {
1917:             if std::env::var_os("TCL_LSP_TRACE_ORIGINAL_FACTORY_GUARDS").is_some() {
1918:                 let offset = parent.argv.first().map(|span| span.start());
1919:                 eprintln!("ORIGINAL_FACTORY_GUARD stage={stage} offset={offset:?} passed={passed}");
1920:             }
1921:         };
/* ORIGINAL_SOURCE_RANGE 1924..1927 */
1924:         #[cfg(test)]
1925:         if trace_enabled {
1926:             trace("original_body.module_metadata", metadata.is_some());
1927:         }
/* ORIGINAL_SOURCE_RANGE 1930..1936 */
1930:         #[cfg(test)]
1931:         if trace_enabled {
1932:             trace(
1933:                 "original_body.retained",
1934:                 module.retained_source_bindings.is_some(),
1935:             );
1936:         }
/* ORIGINAL_SOURCE_RANGE 1939..1942 */
1939:         #[cfg(test)]
1940:         if trace_enabled {
1941:             trace("original_body.positioned", bindings.is_some());
1942:         }
/* ORIGINAL_SOURCE_RANGE 1944..1950 */
1944:         #[cfg(test)]
1945:         if trace_enabled {
1946:             trace(
1947:                 "original_body.parent_vector",
1948:                 retained.owns_original_tokens(parent),
1949:             );
1950:         }
/* ORIGINAL_SOURCE_RANGE 1956..1959 */
1956:         #[cfg(test)]
1957:         if trace_enabled {
1958:             trace("original_body.selected_script", source.is_some());
1959:         }
/* ORIGINAL_SOURCE_RANGE 1967..1970 */
1967:         #[cfg(test)]
1968:         if trace_enabled {
1969:             trace("original_body.namespace", namespace.is_some());
1970:         }
/* ORIGINAL_SOURCE_RANGE 1978..1981 */
1978:         #[cfg(test)]
1979:         if trace_enabled {
1980:             trace("original_body.stage", selected.is_some());
1981:         }
/* ORIGINAL_SOURCE_RANGE 6857..7039 */
6857: #[cfg(test)]
6858: mod body_cache_eligible_tests {
6859:     use crate::interprocedural::test_body_identity::fixture_id;
6860: 
6861:     use super::body_cache_eligible;
6862: 
6863:     #[test]
6864:     fn isolated_body_profile_keeps_the_original_standalone_source_purpose() {
6865:         let environment = crate::environment_ingress::resolve_environment("tcl9.0");
6866:         let context = environment.default_context_registry();
6867:         let registry = context.commands();
6868:         let profile = environment.unit_profile();
6869:         let config = tcl_lexer::LexerConfig::for_file_grammar(profile.grammar);
6870:         let source = "upvar 1 ${odd name} local";
6871:         let body = super::lower_proc_body_isolated(source, "::", registry, config, Some(profile));
6872:         let statement = body.statements.first().expect("original statement");
6873:         let tokens = body
6874:             .retained_source_tokens_for_statement(statement)
6875:             .expect("original source tokens");
6876:         let binding = tokens.source_binding.as_ref().expect("original binding");
6877:         let metadata = tcl_registry::model::semantic::SemanticContext::for_profile(profile).into();
6878:         assert_eq!(
6879:             binding.original_source_advice_purpose(tokens, metadata, registry),
6880:             Some(crate::command_binding::OriginalInvocationSourcePurpose::Standalone)
6881:         );
6882:         assert!(
6883:             binding
6884:                 .original_invocation_source_purpose(tokens, metadata, registry)
6885:                 .is_none()
6886:         );
6887:         let retained = body
6888:             .executed_source
6889:             .as_ref()
6890:             .expect("original isolated body source");
6891:         assert_eq!(retained.try_text().unwrap(), source);
6892:         assert_eq!(retained.base(), 0);
6893:         assert!(body.native_compilation_admission.is_none());
6894:         assert!(
6895:             crate::registry_invocation::admitted_native_compiler_invocation(registry, None, tokens)
6896:                 .is_none()
6897:         );
6898:         let info = crate::cfg_builder::upvar_info::collect_upvar_targets_with_registry(
6899:             &body,
6900:             &["odd name".to_owned()],
6901:             registry,
6902:         );
6903:         assert_eq!(
6904:             info.param_targets.get("local").map(String::as_str),
6905:             Some("odd name")
6906:         );
6907:     }
6908: 
6909:     #[test]
6910:     fn plain_bodies_are_eligible() {
6911:         assert!(body_cache_eligible("set x 1"));
6912:         assert!(body_cache_eligible("puts \"hi $name\"\nreturn $x"));
6913:         assert!(body_cache_eligible("if {$x} { foo } else { bar }"));
6914:         assert!(body_cache_eligible(""));
6915:     }
6916: 
6917:     #[test]
6918:     fn cross_item_constructs_disqualify() {
6919:         for body in [
6920:             "namespace eval x { }",
6921:             "namespace import ::ns::*",
6922:             "interp alias {} x {} y",
6923:             "rename set myset",
6924:             "apply {{} { }}",
6925:             "when HTTP_REQUEST { }",
6926:             "oo::class create C { }",
6927:             "itcl::class C { }",
6928:             "proc inner {} { }",
6929:         ] {
6930:             assert!(!body_cache_eligible(body), "should disqualify: {body}");
6931:         }
6932:     }
6933: 
6934:     #[test]
6935:     fn tab_separated_command_still_disqualifies() {
6936:         assert!(!body_cache_eligible("interp\talias {} x {} y"));
6937:         assert!(!body_cache_eligible("namespace\timport ::ns::*"));
6938:     }
6939: 
6940:     #[test]
6941:     fn substring_only_use_is_safe() {
6942:         assert!(body_cache_eligible("set myproclist {a b c}"));
6943:         assert!(body_cache_eligible("set renamed 1"));
6944:     }
6945: 
6946:     #[test]
6947:     fn source_may_alias_commands_flags_interp() {
6948:         use super::source_may_alias_commands;
6949:         // `interp alias` establishes an alias a cached body cannot see.
6950:         assert!(source_may_alias_commands(
6951:             "interp alias {} = {} expr\nproc f {} { = 1 }\n"
6952:         ));
6953:         assert!(source_may_alias_commands("interp\talias {} = {} expr"));
6954:         // No `interp` -> safe to cache.
6955:         assert!(!source_may_alias_commands(
6956:             "proc f {x} { set y $x }\nproc g {} { return 1 }\n"
6957:         ));
6958:         // `interp` as a substring of a bareword does not trip it.
6959:         assert!(!source_may_alias_commands("set interpreter 1"));
6960:     }
6961: 
6962:     // Proves *why* `source_may_alias_commands` must guard the file: with a
6963:     // top-level `interp alias {} = {} expr` in scope, lowering `f`'s
6964:     // body through the isolated body cache (empty alias table) resolves `=` as an
6965:     // unknown command, whereas the in-place whole-file lowering resolves it to
6966:     // `expr` — so the module IRs differ. The db therefore must not install the
6967:     // cache for such a file.
6968:     fn assert_scope_withdraws_cache(source: &str, expected_target: &str) {
6969:         let registry = tcl_registry::CommandRegistry::build_default();
6970:         let config = tcl_lexer::LexerConfig::default();
6971:         let cache_calls = std::cell::Cell::new(0);
6972:         let cache = |body: &str, namespace: &str| {
6973:             cache_calls.set(cache_calls.get() + 1);
6974:             super::lower_proc_body_isolated(body, namespace, &registry, config, None)
6975:         };
6976:         let cached = super::lower_to_ir_with_body_cache(source, &registry, config, None, &cache);
6977:         let fresh = super::lower_to_ir_with_config(source, &registry, config);
6978:         assert_eq!(
6979:             cache_calls.get(),
6980:             0,
6981:             "an isolated cache lacks this dispatch context"
6982:         );
6983:         // Separate analyses have distinct activation/source identities. Test
6984:         // the actual withdrawal and retained dispatch instead of equating the
6985:         // debug serialization of two different physical worlds.
6986:         for module in [&cached, &fresh] {
6987:             let procedure = module
6988:                 .procedures
6989:                 .get(&fixture_id(&module.procedures, "::f"))
6990:                 .expect("authored fixture body");
6991:             assert_eq!(procedure.params, ["x"]);
6992:             let mut retained_target = false;
6993:             crate::ir::for_each_statement(&procedure.body, &mut |statement| {
6994:                 if let Some(tokens) = statement.tokens() {
6995:                     retained_target |= tokens
6996:                         .source_binding
6997:                         .iter()
6998:                         .chain(tokens.nested_bindings.iter().map(|(_, binding)| binding))
6999:                         .filter_map(|binding| binding.proved_execution_target())
7000:                         .any(|target| target.command == expected_target && target.registry_backed);
7001:                 }
7002:             });
7003:             assert!(
7004:                 retained_target,
7005:                 "the original invocation must retain {expected_target}"
7006:             );
7007:         }
7008:     }
7009: 
7010:     #[test]
7011:     fn alias_in_scope_withdraws_isolated_cache_proof() {
7012:         assert_scope_withdraws_cache(
7013:             "interp alias {} = {} expr\nproc f {x} { return [= {$x + 1}] }\n",
7014:             "::expr",
7015:         );
7016:     }
7017: 
7018:     #[test]
7019:     fn source_may_alias_commands_flags_rename() {
7020:         use super::source_may_alias_commands;
7021:         // A static `rename` establishes an alias a cached body cannot see —
7022:         // same hazard as `interp alias`, see `detect_rename`.
7023:         assert!(source_may_alias_commands(
7024:             "rename puts myputs\nproc f {x} { myputs $x }\n"
7025:         ));
7026:         assert!(source_may_alias_commands("rename\tputs myputs"));
7027:         // `rename` as a substring of a bareword does not trip it.
7028:         assert!(!source_may_alias_commands("set renamed 1"));
7029:     }
7030: 
7031:     // Same hazard as `alias_in_scope_makes_body_cache_diverge`, for a static
7032:     // `rename`: `rename puts myputs` at the top level must make `f`'s body
7033:     // resolve `myputs` to `puts`, which the isolated (empty-alias-table) body
7034:     // cache cannot see.
7035:     #[test]
7036:     fn rename_in_scope_withdraws_isolated_cache_proof() {
7037:         assert_scope_withdraws_cache("rename puts myputs\nproc f {x} { myputs $x }\n", "::puts");
7038:     }
7039: }
/* ORIGINAL_SOURCE_RANGE 7483..11915 */
7483: #[cfg(test)]
7484: mod tests {
7485:     use crate::interprocedural::test_body_identity::{fixture_id, fixture_id_if_present};
7486: 
7487:     fn fixture_method<'a>(
7488:         methods: &'a crate::ir::MethodInventory,
7489:         label: &str,
7490:     ) -> Option<&'a crate::ir::MethodDef> {
7491:         methods.unique_display(label).map(|(_, method)| method)
7492:     }
7493: 
7494:     /// An opaque invocation retains its original evaluated argv without licensing
7495:     /// native instructions, a known normal store, or an invented entered body.
7496:     pub(super) fn assert_runtime_opaque_call(
7497:         statement: &crate::ir::Statement,
7498:         registry: &tcl_registry::CommandRegistry,
7499:         expected_head: &str,
7500:     ) {
7501:         let crate::ir::Statement::Call {
7502:             command,
7503:             args,
7504:             tokens: Some(tokens),
7505:             ..
7506:         } = statement
7507:         else {
7508:             panic!("expected retained invocation, got {statement:?}");
7509:         };
7510:         assert_eq!(command, expected_head);
7511:         assert_eq!(tokens.words().len(), args.len() + 1);
7512:         assert!(tokens.source_binding.is_some(), "missing dispatch receipt");
7513:         assert!(crate::registry_invocation::proved_native_inline_operation(tokens).is_none());
7514:         if let Some(region) = tokens.evaluated_body() {
7515:             assert!(
7516:                 region.possible_bodies.is_some(),
7517:                 "runtime retains an analysis-only body inventory"
7518:             );
7519:             assert_eq!(
7520:                 region.selection,
7521:                 crate::execution_region::RegionSelection::MaySkip
7522:             );
7523:             assert_eq!(
7524:                 region.residual_effects,
7525:                 crate::execution_region::WrapperEffectProjection::OpaqueResidual
7526:             );
7527:         }
7528:         let context = &tokens.source_binding.as_ref().unwrap().variable_context;
7529:         let mutations =
7530:             crate::place_bridge::statement_mutation_places(statement, context, registry);
7531:         assert!(
7532:             mutations
7533:                 .iter()
7534:                 .any(|place| place.kind == crate::place::PlaceKind::Unknown)
7535:                 || tokens.evaluated_body().is_some()
7536:                 || crate::registry_invocation::normal_transfer_invocation(registry, None, tokens)
7537:                     .is_none(),
7538:             "a runtime body cannot grant bounded normal stores: {mutations:?}"
7539:         );
7540:     }
7541: 
7542:     /// Every C-Tcl dialect folds a brace-word line continuation; the Jim
7543:     /// answer is asserted in `jim_brace_continuation_binds_different_names`.
7544:     const FOLD_RULES: WordValueRules = WordValueRules {
7545:         brace: tcl_dialect::BraceBackslashNewline::Folds,
7546:         list: tcl_dialect::ListParse::Strict,
7547:     };
7548: 
7549:     /// `JimTcl`: the braced word keeps its bytes, and a malformed remainder is
7550:     /// split rather than raised.
7551:     const LITERAL_RULES: WordValueRules = WordValueRules {
7552:         brace: tcl_dialect::BraceBackslashNewline::Literal,
7553:         list: tcl_dialect::ListParse::Lenient,
7554:     };
7555: 
7556:     /// A brace-word line continuation is folded to a space by every build of
7557:     /// the Tcl core and kept verbatim by `JimTcl`, so a wrapped parameter or
7558:     /// variable list binds *different names* in the two.
7559:     ///
7560:     /// Measured on jimsh 0.84 against tclsh 8.6. The two word kinds resolve
7561:     /// the surviving `\<newline>` differently, because only one of them has a
7562:     /// `name ?default?` level:
7563:     ///
7564:     /// * **Formal parameters** — `proc p {a b\<newline>c} {}` binds three
7565:     ///   parameters under Tcl and *two* under Jim: the second element is the
7566:     ///   specifier `b c`, so the parameter is `b` **defaulting to `c`**
7567:     ///   (`p 1` leaves `b` as `c`; `p 1 2` sets it to `2`).
7568:     /// * **Variable lists** — `foreach {a b\<newline>c} …` has no such level,
7569:     ///   so Jim binds a variable whose name really is `b c`
7570:     ///   (`info exists {b c}` is 1 and `info exists b` is 0).
7571:     ///
7572:     /// Jim's `info args` is no help here: unlike Tcl's it reports the raw
7573:     /// specifiers (`a {b c}`), not the parameter names.
7574:     #[test]
7575:     fn jim_brace_continuation_binds_different_names() {
7576:         let wrapped = "a b\\\nc";
7577: 
7578:         assert_eq!(
7579:             parse_formal_param_names(
7580:                 wrapped,
7581:                 FOLD_RULES,
7582:                 Some(tcl_dialect::ParameterGrammar::Tcl)
7583:             )
7584:             .unwrap(),
7585:             vec!["a", "b", "c"],
7586:             "C Tcl folds the continuation into a separator"
7587:         );
7588:         assert_eq!(
7589:             parse_formal_param_names(
7590:                 wrapped,
7591:                 LITERAL_RULES,
7592:                 Some(tcl_dialect::ParameterGrammar::Jim)
7593:             )
7594:             .unwrap(),
7595:             vec!["a", "b"],
7596:             "Jim keeps the bytes, so `b c` is one specifier: `b` defaulting to `c`"
7597:         );
7598: 
7599:         assert_eq!(
7600:             parse_var_list_names(wrapped, FOLD_RULES).unwrap(),
7601:             vec!["a", "b", "c"]
7602:         );
7603:         assert_eq!(
7604:             parse_var_list_names(wrapped, LITERAL_RULES).unwrap(),
7605:             vec!["a", "b c"]
7606:         );
7607:     }
7608: 
7609:     /// `JimTcl`'s list parser never raises, so a word whose list text is
7610:     /// malformed still binds names instead of collapsing lowering to a
7611:     /// barrier. `llength "a {b"` is 2 under jimsh 0.84 and an error under
7612:     /// tclsh 8.6, and the same split backs `foreach`'s variable list.
7613:     #[test]
7614:     fn malformed_list_word_binds_names_only_for_jim() {
7615:         assert_eq!(
7616:             parse_var_list_names("a {b", FOLD_RULES),
7617:             None,
7618:             "C Tcl raises, which lowering turns into a barrier"
7619:         );
7620:         assert_eq!(
7621:             parse_var_list_names("a {b", LITERAL_RULES).unwrap(),
7622:             vec!["a", "b"],
7623:             "Jim splits it anyway — the unterminated element runs to the end"
7624:         );
7625:     }
7626: 
7627:     /// Both axes reach the helpers from the dialect, so `list_parse` is not
7628:     /// silently left at its `Strict` default for a Jim document.
7629:     #[test]
7630:     fn list_word_rules_come_from_the_dialect() {
7631:         use tcl_dialect::model::{Family, grammar};
7632:         for &release in Family::Jim.releases() {
7633:             let config = tcl_lexer::LexerConfig::from_grammar(grammar(Family::Jim, release));
7634:             assert_eq!(
7635:                 WordValueRules::from_config(&config),
7636:                 LITERAL_RULES,
7637:                 "{release}"
7638:             );
7639:         }
7640:         for &release in Family::Tcl.releases() {
7641:             let config = tcl_lexer::LexerConfig::from_grammar(grammar(Family::Tcl, release));
7642:             assert_eq!(
7643:                 WordValueRules::from_config(&config),
7644:                 FOLD_RULES,
7645:                 "{release}"
7646:             );
7647:         }
7648:     }
7649: 
7650:     /// The knob is wired to the dialect, not chosen per call site.
7651:     #[test]
7652:     fn brace_continuation_comes_from_the_dialect() {
7653:         use tcl_dialect::model::{Family, grammar};
7654:         for &release in Family::Jim.releases() {
7655:             assert_eq!(
7656:                 grammar(Family::Jim, release).brace_backslash_newline,
7657:                 tcl_dialect::BraceBackslashNewline::Literal,
7658:                 "{release}"
7659:             );
7660:         }
7661:         for &release in Family::Tcl.releases() {
7662:             assert_eq!(
7663:                 grammar(Family::Tcl, release).brace_backslash_newline,
7664:                 tcl_dialect::BraceBackslashNewline::Folds,
7665:                 "{release}"
7666:             );
7667:         }
7668:     }
7669: 
7670:     use super::*;
7671: 
7672:     fn reg() -> CommandRegistry {
7673:         // These fixtures assert concrete C Tcl behaviour, including 9.1 grammar.
7674:         CommandRegistry::build_default().project_for_profile(
7675:             tcl_registry::model::ingress::resolve_environment("tcl9.1").analyser_profile(),
7676:         )
7677:     }
7678: 
7679:     #[test]
7680:     fn borrowed_lowering_retains_exact_ingress_before_finalisation() {
7681:         let registry = tcl_registry::model::ingress::static_context_for("jim").commands();
7682:         let profile = registry.profile().expect("selected profile");
7683:         let config = tcl_lexer::LexerConfig::for_profile(Some(profile));
7684:         let mut lowerer = Lowerer::with_config(registry, config);
7685:         let module = lowerer.lower("set x 003");
7686:         assert!(std::ptr::eq(
7687:             module.resolved_profile().expect("profile"),
7688:             profile
7689:         ));
7690:         assert!(module.registry_snapshot.is_some());
7691:         assert_eq!(module.lexer_config, config);
7692:         assert_eq!(
7693:             module.word_values(),
7694:             tcl_syntax::word_rules::WordValueRules::from_config(&config)
7695:         );
7696:     }
7697: 
7698:     #[test]
7699:     fn runtime_procedure_target_retains_its_actual_activation() {
7700:         let registry = tcl_registry::model::ingress::static_context_for("tcl8.6").commands();
7701:         let mut lowerer = Lowerer::new(registry);
7702:         let module = lowerer.lower_procedure_target("puts $x", "");
7703:         let binding = module.top_level.statements[0]
7704:             .tokens()
7705:             .and_then(|tokens| tokens.source_binding.as_ref())
7706:             .expect("positioned runtime procedure invocation");
7707:         assert_eq!(
7708:             binding.variable_frame,
7709:             crate::var_resolve::VariableExecutionFrame::Procedure {
7710:                 namespace: "::".to_owned(),
7711:                 identity: "::top".to_owned(),
7712:             }
7713:         );
7714:         assert_eq!(
7715:             binding.variable_context.activation.as_deref(),
7716:             Some("::top")
7717:         );
7718:     }
7719: 
7720:     #[test]
7721:     fn catch_options_specialisation_requires_the_selected_completion_grammar() {
7722:         for version in tcl_dialect::TclVersion::ALL {
7723:             let dialect = format!("tcl{}", version.version_string());
7724:             let registry = tcl_registry::model::ingress::static_context_for(&dialect).commands();
7725:             let module = lower_to_ir("catch {set x executed} result options", registry);
7726:             if version == tcl_dialect::TclVersion::V8_4 {
7727:                 assert!(matches!(
7728:                     module.top_level.statements[0],
7729:                     Statement::Barrier { .. }
7730:                 ));
7731:             } else {
7732:                 assert!(matches!(
7733:                     module.top_level.statements[0],
7734:                     Statement::Catch { .. }
7735:                 ));
7736:             }
7737:         }
7738:     }
7739: 
7740:     #[test]
7741:     fn fatal_array_index_source_mask_follows_the_release() {
7742:         let source = "puts $array({key})";
7743:         for dialect in ["tcl8.4", "tcl8.6"] {
7744:             assert_eq!(
7745:                 first_fatal_parse_error_with_config(
7746:                     source,
7747:                     tcl_lexer::LexerConfig::for_dialect(dialect)
7748:                 ),
7749:                 None,
7750:                 "{dialect} accepts the index text"
7751:             );
7752:         }
7753:         for dialect in ["tcl9.0", "tcl9.1"] {
7754:             assert_eq!(
7755:                 first_fatal_parse_error_with_config(
7756:                     source,
7757:                     tcl_lexer::LexerConfig::for_dialect(dialect)
7758:                 ),
7759:                 Some(tcl_lexer::INVALID_CHARACTER_IN_ARRAY_INDEX.to_owned()),
7760:                 "{dialect} rejects the raw brace"
7761:             );
7762:         }
7763:     }
7764: 
7765:     #[test]
7766:     fn irules_priority_uses_proved_native_identity_and_frozen_argument_value() {
7767:         let profile = tcl_dialect::DialectProfile::irules();
7768:         let registry = tcl_registry::model::ingress::static_context_for_profile(profile).commands();
7769:         for (source, expected) in [
7770:             (
7771:                 "proc priority {value} {return}; priority 700; when HTTP_REQUEST {}",
7772:                 500,
7773:             ),
7774:             (
7775:                 "set selected 700; priority $selected; when HTTP_REQUEST {}",
7776:                 700,
7777:             ),
7778:         ] {
7779:             let module = lower_to_ir_with_config(
7780:                 source,
7781:                 registry,
7782:                 tcl_lexer::LexerConfig::from_grammar(profile.grammar),
7783:             );
7784:             assert_eq!(
7785:                 module
7786:                     .procedures
7787:                     .get(&fixture_id(&module.procedures, "::when::HTTP_REQUEST"))
7788:                     .expect("authored fixture body")
7789:                     .base_priority,
7790:                 expected
7791:             );
7792:         }
7793:     }
7794: 
7795:     #[test]
7796:     fn irules_event_priorities_follow_file_state_and_keep_repeated_handlers() {
7797:         let profile = tcl_dialect::DialectProfile::irules();
7798:         let registry = tcl_registry::model::ingress::static_context_for_profile(profile).commands();
7799:         let module = lower_to_ir_with_config(
7800:             "priority 700\n\
7801:              when HTTP_REQUEST {}\n\
7802:              priority 400\n\
7803:              when HTTP_REQUEST {}\n\
7804:              when HTTP_REQUEST priority 200 {}\n\
7805:              when HTTP_REQUEST {}",
7806:             registry,
7807:             tcl_lexer::LexerConfig::from_grammar(profile.grammar),
7808:         );
7809: 
7810:         let priorities: Vec<_> = [
7811:             "::when::HTTP_REQUEST",
7812:             "::when::HTTP_REQUEST#1",
7813:             "::when::HTTP_REQUEST#2",
7814:             "::when::HTTP_REQUEST#3",
7815:         ]
7816:         .into_iter()
7817:         .map(|name| {
7818:             module
7819:                 .procedures
7820:                 .get(&fixture_id(&module.procedures, name))
7821:                 .expect("authored fixture body")
7822:                 .base_priority
7823:         })
7824:         .collect();
7825:         assert_eq!(priorities, [700, 400, 200, 400]);
7826:     }
7827: 
7828:     #[test]
7829:     fn irules_declaration_body_shape_gates_lowered_regions() {
7830:         let profile = tcl_dialect::DialectProfile::irules();
7831:         let registry = tcl_registry::model::ingress::static_context_for_profile(profile).commands();
7832:         let module = lower_to_ir_with_config(
7833:             "when HTTP_REQUEST priority 1001 {}\n\
7834:              when HTTP_REQUEST bare_body\n\
7835:              when CLIENT_DATA \"quoted body\"\n\
7836:              proc bare_proc {} bare_body\n\
7837:              proc quoted_proc {} \"return\"\n\
7838:              proc valid_proc {} { return }\n\
7839:              when NOT_A_REAL_EVENT {}\n\
7840:              when HTTP_REQUEST priority 200 {}\n\
7841:              when HTTP_REQUEST {}",
7842:             registry,
7843:             tcl_lexer::LexerConfig::from_grammar(profile.grammar),
7844:         );
7845: 
7846:         assert!(
7847:             fixture_id_if_present(&module.procedures, "::when::NOT_A_REAL_EVENT").is_some(),
7848:             "a syntactically valid unknown event is lowered so the XC translator can report it"
7849:         );
7850:         for name in ["::when::CLIENT_DATA", "::bare_proc", "::quoted_proc"] {
7851:             assert!(
7852:                 !fixture_id_if_present(&module.procedures, name).is_some(),
7853:                 "a non-braced declaration body must not open {name}"
7854:             );
7855:         }
7856:         assert!(fixture_id_if_present(&module.procedures, "::valid_proc").is_some());
7857:         let request = [
7858:             module
7859:                 .procedures
7860:                 .get(&fixture_id(&module.procedures, "::when::HTTP_REQUEST"))
7861:                 .expect("authored fixture body")
7862:                 .base_priority,
7863:             module
7864:                 .procedures
7865:                 .get(&fixture_id(&module.procedures, "::when::HTTP_REQUEST#1"))
7866:                 .expect("authored fixture body")
7867:                 .base_priority,
7868:         ];
7869:         assert_eq!(request, [200, 500], "valid repeated handlers keep priority");
7870:     }
7871: 
7872:     #[test]
7873:     fn irules_declarations_only_lower_at_the_file_surface() {
7874:         let profile = tcl_dialect::DialectProfile::irules();
7875:         let registry = tcl_registry::model::ingress::static_context_for_profile(profile).commands();
7876:         let module = lower_to_ir_with_config(
7877:             "if {1} {\n\
7878:                  when CLIENT_DATA { pool top_level_nested_when }\n\
7879:                  proc top_level_nested_proc {} { pool top_level_nested_proc }\n\
7880:              }\n\
7881:              when HTTP_REQUEST {\n\
7882:                  if {1} {\n\
7883:                      when SERVER_DATA { pool event_nested_when }\n\
7884:                      proc event_nested_proc {} { pool event_nested_proc }\n\
7885:                  }\n\
7886:                  pool live_event\n\
7887:              }\n\
7888:              proc helper {} {\n\
7889:                  if {1} {\n\
7890:                      when HTTP_RESPONSE { pool proc_nested_when }\n\
7891:                      proc proc_nested_proc {} { pool proc_nested_proc }\n\
7892:                  }\n\
7893:                  pool live_proc\n\
7894:              }\n",
7895:             registry,
7896:             tcl_lexer::LexerConfig::from_grammar(profile.grammar),
7897:         );
7898: 
7899:         for absent in [
7900:             "::when::CLIENT_DATA",
7901:             "::when::SERVER_DATA",
7902:             "::when::HTTP_RESPONSE",
7903:             "::top_level_nested_proc",
7904:             "::event_nested_proc",
7905:             "::proc_nested_proc",
7906:         ] {
7907:             assert!(
7908:                 fixture_id_if_present(&module.procedures, absent).is_none(),
7909:                 "nested declaration must remain inert: {absent}"
7910:             );
7911:         }
7912:         assert!(fixture_id_if_present(&module.procedures, "::when::HTTP_REQUEST").is_some());
7913:         assert!(fixture_id_if_present(&module.procedures, "::helper").is_some());
7914:     }
7915: 
7916:     #[test]
7917:     fn static_bool_accepts_unique_prefix_booleans() {
7918:         // A condition folds boolean words by unique prefix, like Tcl
7919:         // (`if {tr}` runs, `if {of}` does not — verified against tclsh).
7920:         assert_eq!(static_bool("tr"), Some(true));
7921:         assert_eq!(static_bool(" ye "), Some(true));
7922:         assert_eq!(static_bool("on"), Some(true));
7923:         assert_eq!(static_bool("of"), Some(false));
7924:         assert_eq!(static_bool("n"), Some(false));
7925:         assert_eq!(static_bool("0"), Some(false));
7926:         assert_eq!(static_bool("1"), Some(true));
7927:         // Ambiguous `o` (on/off) is not a static boolean.
7928:         assert_eq!(static_bool("o"), None);
7929:         assert_eq!(static_bool("$x"), None);
7930:     }
7931: 
7932:     #[test]
7933:     fn lowering_is_dialect_aware_via_expand_syntax() {
7934:         // Lowering re-segments each
7935:         // body under the document dialect.  For `if {*}$cond { puts hi }`,
7936:         // on 8.5+ the `{*}` expands the condition, so the structured `if`
7937:         // trips the expand-barrier (an opaque `Statement::Barrier` — the
7938:         // structure can't be reasoned about); on 8.4 `{*}` is a literal
7939:         // word, so the `if` lowers normally (no barrier).
7940:         let reg = reg();
7941:         let src = "if {*}$cond { puts hi }";
7942:         let m90 = lower_to_ir_with_config(src, &reg, tcl_lexer::LexerConfig::default());
7943:         let m84 = lower_to_ir_with_config(src, &reg, tcl_lexer::LexerConfig::for_dialect("tcl8.4"));
7944:         let is_barrier = |m: &Module| {
7945:             matches!(
7946:                 m.top_level.statements.first(),
7947:                 Some(Statement::Barrier { .. })
7948:             )
7949:         };
7950:         assert!(
7951:             is_barrier(&m90),
7952:             "9.0 expands `{{*}}` → structured `if` becomes a barrier: {:?}",
7953:             m90.top_level.statements,
7954:         );
7955:         assert!(
7956:             !is_barrier(&m84),
7957:             "8.4 treats `{{*}}` as literal → `if` lowers without a barrier: {:?}",
7958:             m84.top_level.statements,
7959:         );
7960:     }
7961: 
7962:     /// Every structured form `try_dispatch_structured_hook` covers must
7963:     /// barrier on `{*}` expansion.  A form that instead commits to its
7964:     /// *un-expanded* argv fabricates nonsense IR — `lmap i {*}$spec {…}`
7965:     /// becomes an `IRForeach` with one iterator over the literal word
7966:     /// `${spec}`, making W210 claim a loop variable is read before it is set.
7967:     #[test]
7968:     fn every_argv_shaped_hook_barriers_on_expansion() {
7969:         let reg = reg();
7970:         for src in [
7971:             // Forms whose argv shape is fixed by the hook.
7972:             "foreach i {*}$spec {puts $i}",
7973:             "if {*}$cond {puts hi}",
7974:             "switch {*}$spec {a {puts hi}}",
7975:             "while {*}$spec {puts hi}",
7976:             "for {*}$spec {puts hi}",
7977:             "proc {*}$spec {puts hi}",
7978:             "namespace eval {*}$spec {puts hi}",
7979:             // Forms it missed.
7980:             "lmap i {*}$spec {puts $i}",
7981:             "dict for {k v} {*}$rest {puts $k}",
7982:             "array for {k v} {*}$rest {puts $k}",
7983:             "foreachLine ln {*}$rest {puts $ln}",
7984:             "catch {puts hi} {*}$rest",
7985:             "try {puts hi} {*}$rest",
7986:             "eval {*}$rest",
7987:             "uplevel {*}$rest",
7988:             "apply {*}$rest",
7989:         ] {
7990:             let m = lower_to_ir(src, &reg);
7991:             assert!(
7992:                 matches!(
7993:                     m.top_level.statements.first(),
7994:                     Some(Statement::Barrier { .. })
7995:                 ),
7996:                 "`{src}` must barrier on `{{*}}` expansion: {:?}",
7997:                 m.top_level.statements,
7998:             );
7999:         }
8000:     }
8001: 
8002:     /// The barrier is an *expansion* gate, not a blanket one: the same
8003:     /// structured forms without `{*}` keep their specialised lowering, and a
8004:     /// non-structured hook (`set`) never barriers on expansion at all — its
8005:     /// own `has_expansion` check declines and the call reaches
8006:     /// `lower_default`.
8007:     #[test]
8008:     fn expansion_barrier_leaves_unexpanded_and_non_structured_forms_alone() {
8009:         let reg = reg();
8010:         for src in [
8011:             "foreach i $spec {puts $i}",
8012:             "lmap i $spec {puts $i}",
8013:             "catch {puts hi} err",
8014:             "set {*}$rest",
8015:             "puts {*}$rest",
8016:         ] {
8017:             let m = lower_to_ir(src, &reg);
8018:             assert!(
8019:                 !matches!(
8020:                     m.top_level.statements.first(),
8021:                     Some(Statement::Barrier { .. })
8022:                 ),
8023:                 "`{src}` must not raise the expansion barrier: {:?}",
8024:                 m.top_level.statements,
8025:             );
8026:         }
8027:     }
8028: 
8029:     /// The barrier reason names the command, which the compiler-explorer
8030:     /// `--show ir` view quotes.
8031:     #[test]
8032:     fn expansion_barrier_reason_names_the_command() {
8033:         let m = lower_to_ir("lmap i {*}$spec {puts $i}", &reg());
8034:         let Some(Statement::Barrier { reason, .. }) = m.top_level.statements.first() else {
8035:             panic!("expected a barrier: {:?}", m.top_level.statements);
8036:         };
8037:         assert_eq!(reason, "lmap with argument expansion");
8038:     }
8039: 
8040:     #[test]
8041:     fn empty_source() {
8042:         let m = lower_to_ir("", &reg());
8043:         assert_eq!(m.top_level.statements, [] as [crate::ir::Statement; 0]);
8044:     }
8045: 
8046:     #[test]
8047:     fn simple_set() {
8048:         let m = lower_to_ir("set x 1", &reg());
8049:         assert_eq!(m.top_level.statements.len(), 1);
8050:         assert!(matches!(
8051:             &m.top_level.statements[0],
8052:             Statement::AssignConst { name, value, .. } if name == "x" && value == "1"
8053:         ));
8054:     }
8055: 
8056:     #[test]
8057:     fn set_with_variable_value() {
8058:         let m = lower_to_ir("set y $x", &reg());
8059:         assert_eq!(m.top_level.statements.len(), 1);
8060:         assert!(matches!(
8061:             &m.top_level.statements[0],
8062:             Statement::AssignValue { name, .. } if name == "y"
8063:         ));
8064:     }
8065: 
8066:     #[test]
8067:     fn incr_command() {
8068:         let m = lower_to_ir("incr i", &reg());
8069:         assert_eq!(m.top_level.statements.len(), 1);
8070:         assert!(matches!(
8071:             &m.top_level.statements[0],
8072:             Statement::Incr { name, .. } if name == "i"
8073:         ));
8074:     }
8075: 
8076:     // The `extract_oo_methods_pass` post-pass
8077:     // lifts TclOO method bodies into `module.methods`.
8078: 
8079:     #[test]
8080:     fn extracts_oo_class_methods() {
8081:         let src = "oo::class create Counter {\n\
8082:                    \x20   variable n\n\
8083:                    \x20   constructor {} { set n 0 }\n\
8084:                    \x20   method bump {} { incr n }\n\
8085:                    \x20   method get {} { return $n }\n\
8086:                    }\n";
8087:         let m = lower_to_ir(src, &reg());
8088:         let mut keys: Vec<String> = m
8089:             .methods
8090:             .values()
8091:             .map(crate::ir::MethodDef::reporting_label)
8092:             .collect();
8093:         keys.sort();
8094:         assert_eq!(
8095:             keys,
8096:             vec![
8097:                 "::Counter::<constructor>".to_string(),
8098:                 "::Counter::bump".to_string(),
8099:                 "::Counter::get".to_string(),
8100:             ],
8101:             "methods: {keys:?}",
8102:         );
8103:         let get =
8104:             fixture_method(&m.methods, "::Counter::get").expect("unique retained fixture method");
8105:         assert_eq!(get.method_name, "get");
8106:         assert_eq!(get.kind, MethodKind::Method);
8107:         assert_eq!(get.class_name, "::Counter");
8108:         assert_eq!(
8109:             get.execution_namespace,
8110:             crate::ir::ExecutionNamespace::RuntimeSelected,
8111:             "TclOO resolves relative commands in the runtime receiver namespace"
8112:         );
8113:         // `variable n` in the class body is an in-scope instance var
8114:         // for every method (auto-linked).
8115:         assert!(
8116:             get.instance_vars.contains("n"),
8117:             "get ivars: {:?}",
8118:             get.instance_vars
8119:         );
8120:         // The method body is lowered for analysis (the `incr n` /
8121:         // `return $n` statements are present, not an empty barrier).
8122:         let bump =
8123:             fixture_method(&m.methods, "::Counter::bump").expect("unique retained fixture method");
8124:         assert!(
8125:             !bump.body.statements.is_empty(),
8126:             "bump body should be lowered"
8127:         );
8128:         let ctor = fixture_method(&m.methods, "::Counter::<constructor>")
8129:             .expect("unique retained fixture method");
8130:         assert_eq!(ctor.kind, MethodKind::Constructor);
8131:         assert_eq!(m.redefined_methods.len(), 0);
8132:         assert!(
8133:             !m.oo_evidence.unretained_executable_roots,
8134:             "every executable body in a fully static class was retained"
8135:         );
8136:     }
8137: 
8138:     #[test]
8139:     fn lowers_oo_configurable_class_body() {
8140:         // `oo::configurable create` (and `oo::abstract` / `oo::singleton`)
8141:         // share the `METACLASS create NAME { body }` shape, so their bodies
8142:         // must be lowered and their methods lifted like `oo::class`'s — not left
8143:         // as an unanalysed barrier, which would skip every method body of a
8144:         // class defined with `oo::configurable`.
8145:         let src = "oo::configurable create Pin {\n\
8146:                    \x20   property node\n\
8147:                    \x20   method describe {} { return [my configure -node] }\n\
8148:                    }\n";
8149:         let m = lower_to_ir(src, &reg());
8150:         assert!(
8151:             m.methods
8152:                 .values()
8153:                 .any(|method| method.reporting_label() == "::Pin::describe"),
8154:             "oo::configurable method must be lifted; methods: {:?}",
8155:             m.methods.keys().collect::<Vec<_>>()
8156:         );
8157:         assert!(
8158:             !fixture_method(&m.methods, "::Pin::describe")
8159:                 .expect("unique retained fixture method")
8160:                 .body
8161:                 .statements
8162:                 .is_empty(),
8163:             "the method body should be lowered, not barriered"
8164:         );
8165:     }
8166: 
8167:     #[test]
8168:     fn extracts_oo_define_methods_and_namespaced_class() {
8169:         // `oo::define` adds methods to an existing class, and a class
8170:         // created inside `namespace eval` qualifies under that ns.
8171:         let src = "namespace eval ::app {\n\
8172:                    \x20   oo::class create Widget {\n\
8173:                    \x20       method draw {} { return ok }\n\
8174:                    \x20   }\n\
8175:                    }\n\
8176:                    oo::define ::app::Widget {\n\
8177:                    \x20   method hide {} { return done }\n\
8178:                    }\n";
8179:         let m = lower_to_ir(src, &reg());
8180:         assert!(
8181:             m.methods
8182:                 .values()
8183:                 .any(|method| method.reporting_label() == "::app::Widget::draw"),
8184:             "methods: {:?}",
8185:             m.methods.keys().collect::<Vec<_>>()
8186:         );
8187:         assert!(
8188:             m.methods
8189:                 .values()
8190:                 .any(|method| method.reporting_label() == "::app::Widget::hide"),
8191:             "methods: {:?}",
8192:             m.methods.keys().collect::<Vec<_>>()
8193:         );
8194:     }
8195: 
8196:     // Extraction is driven by the registry definer grammars, so
8197:     // oo::objdefine, snit, and itcl bodies produce method units too.
8198: 
8199:     // TP: an `oo::objdefine $obj { … }` body produces per-object method
8200:     // units, so the body is visible to analysis.
8201:     #[test]
8202:     fn objdefine_bodies_produce_per_object_method_units() {
8203:         let src = "oo::class create C {}\n\
8204:                    set k [C new]\n\
8205:                    oo::objdefine $k {\n\
8206:                    \x20   variable z\n\
8207:                    \x20   method probe {} { return $z }\n\
8208:                    }\n";
8209:         let m = lower_to_ir(src, &reg());
8210:         let unit = m
8211:             .methods
8212:             .unique_display("::@objdefine@::k::probe")
8213:             .map(|(_, method)| method)
8214:             .unwrap_or_else(|| panic!("methods: {:?}", m.methods.keys().collect::<Vec<_>>()));
8215:         assert_eq!(unit.method_name, "probe");
8216:         assert!(!unit.body.statements.is_empty(), "body must be lowered");
8217:         // The block's `variable z` is per-object state in scope for the
8218:         // per-object method.
8219:         assert!(
8220:             unit.instance_vars.contains("z"),
8221:             "ivars: {:?}",
8222:             unit.instance_vars
8223:         );
8224:     }
8225: 
8226:     // TN: objdefine `variable` declarations are
8227:     // per-object — they must NOT pollute the real class's cross-block
8228:     // instance-variable union.
8229:     #[test]
8230:     fn objdefine_variables_stay_out_of_the_class_union() {
8231:         let src = "oo::class create C {\n\
8232:                    \x20   method m {} { info exists z }\n\
8233:                    }\n\
8234:                    set k [C new]\n\
8235:                    oo::objdefine $k { variable z }\n";
8236:         let m = lower_to_ir(src, &reg());
8237:         let class_m = fixture_method(&m.methods, "::C::m").expect("unique retained fixture method");
8238:         assert!(
8239:             !class_m.instance_vars.contains("z"),
8240:             "per-object `z` leaked into the class union: {:?}",
8241:             class_m.instance_vars
8242:         );
8243:     }
8244: 
8245:     // TP (item 2): snit method / typemethod / constructor bodies become
8246:     // method units, with the grammar's implicit member-body variables
8247:     // (self / selfns / type / options) and declared type variables in scope.
8248:     #[test]
8249:     fn snit_type_bodies_produce_method_units() {
8250:         let src = "snit::type Dog {\n\
8251:                    \x20   variable name\n\
8252:                    \x20   constructor {args} { set name fido }\n\
8253:                    \x20   method bark {} { return \"$name barks\" }\n\
8254:                    \x20   typemethod count {} { return 0 }\n\
8255:                    }\n";
8256:         let m = lower_to_ir(src, &reg());
8257:         let bark = m
8258:             .methods
8259:             .unique_display("::Dog::bark")
8260:             .map(|(_, method)| method)
8261:             .unwrap_or_else(|| panic!("methods: {:?}", m.methods.keys().collect::<Vec<_>>()));
8262:         assert_eq!(bark.kind, MethodKind::Method);
8263:         assert_eq!(
8264:             bark.execution_namespace,
8265:             crate::ir::ExecutionNamespace::exact("::Dog")
8266:         );
8267:         assert_ne!(bark.body.statements, [] as [crate::ir::Statement; 0]);
8268:         for implicit in ["self", "selfns", "type", "options", "name"] {
8269:             assert!(
8270:                 bark.instance_vars.contains(implicit),
8271:                 "missing {implicit}: {:?}",
8272:                 bark.instance_vars
8273:             );
8274:         }
8275:         assert_eq!(
8276:             fixture_method(&m.methods, "::Dog::count")
8277:                 .expect("unique retained fixture method")
8278:                 .kind,
8279:             MethodKind::ClassMethod,
8280:             "typemethod dispatches on the type command"
8281:         );
8282:         assert!(
8283:             m.methods
8284:                 .values()
8285:                 .any(|method| method.reporting_label() == "::Dog::<constructor>")
8286:         );
8287:     }
8288: 
8289:     // TP: the widget grammar's extra implicit vars (win / hull) reach
8290:     // widget method units — registry data, not a name-suffix check.
8291:     #[test]
8292:     fn snit_widget_bodies_see_win_and_hull() {
8293:         let src = "snit::widget MyBar {\n\
8294:                    \x20   method redraw {} { return $win }\n\
8295:                    }\n";
8296:         let m = lower_to_ir(src, &reg());
8297:         let redraw = m
8298:             .methods
8299:             .unique_display("::MyBar::redraw")
8300:             .map(|(_, method)| method)
8301:             .unwrap_or_else(|| panic!("methods: {:?}", m.methods.keys().collect::<Vec<_>>()));
8302:         assert!(redraw.instance_vars.contains("win"));
8303:         assert!(redraw.instance_vars.contains("hull"));
8304:     }
8305: 
8306:     // TP (item 2): itcl method bodies — including the access-modifier
8307:     // wrapped spellings — become method units with `this`, instance
8308:     // variables, and commons in scope.
8309:     #[test]
8310:     fn itcl_class_bodies_produce_method_units() {
8311:         let src = "itcl::class Toaster {\n\
8312:                    \x20   variable crumbs 0\n\
8313:                    \x20   common heat 3\n\
8314:                    \x20   public method toast {n} { incr crumbs $n }\n\
8315:                    \x20   method clean {} { set crumbs 0 }\n\
8316:                    \x20   constructor {} { set crumbs 0 }\n\
8317:                    }\n";
8318:         let m = lower_to_ir(src, &reg());
8319:         let toast = m
8320:             .methods
8321:             .unique_display("::Toaster::toast")
8322:             .map(|(_, method)| method)
8323:             .unwrap_or_else(|| panic!("methods: {:?}", m.methods.keys().collect::<Vec<_>>()));
8324:         assert_eq!(toast.params, vec!["n".to_string()]);
8325:         assert_eq!(
8326:             toast.execution_namespace,
8327:             crate::ir::ExecutionNamespace::exact("::Toaster")
8328:         );
8329:         for name in ["this", "crumbs", "heat"] {
8330:             assert!(
8331:                 toast.instance_vars.contains(name),
8332:                 "missing {name}: {:?}",
8333:                 toast.instance_vars
8334:             );
8335:         }
8336:         assert!(
8337:             m.methods
8338:                 .values()
8339:                 .any(|method| method.reporting_label() == "::Toaster::clean")
8340:         );
8341:         assert!(
8342:             m.methods
8343:                 .values()
8344:                 .any(|method| method.reporting_label() == "::Toaster::<constructor>")
8345:         );
8346:     }
8347: 
8348:     #[test]
8349:     fn definition_member_words_use_positioned_source_and_retained_grammar() {
8350:         // Software source projection only: no runtime member or frame grant.
8351:         use crate::registry_invocation::EffectiveInvocationWord as Word;
8352:         let source = "method {a\\\n  b} \"$name\" {*}$args";
8353:         let config = tcl_lexer::LexerConfig::for_dialect("tcl8.6");
8354:         for (config, expected) in [
8355:             (config, "a b"),
8356:             (
8357:                 tcl_lexer::LexerConfig {
8358:                     brace_backslash_newline: tcl_dialect::BraceBackslashNewline::Literal,
8359:                     ..config
8360:                 },
8361:                 "a\\\n  b",
8362:             ),
8363:         ] {
8364:             let segment =
8365:                 crate::segmenter::segment_commands_with_offset_and_config(source, 0, config)
8366:                     .pop()
8367:                     .expect("one original member invocation");
8368:             let tokens =
8369:                 CommandTokens::from_segmented(&tcl_lexer::SourceMap::new(source), config, &segment);
8370:             assert_eq!(
8371:                 statement_words(&tokens, config),
8372:                 vec![
8373:                     Word::Literal("method".to_owned()),
8374:                     Word::Literal(expected.to_owned()),
8375:                     Word::Dynamic,
8376:                     Word::Expanded,
8377:                 ]
8378:             );
8379:         }
8380:     }
8381: 
8382:     // TP: TclOO wrapper members — `self { method … }` lifts a
8383:     // classmethod-kind unit, `private { method … }` an instance one; the
8384:     // prefix spellings match.
8385:     #[test]
8386:     fn tcloo_wrapper_members_produce_units() {
8387:         let src = "oo::class create W {\n\
8388:                    \x20   self { method make {} { return [my new] } }\n\
8389:                    \x20   private { method hidden {} { return 1 } }\n\
8390:                    \x20   self method direct {} { return 2 }\n\
8391:                    }\n";
8392:         let m = lower_to_ir(src, &reg());
8393:         assert_eq!(
8394:             fixture_method(&m.methods, "::W::make").map_or_else(
8395:                 || panic!("methods: {:?}", m.methods.keys().collect::<Vec<_>>()),
8396:                 |d| d.kind
8397:             ),
8398:             MethodKind::ClassMethod
8399:         );
8400:         assert_eq!(
8401:             fixture_method(&m.methods, "::W::direct")
8402:                 .expect("unique retained fixture method")
8403:                 .kind,
8404:             MethodKind::ClassMethod
8405:         );
8406:         assert_eq!(
8407:             fixture_method(&m.methods, "::W::hidden")
8408:                 .expect("unique retained fixture method")
8409:                 .kind,
8410:             MethodKind::Method
8411:         );
8412:         assert!(!m.oo_evidence.unretained_executable_roots);
8413:     }
8414: 
8415:     // TN: an `initialise` body is a *definition script* evaluated in the
8416:     // class object's namespace, not a method frame — no unit.
8417:     #[test]
8418:     fn tcloo_initialise_body_is_not_a_method_unit() {
8419:         let src = "oo::class create I {\n\
8420:                    \x20   initialise { variable cache {} }\n\
8421:                    \x20   method read {} { return 1 }\n\
8422:                    }\n";
8423:         let m = lower_to_ir(src, &reg());
8424:         assert!(
8425:             !m.methods
8426:                 .values()
8427:                 .any(|m| m.reporting_label().contains("initialise")),
8428:             "methods: {:?}",
8429:             m.methods.keys().collect::<Vec<_>>()
8430:         );
8431:         assert!(
8432:             m.methods
8433:                 .values()
8434:                 .any(|method| method.reporting_label() == "::I::read")
8435:         );
8436:         assert!(
8437:             m.oo_evidence.unretained_executable_roots,
8438:             "the unrepresented initialise script must remain explicit evidence"
8439:         );
8440:     }
8441: 
8442:     // TN: `self constructor` / `self destructor` name no member (tclsh
8443:     // 8.6.18, 9.0.4 and 9.1: `invalid command name "constructor"`), so
8444:     // neither lifts a unit —
8445:     // while the instance-side spellings beside them do.
8446:     #[test]
8447:     fn tcloo_self_constructor_and_destructor_lift_no_unit() {
8448:         let src = "oo::class create S {\n\
8449:                    \x20   self constructor {} { set a 1 }\n\
8450:                    \x20   self destructor { set b 2 }\n\
8451:                    \x20   method m {} { return 3 }\n\
8452:                    }\n";
8453:         let m = lower_to_ir(src, &reg());
8454:         assert!(
8455:             m.methods
8456:                 .values()
8457:                 .all(|d| !matches!(d.kind, MethodKind::Constructor | MethodKind::Destructor)),
8458:             "methods: {:?}",
8459:             m.methods.keys().collect::<Vec<_>>()
8460:         );
8461:         assert!(
8462:             m.methods
8463:                 .values()
8464:                 .any(|method| method.reporting_label() == "::S::m")
8465:         );
8466:         let src = "oo::class create T {\n\
8467:                    \x20   constructor {} { set a 1 }\n\
8468:                    \x20   destructor { set b 2 }\n\
8469:                    }\n";
8470:         let m = lower_to_ir(src, &reg());
8471:         assert_eq!(
8472:             fixture_method(&m.methods, "::T::<constructor>")
8473:                 .expect("unique retained fixture method")
8474:                 .kind,
8475:             MethodKind::Constructor
8476:         );
8477:         assert!(
8478:             m.methods.values().any(|d| d.kind == MethodKind::Destructor),
8479:             "methods: {:?}",
8480:             m.methods.keys().collect::<Vec<_>>()
8481:         );
8482:     }
8483: 
8484:     // TN: a dynamic objdefine receiver that is not a simple variable
8485:     // reference (a command substitution) stays un-extracted.
8486:     #[test]
8487:     fn objdefine_command_substitution_receiver_abstains() {
8488:         let src = "oo::class create C {}\n\
8489:                    oo::objdefine [C new] { method m {} { return 1 } }\n";
8490:         let m = lower_to_ir(src, &reg());
8491:         assert!(
8492:             !m.methods
8493:                 .values()
8494:                 .any(|m| m.reporting_label().starts_with("::@objdefine@")),
8495:             "methods: {:?}",
8496:             m.methods.keys().collect::<Vec<_>>()
8497:         );
8498:         assert!(m.oo_evidence.unretained_executable_roots);
8499:     }
8500: 
8501:     #[test]
8502:     fn colliding_method_reports_retain_distinct_bodies_and_constructor_purposes() {
8503:         let source = "namespace eval A {}\noo::class create A::B {method c {} {return LEFT}}\noo::class create A {method B::c {} {return RIGHT}; method <constructor> {} {return NAMED}; constructor {} {set local ACTUAL}; export B::c <constructor>}\n";
8504:         let module = lower_to_ir(source, &reg());
8505:         assert_eq!(module.methods.len(), 4);
8506:         assert_eq!(
8507:             module
8508:                 .methods
8509:                 .keys()
8510:                 .copied()
8511:                 .collect::<std::collections::HashSet<_>>()
8512:                 .len(),
8513:             4
8514:         );
8515:         assert!(module.methods.unique_display("::A::B::c").is_none());
8516:         assert!(
8517:             module
8518:                 .methods
8519:                 .unique_display("::A::<constructor>")
8520:                 .is_none()
8521:         );
8522:         assert_eq!(
8523:             module
8524:                 .methods
8525:                 .values()
8526:                 .filter(|method| method.kind == MethodKind::Constructor)
8527:                 .count(),
8528:             1
8529:         );
8530:         assert_eq!(
8531:             module
8532:                 .methods
8533:                 .values()
8534:                 .filter(|method| method.kind == MethodKind::Method
8535:                     && method.method_name == "<constructor>")
8536:                 .count(),
8537:             1
8538:         );
8539:         assert!(module.redefined_methods.is_empty());
8540:         for id in module.methods.keys() {
8541:             assert_eq!(module.method_definition_bodies(*id).count(), 1);
8542:         }
8543:     }
8544: 
8545:     #[test]
8546:     fn redefined_oo_method_retains_the_replacement_body() {
8547:         // A method redefined by a later `oo::define` keeps the first
8548:         // body in `methods`, and RETAINS the replacement in
8549:         // `redefined_methods` so analysis consumers can
8550:         // scan every body a dispatch may run instead of abstaining.
8551:         let src = "oo::class create C {\n\
8552:                    \x20   method m {} { return 1 }\n\
8553:                    }\n\
8554:                    oo::define C {\n\
8555:                    \x20   method m {} { return 2 }\n\
8556:                    }\n";
8557:         let m = lower_to_ir(src, &reg());
8558:         assert!(
8559:             m.methods
8560:                 .values()
8561:                 .any(|method| method.reporting_label() == "::C::m")
8562:         );
8563:         let (primary, replacements) = m
8564:             .redefined_methods
8565:             .iter()
8566:             .next()
8567:             .unwrap_or_else(|| panic!("redefined: {:?}", m.redefined_methods));
8568:         assert_eq!(m.methods.get(primary).unwrap().method_name, "m");
8569:         assert_eq!(replacements.len(), 1, "one replacement body retained");
8570:         let retained = m.methods.get(&replacements[0]).unwrap();
8571:         assert_eq!(retained.class_name, "::C");
8572:         assert!(
8573:             !retained.body.statements.is_empty(),
8574:             "the replacement body is lowered, not discarded"
8575:         );
8576:         assert_eq!(m.oo_unanalysed_classes.len(), 0);
8577:         assert!(!m.oo_evidence.dynamic_target);
8578:         assert!(!m.oo_evidence.unretained_executable_roots);
8579:     }
8580: 
8581:     #[test]
8582:     fn unreadable_oo_members_flag_the_class_or_module() {
8583:         // A dynamic member NAME may redefine any method of the class —
8584:         // the class is flagged unanalysable.
8585:         let m = lower_to_ir(
8586:             "oo::class create C {\n    method m {} { return 1 }\n    method $n {} { return 2 }\n}\n",
8587:             &reg(),
8588:         );
8589:         assert!(m.oo_unanalysed_classes.contains("::C"), "{m:?}");
8590:         assert!(m.oo_evidence.unretained_executable_roots);
8591:         // A dynamic member BODY is a method whose code no scan can read.
8592:         let m = lower_to_ir("oo::class create C {\n    method m {} $body\n}\n", &reg());
8593:         assert!(m.oo_unanalysed_classes.contains("::C"));
8594:         assert!(m.oo_evidence.unretained_executable_roots);
8595:         // A dynamic CLASS word may touch any class — module-wide flag.
8596:         let m = lower_to_ir("oo::define $cls { method m {} { return 1 } }\n", &reg());
8597:         assert!(m.oo_evidence.dynamic_target);
8598:         assert!(m.oo_evidence.unretained_executable_roots);
8599:         // A fully-static module sets neither.
8600:         let m = lower_to_ir("oo::class create C { method m {} { return 1 } }\n", &reg());
8601:         assert_eq!(m.oo_unanalysed_classes.len(), 0);
8602:         assert!(!m.oo_evidence.dynamic_target);
8603:         assert!(!m.oo_evidence.unretained_executable_roots);
8604:     }
8605: 
8606:     #[test]
8607:     fn every_unextracted_oo_body_shape_leaves_module_evidence() {
8608:         for source in [
8609:             // The outer definition script is computed, so the definer post-pass
8610:             // cannot segment it.
8611:             "oo::class create C [list method mutate {} { return 1 }]",
8612:             // Inline oo::define is body-bearing but is not a braced definition
8613:             // block accepted by classify_definer_call.
8614:             "oo::class create C {}; oo::define C method mutate {} { return 1 }",
8615:             // Accessor and configuration scripts are deliberately not MethodDef
8616:             // frames, but remain runtime-callable executable bodies.
8617:             "oo::configurable create C { property p -get { return 1 } }",
8618:             "itcl::class C { variable value 0 { return 1 } }",
8619:             // A definition created when an already-extracted method runs is not
8620:             // visited by this source-root post-pass.
8621:             "oo::class create Outer { method install {} { oo::class create Inner { method mutate {} { return 1 } } } }",
8622:             // Definition scripts may invoke ordinary commands; such execution
8623:             // is not represented by a lifted method body.
8624:             "oo::class create C { ::rename ::set ::saved_set }",
8625:         ] {
8626:             let module = lower_to_ir(source, &reg());
8627:             assert!(
8628:                 module.oo_evidence.unretained_executable_roots,
8629:                 "unretained executable definition body was not recorded: {source}"
8630:             );
8631:         }
8632:     }
8633: 
8634:     #[test]
8635:     fn oo_method_nested_proc_not_registered_globally() {
8636:         // A `proc` defined inside a method body is created at
8637:         // method-call time, not script load — it must not leak into
8638:         // `module.procedures` (codegen safety).
8639:         let src = "oo::class create C {\n\
8640:                    \x20   method m {} { proc helper {} { return 1 }; return 2 }\n\
8641:                    }\n\
8642:                    proc toplevel {} { return 3 }\n";
8643:         let m = lower_to_ir(src, &reg());
8644:         assert!(
8645:             fixture_id_if_present(&m.procedures, "::toplevel").is_some(),
8646:             "procs: {:?}",
8647:             m.procedures.keys().collect::<Vec<_>>()
8648:         );
8649:         assert!(
8650:             !fixture_id_if_present(&m.procedures, "::helper").is_some(),
8651:             "nested method proc must not be registered: {:?}",
8652:             m.procedures.keys().collect::<Vec<_>>()
8653:         );
8654:         // The method body still lowered the `proc helper ...` call.
8655:         assert!(
8656:             m.methods
8657:                 .values()
8658:                 .any(|method| method.reporting_label() == "::C::m")
8659:         );
8660:     }
8661: 
8662:     #[test]
8663:     fn apply_body_proc_registers_in_lambda_namespace_not_callers() {
8664:         // `apply`'s body runs in the namespace named by the lambda — or the
8665:         // *global* namespace when none is given — NOT the caller's namespace.
8666:         // So a nested `proc` registers as `::helper`, never `::foo::helper`
8667:         // (Tcl `apply` manual).
8668:         let src = "namespace eval foo {\n\
8669:                    \x20   apply {{} { proc helper {} { return 1 } }}\n\
8670:                    }\n";
8671:         let m = lower_to_ir(src, &reg());
8672:         assert!(
8673:             fixture_id_if_present(&m.procedures, "::helper").is_some(),
8674:             "apply body proc must register in the global namespace: {:?}",
8675:             m.procedures.keys().collect::<Vec<_>>()
8676:         );
8677:         assert!(
8678:             !fixture_id_if_present(&m.procedures, "::foo::helper").is_some(),
8679:             "apply body proc must NOT inherit the caller namespace: {:?}",
8680:             m.procedures.keys().collect::<Vec<_>>()
8681:         );
8682:     }
8683: 
8684:     #[test]
8685:     fn apply_body_proc_uses_explicit_lambda_namespace() {
8686:         // A lambda whose element 2 pins a namespace runs its body there.
8687:         let src = "apply {{} { proc helper {} { return 1 } } ::bar}\n";
8688:         let m = lower_to_ir(src, &reg());
8689:         assert!(
8690:             fixture_id_if_present(&m.procedures, "::bar::helper").is_some(),
8691:             "explicit lambda namespace must be honoured: {:?}",
8692:             m.procedures.keys().collect::<Vec<_>>()
8693:         );
8694:     }
8695: 
8696:     /// TP — a relative lambda namespace element homes against the GLOBAL
8697:     /// namespace even from inside a qualified-name proc (`doc/apply.n`:
8698:     /// "interpreted relative to the global namespace even if its name does
8699:     /// not start with ::"; tclsh 9.0.4 probe `a2b_apply.tcl`). Mirrors the
8700:     /// analyser's `handle_apply_command` so IR and analysis agree.
8701:     #[test]
8702:     fn apply_relative_lambda_namespace_homes_globally_not_to_the_caller() {
8703:         let src = "proc ::caller::p {} { apply {{} { proc helper {} { return 1 } } sub} }\n";
8704:         let m = lower_to_ir(src, &reg());
8705:         assert!(
8706:             fixture_id_if_present(&m.procedures, "::sub::helper").is_some(),
8707:             "relative lambda ns must resolve against ::: {:?}",
8708:             m.procedures.keys().collect::<Vec<_>>()
8709:         );
8710:         assert!(
8711:             !fixture_id_if_present(&m.procedures, "::caller::sub::helper").is_some(),
8712:             "relative lambda ns must NOT pin against the caller: {:?}",
8713:             m.procedures.keys().collect::<Vec<_>>()
8714:         );
8715:     }
8716: 
8717:     #[test]
8718:     fn no_oo_methods_for_plain_script() {
8719:         let m = lower_to_ir("proc greet {} { puts hi }", &reg());
8720:         assert_eq!(m.methods.len(), 0);
8721:         assert_eq!(m.redefined_methods.len(), 0);
8722:     }
8723: 
8724:     #[test]
8725:     fn proc_definition() {
8726:         let m = lower_to_ir("proc greet {name} {puts $name}", &reg());
8727:         // proc emits a Statement::Call + registers a procedure.
8728:         assert!(fixture_id_if_present(&m.procedures, "::greet").is_some());
8729:         let p = m
8730:             .procedures
8731:             .get(&fixture_id(&m.procedures, "::greet"))
8732:             .expect("authored fixture body");
8733:         assert_eq!(p.params, vec!["name"]);
8734:     }
8735: 
8736:     #[test]
8737:     fn if_statement() {
8738:         let m = lower_to_ir("if {1} {set x 1}", &reg());
8739:         assert_eq!(m.top_level.statements.len(), 1);
8740:         assert!(matches!(&m.top_level.statements[0], Statement::If { .. }));
8741:     }
8742: 
8743:     #[test]
8744:     fn logical_structure_does_not_grant_native_compilation() {
8745:         let registry = reg();
8746:         let source = "if {1} {set x 1}";
8747:         let logical = lower_to_ir(source, &registry);
8748:         assert!(matches!(
8749:             logical.top_level.statements.first(),
8750:             Some(Statement::If { .. })
8751:         ));
8752:         let mut native = Lowerer::new(&registry).for_bytecode_backend();
8753:         native.source_entry_origin = SourceEntryOrigin::Driver;
8754:         native.native_compilation.mode =
8755:             tcl_registry::native_compilation::NativeCompilationMode::Direct;
8756:         let emitted = lower_to_ir_with(native, source);
8757:         let Some(Statement::Call {
8758:             tokens: Some(tokens),
8759:             ..
8760:         }) = emitted.top_level.statements.first()
8761:         else {
8762:             panic!(
8763:                 "direct source entry has no admitted native compiler: {:?}",
8764:                 emitted.top_level
8765:             );
8766:         };
8767:         assert!(
8768:             crate::registry_invocation::admitted_native_compiler_invocation(
8769:                 &registry, None, tokens
8770:             )
8771:             .is_none()
8772:         );
8773:     }
8774: 
8775:     #[test]
8776:     fn for_loop() {
8777:         let m = lower_to_ir("for {set i 0} {$i < 10} {incr i} {puts $i}", &reg());
8778:         assert_eq!(m.top_level.statements.len(), 1);
8779:         assert!(matches!(&m.top_level.statements[0], Statement::For { .. }));
8780:     }
8781: 
8782:     #[test]
8783:     fn while_loop() {
8784:         let m = lower_to_ir("while {1} {puts loop}", &reg());
8785:         assert_eq!(m.top_level.statements.len(), 1);
8786:         assert!(matches!(
8787:             &m.top_level.statements[0],
8788:             Statement::While { .. }
8789:         ));
8790:     }
8791: 
8792:     #[test]
8793:     fn foreach_loop() {
8794:         let m = lower_to_ir("foreach x {a b c} {puts $x}", &reg());
8795:         assert_eq!(m.top_level.statements.len(), 1);
8796:         assert!(matches!(
8797:             &m.top_level.statements[0],
8798:             Statement::Foreach { .. }
8799:         ));
8800:     }
8801: 
8802:     #[test]
8803:     fn catch_statement() {
8804:         let m = lower_to_ir("catch {error oops} result", &reg());
8805:         assert_eq!(m.top_level.statements.len(), 1);
8806:         assert!(matches!(
8807:             &m.top_level.statements[0],
8808:             Statement::Catch { .. }
8809:         ));
8810:     }
8811: 
8812:     #[test]
8813:     fn generic_command() {
8814:         let m = lower_to_ir("puts hello", &reg());
8815:         assert_eq!(m.top_level.statements.len(), 1);
8816:         assert!(matches!(
8817:             &m.top_level.statements[0],
8818:             Statement::Call { command, .. } if command == "puts"
8819:         ));
8820:     }
8821: 
8822:     #[test]
8823:     fn multiple_commands() {
8824:         let m = lower_to_ir("set x 1\nset y 2\nputs $x", &reg());
8825:         assert_eq!(m.top_level.statements.len(), 3);
8826:     }
8827: 
8828:     #[test]
8829:     fn return_statement() {
8830:         let m = lower_to_ir("return 42", &reg());
8831:         assert_eq!(m.top_level.statements.len(), 1);
8832:         assert!(matches!(
8833:             &m.top_level.statements[0],
8834:             Statement::Return { value: Some(v), .. } if v == "42"
8835:         ));
8836:     }
8837: 
8838:     #[test]
8839:     fn returned_module_snapshots_retain_their_actual_source_owner() {
8840:         use std::sync::Arc;
8841: 
8842:         let generation = tcl_registry::model::ingress::static_context_for("tcl8.6");
8843:         let context = Arc::new(generation.with_command_store(Arc::clone(generation.commands())));
8844:         let registry = generation.commands();
8845:         let config = tcl_lexer::LexerConfig::for_dialect("tcl8.6");
8846:         let source = "throw ERROR payload";
8847:         for target in 0..3 {
8848:             let mut lowerer = Lowerer::with_config(registry, config)
8849:                 .with_dialect(registry.profile())
8850:                 .with_context_registry(Arc::clone(&context));
8851:             let module = match target {
8852:                 0 => lowerer.lower(source),
8853:                 1 => lowerer.lower_procedure_target(source, "::N"),
8854:                 _ => lowerer.lower_script_target(source, "::N"),
8855:             };
8856:             let owner = module
8857:                 .retained_source_bindings
8858:                 .as_ref()
8859:                 .expect("actual completed source");
8860:             assert_eq!(module.source.bytes(), source.as_bytes());
8861:             assert!(
8862:                 owner.positioned_for_module(module, registry).is_some(),
8863:                 "{target}"
8864:             );
8865:             let mut changed = module.clone();
8866:             changed.source = tcl_lexer::SourceImage::document("throw ERROR changed");
8867:             assert!(owner.positioned_for_module(&changed, registry).is_none());
8868:             let mut changed = module.clone();
8869:             changed.lexer_config.strict_quoting = !changed.lexer_config.strict_quoting;
8870:             assert!(owner.positioned_for_module(&changed, registry).is_none());
8871:         }
8872:     }
8873: 
8874:     #[test]
8875:     fn lower_to_ir_public_api() {
8876:         let r = reg();
8877:         let m = lower_to_ir("set x 1\nproc foo {} {return 1}", &r);
8878:         assert_eq!(m.top_level.statements.len(), 2);
8879:         assert!(fixture_id_if_present(&m.procedures, "::foo").is_some());
8880:     }
8881: 
8882:     // A proc body homes nested definitions to the proc's *defining*
8883:     // namespace, not the lexical namespace of the `proc` call.
8884: 
8885:     #[test]
8886:     fn configured_source_ingress_retains_one_input_for_entry_and_module() {
8887:         let registry = tcl_registry::model::ingress::static_context_for("tcl8.6").commands();
8888:         let profile = registry.profile().unwrap();
8889:         let config = tcl_lexer::LexerConfig::from_grammar(profile.grammar);
8890:         let source = "proc f {p} {return $p}";
8891:         let module = lower_to_ir_with_dialect(source, registry, config, Some(profile));
8892:         let input = module
8893:             .source_metadata_input
8894:             .as_ref()
8895:             .expect("actual configured source input");
8896:         assert_eq!(
8897:             module.source_entry.metadata_context.source_analysis_input(),
8898:             Some(input)
8899:         );
8900:         assert!(module.source_entry.logical_source_input.is_none());
8901:         assert_eq!(
8902:             module
8903:                 .source_entry
8904:                 .options()
8905:                 .execution_name_policy()
8906:                 .unwrap()
8907:                 .native_recipe()
8908:                 .unwrap()
8909:                 .authority(),
8910:             tcl_syntax::naming::NamePolicyAuthority::AuthoredSimulation
8911:         );
8912:         assert!(module.source_entry.native_entry.is_none());
8913:         assert!(
8914:             module
8915:                 .retained_source_bindings
8916:                 .as_ref()
8917:                 .unwrap()
8918:                 .matches_module(&module, registry)
8919:         );
8920:         let procedures = module.procedures.iter().collect::<Vec<_>>();
8921:         assert_eq!(procedures.len(), 1);
8922:         assert!(module.procedure_ids.owns(*procedures[0].0));
8923:         assert_eq!(procedures[0].1.qualified_name, "::f");
8924:     }
8925: 
8926:     #[test]
8927:     fn original_name_operand_publishes_a_body_without_borrowing_the_head_lookup() {
8928:         let registry = tcl_registry::model::ingress::static_context_for("tcl8.6").commands();
8929:         let profile = registry.profile().unwrap();
8930:         let source = r#"proc f {p} {set b [set {$p}]; set a 1; set a 2; return "$a$b"}"#;
8931:         let module = lower_to_ir_with_dialect(
8932:             source,
8933:             registry,
8934:             tcl_lexer::LexerConfig::from_grammar(profile.grammar),
8935:             Some(profile),
8936:         );
8937:         let procedures = module.procedures.iter().collect::<Vec<_>>();
8938:         assert_eq!(procedures.len(), 1);
8939:         let (id, procedure) = procedures[0];
8940:         assert!(module.procedure_ids.owns(*id));
8941:         assert_eq!(procedure.qualified_name, "::f");
8942:         let tokens = module
8943:             .top_level
8944:             .statements
8945:             .iter()
8946:             .find_map(Statement::tokens)
8947:             .expect("the actual original declaration command");
8948:         let binding = tokens
8949:             .source_binding
8950:             .as_ref()
8951:             .expect("original source binding");
8952:         let input = binding
8953:             .original_written_name_input(tokens, 1)
8954:             .expect("actual original name operand");
8955:         assert!(
8956:             binding.original_command_lookup(tokens, &input).is_none(),
8957:             "an operand cannot replace the original command-head owner"
8958:         );
8959:         assert!(module.source_entry.native_entry.is_none());
8960:         assert_eq!(
8961:             procedure.declaration_site.as_ref(),
8962:             binding.invocation_site()
8963:         );
8964:         let head = binding
8965:             .original_written_name_input(tokens, 0)
8966:             .expect("actual original declaration head");
8967:         assert_eq!(head.bytes(), b"proc");
8968:         assert_eq!(input.bytes(), b"f");
8969:         assert_ne!(
8970:             head.original_word_key().unwrap().original_word(),
8971:             input.original_word_key().unwrap().original_word()
8972:         );
8973:         let crate::signature_scan::scope::SignatureSourceNameInput::OriginalWord(key) = &input
8974:         else {
8975:             panic!("original literal name word");
8976:         };
8977:         assert_eq!(
8978:             key.policy().authority(),
8979:             tcl_syntax::naming::NamePolicyAuthority::AuthoredSimulation
8980:         );
8981:         if let Some(scope) = binding.original_operand_naming_scope(&input) {
8982:             assert_eq!(
8983:                 procedure.publication.as_ref(),
8984:                 crate::signature_scan::scope::SignatureSourceCommand::procedure_from_key(
8985:                     &scope, key
8986:                 )
8987:                 .as_ref()
8988:             );
8989:         } else {
8990:             assert!(procedure.publication.is_none());
8991:         }
8992:     }
8993: 
8994:     #[test]
8995:     fn proc_body_namespace_peels_the_names_own_qualifier() {
8996:         // Unit-level: the helper is the inverse of `qualify_proc_name`.
8997:         assert_eq!(proc_body_namespace("::a::outer", "::"), "::a");
8998:         assert_eq!(proc_body_namespace("::b::c::o2", "::"), "::b::c");
8999:         assert_eq!(proc_body_namespace("::plain", "::ignored"), "::");
9000:         // A bare (unrooted) key can't come out of `qualify_proc_name`, but the
9001:         // fallback must not manufacture an empty namespace if it ever did.
9002:         assert_eq!(proc_body_namespace("plain", "::lex"), "::lex");
9003:     }
9004: 
9005:     #[test]
9006:     fn nested_proc_homes_to_the_outer_procs_defining_namespace() {
9007:         // TP. On tclsh 9.0.4 and 8.6.16, identically:
9008:         //   namespace eval ::a {}
9009:         //   proc a::outer {} { proc helper {x} {return $x} }
9010:         //   a::outer ; info commands ::a::helper   -> ::a::helper
9011:         //              info commands ::helper      -> {}
9012:         let m = lower_to_ir(
9013:             "namespace eval ::a {}\nproc a::outer {} { proc helper {x} { return $x } }\n",
9014:             &reg(),
9015:         );
9016:         assert!(
9017:             fixture_id_if_present(&m.procedures, "::a::helper").is_some(),
9018:             "nested proc must home to ::a, got {:?}",
9019:             m.procedures.keys().collect::<Vec<_>>(),
9020:         );
9021:         assert!(
9022:             !fixture_id_if_present(&m.procedures, "::helper").is_some(),
9023:             "nested proc must NOT home lexically to ::",
9024:         );
9025:     }
9026: 
9027:     #[test]
9028:     fn nested_proc_homing_composes_through_three_levels() {
9029:         // TP. On tclsh, `proc g::o7 {} { proc o7b {} { proc h7 {u} … } }` →
9030:         // running `g::o7` then `::g::o7b` leaves `::g::h7` (never `::h7`).
9031:         let m = lower_to_ir(
9032:             "namespace eval ::g {}\nproc g::o7 {} { proc o7b {} { proc h7 {u} { return $u } } }\n",
9033:             &reg(),
9034:         );
9035:         assert!(fixture_id_if_present(&m.procedures, "::g::o7b").is_some());
9036:         assert!(
9037:             fixture_id_if_present(&m.procedures, "::g::h7").is_some(),
9038:             "third level must stay in ::g, got {:?}",
9039:             m.procedures.keys().collect::<Vec<_>>(),
9040:         );
9041:         assert!(!fixture_id_if_present(&m.procedures, "::h7").is_some());
9042:     }
9043: 
9044:     #[test]
9045:     fn nested_proc_name_qualifier_beats_the_lexical_namespace_eval() {
9046:         // TP. On tclsh, inside `namespace eval ::d`, `proc ::e::o3` still homes
9047:         // its body to `::e` — `::e::h3` exists, `::d::h3` and `::h3` do not.
9048:         let m = lower_to_ir(
9049:             "namespace eval ::e {}\nnamespace eval ::d {\n    proc ::e::o3 {} { proc h3 {z} { return $z } }\n}\n",
9050:             &reg(),
9051:         );
9052:         assert!(
9053:             fixture_id_if_present(&m.procedures, "::e::h3").is_some(),
9054:             "got {:?}",
9055:             m.procedures.keys().collect::<Vec<_>>(),
9056:         );
9057:         assert!(!fixture_id_if_present(&m.procedures, "::d::h3").is_some());
9058:         assert!(!fixture_id_if_present(&m.procedures, "::h3").is_some());
9059:     }
9060: 
9061:     #[test]
9062:     fn unqualified_outer_proc_leaves_nested_homing_unchanged() {
9063:         // TN. The common shape: lexical and defining namespace agree, so
9064:         // homing changes nothing. Both at top level…
9065:         let m = lower_to_ir("proc outer {} { proc inner {} { return 1 } }\n", &reg());
9066:         assert!(fixture_id_if_present(&m.procedures, "::inner").is_some());
9067:         // …and inside a `namespace eval`, where both are `::ns`.
9068:         let m = lower_to_ir(
9069:             "namespace eval ::ns {\n    proc outer {} { proc inner {} { return 1 } }\n}\n",
9070:             &reg(),
9071:         );
9072:         assert!(
9073:             fixture_id_if_present(&m.procedures, "::ns::inner").is_some(),
9074:             "got {:?}",
9075:             m.procedures.keys().collect::<Vec<_>>(),
9076:         );
9077:     }
9078: 
9079:     #[test]
9080:     fn absolutely_named_nested_proc_is_unaffected() {
9081:         // TN. On tclsh, `proc a::outer4 {} { proc ::abs {q} … }` creates `::abs`
9082:         // — an absolute inner name ignores the enclosing frame entirely.
9083:         let m = lower_to_ir(
9084:             "namespace eval ::a {}\nproc a::outer4 {} { proc ::abs {q} { return $q } }\n",
9085:             &reg(),
9086:         );
9087:         assert!(fixture_id_if_present(&m.procedures, "::abs").is_some());
9088:         assert!(!fixture_id_if_present(&m.procedures, "::a::abs").is_some());
9089:     }
9090: 
9091:     #[test]
9092:     fn original_formal_name_headers_use_selected_grammar_and_keep_activation_separate() {
9093:         // naming.variable.original-readonly-formal-topology
9094:         // docs/design/analysis/name-resolution-proofs/original-readonly-formal-topology.md
9095:         let tcl = Some(tcl_dialect::ParameterGrammar::Tcl);
9096:         let jim = Some(tcl_dialect::ParameterGrammar::Jim);
9097:         assert_eq!(parse_formal_param_names("{a::b}", FOLD_RULES, tcl), None);
9098:         assert_eq!(
9099:             parse_formal_param_names("{a::b}", LITERAL_RULES, jim),
9100:             Some(vec!["a::b".to_owned()])
9101:         );
9102:         assert_eq!(parse_formal_param_names("{a(1)}", FOLD_RULES, tcl), None);
9103:         assert_eq!(
9104:             parse_formal_param_names("{a(1)}", LITERAL_RULES, jim),
9105:             Some(vec!["a(1)".to_owned()])
9106:         );
9107:         // Name-only headers retain original link spelling. They cannot claim
9108:         // the ordinary local storage name or manufacture a caller-link frame.
9109:         assert_eq!(
9110:             parse_formal_param_names("&a {&b default}", LITERAL_RULES, jim),
9111:             Some(vec!["&a".to_owned(), "&b".to_owned()])
9112:         );
9113:         assert_eq!(
9114:             parse_formal_param_names("args args", LITERAL_RULES, jim),
9115:             None
9116:         );
9117:         assert_eq!(
9118:             parse_formal_param_names("args args", FOLD_RULES, tcl),
9119:             Some(vec!["args".to_owned(), "args".to_owned()])
9120:         );
9121:         assert_eq!(parse_formal_param_names("a b", FOLD_RULES, None), None);
9122:     }
9123: 
9124:     #[test]
9125:     fn formal_param_names_take_the_specifier_name_only() {
9126:         assert_eq!(
9127:             parse_formal_param_names(
9128:                 "a b c",
9129:                 FOLD_RULES,
9130:                 Some(tcl_dialect::ParameterGrammar::Tcl)
9131:             )
9132:             .unwrap(),
9133:             vec!["a", "b", "c"],
9134:         );
9135:         assert_eq!(
9136:             parse_formal_param_names(
9137:                 "{x default} y",
9138:                 FOLD_RULES,
9139:                 Some(tcl_dialect::ParameterGrammar::Tcl)
9140:             )
9141:             .unwrap(),
9142:             vec!["x", "y"]
9143:         );
9144:         assert_eq!(
9145:             parse_formal_param_names("", FOLD_RULES, Some(tcl_dialect::ParameterGrammar::Tcl))
9146:                 .unwrap(),
9147:             [] as [std::string::String; 0]
9148:         );
9149:         // A wrapped parameter list collapses its continuation before splitting.
9150:         assert_eq!(
9151:             parse_formal_param_names(
9152:                 "a b\\\n    c",
9153:                 FOLD_RULES,
9154:                 Some(tcl_dialect::ParameterGrammar::Tcl)
9155:             )
9156:             .unwrap(),
9157:             vec!["a", "b", "c"]
9158:         );
9159:     }
9160: 
9161:     #[test]
9162:     fn formal_param_names_reject_what_tcl_rejects() {
9163:         // Tcl refuses to create these procedures, so lowering declines too.
9164:         assert_eq!(
9165:             parse_formal_param_names(
9166:                 "{a b c}",
9167:                 FOLD_RULES,
9168:                 Some(tcl_dialect::ParameterGrammar::Tcl)
9169:             ),
9170:             None
9171:         );
9172:         assert_eq!(
9173:             parse_formal_param_names(
9174:                 "{a::b}",
9175:                 FOLD_RULES,
9176:                 Some(tcl_dialect::ParameterGrammar::Tcl)
9177:             ),
9178:             None
9179:         );
9180:         assert_eq!(
9181:             parse_formal_param_names(
9182:                 "{a(1)}",
9183:                 FOLD_RULES,
9184:                 Some(tcl_dialect::ParameterGrammar::Tcl)
9185:             ),
9186:             None
9187:         );
9188:         assert_eq!(
9189:             parse_formal_param_names("{a", FOLD_RULES, Some(tcl_dialect::ParameterGrammar::Tcl)),
9190:             None
9191:         );
9192:     }
9193: 
9194:     #[test]
9195:     fn var_list_names_keep_grouped_elements_whole() {
9196:         assert_eq!(
9197:             parse_var_list_names("a b", FOLD_RULES).unwrap(),
9198:             vec!["a", "b"]
9199:         );
9200:         // tclsh 9.0: both spellings bind the one variable named `a b`.
9201:         assert_eq!(
9202:             parse_var_list_names("{a b}", FOLD_RULES).unwrap(),
9203:             vec!["a b"]
9204:         );
9205:         assert_eq!(
9206:             parse_var_list_names("a\\ b", FOLD_RULES).unwrap(),
9207:             vec!["a b"]
9208:         );
9209:         assert_eq!(
9210:             parse_var_list_names("", FOLD_RULES).unwrap(),
9211:             [] as [std::string::String; 0]
9212:         );
9213:         assert_eq!(
9214:             parse_var_list_names("a b\\\n    c", FOLD_RULES).unwrap(),
9215:             vec!["a", "b", "c"]
9216:         );
9217:         // Unbalanced — no binding can be named, so the caller barriers.
9218:         assert_eq!(parse_var_list_names("{a", FOLD_RULES), None);
9219:     }
9220: 
9221:     // A formal-parameter list has two list levels, so a grouped or escaped
9222:     // specifier is one parameter, not one name per whitespace run:
9223:     // `proc p {a\ b} {}` has arity one.
9224: 
9225:     /// Parameter names recorded for `::p` when `src` is lowered.
9226:     fn proc_params(src: &str) -> Vec<String> {
9227:         let m = lower_to_ir(src, &reg());
9228:         fixture_id_if_present(&m.procedures, "::p")
9229:             .and_then(|id| m.procedures.get(&id))
9230:             .unwrap_or_else(|| panic!("::p registered for {src:?}"))
9231:             .params
9232:             .clone()
9233:     }
9234: 
9235:     #[test]
9236:     fn escaped_space_proc_param_is_one_parameter() {
9237:         // tclsh 9.0: `proc p {a\ b} {}` → `info args p` is `a`, with
9238:         // `info default p a` yielding `b`. Only the name reaches the IR, so
9239:         // the arity is one, not two (`a\` and `b`).
9240:         assert_eq!(proc_params("proc p {a\\ b} {}"), vec!["a"]);
9241:         // The grouped spelling decodes identically.
9242:         assert_eq!(proc_params("proc p {{a b}} {}"), vec!["a"]);
9243:     }
9244: 
9245:     #[test]
9246:     fn proc_params_keep_defaults_and_args_as_names() {
9247:         // FP-guard: `{x {y 2} args}` is still the three parameters `x`, `y`,
9248:         // and the variadic `args`.
9249:         assert_eq!(
9250:             proc_params("proc p {x {y 2} args} {}"),
9251:             vec!["x", "y", "args"]
9252:         );
9253:         assert_eq!(proc_params("proc p {} {}"), [] as [std::string::String; 0]);
9254:     }
9255: 
9256:     #[test]
9257:     fn proc_params_tcl_rejects_fall_through_to_barrier() {
9258:         // tclsh: `proc p {{a b c}} {}` → "too many fields in argument
9259:         // specifier". No procedure is created, so lowering registers none and
9260:         // leaves the runtime `proc` to report it.
9261:         for src in [
9262:             "proc p {{a b c}} {}",
9263:             "proc p {a::b} {}",
9264:             "proc p {a(1)} {}",
9265:         ] {
9266:             let m = lower_to_ir(src, &reg());
9267:             assert!(
9268:                 !fixture_id_if_present(&m.procedures, "::p").is_some(),
9269:                 "no ::p for {src:?}: {:?}",
9270:                 m.procedures.keys().collect::<Vec<_>>(),
9271:             );
9272:             assert!(
9273:                 matches!(&m.top_level.statements[0], Statement::Barrier { reason, .. } if reason == "malformed proc params"),
9274:                 "expected a malformed-params barrier for {src:?}, got {:?}",
9275:                 m.top_level.statements[0],
9276:             );
9277:         }
9278:     }
9279: 
9280:     #[test]
9281:     fn oo_method_params_use_the_formal_parameter_grammar() {
9282:         let m = lower_to_ir(
9283:             "oo::class create C {\n    method m {a\\ b {c 1}} { return 1 }\n}\n",
9284:             &reg(),
9285:         );
9286:         let method = fixture_method(&m.methods, "::C::m").unwrap_or_else(|| {
9287:             panic!(
9288:                 "::C::m lowered, got {:?}",
9289:                 m.methods.keys().collect::<Vec<_>>()
9290:             )
9291:         });
9292:         assert_eq!(method.params, vec!["a", "c"]);
9293:         // A parameter list Tcl rejects makes the whole class unanalysable.
9294:         let m = lower_to_ir(
9295:             "oo::class create C {\n    method m {{a b c}} { return 1 }\n}\n",
9296:             &reg(),
9297:         );
9298:         assert!(m.oo_unanalysed_classes.contains("::C"), "{m:?}");
9299:         assert!(
9300:             !m.methods
9301:                 .values()
9302:                 .any(|method| method.reporting_label() == "::C::m")
9303:         );
9304:     }
9305: 
9306:     #[test]
9307:     fn qualify_proc_name_global() {
9308:         assert_eq!(qualify_proc_name("::", "foo"), "::foo");
9309:     }
9310: 
9311:     #[test]
9312:     fn qualify_proc_name_nested() {
9313:         assert_eq!(qualify_proc_name("::ns", "bar"), "::ns::bar");
9314:     }
9315: 
9316:     #[test]
9317:     fn qualify_proc_name_already_qualified() {
9318:         assert_eq!(qualify_proc_name("::ns", "::abs"), "::abs");
9319:     }
9320: 
9321:     #[test]
9322:     fn qualify_proc_name_preserves_colon_named_namespace_keys() {
9323:         assert_eq!(qualify_proc_name(":::", ":"), "::::::");
9324:         assert_eq!(qualify_proc_name("::a", "a:::b"), "::a::a::b");
9325:         assert_eq!(tcl_syntax::naming::key_holder_and_tail("::::::").0, ":::");
9326:     }
9327: 
9328:     #[test]
9329:     fn parse_uplevel_level_decimal() {
9330:         let relative = |shift| {
9331:             Some(UplevelLevel {
9332:                 shift,
9333:                 absolute: false,
9334:             })
9335:         };
9336:         assert_eq!(parse_uplevel_level("1"), relative(1));
9337:         assert_eq!(parse_uplevel_level("3"), relative(3));
9338:         assert_eq!(parse_uplevel_level("0"), relative(0));
9339:     }
9340: 
9341:     #[test]
9342:     fn parse_uplevel_level_hash_form() {
9343:         let absolute = |shift| {
9344:             Some(UplevelLevel {
9345:                 shift,
9346:                 absolute: true,
9347:             })
9348:         };
9349:         assert_eq!(parse_uplevel_level("#0"), absolute(0));
9350:         assert_eq!(parse_uplevel_level("#3"), absolute(3));
9351:     }
9352: 
9353:     #[test]
9354:     fn parse_uplevel_level_zero_keeps_absolute_and_relative_apart() {
9355:         // `uplevel #0` runs the body in the global frame; `uplevel 0` runs it
9356:         // in the current frame. Both carry the magnitude 0, so only the
9357:         // `absolute` flag tells them apart — conflating them miscompiled the
9358:         // command-word namespace of every `uplevel 0` body.
9359:         let hash_zero = parse_uplevel_level("#0").expect("#0 parses");
9360:         let bare_zero = parse_uplevel_level("0").expect("0 parses");
9361:         assert_eq!(hash_zero.shift, bare_zero.shift);
9362:         assert!(hash_zero.absolute);
9363:         assert!(!bare_zero.absolute);
9364:         assert_ne!(hash_zero, bare_zero);
9365:     }
9366: 
9367:     #[test]
9368:     fn parse_uplevel_level_dynamic_returns_none() {
9369:         assert_eq!(parse_uplevel_level("$lvl"), None);
9370:         assert_eq!(parse_uplevel_level("[expr {1+1}]"), None);
9371:         assert_eq!(parse_uplevel_level("foo"), None);
9372:     }
9373: 
9374:     #[test]
9375:     fn uplevel_static_body_no_level() {
9376:         let m = lower_to_ir("uplevel {set x 1}", &reg());
9377:         assert_eq!(m.top_level.statements.len(), 1);
9378:         match &m.top_level.statements[0] {
9379:             Statement::UpFrame {
9380:                 frame_shift, body, ..
9381:             } => {
9382:                 assert_eq!(*frame_shift, 1);
9383:                 assert_eq!(body.statements.len(), 1);
9384:             }
9385:             other => panic!("expected UpFrame, got {other:?}"),
9386:         }
9387:     }
9388: 
9389:     #[test]
9390:     fn uplevel_static_body_with_level_one() {
9391:         let m = lower_to_ir("uplevel 1 {set x 1}", &reg());
9392:         match &m.top_level.statements[0] {
9393:             Statement::UpFrame {
9394:                 frame_shift,
9395:                 absolute,
9396:                 ..
9397:             } => {
9398:                 assert_eq!(*frame_shift, 1);
9399:                 assert!(!*absolute, "`uplevel 1` is the relative form");
9400:             }
9401:             other => panic!("expected UpFrame, got {other:?}"),
9402:         }
9403:     }
9404: 
9405:     #[test]
9406:     fn uplevel_static_body_with_hash_zero() {
9407:         let m = lower_to_ir("uplevel #0 {set x 1}", &reg());
9408:         match &m.top_level.statements[0] {
9409:             Statement::UpFrame {
9410:                 frame_shift,
9411:                 absolute,
9412:                 ..
9413:             } => {
9414:                 assert_eq!(*frame_shift, 0);
9415:                 assert!(*absolute, "`uplevel #0` is the absolute global form");
9416:             }
9417:             other => panic!("expected UpFrame for #0, got {other:?}"),
9418:         }
9419:     }
9420: 
9421:     #[test]
9422:     fn uplevel_static_body_with_bare_zero_is_relative() {
9423:         // `uplevel 0 {body}` evaluates the body in the *current* frame, not
9424:         // the global one. It shares the magnitude 0 with `#0` and is told
9425:         // apart only by `absolute`.
9426:         let m = lower_to_ir("uplevel 0 {set x 1}", &reg());
9427:         match &m.top_level.statements[0] {
9428:             Statement::UpFrame {
9429:                 frame_shift,
9430:                 absolute,
9431:                 ..
9432:             } => {
9433:                 assert_eq!(*frame_shift, 0);
9434:                 assert!(!*absolute, "`uplevel 0` is the relative current-frame form");
9435:             }
9436:             other => panic!("expected UpFrame for bare 0, got {other:?}"),
9437:         }
9438:     }
9439: 
9440:     #[test]
9441:     fn uplevel_dynamic_body_falls_back_to_default() {
9442:         // ``uplevel 1 $body`` body is a $var, not a brace literal —
9443:         // can't be statically resolved without const-propagation.
9444:         // Falls back to ``lower_default`` (Statement::Call).
9445:         let m = lower_to_ir("uplevel 1 $body", &reg());
9446:         assert!(matches!(
9447:             m.top_level.statements[0],
9448:             Statement::Call { .. } | Statement::Barrier { .. }
9449:         ));
9450:     }
9451: 
9452:     #[test]
9453:     fn uplevel_dynamic_level_falls_back_to_default() {
9454:         // ``uplevel $lvl {body}`` — level is dynamic, can't pick a
9455:         // ``frame_shift``. Falls back to default lowering.
9456:         let m = lower_to_ir("uplevel $lvl {set x 1}", &reg());
9457:         assert!(matches!(
9458:             m.top_level.statements[0],
9459:             Statement::Call { .. } | Statement::Barrier { .. }
9460:         ));
9461:     }
9462: 
9463:     #[test]
9464:     fn const_prop_uplevel_resolves_set_var_body() {
9465:         // ``set body {set x 1}; uplevel 1 $body`` inside a
9466:         // proc — the const-map records ``body`` and the uplevel
9467:         // folds in the literal as an UpFrame.
9468:         let m = lower_to_ir("proc f {} { set body {set x 1}\n uplevel 1 $body }", &reg());
9469:         let proc = fixture_id_if_present(&m.procedures, "::f")
9470:             .and_then(|id| m.procedures.get(&id))
9471:             .expect("proc registered");
9472:         // proc body: [AssignConst(body), UpFrame { body: [...] }]
9473:         let last = proc.body.statements.last().expect("body has statements");
9474:         match last {
9475:             Statement::UpFrame { body, .. } => {
9476:                 assert!(!body.statements.is_empty(), "expected lowered body");
9477:             }
9478:             other => panic!("expected UpFrame, got {other:?}"),
9479:         }
9480:     }
9481: 
9482:     #[test]
9483:     fn const_prop_eval_resolves_set_var_body() {
9484:         // ``eval $body`` with const-mapped body folds to a
9485:         // Statement::Block.
9486:         let m = lower_to_ir("proc f {} { set body {set x 1}\n eval $body }", &reg());
9487:         let proc = fixture_id_if_present(&m.procedures, "::f")
9488:             .and_then(|id| m.procedures.get(&id))
9489:             .expect("proc registered");
9490:         let last = proc.body.statements.last().expect("body has statements");
9491:         match last {
9492:             Statement::Block { body, .. } => {
9493:                 assert!(!body.statements.is_empty(), "expected lowered block");
9494:             }
9495:             other => panic!("expected Block, got {other:?}"),
9496:         }
9497:     }
9498: 
9499:     #[test]
9500:     fn const_prop_eval_brace_body_emits_block() {
9501:         // ``eval {body}`` in a proc context lowers to Block.
9502:         let m = lower_to_ir("proc f {} { eval {set x 1} }", &reg());
9503:         let proc = fixture_id_if_present(&m.procedures, "::f")
9504:             .and_then(|id| m.procedures.get(&id))
9505:             .expect("proc registered");
9506:         assert!(matches!(proc.body.statements[0], Statement::Block { .. }));
9507:     }
9508: 
9509:     #[test]
9510:     fn const_prop_disabled_at_top_level() {
9511:         // The const-map is gated on ``proc_depth > 0``. At
9512:         // top-level, ``set body {set x 1}; uplevel 1 $body``
9513:         // does NOT relax — the uplevel falls back to default
9514:         // dispatch (Call / Barrier).
9515:         let m = lower_to_ir("set body {set x 1}\nuplevel 1 $body", &reg());
9516:         // statements[0] = AssignConst(body), [1] = uplevel call
9517:         assert!(matches!(
9518:             m.top_level.statements[1],
9519:             Statement::Call { .. } | Statement::Barrier { .. }
9520:         ));
9521:     }
9522: 
9523:     #[test]
9524:     fn const_prop_invalidated_on_reassignment() {
9525:         // ``set body {a}; set body $other; uplevel 1 $body`` — the
9526:         // second ``set`` invalidates the binding (RHS is a $var,
9527:         // not a brace literal), so the uplevel can't fold.
9528:         let m = lower_to_ir(
9529:             "proc f {} { set body {a}\n set body $other\n uplevel 1 $body }",
9530:             &reg(),
9531:         );
9532:         let proc = fixture_id_if_present(&m.procedures, "::f")
9533:             .and_then(|id| m.procedures.get(&id))
9534:             .expect("proc registered");
9535:         let last = proc.body.statements.last().expect("body");
9536:         assert!(
9537:             !matches!(last, Statement::UpFrame { .. }),
9538:             "expected fallback after re-assignment, got {last:?}",
9539:         );
9540:     }
9541: 
9542:     #[test]
9543:     fn const_prop_eval_list_literal() {
9544:         // ``eval [list set x 42]`` recognised as static body.
9545:         let m = lower_to_ir("proc f {} { eval [list set x 42] }", &reg());
9546:         let proc = fixture_id_if_present(&m.procedures, "::f")
9547:             .and_then(|id| m.procedures.get(&id))
9548:             .expect("proc registered");
9549:         assert!(matches!(proc.body.statements[0], Statement::Block { .. }));
9550:     }
9551: 
9552:     #[test]
9553:     fn const_prop_eval_list_with_dynamic_arg_rejected() {
9554:         // ``eval [list set x $v]`` — dynamic ``\$v`` rejects the
9555:         // list-literal shape. Falls back to runtime barrier.
9556:         let m = lower_to_ir("proc f {} { eval [list set x $v] }", &reg());
9557:         let proc = fixture_id_if_present(&m.procedures, "::f")
9558:             .and_then(|id| m.procedures.get(&id))
9559:             .expect("proc registered");
9560:         assert!(!matches!(proc.body.statements[0], Statement::Block { .. }));
9561:     }
9562: 
9563:     #[test]
9564:     fn const_prop_eval_non_list_command_rejected() {
9565:         // ``eval [foo arg]`` — inner command isn't ``list``;
9566:         // can't synthesise a body. Falls back to runtime barrier.
9567:         let m = lower_to_ir("proc f {} { eval [foo arg] }", &reg());
9568:         let proc = fixture_id_if_present(&m.procedures, "::f")
9569:             .and_then(|id| m.procedures.get(&id))
9570:             .expect("proc registered");
9571:         assert!(!matches!(proc.body.statements[0], Statement::Block { .. }));
9572:     }
9573: 
9574:     #[test]
9575:     fn const_prop_does_not_leak_into_nested_proc() {
9576:         // A ``set body {literal}`` in the outer proc must
9577:         // NOT appear to a nested ``proc inner``'s
9578:         // barrier-relaxation gate as a tracked literal.
9579:         let m = lower_to_ir(
9580:             "proc outer {} {\n  set body {set x 1}\n  proc inner {} { uplevel 1 $body }\n}",
9581:             &reg(),
9582:         );
9583:         let inner = fixture_id_if_present(&m.procedures, "::inner")
9584:             .and_then(|id| m.procedures.get(&id))
9585:             .expect("inner registered");
9586:         // The inner uplevel must remain a Call/Barrier — NOT an
9587:         // UpFrame. If the const-map leaked, the inner body would
9588:         // be folded as UpFrame { body: [set x 1], .. }.
9589:         let last = inner.body.statements.last().expect("body");
9590:         assert!(
9591:             !matches!(last, Statement::UpFrame { .. }),
9592:             "outer scope's const-map must not leak into nested proc, got {last:?}",
9593:         );
9594:     }
9595: 
9596:     #[test]
9597:     fn ns_import_recorded_with_context_namespace() {
9598:         // ``namespace import ::tcltest::*`` at top-level
9599:         // records (``::``, ``::tcltest::*``).
9600:         let m = lower_to_ir("namespace import ::tcltest::*", &reg());
9601:         assert_eq!(
9602:             m.namespace_imports,
9603:             vec![("::".to_string(), "::tcltest::*".to_string())]
9604:         );
9605:     }
9606: 
9607:     #[test]
9608:     fn ns_import_retains_relative_dependency_pattern() {
9609:         let m = lower_to_ir("namespace import foo::*", &reg());
9610:         assert_eq!(
9611:             m.namespace_imports,
9612:             vec![("::".to_owned(), "foo::*".to_owned())]
9613:         );
9614:     }
9615: 
9616:     #[test]
9617:     fn ns_import_dependencies_preserve_selected_literal_patterns_and_order() {
9618:         let m = lower_to_ir("namespace import foo::* ::* ::::* ::foo::* foo::*", &reg());
9619:         assert_eq!(
9620:             m.namespace_imports,
9621:             ["foo::*", "::*", "::::*", "::foo::*", "foo::*"]
9622:                 .into_iter()
9623:                 .map(|pattern| ("::".to_owned(), pattern.to_owned()))
9624:                 .collect::<Vec<_>>()
9625:         );
9626:         let shadowed = lower_to_ir(
9627:             "proc namespace args {}; namespace import foo::* ::foo::*",
9628:             &reg(),
9629:         );
9630:         assert!(shadowed.namespace_imports.is_empty());
9631:     }
9632: 
9633:     #[test]
9634:     fn ns_import_handles_force_flag() {
9635:         // ``-force`` is the documented option; the next word is
9636:         // the pattern.
9637:         let m = lower_to_ir("namespace import -force ::tcltest::*", &reg());
9638:         assert_eq!(
9639:             m.namespace_imports,
9640:             vec![("::".to_string(), "::tcltest::*".to_string())]
9641:         );
9642:     }
9643: 
9644:     #[test]
9645:     fn proc_dynamic_name_resolved_via_const_map() {
9646:         // ``set name {Verbose}; proc \$name {} { ... }``
9647:         // inside a proc — ``name`` is in the const-map, so the
9648:         // inner proc registers as ``::Verbose``.
9649:         let m = lower_to_ir(
9650:             "proc factory {} { set name {Verbose}\n proc $name {} { puts hi } }",
9651:             &reg(),
9652:         );
9653:         assert!(
9654:             fixture_id_if_present(&m.procedures, "::Verbose").is_some(),
9655:             "expected ::Verbose in {:?}",
9656:             m.procedures.keys().collect::<Vec<_>>()
9657:         );
9658:     }
9659: 
9660:     #[test]
9661:     fn proc_dynamic_name_no_binding_stays_barrier() {
9662:         // ``proc \$name`` with no const-map entry — bail to barrier.
9663:         let m = lower_to_ir("proc factory {} { proc $name {} { puts hi } }", &reg());
9664:         let factory = fixture_id_if_present(&m.procedures, "::factory")
9665:             .and_then(|id| m.procedures.get(&id))
9666:             .expect("factory registered");
9667:         let last = factory.body.statements.last().expect("body");
9668:         assert!(
9669:             matches!(last, Statement::Barrier { .. }),
9670:             "expected Barrier, got {last:?}"
9671:         );
9672:     }
9673: 
9674:     #[test]
9675:     fn proc_with_trailing_colons_routes_through_barrier() {
9676:         // Tcl 9 ``proc ::ns:: {args} {body}`` registers a command
9677:         // named ``""`` inside ``::ns``.  Static normalisation would
9678:         // strip the trailing ``::`` and register the proc under the
9679:         // namespace name itself — wrong cmd.  Route through
9680:         // Statement::Barrier so the runtime ``proc`` builtin handles
9681:         // the registration.
9682:         let m = lower_to_ir("proc ::ns:: {a b} { puts $a$b }", &reg());
9683:         // No procedure entry should have been AOT-registered under
9684:         // ``::ns`` (which is what the bug would produce) or any
9685:         // empty-key variant.
9686:         assert!(
9687:             !fixture_id_if_present(&m.procedures, "::ns").is_some()
9688:                 && !fixture_id_if_present(&m.procedures, "::ns::").is_some()
9689:                 && !fixture_id_if_present(&m.procedures, "").is_some(),
9690:             "trailing-:: proc should not be AOT-registered; got {:?}",
9691:             m.procedures.keys().collect::<Vec<_>>()
9692:         );
9693:         // The top-level statement should be a Barrier with the
9694:         // empty-simple-name reason.
9695:         let top = m
9696:             .top_level
9697:             .statements
9698:             .last()
9699:             .expect("at least one top-level statement");
9700:         match top {
9701:             Statement::Barrier {
9702:                 reason, command, ..
9703:             } => {
9704:                 assert_eq!(command, "proc");
9705:                 assert!(
9706:                     reason.contains("empty-simple-name"),
9707:                     "unexpected barrier reason: {reason}"
9708:                 );
9709:             }
9710:             other => panic!("expected Statement::Barrier, got {other:?}"),
9711:         }
9712:     }
9713: 
9714:     #[test]
9715:     fn proc_with_command_substitution_in_name_stays_barrier() {
9716:         // ``proc \$name[suffix]`` — multi-token name with a command
9717:         // substitution. The const-map gate only covers single-VAR
9718:         // tokens; this stays on the runtime path.
9719:         let m = lower_to_ir(
9720:             "proc factory {} { set name {x}\n proc $name[suffix] {} { puts hi } }",
9721:             &reg(),
9722:         );
9723:         // ``::factory`` registered; the inner proc must NOT be
9724:         // registered under any literal name (``::x...``).
9725:         assert!(
9726:             !m.procedures
9727:                 .values()
9728:                 .any(|body| body.qualified_name.contains("suffix"))
9729:         );
9730:     }
9731: 
9732:     #[test]
9733:     fn proc_subst_nocommands_body_materialised() {
9734:         // ``proc \$name {x} [subst -nocommands {return \$default}]``
9735:         // with both ``name`` and ``default`` const-tracked materialises
9736:         // the body to ``return 0`` and lowers it as a real script.
9737:         let m = lower_to_ir(
9738:             "proc factory {} { set name {Verbose}\n set default {0}\n proc $name {x} [subst -nocommands {return $default}] }",
9739:             &reg(),
9740:         );
9741:         let inner = fixture_id_if_present(&m.procedures, "::Verbose")
9742:             .and_then(|id| m.procedures.get(&id))
9743:             .expect("::Verbose registered");
9744:         // Body should contain a Return statement (or at least be
9745:         // non-empty — the materialised body lowers to a real
9746:         // statement, not a Barrier).
9747:         assert!(
9748:             !inner.body.statements.is_empty(),
9749:             "expected lowered body, got empty"
9750:         );
9751:     }
9752: 
9753:     #[test]
9754:     fn foreach_line_lowers_to_foreach_statement() {
9755:         // `foreachLine var filename body` lowers
9756:         // to a single-iterator Statement::Foreach so variables assigned
9757:         // inside the body propagate to the enclosing scope.  The
9758:         // generic stdlib-proc path would route through Statement::Barrier and
9759:         // lose that lattice information.
9760:         let m = lower_to_ir(
9761:             "foreachLine line /etc/hosts { set count [expr {$count + 1}] }",
9762:             &reg(),
9763:         );
9764:         let stmts = &m.top_level.statements;
9765:         let last = stmts.last().expect("at least one statement");
9766:         match last {
9767:             Statement::Foreach {
9768:                 iterators, is_lmap, ..
9769:             } => {
9770:                 assert!(!is_lmap);
9771:                 assert_eq!(iterators.len(), 1);
9772:                 assert_eq!(iterators[0].vars, vec!["line".to_owned()]);
9773:             }
9774:             other => panic!("expected Statement::Foreach, got {other:?}"),
9775:         }
9776:     }
9777: 
9778:     #[test]
9779:     fn foreach_line_var_body_routes_through_barrier() {
9780:         // `foreachLine line file $body` — the body is a Var token,
9781:         // which is single-token but NOT a braced literal.  Compiling
9782:         // the literal `$body` text as a static loop body would
9783:         // produce incorrect IR / data-flow; the lowering must fall
9784:         // through to the runtime command via Barrier.
9785:         let m = lower_to_ir("foreachLine line /etc/hosts $body", &reg());
9786:         let last = m.top_level.statements.last().expect("top-level statement");
9787:         match last {
9788:             Statement::Barrier {
9789:                 reason, command, ..
9790:             } => {
9791:                 assert_eq!(command, "foreachLine");
9792:                 assert!(
9793:                     reason.contains("dynamic body"),
9794:                     "unexpected reason: {reason}"
9795:                 );
9796:             }
9797:             other => panic!("expected Barrier for Var body, got {other:?}"),
9798:         }
9799:     }
9800: 
9801:     #[test]
9802:     fn foreach_line_cmd_body_routes_through_barrier() {
9803:         // Same guard for a `[cmd]` body — single-token but a Cmd
9804:         // substitution, not a braced literal.
9805:         let m = lower_to_ir("foreachLine line /etc/hosts [build-body]", &reg());
9806:         let last = m.top_level.statements.last().expect("top-level statement");
9807:         assert_runtime_opaque_call(last, &reg(), "foreachLine");
9808:     }
9809: 
9810:     #[test]
9811:     fn proc_var_body_const_map_materialised() {
9812:         // A bare `$body` body word whose value
9813:         // is in the const-map materialises into the Procedure body
9814:         // (matching the `proc $name {x} $body` shape).
9815:         let m = lower_to_ir(
9816:             "proc factory {} { set name {Greeter}\n set body {return hi}\n proc $name {} $body }",
9817:             &reg(),
9818:         );
9819:         let inner = fixture_id_if_present(&m.procedures, "::Greeter")
9820:             .and_then(|id| m.procedures.get(&id))
9821:             .expect("::Greeter registered");
9822:         // The body was const-resolved to "return hi"; lowering it
9823:         // produces a Return statement.
9824:         assert!(
9825:             !inner.body.statements.is_empty(),
9826:             "expected lowered body, got empty"
9827:         );
9828:     }
9829: 
9830:     #[test]
9831:     fn proc_var_body_unresolved_keeps_empty_body() {
9832:         // `$body` has no const-map binding but `$name` does — the
9833:         // proc name resolves, but the body stays empty (the runtime
9834:         // proc call below carries the dynamic body text).
9835:         let m = lower_to_ir(
9836:             "proc factory {} { set name {Greeter}\n proc $name {} $body }",
9837:             &reg(),
9838:         );
9839:         let inner = fixture_id_if_present(&m.procedures, "::Greeter")
9840:             .and_then(|id| m.procedures.get(&id))
9841:             .expect("::Greeter registered");
9842:         assert_eq!(
9843:             inner.body.statements.len(),
9844:             0,
9845:             "expected empty body for unresolved dynamic body, got {:?}",
9846:             inner.body.statements
9847:         );
9848:     }
9849: 
9850:     #[test]
9851:     fn proc_dynamic_params_routes_through_barrier() {
9852:         // A dynamic params word — there's no static arg-list to
9853:         // build a real Procedure from, so the whole proc shape
9854:         // bails to a Barrier.  Even when the name resolves via the
9855:         // const-map.
9856:         let m = lower_to_ir(
9857:             "proc factory {} { set name {x}\n proc $name $params { puts hi } }",
9858:             &reg(),
9859:         );
9860:         // No inner procedure should be registered — params couldn't
9861:         // be parsed statically.
9862:         assert!(
9863:             !fixture_id_if_present(&m.procedures, "::x").is_some(),
9864:             "dynamic-params shape must not AOT-register: {:?}",
9865:             m.procedures.keys().collect::<Vec<_>>()
9866:         );
9867:     }
9868: 
9869:     #[test]
9870:     fn proc_multi_token_body_word_is_dynamic() {
9871:         // `proc foo {} "pre${body}post"` — the body is a quoted
9872:         // multi-token word.  Even though the first token is Str,
9873:         // single_token_word is false so the whole word is dynamic
9874:         // and we route through Barrier (the multi-token guard).
9875:         let m = lower_to_ir(
9876:             r#"proc factory {} { set body {return hi}; proc inner {} "pre${body}post" }"#,
9877:             &reg(),
9878:         );
9879:         // `::inner` would only be registered if the body was
9880:         // materialised — which can't happen for multi-token words.
9881:         // We allow either no entry or an empty-body entry; the key
9882:         // assertion is that the literal source text isn't compiled
9883:         // as a script.
9884:         if let Some(inner) =
9885:             fixture_id_if_present(&m.procedures, "::inner").and_then(|id| m.procedures.get(&id))
9886:         {
9887:             assert_eq!(
9888:                 inner.body.statements.len(),
9889:                 0,
9890:                 "multi-token body must not be statically lowered, got {:?}",
9891:                 inner.body.statements
9892:             );
9893:         }
9894:     }
9895: 
9896:     #[test]
9897:     fn proc_subst_nocommands_missing_var_skips_materialisation() {
9898:         // ``\$default`` is not in the const-map — the materialiser
9899:         // refuses, leaving the body to fall back to runtime
9900:         // dispatch.
9901:         let m = lower_to_ir(
9902:             "proc factory {} { set name {Verbose}\n proc $name {x} [subst -nocommands {return $default}] }",
9903:             &reg(),
9904:         );
9905:         // Verbose not registered (because \$default missing means
9906:         // we keep the dynamic body which routes via Barrier — but
9907:         // the proc name itself was substituted). Actually
9908:         // the proc IS registered with whatever the body lowering
9909:         // produces; the assertion is that it's NOT the materialised
9910:         // form.
9911:         let inner =
9912:             fixture_id_if_present(&m.procedures, "::Verbose").and_then(|id| m.procedures.get(&id));
9913:         if let Some(p) = inner {
9914:             // The body should not contain a Return whose value is
9915:             // the literal "0" — that would be the materialised
9916:             // form. It can be empty / contain a Barrier.
9917:             // Conservative check: just verify the helper refused.
9918:             // (The body might still lower the original CMD-token
9919:             // text as a runtime call.)
9920:             assert!(
9921:                 p.body.statements.is_empty()
9922:                     || matches!(
9923:                         p.body.statements[0],
9924:                         Statement::Call { .. } | Statement::Barrier { .. }
9925:                     )
9926:             );
9927:         }
9928:     }
9929: 
9930:     /// Tcl 9.1's positive family names the same effect set `-nocommands`
9931:     /// leaves — variables and backslashes on, commands off — so the body
9932:     /// materialises the same way.
9933:     ///
9934:     /// tclsh 9.1b0, with `name` set to `world`:
9935:     /// `subst -variables -backslashes {hello $name\n[format X]}` → `hello
9936:     /// world`, a newline, then the untouched `[format X]`.
9937:     #[test]
9938:     fn proc_subst_tcl91_positive_switches_materialised() {
9939:         let m = lower_to_ir(
9940:             "proc factory {} { set name {Verbose}\n set default {0}\n proc $name {x} [subst -variables -backslashes {return $default}] }",
9941:             &reg(),
9942:         );
9943:         let inner = fixture_id_if_present(&m.procedures, "::Verbose")
9944:             .and_then(|id| m.procedures.get(&id))
9945:             .expect("::Verbose registered");
9946:         assert!(
9947:             !inner.body.statements.is_empty(),
9948:             "expected lowered body, got empty"
9949:         );
9950:         assert!(
9951:             !matches!(inner.body.statements[0], Statement::Barrier { .. }),
9952:             "expected a materialised body, got {:?}",
9953:             inner.body.statements
9954:         );
9955:     }
9956: 
9957:     /// A computed switch word leaves the call unreadable, so the registry
9958:     /// answers every kind and the materialiser refuses.
9959:     #[test]
9960:     fn proc_subst_computed_switch_word_refused() {
9961:         let m = lower_to_ir(
9962:             "proc factory {opt} { set name {Verbose}\n set default {0}\n proc $name {x} [subst $opt {return $default}] }",
9963:             &reg(),
9964:         );
9965:         if let Some(p) =
9966:             fixture_id_if_present(&m.procedures, "::Verbose").and_then(|id| m.procedures.get(&id))
9967:         {
9968:             assert!(
9969:                 p.body.statements.is_empty()
9970:                     || matches!(
9971:                         p.body.statements[0],
9972:                         Statement::Call { .. } | Statement::Barrier { .. }
9973:                     ),
9974:                 "expected no materialised body, got {:?}",
9975:                 p.body.statements
9976:             );
9977:         }
9978:     }
9979: 
9980:     #[test]
9981:     fn proc_subst_nocommands_nobackslashes_refused() {
9982:         // ``-nobackslashes`` flag — semantics differ from our
9983:         // evaluator's default. Refuse and fall through.
9984:         let m = lower_to_ir(
9985:             "proc factory {} { set name {Verbose}\n set default {0}\n proc $name {x} [subst -nobackslashes -nocommands {return $default}] }",
9986:             &reg(),
9987:         );
9988:         let inner =
9989:             fixture_id_if_present(&m.procedures, "::Verbose").and_then(|id| m.procedures.get(&id));
9990:         if let Some(p) = inner {
9991:             // Body did not materialise — should be empty or have
9992:             // a fallback shape.
9993:             assert!(
9994:                 p.body.statements.is_empty()
9995:                     || matches!(
9996:                         p.body.statements[0],
9997:                         Statement::Call { .. } | Statement::Barrier { .. }
9998:                     )
9999:             );
10000:         }
10001:     }
10002: 
10003:     #[test]
10004:     fn proc_dynamic_name_picks_latest_set() {
10005:         // Multiple ``set`` calls — the most recent literal wins.
10006:         let m = lower_to_ir(
10007:             "proc factory {} { set name {First}\n set name {Second}\n proc $name {} { puts hi } }",
10008:             &reg(),
10009:         );
10010:         assert!(fixture_id_if_present(&m.procedures, "::Second").is_some());
10011:         assert!(!fixture_id_if_present(&m.procedures, "::First").is_some());
10012:     }
10013: 
10014:     #[test]
10015:     fn ns_export_recorded() {
10016:         let m = lower_to_ir("namespace eval ::tcltest { namespace export test }", &reg());
10017:         // The export was inside a ``namespace eval`` body so the
10018:         // context namespace is ``::tcltest``.
10019:         assert!(
10020:             m.namespace_exports
10021:                 .iter()
10022:                 .any(|(ns, pat)| ns == "::tcltest" && pat == "test")
10023:         );
10024:     }
10025: 
10026:     #[test]
10027:     fn namespace_directive_metadata_keeps_actual_availability_and_source_config() {
10028:         // naming.compiler.original-analysis-metadata-context
10029:         // docs/design/analysis/name-resolution-proofs/original-analysis-metadata-context.md
10030:         let baseline = tcl_registry::model::ingress::static_context_for("tcl8.6");
10031:         let profile = tcl_dialect::DialectProfile::find("tcl8.6").unwrap();
10032:         let mut registry = baseline.commands().project_for_profile(profile);
10033:         let mut descriptor = registry.get("namespace").unwrap().clone();
10034:         descriptor.surface = Some(tcl_dialect::model::SpecSurface::TCL86_PLUS);
10035:         registry.insert(descriptor);
10036:         let current =
10037:             std::sync::Arc::new(baseline.with_command_store(std::sync::Arc::new(registry)));
10038:         let older = std::sync::Arc::new(
10039:             tcl_registry::model::ingress::static_context_for("tcl8.4")
10040:                 .with_command_store(std::sync::Arc::clone(current.commands())),
10041:         );
10042:         let config = tcl_lexer::LexerConfig::for_file_grammar(profile.grammar);
10043:         let (_owner, native) =
10044:             crate::environment_ingress::captured_native_entry_with_owner(profile);
10045:         let entry = crate::command_binding::SourceAnalysisEntry {
10046:             native_entry: Some(std::sync::Arc::new(native)),
10047:             invocation_dialect: Some(tcl_registry::InvocationDialect::of_profile(profile)),
10048:             native_compilation: crate::environment_ingress::authoring_native_compilation(),
10049:             ..Default::default()
10050:         };
10051:         let make = |context: std::sync::Arc<tcl_registry::model::ContextRegistry>| {
10052:             let input =
10053:                 crate::analyser::ResolvedAnalysisInput::new(profile, profile, context, config);
10054:             let mut lowerer =
10055:                 Lowerer::with_config(current.commands(), config).with_dialect(Some(profile));
10056:             lowerer.set_source_analysis_options(entry.options());
10057:             lowerer.with_resolved_analysis_input(input)
10058:         };
10059:         let source = "namespace export exposed";
10060:         let mut selected = make(std::sync::Arc::clone(&current));
10061:         selected.lower(source);
10062:         assert_eq!(
10063:             selected.namespace_exports,
10064:             [("::".to_owned(), "exposed".to_owned())]
10065:         );
10066:         let mut unavailable = make(older);
10067:         unavailable.lower(source);
10068:         assert!(unavailable.namespace_exports.is_empty());
10069:         let mut missing = make(std::sync::Arc::clone(&current));
10070:         missing.metadata_input = None;
10071:         missing.dialect_context = None;
10072:         missing.lower(source);
10073:         assert!(missing.namespace_exports.is_empty());
10074:         let logical_profile = tcl_dialect::DialectProfile::plain_tcl();
10075:         let logical_input = crate::analyser::ResolvedAnalysisInput::new(
10076:             logical_profile,
10077:             logical_profile,
10078:             std::sync::Arc::clone(&current),
10079:             tcl_lexer::LexerConfig::for_file_grammar(logical_profile.grammar),
10080:         );
10081:         let mut missing_authoring =
10082:             Lowerer::with_config(current.commands(), logical_input.lexer_config())
10083:                 .with_resolved_analysis_input(logical_input);
10084:         assert!(missing_authoring.invocation_metadata_context().is_some());
10085:         assert_eq!(
10086:             missing_authoring.source_entry_origin,
10087:             SourceEntryOrigin::Authoring
10088:         );
10089:         missing_authoring.metadata_input = None;
10090:         missing_authoring.logical_source_input = None;
10091:         missing_authoring.dialect_context = None;
10092:         assert!(!missing_authoring.allows_standalone_registry_metadata());
10093:         assert!(missing_authoring.invocation_metadata_context().is_none());
10094:         missing_authoring.lower(source);
10095:         assert!(missing_authoring.namespace_exports.is_empty());
10096:         let mut stale = make(std::sync::Arc::clone(&current));
10097:         stale.config.strict_quoting = !config.strict_quoting;
10098:         stale.lower(source);
10099:         assert!(stale.namespace_exports.is_empty());
10100:         let mut foreign = make(
10101:             tcl_registry::model::ingress::resolve_environment("tcl9.1").default_context_registry(),
10102:         );
10103:         foreign.lower(source);
10104:         assert!(foreign.namespace_exports.is_empty());
10105:     }
10106: 
10107:     #[test]
10108:     fn namespace_directive_metadata_uses_frozen_handler_operands() {
10109:         for source in [
10110:             "set pattern {-c}; namespace export OLD; namespace export -clear $pattern -- x",
10111:             "rename namespace ns; set pattern {-c}; ns export OLD; ns export -clear $pattern -- x",
10112:         ] {
10113:             let module = lower_to_ir(source, &reg());
10114:             assert_eq!(
10115:                 module.namespace_exports,
10116:                 ["OLD", "-c", "--", "x"].map(|pattern| ("::".to_owned(), pattern.to_owned())),
10117:                 "{source}",
10118:             );
10119:         }
10120:         let replaced = lower_to_ir("proc namespace args {}; namespace export x", &reg());
10121:         assert_eq!(
10122:             replaced.namespace_exports,
10123:             [] as [(std::string::String, std::string::String); 0]
10124:         );
10125:     }
10126: 
10127:     #[test]
10128:     fn ns_import_in_dead_branch_suppressed() {
10129:         // ``if {0} { namespace import ::evil::* }`` — the
10130:         // import is inside a syntactically-dead branch so it must
10131:         // NOT be recorded.
10132:         let m = lower_to_ir("if {0} { namespace import ::evil::* }", &reg());
10133:         assert_eq!(
10134:             m.namespace_imports.len(),
10135:             0,
10136:             "imports inside dead if{{0}} branch must not be collected, got {:?}",
10137:             m.namespace_imports,
10138:         );
10139:     }
10140: 
10141:     #[test]
10142:     fn ns_import_in_static_true_else_suppressed() {
10143:         // ``if {1} { ... } else { namespace import ::evil::* }``
10144:         // — the else branch is dead.
10145:         let m = lower_to_ir(
10146:             "if {1} { namespace import ::good::* } else { namespace import ::evil::* }",
10147:             &reg(),
10148:         );
10149:         // Only ``::good::*`` recorded.
10150:         assert_eq!(m.namespace_imports.len(), 1);
10151:         assert_eq!(m.namespace_imports[0].1, "::good::*");
10152:     }
10153: 
10154:     #[test]
10155:     fn const_prop_inherited_into_catch_body() {
10156:         // Child scope (catch body) inherits parent's const-map.
10157:         let m = lower_to_ir(
10158:             "proc f {} { set body {set x 1}\n catch { uplevel 1 $body } }",
10159:             &reg(),
10160:         );
10161:         let proc = fixture_id_if_present(&m.procedures, "::f")
10162:             .and_then(|id| m.procedures.get(&id))
10163:             .expect("proc registered");
10164:         // Look for a Catch wrapping an UpFrame.
10165:         let catch_stmt = proc
10166:             .body
10167:             .statements
10168:             .iter()
10169:             .find(|s| matches!(s, Statement::Catch { .. }))
10170:             .expect("expected Catch");
10171:         if let Statement::Catch { body, .. } = catch_stmt {
10172:             assert!(
10173:                 body.statements
10174:                     .iter()
10175:                     .any(|s| matches!(s, Statement::UpFrame { .. })),
10176:                 "expected UpFrame inside catch body, got {body:?}",
10177:             );
10178:         }
10179:     }
10180: 
10181:     // trace add execution module-fact population
10182: 
10183:     #[test]
10184:     fn trace_add_execution_literal_recorded() {
10185:         let m = lower_to_ir("trace add execution foo enter handler", &reg());
10186:         assert!(m.traced_commands.contains("foo"));
10187:         assert!(!m.has_dynamic_trace);
10188:     }
10189: 
10190:     #[test]
10191:     fn trace_add_execution_dynamic_widens() {
10192:         let m = lower_to_ir("trace add execution $cmd enter handler", &reg());
10193:         assert!(m.has_dynamic_trace);
10194:         assert_eq!(m.traced_commands.len(), 0);
10195:     }
10196: 
10197:     #[test]
10198:     fn trace_add_execution_qualified_canonicalised() {
10199:         let m = lower_to_ir("trace add execution ::ns::foo enter h", &reg());
10200:         // Stripped of leading ``::`` so the GVN gate's
10201:         // `command.trim_start_matches("::")` lookup hits.
10202:         assert!(m.traced_commands.contains("ns::foo"));
10203:     }
10204: 
10205:     #[test]
10206:     fn trace_add_variable_does_not_record_execution_trace() {
10207:         // `trace add variable` is a separate channel — should not
10208:         // populate `traced_commands` (those are command traces only).
10209:         let m = lower_to_ir("trace add variable x write h", &reg());
10210:         assert_eq!(m.traced_commands.len(), 0);
10211:         assert!(!m.has_dynamic_trace);
10212:     }
10213: 
10214:     /// `walk_for_trace`'s post-lower scan recurses once per nested
10215:     /// `if`/`for`/`while`/`foreach`/`catch`/`try`/`switch`/`Block`/`UpFrame`
10216:     /// body, with no depth cap of its own. Transitively bounded to
10217:     /// `MAX_LOWER_NEST_DEPTH`
10218:     /// (256) by `lower_script`/`lower_body` (this same `lower_to_ir` call
10219:     /// builds the `Script` `walk_for_trace` then scans), so this is
10220:     /// defence-in-depth / consistency with every other full-tree walker in
10221:     /// this crate, not a currently-reproducible crash. 1000 levels of
10222:     /// source nesting is comfortably past the cap; the assertion is
10223:     /// that lowering (which runs `populate_trace_facts` ->
10224:     /// `walk_for_trace`) returns at all, not what it returns. Spawns its
10225:     /// own big-stack thread since the lexer/CST/segmenter stages upstream
10226:     /// of `lower_script`'s own cap still walk the full un-truncated source
10227:     /// nesting before that cap trims it — same rationale as
10228:     /// `codegen::structured::tests::deeply_nested_if_survives_structured_walk`.
10229:     #[test]
10230:     fn deeply_nested_if_survives_walk_for_trace() {
10231:         const DEPTH: usize = 1000;
10232:         const STACK_SIZE: usize = 64 * 1024 * 1024;
10233:         let mut src = String::new();
10234:         for _ in 0..DEPTH {
10235:             src.push_str("if {1} {\n");
10236:         }
10237:         src.push_str("trace add execution foo enter handler\n");
10238:         for _ in 0..DEPTH {
10239:             src.push_str("}\n");
10240:         }
10241:         std::thread::Builder::new()
10242:             .stack_size(STACK_SIZE)
10243:             .spawn(move || {
10244:                 let _ = lower_to_ir(&src, &reg());
10245:             })
10246:             .unwrap()
10247:             .join()
10248:             .unwrap();
10249:     }
10250: 
10251:     // trace add/remove/variable/vdelete module-fact population
10252: 
10253:     #[test]
10254:     fn trace_target_names_keep_empty_and_literal_sigil_data() {
10255:         let registry = reg();
10256:         let empty = lower_to_ir("trace add variable {} write callback", &registry);
10257:         assert!(empty.traced_variables.contains(""));
10258:         assert!(!empty.traced_variables.contains("$"));
10259:         let literal = lower_to_ir("trace add variable {$counter} write callback", &registry);
10260:         assert!(literal.traced_variables.contains("$counter"));
10261:         assert!(!literal.traced_variables.contains("counter"));
10262:     }
10263: 
10264:     #[test]
10265:     fn trace_add_variable_literal_recorded() {
10266:         let m = lower_to_ir("trace add variable x write h", &reg());
10267:         assert!(m.traced_variables.contains("x"), "{:?}", m.traced_variables);
10268:         assert!(!m.has_dynamic_variable_trace);
10269:     }
10270: 
10271:     #[test]
10272:     fn trace_remove_variable_literal_recorded() {
10273:         // A `remove` only proves a trace *might* have existed — still
10274:         // conservative to record, mirroring `trace add`.
10275:         let m = lower_to_ir("trace remove variable x write h", &reg());
10276:         assert!(m.traced_variables.contains("x"), "{:?}", m.traced_variables);
10277:     }
10278: 
10279:     #[test]
10280:     fn trace_add_variable_qualified_canonicalised() {
10281:         let m = lower_to_ir("trace add variable ::x write h", &reg());
10282:         // `::`-stripped so a top-level `set x 5` (chain key `x`) matches.
10283:         assert!(m.traced_variables.contains("x"), "{:?}", m.traced_variables);
10284:     }
10285: 
10286:     #[test]
10287:     fn trace_add_variable_dynamic_widens() {
10288:         let m = lower_to_ir("trace add variable $name write h", &reg());
10289:         assert!(m.has_dynamic_variable_trace);
10290:         assert_eq!(m.traced_variables.len(), 0);
10291:     }
10292: 
10293:     #[test]
10294:     fn trace_add_variable_inside_proc_recorded() {
10295:         let m = lower_to_ir(
10296:             "proc setup {} { trace add variable ::x read onread }",
10297:             &reg(),
10298:         );
10299:         assert!(m.traced_variables.contains("x"), "{:?}", m.traced_variables);
10300:     }
10301: 
10302:     #[test]
10303:     fn trace_add_variable_inside_method_recorded() {
10304:         // TclOO method bodies are extracted into `module.methods` (a
10305:         // separate map from `module.procedures`) before this scan runs —
10306:         // must not be missed just because it isn't a plain proc.
10307:         let m = lower_to_ir(
10308:             "oo::class create C {\n method m {} { trace add variable v write cb }\n}",
10309:             &reg(),
10310:         );
10311:         assert!(m.traced_variables.contains("v"), "{:?}", m.traced_variables);
10312:     }
10313: 
10314:     #[test]
10315:     fn trace_legacy_variable_form_recorded() {
10316:         // The deprecated `trace variable name ops command` spelling must
10317:         // populate the same fact as `trace add variable` — no
10318:         // hardcoded-per-form gap.
10319:         let registry = tcl_registry::model::ingress::static_context_for("tcl8.6").commands();
10320:         let m = lower_to_ir("trace variable x r onread", registry);
10321:         assert!(m.traced_variables.contains("x"), "{:?}", m.traced_variables);
10322:     }
10323: 
10324:     #[test]
10325:     fn trace_legacy_vdelete_form_recorded() {
10326:         let registry = tcl_registry::model::ingress::static_context_for("tcl8.6").commands();
10327:         let m = lower_to_ir("trace vdelete x r onread", registry);
10328:         assert!(m.traced_variables.contains("x"), "{:?}", m.traced_variables);
10329:     }
10330: 
10331:     #[test]
10332:     fn removed_legacy_trace_forms_do_not_donate_tcl9_transitions() {
10333:         let registry = tcl_registry::model::ingress::static_context_for("tcl9.0").commands();
10334:         for source in ["trace variable x r onread", "trace vdelete x r onread"] {
10335:             let module = lower_to_ir(source, registry);
10336:             assert!(module.traced_variables.is_empty());
10337:             assert!(!module.has_dynamic_variable_trace);
10338:         }
10339:     }
10340: 
10341:     #[test]
10342:     fn trace_info_variable_does_not_record() {
10343:         // `trace info`/`vinfo` only query trace state — no
10344:         // `ESTABLISHES_VARIABLE_TRACE` trait, so they must not widen the
10345:         // module fact.
10346:         let m = lower_to_ir("trace info variable x", &reg());
10347:         assert_eq!(m.traced_variables.len(), 0);
10348:         assert!(!m.has_dynamic_variable_trace);
10349:     }
10350: 
10351:     #[test]
10352:     fn trace_add_variable_through_interp_alias_recorded() {
10353:         // `interp alias {} tracer {} trace` means `tracer add variable ...`
10354:         // is really a `trace add variable ...` call — the whole-module scan
10355:         // must key off the canonical (alias-resolved) command name, not the
10356:         // source-surface `tracer` spelling, or this trace target is missed.
10357:         let m = lower_to_ir(
10358:             "interp alias {} tracer {} trace\ntracer add variable x write h",
10359:             &reg(),
10360:         );
10361:         assert!(m.traced_variables.contains("x"), "{:?}", m.traced_variables);
10362:     }
10363: 
10364:     #[test]
10365:     fn trace_add_execution_through_interp_alias_recorded() {
10366:         // Same alias-resolution requirement for the execution-trace channel:
10367:         // `walk_for_trace` gates entry into both `traced_commands` and
10368:         // `populate_variable_trace_facts` on one shared canonical-name check.
10369:         let m = lower_to_ir(
10370:             "interp alias {} tracer {} trace\ntracer add execution foo enter h",
10371:             &reg(),
10372:         );
10373:         assert!(m.traced_commands.contains("foo"), "{:?}", m.traced_commands);
10374:         assert!(!m.has_dynamic_trace);
10375:     }
10376: 
10377:     #[test]
10378:     fn trace_add_execution_does_not_record_variable_trace() {
10379:         // The command-execution channel is separate — should not
10380:         // populate `traced_variables`.
10381:         let m = lower_to_ir("trace add execution foo enter h", &reg());
10382:         assert_eq!(m.traced_variables.len(), 0);
10383:         assert!(!m.has_dynamic_variable_trace);
10384:     }
10385: 
10386:     #[test]
10387:     fn trace_add_execution_inside_proc_recorded() {
10388:         let m = lower_to_ir("proc init {} { trace add execution foo enter h }", &reg());
10389:         assert!(
10390:             m.traced_commands.contains("foo"),
10391:             "traced_commands={:?}",
10392:             m.traced_commands,
10393:         );
10394:     }
10395: 
10396:     #[test]
10397:     fn trace_add_variable_abbreviated_type_word_recorded() {
10398:         // `trace add v x write h` / `trace add var x write h` install the
10399:         // same variable trace as the full `variable` spelling — C Tcl
10400:         // accepts any unique prefix (checked against tclsh 8.6.14).
10401:         let m = lower_to_ir("trace add v x write h", &reg());
10402:         assert!(m.traced_variables.contains("x"), "{:?}", m.traced_variables);
10403:         let m = lower_to_ir("trace add var x write h", &reg());
10404:         assert!(m.traced_variables.contains("x"), "{:?}", m.traced_variables);
10405:     }
10406: 
10407:     #[test]
10408:     fn trace_remove_variable_abbreviated_type_word_recorded() {
10409:         let m = lower_to_ir("trace remove var x write h", &reg());
10410:         assert!(m.traced_variables.contains("x"), "{:?}", m.traced_variables);
10411:     }
10412: 
10413:     #[test]
10414:     fn trace_add_execution_abbreviated_type_word_not_variable() {
10415:         // `e`/`exec` abbreviate `execution`, not `variable` — must not
10416:         // widen `traced_variables`.
10417:         let m = lower_to_ir("trace add e foo enter h", &reg());
10418:         assert_eq!(m.traced_variables.len(), 0);
10419:         assert!(m.traced_commands.contains("foo"), "{:?}", m.traced_commands);
10420:     }
10421: 
10422:     #[test]
10423:     fn trace_add_variable_inside_namespace_eval_body_recorded() {
10424:         // A trace installed inside a `namespace eval` body (a synthetic
10425:         // `Module::body_units` entry, not a named proc) must populate the
10426:         // same whole-module fact as one inside a `proc`.
10427:         let m = lower_to_ir(
10428:             "namespace eval ::n { trace add variable ::x write h }",
10429:             &reg(),
10430:         );
10431:         assert!(m.traced_variables.contains("x"), "{:?}", m.traced_variables);
10432:     }
10433: 
10434:     #[test]
10435:     fn trace_add_variable_inside_apply_body_recorded() {
10436:         let m = lower_to_ir("apply {{} { trace add variable ::x write h }}", &reg());
10437:         assert!(m.traced_variables.contains("x"), "{:?}", m.traced_variables);
10438:     }
10439: 
10440:     #[test]
10441:     fn trace_add_variable_inside_method_body_recorded() {
10442:         let m = lower_to_ir(
10443:             "oo::class create C { method m {} { trace add variable ::x write h } }",
10444:             &reg(),
10445:         );
10446:         assert!(m.traced_variables.contains("x"), "{:?}", m.traced_variables);
10447:     }
10448: 
10449:     // barrier-gate
10450: 
10451:     #[test]
10452:     fn body_has_dynamic_barrier_clean() {
10453:         // No barriers at all.
10454:         assert!(!body_has_dynamic_barrier(
10455:             "set x 1",
10456:             &reg(),
10457:             tcl_lexer::LexerConfig::default()
10458:         ));
10459:         // Barrier with a fully literal body.
10460:         assert!(!body_has_dynamic_barrier(
10461:             "eval { set x 1 }",
10462:             &reg(),
10463:             tcl_lexer::LexerConfig::default()
10464:         ));
10465:         // Nested literal.
10466:         assert!(!body_has_dynamic_barrier(
10467:             "if { 1 } { eval { set x 1 } }",
10468:             &reg(),
10469:             tcl_lexer::LexerConfig::default()
10470:         ));
10471:     }
10472: 
10473:     #[test]
10474:     fn descriptor_binding_requirement_keeps_original_head_and_exact_metadata_without_native_receipt()
10475:      {
10476:         let mut registry = reg();
10477:         let prototype = registry.get_exact("list").unwrap().clone();
10478:         for label in ["::probe", ":probe", "A:::probe", "probe::", ""] {
10479:             let mut descriptor = prototype.clone();
10480:             descriptor.name = label;
10481:             registry.insert(descriptor);
10482:         }
10483:         for label in ["::probe", ":probe", "A:::probe", "probe::", ""] {
10484:             let source = if label.is_empty() {
10485:                 "{} value".to_owned()
10486:             } else {
10487:                 format!("{label} value")
10488:             };
10489:             let mut lowerer = Lowerer::new(&registry);
10490:             lowerer.word_space = WordSpace::new(&source, 0, lowerer.source_channel);
10491:             lowerer.command_binding_site_stack.push(Vec::new());
10492:             let commands = crate::segmenter::segment_commands_with_offset_and_config(
10493:                 &source,
10494:                 0,
10495:                 lowerer.config,
10496:             );
10497:             let key = registry.get_exact(label).unwrap().descriptor_key();
10498:             lowerer.record_consumed_command_binding(
10499:                 &commands[0],
10500:                 "::",
10501:                 crate::registry_invocation::SelectedLoweringBindingIdentity::Logical(key),
10502:             );
10503:             let site = &lowerer.command_binding_site_stack[0][0];
10504:             assert_eq!(site.binding.name, label);
10505:             assert_eq!(
10506:                 site.binding.identity,
10507:                 tcl_syntax::naming::unroot_rooted_key(label).unwrap_or(label)
10508:             );
10509:             assert!(site.binding.namespace_context.is_none());
10510:             assert!(
10511:                 site.source_tokens
10512:                     .as_deref()
10513:                     .unwrap()
10514:                     .source_binding
10515:                     .is_none()
10516:             );
10517:         }
10518:     }
10519: 
10520:     #[test]
10521:     fn unavailable_lowering_metadata_keeps_generic_dispatch_and_conservative_method_names() {
10522:         let registry = reg();
10523:         let source = "unresolved local $dynamic";
10524:         let mut lowerer = Lowerer::new(&registry);
10525:         lowerer.source_entry_origin = SourceEntryOrigin::Driver;
10526:         lowerer.metadata_origin = LoweringMetadataOrigin::Supplied;
10527:         lowerer.word_space = WordSpace::new(source, 0, lowerer.source_channel);
10528:         let commands =
10529:             crate::segmenter::segment_commands_with_offset_and_config(source, 0, lowerer.config);
10530:         let statement = lowerer.lower_default(&commands[0], "::");
10531:         let Statement::Call {
10532:             canonical_command,
10533:             defs,
10534:             reads,
10535:             ..
10536:         } = &statement
10537:         else {
10538:             panic!("missing original/context ownership must retain a generic call");
10539:         };
10540:         assert!(canonical_command.is_none());
10541:         assert!(defs.is_empty());
10542:         assert!(reads.is_empty());
10543:         assert_eq!(
10544:             lowerer.advisory_method_instance_names(&statement),
10545:             vec!["local", "${dynamic}"]
10546:         );
10547:     }
10548: 
10549:     #[test]
10550:     fn method_variable_advice_preserves_literal_names_and_captured_prefix_values() {
10551:         let registry = reg();
10552:         let mut lowerer = Lowerer::new(&registry).trace_visible();
10553:         lowerer.lower("variable {}; variable {$counter}; variable {brace{name}}; variable {-dash}");
10554:         let names: Vec<_> = lowerer
10555:             .module
10556:             .top_level
10557:             .statements
10558:             .iter()
10559:             .flat_map(|statement| lowerer.advisory_method_instance_names(statement))
10560:             .collect();
10561:         assert_eq!(names, vec!["", "$counter", "brace{name}", "-dash"]);
10562: 
10563:         let mut captured = Lowerer::new(&registry).trace_visible();
10564:         captured.lower("interp alias {} ivar {} variable {$counter}; ivar");
10565:         let statement = captured.module.top_level.statements.last().unwrap();
10566:         assert_eq!(
10567:             captured.advisory_method_instance_names(statement),
10568:             vec!["$counter"]
10569:         );
10570:     }
10571: 
10572:     #[test]
10573:     fn unresolved_method_name_protection_keeps_original_source_text_without_reparsing() {
10574:         let registry = reg();
10575:         let source = "unresolved {} {$counter} {brace{name}} {a(b)} {-dash} $dynamic";
10576:         let mut lowerer = Lowerer::new(&registry);
10577:         lowerer.source_entry_origin = SourceEntryOrigin::Driver;
10578:         lowerer.metadata_origin = LoweringMetadataOrigin::Supplied;
10579:         lowerer.word_space = WordSpace::new(source, 0, lowerer.source_channel);
10580:         let commands =
10581:             crate::segmenter::segment_commands_with_offset_and_config(source, 0, lowerer.config);
10582:         let statement = lowerer.lower_default(&commands[0], "::");
10583:         let Statement::Call { args, .. } = &statement else {
10584:             panic!("generic source fallback");
10585:         };
10586:         assert_eq!(lowerer.advisory_method_instance_names(&statement), *args);
10587:         assert_eq!(
10588:             args,
10589:             &vec!["", "$counter", "brace{name}", "a(b)", "-dash", "${dynamic}"]
10590:         );
10591:     }
10592: 
10593:     #[test]
10594:     fn local_body_literal_reference_lookup_uses_whole_scalar_source_geometry() {
10595:         let registry = reg();
10596:         let mut lowerer = Lowerer::new(&registry);
10597:         lowerer.proc_depth = 1;
10598:         lowerer.const_map_stack.push(HashMap::from([(
10599:             "body".to_owned(),
10600:             "return original".to_owned(),
10601:         )]));
10602:         for reference in ["$body", "${body}"] {
10603:             assert_eq!(
10604:                 lowerer.const_map_lookup(reference).as_deref(),
10605:                 Some("return original")
10606:             );
10607:         }
10608:         for reference in [
10609:             "body",
10610:             "$body suffix",
10611:             "${body}suffix",
10612:             "$body(index)",
10613:             "${body(index)}",
10614:             "$",
10615:             "${body",
10616:             "$::body",
10617:         ] {
10618:             assert_eq!(lowerer.const_map_lookup(reference), None, "{reference}");
10619:         }
10620:         lowerer.proc_depth = 0;
10621:         assert_eq!(lowerer.const_map_lookup("$body"), None);
10622:     }
10623: 
10624:     #[test]
10625:     fn local_body_literal_retention_requires_actual_assignment_and_decodes_the_written_key() {
10626:         let config = tcl_lexer::LexerConfig::default();
10627:         let source = r"set b\x6fdy {return original}";
10628:         let commands = crate::segmenter::segment_commands_with_offset_and_config(source, 0, config);
10629:         let seg = &commands[0];
10630:         let assignment = Statement::AssignConst {
10631:             span: seg.span,
10632:             name: seg.args()[0].clone(),
10633:             name_braced: false,
10634:             value: seg.args()[1].clone(),
10635:             value_span: None,
10636:         };
10637:         assert_eq!(
10638:             assigned_local_body_literal(seg, &assignment, config),
10639:             Some(("body".to_owned(), "return original".to_owned()))
10640:         );
10641:         let opaque = Statement::Barrier {
10642:             span: seg.span,
10643:             reason: "opaque invocation".to_owned(),
10644:             command: "set".to_owned(),
10645:             canonical_command: None,
10646:             args: seg.args().to_vec(),
10647:             tokens: None,
10648:         };
10649:         assert_eq!(assigned_local_body_literal(seg, &opaque, config), None);
10650:     }
10651: 
10652:     #[test]
10653:     fn local_body_literal_invalidation_distinguishes_literal_sigils_and_decodes_write_keys() {
10654:         let config = tcl_lexer::LexerConfig::default();
10655:         let mut scope = HashMap::from([("body".to_owned(), "return original".to_owned())]);
10656:         let write = |name: &str, name_braced: bool| Statement::AssignConst {
10657:             span: tcl_lexer::Span::new(0, 0),
10658:             name: name.to_owned(),
10659:             name_braced,
10660:             value: "replacement".to_owned(),
10661:             value_span: None,
10662:         };
10663:         invalidate_const_map_for(&write("$body", true), &mut scope, config);
10664:         assert!(scope.contains_key("body"));
10665:         invalidate_const_map_for(&write("::body", true), &mut scope, config);
10666:         assert!(scope.contains_key("body"));
10667:         invalidate_const_map_for(&write(r"b\x6fdy", false), &mut scope, config);
10668:         assert!(scope.is_empty());
10669:         scope.insert("body".to_owned(), "return original".to_owned());
10670:         invalidate_const_map_for(&write("body(index)", true), &mut scope, config);
10671:         assert!(scope.is_empty());
10672:         scope.insert("body".to_owned(), "return original".to_owned());
10673:         invalidate_const_map_for(&write("$computed", false), &mut scope, config);
10674:         assert!(scope.is_empty());
10675:     }
10676: 
10677:     #[test]
10678:     fn local_body_literal_generic_call_with_empty_defs_withdraws_all_retained_values() {
10679:         let config = tcl_lexer::LexerConfig::default();
10680:         let registry = reg();
10681:         let mut lowerer = Lowerer::new(&registry);
10682:         let source = "unknown_writer $computed replacement";
10683:         lowerer.word_space = WordSpace::new(source, 0, lowerer.source_channel);
10684:         let commands = crate::segmenter::segment_commands_with_offset_and_config(source, 0, config);
10685:         let call = lowerer.lower_default(&commands[0], "::");
10686:         assert!(matches!(&call, Statement::Call { defs, .. } if defs.is_empty()));
10687:         let mut scope = HashMap::from([("body".to_owned(), "return original".to_owned())]);
10688:         invalidate_const_map_for(&call, &mut scope, config);
10689:         assert!(scope.is_empty());
10690:     }
10691: 
10692:     #[test]
10693:     fn local_body_literal_quiet_logical_source_retains_factory_names_and_bodies() {
10694:         let context =
10695:             tcl_registry::model::ingress::resolve_environment("tcl8.6").default_context_registry();
10696:         let profile = tcl_dialect::DialectProfile::plain_tcl();
10697:         let input = crate::analyser::ResolvedAnalysisInput::new(
10698:             profile,
10699:             profile,
10700:             std::sync::Arc::clone(&context),
10701:             tcl_lexer::LexerConfig::for_file_grammar(profile.grammar),
10702:         );
10703:         let source = "proc factory {} {set name {LiteralChild}; set body {return original}; proc $name {} $body}";
10704:         let mut lowerer = Lowerer::with_config(context.commands(), input.lexer_config())
10705:             .with_resolved_analysis_input(input);
10706:         lowerer.lower(source);
10707:         let module = lowerer.finish_module(source);
10708:         let child = fixture_id_if_present(&module.procedures, "::LiteralChild")
10709:             .and_then(|id| module.procedures.get(&id))
10710:             .expect("genuine quiet Logical source retains the original child");
10711:         assert_eq!(child.body_source.as_deref(), Some("return original"));
10712:         assert!(module.source_entry.native_entry.is_none());
10713:     }
10714: 
10715:     #[test]
10716:     fn local_body_literal_opcode_without_original_quiet_source_owner_cannot_retain_contents() {
10717:         let registry = reg();
10718:         let source = "set body {return original}";
10719:         let mut lowerer = Lowerer::new(&registry);
10720:         lowerer.proc_depth = 1;
10721:         lowerer.const_map_stack.push(HashMap::from([(
10722:             "previous".to_owned(),
10723:             "return stale".to_owned(),
10724:         )]));
10725:         lowerer.word_space = WordSpace::new(source, 0, lowerer.source_channel);
10726:         let commands =
10727:             crate::segmenter::segment_commands_with_offset_and_config(source, 0, lowerer.config);
10728:         let seg = &commands[0];
10729:         let synthetic = Statement::AssignConst {
10730:             span: seg.span,
10731:             name: seg.args()[0].clone(),
10732:             name_braced: false,
10733:             value: seg.args()[1].clone(),
10734:             value_span: None,
10735:         };
10736:         lowerer.update_const_map(seg, &synthetic);
10737:         assert!(lowerer.const_map_stack.last().unwrap().is_empty());
10738:         assert_eq!(lowerer.original_native_written_argument_value(seg, 1), None);
10739:     }
10740: 
10741:     #[test]
10742:     fn local_body_literal_expression_and_value_evaluation_withdraw_unclosed_effects() {
10743:         let registry = reg();
10744:         let config = tcl_lexer::LexerConfig::default();
10745:         for source in [
10746:             "expr {[overwrite]}",
10747:             "expr {$watched}",
10748:             "set other [overwrite]",
10749:             "set other $watched",
10750:             "incr other $watched",
10751:         ] {
10752:             let module = lower_to_ir(source, &registry);
10753:             let statement = module
10754:                 .top_level
10755:                 .statements
10756:                 .first()
10757:                 .expect("original statement");
10758:             assert!(!matches!(statement, Statement::AssignConst { .. }));
10759:             let mut scope = HashMap::from([("body".to_owned(), "return original".to_owned())]);
10760:             invalidate_const_map_for(statement, &mut scope, config);
10761:             assert!(scope.is_empty(), "unclosed effects: {source}");
10762:         }
10763:     }
10764: 
10765:     #[test]
10766:     fn class_variable_source_union_keeps_decoded_names_and_slot_operation_boundaries() {
10767:         let registry = reg();
10768:         let profile = registry.profile().unwrap();
10769:         let config = tcl_lexer::LexerConfig::for_profile(Some(profile));
10770:         let source = r"variable -set {} {$counter} {brace{name}} {-dash}; variable \$counter";
10771:         let segments = crate::segmenter::segment_commands_with_offset_and_config(source, 0, config);
10772:         let names = declared_member_vars(
10773:             &tcl_registry::definer::TCLOO_GRAMMAR,
10774:             &segments,
10775:             Some(profile.surface_query()),
10776:             config,
10777:         );
10778:         assert_eq!(
10779:             names,
10780:             HashSet::from([
10781:                 "".to_owned(),
10782:                 "$counter".to_owned(),
10783:                 "brace{name}".to_owned(),
10784:                 "-dash".to_owned()
10785:             ])
10786:         );
10787:         assert!(!names.contains("counter"));
10788:         assert!(!names.contains("-set"));
10789:         let escaped_segments = crate::segmenter::segment_commands_with_offset_and_config(
10790:             r"variable \$counter",
10791:             0,
10792:             config,
10793:         );
10794:         assert_eq!(
10795:             declared_member_vars(
10796:                 &tcl_registry::definer::TCLOO_GRAMMAR,
10797:                 &escaped_segments,
10798:                 Some(profile.surface_query()),
10799:                 config,
10800:             ),
10801:             HashSet::from(["$counter".to_owned()])
10802:         );
10803:     }
10804: 
10805:     #[test]
10806:     fn class_variable_unknown_operands_keep_known_literal_protection_without_reference_parsing() {
10807:         let registry = reg();
10808:         let profile = registry.profile().unwrap();
10809:         let config = tcl_lexer::LexerConfig::for_profile(Some(profile));
10810:         let segments = crate::segmenter::segment_commands_with_offset_and_config(
10811:             "variable $dynamic {} {$counter} {a(b)}",
10812:             0,
10813:             config,
10814:         );
10815:         let names = declared_member_vars(
10816:             &tcl_registry::definer::TCLOO_GRAMMAR,
10817:             &segments,
10818:             Some(profile.surface_query()),
10819:             config,
10820:         );
10821:         assert_eq!(
10822:             names,
10823:             HashSet::from(["".to_owned(), "$counter".to_owned(), "a(b)".to_owned()])
10824:         );
10825:         assert!(!names.contains("counter"));
10826:         assert!(!names.contains("a"));
10827:         assert!(!names.contains("dynamic"));
10828:     }
10829: 
10830:     #[test]
10831:     fn body_barrier_metadata_keeps_exact_selected_rooted_descriptor() {
10832:         let mut registry = reg();
10833:         assert!(body_has_dynamic_barrier(
10834:             "::eval $body",
10835:             &registry,
10836:             tcl_lexer::LexerConfig::default()
10837:         ));
10838:         let mut rooted = registry.get_exact("list").unwrap().clone();
10839:         rooted.name = "::eval";
10840:         registry.insert(rooted);
10841:         assert!(!body_has_dynamic_barrier(
10842:             "::eval $body",
10843:             &registry,
10844:             tcl_lexer::LexerConfig::default()
10845:         ));
10846:         assert!(body_has_dynamic_barrier(
10847:             "eval $body",
10848:             &registry,
10849:             tcl_lexer::LexerConfig::default()
10850:         ));
10851:         for head in ["::::eval", ":eval", "eval::", "eval:::member"] {
10852:             assert!(!body_has_dynamic_barrier(
10853:                 &format!("{head} $body"),
10854:                 &registry,
10855:                 tcl_lexer::LexerConfig::default()
10856:             ));
10857:         }
10858:     }
10859: 
10860:     #[test]
10861:     fn body_has_dynamic_barrier_dynamic_eval_body() {
10862:         // ``eval $x`` inside the outer body — dynamic.
10863:         assert!(body_has_dynamic_barrier(
10864:             "eval $x",
10865:             &reg(),
10866:             tcl_lexer::LexerConfig::default()
10867:         ));
10868:         // Same shape nested.
10869:         assert!(body_has_dynamic_barrier(
10870:             "if { 1 } { eval $x }",
10871:             &reg(),
10872:             tcl_lexer::LexerConfig::default()
10873:         ));
10874:     }
10875: 
10876:     #[test]
10877:     fn body_has_dynamic_barrier_dynamic_uplevel_body() {
10878:         assert!(body_has_dynamic_barrier(
10879:             "uplevel 1 $body",
10880:             &reg(),
10881:             tcl_lexer::LexerConfig::default()
10882:         ));
10883:         assert!(body_has_dynamic_barrier(
10884:             "uplevel #0 $b",
10885:             &reg(),
10886:             tcl_lexer::LexerConfig::default()
10887:         ));
10888:     }
10889: 
10890:     #[test]
10891:     fn body_has_dynamic_barrier_requires_proved_uplevel_level() {
10892:         // A numeric value selects a frame, but "marker" is the first script
10893:         // word on every pinned C release. Bracing the last word cannot decide
10894:         // which operation an unknown first value requests.
10895:         for source in ["uplevel 0 {set x 1}", "uplevel #0 {set x 1}"] {
10896:             assert!(!body_has_dynamic_barrier(
10897:                 source,
10898:                 &reg(),
10899:                 tcl_lexer::LexerConfig::default()
10900:             ));
10901:         }
10902:         assert!(body_has_dynamic_barrier(
10903:             "uplevel $lvl {set x 1}",
10904:             &reg(),
10905:             tcl_lexer::LexerConfig::default()
10906:         ));
10907:     }
10908: 
10909:     #[test]
10910:     fn body_has_dynamic_barrier_qualified_eval_uplevel() {
10911:         // ``::eval`` and ``::uplevel`` are also caught.
10912:         assert!(body_has_dynamic_barrier(
10913:             "::eval $x",
10914:             &reg(),
10915:             tcl_lexer::LexerConfig::default()
10916:         ));
10917:         assert!(body_has_dynamic_barrier(
10918:             "::uplevel 1 $body",
10919:             &reg(),
10920:             tcl_lexer::LexerConfig::default()
10921:         ));
10922:     }
10923: 
10924:     /// The gate resolves `uplevel`'s script word through the
10925:     /// registry's `ArgRole::Body` resolver, not a local level-word sniff, so
10926:     /// every documented `uplevel ?level? arg ?arg ...?` shape agrees with
10927:     /// `uplevel_body_arg_role_skips_optional_level` in `tcl-registry`.
10928:     #[test]
10929:     fn body_has_dynamic_barrier_uplevel_level_shapes_follow_the_registry() {
10930:         let r = reg();
10931:         // TN — a literal script in each level spelling relaxes.
10932:         for clean in [
10933:             "uplevel {set x 1}",
10934:             "uplevel 1 {set x 1}",
10935:             "uplevel #0 {set x 1}",
10936:             "uplevel 0 {set x 1}",
10937:         ] {
10938:             assert!(
10939:                 !body_has_dynamic_barrier(clean, &r, tcl_lexer::LexerConfig::default()),
10940:                 "{clean} must not poison"
10941:             );
10942:         }
10943:         // TP — a substituted script word in each level spelling poisons.
10944:         for dirty in [
10945:             "uplevel $body",
10946:             "uplevel 1 $body",
10947:             "uplevel #0 $body",
10948:             "uplevel $lvl $body",
10949:             "uplevel $lvl {set x 1}",
10950:             "uplevel [expr {$n - 1}] {set x 1}",
10951:             "uplevel 1 [gen]",
10952:         ] {
10953:             assert!(
10954:                 body_has_dynamic_barrier(dirty, &r, tcl_lexer::LexerConfig::default()),
10955:                 "{dirty} must poison"
10956:             );
10957:         }
10958:         // FN guard — the words after the script word concatenate into it
10959:         // (`SCRIPT_CONCATENATES_ARGS`), so a dynamic tail is still dynamic
10960:         // even though the marked body word is a braced literal.
10961:         assert!(body_has_dynamic_barrier(
10962:             "uplevel 1 {set x} $tail",
10963:             &reg(),
10964:             tcl_lexer::LexerConfig::default()
10965:         ));
10966:         assert!(body_has_dynamic_barrier(
10967:             "eval {set x} $tail",
10968:             &reg(),
10969:             tcl_lexer::LexerConfig::default()
10970:         ));
10971:         // …and an all-literal multi-word tail stays clean.
10972:         assert!(!body_has_dynamic_barrier(
10973:             "uplevel 1 {set x} {1}",
10974:             &reg(),
10975:             tcl_lexer::LexerConfig::default()
10976:         ));
10977:         // A bodyless `uplevel 1` is a wrong-#args error the registry exposes
10978:         // no body word for — poison rather than guess.
10979:         assert!(body_has_dynamic_barrier(
10980:             "uplevel 1",
10981:             &reg(),
10982:             tcl_lexer::LexerConfig::default()
10983:         ));
10984:         // A local level sniff that strips a leading `-` before the digit test
10985:         // would accept `-N` as a level; the registry does not, and the
10986:         // registry is right.  On tclsh 8.6.14, with `proc -1 {args} {…}`
10987:         // defined, `uplevel -1 {set x 1}` *calls* `-1` with `set x 1` — the
10988:         // word is the script's first word, not a level.  tclsh9.0.4 instead
10989:         // errors `bad level "-1"`.  Under either reading the word is an
10990:         // unbraced script word, so the gate poisons.
10991:         assert!(body_has_dynamic_barrier(
10992:             "uplevel -1 {set x 1}",
10993:             &reg(),
10994:             tcl_lexer::LexerConfig::default()
10995:         ));
10996:     }
10997: 
10998:     /// The eval-family *subcommand*
10999:     /// members carry `EVALUATES_CODE` / `SCRIPT_CONCATENATES_ARGS` on the
11000:     /// subcommand, not on the `namespace` / `interp` spec.  Composing them
11001:     /// (`invocation_traits`) plus registry-resolved body indices makes them
11002:     /// flow through the same path a bare `eval` does, which a parent-only
11003:     /// trait test missed entirely.
11004:     #[test]
11005:     fn body_has_dynamic_barrier_covers_compound_eval_family() {
11006:         let r = reg();
11007:         // TP — the script is substituted.
11008:         assert!(body_has_dynamic_barrier(
11009:             "namespace eval ns $body",
11010:             &r,
11011:             tcl_lexer::LexerConfig::default()
11012:         ));
11013:         assert!(body_has_dynamic_barrier(
11014:             "namespace inscope ns $body",
11015:             &r,
11016:             tcl_lexer::LexerConfig::default()
11017:         ));
11018:         assert!(body_has_dynamic_barrier(
11019:             "interp eval slave $body",
11020:             &r,
11021:             tcl_lexer::LexerConfig::default()
11022:         ));
11023:         // TN — a braced literal script relaxes, and its own contents are
11024:         // still recursed.
11025:         assert!(!body_has_dynamic_barrier(
11026:             "namespace eval ns {set x 1}",
11027:             &r,
11028:             tcl_lexer::LexerConfig::default()
11029:         ));
11030:         assert!(body_has_dynamic_barrier(
11031:             "namespace eval ns {eval $x}",
11032:             &r,
11033:             tcl_lexer::LexerConfig::default()
11034:         ));
11035:         // TN — a `namespace` subcommand that evaluates nothing is not a
11036:         // barrier, however dynamic its arguments are.
11037:         assert!(!body_has_dynamic_barrier(
11038:             "namespace delete $ns",
11039:             &r,
11040:             tcl_lexer::LexerConfig::default()
11041:         ));
11042:         assert!(!body_has_dynamic_barrier(
11043:             "namespace current",
11044:             &r,
11045:             tcl_lexer::LexerConfig::default()
11046:         ));
11047:     }
11048: 
11049:     /// TN for the barrier test itself: an ordinary command with a
11050:     /// substituted argument is not a script evaluator, so it never poisons —
11051:     /// the gate keys on the registry trait, not on "has a `$var` argument".
11052:     #[test]
11053:     fn body_has_dynamic_barrier_non_body_command_is_clean() {
11054:         let r = reg();
11055:         assert!(!body_has_dynamic_barrier(
11056:             "set x $y",
11057:             &r,
11058:             tcl_lexer::LexerConfig::default()
11059:         ));
11060:         assert!(!body_has_dynamic_barrier(
11061:             "puts [format %s $x]",
11062:             &r,
11063:             tcl_lexer::LexerConfig::default()
11064:         ));
11065:         assert!(!body_has_dynamic_barrier(
11066:             "lappend acc $item",
11067:             &r,
11068:             tcl_lexer::LexerConfig::default()
11069:         ));
11070:         // A user command the registry does not know at all is not a barrier.
11071:         assert!(!body_has_dynamic_barrier(
11072:             "mycmd $script",
11073:             &r,
11074:             tcl_lexer::LexerConfig::default()
11075:         ));
11076:     }
11077: 
11078:     #[test]
11079:     fn try_lower_eval_static_rejects_nested_dynamic_barrier() {
11080:         // The relaxer would normally promote ``eval { ... }`` to a
11081:         // ``Statement::Block``; with the barrier gate, the nested
11082:         // ``eval $x`` poisons the relaxation and we fall back to
11083:         // ``Statement::Barrier``.
11084:         let m = lower_to_ir(r"eval { eval $x }", &reg());
11085:         let stmt = m.top_level.statements.first().expect("at least one stmt");
11086:         assert_runtime_opaque_call(stmt, &reg(), "eval");
11087:     }
11088: 
11089:     #[test]
11090:     fn try_lower_eval_static_clean_body_relaxes() {
11091:         // No nested barrier — relaxes to Block.
11092:         let m = lower_to_ir("eval { set x 1 }", &reg());
11093:         let stmt = m.top_level.statements.first().expect("at least one stmt");
11094:         let Statement::Block { error_context, .. } = stmt else {
11095:             panic!("expected Block (relaxed), got {stmt:?}");
11096:         };
11097:         assert_eq!(
11098:             *error_context,
11099:             Some(tcl_registry::InlineBodyErrorContext::SameFrameScriptEvaluation),
11100:         );
11101:     }
11102: 
11103:     // The next three tests confirm `eval` and `uplevel` dispatch
11104:     // through the registry-driven hook ID to the expected output.
11105: 
11106:     #[test]
11107:     fn registry_dispatch_eval_static_body_lowers_to_block() {
11108:         // `eval {body}` with a literal body should still relax
11109:         // to `Statement::Block` when dispatched through the
11110:         // registry-driven path.
11111:         let m = lower_to_ir("eval { set y 2 }", &reg());
11112:         let stmt = m.top_level.statements.first().expect("at least one stmt");
11113:         assert!(
11114:             matches!(stmt, Statement::Block { .. }),
11115:             "expected Block via registry hook, got {stmt:?}",
11116:         );
11117:     }
11118: 
11119:     #[test]
11120:     fn registry_dispatch_uplevel_static_body_lowers_to_upframe() {
11121:         // `uplevel 1 {body}` with a literal body should lower
11122:         // to a UpFrame via the registry-driven path.
11123:         let m = lower_to_ir("uplevel 1 { set z 3 }", &reg());
11124:         let stmt = m.top_level.statements.first().expect("at least one stmt");
11125:         assert!(
11126:             matches!(stmt, Statement::UpFrame { .. }),
11127:             "expected UpFrame via registry hook, got {stmt:?}",
11128:         );
11129:     }
11130: 
11131:     #[test]
11132:     fn registry_dispatch_unknown_command_falls_through_to_default() {
11133:         // `lower_command` has no per-
11134:         // name fallback — commands that aren't in the registry
11135:         // (or whose `lowering_hook` is `None`) route directly
11136:         // to [`Lowerer::lower_default`], which emits a generic
11137:         // `Statement::Call`.  Pin that contract with a clearly
11138:         // unknown command name.
11139:         let m = lower_to_ir("totallyMadeUpCommand arg1 arg2", &reg());
11140:         let stmt = m.top_level.statements.first().expect("at least one stmt");
11141:         match stmt {
11142:             Statement::Call { command, .. } => assert_eq!(
11143:                 command, "totallyMadeUpCommand",
11144:                 "expected generic Call via lower_default, got command={command}",
11145:             ),
11146:             other => panic!("expected Call via lower_default, got {other:?}"),
11147:         }
11148:     }
11149: 
11150:     #[test]
11151:     fn deferred_tk_callback_does_not_hide_constructor_variable_defs() {
11152:         let m = lower_to_ir(
11153:             "entry .e -textvariable input -validatecommand {return 1}",
11154:             &reg(),
11155:         );
11156:         let stmt = m.top_level.statements.first().expect("entry call");
11157:         match stmt {
11158:             Statement::Call { command, defs, .. } => {
11159:                 assert_eq!(command, "entry");
11160:                 assert_eq!(defs, &["::input"]);
11161:             }
11162:             other => panic!("deferred callback must not make the constructor opaque: {other:?}"),
11163:         }
11164:     }
11165: 
11166:     #[test]
11167:     fn immediate_tcltest_body_remains_a_runtime_barrier() {
11168:         let m = lower_to_ir(
11169:             "tcltest::test sample description -body {error failure}",
11170:             &reg(),
11171:         );
11172:         let stmt = m.top_level.statements.first().expect("test call");
11173:         assert_runtime_opaque_call(stmt, &reg(), "tcltest::test");
11174:     }
11175: 
11176:     #[test]
11177:     fn same_invocation_command_prefix_is_a_runtime_barrier() {
11178:         // naming.compiler.original-analysis-metadata-context
11179:         // docs/design/analysis/name-resolution-proofs/original-analysis-metadata-context.md
11180:         let m = lower_to_ir("lsort -command compare {b a}", &reg());
11181:         let stmt = m.top_level.statements.first().expect("lsort call");
11182:         assert_runtime_opaque_call(stmt, &reg(), "lsort");
11183:     }
11184: 
11185:     #[test]
11186:     fn deferred_command_prefix_does_not_create_a_runtime_barrier() {
11187:         // naming.compiler.original-analysis-metadata-context
11188:         // docs/design/analysis/name-resolution-proofs/original-analysis-metadata-context.md
11189:         for (source, expected_command) in [
11190:             ("scrollbar .s -command moved", "scrollbar"),
11191:             ("trace add variable v write changed", "trace"),
11192:         ] {
11193:             let m = lower_to_ir(source, &reg());
11194:             let stmt = m.top_level.statements.first().expect("callback host call");
11195:             assert!(
11196:                 matches!(stmt, Statement::Call { command, .. } if command == expected_command),
11197:                 "a stored command prefix cannot affect its registration invocation: {stmt:?}",
11198:             );
11199:         }
11200:     }
11201: 
11202:     #[test]
11203:     fn complete_logical_source_keeps_original_structure_and_native_absence() {
11204:         // naming.compiler.original-analysis-metadata-context
11205:         // docs/design/analysis/name-resolution-proofs/original-analysis-metadata-context.md
11206:         let context =
11207:             tcl_registry::model::ingress::resolve_environment("tcl9.1").default_context_registry();
11208:         let profile = tcl_dialect::DialectProfile::plain_tcl();
11209:         let input = crate::analyser::ResolvedAnalysisInput::new(
11210:             profile,
11211:             profile,
11212:             std::sync::Arc::clone(&context),
11213:             tcl_lexer::LexerConfig::for_file_grammar(profile.grammar),
11214:         );
11215:         let source = "proc subject {} {return VALUE}; set result VALUE";
11216:         let mut current = Lowerer::with_config(context.commands(), input.lexer_config())
11217:             .with_resolved_analysis_input(input.clone());
11218:         current.lower(source);
11219:         let module = current.finish_module(source);
11220:         assert!(fixture_id_if_present(&module.procedures, "::subject").is_some());
11221:         // Upstream keeps non-numeric bare literals as AssignValue so escape
11222:         // spelling survives. This assertion covers IR/source ownership only.
11223:         let statement = module.top_level.statements.iter().find(|statement| {
11224:             matches!(statement, Statement::AssignValue { name, value, value_needs_backsubst: false, .. }
11225:                 if name == "result" && value == "VALUE")
11226:         }).expect("unchanged literal assignment retains the upstream representation");
11227:         let tokens = module
11228:             .top_level
11229:             .retained_source_tokens_for_statement(statement)
11230:             .unwrap();
11231:         let literal = crate::type_infer::original_literal_argument_contents(
11232:             context.commands(),
11233:             &module,
11234:             tokens,
11235:             1,
11236:         )
11237:         .expect("assignment retains its genuine original source");
11238:         assert_eq!(literal.value(), "VALUE");
11239:         assert_eq!(
11240:             module.source_entry.logical_source_input.as_ref(),
11241:             Some(&input)
11242:         );
11243:         assert!(module.source_entry.native_entry.is_none());
11244:         assert!(module.source_entry.execution_name_policy.is_none());
11245: 
11246:         let mut stale = Lowerer::with_config(context.commands(), input.lexer_config());
11247:         stale.config.strict_quoting = !stale.config.strict_quoting;
11248:         stale = stale.with_resolved_analysis_input(input.clone());
11249:         assert!(!fixture_id_if_present(&stale.lower(source).procedures, "::subject").is_some());
11250:         let foreign = crate::analyser::ResolvedAnalysisInput::new(
11251:             profile,
11252:             profile,
11253:             tcl_registry::model::ingress::resolve_environment("tcl8.6").default_context_registry(),
11254:             input.lexer_config(),
11255:         );
11256:         let mut foreign = Lowerer::with_config(context.commands(), foreign.lexer_config())
11257:             .with_resolved_analysis_input(foreign);
11258:         assert!(!fixture_id_if_present(&foreign.lower(source).procedures, "::subject").is_some());
11259: 
11260:         let native_profile = context.commands().profile().unwrap();
11261:         let native = crate::analyser::ResolvedAnalysisInput::new(
11262:             native_profile,
11263:             native_profile,
11264:             std::sync::Arc::clone(&context),
11265:             tcl_lexer::LexerConfig::for_file_grammar(native_profile.grammar),
11266:         );
11267:         let mut absent = Lowerer::with_config(context.commands(), native.lexer_config())
11268:             .with_resolved_analysis_input(native);
11269:         let module = absent.lower(source);
11270:         assert!(!fixture_id_if_present(&module.procedures, "::subject").is_some());
11271:         assert!(module.source_entry.logical_source_input.is_none());
11272:         assert!(module.source_entry.native_entry.is_none());
11273:         assert!(module.source_entry.unknown_entry);
11274:     }
11275: 
11276:     #[test]
11277:     fn logical_original_declaration_layout_keeps_unicode_and_qualified_alias_heads() {
11278:         // naming.compiler.original-analysis-metadata-context
11279:         // docs/design/analysis/name-resolution-proofs/original-analysis-metadata-context.md
11280:         // These exact UTF-8 source spellings exercise conditional Logical
11281:         // layout selection, independently of any Native slot or execution.
11282:         let context =
11283:             tcl_registry::model::ingress::resolve_environment("tcl9.1").default_context_registry();
11284:         let profile = tcl_dialect::DialectProfile::plain_tcl();
11285:         let input = crate::analyser::ResolvedAnalysisInput::new(
11286:             profile,
11287:             profile,
11288:             std::sync::Arc::clone(&context),
11289:             tcl_lexer::LexerConfig::for_file_grammar(profile.grammar),
11290:         );
11291:         for source in [
11292:             "rename proc ::α; ::α subject {} {return VALUE}",
11293:             "interp alias {} ::α {} proc; ::α subject {} {return VALUE}",
11294:             "rename proc ::α; interp alias {} ::β {} ::α; ::β subject {} {return VALUE}",
11295:             r"rename proc ::α; \u003a\u003aα subject {} {return VALUE}",
11296:         ] {
11297:             let mut lowerer = Lowerer::with_config(context.commands(), input.lexer_config())
11298:                 .with_resolved_analysis_input(input.clone());
11299:             let module = lowerer.lower(source);
11300:             assert!(
11301:                 fixture_id_if_present(&module.procedures, "::subject").is_some(),
11302:                 "{source}"
11303:             );
11304:             assert!(module.source_entry.native_entry.is_none());
11305:             assert!(module.source_entry.execution_name_policy.is_none());
11306:             assert_eq!(
11307:                 module.source_entry.logical_source_input.as_ref(),
11308:                 Some(&input)
11309:             );
11310:         }
11311:         for source in [
11312:             "interp alias {} ::α {} proc subject; ::α {} {return VALUE}",
11313:             "interp alias {} ::α {} proc subject {}; ::α {return VALUE}",
11314:         ] {
11315:             let mut lowerer = Lowerer::with_config(context.commands(), input.lexer_config())
11316:                 .with_resolved_analysis_input(input.clone());
11317:             let module = lowerer.lower(source);
11318:             let procedure = fixture_id_if_present(&module.procedures, "::subject")
11319:                 .and_then(|id| module.procedures.get(&id))
11320:                 .expect("captured source declaration");
11321:             assert!(procedure.params.is_empty());
11322:             assert_eq!(procedure.params_raw, "");
11323:             assert!(module.source_entry.native_entry.is_none());
11324:         }
11325:         let source = "rename proc ::α; ::α ::α args {return PAYLOAD}; ::α subject {} {}";
11326:         let mut replaced = Lowerer::with_config(context.commands(), input.lexer_config())
11327:             .with_resolved_analysis_input(input);
11328:         assert!(!fixture_id_if_present(&replaced.lower(source).procedures, "::subject").is_some());
11329:     }
11330: 
11331:     #[test]
11332:     fn complete_source_input_declines_changed_unit_profile_without_authoring_fallback() {
11333:         // naming.compiler.original-analysis-metadata-context
11334:         // docs/design/analysis/name-resolution-proofs/original-analysis-metadata-context.md
11335:         let context =
11336:             tcl_registry::model::ingress::resolve_environment("tcl8.6").default_context_registry();
11337:         let profile = tcl_dialect::DialectProfile::plain_tcl();
11338:         let input = crate::analyser::ResolvedAnalysisInput::new(
11339:             profile,
11340:             profile,
11341:             std::sync::Arc::clone(&context),
11342:             tcl_lexer::LexerConfig::from_grammar(profile.grammar),
11343:         );
11344:         let selected = Lowerer::with_config(context.commands(), input.lexer_config())
11345:             .with_resolved_analysis_input(input.clone());
11346:         assert!(selected.invocation_metadata_context().is_some());
11347:         assert_eq!(selected.logical_source_input.as_ref(), Some(&input));
11348:         let mut wrong = Lowerer::with_config(context.commands(), input.lexer_config())
11349:             .with_dialect(Some(tcl_dialect::DialectProfile::find("tcl8.6").unwrap()))
11350:             .with_resolved_analysis_input(input.clone());
11351:         assert!(wrong.invocation_metadata_context().is_none());
11352:         assert!(wrong.unknown_entry);
11353:         let module = wrong.lower("puts VALUE");
11354:         assert_eq!(module.source_metadata_input.as_ref(), Some(&input));
11355:         assert!(module.source_entry.unknown_entry);
11356:         assert!(module.source_entry.logical_source_input.is_none());
11357:     }
11358: 
11359:     #[test]
11360:     fn lowered_generic_metadata_keeps_supplied_context_and_refuses_missing_driver_input() {
11361:         // naming.compiler.original-analysis-metadata-context
11362:         // docs/design/analysis/name-resolution-proofs/original-analysis-metadata-context.md
11363:         let context = tcl_registry::model::ingress::context_for_profile(
11364:             tcl_registry::model::ingress::resolve_environment("tcl8.6").analyser_profile(),
11365:         );
11366:         let registry = context.commands();
11367:         let config = tcl_lexer::LexerConfig::for_dialect("tcl8.6");
11368:         let mut missing = Lowerer::with_config(registry, config).with_dialect(registry.profile());
11369:         missing.set_source_analysis_options(SourceAnalysisOptions::default());
11370:         missing = missing.with_dialect(registry.profile());
11371:         assert!(missing.invocation_metadata_context().is_none());
11372:         assert!(
11373:             missing
11374:                 .lower("puts retained")
11375:                 .source_metadata_input
11376:                 .is_none()
11377:         );
11378:         let mut supplied = Lowerer::with_config(registry, config)
11379:             .with_context_registry(std::sync::Arc::clone(&context))
11380:             .with_dialect(registry.profile());
11381:         supplied.set_source_analysis_options(SourceAnalysisOptions::default());
11382:         assert!(
11383:             supplied
11384:                 .invocation_metadata_context()
11385:                 .unwrap()
11386:                 .matches_registry(registry)
11387:         );
11388:         let module = supplied.lower("puts retained");
11389:         assert!(std::sync::Arc::ptr_eq(
11390:             &module
11391:                 .source_metadata_input
11392:                 .as_ref()
11393:                 .unwrap()
11394:                 .context_registry(),
11395:             &context
11396:         ));
11397:         let foreign = tcl_registry::model::ingress::context_for_profile(
11398:             tcl_registry::model::ingress::resolve_environment("tcl9.1").analyser_profile(),
11399:         );
11400:         let mut wrong = Lowerer::with_config(registry, config)
11401:             .with_context_registry(std::sync::Arc::clone(&foreign));
11402:         wrong.set_source_analysis_options(SourceAnalysisOptions::default());
11403:         assert!(
11404:             !wrong
11405:                 .invocation_metadata_context()
11406:                 .unwrap()
11407:                 .matches_registry(registry)
11408:         );
11409:         assert!(!wrong.safe_on_uninit("incr", &["value".to_owned()]));
11410:         let older = std::sync::Arc::new(
11411:             tcl_registry::model::ingress::static_context_for("tcl8.4")
11412:                 .with_command_store(std::sync::Arc::clone(registry)),
11413:         );
11414:         let actual = Lowerer::with_config(registry, config)
11415:             .with_dialect(registry.profile())
11416:             .with_context_registry(older);
11417:         assert!(!actual.safe_on_uninit("incr", &["value".to_owned()]));
11418:         let current = Lowerer::with_config(registry, config)
11419:             .with_dialect(registry.profile())
11420:             .with_context_registry(std::sync::Arc::clone(&context));
11421:         assert!(current.safe_on_uninit("incr", &["value".to_owned()]));
11422:     }
11423: 
11424:     #[test]
11425:     fn reference_only_command_prefix_does_not_create_a_runtime_barrier() {
11426:         // naming.compiler.original-analysis-metadata-context
11427:         // docs/design/analysis/name-resolution-proofs/original-analysis-metadata-context.md
11428:         let m = lower_to_ir("trace remove variable v write changed", &reg());
11429:         let stmt = m.top_level.statements.first().expect("trace remove call");
11430:         assert!(
11431:             matches!(stmt, Statement::Call { command, .. } if command == "trace"),
11432:             "matching a prior registration does not execute the prefix: {stmt:?}",
11433:         );
11434:     }
11435: 
11436:     // These tests pin the registry-driven hook-ID dispatch of `if`,
11437:     // `switch`, `for`, `while`, `catch`, `try` to the expected shape.
11438: 
11439:     #[test]
11440:     fn registry_dispatch_if_lowers_to_if() {
11441:         let m = lower_to_ir("if {1} { set q 4 }", &reg());
11442:         let stmt = m.top_level.statements.first().expect("at least one stmt");
11443:         assert!(
11444:             matches!(stmt, Statement::If { .. }),
11445:             "expected If via registry hook, got {stmt:?}",
11446:         );
11447:     }
11448: 
11449:     #[test]
11450:     fn registry_dispatch_switch_lowers_to_switch() {
11451:         let m = lower_to_ir("switch a { a { set q 1 } b { set q 2 } }", &reg());
11452:         let stmt = m.top_level.statements.first().expect("at least one stmt");
11453:         assert!(
11454:             matches!(stmt, Statement::Switch { .. }),
11455:             "expected Switch via registry hook, got {stmt:?}",
11456:         );
11457:     }
11458: 
11459:     #[test]
11460:     fn registry_dispatch_for_lowers_to_for() {
11461:         let m = lower_to_ir("for {set i 0} {$i < 3} {incr i} { set q $i }", &reg());
11462:         let stmt = m.top_level.statements.first().expect("at least one stmt");
11463:         assert!(
11464:             matches!(stmt, Statement::For { .. }),
11465:             "expected For via registry hook, got {stmt:?}",
11466:         );
11467:     }
11468: 
11469:     #[test]
11470:     fn registry_dispatch_while_lowers_to_while() {
11471:         let m = lower_to_ir("while {0} { set q 1 }", &reg());
11472:         let stmt = m.top_level.statements.first().expect("at least one stmt");
11473:         assert!(
11474:             matches!(stmt, Statement::While { .. }),
11475:             "expected While via registry hook, got {stmt:?}",
11476:         );
11477:     }
11478: 
11479:     #[test]
11480:     fn registry_dispatch_catch_lowers_to_catch() {
11481:         let m = lower_to_ir("catch { set q 1 }", &reg());
11482:         let stmt = m.top_level.statements.first().expect("at least one stmt");
11483:         assert!(
11484:             matches!(stmt, Statement::Catch { .. }),
11485:             "expected Catch via registry hook, got {stmt:?}",
11486:         );
11487:     }
11488: 
11489:     #[test]
11490:     fn registry_dispatch_try_lowers_to_try() {
11491:         let m = lower_to_ir("try { set q 1 } on error e { set q 2 }", &reg());
11492:         let stmt = m.top_level.statements.first().expect("at least one stmt");
11493:         assert!(
11494:             matches!(stmt, Statement::Try { .. }),
11495:             "expected Try via registry hook, got {stmt:?}",
11496:         );
11497:     }
11498: 
11499:     // `proc`, `namespace eval`, `foreach`, `lmap`, `dict` dispatch
11500:     // through registry-driven hook-ID, with shape preconditions
11501:     // enforced inside each match arm.
11502: 
11503:     #[test]
11504:     fn registry_dispatch_proc_lowers_to_proc_call_and_registers_procedure() {
11505:         let m = lower_to_ir("proc greet {name} { puts hi }", &reg());
11506:         let stmt = m.top_level.statements.first().expect("at least one stmt");
11507:         match stmt {
11508:             Statement::Call { command, .. } => assert_eq!(
11509:                 command, "proc",
11510:                 "expected `proc` call via registry hook, got command={command}",
11511:             ),
11512:             other => panic!("expected Call via registry hook, got {other:?}"),
11513:         }
11514:         assert!(
11515:             fixture_id_if_present(&m.procedures, "::greet").is_some(),
11516:             "expected ::greet to be registered in module.procedures, got keys={:?}",
11517:             m.procedures.keys().collect::<Vec<_>>(),
11518:         );
11519:     }
11520: 
11521:     #[test]
11522:     fn registry_dispatch_proc_wrong_arity_falls_through_to_default() {
11523:         // `proc` with two args — fails the `args.len() == 3`
11524:         // precondition.  The registry-driven path returns None,
11525:         // falls through to the residual string match's
11526:         // `_ => lower_default(...)` arm, which produces a
11527:         // runtime `Call` rather than registering a procedure.
11528:         let m = lower_to_ir("proc greet onlytwo", &reg());
11529:         let stmt = m.top_level.statements.first().expect("at least one stmt");
11530:         assert!(
11531:             matches!(stmt, Statement::Call { .. }),
11532:             "expected Call via lower_default fallback, got {stmt:?}",
11533:         );
11534:         assert!(
11535:             !fixture_id_if_present(&m.procedures, "::greet").is_some(),
11536:             "expected ::greet NOT to be registered when arity is wrong",
11537:         );
11538:     }
11539: 
11540:     #[test]
11541:     fn registry_dispatch_namespace_eval_lowers_to_barrier() {
11542:         // `lower_namespace_eval` emits a `Statement::Barrier`
11543:         // tagged with `reason: "namespace eval"`.
11544:         let m = lower_to_ir("namespace eval ::myns { set q 1 }", &reg());
11545:         let stmt = m.top_level.statements.first().expect("at least one stmt");
11546:         match stmt {
11547:             Statement::Barrier { reason, .. } => assert_eq!(
11548:                 reason, "namespace eval",
11549:                 "expected `namespace eval` barrier via registry hook, got reason={reason}",
11550:             ),
11551:             other => panic!("expected Barrier via registry hook, got {other:?}"),
11552:         }
11553:     }
11554: 
11555:     #[test]
11556:     fn registry_dispatch_namespace_non_eval_subcommand_falls_through() {
11557:         // `namespace import` has no `lowering_hook` on its
11558:         // subcommand spec, so `resolve_call` returns hook=None.
11559:         // The registry-driven dispatcher returns None and the
11560:         // residual string match's `_ => lower_default(...)`
11561:         // arm produces a generic `Call`.
11562:         let m = lower_to_ir("namespace import ::foo::*", &reg());
11563:         let stmt = m.top_level.statements.first().expect("at least one stmt");
11564:         assert!(
11565:             matches!(stmt, Statement::Call { .. }),
11566:             "expected Call via lower_default fallback, got {stmt:?}",
11567:         );
11568:     }
11569: 
11570:     #[test]
11571:     fn registry_dispatch_foreach_lowers_to_foreach() {
11572:         let m = lower_to_ir("foreach v {1 2 3} { set q $v }", &reg());
11573:         let stmt = m.top_level.statements.first().expect("at least one stmt");
11574:         assert!(
11575:             matches!(stmt, Statement::Foreach { .. }),
11576:             "expected Foreach via registry hook, got {stmt:?}",
11577:         );
11578:     }
11579: 
11580:     #[test]
11581:     fn registry_dispatch_lmap_lowers_to_foreach() {
11582:         // `lmap` shares `lower_foreach(... is_lmap=true)` with
11583:         // `foreach`; both produce `Statement::Foreach`.
11584:         let m = lower_to_ir("lmap v {1 2 3} { expr {$v + 1} }", &reg());
11585:         let stmt = m.top_level.statements.first().expect("at least one stmt");
11586:         assert!(
11587:             matches!(stmt, Statement::Foreach { .. }),
11588:             "expected Foreach (is_lmap=true) via registry hook, got {stmt:?}",
11589:         );
11590:     }
11591: 
11592:     #[test]
11593:     fn registry_dispatch_dict_lowers_via_lower_dict() {
11594:         // `dict set d k v` exercises the `lower_dict`
11595:         // subcommand-dispatch path.  Pin the registry-driven
11596:         // route by checking the canonical command name on the
11597:         // emitted Call.
11598:         let m = lower_to_ir("dict set d k v", &reg());
11599:         let stmt = m.top_level.statements.first().expect("at least one stmt");
11600:         match stmt {
11601:             Statement::Call { command, .. } => assert_eq!(
11602:                 command, "dict",
11603:                 "expected `dict` call via registry hook, got command={command}",
11604:             ),
11605:             other => panic!("expected Call via registry hook, got {other:?}"),
11606:         }
11607:     }
11608: 
11609:     #[test]
11610:     fn registry_dispatch_dict_empty_args_falls_through_to_default() {
11611:         // Bare `dict` — fails the `!args.is_empty()`
11612:         // precondition, falls through to `lower_default`.
11613:         let m = lower_to_ir("dict", &reg());
11614:         let stmt = m.top_level.statements.first().expect("at least one stmt");
11615:         assert!(
11616:             matches!(stmt, Statement::Call { .. }),
11617:             "expected Call via lower_default fallback, got {stmt:?}",
11618:         );
11619:     }
11620: 
11621:     // `when` and `foreachLine` dispatch through registry-driven
11622:     // hook-ID.  `when` is dialect-gated (iRules), so its test
11623:     // registry loads the dialect explicitly.  `foreachLine` is
11624:     // a Tcl 9.0+ command always registered in `build_default()`.
11625: 
11626:     #[test]
11627:     fn registry_dispatch_when_lowers_via_lower_when_with_irules_loaded() {
11628:         // The iRules `when` spec carries `LoweringHookId::When`
11629:         // and only enters the registry after
11630:         // `load_dialect(IRULES)`.  Production callers (the LSP
11631:         // server) always pair `build_default()`
11632:         // with the active dialect; this test mirrors that.
11633:         let profile = tcl_dialect::DialectProfile::irules();
11634:         let registry = tcl_registry::model::ingress::static_context_for_profile(profile).commands();
11635:         let m = lower_to_ir_with_config(
11636:             "when HTTP_REQUEST { set q 1 }",
11637:             registry,
11638:             tcl_lexer::LexerConfig::for_profile(Some(profile)),
11639:         );
11640:         let stmt = m.top_level.statements.first().expect("at least one stmt");
11641:         match stmt {
11642:             Statement::Call { command, .. } => assert_eq!(
11643:                 command, "when",
11644:                 "expected `when` call via registry hook, got command={command}",
11645:             ),
11646:             other => panic!("expected Call via registry hook, got {other:?}"),
11647:         }
11648:         assert!(
11649:             fixture_id_if_present(&m.procedures, "::when::HTTP_REQUEST").is_some(),
11650:             "expected ::when::HTTP_REQUEST procedure to be registered, got keys={:?}",
11651:             m.procedures.keys().collect::<Vec<_>>(),
11652:         );
11653:     }
11654: 
11655:     #[test]
11656:     fn registry_dispatch_when_without_irules_loaded_falls_through() {
11657:         // Without `load_irules()`, the registry has no `when`
11658:         // spec, so `resolve_call` returns `None` and
11659:         // `try_dispatch_structured_hook` falls through to
11660:         // `lower_default`.  This is a misconfiguration on the
11661:         // caller's side (the source uses iRules but the
11662:         // registry doesn't know about it); the lowerer emits a
11663:         // generic `Call` rather than silently treating it as
11664:         // an event handler.  Pinning this behaviour catches
11665:         // future drift if `build_default()` ever folds in
11666:         // iRules.
11667:         let m = lower_to_ir("when HTTP_REQUEST { set q 1 }", &reg());
11668:         let stmt = m.top_level.statements.first().expect("at least one stmt");
11669:         match stmt {
11670:             Statement::Call { command, .. } => assert_eq!(
11671:                 command, "when",
11672:                 "expected generic Call via lower_default, got command={command}",
11673:             ),
11674:             other => panic!("expected Call via lower_default, got {other:?}"),
11675:         }
11676:         assert!(
11677:             !m.procedures
11678:                 .values()
11679:                 .any(|body| body.qualified_name.starts_with("::when::")),
11680:             "expected NO ::when::* procedure registered without iRules loaded",
11681:         );
11682:     }
11683: 
11684:     #[test]
11685:     fn registry_dispatch_foreach_line_lowers_via_lower_foreach_line() {
11686:         // `foreachLine` is a Tcl 9.0+ command (TIP 670) and
11687:         // `build_default()` registers it via the
11688:         // `tcl::foreachline` spec.  No dialect-load dance is
11689:         // needed.  The body is a brace-string literal here, so
11690:         // the dedicated lowerer relaxes to a typed `Foreach`
11691:         // (not a barrier).
11692:         let m = lower_to_ir("foreachLine line readme.txt { set q $line }", &reg());
11693:         let stmt = m.top_level.statements.first().expect("at least one stmt");
11694:         assert!(
11695:             matches!(stmt, Statement::Foreach { .. }),
11696:             "expected Foreach via registry hook, got {stmt:?}",
11697:         );
11698:     }
11699: 
11700:     #[test]
11701:     fn registry_dispatch_foreach_line_wrong_arity_falls_through_to_default() {
11702:         // `foreachLine` with two args — fails the
11703:         // `args.len() == 3` precondition, falls through to
11704:         // `lower_default`.
11705:         let m = lower_to_ir("foreachLine onlytwo args", &reg());
11706:         let stmt = m.top_level.statements.first().expect("at least one stmt");
11707:         match stmt {
11708:             Statement::Call { command, .. } => assert_eq!(
11709:                 command, "foreachLine",
11710:                 "expected generic Call via lower_default, got command={command}",
11711:             ),
11712:             other => panic!("expected Call via lower_default, got {other:?}"),
11713:         }
11714:     }
11715: 
11716:     /// `if {1} { if {1} { ... } }`, `depth` levels deep.
11717:     fn nested_if_source(depth: u32) -> String {
11718:         let mut source = String::new();
11719:         for _ in 0..depth {
11720:             source.push_str("if {1} {\n");
11721:         }
11722:         for _ in 0..depth {
11723:             source.push_str("}\n");
11724:         }
11725:         source
11726:     }
11727: 
11728:     /// Depth-first search for a [`Statement::Barrier`] whose `reason`
11729:     /// contains `needle`, anywhere in `script`'s tree (into `If` clauses and
11730:     /// `else` bodies — the only nesting `nested_if_source` produces).
11731:     fn contains_barrier_reason(script: &Script, needle: &str) -> bool {
11732:         script.statements.iter().any(|stmt| match stmt {
11733:             Statement::Barrier { reason, .. } => reason.contains(needle),
11734:             Statement::If {
11735:                 clauses, else_body, ..
11736:             } => {
11737:                 clauses
11738:                     .iter()
11739:                     .any(|c| contains_barrier_reason(&c.body, needle))
11740:                     || else_body
11741:                         .as_ref()
11742:                         .is_some_and(|e| contains_barrier_reason(e, needle))
11743:             }
11744:             _ => false,
11745:         })
11746:     }
11747: 
11748:     /// `lower_script` / `lower_body` recurse one Rust frame group per `if`
11749:     /// nesting level, so they need the same depth cap as `analyse_body`
11750:     /// (`tcl_compiler::analyser::commands::MAX_BODY_DEPTH`) and
11751:     /// `cfg_builder::lower_script` (`MAX_LOWER_DEPTH`). A document whose IR
11752:     /// lowering runs unguarded defeats the CFG builder's own guard
11753:     /// downstream — the crash happens one stage earlier. Lowering 2000
11754:     /// levels must neither hang nor overflow the stack, and must record the
11755:     /// cap trip as a `Statement::Barrier` (unknown effects) rather than
11756:     /// silently truncating to an empty, falsely-dead-looking script.
11757:     #[test]
11758:     fn deeply_nested_if_past_max_lower_depth_barriers_not_crashes() {
11759:         let source = nested_if_source(2000);
11760:         // `cargo test` runs each test on a small default-stack thread — see
11761:         // the identical helper's doc comment in `analyser::commands::tests`.
11762:         let m = std::thread::Builder::new()
11763:             .stack_size(64 * 1024 * 1024)
11764:             .spawn(move || lower_to_ir(&source, &reg()))
11765:             .expect("spawn big-stack test thread")
11766:             .join()
11767:             .expect("lower_to_ir on big-stack thread panicked");
11768:         assert!(
11769:             contains_barrier_reason(&m.top_level, "nesting depth exceeds analysis limit"),
11770:             "expected a depth-cap Barrier somewhere in the lowered tree"
11771:         );
11772:     }
11773: 
11774:     /// Depth of the deepest chain of nested `If` statements in `script`.
11775:     fn if_chain_depth(script: &Script) -> u32 {
11776:         script
11777:             .statements
11778:             .iter()
11779:             .map(|stmt| match stmt {
11780:                 Statement::If { clauses, .. } => {
11781:                     1 + clauses.first().map_or(0, |c| if_chain_depth(&c.body))
11782:                 }
11783:                 _ => 0,
11784:             })
11785:             .max()
11786:             .unwrap_or(0)
11787:     }
11788: 
11789:     #[test]
11790:     fn shallow_nested_if_lowers_with_no_barrier() {
11791:         // False-positive guard: ordinary, hand-written nesting must lower
11792:         // as real `If` statements all the way down, never barriered.
11793:         let source = nested_if_source(10);
11794:         let m = lower_to_ir(&source, &reg());
11795:         assert!(
11796:             !contains_barrier_reason(&m.top_level, "nesting depth exceeds analysis limit"),
11797:             "shallow nesting must not trip the depth cap"
11798:         );
11799:         // 10 real nested `If`s, not a single opaque barrier standing in for
11800:         // all of them.
11801:         assert_eq!(if_chain_depth(&m.top_level), 10);
11802:     }
11803: 
11804:     /// Regression (JimTcl/iRules dialect drift): every re-lex of a *body*
11805:     /// this lowering performs takes its grammar from the document's own
11806:     /// [`tcl_lexer::LexerConfig`], not the Tcl 9.x default.
11807:     ///
11808:     /// `body_has_dynamic_barrier` re-segments a braced body to find a nested
11809:     /// dynamic `eval`/`uplevel`.  Under `f5-irules` the lexer treats `}{` as a
11810:     /// word separator, so `foo {a}{eval $x}` is **three** words and its third
11811:     /// is a braced script containing a dynamic `eval`; under the default
11812:     /// grammar the two braces weld into one compound word whose text is
11813:     /// `aeval $x`, whose head `aeval` is nobody's barrier.  Before the config
11814:     /// was threaded, the iRules document was re-segmented under Tcl rules and
11815:     /// the barrier was missed — the outer `eval` relaxed to inline IR that
11816:     /// runs a still-dynamic inner `eval`.
11817:     #[test]
11818:     fn body_relex_follows_the_document_dialect_not_the_default() {
11819:         let irules = tcl_dialect::DialectProfile::irules();
11820:         let irules_config = tcl_lexer::LexerConfig::from_grammar(irules.grammar);
11821:         let registry = tcl_registry::model::ingress::static_context_for_profile(irules).commands();
11822: 
11823:         let body = "foo {a}{eval $x}";
11824:         assert!(
11825:             !body_has_dynamic_barrier(body, registry, tcl_lexer::LexerConfig::default()),
11826:             "under the default grammar `}}{{` welds one word, so no nested barrier is visible"
11827:         );
11828:         assert!(
11829:             body_has_dynamic_barrier(body, registry, irules_config),
11830:             "under f5-irules `}}{{` separates words, exposing the nested dynamic `eval`"
11831:         );
11832: 
11833:         // End to end: the same fact decides whether the outer `eval` relaxes
11834:         // to an inline `Block` or stays a runtime `Barrier`.
11835:         let source = "eval {foo {a}{eval $x}}";
11836:         let irules_module = lower_to_ir_with_config(source, registry, irules_config);
11837:         assert_eq!(irules_module.top_level.statements.len(), 1);
11838:         assert_runtime_opaque_call(&irules_module.top_level.statements[0], registry, "eval");
11839: 
11840:         // Under the default grammar the weld makes `{a}{eval $x}` a *single*
11841:         // word, and that word is not valid Tcl — C answers `extra characters
11842:         // after close-brace` for this very body, on 8.6 and 9.0 alike. So the
11843:         // relaxation is declined here too, by the parse gate rather than the
11844:         // barrier gate (#1829): inlining would lower the malformed text with
11845:         // the lenient lowering and give it a meaning C never gives it.
11846:         let tcl_module =
11847:             lower_to_ir_with_config(source, registry, tcl_lexer::LexerConfig::default());
11848:         assert!(
11849:             matches!(
11850:                 tcl_module.top_level.statements.as_slice(),
11851:                 [Statement::Barrier { .. }]
11852:             ),
11853:             "a body that does not parse keeps the runtime barrier: {:?}",
11854:             tcl_module.top_level.statements
11855:         );
11856: 
11857:         // Positive control: the relaxation is still alive. A body with no
11858:         // nested barrier that *does* parse must still reach the inline Block,
11859:         // so neither assertion above can pass merely because relaxation
11860:         // stopped happening at all.
11861:         let relaxable = lower_to_ir_with_config(
11862:             "eval {foo a b}",
11863:             registry,
11864:             tcl_lexer::LexerConfig::default(),
11865:         );
11866:         assert!(
11867:             matches!(
11868:                 relaxable.top_level.statements.as_slice(),
11869:                 [Statement::Block { .. }]
11870:             ),
11871:             "a parsing, barrier-free body still relaxes to a Block: {:?}",
11872:             relaxable.top_level.statements
11873:         );
11874:     }
11875: 
11876:     /// `JimTcl`'s `$(…)` lowers as the expression it is, end to end from the
11877:     /// lexer: `set x $($a*2)` becomes the `AssignExpr` a `[expr {$a*2}]`
11878:     /// value produces, with the body anchored two bytes past the `$(` so
11879:     /// expression diagnostics land on the right source; `return $($a+1)`
11880:     /// carries its expression the same way.
11881:     #[test]
11882:     fn jim_expr_sugar_lowers_as_an_anchored_expression() {
11883:         let jim = tcl_registry::model::resolve_environment("jim").unit_profile();
11884:         let registry = tcl_registry::model::ingress::static_context_for_profile(jim).commands();
11885:         let config = tcl_lexer::LexerConfig::from_grammar(jim.grammar);
11886:         let module = lower_to_ir_with_config("set x $($a*2)\nreturn $($a+1)\n", registry, config);
11887:         let statements = module.top_level.statements.as_slice();
11888:         match statements {
11889:             [
11890:                 Statement::AssignExpr {
11891:                     name,
11892:                     expr,
11893:                     expr_base,
11894:                     command_binding,
11895:                     ..
11896:                 },
11897:                 Statement::Return {
11898:                     expr: return_expr, ..
11899:                 },
11900:             ] => {
11901:                 assert_eq!(name, "x");
11902:                 let rendered = format!("{expr:?}");
11903:                 assert!(rendered.contains('a'), "operand missing from {rendered}");
11904:                 // `set x ` is six bytes, `$(` two more: the body starts at 8.
11905:                 assert_eq!(*expr_base, Some(8), "the sugar body's absolute anchor");
11906:                 assert!(
11907:                     command_binding.is_none(),
11908:                     "Jim expression syntax must not manufacture an expr command binding"
11909:                 );
11910:                 assert!(return_expr.is_some(), "return $(…) carries its expression");
11911:             }
11912:             other => panic!("expected AssignExpr + Return; got {other:?}"),
11913:         }
11914:     }
11915: }
/* ORIGINAL_SOURCE_RANGE 11917..12223 */
11917: #[cfg(test)]
11918: mod original_script_purpose_tests {
11919: 
11920:     use super::*;
11921: 
11922:     fn first_invocation(script: &Script) -> &CommandTokens {
11923:         script
11924:             .statements
11925:             .iter()
11926:             .find_map(Statement::tokens)
11927:             .expect("retained original invocation")
11928:     }
11929: 
11930:     #[test]
11931:     fn original_whole_and_zero_base_body_parsers_keep_distinct_bom_purposes() {
11932:         // naming.source.original-configured-script-completeness
11933:         // docs/design/analysis/name-resolution-proofs/source-original-configured-script-completeness.md
11934:         // Parser purpose and retained source ancestry; no Native entry or Normal store.
11935:         let mut prepared = crate::analyser::Analyser::new();
11936:         let input = prepared.prepare_analysis_input("tcl9.1").unwrap();
11937:         let context = input.context_registry();
11938:         let registry = context.commands();
11939:         let source = "\u{feff}unknown argument";
11940:         for bom in [tcl_lexer::LeadingBom::Skip, tcl_lexer::LeadingBom::Content] {
11941:             let mut config = input.lexer_config();
11942:             config.leading_bom = bom;
11943:             config.braced_var = tcl_lexer::BracedVarStyle::FirstClose;
11944:             let supplied = crate::analyser::ResolvedAnalysisInput::new(
11945:                 input.analyser_profile(),
11946:                 input.unit_profile(),
11947:                 input.context_registry(),
11948:                 config,
11949:             );
11950:             let config = supplied.lexer_config();
11951:             let mut whole = Lowerer::with_config(registry, config)
11952:                 .with_resolved_analysis_input(supplied.clone());
11953:             let module = whole.lower(source);
11954:             let command = first_invocation(&module.top_level);
11955:             assert_eq!(
11956:                 command.argv_texts[0],
11957:                 if bom == tcl_lexer::LeadingBom::Skip {
11958:                     "unknown"
11959:                 } else {
11960:                     "\u{feff}unknown"
11961:                 }
11962:             );
11963:             assert_eq!(
11964:                 command.argv[0].start(),
11965:                 if bom == tcl_lexer::LeadingBom::Skip {
11966:                     3
11967:                 } else {
11968:                     0
11969:                 }
11970:             );
11971:             assert_eq!(module.lexer_config, config);
11972:             assert_eq!(module.source_metadata_input.as_ref(), Some(&supplied));
11973: 
11974:             let mut body = Lowerer::with_config(registry, config)
11975:                 .with_resolved_analysis_input(supplied.clone());
11976:             let script = body.lower_into_script(source, "::");
11977:             let command = first_invocation(&script);
11978:             assert_eq!(command.argv_texts[0], "\u{feff}unknown");
11979:             assert_eq!(command.argv[0].start(), 0);
11980:             assert_eq!(body.config, config);
11981:             assert_eq!(body.metadata_input.as_ref(), Some(&supplied));
11982:             if bom == tcl_lexer::LeadingBom::Skip {
11983:                 // This fresh local span space does not own a projected input.
11984:                 // Keep the actual parent input; mismatched metadata is terminal.
11985:                 assert!(
11986:                     body.source_metadata_input()
11987:                         .retain()
11988:                         .metadata_context_for_source(
11989:                             registry,
11990:                             config.nested(),
11991:                             Some(supplied.unit_profile())
11992:                         )
11993:                         .is_none()
11994:                 );
11995:             }
11996:             assert!(crate::registry_invocation::proved_native_inline_operation(command).is_none());
11997: 
11998:             // An explicit non-BOM grammar override is retained for body parsing.
11999:             let script = body.lower_into_script("puts \"${a{}\"", "::");
12000:             let command = first_invocation(&script);
12001:             assert_eq!(command.argv_texts, ["puts", "${a{}"]);
12002:             assert!(
12003:                 body.eval_subst_nocommands_body("\u{feff}subst -nocommands {literal}")
12004:                     .is_none()
12005:             );
12006:             assert!(eval_list_literal_body("\u{feff}list item", config).is_none());
12007:         }
12008:     }
12009: 
12010:     #[test]
12011:     fn original_selected_nested_body_keeps_parent_metadata_for_known_command_advice() {
12012:         // naming.source.original-registry-header-advice
12013:         // docs/design/analysis/name-resolution-proofs/original-registry-header-advice.md
12014:         // Existing original body inventory and metadata; no entered/Normal handler donation.
12015:         let mut prepared = crate::analyser::Analyser::new();
12016:         let input = prepared.prepare_analysis_input("tcl9.1").unwrap();
12017:         for bom in [tcl_lexer::LeadingBom::Skip, tcl_lexer::LeadingBom::Content] {
12018:             let mut config = input.lexer_config();
12019:             config.leading_bom = bom;
12020:             config.braced_var = tcl_lexer::BracedVarStyle::FirstClose;
12021:             let supplied = crate::analyser::ResolvedAnalysisInput::new(
12022:                 input.analyser_profile(),
12023:                 input.unit_profile(),
12024:                 input.context_registry(),
12025:                 config,
12026:             );
12027:             let context = supplied.context_registry();
12028:             let registry = context.commands();
12029:             let source = "eval {puts hi}";
12030:             let identities =
12031:                 crate::realm::document_realm_bindings_with_resolved_input(source, &supplied, None);
12032:             let parent = crate::segmenter::segment_commands_with_offset_and_config(
12033:                 source,
12034:                 0,
12035:                 supplied.lexer_config(),
12036:             )
12037:             .pop()
12038:             .unwrap();
12039:             let original = identities
12040:                 .executed_script_for_word(parent.argv[1].span)
12041:                 .unwrap();
12042:             let bindings = identities
12043:                 .source_bindings_ref()
12044:                 .selected_source(original)
12045:                 .unwrap();
12046:             let mut lowerer = Lowerer::with_config(registry, supplied.lexer_config())
12047:                 .with_resolved_analysis_input(supplied.clone());
12048:             lowerer.set_source_image_channel(&original.text);
12049:             let script = lowerer.lower_into_script_with_bindings(
12050:                 original.try_text().unwrap(),
12051:                 original.base(),
12052:                 "::",
12053:                 bindings,
12054:             );
12055:             let command = first_invocation(&script);
12056:             let site = command
12057:                 .source_binding
12058:                 .as_ref()
12059:                 .unwrap()
12060:                 .invocation_site()
12061:                 .unwrap();
12062:             assert_eq!(&site.source, &original.origin);
12063:             assert_eq!(site.offset, original.base());
12064:             assert_eq!(command.argv_texts, ["puts", "hi"]);
12065:             let advice = crate::registry_invocation::original_registry_invocation_assistance_with_metadata_context(
12066:                 registry, lowerer.invocation_metadata_context(), command).unwrap();
12067:             assert_eq!(advice.unanimous_command_words().unwrap().command(), "puts");
12068:             assert_eq!(lowerer.metadata_input.as_ref(), Some(&supplied));
12069:             let mut changed_config = supplied.lexer_config();
12070:             changed_config.strict_quoting = !changed_config.strict_quoting;
12071:             let changed = crate::analyser::ResolvedAnalysisInput::new(
12072:                 supplied.analyser_profile(),
12073:                 supplied.unit_profile(),
12074:                 supplied.context_registry(),
12075:                 changed_config,
12076:             );
12077:             assert!(
12078:                 crate::registry_invocation::InvocationMetadataContext::for_source_input(
12079:                     registry,
12080:                     &changed,
12081:                     supplied.lexer_config(),
12082:                     Some(supplied.unit_profile())
12083:                 )
12084:                 .is_none()
12085:             );
12086:         }
12087:     }
12088: 
12089:     #[test]
12090:     fn original_materialised_zero_base_body_keeps_its_selected_point_owner() {
12091:         // naming.source.original-configured-script-completeness
12092:         // docs/design/analysis/name-resolution-proofs/source-original-configured-script-completeness.md
12093:         // Actual original escaped body and selected derived source; no compiler/frame grant.
12094:         let mut prepared = crate::analyser::Analyser::new();
12095:         let input = prepared.prepare_analysis_input("tcl9.1").unwrap();
12096:         let context = input.context_registry();
12097:         let registry = context.commands();
12098:         let source = "eval \\uFEFFunknown";
12099:         let identities =
12100:             crate::realm::document_realm_bindings_with_resolved_input(source, &input, None);
12101:         let parent = crate::segmenter::segment_commands_with_offset_and_config(
12102:             source,
12103:             0,
12104:             input.lexer_config(),
12105:         )
12106:         .pop()
12107:         .unwrap();
12108:         let original = identities
12109:             .executed_script_for_word(parent.argv[1].span)
12110:             .expect("original evaluated script");
12111:         assert_eq!(original.base(), 0);
12112:         assert_eq!(
12113:             original.mapping,
12114:             crate::command_binding::ExecutedScriptMapping::Materialised
12115:         );
12116:         let body = original.try_text().unwrap();
12117:         assert_eq!(body, "\u{feff}unknown");
12118:         let bindings = identities
12119:             .source_bindings_ref()
12120:             .selected_source(original)
12121:             .unwrap();
12122:         assert_eq!(bindings.source_origin(), Some(&original.origin));
12123:         let mut lowerer = Lowerer::with_config(registry, input.lexer_config())
12124:             .with_resolved_analysis_input(input.clone());
12125:         lowerer.set_source_image_channel(&original.text);
12126:         let script = lowerer.lower_into_script_with_bindings(body, 0, "::", bindings);
12127:         let command = first_invocation(&script);
12128:         assert_eq!(command.argv_texts, ["\u{feff}unknown"]);
12129:         let site = command
12130:             .source_binding
12131:             .as_ref()
12132:             .unwrap()
12133:             .invocation_site()
12134:             .expect("actual derived point");
12135:         assert_eq!(site.offset, 0);
12136:         assert_eq!(&site.source, &original.origin);
12137:         assert_eq!(site.source.source_image().bytes(), body.as_bytes());
12138:         assert_eq!(
12139:             script.executed_source.as_ref().unwrap().origin,
12140:             original.origin
12141:         );
12142:         assert!(crate::registry_invocation::proved_native_inline_operation(command).is_none());
12143:         assert_eq!(lowerer.config, input.lexer_config());
12144:         assert_eq!(lowerer.metadata_input.as_ref(), Some(&input));
12145: 
12146:         // Equal derived text under another original parent has no retained point.
12147:         let foreign_parent = crate::command_binding::CommandAllocationSite {
12148:             source: std::sync::Arc::new(crate::command_binding::SourceOriginId::authored(
12149:                 &std::sync::Arc::from("eval $other"),
12150:             )),
12151:             offset: 0,
12152:         };
12153:         let foreign = crate::command_binding::ExecutedScriptSource::materialised(
12154:             foreign_parent,
12155:             vec![0],
12156:             body,
12157:         );
12158:         let foreign_bindings = identities
12159:             .source_bindings_ref()
12160:             .selected_source(&foreign)
12161:             .unwrap();
12162:         let refused = lowerer.lower_into_script_with_bindings(body, 0, "::", foreign_bindings);
12163:         assert!(
12164:             first_invocation(&refused)
12165:                 .source_binding
12166:                 .as_ref()
12167:                 .unwrap()
12168:                 .invocation_site()
12169:                 .is_none()
12170:         );
12171:     }
12172:     #[test]
12173:     fn original_definer_targets_keep_literal_data_distinct_from_scalar_references() {
12174:         for (target, expected) in [
12175:             ("{$obj}", "::@objdefine@::$obj"),
12176:             ("$obj", "::@objdefine@::obj"),
12177:             ("${two words}", "::@objdefine@::two words"),
12178:             ("{two words}", "::@objdefine@::two words"),
12179:             ("{}", "::@objdefine@::"),
12180:             ("{[obj]}", "::@objdefine@::[obj]"),
12181:         ] {
12182:             let source = format!("oo::objdefine {target} {{method m {{}} {{return VALUE}}}}");
12183:             let analysis = crate::analyser::Analyser::new().analyse(&source, "tcl");
12184:             let input = analysis.resolved_input.as_ref().unwrap();
12185:             let module = lower_to_ir_with(
12186:                 Lowerer::with_config(
12187:                     input.borrowed_context_registry().commands(),
12188:                     input.lexer_config(),
12189:                 )
12190:                 .with_resolved_analysis_input(input.clone()),
12191:                 &source,
12192:             );
12193:             let method = module
12194:                 .methods
12195:                 .values()
12196:                 .find(|method| method.method_name == "m")
12197:                 .expect("actual conditional original definition body");
12198:             assert_eq!(method.class_name, expected);
12199:             assert!(method.definition_scope.is_some());
12200:         }
12201:         for target in [
12202:             "$obj(key)",
12203:             "${obj(key)}",
12204:             "[pick]",
12205:             "x$obj",
12206:             "{nul\0receiver}",
12207:         ] {
12208:             let source = format!("oo::objdefine {target} {{method m {{}} {{return VALUE}}}}");
12209:             let analysis = crate::analyser::Analyser::new().analyse(&source, "tcl");
12210:             let input = analysis.resolved_input.as_ref().unwrap();
12211:             let module = lower_to_ir_with(
12212:                 Lowerer::with_config(
12213:                     input.borrowed_context_registry().commands(),
12214:                     input.lexer_config(),
12215:                 )
12216:                 .with_resolved_analysis_input(input.clone()),
12217:                 &source,
12218:             );
12219:             assert!(module.methods.is_empty());
12220:             assert!(module.oo_evidence.unretained_executable_roots);
12221:         }
12222:     }
12223: }
