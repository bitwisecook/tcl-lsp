/* ORIGINAL_SOURCE_RANGE 1..9760 */
1: // tcl-lsp — a language server and toolchain for Tcl
2: // Copyright (C) 2026 James Deucker (bitwisecook) <https://github.com/bitwisecook>
3: //
4: // This program is free software: you can redistribute it and/or modify
5: // it under the terms of the GNU Affero General Public License as published by
6: // the Free Software Foundation, either version 3 of the License, or
7: // (at your option) any later version.
8: //
9: // This program is distributed in the hope that it will be useful,
10: // but WITHOUT ANY WARRANTY; without even the implied warranty of
11: // MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
12: // GNU Affero General Public License for more details.
13: //
14: // You should have received a copy of the GNU Affero General Public License
15: // along with this program.  If not, see <https://www.gnu.org/licenses/>.
16: //
17: // SPDX-License-Identifier: AGPL-3.0-or-later
18: 
19: //! The value-transfer witnesses, program by program
20: //! (`docs/design/compiler/value-transfers-examples.md`).
21: //!
22: //! Each test drives the compiler the way a user reaches it — the shared
23: //! lattice through `CompilationUnit::build`, the rewrites through the
24: //! multipass optimiser — and, where the witness is a program's output,
25: //! runs the original and the optimised program under every `tclsh` release
26: //! found on `PATH`. A release that is not installed is skipped and the
27: //! test says which ran; none at all is reported, never skipped silently.
28: 
29: #[path = "support/body_identity.rs"]
30: mod body_identity;
31: use body_identity::fixture_id;
32: 
33: use std::io::Write as _;
34: use std::process::Command;
35: use std::sync::atomic::{AtomicUsize, Ordering};
36: 
37: use tcl_compiler::analyses::{ConstValue, LatticeValue};
38: use tcl_compiler::compilation_unit::CompilationUnit;
39: use tcl_compiler::interprocedural::{ConstantReturn, ProcSummary};
40: use tcl_compiler::intervals::{Interval, compute_intervals_with, numbers_for_dialect};
41: use tcl_compiler::ir::Statement;
42: use tcl_compiler::lowering::lower_to_ir_with_dialect;
43: use tcl_compiler::optimiser::Optimisation;
44: use tcl_compiler::optimiser::manager::{
45:     optimise_raw, optimise_source_multipass, optimise_unit, optimise_with_dialect,
46: };
47: use tcl_compiler::static_loops::{
48:     DEFAULT_MAX_STATIC_LOOP_ITERS, LoopSemantics, StaticEnv, StaticValue, summarise_for_statement,
49: };
50: use tcl_compiler::tcl_expr_eval::FoldPolicy;
51: use tcl_core_types::DiagCode;
52: use tcl_registry::model::ingress::{resolve_environment, static_context_for};
53: use tcl_registry::value_transfer::{BindingKind, Existence};
54: 
55: /// The releases the oracle runs, oldest first.
56: const RELEASES: [&str; 5] = ["8.4", "8.5", "8.6", "9.0", "9.1"];
57: 
58: /// The multipass optimiser's iteration ceiling for a witness program.
59: const PASSES: usize = 8;
60: 
61: /// The dialects the exit witnesses analyse under: a release per numeral
62: /// grammar and integer tower; `f5-irules`, a vendor dialect that evaluates
63: /// under the 8.4 base it declares (ruling 8); and the lenient `tcl` profile,
64: /// which declares no release, so every axis answers by unanimity (ruling 7).
65: const DIALECTS: [&str; 5] = ["tcl8.4", "tcl8.6", "tcl9.0", "f5-irules", "tcl"];
66: 
67: /// Run `script` from a file under `tclsh`: whether it exited cleanly and
68: /// what it printed. A script run from a file exits non-zero on an error,
69: /// where one read from stdin does not.
70: fn run_script(tclsh: &str, script: &str) -> Option<(bool, String)> {
71:     static NEXT: AtomicUsize = AtomicUsize::new(0);
72:     let path = std::env::temp_dir().join(format!(
73:         "value-transfer-witness-{}-{}.tcl",
74:         std::process::id(),
75:         NEXT.fetch_add(1, Ordering::Relaxed)
76:     ));
77:     std::fs::File::create(&path)
78:         .and_then(|mut file| file.write_all(script.as_bytes()))
79:         .ok()?;
80:     let output = Command::new(tclsh).arg(&path).output();
81:     let _ = std::fs::remove_file(&path);
82:     let output = output.ok()?;
83:     Some((
84:         output.status.success(),
85:         String::from_utf8_lossy(&output.stdout).into_owned(),
86:     ))
87: }
88: 
89: /// Every release with its reference interpreter, oldest first, as the shared
90: /// oracle lookup finds it ([`tcl_test_support::witness_tclsh`]): a release
91: /// with none fails the test where `TCL_LSP_REQUIRE_TCLSH` requires it, and
92: /// is reported as skipped otherwise.
93: fn releases_on_path() -> Vec<(&'static str, String)> {
94:     RELEASES
95:         .iter()
96:         .filter_map(|&series| {
97:             let version = tcl_dialect::TclVersion::from_version_string(series)?;
98:             let tclsh = tcl_test_support::witness_tclsh(version)?;
99:             Some((series, tclsh.path.to_string_lossy().into_owned()))
100:         })
101:         .collect()
102: }
103: 
104: /// The dialect profile name a release is analysed under.
105: fn dialect_of(series: &str) -> String {
106:     format!("tcl{series}")
107: }
108: 
109: /// `source` rewritten by the multipass optimiser under `dialect`, with
110: /// every rewrite it applied.
111: fn optimised(source: &str, dialect: &str) -> (String, Vec<Optimisation>) {
112:     let registry = static_context_for(dialect).commands();
113:     let profile = resolve_environment(dialect).analyser_profile();
114:     optimise_source_multipass(source, registry, Some(profile), PASSES)
115: }
116: 
117: /// The single-pass rewrites of `source` under `dialect`, each span an
118: /// offset into `source` itself.
119: fn rewrites_of(source: &str, dialect: &str) -> Vec<Optimisation> {
120:     let registry = static_context_for(dialect).commands();
121:     let profile = resolve_environment(dialect).analyser_profile();
122:     optimise_with_dialect(source, registry, Some(profile))
123: }
124: 
125: /// The compilation unit `CompilationUnit::build` makes of `source` under
126: /// `dialect` — the direct path every consumer reads the shared lattice
127: /// from.
128: fn unit_of(source: &str, dialect: &str) -> CompilationUnit {
129:     let registry = static_context_for(dialect).commands();
130:     CompilationUnit::build_for_dialect(source, registry, false, dialect)
131: }
132: 
133: /// The compilation unit of `source` under `dialect` with its procedure
134: /// summaries, as the optimiser and the explorer build it.
135: fn summarised_unit(source: &str, dialect: &str) -> CompilationUnit {
136:     let registry = static_context_for(dialect).commands();
137:     let profile = resolve_environment(dialect).analyser_profile();
138:     unit_of(source, dialect).with_interprocedural(registry, Some(profile))
139: }
140: 
141: /// The summary of `proc` in `source` under `dialect`.
142: fn summary_of(source: &str, dialect: &str, proc: &str) -> ProcSummary {
143:     let unit = summarised_unit(source, dialect);
144:     let id = fixture_id(&unit.ir_module.procedures, proc);
145:     unit.interproc
146:         .expect("the summaries")
147:         .procedures
148:         .remove(&id)
149:         .expect("the procedure's summary")
150: }
151: 
152: /// The shared lattice's value for `var`'s version `version` in `proc`.
153: fn value_at(unit: &CompilationUnit, proc: &str, var: &str, version: u32) -> Option<LatticeValue> {
154:     let function = unit
155:         .procedures
156:         .get(&fixture_id(&unit.procedures, proc))
157:         .expect("the procedure");
158:     let symbol = function.ssa.var_symbol(var).expect("the variable");
159:     function.sccp.values.get(&(symbol, version)).cloned()
160: }
161: 
162: /// The shared lattice's value for the last version of `var` in `proc`
163: /// under `dialect`.
164: fn last_value(source: &str, dialect: &str, proc: &str, var: &str) -> LatticeValue {
165:     let unit = unit_of(source, dialect);
166:     let function = unit
167:         .procedures
168:         .get(&fixture_id(&unit.procedures, proc))
169:         .expect("the procedure");
170:     let symbol = function.ssa.var_symbol(var).expect("the variable");
171:     function
172:         .sccp
173:         .values
174:         .iter()
175:         .filter(|((sym, _), _)| *sym == symbol)
176:         .max_by_key(|((_, version), _)| *version)
177:         .map(|(_, value)| value.clone())
178:         .expect("a definition")
179: }
180: 
181: /// The answers the run recorded for `command`'s statements in `proc`.
182: fn answers_for(unit: &CompilationUnit, proc: &str, command: &str) -> Vec<String> {
183:     unit.procedures
184:         .get(&fixture_id(&unit.procedures, proc))
185:         .expect("the procedure")
186:         .sccp
187:         .explanations
188:         .iter()
189:         .filter(|explanation| explanation.command == command)
190:         .map(|explanation| explanation.answer.clone())
191:         .collect()
192: }
193: 
194: fn text(value: &str) -> LatticeValue {
195:     LatticeValue::Const(ConstValue::String(value.to_owned()))
196: }
197: 
198: /// Every release on `PATH` prints `expected` for `source` and for its
199: /// optimised form under that release's dialect.
200: fn prints_under_every_release(source: &str, expected: &str) {
201:     prints_under_releases_from(source, expected, "8.4");
202: }
203: 
204: /// [`prints_under_every_release`] for the releases from `first` on: a
205: /// program using an option a release lacks runs only where it exists.
206: fn prints_under_releases_from(source: &str, expected: &str, first: &str) {
207:     for (series, tclsh) in releases_on_path() {
208:         if series < first {
209:             continue;
210:         }
211:         let (rewritten, _) = optimised(source, &dialect_of(series));
212:         for program in [source, rewritten.as_str()] {
213:             assert_eq!(
214:                 run_script(&tclsh, program),
215:                 Some((true, expected.to_owned())),
216:                 "tclsh{series}:\n{program}"
217:             );
218:         }
219:     }
220: }
221: 
222: /// A value-position cell update whose read the host statement does not
223: /// hold declines rather than answering a pending bottom a join launders:
224: /// `tcl opt` had rewritten `puts $x` to `puts 5`, where `f 1` prints 2.
225: #[test]
226: fn a_value_position_increment_never_launders_a_join() {
227:     let source =
228:         "proc f {cond} {set n 1; if {$cond} {set x [incr n]} else {set x 5}; puts $x}\nf 1\nf 0\n";
229:     for dialect in ["tcl8.4", "tcl8.6", "tcl9.0", "f5-irules"] {
230:         let (rewritten, rewrites) = optimised(source, dialect);
231:         assert!(
232:             rewritten.contains("puts $x"),
233:             "{dialect}: `puts $x` must keep its variable\n{rewritten}\n{rewrites:#?}"
234:         );
235:     }
236:     prints_under_every_release(source, "2\n5\n");
237: }
238: 
239: /// A cell update reads its words as Tcl substitutes them: a braced `$x` is
240: /// the text `$x`, not a read of `x`, and a quoted `\t` is a tab. Read by
241: /// their spelling, `puts $t` was rewritten to `puts a1` and `lappend l
242: /// "a\tb"` folded to `set l {{a\tb}}`.
243: #[test]
244: fn a_cell_update_reads_its_words_as_tcl_substitutes_them() {
245:     let cases: [(&str, &str, LatticeValue, &str); 4] = [
246:         (
247:             "proc p {} {set x 1; set s a; append s {$x}; set t $s; puts $t}\np\n",
248:             "s",
249:             text("a$x"),
250:             "a$x\n",
251:         ),
252:         (
253:             "proc p {} {set x 1; set l {}; lappend l {$x}; puts $l}\np\n",
254:             "l",
255:             text("{$x}"),
256:             "{$x}\n",
257:         ),
258:         (
259:             "proc p {} {set s x; append s \"a\\tb\"; set t $s; puts $t}\np\n",
260:             "s",
261:             text("xa\tb"),
262:             "xa\tb\n",
263:         ),
264:         (
265:             "proc p {} {set l {}; lappend l \"a\\tb\"; puts $l}\np\n",
266:             "l",
267:             text("{a\tb}"),
268:             "{a\tb}\n",
269:         ),
270:     ];
271:     for (source, var, value, output) in cases {
272:         for dialect in ["tcl8.4", "tcl8.6", "tcl9.0"] {
273:             assert_eq!(
274:                 last_value(source, dialect, "::p", var),
275:                 value,
276:                 "{dialect}: {source}"
277:             );
278:         }
279:         prints_under_every_release(source, output);
280:     }
281: }
282: 
283: /// `[string range "a\tb" 0 1]` in value position reads the quoted word as
284: /// Tcl substitutes it (`a` and a tab); a braced word keeps its backslash.
285: #[test]
286: fn value_position_words_are_read_as_tcl_substitutes_them() {
287:     let quoted = "proc p {} {set r [string range \"a\\tb\" 0 1]; puts $r}\np\n";
288:     let braced = "proc p {} {set r [string range {a\\tb} 0 1]; puts $r}\np\n";
289:     for dialect in ["tcl8.4", "tcl8.6", "tcl9.0"] {
290:         assert_eq!(last_value(quoted, dialect, "::p", "r"), text("a\t"));
291:         assert_eq!(last_value(braced, dialect, "::p", "r"), text("a\\"));
292:     }
293:     prints_under_every_release(quoted, "a\t\n");
294:     prints_under_every_release(braced, "a\\\n");
295: }
296: 
297: /// A `{*}` word in value position expands before a route reads it:
298: /// `[list {*}{a b}]` is the two elements `a` and `b`. Read as the one
299: /// braced word `a b`, `tcl opt` rewrote `puts [llength $l]` to `puts 1`
300: /// where tclsh prints 2.
301: #[test]
302: fn an_expanded_word_in_value_position_is_several_operands() {
303:     let source = "proc p {} {set l [list {*}{a b}]; puts [llength $l]; puts [lindex $l 1]}\np\n";
304:     for dialect in ["tcl8.5", "tcl8.6", "tcl9.0"] {
305:         let value = last_value(source, dialect, "::p", "l");
306:         assert!(
307:             value == text("a b") || !matches!(value, LatticeValue::Const(_)),
308:             "{dialect}: {value:?}"
309:         );
310:     }
311:     prints_under_releases_from(source, "2\nb\n", "8.5");
312: }
313: 
314: /// The shared lattice folds under the module's observed bindings, the
315: /// stance a rewrite's re-run proves under too: with `proc incr` defined at
316: /// the top level, `incr n` calls that procedure, so `n#2` is not the
317: /// builtin's 2, and the statement says why (#2164).
318: #[test]
319: fn the_shared_lattice_declines_a_renamed_head() {
320:     let body = "proc p {} {set n 1; incr n; return $n}\n";
321:     let shadowed = format!("proc incr {{v args}} {{return 99}}\n{body}");
322:     for dialect in ["tcl8.4", "tcl8.6", "tcl9.0"] {
323:         let unit = unit_of(&shadowed, dialect);
324:         assert_eq!(
325:             value_at(&unit, "::p", "n", 2),
326:             Some(LatticeValue::Overdefined),
327:             "{dialect}"
328:         );
329:         assert_eq!(
330:             answers_for(&unit, "::p", "incr"),
331:             ["declined: rebinding-suspected"],
332:             "{dialect}"
333:         );
334:         let unit = unit_of(body, dialect);
335:         assert_eq!(
336:             value_at(&unit, "::p", "n", 2),
337:             Some(LatticeValue::Const(ConstValue::Int(2))),
338:             "{dialect}"
339:         );
340:         assert_eq!(
341:             answers_for(&unit, "::p", "incr"),
342:             ["evaluated"],
343:             "{dialect}"
344:         );
345:     }
346: }
347: 
348: /// A `::`-qualified global a nested cell update writes is in its
349: /// procedure's global-write summary with no `global` declaration, so a
350: /// caller no longer forwards the value the global held before the call
351: /// or deletes the store it reads (#2214). An unqualified name with no
352: /// declaration stays local.
353: #[test]
354: fn a_qualified_nested_cell_update_is_a_global_write() {
355:     use tcl_compiler::cfg_builder::global_write_info::detect_global_write_procs;
356:     use tcl_compiler::lowering::lower_to_ir;
357:     let registry = static_context_for("tcl8.6").commands();
358:     for body in ["set y [incr ::hits]", "set y [expr {[incr ::hits] + 1}]"] {
359:         let module = lower_to_ir(&format!("proc bump {{}} {{{body}; return $y}}\n"), registry);
360:         let writes = detect_global_write_procs(&module);
361:         assert!(
362:             writes[&fixture_id(&module.procedures, "::bump")]
363:                 .names
364:                 .contains("::hits"),
365:             "{body}: {writes:?}"
366:         );
367:         assert!(
368:             writes[&fixture_id(&module.procedures, "::bump")]
369:                 .names
370:                 .contains("hits"),
371:             "{body}: {writes:?}"
372:         );
373:     }
374:     let module = lower_to_ir("proc bump {} {set y [incr hits]; return $y}\n", registry);
375:     let writes = detect_global_write_procs(&module);
376:     assert!(
377:         writes[&fixture_id(&module.procedures, "::bump")].is_empty(),
378:         "{writes:?}"
379:     );
380: 
381:     let source = "set hits 0\nproc bump {} {set y [incr ::hits]; return $y}\nbump\nputs $hits\n";
382:     for dialect in ["tcl8.4", "tcl8.6", "tcl9.0"] {
383:         let (rewritten, rewrites) = optimised(source, dialect);
384:         assert!(
385:             rewritten.contains("set hits 0") && rewritten.contains("puts $hits"),
386:             "{dialect}:\n{rewritten}\n{rewrites:#?}"
387:         );
388:     }
389:     prints_under_every_release(source, "1\n");
390: }
391: 
392: /// The same holds for a qualified global a procedure reaches through
393: /// `upvar #0`: the caller at the global frame reads `::hits` as `hits`.
394: #[test]
395: fn a_qualified_alias_target_is_a_global_write_at_the_caller() {
396:     let source = "set hits 0\nproc bump {} {upvar #0 ::hits h; incr h}\nbump\nputs $hits\n";
397:     for dialect in ["tcl8.4", "tcl8.6", "tcl9.0"] {
398:         let (rewritten, rewrites) = optimised(source, dialect);
399:         assert!(
400:             rewritten.contains("set hits 0") && rewritten.contains("puts $hits"),
401:             "{dialect}:\n{rewritten}\n{rewrites:#?}"
402:         );
403:     }
404:     prints_under_every_release(source, "1\n");
405: }
406: 
407: /// A callee's global-write summary records writes, not reads, and a
408: /// callee that writes a global may read it first: `set hits 10` ahead of
409: /// a `bump` running `global hits; incr hits 5` is observed, not dead
410: /// (tclsh 8.4 to 9.1 print 15, where deleting it printed 5).
411: #[test]
412: fn a_store_a_global_writing_callee_reads_is_kept() {
413:     let source = "set hits 10\nproc bump {} {global hits; incr hits 5}\nbump\nputs $hits\n";
414:     for dialect in ["tcl8.4", "tcl8.6", "tcl9.0"] {
415:         let (rewritten, rewrites) = optimised(source, dialect);
416:         assert!(
417:             rewritten.contains("set hits 10"),
418:             "{dialect}:\n{rewritten}\n{rewrites:#?}"
419:         );
420:     }
421:     prints_under_every_release(source, "15\n");
422: }
423: 
424: /// A callee that only reads a global keeps the store it reads: O109 does not
425: /// delete `set hits 0` ahead of `show` — the rewrite keeps both stores, and
426: /// tclsh 8.4 to 9.1 print 0 then 1 for both programs.
427: #[test]
428: fn a_store_a_global_reading_callee_observes_is_kept() {
429:     let source = "set hits 0\nproc show {} {global hits; puts $hits}\nshow\nset hits 1\nshow\n";
430:     for dialect in ["tcl8.4", "tcl8.6", "tcl9.0"] {
431:         let (rewritten, rewrites) = optimised(source, dialect);
432:         assert!(
433:             rewritten.contains("set hits 0") && rewritten.contains("set hits 1"),
434:             "{dialect}:\n{rewritten}\n{rewrites:#?}"
435:         );
436:     }
437:     prints_under_every_release(source, "0\n1\n");
438: }
439: 
440: /// `[set x]` in value position reads the variable through the cell-write
441: /// route (the Tier-1 list); `[set x 10]` writes it, so the statement's call
442: /// holds the write and its host the result: `x` is 10 after the statement and
443: /// so is `w`, which tclsh 8.4 to 9.1 print, before and after the optimiser.
444: #[test]
445: fn a_value_position_set_reads_the_variable() {
446:     let source = "proc p {} {set x hello; set r [set x]; set w [set x 10]; return $r$w}\n";
447:     let ten = Some(LatticeValue::Const(ConstValue::Int(10)));
448:     for dialect in ["tcl8.4", "tcl8.6", "tcl9.0", "f5-irules"] {
449:         let unit = unit_of(source, dialect);
450:         assert_eq!(
451:             value_at(&unit, "::p", "r", 1),
452:             Some(text("hello")),
453:             "{dialect}"
454:         );
455:         assert_eq!(value_at(&unit, "::p", "w", 1), ten, "{dialect}");
456:         assert_eq!(value_at(&unit, "::p", "x", 2), ten, "{dialect}");
457:     }
458:     prints_under_every_release(&format!("{source}puts [p]\n"), "hello10\n");
459: }
460: 
461: /// Program (3) of the interface contract: `incr n` and `incr n 2` over
462: /// `set n 1` give `n#3` the 4 every release prints, in the shared lattice
463: /// under every dialect — each statement's route answering — and the
464: /// optimiser forwards it into `puts $n` (O100).
465: #[test]
466: fn program_three_folds_in_every_consumer() {
467:     let source = "proc p {} {set n 1; incr n; incr n 2; puts $n}\np\n";
468:     for dialect in DIALECTS {
469:         let unit = unit_of(source, dialect);
470:         assert_eq!(
471:             value_at(&unit, "::p", "n", 3),
472:             Some(LatticeValue::Const(ConstValue::Int(4))),
473:             "{dialect}"
474:         );
475:         assert_eq!(
476:             answers_for(&unit, "::p", "incr"),
477:             ["evaluated", "evaluated"],
478:             "{dialect}"
479:         );
480:         let rewrites = rewrites_of(source, dialect);
481:         assert!(
482:             rewrites.iter().any(|r| r.code == DiagCode::O100),
483:             "{dialect}: {rewrites:#?}"
484:         );
485:         let (rewritten, _) = optimised(source, dialect);
486:         assert!(rewritten.contains("puts 4"), "{dialect}:\n{rewritten}");
487:     }
488:     prints_under_every_release(source, "4\n");
489: }
490: 
491: /// A model's answer for `x` after the statement: the text of its value, or
492: /// `None` where it declines.
493: fn lattice_text(value: LatticeValue) -> Option<String> {
494:     match value {
495:         LatticeValue::Const(ConstValue::Int(i)) => Some(i.to_string()),
496:         LatticeValue::Const(ConstValue::String(s)) => Some(s),
497:         _ => None,
498:     }
499: }
500: 
501: /// A seed as the literal ingress reads it: a canonical integer is the
502: /// integer, and any other text is its text.
503: fn seeded(text: &str) -> StaticValue {
504:     tcl_registry::value_transfer::ExactValue::from_literal(text)
505:         .as_int()
506:         .map_or_else(|| StaticValue::Str(text.to_owned()), StaticValue::Int)
507: }
508: 
509: /// The loop enumeration's answer for `x` after `statement` runs once as the
510: /// body of `for {set i 0} {$i < 1} {incr i} {…}`, seeded as the solver
511: /// seeds it — `x` from `init` and `n` from 3 through the literal ingress.
512: fn simulated_text(dialect: &str, init: &str, statement: &str) -> Option<String> {
513:     let registry = static_context_for(dialect).commands();
514:     let profile = resolve_environment(dialect).analyser_profile();
515:     let module = lower_to_ir_with_dialect(
516:         &format!("for {{set i 0}} {{$i < 1}} {{incr i}} {{{statement}}}\n"),
517:         registry,
518:         tcl_lexer::LexerConfig::default(),
519:         Some(profile),
520:     );
521:     let for_stmt = module
522:         .top_level
523:         .statements
524:         .iter()
525:         .find(|stmt| matches!(stmt, Statement::For { .. }))
526:         .expect("the loop");
527:     let mut seed = StaticEnv::new();
528:     seed.insert("x".to_owned(), seeded(init));
529:     seed.insert("n".to_owned(), seeded("3"));
530:     let env = summarise_for_statement(
531:         for_stmt,
532:         &seed,
533:         DEFAULT_MAX_STATIC_LOOP_ITERS,
534:         LoopSemantics {
535:             policy: FoldPolicy::from_registry(registry),
536:             registry,
537:         },
538:     )?;
539:     match env.get("x").expect("x after the loop") {
540:         StaticValue::Int(i) => Some(i.to_string()),
541:         StaticValue::Str(s) => Some(s.clone()),
542:         other => panic!("{dialect}: an increment gave {other:?}"),
543:     }
544: }
545: 
546: /// The interval domain's answer at `x`'s last definition in `::p`.
547: fn interval_at(unit: &CompilationUnit, dialect: &str) -> Interval {
548:     let function = unit
549:         .procedures
550:         .get(&fixture_id(&unit.procedures, "::p"))
551:         .expect("the procedure");
552:     let profile = resolve_environment(dialect).analyser_profile();
553:     let intervals = compute_intervals_with(
554:         &function.cfg,
555:         &function.ssa,
556:         &function.sccp.values,
557:         numbers_for_dialect(Some(profile)),
558:     );
559:     let x = function.ssa.var_symbol("x").expect("x");
560:     intervals
561:         .iter()
562:         .filter(|((symbol, _), _)| *symbol == x)
563:         .max_by_key(|((_, version), _)| *version)
564:         .map(|(_, interval)| *interval)
565:         .expect("an interval for x")
566: }
567: 
568: /// Whether `interval` holds the integer `text` spells (a bignum included).
569: fn interval_holds(interval: Interval, text: &str) -> bool {
570:     let value: i128 = text.parse().expect("an integer");
571:     interval.lo.is_none_or(|lo| i128::from(lo) <= value)
572:         && interval.hi.is_none_or(|hi| value <= i128::from(hi))
573: }
574: 
575: /// The lattice, the loop simulator and the interval domain answer one
576: /// increment alike: the lattice and the simulator give the same value or
577: /// both decline, and the interval never excludes the lattice's value.
578: /// Each value is the release's own: `incr x $n` is 8 everywhere; `incr x`
579: /// over `010` is 9 up to 8.6 and 11 from 9.0; over `9223372036854775807`
580: /// it is `9223372036854775808` from 8.5 and `-8` under 8.4, which no model
581: /// computes, so 8.4 declines. `f5-irules` answers as its 8.4 base does
582: /// (ruling 8), and the lenient profile, naming no single release, declines
583: /// both release-dependent cases.
584: #[test]
585: fn the_three_incr_models_agree() {
586:     let cases: [(&str, &str, [Option<&str>; 5]); 3] = [
587:         ("5", "incr x $n", [Some("8"); 5]),
588:         (
589:             "010",
590:             "incr x",
591:             [Some("9"), Some("9"), Some("11"), Some("9"), None],
592:         ),
593:         (
594:             "9223372036854775807",
595:             "incr x",
596:             [
597:                 None,
598:                 Some("9223372036854775808"),
599:                 Some("9223372036854775808"),
600:                 None,
601:                 None,
602:             ],
603:         ),
604:     ];
605:     for (init, statement, expected) in cases {
606:         let source = format!("proc p {{}} {{set x {init}; set n 3; {statement}; return $x}}\n");
607:         for (dialect, want) in DIALECTS.into_iter().zip(expected) {
608:             let unit = unit_of(&source, dialect);
609:             let lattice =
610:                 lattice_text(value_at(&unit, "::p", "x", 2).expect("the increment's definition"));
611:             let simulated = simulated_text(dialect, init, statement);
612:             assert_eq!(
613:                 lattice.as_deref(),
614:                 want,
615:                 "{dialect}: lattice, {statement} over {init}"
616:             );
617:             assert_eq!(
618:                 simulated, lattice,
619:                 "{dialect}: simulator, {statement} over {init}"
620:             );
621:             if let Some(value) = &lattice {
622:                 let interval = interval_at(&unit, dialect);
623:                 assert!(
624:                     interval_holds(interval, value),
625:                     "{dialect}: {interval:?} excludes {value}"
626:                 );
627:             }
628:         }
629:         for (series, tclsh) in releases_on_path() {
630:             let unit = unit_of(&source, &dialect_of(series));
631:             let Some(value) = lattice_text(value_at(&unit, "::p", "x", 2).expect("the definition"))
632:             else {
633:                 continue;
634:             };
635:             let program = format!("set x {init}; set n 3; {statement}; puts $x");
636:             assert_eq!(
637:                 run_script(&tclsh, &program),
638:                 Some((true, format!("{value}\n"))),
639:                 "tclsh{series}: {program}"
640:             );
641:         }
642:     }
643: }
644: 
645: /// `set result [incr n]` reads the store it increments, so neither dead
646: /// store rewrite (O109, O126) takes `set n 1` and the increment stays;
647: /// the optimised program prints 2 twice, as every release does (#2050).
648: #[test]
649: fn set_result_incr_keeps_its_increment() {
650:     let source = "proc p {} {set n 1; set result [incr n]; puts $result; puts $n}\np\n";
651:     let store = source.find("set n 1").expect("the store");
652:     for dialect in DIALECTS {
653:         let rewrites = rewrites_of(source, dialect);
654:         assert!(
655:             !rewrites.iter().any(|r| {
656:                 matches!(r.code, DiagCode::O109 | DiagCode::O126)
657:                     && (r.span.start() as usize..r.span.end() as usize).contains(&store)
658:             }),
659:             "{dialect}: {rewrites:#?}"
660:         );
661:         let (rewritten, all) = optimised(source, dialect);
662:         assert!(
663:             rewritten.contains("set n 1") && rewritten.contains("[incr n]"),
664:             "{dialect}:\n{rewritten}\n{all:#?}"
665:         );
666:     }
667:     prints_under_every_release(source, "2\n2\n");
668: }
669: 
670: /// The string and list build chains fold through a `$var` piece the
671: /// lattice proves: `append s $p` (O104) — a leading space kept (#2052) —
672: /// and `lappend l a $x` (O130).
673: #[test]
674: fn o104_and_o130_fold_a_chain_through_a_lattice_operand() {
675:     let cases = [
676:         (
677:             "set s hello\nset p again\nappend s $p\nputs $s\n",
678:             DiagCode::O104,
679:             "set s helloagain",
680:             "helloagain\n",
681:         ),
682:         (
683:             "set s hello\nset p { again}\nappend s $p\nputs $s\n",
684:             DiagCode::O104,
685:             "set s {hello again}",
686:             "hello again\n",
687:         ),
688:         (
689:             "set l {}\nset x b\nlappend l a $x\nputs $l\n",
690:             DiagCode::O130,
691:             "set l {a b}",
692:             "a b\n",
693:         ),
694:     ];
695:     for (source, code, folded, output) in cases {
696:         for dialect in DIALECTS {
697:             let rewrites = rewrites_of(source, dialect);
698:             assert!(
699:                 rewrites
700:                     .iter()
701:                     .any(|r| r.code == code && r.replacement == folded),
702:                 "{dialect}: {source}\n{rewrites:#?}"
703:             );
704:         }
705:         prints_under_every_release(source, output);
706:     }
707: }
708: 
709: /// Deleting a store whose value was a quoted word takes the whole word:
710: /// no line of the optimised program holds only its closing quote (#2053).
711: #[test]
712: fn deleting_a_quoted_store_leaves_no_quote() {
713:     let source = "set s hello\nset p \"again\"\nappend s $p\nputs $s\n";
714:     for dialect in DIALECTS {
715:         let (rewritten, rewrites) = optimised(source, dialect);
716:         assert!(
717:             !rewritten.lines().any(|line| line.trim() == "\""),
718:             "{dialect}:\n{rewritten}\n{rewrites:#?}"
719:         );
720:     }
721:     prints_under_every_release(source, "helloagain\n");
722: }
723: 
724: /// `lassign` is no write under a profile whose release lacks it: under
725: /// 8.4 the call is an unknown command `catch` absorbs, so `a` is still
726: /// `old` at the `puts` — the optimiser forwards it, and the store that fed
727: /// it is then dead, where deleting the store while keeping the read made
728: /// 8.4 fail with `can't read "a"` — and 8.4 prints `old`. From 8.5
729: /// `lassign` assigns `new`, which no rewrite forwards past (#2144).
730: #[test]
731: fn lassign_is_not_a_write_under_a_profile_without_it() {
732:     let source = "set a old\ncatch {lassign {new second} a b}\nputs $a\n";
733:     let (rewritten, rewrites) = optimised(source, "tcl8.4");
734:     assert!(rewritten.contains("puts old"), "{rewritten}\n{rewrites:#?}");
735:     for dialect in ["tcl8.6", "tcl9.0"] {
736:         let (rewritten, rewrites) = optimised(source, dialect);
737:         assert!(
738:             rewritten.contains("puts $a"),
739:             "{dialect}:\n{rewritten}\n{rewrites:#?}"
740:         );
741:     }
742:     for (series, tclsh) in releases_on_path() {
743:         let (rewritten, _) = optimised(source, &dialect_of(series));
744:         let want = if series == "8.4" { "old\n" } else { "new\n" };
745:         for program in [source, rewritten.as_str()] {
746:             assert_eq!(
747:                 run_script(&tclsh, program),
748:                 Some((true, want.to_owned())),
749:                 "tclsh{series}:\n{program}"
750:             );
751:         }
752:     }
753: }
754: 
755: /// A typed assignment reads its value word as Tcl substitutes it: a quoted
756: /// `\t` is a tab and a braced backslash-newline one space. Read by its
757: /// spelling, `set s "a\tb"` held four characters, so `string length $s`
758: /// folded to 4 and `[list $c]` quoted a backslash (tclsh 8.4 to 9.1 print
759: /// 3, 3, 2, `{x<TAB>y}` and 3).
760: #[test]
761: fn a_typed_assignment_reads_its_word_as_tcl_substitutes_it() {
762:     let cases: [(&str, &str, LatticeValue, &str); 5] = [
763:         (
764:             "proc p {} {set s \"a\\tb\"; puts [string length $s]}\np\n",
765:             "s",
766:             text("a\tb"),
767:             "3\n",
768:         ),
769:         (
770:             "proc p {} {set e \"p\\tq\"; set f [set e]; puts [string length $f]}\np\n",
771:             "f",
772:             text("p\tq"),
773:             "3\n",
774:         ),
775:         (
776:             "proc p {} {set b \"\\t\"; append b q; puts [string length $b]}\np\n",
777:             "b",
778:             text("\tq"),
779:             "2\n",
780:         ),
781:         (
782:             "proc p {} {set c \"x\\ty\"; set d [list $c]; puts $d}\np\n",
783:             "d",
784:             text("{x\ty}"),
785:             "{x\ty}\n",
786:         ),
787:         (
788:             "proc p {} {set s {a\\\nb}; puts [string length $s]}\np\n",
789:             "s",
790:             text("a b"),
791:             "3\n",
792:         ),
793:     ];
794:     for (source, var, value, output) in cases {
795:         for dialect in DIALECTS {
796:             assert_eq!(
797:                 last_value(source, dialect, "::p", var),
798:                 value,
799:                 "{dialect}: {source}"
800:             );
801:         }
802:         prints_under_every_release(source, output);
803:     }
804: }
805: 
806: /// A braced `incr` amount is its own text: `incr x {$n}` raises `expected
807: /// integer but got "$n"` in every release, so `x#2` has no value and the
808: /// statement reads no `n`; the route proves the error and answers it as the
809: /// completion it is, after no store. Read as a substitution it folded to 4.
810: #[test]
811: fn a_braced_increment_amount_is_its_text() {
812:     let body = "proc p {} {set n 3; set x 1; incr x {$n}; return $x}\n";
813:     for dialect in DIALECTS {
814:         let unit = unit_of(body, dialect);
815:         assert_eq!(
816:             value_at(&unit, "::p", "x", 2),
817:             Some(LatticeValue::Overdefined),
818:             "{dialect}"
819:         );
820:         assert_eq!(
821:             answers_for(&unit, "::p", "incr"),
822:             ["evaluated: error after 0 stores"],
823:             "{dialect}"
824:         );
825:         let function = unit
826:             .procedures
827:             .get(&fixture_id(&unit.procedures, "::p"))
828:             .expect("authored fixture body");
829:         let n = function.ssa.var_symbol("n").expect("n");
830:         let increment = function
831:             .ssa
832:             .blocks
833:             .values()
834:             .flat_map(|block| &block.statements)
835:             .find(|stmt| matches!(stmt.statement, Statement::Incr { .. }))
836:             .expect("the increment");
837:         assert!(
838:             !increment.uses.contains_key(&n),
839:             "{dialect}: a braced amount reads nothing"
840:         );
841:     }
842:     let source = format!("{body}puts [catch p msg]; puts $msg\n");
843:     prints_under_every_release(&source, "1\nexpected integer but got \"$n\"\n");
844: }
845: 
846: /// A list's first element that starts with `#` is brace-quoted from 8.5 and
847: /// bare in 8.4 (`puts [list # a]` prints `# a` under tclsh 8.4 and `{#} a`
848: /// from 8.5), so each release folds its own rendering and a profile naming
849: /// no release declines.
850: #[test]
851: fn a_leading_hash_is_quoted_per_release() {
852:     let source = "proc p {} {set r [list # a]; set l {}; lappend l # b; puts $r; puts $l}\np\n";
853:     for (dialect, list, appended) in [
854:         ("tcl8.4", Some("# a"), Some("# b")),
855:         ("tcl8.6", Some("{#} a"), Some("{#} b")),
856:         ("tcl9.0", Some("{#} a"), Some("{#} b")),
857:         ("f5-irules", Some("# a"), Some("# b")),
858:         ("tcl", None, None),
859:     ] {
860:         let expect = |value: Option<&str>| value.map_or(LatticeValue::Overdefined, text);
861:         assert_eq!(
862:             last_value(source, dialect, "::p", "r"),
863:             expect(list),
864:             "{dialect}"
865:         );
866:         assert_eq!(
867:             last_value(source, dialect, "::p", "l"),
868:             expect(appended),
869:             "{dialect}"
870:         );
871:     }
872:     // The same rule reaches every consumer that renders a list for the
873:     // target: the `lappend` chain fold (O130) and the `args` list an
874:     // argument-sensitive procedure fold (O103) seeds.
875:     let variadic = "proc f {args} {return $args}\nputs [f # a]\nputs [f #x b]\n";
876:     for (series, tclsh) in releases_on_path() {
877:         let (expected, variadic_expected) = if series == "8.4" {
878:             ("# a\n# b\n", "# a\n#x b\n")
879:         } else {
880:             ("{#} a\n{#} b\n", "{#} a\n{#x} b\n")
881:         };
882:         for (program, expected) in [(source, expected), (variadic, variadic_expected)] {
883:             let (rewritten, _) = optimised(program, &dialect_of(series));
884:             for program in [program, rewritten.as_str()] {
885:                 assert_eq!(
886:                     run_script(&tclsh, program),
887:                     Some((true, expected.to_owned())),
888:                     "tclsh{series}:\n{program}"
889:                 );
890:             }
891:         }
892:     }
893: }
894: 
895: /// A typed assignment is `set`'s lowering, so once the module shadows
896: /// `set` it proves nothing: with `proc set {name value} {return ZZZ}`,
897: /// `set s hello` never writes `s` and `append s world` leaves `world`
898: /// (tclsh 8.4 to 9.1), where folding the assignment rewrote the program to
899: /// print `helloworld`.
900: #[test]
901: fn a_typed_assignment_declines_once_set_is_rebound() {
902:     let source =
903:         "proc set {name value} {return ZZZ}\nproc p {} {set s hello; append s world; puts $s}\np\n";
904:     for dialect in ["tcl8.4", "tcl8.6", "tcl9.0"] {
905:         let unit = unit_of(source, dialect);
906:         assert_eq!(
907:             value_at(&unit, "::p", "s", 1),
908:             Some(LatticeValue::Overdefined),
909:             "{dialect}"
910:         );
911:         let (rewritten, rewrites) = optimised(source, dialect);
912:         assert!(
913:             !rewritten.contains("helloworld"),
914:             "{dialect}:\n{rewritten}\n{rewrites:#?}"
915:         );
916:     }
917:     prints_under_every_release(source, "world\n");
918: }
919: 
920: /// O100 forwards a value holding a tab as a word that re-reads to the same
921: /// value: the tab stays a tab inside the braces (tclsh 8.4 to 9.1 print
922: /// `a<TAB>b` and `x<TAB>y`, before and after the rewrite).
923: #[test]
924: fn o100_forwards_a_tab_verbatim() {
925:     for (source, word, output) in [
926:         ("set r {a\tb}\nputs $r\n", "{a\tb}", "a\tb\n"),
927:         (
928:             "set b [string range \"x\\ty\" 0 2]\nputs $b\n",
929:             "{x\ty}",
930:             "x\ty\n",
931:         ),
932:     ] {
933:         for dialect in ["tcl8.4", "tcl8.6", "tcl9.0"] {
934:             let rewrites = rewrites_of(source, dialect);
935:             assert!(
936:                 rewrites
937:                     .iter()
938:                     .any(|r| r.code == DiagCode::O100 && r.replacement == word),
939:                 "{dialect}: {rewrites:#?}"
940:             );
941:         }
942:         prints_under_every_release(source, output);
943:     }
944: }
945: 
946: /// A keyed update reads the dictionary it rewrites under every spelling
947: /// that reaches it: the qualified `::tcl::dict::` commands, a nested
948: /// `[dict set …]`, and an alias of `dict set`. The read had been recorded
949: /// only for the `dict` ensemble at statement level, so O109 deleted the
950: /// store feeding the others: `::tcl::dict::set d k v` printed `k v` where
951: /// tclsh 8.5 to 9.1 print `a 1 k v`. Tcl 8.4 has no `dict`, and every
952: /// program fails there the same way before and after.
953: #[test]
954: fn a_keyed_update_reads_its_dictionary_under_every_spelling() {
955:     let programs = [
956:         (
957:             "proc p {} {set d {a 1}; ::tcl::dict::set d k v; return $d}\nputs [p]\n",
958:             "a 1 k v\n",
959:         ),
960:         (
961:             "proc p {} {set d {a 1}; puts [dict set d k v]}\np\n",
962:             "a 1 k v\n",
963:         ),
964:         (
965:             "proc p {} {set d {a 1}; puts [::tcl::dict::set d k v]}\np\n",
966:             "a 1 k v\n",
967:         ),
968:         (
969:             "proc p {} {set d {a 1 b 2}; ::tcl::dict::unset d a; return $d}\nputs [p]\n",
970:             "b 2\n",
971:         ),
972:         (
973:             "proc p {} {set d {a 1}; ::tcl::dict::incr d a; return $d}\nputs [p]\n",
974:             "a 2\n",
975:         ),
976:         (
977:             "proc p {} {set d {a 1}; ::tcl::dict::append d a x; return $d}\nputs [p]\n",
978:             "a 1x\n",
979:         ),
980:         (
981:             "proc p {} {set d {a 1}; ::tcl::dict::lappend d a x; return $d}\nputs [p]\n",
982:             "a {1 x}\n",
983:         ),
984:         (
985:             "interp alias {} ds {} dict set\nproc p {} {set d {a 1}; ds d k v; return $d}\nputs [p]\n",
986:             "a 1 k v\n",
987:         ),
988:     ];
989:     for (source, expected) in programs {
990:         for (series, tclsh) in releases_on_path() {
991:             let (rewritten, _) = optimised(source, &dialect_of(series));
992:             if series == "8.4" {
993:                 assert_eq!(
994:                     run_script(&tclsh, &rewritten),
995:                     run_script(&tclsh, source),
996:                     "tclsh8.4:\n{rewritten}"
997:                 );
998:                 continue;
999:             }
1000:             for program in [source, rewritten.as_str()] {
1001:                 assert_eq!(
1002:                     run_script(&tclsh, program),
1003:                     Some((true, expected.to_owned())),
1004:                     "tclsh{series}:\n{program}"
1005:                 );
1006:             }
1007:         }
1008:     }
1009: }
1010: 
1011: /// A BPF-Tcl expression never takes the Tcl engine's answer: BPF-Tcl's
1012: /// signed division truncates towards zero (`-7 / 2` is `-3`) where Tcl
1013: /// floors (`-4` under tclsh 8.4 to 9.1), so the route under the BPF
1014: /// language evaluates nothing and the BPF frontend's own arithmetic stays
1015: /// the only answer. No shipped command declares the BPF language yet; the
1016: /// synthetic `bpfexpr` stands for the frontend's expression arguments.
1017: #[test]
1018: fn a_bpf_expression_never_takes_the_tcl_answer() {
1019:     use tcl_registry::spec::CommandSpec;
1020:     use tcl_registry::value_transfer::SemanticsDeclaration;
1021:     use tcl_registry::value_transfer::builtins::BPF_EXPR;
1022:     let mut registry = tcl_registry::CommandRegistry::build_default();
1023:     registry.insert(CommandSpec {
1024:         name: "bpfexpr",
1025:         semantics: SemanticsDeclaration::Declared(&BPF_EXPR),
1026:         ..CommandSpec::DEFAULT
1027:     });
1028:     let source = "proc p {} {set r [bpfexpr {-7 / 2}]; set t [expr {-7 / 2}]; return $r$t}\n";
1029:     let unit = CompilationUnit::build_for_dialect(source, &registry, false, "tcl9.0");
1030:     assert_eq!(
1031:         value_at(&unit, "::p", "r", 1),
1032:         Some(LatticeValue::Overdefined)
1033:     );
1034:     assert_eq!(
1035:         answers_for(&unit, "::p", "bpfexpr"),
1036:         ["declined: unsupported"]
1037:     );
1038:     assert_eq!(
1039:         value_at(&unit, "::p", "t", 1),
1040:         Some(LatticeValue::Const(ConstValue::Int(-4)))
1041:     );
1042:     prints_under_every_release("puts [expr {-7 / 2}]\n", "-4\n");
1043: }
1044: 
1045: /// A math function the module rebinds declines. From 8.5 `abs(…)`
1046: /// dispatches to the command `::tcl::mathfunc::abs`, so the module's `proc`
1047: /// of that name is what runs: tclsh 8.5 to 9.1 print 99. Under 8.4 the
1048: /// grammar dispatches internally and has no such command, so the `proc`
1049: /// cannot even be created and the program prints 2. A namespace-local
1050: /// override is the same rebinding: from 8.5 `expr` resolves
1051: /// `tcl::mathfunc::abs` relative to the namespace it runs in first, so
1052: /// `abs(…)` inside `::ns` calls `::ns::tcl::mathfunc::abs` (tclsh 8.5 to
1053: /// 9.1: 99; 8.4: 2).
1054: #[test]
1055: fn abs_rebinding_declines() {
1056:     let rebound = "catch {rename ::tcl::mathfunc::abs ::tcl::mathfunc::saved_abs}\n\
1057:                    catch {proc ::tcl::mathfunc::abs {x} {return 99}}\n\
1058:                    proc p {} {set r [expr {abs(-2)}]; return $r}\nputs [p]\n";
1059:     let local = "namespace eval ns {\n\
1060:                  namespace eval tcl::mathfunc { proc abs {x} {return 99} }\n\
1061:                  proc p {} {set r [expr {abs(-2)}]; return $r}\n\
1062:                  }\nputs [ns::p]\n";
1063:     let plain = "proc p {} {set r [expr {abs(-2)}]; return $r}\nputs [p]\n";
1064:     let two = Some(LatticeValue::Const(ConstValue::Int(2)));
1065:     for (dialect, want) in [
1066:         ("tcl8.4", two.clone()),
1067:         ("tcl8.6", Some(LatticeValue::Overdefined)),
1068:         ("tcl9.0", Some(LatticeValue::Overdefined)),
1069:     ] {
1070:         let unit = unit_of(rebound, dialect);
1071:         assert_eq!(value_at(&unit, "::p", "r", 1), want, "{dialect}");
1072:         assert_eq!(
1073:             value_at(&unit_of(local, dialect), "::ns::p", "r", 1),
1074:             want,
1075:             "{dialect}: the namespace-local override"
1076:         );
1077:         assert_eq!(
1078:             value_at(&unit_of(plain, dialect), "::p", "r", 1),
1079:             two,
1080:             "{dialect}"
1081:         );
1082:     }
1083:     assert_eq!(
1084:         answers_for(&unit_of(rebound, "tcl9.0"), "::p", "expr"),
1085:         ["declined: rebinding-suspected"]
1086:     );
1087:     assert_eq!(
1088:         answers_for(&unit_of(local, "tcl9.0"), "::ns::p", "expr"),
1089:         ["declined: rebinding-suspected"]
1090:     );
1091:     for (series, tclsh) in releases_on_path() {
1092:         let expected = if series == "8.4" { "2\n" } else { "99\n" };
1093:         for source in [rebound, local] {
1094:             let (rewritten, _) = optimised(source, &dialect_of(series));
1095:             for program in [source, rewritten.as_str()] {
1096:                 assert_eq!(
1097:                     run_script(&tclsh, program),
1098:                     Some((true, expected.to_owned())),
1099:                     "tclsh{series}:\n{program}"
1100:                 );
1101:             }
1102:         }
1103:     }
1104: }
1105: 
1106: /// A nested command the module rebinds declines the whole expression: with
1107: /// the module's own `proc llength`, `[llength {a b}]` is 99, and tclsh 8.4
1108: /// to 9.1 print 198 for `expr {[llength {a b}] * 2}`; the builtin fold would
1109: /// have answered 4.
1110: #[test]
1111: fn a_rebound_nested_head_declines_the_expression() {
1112:     let source = "proc llength {l} {return 99}\n\
1113:                   proc p {} {set r [expr {[llength {a b}] * 2}]; return $r}\nputs [p]\n";
1114:     for dialect in DIALECTS {
1115:         let unit = unit_of(source, dialect);
1116:         assert_eq!(
1117:             value_at(&unit, "::p", "r", 1),
1118:             Some(LatticeValue::Overdefined),
1119:             "{dialect}"
1120:         );
1121:         assert_eq!(
1122:             answers_for(&unit, "::p", "expr"),
1123:             ["declined: rebinding-suspected"],
1124:             "{dialect}"
1125:         );
1126:     }
1127:     let pure = "proc p {} {set r [expr {[llength {a b}] * 2}]; return $r}\nputs [p]\n";
1128:     for dialect in DIALECTS {
1129:         assert_eq!(
1130:             value_at(&unit_of(pure, dialect), "::p", "r", 1),
1131:             Some(LatticeValue::Const(ConstValue::Int(4))),
1132:             "{dialect}"
1133:         );
1134:     }
1135:     prints_under_every_release(source, "198\n");
1136:     prints_under_every_release(pure, "4\n");
1137: }
1138: 
1139: /// A condition over one finite input decides when every member agrees:
1140: /// `foreach a {1 2}` makes `a` the set `{1, 2}`, so `$a > 0` is true for
1141: /// each and the branch folds, while `$a > 1` differs between the members
1142: /// and stays open (tclsh 8.4 to 9.1 print `pos pos` and `small big`).
1143: #[test]
1144: fn a_finite_condition_decides_when_every_member_agrees() {
1145:     let decided = |source: &str, dialect: &str| -> Vec<(String, bool)> {
1146:         let unit = unit_of(source, dialect);
1147:         unit.procedures
1148:             .get(&fixture_id(&unit.ir_module.procedures, "::p"))
1149:             .expect("the procedure")
1150:             .sccp
1151:             .constant_branches
1152:             .iter()
1153:             .map(|branch| (branch.condition.clone(), branch.value))
1154:             .collect()
1155:     };
1156:     let agree = "proc p {} {foreach a {1 2} {if {$a > 0} {puts pos} else {puts neg}}}\np\n";
1157:     let split = "proc p {} {foreach a {1 2} {if {$a > 1} {puts big} else {puts small}}}\np\n";
1158:     for dialect in DIALECTS {
1159:         assert!(
1160:             decided(agree, dialect).contains(&("$a > 0".to_owned(), true)),
1161:             "{dialect}: {:?}",
1162:             decided(agree, dialect)
1163:         );
1164:         assert!(
1165:             !decided(split, dialect)
1166:                 .iter()
1167:                 .any(|(condition, _)| condition == "$a > 1"),
1168:             "{dialect}: {:?}",
1169:             decided(split, dialect)
1170:         );
1171:     }
1172:     prints_under_every_release(agree, "pos\npos\n");
1173:     prints_under_every_release(split, "small\nbig\n");
1174: }
1175: 
1176: /// A folded call keeps a double's Tcl spelling: `proc p {} {return [expr
1177: /// {1.0 * 3}]}; puts [p]` prints `3.0` under tclsh 8.4 to 9.1, and O103 had
1178: /// rewritten the call to `puts 3` with Rust's float rendering.
1179: #[test]
1180: fn a_folded_call_keeps_a_doubles_spelling() {
1181:     for source in [
1182:         "proc p {} {return [expr {1.0 * 3}]}\nputs [p]\n",
1183:         "proc p {} {set r [expr {1.0 * 3}]; return $r}\nputs [p]\n",
1184:     ] {
1185:         for dialect in ["tcl8.6", "tcl9.0"] {
1186:             let (rewritten, _) = optimised(source, dialect);
1187:             assert!(!rewritten.contains("puts 3\n"), "{dialect}:\n{rewritten}");
1188:         }
1189:         prints_under_every_release(source, "3.0\n");
1190:     }
1191: }
1192: 
1193: /// `format` runs the shared core on its registry-owned route, reading its
1194: /// operands from the lattice and its literal words under the document's
1195: /// escape grammar: tclsh 8.4 and 8.5 read `"\x4142"` as the one byte `B`
1196: /// (`\x` takes every hex digit before 8.6) and 8.6 to 9.1 as `A42`; `%03d`
1197: /// of the constant 5 is `005` and `%5.2f` of 3.14159 is ` 3.14` everywhere.
1198: #[test]
1199: fn format_folds_through_the_shared_core() {
1200:     let source = "proc p {} {set n 5; set r [format %03d $n]; set s [format %s \"\\x4142\"]; \
1201:                   set t [format %5.2f 3.14159]; return \"$r|$s|$t\"}\nputs [p]\n";
1202:     for (dialect, bytes) in [("tcl8.4", "B"), ("tcl8.6", "A42"), ("tcl9.0", "A42")] {
1203:         let unit = unit_of(source, dialect);
1204:         assert_eq!(
1205:             value_at(&unit, "::p", "r", 1),
1206:             Some(text("005")),
1207:             "{dialect}"
1208:         );
1209:         assert_eq!(
1210:             value_at(&unit, "::p", "s", 1),
1211:             Some(text(bytes)),
1212:             "{dialect}"
1213:         );
1214:         assert_eq!(
1215:             value_at(&unit, "::p", "t", 1),
1216:             Some(text(" 3.14")),
1217:             "{dialect}"
1218:         );
1219:     }
1220:     for (series, tclsh) in releases_on_path() {
1221:         let expected = if matches!(series, "8.4" | "8.5") {
1222:             "005|B| 3.14\n"
1223:         } else {
1224:             "005|A42| 3.14\n"
1225:         };
1226:         let (rewritten, _) = optimised(source, &dialect_of(series));
1227:         for program in [source, rewritten.as_str()] {
1228:             assert_eq!(
1229:                 run_script(&tclsh, program),
1230:                 Some((true, expected.to_owned())),
1231:                 "tclsh{series}:\n{program}"
1232:             );
1233:         }
1234:     }
1235: }
1236: 
1237: /// The route tally counts every family's entries once — the fixed point
1238: /// re-evaluates each statement several times before it settles, so only
1239: /// the settled sweep counts — with a nested route entry counted beside its
1240: /// host's: `set r [expr {"x"}]; set n [expr {[string length abcdef] *
1241: /// 2}]` is two fused expressions, one nesting a direct-routed `string
1242: /// length`, so `direct 1 · expression 2 · implementation 0`; `incr` alone
1243: /// is a direct entry with no expression; a decided literal condition is an
1244: /// expression entry, recorded once for reachability and once for the
1245: /// collected branch, so `if {1} {…}` is two expression entries and no
1246: /// direct one. No shipped command declares an `EvaluatorCapability`, so
1247: /// `implementation` stays 0 throughout; a pack's declared implementation
1248: /// counts there (`a_declared_implementation_folds_through_the_driver`).
1249: /// An entry is counted only
1250: /// once the route is entered: with the module's own `proc expr`, `set r
1251: /// [expr {1 + 1}]` declines at the trust check and never reaches the
1252: /// engine, so it counts nothing.
1253: #[test]
1254: fn route_entries_are_counted_per_family() {
1255:     let tally_of = |source: &str, dialect: &str| {
1256:         let unit = unit_of(source, dialect);
1257:         unit.procedures
1258:             .get(&fixture_id(&unit.ir_module.procedures, "::p"))
1259:             .expect("the procedure")
1260:             .sccp
1261:             .route_tally
1262:     };
1263:     let nested_expr = "proc p {} {set r [expr {\"x\"}]; \
1264:                         set n [expr {[string length abcdef] * 2}]}";
1265:     let direct_only = "proc p {} {set x 1; incr x; return $x}";
1266:     let expression_only = "proc p {} {if {1} {puts a} else {puts b}}";
1267:     let rebound_expr = "proc expr {args} {return 99}\nproc p {} {set r [expr {1 + 1}]}";
1268:     for dialect in DIALECTS {
1269:         let tally = tally_of(nested_expr, dialect);
1270:         assert_eq!(tally.direct, 1, "{dialect}: the nested `string length`");
1271:         assert_eq!(tally.expression, 2, "{dialect}: both fused `expr`s");
1272:         assert_eq!(tally.implementation, 0, "{dialect}");
1273: 
1274:         let tally = tally_of(direct_only, dialect);
1275:         assert_eq!(tally.direct, 1, "{dialect}: the typed `incr`");
1276:         assert_eq!(tally.expression, 0, "{dialect}");
1277:         assert_eq!(tally.implementation, 0, "{dialect}");
1278: 
1279:         let tally = tally_of(expression_only, dialect);
1280:         assert_eq!(tally.direct, 0, "{dialect}");
1281:         assert_eq!(
1282:             tally.expression, 2,
1283:             "{dialect}: the condition, reachability and the collected branch"
1284:         );
1285:         assert_eq!(tally.implementation, 0, "{dialect}");
1286: 
1287:         let tally = tally_of(rebound_expr, dialect);
1288:         assert_eq!(
1289:             (tally.direct, tally.expression, tally.implementation),
1290:             (0, 0, 0),
1291:             "{dialect}: a rebound `expr` enters no route"
1292:         );
1293:     }
1294: }
1295: 
1296: /// The interface contract's `expr` acceptance list: multi-argument forms,
1297: /// braced versus quoted arguments, short-circuit operators and ternaries,
1298: /// strings that look like code, nested pure substitutions, errors,
1299: /// bignums, and target release ambiguity.
1300: /// Each case is `proc p {} {<prelude>; set r [<expr call>]}`, oracle
1301: /// values checked against `tclsh8.4` to `tclsh9.1` directly.
1302: /// `expression_witnesses_match_every_release_on_path` re-runs the same
1303: /// programs against the real interpreters. `2**64` and `1 << 70` are
1304: /// beyond-wide from 8.5: `tclsh8.4` raises for the first (`**` is not an
1305: /// 8.4 operator) and wraps to 0 for the second, so both decline under
1306: /// `tcl8.4` (`WrongRepresentation`) and under `f5-irules`, whose runtime
1307: /// base is 8.4's; `"010" + 0` reads the leading zero as octal up to
1308: /// 8.6, `f5-irules` included, and as decimal from 9.0. The lenient profile
1309: /// declares no release, so all three release-dependent cases decline there.
1310: #[test]
1311: fn expr_acceptance_list() {
1312:     let cases: [(&str, &str, &str, [Option<&str>; 5]); 10] = [
1313:         ("multi-argument form", "", "expr 1 + 2", [Some("3"); 5]),
1314:         (
1315:             "a quoted argument substituted as text",
1316:             "set a {1 + 1}",
1317:             "expr \"$a * 2\"",
1318:             [Some("3"); 5],
1319:         ),
1320:         (
1321:             "short-circuit &&",
1322:             "",
1323:             "expr {0 && [error never]}",
1324:             [Some("0"); 5],
1325:         ),
1326:         (
1327:             "a ternary",
1328:             "",
1329:             "expr {1 ? \"yes\" : \"no\"}",
1330:             [Some("yes"); 5],
1331:         ),
1332:         (
1333:             "a value that looks like code is never re-substituted",
1334:             "set a {[exit]}",
1335:             "expr {$a eq {[exit]}}",
1336:             [Some("1"); 5],
1337:         ),
1338:         (
1339:             "a nested pure substitution",
1340:             "",
1341:             "expr {[string length abcdef] * 2}",
1342:             [Some("12"); 5],
1343:         ),
1344:         ("an error", "", "expr {1/0}", [None; 5]),
1345:         (
1346:             "a bignum",
1347:             "",
1348:             "expr {2**64}",
1349:             [
1350:                 None,
1351:                 Some("18446744073709551616"),
1352:                 Some("18446744073709551616"),
1353:                 None,
1354:                 None,
1355:             ],
1356:         ),
1357:         (
1358:             "a shift beyond wide",
1359:             "",
1360:             "expr {1 << 70}",
1361:             [
1362:                 None,
1363:                 Some("1180591620717411303424"),
1364:                 Some("1180591620717411303424"),
1365:                 None,
1366:                 None,
1367:             ],
1368:         ),
1369:         (
1370:             "a leading-zero numeral, release-dependent",
1371:             "",
1372:             "expr {\"010\" + 0}",
1373:             [Some("8"), Some("8"), Some("10"), Some("8"), None],
1374:         ),
1375:     ];
1376:     for (description, prelude, expr_call, expected) in cases {
1377:         let source = format!("proc p {{}} {{{prelude}\nset r [{expr_call}]\n}}");
1378:         for (dialect, want) in DIALECTS.into_iter().zip(expected) {
1379:             let unit = unit_of(&source, dialect);
1380:             let folded = value_at(&unit, "::p", "r", 1).and_then(lattice_text);
1381:             assert_eq!(
1382:                 folded.as_deref(),
1383:                 want,
1384:                 "{dialect}: {description} ({expr_call})"
1385:             );
1386:         }
1387:     }
1388: }
1389: 
1390: /// One distinct finite SSA value stays correlated with itself: `foreach a
1391: /// {1 2} {set r [expr {$a * $a}]}` gives the in-loop `r` the set `{1, 4}`,
1392: /// never `{1, 2, 4}` — the cartesian product a wrongly-independent pairing
1393: /// would produce (§ *The correlated finite-set limit*).
1394: #[test]
1395: fn the_square_of_one_finite_input_stays_correlated() {
1396:     let source = "proc p {} {foreach a {1 2} {set r [expr {$a * $a}]}}";
1397:     for dialect in DIALECTS {
1398:         let unit = unit_of(source, dialect);
1399:         let value = value_at(&unit, "::p", "r", 1).expect("r's in-loop definition");
1400:         let LatticeValue::ConstSet(mut members) = value else {
1401:             panic!("{dialect}: {value:?} is not a finite set");
1402:         };
1403:         members.sort_by_key(|c| match c {
1404:             ConstValue::Int(i) => *i,
1405:             other => panic!("{dialect}: {other:?}"),
1406:         });
1407:         assert_eq!(
1408:             members,
1409:             vec![ConstValue::Int(1), ConstValue::Int(4)],
1410:             "{dialect}"
1411:         );
1412:     }
1413: }
1414: 
1415: /// The mirror pairs of the interface page
1416: /// (`docs/design/compiler/value-transfers.md` § *The correlated
1417: /// finite-set limit*): `a` and `b` are the loop's two binders, so pairing
1418: /// them by position or taking their cartesian product would both be
1419: /// unsound. The loop header answers each binder of the two-binder source
1420: /// with the elements it takes (`a` is `{1 2}`, `b` is `{10 20}`), so each
1421: /// quotient sees the page's two distinct `Finite` identities and declines
1422: /// `CorrelatedSets`, and the version each loop leaves `x` and `y` at holds
1423: /// no value of its own. Only ordered enumeration answers what the loops
1424: /// leave — `x` is 10 and `y` is 5, each loop's last quotient — which the
1425: /// solver states on each loop's exit, so each post-loop branch decides
1426: /// false: tclsh 8.4 to 9.1 print `other` twice.
1427: #[test]
1428: fn the_mirror_pairs_decline_as_correlated() {
1429:     let source = "proc p {} {\n\
1430:                    set x 0\n\
1431:                    foreach {a b} {1 10 2 20} { set x [expr {$b / $a}] }\n\
1432:                    if {$x == 20} { puts twenty } else { puts other }\n\
1433:                    set y 0\n\
1434:                    foreach {a b} {1 20 2 10} { set y [expr {$b / $a}] }\n\
1435:                    if {$y == 25} { puts twentyfive } else { puts other }\n\
1436:                   }\n";
1437:     for dialect in DIALECTS {
1438:         let unit = unit_of(source, dialect);
1439:         let function = unit
1440:             .procedures
1441:             .get(&fixture_id(&unit.procedures, "::p"))
1442:             .expect("the procedure");
1443:         for var in ["x", "y"] {
1444:             let symbol = function.ssa.var_symbol(var).expect(var);
1445:             let last = function
1446:                 .sccp
1447:                 .values
1448:                 .iter()
1449:                 .filter(|((sym, _), _)| *sym == symbol)
1450:                 .max_by_key(|((_, version), _)| *version)
1451:                 .map(|(_, value)| value.clone())
1452:                 .expect("a definition");
1453:             assert_eq!(last, LatticeValue::Overdefined, "{dialect}: {var}");
1454:         }
1455:         for condition in ["$x == 20", "$y == 25"] {
1456:             let decided = function
1457:                 .sccp
1458:                 .constant_branches
1459:                 .iter()
1460:                 .find(|branch| branch.condition == condition)
1461:                 .unwrap_or_else(|| {
1462:                     panic!(
1463:                         "{dialect}: {condition} undecided: {:?}",
1464:                         function.sccp.constant_branches
1465:                     )
1466:                 });
1467:             assert!(!decided.value, "{dialect}: {condition}");
1468:         }
1469:         // The two-binder source is lowered: `a` and `b` are two
1470:         // distinct finite inputs, so each quotient declines as correlated.
1471:         let answers = answers_for(&unit, "::p", "expr");
1472:         assert_eq!(
1473:             answers,
1474:             ["declined: correlated-sets", "declined: correlated-sets"],
1475:             "{dialect}"
1476:         );
1477:     }
1478:     prints_under_every_release(&format!("{source}p\n"), "other\nother\n");
1479: }
1480: 
1481: /// A condition over a leading-zero digit string decides nothing under 8.x:
1482: /// the grammar reads `08` as an invalid octal, so it reaches the condition
1483: /// as text and `if` raises `expected boolean value but got "08"` (tclsh 8.5
1484: /// and 8.6; 8.4, 9.0 and 9.1 print `yes`). It was decided true (I230) and
1485: /// rewritten to `if {1}`. Under 9.0 `08` is the number 8 and the branch is
1486: /// decided.
1487: #[test]
1488: fn an_invalid_octal_condition_decides_nothing() {
1489:     for (literal, quoted) in [("08", false), ("-08", false), ("08", true)] {
1490:         let condition = if quoted {
1491:             format!("\"{literal}\"")
1492:         } else {
1493:             "$x".to_owned()
1494:         };
1495:         let source = format!(
1496:             "proc p {{}} {{set x {literal}; if {{{condition}}} {{puts yes}} else {{puts no}}}}\np\n"
1497:         );
1498:         for (dialect, decided) in [("tcl8.6", false), ("tcl9.0", true)] {
1499:             let unit = unit_of(&source, dialect);
1500:             let function = unit
1501:                 .procedures
1502:                 .get(&fixture_id(&unit.procedures, "::p"))
1503:                 .expect("the procedure");
1504:             assert_eq!(
1505:                 !function.sccp.constant_branches.is_empty(),
1506:                 decided,
1507:                 "{dialect}: {source}: {:?}",
1508:                 function.sccp.constant_branches
1509:             );
1510:         }
1511:         for (series, tclsh) in releases_on_path() {
1512:             let (rewritten, rewrites) = optimised(&source, &dialect_of(series));
1513:             assert_eq!(
1514:                 run_script(&tclsh, &rewritten),
1515:                 run_script(&tclsh, &source),
1516:                 "tclsh{series}:\n{rewritten}\n{rewrites:#?}"
1517:             );
1518:         }
1519:     }
1520: }
1521: 
1522: /// `expr_acceptance_list`'s programs, run against the real `tclsh` per
1523: /// release found on `PATH`: wherever the compiler's fold answers a value
1524: /// it is the same value `tclsh` prints, and wherever the underlying
1525: /// program raises the fold has declined too. At least half the programs
1526: /// must fold on any release, so the witness is not vacuous. The optimised
1527: /// program must print what the original prints — or raise where it raises —
1528: /// under the same release, so a rewrite never folds what the lattice
1529: /// declines: the last four programs are O101's (`1 << 70` wraps to 0 under
1530: /// tclsh 8.4; `1e308 * 10` raises `floating-point value too large to
1531: /// represent` there; `min` is unknown before 8.5; `ABS` is no math function
1532: /// in any release).
1533: #[test]
1534: fn expression_witnesses_match_every_release_on_path() {
1535:     let cases: [(&str, &str); 13] = [
1536:         ("", "expr 1 + 2"),
1537:         ("set a {1 + 1}", "expr \"$a * 2\""),
1538:         ("", "expr {0 && [error never]}"),
1539:         ("", "expr {1 ? \"yes\" : \"no\"}"),
1540:         ("set a {[exit]}", "expr {$a eq {[exit]}}"),
1541:         ("", "expr {[string length abcdef] * 2}"),
1542:         ("", "expr {1/0}"),
1543:         ("", "expr {2**64}"),
1544:         ("", "expr {1 << 70}"),
1545:         ("", "expr {\"010\" + 0}"),
1546:         ("", "expr {1e308 * 10}"),
1547:         ("", "expr {min(1,2)}"),
1548:         ("", "expr {ABS(-2)}"),
1549:     ];
1550:     for (series, tclsh) in releases_on_path() {
1551:         let dialect = dialect_of(series);
1552:         let mut answered = 0usize;
1553:         for (prelude, expr_call) in cases {
1554:             let source = format!("proc p {{}} {{{prelude}\nset r [{expr_call}]\n}}");
1555:             let unit = unit_of(&source, &dialect);
1556:             let folded = value_at(&unit, "::p", "r", 1).and_then(lattice_text);
1557:             let oracle = run_script(&tclsh, &format!("{prelude}\nset r [{expr_call}]\nputs $r"));
1558:             match (&folded, oracle) {
1559:                 (Some(value), Some((true, printed))) => {
1560:                     assert_eq!(
1561:                         value.as_str(),
1562:                         printed.trim_end_matches('\n'),
1563:                         "tclsh{series}: {expr_call}"
1564:                     );
1565:                     answered += 1;
1566:                 }
1567:                 (Some(value), other) => panic!(
1568:                     "tclsh{series}: {expr_call} folded to {value} but tclsh answered {other:?}"
1569:                 ),
1570:                 // A decline under a release whose runtime tclsh happens
1571:                 // not to raise for (`1 << 70` wraps silently under 8.4)
1572:                 // is still a decline: nothing to check either way.
1573:                 (None, _) => {}
1574:             }
1575:             let program =
1576:                 format!("proc p {{}} {{{prelude}\nset r [{expr_call}]\nreturn $r\n}}\nputs [p]\n");
1577:             let (rewritten, rewrites) = optimised(&program, &dialect);
1578:             assert_eq!(
1579:                 run_script(&tclsh, &rewritten),
1580:                 run_script(&tclsh, &program),
1581:                 "tclsh{series}: {expr_call}\n{rewritten}\n{rewrites:#?}"
1582:             );
1583:         }
1584:         assert!(
1585:             answered * 2 > cases.len(),
1586:             "tclsh{series}: the fold answered only {answered} of {} cases",
1587:             cases.len()
1588:         );
1589:     }
1590: }
1591: 
1592: /// O101 rewrites only what the shared expression route proves, so the
1593: /// programs the old constant folder rewrote against the target stay put
1594: /// (`tcl opt --profile full` applies every pass, as `optimised` does).
1595: /// Oracle, tclsh 8.4: `1 << 70` is `0` (the wide shift wraps), `1e308 * 10`
1596: /// raises `floating-point value too large to represent`, and `min(1,2)`
1597: /// raises `unknown math function "min"`; 8.5 to 9.1 answer
1598: /// `1180591620717411303424`, `Inf` and `1`. `ABS(-2)` raises on every
1599: /// release (`unknown math function "ABS"` under 8.4, `invalid command name
1600: /// "tcl::mathfunc::ABS"` from 8.5): a math function's name is
1601: /// case-sensitive. An infinity in the middle is the same tower: `(1e308 *
1602: /// 10) > 0` is 1 from 8.5 and raises at the product under 8.4. None of them
1603: /// folds under iRules — 8.4, the release its engine runs, folds none — nor
1604: /// under the version-less `tcl` profile, whose releases disagree on each.
1605: #[test]
1606: fn o101_rewrites_only_what_the_route_proves() {
1607:     let cases: [(&str, [Option<&str>; 5]); 5] = [
1608:         (
1609:             "1 << 70",
1610:             [
1611:                 None,
1612:                 Some("1180591620717411303424"),
1613:                 Some("1180591620717411303424"),
1614:                 None,
1615:                 None,
1616:             ],
1617:         ),
1618:         ("1e308 * 10", [None, Some("Inf"), Some("Inf"), None, None]),
1619:         ("(1e308 * 10) > 0", [None, Some("1"), Some("1"), None, None]),
1620:         ("min(1,2)", [None, Some("1"), Some("1"), None, None]),
1621:         ("ABS(-2)", [None; 5]),
1622:     ];
1623:     for (expression, answers) in cases {
1624:         let program =
1625:             format!("proc p {{}} {{set r [expr {{{expression}}}]; return $r}}\nputs [p]\n");
1626:         for (dialect, answer) in DIALECTS.into_iter().zip(answers) {
1627:             let (rewritten, rewrites) = optimised(&program, dialect);
1628:             let kept = rewritten.contains(&format!("expr {{{expression}}}"));
1629:             match answer {
1630:                 None => assert!(
1631:                     kept,
1632:                     "{dialect}: `expr {{{expression}}}` must stay:\n{rewritten}\n{rewrites:#?}"
1633:                 ),
1634:                 Some(value) => assert!(
1635:                     !kept && rewritten.contains(value),
1636:                     "{dialect}: `expr {{{expression}}}` folds to {value}:\n{rewritten}\n{rewrites:#?}"
1637:                 ),
1638:             }
1639:         }
1640:     }
1641: }
1642: 
1643: /// O112 decided a condition with the old constant folder, which answered
1644: /// a beyond-wide integer or an infinity under 8.4 as 8.5 does and read no
1645: /// binding. tclsh 8.4: `1 << 70` wraps to 0, so `if {(1 << 70) == 0}`
1646: /// takes its first branch and `while {(1 << 70) == 0}` runs; `1e308 * 10`
1647: /// raises `floating-point value too large to represent`. From 8.5 the
1648: /// shift is 1180591620717411303424 and the product `Inf`. With `proc
1649: /// ::tcl::mathfunc::abs {x} {return 99}`, tclsh 8.5 to 9.1 print `other`
1650: /// and `loop`, where O112 kept `puts two` alone (8.4 has no wrapper
1651: /// namespace, so the `proc` fails and the builtin prints `two`). Each
1652: /// program prints the same optimised as it does unoptimised under every
1653: /// release.
1654: #[test]
1655: fn a_structure_fold_stays_within_the_targets_tower() {
1656:     let rebound = "catch {proc ::tcl::mathfunc::abs {x} {return 99}}\n\
1657:                    proc p {} {\n\
1658:                    if {abs(-2) == 2} {puts two} else {puts other}\n\
1659:                    while {abs(-2) == 99} {puts loop; break}\n\
1660:                    }\np\n";
1661:     let programs = [
1662:         (
1663:             "proc p {} {if {(1 << 70) == 0} {puts zero} else {puts big}}\np\n",
1664:             &["tcl8.4"][..],
1665:             &["if {"][..],
1666:         ),
1667:         (
1668:             "proc p {} {while {(1 << 70) == 0} {puts once; break}; puts done}\np\n",
1669:             &["tcl8.4"][..],
1670:             &["while {"][..],
1671:         ),
1672:         (
1673:             "proc p {} {if {1e308 * 10 > 0} {puts inf} else {puts finite}}\np\n",
1674:             &["tcl8.4"][..],
1675:             &["if {"][..],
1676:         ),
1677:         (
1678:             rebound,
1679:             &["tcl8.6", "tcl9.0"][..],
1680:             &["if {abs(-2) == 2}", "while {"][..],
1681:         ),
1682:     ];
1683:     for (program, undecided_under, kept) in programs {
1684:         for dialect in undecided_under {
1685:             let (rewritten, rewrites) = optimised(program, dialect);
1686:             assert!(
1687:                 kept.iter().all(|structure| rewritten.contains(structure)),
1688:                 "{dialect} decides nothing:\n{rewritten}\n{rewrites:#?}"
1689:             );
1690:         }
1691:         for (series, tclsh) in releases_on_path() {
1692:             let (rewritten, rewrites) = optimised(program, &dialect_of(series));
1693:             assert_eq!(
1694:                 run_script(&tclsh, &rewritten),
1695:                 run_script(&tclsh, program),
1696:                 "tclsh{series}:\n{rewritten}\n{rewrites:#?}"
1697:             );
1698:         }
1699:     }
1700: }
1701: 
1702: /// The bounded host's stand-in for `tenant::label`'s body `{name} { fold
1703: /// [string cat "tenant:" $name] }`: one exact argument in, `tenant:` before
1704: /// it out, under the release the call is pinned to.
1705: struct LabelHost;
1706: 
1707: impl tcl_registry::pack_hooks::PackHookHost for LabelHost {
1708:     fn invoke(
1709:         &self,
1710:         _slot: tcl_registry::pack_hooks::HookSlot,
1711:         call: &tcl_registry::pack_hooks::HookCall<'_>,
1712:     ) -> tcl_registry::pack_hooks::HookAnswer {
1713:         use tcl_registry::pack_hooks::{EvaluationAnswer, HookAnswer};
1714:         match call.words {
1715:             [name] if call.dialect == Some("tcl9.0") => HookAnswer::Evaluation(EvaluationAnswer {
1716:                 result: Some(format!("tenant:{}", name.value)),
1717:                 stores: Vec::new(),
1718:             }),
1719:             _ => HookAnswer::Abstain,
1720:         }
1721:     }
1722: }
1723: 
1724: /// A `tcl9.0` registry holding `tenant::label` as a pack declares it —
1725: /// `arity 1`, `evaluate -implementation tenant.label.v1 -host bounded_tcl`
1726: /// reading `arg 0 exact` — its body bound to an `evaluate` slot.
1727: fn tenant_label_registry() -> tcl_registry::CommandRegistry {
1728:     use tcl_registry::pack_hooks::{self, HookFamily, HookInput, HookInputs};
1729:     use tcl_registry::spec::CommandSpec;
1730:     use tcl_registry::value_transfer::{
1731:         CompletionSupport, ContextDependency, DeclaredEvaluation, DeclaredImplementation,
1732:         DeclaredInput, DeclaredSemantics, DeclaredStructure, EvaluatorCapability, Exactness,
1733:         HostKind, ImplementationBudget, ImplementationIdentity, Needs, SemanticsDeclaration,
1734:     };
1735: 
1736:     let slot = pack_hooks::allocate(
1737:         HookFamily::Evaluate,
1738:         &HookInputs::declared([HookInput::Words]),
1739:     )
1740:     .expect("an evaluate slot");
1741:     let label: &'static DeclaredSemantics = Box::leak(Box::new(DeclaredSemantics {
1742:         scope: "tenant::label",
1743:         structure: DeclaredStructure::default(),
1744:         evaluation: DeclaredEvaluation::Implementation(DeclaredImplementation {
1745:             capability: EvaluatorCapability {
1746:                 identity: ImplementationIdentity {
1747:                     pack: "tenant",
1748:                     id: "tenant.label.v1",
1749:                     content_hash: 1,
1750:                 },
1751:                 host: HostKind::BoundedTcl,
1752:                 target: Needs::NONE,
1753:                 inputs: &[DeclaredInput::Operand {
1754:                     index: 0,
1755:                     exactness: Exactness::Exact,
1756:                 }],
1757:                 depends: &[
1758:                     ContextDependency::TclProfile,
1759:                     ContextDependency::ImplementationIdentity,
1760:                 ],
1761:                 budget: ImplementationBudget {
1762:                     commands: Some(2000),
1763:                     wall_clock_ms: Some(20),
1764:                     value_bytes: Some(65536),
1765:                 },
1766:                 completion: CompletionSupport::NormalOnly,
1767:             },
1768:             slot: Some(slot),
1769:             extension: None,
1770:         }),
1771:         option_declines: &[],
1772:     }));
1773:     let mut base = tcl_registry::CommandRegistry::build_default();
1774:     base.insert(CommandSpec {
1775:         name: "tenant::label",
1776:         semantics: SemanticsDeclaration::Declared(label),
1777:         ..CommandSpec::DEFAULT
1778:     });
1779:     base.project_for_profile(tcl_dialect::DialectProfile::find("tcl9.0").expect("the profile"))
1780: }
1781: 
1782: /// A declared implementation runs through the driver as a shipped route
1783: /// does, from the pack's declaration alone: `tenant::label acme` folds to
1784: /// `tenant:acme` through the body's `fold`, and the entry counts as an
1785: /// implementation; an argument the analysis does not know declines
1786: /// `NotExact` before any body runs; and a worker with no host declines
1787: /// `Transient` — a state of the worker, never a verdict on the inputs. The
1788: /// host here stands in for the bounded one, which runs the body in
1789: /// `tcl-spec-hooks`' own witnesses.
1790: #[test]
1791: fn a_declared_implementation_folds_through_the_driver() {
1792:     use tcl_registry::pack_hooks;
1793: 
1794:     let registry = tenant_label_registry();
1795:     let source = "proc p {x} {\n\
1796:                   set known [tenant::label acme]\n\
1797:                   set unknown [tenant::label $x]\n\
1798:                   return $known$unknown\n\
1799:                   }\n";
1800:     let routes = |unit: &CompilationUnit| -> Vec<String> {
1801:         unit.procedures
1802:             .get(&fixture_id(&unit.procedures, "::p"))
1803:             .expect("the procedure")
1804:             .sccp
1805:             .explanations
1806:             .iter()
1807:             .filter(|explanation| explanation.command == "tenant::label")
1808:             .map(|explanation| explanation.route.clone())
1809:             .collect()
1810:     };
1811: 
1812:     pack_hooks::install_host(std::rc::Rc::new(LabelHost));
1813:     let unit = CompilationUnit::build_for_dialect(source, &registry, false, "tcl9.0");
1814:     assert_eq!(
1815:         value_at(&unit, "::p", "known", 1),
1816:         Some(text("tenant:acme"))
1817:     );
1818:     assert_eq!(
1819:         value_at(&unit, "::p", "unknown", 1),
1820:         Some(LatticeValue::Overdefined)
1821:     );
1822:     assert_eq!(
1823:         answers_for(&unit, "::p", "tenant::label"),
1824:         ["evaluated", "declined: not-exact"]
1825:     );
1826:     assert_eq!(
1827:         routes(&unit),
1828:         [
1829:             "implementation tenant.label.v1",
1830:             "implementation tenant.label.v1"
1831:         ]
1832:     );
1833:     let tally = unit
1834:         .procedures
1835:         .get(&fixture_id(&unit.procedures, "::p"))
1836:         .expect("the procedure")
1837:         .sccp
1838:         .route_tally;
1839:     assert_eq!(tally.implementation, 2, "both calls enter the route");
1840:     assert_eq!(tally.direct, 0);
1841: 
1842:     // The same worker without its host: the known call cannot run, and
1843:     // says so as a transient decline; the unknown one still declines on
1844:     // its input first.
1845:     pack_hooks::clear_host();
1846:     let unit = CompilationUnit::build_for_dialect(source, &registry, false, "tcl9.0");
1847:     assert_eq!(
1848:         value_at(&unit, "::p", "known", 1),
1849:         Some(LatticeValue::Overdefined)
1850:     );
1851:     assert_eq!(
1852:         answers_for(&unit, "::p", "tenant::label"),
1853:         ["declined: transient", "declined: not-exact"]
1854:     );
1855: }
1856: 
1857: /// The value-transfer design's executable example: a private command
1858: /// a workspace pack declares under its own name, a second name, and a
1859: /// subcommand form whose operand sits one word later.
1860: const TENANT_PACK: &str = include_str!("fixtures/value_transfers/tenant.tclspec");
1861: 
1862: /// The example's three spellings, each taking the name as its last word.
1863: const TENANT_SPELLINGS: [&str; 3] = ["tenant::label", "tenant::tag", "tenant label"];
1864: 
1865: /// What a vendor runtime provides for the example: the three spellings as
1866: /// real commands, written for every release from 8.4 (no `string cat`, no
1867: /// `namespace ensemble`), so a program the analysis never sees the
1868: /// definitions of runs under each `tclsh`.
1869: const TENANT_RUNTIME: &str = "namespace eval ::tenant {\n\
1870:                               \x20   proc label {name} {return \"tenant:$name\"}\n\
1871:                               \x20   proc tag {name} {return \"tenant:$name\"}\n\
1872:                               }\n\
1873:                               proc ::tenant {subcommand name} {\n\
1874:                               \x20   if {$subcommand ne \"label\"} {error \"bad subcommand $subcommand\"}\n\
1875:                               \x20   return [::tenant::label $name]\n\
1876:                               }\n";
1877: 
1878: /// Serialises the tests that publish a hook plan: the published plan is the
1879: /// process's, and a thread whose host was built from a plan follows it.
1880: static PUBLISHED_PACKS: std::sync::Mutex<()> = std::sync::Mutex::new(());
1881: 
1882: /// A workspace pack of `source` loaded as the language server and the CLI
1883: /// load one: the pack set, its hook plan published and this thread's host
1884: /// built from it.
1885: fn pack_workspace(name: &str, source: &str) -> tcl_spectcl::PackSet {
1886:     let packs = pack_workspace_noting(name, source);
1887:     assert!(packs.notices.is_empty(), "{:#?}", packs.notices);
1888:     packs
1889: }
1890: 
1891: /// [`pack_workspace`] for a pack whose load notices the caller accepts.
1892: fn pack_workspace_noting(name: &str, source: &str) -> tcl_spectcl::PackSet {
1893:     let packs = tcl_spectcl::pack::load_in_memory(vec![(
1894:         tcl_spectcl::PackFile {
1895:             tier: tcl_spectcl::Tier::Workspace,
1896:             path: std::path::PathBuf::from(format!("/workspace/.tcl-lsp/{name}.tclspec")),
1897:             origin: tcl_spectcl::discovery::Origin::DotDir,
1898:             dependency_tier: None,
1899:         },
1900:         source.to_owned(),
1901:     )]);
1902:     tcl_spectcl::hooks::publish(&packs);
1903:     tcl_spectcl::hooks::ensure_thread_host();
1904:     packs
1905: }
1906: 
1907: /// The example loaded as a workspace loads it: the pack set, its hook plan
1908: /// published and this thread's host built from it, as the language server
1909: /// and the CLI do on a pack load.
1910: fn tenant_workspace() -> tcl_spectcl::PackSet {
1911:     pack_workspace("tenant", TENANT_PACK)
1912: }
1913: 
1914: /// Program (2) of the interface page: `binary format` declares a
1915: /// registry-owned route, so `set h [binary format H* 414243444546]` is
1916: /// `ABCDEF` in the shared lattice under every profile, typed a byte array by
1917: /// construction, and neither S100 nor S110 reports a conversion for it. A
1918: /// computed byte array has no lossless source spelling, so no rewrite writes
1919: /// it into the program (`SccpResult::materialises`): the optimised program
1920: /// keeps the command that builds it and prints what every release prints.
1921: #[test]
1922: fn program_two_folds_and_is_a_byte_array() {
1923:     use tcl_compiler::shimmer::{find_byte_array_warnings_for_cu, find_shimmer_warnings_for_cu};
1924:     use tcl_compiler::value_transfer::FoldedType;
1925:     use tcl_registry::TclType;
1926:     use tcl_registry::value_transfer::RepresentationEvidence;
1927:     let source = "proc p {} {\n    set h [binary format H* 414243444546]\n    puts $h\n}\n\
1928:                   proc b {} {\n    set g [binary format H* 4748]\n    return $g\n}\np\nputs [b]\n";
1929:     let byte_array = FoldedType {
1930:         intrep: Some(TclType::ByteArray),
1931:         shape: None,
1932:         representation: RepresentationEvidence::Constructed(TclType::ByteArray),
1933:     };
1934:     for dialect in DIALECTS {
1935:         let unit = unit_of(source, dialect);
1936:         assert_eq!(
1937:             value_at(&unit, "::p", "h", 1),
1938:             Some(text("ABCDEF")),
1939:             "{dialect}"
1940:         );
1941:         assert_eq!(
1942:             folded_at(&unit, "::p", "h", 1),
1943:             Some(byte_array.clone()),
1944:             "{dialect}"
1945:         );
1946:         let registry = static_context_for(dialect).commands();
1947:         let shimmers = find_shimmer_warnings_for_cu(&unit, registry);
1948:         assert!(shimmers.is_empty(), "{dialect}: {shimmers:?}");
1949:         let damage = find_byte_array_warnings_for_cu(&unit, registry);
1950:         assert!(damage.is_empty(), "{dialect}: {damage:?}");
1951:         let (rewritten, _) = optimised(source, dialect);
1952:         assert!(
1953:             !rewritten.contains("ABCDEF") && !rewritten.contains("GH"),
1954:             "{dialect}: a byte array was written into the source:\n{rewritten}"
1955:         );
1956:     }
1957:     prints_under_every_release(source, "ABCDEF\nGH\n");
1958: }
1959: 
1960: /// The folded type of `var`'s version `version` in `proc`: the semantic
1961: /// type and representation evidence the evaluation that produced it stated.
1962: fn folded_at(
1963:     unit: &CompilationUnit,
1964:     proc: &str,
1965:     var: &str,
1966:     version: u32,
1967: ) -> Option<tcl_compiler::value_transfer::FoldedType> {
1968:     let function = unit
1969:         .procedures
1970:         .get(&fixture_id(&unit.procedures, proc))
1971:         .expect("the procedure");
1972:     let symbol = function.ssa.var_symbol(var).expect("the variable");
1973:     function.sccp.folded_types.get(&(symbol, version)).cloned()
1974: }
1975: 
1976: /// The shared lattice keeps what each evaluation states of its
1977: /// value's type beside the value itself (`SccpResult::folded_types`). A
1978: /// result and a write carry the type facts and the representation the route
1979: /// constructed — `string length` and `incr` build an int, `list` a list,
1980: /// `append` a string; a copy shares its source's; a φ keeps what its arms
1981: /// state alike; a literal states nothing; an opaque barrier (`eval
1982: /// $script`) widens every value and forgets what they stated. A pack's declared implementation states its
1983: /// `result -semantic` type and no representation, and the type lattice
1984: /// takes it where the static typing knows nothing of a pack command's
1985: /// result.
1986: #[test]
1987: fn folded_types_state_what_each_route_constructed() {
1988:     use tcl_compiler::value_transfer::FoldedType;
1989:     use tcl_registry::TclType;
1990:     use tcl_registry::value_transfer::RepresentationEvidence;
1991:     let built = |ty: TclType| {
1992:         Some(FoldedType {
1993:             intrep: Some(ty),
1994:             shape: None,
1995:             representation: RepresentationEvidence::Constructed(ty),
1996:         })
1997:     };
1998:     let unit = unit_of(
1999:         "proc p {c} {\n    set s abc\n    set n [string length $s]\n    set l [list a b]\n    \
2000:          incr n\n    append s x\n    set m $n\n    \
2001:          if {$c} {set k [llength $l]} else {set k [string length $s]}\n    \
2002:          return $m$k$l$s\n}\n\
2003:          proc b {script} {\n    set s abc\n    set n [string length $s]\n    eval $script\n    \
2004:          return $n\n}\n",
2005:         "tcl9.0",
2006:     );
2007:     assert_eq!(folded_at(&unit, "::p", "s", 1), None, "a literal");
2008:     assert_eq!(folded_at(&unit, "::p", "n", 1), built(TclType::Int));
2009:     assert_eq!(folded_at(&unit, "::p", "l", 1), built(TclType::List));
2010:     assert_eq!(folded_at(&unit, "::p", "n", 2), built(TclType::Int), "incr");
2011:     assert_eq!(
2012:         folded_at(&unit, "::p", "s", 2),
2013:         built(TclType::String),
2014:         "append"
2015:     );
2016:     assert_eq!(
2017:         folded_at(&unit, "::p", "m", 1),
2018:         built(TclType::Int),
2019:         "a copy"
2020:     );
2021:     assert_eq!(
2022:         folded_at(&unit, "::p", "k", 1),
2023:         built(TclType::Int),
2024:         "the φ"
2025:     );
2026:     assert_eq!(
2027:         built(TclType::ByteArray)
2028:             .map(|folded| folded.label())
2029:             .as_deref(),
2030:         Some("bytearray (constructed)")
2031:     );
2032:     let barrier = unit
2033:         .procedures
2034:         .get(&fixture_id(&unit.procedures, "::b"))
2035:         .expect("the procedure");
2036:     assert!(
2037:         barrier.sccp.folded_types.is_empty(),
2038:         "{:?}",
2039:         barrier.sccp.folded_types
2040:     );
2041: 
2042:     let _published = PUBLISHED_PACKS
2043:         .lock()
2044:         .unwrap_or_else(std::sync::PoisonError::into_inner);
2045:     let packs = tenant_workspace();
2046:     let registry = tcl_spectcl::install::registry_for_dialect_with_packs("tcl9.0", &packs);
2047:     let unit = CompilationUnit::build_for_dialect(
2048:         "proc p {} {\n    set r [tenant::label acme]\n    return $r\n}\n",
2049:         &registry,
2050:         false,
2051:         "tcl9.0",
2052:     );
2053:     let stated = Some(FoldedType {
2054:         intrep: Some(TclType::String),
2055:         shape: None,
2056:         representation: RepresentationEvidence::Unknown,
2057:     });
2058:     assert_eq!(folded_at(&unit, "::p", "r", 1), stated);
2059:     let function = unit
2060:         .procedures
2061:         .get(&fixture_id(&unit.procedures, "::p"))
2062:         .expect("the procedure");
2063:     let r = function.ssa.var_symbol("r").expect("the variable");
2064:     assert_eq!(
2065:         function.types.get(&(r, 1)),
2066:         Some(&tcl_compiler::types::TypeLattice::of(TclType::String)),
2067:         "the type lattice takes the declared result type"
2068:     );
2069:     tcl_spectcl::hooks::publish(&tcl_spectcl::PackSet::default());
2070: }
2071: 
2072: /// The step-1 completion test (`docs/design/compiler/value-transfers.md`
2073: /// § *The completion test*): one private command, renamed, and given a
2074: /// subcommand form with its operand one word later, reaches the analysis
2075: /// and the optimiser from its pack's declarations alone — the fixture is the
2076: /// only file that names any of the three spellings.
2077: ///
2078: /// - Each spelling folds `acme` to `tenant:acme` through the analysis, on
2079: ///   the implementation route, and an argument the analysis does not know
2080: ///   declines `not-exact`; without the pack the same program folds nothing,
2081: ///   so the answer is the declaration's.
2082: /// - The body runs under the analysed release: it folds under 8.6, 9.0 and
2083: ///   9.1, and under 8.4, 8.5 and iRules' 8.4 base it raises and declines,
2084: ///   because `string cat` is 8.6's — the releases `tclsh` itself runs `puts
2085: ///   [string cat tenant: acme]` under. A profile naming no release has no
2086: ///   engine to run it on and declines.
2087: /// - The optimiser forwards the folded constant (O100), and the vendor
2088: ///   runtime — [`TENANT_RUNTIME`], which the analysis never sees — prints
2089: ///   what the optimised program prints under every `tclsh` on `PATH`.
2090: #[test]
2091: fn the_completion_test_needs_no_consumer_edit() {
2092:     let _published = PUBLISHED_PACKS
2093:         .lock()
2094:         .unwrap_or_else(std::sync::PoisonError::into_inner);
2095:     let packs = tenant_workspace();
2096:     for (dialect, folds) in [
2097:         ("tcl8.4", false),
2098:         ("tcl8.5", false),
2099:         ("tcl8.6", true),
2100:         ("tcl9.0", true),
2101:         ("tcl9.1", true),
2102:         ("f5-irules", false),
2103:         ("tcl", false),
2104:     ] {
2105:         let registry = tcl_spectcl::install::registry_for_dialect_with_packs(dialect, &packs);
2106:         for spelling in TENANT_SPELLINGS {
2107:             every_spelling_answers(&registry, dialect, spelling, folds);
2108:         }
2109:     }
2110:     the_vendor_runtime_prints_what_the_optimiser_forwards(&packs);
2111: }
2112: 
2113: /// `spelling acme` and `spelling $x` in one procedure under `dialect`: both
2114: /// calls enter the implementation route; the known argument folds to
2115: /// `tenant:acme` where the body runs (`folds`) and declines `unsupported`
2116: /// where it cannot; the unknown one declines `not-exact`. The same program
2117: /// against the registry without the pack folds nothing.
2118: fn every_spelling_answers(
2119:     registry: &tcl_registry::CommandRegistry,
2120:     dialect: &str,
2121:     spelling: &str,
2122:     folds: bool,
2123: ) {
2124:     let head = spelling.split(' ').next().expect("a head");
2125:     let source = format!(
2126:         "proc p {{x}} {{\n    set known [{spelling} acme]\n    set unknown [{spelling} $x]\n    return $known$unknown\n}}\n"
2127:     );
2128:     let unit = CompilationUnit::build_for_dialect(&source, registry, false, dialect);
2129:     let function = unit
2130:         .procedures
2131:         .get(&fixture_id(&unit.procedures, "::p"))
2132:         .expect("the procedure");
2133:     let routes: Vec<&str> = function
2134:         .sccp
2135:         .explanations
2136:         .iter()
2137:         .filter(|explanation| explanation.command == head)
2138:         .map(|explanation| explanation.route.as_str())
2139:         .collect();
2140:     assert_eq!(
2141:         routes,
2142:         [
2143:             "implementation tenant.label.v1",
2144:             "implementation tenant.label.v1"
2145:         ],
2146:         "{dialect} {spelling}"
2147:     );
2148:     let (value, answer) = if folds {
2149:         (text("tenant:acme"), "evaluated")
2150:     } else {
2151:         (LatticeValue::Overdefined, "declined: unsupported")
2152:     };
2153:     assert_eq!(
2154:         value_at(&unit, "::p", "known", 1),
2155:         Some(value),
2156:         "{dialect} {spelling}"
2157:     );
2158:     assert_eq!(
2159:         value_at(&unit, "::p", "unknown", 1),
2160:         Some(LatticeValue::Overdefined),
2161:         "{dialect} {spelling}"
2162:     );
2163:     assert_eq!(
2164:         answers_for(&unit, "::p", head),
2165:         [answer, "declined: not-exact"],
2166:         "{dialect} {spelling}"
2167:     );
2168:     assert_eq!(
2169:         function.sccp.route_tally.implementation, 2,
2170:         "{dialect} {spelling}: both calls enter the route"
2171:     );
2172:     let bare = static_context_for(dialect).commands();
2173:     let unit = CompilationUnit::build_for_dialect(&source, bare, false, dialect);
2174:     assert_eq!(
2175:         value_at(&unit, "::p", "known", 1),
2176:         Some(LatticeValue::Overdefined),
2177:         "{dialect} {spelling}: without the pack the name is nobody's"
2178:     );
2179: }
2180: 
2181: /// The optimiser forwards each spelling's folded constant (O100) where the
2182: /// body runs and rewrites nothing where it cannot; `tclsh` runs the body's
2183: /// `string cat` exactly where the analysis folds; and with the vendor
2184: /// runtime ([`TENANT_RUNTIME`]) the original and the optimised program
2185: /// print the same under every `tclsh` on `PATH`.
2186: fn the_vendor_runtime_prints_what_the_optimiser_forwards(packs: &tcl_spectcl::PackSet) {
2187:     let program = "proc p {} {\n    set a [tenant::label acme]\n    set b [tenant::tag acme]\n    set c [tenant label acme]\n    puts $a\n    puts $b\n    puts $c\n}\np\n";
2188:     let optimise = |dialect: &str| {
2189:         let registry = tcl_spectcl::install::registry_for_dialect_with_packs(dialect, packs);
2190:         let profile = resolve_environment(dialect).analyser_profile();
2191:         optimise_source_multipass(program, &registry, Some(profile), PASSES)
2192:     };
2193:     let (rewritten, rewrites) = optimise("tcl9.0");
2194:     assert_eq!(
2195:         rewritten.matches("puts tenant:acme").count(),
2196:         3,
2197:         "{rewritten}\n{rewrites:#?}"
2198:     );
2199:     assert!(
2200:         rewrites
2201:             .iter()
2202:             .any(|rewrite| rewrite.code.as_str() == "O100"),
2203:         "{rewrites:#?}"
2204:     );
2205:     let (unchanged, _) = optimise("tcl8.4");
2206:     assert!(
2207:         !unchanged.contains("puts tenant:acme"),
2208:         "the body cannot run under 8.4:\n{unchanged}"
2209:     );
2210:     for (series, tclsh) in releases_on_path() {
2211:         let body_runs = run_script(&tclsh, "puts [string cat tenant: acme]")
2212:             == Some((true, "tenant:acme\n".to_owned()));
2213:         assert_eq!(
2214:             body_runs,
2215:             matches!(series, "8.6" | "9.0" | "9.1"),
2216:             "tclsh{series} runs the body exactly where the analysis folds"
2217:         );
2218:         let (rewritten, rewrites) = optimise(&dialect_of(series));
2219:         for candidate in [program, rewritten.as_str()] {
2220:             assert_eq!(
2221:                 run_script(&tclsh, &format!("{TENANT_RUNTIME}{candidate}")),
2222:                 Some((true, "tenant:acme\ntenant:acme\ntenant:acme\n".to_owned())),
2223:                 "tclsh{series}:\n{candidate}\n{rewrites:#?}"
2224:             );
2225:         }
2226:     }
2227: }
2228: 
2229: /// A pack command that writes the variable it names, from that variable's
2230: /// incoming value: `acc::add VAR PIECE` appends `PIECE` to what `VAR`
2231: /// holds. Its `write` needs the variable's prior value as an input
2232: /// (`target 0 incoming`), which the analysis can read only where the
2233: /// lowering records a use of it: the word must carry the `VarWrite` role
2234: /// and the command the `READS_BEFORE_WRITE` trait. `acc::put` declares the
2235: /// same body without the trait, and `acc::store VAR VALUE` writes its
2236: /// argument without reading the variable.
2237: const ACC_PACK: &str = "speclib acc 2.2 {
2238:     command acc::add {
2239:         arity 2
2240:         arg 0 -role VarWrite
2241:         traits {READS_BEFORE_WRITE}
2242:         semantics {
2243:             stores -targets {0} -outcome write
2244:             result -semantic string
2245:         }
2246:         evaluate -implementation acc.add.v1 -host bounded_tcl {
2247:             inputs {target 0 incoming arg 1 exact}
2248:             body {prior piece} { set joined $prior$piece; write 0 $joined; fold $joined }
2249:         }
2250:     }
2251:     command acc::put {
2252:         arity 2
2253:         arg 0 -role VarWrite
2254:         semantics {
2255:             stores -targets {0} -outcome write
2256:             result -semantic string
2257:         }
2258:         evaluate -implementation acc.put.v1 -host bounded_tcl {
2259:             inputs {target 0 incoming arg 1 exact}
2260:             body {prior piece} { set joined $prior$piece; write 0 $joined; fold $joined }
2261:         }
2262:     }
2263:     command acc::store {
2264:         arity 2
2265:         arg 0 -role VarWrite
2266:         semantics {
2267:             stores -targets {0} -outcome write
2268:             result -semantic string
2269:         }
2270:         evaluate -implementation acc.store.v1 -host bounded_tcl {
2271:             inputs {arg 1 exact}
2272:             body {value} { write 0 $value; fold $value }
2273:         }
2274:     }
2275: }
2276: ";
2277: 
2278: /// A pack's `write` through an incoming target reaches the real driver in
2279: /// statement position: `acc::add s cd` over `s` = `ab` leaves `abcd` in the
2280: /// next version of `s`, run by the tclvm host from the loaded pack. In value
2281: /// position neither shape is a value: the read of `s` inside `[acc::add s
2282: /// ef]` sits on the synthetic call ahead of its host, as a nested `[incr
2283: /// x]`'s does, so the incoming target is not exact there; and `[acc::store u
2284: /// xy]`, which reads nothing, evaluates but writes storage the substitution
2285: /// has no definition for, so it is not substituted. Without
2286: /// `READS_BEFORE_WRITE` nothing records the variable's prior value at the
2287: /// call, so the incoming target is not exact and `acc::put` declines.
2288: #[test]
2289: fn a_pack_write_through_an_incoming_target_reaches_the_driver() {
2290:     let _published = PUBLISHED_PACKS
2291:         .lock()
2292:         .unwrap_or_else(std::sync::PoisonError::into_inner);
2293:     let packs = pack_workspace("acc", ACC_PACK);
2294:     let registry = tcl_spectcl::install::registry_for_dialect_with_packs("tcl9.0", &packs);
2295:     let source = "proc p {} {\n    set s ab\n    acc::add s cd\n    set r [acc::add s ef]\n    \
2296:                   set w [acc::store u xy]\n    return $s$r$w\n}\n\
2297:                   proc q {} {\n    set t ab\n    acc::put t cd\n    return $t\n}\n";
2298:     let unit = CompilationUnit::build_for_dialect(source, &registry, false, "tcl9.0");
2299:     assert_eq!(
2300:         value_at(&unit, "::p", "s", 2),
2301:         Some(text("abcd")),
2302:         "the statement's write lands on the next version of `s`"
2303:     );
2304:     for value in ["r", "w"] {
2305:         assert_eq!(
2306:             value_at(&unit, "::p", value, 1),
2307:             Some(LatticeValue::Overdefined),
2308:             "`{value}`: a writing call is never a value in value position"
2309:         );
2310:     }
2311:     assert_eq!(
2312:         answers_for(&unit, "::p", "acc::add"),
2313:         ["evaluated", "declined: not-exact"]
2314:     );
2315:     assert_eq!(
2316:         answers_for(&unit, "::p", "acc::store"),
2317:         ["not substituted: the outcome writes storage"]
2318:     );
2319:     assert_eq!(
2320:         value_at(&unit, "::q", "t", 2),
2321:         Some(LatticeValue::Overdefined),
2322:         "no use of `t` is recorded at the call without the trait"
2323:     );
2324:     assert_eq!(
2325:         answers_for(&unit, "::q", "acc::put"),
2326:         ["declined: not-exact"]
2327:     );
2328:     tcl_spectcl::hooks::publish(&tcl_spectcl::PackSet::default());
2329: }
2330: 
2331: /// The no-match preserve (#2051's program): a `regexp` that cannot
2332: /// match leaves its match variables as they were, so the store feeding one
2333: /// stays — no O109 deletes it, no W220 calls it unread, no W210 reports the
2334: /// read — and the original and optimised programs print `before` under
2335: /// every release. The same commands in a condition or a word keep the
2336: /// stores their targets may preserve: `tcl opt` had deleted `set v before`
2337: /// from both, and the optimised programs failed with `can't read "v": no
2338: /// such variable`.
2339: #[test]
2340: fn a_no_match_keeps_the_store_it_preserves() {
2341:     use tcl_compiler::analyser::Analyser;
2342:     let programs = [
2343:         (
2344:             "proc p {} {\n    set a before\n    regexp {(x)(y)} zz a b\n    puts $a\n}\np\n",
2345:             "a",
2346:             "before\n",
2347:         ),
2348:         (
2349:             "proc q {s} {\n    set v before\n    if {[regexp {(x)} $s -> v]} {\n        \
2350:              puts matched\n    }\n    puts $v\n}\nq abc\n",
2351:             "v",
2352:             "before\n",
2353:         ),
2354:         (
2355:             "proc r {} {\n    set v before\n    puts [regexp {x} y v]\n    puts $v\n}\nr\n",
2356:             "v",
2357:             "0\nbefore\n",
2358:         ),
2359:     ];
2360:     for (source, kept, printed) in programs {
2361:         let named = format!("'{kept}'");
2362:         for dialect in DIALECTS {
2363:             let rewrites = rewrites_of(source, dialect);
2364:             assert!(
2365:                 !rewrites
2366:                     .iter()
2367:                     .any(|rewrite| rewrite.code == DiagCode::O109),
2368:                 "{dialect}: {source}{rewrites:#?}"
2369:             );
2370:             let reported: Vec<(DiagCode, String)> = Analyser::new()
2371:                 .analyse(source, dialect)
2372:                 .diagnostics
2373:                 .into_iter()
2374:                 .filter(|d| matches!(d.code, DiagCode::W210 | DiagCode::W220))
2375:                 .map(|d| (d.code, d.message))
2376:                 .collect();
2377:             assert!(
2378:                 !reported.iter().any(|(_, message)| message.contains(&named)),
2379:                 "{dialect}: {source}{reported:?}"
2380:             );
2381:         }
2382:         prints_under_every_release(source, printed);
2383:     }
2384: }
2385: 
2386: /// A pack command's declared preserve is a preserved definition like a
2387: /// builtin's: `keep::miss VAR PIECE` declares `write_or_preserve`
2388: /// on its target and its body preserves it, so the definition holds the
2389: /// version before the call — the undefined root in `p`, the `set` in `q` —
2390: /// which is what W210 reads. The pack spells no trait: the outcome alone
2391: /// makes the target a conditional write.
2392: #[test]
2393: fn a_pack_declared_preserve_holds_the_prior_version() {
2394:     const KEEP_PACK: &str = "speclib keep 2.2 {
2395:     command keep::miss {
2396:         arity 2
2397:         arg 0 -role VarWrite
2398:         semantics {
2399:             stores -targets {0} -outcome write_or_preserve
2400:             result -semantic int
2401:         }
2402:         evaluate -implementation keep.miss.v1 -host bounded_tcl {
2403:             inputs {arg 1 exact}
2404:             body {piece} { preserve 0; fold 0 }
2405:         }
2406:     }
2407: }
2408: ";
2409:     let _published = PUBLISHED_PACKS
2410:         .lock()
2411:         .unwrap_or_else(std::sync::PoisonError::into_inner);
2412:     let packs = pack_workspace("keep", KEEP_PACK);
2413:     let registry = tcl_spectcl::install::registry_for_dialect_with_packs("tcl9.0", &packs);
2414:     let source = "proc p {} {\n    keep::miss v x\n    return $v\n}\n\
2415:                   proc q {} {\n    set v before\n    keep::miss v x\n    return $v\n}\n";
2416:     let unit = CompilationUnit::build_for_dialect(source, &registry, false, "tcl9.0");
2417:     for (proc, prior) in [("::p", 0), ("::q", 1)] {
2418:         let function = unit
2419:             .procedures
2420:             .get(&fixture_id(&unit.procedures, proc))
2421:             .expect("the procedure");
2422:         let symbol = function.ssa.var_symbol("v").expect("the variable");
2423:         assert_eq!(
2424:             function.sccp.preserved.get(&(symbol, prior + 1)),
2425:             Some(&prior),
2426:             "{proc}: {:?}",
2427:             function.sccp.preserved
2428:         );
2429:         assert_eq!(answers_for(&unit, proc, "keep::miss"), ["evaluated"]);
2430:     }
2431:     tcl_spectcl::hooks::publish(&tcl_spectcl::PackSet::default());
2432: }
2433: 
2434: /// A word that raises ends the invocation before the command runs, whichever
2435: /// operands its route reads: `review::constant [error boom]` declares
2436: /// `inputs {}`, yet Tcl substitutes the word first and the command never
2437: /// runs, so `catch` is not proven to complete normally — `tcl opt` had
2438: /// rewritten `puts $code` and `puts $message` to `puts 0` and
2439: /// `puts answer`, where every tclsh prints `1` and `boom`. A call whose
2440: /// words complete still folds.
2441: #[test]
2442: fn a_raising_argument_ends_the_invocation_before_its_implementation_runs() {
2443:     const CONSTANT_PACK: &str = "speclib review 2.2 {
2444:     command review::constant {
2445:         arity 1
2446:         semantics {
2447:             effects {no_store_writes no_external_io}
2448:             result -semantic string
2449:         }
2450:         evaluate -implementation review.constant.v1 -host bounded_tcl {
2451:             inputs {}
2452:             depends {tcl_profile implementation_identity}
2453:             body {} {fold answer}
2454:         }
2455:     }
2456: }
2457: ";
2458:     let _published = PUBLISHED_PACKS
2459:         .lock()
2460:         .unwrap_or_else(std::sync::PoisonError::into_inner);
2461:     let packs = pack_workspace("review", CONSTANT_PACK);
2462:     let dialect = "tcl8.6";
2463:     let registry = tcl_spectcl::install::registry_for_dialect_with_packs(dialect, &packs);
2464:     let profile = resolve_environment(dialect).analyser_profile();
2465:     let source = "set code [catch {review::constant [error boom]} message]\nputs $code\n\
2466:                   puts $message\nproc p {} {\n    set v start\n    \
2467:                   catch {set v [review::constant [error boom]]} m\n    return \"$v $m\"\n}\n\
2468:                   proc q {} {\n    set w [review::constant abc]\n    return $w\n}\n";
2469:     let (rewritten, rewrites) = optimise_source_multipass(source, &registry, Some(profile), PASSES);
2470:     for kept in ["puts $code", "puts $message", "return \"$v $m\""] {
2471:         assert!(
2472:             rewritten.contains(kept),
2473:             "{kept}:\n{rewritten}\n{rewrites:#?}"
2474:         );
2475:     }
2476:     assert!(rewritten.contains("return answer"), "{rewritten}");
2477:     tcl_spectcl::hooks::publish(&tcl_spectcl::PackSet::default());
2478: }
2479: 
2480: /// A declared route answers only a call its resolved arity accepts:
2481: /// `review::label acme extra` against `arity 1` raises `wrong # args` in
2482: /// every tclsh, so neither the explicit implementation nor the one derived
2483: /// from the reference body runs, and the catch facts stay unproven, where
2484: /// `tcl opt` had rewritten `puts $code` to `puts 0`; an expression route
2485: /// declines the same way. A call the arity accepts still folds.
2486: #[test]
2487: fn a_declared_route_refuses_a_call_outside_its_arity() {
2488:     const EXPLICIT: &str = "speclib review 2.2 {
2489:     command review::label {
2490:         arity 1
2491:         semantics {
2492:             effects {no_store_writes no_external_io}
2493:             result -semantic string
2494:         }
2495:         evaluate -implementation review.label.v1 -host bounded_tcl {
2496:             inputs {arg 0 exact}
2497:             depends {tcl_profile implementation_identity}
2498:             body {name} {fold $name}
2499:         }
2500:     }
2501: }
2502: ";
2503:     const DERIVED: &str = "speclib review 2.2 {
2504:     command review::label {
2505:         arity 1
2506:         runtime_backing tcl-body {-pack-text {proc review::label {name} {return $name}} -evaluate}
2507:     }
2508: }
2509: ";
2510:     const EXPRESSION: &str = "speclib review 2.2 {
2511:     command review::label {
2512:         arity 1
2513:         evaluate -expression tcl.expr
2514:     }
2515: }
2516: ";
2517:     let _published = PUBLISHED_PACKS
2518:         .lock()
2519:         .unwrap_or_else(std::sync::PoisonError::into_inner);
2520:     let dialect = "tcl8.6";
2521:     for (pack, good, folded) in [
2522:         (EXPLICIT, "review::label acme", text("acme")),
2523:         (DERIVED, "review::label acme", text("acme")),
2524:         (
2525:             EXPRESSION,
2526:             "review::label {1 + 2}",
2527:             LatticeValue::Const(ConstValue::Int(3)),
2528:         ),
2529:     ] {
2530:         // The derived pack's one notice is the pack-text advisory.
2531:         let packs = pack_workspace_noting("review", pack);
2532:         let registry = tcl_spectcl::install::registry_for_dialect_with_packs(dialect, &packs);
2533:         let source = format!(
2534:             "proc p {{}} {{\n    set code [catch {{review::label acme extra}} message]\n    \
2535:              set ok [{good}]\n    return $code$message$ok\n}}\n"
2536:         );
2537:         let unit = CompilationUnit::build_for_dialect(&source, &registry, false, dialect);
2538:         assert!(
2539:             !matches!(
2540:                 value_at(&unit, "::p", "code", 1),
2541:                 Some(LatticeValue::Const(_))
2542:             ),
2543:             "{pack}: {:?}",
2544:             value_at(&unit, "::p", "code", 1)
2545:         );
2546:         assert_eq!(value_at(&unit, "::p", "ok", 1), Some(folded), "{pack}");
2547:         let profile = resolve_environment(dialect).analyser_profile();
2548:         let (rewritten, _) = optimise_source_multipass(&source, &registry, Some(profile), PASSES);
2549:         assert!(
2550:             rewritten.contains("return $code$message"),
2551:             "{pack}: {rewritten}"
2552:         );
2553:     }
2554:     tcl_spectcl::hooks::publish(&tcl_spectcl::PackSet::default());
2555: }
2556: 
2557: /// A declared implementation's `binding` dependencies are checked at the
2558: /// call: `review::length` declares that its body rests on `string`, so in a
2559: /// module that renames `string` and defines its own — tclsh prints
2560: /// `rebound` — the body's builtin `string length` is not the command the
2561: /// module calls, and the call declines where `tcl opt` had rewritten
2562: /// `puts $x` to `puts 3`. The same call in a module that keeps the builtin
2563: /// still folds.
2564: #[test]
2565: fn a_declared_binding_the_module_rebinds_declines_the_call() {
2566:     const PACK: &str = "speclib review 2.2 {
2567:     command review::length {
2568:         arity 1
2569:         semantics {
2570:             effects {no_store_writes no_external_io}
2571:             result -semantic int
2572:         }
2573:         evaluate -implementation review.length.v1 -host bounded_tcl {
2574:             inputs {arg 0 exact}
2575:             depends {tcl_profile implementation_identity binding string}
2576:             body {value} {fold [string length $value]}
2577:         }
2578:     }
2579: }
2580: ";
2581:     let _published = PUBLISHED_PACKS
2582:         .lock()
2583:         .unwrap_or_else(std::sync::PoisonError::into_inner);
2584:     let dialect = "tcl8.6";
2585:     let packs = pack_workspace("review", PACK);
2586:     let registry = tcl_spectcl::install::registry_for_dialect_with_packs(dialect, &packs);
2587:     let profile = resolve_environment(dialect).analyser_profile();
2588:     let call = "set x [review::length abc]\nputs $x\n";
2589:     let rebound =
2590:         format!("rename string saved_string\nproc string args {{return rebound}}\n{call}");
2591:     let (rewritten, _) = optimise_source_multipass(&rebound, &registry, Some(profile), PASSES);
2592:     assert!(rewritten.contains("puts $x"), "{rewritten}");
2593:     assert!(!rewritten.contains("puts 3"), "{rewritten}");
2594:     let (kept, _) = optimise_source_multipass(call, &registry, Some(profile), PASSES);
2595:     assert!(kept.contains("puts 3"), "{kept}");
2596:     tcl_spectcl::hooks::publish(&tcl_spectcl::PackSet::default());
2597: }
2598: 
2599: /// A pack's `evaluate -direct ID` runs the registry evaluator the id names
2600: /// when it is one a pack may name: `review::list a b` on `ListOfArgs` is
2601: /// `a b` in the shared lattice, so `if {$x eq {a b}}` decides (I230), and
2602: /// the answer is `evaluated` on the direct route. A subcommand scope reads
2603: /// its arguments after the subcommand word: `review pair a b` is `a b` too.
2604: #[test]
2605: fn a_pack_direct_route_runs_the_evaluator_it_names() {
2606:     use tcl_compiler::analyser::Analyser;
2607:     const DIRECT_PACK: &str = "speclib review 2.2 {
2608:     command review::list {
2609:         arity 0..
2610:         semantics {
2611:             effects {no_store_writes no_external_io}
2612:             result -semantic list
2613:         }
2614:         evaluate -direct ListOfArgs
2615:     }
2616:     command review {
2617:         arity 1..
2618:         subcommand pair {
2619:             arity 2
2620:             evaluate -direct ListOfArgs
2621:         }
2622:     }
2623: }
2624: ";
2625:     let _published = PUBLISHED_PACKS
2626:         .lock()
2627:         .unwrap_or_else(std::sync::PoisonError::into_inner);
2628:     let packs = pack_workspace("review", DIRECT_PACK);
2629:     let dialect = "tcl8.6";
2630:     let registry = tcl_spectcl::install::registry_for_dialect_with_packs(dialect, &packs);
2631:     let source = "proc p {} {\n    set x [review::list a b]\n    set y [review pair a b]\n    \
2632:                   if {$x eq {a b}} {puts selected} else {puts unreachable}\n    return $x$y\n}\n";
2633:     let unit = CompilationUnit::build_for_dialect(source, &registry, false, dialect);
2634:     assert_eq!(value_at(&unit, "::p", "x", 1), Some(text("a b")));
2635:     assert_eq!(value_at(&unit, "::p", "y", 1), Some(text("a b")));
2636:     assert_eq!(
2637:         answers_for(&unit, "::p", "review::list"),
2638:         ["evaluated"],
2639:         "the direct route runs"
2640:     );
2641:     let decided = Analyser::new()
2642:         .with_pack_overlay(packs.key)
2643:         .analyse(source, dialect)
2644:         .diagnostics
2645:         .into_iter()
2646:         .any(|d| d.code == DiagCode::I230);
2647:     assert!(decided, "the condition decides");
2648:     tcl_spectcl::hooks::publish(&tcl_spectcl::PackSet::default());
2649: }
2650: 
2651: /// Workspace commands whose one target may keep its prior value, declared
2652: /// by outcome alone: no `READS_BEFORE_WRITE`, no write-class trait.
2653: const MAY_PRESERVE_PACK: &str = "speclib kv 2.2 {
2654:     command kv::maybe {
2655:         arity 2
2656:         arg 1 -role VarWrite
2657:         semantics {
2658:             stores -targets {1} -outcome may_write
2659:         }
2660:         evaluate none
2661:     }
2662:     command kv::wp {
2663:         arity 2
2664:         arg 1 -role VarWrite
2665:         semantics {
2666:             stores -targets {1} -outcome write_or_preserve
2667:         }
2668:         evaluate none
2669:     }
2670:     command kv::split3 {
2671:         arity 4
2672:         arg_role_resolver {words ctx} { role 1 VarWrite; role 2 VarWrite; role 3 VarWrite }
2673:         arg_role_resolver_roles {VarWrite}
2674:         semantics {
2675:             stores -targets {1 2 3} -outcome write_or_preserve
2676:             result -semantic int
2677:         }
2678:         evaluate -implementation kv.split3.v1 -host bounded_tcl {
2679:             inputs {arg 0 exact}
2680:             body {s} {
2681:                 set parts [split $s :]
2682:                 if {[llength $parts] != 3} {
2683:                     preserve 1; preserve 2; preserve 3
2684:                     fold 0
2685:                     return
2686:                 }
2687:                 lassign $parts a b c
2688:                 write 1 $a; write 2 $b; write 3 $c
2689:                 fold 3
2690:             }
2691:         }
2692:     }
2693: }
2694: ";
2695: 
2696: /// Whether the analysis of `source` reports W220 on `name`, and whether
2697: /// the optimiser's single pass removes a store, under `dialect` with the
2698: /// packs `key` names installed in `registry`.
2699: fn dead_store_findings(
2700:     registry: &tcl_registry::CommandRegistry,
2701:     key: u64,
2702:     source: &str,
2703:     dialect: &str,
2704:     name: &str,
2705: ) -> (bool, bool) {
2706:     use tcl_compiler::analyser::Analyser;
2707:     let named = format!("'{name}'");
2708:     let reported = Analyser::new()
2709:         .with_pack_overlay(key)
2710:         .analyse(source, dialect)
2711:         .diagnostics
2712:         .into_iter()
2713:         .any(|d| d.code == DiagCode::W220 && d.message.contains(&named));
2714:     let profile = resolve_environment(dialect).analyser_profile();
2715:     let removed = optimise_with_dialect(source, registry, Some(profile))
2716:         .iter()
2717:         .any(|rewrite| matches!(rewrite.code, DiagCode::O109 | DiagCode::O126));
2718:     (reported, removed)
2719: }
2720: 
2721: /// A store a later call only may overwrite is live: a pack target declared
2722: /// `may_write` or `write_or_preserve` may keep the value the store gave it,
2723: /// so the store ahead of the call — as a statement, in a condition, or in a
2724: /// word — draws no W220 and no O109, as the store ahead of a `regexp` does,
2725: /// whether or not the pack spells `READS_BEFORE_WRITE`. The shipped
2726: /// `append_to_collection` (`may_write` in `specs/sdc_base.tclspec`) is the
2727: /// first program: O109 had deleted `set c {}`, and the procedure then
2728: /// returned an unset variable whenever the call kept the collection as it
2729: /// was.
2730: #[test]
2731: fn a_store_a_declared_outcome_may_preserve_is_live() {
2732:     let shipped = tcl_spectcl::bundled::load_from(
2733:         &std::path::PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("../../specs"),
2734:     );
2735:     let eda = "synopsys-eda-tcl";
2736:     let registry = tcl_spectcl::bundled::registry_for_dialect_from(eda, &shipped);
2737:     let source =
2738:         "proc p {objs} {\n    set c {}\n    append_to_collection c $objs\n    return $c\n}\n";
2739:     assert_eq!(
2740:         dead_store_findings(&registry, shipped.key, source, eda, "c"),
2741:         (false, false),
2742:         "{source}"
2743:     );
2744: 
2745:     let _published = PUBLISHED_PACKS
2746:         .lock()
2747:         .unwrap_or_else(std::sync::PoisonError::into_inner);
2748:     let packs = pack_workspace("kv", MAY_PRESERVE_PACK);
2749:     let dialect = "tcl9.0";
2750:     let registry = tcl_spectcl::install::registry_for_dialect_with_packs(dialect, &packs);
2751:     for command in ["kv::maybe", "kv::wp"] {
2752:         for call in [
2753:             format!("    {command} $s v\n"),
2754:             format!("    if {{[{command} $s v]}} {{ puts hit }}\n"),
2755:             format!("    set r [{command} $s v]\n    puts $r\n"),
2756:         ] {
2757:             let source = format!("proc p {{s}} {{\n    set v old\n{call}    return $v\n}}\n");
2758:             assert_eq!(
2759:                 dead_store_findings(&registry, packs.key, &source, dialect, "v"),
2760:                 (false, false),
2761:                 "{source}"
2762:             );
2763:         }
2764:     }
2765: 
2766:     // The no-match path's `preserve` keeps the prior value: `x` holds `old`
2767:     // after the call, and the store stays.
2768:     let source = "proc p {} {\n    set x old\n    kv::split3 nocolons x y z\n    return $x\n}\n";
2769:     let unit = CompilationUnit::build_for_dialect(source, &registry, false, dialect);
2770:     assert_eq!(value_at(&unit, "::p", "x", 2), Some(text("old")));
2771:     assert_eq!(answers_for(&unit, "::p", "kv::split3"), ["evaluated"]);
2772:     assert_eq!(
2773:         dead_store_findings(&registry, packs.key, source, dialect, "x"),
2774:         (false, false)
2775:     );
2776:     tcl_spectcl::hooks::publish(&tcl_spectcl::PackSet::default());
2777: }
2778: 
2779: /// A materialised child carries the span of the factory call that produced
2780: /// it (#2143): `Configure port 8080 {the port}` materialises `proc
2781: /// port {x} {return 8080}`, and the child's W214 for `x` anchors at that
2782: /// call — line 4 — where, with no span of its own, it anchored at 1:1. The
2783: /// factory's template is read through its template-word plan, and `port
2784: /// ignored` is `8080` under tclsh 8.4 to 9.1 before and after `tcl opt`.
2785: #[test]
2786: fn a_materialised_child_carries_its_factory_call_span() {
2787:     use tcl_compiler::analyser::Analyser;
2788:     let source = "proc Configure {name default description} {\n    \
2789:                   proc $name {x} [subst -nocommands {return $default}]\n}\n\
2790:                   Configure port 8080 {the port}\n";
2791:     for dialect in ["tcl8.4", "tcl8.6", "tcl9.0", "tcl"] {
2792:         let reported = Analyser::new().analyse(source, dialect).diagnostics;
2793:         let lines: Vec<usize> = reported
2794:             .iter()
2795:             .filter(|d| d.code == DiagCode::W214 && d.message.contains("'::port'"))
2796:             .map(|d| source[..d.span.start() as usize].matches('\n').count() + 1)
2797:             .collect();
2798:         assert_eq!(lines, [4], "{dialect}: {reported:?}");
2799:     }
2800:     prints_under_every_release(&format!("{source}puts [port ignored]\n"), "8080\n");
2801: }
2802: 
2803: /// A computed template that runs commands can read any variable:
2804: /// `subst -novariables $t` over `[set x]` reads `x`, so the store
2805: /// before it stays — the original and optimised programs print `1` under
2806: /// tclsh 8.4 to 9.1, where dropping `set x 1` as unused made them raise.
2807: #[test]
2808: fn a_computed_template_that_runs_commands_keeps_the_stores_it_reads() {
2809:     let source = "proc f {t} {\n    set x 1\n    return [subst -novariables $t]\n}\n\
2810:                   puts [f {[set x]}]\n";
2811:     for dialect in ["tcl8.4", "tcl8.6", "tcl9.0", "tcl"] {
2812:         let (rewritten, _) = optimised(source, dialect);
2813:         assert!(rewritten.contains("set x 1"), "{dialect}: {rewritten}");
2814:     }
2815:     prints_under_every_release(source, "1\n");
2816: }
2817: 
2818: // The interface page's exit witnesses (its § *Test
2819: // anchors*, "fixed witnesses to add"), each read off the shared lattice
2820: // through the memoised unit and checked against `tcl opt`'s rewritten
2821: // program, printed under every release on `PATH`.
2822: 
2823: /// The no-match preserve witness: a `regexp` that cannot match leaves its
2824: /// match variables exactly as they were — the lattice holds `a`'s prior
2825: /// value at the call's own definition (a `Preserve`, not a manufactured
2826: /// one), and `zz` never matches `(x)(y)`, so both the original and the
2827: /// `tcl opt`-rewritten program print `before` on every release.
2828: #[test]
2829: fn the_no_match_preserve_witness() {
2830:     let source = "proc p {} {\n    set a before\n    regexp {(x)(y)} zz a b\n    puts $a\n}\np\n";
2831:     for dialect in DIALECTS {
2832:         assert_eq!(
2833:             last_value(source, dialect, "::p", "a"),
2834:             text("before"),
2835:             "{dialect}: the no-match leaves $a at its prior value"
2836:         );
2837:     }
2838:     prints_under_every_release(source, "before\n");
2839: }
2840: 
2841: /// The partial-scan witness: `scan "12" "%d %d" a b` converts one field
2842: /// from the two-integer format before the input is exhausted — `a` takes
2843: /// the converted `12`, `b` is left exactly as it was (a `Preserve`, the
2844: /// same outcome kind the no-match witness reads) — and both agree with
2845: /// `tclsh` before and after `tcl opt`. Run as its own statement, not
2846: /// nested in a `[…]` value position: a nested invocation's stores answer
2847: /// under the effect-free policy `fold_cmd_subst_routes` documents, which
2848: /// has no definition for them to land on, so `a` and `b` would be
2849: /// `Overdefined` for a reason unrelated to what this witness proves.
2850: #[test]
2851: fn the_partial_scan_witness() {
2852:     let source = "proc p {} {\n    set a before\n    set b before\n    \
2853:                   scan \"12\" \"%d %d\" a b\n    puts \"$a $b\"\n}\np\n";
2854:     for dialect in DIALECTS {
2855:         assert_eq!(
2856:             last_value(source, dialect, "::p", "a"),
2857:             LatticeValue::Const(ConstValue::Int(12)),
2858:             "{dialect}: the converted field takes the scanned value, typed as %d built it"
2859:         );
2860:         assert_eq!(
2861:             last_value(source, dialect, "::p", "b"),
2862:             text("before"),
2863:             "{dialect}: the field past the exhausted input is preserved"
2864:         );
2865:     }
2866:     prints_under_every_release(source, "12 before\n");
2867: }
2868: 
2869: /// The conversion-count witness: `%n` is a
2870: /// conversion for `scan`'s underflow, as C's `nconversions` counts it, so
2871: /// `scan "" %n%d n a` is 1 and writes `n` the characters consumed, 0, on
2872: /// every release. The route had answered the underflow's -1 and preserved
2873: /// `n`, so `tcl opt` rewrote `puts $n` to `puts 5` and W210 reported the
2874: /// read of an `n` the call binds.
2875: #[test]
2876: fn the_percent_n_count_witness() {
2877:     use tcl_compiler::analyser::Analyser;
2878:     let kept = "proc p {} {\n    set n 5\n    scan \"\" %n%d n a\n    puts $n\n}\np\n";
2879:     let bound = "proc q {} {\n    scan \"\" %n%d n a\n    puts $n\n}\nq\n";
2880:     for dialect in DIALECTS {
2881:         assert_eq!(
2882:             last_value(kept, dialect, "::p", "n"),
2883:             LatticeValue::Const(ConstValue::Int(0)),
2884:             "{dialect}: `%n` writes the characters consumed"
2885:         );
2886:         let (rewritten, rewrites) = optimised(kept, dialect);
2887:         assert!(
2888:             !rewritten.contains("puts 5"),
2889:             "{dialect}: the scan wrote `n`\n{rewritten}\n{rewrites:#?}"
2890:         );
2891:         for source in [kept, bound] {
2892:             let reported: Vec<String> = Analyser::new()
2893:                 .analyse(source, dialect)
2894:                 .diagnostics
2895:                 .into_iter()
2896:                 .filter(|d| d.code == DiagCode::W210 && d.message.contains("'n'"))
2897:                 .map(|d| d.message)
2898:                 .collect();
2899:             assert!(reported.is_empty(), "{dialect}: {source}{reported:?}");
2900:         }
2901:     }
2902:     prints_under_every_release(kept, "0\n");
2903:     prints_under_every_release(bound, "0\n");
2904: }
2905: 
2906: /// `const` writes only an absent place: the first `const c 5`
2907: /// writes 5 into the absent `c` and the second keeps it — tclsh 9.0 and
2908: /// 9.1 print 5 twice — so the lattice holds 5 after the first and no value
2909: /// after the second, and `tcl opt` never prints 7. `set x 1; const x 2`
2910: /// raises on both releases, and the route declines it.
2911: #[test]
2912: fn const_writes_only_an_absent_place() {
2913:     let source = "proc p {} {\n    const c 5\n    puts $c\n    const c 7\n    puts $c\n}\np\n";
2914:     let raises = "proc q {} {\n    set x 1\n    const x 2\n}\nq\n";
2915:     for dialect in ["tcl9.0", "tcl9.1"] {
2916:         let unit = unit_of(source, dialect);
2917:         assert_eq!(
2918:             value_at(&unit, "::p", "c", 1).and_then(lattice_text),
2919:             Some("5".to_owned()),
2920:             "{dialect}: the absent place takes the value"
2921:         );
2922:         assert_eq!(
2923:             value_at(&unit, "::p", "c", 2).and_then(lattice_text),
2924:             None,
2925:             "{dialect}: an existing constant keeps a value the route does not model"
2926:         );
2927:         let (rewritten, rewrites) = optimised(source, dialect);
2928:         assert!(
2929:             !rewritten.contains("puts 7"),
2930:             "{dialect}: {rewritten}\n{rewrites:#?}"
2931:         );
2932:         assert!(
2933:             answers_for(&unit_of(raises, dialect), "::q", "const")
2934:                 .iter()
2935:                 .all(|answer| answer.starts_with("declined")),
2936:             "{dialect}: an existing variable declines"
2937:         );
2938:     }
2939:     for (series, tclsh) in releases_on_path() {
2940:         if !series.starts_with('9') {
2941:             continue;
2942:         }
2943:         let (rewritten, _) = optimised(source, &dialect_of(series));
2944:         for program in [source, rewritten.as_str()] {
2945:             assert_eq!(
2946:                 run_script(&tclsh, program),
2947:                 Some((true, "5\n5\n".to_owned())),
2948:                 "tclsh{series}:\n{program}"
2949:             );
2950:         }
2951:         assert_eq!(
2952:             run_script(&tclsh, raises).map(|(ok, _)| ok),
2953:             Some(false),
2954:             "tclsh{series}: const over an existing variable raises"
2955:         );
2956:     }
2957: }
2958: 
2959: /// The repeated-target witness: a call whose declared targets name the
2960: /// same place twice composes in execution order, so the last position's
2961: /// value wins. `lassign`'s repeated-target form (the interface page's own
2962: /// "`lassign … a a`") is 8.5+ and raises under 8.4, so this reads the same
2963: /// fact through `regexp`'s match-variable list, which every release
2964: /// shares: `(a)(b)` against `ab` captures `a` into `x` and then `b` into
2965: /// `x` again, and `x` ends the call as `b`.
2966: #[test]
2967: fn the_repeated_target_witness() {
2968:     let source = "proc p {} {\n    regexp {(a)(b)} ab -> x x\n    puts $x\n}\np\n";
2969:     for dialect in DIALECTS {
2970:         assert_eq!(
2971:             last_value(source, dialect, "::p", "x"),
2972:             text("b"),
2973:             "{dialect}: the second position's capture is the one that survives"
2974:         );
2975:     }
2976:     prints_under_every_release(source, "b\n");
2977: }
2978: 
2979: /// The existence fact `var`'s last version holds in `proc`: the fact the
2980: /// solver established where the version was defined.
2981: fn last_existence(unit: &CompilationUnit, proc: &str, var: &str) -> Option<Existence> {
2982:     let function = unit
2983:         .procedures
2984:         .get(&fixture_id(&unit.procedures, proc))
2985:         .expect("the procedure");
2986:     let symbol = function.ssa.var_symbol(var).expect("the variable");
2987:     function
2988:         .sccp
2989:         .existence
2990:         .iter()
2991:         .filter(|((sym, _), _)| *sym == symbol)
2992:         .max_by_key(|((_, version), _)| *version)
2993:         .map(|(_, fact)| *fact)
2994: }
2995: 
2996: /// What `tclsh` reports of `places` after `body` runs in a procedure:
2997: /// `None` when the body raises, else each place's `info exists` and
2998: /// `array exists`.
2999: fn oracle_existence(tclsh: &str, body: &str, places: &[&str]) -> Option<Vec<(bool, bool)>> {
3000:     let mut probes = String::new();
3001:     for place in places {
3002:         probes.push_str(" [info exists ");
3003:         probes.push_str(place);
3004:         probes.push_str("] [array exists ");
3005:         probes.push_str(place);
3006:         probes.push(']');
3007:     }
3008:     let script = format!(
3009:         "proc p {{}} {{\n{body}\nreturn [list{probes}]\n}}\n\
3010:          if {{[catch p answer]}} {{puts -nonewline error}} else {{puts -nonewline $answer}}\n"
3011:     );
3012:     let (ok, output) = run_script(tclsh, &script)?;
3013:     assert!(ok, "{tclsh} ran the probe for {body:?}");
3014:     if output == "error" {
3015:         return None;
3016:     }
3017:     let bits: Vec<bool> = output.split_whitespace().map(|bit| bit == "1").collect();
3018:     Some(bits.chunks(2).map(|pair| (pair[0], pair[1])).collect())
3019: }
3020: 
3021: /// Whether `fact` agrees with what `tclsh` reports of a place: a proven
3022: /// binding exists, as an array exactly when it is one, and a proven
3023: /// absence does not; a fact that proves neither claims nothing.
3024: fn existence_agrees(fact: Option<Existence>, (exists, array): (bool, bool)) -> bool {
3025:     match fact {
3026:         Some(Existence::Unbound) => !exists && !array,
3027:         Some(Existence::Bound(BindingKind::Scalar)) => exists && !array,
3028:         Some(Existence::Bound(BindingKind::Array)) => exists && array,
3029:         Some(Existence::Bound(BindingKind::Either)) => exists,
3030:         Some(Existence::MayBound | Existence::Pending) | None => true,
3031:     }
3032: }
3033: 
3034: const SCALAR: Option<Existence> = Some(Existence::Bound(BindingKind::Scalar));
3035: const ARRAY: Option<Existence> = Some(Existence::Bound(BindingKind::Array));
3036: const UNBOUND: Option<Existence> = Some(Existence::Unbound);
3037: 
3038: /// The dialects the release table is analysed under: each release, and
3039: /// the `tcl` profile that spans them all.
3040: const RELEASE_DIALECTS: [&str; 6] = ["tcl8.4", "tcl8.5", "tcl8.6", "tcl9.0", "tcl9.1", "tcl"];
3041: 
3042: /// The release table's lines every release reads alike: each place's fact
3043: /// after the line, under every dialect, and against every `tclsh` on
3044: /// `PATH` wherever the line completes.
3045: fn the_lines_every_release_reads_alike(releases: &[(&'static str, String)]) {
3046:     type Row = (&'static str, &'static [(&'static str, Option<Existence>)]);
3047:     let alike: [Row; 9] = [
3048:         ("append s foo", &[("s", SCALAR)]),
3049:         ("lappend l foo", &[("l", SCALAR)]),
3050:         ("regexp {(x)(y)} zz a b", &[("a", UNBOUND), ("b", UNBOUND)]),
3051:         (
3052:             "scan {12 nope} {%d %d} a b",
3053:             &[("a", SCALAR), ("b", UNBOUND)],
3054:         ),
3055:         ("unset nosuch", &[("nosuch", UNBOUND)]),
3056:         ("unset -nocomplain nosuch", &[("nosuch", UNBOUND)]),
3057:         (
3058:             "set arr(k) 1; unset arr(k)",
3059:             &[("arr", ARRAY), ("arr(k)", UNBOUND)],
3060:         ),
3061:         ("set x 1; unset x; set x 2", &[("x", SCALAR)]),
3062:         ("foreach x {} {}", &[("x", UNBOUND)]),
3063:     ];
3064:     for (body, places) in alike {
3065:         let source = format!("proc p {{}} {{{body}}}\n");
3066:         for dialect in RELEASE_DIALECTS {
3067:             let unit = unit_of(&source, dialect);
3068:             for &(place, expected) in places {
3069:                 assert_eq!(
3070:                     last_existence(&unit, "::p", place),
3071:                     expected,
3072:                     "{dialect}: `{place}` after `{body}`"
3073:                 );
3074:             }
3075:         }
3076:         let names: Vec<&str> = places.iter().map(|(place, _)| *place).collect();
3077:         for (series, tclsh) in releases {
3078:             let Some(answers) = oracle_existence(tclsh, body, &names) else {
3079:                 continue;
3080:             };
3081:             let unit = unit_of(&source, &dialect_of(series));
3082:             for (&(place, _), answer) in places.iter().zip(answers) {
3083:                 assert!(
3084:                     existence_agrees(last_existence(&unit, "::p", place), answer),
3085:                     "tclsh{series}: `{place}` after `{body}` is {answer:?}"
3086:                 );
3087:             }
3088:         }
3089:     }
3090:     for dialect in RELEASE_DIALECTS {
3091:         assert_eq!(
3092:             last_value("proc p {} {append s foo}\n", dialect, "::p", "s"),
3093:             text("foo"),
3094:             "{dialect}: `append` creates its cell in every release"
3095:         );
3096:         assert_eq!(
3097:             last_value("proc p {} {lappend l foo}\n", dialect, "::p", "l"),
3098:             text("foo"),
3099:             "{dialect}: `lappend` creates its cell in every release"
3100:         );
3101:     }
3102: }
3103: 
3104: /// The release table's `incr` lines: the cell is created from 8.5, with
3105: /// the amount as its value; under 8.4, where `tclsh8.4` raises, the route
3106: /// answers the error after no store, and under the spanning profile, which
3107: /// cannot say which release runs, the value declines as an unbound place.
3108: fn the_increment_split(releases: &[(&'static str, String)]) {
3109:     let increments: [(&str, &str, i64); 3] = [
3110:         ("incr fresh", "fresh", 1),
3111:         ("incr fresh 2", "fresh", 2),
3112:         ("incr arr(k)", "arr(k)", 1),
3113:     ];
3114:     for (body, place, amount) in increments {
3115:         let source = format!("proc p {{}} {{{body}}}\n");
3116:         for dialect in ["tcl8.5", "tcl8.6", "tcl9.0", "tcl9.1"] {
3117:             let unit = unit_of(&source, dialect);
3118:             assert_eq!(
3119:                 last_value(&source, dialect, "::p", place),
3120:                 LatticeValue::Const(ConstValue::Int(amount)),
3121:                 "{dialect}: `{body}` creates its cell"
3122:             );
3123:             assert_eq!(last_existence(&unit, "::p", place), SCALAR, "{dialect}");
3124:             if place == "arr(k)" {
3125:                 assert_eq!(last_existence(&unit, "::p", "arr"), ARRAY, "{dialect}");
3126:             }
3127:         }
3128:         for (dialect, answer) in [
3129:             ("tcl8.4", "evaluated: error after 0 stores"),
3130:             ("tcl", "declined: unbound-place"),
3131:         ] {
3132:             let unit = unit_of(&source, dialect);
3133:             assert_eq!(
3134:                 last_value(&source, dialect, "::p", place),
3135:                 LatticeValue::Overdefined,
3136:                 "{dialect}: `{body}` raises under 8.4, so its value declines"
3137:             );
3138:             let answers = answers_for(&unit, "::p", "incr");
3139:             assert!(
3140:                 answers.iter().any(|found| found == answer),
3141:                 "{dialect}: `{body}` answers {answer}: {answers:?}"
3142:             );
3143:         }
3144:         for (series, tclsh) in releases {
3145:             let answer = oracle_existence(tclsh, body, &[place]);
3146:             if *series == "8.4" {
3147:                 assert_eq!(answer, None, "tclsh8.4 raises on `{body}`");
3148:             } else {
3149:                 assert_eq!(answer, Some(vec![(true, false)]), "tclsh{series}: `{body}`");
3150:             }
3151:         }
3152:     }
3153: }
3154: 
3155: /// The page's release table for an absent cell
3156: /// (`docs/design/compiler/value-transfers.md` § *Existence*), every line but
3157: /// the `unset p nosuch q` prefix line, whose stores an error leaves behind
3158: /// are not modelled: each place's
3159: /// existence after the line, and the value a cell update leaves, under
3160: /// each release's dialect and the `tcl` profile that spans them all. An
3161: /// `incr` of an absent place binds from 8.5 and declines under 8.4 and
3162: /// under the spanning profile; `append` and `lappend` bind in every
3163: /// release; a no-match and an exhausted `scan` leave their places as they
3164: /// were; an unbind leaves the place unbound, and an unset element its array
3165: /// bound. Every fact is checked against `tclsh` wherever the line completes.
3166: #[test]
3167: fn the_absent_cell_release_table() {
3168:     let releases = releases_on_path();
3169:     the_lines_every_release_reads_alike(&releases);
3170:     the_increment_split(&releases);
3171: }
3172: 
3173: /// Whether one pass of the optimiser under `dialect` deletes the statement
3174: /// spelled `store` in `source` (O108, O109 or O126).
3175: fn removes_store(source: &str, dialect: &str, store: &str) -> bool {
3176:     let at = u32::try_from(source.find(store).expect("the store")).expect("an offset");
3177:     rewrites_of(source, dialect).iter().any(|rewrite| {
3178:         matches!(
3179:             rewrite.code,
3180:             DiagCode::O108 | DiagCode::O109 | DiagCode::O126
3181:         ) && rewrite.span.start() <= at
3182:             && at < rewrite.span.end()
3183:     })
3184: }
3185: 
3186: /// O109 keeps a store an existence read observes (#2132): while the
3187: /// read stands, no pass deletes the store behind it — the item's two
3188: /// programs keep `set x 1` and `incr n` behind `[info exists …]`, and an
3189: /// existence read in a bare statement, a `catch` body, a value word, a
3190: /// `return`, an `expr` word and `array exists` keeps its store, as does an
3191: /// unbind the store feeds: a nested `[unset x]` in an argument, a value
3192: /// word, a condition or a `return` (it raises on an absent `x`), and an
3193: /// `array unset` of a scalar, which leaves the scalar bound. An unbind
3194: /// statement is never removed. Every program the multipass optimiser
3195: /// rewrites, folding a decided read and then the store it no longer
3196: /// needs, prints what the original does under every release on `PATH` —
3197: /// the `incr` program from 8.5, where the original creates `n`; 8.4
3198: /// raises there.
3199: #[test]
3200: fn o109_keeps_a_store_an_existence_read_observes() {
3201:     let set_first = "proc p {} {set x 1; if {[info exists x]} {puts yes}}\np\n";
3202:     let incr_first = "proc p {} {incr n; if {[info exists n]} {puts yes}}\np\n";
3203:     for dialect in ["tcl8.4", "tcl8.6", "tcl9.0", "tcl"] {
3204:         assert!(!removes_store(set_first, dialect, "set x 1"), "{dialect}");
3205:     }
3206:     for dialect in ["tcl8.6", "tcl9.0"] {
3207:         assert!(!removes_store(incr_first, dialect, "incr n"), "{dialect}");
3208:     }
3209:     prints_under_every_release(set_first, "yes\n");
3210:     for (series, tclsh) in releases_on_path()
3211:         .into_iter()
3212:         .filter(|(series, _)| *series != "8.4")
3213:     {
3214:         let (rewritten, _) = optimised(incr_first, &dialect_of(series));
3215:         for program in [incr_first, rewritten.as_str()] {
3216:             assert_eq!(
3217:                 run_script(&tclsh, program),
3218:                 Some((true, "yes\n".to_owned())),
3219:                 "tclsh{series}:\n{program}"
3220:             );
3221:         }
3222:     }
3223:     let positions = "proc p1 {} {set x 1; info exists x}\n\
3224:          proc p2 {} {set x 1; catch {info exists x} r; return $r}\n\
3225:          proc p3 {} {set x 1; lappend l [info exists x]; return $l}\n\
3226:          proc p4 {} {set x 1; return [info exists x]}\n\
3227:          proc p5 {} {set x(a) 1; array exists x}\n\
3228:          proc p6 {} {set x 1; set y [expr {[info exists x] ? \"yes\" : \"no\"}]; return $y}\n\
3229:          proc p7 {} {set x 1; unset x; info exists x}\n\
3230:          proc p8 {c} {set x 1; if {$c} {unset x}; info exists x}\n\
3231:          proc p9 {} {set x 1; lappend l [unset x]; info exists x}\n\
3232:          proc p10 {} {set x 1; set y [unset x]; info exists x}\n\
3233:          proc p11 {} {set x 1; if {[unset x] eq \"\"} {info exists x}}\n\
3234:          proc p12 {} {set x 1; return [unset x]}\n\
3235:          proc p13 {} {set x 1; array unset x; return $x}\n\
3236:          proc p14 {} {set x 1; lappend l [array unset x]; info exists x}\n\
3237:          puts [list [p1] [p2] [p3] [p4] [p5] [p6] [p7] [p8 0] [p8 1] \
3238:          [p9] [p10] [p11] [p12] [p13] [p14]]\n";
3239:     let unbinds = positions.matches("unset x").count();
3240:     for dialect in ["tcl8.4", "tcl8.6", "tcl9.0"] {
3241:         for line in positions.lines().filter(|line| line.starts_with("proc ")) {
3242:             let store = if line.contains("set x(a) 1") {
3243:                 "set x(a) 1"
3244:             } else {
3245:                 "set x 1"
3246:             };
3247:             let one = format!("{line}\n");
3248:             assert!(!removes_store(&one, dialect, store), "{dialect}: {one}");
3249:         }
3250:         let (rewritten, _) = optimised(positions, dialect);
3251:         assert_eq!(
3252:             rewritten.matches("unset x").count(),
3253:             unbinds,
3254:             "{dialect}: an unbind is never removed:\n{rewritten}"
3255:         );
3256:     }
3257:     prints_under_every_release(positions, "1 1 1 1 1 yes 0 1 0 0 0 0 {} 1 1\n");
3258: }
3259: 
3260: /// The entry rule for a parameter and a never-assigned local (the
3261: /// Existence row): a parameter enters `Bound(Scalar)`, so `[info exists
3262: /// a]` decides true, and a local nothing ever assigns enters `Unbound`, so
3263: /// `[info exists b]` decides false — both inside the fixed point, so
3264: /// neither dead arm survives the optimiser.
3265: #[test]
3266: fn a_parameter_binds_and_a_never_assigned_local_stays_unbound() {
3267:     let source = "proc p {a} {\n    if {[info exists a]} {puts yes} else {puts no}\n    \
3268:                   if {[info exists b]} {puts wrong} else {puts right}\n}\np 1\n";
3269:     for dialect in DIALECTS {
3270:         let unit = unit_of(source, dialect);
3271:         assert_eq!(
3272:             last_existence(&unit, "::p", "a"),
3273:             SCALAR,
3274:             "{dialect}: a parameter binds at entry"
3275:         );
3276:         assert_eq!(
3277:             last_existence(&unit, "::p", "b"),
3278:             UNBOUND,
3279:             "{dialect}: a never-assigned local is unbound at entry"
3280:         );
3281:         let (rewritten, rewrites) = optimised(source, dialect);
3282:         assert!(
3283:             !rewritten.contains("puts no") && !rewritten.contains("puts wrong"),
3284:             "{dialect}: both guards decide inside the fixed point:\n{rewritten}\n{rewrites:#?}"
3285:         );
3286:     }
3287:     prints_under_every_release(source, "yes\nright\n");
3288: }
3289: 
3290: /// `unset -nocomplain` never raises, whether the place was bound or
3291: /// always absent — its completion domain has no error, unlike a plain
3292: /// `unset` of an absent name (the release table's own `unset -nocomplain
3293: /// nosuch` line, read here through the whole program rather than the
3294: /// existence probe alone): a second, redundant `-nocomplain` and one over
3295: /// a name never set both leave silently.
3296: #[test]
3297: fn unset_nocomplain_never_raises_bound_or_not() {
3298:     let source = "proc p {} {\n    set x 1\n    unset -nocomplain x\n    \
3299:                   unset -nocomplain x\n    unset -nocomplain never\n    \
3300:                   puts done\n    puts [info exists x]\n}\np\n";
3301:     for dialect in RELEASE_DIALECTS {
3302:         let unit = unit_of(source, dialect);
3303:         assert_eq!(
3304:             last_existence(&unit, "::p", "x"),
3305:             UNBOUND,
3306:             "{dialect}: a repeated -nocomplain leaves the place unbound"
3307:         );
3308:     }
3309:     prints_under_every_release(source, "done\n0\n");
3310: }
3311: 
3312: /// A scope-alias local enters `MayBound`, never provably `Unbound`,
3313: /// however little the visible source writes the linked global: the alias
3314: /// tracks a cell other, unanalysed code may already have set, so the
3315: /// guard on it never decides and both arms of `[info exists g]` survive
3316: /// the optimiser — even though this program's own `::g` is never set
3317: /// anywhere, so tclsh always takes the "no" arm.
3318: #[test]
3319: fn a_scope_alias_enters_maybound() {
3320:     let source =
3321:         "proc p {} {\n    global g\n    if {[info exists g]} {puts yes} else {puts no}\n}\np\n";
3322:     for dialect in DIALECTS {
3323:         let unit = unit_of(source, dialect);
3324:         assert_eq!(
3325:             last_existence(&unit, "::p", "g"),
3326:             Some(Existence::MayBound),
3327:             "{dialect}: a scope alias is MayBound, not provably absent"
3328:         );
3329:         let (rewritten, rewrites) = optimised(source, dialect);
3330:         assert!(
3331:             rewritten.contains("puts yes") && rewritten.contains("puts no"),
3332:             "{dialect}: a MayBound guard never folds away either arm:\n{rewritten}\n{rewrites:#?}"
3333:         );
3334:     }
3335:     prints_under_every_release(source, "no\n");
3336: }
3337: 
3338: /// A cross-event iRules variable enters `MayBound` (a superset of
3339: /// `ConnectionScope::cross_event_defs`): `y` is bound in `CLIENT_ACCEPTED`
3340: /// and read at `HTTP_REQUEST`'s own entry, so the guard there never
3341: /// decides either — no oracle here, since `when` is not a command a plain
3342: /// `tclsh` runs.
3343: #[test]
3344: fn a_cross_event_variable_enters_maybound() {
3345:     let source = "when CLIENT_ACCEPTED {\n    set y 1\n}\n\
3346:                   when HTTP_REQUEST {\n    if {[info exists y]} {puts yes} else {puts no}\n}\n";
3347:     let unit = unit_of(source, "f5-irules");
3348:     assert_eq!(
3349:         last_existence(&unit, "::when::HTTP_REQUEST", "y"),
3350:         Some(Existence::MayBound),
3351:         "a cross-event variable is MayBound at another handler's entry"
3352:     );
3353:     let (rewritten, rewrites) = optimised(source, "f5-irules");
3354:     assert!(
3355:         rewritten.contains("puts yes") && rewritten.contains("puts no"),
3356:         "a MayBound guard never folds away either arm:\n{rewritten}\n{rewrites:#?}"
3357:     );
3358: }
3359: 
3360: /// O130 folds a chain starting at an absent cell (the O104 / O130 row):
3361: /// the release rule creates `l` in every release, so `lappend l a;
3362: /// lappend l b` folds through the value at the last write exactly as a
3363: /// `set`-anchored chain does. The single O130 rewrite is read here
3364: /// (`rewrites_of`, matching `chain_fold.rs`'s own unit-test shape) since
3365: /// the multipass optimiser goes on to propagate `l`'s now-known value
3366: /// into `return $l` and drop the fold as unused in its turn — a further,
3367: /// sound reduction the exit line's own program does not name.
3368: #[test]
3369: fn o130_folds_a_chain_from_an_absent_cell() {
3370:     let source = "proc p {} {\n    lappend l a\n    lappend l b\n    return $l\n}\nputs [p]\n";
3371:     for dialect in ["tcl8.4", "tcl8.6", "tcl9.0", "tcl"] {
3372:         let rewrites = rewrites_of(source, dialect);
3373:         let fold = rewrites
3374:             .iter()
3375:             .find(|o| o.code == DiagCode::O130 && o.replacement.starts_with("set"))
3376:             .unwrap_or_else(|| panic!("{dialect}: expected an O130 fold: {rewrites:#?}"));
3377:         assert_eq!(fold.replacement, "set l {a b}", "{dialect}");
3378:     }
3379:     prints_under_every_release(source, "a b\n");
3380: }
3381: 
3382: /// A failing dead write is retained (O108's totality proof, the Rewrites
3383: /// row's "failing dead write retained"): `lappend l c` over the malformed
3384: /// list `"a {b"` raises `unmatched open brace in list` in every release,
3385: /// so deleting it — `l` is never read afterwards — would turn a raising
3386: /// program into a silent one.
3387: #[test]
3388: fn a_failing_dead_lappend_is_retained() {
3389:     let source = "proc p {} {\n    set l \"a {b\"\n    lappend l c\n}\np\n";
3390:     for dialect in ["tcl8.4", "tcl8.6", "tcl9.0", "tcl"] {
3391:         assert!(!removes_store(source, dialect, "lappend l c"), "{dialect}");
3392:     }
3393:     for (series, tclsh) in releases_on_path() {
3394:         assert_eq!(
3395:             run_script(&tclsh, source).map(|(ok, _)| ok),
3396:             Some(false),
3397:             "tclsh{series}: a malformed list raises on `lappend`"
3398:         );
3399:     }
3400: }
3401: 
3402: /// A failing dead `incr` is retained under 8.4 (O108's totality proof,
3403: /// permission 3): `incr n` on the never-bound, never-read `n` raises
3404: /// `can't read "n": no such variable` under 8.4, so removing it would turn
3405: /// a raising program into a silent one there; a profile whose every
3406: /// release creates the cell (8.5 onwards) still removes it.
3407: #[test]
3408: fn a_failing_dead_incr_is_retained_under_84() {
3409:     let source = "proc p {} {\n    incr n\n    return\n}\np\n";
3410:     for dialect in ["tcl8.4", "tcl", "f5-irules"] {
3411:         assert!(!removes_store(source, dialect, "incr n"), "{dialect}");
3412:     }
3413:     for dialect in ["tcl8.5", "tcl8.6", "tcl9.0", "tcl9.1"] {
3414:         assert!(removes_store(source, dialect, "incr n"), "{dialect}");
3415:     }
3416:     for (series, tclsh) in releases_on_path() {
3417:         let ok = run_script(&tclsh, source).map(|(ok, _)| ok);
3418:         if series == "8.4" {
3419:             assert_eq!(
3420:                 ok,
3421:                 Some(false),
3422:                 "tclsh8.4: `incr n` raises on an absent place"
3423:             );
3424:         } else {
3425:             assert_eq!(ok, Some(true), "tclsh{series}: `incr n` creates the cell");
3426:         }
3427:     }
3428: }
3429: 
3430: /// Whether the analyser reports `code` anywhere in `source` under
3431: /// `dialect`.
3432: fn reports(source: &str, dialect: &str, code: DiagCode) -> bool {
3433:     tcl_compiler::analyser::Analyser::new()
3434:         .analyse(source, dialect)
3435:         .diagnostics
3436:         .iter()
3437:         .any(|diagnostic| diagnostic.code == code)
3438: }
3439: 
3440: /// An externally mutable place is never refined: a call the
3441: /// module cannot see — here a computed head —
3442: /// sets or unsets a global between the guard and the inner query, with no
3443: /// barrier in between, so the inner `info exists` decides nothing. tclsh
3444: /// 8.4 to 9.1 print `yes yes gone`; a refinement would fold the inner
3445: /// conditions to `no no still`, with three false I230s.
3446: #[test]
3447: fn an_unseen_call_ends_no_refinement_because_none_is_made() {
3448:     let source = "\
3449: proc init {} { set ::x 1 }
3450: proc cleanup {} { unset ::x }
3451: set handlers {init cleanup}
3452: proc p {} {
3453:     if {![info exists ::x]} {
3454:         [lindex $::handlers 0]
3455:         if {[info exists ::x]} { puts yes } else { puts no }
3456:     }
3457: }
3458: proc q {} {
3459:     global x
3460:     if {![info exists x]} {
3461:         [lindex $::handlers 0]
3462:         if {[info exists x]} { puts yes } else { puts no }
3463:     }
3464: }
3465: proc r {} {
3466:     set ::x 1
3467:     if {[info exists ::x]} {
3468:         [lindex $::handlers 1]
3469:         if {[info exists ::x]} { puts still } else { puts gone }
3470:     }
3471: }
3472: p; unset ::x; q; r
3473: ";
3474:     for dialect in DIALECTS {
3475:         assert!(
3476:             !reports(source, dialect, DiagCode::I230),
3477:             "{dialect}: no inner query is decided"
3478:         );
3479:         let (rewritten, rewrites) = optimised(source, dialect);
3480:         assert!(
3481:             rewritten.contains("puts yes")
3482:                 && rewritten.contains("puts no")
3483:                 && rewritten.contains("puts still")
3484:                 && rewritten.contains("puts gone"),
3485:             "{dialect}: no arm is folded away:\n{rewritten}\n{rewrites:#?}"
3486:         );
3487:     }
3488:     prints_under_every_release(source, "yes\nyes\ngone\n");
3489: }
3490: 
3491: /// The absent-start chain anchor reads the fact at the statement: after a
3492: /// non-lowered `switch` whose arm may bind
3493: /// `l`, the per-version fact of `l`'s version 0 is still `Unbound`, but
3494: /// the fact at `lappend l a` is `MayBound` — the arm's clobber — so no
3495: /// chain anchors there. tclsh 8.4 to 9.1 print `z a b` and `a b`, before
3496: /// and after the optimiser.
3497: #[test]
3498: fn an_absent_start_anchor_reads_the_fact_at_the_statement() {
3499:     let source = "proc p {c} { switch -glob -- $c { a* { set l z } }; lappend l a; lappend l b; puts $l }\np abc\np q\n";
3500:     for dialect in ["tcl8.4", "tcl8.6", "tcl9.0", "tcl"] {
3501:         let rewrites = rewrites_of(source, dialect);
3502:         assert!(
3503:             !rewrites.iter().any(|o| o.code == DiagCode::O130),
3504:             "{dialect}: {rewrites:#?}"
3505:         );
3506:     }
3507:     prints_under_every_release(source, "z a b\na b\n");
3508: }
3509: 
3510: /// A failing dead `incr` on a may-bound place is retained under 8.4:
3511: /// `incr n` after `if {$c} {set n 1}` raises `can't
3512: /// read "n"` under 8.4 when `c` is false, so removing it would silence a
3513: /// raising program there; a profile whose every release creates the cell
3514: /// still removes it. tclsh 8.4 prints `1` (the call raised) and 8.5 to 9.1
3515: /// print `0`.
3516: #[test]
3517: fn a_failing_dead_incr_on_a_maybound_place_is_retained_under_84() {
3518:     let source =
3519:         "proc p {c} {\n    if {$c} {set n 1}\n    incr n\n    return\n}\nputs [catch {p 0} msg]\n";
3520:     for dialect in ["tcl8.4", "tcl", "f5-irules"] {
3521:         assert!(!removes_store(source, dialect, "incr n"), "{dialect}");
3522:     }
3523:     for dialect in ["tcl8.5", "tcl8.6", "tcl9.0", "tcl9.1"] {
3524:         assert!(removes_store(source, dialect, "incr n"), "{dialect}");
3525:     }
3526:     for (series, tclsh) in releases_on_path() {
3527:         let expected = if series == "8.4" { "1\n" } else { "0\n" };
3528:         let (rewritten, _) = optimised(source, &dialect_of(series));
3529:         for program in [source, rewritten.as_str()] {
3530:             assert_eq!(
3531:                 run_script(&tclsh, program),
3532:                 Some((true, expected.to_owned())),
3533:                 "tclsh{series}:\n{program}"
3534:             );
3535:         }
3536:     }
3537: }
3538: 
3539: /// A script body nested in a substitution clobbers what it may unset
3540: /// (#2231's consequence): `[catch {unset x}]` in a
3541: /// condition leaves `x` may-bound, so the later `[info exists x]` decides
3542: /// nothing — a fold would give `1` with an I230. tclsh 8.4 to 9.1 print
3543: /// `no`, before and after the optimiser.
3544: #[test]
3545: fn a_substituted_body_clobbers_what_it_unsets() {
3546:     let source = "set x 1\nif {[catch {unset x}]} { puts err }\nif {[info exists x]} {puts yes} else {puts no}\n";
3547:     for dialect in DIALECTS {
3548:         assert!(!reports(source, dialect, DiagCode::I230), "{dialect}");
3549:         let (rewritten, rewrites) = optimised(source, dialect);
3550:         assert!(
3551:             rewritten.contains("puts no"),
3552:             "{dialect}: the else arm stays:\n{rewritten}\n{rewrites:#?}"
3553:         );
3554:     }
3555:     prints_under_every_release(source, "no\n");
3556: }
3557: 
3558: /// A whole-variable `switch` subject resolves from the lattice (§ `switch`
3559: /// of the interface page), so program (4)'s flattened form decides per arm: I231
3560: /// on the dead arm's pattern and O107 on its body, beside O112 on the whole
3561: /// statement, which subsumes O107's rewrite when the findings are applied
3562: /// together — so O107 is read from the passes' raw findings and the
3563: /// applied program keeps neither the arm nor the `switch`, printing
3564: /// `always` under 8.4 to 9.1. A `${…}` subject whose name carries a
3565: /// backslash stays `Raw` and decides nothing — no I231 and no O107 — and
3566: /// tclsh prints `hit` before and after the optimiser.
3567: #[test]
3568: fn the_flattened_form_yields_o107() {
3569:     let source = "set acc \"\"; append acc foo; append acc bar\nswitch -- $acc {\n    baz     { puts never }\n    default { puts always }\n}\n";
3570:     let pattern = u32::try_from(source.find("baz").expect("the dead arm")).expect("an offset");
3571:     for dialect in DIALECTS {
3572:         let diagnostics = tcl_compiler::analyser::Analyser::new()
3573:             .analyse(source, dialect)
3574:             .diagnostics;
3575:         assert!(
3576:             diagnostics
3577:                 .iter()
3578:                 .any(|d| d.code == DiagCode::I231 && d.span.start() == pattern),
3579:             "{dialect}: I231 on the dead arm's pattern: {diagnostics:#?}"
3580:         );
3581:         let registry = static_context_for(dialect).commands();
3582:         let raw = optimise_raw(source, registry, Some(dialect));
3583:         for code in [DiagCode::O107, DiagCode::O112] {
3584:             assert!(
3585:                 raw.iter().any(|o| o.code == code),
3586:                 "{dialect}: {code:?} is a finding:\n{raw:#?}"
3587:             );
3588:         }
3589:         let (rewritten, rewrites) = optimised(source, dialect);
3590:         assert!(
3591:             !rewritten.contains("puts never") && !rewritten.contains("switch"),
3592:             "{dialect}: the applied program keeps neither the arm nor the switch:\n{rewritten}\n{rewrites:#?}"
3593:         );
3594:     }
3595:     prints_under_every_release(source, "always\n");
3596: 
3597:     let negative = "set {a\\b} baz\nswitch -- ${a\\b} {\n    baz     { puts hit }\n    default { puts miss }\n}\n";
3598:     for dialect in DIALECTS {
3599:         assert!(!reports(negative, dialect, DiagCode::I231), "{dialect}");
3600:         let rewrites = rewrites_of(negative, dialect);
3601:         assert!(
3602:             !rewrites.iter().any(|o| o.code == DiagCode::O107),
3603:             "{dialect}: {rewrites:#?}"
3604:         );
3605:     }
3606:     prints_under_every_release(negative, "hit\n");
3607: }
3608: 
3609: /// Program (4) — `switch` over the string two appends build — yields O112
3610: /// and I231 on the dead arm in every form. The exact form decides through its
3611: /// dispatch chain, which also drops the arm's body (O107); the `-glob`,
3612: /// `-regexp`, `-nocase` and fall-through forms decide through the selection
3613: /// record the solver makes at the statement, where the subject has the version
3614: /// the statement reads, and report the arm as a selection fact: no block is
3615: /// dropped, O107 does not fire and no O100 hints at a branch. `-nocase` is
3616: /// 8.5's, so a profile that may be 8.4 leaves it alone. The optimised program
3617: /// prints `always` under tclsh 8.4 to 9.1 (`-nocase` from 8.5).
3618: #[test]
3619: fn program_four_yields_o112_and_i231_for_every_form() {
3620:     let build = "set acc \"\"; append acc foo; append acc bar\n";
3621:     let arms = "{\n    baz     { puts never }\n    default { puts always }\n}\n";
3622:     // `baz -` shares `qux`'s body; the `-` is spelled bare, the one spelling
3623:     // every release reads alike.
3624:     let shared = "{\n    baz     -\n    qux     { puts never }\n    default { puts always }\n}\n";
3625:     let forms = [
3626:         (format!("{build}switch -- $acc {arms}"), "8.4", true),
3627:         (format!("{build}switch -glob -- $acc {arms}"), "8.4", false),
3628:         (
3629:             format!("{build}switch -regexp -- $acc {arms}"),
3630:             "8.4",
3631:             false,
3632:         ),
3633:         (
3634:             format!("{build}switch -nocase -- $acc {arms}"),
3635:             "8.5",
3636:             false,
3637:         ),
3638:         (format!("{build}switch -- $acc {shared}"), "8.4", false),
3639:     ];
3640:     for (source, first, flattened) in forms {
3641:         let dead = |word: &str| u32::try_from(source.find(word).expect("an arm")).expect("offset");
3642:         let mut dead_arms = vec![dead("baz")];
3643:         if source.contains("qux") {
3644:             dead_arms.push(dead("qux"));
3645:         }
3646:         for dialect in DIALECTS {
3647:             let has_the_form = first == "8.4" || !matches!(dialect, "tcl8.4" | "f5-irules" | "tcl");
3648:             let diagnostics = tcl_compiler::analyser::Analyser::new()
3649:                 .analyse(&source, dialect)
3650:                 .diagnostics;
3651:             let registry = static_context_for(dialect).commands();
3652:             let raw = optimise_raw(&source, registry, Some(dialect));
3653:             if !has_the_form {
3654:                 assert!(
3655:                     !raw.iter().any(|o| o.code == DiagCode::O112)
3656:                         && !diagnostics.iter().any(|d| d.code == DiagCode::I231),
3657:                     "{dialect}: no selection is made\n{source}"
3658:                 );
3659:                 continue;
3660:             }
3661:             for &arm in &dead_arms {
3662:                 assert!(
3663:                     diagnostics
3664:                         .iter()
3665:                         .any(|d| d.code == DiagCode::I231 && d.span.start() == arm),
3666:                     "{dialect}: I231 on the dead arm at {arm}\n{source}\n{diagnostics:#?}"
3667:                 );
3668:             }
3669:             let (rewritten, rewrites) = optimised(&source, dialect);
3670:             assert!(
3671:                 rewrites.iter().any(|o| o.code == DiagCode::O112)
3672:                     && !rewritten.contains("puts never")
3673:                     && !rewritten.contains("switch"),
3674:                 "{dialect}: O112 leaves `puts always`\n{source}\n{rewritten}\n{rewrites:#?}"
3675:             );
3676:             assert_eq!(
3677:                 raw.iter().any(|o| o.code == DiagCode::O107),
3678:                 flattened,
3679:                 "{dialect}: O107 on the dead body only where the CFG has the arm's block\n{source}\n{raw:#?}"
3680:             );
3681:             if !flattened {
3682:                 let unit = unit_of(&source, dialect);
3683:                 let top = &unit.top_level;
3684:                 assert_eq!(
3685:                     top.sccp.executable_blocks.len(),
3686:                     top.cfg.blocks.len(),
3687:                     "{dialect}: no block is dropped\n{source}"
3688:                 );
3689:                 let profile = resolve_environment(dialect).analyser_profile();
3690:                 let checks =
3691:                     tcl_compiler::compiler_checks::run_all_checks(&unit, registry, Some(profile));
3692:                 assert!(
3693:                     checks.iter().all(|check| check.code != DiagCode::O100),
3694:                     "{dialect}: a selection fact hints at no branch\n{source}\n{checks:#?}"
3695:                 );
3696:             }
3697:         }
3698:         prints_under_releases_from(&source, "always\n", first);
3699:     }
3700: }
3701: 
3702: /// A selection fact names an arm no branch leads to, so it folds no
3703: /// condition: the statement's block also ends in the `if`'s branch, and a
3704: /// fact keyed by that block had rewritten `if {$x}` to `if {0}`. The procedure
3705: /// is called with both a true and a false argument, so `x` is no constant.
3706: /// tclsh 8.4 to 9.1 print `A`, `X` and `A` for the program, before and after
3707: /// the optimiser.
3708: #[test]
3709: fn a_selection_fact_folds_no_condition_beside_it() {
3710:     let source = "proc p {x} {\n    set s abc\n    switch -glob -- $s {a* {puts A} b* {puts B}}\n    if {$x} {puts X}\n}\np 1\np 0\n";
3711:     for dialect in DIALECTS {
3712:         let registry = static_context_for(dialect).commands();
3713:         let raw = optimise_raw(source, registry, Some(dialect));
3714:         assert!(
3715:             !raw.iter().any(|o| o.code == DiagCode::O101),
3716:             "{dialect}: no condition folds\n{raw:#?}"
3717:         );
3718:         let (rewritten, _) = optimised(source, dialect);
3719:         assert!(
3720:             rewritten.contains("if {$x}") && !rewritten.contains("switch"),
3721:             "{dialect}: the switch folds, the condition stays\n{rewritten}"
3722:         );
3723:     }
3724:     prints_under_every_release(source, "A\nX\nA\n");
3725: }
3726: 
3727: /// A loop whose header the solver decides is reported from that fact: W240
3728: /// where the header is false at entry, W241 where it is true at every test
3729: /// and nothing leaves the loop, and either replaces W242's hint that a
3730: /// counter is never modified. Each W240 program prints only `done` under
3731: /// tclsh 8.4 to 9.1, before and after the optimiser: the body never runs.
3732: /// The infinite loops are not run. A header nothing decides keeps W242, and
3733: /// one with an exit the flow graph or the body's text finds draws none.
3734: #[test]
3735: fn a_decided_loop_header_gives_w240_or_w241() {
3736:     let codes = |source: &str, dialect: &str| -> Vec<String> {
3737:         let mut found: Vec<String> = tcl_compiler::analyser::Analyser::new()
3738:             .analyse(source, dialect)
3739:             .diagnostics
3740:             .iter()
3741:             .map(|d| d.code.to_string())
3742:             .filter(|code| matches!(code.as_str(), "W240" | "W241" | "W242"))
3743:             .collect();
3744:         found.sort();
3745:         found
3746:     };
3747:     let never = [
3748:         "set n 0\nwhile {$n} {puts never}\nputs done\n",
3749:         "proc p {} {set n 0; while {$n} {puts never}; return done}\nputs [p]\n",
3750:         "for {set i 0} {$i < 0} {incr i} {puts never}\nputs done\n",
3751:         "set n 0\nwhile 0 {puts never}\nputs done\n",
3752:     ];
3753:     for source in never {
3754:         for dialect in DIALECTS {
3755:             assert_eq!(codes(source, dialect), ["W240"], "{dialect}\n{source}");
3756:         }
3757:         prints_under_every_release(source, "done\n");
3758:     }
3759:     let infinite = [
3760:         "set go 1\nwhile {$go} {puts x}\n",
3761:         "proc p {} {set go 1; while {$go} {puts x}}\n",
3762:         "for {set i 0} {$i < 10} {} {puts hi}\n",
3763:         "while 1 {puts x}\n",
3764:     ];
3765:     for source in infinite {
3766:         for dialect in DIALECTS {
3767:             assert_eq!(codes(source, dialect), ["W241"], "{dialect}\n{source}");
3768:         }
3769:     }
3770:     let undecided = "proc p {n} {\n    while {$n} {puts x}\n}\n";
3771:     let left =
3772:         "proc p {} {\n    set go 1\n    while {$go} {if {[gets stdin] eq \"q\"} {break}}\n}\n";
3773:     for dialect in DIALECTS {
3774:         assert_eq!(codes(undecided, dialect), ["W242"], "{dialect}");
3775:         assert!(codes(left, dialect).is_empty(), "{dialect}");
3776:     }
3777: }
3778: 
3779: /// `case` lowers as an opaque glob selection over its own contract: `a*` and
3780: /// a literal pattern each select the first arm, in the one-word form and in
3781: /// the separate-words form with `in` alike — the selection record says so
3782: /// under 8.4, 8.6 and the iRules profile — no I231 claims the live arm is
3783: /// dead, and the optimiser leaves `puts yes`, which tclsh 8.4 to 8.6 print
3784: /// before and after it. From 9.0 there is no `case`: nothing lowers it, so
3785: /// nothing is recorded or folded.
3786: #[test]
3787: fn case_selects_its_glob_arm() {
3788:     for clauses in [
3789:         "in a* {puts yes} default {puts no}",
3790:         "in abc {puts yes} default {puts no}",
3791:         "{a* {puts yes} default {puts no}}",
3792:     ] {
3793:         let source = format!("proc p {{}} {{\n    case abc {clauses}\n}}\np\n");
3794:         for dialect in ["tcl8.4", "tcl8.6", "f5-irules"] {
3795:             let unit = unit_of(&source, dialect);
3796:             let records = &unit
3797:                 .procedures
3798:                 .get(&fixture_id(&unit.procedures, "::p"))
3799:                 .expect("the procedure")
3800:                 .sccp
3801:                 .selections;
3802:             assert_eq!(records.len(), 1, "{dialect}: {source}");
3803:             assert_eq!(records[0].fact.selected, [Some(0)], "{dialect}: {source}");
3804:             assert!(
3805:                 !reports(&source, dialect, DiagCode::I231),
3806:                 "{dialect}: {source}"
3807:             );
3808:             let (rewritten, rewrites) = optimised(&source, dialect);
3809:             assert!(
3810:                 rewritten.contains("puts yes") && !rewritten.contains("puts no"),
3811:                 "{dialect}: {source}\n{rewritten}\n{rewrites:#?}"
3812:             );
3813:         }
3814:         let unit = unit_of(&source, "tcl9.0");
3815:         let function = unit
3816:             .procedures
3817:             .get(&fixture_id(&unit.procedures, "::p"))
3818:             .expect("the procedure");
3819:         assert!(function.sccp.selections.is_empty(), "tcl9.0: {source}");
3820:         assert!(
3821:             !function
3822:                 .ssa
3823:                 .blocks
3824:                 .values()
3825:                 .flat_map(|block| &block.statements)
3826:                 .any(|statement| matches!(statement.statement, Statement::Switch { .. })),
3827:             "tcl9.0: {source}"
3828:         );
3829:         for (series, tclsh) in releases_on_path() {
3830:             if !series.starts_with("8.") {
3831:                 continue;
3832:             }
3833:             let (rewritten, _) = optimised(&source, &dialect_of(series));
3834:             for program in [source.as_str(), rewritten.as_str()] {
3835:                 assert_eq!(
3836:                     run_script(&tclsh, program),
3837:                     Some((true, "yes\n".to_owned())),
3838:                     "tclsh{series}:\n{program}"
3839:                 );
3840:             }
3841:         }
3842:     }
3843: }
3844: 
3845: /// A write an arm of a `switch` the flow graph keeps as one statement makes
3846: /// is never folded away: tclsh 8.4 to 9.1 print `b` and `0` for each of these
3847: /// programs, before and after the optimiser, where taking the earlier `go` as
3848: /// the value after the switch printed `a` and `1`. `-nocase` is from 8.5.
3849: #[test]
3850: fn a_write_an_opaque_switch_arm_makes_is_never_folded_away() {
3851:     for (arm, first) in [
3852:         ("-glob -- $s { q* { set go 0 } }", "8.4"),
3853:         ("-nocase -- $s { Q1 { set go 0 } }", "8.5"),
3854:         ("-regexp -- $s { {^q} { set go 0 } }", "8.4"),
3855:         ("-glob -- $s { x - q* { set go 0 } }", "8.4"),
3856:         (
3857:             "-glob -- $s { z* { set other 1 } default { set go 0 } }",
3858:             "8.4",
3859:         ),
3860:     ] {
3861:         let source = format!(
3862:             "set go 1\nset s [string tolower Q1]\nswitch {arm}\nif {{$go}} {{puts a}} else {{puts b}}\nputs $go\n"
3863:         );
3864:         prints_under_releases_from(&source, "b\n0\n", first);
3865:         let in_proc = format!(
3866:             "proc p {{}} {{\n set go 1\n set s [string tolower Q1]\n switch {arm}\n if {{$go}} {{puts a}} else {{puts b}}\n puts $go\n}}\np\n"
3867:         );
3868:         prints_under_releases_from(&in_proc, "b\n0\n", first);
3869:     }
3870: }
3871: 
3872: /// What a command an arm of such a `switch` runs does to the frame is never
3873: /// folded away either: a callee that writes the caller's `go` through `upvar`,
3874: /// `namespace eval` at the global level and `dict with` (8.5 on) each leave
3875: /// `b` and `0` at the top level, where the earlier `go` printed `a` and `1`;
3876: /// in a procedure `namespace eval ::` writes the global, and the local keeps
3877: /// its value before and after the optimiser.
3878: #[test]
3879: fn a_write_a_command_an_opaque_switch_arm_runs_is_never_folded_away() {
3880:     for (arm, first, in_proc) in [
3881:         ("zero go", "8.4", "b\n0\n"),
3882:         ("namespace eval :: {set go 0}", "8.4", "a\n1\n"),
3883:         ("set d {}; dict with d {set go 0}", "8.5", "b\n0\n"),
3884:     ] {
3885:         let source = format!(
3886:             "proc zero {{v}} {{upvar 1 $v x; set x 0}}\nset go 1\nset s [string tolower Q1]\n\
3887:              switch -glob -- $s {{ q* {{ {arm} }} }}\nif {{$go}} {{puts a}} else {{puts b}}\nputs $go\n"
3888:         );
3889:         prints_under_releases_from(&source, "b\n0\n", first);
3890:         let in_proc_source = format!(
3891:             "proc zero {{v}} {{upvar 1 $v x; set x 0}}\nproc p {{}} {{\n set go 1\n set s [string tolower Q1]\n \
3892:              switch -glob -- $s {{ q* {{ {arm} }} }}\n if {{$go}} {{puts a}} else {{puts b}}\n puts $go\n}}\np\n"
3893:         );
3894:         prints_under_releases_from(&in_proc_source, in_proc, first);
3895:     }
3896: }
3897: 
3898: /// A write a callback script makes — an `after` handler, a variable trace's
3899: /// callback, a procedure named as a callback — is never folded away either:
3900: /// each program prints the callback's value, `1` and `b`, under every
3901: /// release, before and after the optimiser.
3902: #[test]
3903: fn a_write_a_callback_script_makes_is_never_folded_away() {
3904:     for source in [
3905:         "set done 0\nafter 10 { set done 1 }\nafter 50\nupdate\nputs $done\n",
3906:         "proc tick {} { set ::done 1 }\nset done 0\nafter 10 tick\nafter 50\nupdate\nputs $done\n",
3907:         "set done 0\nafter 10 { set ::done 1 }\nafter 50\nupdate\nif {$done} {puts 1} else {puts 0}\n",
3908:         "set done 0\nafter 10 \"set ::done 1\"\nafter 50\nupdate\nputs $done\n",
3909:         "set done 0\nafter 10 [list set ::done 1]\nafter 50\nupdate\nputs $done\n",
3910:         "proc tick {n} { set ::done $n }\nset done 0\nafter 10 [list tick 1]\nafter 50\nupdate\nputs $done\n",
3911:     ] {
3912:         prints_under_every_release(source, "1\n");
3913:     }
3914:     prints_under_every_release(
3915:         "set go 1\ntrace add variable x write { set ::go 0 ;# }\nset x 1\nif {$go} {puts a} else {puts b}\n",
3916:         "b\n",
3917:     );
3918: }
3919: 
3920: /// A command the module cannot see may write a plain top-level name as it
3921: /// writes `::g`, so the name is never folded across the call: `foo` here is
3922: /// defined at run time, from a file the program writes and sources, and sets
3923: /// the global — tclsh 8.4 to 9.1 print `six` and `6`, where taking `5` across
3924: /// the call printed `other` and `5`.
3925: #[test]
3926: fn a_write_a_command_the_module_cannot_see_makes_is_never_folded_away() {
3927:     let define = "set f [file join [file dirname [info script]] vt-unseen-[pid].tcl]\n\
3928:                   set fh [open $f w]\nputs $fh {proc foo {} {set ::g 6}}\nclose $fh\n\
3929:                   source $f\nfile delete $f\n";
3930:     for tail in [
3931:         "set g 5\nfoo\nif {$g == 6} {puts six} else {puts other}\nputs $g\n",
3932:         "set ::g 5\nfoo\nif {$::g == 6} {puts six} else {puts other}\nputs $::g\n",
3933:         "set g 5\nwhile {$g != 6} { foo }\nputs six\nputs $g\n",
3934:     ] {
3935:         prints_under_every_release(&format!("{define}{tail}"), "six\n6\n");
3936:     }
3937: }
3938: 
3939: /// A sourced file runs in the frame of the call, so it writes a procedure's
3940: /// local as well as a global: the file here sets `g` to 6, and tclsh 8.4 to 9.1
3941: /// print `six` and `6` at the top level and in a procedure, where taking `5`
3942: /// across the `source` printed `other` and `5`.
3943: #[test]
3944: fn a_write_a_sourced_file_makes_is_never_folded_away() {
3945:     let write_file = "set f [file join [file dirname [info script]] vt-sourced-[pid].tcl]\n\
3946:                       set fh [open $f w]\nputs $fh {set g 6}\nclose $fh\n";
3947:     let top = format!(
3948:         "{write_file}set g 5\nsource $f\nfile delete $f\nif {{$g == 6}} {{puts six}} else {{puts other}}\nputs $g\n"
3949:     );
3950:     prints_under_every_release(&top, "six\n6\n");
3951:     let in_proc = format!(
3952:         "proc p {{f}} {{\n set g 5\n source $f\n if {{$g == 6}} {{puts six}} else {{puts other}}\n puts $g\n}}\n{write_file}p $f\nfile delete $f\n"
3953:     );
3954:     prints_under_every_release(&in_proc, "six\n6\n");
3955: }
3956: 
3957: /// A command the module cannot see may write a procedure's local as well as a
3958: /// global: a callee an autoloader or the unresolved-command handler brings in
3959: /// runs `upvar 1` into the frame that called it. `missing` here is defined by
3960: /// `auto_index` when Tcl's `unknown` first looks for it, and sets the
3961: /// caller's `g` to 6 — tclsh 8.4 to 9.1 print `six` and `6` from each
3962: /// procedure, where taking `5` across the call printed `other` and `5`, and the
3963: /// loop the call ends never stopped.
3964: #[test]
3965: fn a_write_an_autoloaded_command_makes_to_a_procedure_local_is_never_folded_away() {
3966:     let define = "set auto_index(missing) {proc missing {} {upvar 1 g g; set g 6}}\n";
3967:     for body in [
3968:         " set g 5\n missing\n if {$g == 6} {puts six} else {puts other}\n puts $g\n",
3969:         " set g 5\n set r [missing]\n if {$g == 6} {puts six} else {puts other}\n puts $g\n",
3970:         " set g 5\n while {$g != 6} { missing }\n puts six\n puts $g\n",
3971:     ] {
3972:         prints_under_every_release(
3973:             &format!("{define}proc p {{}} {{\n{body}}}\np\n"),
3974:             "six\n6\n",
3975:         );
3976:     }
3977: }
3978: 
3979: /// Each program selects its `hit` arm of a `switch` whose subject and pattern
3980: /// are the same characters spelled two ways: a bare or quoted word is its
3981: /// escapes decoded, a braced word its content, and an element of a braced arm
3982: /// list either. The flattened dispatch compared the subject's spelling — `a\nb`
3983: /// is four characters there — to the decoded pattern, so the analyser called
3984: /// the `hit` arm unreachable (I231) and the optimiser rewrote the program to
3985: /// its `miss` default, where tclsh 8.4 to 9.1 print `hit`.
3986: const SAME_CHARACTERS: [&str; 18] = [
3987:     r#"switch -- a\nb {"a\nb" {puts hit} default {puts miss}}"#,
3988:     r#"switch -exact -- "a\tb" {a\tb {puts hit} default {puts miss}}"#,
3989:     r#"switch a\nb {"a\nb" {puts hit} default {puts miss}}"#,
3990:     r#"switch "a\nb" {a\nb {puts hit} default {puts miss}}"#,
3991:     r#"switch "a\tb" {a\tb {puts hit} default {puts miss}}"#,
3992:     r#"switch a\tb {"a\tb" {puts hit} default {puts miss}}"#,
3993:     r#"switch "a\\b" {{a\b} {puts hit} default {puts miss}}"#,
3994:     r#"switch {a\b} {"a\\b" {puts hit} default {puts miss}}"#,
3995:     "switch \"a\\nb\" {{a\nb} {puts hit} default {puts miss}}",
3996:     "switch {a\nb} {\"a\\nb\" {puts hit} default {puts miss}}",
3997:     "switch {a\\\nb} {{a b} {puts hit} default {puts miss}}",
3998:     r#"switch "a\tb" a\tb {puts hit} default {puts miss}"#,
3999:     r#"switch a\tb "a\tb" {puts hit} default {puts miss}"#,
4000:     r"switch a\$b {a\$b {puts hit} default {puts miss}}",
4001:     r"switch a\[b {a\[b {puts hit} default {puts miss}}",
4002:     "set s \"a\\nb\"\nswitch $s {a\\nb {puts hit} default {puts miss}}",
4003:     r#"switch -glob -- a\nb {"a\nb" {puts hit} default {puts miss}}"#,
4004:     r"switch -glob -- a\$b {a\$b {puts hit} default {puts miss}}",
4005: ];
4006: 
4007: /// A `switch` compares the values of its words however they are spelled: every
4008: /// program of [`SAME_CHARACTERS`] prints `hit` under every release, before and
4009: /// after the optimiser, which keeps the matching arm and nothing else, and no
4010: /// O107 rewrite removes the arm that runs.
4011: #[test]
4012: fn a_switch_compares_the_values_of_its_words_however_they_are_spelled() {
4013:     for source in SAME_CHARACTERS {
4014:         for dialect in ["tcl8.4", "tcl8.6", "tcl9.0"] {
4015:             let (rewritten, _) = optimised(source, dialect);
4016:             assert!(
4017:                 rewritten.trim().ends_with("puts hit")
4018:                     && !rewritten.contains("switch")
4019:                     && !rewritten.contains("miss"),
4020:                 "{dialect}: {source}\n{rewritten}"
4021:             );
4022:             for dead in rewrites_of(source, dialect)
4023:                 .iter()
4024:                 .filter(|rewrite| rewrite.code == DiagCode::O107)
4025:             {
4026:                 let removed = &source[dead.span.start() as usize..dead.span.end() as usize];
4027:                 assert!(
4028:                     !removed.contains("hit"),
4029:                     "{dialect}: O107 removes the arm that runs: {source}\n{removed}"
4030:                 );
4031:             }
4032:         }
4033:         prints_under_every_release(source, "hit\n");
4034:     }
4035: }
4036: 
4037: /// Before 8.5 `switch` reads every leading word that starts with `-` as an
4038: /// option, however many words follow, so a subject holding `-glob` is one:
4039: /// tclsh 8.4 rejects the program with `bad option`, where 8.5 to 9.1 select
4040: /// the `-glob` arm and print `G`. A release that may be 8.4 — `tcl8.4`, a
4041: /// profile that names none — keeps the statement as it is, and from 8.5 the
4042: /// optimiser keeps the arm. `--` ends the run, so the subject is one under
4043: /// every release and the statement folds under all of them; a subject that
4044: /// does not start with `-` is selected through the statement's own record
4045: /// where the flattened chain is not built; and a literal subject is read by
4046: /// its decoded value, so `\x2dglob` is an option as `-glob` is.
4047: #[test]
4048: fn a_subject_a_release_may_read_as_an_option_is_not_folded_before_8_5() {
4049:     let bare = "set x -glob\nswitch $x {-glob {puts G} default {puts D}}\n";
4050:     let escaped = "switch \\x2dglob {-glob {puts G} default {puts D}}\n";
4051:     for source in [bare, escaped] {
4052:         for (series, tclsh) in releases_on_path() {
4053:             let before_85 = series == "8.4";
4054:             let expected = if before_85 {
4055:                 (false, String::new())
4056:             } else {
4057:                 (true, "G\n".to_owned())
4058:             };
4059:             let (rewritten, _) = optimised(source, &dialect_of(series));
4060:             for program in [source, rewritten.as_str()] {
4061:                 assert_eq!(
4062:                     run_script(&tclsh, program),
4063:                     Some(expected.clone()),
4064:                     "tclsh{series}:\n{program}"
4065:                 );
4066:             }
4067:             assert_eq!(
4068:                 rewritten.contains("switch"),
4069:                 before_85,
4070:                 "{series}: {rewritten}"
4071:             );
4072:         }
4073:         let (kept, _) = optimised(source, "tk");
4074:         assert!(kept.contains("switch"), "a profile with no release: {kept}");
4075:     }
4076:     let ended = "set x -glob\nswitch -- $x {-glob {puts G} default {puts D}}\n";
4077:     for dialect in ["tcl8.4", "tcl8.6", "tk"] {
4078:         let (rewritten, _) = optimised(ended, dialect);
4079:         assert!(
4080:             rewritten.contains("puts G") && !rewritten.contains("switch"),
4081:             "{dialect}: {rewritten}"
4082:         );
4083:     }
4084:     prints_under_every_release(ended, "G\n");
4085:     let plain = "set x a\nswitch $x {a {puts A} default {puts D}}\n";
4086:     for dialect in ["tcl8.4", "tk", "tcl9.0"] {
4087:         let (rewritten, _) = optimised(plain, dialect);
4088:         assert!(
4089:             rewritten.contains("puts A") && !rewritten.contains("switch"),
4090:             "{dialect}: {rewritten}"
4091:         );
4092:     }
4093:     prints_under_every_release(plain, "A\n");
4094: }
4095: 
4096: /// With pattern and body words the subject is inside the option scan on every
4097: /// release — 8.5 to 9.1 stop the scan with two words left, and a pattern and
4098: /// its body are two words — so a variable holding `-glob` is an option there
4099: /// too: every tclsh rejects the program below with `extra switch pattern with
4100: /// no body`, where the default arm would print `D`. The statement is kept
4101: /// under every release's profile and under one that names none.
4102: #[test]
4103: fn a_subject_inside_the_scan_of_the_arms_as_words_is_not_folded_on_any_release() {
4104:     let source = "set x -glob\nswitch $x a {puts A} default {puts D}\n";
4105:     for (series, tclsh) in releases_on_path() {
4106:         let (rewritten, _) = optimised(source, &dialect_of(series));
4107:         for program in [source, rewritten.as_str()] {
4108:             assert_eq!(
4109:                 run_script(&tclsh, program),
4110:                 Some((false, String::new())),
4111:                 "tclsh{series}:\n{program}"
4112:             );
4113:         }
4114:         assert!(rewritten.contains("switch"), "{series}: {rewritten}");
4115:     }
4116:     let (kept, _) = optimised(source, "tk");
4117:     assert!(kept.contains("switch"), "a profile with no release: {kept}");
4118: }
4119: 
4120: /// A read inside a braced `expr` is a use of the version it reads, and a read
4121: /// beside a write the same statement's substitutions make is read before,
4122: /// between and after it: the store feeding the word that runs first stays,
4123: /// and no word is forwarded the earlier value. Each program prints what
4124: /// tclsh 8.4 to 9.1 print, before and after the optimiser — where the
4125: /// statement was a `puts`, a `set` of an expression or of a string, an `expr`,
4126: /// a `return`, an `incr`, a condition, or a call to a procedure, the optimiser
4127: /// had deleted `set x 1` and the program raised `can't read "x"`, or forwarded
4128: /// `1` past the increment and printed `1 2 1`.
4129: #[test]
4130: fn a_braced_expr_read_keeps_its_store() {
4131:     // The two programs the examples page gives.
4132:     prints_under_every_release(
4133:         "proc p {} {\n set n 1\n set r [expr {$n + [incr n]}]\n return $r\n}\nputs [p]\n",
4134:         "3\n",
4135:     );
4136:     prints_under_every_release(
4137:         "proc q {} {\n set n 1\n set r [expr {[incr n] + [incr n]}]\n return $r\n}\nputs [q]\n",
4138:         "5\n",
4139:     );
4140:     for (body, expected) in [
4141:         ("puts [expr {$x + [set x 10] + $x}]\n puts $x", "21\n10\n"),
4142:         (
4143:             "set r [expr {$x + [set x 10] + $x}]\n puts $r\n puts $x",
4144:             "21\n10\n",
4145:         ),
4146:         ("expr {$x + [set x 10] + $x}\n puts $x", "10\n"),
4147:         ("if {$x + [set x 10] > 3} {puts yes}\n puts $x", "yes\n10\n"),
4148:         ("while {$x + [set x 10] < 3} {break}\n puts $x", "10\n"),
4149:         (
4150:             "set y 5\n incr y [expr {$x + [set x 10]}]\n puts \"$y $x\"",
4151:             "16 10\n",
4152:         ),
4153:         (
4154:             "set r \"$x [set x 10] $x\"\n puts \"$r|$x\"",
4155:             "1 10 10|10\n",
4156:         ),
4157:         ("foo $x [incr x] $x\n puts $x", "1 2 2\n2\n"),
4158:         (
4159:             "set l {}\n lappend l $x [incr x] $x\n puts \"$l|$x\"",
4160:             "1 2 2|2\n",
4161:         ),
4162:         (
4163:             "set r [expr {[string length $x] + [set x 10]}]\n puts \"$r $x\"",
4164:             "11 10\n",
4165:         ),
4166:         (
4167:             "set r [expr {[expr {$x + 1}] + [set x 10]}]\n puts \"$r $x\"",
4168:             "12 10\n",
4169:         ),
4170:     ] {
4171:         let source = format!(
4172:             "proc foo {{a b c}} {{puts \"$a $b $c\"}}\nproc p {{}} {{\n set x 1\n {body}\n}}\np\n"
4173:         );
4174:         prints_under_every_release(&source, expected);
4175:     }
4176:     prints_under_every_release(
4177:         "proc p {} {\n set x 1\n return [expr {$x + [set x 10]}]\n}\nputs [p]\n",
4178:         "11\n",
4179:     );
4180:     // At the top level the same statements print the same.
4181:     prints_under_every_release(
4182:         "set x 1\nputs [expr {$x + [set x 10] + $x}]\nputs $x\n",
4183:         "21\n10\n",
4184:     );
4185: }
4186: 
4187: /// A write a statement makes that none of its words read overwrites the store
4188: /// before it, as it did: the call that carries the write reads the place only
4189: /// where a word does. `puts [set x 2]` and a `gets` that fills a loop's
4190: /// variable leave the stores before them dead, so O109 and O126 still remove
4191: /// them, and each program prints the same afterwards.
4192: #[test]
4193: fn a_store_a_nested_write_overwrites_unread_is_still_dead() {
4194:     let overwritten = "proc p {} {\n set x 1\n puts [set x 2]\n return $x\n}\nputs [p]\n";
4195:     let loop_variable = "proc p {fd} {\n set line {}\n set n 0\n \
4196:                          while {[gets $fd line] >= 0} {incr n}\n return $n\n}\n\
4197:                          set f [open /dev/null r]\nputs [p $f]\n";
4198:     for dialect in ["tcl8.4", "tcl8.6", "tcl9.0"] {
4199:         assert!(removes_store(overwritten, dialect, "set x 1"), "{dialect}");
4200:         assert!(
4201:             removes_store(loop_variable, dialect, "set line {}"),
4202:             "{dialect}"
4203:         );
4204:     }
4205:     prints_under_every_release(overwritten, "2\n2\n");
4206:     prints_under_every_release(loop_variable, "0\n");
4207: }
4208: 
4209: /// The programs of [`a_nested_write_in_a_host_prints_what_tclsh_prints`], each with what
4210: /// tclsh 8.4 to 9.1 print.
4211: const NESTED_WRITE_PROGRAMS: &[(&str, &str)] = &[
4212:     // a loop carries the write round
4213:     (
4214:         "set x 0\nfor {set i 0} {$i < 3} {incr i} { set r [expr {[incr x] * 2}] }\nputs \"$r $x\"\n",
4215:         "6 3\n",
4216:     ),
4217:     (
4218:         "set x 0\nset i 0\nwhile {$i < 4} { expr {[incr x 2] + 0}; incr i }\nputs $x\n",
4219:         "8\n",
4220:     ),
4221:     (
4222:         "proc p {n} {set x 0; for {set i 0} {$i < $n} {incr i} {set r [expr {$x + [incr x]}]}; return \"$r $x\"}\nputs [p 3]\nputs [p 1]\n",
4223:         "5 3\n1 1\n",
4224:     ),
4225:     // a branch the engine takes or skips
4226:     (
4227:         "proc p {c} { set x 1; if {$c} { set r [expr {[incr x] + 1}] } else { set r 0 }; return \"$r $x\" }\nputs [p 1]\nputs [p 0]\n",
4228:         "3 2\n0 1\n",
4229:     ),
4230:     (
4231:         "proc p {c} { set x 1; set r [expr {$c ? [incr x] : 0}]; return \"$r $x\" }\nputs [p 1]\nputs [p 0]\n",
4232:         "2 2\n0 1\n",
4233:     ),
4234:     (
4235:         "proc p {c} { set x 1; set r [expr {$c && [incr x]}]; return \"$r $x\" }\nputs [p 1]\nputs [p 0]\n",
4236:         "1 2\n0 1\n",
4237:     ),
4238:     (
4239:         "proc p {c} { set x 1; set r [expr {$c || [incr x]}]; return \"$r $x\" }\nputs [p 1]\nputs [p 0]\n",
4240:         "1 1\n1 2\n",
4241:     ),
4242:     (
4243:         "set x 1\nset r [expr {1 ? [incr x] : [incr x 10]}]\nputs \"$r $x\"\n",
4244:         "2 2\n",
4245:     ),
4246:     (
4247:         "set x 1\nset r [expr {0 || [incr x]}]\nputs \"$r $x\"\n",
4248:         "1 2\n",
4249:     ),
4250:     (
4251:         "set x 1\nset r [expr {1 || [incr x]}]\nputs \"$r $x\"\n",
4252:         "1 1\n",
4253:     ),
4254:     // an input the engine takes on one member and not on another
4255:     (
4256:         "proc p {n} {set x 1; if {$n} {set c 0} else {set c 1}; set r [expr {$c ? [incr x] : 7}]; return \"$r $x\"}\nputs [p 0]\nputs [p 1]\n",
4257:         "2 2\n7 1\n",
4258:     ),
4259:     // an element of an array
4260:     (
4261:         "set a(1) 5\nset r [expr {$a(1) + [incr a(1)]}]\nputs \"$r $a(1)\"\n",
4262:         "11 6\n",
4263:     ),
4264:     (
4265:         "set a(k) 1\nset r [expr {[incr a(k)] + [incr a(k)]}]\nputs \"$r $a(k)\"\n",
4266:         "5 3\n",
4267:     ),
4268:     (
4269:         "array set a {1 5 2 6}\nset r [expr {$a(1) + [set a(2) 9] + $a(2)}]\nputs \"$r $a(1) $a(2)\"\n",
4270:         "23 5 9\n",
4271:     ),
4272:     // a place the frame does not own is left alone
4273:     (
4274:         "set ::g 5\nset r [expr {$::g + [incr ::g]}]\nputs \"$r $::g\"\n",
4275:         "11 6\n",
4276:     ),
4277:     (
4278:         "proc p {} {global g; set g 1; set r [expr {$g + [incr g]}]; return \"$r $g\"}\nputs [p]\n",
4279:         "3 2\n",
4280:     ),
4281:     (
4282:         "proc p {} {upvar 1 v w; set w 1; set r [expr {$w + [incr w]}]; return \"$r $w\"}\nset v 0\nputs [p]\nputs $v\n",
4283:         "3 2\n2\n",
4284:     ),
4285:     // a write a word's own command makes
4286:     (
4287:         "set s a\nset r [expr {[string length [append s bc]] + [string length $s]}]\nputs \"$r $s\"\n",
4288:         "6 abc\n",
4289:     ),
4290:     (
4291:         "set s a\nset r [expr {[string length $s] + [string length [append s bc]]}]\nputs \"$r $s\"\n",
4292:         "4 abc\n",
4293:     ),
4294:     (
4295:         "set l {}\nset r [expr {[llength [lappend l a]] + [llength $l]}]\nputs \"$r $l\"\n",
4296:         "2 a\n",
4297:     ),
4298:     (
4299:         "set x 5\nset r [expr {$x * [set x 2] + $x}]\nputs \"$r $x\"\n",
4300:         "12 2\n",
4301:     ),
4302:     (
4303:         "set s a\nset r [expr {[string length [append s [append s b]]]}]\nputs \"$r $s\"\n",
4304:         "4 abab\n",
4305:     ),
4306:     (
4307:         "set x 1\nset r [expr {$x} + [incr x]]\nputs \"$r $x\"\n",
4308:         "4 2\n",
4309:     ),
4310:     (
4311:         "unset -nocomplain u\nset r [expr {[string length [append u [set u 3]]]}]\nputs \"$r $u\"\n",
4312:         "2 33\n",
4313:     ),
4314:     // substitutions inside substitutions
4315:     (
4316:         "set x 1\nset r [expr {[expr {$x + [incr x]}] + [incr x]}]\nputs \"$r $x\"\n",
4317:         "6 3\n",
4318:     ),
4319:     (
4320:         "set x 1\nset r [expr {[set y [incr x]] + $y + $x}]\nputs \"$r $x $y\"\n",
4321:         "6 2 2\n",
4322:     ),
4323:     (
4324:         "set x 1\nset r [expr {[incr x] * [incr x] * [incr x]}]\nputs \"$r $x\"\n",
4325:         "24 4\n",
4326:     ),
4327:     // the statements a substitution sits in
4328:     ("set x 1\nexpr {[incr x] + [incr x]}\nputs $x\n", "3\n"),
4329:     (
4330:         "set x 1\nif {[incr x] == 2} { puts yes } else { puts no }\nputs $x\n",
4331:         "yes\n2\n",
4332:     ),
4333:     ("set x 1\nwhile {[incr x] < 5} { }\nputs $x\n", "5\n"),
4334:     (
4335:         "proc p {} {set x 1; return [expr {[incr x] + $x}]}\nputs [p]\n",
4336:         "4\n",
4337:     ),
4338:     (
4339:         "proc p {} {set x 1; set y [expr {[incr x] + $x}]; return \"$y $x\"}\nputs [p]\n",
4340:         "4 2\n",
4341:     ),
4342:     ("set x 1\nputs [expr {$x + [incr x]}]\nputs $x\n", "3\n2\n"),
4343:     (
4344:         "set x 1\nset y [list [expr {[incr x] + 1}] $x]\nputs $y\n",
4345:         "3 2\n",
4346:     ),
4347:     ("set x 1\nputs \"[expr {[incr x] + 1}] $x\"\n", "3 2\n"),
4348:     (
4349:         "set x 1\nset r [expr \"$x + [incr x] + $x\"]\nputs \"$r $x\"\n",
4350:         "5 2\n",
4351:     ),
4352:     (
4353:         "set x 1\nset r [expr {\"$x [incr x]\" eq {1 2}}]\nputs \"$r $x\"\n",
4354:         "1 2\n",
4355:     ),
4356:     // a quoted or unbraced operand
4357:     (
4358:         "set x 1\nset r [expr $x + [incr x]]\nputs \"$r $x\"\n",
4359:         "3 2\n",
4360:     ),
4361:     (
4362:         "set x 1\nset r [expr $x \"+\" [incr x]]\nputs \"$r $x\"\n",
4363:         "3 2\n",
4364:     ),
4365:     (
4366:         "set x 1\nset r [expr {[incr x] + [info exists x]}]\nputs \"$r $x\"\n",
4367:         "3 2\n",
4368:     ),
4369:     (
4370:         "unset -nocomplain x\nset r [expr {[info exists x] + [set x 3]}]\nputs \"$r $x\"\n",
4371:         "3 3\n",
4372:     ),
4373:     (
4374:         "unset -nocomplain x\nset r [expr {[set x 3] + [info exists x]}]\nputs \"$r $x\"\n",
4375:         "4 3\n",
4376:     ),
4377:     // existence
4378:     (
4379:         "set x 1\ncatch {set r [expr {[incr x] + [error mid]}]}\nputs $x\n",
4380:         "2\n",
4381:     ),
4382:     (
4383:         "set x 1\ncatch {set r [expr {1 / 0 + [incr x]}]}\nputs $x\n",
4384:         "1\n",
4385:     ),
4386:     (
4387:         "set x 1\ncatch {set r [expr {[incr x] + 1 / 0}]}\nputs $x\n",
4388:         "2\n",
4389:     ),
4390:     // a value that is not an integer
4391:     (
4392:         "set x 1.5\nset r [expr {$x + [set x 2.5] + $x}]\nputs \"$r $x\"\n",
4393:         "6.5 2.5\n",
4394:     ),
4395: ];
4396: 
4397: /// A write a substitution inside an expression makes is a definition of the
4398: /// statement that holds the expression, made before the statement takes the
4399: /// result: each program prints what tclsh 8.4 to 9.1 print, before and after
4400: /// the optimiser forwards the values the shared lattice now knows. They cover
4401: /// a loop that carries the write round, a branch or a short-circuit that
4402: /// skips it, an element of an array, a place the frame does not own, a write a
4403: /// word's own command makes, a substitution inside a substitution, each kind
4404: /// of statement that holds an expression, an operand that is quoted or
4405: /// unbraced, a place the write creates, and a value that is not an integer.
4406: #[test]
4407: fn a_nested_write_in_a_host_prints_what_tclsh_prints() {
4408:     for &(source, expected) in NESTED_WRITE_PROGRAMS {
4409:         prints_under_every_release(source, expected);
4410:     }
4411: }
4412: 
4413: /// A command the module cannot see — here `foo`, defined at run time from a
4414: /// file the program writes and sources — writes a plain top-level name as it
4415: /// writes `::g` when it runs inside the body of a `catch` the flow graph
4416: /// keeps as one statement, or through a computed head: tclsh 8.4 to 9.1 print
4417: /// `six` and `6` for each program, where taking `5` across the call printed
4418: /// `other` and `5` and a rewrite followed.
4419: #[test]
4420: fn a_write_a_catch_body_or_a_computed_head_runs_is_never_folded_away() {
4421:     let define = "set f [file join [file dirname [info script]] vt-unseen-[pid].tcl]\n\
4422:                   set fh [open $f w]\nputs $fh {proc foo {} {set ::g 6}}\nclose $fh\n\
4423:                   source $f\nfile delete $f\n";
4424:     for tail in [
4425:         "set g 5\ncatch {foo}\nif {$g == 6} {puts six} else {puts other}\nputs $g\n",
4426:         "set g 5\ncatch {foo} msg\nif {$g == 6} {puts six} else {puts other}\nputs $g\n",
4427:         "set g 5\ncatch {if {1} {foo}}\nif {$g == 6} {puts six} else {puts other}\nputs $g\n",
4428:         "set ::g 5\ncatch {foo}\nif {$::g == 6} {puts six} else {puts other}\nputs $::g\n",
4429:         "set g 5\nif {[catch {foo}]} {puts bad}\nif {$g == 6} {puts six} else {puts other}\nputs $g\n",
4430:         "set cmd foo\nset g 5\n$cmd\nif {$g == 6} {puts six} else {puts other}\nputs $g\n",
4431:         "set cmd foo\nset g 5\nwhile {[$cmd] != 7} {break}\nif {$g == 6} {puts six} else {puts other}\nputs $g\n",
4432:     ] {
4433:         prints_under_every_release(&format!("{define}{tail}"), "six\n6\n");
4434:     }
4435:     for tail in [
4436:         "set g 5\ncatch {puts [foo]}\nif {$g == 6} {puts six} else {puts other}\nputs $g\n",
4437:         "set cmd foo\nset g 5\nputs [$cmd]\nif {$g == 6} {puts six} else {puts other}\nputs $g\n",
4438:     ] {
4439:         prints_under_every_release(&format!("{define}{tail}"), "6\nsix\n6\n");
4440:     }
4441:     // A command in the body that may write any name.
4442:     for program in [
4443:         "set go 1\ncatch { namespace eval :: {set go 0} }\nif {$go} {puts a} else {puts b}\n",
4444:         "set go 1\nset script {set go 0}\ncatch { eval $script }\nif {$go} {puts a} else {puts b}\n",
4445:     ] {
4446:         prints_under_every_release(program, "b\n");
4447:     }
4448: }
4449: 
4450: /// A command the module cannot see — `foo` again, defined at run time — runs
4451: /// inside a body that is no body of the frame the substitution is written in:
4452: /// a lambda `apply` runs, a `namespace eval` or `uplevel` body, the text a
4453: /// `subst` substitutes, an expression word inside a body. It writes `::g`
4454: /// there as it does anywhere, so tclsh 8.4 to 9.1 print `six` and `6` for each
4455: /// program, where the value before the call was taken across it and the
4456: /// condition decided. A lambda body that writes a name of its own, and a
4457: /// `subst` of text that runs nothing unseen, leave the condition decided.
4458: #[test]
4459: fn a_substitution_runs_the_unseen_code_in_every_body_it_holds() {
4460:     let define = "set f [file join [file dirname [info script]] vt-unseen-[pid].tcl]\n\
4461:                   set fh [open $f w]\nputs $fh {proc foo {} {set ::g 6}}\nclose $fh\n\
4462:                   source $f\nfile delete $f\n";
4463:     let check = "if {$g == 6} {puts six} else {puts other}\nputs $g\n";
4464:     for form in [
4465:         "set x [namespace eval ns {foo}]",
4466:         "set x [uplevel #0 {foo}]",
4467:         "set x [subst {[foo]}]",
4468:         "set x [catch {expr {[foo] + 1}}]",
4469:         "set x [catch {if {[foo]} {set y 1}}]",
4470:     ] {
4471:         prints_under_every_release(&format!("{define}set g 5\n{form}\n{check}"), "six\n6\n");
4472:     }
4473:     for form in [
4474:         "set x [apply {{} {foo}}]",
4475:         "set x [catch {apply {{} {foo}}}]",
4476:         "set x [apply {{} {if {[foo]} {set y 1}}}]",
4477:         "set x [apply {{n} {foo}} 1]",
4478:     ] {
4479:         prints_under_releases_from(
4480:             &format!("{define}set g 5\n{form}\n{check}"),
4481:             "six\n6\n",
4482:             "8.5",
4483:         );
4484:     }
4485:     // A body with nothing unseen in it leaves the condition decided: the
4486:     // optimiser folds it, and the program prints the same.
4487:     let decided = "set g 5\nset x [namespace eval ns {set y 1}]\n\
4488:                    if {$g == 5} {puts five} else {puts other}\nputs $g\n";
4489:     let lambda = "set g 5\nset x [apply {{} {set y 1}}]\n\
4490:                   if {$g == 5} {puts five} else {puts other}\nputs $g\n";
4491:     let text = "set g 5\nset x [subst {[set y 1]}]\n\
4492:                 if {$g == 5} {puts five} else {puts other}\nputs $g\n";
4493:     for (source, first) in [(decided, "8.4"), (lambda, "8.5"), (text, "8.4")] {
4494:         for dialect in ["tcl8.6", "tcl9.0"] {
4495:             assert!(!optimised(source, dialect).0.contains("other"), "{source}");
4496:         }
4497:         prints_under_releases_from(source, "five\n5\n", first);
4498:     }
4499: }
4500: 
4501: /// A name the body of a `catch` writes on one path only keeps the value it
4502: /// held before, so the store before the `catch` is read: tclsh prints `5` for
4503: /// each program, where taking the body's write as the one every path makes
4504: /// deleted `set g 5` and the read raised `can't read "g"`.
4505: #[test]
4506: fn a_store_a_catch_body_may_leave_untouched_is_not_dead() {
4507:     let top = "set g 5\ncatch { if {[expr {[clock seconds] < 0}]} { set g 0 } }\nputs $g\n";
4508:     let in_proc = "proc p {} {\n set g 5\n catch { if {[expr {[clock seconds] < 0}]} { set g 0 } }\n puts $g\n}\np\n";
4509:     let with_result =
4510:         "set g 5\ncatch { if {[expr {[clock seconds] < 0}]} { set g 0 } } msg\nputs $g\n";
4511:     for dialect in ["tcl8.4", "tcl8.6", "tcl9.0"] {
4512:         for source in [top, in_proc, with_result] {
4513:             assert!(
4514:                 !removes_store(source, dialect, "set g 5"),
4515:                 "{dialect}: {source}"
4516:             );
4517:         }
4518:     }
4519:     for source in [top, in_proc, with_result] {
4520:         prints_under_every_release(source, "5\n");
4521:     }
4522: }
4523: 
4524: /// A program, what tclsh prints for it, and the one condition it holds, if any:
4525: /// its truth, and whether the analysis decides it.
4526: type BodyProgram = (&'static str, &'static str, Option<(bool, bool)>);
4527: 
4528: /// Programs whose `catch` stands in a `[…]` substitution, with what tclsh
4529: /// 8.4 to 9.1 print and the one condition each holds, if any: its truth, and
4530: /// whether the analysis decides it. They are the three of #2231 (the second is
4531: /// the statement form), one in a procedure, a result variable beside the
4532: /// substitution, a `catch` in a `catch`, one reached through an alias of
4533: /// `catch` (whose head the module rebinds, so nothing is decided), and a body
4534: /// that sets a name, unsets one, substitutes a command, or writes through an
4535: /// expression word.
4536: const CATCH_BODY_PROGRAMS: &[BodyProgram] = &[
4537:     (
4538:         "set x 1\nset c [catch {incr x}]\nif {$x == 2} {puts two} else {puts \"not two: $x\"}\n",
4539:         "two\n",
4540:         Some((true, true)),
4541:     ),
4542:     ("set x 5\ncatch {incr x} m\nputs \"$x $m\"\n", "6 6\n", None),
4543:     (
4544:         "set x 1\nset c [catch {append x y}]\nputs $x\n",
4545:         "1y\n",
4546:         None,
4547:     ),
4548:     (
4549:         "proc p {} {\n set x 1\n set c [catch {incr x}]\n if {$x == 2} {return two} else {return other}\n}\nputs [p]\n",
4550:         "two\n",
4551:         Some((true, true)),
4552:     ),
4553:     (
4554:         "set x 5\nputs [catch {incr x} m]\nputs \"$x $m\"\n",
4555:         "0\n6 6\n",
4556:         None,
4557:     ),
4558:     (
4559:         "set x 1\nset c [catch {catch {incr x}}]\nif {$x == 2} {puts two} else {puts other}\n",
4560:         "two\n",
4561:         Some((true, true)),
4562:     ),
4563:     (
4564:         "set g 5\nset rc [catch {set g 0}]\nif {$g} {puts a} else {puts b}\n",
4565:         "b\n",
4566:         Some((false, true)),
4567:     ),
4568:     (
4569:         "set x 1\nputs [catch {unset x}]\nputs [info exists x]\n",
4570:         "0\n0\n",
4571:         None,
4572:     ),
4573:     (
4574:         "set x 1\nputs [catch {expr {[incr x] + [error mid]}}]\nputs $x\n",
4575:         "1\n2\n",
4576:         None,
4577:     ),
4578:     (
4579:         "set x 5\nset c [catch {puts $x}]\nputs $c\n",
4580:         "5\n0\n",
4581:         None,
4582:     ),
4583:     ("set x 5\nset c [catch {incr x}]\nputs $c\n", "0\n", None),
4584:     (
4585:         "set x 1\nset c [catch {set y [incr x]}]\nif {$x == 2} {puts two} else {puts other}\n",
4586:         "two\n",
4587:         Some((true, true)),
4588:     ),
4589:     (
4590:         "interp alias {} c {} catch\nset x 1\nset r [c {incr x}]\n\
4591:          if {$x == 2} {puts two} else {puts other}\n",
4592:         "two\n",
4593:         Some((true, false)),
4594:     ),
4595: ];
4596: 
4597: /// The truths the diagnostics claim for the conditions of `source` under
4598: /// `dialect`: `true` for an `if` that is always true, `false` for one that
4599: /// is always false.
4600: fn condition_claims(source: &str, dialect: &str) -> Vec<bool> {
4601:     tcl_compiler::analyser::Analyser::new()
4602:         .analyse(source, dialect)
4603:         .diagnostics
4604:         .iter()
4605:         .filter(|diagnostic| diagnostic.code == DiagCode::I230)
4606:         .filter_map(|diagnostic| {
4607:             if diagnostic.message.contains("is always true") {
4608:                 Some(true)
4609:             } else if diagnostic.message.contains("is always false") {
4610:                 Some(false)
4611:             } else {
4612:                 None
4613:             }
4614:         })
4615:         .collect()
4616: }
4617: 
4618: /// The body of a `catch`, or of a `try`, inside a `[…]` substitution runs once
4619: /// in the frame the substitution is written in, whatever it completes with,
4620: /// so what it writes and what it reads are the statement's own effect: the
4621: /// writes are definitions after the statement and the reads are uses of the
4622: /// definitions before it (#2231). Each program prints what it did before the
4623: /// multipass optimiser rewrote it — where the lattice held the value before
4624: /// the body, the stores the body reads were deleted — and the condition it
4625: /// holds is claimed by no diagnostic but with the truth tclsh gives it; a
4626: /// closed body under the builtin head decides it. A `try` body does the same
4627: /// from 8.6.
4628: #[test]
4629: fn a_nested_catch_body_is_the_statements_effect() {
4630:     for &(source, expected, condition) in CATCH_BODY_PROGRAMS {
4631:         prints_under_every_release(source, expected);
4632:         let truth = condition.map(|(truth, _)| truth);
4633:         for dialect in DIALECTS {
4634:             assert!(
4635:                 condition_claims(source, dialect)
4636:                     .iter()
4637:                     .all(|claimed| Some(*claimed) == truth),
4638:                 "{dialect}: a condition is decided as tclsh does not:\n{source}"
4639:             );
4640:             for store in ["set x 1", "set x 5"] {
4641:                 if source.contains(store) {
4642:                     assert!(
4643:                         !removes_store(source, dialect, store),
4644:                         "{dialect}: {store} is read:\n{source}"
4645:                     );
4646:                 }
4647:             }
4648:         }
4649:         for dialect in ["tcl8.6", "tcl9.0"] {
4650:             let decided = condition
4651:                 .filter(|(_, decided)| *decided)
4652:                 .map(|(truth, _)| truth);
4653:             assert_eq!(
4654:                 condition_claims(source, dialect),
4655:                 decided.into_iter().collect::<Vec<_>>(),
4656:                 "{dialect}: the condition is decided exactly where the body is closed:\n{source}"
4657:             );
4658:         }
4659:     }
4660:     let in_try = "set x 1\nset r [try {incr x} on error {} {set y 0}]\n\
4661:                   if {$x == 2} {puts two} else {puts other}\n";
4662:     prints_under_releases_from(in_try, "two\n", "8.6");
4663:     for dialect in ["tcl8.6", "tcl9.0"] {
4664:         assert!(
4665:             condition_claims(in_try, dialect)
4666:                 .iter()
4667:                 .all(|claimed| *claimed),
4668:             "{dialect}"
4669:         );
4670:     }
4671: }
4672: 
4673: /// The scripts of the `catch` code table that read nothing the program has
4674: /// not set, with what the result variable holds after `catch {script} m`
4675: /// under tclsh 8.4 to 9.1.
4676: const CATCH_RESULTS: &[(&str, &str)] = &[
4677:     ("error boom", "boom"),
4678:     ("return 5", "5"),
4679:     ("break", ""),
4680:     ("continue", ""),
4681:     ("set v 1", "1"),
4682:     ("expr {1/0}", "divide by zero"),
4683:     ("set y 5; error $y", "5"),
4684:     ("set y 5; set z $y; error $z", "5"),
4685:     ("error a; error b", "a"),
4686:     ("", ""),
4687:     ("catch {error z}", "1"),
4688:     ("set x 1; incr x", "2"),
4689:     ("string length abc", "3"),
4690: ];
4691: 
4692: /// A closed `catch` — brace-quoted, every command with a route of its own and
4693: /// every value exact — is evaluated to the code and the result its script
4694: /// completes with, so the result variable holds what the script returned: the
4695: /// last command's result, the message of the error it stopped at (the first
4696: /// completion that is not a normal one ends the script, whatever follows), or
4697: /// what `return` carried. The lattice holds it, the optimiser forwards it, and
4698: /// tclsh 8.4 to 9.1 print the same before and after.
4699: ///
4700: /// What the program does not prove stays unknown — an error whose message
4701: /// reads a variable never set — and the variable is still bound.
4702: #[test]
4703: fn a_closed_catch_script_gives_its_result_variable_what_it_returned() {
4704:     for &(script, expected) in CATCH_RESULTS {
4705:         let source = format!("catch {{{script}}} m\nputs \"<$m>\"\n");
4706:         for dialect in DIALECTS {
4707:             let unit = unit_of(&source, dialect);
4708:             assert_eq!(
4709:                 top_value_at(&unit, "m", 1).and_then(lattice_text),
4710:                 Some(expected.to_owned()),
4711:                 "{dialect}: {source}"
4712:             );
4713:             let (rewritten, _) = optimised(&source, dialect);
4714:             assert!(
4715:                 rewritten.contains(&format!("puts \"<{expected}>\"")),
4716:                 "{dialect}:\n{rewritten}"
4717:             );
4718:         }
4719:         prints_under_every_release(&source, &format!("<{expected}>\n"));
4720:     }
4721: 
4722:     let unknown = "catch {error $nothing} m\nputs \"<$m>\"\n";
4723:     for dialect in DIALECTS {
4724:         assert_eq!(
4725:             top_value_at(&unit_of(unknown, dialect), "m", 1),
4726:             Some(LatticeValue::Overdefined),
4727:             "{dialect}"
4728:         );
4729:         let unbound_reads: Vec<String> = tcl_compiler::analyser::Analyser::new()
4730:             .analyse(unknown, dialect)
4731:             .diagnostics
4732:             .iter()
4733:             .filter(|diagnostic| diagnostic.code == DiagCode::W210)
4734:             .map(|diagnostic| diagnostic.message.clone())
4735:             .collect();
4736:         assert!(
4737:             unbound_reads.iter().all(|message| !message.contains("'m'")),
4738:             "{dialect}: the result variable is bound: {unbound_reads:?}"
4739:         );
4740:     }
4741:     prints_under_every_release(unknown, "<can't read \"nothing\": no such variable>\n");
4742: 
4743:     // A script that is not brace-quoted text is not known: `"error $e"` runs
4744:     // `error a b`, whose message is `a`, where its spelling would give `a b`.
4745:     let quoted = "set e {a b}\ncatch \"error $e\" m\nputs \"<$m>\"\n";
4746:     for dialect in DIALECTS {
4747:         assert_eq!(
4748:             top_value_at(&unit_of(quoted, dialect), "m", 1),
4749:             Some(LatticeValue::Overdefined),
4750:             "{dialect}"
4751:         );
4752:     }
4753:     prints_under_every_release(quoted, "<a>\n");
4754: }
4755: 
4756: /// A word of a command inside a `catch` script that raises is the script's
4757: /// error, which the `catch` absorbs: the statement itself does not raise, so
4758: /// what follows it in a `try` body runs. tclsh 8.6 to 9.1 print `1`; taking
4759: /// the word's error for the statement's ended the block and folded `after` to
4760: /// the handler's `0`.
4761: #[test]
4762: fn an_error_a_catch_script_raises_is_not_the_statements_own() {
4763:     // The script's `return` keeps the `catch` one opaque call, and without it
4764:     // the script is lowered into the procedure's blocks.
4765:     for script in ["set a [error boom]; return x", "set a [error boom]"] {
4766:         let source = format!(
4767:             "proc p {{}} {{\n    try {{\n        catch {{{script}}} m\n        \
4768:              set after 1\n    }} on error {{}} {{\n        set after 0\n    }}\n    \
4769:              return $after\n}}\nputs [p]\n"
4770:         );
4771:         prints_under_releases_from(&source, "1\n", "8.6");
4772:         let unit = unit_of(&source, "tcl8.6");
4773:         let function = unit
4774:             .procedures
4775:             .get(&fixture_id(&unit.procedures, "::p"))
4776:             .expect("the procedure");
4777:         let executable: Vec<&str> = function
4778:             .sccp
4779:             .executable_blocks
4780:             .iter()
4781:             .filter_map(|id| function.cfg.blocks.get(id))
4782:             .map(|block| block.name.as_str())
4783:             .collect();
4784:         assert!(
4785:             executable.iter().any(|name| name.starts_with("try_ok")),
4786:             "the body completes normally: {executable:?}"
4787:         );
4788:     }
4789: }
4790: 
4791: /// A result the program does not prove is still bound, and the options
4792: /// dictionary beside it is a dictionary whose text the analysis never has:
4793: /// `catch {error $x} m o` evaluates to the code 1, binds `m` as a string and
4794: /// `o` as a dictionary, each with a value that is not available, and draws
4795: /// no W210 where they are read.
4796: #[test]
4797: fn an_unproven_result_and_the_options_dictionary_are_bound_and_typed() {
4798:     use tcl_compiler::value_transfer::FoldedType;
4799:     use tcl_registry::TclType;
4800:     use tcl_registry::value_transfer::RepresentationEvidence;
4801:     let source = "proc p {x} {\n    catch {error $x} m o\n    return [list $m $o]\n}\n";
4802:     let stated = |ty| {
4803:         Some(FoldedType {
4804:             intrep: Some(ty),
4805:             shape: None,
4806:             representation: RepresentationEvidence::Unknown,
4807:         })
4808:     };
4809:     for dialect in ["tcl8.5", "tcl8.6", "tcl9.0"] {
4810:         let unit = unit_of(source, dialect);
4811:         for var in ["m", "o"] {
4812:             assert_eq!(
4813:                 value_at(&unit, "::p", var, 1),
4814:                 Some(LatticeValue::Overdefined),
4815:                 "{dialect}: {var}"
4816:             );
4817:         }
4818:         assert_eq!(folded_at(&unit, "::p", "m", 1), stated(TclType::String));
4819:         assert_eq!(folded_at(&unit, "::p", "o", 1), stated(TclType::Dict));
4820:         assert_eq!(answers_for(&unit, "::p", "catch"), ["evaluated"]);
4821:         assert!(!reports(source, dialect, DiagCode::W210), "{dialect}");
4822:     }
4823: }
4824: 
4825: /// The options dictionary of a `catch` starts `-code N -level L` for every
4826: /// completion but an error (`error msg info code` lists `-errorinfo` first),
4827: /// so that is all the route states of its text: tclsh 8.5 to 9.1 give each
4828: /// row below that prefix. It is never an exact value, because a success is
4829: /// not always `-code 0 -level 0` alone: from 8.6 `incr` and `lappend` of an
4830: /// absent variable leave a stale `-errorcode {TCL READ VARNAME}` in the
4831: /// options of a normal completion, and `-errorinfo`, `-errorline` and
4832: /// `-errorstack` are the interpreter's own text.
4833: #[test]
4834: fn the_options_dictionary_starts_with_the_code_and_level_the_route_states() {
4835:     let rows = [
4836:         ("set v 1", "-code 0 -level 0"),
4837:         ("return 5", "-code 0 -level 1"),
4838:         ("break", "-code 3 -level 0"),
4839:         ("continue", "-code 4 -level 0"),
4840:         ("return -code 5 custom", "-code 5 -level 1"),
4841:         ("incr absent", "-code 0 -level 0"),
4842:         ("lappend absent x", "-code 0 -level 0"),
4843:     ];
4844:     let stale = "catch {incr absent} m o\nputs $o\n";
4845:     let mut ran = 0;
4846:     for (series, tclsh) in releases_on_path() {
4847:         if series < "8.5" {
4848:             continue;
4849:         }
4850:         ran += 1;
4851:         for (script, prefix) in rows {
4852:             let program = format!(
4853:                 "catch {{{script}}} m o\nputs [expr {{[string first {{{prefix}}} $o] == 0}}]\n"
4854:             );
4855:             assert_eq!(
4856:                 run_script(&tclsh, &program),
4857:                 Some((true, "1\n".to_owned())),
4858:                 "tclsh{series}: {program}"
4859:             );
4860:         }
4861:         let expected = if series >= "8.6" {
4862:             "-code 0 -level 0 -errorcode {TCL READ VARNAME}\n"
4863:         } else {
4864:             "-code 0 -level 0\n"
4865:         };
4866:         assert_eq!(
4867:             run_script(&tclsh, stale),
4868:             Some((true, expected.to_owned())),
4869:             "tclsh{series}"
4870:         );
4871:     }
4872:     assert!(ran > 0 || releases_on_path().is_empty());
4873:     let source = "proc p {} {\n    catch {incr absent} m o\n    return $o\n}\n";
4874:     for dialect in ["tcl8.5", "tcl8.6", "tcl9.0"] {
4875:         assert_eq!(
4876:             value_at(&unit_of(source, dialect), "::p", "o", 1),
4877:             Some(LatticeValue::Overdefined),
4878:             "{dialect}"
4879:         );
4880:     }
4881: }
4882: 
4883: /// Programs whose `catch`, or `try`, runs a script that is not brace-quoted
4884: /// text, in a substitution, with what tclsh prints and the first release that
4885: /// has the command: a quoted word that substitutes nothing, a script held in a
4886: /// variable, a quoted word that substitutes, one with an escape, one that
4887: /// writes what the script reads, a `catch` in a `catch`, a condition, and a
4888: /// `try` body.
4889: const UNBRACED_SCRIPT_PROGRAMS: &[(&str, &str, &str)] = &[
4890:     (
4891:         "set x 1\nset c [catch \"incr x\"]\nif {$x == 2} {puts two} else {puts other}\n",
4892:         "two\n",
4893:         "8.4",
4894:     ),
4895:     (
4896:         "set x 1\nset c [catch \"incr x; set y 2\" m]\nif {$x == 2} {puts two} else {puts other}\n",
4897:         "two\n",
4898:         "8.4",
4899:     ),
4900:     (
4901:         "proc p {} {\n    set x 1\n    set c [catch \"incr x\"]\n    \
4902:          if {$x == 2} {return two} else {return other}\n}\nputs [p]\n",
4903:         "two\n",
4904:         "8.4",
4905:     ),
4906:     (
4907:         "set x 1\nset s {incr x}\nset c [catch $s]\nif {$x == 2} {puts two} else {puts other}\n",
4908:         "two\n",
4909:         "8.4",
4910:     ),
4911:     (
4912:         "proc p {} {\n    set x 1\n    set s {incr x}\n    set c [catch $s]\n    \
4913:          if {$x == 2} {return two} else {return other}\n}\nputs [p]\n",
4914:         "two\n",
4915:         "8.4",
4916:     ),
4917:     (
4918:         "proc p {} {\n    set x 1\n    set v x\n    set c [catch \"incr $v\"]\n    \
4919:          if {$x == 2} {return two} else {return other}\n}\nputs [p]\n",
4920:         "two\n",
4921:         "8.4",
4922:     ),
4923:     (
4924:         "proc p {} {\n    set x 1\n    set c [catch \"incr x\\n\"]\n    \
4925:          if {$x == 2} {return two} else {return other}\n}\nputs [p]\n",
4926:         "two\n",
4927:         "8.4",
4928:     ),
4929:     (
4930:         "proc p {} {\n    set x 1\n    set c [catch \"catch {incr x}\"]\n    \
4931:          if {$x == 2} {return two} else {return other}\n}\nputs [p]\n",
4932:         "two\n",
4933:         "8.4",
4934:     ),
4935:     (
4936:         "proc p {} {\n    set x 1\n    set s {incr x}\n    if {[catch $s]} {puts bad}\n    \
4937:          if {$x == 2} {return two} else {return other}\n}\nputs [p]\n",
4938:         "two\n",
4939:         "8.4",
4940:     ),
4941:     (
4942:         "proc p {} {\n    set x 1\n    if {[catch \"incr x\"]} {puts bad}\n    \
4943:          if {$x == 2} {return two} else {return other}\n}\nputs [p]\n",
4944:         "two\n",
4945:         "8.4",
4946:     ),
4947:     (
4948:         "proc p {} {\n    set a 1\n    set b 1\n    set c [catch \"incr a; incr b\"]\n    \
4949:          return \"$a$b\"\n}\nputs [p]\n",
4950:         "22\n",
4951:         "8.4",
4952:     ),
4953:     (
4954:         "set x 5\nset s {puts $x}\nset c [catch $s]\nputs $c\n",
4955:         "5\n0\n",
4956:         "8.4",
4957:     ),
4958:     (
4959:         "proc p {} {\n    set x 1\n    set r [try \"incr x\" on error {} {}]\n    \
4960:          if {$x == 2} {return two} else {return other}\n}\nputs [p]\n",
4961:         "two\n",
4962:         "8.6",
4963:     ),
4964:     (
4965:         "proc p {} {\n    set x 1\n    set s {incr x}\n    set r [try $s on error {} {}]\n    \
4966:          if {$x == 2} {return two} else {return other}\n}\nputs [p]\n",
4967:         "two\n",
4968:         "8.6",
4969:     ),
4970: ];
4971: 
4972: /// A script a substitution runs in this frame, once, whatever it completes
4973: /// with, is the statement's effect wherever its text is known: a quoted word
4974: /// that substitutes nothing is read as the brace-quoted one is, and a script
4975: /// that is run-time data — held in a variable, substituted, escaped, expanded
4976: /// — may write any name, so nothing after the statement is decided on a value
4977: /// from before it, as after the statement form's barrier. Each program prints
4978: /// what tclsh prints, before and after the optimiser; no diagnostic decides
4979: /// its condition as tclsh does not, and the store a script reads stays.
4980: #[test]
4981: fn a_quoted_or_computed_script_is_the_statements_effect() {
4982:     for &(source, expected, first) in UNBRACED_SCRIPT_PROGRAMS {
4983:         prints_under_releases_from(source, expected, first);
4984:         let dialects: &[&str] = if first == "8.4" {
4985:             &DIALECTS
4986:         } else {
4987:             &["tcl8.6", "tcl9.0"]
4988:         };
4989:         for &dialect in dialects {
4990:             assert!(
4991:                 condition_claims(source, dialect)
4992:                     .iter()
4993:                     .all(|claimed| *claimed),
4994:                 "{dialect}: a condition is decided as tclsh does not:\n{source}"
4995:             );
4996:         }
4997:     }
4998:     let reads = "set x 5\nset s {puts $x}\nset c [catch $s]\nputs $c\n";
4999:     for dialect in DIALECTS {
5000:         assert!(
5001:             !removes_store(reads, dialect, "set x 5"),
5002:             "{dialect}: the script reads x"
5003:         );
5004:     }
5005: }
5006: 
5007: /// The rows of the `catch` code table that read nothing the program has not
5008: /// set: the script, the code `catch` returns for it and what its result
5009: /// variable holds, the same under tclsh 8.4 to 9.1. `return -code 5 custom`
5010: /// completes with the code 2 where it stands in a `catch` — the code 5 is the
5011: /// one a procedure's caller sees.
5012: const CATCH_CODES: &[(&str, i64, &str)] = &[
5013:     ("return 5", 2, "5"),
5014:     ("break", 3, ""),
5015:     ("continue", 4, ""),
5016:     ("error boom", 1, "boom"),
5017:     ("set v 1", 0, "1"),
5018:     ("expr {1/0}", 1, "divide by zero"),
5019:     ("return -code 5 custom", 2, "custom"),
5020:     ("string length abc", 0, "3"),
5021: ];
5022: 
5023: /// The program one row of the code table runs: a procedure that keeps the
5024: /// code of a `catch` in a substitution and the result beside it, and prints
5025: /// both.
5026: fn catch_program(script: &str) -> String {
5027:     format!("proc p {{}} {{\n    set c [catch {{{script}}} m]\n    puts \"$c|$m\"\n}}\np\n")
5028: }
5029: 
5030: /// The rows every release reads alike, under each release's dialect and the
5031: /// `tcl` profile that spans them: the code, the result, the `evaluated`
5032: /// answer and the optimiser's forwarding, and the lines tclsh 8.4 to 9.1
5033: /// print before and after.
5034: fn the_catch_rows_every_release_reads_alike() {
5035:     for &(script, code, result) in CATCH_CODES {
5036:         let source = catch_program(script);
5037:         for dialect in RELEASE_DIALECTS {
5038:             let unit = unit_of(&source, dialect);
5039:             assert_eq!(
5040:                 value_at(&unit, "::p", "c", 1),
5041:                 Some(LatticeValue::Const(ConstValue::Int(code))),
5042:                 "{dialect}: the code of {script}"
5043:             );
5044:             assert_eq!(
5045:                 value_at(&unit, "::p", "m", 1).and_then(lattice_text),
5046:                 Some(result.to_owned()),
5047:                 "{dialect}: the result of {script}"
5048:             );
5049:             assert_eq!(
5050:                 answers_for(&unit, "::p", "catch"),
5051:                 ["evaluated"],
5052:                 "{dialect}: {script}"
5053:             );
5054:             let (rewritten, _) = optimised(&source, dialect);
5055:             assert!(
5056:                 rewritten.contains(&format!("{code}|{result}")),
5057:                 "{dialect}: {script} is forwarded:\n{rewritten}"
5058:             );
5059:         }
5060:         prints_under_every_release(&source, &format!("{code}|{result}\n"));
5061:     }
5062: }
5063: 
5064: /// `catch {incr absent}`: the error of 8.4 and of the iRules dialect on its
5065: /// 8.4 base, the created cell from 8.5, and nothing under the spanning
5066: /// profile, which cannot say which release runs.
5067: fn the_catch_row_that_splits_on_an_absent_cell() {
5068:     let absent = catch_program("incr absent");
5069:     let message = "can't read \"absent\": no such variable";
5070:     let created = Some((0, "1"));
5071:     let raised = Some((1, message));
5072:     for (dialect, expected) in [
5073:         ("tcl8.4", raised),
5074:         ("f5-irules", raised),
5075:         ("tcl8.5", created),
5076:         ("tcl8.6", created),
5077:         ("tcl9.0", created),
5078:         ("tcl9.1", created),
5079:         ("tcl", None),
5080:     ] {
5081:         let unit = unit_of(&absent, dialect);
5082:         let code_fact = value_at(&unit, "::p", "c", 1);
5083:         let result_fact = value_at(&unit, "::p", "m", 1).and_then(lattice_text);
5084:         if let Some((code, result)) = expected {
5085:             assert_eq!(
5086:                 code_fact,
5087:                 Some(LatticeValue::Const(ConstValue::Int(code))),
5088:                 "{dialect}: the code"
5089:             );
5090:             assert_eq!(
5091:                 result_fact.as_deref(),
5092:                 Some(result),
5093:                 "{dialect}: the result"
5094:             );
5095:         } else {
5096:             assert_eq!(code_fact, Some(LatticeValue::Overdefined), "{dialect}");
5097:             assert_eq!(result_fact, None, "{dialect}");
5098:         }
5099:     }
5100:     for (series, tclsh) in releases_on_path() {
5101:         let expected = if series == "8.4" {
5102:             format!("1|{message}\n")
5103:         } else {
5104:             "0|1\n".to_owned()
5105:         };
5106:         for text in [absent.clone(), optimised(&absent, &dialect_of(series)).0] {
5107:             assert_eq!(
5108:                 run_script(&tclsh, &text),
5109:                 Some((true, expected.clone())),
5110:                 "tclsh{series}:\n{text}"
5111:             );
5112:         }
5113:     }
5114: }
5115: 
5116: /// A `catch` in a `[…]` substitution — where the code is the value of the
5117: /// statement and the message or result a variable beside it — is evaluated to
5118: /// the code its script completes with: the code table, forwarded by the
5119: /// optimiser and printed by tclsh 8.4 to 9.1 before and after, with the
5120: /// release split of `incr` on a cell that is absent as the one row that
5121: /// differs. A procedure's own completion is a callee's summary, so `catch
5122: /// {q}` over a `proc q {} {return -code 5 custom}` states nothing of the code
5123: /// 5 tclsh prints.
5124: #[test]
5125: fn the_catch_code_table() {
5126:     the_catch_rows_every_release_reads_alike();
5127:     the_catch_row_that_splits_on_an_absent_cell();
5128:     let callee = "proc q {} {return -code 5 custom}\n\
5129:                   proc p {} {\n    set c [catch {q} m]\n    puts \"$c|$m\"\n}\np\n";
5130:     for dialect in RELEASE_DIALECTS {
5131:         assert_eq!(
5132:             value_at(&unit_of(callee, dialect), "::p", "c", 1),
5133:             Some(LatticeValue::Overdefined),
5134:             "{dialect}"
5135:         );
5136:     }
5137:     prints_under_every_release(callee, "5|custom\n");
5138: }
5139: 
5140: /// A script that is not brace-quoted text is not known: `"error $e"` runs
5141: /// `error a b`, whose message is `a`, where its spelling would give `a b`. A
5142: /// `catch` in a substitution has no barrier ahead of it, so the script word is
5143: /// the only thing between the lattice and a message that was never raised:
5144: /// the result and the code stay unknown under every dialect, and tclsh 8.4 to
5145: /// 9.1 print `1|a`.
5146: #[test]
5147: fn a_catch_script_that_is_not_brace_quoted_text_is_not_the_script_it_runs() {
5148:     let quoted = "proc p {} {\n    set e {a b}\n    set c [catch \"error $e\" m]\n    \
5149:                   puts \"$c|$m\"\n}\np\n";
5150:     for dialect in RELEASE_DIALECTS {
5151:         let unit = unit_of(quoted, dialect);
5152:         for var in ["c", "m"] {
5153:             assert_eq!(
5154:                 value_at(&unit, "::p", var, 1),
5155:                 Some(LatticeValue::Overdefined),
5156:                 "{dialect}: {var}"
5157:             );
5158:         }
5159:     }
5160:     prints_under_every_release(quoted, "1|a\n");
5161: }
5162: 
5163: /// A command substitution that is the whole value of a statement is run in
5164: /// order with its own writes whichever registry-owned route the command
5165: /// declares: the statement's call holds what the command stored and the
5166: /// statement what it returned, so `set a [incr n]` leaves `n` 2 as well as
5167: /// `a`. Each program prints what tclsh 8.5 to 9.1 print before and after the
5168: /// optimiser, and the values the lattice holds are the ones printed.
5169: #[test]
5170: fn a_command_substitution_lands_its_writes_beside_its_result() {
5171:     type Program = (
5172:         &'static str,
5173:         &'static str,
5174:         &'static [(&'static str, &'static str)],
5175:     );
5176:     let programs: [Program; 7] = [
5177:         (
5178:             "proc p {} {set n 1; set a [incr n]; return \"$a $n\"}\nputs [p]\n",
5179:             "2 2\n",
5180:             &[("a", "2"), ("n", "2")],
5181:         ),
5182:         (
5183:             "proc p {} {set a [set b 5]; return \"$a $b\"}\nputs [p]\n",
5184:             "5 5\n",
5185:             &[("a", "5"), ("b", "5")],
5186:         ),
5187:         (
5188:             "proc p {} {set s abc; set a [append s def]; return \"$a|$s\"}\nputs [p]\n",
5189:             "abcdef|abcdef\n",
5190:             &[("a", "abcdef"), ("s", "abcdef")],
5191:         ),
5192:         (
5193:             "proc p {} {set l {}; set a [lappend l x y]; return \"$a|$l\"}\nputs [p]\n",
5194:             "x y|x y\n",
5195:             &[("a", "x y"), ("l", "x y")],
5196:         ),
5197:         (
5198:             "proc p {} {set a [scan {7 8} {%d %d} x y]; return \"$a $x $y\"}\nputs [p]\n",
5199:             "2 7 8\n",
5200:             &[("a", "2"), ("x", "7"), ("y", "8")],
5201:         ),
5202:         (
5203:             "proc p {} {set a [lassign {1 2 3} u v]; return \"$a|$u|$v\"}\nputs [p]\n",
5204:             "3|1|2\n",
5205:             &[("a", "3"), ("u", "1"), ("v", "2")],
5206:         ),
5207:         (
5208:             "proc p {} {set d {}; set a [dict set d k v]; return \"$a|$d\"}\nputs [p]\n",
5209:             "k v|k v\n",
5210:             &[("a", "k v"), ("d", "k v")],
5211:         ),
5212:     ];
5213:     for (source, expected, last) in programs {
5214:         for dialect in ["tcl8.6", "tcl9.0"] {
5215:             for &(var, text) in last {
5216:                 assert_eq!(
5217:                     lattice_text(last_value(source, dialect, "::p", var)).as_deref(),
5218:                     Some(text),
5219:                     "{dialect}: {var} after\n{source}"
5220:                 );
5221:             }
5222:         }
5223:         prints_under_releases_from(source, expected, "8.5");
5224:     }
5225: }
5226: 
5227: /// The scripts of a procedure's `catch` that are straight-line statements —
5228: /// which the flow graph lowers into blocks, ending at a statement that defines
5229: /// the result variable — with what the result variable holds after `catch
5230: /// {script} m` under tclsh 8.4 to 9.1.
5231: const FLATTENED_CATCH_RESULTS: &[(&str, &str)] = &[
5232:     ("set v 1", "1"),
5233:     ("expr {1/0}", "divide by zero"),
5234:     ("set y 5; set z $y", "5"),
5235:     ("string length abc", "3"),
5236:     ("set x 1; incr x", "2"),
5237:     ("set v [string length abc]; set w [expr {$v * 2}]", "6"),
5238: ];
5239: 
5240: /// The number of flattened `catch` regions of `proc`.
5241: fn flattened_catches(unit: &CompilationUnit, proc: &str) -> usize {
5242:     unit.procedures
5243:         .get(&fixture_id(&unit.procedures, proc))
5244:         .expect("the procedure")
5245:         .cfg
5246:         .catch_ends
5247:         .len()
5248: }
5249: 
5250: /// A `catch` the flow graph flattens into the procedure's blocks has no words
5251: /// where its region ends: the statement there only defines the result and
5252: /// options variables. The graph keeps the `catch` as written beside it, and
5253: /// the solver evaluates it as it does the statement the graph leaves whole,
5254: /// so the result variable holds what the script returned — the last
5255: /// command's result, or the message of the error it stopped at — under every
5256: /// dialect. The lattice holds it, the optimiser forwards it, and tclsh 8.4 to
5257: /// 9.1 print the same before and after.
5258: #[test]
5259: fn a_flattened_catch_gives_its_result_variable_what_its_script_returned() {
5260:     for &(script, expected) in FLATTENED_CATCH_RESULTS {
5261:         let source =
5262:             format!("proc p {{}} {{\n    catch {{{script}}} m\n    puts \"<$m>\"\n}}\np\n");
5263:         for dialect in DIALECTS {
5264:             let unit = unit_of(&source, dialect);
5265:             assert_eq!(flattened_catches(&unit, "::p"), 1, "{dialect}: {source}");
5266:             assert_eq!(
5267:                 value_at(&unit, "::p", "m", 1).and_then(lattice_text),
5268:                 Some(expected.to_owned()),
5269:                 "{dialect}: {source}"
5270:             );
5271:             assert_eq!(
5272:                 answers_for(&unit, "::p", "catch"),
5273:                 ["evaluated"],
5274:                 "{dialect}: {source}"
5275:             );
5276:             let (rewritten, _) = optimised(&source, dialect);
5277:             assert!(
5278:                 rewritten.contains(&format!("puts \"<{expected}>\"")),
5279:                 "{dialect}:\n{rewritten}"
5280:             );
5281:         }
5282:         prints_under_every_release(&source, &format!("<{expected}>\n"));
5283:     }
5284: }
5285: 
5286: /// The script of a flattened `catch` runs over the state before its body, not
5287: /// the state where its region ends, where its own writes have already been
5288: /// made: over `x` = 1, `catch {incr x} m` leaves `m` 2 and `x` 2, where the
5289: /// state after the body would give 3. A script that reads what it writes
5290: /// finds it as it was, and a result variable the body also writes is stored
5291: /// last. tclsh 8.4 to 9.1 print what the analysis holds, before and after the
5292: /// optimiser.
5293: #[test]
5294: fn a_flattened_catch_runs_its_script_over_the_state_before_it() {
5295:     let int = |n: i64| Some(LatticeValue::Const(ConstValue::Int(n)));
5296:     let programs: [(&str, &str, i64); 4] = [
5297:         (
5298:             "proc p {} {\n    set x 1\n    catch {incr x} m\n    puts \"$m|$x\"\n}\np\n",
5299:             "2|2\n",
5300:             2,
5301:         ),
5302:         (
5303:             "proc p {} {\n    set x 1\n    catch {incr x; incr x} m\n    puts \"$m|$x\"\n}\np\n",
5304:             "3|3\n",
5305:             3,
5306:         ),
5307:         (
5308:             "proc p {} {\n    set x 1\n    catch {set x [expr {$x + 10}]; set x} m\n    \
5309:              puts \"$m|$x\"\n}\np\n",
5310:             "11|11\n",
5311:             11,
5312:         ),
5313:         (
5314:             "proc p {} {\n    catch {set m 5} m\n    puts $m\n}\np\n",
5315:             "5\n",
5316:             5,
5317:         ),
5318:     ];
5319:     for (source, printed, result) in programs {
5320:         for dialect in ["tcl8.6", "tcl9.0"] {
5321:             let unit = unit_of(source, dialect);
5322:             assert_eq!(flattened_catches(&unit, "::p"), 1, "{dialect}: {source}");
5323:             assert_eq!(
5324:                 Some(last_value(source, dialect, "::p", "m")),
5325:                 int(result),
5326:                 "{dialect}: m in\n{source}"
5327:             );
5328:         }
5329:         prints_under_every_release(source, printed);
5330:     }
5331: }
5332: 
5333: /// What a flattened `catch` cannot prove stays unknown, and the variables it
5334: /// defines stay bound: a script that raises from a word it substitutes, a
5335: /// parameter the procedure was called with, and a result variable a write
5336: /// trace watches. Each program prints under tclsh 8.4 to 9.1 what the
5337: /// original prints, before and after the optimiser.
5338: #[test]
5339: fn a_flattened_catch_the_solver_cannot_prove_stays_unknown() {
5340:     let programs = [
5341:         (
5342:             "proc p {} {\n    catch {puts $undefined} m\n    puts \"<$m>\"\n}\np\n",
5343:             "<can't read \"undefined\": no such variable>\n",
5344:             "8.4",
5345:         ),
5346:         (
5347:             "proc p {x} {\n    catch {incr x} m\n    return \"$m|$x\"\n}\nputs [p 5]\nputs [p abc]\n",
5348:             "6|6\nexpected integer but got \"abc\"|abc\n",
5349:             "8.4",
5350:         ),
5351:         (
5352:             "proc tr {args} {puts T}\nproc p {} {\n    trace add variable m write tr\n    \
5353:              catch {set v 1} m\n    puts $m\n}\np\n",
5354:             "T\n1\n",
5355:             "8.5",
5356:         ),
5357:     ];
5358:     for (source, printed, first) in programs {
5359:         let dialects: &[&str] = if first == "8.4" {
5360:             &DIALECTS
5361:         } else {
5362:             &["tcl8.6", "tcl9.0"]
5363:         };
5364:         for &dialect in dialects {
5365:             let unit = unit_of(source, dialect);
5366:             assert_eq!(
5367:                 value_at(&unit, "::p", "m", 1),
5368:                 Some(LatticeValue::Overdefined),
5369:                 "{dialect}: {source}"
5370:             );
5371:         }
5372:         prints_under_releases_from(source, printed, first);
5373:     }
5374: }
5375: 
5376: /// `catch` stores the value of its script's last command in the result
5377: /// variable, so a flattened body's last store is observed where the region
5378: /// ends: deleting it as a store nothing reads changes what the result variable
5379: /// holds. Each program prints under tclsh 8.4 to 9.1 what the original prints,
5380: /// before and after the optimiser, with the store still there — where the
5381: /// result is not one the lattice proves, a parameter, a global, a place a
5382: /// `catch` in a branch or an `upvar` alias names — and so does the program
5383: /// that stores to the same name earlier, which the pass leaves alone.
5384: #[test]
5385: fn a_store_the_flattened_catch_returns_is_not_dead() {
5386:     // The statement stays whatever a word of it is folded to, so each program
5387:     // names the store by what leads it.
5388:     let programs = [
5389:         (
5390:             "proc p {c} {\n    catch {set v $c} m\n    puts \"<$m>\"\n}\np 7\n",
5391:             "<7>\n",
5392:             "set v ",
5393:             "8.4",
5394:         ),
5395:         (
5396:             "proc p {c} {\n    catch {set v $c; set w $v} m\n    puts \"<$m>\"\n}\np 7\n",
5397:             "<7>\n",
5398:             "set w ",
5399:             "8.4",
5400:         ),
5401:         (
5402:             "proc p {c} {\n    catch {set v [string length $c]} m o\n    puts \"<$m>\"\n}\np 7\n",
5403:             "<1>\n",
5404:             "set v ",
5405:             "8.5",
5406:         ),
5407:         (
5408:             "set g 0\nproc p {c} {\n    global g\n    catch {set v $c} g\n}\np 7\nputs $g\n",
5409:             "7\n",
5410:             "set v ",
5411:             "8.4",
5412:         ),
5413:         (
5414:             "proc p {c} {\n    if {$c} {catch {set v 1} m} else {set m other}\n    return $m\n}\n\
5415:              puts \"[p 1] [p 0]\"\n",
5416:             "1 other\n",
5417:             "set v ",
5418:             "8.4",
5419:         ),
5420:         (
5421:             "set g 0\nproc p {} {\n    upvar 1 g m\n    catch {set v 1} m\n}\np\nputs $g\n",
5422:             "1\n",
5423:             "set v ",
5424:             "8.4",
5425:         ),
5426:     ];
5427:     for (source, printed, store, first) in programs {
5428:         for dialect in ["tcl8.6", "tcl9.0"] {
5429:             assert!(
5430:                 !removes_store(source, dialect, store),
5431:                 "{dialect}: {store} is the result:\n{source}"
5432:             );
5433:             assert!(
5434:                 optimised(source, dialect).0.contains(store),
5435:                 "{dialect}: {store} stays:\n{source}"
5436:             );
5437:         }
5438:         prints_under_releases_from(source, printed, first);
5439:     }
5440: }
5441: 
5442: /// A call to a command the module cannot see reads its words before its head
5443: /// runs and may read or write any global afterwards: `foo` here is defined at
5444: /// run time, reads `g` and sets `g` and `m`, and tclsh 8.4 to 9.1 print what each
5445: /// program says. The operand keeps the value it read; the store the callee reads
5446: /// stays, whether a later read follows it or a later store overwrites it —
5447: /// deleting it made the callee raise `can't read "g"`; and a read after the
5448: /// call is never taken for the value before it, of the name the call's words
5449: /// read or of one they do not.
5450: #[test]
5451: fn a_call_the_module_cannot_see_reads_its_words_first_and_may_read_and_write_after() {
5452:     let define = "set f [file join [file dirname [info script]] vt-unseen-[pid].tcl]\n\
5453:                   set fh [open $f w]\nputs $fh {proc foo {n} {global g; puts \"n=$n g=$g\"; set ::g 6; set ::m 4}}\n\
5454:                   close $fh\nsource $f\nfile delete $f\n";
5455:     for (tail, expected) in [
5456:         ("set g 5\nfoo $g\nputs $g\n", "n=5 g=5\n6\n"),
5457:         ("set g 5\nset cmd foo\n$cmd $g\nputs $g\n", "n=5 g=5\n6\n"),
5458:         (
5459:             "set cmd foo\nset g 5\n$cmd $g\nputs [expr {$g + 0}]\n",
5460:             "n=5 g=5\n6\n",
5461:         ),
5462:         (
5463:             "set g 5\nset m 3\nfoo $g\nputs $g\nputs $m\n",
5464:             "n=5 g=5\n6\n4\n",
5465:         ),
5466:         ("set g 5\nfoo 1\nputs $g\n", "n=1 g=5\n6\n"),
5467:         ("set cmd foo\nset g 5\n$cmd 1\nputs $g\n", "n=1 g=5\n6\n"),
5468:         ("set g 5\nfoo 1\nset g 7\nputs $g\n", "n=1 g=5\n7\n"),
5469:         (
5470:             "set cmd foo\nset g 5\n$cmd 1\nset g 7\nputs $g\n",
5471:             "n=1 g=5\n7\n",
5472:         ),
5473:     ] {
5474:         prints_under_every_release(&format!("{define}{tail}"), expected);
5475:     }
5476: }
5477: 
5478: /// A callback spelled as several words, which `after` joins as `concat` does,
5479: /// or one the scan cannot read — a computed script, a command the module never
5480: /// defines, an alias, an expansion — writes the variable a loop waits on, or
5481: /// the one a later read folds: tclsh prints `1` for each program, where
5482: /// taking `0` across the `update` printed `0`. A callback that only cancels,
5483: /// or stores a script that writes another name, leaves the value alone.
5484: #[test]
5485: fn a_write_a_callback_the_scan_could_not_read_makes_is_never_folded_away() {
5486:     let define = "set f [file join [file dirname [info script]] vt-callback-[pid].tcl]\n\
5487:                   set fh [open $f w]\nputs $fh {proc finish {} {set ::done 1}}\nclose $fh\n\
5488:                   source $f\nfile delete $f\n";
5489:     // Two rounds, so a callback that stores another still runs.
5490:     let wait = "after 30\nupdate\nafter 30\nupdate\nputs $done\n";
5491:     for head in [
5492:         "after 10 set done 1",
5493:         "after idle set done 1",
5494:         "after 10 incr done",
5495:         "after 10 {set done} 1",
5496:         "set script {set done 1}\nafter 10 $script",
5497:         "after 10 finish",
5498:         "interp alias {} fin {} set done 1\nafter 10 fin",
5499:         "proc build {} {return {set done 1}}\nafter 10 [build]",
5500:         "after 10 {after 10 set done 1}",
5501:     ] {
5502:         prints_under_every_release(&format!("{define}set done 0\n{head}\n{wait}"), "1\n");
5503:     }
5504:     prints_under_releases_from(
5505:         &format!("set done 0\nafter 10 {{*}}[list set done 1]\n{wait}"),
5506:         "1\n",
5507:         "8.5",
5508:     );
5509:     for head in [
5510:         "after 10 {set done 1}\nafter cancel {set done 1}",
5511:         "set id [after 10 {set done 1}]\nafter cancel $id",
5512:         "after 10 {set other 1}",
5513:         "after 10 set other 1",
5514:     ] {
5515:         prints_under_every_release(&format!("set done 0\n{head}\n{wait}"), "0\n");
5516:     }
5517: }
5518: 
5519: /// An alias's target word and the words after it are the one command a call
5520: /// to the alias runs, so an alias to `string length` stores no callback that
5521: /// writes a variable, however `string` is spelled: the top-level branch on `x`
5522: /// is decided and folded, and tclsh 8.4 to 9.1 print `kept` before and after
5523: /// the optimiser. Read alone, the target word is `string` with no subcommand,
5524: /// a script that may write any variable, and the branch was left undecided.
5525: #[test]
5526: fn an_alias_to_a_command_that_writes_nothing_leaves_its_branch_decided() {
5527:     for target in ["string length", "::string length"] {
5528:         let source = format!(
5529:             "interp alias {{}} safe {{}} {target}\nset x 5\nsafe {{set x 6}}\n\
5530:              if {{$x == 5}} {{puts kept}} else {{puts changed}}\n"
5531:         );
5532:         for dialect in ["tcl8.4", "tcl8.6", "tcl9.0", "tcl"] {
5533:             let unit = unit_of(&source, dialect);
5534:             assert!(
5535:                 !unit.top_level.sccp.constant_branches.is_empty(),
5536:                 "{dialect}: {source}"
5537:             );
5538:             let (rewritten, rewrites) = optimised(&source, dialect);
5539:             assert!(
5540:                 !rewritten.contains("changed"),
5541:                 "{dialect}: {source}\n{rewritten}\n{rewrites:#?}"
5542:             );
5543:         }
5544:         prints_under_every_release(&source, "kept\n");
5545:     }
5546: }
5547: 
5548: /// A braced arm list is a list: a bare or quoted element's escapes collapse
5549: /// under the release's grammar, and before 8.6 a `\x` takes every hex digit
5550: /// that follows and keeps the last two, so `a\x41b` is not `aAb` there. tclsh
5551: /// prints `miss` from 8.4 and 8.5 and `hit` from 8.6 for each program, before
5552: /// and after the optimiser, which folded the arm to `hit` under all of them.
5553: #[test]
5554: fn a_braced_arm_list_decodes_its_elements_under_the_releases_escapes() {
5555:     for (series, tclsh) in releases_on_path() {
5556:         let expected = if series < "8.6" { "miss\n" } else { "hit\n" };
5557:         for source in [
5558:             r#"switch -- aAb {"a\x41b" {puts hit} default {puts miss}}"#,
5559:             r"switch -- aAb {a\x41b {puts hit} default {puts miss}}",
5560:             r#"switch -glob -- aAb {"a\x41b" {puts hit} default {puts miss}}"#,
5561:             r"switch -glob -- aAb {a\x41b {puts hit} default {puts miss}}",
5562:         ] {
5563:             let dialect = dialect_of(series);
5564:             let (rewritten, _) = optimised(source, &dialect);
5565:             for program in [source, rewritten.as_str()] {
5566:                 assert_eq!(
5567:                     run_script(&tclsh, program),
5568:                     Some((true, expected.to_owned())),
5569:                     "tclsh{series}:\n{program}"
5570:                 );
5571:             }
5572:         }
5573:     }
5574: }
5575: 
5576: /// The shared lattice's value for `var`'s version `version` at the top level.
5577: fn top_value_at(unit: &CompilationUnit, var: &str, version: u32) -> Option<LatticeValue> {
5578:     let function = &unit.top_level;
5579:     let symbol = function.ssa.var_symbol(var).expect("the variable");
5580:     function.sccp.values.get(&(symbol, version)).cloned()
5581: }
5582: 
5583: /// The interface page's ordered-state programs, each over `set x 1`: the
5584: /// expression, the value it has and what `x` holds after it. The seventh
5585: /// program stops at an error in the middle of its expression and is read
5586: /// apart.
5587: const ORDERED_STATE: [(&str, &str, &str); 6] = [
5588:     ("{$x + [incr x] + $x}", "5", "2"),
5589:     ("{0 && [incr x]}", "0", "1"),
5590:     ("{$x + [set x 10] + $x}", "21", "10"),
5591:     ("{[incr x] + [incr x]}", "5", "3"),
5592:     ("{$x ? [incr x] : [incr x 10]}", "2", "2"),
5593:     ("\"$x + [incr x]\"", "3", "2"),
5594: ];
5595: 
5596: /// The seven programs of the interface page's ordered-state paragraph reach
5597: /// every consumer: the shared lattice holds the expression's value in `r#1`
5598: /// and the last write the expression made in `x#2`, in a procedure and at the
5599: /// top level and under every dialect; the optimiser forwards both into the
5600: /// reads after it; and each optimised program prints what tclsh 8.4 to 9.1
5601: /// print. Where the expression is a `puts` argument the statement is not
5602: /// evaluated, no nested write is folded and `puts $x` still reads `x`, and the
5603: /// program prints the same. The seventh program, an error between a write and
5604: /// the end of its expression inside a `catch`, leaves `x` at 2: in a procedure
5605: /// the lattice holds 2 in `x#2`, at the top level, where the `catch` is one
5606: /// call, `x` is unknown, and nothing forwards the earlier value to the read.
5607: #[test]
5608: fn the_seven_ordered_state_witnesses() {
5609:     for (expression, value, after) in ORDERED_STATE {
5610:         let int = |text: &str| Some(LatticeValue::Const(ConstValue::Int(text.parse().unwrap())));
5611:         let top = format!("set x 1\nset r [expr {expression}]\nputs $r\nputs $x\n");
5612:         let in_proc = format!(
5613:             "proc p {{}} {{\n    set x 1\n    set r [expr {expression}]\n    puts $r\n    puts $x\n}}\np\n"
5614:         );
5615:         let shown = format!("{value}\n{after}\n");
5616:         for dialect in DIALECTS {
5617:             let unit = unit_of(&in_proc, dialect);
5618:             assert_eq!(
5619:                 value_at(&unit, "::p", "r", 1),
5620:                 int(value),
5621:                 "{dialect}: {expression}"
5622:             );
5623:             assert_eq!(
5624:                 value_at(&unit, "::p", "x", 2),
5625:                 int(after),
5626:                 "{dialect}: {expression}"
5627:             );
5628:             let unit = unit_of(&top, dialect);
5629:             assert_eq!(
5630:                 top_value_at(&unit, "r", 1),
5631:                 int(value),
5632:                 "{dialect}: {expression}"
5633:             );
5634:             assert_eq!(
5635:                 top_value_at(&unit, "x", 2),
5636:                 int(after),
5637:                 "{dialect}: {expression}"
5638:             );
5639:             for source in [&top, &in_proc] {
5640:                 let (rewritten, rewrites) = optimised(source, dialect);
5641:                 assert!(
5642:                     rewrites.iter().any(|o| o.code == DiagCode::O100)
5643:                         && rewritten.contains(&format!("puts {value}"))
5644:                         && rewritten.contains(&format!("puts {after}"))
5645:                         && !rewritten.contains("puts $"),
5646:                     "{dialect}: {expression}\n{rewritten}"
5647:                 );
5648:             }
5649:         }
5650:         prints_under_every_release(&top, &shown);
5651:         prints_under_every_release(&in_proc, &shown);
5652: 
5653:         let argument = format!("set x 1\nputs [expr {expression}]\nputs $x\n");
5654:         for dialect in DIALECTS.iter().filter(|_| value != "0") {
5655:             let (rewritten, _) = optimised(&argument, dialect);
5656:             assert!(
5657:                 rewritten.contains("puts $x") && rewritten.contains("expr"),
5658:                 "{dialect}: {expression}\n{rewritten}"
5659:             );
5660:         }
5661:         prints_under_every_release(&argument, &shown);
5662:     }
5663: 
5664:     let caught = [
5665:         "set x 1\ncatch {expr {[incr x] + [error mid]}} msg\nputs $msg\nputs $x\n",
5666:         "proc p {} {\n    set x 1\n    catch {expr {[incr x] + [error mid]}} msg\n    puts $msg\n    puts $x\n}\np\n",
5667:     ];
5668:     for dialect in DIALECTS {
5669:         // A `catch` at the top level is one call whose body writes are
5670:         // may-definitions, so `x` is unknown after it; in a procedure its
5671:         // body is blocks of its own, the error leaves from the statement
5672:         // that raised it, and the handler is thrown to with the write the
5673:         // expression had made.
5674:         assert_eq!(
5675:             top_value_at(&unit_of(caught[0], dialect), "x", 2),
5676:             Some(LatticeValue::Overdefined),
5677:             "{dialect}"
5678:         );
5679:         assert_eq!(
5680:             value_at(&unit_of(caught[1], dialect), "::p", "x", 2),
5681:             Some(LatticeValue::Const(ConstValue::Int(2))),
5682:             "{dialect}"
5683:         );
5684:         for source in caught {
5685:             let (rewritten, _) = optimised(source, dialect);
5686:             assert!(
5687:                 rewritten.contains("set x 1") && rewritten.contains("puts $x"),
5688:                 "{dialect}: nothing forwards the earlier x\n{rewritten}"
5689:             );
5690:         }
5691:     }
5692:     for source in caught {
5693:         prints_under_every_release(source, "mid\n2\n");
5694:     }
5695:     // The completion code, 1, is read from the options.
5696:     let coded = "set x 1\ncatch {expr {[incr x] + [error mid]}} msg opts\nputs $msg\n\
5697:                  puts [dict get $opts -code]\nputs $x\n";
5698:     assert!(optimised(coded, "tcl8.6").0.contains("puts $x"));
5699:     prints_under_releases_from(coded, "mid\n1\n2\n", "8.5");
5700: }
5701: 
5702: /// A nested write to a place the ordered state cannot own — a qualified
5703: /// global, a `global` or an `upvar` alias — declines the expression whatever
5704: /// the write's own answer: the statement is not folded, its nested write stays,
5705: /// and the optimised program prints what tclsh 8.4 to 9.1 print. Where the
5706: /// write also reads a place nothing proves (`incr ::g`) the read is what
5707: /// declines, and a branch the expression never reaches owns nothing, so
5708: /// `0 && [set ::g 10]` is 0.
5709: #[test]
5710: fn a_nested_write_outside_the_state_declines() {
5711:     let programs = [
5712:         (
5713:             "proc p {} {\n set x 1\n set r [expr {$x + [set ::g 10]}]\n puts \"$r $::g\"\n}\np\n",
5714:             "11 10\n",
5715:             "declined: stateful-nested",
5716:         ),
5717:         (
5718:             "proc p {} {\n global g\n set x 1\n set r [expr {$x + [set g 10]}]\n puts \"$r $g\"\n}\np\n",
5719:             "11 10\n",
5720:             "declined: stateful-nested",
5721:         ),
5722:         (
5723:             "proc p {} {\n upvar 1 v w\n set x 1\n set r [expr {$x + [set w 10]}]\n puts \"$r $w\"\n}\nset v 0\np\n",
5724:             "11 10\n",
5725:             "declined: stateful-nested",
5726:         ),
5727:         (
5728:             "set ::g 5\nproc p {} {\n set x 1\n set r [expr {$x + [incr ::g]}]\n puts \"$r $::g\"\n}\np\n",
5729:             "7 6\n",
5730:             "declined: not-exact",
5731:         ),
5732:     ];
5733:     for (source, printed, answer) in programs {
5734:         for dialect in DIALECTS {
5735:             let unit = unit_of(source, dialect);
5736:             assert_eq!(
5737:                 answers_for(&unit, "::p", "expr"),
5738:                 [answer],
5739:                 "{dialect}:\n{source}"
5740:             );
5741:             assert_eq!(
5742:                 value_at(&unit, "::p", "r", 1),
5743:                 Some(LatticeValue::Overdefined),
5744:                 "{dialect}:\n{source}"
5745:             );
5746:             let (rewritten, _) = optimised(source, dialect);
5747:             assert!(
5748:                 rewritten.contains("expr {$x + [") && rewritten.contains("puts \"$r "),
5749:                 "{dialect}: the statement is kept\n{rewritten}"
5750:             );
5751:         }
5752:         prints_under_every_release(source, printed);
5753:     }
5754: 
5755:     let unreached = "proc p {} {\n set r [expr {0 && [set ::g 10]}]\n puts $r\n}\np\n";
5756:     for dialect in DIALECTS {
5757:         assert_eq!(
5758:             value_at(&unit_of(unreached, dialect), "::p", "r", 1),
5759:             Some(LatticeValue::Const(ConstValue::Int(0))),
5760:             "{dialect}"
5761:         );
5762:     }
5763:     prints_under_every_release(unreached, "0\n");
5764: }
5765: 
5766: /// What a prefix-rule program leaves that the analysis proves.
5767: enum PrefixFact {
5768:     /// The place's last version holds this text.
5769:     Text(&'static str, &'static str),
5770:     /// The place's last version holds this number, whichever way a route
5771:     /// writes it.
5772:     Number(&'static str, i64),
5773:     /// The place's last version is unbound.
5774:     Unbound(&'static str),
5775: }
5776: 
5777: /// One of the interface page's nine programs for the prefix rule
5778: /// (§ *`catch`, `try`, and completion*): the statements before the `catch`,
5779: /// the body it runs — an error after some of its stores — what is printed
5780: /// after it, what every release prints, the first release with the command,
5781: /// and what the analysis proves of a body its blocks hold. A body that is one
5782: /// straight-line block is lowered into blocks in a procedure; the rest, and
5783: /// every body at the top level, stay one call.
5784: struct PrefixProgram {
5785:     name: &'static str,
5786:     before: &'static str,
5787:     body: &'static str,
5788:     after: &'static str,
5789:     printed: &'static str,
5790:     first: &'static str,
5791:     flattened: &'static [PrefixFact],
5792: }
5793: 
5794: const PREFIX_PROGRAMS: [PrefixProgram; 10] = [
5795:     PrefixProgram {
5796:         name: "lassign stops at the array",
5797:         before: "set a old\narray set b {k keep}",
5798:         body: "lassign {new second} a b",
5799:         after: "puts \"$a $b(k)\"",
5800:         printed: "new keep\n",
5801:         first: "8.5",
5802:         flattened: &[
5803:             PrefixFact::Text("a", "new"),
5804:             PrefixFact::Text("b(k)", "keep"),
5805:         ],
5806:     },
5807:     PrefixProgram {
5808:         name: "lassign leaves the places after the array",
5809:         before: "array set b {k keep}\nset a old\nset c old",
5810:         body: "lassign {x y z} a b c",
5811:         after: "puts \"$a $c\"",
5812:         printed: "x old\n",
5813:         first: "8.5",
5814:         flattened: &[PrefixFact::Text("a", "x"), PrefixFact::Text("c", "old")],
5815:     },
5816:     PrefixProgram {
5817:         name: "foreach binds in order",
5818:         before: "array set b {k keep}\nset a old",
5819:         body: "foreach {a b} {new second} {set inside 1}",
5820:         after: "puts \"$a [info exists inside]\"",
5821:         printed: "new 0\n",
5822:         first: "8.4",
5823:         flattened: &[],
5824:     },
5825:     PrefixProgram {
5826:         name: "scan writes the place before the array",
5827:         before: "array set b {k keep}\nset a old",
5828:         body: "scan {1 2} {%d %d} a b",
5829:         after: "puts $a",
5830:         printed: "1\n",
5831:         first: "8.4",
5832:         flattened: &[PrefixFact::Number("a", 1)],
5833:     },
5834:     PrefixProgram {
5835:         name: "scan goes on past the array",
5836:         before: "array set a {k keep}\nset b old",
5837:         body: "scan {1 2} {%d %d} a b",
5838:         after: "puts \"$a(k) $b\"",
5839:         printed: "keep 2\n",
5840:         first: "8.4",
5841:         flattened: &[PrefixFact::Number("b", 2)],
5842:     },
5843:     PrefixProgram {
5844:         name: "regexp stops at the array",
5845:         before: "array set b {k keep}\nset a old",
5846:         body: "regexp {(x)(y)} xy a b",
5847:         after: "puts $a",
5848:         printed: "xy\n",
5849:         first: "8.4",
5850:         flattened: &[PrefixFact::Text("a", "xy")],
5851:     },
5852:     PrefixProgram {
5853:         name: "unset stops at the absent name",
5854:         before: "set p 1\nset q 2",
5855:         body: "unset p nosuch q",
5856:         after: "puts \"[info exists p] $q\"",
5857:         printed: "0 2\n",
5858:         first: "8.4",
5859:         flattened: &[PrefixFact::Unbound("p"), PrefixFact::Number("q", 2)],
5860:     },
5861:     PrefixProgram {
5862:         name: "an error in a word is before the command",
5863:         before: "set x 1",
5864:         body: "append x 2 [error boom]",
5865:         after: "puts $x",
5866:         printed: "1\n",
5867:         first: "8.4",
5868:         flattened: &[PrefixFact::Number("x", 1)],
5869:     },
5870:     PrefixProgram {
5871:         name: "an error in the value is before the store",
5872:         before: "",
5873:         body: "set r [expr {1 + [error mid]}]",
5874:         after: "puts [info exists r]",
5875:         printed: "0\n",
5876:         first: "8.4",
5877:         flattened: &[PrefixFact::Unbound("r")],
5878:     },
5879:     PrefixProgram {
5880:         name: "an error in an expression keeps its writes",
5881:         before: "set x 1",
5882:         body: "expr {[incr x] + [error mid]}",
5883:         after: "puts $x",
5884:         printed: "2\n",
5885:         first: "8.4",
5886:         flattened: &[PrefixFact::Number("x", 2)],
5887:     },
5888: ];
5889: 
5890: impl PrefixProgram {
5891:     /// The program as a script: the `catch` at the top level is one call.
5892:     fn at_the_top_level(&self) -> String {
5893:         format!(
5894:             "{}\ncatch {{{}}} m\n{}\n",
5895:             self.before, self.body, self.after
5896:         )
5897:     }
5898: 
5899:     /// The program in a procedure, where a one-block body is lowered.
5900:     fn in_a_procedure(&self) -> String {
5901:         format!(
5902:             "proc p {{}} {{\n{}\ncatch {{{}}} m\n{}\n}}\np\n",
5903:             self.before, self.body, self.after
5904:         )
5905:     }
5906: 
5907:     /// The program with `try … on error` for its `catch` (8.6 on).
5908:     fn with_a_handler(&self) -> String {
5909:         format!(
5910:             "proc p {{}} {{\n{}\ntry {{{}}} on error {{m}} {{}}\n{}\n}}\np\n",
5911:             self.before, self.body, self.after
5912:         )
5913:     }
5914: 
5915:     /// The program with a store after its body in the `try` (8.6 on): the
5916:     /// body's statements are a block each, the handler is thrown to from the
5917:     /// state the failing command leaves, and the store after it never runs.
5918:     fn with_a_store_after_in_the_try(&self) -> String {
5919:         format!(
5920:             "proc p {{}} {{\n{}\ntry {{{}; set w 0}} on error {{m}} {{}}\n{}\n}}\np\n",
5921:             self.before, self.body, self.after
5922:         )
5923:     }
5924: 
5925:     /// What the analysis of `function` claims of `fact`: that it holds, a
5926:     /// different value or binding, or nothing.
5927:     fn claim(fact: &PrefixFact, function: &tcl_compiler::compilation_unit::FunctionUnit) -> Claim {
5928:         let last = |name: &str| {
5929:             let symbol = function.ssa.var_symbol(name).expect("the variable");
5930:             function
5931:                 .sccp
5932:                 .values
5933:                 .iter()
5934:                 .filter(|((sym, _), _)| *sym == symbol)
5935:                 .max_by_key(|((_, version), _)| *version)
5936:                 .map(|(_, value)| value.clone())
5937:         };
5938:         let value = |name: &str, texts: &[String]| match last(name) {
5939:             Some(LatticeValue::Const(ConstValue::String(held))) if texts.contains(&held) => {
5940:                 Claim::Holds
5941:             }
5942:             Some(LatticeValue::Const(ConstValue::Int(held)))
5943:                 if texts.contains(&held.to_string()) =>
5944:             {
5945:                 Claim::Holds
5946:             }
5947:             Some(LatticeValue::Const(_)) => Claim::Contradicts,
5948:             _ => Claim::Silent,
5949:         };
5950:         match fact {
5951:             PrefixFact::Text(name, text) => value(name, &[(*text).to_owned()]),
5952:             PrefixFact::Number(name, number) => value(name, &[number.to_string()]),
5953:             PrefixFact::Unbound(name) => {
5954:                 let symbol = function.ssa.var_symbol(name).expect("the variable");
5955:                 let held = function
5956:                     .sccp
5957:                     .existence
5958:                     .iter()
5959:                     .filter(|((sym, _), _)| *sym == symbol)
5960:                     .max_by_key(|((_, version), _)| *version)
5961:                     .map(|(_, fact)| *fact);
5962:                 match held {
5963:                     Some(Existence::Unbound) => Claim::Holds,
5964:                     Some(Existence::Bound(_)) => Claim::Contradicts,
5965:                     _ => Claim::Silent,
5966:                 }
5967:             }
5968:         }
5969:     }
5970: }
5971: 
5972: /// What an analysis says of a fact tclsh bears out.
5973: #[derive(Debug, PartialEq, Eq)]
5974: enum Claim {
5975:     /// It proves the fact.
5976:     Holds,
5977:     /// It proves something else, which tclsh does not do.
5978:     Contradicts,
5979:     /// It proves nothing of the place.
5980:     Silent,
5981: }
5982: 
5983: /// The prefix rule holds in the default build — a `catch` at the top level, or
5984: /// one whose body is not a straight line, is one call whose body writes are
5985: /// may-definitions, and a `catch` in a procedure with a one-block body is
5986: /// lowered into blocks — and in the faithful-exceptions build, which gives a
5987: /// `try` handler blocks and exception edges: an error after `k` stores leaves
5988: /// those `k` and nothing else, so the handler is thrown to with them, and so
5989: /// it is where a store after the body in the `try` splits it into blocks: the
5990: /// state before the failing command reaches the handler only where that
5991: /// command can fail before it stores. Each
5992: /// program prints what tclsh 8.4 to 9.1 print, before and after `tcl opt`, in
5993: /// every shape. Where a body's blocks are the analysis's own, what it proves
5994: /// is exact: the place written before the error holds the value it was given
5995: /// and the places after it hold what they did. A body that is one call
5996: /// proves no such thing, and the places it may write hold no value.
5997: #[test]
5998: fn the_prefix_rule_holds_in_both_builds() {
5999:     for program in &PREFIX_PROGRAMS {
6000:         let (top, in_proc, handled, split) = (
6001:             program.at_the_top_level(),
6002:             program.in_a_procedure(),
6003:             program.with_a_handler(),
6004:             program.with_a_store_after_in_the_try(),
6005:         );
6006:         prints_under_releases_from(&top, program.printed, program.first);
6007:         prints_under_releases_from(&in_proc, program.printed, program.first);
6008:         let handler_first = if program.first < "8.6" {
6009:             "8.6"
6010:         } else {
6011:             program.first
6012:         };
6013:         prints_under_releases_from(&handled, program.printed, handler_first);
6014:         prints_under_releases_from(&split, program.printed, handler_first);
6015: 
6016:         for dialect in ["tcl8.6", "tcl9.0"] {
6017:             for fact in program.flattened {
6018:                 // The body's blocks are the analysis's own: it proves the fact.
6019:                 for source in [&in_proc, &handled, &split] {
6020:                     let unit = unit_of(source, dialect);
6021:                     let function = unit
6022:                         .procedures
6023:                         .get(&fixture_id(&unit.procedures, "::p"))
6024:                         .expect("the procedure");
6025:                     assert_eq!(
6026:                         PrefixProgram::claim(fact, function),
6027:                         Claim::Holds,
6028:                         "{}: {dialect}\n{source}",
6029:                         program.name
6030:                     );
6031:                 }
6032:                 // One call whose body writes are may-definitions proves
6033:                 // nothing of a place it may write, and never the value the
6034:                 // place held before it.
6035:                 let unit = unit_of(&top, dialect);
6036:                 assert_ne!(
6037:                     PrefixProgram::claim(fact, &unit.top_level),
6038:                     Claim::Contradicts,
6039:                     "{}: {dialect}\n{top}",
6040:                     program.name
6041:                 );
6042:             }
6043:         }
6044:     }
6045: }
6046: 
6047: /// A command of a `catch` body may fail wherever it stands, and the handler is
6048: /// thrown to with what the body has stored by then: after `set x 1; catch
6049: /// {set x 2; foo; set x 1}` the handler may see `x` at 2 — `foo` raises
6050: /// between the stores — so the lattice holds no constant for it, the store of
6051: /// 2 is not dead, and the program prints what tclsh prints. The optimiser
6052: /// had deleted `set x 2` and `set a 2`, which print `1` and `a=3` where tclsh
6053: /// 8.4 to 9.1 print `2` and `a=2`, and the handler's state was joined from the
6054: /// state before the body and the state at its end alone.
6055: #[test]
6056: fn a_throw_between_two_writes_is_a_state_the_handler_sees() {
6057:     let programs = [
6058:         (
6059:             "proc foo {} {error x}\nproc p {} {\n    set x 1\n    catch {set x 2; foo; set x 1}\n    puts $x\n}\np\n",
6060:             "2\n",
6061:             "set x 2",
6062:         ),
6063:         (
6064:             "proc foo {} {error x}\nproc p {} {\n    set a 1\n    catch {set a 2; foo; set a 3}\n    puts \"a=$a\"\n}\np\n",
6065:             "a=2\n",
6066:             "set a 2",
6067:         ),
6068:     ];
6069:     for (source, printed, store) in programs {
6070:         let name = if source.contains("set a 1") { "a" } else { "x" };
6071:         for dialect in ["tcl8.6", "tcl9.0"] {
6072:             let (rewritten, _) = optimised(source, dialect);
6073:             assert!(
6074:                 rewritten.contains(store),
6075:                 "{dialect}: {store} stays\n{rewritten}"
6076:             );
6077:             let held = last_value(source, dialect, "::p", name);
6078:             assert!(
6079:                 !matches!(held, LatticeValue::Const(ConstValue::Int(1 | 3))),
6080:                 "{dialect}: the handler may see 2, not a constant 1 or 3: {held:?}"
6081:             );
6082:         }
6083:         prints_under_releases_from(source, printed, "8.4");
6084:     }
6085: }
6086: 
6087: /// A statement after one that certainly raises never runs: after `array set b
6088: /// {k v}`, the body `lassign {x y} a b; set z 1` stops at the array, so `z`
6089: /// is never set where the handler runs, in a `catch` lowered into blocks and
6090: /// in the body of a `try`, which stays one block.
6091: #[test]
6092: fn a_statement_after_a_certain_error_never_runs() {
6093:     let in_catch = "proc p {} {\n    array set b {k v}\n    catch {lassign {x y} a b; set z 1} m\n    puts [info exists z]\n}\np\n";
6094:     let in_try = "proc p {} {\n    array set b {k v}\n    try {lassign {x y} a b; set z 1} on error {} {}\n    puts [info exists z]\n}\np\n";
6095:     for (source, first) in [(in_catch, "8.5"), (in_try, "8.6")] {
6096:         for dialect in ["tcl8.6", "tcl9.0"] {
6097:             let unit = unit_of(source, dialect);
6098:             assert_eq!(
6099:                 last_existence(&unit, "::p", "z"),
6100:                 UNBOUND,
6101:                 "{dialect}: z is never set\n{source}"
6102:             );
6103:         }
6104:         prints_under_releases_from(source, "0\n", first);
6105:     }
6106: }
6107: 
6108: /// An error outside any `catch` or `try` is the procedure's own, with no
6109: /// handler to be thrown to, and nothing that follows it is claimed: after
6110: /// `lassign {x y} a b` over an array `b` a `catch` the procedure goes on to
6111: /// run is still reached, as it was before the prefix rule.
6112: #[test]
6113: fn a_certain_error_outside_a_handler_claims_nothing() {
6114:     let source = "proc p {} {\n    array set b {k v}\n    lassign {x y} a b\n    catch {set z 1}\n    return $z\n}\n";
6115:     for dialect in ["tcl8.6", "tcl9.0"] {
6116:         let unit = unit_of(source, dialect);
6117:         let function = unit
6118:             .procedures
6119:             .get(&fixture_id(&unit.procedures, "::p"))
6120:             .expect("the procedure");
6121:         let reached = function
6122:             .sccp
6123:             .executable_blocks
6124:             .iter()
6125:             .any(|block| function.ssa.block_name(*block).starts_with("catch_body"));
6126:         assert!(reached, "{dialect}: the body of the catch is reached");
6127:     }
6128: }
6129: 
6130: /// A store in a `catch` body is taken as run only where its place is proved
6131: /// to take it. Tcl raises on a scalar store into an array and on an element
6132: /// store into a scalar, and `catch` observes the error, so where the analysis
6133: /// does not prove a variable's kind the script's completion is not exact and
6134: /// the `catch` is left unevaluated. The kind is read from before the body in
6135: /// every form: at the statement in the value form, before the marker that
6136: /// states what the body may write in the statement form, and at the exit of
6137: /// the block before a flattened body. The route had taken `set y 1` over a `y`
6138: /// that may be an array as run, so `p 1` printed `zero`, and at the top level
6139: /// the marker had made the array `b` either kind, so the program printed
6140: /// `empty`, where tclsh prints `c=1` and `error`. Where the kind is proved, the
6141: /// `catch` is still evaluated in each form, and the body's own earlier store
6142: /// decides the kind a later one needs.
6143: #[test]
6144: fn a_catch_body_store_is_run_only_where_its_place_is_proved_to_take_it() {
6145:     let value_form = "proc p {n} {\n    if {$n} {array set y {a 1}}\n    set c [catch {set y 1}]\n    if {$c == 0} {return zero}\n    return \"c=$c\"\n}\nputs [p 1]\nputs [p 0]\n";
6146:     let flattened = "proc p {n} {\n    if {$n} {array set y {a 1}}\n    catch {set y 1} m\n    if {$m eq \"1\"} {return one}\n    return other\n}\nputs [p 1]\nputs [p 0]\n";
6147:     let top_level = "set a old\narray set b {k keep}\ncatch {lassign {new second} a b} m2\nif {$m2 eq \"\"} {puts empty} else {puts error}\nputs $a\n";
6148:     for dialect in DIALECTS {
6149:         assert_ne!(
6150:             last_value(value_form, dialect, "::p", "c"),
6151:             LatticeValue::Const(ConstValue::Int(0)),
6152:             "{dialect}: `y` may be an array"
6153:         );
6154:         let held = last_value(flattened, dialect, "::p", "m");
6155:         assert!(
6156:             !matches!(held, LatticeValue::Const(_)),
6157:             "{dialect}: `y` may be an array: {held:?}"
6158:         );
6159:         assert_ne!(
6160:             top_value_at(&unit_of(top_level, dialect), "m2", 1),
6161:             Some(text("")),
6162:             "{dialect}: `b` is an array"
6163:         );
6164:     }
6165:     prints_under_every_release(value_form, "c=1\nzero\n");
6166:     prints_under_every_release(flattened, "other\none\n");
6167:     prints_under_releases_from(top_level, "error\nnew\n", "8.5");
6168: 
6169:     // The value form: the code each body completes with, where the kinds
6170:     // its stores need are proved (`Some`) or not (`None`), and what tclsh
6171:     // prints for it. An element store needs an array or nothing, which an
6172:     // earlier element store of the body proves; a scalar store after one
6173:     // raises.
6174:     let value_forms = [
6175:         ("set y 1", Some(0), "0"),
6176:         ("set y(a) 1; set y(b) 2", Some(0), "0"),
6177:         ("set y(a) 1; set y 2", None, "1"),
6178:     ];
6179:     for (body, code, printed) in value_forms {
6180:         let source = format!(
6181:             "proc p {{}} {{\n    set c [catch {{{body}}} m]\n    return $c\n}}\nputs [p]\n"
6182:         );
6183:         for dialect in DIALECTS {
6184:             let held = value_at(&unit_of(&source, dialect), "::p", "c", 1);
6185:             match code {
6186:                 Some(code) => assert_eq!(
6187:                     held,
6188:                     Some(LatticeValue::Const(ConstValue::Int(code))),
6189:                     "{dialect}: {body}"
6190:                 ),
6191:                 None => assert!(
6192:                     !matches!(held, Some(LatticeValue::Const(_))),
6193:                     "{dialect}: {body}: {held:?}"
6194:                 ),
6195:             }
6196:         }
6197:         prints_under_every_release(&source, &format!("{printed}\n"));
6198:     }
6199:     let into_an_array = "proc p {} {\n    array set y {k v}\n    set c [catch {set y(a) 1} m]\n    return $c\n}\nputs [p]\n";
6200:     let flattened_proved = "proc p {} {\n    catch {set v 1} r\n    return $r\n}\nputs [p]\n";
6201:     let top_proved = "set w 0\ncatch {set v 1; set w 2} r\nif {[info exists v]} {puts yes} else {puts no}\nputs \"$r $w\"\n";
6202:     for dialect in DIALECTS {
6203:         assert_eq!(
6204:             value_at(&unit_of(into_an_array, dialect), "::p", "c", 1),
6205:             Some(LatticeValue::Const(ConstValue::Int(0))),
6206:             "{dialect}"
6207:         );
6208:         assert_eq!(
6209:             last_value(flattened_proved, dialect, "::p", "r"),
6210:             LatticeValue::Const(ConstValue::Int(1)),
6211:             "{dialect}"
6212:         );
6213:         assert_eq!(
6214:             top_value_at(&unit_of(top_proved, dialect), "r", 1),
6215:             Some(LatticeValue::Const(ConstValue::Int(2))),
6216:             "{dialect}"
6217:         );
6218:     }
6219:     prints_under_every_release(into_an_array, "0\n");
6220:     prints_under_every_release(flattened_proved, "1\n");
6221:     prints_under_every_release(top_proved, "yes\n2 2\n");
6222: 
6223:     // The body's own earlier store decides the kind a later one needs: a
6224:     // scalar then an element store raises, and an element then a scalar one.
6225:     let scalar_then_element =
6226:         "proc p {} {\n    catch {set y 1; set y(a) 2} m\n    return \"$m $y\"\n}\nputs [p]\n";
6227:     let element_then_scalar = "catch {set y(a) 1; set y 2} m\nputs \"$m [array exists y]\"\n";
6228:     for dialect in DIALECTS {
6229:         let held = last_value(scalar_then_element, dialect, "::p", "m");
6230:         assert!(
6231:             !matches!(held, LatticeValue::Const(_)),
6232:             "{dialect}: `y` is a scalar: {held:?}"
6233:         );
6234:         let held = top_value_at(&unit_of(element_then_scalar, dialect), "m", 1);
6235:         assert!(
6236:             !matches!(held, Some(LatticeValue::Const(_))),
6237:             "{dialect}: `y` is an array: {held:?}"
6238:         );
6239:     }
6240:     prints_under_every_release(
6241:         scalar_then_element,
6242:         "can't set \"y(a)\": variable isn't array 1\n",
6243:     );
6244:     prints_under_every_release(
6245:         element_then_scalar,
6246:         "can't set \"y\": variable is array 1\n",
6247:     );
6248: }
6249: 
6250: /// The loops a `catch` body holds, each in the statement form in a procedure:
6251: /// the body of the loop, a command after the loop in the same script, what
6252: /// tclsh 8.4 to 9.1 leave in the result variable, and the first release with
6253: /// what the body uses. A loop absorbs its body's `break` and `continue`, so
6254: /// the script goes on past the loop; every other completion is the loop's
6255: /// own, so the script ends there with it.
6256: const LOOP_BODIES: [(&str, &str, &str, &str); 12] = [
6257:     (
6258:         "foreach x {1 2 3} {set y $x; break}",
6259:         "set z $y",
6260:         "1",
6261:         "8.4",
6262:     ),
6263:     (
6264:         "foreach x {1 2 3} {set y $x; continue; set y no}",
6265:         "set z $y",
6266:         "3",
6267:         "8.4",
6268:     ),
6269:     (
6270:         "foreach x {1 2} {set y $x; error boom}",
6271:         "set z done",
6272:         "boom",
6273:         "8.4",
6274:     ),
6275:     (
6276:         "foreach x {1 2} {set y $x; return r}",
6277:         "set z done",
6278:         "r",
6279:         "8.4",
6280:     ),
6281:     (
6282:         "foreach x {1 2} {foreach y {a b} {break}; set z $x}",
6283:         "set w $z",
6284:         "2",
6285:         "8.4",
6286:     ),
6287:     (
6288:         "set z none; foreach x {} {set z ran}",
6289:         "set z",
6290:         "none",
6291:         "8.4",
6292:     ),
6293:     ("foreach x {1 2} {set x}", "", "", "8.4"),
6294:     (
6295:         "foreach {a b} {1 2 3} {set z \"$a:$b\"}",
6296:         "set z",
6297:         "3:",
6298:         "8.4",
6299:     ),
6300:     ("lmap x {1 2 3 4} {set x}", "", "1 2 3 4", "8.6"),
6301:     ("lmap x {1 2 3} {set y $x; continue}", "", "", "8.6"),
6302:     ("lmap x {1 2 3} {set y $x; break}", "", "", "8.6"),
6303:     (
6304:         "foreach x {1 2 3} {set y $x; break;}",
6305:         "set z $y",
6306:         "1",
6307:         "8.4",
6308:     ),
6309: ];
6310: 
6311: /// A loop in a `catch` body runs as its iteration plan says
6312: /// (`IterationPlan::step`, `LoopResult::of`): `break` ends the loop and
6313: /// `continue` the iteration, each absorbed, and an error, a `return`, a code of
6314: /// the body's own and a `break` at level 1, which the loop sees as a
6315: /// `return`, leave it. `foreach` yields the empty string and `lmap` the
6316: /// results of the iterations that completed normally. The loop's variables
6317: /// are stores of the script, taken where their kind is proved: an array
6318: /// raises after the stores before it, and a variable of unproven kind, like a
6319: /// list the analysis does not know, leaves the `catch` unevaluated. Each
6320: /// program prints what tclsh prints before and after `tcl opt`.
6321: #[test]
6322: fn a_loop_absorbs_break_and_continue() {
6323:     for (body, after, held, first) in LOOP_BODIES {
6324:         let script = if after.is_empty() {
6325:             body.to_owned()
6326:         } else {
6327:             format!("{body}; {after}")
6328:         };
6329:         let source = format!(
6330:             "proc p {{}} {{\n    catch {{{script}}} m\n    return \"<$m>\"\n}}\nputs [p]\n"
6331:         );
6332:         let dialects: &[&str] = if first == "8.6" {
6333:             &["tcl8.6", "tcl9.0"]
6334:         } else {
6335:             &DIALECTS
6336:         };
6337:         for dialect in dialects {
6338:             assert_eq!(
6339:                 lattice_text(last_value(&source, dialect, "::p", "m")).as_deref(),
6340:                 Some(held),
6341:                 "{dialect}: {script}"
6342:             );
6343:         }
6344:         prints_under_releases_from(&source, &format!("<{held}>\n"), first);
6345:     }
6346: 
6347:     // The value form, the loop variable also set where the script starts, so
6348:     // it is among what the statement writes: the code and the message.
6349:     let value_forms = [
6350:         ("foreach x {1 2} {break}", 0, "", "0 {}", "8.4"),
6351:         ("foreach x {1 2} {error boom}", 1, "boom", "1 boom", "8.4"),
6352:         (
6353:             "foreach x {1 2} {return -code break b}",
6354:             2,
6355:             "b",
6356:             "2 b",
6357:             "8.4",
6358:         ),
6359:         (
6360:             "foreach x {1 2} {return -level 0 -code 5 v}",
6361:             5,
6362:             "v",
6363:             "5 v",
6364:             "8.5",
6365:         ),
6366:     ];
6367:     for (body, code, held, printed, first) in value_forms {
6368:         let source = format!(
6369:             "proc p {{}} {{\n    set c [catch {{set x 0; {body}}} m]\n    return [list $c $m]\n}}\nputs [p]\n"
6370:         );
6371:         for dialect in ["tcl8.6", "tcl9.0"] {
6372:             let unit = unit_of(&source, dialect);
6373:             assert_eq!(
6374:                 value_at(&unit, "::p", "c", 1),
6375:                 Some(LatticeValue::Const(ConstValue::Int(code))),
6376:                 "{dialect}: {body}"
6377:             );
6378:             assert_eq!(
6379:                 value_at(&unit, "::p", "m", 1)
6380:                     .and_then(lattice_text)
6381:                     .as_deref(),
6382:                 Some(held),
6383:                 "{dialect}: {body}"
6384:             );
6385:         }
6386:         prints_under_releases_from(&source, &format!("{printed}\n"), first);
6387:     }
6388: 
6389:     // A loop variable the script proved an array raises there, after the
6390:     // variables bound before it: the code is 1 and `a` is `new`.
6391:     let raises = "proc p {} {\n    set c [catch {set a old; set b(k) keep; foreach {a b} {new second} {set inside 1}} m]\n    return [list $c $a [info exists inside]]\n}\nputs [p]\n";
6392:     for dialect in DIALECTS {
6393:         let unit = unit_of(raises, dialect);
6394:         assert_eq!(
6395:             value_at(&unit, "::p", "c", 1),
6396:             Some(LatticeValue::Const(ConstValue::Int(1))),
6397:             "{dialect}"
6398:         );
6399:         assert_eq!(
6400:             last_value(raises, dialect, "::p", "a"),
6401:             text("new"),
6402:             "{dialect}"
6403:         );
6404:     }
6405:     prints_under_every_release(raises, "1 new 0\n");
6406: 
6407:     // What leaves the `catch` unevaluated, and the variable that raises: an
6408:     // unknown list, a loop variable that may be an array, and one that is.
6409:     let undecided = [
6410:         "proc p {l} {\n    catch {foreach x $l {break}; set z done} m\n    return [string equal $m done]\n}\nputs [p {1 2}]\n",
6411:         "proc p {n} {\n    if {$n} {array set x {a 1}}\n    catch {foreach x {1 2} {break}; set z done} m\n    return [string equal $m done]\n}\nputs [p 1]\nputs [p 0]\n",
6412:         "proc p {} {\n    array set b {k keep}\n    set a old\n    catch {foreach {a b} {new second} {set inside 1}; set z done} m\n    return \"[string equal $m done] $a [info exists inside]\"\n}\nputs [p]\n",
6413:     ];
6414:     let printed = ["1\n", "0\n1\n", "0 new 0\n"];
6415:     for (source, printed) in undecided.into_iter().zip(printed) {
6416:         for dialect in DIALECTS {
6417:             let held = last_value(source, dialect, "::p", "m");
6418:             assert_ne!(held, text("done"), "{dialect}:\n{source}");
6419:         }
6420:         prints_under_every_release(source, printed);
6421:     }
6422: }
6423: 
6424: /// A store ahead of a write that may stop part-way is dead only where every
6425: /// path through the body overwrites it. `lassign` assigns its targets in
6426: /// order and raises at the first it cannot write, so a store into a target it
6427: /// reaches before the one that may fail is overwritten on every path, and a
6428: /// store into a target after it is not. O109 keeps `set b old` ahead of
6429: /// `lassign {new second} a b` where `a` may be or is an array, which leaves
6430: /// `b` old, keeps `set c old` ahead of `lassign {x y z} a b c` where `b` is an
6431: /// array, in a `try` and in `[catch {…}]`, since the command that raised
6432: /// preserved `c`, and deletes `set a old` ahead of `lassign {new second} a b`
6433: /// in a `try` where
6434: /// `b` is an array: the body's first command certainly raises after it stores
6435: /// `a`, so the solver leaves the edge from the block before the body to the
6436: /// handler closed, and no handler reads `old`. Every program prints what
6437: /// tclsh 8.5 (8.6 for `try`) to 9.1 prints before and after `tcl opt`.
6438: #[test]
6439: fn o109_refuses_the_store_ahead_of_a_partial_lassign() {
6440:     let kept = [
6441:         (
6442:             "proc p {c} {\n    if {$c} {array set a {k v}}\n    set b old\n    catch {lassign {new second} a b}\n    return $b\n}\nputs [p 0]\nputs [p 1]\n",
6443:             "second\nold\n",
6444:             "8.5",
6445:         ),
6446:         (
6447:             "proc p {} {\n    array set a {k v}\n    set b old\n    try {lassign {new second} a b} on error {} {}\n    return $b\n}\nputs [p]\n",
6448:             "old\n",
6449:             "8.6",
6450:         ),
6451:         (
6452:             "proc p {c} {\n    if {$c} {array set a {k v}}\n    set b old\n    try {lassign {new second} a b} on error {} {}\n    return $b\n}\nputs [p 0]\nputs [p 1]\n",
6453:             "second\nold\n",
6454:             "8.6",
6455:         ),
6456:         (
6457:             "proc p {} {\n    array set b {k v}\n    set c old\n    try {lassign {x y z} a b c} on error {} {}\n    return [list $c [info exists a]]\n}\nputs [p]\n",
6458:             "old 1\n",
6459:             "8.6",
6460:         ),
6461:         (
6462:             "proc p {} {\n    array set b {k v}\n    set c old\n    set r [catch {lassign {x y z} a b c} m]\n    if {[info exists c]} {lappend r $c}\n    return $r\n}\nputs [p]\n",
6463:             "1 old\n",
6464:             "8.5",
6465:         ),
6466:     ];
6467:     for (source, printed, first) in kept {
6468:         for dialect in ["tcl8.6", "tcl9.0"] {
6469:             // The store stays while its variable is read: a read the
6470:             // optimiser forwards `old` into reads no store.
6471:             let (rewritten, rewrites) = optimised(source, dialect);
6472:             let kept = ["b", "c"].iter().all(|name| {
6473:                 !source.contains(&format!("set {name} old"))
6474:                     || rewritten.contains(&format!("set {name} old"))
6475:                     || !rewritten.contains(&format!("${name}"))
6476:             });
6477:             assert!(
6478:                 kept,
6479:                 "{dialect}: the store `lassign` may never reach stays\n{rewritten}\n{rewrites:#?}"
6480:             );
6481:         }
6482:         prints_under_releases_from(source, printed, first);
6483:     }
6484:     // Deleted: a store every path overwrites, and one a raise preserved where
6485:     // nothing reads what it preserved.
6486:     let deleted = [
6487:         (
6488:             "proc p {} {\n    set a old\n    array set b {k keep}\n    try {lassign {new second} a b} on error {m} {}\n    return $a\n}\nputs [p]\n",
6489:             "set a old",
6490:             "new\n",
6491:         ),
6492:         (
6493:             "proc p {} {\n    array set b {k v}\n    set c old\n    try {lassign {x y z} a b c} on error {} {}\n    return done\n}\nputs [p]\n",
6494:             "set c old",
6495:             "done\n",
6496:         ),
6497:     ];
6498:     for (source, store, printed) in deleted {
6499:         for dialect in ["tcl8.6", "tcl9.0"] {
6500:             let (rewritten, rewrites) = optimised(source, dialect);
6501:             assert!(
6502:                 !rewritten.contains(store)
6503:                     && rewrites
6504:                         .iter()
6505:                         .any(|rewrite| matches!(rewrite.code, DiagCode::O109 | DiagCode::O126)),
6506:                 "{dialect}: `{store}` is dead\n{rewritten}\n{rewrites:#?}"
6507:             );
6508:         }
6509:         prints_under_releases_from(source, printed, "8.6");
6510:     }
6511: }
6512: 
6513: /// A write that may not run leaves the store ahead of it to the reads after
6514: /// it, in the three shapes a sweep of generated bodies found folding or
6515: /// deleting that store. `scan` makes every store it can and raises after the
6516: /// last, so with `a` an array `scan {1 2} {%d %d} a b` leaves `b` 2, which
6517: /// the route proves in a `catch`, a `try` and `[catch {…}]`. A write in a
6518: /// `catch` or `try` body inside a substitution happens only where the body
6519: /// has not stopped first, so `set c old` stays ahead of `[catch {lassign {x
6520: /// y z} a b c} m]` where `b` may be an array — as a value, in a condition,
6521: /// and nested in a word or an expression of the body — and `set b old`
6522: /// ahead of `[catch {set a x; set b [error mid]} m]`, whose word raises. And
6523: /// a `try` body that ends in a raise may fail at its first command before
6524: /// it stores, so `set b old` stays ahead of `try {lassign {x y} a b; error
6525: /// boom} on error {} {}` where `a` may be an array. Every program prints
6526: /// what tclsh prints before and after `tcl opt`, from the first release
6527: /// that has its commands.
6528: #[test]
6529: fn a_store_ahead_of_a_write_that_may_not_run_stays() {
6530:     let scans = [
6531:         (
6532:             "proc p {} {\n    array set a {k v}\n    set b old\n    catch {scan {1 2} {%d %d} a b} m\n    return $b\n}\nputs [p]\n",
6533:             "8.4",
6534:         ),
6535:         (
6536:             "proc p {} {\n    array set a {k v}\n    set b old\n    try {scan {1 2} {%d %d} a b} on error {m} {}\n    return $b\n}\nputs [p]\n",
6537:             "8.6",
6538:         ),
6539:         (
6540:             "proc p {} {\n    array set a {k v}\n    set b old\n    set r [catch {scan {1 2} {%d %d} a b} m]\n    return $b\n}\nputs [p]\n",
6541:             "8.4",
6542:         ),
6543:     ];
6544:     for (source, first) in scans {
6545:         for dialect in ["tcl8.6", "tcl9.0"] {
6546:             assert_eq!(
6547:                 lattice_text(last_value(source, dialect, "::p", "b")),
6548:                 Some("2".to_owned()),
6549:                 "{dialect}: scan writes b after failing on a\n{source}"
6550:             );
6551:         }
6552:         prints_under_releases_from(source, "2\n", first);
6553:     }
6554:     let kept = [
6555:         (
6556:             "proc p {n} {\n    if {$n} {array set b {k v}}\n    set c old\n    set r [catch {lassign {x y z} a b c} m]\n    if {[info exists c]} {lappend r $c}\n    return $r\n}\nputs [p 0]\nputs [p 1]\n",
6557:             "0 z\n1 old\n",
6558:             "8.5",
6559:         ),
6560:         (
6561:             "proc p {n} {\n    if {$n} {array set b {k v}}\n    set c old\n    if {[catch {lassign {x y z} a b c} m]} {return [list raised $c]}\n    return [list ok $c]\n}\nputs [p 0]\nputs [p 1]\n",
6562:             "ok z\nraised old\n",
6563:             "8.5",
6564:         ),
6565:         (
6566:             "proc p {n} {\n    if {$n} {array set b {k v}}\n    set c old\n    set r [catch {set q [lassign {x y z} a b c]} m]\n    return [list $r $c]\n}\nputs [p 0]\nputs [p 1]\n",
6567:             "0 z\n1 old\n",
6568:             "8.5",
6569:         ),
6570:         (
6571:             "proc p {n} {\n    if {$n} {array set b {k v}}\n    set c old\n    set r [catch {expr {[lassign {x y z} a b c] eq {}}} m]\n    return [list $r $c]\n}\nputs [p 0]\nputs [p 1]\n",
6572:             "0 z\n1 old\n",
6573:             "8.5",
6574:         ),
6575:         (
6576:             "proc p {} {\n    set b old\n    set r [catch {set a x; set b [error mid]} m]\n    return [list $r $a $b]\n}\nputs [p]\n",
6577:             "1 x old\n",
6578:             "8.4",
6579:         ),
6580:         (
6581:             "proc p {n} {\n    if {$n} {array set a {k v}}\n    set b old\n    try {lassign {x y} a b; error boom} on error {m} {}\n    return $b\n}\nputs [p 0]\nputs [p 1]\n",
6582:             "y\nold\n",
6583:             "8.6",
6584:         ),
6585:     ];
6586:     for (source, printed, first) in kept {
6587:         for dialect in ["tcl8.6", "tcl9.0"] {
6588:             let (rewritten, rewrites) = optimised(source, dialect);
6589:             let kept = ["b", "c"].iter().all(|name| {
6590:                 !source.contains(&format!("set {name} old"))
6591:                     || rewritten.contains(&format!("set {name} old"))
6592:                     || !rewritten.contains(&format!("${name}"))
6593:             });
6594:             assert!(
6595:                 kept,
6596:                 "{dialect}: the store a write may not reach stays\n{rewritten}\n{rewrites:#?}"
6597:             );
6598:         }
6599:         prints_under_releases_from(source, printed, first);
6600:     }
6601: }
6602: 
6603: /// The programs of [`a_raising_store_is_never_dead`]: each source, the raising
6604: /// store it keeps, what it prints and the first release that runs it.
6605: const RAISING_STORES: [(&str, &str, &str, &str); 16] = [
6606:     (
6607:         "proc p {} {\n    set x 1\n    catch {set x [expr {1/0}]; set y 2} m\n    return [list $m [info exists y]]\n}\nputs [p]\n",
6608:         "set x [expr {1/0}]",
6609:         "{divide by zero} 0\n",
6610:         "8.4",
6611:     ),
6612:     (
6613:         "proc p {} {\n    set x 1\n    catch {set x [lindex {a b} 1.5]; set y 2} m\n    return [info exists y]\n}\nputs [p]\n",
6614:         "set x [lindex {a b} 1.5]",
6615:         "0\n",
6616:         "8.4",
6617:     ),
6618:     (
6619:         "proc p {} {\n    set x 1\n    catch {set x [lindex {a b} 1.5]; set y 2}\n    return [info exists y]\n}\nputs [p]\n",
6620:         "set x [lindex {a b} 1.5]",
6621:         "0\n",
6622:         "8.4",
6623:     ),
6624:     (
6625:         "proc p {} {\n    set x abc\n    catch {incr x; set y 2} m\n    return [list [info exists y] $x]\n}\nputs [p]\n",
6626:         "incr x",
6627:         "0 abc\n",
6628:         "8.4",
6629:     ),
6630:     (
6631:         "proc p {} {\n    set a 1\n    catch {unset a b; set y 2} m\n    return [list [info exists y] [info exists a]]\n}\nputs [p]\n",
6632:         "unset a b",
6633:         "0 0\n",
6634:         "8.4",
6635:     ),
6636:     (
6637:         "proc p {} {\n    set x 1\n    set c [catch {foreach i {1 2 3} {set x [lindex {a b} 1.5]; set y 2}}]\n    return [list $c [info exists y]]\n}\nputs [p]\n",
6638:         "set x [lindex {a b} 1.5]",
6639:         "1 0\n",
6640:         "8.4",
6641:     ),
6642:     (
6643:         "proc p {} {\n    set x 1\n    try {set x [lindex {a b} 1.5]; set y 2} on error {m} {return [info exists y]}\n    return none\n}\nputs [p]\n",
6644:         "set x [lindex {a b} 1.5]",
6645:         "0\n",
6646:         "8.6",
6647:     ),
6648:     (
6649:         "proc p {} {\n    set x 1\n    try {set x [expr {1/0}]; set y 2} finally {puts \"fin [info exists y]\"}\n}\ncatch {p} m\nputs $m\n",
6650:         "set x [expr {1/0}]",
6651:         "fin 0\ndivide by zero\n",
6652:         "8.6",
6653:     ),
6654:     (
6655:         "proc p {} {\n    set x [format %d abc]\n    return 1\n}\nputs [catch {p}]\n",
6656:         "set x [format %d abc]",
6657:         "1\n",
6658:         "8.4",
6659:     ),
6660:     (
6661:         "proc p {} {\n    set x 1\n    try {set x [lindex {a b} 1.5]; set y 2} finally {puts \"fin [info exists y]\"}\n}\nputs [catch {p}]\n",
6662:         "set x [lindex {a b} 1.5]",
6663:         "fin 0\n1\n",
6664:         "8.6",
6665:     ),
6666:     (
6667:         "proc p {} {\n    set x 1\n    catch {set x [string range abc 1 x]; set y 2} m\n    return [info exists y]\n}\nputs [p]\n",
6668:         "set x [string range abc 1 x]",
6669:         "0\n",
6670:         "8.4",
6671:     ),
6672:     (
6673:         "proc p {} {\n    set a old; set c old; array set b {k v}\n    catch {scan {1 2 3} {%d %d %d} a b c; set y 2} m\n    return [list [info exists y] $a $c]\n}\nputs [p]\n",
6674:         "scan {1 2 3} {%d %d %d} a b c",
6675:         "0 1 3\n",
6676:         "8.4",
6677:     ),
6678:     (
6679:         "proc p {} {\n    set a old; set c old; array set b {k v}\n    catch {lassign {1 2 3} a b c; set y 2} m\n    return [list [info exists y] $a $c]\n}\nputs [p]\n",
6680:         "lassign {1 2 3} a b c",
6681:         "0 1 old\n",
6682:         "8.5",
6683:     ),
6684:     (
6685:         "proc q {x} {\n    catch {set x [expr {1/0}]; set y 2} m\n    puts $x\n    puts [list $m [info exists y]]\n}\nq 5\n",
6686:         "set x [expr {1/0}]",
6687:         "5\n{divide by zero} 0\n",
6688:         "8.4",
6689:     ),
6690:     (
6691:         "proc p {i} {\n    set a(k) 1\n    catch {set a($i) [expr {1/0}]; set y 2} m\n    return [list $m [info exists y]]\n}\nputs [p j]\n",
6692:         "set a($i) [expr {1/0}]",
6693:         "{divide by zero} 0\n",
6694:         "8.4",
6695:     ),
6696:     (
6697:         "proc add {a b} {\n    expr {$a + $b}\n}\nproc f {} {\n    set unused [add x 1]\n    puts done\n}\nputs [catch f]\n",
6698:         "set unused [add x 1]",
6699:         "1\n",
6700:         "8.4",
6701:     ),
6702: ];
6703: 
6704: /// A store whose value raises is never dead, and the solver's proof that it
6705: /// raises is no proof that it evaluated cleanly. Inside a `catch` or `try`
6706: /// body the raise is the store's effect: `set x [expr {1/0}]` ahead of `set
6707: /// y 2` stops the body there, so `y` is never set, though nothing reads the
6708: /// `x` it would have stored and the solver gives that definition the value
6709: /// `x` held before it. The same holds for a command substitution that raises
6710: /// on its own words (`[lindex {a b} 1.5]`, `[string range abc 1 x]`), an
6711: /// `incr` of a value that is no integer, an `unset` of an absent name, a
6712: /// `scan` or `lassign` that stops at an array, a value-position `catch` over
6713: /// a loop, a store to a parameter whose constant argument is propagated past
6714: /// it, and a store to an element whose key is not known, and a command
6715: /// substitution that raises outside any body stops the procedure (#2346's
6716: /// arm: `set x [format %d abc]` unread, and a call to a pure procedure that
6717: /// raises, `set unused [add x 1]`). Every program prints what tclsh
6718: /// prints before and after `tcl opt`, from the first release that has its
6719: /// commands, and keeps its raising store.
6720: #[test]
6721: fn a_raising_store_is_never_dead() {
6722:     for (source, store, printed, first) in RAISING_STORES {
6723:         for dialect in ["tcl8.6", "tcl9.0"] {
6724:             let (rewritten, rewrites) = optimised(source, dialect);
6725:             assert!(
6726:                 rewritten.contains(store),
6727:                 "{dialect}: `{store}` raises and stays\n{rewritten}\n{rewrites:#?}"
6728:             );
6729:         }
6730:         prints_under_releases_from(source, printed, first);
6731:     }
6732: }
6733: 
6734: /// One program of [`a_call_that_cannot_raise_leaves_a_dead_store`].
6735: struct CompletingCall {
6736:     source: &'static str,
6737:     /// The unused store of the call.
6738:     store: &'static str,
6739:     /// Whether `tcl opt` drops it: only where the call cannot raise.
6740:     goes: bool,
6741:     printed: &'static str,
6742: }
6743: 
6744: /// The programs of [`a_call_that_cannot_raise_leaves_a_dead_store`].
6745: const COMPLETING_CALLS: [CompletingCall; 15] = [
6746:     // The registry baseline: `string length` completes whatever it is given.
6747:     CompletingCall {
6748:         source: "proc lbl {x} {return [string length $x]}\nproc main {} {\n    set a [lbl abc]\n    return 1\n}\nputs [main]\n",
6749:         store: "set a [lbl abc]",
6750:         goes: true,
6751:         printed: "1\n",
6752:     },
6753:     // The call's word reads a parameter, which is set.
6754:     CompletingCall {
6755:         source: "proc lbl {x} {set n [string length $x]; return $n}\nproc main {y} {\n    set a [lbl $y]\n    return 1\n}\nputs [main q]\n",
6756:         store: "set a [lbl $y]",
6757:         goes: true,
6758:         printed: "1\n",
6759:     },
6760:     // A literal return, reached through a second procedure.
6761:     CompletingCall {
6762:         source: "proc one {} {return 1}\nproc two {} {return [one]}\nproc main {} {\n    set a [two]\n    return 1\n}\nputs [main]\n",
6763:         store: "set a [two]",
6764:         goes: true,
6765:         printed: "1\n",
6766:     },
6767:     // `expr` raises for `x + 1`.
6768:     CompletingCall {
6769:         source: "proc add {a b} {expr {$a + $b}}\nproc main {} {\n    set a [add x 1]\n    return 1\n}\nputs [catch main]\n",
6770:         store: "set a [add x 1]",
6771:         goes: false,
6772:         printed: "1\n",
6773:     },
6774:     // A word count the parameters reject.
6775:     CompletingCall {
6776:         source: "proc lbl {x} {return [string length $x]}\nproc main {} {\n    set a [lbl]\n    return 1\n}\nputs [catch main]\n",
6777:         store: "set a [lbl]",
6778:         goes: false,
6779:         printed: "1\n",
6780:     },
6781:     // A recursion, which the nesting limit ends.
6782:     CompletingCall {
6783:         source: "proc rec {n} {return [string length [rec $n]]}\nproc main {} {\n    set a [rec 1]\n    return 1\n}\nputs [catch main]\n",
6784:         store: "set a [rec 1]",
6785:         goes: false,
6786:         printed: "1\n",
6787:     },
6788:     // `lindex` raises on a list with an unmatched brace.
6789:     CompletingCall {
6790:         source: "proc first {x} {return [lindex $x 0]}\nproc main {} {\n    set a [first \\{]\n    return 1\n}\nputs [catch main]\n",
6791:         store: "set a [first \\{]",
6792:         goes: false,
6793:         printed: "1\n",
6794:     },
6795:     // The call's word reads a variable nothing sets.
6796:     CompletingCall {
6797:         source: "proc lbl {x} {return [string length $x]}\nproc main {} {\n    set a [lbl $y]\n    return 1\n}\nputs [catch main]\n",
6798:         store: "set a [lbl $y]",
6799:         goes: false,
6800:         printed: "1\n",
6801:     },
6802:     // `lbl` in `::ns` is `::ns::lbl`, which raises, not the global one.
6803:     CompletingCall {
6804:         source: "proc ::lbl {x} {return [string length $x]}\nnamespace eval ns {\n    proc lbl {x} {error boom}\n    proc main {} {\n        set a [lbl abc]\n        return 1\n    }\n}\nputs [catch ns::main]\n",
6805:         store: "set a [lbl abc]",
6806:         goes: false,
6807:         printed: "1\n",
6808:     },
6809:     // `main` runs before `lbl`'s definition: `invalid command name`.
6810:     CompletingCall {
6811:         source: "proc main {} {\n    set a [lbl abc]\n    return 1\n}\nputs [catch main]\nproc lbl {x} {return [string length $x]}\n",
6812:         store: "set a [lbl abc]",
6813:         goes: false,
6814:         printed: "1\n",
6815:     },
6816:     // `lbl` is defined only under a condition that does not hold.
6817:     CompletingCall {
6818:         source: "if {[info exists ::env(TCL_LSP_NEVER_SET)]} {\n    proc lbl {x} {return [string length $x]}\n}\nproc main {} {\n    set a [lbl abc]\n    return 1\n}\nputs [catch main]\n",
6819:         store: "set a [lbl abc]",
6820:         goes: false,
6821:         printed: "1\n",
6822:     },
6823:     // A callback runs after the load, which defined `lbl`.
6824:     CompletingCall {
6825:         source: "proc main {} {\n    set a [lbl abc]\n    return 1\n}\nproc lbl {x} {return [string length $x]}\nafter 0 {puts [main]; set ::done 1}\nvwait ::done\n",
6826:         store: "set a [lbl abc]",
6827:         goes: true,
6828:         printed: "1\n",
6829:     },
6830:     // `lbl`'s body is `extra characters after close-quote`.
6831:     CompletingCall {
6832:         source: "proc lbl {x} {return [string length \"a\"b]}\nproc main {} {\n    set a [lbl abc]\n    return 1\n}\nputs [catch main]\n",
6833:         store: "set a [lbl abc]",
6834:         goes: false,
6835:         printed: "1\n",
6836:     },
6837:     // `lbl`'s body is `extra characters after close-brace`.
6838:     CompletingCall {
6839:         source: "proc lbl {x} {return [string length {a}b]}\nproc main {} {\n    set a [lbl abc]\n    return 1\n}\nputs [catch main]\n",
6840:         store: "set a [lbl abc]",
6841:         goes: false,
6842:         printed: "1\n",
6843:     },
6844:     // Under 8.4 `{*}` is a braced word, so `{*}$x` is the close-brace error;
6845:     // from 8.5 the expansion reaches `string length a b`.
6846:     CompletingCall {
6847:         source: "proc lbl {x} {return [string length {*}$x]}\nproc main {} {\n    set a [lbl {a b}]\n    return 1\n}\nputs [catch main]\n",
6848:         store: "set a [lbl {a b}]",
6849:         goes: false,
6850:         printed: "1\n",
6851:     },
6852: ];
6853: 
6854: /// The unused store of a call goes only where the call cannot raise:
6855: /// purity says a call changes nothing, not that it completes, so the
6856: /// call's procedure must complete whatever its arguments hold — a
6857: /// straight-line body that reads only what it set and runs only commands
6858: /// that complete so, `string length` among them — and be called with a word
6859: /// count its parameters accept, its words reading only set variables. A body
6860: /// whose `expr` or `lindex` may raise, a rejected word count, a recursion, an
6861: /// unset read and a procedure the caller's namespace shadows each keep the
6862: /// store, and so does a callee whose `proc` statement has not surely run
6863: /// where the caller runs — defined after the load first runs the caller, or
6864: /// under a condition — and a callee whose body holds a word the
6865: /// release's parser rejects; a caller only a callback runs, after the
6866: /// load, takes a callee defined anywhere at the top level. Every program
6867: /// prints what tclsh prints before and after `tcl opt` under every release.
6868: #[test]
6869: fn a_call_that_cannot_raise_leaves_a_dead_store() {
6870:     for call in &COMPLETING_CALLS {
6871:         for dialect in ["tcl8.4", "tcl8.6", "tcl9.0"] {
6872:             let (rewritten, rewrites) = optimised(call.source, dialect);
6873:             assert_eq!(
6874:                 !rewritten.contains(call.store),
6875:                 call.goes,
6876:                 "{dialect}: `{}` goes only where the call cannot raise\n{rewritten}\n{rewrites:#?}",
6877:                 call.store
6878:             );
6879:         }
6880:         prints_under_releases_from(call.source, call.printed, "8.4");
6881:     }
6882: }
6883: 
6884: /// A procedure of the module that takes a package command's name replaces
6885: /// it for every caller: `proc base32::encode` and `namespace eval
6886: /// base32 {proc encode …}` print `shadowed` on tclsh 8.5.19 to 9.1.0, so the
6887: /// `base32` route never answers through them — the call folds to its
6888: /// procedure's constant (O103), as before the route — and no condition
6889: /// reading the call is decided (I230). The route still answers where the
6890: /// package is required and nothing shadows it.
6891: #[test]
6892: fn a_shadowing_procedure_stops_a_package_route() {
6893:     let shadows = [
6894:         (
6895:             "namespace eval base32 {}\nproc base32::encode {x} {return shadowed}\nputs [base32::encode abc]\n",
6896:             "shadowed\n",
6897:         ),
6898:         (
6899:             "namespace eval base32 {\n    proc encode {x} {return shadowed}\n}\nputs [base32::encode abc]\nputs [base32::encode xyz]\n",
6900:             "shadowed\nshadowed\n",
6901:         ),
6902:         (
6903:             "namespace eval base32 {}\nproc base32::encode {x} {return shadowed}\nif {[base32::encode abc] eq \"shadowed\"} {puts yes} else {puts no}\n",
6904:             "yes\n",
6905:         ),
6906:     ];
6907:     for (source, printed) in shadows {
6908:         for dialect in ["tcl8.5", "tcl8.6", "tcl9.0", "tcl9.1"] {
6909:             let (rewritten, rewrites) = optimised(source, dialect);
6910:             assert!(
6911:                 !rewritten.contains("MFRGG===") && !rewritten.contains("if {0}"),
6912:                 "{dialect}: the module's procedure answers\n{rewritten}\n{rewrites:#?}"
6913:             );
6914:             assert!(
6915:                 !reports(source, dialect, DiagCode::I230),
6916:                 "{dialect}: no condition on the shadowed call is decided"
6917:             );
6918:         }
6919:         prints_under_releases_from(source, printed, "8.5");
6920:     }
6921:     let required = "package require base32\nset h [base32::encode abc]\nputs $h\n";
6922:     for dialect in ["tcl8.5", "tcl8.6", "tcl9.0", "tcl9.1"] {
6923:         let (rewritten, rewrites) = optimised(required, dialect);
6924:         assert!(
6925:             rewritten.contains("puts MFRGG==="),
6926:             "{dialect}: the route answers\n{rewritten}\n{rewrites:#?}"
6927:         );
6928:     }
6929: }
6930: 
6931: /// A route's decline is final: the interpolation rewriter never takes
6932: /// a word the lexer reads as one `[…]` apart, so `[string match -nocase
6933: /// {a]€} {€a}]`, whose route declines the collation, stays as written where
6934: /// the rewriter had cut it at the `]` inside the braces and emitted a
6935: /// program no tclsh parses. A declined route inside interpolation text
6936: /// leaves the word as written, and an answered one still folds. tclsh 8.4.20
6937: /// to 9.1.0 print the same before and after `tcl opt`.
6938: #[test]
6939: fn a_declined_route_leaves_its_word_as_written() {
6940:     for (source, printed, kept) in [
6941:         ("puts [string match -nocase {a]€} {€a}]\n", "0\n", true),
6942:         ("puts [string match -nocase {ba]😀[€} {€a}]\n", "0\n", true),
6943:         (
6944:             "puts \"x[string match -nocase {a€} {€a}]y\"\n",
6945:             "x0y\n",
6946:             true,
6947:         ),
6948:         ("puts [string match {ba]😀[€} {€a}]\n", "0\n", false),
6949:         ("puts \"x[string match {a*} abc]y\"\n", "x1y\n", false),
6950:     ] {
6951:         for dialect in ["tcl8.6", "tcl9.0"] {
6952:             let (rewritten, rewrites) = optimised(source, dialect);
6953:             if kept {
6954:                 assert_eq!(
6955:                     rewritten.lines().next(),
6956:                     source.lines().next(),
6957:                     "{dialect}: the declined word stays\n{rewrites:#?}"
6958:                 );
6959:             }
6960:         }
6961:         prints_under_every_release(source, printed);
6962:     }
6963: }
6964: 
6965: /// One program of [`a_level_zero_return_completes_where_it_stands`].
6966: struct LevelZeroReturn {
6967:     source: &'static str,
6968:     /// Statements a level-0 `return` leaves to run, which `tcl opt` keeps.
6969:     kept: &'static [&'static str],
6970:     /// Statements after a level-0 jump or error, which never run and O107
6971:     /// removes.
6972:     gone: &'static [&'static str],
6973:     printed: &'static str,
6974:     /// The first release that runs it.
6975:     first: &'static str,
6976: }
6977: 
6978: /// The programs of [`a_level_zero_return_completes_where_it_stands`].
6979: const LEVEL_ZERO_RETURNS: [LevelZeroReturn; 5] = [
6980:     LevelZeroReturn {
6981:         source: "proc p {} {return -level 0 -code ok x; puts \"after in p\"; return done}\nputs [p]\nreturn -level 0 -code ok top\nputs \"after at top\"\n",
6982:         kept: &["puts \"after in p\"", "puts \"after at top\""],
6983:         gone: &[],
6984:         printed: "after in p\ndone\nafter at top\n",
6985:         first: "8.5",
6986:     },
6987:     LevelZeroReturn {
6988:         source: "try {return -level 0 -code 0 x} on ok {v} {puts \"ok $v\"}\ntry {return -level 0 -code 2 x} on return {v} {puts \"ret $v\"}\n",
6989:         kept: &["puts \"ok $v\"", "puts \"ret $v\""],
6990:         gone: &[],
6991:         printed: "ok x\nret x\n",
6992:         first: "8.6",
6993:     },
6994:     LevelZeroReturn {
6995:         source: "proc p {} {\n    set n 0\n    foreach i {1 2 3 4} {\n        if {$i == 2} {return -level 0 -code continue}\n        if {$i == 4} {return -level 0 -code break}\n        incr n\n    }\n    return $n\n}\nputs [p]\n",
6996:         kept: &["incr n"],
6997:         gone: &[],
6998:         printed: "2\n",
6999:         first: "8.5",
7000:     },
7001:     LevelZeroReturn {
7002:         source: "proc e {} {\n    return -level 0 -code error -errorcode {A B} boom\n    set z 1\n    puts never\n}\nputs [catch e m]\nputs $m\nputs $::errorCode\n",
7003:         kept: &[],
7004:         gone: &["puts never"],
7005:         printed: "1\nboom\nA B\n",
7006:         first: "8.5",
7007:     },
7008:     LevelZeroReturn {
7009:         source: "proc p {} {\n    foreach i {1 2 3} {\n        return -level 0 -code break\n        set xb 1\n    }\n    foreach i {1 2} {\n        return -level 0 -code continue\n        set yc 1\n    }\n    return [list [info exists xb] [info exists yc]]\n}\nputs [p]\nproc q {} {\n    catch {return -level 0 -code error e; set xe 1}\n    return [info exists xe]\n}\nputs [q]\n",
7010:         kept: &["return [list [info exists xb] [info exists yc]]"],
7011:         gone: &["set xb 1", "set yc 1"],
7012:         printed: "0 0\n0\n",
7013:         first: "8.5",
7014:     },
7015: ];
7016: 
7017: /// A `return` at level 0 completes where it stands, with its code (#2357):
7018: /// `ok` runs on to the next statement, `error` raises, and `break` or
7019: /// `continue` leaves the loop around it. One decoding of `return`'s options,
7020: /// the registry's, answers the lowering, the CFG and the solver alike, and
7021: /// read a level-0 `return` as the procedure's exit no longer: O107 deleted
7022: /// the statements after `return -level 0 -code ok x` in a procedure and at
7023: /// the top level, and the `try` handlers its code selects. In a procedure, at
7024: /// the top level, in a loop and under `try`, each program prints what tclsh
7025: /// prints before and after `tcl opt`, from the first release with `-level`,
7026: /// and what follows a level-0 jump or error in its block never runs, which
7027: /// O107 removes. Under 8.4, which reads three options, `-level` is rejected,
7028: /// and `catch` reports it.
7029: #[test]
7030: fn a_level_zero_return_completes_where_it_stands() {
7031:     for program in &LEVEL_ZERO_RETURNS {
7032:         for dialect in ["tcl8.6", "tcl9.0"] {
7033:             let (rewritten, rewrites) = optimised(program.source, dialect);
7034:             for statement in program.kept {
7035:                 assert!(
7036:                     rewritten.contains(statement),
7037:                     "{dialect}: `{statement}` runs after a level-0 return\n{rewritten}\n{rewrites:#?}"
7038:                 );
7039:             }
7040:             for statement in program.gone {
7041:                 assert!(
7042:                     !rewritten.contains(statement),
7043:                     "{dialect}: `{statement}` never runs after a level-0 jump or error\n{rewritten}\n{rewrites:#?}"
7044:                 );
7045:             }
7046:         }
7047:         prints_under_releases_from(program.source, program.printed, program.first);
7048:     }
7049:     let rejected = "proc p {} {catch {return -level 0 -code ok x} m; return $m}\nputs [p]\n";
7050:     for (series, tclsh) in releases_on_path() {
7051:         let printed = if series == "8.4" {
7052:             "bad option \"-level\": must be -code, -errorcode, or -errorinfo\n"
7053:         } else {
7054:             "x\n"
7055:         };
7056:         let (rewritten, _) = optimised(rejected, &dialect_of(series));
7057:         for program in [rejected, rewritten.as_str()] {
7058:             assert_eq!(
7059:                 run_script(&tclsh, program),
7060:                 Some((true, printed.to_owned())),
7061:                 "tclsh{series}:\n{program}"
7062:             );
7063:         }
7064:     }
7065: }
7066: 
7067: /// The e5 program with its stub block in place: `db_query` and `db_eval`
7068: /// declared under each `-frame` word, called in a procedure that holds `g`.
7069: fn stubbed_e5(frame: &str) -> String {
7070:     format!(
7071:         "# tcl-lsp: stubs-begin\n# tcl-lsp: stub db_query {{sql}}{frame}\n\
7072:          # tcl-lsp: stub db_eval {{sql script:body}}{frame}\n# tcl-lsp: stubs-end\n\
7073:          proc q {{}} {{\n    set g 5\n    db_query {{select 1}}\n    \
7074:          if {{$g == 5}} {{puts five}} else {{puts other}}\n}}\n\
7075:          proc p {{}} {{\n    set g 5\n    db_eval {{select 1}} {{set g 6}}\n    \
7076:          if {{$g == 5}} {{puts five}} else {{puts other}}\n}}\nq\np\n"
7077:     )
7078: }
7079: 
7080: /// A stub that states its frame effect is a command the module can name.
7081: /// `-frame own` and `-frame none` state that the call crosses no
7082: /// frame, so the locals `q` holds at `db_query {select 1}` keep their values
7083: /// and `$g == 5` is decided; `-frame caller` states `argparse`'s effect, and a
7084: /// stub that states none may reach the frame that calls it as code the module
7085: /// cannot see may, so the condition stays open under both. A stub with a body
7086: /// role answers as the registry's rule answers for one: `db_eval`'s call is
7087: /// the barrier `time {…}` lowers to, and the condition after it stays open
7088: /// whatever the frame effect. Each declaration runs under tclsh with a
7089: /// definition it describes — a procedure that returns, or one that sets its
7090: /// caller's `g` through `upvar 1` — and prints what the claims allow.
7091: #[test]
7092: fn a_stub_that_states_its_frame_effect_is_a_named_head() {
7093:     let own = "proc db_query {sql} {return 1}\nproc db_eval {sql script} {uplevel 1 $script}\n";
7094:     let caller = "proc db_query {sql} {upvar 1 g g; set g 6}\nproc db_eval {sql script} {uplevel 1 $script}\n";
7095:     for (frame, definitions, claims, printed) in [
7096:         (" -frame own", own, &[true][..], "five\nother\n"),
7097:         (" -frame none", own, &[true][..], "five\nother\n"),
7098:         (" -frame caller", caller, &[][..], "other\nother\n"),
7099:         ("", caller, &[][..], "other\nother\n"),
7100:     ] {
7101:         let source = stubbed_e5(frame);
7102:         for dialect in ["tcl8.4", "tcl8.6", "tcl9.0"] {
7103:             assert_eq!(
7104:                 condition_claims(&source, dialect),
7105:                 claims,
7106:                 "{dialect}{frame}:\n{source}"
7107:             );
7108:         }
7109:         for (series, tclsh) in releases_on_path() {
7110:             assert_eq!(
7111:                 run_script(&tclsh, &format!("{definitions}{source}")),
7112:                 Some((true, printed.to_owned())),
7113:                 "tclsh{series}{frame}"
7114:             );
7115:         }
7116:     }
7117:     let registry = static_context_for("tcl8.6").commands();
7118:     let barrier_of = |source: &str, head: &str| {
7119:         let declared =
7120:             tcl_compiler::analyser::utils::document_declared_surface(source, None, "tcl8.6");
7121:         let module = tcl_compiler::lowering::lower_to_ir_with(
7122:             tcl_compiler::lowering::Lowerer::with_config(
7123:                 registry,
7124:                 tcl_lexer::LexerConfig::for_profile(registry.profile()),
7125:             )
7126:             .with_declared_commands(Some(&declared)),
7127:             source,
7128:         );
7129:         let mut reasons = Vec::new();
7130:         tcl_compiler::ir::for_each_statement(
7131:             &module
7132:                 .procedures
7133:                 .get(&fixture_id(&module.procedures, "::p"))
7134:                 .expect("authored fixture body")
7135:                 .body,
7136:             &mut |statement| {
7137:                 if let Statement::Barrier {
7138:                     command, reason, ..
7139:                 } = statement
7140:                     && command == head
7141:                 {
7142:                     reasons.push(reason.clone());
7143:                 }
7144:             },
7145:         );
7146:         reasons
7147:     };
7148:     let timed = barrier_of(
7149:         "proc p {} {\n    set g 5\n    time {set g 6}\n    puts $g\n}\n",
7150:         "time",
7151:     );
7152:     assert_eq!(timed, ["unsupported body command"]);
7153:     for frame in ["", " -frame own", " -frame none", " -frame caller"] {
7154:         assert_eq!(barrier_of(&stubbed_e5(frame), "db_eval"), timed, "{frame}");
7155:     }
7156:     // Run as a callback, a command that reaches the frame it runs in writes
7157:     // the global frame: `$done` stays open after `update` under `-frame
7158:     // caller`, and with no `-frame`, where tclsh prints 1.
7159:     let callback = |frame: &str| {
7160:         format!(
7161:             "# tcl-lsp: stubs-begin\n# tcl-lsp: stub db_bind {{spec}}{frame}\n\
7162:              # tcl-lsp: stubs-end\nset done 0\nafter 10 {{db_bind {{done}}}}\nafter 50\n\
7163:              update\nif {{$done}} {{puts 1}} else {{puts 0}}\n"
7164:         )
7165:     };
7166:     let reaches = "proc db_bind {spec} {upvar 1 done d; set d 1}\n";
7167:     for (frame, definition, claims, printed) in [
7168:         (" -frame caller", reaches, &[][..], "1\n"),
7169:         ("", reaches, &[][..], "1\n"),
7170:         (
7171:             " -frame own",
7172:             "proc db_bind {spec} {return}\n",
7173:             &[false][..],
7174:             "0\n",
7175:         ),
7176:     ] {
7177:         let source = callback(frame);
7178:         for dialect in ["tcl8.4", "tcl8.6", "tcl9.0"] {
7179:             assert_eq!(
7180:                 condition_claims(&source, dialect),
7181:                 claims,
7182:                 "{dialect}{frame}:\n{source}"
7183:             );
7184:         }
7185:         for (series, tclsh) in releases_on_path() {
7186:             assert_eq!(
7187:                 run_script(&tclsh, &format!("{definition}{source}")),
7188:                 Some((true, printed.to_owned())),
7189:                 "tclsh{series}{frame}"
7190:             );
7191:         }
7192:     }
7193: }
7194: 
7195: /// A lambda an `after` callback applies runs its body in a frame of its own,
7196: /// so what it writes in the global frame is the callback's write: the scan of
7197: /// callback scripts reads the lambda as a procedure's summary reads a body,
7198: /// and `$done` after `update` decides nothing. Each program prints `changed`
7199: /// and `1` under tclsh 8.5 to 9.1, before and after `tcl opt`, where the
7200: /// rewrite had printed `zero` and `0`.
7201: #[test]
7202: fn a_lambda_a_callback_applies_writes_the_globals_its_body_writes() {
7203:     for (lambda, words) in [
7204:         ("{} {global done; set done 1}", ""),
7205:         ("{} {set ::done 1}", ""),
7206:         ("{} {upvar #0 done d; set d 1}", ""),
7207:         ("{} {incr ::done}", ""),
7208:         ("{} {global done; foreach done {1} {}}", ""),
7209:         ("{} {global done; catch {set done 1}}", ""),
7210:         ("{} {uplevel #0 {set done 1}}", ""),
7211:         ("{} {apply {{} {global done; set done 1}}}", ""),
7212:         ("{} {after 0 {set done 1}; update}", ""),
7213:         ("{x} {global done; set done $x}", " 1"),
7214:     ] {
7215:         for callback in [
7216:             format!("after 10 {{apply {{{lambda}}}{words}}}"),
7217:             format!("after 10 [list apply {{{lambda}}}{words}]"),
7218:         ] {
7219:             let source = format!(
7220:                 "set done 0\n{callback}\nafter 50\nupdate\n\
7221:                  if {{$done eq 0}} {{puts zero}} else {{puts changed}}\nputs $done\n"
7222:             );
7223:             prints_under_releases_from(&source, "changed\n1\n", "8.5");
7224:         }
7225:     }
7226: }
7227: 
7228: /// A `try` body that cannot fall through is thrown to from the point it
7229: /// raises at, and its first command may fail before it stores anything, with
7230: /// the state the body entered with: after `try {set x [expr {1 / $d}]; error
7231: /// boom} on error {} {}` the handler sees `x` unbound where the division
7232: /// raised, so `info exists x` decides nothing, the program prints `no` for a
7233: /// zero divisor and `yes` for any other, and it does so before and after `tcl
7234: /// opt`.
7235: #[test]
7236: fn a_body_that_ends_in_an_error_may_have_failed_at_its_start() {
7237:     let source = "proc p {d} {\n    try {set x [expr {1 / $d}]; error boom} on error {} {}\n    if {[info exists x]} {return yes}\n    return no\n}\nputs [p 0]\nputs [p 1]\n";
7238:     for dialect in ["tcl8.6", "tcl9.0"] {
7239:         let (rewritten, _) = optimised(source, dialect);
7240:         assert!(
7241:             rewritten.contains("return no"),
7242:             "{dialect}: x may be unbound where the handler runs\n{rewritten}"
7243:         );
7244:     }
7245:     prints_under_releases_from(source, "no\nyes\n", "8.6");
7246: }
7247: 
7248: /// The ways a `try` body or one of its handlers leaves, each with a `finally`
7249: /// clause that sets the global `g`: what a procedure runs and why the clause
7250: /// is reached.
7251: const FINALLY_PATHS: [(&str, &str); 13] = [
7252:     ("an error", "try {error boom} finally {set g 1}"),
7253:     ("a throw", "try {throw {A B} boom} finally {set g 1}"),
7254:     ("a return", "try {return early} finally {set g 1}"),
7255:     (
7256:         "a break out of a loop",
7257:         "while 1 { try {break} finally {set g 1} }",
7258:     ),
7259:     (
7260:         "an error in a loop",
7261:         "foreach i {1 2} { try {error boom} finally {set g 1} }",
7262:     ),
7263:     (
7264:         "every branch of an if leaving",
7265:         "try {if {[info exists ::c]} {return ok} else {error boom}} finally {set g 1}",
7266:     ),
7267:     (
7268:         "every arm of a switch leaving",
7269:         "try {switch [info exists ::c] {1 {return ok} default {error boom}}} finally {set g 1}",
7270:     ),
7271:     ("a tailcall", "try {tailcall list} finally {set g 1}"),
7272:     (
7273:         "a handler's return",
7274:         "try {error boom} on error {} {return handled} finally {set g 1}",
7275:     ),
7276:     (
7277:         "a handler's error",
7278:         "try {error boom} on error {} {error again} finally {set g 1}",
7279:     ),
7280:     (
7281:         "a handler's break",
7282:         "foreach i {1 2} { try {error boom} on error {} {break} finally {set g 1} }",
7283:     ),
7284:     (
7285:         "an exit that rejects its status",
7286:         "try {exit abc} finally {set g 1}",
7287:     ),
7288:     (
7289:         "an error only a trap might take",
7290:         "try {error boom} trap {NOT MATCHING} {} {exit 0} finally {set g 1}",
7291:     ),
7292: ];
7293: 
7294: /// A `finally` clause runs however the `try` body or a handler leaves, so its
7295: /// body is live on every path (#2142). Each statement of [`FINALLY_PATHS`] sets
7296: /// the global `g` in its clause, and `catch {p}; puts $g` prints `1` under
7297: /// tclsh 8.6 to 9.1 before and after the optimiser, which had emptied the
7298: /// clause and printed `0`; so does a `return $x` whose substitution only a
7299: /// handler that exits may take, and a handler that exits once its variable is
7300: /// bound, where a write trace refuses the binding. In a procedure, `set f 0;
7301: /// try {error boom} finally {set f 1}; return $f` reads no unset `f`: the body
7302: /// always raises, so the `return` never runs and both stores are dead — W220
7303: /// is a true positive on each — and once a `catch` lets the `return` run, the
7304: /// clause's store is the one it reads. The issue's two programs that must keep
7305: /// firing still do: a handler that may not run binds nothing (W210), and a
7306: /// handler's store the clause overwrites is dead (W220).
7307: #[test]
7308: fn try_finally_runs_on_every_path() {
7309:     let mut sources: Vec<(String, &str)> = FINALLY_PATHS
7310:         .iter()
7311:         .map(|(why, statement)| {
7312:             (
7313:                 format!(
7314:                     "set g 0\nproc p {{}} {{\n    global g\n    {statement}\n}}\ncatch {{p}}\nputs $g\n"
7315:                 ),
7316:                 *why,
7317:             )
7318:         })
7319:         .collect();
7320:     sources.push((
7321:         "set g 0\nproc p {x} {\n    global g\n    try {return $x} on error {} {exit 0} finally {set g 1}\n}\np 5\nputs $g\n".to_owned(),
7322:         "a return a handler takes only the substitution's error of",
7323:     ));
7324:     sources.push((
7325:         "set g 0\nproc tr args {error TRACE}\nproc p {} {\n    global g\n    trace add variable msg write tr\n    try {error boom} on error msg {exit 0} finally {set g 1}\n}\ncatch p\nputs $g\n".to_owned(),
7326:         "a handler whose binding a trace refuses before its exit",
7327:     ));
7328:     for (source, why) in &sources {
7329:         for dialect in ["tcl8.6", "tcl9.0"] {
7330:             let (rewritten, _) = optimised(source, dialect);
7331:             assert!(
7332:                 rewritten.contains("set g 1"),
7333:                 "{why}: {dialect}: the clause runs on this path\n{rewritten}"
7334:             );
7335:         }
7336:         prints_under_releases_from(source, "1\n", "8.6");
7337:     }
7338: 
7339:     let issue =
7340:         "proc p {} {\n    set f 0\n    try {error boom} finally {set f 1}\n    return $f\n}\n";
7341:     let caught = "proc p {} {\n    set f 0\n    catch {try {error boom} finally {set f 1}}\n    return $f\n}\nputs [p]\n";
7342:     let unbound =
7343:         "proc q {c} {\n    try {if {$c} {error boom}} on error {} {set g 1}\n    return $g\n}\n";
7344:     let overwritten = "proc p {} {\n    try {error boom} on error {} {set f 2} finally {set f 1}\n    return $f\n}\n";
7345:     for dialect in ["tcl8.6", "tcl9.0"] {
7346:         assert!(
7347:             !reports(issue, dialect, DiagCode::W210),
7348:             "{dialect}: the clause binds `f` before any read\n{issue}"
7349:         );
7350:         assert!(
7351:             reports(issue, dialect, DiagCode::W220),
7352:             "{dialect}: the `return` never runs, so both stores are dead\n{issue}"
7353:         );
7354:         assert!(
7355:             !reports(caught, dialect, DiagCode::W210),
7356:             "{dialect}\n{caught}"
7357:         );
7358:         let (rewritten, _) = optimised(caught, dialect);
7359:         assert!(
7360:             rewritten.contains("set f 1"),
7361:             "{dialect}: the clause's store is read\n{rewritten}"
7362:         );
7363:         assert!(
7364:             reports(unbound, dialect, DiagCode::W210),
7365:             "{dialect}: a handler that may not run binds nothing\n{unbound}"
7366:         );
7367:         assert!(
7368:             reports(overwritten, dialect, DiagCode::W220),
7369:             "{dialect}: the clause overwrites the handler's store\n{overwritten}"
7370:         );
7371:     }
7372:     prints_under_releases_from(caught, "1\n", "8.6");
7373: }
7374: 
7375: /// A `try`'s handlers are read once, by the registry's handler chain, and the
7376: /// control-flow graph wires the edges it names. The first match runs, so a
7377: /// handler an earlier unconditional one pre-empts runs nothing — a `-` handler
7378: /// pre-empts like any other, a `trap` never does; a `-` handler runs its
7379: /// owner's script, which a match reaches with the group's names bound; and a
7380: /// `break` the first matching handler selects goes to that handler, not to its
7381: /// loop. Each program prints what tclsh 8.6 to 9.1 print, before and after the
7382: /// optimiser, and reads no unset name (no W210).
7383: #[test]
7384: fn try_handlers_run_as_the_registry_chain_reads_them() {
7385:     let programs = [
7386:         (
7387:             "proc p {} {\n    try {error boom} on error {} {set x 1} on error {} {return} finally {puts $x}\n}\np\n",
7388:             "1\n",
7389:         ),
7390:         (
7391:             "proc p {} {\n    set x 1\n    try {error boom} on error {} - on ok {} {} on error {} {unset x; return} finally {puts $x}\n}\np\n",
7392:             "1\n",
7393:         ),
7394:         (
7395:             "proc p {} {\n    set x 0\n    try {error boom} on error {} - on ok {} {set x 1} finally {}\n    return $x\n}\nputs [p]\n",
7396:             "1\n",
7397:         ),
7398:         (
7399:             "proc p {} {\n    try {error boom} on error {} - on ok {} {set x 1} finally {puts $x}\n}\np\n",
7400:             "1\n",
7401:         ),
7402:         (
7403:             "proc q {} {\n    try {error boom} on error {m} - on ok {} {return \"caught $m\"}\n    return after\n}\nputs [q]\n",
7404:             "caught boom\n",
7405:         ),
7406:         (
7407:             "proc s {} {\n    try {error boom} trap {X} {} {return T} on error {} {return E}\n}\nputs [s]\n",
7408:             "E\n",
7409:         ),
7410:         (
7411:             "proc p {} {\n    while 1 {\n        try {break} on break {} {set x 1} finally {}\n        break\n    }\n    puts $x\n}\np\n",
7412:             "1\n",
7413:         ),
7414:         (
7415:             "proc p {} {\n    while 1 {\n        try {break} on break {} {set x 1}\n        break\n    }\n    puts $x\n}\np\n",
7416:             "1\n",
7417:         ),
7418:     ];
7419:     for (source, printed) in programs {
7420:         for dialect in ["tcl8.6", "tcl9.0"] {
7421:             assert!(
7422:                 !reports(source, dialect, DiagCode::W210),
7423:                 "{dialect}: every path into the read binds it\n{source}"
7424:             );
7425:         }
7426:         prints_under_releases_from(source, printed, "8.6");
7427:     }
7428: }
7429: 
7430: /// A handler's selector is read with the target's numerals: `on 010` takes
7431: /// code 8 up to 8.6 and code 10 from 9.0. A body that completes with code 8
7432: /// reaches the handler under 8.6, so its store stays and `catch p; puts $g`
7433: /// prints `1`; from 9.0 nothing takes the code, the handler never runs, its
7434: /// store is dead and the program prints `0`. Each release prints the same
7435: /// before and after the optimiser under its own dialect.
7436: #[test]
7437: fn a_handler_selector_reads_the_targets_numerals() {
7438:     let source = "set g 0\nproc p {} {\n    global g\n    try {return -level 0 -code 8 boom} on 010 {} {set g 1} finally {}\n}\ncatch p\nputs $g\n";
7439:     let (under_8_6, _) = optimised(source, "tcl8.6");
7440:     assert!(
7441:         under_8_6.contains("set g 1"),
7442:         "8.6 reads `010` as 8: the handler runs\n{under_8_6}"
7443:     );
7444:     let (under_9_0, _) = optimised(source, "tcl9.0");
7445:     assert!(
7446:         !under_9_0.contains("set g 1"),
7447:         "9.0 reads `010` as 10: the handler never runs\n{under_9_0}"
7448:     );
7449:     for (series, tclsh) in releases_on_path() {
7450:         if series < "8.6" {
7451:             continue;
7452:         }
7453:         let printed = if series == "8.6" { "1\n" } else { "0\n" };
7454:         let (rewritten, _) = optimised(source, &dialect_of(series));
7455:         for program in [source, rewritten.as_str()] {
7456:             assert_eq!(
7457:                 run_script(&tclsh, program),
7458:                 Some((true, printed.to_owned())),
7459:                 "tclsh{series}:\n{program}"
7460:             );
7461:         }
7462:     }
7463: }
7464: 
7465: /// A handler that never runs — one an earlier handler pre-empts, a `-`
7466: /// handler whose script is its owner's, one the body's completion is known
7467: /// to miss, and one whose only way in is a normal completion the body never
7468: /// makes — leaves the `try` that does run. The binding of a handler's
7469: /// variables carries the span of the whole `try`, and the optimiser had
7470: /// deleted it with the dead handler: the `try` vanished, with the handler
7471: /// that runs and the `break` of its body. Each program prints what tclsh 8.6
7472: /// to 9.1 print before and after the optimiser, and the `try` stays.
7473: #[test]
7474: fn a_handler_that_never_runs_keeps_its_try() {
7475:     let programs = [
7476:         (
7477:             "proc p {} {\n    try {error boom} on error {} {puts first} on 1 {m} {puts second}\n    puts after\n}\np\n",
7478:             "first\nafter\n",
7479:             "try {error boom}",
7480:         ),
7481:         (
7482:             "proc p {} {\n    try {error boom} on error {m} - on ok {} {puts \"caught $m\"}\n    puts after\n}\np\n",
7483:             "caught boom\nafter\n",
7484:             "try {error boom}",
7485:         ),
7486:         (
7487:             "proc p {} {\n    foreach i {1 2} {\n        puts $i\n        try {break} on error {m} {puts caught}\n        puts after\n    }\n    puts done\n}\np\n",
7488:             "1\ndone\n",
7489:             "try {break}",
7490:         ),
7491:         (
7492:             "proc p {} {\n    try {\n        try {error a} finally {}\n        puts unreached\n    } on ok {m} {puts ok} on error {} {puts caught}\n    puts after\n}\np\n",
7493:             "caught\nafter\n",
7494:             "try {error a}",
7495:         ),
7496:     ];
7497:     for (source, printed, kept) in programs {
7498:         for dialect in ["tcl8.6", "tcl9.0"] {
7499:             let (rewritten, _) = optimised(source, dialect);
7500:             assert!(
7501:                 rewritten.contains(kept),
7502:                 "{dialect}: the `try` stays\n{rewritten}"
7503:             );
7504:         }
7505:         prints_under_releases_from(source, printed, "8.6");
7506:     }
7507: }
7508: 
7509: /// What the `finally` clause resumes once it is done. A `try` that never
7510: /// completes normally does not fall through its clause: after `try {break} on
7511: /// error {} {} finally {}` in a loop, `set x 1` never runs and the read after
7512: /// the loop is of an unset `x` (W210, a true positive: tclsh fails there), and
7513: /// after `try {return early} on error {} {} finally {}` the code that follows
7514: /// is dead (O107). A clause that itself transfers control keeps its transfer:
7515: /// its `break` overrides a pending `return`, so the code after the loop runs.
7516: /// A `return` an inner `try … finally` intercepts reaches the outer clause
7517: /// through the inner one, so the name the inner clause binds is bound; an
7518: /// inner handler that catches an error runs before the outer clause; a `break`
7519: /// leaves through both clauses in order; and a `return` that passes an inner
7520: /// clause resumes past the code after the inner `try`, where the outer clause
7521: /// may read an unset name (W210, a true positive). Each program prints what
7522: /// tclsh 8.6 to 9.1 print before and after the optimiser.
7523: #[test]
7524: fn a_finally_resumes_what_it_interrupted() {
7525:     let never_completes = "proc p {} {\n    while 1 {\n        try {break} on error {} {} finally {}\n        set x 1\n    }\n    puts $x\n}\n";
7526:     let returns = "proc p {} {\n    try {return early} on error {} {} finally {}\n    set x 1\n    return $x\n}\nputs [p]\n";
7527:     let resumes_past = "proc p {c} {\n    try { try {if {$c} {return}} finally {}; set x 1 } finally {puts $x}\n}\np 0\n";
7528:     for dialect in ["tcl8.6", "tcl9.0"] {
7529:         assert!(
7530:             reports(never_completes, dialect, DiagCode::W210),
7531:             "{dialect}: `set x 1` never runs\n{never_completes}"
7532:         );
7533:         assert!(
7534:             rewrites_of(returns, dialect)
7535:                 .iter()
7536:                 .any(|rewrite| rewrite.code == DiagCode::O107),
7537:             "{dialect}: the code after the `try` is dead\n{returns}"
7538:         );
7539:         assert!(
7540:             reports(resumes_past, dialect, DiagCode::W210),
7541:             "{dialect}: the outer clause may read `x` unset\n{resumes_past}"
7542:         );
7543:         assert!(
7544:             !rewrites_of(resumes_past, dialect)
7545:                 .iter()
7546:                 .any(|rewrite| rewrite.code == DiagCode::O102),
7547:             "{dialect}: `x` has no single reaching definition\n{resumes_past}"
7548:         );
7549:     }
7550:     prints_under_releases_from(returns, "early\n", "8.6");
7551:     prints_under_releases_from(resumes_past, "1\n", "8.6");
7552: 
7553:     let programs = [
7554:         (
7555:             "proc p {} {\n    while 1 { try {return early} finally {break} }\n    set x 1\n    return \"after $x\"\n}\nputs [p]\n",
7556:             "after 1\n",
7557:         ),
7558:         (
7559:             "proc p {} {\n    try { try {return ok} finally {set x 1} } finally {puts $x}\n}\np\n",
7560:             "1\n",
7561:         ),
7562:         (
7563:             "proc p {} {\n    try {try {error boom} on error {} {set x 1; return} finally {set y 1}} finally {puts $x; puts $y}\n}\np\n",
7564:             "1\n1\n",
7565:         ),
7566:         (
7567:             "proc p {} {\n    set x 0\n    while 1 {\n        try { try {unset x; break} finally {set y 1} } finally {set x 5}\n    }\n    return $x\n}\nputs [p]\n",
7568:             "5\n",
7569:         ),
7570:         (
7571:             "proc p {} {\n    set x 0\n    while {$x < 3} {\n        try {unset x; continue} finally {set x 5}\n    }\n    return $x\n}\nputs [p]\n",
7572:             "5\n",
7573:         ),
7574:     ];
7575:     for (source, printed) in programs {
7576:         for dialect in ["tcl8.6", "tcl9.0"] {
7577:             assert!(
7578:                 !reports(source, dialect, DiagCode::W210),
7579:                 "{dialect}: every path into the read binds it\n{source}"
7580:             );
7581:         }
7582:         prints_under_releases_from(source, printed, "8.6");
7583:     }
7584: }
7585: 
7586: /// A process exit runs no `finally`: in `try {exit 7} finally {set g 1}` the
7587: /// clause is never entered, so its store is dead code (O107), where a
7588: /// `return` or an error would have run it.
7589: #[test]
7590: fn an_exit_runs_no_finally() {
7591:     for body in ["exit", "exit 7"] {
7592:         let source =
7593:             format!("proc p {{}} {{\n    global g\n    try {{{body}}} finally {{set g 1}}\n}}\n");
7594:         for dialect in ["tcl8.6", "tcl9.0"] {
7595:             assert!(
7596:                 rewrites_of(&source, dialect)
7597:                     .iter()
7598:                     .any(|rewrite| rewrite.code == DiagCode::O107),
7599:                 "{dialect}: the clause is never entered\n{source}"
7600:             );
7601:         }
7602:     }
7603: }
7604: 
7605: /// A body that leaves before its last statement is thrown to from where it
7606: /// leaves, not from the dead code after it: the handler of `try {return r3;
7607: /// set v 8} on return {} {puts t8}` runs, where its only edge had come from
7608: /// the dead `set v 8` and the optimiser deleted the handler's body and the code
7609: /// after the `try`; a dead `error` after the `return` is no throw point that
7610: /// takes the `return`'s place; and a `break` caught by `on break` binds the
7611: /// handler's store on each pass. Each program prints what tclsh 8.6 to 9.1
7612: /// print, before and after the optimiser, and reads no unset name.
7613: #[test]
7614: fn a_handler_is_thrown_to_from_where_the_body_leaves() {
7615:     let programs = [
7616:         (
7617:             "proc p {} {\n    try {return r3; set v 8} on return {} {puts t8}\n    return done\n}\nputs [p]\n",
7618:             "t8\ndone\n",
7619:         ),
7620:         (
7621:             "proc p {} {\n    set x 1\n    try {set x 5; return r3; set y 1} on return {} {puts \"h $x\"}\n    puts $x\n}\np\n",
7622:             "h 5\n5\n",
7623:         ),
7624:         (
7625:             "proc p {} {\n    try {return r3; error dead} on return {} {puts t8}\n    return done\n}\nputs [p]\n",
7626:             "t8\ndone\n",
7627:         ),
7628:         (
7629:             "proc p {} {\n    foreach i {1 2} {\n        try {break; set y 1} on break {} {set x $i}\n    }\n    puts $x\n}\np\n",
7630:             "2\n",
7631:         ),
7632:     ];
7633:     for (source, printed) in programs {
7634:         for dialect in ["tcl8.6", "tcl9.0"] {
7635:             assert!(
7636:                 !reports(source, dialect, DiagCode::W210),
7637:                 "{dialect}: every path into the read binds it\n{source}"
7638:             );
7639:         }
7640:         prints_under_releases_from(source, printed, "8.6");
7641:     }
7642: }
7643: 
7644: /// The ways a `try` body, or a script it holds, fails between two stores, each
7645: /// with what tclsh 8.6 to 9.1 print and the store a failure leaves, which is
7646: /// no dead store. `foo` raises with no argument and with `2`, and `p 1` sets
7647: /// `x` to 1 before the statement, so each program prints the value stored
7648: /// before the failure where the store after it would have given another.
7649: const BETWEEN_TWO_STORES: [(&str, &str, &str, &str); 16] = [
7650:     (
7651:         "a handler",
7652:         "try {set x 2; foo; set x 3} on error {} {puts $x}",
7653:         "2\n",
7654:         "set x 2",
7655:     ),
7656:     (
7657:         "a finally clause no handler stands in for",
7658:         "try {set x 2; foo; set x 3} finally {puts $x}",
7659:         "2\n",
7660:         "set x 2",
7661:     ),
7662:     (
7663:         "a finally clause, where the first command fails before it stores",
7664:         "try {set x [foo]; set x 3} finally {puts $x}",
7665:         "1\n",
7666:         "set x 1",
7667:     ),
7668:     (
7669:         "a handler and the clause after it",
7670:         "try {set x 2; foo; set x 3} on error {} {puts \"h $x\"} finally {puts \"f $x\"}",
7671:         "h 2\nf 2\n",
7672:         "set x 2",
7673:     ),
7674:     (
7675:         "a body that cannot fall through",
7676:         "try {set x 2; foo; set x 3; error boom} on error {} {puts $x}",
7677:         "2\n",
7678:         "set x 2",
7679:     ),
7680:     (
7681:         "an arm of an if",
7682:         "try {if {$c} {set x 2; foo; set x 3}} on error {} {puts $x}",
7683:         "2\n",
7684:         "set x 2",
7685:     ),
7686:     (
7687:         "an arm, with the clause",
7688:         "try {if {$c} {set x 2; foo; set x 3}} finally {puts $x}",
7689:         "2\n",
7690:         "set x 2",
7691:     ),
7692:     (
7693:         "a loop body",
7694:         "try {foreach i {1 2} {set x $i; foo $i; set x 9}} on error {} {puts $x}",
7695:         "2\n",
7696:         "set x $i",
7697:     ),
7698:     (
7699:         "a for loop",
7700:         "try {for {set i 0} {$i < 3} {incr i} {set x $i; foo $i}} on error {} {puts $x}",
7701:         "2\n",
7702:         "set x $i",
7703:     ),
7704:     (
7705:         "an arm of a switch",
7706:         "try {switch $c {1 {set x 2; foo; set x 3} default {set x 4}}} on error {} {puts $x}",
7707:         "2\n",
7708:         "set x 2",
7709:     ),
7710:     (
7711:         "a nested try no handler of which takes the error",
7712:         "try {try {set x 2; foo; set x 3} on break {} {}} on error {} {puts $x}",
7713:         "2\n",
7714:         "set x 2",
7715:     ),
7716:     (
7717:         "a nested try with no handler",
7718:         "try {try {set x 2; foo; set x 3}} on error {} {puts $x}",
7719:         "2\n",
7720:         "set x 2",
7721:     ),
7722:     (
7723:         "a handler of a nested try",
7724:         "try {try {error a} on error {} {set x 2; foo; set x 3}} on error {} {puts $x}",
7725:         "2\n",
7726:         "set x 2",
7727:     ),
7728:     (
7729:         "the clause of a nested try",
7730:         "try {try {error a} finally {set x 2; foo; set x 3}} on error {} {puts $x}",
7731:         "2\n",
7732:         "set x 2",
7733:     ),
7734:     (
7735:         "a trap",
7736:         "try {set x 2; foo; set x 3} trap {} {} {puts $x}",
7737:         "2\n",
7738:         "set x 2",
7739:     ),
7740:     (
7741:         "a handler a `-` handler hands its match to",
7742:         "try {set x 2; foo; set x 3} on error {m} - on ok {} {puts $x}",
7743:         "2\n",
7744:         "set x 2",
7745:     ),
7746: ];
7747: 
7748: /// A command of a `try` body may fail wherever it stands, at any depth, and a
7749: /// handler or the `finally` clause is thrown to with what the body has stored
7750: /// by then. Each statement of [`BETWEEN_TWO_STORES`] stores 2, calls `foo`,
7751: /// which raises, and stores another value: the handler or clause prints 2
7752: /// under tclsh 8.6 to 9.1, before and after the optimiser, and `set x 2` is
7753: /// no dead store. The optimiser had deleted it and forwarded the store after
7754: /// the failure: `try {set x 2; foo; set x 3} finally {puts $x}` became `puts
7755: /// 3`, and `set x 1; try {set x 2; foo; set x 1} on error {} {}; puts $x`
7756: /// printed `1`, since the handler and the clause were thrown to from the
7757: /// state before the body and at its end alone.
7758: #[test]
7759: fn a_try_body_is_thrown_to_from_between_its_stores() {
7760:     for (why, statement, printed, kept) in BETWEEN_TWO_STORES {
7761:         let source = format!(
7762:             "proc foo {{args}} {{if {{$args eq {{}} || [lindex $args 0] == 2}} {{error x}}}}\nproc p {{c}} {{\n    set x 1\n    {statement}\n}}\ncatch {{p 1}}\n"
7763:         );
7764:         for dialect in ["tcl8.6", "tcl9.0"] {
7765:             let (rewritten, _) = optimised(&source, dialect);
7766:             assert!(
7767:                 rewritten.contains(kept),
7768:                 "{why}: {dialect}: `{kept}`, the store a failure leaves, stays\n{rewritten}"
7769:             );
7770:         }
7771:         prints_under_releases_from(&source, printed, "8.6");
7772:     }
7773:     let issue = "proc foo {} {error x}\nproc p {} {\n    set x 1\n    try {set x 2; foo; set x 1} on error {} {}\n    puts $x\n}\np\n";
7774:     for dialect in ["tcl8.6", "tcl9.0"] {
7775:         let held = last_value(issue, dialect, "::p", "x");
7776:         assert!(
7777:             !matches!(held, LatticeValue::Const(ConstValue::Int(1))),
7778:             "{dialect}: the handler may see 2, not a constant 1: {held:?}"
7779:         );
7780:     }
7781:     prints_under_releases_from(issue, "2\n", "8.6");
7782: }
7783: 
7784: /// The blocks a `try` body is split into keep what the handlers and the clause
7785: /// were proved of it as one block. A statement that completes with its code
7786: /// from the state before it stays with the statement before it, and the first
7787: /// statements of the body read as one run: `set z 0; error boom` and `set a 1;
7788: /// set b 2; error boom` are an error an `on error` handler takes whole, so the
7789: /// clause around a nested `try` sees the name that handler binds (no W210).
7790: /// The clause is thrown to the state before a statement only where that
7791: /// failure escapes the handlers: a literal assignment raises an error alone,
7792: /// which an `on error` handler takes, and which an `on break` handler does not
7793: /// see at all, so a `break` it takes is still forwarded the value stored
7794: /// before it. And a statement that leaves after its own
7795: /// stores is thrown from the state it leaves, where the next command raises
7796: /// only after a store: `upfoo` writes `x` and raises before `lassign` runs, so
7797: /// the handler sees `a` still `old`, and where a `catch` follows it, which
7798: /// runs its own script first, so that the `on break` handler sees what a
7799: /// `return -code break` left. Each program prints what tclsh 8.6 to 9.1
7800: /// print, before and after the optimiser.
7801: #[test]
7802: fn a_split_try_body_keeps_what_its_handlers_were_proved() {
7803:     let programs = [
7804:         (
7805:             "proc p {} {\n    try { try {set z 0; error boom} on error {} {set x 1; return} finally {} } finally {puts $x}\n}\np\n",
7806:             "1\n",
7807:         ),
7808:         (
7809:             "proc p {} {\n    try { try {set a 1; set b 2; error boom} on error {} {set x 1; return} finally {} } finally {puts $x}\n}\np\n",
7810:             "1\n",
7811:         ),
7812:         (
7813:             "proc p {} {\n    try { try {set {[} 0; error boom} on error {} {set x 1; return} finally {} } finally {puts $x}\n}\np\n",
7814:             "1\n",
7815:         ),
7816:         (
7817:             "proc p {} {\n    try {set z 0; set y 1} on error {} {set y 2} finally {puts $y}\n}\np\n",
7818:             "1\n",
7819:         ),
7820:     ];
7821:     for (source, printed) in programs {
7822:         for dialect in ["tcl8.6", "tcl9.0"] {
7823:             assert!(
7824:                 !reports(source, dialect, DiagCode::W210),
7825:                 "{dialect}: every path into the read binds it\n{source}"
7826:             );
7827:         }
7828:         prints_under_releases_from(source, printed, "8.6");
7829:     }
7830:     // A literal assignment raises an error if it fails at all, which an `on
7831:     // break` handler does not take: the handler sees `y` at 2 alone, and the
7832:     // optimiser forwards it, as it did before the body was split.
7833:     let breaks = "proc p {} {\n    foreach i {1} {\n        try {set y 1; set y 2; break} on break {} {puts $y}\n    }\n}\np\n";
7834:     for dialect in ["tcl8.6", "tcl9.0"] {
7835:         let (rewritten, _) = optimised(breaks, dialect);
7836:         assert!(
7837:             rewritten.contains("puts 2"),
7838:             "{dialect}: the handler sees `y` at 2\n{rewritten}"
7839:         );
7840:     }
7841:     prints_under_releases_from(breaks, "2\n", "8.6");
7842:     let after_stores = "proc upfoo {} {upvar x x; set x 5; error boom}\nproc p {} {\n    array set b {k v}\n    set a old\n    try {upfoo; lassign {new second} a b} on error {} {puts $a}\n}\np\n";
7843:     for dialect in ["tcl8.6", "tcl9.0"] {
7844:         let (rewritten, _) = optimised(after_stores, dialect);
7845:         assert!(
7846:             rewritten.contains("puts $a"),
7847:             "{dialect}: `a` is old or new where the handler runs\n{rewritten}"
7848:         );
7849:     }
7850:     prints_under_releases_from(after_stores, "old\n", "8.6");
7851: 
7852:     // `upfoo` writes `x` and breaks; the `catch` after it runs its own script
7853:     // first, so only the statement's own stores make its block a point, and
7854:     // the `on break` handler sees `x` at 5, not the 1 before and after it.
7855:     let breaks_after_stores = "proc upfoo {} {upvar x x; set x 5; return -code break}\nproc p {} {\n    set x 1\n    try {upfoo; catch {set y 1}; set x 1} on break {} {puts $x}\n}\np\n";
7856:     for dialect in ["tcl8.6", "tcl9.0"] {
7857:         let (rewritten, _) = optimised(breaks_after_stores, dialect);
7858:         assert!(
7859:             rewritten.contains("puts $x"),
7860:             "{dialect}: `x` is 1 or 5 where the handler runs\n{rewritten}"
7861:         );
7862:         let held = last_value(breaks_after_stores, dialect, "::p", "x");
7863:         assert!(
7864:             !matches!(held, LatticeValue::Const(ConstValue::Int(1))),
7865:             "{dialect}: the handler may see 5, not a constant 1: {held:?}"
7866:         );
7867:     }
7868:     prints_under_releases_from(breaks_after_stores, "5\n", "8.6");
7869: }
7870: 
7871: /// The blocks of `proc`'s `puts` statements, in source order.
7872: fn puts_blocks(unit: &CompilationUnit, proc: &str) -> Vec<tcl_compiler::cfg::BlockId> {
7873:     let function = unit
7874:         .procedures
7875:         .get(&fixture_id(&unit.procedures, proc))
7876:         .expect("the procedure");
7877:     let mut found: Vec<(u32, tcl_compiler::cfg::BlockId)> = function
7878:         .cfg
7879:         .blocks
7880:         .iter()
7881:         .flat_map(|(&id, block)| {
7882:             block
7883:                 .statements
7884:                 .iter()
7885:                 .filter(|statement| {
7886:                     matches!(statement, Statement::Call { command, .. } if command == "puts")
7887:                 })
7888:                 .map(move |statement| (statement.span().start(), id))
7889:         })
7890:         .collect();
7891:     found.sort_unstable();
7892:     found.into_iter().map(|(_, id)| id).collect()
7893: }
7894: 
7895: /// The value `var`'s version `version` holds at `block` of `proc`: the
7896: /// block-qualified lookup, which a refinement in force there narrows.
7897: fn value_in(
7898:     unit: &CompilationUnit,
7899:     proc: &str,
7900:     block: tcl_compiler::cfg::BlockId,
7901:     var: &str,
7902:     version: u32,
7903: ) -> Option<LatticeValue> {
7904:     let function = unit
7905:         .procedures
7906:         .get(&fixture_id(&unit.procedures, proc))
7907:         .expect("the procedure");
7908:     let symbol = function.ssa.var_symbol(var).expect("the variable");
7909:     function.sccp.value_at(block, (symbol, version)).cloned()
7910: }
7911: 
7912: /// A refinement never makes a version, and a merge keeps only what every
7913: /// path into it carries: the arms of `if {$x eq "a"} … elseif {$x eq "b"}`
7914: /// hold `x` at `a` and at `b`, and where they meet — the `else` arm returns,
7915: /// so only the two refined arms reach the `puts` past them — `x` reads as
7916: /// its own value, never as either refinement or a set of the two. tclsh 8.4
7917: /// to 9.1 print `a 1`, `a`, `b 2` and `b` for `p a; p b; p c`, before and
7918: /// after `tcl opt`.
7919: #[test]
7920: fn a_merge_drops_the_refinement() {
7921:     let source = "proc p {x} {\n    if {$x eq \"a\"} {\n        set r 1\n    } elseif {$x eq \"b\"} {\n        set r 2\n    } else {\n        return\n    }\n    puts \"$x $r\"\n    puts $x\n}\np a\np b\np c\n";
7922:     for dialect in DIALECTS {
7923:         let unit = unit_of(source, dialect);
7924:         let function = unit
7925:             .procedures
7926:             .get(&fixture_id(&unit.procedures, "::p"))
7927:             .expect("the procedure");
7928:         let refined: Vec<String> = function
7929:             .sccp
7930:             .refinements
7931:             .iter()
7932:             .filter_map(|refinement| match &refinement.fact {
7933:                 tcl_registry::value_transfer::FactView::Exact(value, _) => {
7934:                     Some(String::from_utf8_lossy(&value.bytes).into_owned())
7935:                 }
7936:                 _ => None,
7937:             })
7938:             .collect();
7939:         assert_eq!(
7940:             refined,
7941:             ["a", "b"],
7942:             "{dialect}: each arm's edge refines `x`"
7943:         );
7944:         let blocks: Vec<_> = function
7945:             .cfg
7946:             .blocks
7947:             .iter()
7948:             .filter_map(|(&id, block)| {
7949:                 block
7950:                     .statements
7951:                     .iter()
7952:                     .find_map(|statement| match statement {
7953:                         Statement::AssignConst { name, value, .. } if name == "r" => {
7954:                             Some((value.clone(), id))
7955:                         }
7956:                         _ => None,
7957:                     })
7958:             })
7959:             .collect();
7960:         for (value, block) in blocks {
7961:             let expected = if value == "1" { "a" } else { "b" };
7962:             assert_eq!(
7963:                 value_in(&unit, "::p", block, "x", 0),
7964:                 Some(text(expected)),
7965:                 "{dialect}: the arm that sets `r` to {value} holds `x` at {expected}"
7966:             );
7967:         }
7968:         for block in puts_blocks(&unit, "::p") {
7969:             assert_eq!(
7970:                 value_in(&unit, "::p", block, "x", 0),
7971:                 value_at(&unit, "::p", "x", 0),
7972:                 "{dialect}: past the merge `x` is its own value"
7973:             );
7974:             assert_eq!(function.sccp.refinements_in(block).count(), 0, "{dialect}");
7975:         }
7976:     }
7977:     prints_under_every_release(source, "a 1\na\nb 2\nb\n");
7978: }
7979: 
7980: /// A traced variable is never refined: a read trace may write the variable
7981: /// as the read runs, so the `$x` the arm prints need not be the `a` the
7982: /// condition read. `tr` leaves the first read alone and rewrites `x` on the
7983: /// second, and tclsh 8.4 to 9.1 print `changed`, before and after `tcl opt`.
7984: /// A trace another procedure installs on a name makes it externally mutable
7985: /// in every function, so `q`'s `y` is never refined either.
7986: #[test]
7987: fn a_traced_variable_is_never_refined() {
7988:     let source = "set n 0\nproc tr {name1 name2 op} {upvar 1 $name1 v; incr ::n; if {$::n > 1} {set v changed}}\nproc p {x} {\n    trace add variable x read tr\n    if {$x eq \"a\"} {puts $x}\n}\nproc t {} {trace add variable y write tr}\nproc q {y} {\n    if {$y eq \"a\"} {puts $y}\n}\np a\n";
7989:     for dialect in DIALECTS {
7990:         let unit = unit_of(source, dialect);
7991:         for proc in ["::p", "::q"] {
7992:             let function = unit
7993:                 .procedures
7994:                 .get(&fixture_id(&unit.procedures, proc))
7995:                 .expect("the procedure");
7996:             assert!(
7997:                 function.sccp.refinements.is_empty(),
7998:                 "{dialect} {proc}: {:?}",
7999:                 function.sccp.refinements
8000:             );
8001:             assert!(function.sccp.value_entries.is_empty(), "{dialect} {proc}");
8002:         }
8003:     }
8004:     prints_under_every_release(source, "changed\n");
8005: }
8006: 
8007: /// The nested equality decides: inside `if {$x eq "a"}`'s arm `x` is `a`,
8008: /// so `if {$x eq "b"}` there is false — a constant branch the solver applies,
8009: /// its true block outside the executable blocks — under every dialect, and
8010: /// the optimiser drops `puts never`. The program prints `inner` for `a` and
8011: /// nothing for `b` under tclsh 8.4 to 9.1, before and after `tcl opt`.
8012: #[test]
8013: fn the_nested_equality_decides() {
8014:     let source = "proc p {x} {\n    if {$x eq \"a\"} {\n        if {$x eq \"b\"} {puts never} else {puts inner}\n    }\n}\nset ::v a\np $::v\nset ::v b\np $::v\n";
8015:     for dialect in DIALECTS {
8016:         let unit = unit_of(source, dialect);
8017:         let function = unit
8018:             .procedures
8019:             .get(&fixture_id(&unit.procedures, "::p"))
8020:             .expect("the procedure");
8021:         let decided = function
8022:             .sccp
8023:             .constant_branches
8024:             .iter()
8025:             .find(|branch| branch.condition == "$x eq \"b\"")
8026:             .unwrap_or_else(|| panic!("{dialect}: {:?}", function.sccp.constant_branches));
8027:         assert!(!decided.value, "{dialect}");
8028:         let dead = function
8029:             .cfg
8030:             .block_id(&decided.not_taken_target)
8031:             .expect("the arm");
8032:         assert!(
8033:             !function.sccp.executable_blocks.contains(&dead),
8034:             "{dialect}: the inner true block never runs"
8035:         );
8036:         let (rewritten, _) = optimised(source, dialect);
8037:         assert!(
8038:             !rewritten.contains("puts never"),
8039:             "{dialect}: the optimiser drops the dead arm\n{rewritten}"
8040:         );
8041:     }
8042:     prints_under_every_release(source, "inner\n");
8043: }
8044: 
8045: /// The page's twelve programs (`docs/design/compiler/value-transfers.md`
8046: /// § *Predicate refinement*), each through a procedure whose argument no
8047: /// call site pins — a global the analysis holds no value for — so the
8048: /// branch itself is the only evidence: a numeric `==` keeps the string
8049: /// (`1.0`, ` 1`, `01`, and `08` from 9.0), `eq` compares spellings, a
8050: /// `string is` test proves a type and never a value (` 12 `, `{}` with and
8051: /// without `-strict`, `0x10`), truth is no value (`yes`), and from 8.5 an
8052: /// opaque `-nocase` `switch` and `in` keep what they were given. Each prints
8053: /// the same under every release before and after `tcl opt`.
8054: ///
8055: /// A read of the refined variable itself is never rewritten, so the `==`
8056: /// arms, an `in` arm and a flattened `switch`'s arms also read the arm's
8057: /// value through a definition (`set y $x; puts $y`), which O100 inlines
8058: /// where the arm proves an exact value: an exact value where the table
8059: /// says "never the string" prints `1` for `1.0`, and one member of an `in`
8060: /// set prints that member for another.
8061: #[test]
8062: fn the_twelve_refinement_witnesses() {
8063:     let every = "proc p {x} {if {$x == 1} {set y $x; puts $y; return [string length $x]}; return none}\n\
8064:                  proc q {x} {if {$x == 1} {set y $x; puts $y; return $x}; return none}\n\
8065:                  proc r {x} {if {$x eq \"1\"} {return yes}; return no}\n\
8066:                  proc s {x} {if {$x eq \"a\"} {return $x}; return none}\n\
8067:                  proc t {x} {if {[string is integer -strict $x]} {return [string length $x]}; return none}\n\
8068:                  proc u {x} {if {[string is integer $x]} {return \"yes [string length $x]\"}; return no}\n\
8069:                  proc u2 {x} {if {[string is integer -strict $x]} {return yes}; return no}\n\
8070:                  proc v {x} {if {[string is integer -strict $x]} {return $x}; return none}\n\
8071:                  proc w {x} {if {$x} {return $x}; return none}\n\
8072:                  proc k {x} {switch -- $x {a {set y $x; puts $y; return A} b {set y $x; puts $y; return B}}; return none}\n\
8073:                  set ::v 1.0; puts [p $::v]\n\
8074:                  set ::v \" 1\"; puts [p $::v]\n\
8075:                  set ::v 01; puts [q $::v]\n\
8076:                  set ::v 1.0; puts [r $::v]\n\
8077:                  set ::v a; puts [s $::v]\n\
8078:                  set ::v \" 12 \"; puts [t $::v]\n\
8079:                  set ::v {}; puts [u $::v]; puts [u2 $::v]\n\
8080:                  set ::v 0x10; puts [v $::v]\n\
8081:                  set ::v yes; puts [w $::v]\n\
8082:                  set ::v b; puts [k $::v]\n";
8083:     prints_under_every_release(
8084:         every,
8085:         "1.0\n3\n 1\n2\n01\n01\nno\na\n4\nyes 0\nno\n0x10\nyes\nb\nB\n",
8086:     );
8087:     let leading_zero = "proc y {x} {if {$x == 8} {set y $x; puts $y; return \"yes [string length $x]\"}; return no}\n\
8088:                         set ::v 08; puts [y $::v]\n";
8089:     for (series, tclsh) in releases_on_path() {
8090:         let expected = if series < "9.0" {
8091:             "no\n"
8092:         } else {
8093:             "08\nyes 2\n"
8094:         };
8095:         let (rewritten, _) = optimised(leading_zero, &dialect_of(series));
8096:         for program in [leading_zero, rewritten.as_str()] {
8097:             assert_eq!(
8098:                 run_script(&tclsh, program),
8099:                 Some((true, expected.to_owned())),
8100:                 "tclsh{series}:\n{program}"
8101:             );
8102:         }
8103:     }
8104:     let from_85 = "proc z {x} {switch -nocase -- $x {a {return $x}}; return none}\n\
8105:                    proc m {x} {if {$x in {a b c}} {set y $x; puts $y; return $x}; return none}\n\
8106:                    set ::v A; puts [z $::v]\n\
8107:                    set ::v b; puts [m $::v]\n";
8108:     prints_under_releases_from(from_85, "A\nb\nb\n", "8.5");
8109: }
8110: 
8111: /// The lines, from 1, of the S100 shimmer warnings in `source` under
8112: /// `dialect`, in order.
8113: fn shimmer_lines(source: &str, dialect: &str) -> Vec<usize> {
8114:     let registry = static_context_for(dialect).commands();
8115:     let unit = CompilationUnit::build_for_dialect(source, registry, false, dialect);
8116:     let mut lines: Vec<usize> =
8117:         tcl_compiler::shimmer::find_shimmer_warnings_for_cu(&unit, registry)
8118:             .iter()
8119:             .filter(|warning| warning.code == DiagCode::S100)
8120:             .map(|warning| {
8121:                 let start = usize::try_from(warning.span.start())
8122:                     .map_or(source.len(), |start| start.min(source.len()));
8123:                 source[..start].matches('\n').count() + 1
8124:             })
8125:             .collect();
8126:     lines.sort_unstable();
8127:     lines
8128: }
8129: 
8130: /// A `string is` test types its arm: once `string is integer -strict $i`
8131: /// holds, `i` has an integer representation (`tcl::unsupported::representation`
8132: /// reads `int`, tclsh 8.6 to 9.1), so reading it as an index in the arm
8133: /// converts nothing, while past the arm, where the test may have failed,
8134: /// the read still converts a string — S100 on line 6 and not on line 4. The
8135: /// program prints `b` twice under every release, before and after `tcl opt`.
8136: #[test]
8137: fn a_string_is_test_types_its_arm() {
8138:     let source = "proc p {s} {\n    set i [string trim $s]\n    if {[string is integer -strict $i]} {\n        puts [lindex {a b c} $i]\n    }\n    puts [lindex {a b c} $i]\n}\nset ::v 1\np $::v\n";
8139:     for dialect in DIALECTS {
8140:         assert_eq!(shimmer_lines(source, dialect), vec![6], "{dialect}");
8141:     }
8142:     prints_under_every_release(source, "b\nb\n");
8143: }
8144: 
8145: /// A definition in a refined arm takes the arm's value: `set y $x` inside
8146: /// `if {$x eq "a"}` makes `y` the constant `a`, so O100 inlines it where it
8147: /// is read (`puts $y` becomes `puts a`), while a read of `x` itself keeps the
8148: /// version's own value and stays as written. The program prints `a` twice
8149: /// for `a` and nothing for `b` under tclsh 8.4 to 9.1, before and after
8150: /// `tcl opt`.
8151: #[test]
8152: fn a_definition_in_a_refined_arm_takes_the_arms_value() {
8153:     let source = "proc p {x} {\n    if {$x eq \"a\"} {\n        set y $x\n        puts $y\n        puts $x\n    }\n}\nset ::v a\np $::v\nset ::v b\np $::v\n";
8154:     for dialect in DIALECTS {
8155:         let unit = unit_of(source, dialect);
8156:         let function = unit
8157:             .procedures
8158:             .get(&fixture_id(&unit.procedures, "::p"))
8159:             .expect("the procedure");
8160:         let y = function.ssa.var_symbol("y").expect("y");
8161:         assert_eq!(
8162:             function.sccp.values.get(&(y, 1)),
8163:             Some(&text("a")),
8164:             "{dialect}"
8165:         );
8166:         let (rewritten, rewrites) = optimised(source, dialect);
8167:         assert!(rewritten.contains("puts a\n"), "{dialect}:\n{rewritten}");
8168:         assert!(rewritten.contains("puts $x"), "{dialect}:\n{rewritten}");
8169:         assert!(
8170:             rewrites
8171:                 .iter()
8172:                 .any(|rewrite| rewrite.code == DiagCode::O100),
8173:             "{dialect}: {rewrites:?}"
8174:         );
8175:     }
8176:     prints_under_every_release(source, "a\na\n");
8177: }
8178: 
8179: /// A range from a comparison holds of an integer operand, and the bounds
8180: /// checks take one only for an index proved an integer: `end` passes `$i > 5`
8181: /// as a string and indexes `c` (#2368's program, its `gets stdin` a
8182: /// parameter here), and `7.0` fails `$i != 7` and is no index, `lindex`
8183: /// raising `bad index "7.0"` (the review's program), so W230 reports
8184: /// neither, under every dialect. Proved an integer by `string is integer
8185: /// -strict`, `9` past `$i > 5` is past the end: W230 reports it, and tclsh
8186: /// prints `<>`.
8187: #[test]
8188: fn a_range_from_a_comparison_narrows_only_a_proved_integer() {
8189:     let end = "proc q {s} {\n    set i [string trim $s]\n    if {$i > 5} {\n        set x [lindex {a b c} $i]\n        puts $x\n    }\n}\nq end\n";
8190:     let point = "proc g {s} {\n    set i [string trim $s]\n    if {$i != 7} { puts no } else { set x [lindex {a b c} $i]; puts $x }\n}\ng 7.0\n";
8191:     let proved = "proc h {s} {\n    set i [string trim $s]\n    if {[string is integer -strict $i] && $i > 5} {\n        set x [lindex {a b c} $i]\n        puts <$x>\n    }\n}\nh 9\n";
8192:     for dialect in DIALECTS {
8193:         assert!(!reports(end, dialect, DiagCode::W230), "{dialect}: end");
8194:         assert!(!reports(point, dialect, DiagCode::W230), "{dialect}: 7.0");
8195:         assert!(reports(proved, dialect, DiagCode::W230), "{dialect}: 9");
8196:     }
8197:     prints_under_every_release(end, "c\n");
8198:     prints_under_every_release(proved, "<>\n");
8199:     for (series, tclsh) in releases_on_path() {
8200:         let (rewritten, _) = optimised(point, &dialect_of(series));
8201:         for program in [point, rewritten.as_str()] {
8202:             assert_eq!(
8203:                 run_script(&tclsh, program),
8204:                 Some((false, String::new())),
8205:                 "tclsh{series}:\n{program}"
8206:             );
8207:         }
8208:     }
8209: }
8210: 
8211: /// The script an opaque `catch` keeps inside itself reads a name it writes
8212: /// as its own, by the rule an opaque `switch`'s arms are read by: its reads
8213: /// less its writes are what it reads of the frame. A body that sets a name
8214: /// and then reads it — a `set`, a `foreach` binder, a `for` counter in a
8215: /// procedure — draws no W210 under every dialect, where the marker ahead of
8216: /// the call had made each read one of a name that may be unset; tclsh 8.4
8217: /// to 9.1 print what the bodies print, before and after `tcl opt`. A name the
8218: /// body only may set is still undefined after the call on the path where it
8219: /// did not: `puts $x` past `catch {if {$c} {set x 1}}` draws W210, and tclsh
8220: /// raises on `p 0`.
8221: #[test]
8222: fn an_opaque_catch_reads_its_own_writes_as_its_own() {
8223:     for (source, printed) in [
8224:         ("catch {set i 0; puts $i}\n", "0\n"),
8225:         ("catch {foreach x {1 2} {puts $x}}\n", "1\n2\n"),
8226:         (
8227:             "proc p {} {catch {for {set i 0} {$i < 3} {incr i} {puts $i}}}\np\n",
8228:             "0\n1\n2\n",
8229:         ),
8230:     ] {
8231:         for dialect in DIALECTS {
8232:             assert!(
8233:                 !reports(source, dialect, DiagCode::W210),
8234:                 "{dialect}: {source}"
8235:             );
8236:         }
8237:         prints_under_every_release(source, printed);
8238:     }
8239:     let may_set = "proc p {c} {catch {if {$c} {set x 1}}; puts $x}\np 1\np 0\n";
8240:     for dialect in DIALECTS {
8241:         assert!(reports(may_set, dialect, DiagCode::W210), "{dialect}");
8242:     }
8243:     for (series, tclsh) in releases_on_path() {
8244:         let (rewritten, _) = optimised(may_set, &dialect_of(series));
8245:         for program in [may_set, rewritten.as_str()] {
8246:             assert_eq!(
8247:                 run_script(&tclsh, program),
8248:                 Some((false, "1\n".to_owned())),
8249:                 "tclsh{series}:\n{program}"
8250:             );
8251:         }
8252:     }
8253: }
8254: 
8255: /// A loop that runs past the enumeration cap
8256: /// (`DEFAULT_MAX_STATIC_LOOP_ITERS` passes) declines: the solver publishes
8257: /// nothing on its exit, so the branch after it decides nothing and the
8258: /// widened lattice stands. A loop that runs to the cap is enumerated, and
8259: /// its branch decides. tclsh 8.4 to 9.1 print `yes` for both, before and
8260: /// after `tcl opt`.
8261: #[test]
8262: fn the_iteration_cap_publishes_nothing() {
8263:     let cap = tcl_compiler::static_loops::DEFAULT_MAX_STATIC_LOOP_ITERS;
8264:     for (bound, enumerated) in [(cap, true), (cap + 1, false)] {
8265:         let source = format!(
8266:             "proc p {{}} {{\n    for {{set i 0}} {{$i < {bound}}} {{incr i}} {{}}\n    \
8267:              if {{$i == {bound}}} {{puts yes}} else {{puts no}}\n}}\np\n"
8268:         );
8269:         let condition = format!("$i == {bound}");
8270:         for dialect in DIALECTS {
8271:             let unit = unit_of(&source, dialect);
8272:             let function = unit
8273:                 .procedures
8274:                 .get(&fixture_id(&unit.procedures, "::p"))
8275:                 .expect("the procedure");
8276:             let decided = function
8277:                 .sccp
8278:                 .constant_branches
8279:                 .iter()
8280:                 .find(|branch| branch.condition == condition)
8281:                 .map(|branch| branch.value);
8282:             assert_eq!(decided, enumerated.then_some(true), "{dialect}: {bound}");
8283:             assert_eq!(
8284:                 function.sccp.loop_enumerations.len(),
8285:                 usize::from(enumerated),
8286:                 "{dialect}: {bound}"
8287:             );
8288:         }
8289:         prints_under_every_release(&source, "yes\n");
8290:     }
8291: }
8292: 
8293: /// The enumeration stores only to a place whose kind it proves — one it
8294: /// holds a scalar of, or holds unbound — and names an element as the word
8295: /// gives it: `foreach b` over an array `b` raises on its first binding, and
8296: /// `${a(k)}` and `set a(k) …` raise on a scalar `a`, so a `catch` body that
8297: /// does any of them leaves its counter where the error left it. Had the run
8298: /// bound the array as a scalar, or read and written `a(k)` as `a`, `$n == 0`
8299: /// would decide false and `i` would leave the `catch` at 3. A binder takes
8300: /// the same rule as every other store, so `foreach a(k) {1 2} {}` is not
8301: /// run, as `set a(k) …` is not. tclsh 8.4 to 9.1 print `zero`, `0` twice and
8302: /// `two`, before and after `tcl opt`.
8303: #[test]
8304: fn an_enumeration_runs_only_over_places_it_proves() {
8305:     let array_binder = "proc p {} {\n    array set b {k keep}\n    set n 0\n    \
8306:                         catch {foreach b {1 2} {incr n}}\n    \
8307:                         if {$n == 0} {puts zero} else {puts other}\n}\np\n";
8308:     let element = |command: &str| {
8309:         format!(
8310:             "proc p {{}} {{\n    set a 5\n    set i 9\n    \
8311:              catch {{for {{set i 0}} {{$i < 3}} {{incr i}} {{set y $a; {command}}}}}\n    \
8312:              puts $i\n}}\np\n"
8313:         )
8314:     };
8315:     let elements = [element("set x ${a(k)}"), element("set a(k) $i")];
8316:     let element_binder = "proc p {} {\n    set a(k) 0\n    foreach a(k) {1 2} {}\n    \
8317:                           if {$a(k) == 2} {puts two} else {puts other}\n}\np\n";
8318:     for dialect in DIALECTS {
8319:         let binder_unit = unit_of(element_binder, dialect);
8320:         assert!(
8321:             binder_unit
8322:                 .procedures
8323:                 .get(&fixture_id(&binder_unit.procedures, "::p"))
8324:                 .expect("the procedure")
8325:                 .sccp
8326:                 .loop_enumerations
8327:                 .is_empty(),
8328:             "{dialect}"
8329:         );
8330:         let unit = unit_of(array_binder, dialect);
8331:         let function = unit
8332:             .procedures
8333:             .get(&fixture_id(&unit.procedures, "::p"))
8334:             .expect("the procedure");
8335:         assert!(
8336:             function
8337:                 .sccp
8338:                 .constant_branches
8339:                 .iter()
8340:                 .all(|branch| branch.condition != "$n == 0"),
8341:             "{dialect}: {:?}",
8342:             function.sccp.constant_branches
8343:         );
8344:         for source in &elements {
8345:             assert!(
8346:                 !matches!(
8347:                     last_value(source, dialect, "::p", "i"),
8348:                     LatticeValue::Const(_)
8349:                 ),
8350:                 "{dialect}\n{source}"
8351:             );
8352:         }
8353:     }
8354:     prints_under_every_release(array_binder, "zero\n");
8355:     for source in &elements {
8356:         prints_under_every_release(source, "0\n");
8357:     }
8358:     prints_under_every_release(element_binder, "two\n");
8359: }
8360: 
8361: /// A name a loop rebinds that is dead after it — a temporary set before the
8362: /// loop and in its body, read nowhere after — has no φ where the loop leaves,
8363: /// so the version live there is the one from before the loop, which the
8364: /// loop's state does not describe, and the solver states nothing of it. It
8365: /// had stated the loop's last value of the name for that version, which the
8366: /// settled run contradicted, and the contradiction dropped every loop's state
8367: /// in the unit: the loop's own counter, and a later loop's that has nothing
8368: /// to do with the name. A contradiction now drops only the loop whose state
8369: /// it contradicts. The branch after each loop decides, for I230 as for `tcl
8370: /// opt`. tclsh 8.4 to 9.1 print `yes`, `yes` and `three`, `yes`, and `yes`,
8371: /// before and after `tcl opt`.
8372: #[test]
8373: fn a_name_dead_after_its_loop_keeps_every_loops_state() {
8374:     let top = "set tmp 1\nset n 0\nforeach x {1 2} { set tmp $x; incr n }\n\
8375:                if {$n == 2} {puts yes} else {puts no}\n";
8376:     let later = format!(
8377:         "{top}for {{set i 0}} {{$i < 3}} {{incr i}} {{}}\n\
8378:          if {{$i == 3}} {{puts three}} else {{puts other}}\n"
8379:     );
8380:     let dead_while = "set tmp 1\nset n 0\nwhile {$n < 2} { set tmp $n; incr n }\n\
8381:                       if {$n == 2} {puts yes} else {puts no}\n";
8382:     let idiom = "proc p {} {\n    set found 0\n    set last \"\"\n    \
8383:                  foreach x {a b c} { set last $x; if {$x eq \"b\"} { set found 1 } }\n    \
8384:                  if {$found} { return yes }\n    return no\n}\nputs [p]\n";
8385:     for dialect in DIALECTS {
8386:         for (source, claims) in [
8387:             (top, vec![true]),
8388:             (later.as_str(), vec![true, true]),
8389:             (dead_while, vec![true]),
8390:             (idiom, vec![true]),
8391:         ] {
8392:             assert_eq!(
8393:                 condition_claims(source, dialect),
8394:                 claims,
8395:                 "{dialect}\n{source}"
8396:             );
8397:         }
8398:         assert_eq!(
8399:             unit_of(&later, dialect)
8400:                 .top_level
8401:                 .sccp
8402:                 .loop_enumerations
8403:                 .len(),
8404:             2,
8405:             "{dialect}"
8406:         );
8407:     }
8408:     prints_under_every_release(top, "yes\n");
8409:     prints_under_every_release(&later, "yes\nthree\n");
8410:     prints_under_every_release(dead_while, "yes\n");
8411:     prints_under_every_release(idiom, "yes\n");
8412: }
8413: 
8414: /// The state a `foreach` or a `while` leaves decides the branch after it,
8415: /// for I230 as for `tcl opt`: the counter the solver keeps widened inside
8416: /// each loop is 3, then -2, on the loop's exit edges. The `foreach` leaves by
8417: /// its latch, whose test the analysis cannot read, so the solver reaches the
8418: /// block after it while the counter's own value is still a transient
8419: /// constant the loop's state rules out; that value decides nothing, and the
8420: /// arm the state rules out is never reached. tclsh 8.4 to 9.1 print `three`
8421: /// and `minus`, before and after `tcl opt`.
8422: #[test]
8423: fn the_state_a_loop_leaves_decides_the_branch_after_it() {
8424:     let source = "proc p {} {\n    set n 0\n    foreach x {a b c} { incr n }\n    \
8425:                   if {$n == 3} { puts three } else { puts other }\n    set i 10\n    \
8426:                   while {$i > 0} { incr i -3 }\n    \
8427:                   if {$i == -2} { puts minus } else { puts other }\n}\np\n";
8428:     for dialect in DIALECTS {
8429:         assert_eq!(condition_claims(source, dialect), [true, true], "{dialect}");
8430:         let unit = unit_of(source, dialect);
8431:         let function = unit
8432:             .procedures
8433:             .get(&fixture_id(&unit.procedures, "::p"))
8434:             .expect("the procedure");
8435:         assert_eq!(
8436:             function
8437:                 .sccp
8438:                 .loop_enumerations
8439:                 .iter()
8440:                 .map(|record| record.iterations)
8441:                 .collect::<Vec<_>>(),
8442:             [3, 4],
8443:             "{dialect}"
8444:         );
8445:     }
8446:     prints_under_every_release(source, "three\nminus\n");
8447: }
8448: 
8449: /// A loop's own test is the branch that leaves the loop when false, wherever
8450: /// its block sits: `while 1` decided true draws no I230, and an `if` in a
8451: /// loop's body is an `if` like any other, so one decided true there draws
8452: /// one. tclsh 8.4 to 9.1 print `3` and `done`, before and after `tcl opt`.
8453: #[test]
8454: fn a_loops_own_test_is_the_branch_that_leaves_it() {
8455:     let source = "proc p {} {\n    set n 0\n    for {set i 0} {$i < 3} {incr i} {\n        \
8456:                   set k 1\n        if {$k == 1} { incr n }\n    }\n    puts $n\n}\n\
8457:                   proc q {} {\n    while 1 { return done }\n}\np\nputs [q]\n";
8458:     for dialect in DIALECTS {
8459:         assert_eq!(condition_claims(source, dialect), [true], "{dialect}");
8460:     }
8461:     prints_under_every_release(source, "3\ndone\n");
8462: }
8463: 
8464: /// A store before an opaque `switch` arm or an opaque `catch` body that may
8465: /// write an element of the array it names is read by the statement: where
8466: /// no arm runs, or the body raises before the element write lands, the base
8467: /// holds what it held, so `set a 5` stays live, W220 does not report it, and
8468: /// O109 does not delete it — which made `puts $a` raise `can't read "a": no
8469: /// such variable` where tclsh prints `5`. The read is quoted, and
8470: /// read-before-set reads the base as the definition it was, so a base never
8471: /// set before draws no W210. tclsh 8.4 to 9.1 print `5` twice, `5`, `1`, and
8472: /// `1` and `0`, before and after `tcl opt`.
8473: #[test]
8474: fn a_may_written_element_reads_the_store_to_its_array() {
8475:     let switch_arm = "proc p {x} {\n    set a 5\n    switch -glob -- $x { x* {set a(k) 1} }\n    \
8476:                       puts $a\n}\np y\np z\n";
8477:     let catch_body = "set a 5\ncatch {set a(k) 1}\nputs $a\n";
8478:     let never_set_catch = "catch {set a(k) 1}\nputs [array size a]\n";
8479:     let never_set_switch = "proc p {x} {\n    switch -glob -- $x { x* {set a(k) 1} }\n    \
8480:                             puts [array size a]\n}\np x\np y\n";
8481:     for dialect in DIALECTS {
8482:         for source in [switch_arm, catch_body] {
8483:             assert!(
8484:                 !reports(source, dialect, DiagCode::W220),
8485:                 "{dialect}\n{source}"
8486:             );
8487:         }
8488:         for source in [never_set_catch, never_set_switch] {
8489:             assert!(
8490:                 !reports(source, dialect, DiagCode::W210),
8491:                 "{dialect}\n{source}"
8492:             );
8493:         }
8494:     }
8495:     prints_under_every_release(switch_arm, "5\n5\n");
8496:     prints_under_every_release(catch_body, "5\n");
8497:     prints_under_every_release(never_set_catch, "1\n");
8498:     prints_under_every_release(never_set_switch, "1\n0\n");
8499: }
8500: 
8501: /// A loop's body leaves the loop, or writes its counter, through a script
8502: /// word however it is written: `if` runs a bare or a quoted body as it runs a
8503: /// braced one, so `if {$i < 0} break` is an exit and `if {$i < -5} "set i
8504: /// 20"` a write of the counter, and none of these loops is provably infinite
8505: /// (#2381) — the first was W241, "counter $i starts at 5, moves by -1 per
8506: /// step, and compares < 10 (never reached)". tclsh 8.4 to 9.1 print `-1`,
8507: /// `-1`, `-6` and `19`, before and after `tcl opt`.
8508: #[test]
8509: fn a_bare_or_quoted_body_word_leaves_the_loop() {
8510:     let programs = [
8511:         (
8512:             "for {set i 5} {$i < 10} {incr i -1} {if {$i < 0} break}\nputs $i\n",
8513:             "-1\n",
8514:         ),
8515:         (
8516:             "set i 5\nwhile {$i < 10} {if {$i < 0} break; incr i -1}\nputs $i\n",
8517:             "-1\n",
8518:         ),
8519:         (
8520:             "for {set i 0} {$i < 10} {incr i -1} {if {$i < -5} \"break\"}\nputs $i\n",
8521:             "-6\n",
8522:         ),
8523:         (
8524:             "for {set i 0} {$i < 10} {incr i -1} {if {$i < -5} \"set i 20\"}\nputs $i\n",
8525:             "19\n",
8526:         ),
8527:     ];
8528:     for (source, printed) in programs {
8529:         for dialect in DIALECTS {
8530:             assert!(
8531:                 !reports(source, dialect, DiagCode::W241),
8532:                 "{dialect}\n{source}"
8533:             );
8534:         }
8535:         prints_under_every_release(source, printed);
8536:     }
8537: }
8538: 
8539: /// W241's counter path reads what may write the counter from the unit that
8540: /// holds the loop: every statement of the loop's blocks that defines it, and
8541: /// every call there to code the module cannot see. A write a `[…]` word
8542: /// makes, a binder, a procedure's `uplevel` and the `upvar` helper idiom each
8543: /// define the counter, and a call to a procedure another file defines — here
8544: /// one the program sources — is one the module cannot see, at the top level
8545: /// and in a procedure; each `while` was W241, "while loop is provably
8546: /// infinite: counter $i starts at 5, moves by -1 per step, and compares < 10
8547: /// (never reached)", and so was the `for` with a literal start, before the
8548: /// slice. tclsh 8.4 to 9.1 print each program's number, before and after
8549: /// `tcl opt`.
8550: #[test]
8551: fn whatever_writes_the_counter_keeps_w241_silent() {
8552:     let helper = std::env::temp_dir().join(format!(
8553:         "value-transfer-witness-helper-{}.tcl",
8554:         std::process::id()
8555:     ));
8556:     std::fs::write(&helper, "proc foo {name} {upvar 1 $name v; set v 100}\n")
8557:         .expect("the helper file");
8558:     let source_helper = format!("source {{{}}}\n", helper.display());
8559:     let sourced = [
8560:         format!("{source_helper}set i 5\nwhile {{$i < 10}} {{incr i -1; foo i}}\nputs $i\n"),
8561:         format!(
8562:             "{source_helper}proc s {{}} {{\n    set i 5\n    \
8563:              while {{$i < 10}} {{incr i -1; foo i}}\n    return $i\n}}\nputs [s]\n"
8564:         ),
8565:     ];
8566:     let mut programs: Vec<(&str, &str)> = vec![
8567:         (
8568:             "set i 5\nwhile {$i < 10} {incr i -1; set j [incr i 20]}\nputs $i\n",
8569:             "24\n",
8570:         ),
8571:         (
8572:             "set i 5\nwhile {$i < 10} {incr i -1; foreach i {100} {}}\nputs $i\n",
8573:             "100\n",
8574:         ),
8575:         (
8576:             "proc q {} {uplevel 1 {set i 100}}\nset i 5\n\
8577:              while {$i < 10} {incr i -1; q}\nputs $i\n",
8578:             "100\n",
8579:         ),
8580:         (
8581:             "proc foo {name} {upvar 1 $name v; set v 100}\nset i 5\n\
8582:              while {$i < 10} {incr i -1; foo i}\nputs $i\n",
8583:             "100\n",
8584:         ),
8585:         (
8586:             "for {set i 5} {$i < 10} {incr i -1} {if {$i < 0} {set j [incr i 20]}}\nputs $i\n",
8587:             "18\n",
8588:         ),
8589:     ];
8590:     programs.extend(sourced.iter().map(|source| (source.as_str(), "100\n")));
8591:     for (source, printed) in programs {
8592:         for dialect in DIALECTS {
8593:             assert!(
8594:                 !reports(source, dialect, DiagCode::W241),
8595:                 "{dialect}\n{source}"
8596:             );
8597:         }
8598:         prints_under_every_release(source, printed);
8599:     }
8600:     let _ = std::fs::remove_file(&helper);
8601: }
8602: 
8603: /// A loop statement's literal word is its value as Tcl substitutes it: a bare
8604: /// or quoted word's escapes are decoded, so `lappend r a\x41` appends `aA`,
8605: /// `append r \x41` appends `A`, and an `incr` by `\x31` adds 1. The
8606: /// enumeration had handed each word on as written, so it left `r` holding
8607: /// `a\x41 a\x41` and `tcl opt` folded the test after the loop to its false
8608: /// arm. Each loop now leaves what Tcl leaves and the test decides true, for
8609: /// I230 as for `tcl opt`. tclsh 8.4 to 9.1 print `yes` for each, before and
8610: /// after `tcl opt`.
8611: #[test]
8612: fn a_loop_word_is_its_value_with_its_escapes_decoded() {
8613:     for source in [
8614:         "set r {}\nforeach x {1 2} { lappend r a\\x41 }\n\
8615:          if {$r eq \"aA aA\"} {puts yes} else {puts no}\n",
8616:         "set r {}\nfor {set i 0} {$i < 2} {incr i} { append r \\x41 }\n\
8617:          if {$r eq \"AA\"} {puts yes} else {puts no}\n",
8618:         "set r {}\nforeach x {1 2} { lappend r \"a\\x41\" }\n\
8619:          if {$r eq \"aA aA\"} {puts yes} else {puts no}\n",
8620:         "for {set i 0} {$i < 2} {incr i \\x31} {}\n\
8621:          if {$i == 2} {puts yes} else {puts no}\n",
8622:     ] {
8623:         for dialect in DIALECTS {
8624:             assert_eq!(
8625:                 condition_claims(source, dialect),
8626:                 [true],
8627:                 "{dialect}\n{source}"
8628:             );
8629:         }
8630:         prints_under_every_release(source, "yes\n");
8631:     }
8632: }
8633: 
8634: /// The eleven loop programs of the interface page (§ *Bounded-loop
8635: /// enumeration*), one each at the top level: the solver runs each loop to
8636: /// its exit over exact state — a `for` to its false condition, after a
8637: /// `break`, past a `continue`, against a fractional bound, from an empty
8638: /// start script and with its counter written in its body; a `for` the error
8639: /// path of an opaque `catch` leaves; a `foreach` over no elements, over a
8640: /// list too short for its last pass, and to a `break` — and the branch after
8641: /// it decides on what the loop leaves, for the lattice, for I230 and for
8642: /// `tcl opt`, which keeps only the arm that runs: `i` 5; `t` 6; `i` 3 after
8643: /// `break`; `t` 3 with `continue`; `i` 3 for `$i < 2.5`; `i` 4 for the
8644: /// empty start; `i` 4 and `n` 2; `i` 2 on the error path; `x` unbound after
8645: /// `foreach x {} {}`; `a` 3 and `b` empty; `n` 1 and `x` 2. tclsh 8.4 to
8646: /// 9.1 print each program's answer before and after `tcl opt`.
8647: #[test]
8648: fn the_eleven_loop_witnesses() {
8649:     let witnesses = [
8650:         ("for {set i 0} {$i < 5} {incr i} {}\n", "$i == 5", "five"),
8651:         (
8652:             "set t 0; for {set i 0} {$i < 4} {incr i} {incr t $i}\n",
8653:             "$t == 6",
8654:             "six",
8655:         ),
8656:         (
8657:             "for {set i 0} {$i < 10} {incr i} {if {$i == 3} break}\n",
8658:             "$i == 3",
8659:             "three",
8660:         ),
8661:         (
8662:             "set t 0; for {set i 0} {$i < 4} {incr i} {if {$i == 1} continue; incr t}\n",
8663:             "$t == 3",
8664:             "three",
8665:         ),
8666:         ("for {set i 0} {$i < 2.5} {incr i} {}\n", "$i == 3", "three"),
8667:         (
8668:             "set i 0; for {} {$i < 3} {} {incr i 2}\n",
8669:             "$i == 4",
8670:             "four",
8671:         ),
8672:         (
8673:             "set n 0; for {set i 0} {$i < 3} {incr i} {set i [expr {$i + 1}]; incr n}\n",
8674:             "$i == 4 && $n == 2",
8675:             "yes",
8676:         ),
8677:         (
8678:             "catch {for {set i 0} {$i < 5} {incr i} {if {$i == 2} {error x}}}\n",
8679:             "$i == 2",
8680:             "two",
8681:         ),
8682:         ("foreach x {} {}\n", "[info exists x]", ""),
8683:         ("foreach {a b} {1 2 3} {}\n", "$a == 3 && $b eq \"\"", "yes"),
8684:         (
8685:             "set n 0; foreach x {1 2 3} {if {$x == 2} break; incr n}\n",
8686:             "$n == 1 && $x == 2",
8687:             "yes",
8688:         ),
8689:     ];
8690:     for (program, condition, taken) in witnesses {
8691:         // The ninth program's test is the one that holds false.
8692:         let holds = !taken.is_empty();
8693:         let (then, otherwise) = if holds {
8694:             (taken, "other")
8695:         } else {
8696:             ("bound", "unbound")
8697:         };
8698:         let source =
8699:             format!("{program}if {{{condition}}} {{puts {then}}} else {{puts {otherwise}}}\n");
8700:         let printed = if holds { then } else { otherwise };
8701:         let dropped = if holds { otherwise } else { then };
8702:         for dialect in DIALECTS {
8703:             let unit = unit_of(&source, dialect);
8704:             assert!(
8705:                 unit.top_level
8706:                     .sccp
8707:                     .constant_branches
8708:                     .iter()
8709:                     .any(|branch| { branch.condition == condition && branch.value == holds }),
8710:                 "{dialect}: {source}{:?}",
8711:                 unit.top_level.sccp.constant_branches
8712:             );
8713:             assert_eq!(
8714:                 condition_claims(&source, dialect),
8715:                 [holds],
8716:                 "{dialect}: {source}"
8717:             );
8718:             let (rewritten, _) = optimised(&source, dialect);
8719:             assert!(
8720:                 !rewritten.contains(&format!("puts {dropped}")),
8721:                 "{dialect}: {source}{rewritten}"
8722:             );
8723:         }
8724:         prints_under_every_release(&source, &format!("{printed}\n"));
8725:     }
8726: }
8727: 
8728: /// The interface page's correlated pairs (§ *The correlated finite-set
8729: /// limit*) as the page writes them, `incr x [expr {$b / $a}]`: the
8730: /// enumeration runs the amount's `[expr …]` over its state, so each loop
8731: /// leaves what ordered execution leaves — `x` 20 and `y` 25 — where pairing
8732: /// the binders by position would answer 20 for both and their cartesian
8733: /// product neither, and each branch after a loop decides true. Inside each
8734: /// loop the lattice still proves no amount — the quotient pairs two distinct
8735: /// finite inputs, which it declines as correlated — so each `incr` declines.
8736: /// tclsh 8.4 to 9.1 print `twenty` and `twentyfive`, before and after `tcl
8737: /// opt`.
8738: #[test]
8739: fn the_correlated_pairs_decide_by_enumeration() {
8740:     let source = "proc p {} {\n\
8741:                    set x 0\n\
8742:                    foreach {a b} {1 10 2 20} { incr x [expr {$b / $a}] }\n\
8743:                    if {$x == 20} { puts twenty } else { puts other }\n\
8744:                    set y 0\n\
8745:                    foreach {a b} {1 20 2 10} { incr y [expr {$b / $a}] }\n\
8746:                    if {$y == 25} { puts twentyfive } else { puts other }\n\
8747:                   }\n";
8748:     for dialect in DIALECTS {
8749:         assert_eq!(condition_claims(source, dialect), [true, true], "{dialect}");
8750:         let unit = unit_of(source, dialect);
8751:         let function = unit
8752:             .procedures
8753:             .get(&fixture_id(&unit.procedures, "::p"))
8754:             .expect("the procedure");
8755:         let published: Vec<(String, LatticeValue)> = function
8756:             .sccp
8757:             .loop_enumerations
8758:             .iter()
8759:             .flat_map(|record| record.published.iter().cloned())
8760:             .filter(|(name, _)| name == "x" || name == "y")
8761:             .collect();
8762:         assert_eq!(
8763:             published,
8764:             [
8765:                 ("x".to_owned(), LatticeValue::Const(ConstValue::Int(20))),
8766:                 ("y".to_owned(), LatticeValue::Const(ConstValue::Int(25))),
8767:             ],
8768:             "{dialect}"
8769:         );
8770:         assert_eq!(
8771:             answers_for(&unit, "::p", "incr"),
8772:             ["declined: not-exact", "declined: not-exact"],
8773:             "{dialect}"
8774:         );
8775:     }
8776:     prints_under_every_release(&format!("{source}p\n"), "twenty\ntwentyfive\n");
8777: }
8778: 
8779: /// A loop condition's math function is the one the module binds: with `abs`
8780: /// rebound by `proc ::tcl::mathfunc::abs`, `$i < abs(-3)` runs the loop to
8781: /// 99 under 8.5 to 9.1, so the enumeration declines — the shared lattice
8782: /// under the module's observed bindings, the rewrite under its whole-module
8783: /// trust — rather than stop at 3, and the branch after the loop decides
8784: /// nothing. tclsh 8.5 to 9.1 print `other` at the top level and in a
8785: /// procedure, before and after `tcl opt`.
8786: #[test]
8787: fn a_loop_condition_reads_the_math_binding() {
8788:     let top_level = "proc ::tcl::mathfunc::abs {x} {return 99}\n\
8789:                      for {set i 0} {$i < abs(-3)} {incr i} {}\n\
8790:                      if {$i == 3} {puts three} else {puts other}\n";
8791:     let in_a_procedure = "proc p {} {\n    for {set i 0} {$i < abs(-3)} {incr i} {}\n    \
8792:                           if {$i == 3} {puts three} else {puts other}\n}\n\
8793:                           proc ::tcl::mathfunc::abs {x} {return 99}\np\n";
8794:     for dialect in ["tcl8.6", "tcl9.0"] {
8795:         for source in [top_level, in_a_procedure] {
8796:             assert!(
8797:                 !reports(source, dialect, DiagCode::I230),
8798:                 "{dialect}\n{source}"
8799:             );
8800:         }
8801:         let unit = unit_of(top_level, dialect);
8802:         assert!(
8803:             unit.top_level.sccp.loop_enumerations.is_empty(),
8804:             "{dialect}"
8805:         );
8806:         let unit = unit_of(in_a_procedure, dialect);
8807:         let function = unit
8808:             .procedures
8809:             .get(&fixture_id(&unit.procedures, "::p"))
8810:             .expect("the procedure");
8811:         assert!(function.sccp.loop_enumerations.is_empty(), "{dialect}");
8812:     }
8813:     prints_under_releases_from(top_level, "other\n", "8.5");
8814:     prints_under_releases_from(in_a_procedure, "other\n", "8.5");
8815: }
8816: 
8817: /// The argument-sensitive re-run that O103 folds a call from runs the
8818: /// callee's loop under the call's seeds: `[f 3]` runs `f`'s `for` three times
8819: /// and returns `t` at 6, which the loop's exit state holds where the return
8820: /// reads it, so the call folds to 6. tclsh 8.4 to 9.1 print `6`, before and
8821: /// after `tcl opt`.
8822: #[test]
8823: fn the_argument_sensitive_rerun_runs_the_callees_loop() {
8824:     let source = "proc f {n} {\n    set t 0\n    for {set i 0} {$i < $n} {incr i} {incr t 2}\n    \
8825:                   return $t\n}\nset r [f 3]\nputs $r\n";
8826:     for dialect in DIALECTS {
8827:         let (rewritten, applied) = optimised(source, dialect);
8828:         assert!(
8829:             applied
8830:                 .iter()
8831:                 .any(|rewrite| rewrite.code == DiagCode::O103 && rewrite.replacement == "6"),
8832:             "{dialect}: {applied:?}"
8833:         );
8834:         assert!(!rewritten.contains("[f 3]"), "{dialect}:\n{rewritten}");
8835:     }
8836:     prints_under_every_release(source, "6\n");
8837: }
8838: 
8839: /// The state an enumerated loop leaves bounds its counter past the loop
8840: /// header's widening: after `for {set i 0} {$i < 5} {incr i} {}`, `i` is
8841: /// exactly 5, so `lindex` of a three-element list at `$i` is past the end and
8842: /// W230 says so, at the top level and in a procedure. tclsh 8.4 to 9.1 print
8843: /// an empty line, before and after `tcl opt`.
8844: #[test]
8845: fn an_enumerated_loop_bounds_its_counter_after_it() {
8846:     let top_level = "set l {a b c}\nfor {set i 0} {$i < 5} {incr i} {}\nputs [lindex $l $i]\n";
8847:     let in_a_procedure = "proc p {} {\n    set l {a b c}\n    for {set i 0} {$i < 5} {incr i} {}\n    \
8848:                           puts [lindex $l $i]\n}\np\n";
8849:     for dialect in DIALECTS {
8850:         for source in [top_level, in_a_procedure] {
8851:             assert!(
8852:                 reports(source, dialect, DiagCode::W230),
8853:                 "{dialect}\n{source}"
8854:             );
8855:         }
8856:     }
8857:     prints_under_every_release(top_level, "\n");
8858:     prints_under_every_release(in_a_procedure, "\n");
8859: }
8860: 
8861: /// A double the lattice computes is spelled as Tcl spells it: `[expr {1.0 *
8862: /// 3}]` is `3.0` and `[expr {1e300 * 10.0}]` is `1e+301`, so `string length`
8863: /// of each is 3 and 6. The lattice had spelled them as Rust does, `3` and a
8864: /// 302-digit integer, and `tcl opt` folded the calls to `1` and `302`. tclsh
8865: /// 8.4 to 9.1 print `3` and `6`, before and after `tcl opt`.
8866: #[test]
8867: fn a_computed_double_is_spelled_as_tcl_spells_it() {
8868:     let source = "proc p {} {\n    set x [expr {1.0 * 3}]\n    set n [string length $x]\n    \
8869:                   return $n\n}\nproc q {} {\n    set y [expr {1e300 * 10.0}]\n    \
8870:                   set m [string length $y]\n    return $m\n}\nputs [p]\nputs [q]\n";
8871:     for dialect in DIALECTS {
8872:         assert_eq!(
8873:             last_value(source, dialect, "::p", "n"),
8874:             LatticeValue::Const(ConstValue::Int(3)),
8875:             "{dialect}"
8876:         );
8877:         assert_eq!(
8878:             last_value(source, dialect, "::q", "m"),
8879:             LatticeValue::Const(ConstValue::Int(6)),
8880:             "{dialect}"
8881:         );
8882:     }
8883:     prints_under_every_release(source, "3\n6\n");
8884: }
8885: 
8886: /// O103's argument-independent fold replaces a call by the procedure's
8887: /// constant return only where the call is one the argument-sensitive re-run
8888: /// could make: every word after the head literal, and as many as the
8889: /// parameters accept. A word that substitutes runs before the call and may
8890: /// write or raise, and a count the parameters do not accept raises, and the
8891: /// constant says neither: `[p [incr n]]` had become `foo` and lost the
8892: /// `incr`, and `[p $undefined]` and `[p]` had become `foo` where tclsh raises
8893: /// (#2389). A call with a literal word still folds, and a bare call draws the
8894: /// hint only where it is such a call. Each program prints what tclsh 8.4 to
8895: /// 9.1 print, before and after `tcl opt`.
8896: #[test]
8897: fn the_summary_folds_only_a_call_the_rerun_could_make() {
8898:     let kept = [
8899:         (
8900:             "proc p {a} {return foo}\nset n 0\nputs [p [incr n]]\nputs $n\n",
8901:             "foo\n1\n",
8902:             "[p [incr n]]",
8903:         ),
8904:         (
8905:             "proc p {a} {return foo}\nproc q {} {puts [p $undefined]}\nputs [catch q]\n",
8906:             "1\n",
8907:             "[p $undefined]",
8908:         ),
8909:         (
8910:             "proc p {a} {return foo}\nproc q {} {puts [p]}\nputs [catch q]\n",
8911:             "1\n",
8912:             "[p]",
8913:         ),
8914:     ];
8915:     for (source, printed, call) in kept {
8916:         for dialect in DIALECTS {
8917:             let (rewritten, _) = optimised(source, dialect);
8918:             assert!(
8919:                 rewritten.contains(call),
8920:                 "{dialect}: {call} stays\n{rewritten}"
8921:             );
8922:         }
8923:         prints_under_every_release(source, printed);
8924:     }
8925:     let folded = "proc p {a} {return foo}\nputs [p x]\n";
8926:     let bare = "proc p {a} {return foo}\np x\np [incr n]\n";
8927:     for dialect in DIALECTS {
8928:         let (rewritten, _) = optimised(folded, dialect);
8929:         assert!(rewritten.contains("puts foo"), "{dialect}\n{rewritten}");
8930:         let hints: Vec<&str> = rewrites_of(bare, dialect)
8931:             .iter()
8932:             .filter(|rewrite| rewrite.code == DiagCode::O103)
8933:             .map(|rewrite| &bare[rewrite.span.start() as usize..rewrite.span.end() as usize])
8934:             .collect();
8935:         assert_eq!(hints, ["p x"], "{dialect}");
8936:     }
8937:     prints_under_every_release(folded, "foo\n");
8938: }
8939: 
8940: /// A `return` run inside a statement the flow graph keeps whole leaves the
8941: /// procedure from that statement, where no exit block stands for it: an
8942: /// opaque `switch`'s arm. O103's re-run read the other exits alone and folded
8943: /// `[p]`, `[p abc]` and `[p q]` to `2`, where tclsh 8.4 to 9.1 print `1`
8944: /// (#2393). No call folds to `2`, and each program prints what tclsh prints,
8945: /// before and after `tcl opt`.
8946: #[test]
8947: fn a_return_inside_a_statement_kept_whole_stops_the_fold() {
8948:     let programs = [
8949:         (
8950:             "proc p {} {switch -glob -- [clock seconds] {* {return 1}}; return 2}\nputs [p]\n",
8951:             "1\n",
8952:         ),
8953:         (
8954:             "proc p {x} {switch -glob -- $x {* {return 1}}; return 2}\nputs [p abc]\nputs [p q]\n",
8955:             "1\n1\n",
8956:         ),
8957:     ];
8958:     for (source, printed) in programs {
8959:         for dialect in DIALECTS {
8960:             let folded_to_two: Vec<Optimisation> = rewrites_of(source, dialect)
8961:                 .into_iter()
8962:                 .filter(|rewrite| rewrite.code == DiagCode::O103 && rewrite.replacement == "2")
8963:                 .collect();
8964:             assert!(
8965:                 folded_to_two.is_empty(),
8966:                 "{dialect}: {folded_to_two:?}\n{source}"
8967:             );
8968:         }
8969:         prints_under_every_release(source, printed);
8970:     }
8971: }
8972: 
8973: /// A loop over a qualified variable is a statement the flow graph keeps
8974: /// whole too, as a call holding its body word, and a `return` that body runs
8975: /// leaves the procedure from it. The reading asked only the statement
8976: /// variants a `return` could sit in, so both O103 paths folded `[p]`, `[q 5]`
8977: /// and `[r]` to `2`, `2` and `4`, where tclsh prints 1, 5 and 3 (#2393's
8978: /// rule missed the call). No call folds, and each program prints what tclsh
8979: /// 8.4 to 9.1 print, before and after `tcl opt`, the `lmap` one from 8.6.
8980: #[test]
8981: fn a_return_inside_a_call_holding_a_body_stops_the_fold() {
8982:     let programs = [
8983:         (
8984:             "proc p {} {foreach ::x {1} {return 1}; return 2}\nputs [p]\n",
8985:             "1\n",
8986:             "8.4",
8987:         ),
8988:         (
8989:             "proc q {a} {foreach ::y [list $a] {return $a}; return 2}\nputs [q 5]\n",
8990:             "5\n",
8991:             "8.4",
8992:         ),
8993:         (
8994:             "proc r {} {lmap ::z {1} {return 3}; return 4}\nputs [r]\n",
8995:             "3\n",
8996:             "8.6",
8997:         ),
8998:     ];
8999:     for (source, printed, first) in programs {
9000:         for dialect in DIALECTS {
9001:             let folds: Vec<Optimisation> = rewrites_of(source, dialect)
9002:                 .into_iter()
9003:                 .filter(|rewrite| rewrite.code == DiagCode::O103)
9004:                 .collect();
9005:             assert!(folds.is_empty(), "{dialect}: {folds:?}\n{source}");
9006:         }
9007:         prints_under_releases_from(source, printed, first);
9008:     }
9009: }
9010: 
9011: /// The argument-independent O103 folds a procedure
9012: /// whose return is a computed constant. `p`'s return is no literal, but its
9013: /// seedless lattice — the procedure run with its parameters unknown — holds
9014: /// `x` at `foo` where it returns, so the summary says `p` returns `foo` for
9015: /// every caller. The summary path is asked before the re-run and answers on
9016: /// its own: without `p`'s unit, which the re-run needs, `[p]` still folds to
9017: /// `foo`, and the bare call `p` draws the summary path's hint. A return that
9018: /// reads a parameter stays `UsesParam` with no constant; and `r`'s value,
9019: /// exact only under the literal its one caller passes, which the unit's
9020: /// seeded lattice holds, never enters the summary (R7). tclsh 8.4 to 9.1
9021: /// print what each program prints, before and after `tcl opt`.
9022: #[test]
9023: fn o103_summary_path_folds_a_computed_return() {
9024:     let source = "proc p {} {set x [string range foobar 0 2]; return $x}\nputs [p]\n";
9025:     let bare = "proc p {} {set x [string range foobar 0 2]; return $x}\np\n";
9026:     let uses = "proc q {a} {return [expr {$a + 1}]}\nputs [q 5]\n";
9027:     let seeded = "proc r {a} {set x [string range $a 0 2]; return $x}\nputs [r foobar]\n";
9028:     for dialect in DIALECTS {
9029:         let summary = summary_of(source, dialect, "::p");
9030:         assert!(summary.can_fold_static_calls, "{dialect}: {summary:?}");
9031:         assert_eq!(
9032:             summary.constant_return,
9033:             Some(ConstantReturn::Str("foo".to_owned())),
9034:             "{dialect}"
9035:         );
9036: 
9037:         let registry = static_context_for(dialect).commands();
9038:         let profile = resolve_environment(dialect).analyser_profile();
9039:         let mut unit = summarised_unit(source, dialect);
9040:         let p_id = fixture_id(&unit.ir_module.procedures, "::p");
9041:         unit.procedures.remove(&p_id);
9042:         let folds = optimise_unit(&unit, registry, Some(profile));
9043:         assert!(
9044:             folds.iter().any(|fold| fold.code == DiagCode::O103
9045:                 && !fold.hint_only
9046:                 && fold.replacement == "foo"),
9047:             "{dialect}: {folds:?}"
9048:         );
9049:         assert!(
9050:             rewrites_of(bare, dialect)
9051:                 .iter()
9052:                 .any(|fold| fold.code == DiagCode::O103
9053:                     && fold.hint_only
9054:                     && fold.replacement == "foo"),
9055:             "{dialect}"
9056:         );
9057:         let (rewritten, _) = optimised(source, dialect);
9058:         assert!(rewritten.contains("puts foo"), "{dialect}\n{rewritten}");
9059: 
9060:         let summary = summary_of(uses, dialect, "::q");
9061:         assert!(!summary.returns_constant, "{dialect}: {summary:?}");
9062:         assert_eq!(summary.return_depends_on_params, ["a"], "{dialect}");
9063: 
9064:         assert_eq!(
9065:             last_value(seeded, dialect, "::r", "x"),
9066:             text("foo"),
9067:             "{dialect}"
9068:         );
9069:         let summary = summary_of(seeded, dialect, "::r");
9070:         assert!(
9071:             !summary.returns_constant && summary.constant_return.is_none(),
9072:             "{dialect}: {summary:?}"
9073:         );
9074:     }
9075:     prints_under_every_release(source, "foo\n");
9076:     prints_under_every_release(uses, "6\n");
9077:     prints_under_every_release(seeded, "foo\n");
9078: }
9079: 
9080: /// What a summary says a procedure returns is the value it returns, byte
9081: /// for byte, and O103 spells it so (#2388). A literal word is read through
9082: /// the exact value ingress and kept as written — `1.0`, `1.00`, `1e3`,
9083: /// `007`, `true` and ` 5` had become `1`, `1`, `1000`, `7`, `1` and `5`; a
9084: /// braced `$a` is the text `$a`, no passthrough of `a`, and a braced `$x` no
9085: /// read of `x`; and an `expr` literal operand is its own value only as a
9086: /// canonical decimal integer, the expression route deciding `0x10`, `010`,
9087: /// `true` and `1e3`, which the summary had taken as written. The re-run reads
9088: /// a return word the same way: `return " 5"` had folded `[p 1]` to `5`. Each
9089: /// program prints what tclsh 8.4 to 9.1 print, before and after `tcl opt`;
9090: /// for the braced `$x`, O100 still rewrites the body's `return {$x}` (#2391),
9091: /// and `[p]`, the one call, folds to the text.
9092: #[test]
9093: fn the_summary_returns_the_value_exactly() {
9094:     let literals = [
9095:         ("1.0", Some(ConstantReturn::Float(1.0)), "1.0"),
9096:         ("1.00", Some(ConstantReturn::Str("1.00".to_owned())), "1.00"),
9097:         ("1e3", Some(ConstantReturn::Str("1e3".to_owned())), "1e3"),
9098:         ("007", Some(ConstantReturn::Str("007".to_owned())), "007"),
9099:         ("true", Some(ConstantReturn::Bool(true)), "true"),
9100:         ("{$a}", Some(ConstantReturn::Str("$a".to_owned())), "$a"),
9101:     ];
9102:     for (word, constant, printed) in literals {
9103:         let source = format!("proc p {{a}} {{return {word}}}\nputs [p 1]\n");
9104:         for dialect in DIALECTS {
9105:             let summary = summary_of(&source, dialect, "::p");
9106:             assert_eq!(summary.constant_return, constant, "{dialect}: {word}");
9107:             assert_eq!(summary.return_passthrough_param, None, "{dialect}: {word}");
9108:         }
9109:         prints_under_every_release(&source, &format!("{printed}\n"));
9110:     }
9111:     let padded = "proc p {} {return \" 5\"}\nset y [p]\nputs <$y>\n";
9112:     let arg_sensitive =
9113:         "proc p {a} {if {$a} {return \" 5\"} else {return [expr {$a}]}}\nset y [p 1]\nputs <$y>\n";
9114:     for source in [padded, arg_sensitive] {
9115:         for dialect in DIALECTS {
9116:             assert!(
9117:                 rewrites_of(source, dialect)
9118:                     .iter()
9119:                     .any(|fold| fold.code == DiagCode::O103 && fold.replacement == "{ 5}"),
9120:                 "{dialect}: {source}"
9121:             );
9122:         }
9123:         prints_under_every_release(source, "< 5>\n");
9124:     }
9125:     let braced_read = "proc p {} {set x 5; return {$x}}\nputs [p]\n";
9126:     for dialect in DIALECTS {
9127:         assert!(
9128:             rewrites_of(braced_read, dialect)
9129:                 .iter()
9130:                 .any(|fold| fold.code == DiagCode::O103 && fold.replacement == "{$x}"),
9131:             "{dialect}"
9132:         );
9133:     }
9134:     prints_under_every_release(braced_read, "$x\n");
9135:     for (operand, printed) in [("0x10", "16"), ("true", "true"), ("1e3", "1000.0")] {
9136:         let source = format!("proc p {{}} {{return [expr {{{operand}}}]}}\nputs [p]\n");
9137:         prints_under_every_release(&source, &format!("{printed}\n"));
9138:     }
9139:     let octal = "proc p {} {return [expr {010}]}\nputs [p]\n";
9140:     for (series, tclsh) in releases_on_path() {
9141:         let printed = if series < "9.0" { "8\n" } else { "10\n" };
9142:         let (rewritten, _) = optimised(octal, &dialect_of(series));
9143:         for program in [octal, rewritten.as_str()] {
9144:             assert_eq!(
9145:                 run_script(&tclsh, program),
9146:                 Some((true, printed.to_owned())),
9147:                 "tclsh{series}:\n{program}"
9148:             );
9149:         }
9150:     }
9151: }
9152: 
9153: /// A rewrite spells a value with whitespace about an integer in braces: the
9154: /// word renderer had taken ` 5` for the integer 5 and spelled it bare, so
9155: /// `puts $x` became `puts  5`, `return $y` became `return  7` and `set z [q]`
9156: /// became `set z  7`, each printing the number without its space (#2392).
9157: /// tclsh 8.4 to 9.1 print what the program prints, before and after `tcl
9158: /// opt`.
9159: #[test]
9160: fn a_padded_value_is_braced_where_a_rewrite_spells_it() {
9161:     let source = "set x \" 5\"\nputs <$x>\nputs $x\nproc q {} {set y \" 7\"; return $y}\n\
9162:                   puts \"<[q]>\"\nset z [q]\nputs <$z>\n";
9163:     for dialect in DIALECTS {
9164:         let (rewritten, _) = optimised(source, dialect);
9165:         for bare in ["puts  5", "return  7", "set z  7"] {
9166:             assert!(!rewritten.contains(bare), "{dialect}: {bare}\n{rewritten}");
9167:         }
9168:     }
9169:     prints_under_every_release(source, "< 5>\n 5\n< 7>\n< 7>\n");
9170: }
9171: 
9172: /// Where the seedless run is made its answer is the summary's, and a run
9173: /// that proves no one value leaves the summary no constant whatever the
9174: /// return words say: `p`'s loop ends only by raising, so its `return 5` is
9175: /// never reached. The words had made the summary `const(5)` and `tcl opt`
9176: /// rewrote `[p]` to `5`, so the program printed 5 where tclsh 8.4 to 9.1
9177: /// print `divide by zero` — the case of #2390 where the lattice proves no
9178: /// exit. The program prints what tclsh prints, before and after `tcl opt`.
9179: #[test]
9180: fn a_run_that_proves_no_value_leaves_no_constant() {
9181:     let source =
9182:         "proc p {} {while {1} {set x [expr {1/0}]}; return 5}\ncatch {set y [p]} m\nputs $m\n";
9183:     for dialect in DIALECTS {
9184:         let summary = summary_of(source, dialect, "::p");
9185:         assert!(
9186:             !summary.returns_constant && summary.constant_return.is_none(),
9187:             "{dialect}: {summary:?}"
9188:         );
9189:         assert!(
9190:             !rewrites_of(source, dialect)
9191:                 .iter()
9192:                 .any(|fold| fold.code == DiagCode::O103),
9193:             "{dialect}"
9194:         );
9195:     }
9196:     prints_under_every_release(source, "divide by zero\n");
9197: }
9198: 
9199: /// A callee's `Name` effect is a value in its caller, on both O103 paths:
9200: /// `bump n` binds `n` to what a re-run of `bump` under `n`'s 1 leaves, 2,
9201: /// so `p`'s seedless run returns 2 — `p` pure, since the call writes only
9202: /// `p`'s own `n` — and the summary path folds `[p]`; `q`'s return depends on
9203: /// `x`, so `[q 5]` folds to 6 on the argument-sensitive re-run, which
9204: /// re-runs `bump` seeded from `q`'s `n`; and `rec`'s re-run reaches `rec 0`
9205: /// through its own re-runs, so `[rec 4]` folds to 10. tclsh 8.4 to 9.1
9206: /// print 2, 6 and 10, before and after `tcl opt`.
9207: #[test]
9208: fn bump_decides_through_both_o103_paths() {
9209:     let source = "proc bump {name {by 1}} {upvar 1 $name v; incr v $by}\n\
9210:                   proc p {} {set n 1; bump n; return $n}\n\
9211:                   proc q {x} {set n $x; bump n; return $n}\n\
9212:                   proc rec {n} {if {$n <= 0} {return 0}; expr {$n + [rec [expr {$n - 1}]]}}\n\
9213:                   puts [p]\nputs [q 5]\nputs [rec 4]\n";
9214:     for dialect in DIALECTS {
9215:         assert_eq!(
9216:             last_value(source, dialect, "::p", "n"),
9217:             LatticeValue::Const(ConstValue::Int(2)),
9218:             "{dialect}"
9219:         );
9220:         let p = summary_of(source, dialect, "::p");
9221:         assert!(p.pure && p.can_fold_static_calls, "{dialect}: {p:?}");
9222:         assert_eq!(p.constant_return, Some(ConstantReturn::Int(2)), "{dialect}");
9223:         let q = summary_of(source, dialect, "::q");
9224:         assert!(q.pure && q.constant_return.is_none(), "{dialect}: {q:?}");
9225:         let (rewritten, _) = optimised(source, dialect);
9226:         for folded in ["puts 2\n", "puts 6\n", "puts 10\n"] {
9227:             assert!(rewritten.contains(folded), "{dialect}: {folded}{rewritten}");
9228:         }
9229:     }
9230:     prints_under_every_release(source, "2\n6\n10\n");
9231: }
9232: 
9233: /// A command a statement's words run that calls a procedure naming a place
9234: /// is applied as a call statement is: the statement's word effects, paired
9235: /// with it, take what a re-run of the callee leaves in the place, so `n` is
9236: /// 2 after `set r [bump n]`. The unit's lattice takes no call's result, so
9237: /// `s`'s `expr {[bump m] + $m}` is no constant there and `s` has no constant
9238: /// return; the argument-sensitive re-run O103 makes of `s` takes the result
9239: /// and reads `$m` after the write, so `[s]` folds to 6. tclsh 8.4 to 9.1
9240: /// print 2 and 6, before and after `tcl opt`.
9241: #[test]
9242: fn an_embedded_call_applies_its_summary() {
9243:     let source = "proc bump {name {by 1}} {upvar 1 $name v; incr v $by}\n\
9244:                   proc p {} {set n 1; set r [bump n]; return $n}\n\
9245:                   proc s {} {set m 2; set t [expr {[bump m] + $m}]; return $t}\n\
9246:                   puts [p]\nputs [s]\n";
9247:     for dialect in DIALECTS {
9248:         assert_eq!(
9249:             last_value(source, dialect, "::p", "n"),
9250:             LatticeValue::Const(ConstValue::Int(2)),
9251:             "{dialect}"
9252:         );
9253:         let s = summary_of(source, dialect, "::s");
9254:         assert!(s.pure && s.constant_return.is_none(), "{dialect}: {s:?}");
9255:         let (rewritten, _) = optimised(source, dialect);
9256:         for folded in ["puts 2\n", "puts 6\n"] {
9257:             assert!(rewritten.contains(folded), "{dialect}: {folded}{rewritten}");
9258:         }
9259:     }
9260:     prints_under_every_release(source, "2\n6\n");
9261: }
9262: 
9263: /// The top level's value for the last version of `var` in `source` under
9264: /// `dialect`.
9265: fn top_level_value(source: &str, dialect: &str, var: &str) -> LatticeValue {
9266:     let unit = unit_of(source, dialect);
9267:     let symbol = unit.top_level.ssa.var_symbol(var).expect("the variable");
9268:     unit.top_level
9269:         .sccp
9270:         .values
9271:         .iter()
9272:         .filter(|((sym, _), _)| *sym == symbol)
9273:         .max_by_key(|((_, version), _)| *version)
9274:         .map(|(_, value)| value.clone())
9275:         .expect("a definition")
9276: }
9277: 
9278: /// `series`' tclsh stops `source` with an error, and its optimised form
9279: /// with the same one: nothing printed, and a non-zero exit.
9280: fn errors_alike_under(source: &str, series: &str) {
9281:     for (found, tclsh) in releases_on_path() {
9282:         if found != series {
9283:             continue;
9284:         }
9285:         let (rewritten, _) = optimised(source, &dialect_of(series));
9286:         for program in [source, rewritten.as_str()] {
9287:             assert_eq!(
9288:                 run_script(&tclsh, program),
9289:                 Some((false, String::new())),
9290:                 "tclsh{series}:\n{program}"
9291:             );
9292:         }
9293:     }
9294: }
9295: 
9296: const BUMP: &str = "proc bump {name {by 1}} {upvar 1 $name v; incr v $by}\n";
9297: 
9298: /// The seven summary witnesses (`value-transfers.md` § *Proc-level transfer
9299: /// summaries*), each a caller of a procedure whose summary it applies, under
9300: /// every dialect and release: `bump n; bump n 2` leaves `n` 4 and `twice t`,
9301: /// two `bump` updates through `twice`'s own alias, leaves `t` 3, each proved
9302: /// and read as a constant; `reset m` unbinds `m`, so `[info exists m]`
9303: /// decides false; `g` binds `::counter` and states no value, so its read
9304: /// stays; `[rec 4]` folds to 10 on the argument-sensitive path; `ctr; ctr`
9305: /// leaves `::hits` 2 from 8.5, where 8.4's `incr` raises on the absent
9306: /// variable; and `bump absent` binds `absent` to 1 from 8.5, folded only
9307: /// under a release that creates the cell, and raises under 8.4. tclsh 8.4
9308: /// to 9.1 print the same before and after the optimiser, or stop with the
9309: /// same error.
9310: #[test]
9311: fn the_seven_summary_witnesses() {
9312:     let bump_twice = format!("{BUMP}set n 1\nbump n\nbump n 2\nputs $n\n");
9313:     let reset = "proc reset {name} {upvar 1 $name v; unset v}\nset m 1\nreset m\n\
9314:                  if {[info exists m]} {puts bound} else {puts unbound}\n";
9315:     let twice = format!(
9316:         "{BUMP}proc twice {{name}} {{upvar 1 $name w; bump w; bump w}}\nset t 1\ntwice t\nputs $t\n"
9317:     );
9318:     let global = "proc g {} {set ::counter 5}\ng\nputs $::counter\n";
9319:     let rec = "proc rec {n} {if {$n <= 0} {return 0}; expr {$n + [rec [expr {$n - 1}]]}}\n\
9320:                puts [rec 4]\n";
9321:     let hits = "proc ctr {} {incr ::hits}\nctr\nctr\nputs $::hits\n";
9322:     let absent = format!("{BUMP}bump absent\nputs $absent\n");
9323:     for dialect in DIALECTS {
9324:         assert_eq!(
9325:             top_level_value(&bump_twice, dialect, "n"),
9326:             LatticeValue::Const(ConstValue::Int(4)),
9327:             "{dialect}"
9328:         );
9329:         assert_eq!(
9330:             top_level_value(&twice, dialect, "t"),
9331:             LatticeValue::Const(ConstValue::Int(3)),
9332:             "{dialect}"
9333:         );
9334:         assert!(
9335:             unit_of(reset, dialect)
9336:                 .top_level
9337:                 .sccp
9338:                 .constant_branches
9339:                 .iter()
9340:                 .any(|branch| branch.condition == "[info exists m]" && !branch.value),
9341:             "{dialect}"
9342:         );
9343:         for (source, folded) in [
9344:             (bump_twice.as_str(), "puts 4\n"),
9345:             (twice.as_str(), "puts 3\n"),
9346:             (rec, "puts 10\n"),
9347:         ] {
9348:             assert!(
9349:                 optimised(source, dialect).0.contains(folded),
9350:                 "{dialect}: {source}"
9351:             );
9352:         }
9353:         assert!(
9354:             !optimised(reset, dialect).0.contains("puts bound"),
9355:             "{dialect}"
9356:         );
9357:         for (source, read) in [(global, "puts $::counter\n"), (hits, "puts $::hits\n")] {
9358:             assert!(
9359:                 optimised(source, dialect).0.contains(read),
9360:                 "{dialect}: {source}"
9361:             );
9362:         }
9363:         // Of the releases `DIALECTS` holds tcl8.4, tcl8.6 and tcl9.0; beside
9364:         // them f5-irules, on its 8.4 base, and the lenient tcl, which answers
9365:         // only where every release agrees, keep the read as tcl8.4 does, and
9366:         // tcl8.5 and tcl9.1, not in the list, fold as tcl8.6 does.
9367:         let creates_absent = matches!(dialect, "tcl8.6" | "tcl9.0");
9368:         assert_eq!(
9369:             optimised(&absent, dialect).0.contains("puts 1\n"),
9370:             creates_absent,
9371:             "{dialect}"
9372:         );
9373:     }
9374:     prints_under_every_release(&bump_twice, "4\n");
9375:     prints_under_every_release(reset, "unbound\n");
9376:     prints_under_every_release(&twice, "3\n");
9377:     prints_under_every_release(global, "5\n");
9378:     prints_under_every_release(rec, "10\n");
9379:     prints_under_releases_from(hits, "2\n", "8.5");
9380:     errors_alike_under(hits, "8.4");
9381:     prints_under_releases_from(&absent, "1\n", "8.5");
9382:     errors_alike_under(&absent, "8.4");
9383: }
9384: 
9385: /// One summary serves both callers (`value-transfers-examples.md`): each
9386: /// call applies it with a re-run under its own place's value, so the lattice
9387: /// proves `n` 2 and `other` 11, and `bump`'s body is left as written. tclsh
9388: /// 8.4 to 9.1 print `2 11` before and after the optimiser.
9389: #[test]
9390: fn two_callers_share_one_summary() {
9391:     let source = "proc bump {name} {upvar 1 $name v; incr v}\nset n 1\nbump n\n\
9392:                   set other 10\nbump other\nputs \"$n $other\"\n";
9393:     for dialect in DIALECTS {
9394:         assert_eq!(
9395:             top_level_value(source, dialect, "n"),
9396:             LatticeValue::Const(ConstValue::Int(2)),
9397:             "{dialect}"
9398:         );
9399:         assert_eq!(
9400:             top_level_value(source, dialect, "other"),
9401:             LatticeValue::Const(ConstValue::Int(11)),
9402:             "{dialect}"
9403:         );
9404:         let (rewritten, _) = optimised(source, dialect);
9405:         assert!(
9406:             rewritten.contains("{upvar 1 $name v; incr v}"),
9407:             "{dialect}: {rewritten}"
9408:         );
9409:     }
9410:     prints_under_every_release(source, "2 11\n");
9411: }
9412: 
9413: /// #2134's program: `[bump m]` nested in a word is a second call site, so no
9414: /// rewrite specialises `bump` to `bump n`'s place and the body keeps `upvar 1
9415: /// $name v`; the summary applies at both calls, the nested one through its
9416: /// statement's word effects, so `n` is 2 and `m` 11. tclsh 8.4 to 9.1 print
9417: /// `2 11 11` before and after the optimiser, where the specialised body
9418: /// printed `3 10 3`.
9419: #[test]
9420: fn a_nested_caller_keeps_the_callee_whole() {
9421:     let source = "proc bump {name} {\n  upvar 1 $name v\n  incr v\n}\nset n 1\nset m 10\n\
9422:                   bump n\nset z [bump m]\nputs \"$n $m $z\"\n";
9423:     for dialect in DIALECTS {
9424:         assert_eq!(
9425:             top_level_value(source, dialect, "n"),
9426:             LatticeValue::Const(ConstValue::Int(2)),
9427:             "{dialect}"
9428:         );
9429:         assert_eq!(
9430:             top_level_value(source, dialect, "m"),
9431:             LatticeValue::Const(ConstValue::Int(11)),
9432:             "{dialect}"
9433:         );
9434:         let (rewritten, _) = optimised(source, dialect);
9435:         assert!(
9436:             rewritten.contains("upvar 1 $name v\n"),
9437:             "{dialect}: {rewritten}"
9438:         );
9439:     }
9440:     prints_under_every_release(source, "2 11 11\n");
9441: }
9442: 
9443: /// Every release on `PATH` prints `printed` for `source` and then stops it
9444: /// with an error, and does the same for its optimised form under that
9445: /// release's dialect.
9446: fn prints_then_errors(source: &str, printed: &str) {
9447:     for (series, tclsh) in releases_on_path() {
9448:         let (rewritten, _) = optimised(source, &dialect_of(series));
9449:         for program in [source, rewritten.as_str()] {
9450:             assert_eq!(
9451:                 run_script(&tclsh, program),
9452:                 Some((false, printed.to_owned())),
9453:                 "tclsh{series}:\n{program}"
9454:             );
9455:         }
9456:     }
9457: }
9458: 
9459: /// A call that cannot complete normally is a raise where a run reads how its
9460: /// caller completes, so no exit past it is read: a callee whose re-run under
9461: /// the call's seeds raises — `incr` of `foo`, a division by zero, 8.4's
9462: /// `incr` of an absent place — and a call whose word count the callee's
9463: /// parameters reject leave `[c]` as written on both O103 paths, as an
9464: /// embedded call does. A call whose completion the re-run cannot decide, its
9465: /// seed unknown, leaves the seedless return unknown, and the
9466: /// argument-sensitive re-run decides each call: `[c 1]` folds to 0 and `[c
9467: /// foo]` stays. tclsh 8.4 to 9.1 raise in each, before and after `tcl opt`,
9468: /// and 8.5 onwards create the absent place, so there `[c]` folds to 0.
9469: #[test]
9470: fn a_call_that_cannot_complete_is_a_raise() {
9471:     let raising = [
9472:         format!("{BUMP}proc c {{}} {{set n foo; bump n; return 0}}\nputs [c]\n"),
9473:         format!("{BUMP}proc c {{name}} {{bump name; return 0}}\nputs [c foo]\n"),
9474:         format!("{BUMP}proc c {{}} {{set n foo; set r [bump n]; return 0}}\nputs [c]\n"),
9475:         "proc half {name} {upvar 1 $name v; set v [expr {$v / 0}]}\n\
9476:          proc c {} {set n 1; half n; return 0}\nputs [c]\n"
9477:             .to_owned(),
9478:         format!("{BUMP}proc c {{}} {{set n 1; bump n 1 extra; return 0}}\nputs [c]\n"),
9479:     ];
9480:     let seeded =
9481:         format!("{BUMP}proc c {{x}} {{set n $x; bump n; return 0}}\nputs [c 1]\nputs [c foo]\n");
9482:     let absent = format!("{BUMP}proc c {{}} {{bump n; return 0}}\nputs [c]\n");
9483:     for dialect in ["tcl8.4", "tcl8.6"] {
9484:         for source in &raising {
9485:             let (rewritten, _) = optimised(source, dialect);
9486:             assert!(
9487:                 rewritten.contains("puts [c"),
9488:                 "{dialect}: {source}{rewritten}"
9489:             );
9490:         }
9491:         let (rewritten, _) = optimised(&seeded, dialect);
9492:         assert!(
9493:             rewritten.contains("puts 0\nputs [c foo]\n"),
9494:             "{dialect}: {rewritten}"
9495:         );
9496:         assert!(
9497:             summary_of(&seeded, dialect, "::c")
9498:                 .constant_return
9499:                 .is_none(),
9500:             "{dialect}"
9501:         );
9502:         assert_eq!(
9503:             optimised(&absent, dialect).0.contains("puts 0\n"),
9504:             dialect != "tcl8.4",
9505:             "{dialect}"
9506:         );
9507:         // A call its callee's parameters reject states nothing of its place.
9508:         let wrong_count = unit_of(&raising[4], dialect);
9509:         assert!(
9510:             !matches!(
9511:                 last_existence(&wrong_count, "::c", "n"),
9512:                 Some(Existence::Bound(_))
9513:             ),
9514:             "{dialect}"
9515:         );
9516:     }
9517:     for source in &raising {
9518:         prints_then_errors(source, "");
9519:     }
9520:     prints_then_errors(&seeded, "0\n");
9521:     errors_alike_under(&absent, "8.4");
9522:     prints_under_releases_from(&absent, "0\n", "8.5");
9523: }
9524: 
9525: /// A statement the solver proves raises ends its path in a run that reads
9526: /// how the procedure completes, so a `return` past it is no exit of the
9527: /// call: `incr` of `foo`, an `expr` statement or an assignment dividing by
9528: /// zero, `error`, and a call to a procedure with a word count it rejects
9529: /// each leave the call unfolded on both O103 paths. tclsh 8.4 to 9.1 raise
9530: /// in each, before and after `tcl opt`.
9531: #[test]
9532: fn a_statement_that_certainly_raises_ends_the_exit_reading() {
9533:     let sources = [
9534:         "proc c {} {set n foo; incr n; return 0}\nputs [c]\n",
9535:         "proc p {} {expr {1/0}; return foo}\nputs [p]\n",
9536:         "proc p {a} {expr {1/0}; return [expr {$a + 1}]}\nputs [p 5]\n",
9537:         "proc p {} {error boom; return 5}\nputs [p]\n",
9538:         "proc p {} {set x [expr {1/0}]; return 5}\nputs [p]\n",
9539:         "proc f {a} {return $a}\nproc p {} {f 1 2; return 0}\nputs [p]\n",
9540:     ];
9541:     for dialect in ["tcl8.4", "tcl8.6"] {
9542:         for source in sources {
9543:             assert!(
9544:                 !rewrites_of(source, dialect)
9545:                     .iter()
9546:                     .any(|fold| fold.code == DiagCode::O103),
9547:                 "{dialect}: {source}"
9548:             );
9549:         }
9550:     }
9551:     for source in sources {
9552:         prints_then_errors(source, "");
9553:     }
9554: }
9555: 
9556: const BUMPD: &str = "proc bumpd {{name n}} {upvar 1 $name v; incr v}\n";
9557: 
9558: /// A call that omits a `Name` parameter names the place its default spells,
9559: /// as Tcl binds it: the call defines that place and its summary applies
9560: /// there, so a read after it, and the next call's re-run, see what it left.
9561: /// At the top level `set n 1; bumpd n; bumpd` and `set n 1; bumpd; bumpd n`
9562: /// leave `n` 3, read as `puts 3`; in a procedure the lattice proves `n` 3
9563: /// and 2 after the same calls, and the store `bumpd` reads is kept, which
9564: /// O126 deleted, so 8.4's `incr` raised, and is read: neither W220 nor W211
9565: /// calls it unread. tclsh 8.4 to 9.1 print the same before and after
9566: /// `tcl opt`.
9567: #[test]
9568: fn an_omitted_name_argument_names_its_default() {
9569:     let after = format!("{BUMPD}set n 1\nbumpd n\nbumpd\nputs $n\n");
9570:     let before = format!("{BUMPD}set n 1\nbumpd\nbumpd n\nputs $n\n");
9571:     let both = format!(
9572:         "{BUMPD}set n 1\nbumpd\nputs $n\nbumpd n\nputs $n\n\
9573:          proc p {{}} {{set n 1; bumpd; return $n}}\nputs [p]\n\
9574:          proc q {{}} {{set n 1; bumpd n; bumpd; return $n}}\nputs [q]\n\
9575:          proc r {{}} {{set n 1; bumpd; return 0}}\nputs [r]\n"
9576:     );
9577:     for dialect in ["tcl8.4", "tcl8.6"] {
9578:         for source in [&after, &before] {
9579:             assert_eq!(
9580:                 top_level_value(source, dialect, "n"),
9581:                 LatticeValue::Const(ConstValue::Int(3)),
9582:                 "{dialect}: {source}"
9583:             );
9584:             assert!(
9585:                 optimised(source, dialect).0.contains("puts 3\n"),
9586:                 "{dialect}: {source}"
9587:             );
9588:         }
9589:         assert_eq!(
9590:             last_value(&both, dialect, "::p", "n"),
9591:             LatticeValue::Const(ConstValue::Int(2)),
9592:             "{dialect}"
9593:         );
9594:         assert_eq!(
9595:             last_value(&both, dialect, "::q", "n"),
9596:             LatticeValue::Const(ConstValue::Int(3)),
9597:             "{dialect}"
9598:         );
9599:         let (rewritten, _) = optimised(&both, dialect);
9600:         assert!(
9601:             rewritten.contains("bumpd\nputs 2\nbumpd n\nputs 3\n")
9602:                 && rewritten.contains("{set n 1; bumpd; return 0}"),
9603:             "{dialect}: {rewritten}"
9604:         );
9605:         for code in [DiagCode::W211, DiagCode::W220] {
9606:             assert!(!reports(&both, dialect, code), "{dialect}: {code:?}");
9607:         }
9608:     }
9609:     prints_under_every_release(&after, "3\n");
9610:     prints_under_every_release(&before, "3\n");
9611:     prints_under_every_release(&both, "2\n3\n2\n3\n0\n");
9612: }
9613: 
9614: /// A `Name` argument that names an element is a barrier: the summary states
9615: /// what the callee does to a whole place, and an element's index is dropped
9616: /// when its name is normalised, so taking `a(k)` for `a` stated the array
9617: /// bound as a scalar and folded `[array exists a]` to 0. tclsh 8.4 to 9.1
9618: /// print `arr` and 1, before and after `tcl opt`.
9619: #[test]
9620: fn an_element_argument_is_a_barrier() {
9621:     let source = format!(
9622:         "{BUMP}proc q {{}} {{set a(k) 1; bump a(k); if {{[array exists a]}} {{return arr}} else {{return scalar}}}}\n\
9623:          puts [q]\nset b(k) 1\nbump b(k)\nputs [array exists b]\n"
9624:     );
9625:     for dialect in DIALECTS {
9626:         let (rewritten, _) = optimised(&source, dialect);
9627:         assert!(
9628:             rewritten.contains("if {[array exists a]}") && rewritten.contains("[array exists b]"),
9629:             "{dialect}: {rewritten}"
9630:         );
9631:     }
9632:     prints_under_every_release(&source, "arr\n1\n");
9633: }
9634: 
9635: /// The `reset` of the read-before-set witnesses: it unsets the place its
9636: /// argument names.
9637: const RESET: &str = "proc reset {name} {upvar 1 $name v; unset v}\n";
9638: 
9639: /// Whether the analyser reports W210 for `name` in `source` under `dialect`.
9640: fn reads_before_set(source: &str, dialect: &str, name: &str) -> bool {
9641:     let named = format!("'{name}'");
9642:     tcl_compiler::analyser::Analyser::new()
9643:         .analyse(source, dialect)
9644:         .diagnostics
9645:         .iter()
9646:         .any(|diagnostic| diagnostic.code == DiagCode::W210 && diagnostic.message.contains(&named))
9647: }
9648: 
9649: /// A call to a procedure of the module is the assignment its summary states
9650: /// for the place a `Name` argument names: after `reset m`, which unsets it,
9651: /// a read of `m` is read before it is set, in a procedure and at the top
9652: /// level, by `puts` and by `return`, and after the `info exists` test that
9653: /// decides it gone; after `maybe k $c`, which may leave `k` unset, a read of
9654: /// `k` nothing set before the call is too — the analyser has no may form of
9655: /// W210, so it is the plain finding — and after `bump q`, which binds `q`,
9656: /// the read draws nothing. tclsh 8.4 to 9.1 stop with `can't read` in each
9657: /// that reports, before and after `tcl opt`.
9658: #[test]
9659: fn a_read_after_a_call_reads_the_place_as_the_call_leaves_it() {
9660:     let reporting = [
9661:         (
9662:             format!("{RESET}proc p {{}} {{set m 1; reset m; puts $m}}\np\n"),
9663:             "m",
9664:             "",
9665:         ),
9666:         (format!("{RESET}set m 1\nreset m\nputs $m\n"), "m", ""),
9667:         (
9668:             format!("{RESET}proc p {{}} {{set m 1; reset m; return $m}}\nputs [p]\n"),
9669:             "m",
9670:             "",
9671:         ),
9672:         (
9673:             "proc maybe {name c} {upvar 1 $name v; if {$c} {set v 9}}\n\
9674:              proc p {c} {maybe k $c; puts $k}\np 0\n"
9675:                 .to_owned(),
9676:             "k",
9677:             "",
9678:         ),
9679:         (
9680:             format!(
9681:                 "{RESET}proc p {{}} {{set m 1; reset m; \
9682:                  if {{[info exists m]}} {{puts $m}} else {{puts gone}}; puts $m}}\np\n"
9683:             ),
9684:             "m",
9685:             "gone\n",
9686:         ),
9687:     ];
9688:     for (source, name, printed) in &reporting {
9689:         for dialect in DIALECTS {
9690:             assert!(
9691:                 reads_before_set(source, dialect, name),
9692:                 "{dialect}: {source}"
9693:             );
9694:         }
9695:         prints_then_errors(source, printed);
9696:     }
9697:     let bound = format!("{BUMP}proc p {{}} {{bump q; puts $q}}\np\n");
9698:     for dialect in DIALECTS {
9699:         assert!(!reports(&bound, dialect, DiagCode::W210), "{dialect}");
9700:     }
9701: }
9702: 
9703: /// A call the analyser cannot re-run takes its callee's summary: `drop`'s
9704: /// recursion goes 40 calls deep, past the 32 a re-run reaches, so the call
9705: /// at that depth applies `drop`'s step, an unbind, and each run above it
9706: /// reads the place from there; `z` and `y` are unbound after `drop z 40`
9707: /// and `drop y 40`, so both `[info exists …]` tests fold to the `gone`
9708: /// arm. The recursion is no tail call, which O122 would turn into a loop.
9709: /// tclsh 8.4 to 9.1 print `gone` twice, before and after `tcl opt`.
9710: #[test]
9711: fn a_call_past_the_rerun_depth_takes_the_summarys_step() {
9712:     let source = "proc drop {name n} {upvar 1 $name v; \
9713:                   if {$n > 0} {drop v [expr {$n - 1}]; set n 0} else {unset v}}\n\
9714:                   set z 1\ndrop z 40\nif {[info exists z]} {puts kept} else {puts gone}\n\
9715:                   proc p {} {set y 1; drop y 40; \
9716:                   if {[info exists y]} {return kept} else {return gone}}\nputs [p]\n";
9717:     for dialect in ["tcl8.4", "tcl8.6", "tcl9.0"] {
9718:         let unit = unit_of(source, dialect);
9719:         assert_eq!(last_existence(&unit, "::p", "y"), UNBOUND, "{dialect}");
9720:         let (rewritten, _) = optimised(source, dialect);
9721:         assert!(
9722:             rewritten.contains("drop z 40\nputs gone\n")
9723:                 && rewritten.contains("drop y 40; return gone}"),
9724:             "{dialect}: {rewritten}"
9725:         );
9726:     }
9727:     prints_under_every_release(source, "gone\ngone\n");
9728: }
9729: 
9730: /// `split` of the empty string is the empty list under every release, and
9731: /// `tcl opt` folds it through the `split` route: the registry's literal
9732: /// folder made it `{}` (#2418), so `set x [split ""]` became `set x {{}}`
9733: /// and `puts [llength $x]` printed 1 where tclsh prints 0.
9734: #[test]
9735: fn split_of_the_empty_string_is_the_empty_list() {
9736:     let source = "proc p {} {\n    set x [split \"\"]\n    puts [llength $x]\n    puts \"<[split {}]>\"\n}\np\n";
9737:     for dialect in ["tcl8.4", "tcl8.5", "tcl8.6", "tcl9.0", "tcl9.1"] {
9738:         let (rewritten, rewrites) = optimised(source, dialect);
9739:         assert!(
9740:             !rewritten.contains("{{}}") && !rewritten.contains("puts 1"),
9741:             "{dialect}: `split \"\"` is the empty list\n{rewritten}\n{rewrites:#?}"
9742:         );
9743:     }
9744:     prints_under_every_release(source, "0\n<>\n");
9745: }
9746: 
9747: /// A substitution whose route raises is labelled by its completion, as the
9748: /// `lset` view labels one, and not as a store: 8.4 reads no sums, so
9749: /// `string range abcdefghijkl 0 1+1` raises `bad index` there and is no value.
9750: #[test]
9751: fn a_raising_substitution_is_labelled_by_its_completion() {
9752:     let source = "proc p {} {\n    set r [string range abcdefghijkl 0 1+1]\n    return $r\n}\n";
9753:     let unit = summarised_unit(source, "tcl8.4");
9754:     assert_eq!(
9755:         answers_for(&unit, "::p", "string"),
9756:         ["evaluated: error after 0 stores"]
9757:     );
9758:     let unit = summarised_unit(source, "tcl8.6");
9759:     assert_eq!(answers_for(&unit, "::p", "string"), ["evaluated"]);
9760: }
