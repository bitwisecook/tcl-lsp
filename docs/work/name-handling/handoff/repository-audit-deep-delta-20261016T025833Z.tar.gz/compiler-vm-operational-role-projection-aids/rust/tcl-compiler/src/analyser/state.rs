/* ORIGINAL_SOURCE_RANGE 2136..2144 */
2136:     #[cfg(test)]
2137:     pub(crate) fn analyse_and_retain_result_for_test(
2138:         &mut self,
2139:         source: &str,
2140:         dialect: &str,
2141:     ) -> &AnalysisResult {
2142:         self.result = self.analyse(source, dialect);
2143:         &self.result
2144:     }
/* ORIGINAL_SOURCE_RANGE 3598..7573 */
3598: #[cfg(test)]
3599: mod tests {
3600:     use super::*;
3601:     use crate::analyser::types::ScopeKind;
3602: 
3603:     /// The composite-head split asks the shared owner where the
3604:     /// `${…}` name ends, so the dispatched variable and the word suffix move
3605:     /// with the release rather than always splitting at the first `}`.
3606:     ///
3607:     /// The lexer merges `${ns}::setdef` into one `Var` token whose text is
3608:     /// `ns}::setdef`; a *pure* `${x}` arrives as `x`, its closer already
3609:     /// outside the span. Both shapes fall out of `braced_var_name_end`:
3610:     /// `Closed` is the composite case, `Unterminated` the pure one.
3611:     #[test]
3612:     fn split_braced_head_follows_the_release_close_rule() {
3613:         let mut a = Analyser::new();
3614: 
3615:         // 9.x nests, so `${a{b}c}::setdef` dispatches on `a{b}c`.
3616:         a.profile = tcl_registry::model::ingress::resolve_environment("tcl9.0").analyser_profile();
3617:         assert_eq!(a.split_braced_head("ns}::setdef"), ("ns", "::setdef"));
3618:         assert_eq!(a.split_braced_head("a{b}c}::setdef"), ("a{b}c", "::setdef"));
3619:         // A pure `${…}` token has no closer inside its text: all name.
3620:         assert_eq!(a.split_braced_head("a{b}c"), ("a{b}c", ""));
3621:         assert_eq!(a.split_braced_head("x"), ("x", ""));
3622:         // A simple `$obj` / `$ns::v` head is unchanged.
3623:         assert_eq!(a.split_braced_head("ns::v"), ("ns::v", ""));
3624: 
3625:         // 8.x ends the name at the first literal `}`.
3626:         a.profile = tcl_registry::model::ingress::resolve_environment("tcl8.6").analyser_profile();
3627:         assert_eq!(a.split_braced_head("ns}::setdef"), ("ns", "::setdef"));
3628:         assert_eq!(a.split_braced_head("a{b}c}::setdef"), ("a{b", "c}::setdef"));
3629:     }
3630: 
3631:     #[test]
3632:     fn retained_analysis_fixture_keeps_the_returned_source_owner_for_private_queries() {
3633:         // naming.diagnostic.registry-source-ownership
3634:         // docs/design/analysis/name-resolution-proofs/diagnostic-registry-source-ownership.md
3635:         let source = "eval $script";
3636:         let mut analyser = Analyser::new();
3637:         let returned = analyser.analyse(source, "tcl");
3638:         assert!(returned.resolved_input.is_some());
3639:         assert!(analyser.result.resolved_input.is_none());
3640:         analyser.analyse_and_retain_result_for_test(source, "tcl");
3641:         let input = analyser.result.resolved_input.as_ref().unwrap();
3642:         assert!(analyser.result.matches_original_source_image(
3643:             &tcl_lexer::SourceImage::document(source),
3644:             input.lexer_config()
3645:         ));
3646:         let command = crate::segmenter::segment_commands_with_offset_and_config(
3647:             source,
3648:             0,
3649:             input.lexer_config(),
3650:         )
3651:         .pop()
3652:         .unwrap();
3653:         assert!(
3654:             analyser
3655:                 .original_diagnostic_call_at(command.argv[0], command.arg_tokens())
3656:                 .is_some()
3657:         );
3658:     }
3659: 
3660:     #[test]
3661:     fn unavailable_overlay_is_retained_before_every_analysis_walk() {
3662:         let overlay = u64::MAX;
3663:         let source = "proc must_not_be_walked {} {set x 1}; must_not_be_walked";
3664:         let commands = crate::segmenter::segment_commands(source);
3665:         let mut analyser = Analyser::new().with_pack_overlay(overlay);
3666:         let missing = analyser
3667:             .try_analysis_context()
3668:             .expect_err("no registered overlay");
3669:         assert_eq!(missing.overlay, overlay);
3670:         let full = analyser.analyse(source, "tcl");
3671:         let supplied = analyser.analyse_commands(source, &commands, "tcl", true);
3672:         let (chunked, snapshots) = analyser.analyse_chunked(source, vec![commands.clone()], "tcl");
3673:         assert!(snapshots.is_empty());
3674:         let incremental = analyser.analyse_incremental(source, &commands, source, "tcl");
3675:         let mut called = false;
3676:         let per_item = analyser.analyse_per_item_with(source, "tcl", &mut |_| {
3677:             called = true;
3678:             unreachable!("an unavailable generation cannot dispatch a body")
3679:         });
3680:         assert!(!called);
3681:         for result in [full, supplied, chunked, incremental, per_item] {
3682:             assert_eq!(result.analysis_context_unavailable.as_ref(), Some(&missing));
3683:             assert!(result.resolved_input.is_none());
3684:             assert!(result.all_procs.is_empty());
3685:             assert!(result.command_invocations.is_empty());
3686:             assert!(result.diagnostics.is_empty());
3687:             assert!(result.global_scope.children.is_empty());
3688:         }
3689:     }
3690: 
3691:     #[test]
3692:     fn original_whole_source_recovery_keeps_file_config_and_typed_warning_fields() {
3693:         // naming.source.original-configured-script-completeness
3694:         // docs/design/analysis/name-resolution-proofs/source-original-configured-script-completeness.md
3695:         // Original recovery/diagnostic streams, without entered-source admission.
3696:         let source = "\u{feff}set x [foo bar\nputs done\n";
3697:         let mut prepared = Analyser::new();
3698:         let input = prepared.prepare_analysis_input("tcl9.1").unwrap();
3699:         for supplied in [None, Some(input.clone())] {
3700:             let mut analyser = supplied.as_ref().map_or_else(Analyser::new, |input| {
3701:                 Analyser::new().with_resolved_input(input.clone())
3702:             });
3703:             analyser.analyse_and_retain_result_for_test(source, "tcl9.1");
3704:             let mut commands = crate::segmenter::segment_commands_with_offset_and_config(
3705:                 source,
3706:                 0,
3707:                 analyser.file_lexer_config(),
3708:             );
3709:             assert!(analyser.apply_ghost_recovery(source, &mut commands));
3710:             assert_eq!(
3711:                 commands
3712:                     .iter()
3713:                     .map(crate::segmenter::SegmentedCommand::name)
3714:                     .collect::<Vec<_>>(),
3715:                 ["set", "puts"]
3716:             );
3717:             assert_eq!(commands[0].argv[0].span.start(), 3);
3718:             assert_eq!(analyser.result.resolved_input.as_ref(), Some(&input));
3719:         }
3720:         for (source, kind, code) in [
3721:             (
3722:                 "\u{feff}set x {abc}def\n",
3723:                 tcl_lexer::ParseIssueKind::ExtraAfterBrace,
3724:                 DiagCode::E204,
3725:             ),
3726:             (
3727:                 "\u{feff}set y \"abc\"def\n",
3728:                 tcl_lexer::ParseIssueKind::ExtraAfterQuote,
3729:                 DiagCode::E205,
3730:             ),
3731:             (
3732:                 "\u{feff}puts ${foo\n",
3733:                 tcl_lexer::ParseIssueKind::MissingVariableBrace,
3734:                 DiagCode::E206,
3735:             ),
3736:         ] {
3737:             let config = input.lexer_config();
3738:             let (_, warnings) = tcl_lexer::Lexer::with_config(source, config)
3739:                 .tokenise_all_with_warnings()
3740:                 .unwrap();
3741:             let warning = warnings
3742:                 .iter()
3743:                 .find(|warning| warning.kind == kind)
3744:                 .unwrap();
3745:             let analysis = Analyser::new()
3746:                 .with_resolved_input(input.clone())
3747:                 .analyse(source, "display-only");
3748:             let diagnostic = analysis
3749:                 .diagnostics
3750:                 .iter()
3751:                 .find(|diagnostic| diagnostic.code == code)
3752:                 .unwrap();
3753:             assert_eq!(diagnostic.message, warning.message);
3754:             assert_eq!(diagnostic.span, Span::new(warning.offset, warning.offset));
3755:         }
3756:     }
3757: 
3758:     #[test]
3759:     fn original_prepared_input_records_the_file_boundary_and_preserves_supplied_config() {
3760:         // naming.source.original-configured-script-completeness
3761:         // docs/design/analysis/name-resolution-proofs/source-original-configured-script-completeness.md
3762:         // Original editing inputs; no runtime source or Native entry receipt.
3763:         let source = "\u{feff}set name value";
3764:         let mut default = Analyser::new();
3765:         let prepared = default.prepare_analysis_input("tcl9.1").unwrap();
3766:         assert_eq!(prepared.lexer_config(), default.file_lexer_config());
3767:         assert_eq!(
3768:             prepared.lexer_config().leading_bom,
3769:             tcl_lexer::LeadingBom::Skip
3770:         );
3771:         assert_ne!(prepared.lexer_config(), default.lexer_config());
3772:         let ordinary = Analyser::new().analyse(source, "tcl9.1");
3773:         let retained = Analyser::new()
3774:             .with_resolved_input(prepared.clone())
3775:             .analyse(source, "presentation-only");
3776:         assert_eq!(ordinary.resolved_input.as_ref(), Some(&prepared));
3777:         assert_eq!(ordinary.body_lexer_config, Some(prepared.lexer_config()));
3778:         assert!(ordinary.matches_original_source_image(
3779:             &tcl_lexer::SourceImage::document(source),
3780:             prepared.lexer_config(),
3781:         ));
3782:         assert!(retained.matches_original_source_image(
3783:             &tcl_lexer::SourceImage::document(source),
3784:             prepared.lexer_config(),
3785:         ));
3786:         assert_eq!(project_result(&ordinary), project_result(&retained));
3787:         let command = crate::segmenter::segment_commands_with_offset_and_config(
3788:             source,
3789:             0,
3790:             prepared.lexer_config(),
3791:         )
3792:         .pop()
3793:         .unwrap();
3794:         assert_eq!(command.texts[0], "set");
3795: 
3796:         let environment = crate::environment_ingress::resolve_environment("tcl9.1");
3797:         let config = tcl_lexer::LexerConfig {
3798:             leading_bom: tcl_lexer::LeadingBom::Content,
3799:             braced_var: tcl_lexer::BracedVarStyle::FirstClose,
3800:             ..tcl_lexer::LexerConfig::for_file_grammar(environment.grammar())
3801:         };
3802:         let supplied = super::super::input::ResolvedAnalysisInput::new(
3803:             environment.analyser_profile(),
3804:             environment.unit_profile(),
3805:             environment.default_context_registry(),
3806:             config,
3807:         );
3808:         let mut selected = Analyser::new().with_resolved_input(supplied.clone());
3809:         assert_eq!(selected.prepare_analysis_input("tcl8.4").unwrap(), supplied);
3810:         let result = selected.analyse(source, "tcl8.4");
3811:         assert_eq!(result.resolved_input.as_ref(), Some(&supplied));
3812:         assert_eq!(result.body_lexer_config, Some(config));
3813:         let command = crate::segmenter::segment_commands_with_offset_and_config(
3814:             source,
3815:             0,
3816:             result.resolved_input.as_ref().unwrap().lexer_config(),
3817:         )
3818:         .pop()
3819:         .unwrap();
3820:         assert_eq!(command.texts[0], "\u{feff}set");
3821:     }
3822: 
3823:     #[test]
3824:     fn original_incremental_completeness_retains_the_supplied_parser_configuration() {
3825:         // naming.source.original-configured-script-completeness
3826:         // docs/design/analysis/name-resolution-proofs/source-original-configured-script-completeness.md
3827:         // Incremental source analysis must converge; this grants no entry.
3828:         let environment = crate::environment_ingress::resolve_environment("tcl9.1");
3829:         let previous = "puts before";
3830:         let source = "puts \"${a{}\"";
3831:         for braced_var in [
3832:             tcl_lexer::BracedVarStyle::FirstClose,
3833:             tcl_lexer::BracedVarStyle::Tcl9Nesting,
3834:         ] {
3835:             let config = tcl_lexer::LexerConfig {
3836:                 braced_var,
3837:                 ..tcl_lexer::LexerConfig::for_file_grammar(environment.grammar())
3838:             };
3839:             let input = super::super::input::ResolvedAnalysisInput::new(
3840:                 environment.analyser_profile(),
3841:                 environment.unit_profile(),
3842:                 environment.default_context_registry(),
3843:                 config,
3844:             );
3845:             let commands =
3846:                 crate::segmenter::segment_commands_with_offset_and_config(previous, 0, config);
3847:             let result = Analyser::new()
3848:                 .with_resolved_input(input.clone())
3849:                 .analyse_incremental(previous, &commands, source, "tcl9.1");
3850:             let fresh = Analyser::new()
3851:                 .with_resolved_input(input.clone())
3852:                 .analyse(source, "tcl9.1");
3853:             assert_eq!(result.resolved_input.as_ref(), Some(&input));
3854:             assert_eq!(project_result(&result), project_result(&fresh));
3855:         }
3856:     }
3857: 
3858:     #[test]
3859:     fn retained_actual_input_does_not_borrow_a_presentation_overlay() {
3860:         let environment = tcl_registry::model::ingress::resolve_environment("tcl");
3861:         let input = super::super::input::ResolvedAnalysisInput::new(
3862:             environment.analyser_profile(),
3863:             environment.unit_profile(),
3864:             environment.default_context_registry(),
3865:             tcl_lexer::LexerConfig::default().with_grammar(environment.grammar()),
3866:         );
3867:         let mut analyser = Analyser::new()
3868:             .with_resolved_input(input.clone())
3869:             .with_pack_overlay(u64::MAX);
3870:         let result = analyser.analyse("proc retained {} {}", "tcl9.1");
3871:         assert!(result.analysis_context_unavailable.is_none());
3872:         assert_eq!(result.resolved_input.as_ref(), Some(&input));
3873:         assert!(result.all_procs.contains_key("::retained"));
3874:     }
3875: 
3876:     #[test]
3877:     fn new_analyser_starts_at_global_scope_with_empty_state() {
3878:         let a = Analyser::new();
3879:         assert_eq!(a.result.global_scope.kind, ScopeKind::Global);
3880:         assert_eq!(a.current_scope_path, [] as [usize; 0]);
3881:         assert_eq!(a.source, "");
3882:         assert_eq!(a.disabled_diagnostics.len(), 0);
3883:         assert_eq!(a.conditional_depth, 0);
3884:         assert_eq!(a.body_depth, 0);
3885:         assert_eq!(a.last_comment, "");
3886:         assert!(a.file_path.is_none());
3887:         assert_eq!(a.command_aliases.len(), 0);
3888:         assert_eq!(
3889:             a.var_command_sites,
3890:             [] as [crate::analyser::state::VarCommandSite; 0]
3891:         );
3892:         assert_eq!(
3893:             a.cmd_command_sites,
3894:             [] as [crate::analyser::state::CmdCommandSite; 0]
3895:         );
3896:         assert_eq!(a.const_strings.len(), 0);
3897:         assert_eq!(a.regex_vars.len(), 0);
3898:         assert!(a.builtin_names.is_none());
3899:         assert!(a.builtin_dialect.is_none());
3900:         assert!(a.current_event.is_none());
3901:         assert_eq!(a.ensemble_namespaces.len(), 0);
3902:         assert_eq!(a.objdefined_vars.len(), 0);
3903:         assert!(!a.unresolved_commands_emitted);
3904:     }
3905: 
3906:     #[test]
3907:     fn with_disabled_diagnostics_threads_through() {
3908:         let disabled: HashSet<String> = ["W210", "W211"].iter().map(|s| (*s).to_string()).collect();
3909:         let a = Analyser::with_disabled_diagnostics(disabled.clone());
3910:         assert_eq!(a.disabled_diagnostics, disabled);
3911:     }
3912: 
3913:     #[test]
3914:     fn analyse_records_top_level_proc() {
3915:         let mut a = Analyser::new();
3916:         let r = a.analyse("proc foo {} { set x 1 }", "tcl");
3917:         assert!(r.all_procs.contains_key("::foo"));
3918:     }
3919: 
3920:     #[test]
3921:     fn apply_body_proc_registers_in_global_namespace_not_caller() {
3922:         // `apply`'s body runs in the *global* namespace (no lambda namespace
3923:         // given), NOT the caller's — so a nested `proc` registers as `::helper`,
3924:         // never `::foo::helper` (Tcl `apply` manual; matches the IR lowering).
3925:         let mut a = Analyser::new();
3926:         let r = a.analyse(
3927:             "namespace eval foo { apply {{} { proc helper {} { return 1 } }} }",
3928:             "tcl",
3929:         );
3930:         assert!(
3931:             r.all_procs.contains_key("::helper"),
3932:             "apply body proc must register globally: {:?}",
3933:             r.all_procs.keys().collect::<Vec<_>>()
3934:         );
3935:         assert!(
3936:             !r.all_procs.contains_key("::foo::helper"),
3937:             "apply body proc must NOT inherit the caller namespace: {:?}",
3938:             r.all_procs.keys().collect::<Vec<_>>()
3939:         );
3940:     }
3941: 
3942:     /// TP — the tcllib pki idiom: `proc [namespace current]::_x {...}` inside
3943:     /// `::pki`.  The body's own definitions must home to `::pki`, not to a
3944:     /// phantom namespace made out of the substitution's source text.
3945:     ///
3946:     /// Oracle (tclsh 8.6.16 and 9.0.4, probe `s5_probe.tcl`):
3947:     ///
3948:     /// ```text
3949:     /// inner exists: ::pki::_inner
3950:     /// helper homed at: ::pki::helper / global:
3951:     /// ```
3952:     #[test]
3953:     fn a_dynamically_named_procs_body_homes_to_the_lexical_namespace() {
3954:         let src = "namespace eval ::pki {\n\
3955:                        proc _outer {} {\n\
3956:                            proc [namespace current]::_inner {} {\n\
3957:                                proc helper {} { return HELPED }\n\
3958:                            }\n\
3959:                        }\n\
3960:                    }\n";
3961:         let mut a = Analyser::new();
3962:         let r = a.analyse(src, "tcl");
3963:         assert!(
3964:             r.all_procs.contains_key("::pki::helper"),
3965:             "the body of a `[namespace current]`-named proc runs in ::pki: {:?}",
3966:             r.all_procs.keys().collect::<Vec<_>>()
3967:         );
3968:         assert!(
3969:             !r.all_procs
3970:                 .keys()
3971:                 .any(|k| k.contains("[namespace current]") && k.ends_with("helper")),
3972:             "no phantom substitution-text namespace may appear: {:?}",
3973:             r.all_procs.keys().collect::<Vec<_>>()
3974:         );
3975:     }
3976: 
3977:     /// TN — a statically-named proc is untouched: the scope name is the
3978:     /// resolved name verbatim, so an ordinary qualified-name proc still homes
3979:     /// its nested definitions to its own defining namespace.
3980:     #[test]
3981:     fn a_statically_named_procs_body_still_homes_to_its_defining_namespace() {
3982:         let src = "proc ::pki::_outer {} { proc helper {} {} }\n";
3983:         let mut a = Analyser::new();
3984:         let r = a.analyse(src, "tcl");
3985:         assert!(
3986:             r.all_procs.contains_key("::pki::helper"),
3987:             "{:?}",
3988:             r.all_procs.keys().collect::<Vec<_>>()
3989:         );
3990:     }
3991: 
3992:     /// A `$`-spelled dynamic tail (`proc _$n {...}`) keeps the lexical
3993:     /// namespace too — the fallback is the trailing segment, whose holder is
3994:     /// the enclosing namespace.
3995:     #[test]
3996:     fn a_dollar_named_procs_body_homes_to_the_lexical_namespace() {
3997:         let src = "namespace eval ::pki { proc _$suffix {} { proc helper {} {} } }\n";
3998:         let mut a = Analyser::new();
3999:         let r = a.analyse(src, "tcl");
4000:         assert!(
4001:             r.all_procs.contains_key("::pki::helper"),
4002:             "{:?}",
4003:             r.all_procs.keys().collect::<Vec<_>>()
4004:         );
4005:     }
4006: 
4007:     #[test]
4008:     fn apply_body_proc_honours_explicit_lambda_namespace() {
4009:         // A lambda pinning a namespace (element 2) runs its body there.
4010:         let mut a = Analyser::new();
4011:         let r = a.analyse("apply {{} { proc helper {} { return 1 } } ::bar}", "tcl");
4012:         assert!(
4013:             r.all_procs.contains_key("::bar::helper"),
4014:             "explicit lambda namespace must be honoured: {:?}",
4015:             r.all_procs.keys().collect::<Vec<_>>()
4016:         );
4017:     }
4018: 
4019:     /// TP — a *relative* (non-`::`-prefixed) lambda namespace element is
4020:     /// interpreted against the GLOBAL namespace, never the caller's.
4021:     ///
4022:     /// `doc/apply.n`: "If given, namespace is interpreted relative to the
4023:     /// global namespace even if its name does not start with `::`";
4024:     /// `tclProc.c`'s `TclNRApplyObjCmd` `::`-prefixes the word before the
4025:     /// lookup. tclsh 9.0.4 oracle (probe `a2b_apply.tcl`), with `::sub`,
4026:     /// `::pin::sub`, and `::lex::sub` all defined:
4027:     ///
4028:     /// ```text
4029:     /// lex-body current=::lex -> ns=::sub who=GLOBAL-SUB
4030:     /// proc current=::pin     -> ns=::sub who=GLOBAL-SUB
4031:     /// c2 current=::pin       -> ns=::sub who=GLOBAL-SUB
4032:     /// ```
4033:     #[test]
4034:     fn apply_relative_lambda_namespace_homes_globally_not_to_the_caller() {
4035:         let src = "namespace eval ::sub {}\n\
4036:                    namespace eval ::caller::sub {}\n\
4037:                    proc ::caller::p {} {\n\
4038:                        apply {{} { proc helper {} { return 1 } } sub}\n\
4039:                    }\n";
4040:         let mut a = Analyser::new();
4041:         let r = a.analyse(src, "tcl");
4042:         assert!(
4043:             r.all_procs.contains_key("::sub::helper"),
4044:             "relative lambda ns must resolve against ::, not the caller: {:?}",
4045:             r.all_procs.keys().collect::<Vec<_>>()
4046:         );
4047:         assert!(
4048:             !r.all_procs.contains_key("::caller::sub::helper"),
4049:             "relative lambda ns must NOT pin against the caller namespace: {:?}",
4050:             r.all_procs.keys().collect::<Vec<_>>()
4051:         );
4052:         let (_, ns) = r
4053:             .namespace_overrides
4054:             .first()
4055:             .expect("the lambda body records a namespace override");
4056:         assert_eq!(ns, "::sub");
4057:     }
4058: 
4059:     /// TN — an *absolute* namespace element is unaffected by the
4060:     /// global-relative rule: `::caller::sub` stays `::caller::sub`.
4061:     #[test]
4062:     fn apply_absolute_lambda_namespace_is_unchanged() {
4063:         let src = "namespace eval ::sub {}\n\
4064:                    namespace eval ::caller::sub {}\n\
4065:                    proc ::caller::p {} {\n\
4066:                        apply {{} { proc helper {} { return 1 } } ::caller::sub}\n\
4067:                    }\n";
4068:         let mut a = Analyser::new();
4069:         let r = a.analyse(src, "tcl");
4070:         assert!(
4071:             r.all_procs.contains_key("::caller::sub::helper"),
4072:             "absolute lambda ns must be honoured verbatim: {:?}",
4073:             r.all_procs.keys().collect::<Vec<_>>()
4074:         );
4075:     }
4076: 
4077:     /// Control — no namespace element at all still means the global
4078:     /// namespace, from inside a qualified-name proc as much as anywhere.
4079:     #[test]
4080:     fn apply_without_a_namespace_element_stays_global_inside_a_qualified_proc() {
4081:         let src = "proc ::caller::p {} {\n\
4082:                        apply {{} { proc helper {} { return 1 } }}\n\
4083:                    }\n";
4084:         let mut a = Analyser::new();
4085:         let r = a.analyse(src, "tcl");
4086:         assert!(
4087:             r.all_procs.contains_key("::helper"),
4088:             "an absent lambda ns means global: {:?}",
4089:             r.all_procs.keys().collect::<Vec<_>>()
4090:         );
4091:     }
4092: 
4093:     #[test]
4094:     fn apply_with_namespace_element_records_a_namespace_override() {
4095:         // TP (the core mechanism): a literal
4096:         // `apply {{params} body ns}` must record a namespace_overrides
4097:         // entry spanning the body, so `tcl-lsp-core`'s command-resolution
4098:         // lookups can pin bareword calls inside the body to `ns` — the
4099:         // `Scope` subtree `reconstruct_proc_scope` builds for `ns` is
4100:         // rooted under body_span-less wrapper nodes the ordinary lexical
4101:         // walk can never reach.
4102:         let mut a = Analyser::new();
4103:         let src = "apply {{} { cleanup done } ::real}";
4104:         let r = a.analyse(src, "tcl");
4105:         assert_eq!(
4106:             r.namespace_overrides.len(),
4107:             1,
4108:             "{:?}",
4109:             r.namespace_overrides
4110:         );
4111:         let (span, ns) = &r.namespace_overrides[0];
4112:         assert_eq!(ns, "::real");
4113:         // The recorded span is the body token's raw span (opening brace
4114:         // included, per this codebase's lexer-span convention — the
4115:         // closing brace is excluded, one byte short of the token's end).
4116:         assert_eq!(
4117:             &src[span.start() as usize..span.end() as usize],
4118:             "{ cleanup done "
4119:         );
4120:     }
4121: 
4122:     #[test]
4123:     fn apply_without_namespace_element_does_not_record_an_override() {
4124:         // TN — a 2-element lambda (no namespace argument) defaults to
4125:         // global, which `command_resolution_namespace_at` already reports
4126:         // with no override present; pushing a `(span, "::")` entry would
4127:         // be a no-op relative to today's behaviour, but the plan
4128:         // deliberately still records it (uniform code path) — confirm the
4129:         // recorded namespace is exactly `"::"`, not skipped or wrong.
4130:         let mut a = Analyser::new();
4131:         let r = a.analyse("apply {{} { cleanup done }}", "tcl");
4132:         assert_eq!(
4133:             r.namespace_overrides.len(),
4134:             1,
4135:             "{:?}",
4136:             r.namespace_overrides
4137:         );
4138:         assert_eq!(r.namespace_overrides[0].1, "::");
4139:     }
4140: 
4141:     #[test]
4142:     fn unknown_lexer_warning_maps_to_e200() {
4143:         // An unterminated `$arr(idx` array index makes the lexer emit a
4144:         // "missing )" warning, which has no dedicated recovery code — it
4145:         // must surface as the catch-all E200 (not be silently dropped).
4146:         let mut a = Analyser::new();
4147:         let r = a.analyse("set x $arr(idx\n", "tcl8.6");
4148:         let e200 = r.diagnostics.iter().find(|d| d.code == DiagCode::E200);
4149:         assert!(
4150:             e200.is_some_and(|d| d.message == "missing )"),
4151:             "{:?}",
4152:             r.diagnostics
4153:         );
4154:     }
4155: 
4156:     #[test]
4157:     fn analyse_records_multiple_top_level_commands() {
4158:         let mut a = Analyser::new();
4159:         let r = a.analyse("set x 1\nproc foo {} {}\nglobal a b", "tcl");
4160:         assert!(r.all_procs.contains_key("::foo"));
4161:         assert!(r.global_scope.variables.contains_key("x"));
4162:         assert!(r.global_scope.variables.contains_key("a"));
4163:         assert!(r.global_scope.variables.contains_key("b"));
4164:     }
4165: 
4166:     #[test]
4167:     fn analyse_records_instance_class_set_new() {
4168:         // `set d [Dog new]` maps `d` -> `::Dog`.
4169:         let mut a = Analyser::new();
4170:         let r = a.analyse(
4171:             "oo::class create Dog { method bark {} {} }\nset d [Dog new]\n",
4172:             "tcl",
4173:         );
4174:         assert_eq!(
4175:             r.instance_classes.get("d").map(String::as_str),
4176:             Some("::Dog")
4177:         );
4178:     }
4179: 
4180:     /// A rooted `::set d [Dog new]` binds `d` as `set` does: the
4181:     /// instance tracking reads `set`'s handle-binding layout, which the
4182:     /// rooted spelling resolves to, rather than comparing the spelling `set`
4183:     /// (tclsh 8.6.18 to 9.1b0: `$d bark` dispatches to `::Dog`).
4184:     #[test]
4185:     fn analyse_records_instance_class_rooted_set_new() {
4186:         let mut a = Analyser::new();
4187:         let r = a.analyse(
4188:             "oo::class create Dog { method bark {} {} }\n::set d [Dog new]\n",
4189:             "tcl",
4190:         );
4191:         assert_eq!(
4192:             r.instance_classes.get("d").map(String::as_str),
4193:             Some("::Dog")
4194:         );
4195:     }
4196: 
4197:     #[test]
4198:     fn analyse_records_instance_class_create_named() {
4199:         // `Dog create rex` maps `rex` -> `::Dog`.
4200:         let mut a = Analyser::new();
4201:         let r = a.analyse(
4202:             "oo::class create Dog { method bark {} {} }\nDog create rex\n",
4203:             "tcl",
4204:         );
4205:         assert_eq!(
4206:             r.instance_classes.get("rex").map(String::as_str),
4207:             Some("::Dog"),
4208:         );
4209:     }
4210: 
4211:     #[test]
4212:     fn analyse_records_instance_class_set_create() {
4213:         // `set d [Dog create rex]` maps `d` -> `::Dog`.
4214:         let mut a = Analyser::new();
4215:         let r = a.analyse("oo::class create Dog {}\nset d [Dog create rex]\n", "tcl");
4216:         assert_eq!(
4217:             r.instance_classes.get("d").map(String::as_str),
4218:             Some("::Dog")
4219:         );
4220:     }
4221: 
4222:     #[test]
4223:     fn analyse_records_instance_class_through_a_var_headed_create() {
4224:         // TP: tcllib's `httpd/httpd.tcl` flows the
4225:         // constructor's class name through a single, unconditional `set`
4226:         // one line earlier (`set class ::Derived; set obj [$class create
4227:         // NAME]`) rather than writing the class as a literal bareword.
4228:         // Verified against real tclsh9.0/8.6: `$obj`'s methods dispatch to
4229:         // `Dog` either way, so the analyser must bind `obj` -> `::Dog`
4230:         // exactly like the literal-bareword shape already does.
4231:         let mut a = Analyser::new();
4232:         let r = a.analyse(
4233:             "oo::class create Dog { method bark {} {} }\nset class Dog\nset obj [$class create rex]\n",
4234:             "tcl",
4235:         );
4236:         assert_eq!(
4237:             r.instance_classes.get("obj").map(String::as_str),
4238:             Some("::Dog"),
4239:             "{:?}",
4240:             r.instance_classes
4241:         );
4242:     }
4243: 
4244:     #[test]
4245:     fn analyse_records_instance_class_through_a_var_headed_new() {
4246:         // TP — same gap, the `new` constructor spelling.
4247:         let mut a = Analyser::new();
4248:         let r = a.analyse(
4249:             "oo::class create Dog { method bark {} {} }\nset class Dog\nset obj [$class new]\n",
4250:             "tcl",
4251:         );
4252:         assert_eq!(
4253:             r.instance_classes.get("obj").map(String::as_str),
4254:             Some("::Dog"),
4255:             "{:?}",
4256:             r.instance_classes
4257:         );
4258:     }
4259: 
4260:     #[test]
4261:     fn analyse_rejects_a_var_headed_non_manufacturer_word() {
4262:         // FP guard: the shape parser accepts any literal method so that the
4263:         // registry can decide after `$class` resolves. A normal method must
4264:         // not become a constructor merely because it follows a class handle.
4265:         let mut a = Analyser::new();
4266:         let r = a.analyse(
4267:             "oo::class create Dog { method inspect {} { return value } }\nset class Dog\nset obj [$class inspect]\n",
4268:             "tcl",
4269:         );
4270:         assert_eq!(
4271:             r.instance_classes.get("obj"),
4272:             None,
4273:             "{:?}",
4274:             r.instance_classes
4275:         );
4276:     }
4277: 
4278:     #[test]
4279:     fn analyse_rejects_unexported_create_with_namespace_dispatch() {
4280:         // TN/FP guard pinned against tclsh 9.0.4: `Dog
4281:         // createWithNamespace x ::xns` fails with TCL LOOKUP METHOD. The
4282:         // registry retains its structural layout for self-dispatch, but an
4283:         // ordinary `$class` command cannot use it as construction evidence.
4284:         let mut a = Analyser::new();
4285:         let r = a.analyse(
4286:             "oo::class create Dog {}\nset class Dog\nset obj [$class createWithNamespace x ::xns]\n",
4287:             "tcl",
4288:         );
4289:         assert_eq!(
4290:             r.instance_classes.get("obj"),
4291:             None,
4292:             "{:?}",
4293:             r.instance_classes
4294:         );
4295:     }
4296: 
4297:     #[test]
4298:     fn analyse_abstains_on_a_branch_ambiguous_class_var() {
4299:         // TN — a class variable whose reaching definitions genuinely
4300:         // disagree (one arm `Dog`, the other `Cat`) is unprovable at the
4301:         // constructor call: binding *either* class would be a guess, so
4302:         // the analyser must abstain (no `instance_classes` entry) rather
4303:         // than pick one arbitrarily.
4304:         let mut a = Analyser::new();
4305:         let r = a.analyse(
4306:             "oo::class create Dog {}\noo::class create Cat {}\nif {$flag} { set class Dog } else { set class Cat }\nset obj [$class create x]\n",
4307:             "tcl",
4308:         );
4309:         assert_eq!(
4310:             r.instance_classes.get("obj"),
4311:             None,
4312:             "{:?}",
4313:             r.instance_classes
4314:         );
4315:     }
4316: 
4317:     #[test]
4318:     fn analyse_abstains_on_a_genuinely_dynamic_class_var() {
4319:         // TN — a class variable fed by a computed value (no exact
4320:         // constant) can't be proven at all; must abstain exactly like the
4321:         // pre-fix behaviour rather than binding a wrong/empty class.
4322:         let mut a = Analyser::new();
4323:         let r = a.analyse(
4324:             "oo::class create Dog {}\nset class [someFactory]\nset obj [$class create x]\n",
4325:             "tcl",
4326:         );
4327:         assert_eq!(
4328:             r.instance_classes.get("obj"),
4329:             None,
4330:             "{:?}",
4331:             r.instance_classes
4332:         );
4333:     }
4334: 
4335:     #[test]
4336:     fn analyse_does_not_record_class_definition_as_instance() {
4337:         // `oo::class create Dog` defines a class, not an
4338:         // instance — `Dog` must not appear in instance_classes.
4339:         let mut a = Analyser::new();
4340:         let r = a.analyse("oo::class create Dog {}\n", "tcl");
4341:         assert!(
4342:             !r.instance_classes.contains_key("Dog"),
4343:             "class definition leaked into instance_classes: {:?}",
4344:             r.instance_classes,
4345:         );
4346:     }
4347: 
4348:     #[test]
4349:     fn analyse_ignores_instance_of_unknown_class() {
4350:         // `set d [Widget new]` where Widget isn't a user class
4351:         // records nothing.
4352:         let mut a = Analyser::new();
4353:         let r = a.analyse("set d [Widget new]\n", "tcl");
4354:         assert_eq!(r.instance_classes.len(), 0, "{:?}", r.instance_classes);
4355:     }
4356: 
4357:     #[test]
4358:     fn analyse_namespace_eval_opens_scope() {
4359:         let mut a = Analyser::new();
4360:         let r = a.analyse("namespace eval ns1 { }", "tcl");
4361:         assert_eq!(r.global_scope.children.len(), 1);
4362:         assert_eq!(r.global_scope.children[0].name, "ns1");
4363:     }
4364: 
4365:     #[test]
4366:     fn analyse_empty_source_is_empty_result() {
4367:         let mut a = Analyser::new();
4368:         let r = a.analyse("", "tcl");
4369:         assert_eq!(r.all_procs.len(), 0);
4370:         assert_eq!(r.diagnostics, [] as [crate::analyser::types::Diagnostic; 0]);
4371:     }
4372: 
4373:     #[test]
4374:     fn analyse_threads_file_suppression_into_disabled_diagnostics() {
4375:         // ``# tcl-lsp: disable=W210,W211`` at the top of the file
4376:         // must merge into ``self.disabled_diagnostics`` so
4377:         // emitters honour the suppression.
4378:         let mut a = Analyser::new();
4379:         let _ = a.analyse("# tcl-lsp: disable=W210,W211\nproc foo {} {}\n", "tcl");
4380:         assert!(a.disabled_diagnostics.contains("W210"));
4381:         assert!(a.disabled_diagnostics.contains("W211"));
4382:     }
4383: 
4384:     #[test]
4385:     fn original_next_line_noqa_matches_all_actual_analyser_ingresses() {
4386:         // naming.core.original-comment-source-context
4387:         // docs/design/analysis/name-resolution-proofs/core-original-comment-source-context.md
4388:         let source = "# tcl-lsp: stubs-begin\n# tcl-lsp: stub hold {script:body}\n# tcl-lsp: stubs-end\nhold {\n# noqa: W210\n# comment-only\n}\n";
4389:         let profile =
4390:             tcl_registry::model::ingress::resolve_environment("tcl8.6").analyser_profile();
4391:         let config = tcl_lexer::LexerConfig::for_file_grammar(profile.grammar);
4392:         let commands = crate::segmenter::segment_commands_with_offset_and_config(source, 0, config);
4393:         let full = Analyser::new().analyse(source, profile.name);
4394:         let (chunked, _) =
4395:             Analyser::new().analyse_chunked(source, vec![commands.clone()], profile.name);
4396:         let snapshot = Analyser::new().analyse_commands(source, &commands, profile.name, true);
4397:         let isolated = Analyser::new().analyse_per_item(source, profile.name);
4398:         assert!(full.suppressed_lines.get(&5).unwrap().contains("W210"));
4399:         for result in [chunked, snapshot, isolated] {
4400:             assert_eq!(result.suppressed_lines, full.suppressed_lines);
4401:         }
4402:     }
4403: 
4404:     #[test]
4405:     fn analyse_threads_next_line_noqa_into_suppressed_lines() {
4406:         // A ``# noqa`` comment on its own line must seed
4407:         // ``suppressed_lines`` for the *following* line via the
4408:         // ``parse_noqa_line_suppressions`` pre-scan.  Line 0 carries
4409:         // the ``# noqa`` directive so line 1 should be in the map.
4410:         let mut a = Analyser::new();
4411:         let r = a.analyse("# noqa\nset x 1\n", "tcl");
4412:         let codes = r.suppressed_lines.get(&1).expect("line 1 entry");
4413:         assert!(codes.contains("*"));
4414:     }
4415: 
4416:     #[test]
4417:     fn analyse_chunked_threads_next_line_noqa_into_suppressed_lines() {
4418:         // Same wiring through ``analyse_chunked`` — the LSP's
4419:         // primary incremental entry point.
4420:         use crate::segmenter::SegmentedCommand;
4421:         let mut a = Analyser::new();
4422:         let cmds: Vec<Vec<SegmentedCommand>> = vec![Vec::new()];
4423:         let (r, _) = a.analyse_chunked("# noqa: W210\nset x 1\n", cmds, "tcl");
4424:         let codes = r.suppressed_lines.get(&1).expect("line 1 entry");
4425:         assert!(codes.contains("W210"));
4426:     }
4427: 
4428:     #[test]
4429:     fn analyse_commands_threads_next_line_noqa_into_suppressed_lines() {
4430:         // Same wiring through ``analyse_commands`` — the snapshot-
4431:         // restore entry point.
4432:         use crate::segmenter::SegmentedCommand;
4433:         let mut a = Analyser::new();
4434:         let cmds: Vec<SegmentedCommand> = Vec::new();
4435:         let r = a.analyse_commands("# noqa: W210\nset x 1\n", &cmds, "tcl", true);
4436:         let codes = r.suppressed_lines.get(&1).expect("line 1 entry");
4437:         assert!(codes.contains("W210"));
4438:     }
4439: 
4440:     #[test]
4441:     fn analyse_file_suppression_unions_with_constructor_codes() {
4442:         // Constructor-provided codes must survive file-suppression
4443:         // merging — the two sources are unioned, not replaced.
4444:         use std::collections::HashSet;
4445:         let preconfigured: HashSet<String> = ["W120"].iter().map(|s| (*s).to_string()).collect();
4446:         let mut a = Analyser::with_disabled_diagnostics(preconfigured);
4447:         let _ = a.analyse("# tcl-lsp: disable=W210\n", "tcl");
4448:         assert!(a.disabled_diagnostics.contains("W120"));
4449:         assert!(a.disabled_diagnostics.contains("W210"));
4450:     }
4451: 
4452:     #[test]
4453:     fn analyse_runs_dedupe_and_disabled_filter_at_end() {
4454:         // End-to-end: ``proc set {} {}`` emits W113.
4455:         // ``# tcl-lsp: disable=W113`` at the top of the source
4456:         // should silence it via ``apply_disabled_diagnostics``.
4457:         let mut a = Analyser::new();
4458:         let r = a.analyse("# tcl-lsp: disable=W113\nproc set {} {}\n", "tcl");
4459:         assert!(
4460:             !r.diagnostics.iter().any(|d| d.code == DiagCode::W113),
4461:             "W113 should be silenced by file-suppression directive",
4462:         );
4463:     }
4464: 
4465:     #[test]
4466:     fn w113_silent_on_overridable_library_procs() {
4467:         // FP-STY-13: the script-defined Tcl *library* procedures
4468:         // (`unknown`, `history`, `auto_*`, `parray`, `pkg_mkIndex`,
4469:         // `tcl_*` word helpers) are documented as user-replaceable
4470:         // overlays, not C built-ins — redefining one must not fire
4471:         // W113.
4472:         let mut a = Analyser::new();
4473:         for name in [
4474:             "unknown",
4475:             "history",
4476:             "auto_execok",
4477:             "auto_load",
4478:             "auto_mkindex",
4479:             "auto_qualify",
4480:             "auto_reset",
4481:             "parray",
4482:             "pkg_mkIndex",
4483:             "tcl_findLibrary",
4484:             "tcl_wordBreakAfter",
4485:             "tcl_endOfWord",
4486:         ] {
4487:             let r = a.analyse(&format!("proc {name} args {{ return }}\n"), "tcl");
4488:             assert!(
4489:                 !r.diagnostics.iter().any(|d| d.code == DiagCode::W113),
4490:                 "W113 should be silent on overridable library proc {name:?}",
4491:             );
4492:         }
4493:         // TP control: a genuine C built-in still fires.
4494:         let r = a.analyse("proc set {} {}\n", "tcl");
4495:         assert!(
4496:             r.diagnostics.iter().any(|d| d.code == DiagCode::W113),
4497:             "W113 must still fire when redefining a C built-in (`set`)",
4498:         );
4499:     }
4500: 
4501:     #[test]
4502:     fn w307_array_set_const_element_suppression() {
4503:         // TN: `array set state {-command puts}; $state(-command) hi` — the
4504:         // literal element value `puts` is a known command, so the callback-key
4505:         // heuristic must not fire W307. Harvested from the `array set` literal.
4506:         let mut a = Analyser::new();
4507:         let has_w307 = a
4508:             .analyse(
4509:                 "proc f {} { array set state {-command puts}; $state(-command) hi }\n",
4510:                 "tcl",
4511:             )
4512:             .diagnostics
4513:             .iter()
4514:             .any(|d| d.code == DiagCode::W307);
4515:         assert!(
4516:             !has_w307,
4517:             "array-element holding a known command must not fire W307",
4518:         );
4519:         // TP control: a non-command literal value still fires W307.
4520:         let mut b = Analyser::new();
4521:         let has_w307 = b
4522:             .analyse(
4523:                 "proc f {} { array set state {-command notACommand}; $state(-command) hi }\n",
4524:                 "tcl",
4525:             )
4526:             .diagnostics
4527:             .iter()
4528:             .any(|d| d.code == DiagCode::W307);
4529:         assert!(
4530:             has_w307,
4531:             "array-element holding a non-command must still fire W307",
4532:         );
4533:     }
4534: 
4535:     /// Helper: the RBS-family diagnostic codes (W210 read-before-set, W213
4536:     /// unset-no-complain, W214 unused-param) emitted for `src`.
4537:     fn rbs_codes(src: &str) -> Vec<String> {
4538:         Analyser::new()
4539:             .analyse(src, "tcl")
4540:             .diagnostics
4541:             .iter()
4542:             .filter(|d| matches!(d.code.as_str(), "W210" | "W213" | "W214"))
4543:             .map(|d| d.code.to_string())
4544:             .collect()
4545:     }
4546: 
4547:     #[test]
4548:     fn w220_must_alias_kill_same_array_element() {
4549:         // FP-DS-06: two writes to the *same* literal-key array element with no
4550:         // intervening read of it make the first dead — the later-version read
4551:         // `$a(k)` reads the second write, not the first.  Must-alias kill
4552:         // overrides the element-observed suppression.
4553:         let mut a = Analyser::new();
4554:         assert!(
4555:             a.analyse(
4556:                 "proc f {} {\n    set a(k) 1\n    set a(k) 2\n    return $a(k)\n}",
4557:                 "tcl"
4558:             )
4559:             .diagnostics
4560:             .iter()
4561:             .any(|d| d.code == DiagCode::W220 || d.code == DiagCode::O109),
4562:             "two writes to a(k) with no intervening read: first is dead",
4563:         );
4564:         // Control: different keys are independent — no dead store.
4565:         let mut b = Analyser::new();
4566:         assert!(
4567:             !b.analyse(
4568:                 "proc f {} {\n    set a(k) 1\n    set a(j) 2\n    return $a(k)\n}",
4569:                 "tcl"
4570:             )
4571:             .diagnostics
4572:             .iter()
4573:             .any(|d| d.code == DiagCode::W220 || d.code == DiagCode::O109),
4574:             "writes to different array elements are not dead stores",
4575:         );
4576:         // Control: an intervening read of the same element cancels the kill.
4577:         let mut c = Analyser::new();
4578:         assert!(
4579:             !c.analyse(
4580:                 "proc f {} {\n    set a(k) 1\n    puts $a(k)\n    set a(k) 2\n    return $a(k)\n}",
4581:                 "tcl",
4582:             )
4583:             .diagnostics
4584:             .iter()
4585:             .any(|d| d.code == DiagCode::W220 || d.code == DiagCode::O109),
4586:             "an intervening read of a(k) keeps the first write live",
4587:         );
4588:     }
4589: 
4590:     #[test]
4591:     fn dead_store_recovers_rmw_read_in_command_sub() {
4592:         // FP-DS-01: `[incr i $j]` buried in a substitution reads `i`'s prior
4593:         // value, so the feeding `set i 0` is alive — no dead-store (W220/O109)
4594:         // or unused (W211/O126).
4595:         let mut a = Analyser::new();
4596:         let codes: Vec<_> = a
4597:             .analyse(
4598:                 "proc f {} {\n    set i 0\n    foreach j {1 2 3} { lappend r [incr i $j] }\n    return $r\n}\n",
4599:                 "tcl",
4600:             )
4601:             .diagnostics
4602:             .iter()
4603:             .filter(|d| matches!(d.code.as_str(), "W220" | "W211" | "O109" | "O126"))
4604:             .map(|d| d.code.to_string())
4605:             .collect();
4606:         assert_eq!(
4607:             codes.len(),
4608:             0,
4609:             "RMW read in cmd-sub keeps set i 0 alive: {codes:?}"
4610:         );
4611:         // TP control: no read-modify-write of `i` — the first assignment is
4612:         // truly dead, so a dead-store hint must still fire.
4613:         let mut b = Analyser::new();
4614:         assert!(
4615:             b.analyse("proc f {} { set i 0\n set i 5\n return $i }", "tcl")
4616:                 .diagnostics
4617:                 .iter()
4618:                 .any(|d| d.code == DiagCode::W220 || d.code == DiagCode::O109),
4619:             "a genuine dead store must still fire",
4620:         );
4621:     }
4622: 
4623:     #[test]
4624:     fn w210_dynamic_target_upvar_alias_read_is_silent() {
4625:         // `upvar 1 $varName local` aliases `local` to the caller
4626:         // variable named by `$varName` — the standard Tcl pass-by-reference
4627:         // idiom. Reading `$local` is not read-before-set: it errors only when
4628:         // the *caller* variable is missing, exactly the runtime condition that
4629:         // would make the *literal*-target twin (`upvar 1 caller local`) error
4630:         // too. tclsh 8.6/9.0 confirm the two forms are semantically identical,
4631:         // so the analyser treats them alike — both silent.
4632:         let codes = rbs_codes("proc foo {varName} {\n  upvar 1 $varName local\n  puts $local\n}\n");
4633:         assert!(
4634:             !codes.iter().any(|c| c == "W210"),
4635:             "dynamic-target upvar alias read must be silent: {codes:?}"
4636:         );
4637:         // The literal-target twin is silent too.
4638:         let codes = rbs_codes("proc foo {} {\n  upvar 1 caller local\n  puts $local\n}\n");
4639:         assert!(
4640:             !codes.iter().any(|c| c == "W210"),
4641:             "literal-target upvar: {codes:?}"
4642:         );
4643:         // TP control: an *unrelated* local — not the alias, never set — is not a
4644:         // scope alias, so it still fires W210.
4645:         let codes =
4646:             rbs_codes("proc foo {varName} {\n  upvar 1 $varName local\n  puts $unrelated\n}\n");
4647:         assert!(
4648:             codes.iter().any(|c| c == "W210"),
4649:             "unrelated non-alias local must still fire W210: {codes:?}"
4650:         );
4651:         // An `[info exists local]` guard suppresses the read (always did).
4652:         let codes = rbs_codes(
4653:             "proc foo {varName} {\n  upvar 1 $varName local\n  if {[info exists local]} { puts $local }\n}\n",
4654:         );
4655:         assert!(
4656:             !codes.iter().any(|c| c == "W210"),
4657:             "guarded dynamic upvar: {codes:?}"
4658:         );
4659:         // A *write* through the alias is observable (goes to the caller var),
4660:         // so it is not a dead store even with a dynamic target.
4661:         let mut a = Analyser::new();
4662:         assert!(
4663:             !a.analyse(
4664:                 "proc foo {v} {\n  upvar 1 $v local\n  set local 5\n}\n",
4665:                 "tcl"
4666:             )
4667:             .diagnostics
4668:             .iter()
4669:             .any(|d| d.code == DiagCode::W220),
4670:             "write through a dynamic upvar alias is observable, not a dead store",
4671:         );
4672:     }
4673: 
4674:     #[test]
4675:     fn w210_gets_in_while_condition_writes_loop_var() {
4676:         // FP-RBS-03: `[gets $fp line]` in the while condition writes `line`;
4677:         // the body's `$line` reads must not fire W210.
4678:         let codes = rbs_codes(
4679:             "proc f {fp} {\n  while {[gets $fp line] >= 0} {\n    set n [string length $line]\n    puts \"$line ($n chars)\"\n  }\n}\n",
4680:         );
4681:         assert_eq!(codes.len(), 0, "gets-in-condition writes line: {codes:?}");
4682:     }
4683: 
4684:     #[test]
4685:     fn w210_catch_in_expr_writes_result_var() {
4686:         // FP-RBS-06: `[catch {…} tmp]` inside `[expr {…}]` writes `tmp`; the
4687:         // same-expression `|| $tmp` read must not fire W210.
4688:         let codes = rbs_codes(
4689:             "proc f {sock} {\n  set eof [expr {[catch {eof $sock} tmp] || $tmp}]\n  return $eof\n}\n",
4690:         );
4691:         assert_eq!(codes.len(), 0, "catch-in-expr writes tmp: {codes:?}");
4692:     }
4693: 
4694:     #[test]
4695:     fn w214_namespace_eval_body_does_not_recover_caller_param() {
4696:         // FP-RBS-10: a `namespace eval ::ns {…}` body runs in the namespace
4697:         // frame, so `$x` there is NOT a read of the caller's parameter `x` —
4698:         // W214 (unused param) must still fire.  The `eval {…}` form runs in
4699:         // the caller frame, so its `$x` read DOES recover the param (no W214).
4700:         let mut a = Analyser::new();
4701:         assert!(
4702:             a.analyse(
4703:                 "proc g {x} {\n  namespace eval ::ns { puts \"hello $x\" }\n}\n",
4704:                 "tcl"
4705:             )
4706:             .diagnostics
4707:             .iter()
4708:             .any(|d| d.code == DiagCode::W214),
4709:             "namespace-eval body must not recover the caller's param read",
4710:         );
4711:         let mut b = Analyser::new();
4712:         assert!(
4713:             !b.analyse("proc f {x} {\n  eval { puts $x }\n}\n", "tcl")
4714:                 .diagnostics
4715:                 .iter()
4716:                 .any(|d| d.code == DiagCode::W214),
4717:             "eval body runs in the caller frame; $x read recovers the param",
4718:         );
4719:     }
4720: 
4721:     #[test]
4722:     fn w307_in_method_body_dispatch_fires_and_suppresses() {
4723:         // TclOO method bodies are now walked in a `Method` scope, so their
4724:         // `[cmd] method` dispatch sites are recorded for W307.
4725:         // TP: `[format notACommand] run` returns a string, not an object.
4726:         let mut a = Analyser::new();
4727:         let fires = a
4728:             .analyse(
4729:                 "oo::class create C { method m {} { [format notACommand] run } }",
4730:                 "tcl",
4731:             )
4732:             .diagnostics
4733:             .iter()
4734:             .any(|d| d.code == DiagCode::W307);
4735:         assert!(fires, "in-method [format ...] dispatch must fire W307");
4736: 
4737:         // Control: `[D new] run` where D is a known class returns an Object —
4738:         // suppressed (and `run` resolves on D, so no W308 either).
4739:         let mut b = Analyser::new();
4740:         let fires = b
4741:             .analyse(
4742:                 "oo::class create D { method run {} { return ok } }\n\
4743:                  oo::class create C { method m {} { [D new] run } }\n",
4744:                 "tcl",
4745:             )
4746:             .diagnostics
4747:             .iter()
4748:             .any(|d| d.code == DiagCode::W307);
4749:         assert!(
4750:             !fires,
4751:             "in-method [D new] dispatch on known class must not fire W307"
4752:         );
4753:     }
4754: 
4755:     #[test]
4756:     fn w307_my_method_literal_vs_object_return() {
4757:         // TP: `[my plain] run` where `plain` returns a literal — the return is
4758:         // a plain string, so the outer dispatch fires W307.
4759:         let mut a = Analyser::new();
4760:         let fires = a
4761:             .analyse(
4762:                 "oo::class create C { method plain {} { return notACommand }\n\
4763:                  method m {} { [my plain] run } }",
4764:                 "tcl",
4765:             )
4766:             .diagnostics
4767:             .iter()
4768:             .any(|d| d.code == DiagCode::W307);
4769:         assert!(fires, "[my plain] returning a literal must fire W307");
4770: 
4771:         // Control: `[my obj] run` where `obj` returns `[D new]` — object
4772:         // handle, suppressed.
4773:         let mut b = Analyser::new();
4774:         let fires = b
4775:             .analyse(
4776:                 "oo::class create D { method run {} { return ok } }\n\
4777:                  oo::class create C { method obj {} { return [D new] }\n\
4778:                  method m {} { [my obj] run } }",
4779:                 "tcl",
4780:             )
4781:             .diagnostics
4782:             .iter()
4783:             .any(|d| d.code == DiagCode::W307);
4784:         assert!(!fires, "[my obj] returning an object must not fire W307");
4785:     }
4786: 
4787:     #[test]
4788:     fn method_body_params_and_instance_vars_not_flagged() {
4789:         // Walking method bodies must not false-fire read-before-set / unused
4790:         // on the method's formal parameters or the class's instance variables.
4791:         let mut a = Analyser::new();
4792:         let r = a.analyse(
4793:             "oo::class create C {\n\
4794:              variable count\n\
4795:              method add {n} { incr count $n; return $count }\n\
4796:              }\n",
4797:             "tcl",
4798:         );
4799:         let offenders: Vec<_> = r
4800:             .diagnostics
4801:             .iter()
4802:             .filter(|d| matches!(d.code.as_str(), "W210" | "W214"))
4803:             .map(|d| d.code.to_string())
4804:             .collect();
4805:         assert_eq!(
4806:             offenders.len(),
4807:             0,
4808:             "method params / instance vars must not fire W210/W214: {offenders:?}",
4809:         );
4810:     }
4811: 
4812:     #[test]
4813:     fn w307_namespaced_ensemble_composed_name_resolution() {
4814:         // TN: `${ns}::dowork` where `ns` is the const `mypkg` and
4815:         // `::mypkg::dowork` is a known proc — the composed name resolves, so
4816:         // no W307.
4817:         let mut a = Analyser::new();
4818:         let has = a
4819:             .analyse(
4820:                 "namespace eval ::mypkg { proc dowork {arg} {} }\n\
4821:                  proc f {} { set ns mypkg; ${ns}::dowork arg }\n",
4822:                 "tcl",
4823:             )
4824:             .diagnostics
4825:             .iter()
4826:             .any(|d| d.code == DiagCode::W307);
4827:         assert!(!has, "resolvable namespaced ensemble must not fire W307");
4828:         // TP control: composed name with no known proc still fires.
4829:         let mut b = Analyser::new();
4830:         let has = b
4831:             .analyse(
4832:                 "proc f {} { set ns mypkg; ${ns}::unknownproc arg }\n",
4833:                 "tcl",
4834:             )
4835:             .diagnostics
4836:             .iter()
4837:             .any(|d| d.code == DiagCode::W307);
4838:         assert!(
4839:             has,
4840:             "unresolvable composed namespaced ensemble must fire W307"
4841:         );
4842:     }
4843: 
4844:     #[test]
4845:     fn w307_interproc_dict_with_const_element_suppression() {
4846:         // TN: `dict with d { $cmd hi }` where the caller passes `{cmd puts}` —
4847:         // the dict-with unpacks `cmd` to the known command `puts`, so the
4848:         // body's `$cmd hi` dispatch must not fire W307.  The literal is
4849:         // harvested from `d`'s call-site-propagated v0 SCCP const.
4850:         let mut a = Analyser::new();
4851:         let has_w307 = a
4852:             .analyse(
4853:                 "proc f {d} { dict with d { $cmd hi } }\nf {cmd puts}\n",
4854:                 "tcl",
4855:             )
4856:             .diagnostics
4857:             .iter()
4858:             .any(|d| d.code == DiagCode::W307);
4859:         assert!(
4860:             !has_w307,
4861:             "dict-with-unpacked known command must not fire W307"
4862:         );
4863:         // TP control: a non-command unpacked value still fires.
4864:         let mut b = Analyser::new();
4865:         let has_w307 = b
4866:             .analyse(
4867:                 "proc f {d} { dict with d { $cmd hi } }\nf {cmd notACommand}\n",
4868:                 "tcl",
4869:             )
4870:             .diagnostics
4871:             .iter()
4872:             .any(|d| d.code == DiagCode::W307);
4873:         assert!(
4874:             has_w307,
4875:             "dict-with-unpacked non-command must still fire W307"
4876:         );
4877:     }
4878: 
4879:     #[test]
4880:     fn w307_known_class_new_var_suppression() {
4881:         // TN: `set x [C new]; $x run` where C is a known oo::class — `x` holds
4882:         // an Object of class C, so the `$x run` dispatch resolves through the
4883:         // method check (run exists on C) instead of firing W307.
4884:         let mut a = Analyser::new();
4885:         let r = a.analyse(
4886:             "oo::class create C { method run {} { return ok } }\n\
4887:              proc f {} { set x [C new]; $x run }\n",
4888:             "tcl",
4889:         );
4890:         assert!(
4891:             !r.diagnostics.iter().any(|d| d.code == DiagCode::W307),
4892:             "var assigned from a known-class constructor must not fire W307: {:?}",
4893:             r.diagnostics,
4894:         );
4895:     }
4896: 
4897:     #[test]
4898:     fn w216_brace_then_paren_name_vs_value_positions() {
4899:         // FP-STY-12: the braced indirect-array idiom `${name}(idx)` in a
4900:         // *variable-name* position (`set`/`unset`/`incr`/`append`/`lappend`/
4901:         // `vwait`/`info exists`) is the legitimate "array name held in a
4902:         // scalar" access — neither W216 nor W212 fires.
4903:         let mut a = Analyser::new();
4904:         for src in [
4905:             "set token ::http::1\nset ${token}(status) eof\n",
4906:             "info exists ${token}(-pipeline)\n",
4907:             "unset ${tok}(socketcoro)\n",
4908:             "vwait ${token}(status)\n",
4909:             "incr ${arr}(n)\n",
4910:             "append ${arr}(buf) x\n",
4911:             "lappend ${arr}(list) item\n",
4912:         ] {
4913:             let r = a.analyse(src, "tcl");
4914:             assert!(
4915:                 !r.diagnostics
4916:                     .iter()
4917:                     .any(|d| d.code == DiagCode::W216 || d.code == DiagCode::W212),
4918:                 "indirect-array idiom must not fire W216/W212: {src:?} -> {:?}",
4919:                 r.diagnostics,
4920:             );
4921:         }
4922:         // TP control: in a *value* position `${arr}(x)` is a broken read for
4923:         // `$arr(x)` — W216 still fires.
4924:         for src in ["puts ${arr}(x)\n", "set y ${arr}(x)\n"] {
4925:             let r = a.analyse(src, "tcl");
4926:             assert!(
4927:                 r.diagnostics.iter().any(|d| d.code == DiagCode::W216),
4928:                 "value-position ${{arr}}(x) must fire W216: {src:?} -> {:?}",
4929:                 r.diagnostics,
4930:             );
4931:         }
4932:         // TP control: bare `set $x` / `set ${x}` (no `(idx)` suffix) is the
4933:         // dynamic-name foot-gun, not the indirect idiom — W212 still fires.
4934:         for src in ["set $x v\n", "set ${x} v\n"] {
4935:             let r = a.analyse(src, "tcl");
4936:             assert!(
4937:                 r.diagnostics.iter().any(|d| d.code == DiagCode::W212),
4938:                 "bare dynamic-name must still fire W212: {src:?} -> {:?}",
4939:                 r.diagnostics,
4940:             );
4941:         }
4942:     }
4943: 
4944:     #[test]
4945:     fn analyse_dedupes_back_to_back_identical_diagnostics() {
4946:         // Two identical W113 emissions for the same proc name
4947:         // should collapse to one.
4948:         let mut a = Analyser::new();
4949:         let r = a.analyse("proc set {} {}\nproc set {} {}\n", "tcl");
4950:         // Re-defining ``set`` twice means handle_proc emits W113
4951:         // twice — but the second emission is at a *different*
4952:         // span (different proc-name token), so dedupe leaves
4953:         // them both; the test that follows pins the actual count.
4954:         let w113s: Vec<_> = r
4955:             .diagnostics
4956:             .iter()
4957:             .filter(|d| d.code == DiagCode::W113)
4958:             .collect();
4959:         assert_eq!(
4960:             w113s.len(),
4961:             2,
4962:             "two distinct ``proc set`` definitions → two distinct W113s at different spans",
4963:         );
4964:     }
4965: 
4966:     #[test]
4967:     fn analyse_records_source_text_for_handler_re_slicing() {
4968:         // Handlers re-slice ``self.source`` via spans returned by the
4969:         // segmenter; the field must be populated at the top of
4970:         // ``analyse``.
4971:         let mut a = Analyser::new();
4972:         let _ = a.analyse("set x 1", "tcl");
4973:         assert_eq!(a.source, "set x 1");
4974:     }
4975: 
4976:     #[test]
4977:     fn analyse_records_dialect_for_w113_and_emitter_use() {
4978:         // Handlers (W113 shadow check, dialect-only emitters) read
4979:         // ``self.dialect()`` directly.  The field must be populated at
4980:         // the top of ``analyse``.
4981:         let mut a = Analyser::new();
4982:         let _ = a.analyse("", "f5-irules");
4983:         assert_eq!(a.dialect(), "f5-irules");
4984:         assert!(a.profile.is_irules());
4985:     }
4986: 
4987:     #[test]
4988:     fn builtin_command_names_caches_per_dialect() {
4989:         // First lookup populates the cache; subsequent lookups
4990:         // with the same dialect return the same set.
4991:         let mut a = Analyser::new();
4992:         a.profile = tcl_dialect::DialectProfile::plain_tcl();
4993:         // ``set`` is a core built-in across all dialects.
4994:         assert!(a.builtin_command_names().contains("set"));
4995:         // The set is the one `exists` oracle's registry tier — the names the
4996:         // resolved context actually provides, not the unfiltered store name
4997:         // set. Cache
4998:         // invalidation: switching dialect rebuilds onto the new context.
4999:         a.profile = tcl_dialect::DialectProfile::irules();
5000:         assert!(
5001:             a.builtin_command_names().contains("HTTP::header"),
5002:             "the iRules surface is provided under f5-irules"
5003:         );
5004:         assert!(
5005:             !a.builtin_command_names().contains("exec"),
5006:             "a compiler-disabled, interpreter-absent core command does not \
5007:              exist under the closed iRules world (R-c; pre-P1a the unfiltered \
5008:              store set believed in it)"
5009:         );
5010:         assert!(
5011:             a.builtin_command_names().contains("vwait"),
5012:             "a §4b interpreter-present (compiler-refused) builtin still exists \
5013:              for the oracle"
5014:         );
5015:     }
5016: 
5017:     #[test]
5018:     fn analyse_commands_pre_segmented_records_proc() {
5019:         // ``analyse_commands`` is the incremental entry — same
5020:         // dispatcher as ``analyse``, but without re-segmentation.
5021:         // Smoke-test that a pre-segmented chunk records its proc.
5022:         use crate::segmenter::segment_commands;
5023:         let source = "proc foo {} {}";
5024:         let commands = segment_commands(source);
5025:         let mut a = Analyser::new();
5026:         let r = a.analyse_commands(source, &commands, "tcl", true);
5027:         assert!(r.all_procs.contains_key("::foo"));
5028:     }
5029: 
5030:     #[test]
5031:     fn analyse_commands_fires_stray_close_bracket() {
5032:         // The incremental / chunked path runs the E100 stray-`]`
5033:         // check too, matching `analyse`.
5034:         use crate::segmenter::segment_commands;
5035:         let source = "puts foo]";
5036:         let commands = segment_commands(source);
5037:         let mut a = Analyser::new();
5038:         let r = a.analyse_commands(source, &commands, "tcl", true);
5039:         assert_eq!(
5040:             r.diagnostics
5041:                 .iter()
5042:                 .filter(|d| d.code == DiagCode::E100)
5043:                 .count(),
5044:             1,
5045:             "expected one E100; got {:?}",
5046:             r.diagnostics
5047:                 .iter()
5048:                 .map(|d| d.code.to_string())
5049:                 .collect::<Vec<_>>(),
5050:         );
5051:     }
5052: 
5053:     #[test]
5054:     fn analyse_chunked_returns_per_chunk_snapshots() {
5055:         // ``analyse_chunked`` returns one snapshot per chunk.
5056:         // Two chunks → two snapshots; the second snapshot
5057:         // captures cumulative state.
5058:         use crate::segmenter::segment_commands;
5059:         let source = "set x 1\nproc foo {} {}";
5060:         let chunk1 = segment_commands("set x 1");
5061:         let chunk2 = segment_commands("proc foo {} {}");
5062:         let mut a = Analyser::new();
5063:         let (r, snapshots) = a.analyse_chunked(source, vec![chunk1, chunk2], "tcl");
5064:         assert_eq!(snapshots.len(), 2);
5065:         // After chunk 1, x is in scope.
5066:         assert!(snapshots[0].result.global_scope.variables.contains_key("x"));
5067:         // After chunk 2, foo is in all_procs.
5068:         assert!(snapshots[1].result.all_procs.contains_key("::foo"));
5069:         // The final result has both.
5070:         assert!(r.global_scope.variables.contains_key("x"));
5071:         assert!(r.all_procs.contains_key("::foo"));
5072:     }
5073: 
5074:     #[test]
5075:     fn analyse_commands_finalise_false_skips_diagnostic_tail() {
5076:         // When ``finalise=false``, the dedupe/disabled-codes
5077:         // filters don't run — useful for partial-snapshot paths
5078:         // where the tail is deferred.
5079:         use crate::segmenter::segment_commands;
5080:         let source = "proc set {} {}"; // would normally trip W113
5081:         let commands = segment_commands(source);
5082:         let mut a = Analyser::new();
5083:         a.profile = tcl_registry::model::ingress::resolve_environment("tcl").analyser_profile();
5084:         let r = a.analyse_commands(source, &commands, "tcl", false);
5085:         // W113 was emitted by handle_proc but the tail didn't
5086:         // run, so apply_disabled_diagnostics / dedupe didn't
5087:         // touch the diag list.  The diag is still there.
5088:         assert!(r.diagnostics.iter().any(|d| d.code == DiagCode::W113));
5089:     }
5090: 
5091:     #[test]
5092:     fn default_constructs_via_new() {
5093:         let a = Analyser::default();
5094:         assert_eq!(a.current_scope_path.len(), 0);
5095:         assert_eq!(a.body_depth, 0);
5096:     }
5097: 
5098:     // -- tcllib `<NS>::import <ALIAS>` wrapper detection
5099: 
5100:     #[test]
5101:     fn analyse_records_tcllib_import_wrapper_as_conjectured() {
5102:         let mut a = Analyser::new();
5103:         let r = a.analyse("term::ansi::send::import vt\n", "tcl");
5104:         let conjectured: Vec<_> = r
5105:             .namespace_imports
5106:             .iter()
5107:             .filter(|i| i.conjectured)
5108:             .collect();
5109:         assert_eq!(conjectured.len(), 1);
5110:         assert_eq!(conjectured[0].ns, "::vt");
5111:         assert_eq!(conjectured[0].pattern, "::term::ansi::send::*");
5112:     }
5113: 
5114:     #[test]
5115:     fn analyse_tcllib_import_wrapper_alias_relative_to_current_namespace() {
5116:         // ``some::ns::import alias`` inside ``namespace eval outer``
5117:         // creates ``::outer::alias``, not ``::alias``.
5118:         let mut a = Analyser::new();
5119:         let r = a.analyse(
5120:             "namespace eval outer { term::ansi::send::import vt }\n",
5121:             "tcl",
5122:         );
5123:         let conjectured: Vec<_> = r
5124:             .namespace_imports
5125:             .iter()
5126:             .filter(|i| i.conjectured)
5127:             .collect();
5128:         assert_eq!(conjectured.len(), 1);
5129:         assert_eq!(conjectured[0].ns, "::outer::vt");
5130:         assert_eq!(conjectured[0].pattern, "::term::ansi::send::*");
5131:     }
5132: 
5133:     #[test]
5134:     fn analyse_tcllib_import_wrapper_absolute_alias_keeps_leading_colons() {
5135:         // ``::alias`` argument is taken as an absolute namespace —
5136:         // current-namespace prefixing is skipped.
5137:         let mut a = Analyser::new();
5138:         let r = a.analyse("term::ansi::send::import ::abs::vt\n", "tcl");
5139:         let conjectured: Vec<_> = r
5140:             .namespace_imports
5141:             .iter()
5142:             .filter(|i| i.conjectured)
5143:             .collect();
5144:         assert_eq!(conjectured.len(), 1);
5145:         assert_eq!(conjectured[0].ns, "::abs::vt");
5146:     }
5147: 
5148:     #[test]
5149:     fn analyse_tcllib_import_wrapper_skips_substituted_alias() {
5150:         // ``$var`` / ``[cmd]`` aliases can't be statically resolved —
5151:         // the guard requires the alias to contain no ``$`` or ``[``.
5152:         let mut a = Analyser::new();
5153:         let r1 = a.analyse("term::ansi::send::import $alias\n", "tcl");
5154:         assert!(r1.namespace_imports.iter().all(|i| !i.conjectured));
5155:         let mut a = Analyser::new();
5156:         let r2 = a.analyse("term::ansi::send::import [build]\n", "tcl");
5157:         assert!(r2.namespace_imports.iter().all(|i| !i.conjectured));
5158:     }
5159: 
5160:     #[test]
5161:     fn analyse_tcllib_import_wrapper_requires_single_argument() {
5162:         // ``X::import alias extras`` is a non-wrapper call — the
5163:         // wrapper idiom takes exactly one alias word.
5164:         let mut a = Analyser::new();
5165:         let r = a.analyse("term::ansi::send::import vt extra\n", "tcl");
5166:         assert!(r.namespace_imports.iter().all(|i| !i.conjectured));
5167:     }
5168: 
5169:     #[test]
5170:     fn analyse_tcllib_import_wrapper_qualifies_unprefixed_source_ns() {
5171:         // Wrapper command names without a leading ``::`` still
5172:         // resolve to absolute source namespaces — the helper
5173:         // prepends the missing ``::``.
5174:         let mut a = Analyser::new();
5175:         let r = a.analyse("foo::import vt\n", "tcl");
5176:         let conjectured: Vec<_> = r
5177:             .namespace_imports
5178:             .iter()
5179:             .filter(|i| i.conjectured)
5180:             .collect();
5181:         assert_eq!(conjectured.len(), 1);
5182:         assert_eq!(conjectured[0].pattern, "::foo::*");
5183:     }
5184: 
5185:     // -- ``command_aliases`` tests
5186:     //
5187:     // Pin the no-transitive-chain behaviour of command aliases.
5188: 
5189:     #[test]
5190:     fn analyse_alias_chain_records_each_step_independently() {
5191:         // ``a -> b`` and ``b -> expr`` are recorded as two
5192:         // independent entries — neither side resolves
5193:         // transitively to ``expr``.
5194:         let mut a = Analyser::new();
5195:         let r = a.analyse("interp alias {} a {} b\ninterp alias {} b {} expr\n", "tcl");
5196:         let alias_a = r.command_aliases.get("::a").expect("::a recorded");
5197:         assert_eq!(alias_a.target, "b");
5198:         assert_eq!(alias_a.extras, [] as [std::string::String; 0]);
5199:         let alias_b = r.command_aliases.get("::b").expect("::b recorded");
5200:         assert_eq!(alias_b.target, "expr");
5201:         assert_eq!(alias_b.extras, [] as [std::string::String; 0]);
5202:     }
5203: 
5204:     #[test]
5205:     fn analyse_alias_redefinition_overwrites_target() {
5206:         // The second declaration wins.
5207:         let mut a = Analyser::new();
5208:         let r = a.analyse(
5209:             "interp alias {} myop {} expr\ninterp alias {} myop {} puts\n",
5210:             "tcl",
5211:         );
5212:         let alias = r.command_aliases.get("::myop").expect("::myop recorded");
5213:         assert_eq!(alias.target, "puts");
5214:         assert_eq!(alias.extras, [] as [std::string::String; 0]);
5215:     }
5216: 
5217:     #[test]
5218:     fn analyse_alias_qualified_name_recorded() {
5219:         // ``interp alias {} ::ns::myop {} expr`` records under the
5220:         // fully-qualified key.
5221:         let mut a = Analyser::new();
5222:         let r = a.analyse("interp alias {} ::math::= {} expr\n", "tcl");
5223:         let alias = r
5224:             .command_aliases
5225:             .get("::math::=")
5226:             .expect("::math::= recorded");
5227:         assert_eq!(alias.target, "expr");
5228:     }
5229: 
5230:     #[test]
5231:     fn analyse_alias_dynamic_name_not_recorded() {
5232:         // ``$n`` in the alias name field doesn't resolve statically
5233:         // — ``::=`` must not appear in ``command_aliases``.
5234:         let mut a = Analyser::new();
5235:         let r = a.analyse("set n \"=\"\ninterp alias {} $n {} expr\n", "tcl");
5236:         assert!(!r.command_aliases.contains_key("::="));
5237:     }
5238: 
5239:     // -- ``switch -regexp`` literal-pattern recording
5240:     //
5241:     // The pattern arms whose token is a literal are recorded as
5242:     // ``RegexPattern { command = "switch" }``; ``default`` and
5243:     // var / cmd-sub patterns are skipped (variable patterns are
5244:     // handled by the regex-vars resolution instead).
5245: 
5246:     #[test]
5247:     fn analyse_switch_regexp_form1_records_literal_patterns() {
5248:         // Form 1: pattern/body pairs inline.
5249:         let mut a = Analyser::new();
5250:         let r = a.analyse(
5251:             "switch -regexp -- $val \"^foo\" { puts foo } \"^bar\" { puts bar }\n",
5252:             "tcl",
5253:         );
5254:         let switch_pats: Vec<_> = r
5255:             .regex_patterns
5256:             .iter()
5257:             .filter(|p| p.command == "switch")
5258:             .collect();
5259:         assert_eq!(switch_pats.len(), 2);
5260:         assert_eq!(switch_pats[0].pattern, "^foo");
5261:         assert_eq!(switch_pats[1].pattern, "^bar");
5262:     }
5263: 
5264:     #[test]
5265:     fn analyse_switch_regexp_form2_records_literal_patterns() {
5266:         // Form 2: braced body with pattern/body pairs.
5267:         let mut a = Analyser::new();
5268:         let r = a.analyse(
5269:             "switch -regexp -- $val { ^foo { puts foo } ^bar { puts bar } }\n",
5270:             "tcl",
5271:         );
5272:         let switch_pats: Vec<_> = r
5273:             .regex_patterns
5274:             .iter()
5275:             .filter(|p| p.command == "switch")
5276:             .collect();
5277:         assert_eq!(switch_pats.len(), 2);
5278:         assert_eq!(switch_pats[0].pattern, "^foo");
5279:         assert_eq!(switch_pats[1].pattern, "^bar");
5280:     }
5281: 
5282:     #[test]
5283:     fn analyse_braced_expect_clause_regexp_records_literal_and_const_var_patterns() {
5284:         let mut a = Analyser::new();
5285:         let r = a.analyse(
5286:             "set pat {(a+)+$}\nexpect {-regexp {^lit$} { puts lit } -re $pat { puts var }}\n",
5287:             "expect",
5288:         );
5289:         let patterns: Vec<_> = r
5290:             .regex_patterns
5291:             .iter()
5292:             .filter(|p| p.command == "expect")
5293:             .collect();
5294:         assert!(
5295:             patterns.iter().any(|pattern| pattern.pattern == "^lit$"),
5296:             "literal per-clause regexp missing: {patterns:?}"
5297:         );
5298:         assert!(
5299:             patterns.iter().any(|pattern| pattern.pattern == "(a+)+$"),
5300:             "const variable per-clause regexp missing: {patterns:?}"
5301:         );
5302:     }
5303: 
5304:     #[test]
5305:     fn analyse_switch_regexp_skips_default_arm() {
5306:         let mut a = Analyser::new();
5307:         let r = a.analyse(
5308:             "switch -regexp -- $val { ^foo { puts foo } default { puts none } }\n",
5309:             "tcl",
5310:         );
5311:         let switch_pats: Vec<_> = r
5312:             .regex_patterns
5313:             .iter()
5314:             .filter(|p| p.command == "switch")
5315:             .collect();
5316:         assert_eq!(switch_pats.len(), 1);
5317:         assert_eq!(switch_pats[0].pattern, "^foo");
5318:     }
5319: 
5320:     #[test]
5321:     fn analyse_switch_without_regexp_records_nothing() {
5322:         // No ``-regexp`` flag — patterns are glob, not regex.
5323:         let mut a = Analyser::new();
5324:         let r = a.analyse(
5325:             "switch -- $val { foo { puts foo } bar { puts bar } }\n",
5326:             "tcl",
5327:         );
5328:         let switch_pats: Vec<_> = r
5329:             .regex_patterns
5330:             .iter()
5331:             .filter(|p| p.command == "switch")
5332:             .collect();
5333:         assert_eq!(
5334:             switch_pats,
5335:             [] as [&crate::analyser::types::RegexPattern; 0]
5336:         );
5337:     }
5338: 
5339:     #[test]
5340:     fn analyse_switch_regexp_skips_unresolved_var_pattern() {
5341:         // ``$pat`` arm with no defining ``set`` — no const value
5342:         // available, so the arm is dropped.
5343:         let mut a = Analyser::new();
5344:         let r = a.analyse(
5345:             "switch -regexp -- $val { $pat { puts hit } ^lit { puts lit } }\n",
5346:             "tcl",
5347:         );
5348:         let switch_pats: Vec<_> = r
5349:             .regex_patterns
5350:             .iter()
5351:             .filter(|p| p.command == "switch")
5352:             .collect();
5353:         assert_eq!(switch_pats.len(), 1);
5354:         assert_eq!(switch_pats[0].pattern, "^lit");
5355:     }
5356: 
5357:     // -- ``regex-vars`` const-string propagation
5358:     //
5359:     // Verify that ``$var`` regex pattern arguments resolve to the
5360:     // literal stored by a preceding ``set var "..."`` (regexp /
5361:     // regsub and switch -regexp Form 2).
5362: 
5363:     #[test]
5364:     fn analyse_regexp_resolves_var_pattern_to_const_string() {
5365:         let mut a = Analyser::new();
5366:         let r = a.analyse("set p {^foo}\nregexp $p $line\n", "tcl");
5367:         // Two records: the use site (the ``$p`` token) and the
5368:         // defining ``set`` value.
5369:         let regexp_pats: Vec<_> = r
5370:             .regex_patterns
5371:             .iter()
5372:             .filter(|p| p.command == "regexp")
5373:             .collect();
5374:         assert_eq!(regexp_pats.len(), 2);
5375:         assert!(regexp_pats.iter().all(|p| p.pattern == "^foo"));
5376:     }
5377: 
5378:     #[test]
5379:     fn analyse_regsub_resolves_var_pattern_to_const_string() {
5380:         let mut a = Analyser::new();
5381:         let r = a.analyse("set p {a+}\nregsub -all $p $line - out\n", "tcl");
5382:         let regsub_pats: Vec<_> = r
5383:             .regex_patterns
5384:             .iter()
5385:             .filter(|p| p.command == "regsub")
5386:             .collect();
5387:         assert_eq!(regsub_pats.len(), 2);
5388:         assert!(regsub_pats.iter().all(|p| p.pattern == "a+"));
5389:     }
5390: 
5391:     #[test]
5392:     fn analyse_switch_regexp_resolves_var_pattern_to_const_string() {
5393:         let mut a = Analyser::new();
5394:         let r = a.analyse(
5395:             "set p {^foo}\nswitch -regexp -- $val { $p { puts foo } ^bar { puts bar } }\n",
5396:             "tcl",
5397:         );
5398:         let switch_pats: Vec<_> = r
5399:             .regex_patterns
5400:             .iter()
5401:             .filter(|p| p.command == "switch")
5402:             .collect();
5403:         let pats: Vec<&str> = switch_pats.iter().map(|p| p.pattern.as_str()).collect();
5404:         assert!(pats.contains(&"^foo"), "got {pats:?}");
5405:         assert!(pats.contains(&"^bar"), "got {pats:?}");
5406:     }
5407: 
5408:     #[test]
5409:     fn analyse_regex_var_unresolved_records_nothing() {
5410:         // No defining ``set`` — Var has no const value.  The
5411:         // pattern arg is dropped.
5412:         let mut a = Analyser::new();
5413:         let r = a.analyse("regexp $p $line\n", "tcl");
5414:         assert_eq!(
5415:             r.regex_patterns,
5416:             [] as [crate::analyser::types::RegexPattern; 0]
5417:         );
5418:     }
5419: 
5420:     // -- W105 unbraced-body emitter
5421: 
5422:     #[test]
5423:     fn analyse_emits_w105_for_unbraced_if_body_with_substitution() {
5424:         let mut a = Analyser::new();
5425:         let r = a.analyse("if {$cond} \"puts $x\"\n", "tcl");
5426:         let w105: Vec<_> = r
5427:             .diagnostics
5428:             .iter()
5429:             .filter(|d| d.code == DiagCode::W105)
5430:             .collect();
5431:         assert!(!w105.is_empty(), "expected W105, got {:?}", r.diagnostics);
5432:         // Substitution-bearing bodies are flagged at error severity.
5433:         assert!(matches!(w105[0].severity, crate::analyser::Severity::Error));
5434:     }
5435: 
5436:     #[test]
5437:     fn analyse_skips_w105_for_braced_if_body() {
5438:         // Braced ``{ ... }`` body — no W105.
5439:         let mut a = Analyser::new();
5440:         let r = a.analyse("if {$cond} { puts $x }\n", "tcl");
5441:         assert!(!r.diagnostics.iter().any(|d| d.code == DiagCode::W105));
5442:     }
5443: 
5444:     #[test]
5445:     fn analyse_skips_w105_for_command_substitution_body() {
5446:         // A whole-word `[…]` command-substitution body is the safe
5447:         // list-building idiom — `check_unbraced_body` exempts `Cmd`
5448:         // tokens, so no W105.
5449:         let mut a = Analyser::new();
5450:         let r = a.analyse("eval [list set y $x]\n", "tcl");
5451:         assert!(
5452:             !r.diagnostics.iter().any(|d| d.code == DiagCode::W105),
5453:             "{:?}",
5454:             r.diagnostics
5455:         );
5456:     }
5457: 
5458:     #[test]
5459:     fn analyse_skips_w105_for_single_var_body() {
5460:         // FP-STY-14: a body that is a *single bare variable* (`$body`,
5461:         // `$cmd`, `$script`) is a script-valued reference — the variable
5462:         // already holds the script — not an inline code block.  Bracing it
5463:         // (`{$body}`) would turn the reference into the literal text, so the
5464:         // W105 quick-fix is wrong and must not fire: `while {$cond} $body`
5465:         // → no W105, as for `eval $cmd`, `proc $n $a $body`, `uplevel $script`.
5466:         let mut a = Analyser::new();
5467:         for src in [
5468:             "while {$cond} $body\n",
5469:             "eval $cmd\n",
5470:             "after 0 $coroName\n",
5471:             "proc $fakeName $arglist $body\n",
5472:             "foreach name $nameList $body\n",
5473:             "uplevel $script\n",
5474:         ] {
5475:             let r = a.analyse(src, "tcl");
5476:             assert!(
5477:                 !r.diagnostics.iter().any(|d| d.code == DiagCode::W105),
5478:                 "W105 should be silent on single-var body {src:?}, got {:?}",
5479:                 r.diagnostics,
5480:             );
5481:         }
5482:     }
5483: 
5484:     #[test]
5485:     fn analyse_emits_w105_for_quoted_interpolated_body() {
5486:         // TP control: a *quoted* body with interpolation (`eval "do $script"`)
5487:         // really is an inline script woven from substitutions — it can and
5488:         // should be braced, so W105 still fires at ERROR severity.
5489:         let mut a = Analyser::new();
5490:         let r = a.analyse("eval \"do $script\"\n", "tcl");
5491:         let w105: Vec<_> = r
5492:             .diagnostics
5493:             .iter()
5494:             .filter(|d| d.code == DiagCode::W105)
5495:             .collect();
5496:         assert!(!w105.is_empty(), "expected W105, got {:?}", r.diagnostics);
5497:         assert!(matches!(w105[0].severity, crate::analyser::Severity::Error));
5498:     }
5499: 
5500:     // -- W110 string-compare-in-expr emitter
5501: 
5502:     #[test]
5503:     fn analyse_emits_w110_for_string_eq_in_if_condition() {
5504:         let mut a = Analyser::new();
5505:         let r = a.analyse("if {$x == \"foo\"} {puts yes}\n", "tcl");
5506:         let w110: Vec<_> = r
5507:             .diagnostics
5508:             .iter()
5509:             .filter(|d| d.code == DiagCode::W110)
5510:             .collect();
5511:         assert_eq!(w110.len(), 1, "got {:?}", r.diagnostics);
5512:         assert!(w110[0].message.contains("eq"), "got {:?}", w110[0].message);
5513:         assert!(matches!(w110[0].severity, crate::analyser::Severity::Hint));
5514:     }
5515: 
5516:     #[test]
5517:     fn analyse_emits_w110_for_string_ne_in_if_condition() {
5518:         let mut a = Analyser::new();
5519:         let r = a.analyse("if {$x != \"bar\"} {puts no}\n", "tcl");
5520:         let w110: Vec<_> = r
5521:             .diagnostics
5522:             .iter()
5523:             .filter(|d| d.code == DiagCode::W110)
5524:             .collect();
5525:         assert_eq!(w110.len(), 1, "got {:?}", r.diagnostics);
5526:         assert!(w110[0].message.contains("ne"), "got {:?}", w110[0].message);
5527:     }
5528: 
5529:     #[test]
5530:     fn w110_span_anchors_on_the_operator() {
5531:         // Range precision: the diagnostic anchors on the `==` itself, not
5532:         // the whole condition.
5533:         let src = "if {$x == \"foo\"} {puts yes}\n";
5534:         let mut a = Analyser::new();
5535:         let r = a.analyse(src, "tcl");
5536:         let w110: Vec<_> = r
5537:             .diagnostics
5538:             .iter()
5539:             .filter(|d| d.code == DiagCode::W110)
5540:             .collect();
5541:         assert_eq!(w110.len(), 1, "got {:?}", r.diagnostics);
5542:         let expected = src.find("==").unwrap();
5543:         assert_eq!(
5544:             (w110[0].span.start() as usize, w110[0].span.end() as usize),
5545:             (expected, expected + 2),
5546:             "W110 must cover exactly the operator, got {:?}",
5547:             w110[0].span
5548:         );
5549:         // The fix rewrites the operator in place and leaves the braces and
5550:         // operands as written.
5551:         assert_eq!(w110[0].fixes.len(), 1, "fix expected: {:?}", w110[0]);
5552:         let fix = &w110[0].fixes[0];
5553:         assert_eq!(
5554:             fix.span, w110[0].span,
5555:             "the fix covers exactly the operator"
5556:         );
5557:         assert_eq!(fix.new_text, "eq");
5558:     }
5559: 
5560:     #[test]
5561:     fn w110_span_anchors_on_the_matched_operator_not_the_first() {
5562:         // `$a == $b` (variable compare — not flagged) precedes the
5563:         // string compare `$c == "x"`; the anchor must be the SECOND `==`.
5564:         let src = "if {$a == $b && $c == \"x\"} {puts yes}\n";
5565:         let mut a = Analyser::new();
5566:         let r = a.analyse(src, "tcl");
5567:         let w110: Vec<_> = r
5568:             .diagnostics
5569:             .iter()
5570:             .filter(|d| d.code == DiagCode::W110)
5571:             .collect();
5572:         assert_eq!(w110.len(), 1, "got {:?}", r.diagnostics);
5573:         let expected = src.rfind("==").unwrap();
5574:         assert_eq!(
5575:             (w110[0].span.start() as usize, w110[0].span.end() as usize),
5576:             (expected, expected + 2),
5577:             "W110 must anchor the matched (second) `==`, got {:?}",
5578:             w110[0].span
5579:         );
5580:         // The fix rewrites only the proven operator; the variable compare,
5581:         // which may be numeric, keeps its `==`.
5582:         assert_eq!(w110[0].fixes.len(), 1, "fix expected: {:?}", w110[0]);
5583:         let fix = &w110[0].fixes[0];
5584:         let (s, e) = (fix.span.start() as usize, fix.span.end() as usize);
5585:         let applied = format!("{}{}{}", &src[..s], fix.new_text, &src[e..]);
5586:         assert_eq!(applied, "if {$a == $b && $c eq \"x\"} {puts yes}\n");
5587:     }
5588: 
5589:     #[test]
5590:     fn analyse_no_w110_for_numeric_compare() {
5591:         // ``$x == 42`` — numeric literal on the right, no string
5592:         // operand, should not fire.
5593:         let mut a = Analyser::new();
5594:         let r = a.analyse("if {$x == 42} {puts yes}\n", "tcl");
5595:         assert!(
5596:             !r.diagnostics.iter().any(|d| d.code == DiagCode::W110),
5597:             "got {:?}",
5598:             r.diagnostics
5599:         );
5600:     }
5601: 
5602:     #[test]
5603:     fn analyse_no_w110_for_eq_operator() {
5604:         // ``$x eq "foo"`` is the correct form — no W110.
5605:         let mut a = Analyser::new();
5606:         let r = a.analyse("if {$x eq \"foo\"} {puts yes}\n", "tcl");
5607:         assert!(
5608:             !r.diagnostics.iter().any(|d| d.code == DiagCode::W110),
5609:             "got {:?}",
5610:             r.diagnostics
5611:         );
5612:     }
5613: 
5614:     #[test]
5615:     fn analyse_w110_includes_eq_code_fix() {
5616:         // Single ``==`` against a string literal — the blanket
5617:         // rewrite should run and produce a fix containing ``eq``.
5618:         let mut a = Analyser::new();
5619:         let r = a.analyse("if {$x == \"foo\"} {puts yes}\n", "tcl");
5620:         let w110: Vec<_> = r
5621:             .diagnostics
5622:             .iter()
5623:             .filter(|d| d.code == DiagCode::W110)
5624:             .collect();
5625:         assert_eq!(w110.len(), 1, "got {:?}", r.diagnostics);
5626:         assert_eq!(w110[0].fixes.len(), 1, "got {:?}", w110[0].fixes);
5627:         assert!(
5628:             w110[0].fixes[0].new_text.contains("eq"),
5629:             "got {:?}",
5630:             w110[0].fixes[0].new_text
5631:         );
5632:     }
5633: 
5634:     #[test]
5635:     fn analyse_no_w110_for_variable_only_compare() {
5636:         // ``$a == $b`` — both operands are variables, may hold
5637:         // ints, no W110.
5638:         let mut a = Analyser::new();
5639:         let r = a.analyse("if {$a == $b} {puts yes}\n", "tcl");
5640:         assert!(
5641:             !r.diagnostics.iter().any(|d| d.code == DiagCode::W110),
5642:             "got {:?}",
5643:             r.diagnostics
5644:         );
5645:     }
5646: 
5647:     #[test]
5648:     fn analyse_no_w110_for_numeric_string_literal() {
5649:         // ``$x == "42"`` compares numerically when `x` is `42.0`, where `eq`
5650:         // would not, so suggesting `eq` would change the result.
5651:         let mut a = Analyser::new();
5652:         let r = a.analyse("if {$x == \"42\"} {puts yes}\n", "tcl");
5653:         assert!(
5654:             !r.diagnostics.iter().any(|d| d.code == DiagCode::W110),
5655:             "got {:?}",
5656:             r.diagnostics
5657:         );
5658:     }
5659: 
5660:     #[test]
5661:     fn analyse_w110_fires_for_boolean_string_literal() {
5662:         // ``$x == "true"`` — `==` never reads a boolean word as a number, so
5663:         // this compare is already a string compare.
5664:         let mut a = Analyser::new();
5665:         let r = a.analyse("if {$x == \"true\"} {puts yes}\n", "tcl");
5666:         let w110: Vec<_> = r
5667:             .diagnostics
5668:             .iter()
5669:             .filter(|d| d.code == DiagCode::W110)
5670:             .collect();
5671:         assert_eq!(w110.len(), 1, "got {:?}", r.diagnostics);
5672:     }
5673: 
5674:     #[test]
5675:     fn analyse_w110_fires_through_unary_negation() {
5676:         // ``!($x == "foo")`` — W110 walks through ExprUnary.
5677:         let mut a = Analyser::new();
5678:         let r = a.analyse("if {!($x == \"foo\")} {puts no}\n", "tcl");
5679:         let w110: Vec<_> = r
5680:             .diagnostics
5681:             .iter()
5682:             .filter(|d| d.code == DiagCode::W110)
5683:             .collect();
5684:         assert_eq!(w110.len(), 1, "got {:?}", r.diagnostics);
5685:     }
5686: 
5687:     #[test]
5688:     fn analyse_w110_fix_leaves_an_unproven_compare_alone() {
5689:         // ``$a == $b || $x == "foo"`` — only the second ``==`` is proven a
5690:         // string compare, so the fix rewrites that one and keeps the first.
5691:         let mut a = Analyser::new();
5692:         let src = "if {$a == $b || $x == \"foo\"} {puts y}\n";
5693:         let r = a.analyse(src, "tcl");
5694:         let w110: Vec<_> = r
5695:             .diagnostics
5696:             .iter()
5697:             .filter(|d| d.code == DiagCode::W110)
5698:             .collect();
5699:         assert_eq!(w110.len(), 1, "got {:?}", r.diagnostics);
5700:         assert_eq!(w110[0].fixes.len(), 1, "got {:?}", w110[0].fixes);
5701:         let fix = &w110[0].fixes[0];
5702:         let (s, e) = (fix.span.start() as usize, fix.span.end() as usize);
5703:         let applied = format!("{}{}{}", &src[..s], fix.new_text, &src[e..]);
5704:         assert_eq!(applied, "if {$a == $b || $x eq \"foo\"} {puts y}\n");
5705:     }
5706: 
5707:     #[test]
5708:     fn analyse_w110_fires_on_while_condition() {
5709:         // ``while {EXPR} {body}`` — EXPR-role is at index 0.
5710:         let mut a = Analyser::new();
5711:         let r = a.analyse("while {$x == \"foo\"} { break }\n", "tcl");
5712:         let w110: Vec<_> = r
5713:             .diagnostics
5714:             .iter()
5715:             .filter(|d| d.code == DiagCode::W110)
5716:             .collect();
5717:         assert_eq!(w110.len(), 1, "got {:?}", r.diagnostics);
5718:     }
5719: 
5720:     #[test]
5721:     fn analyse_w110_fires_on_top_level_expr_command() {
5722:         // ``expr {$x == "foo"}`` — top-level invocation of
5723:         // ``expr`` exercises the EXPR-role dispatch on the
5724:         // single braced arg.  (Nested ``[expr ...]`` command
5725:         // substitutions are recorded as invocations but the
5726:         // analyser doesn't currently re-enter them for per-
5727:         // command checks; that's a separate concern.)
5728:         let mut a = Analyser::new();
5729:         let r = a.analyse("expr {$x == \"foo\"}\n", "tcl");
5730:         let w110: Vec<_> = r
5731:             .diagnostics
5732:             .iter()
5733:             .filter(|d| d.code == DiagCode::W110)
5734:             .collect();
5735:         assert_eq!(w110.len(), 1, "got {:?}", r.diagnostics);
5736:     }
5737: 
5738:     #[test]
5739:     fn analyse_w110_fires_on_multi_arg_expr_command() {
5740:         // ``expr $x == "foo"`` (no braces, multiple argv slots): the args
5741:         // are joined with spaces — the *substituted* word values, whose
5742:         // quote delimiters Tcl's word splitting already stripped — so the
5743:         // expression is ``$x == foo`` with ``foo`` a bareword, not an
5744:         // ``ExprString``.  W110 (string ``==``) therefore does NOT fire on
5745:         // the unbraced form (only W100 does); it fires on the *braced*
5746:         // ``expr {$x == "foo"}`` where the string literal survives.
5747:         let mut a = Analyser::new();
5748:         let r = a.analyse("expr $x == \"foo\"\n", "tcl");
5749:         let unbraced: Vec<_> = r
5750:             .diagnostics
5751:             .iter()
5752:             .filter(|d| d.code == DiagCode::W110)
5753:             .collect();
5754:         assert_eq!(
5755:             unbraced.len(),
5756:             0,
5757:             "unbraced expr must not fire W110, got {:?}",
5758:             r.diagnostics
5759:         );
5760: 
5761:         let mut a2 = Analyser::new();
5762:         let r2 = a2.analyse("set z [expr {$x == \"foo\"}]\n", "tcl");
5763:         let braced: Vec<_> = r2
5764:             .diagnostics
5765:             .iter()
5766:             .filter(|d| d.code == DiagCode::W110)
5767:             .collect();
5768:         assert_eq!(
5769:             braced.len(),
5770:             1,
5771:             "braced expr must fire W110, got {:?}",
5772:             r2.diagnostics
5773:         );
5774:     }
5775: 
5776:     #[test]
5777:     fn call_by_name_var_not_flagged_unused_or_dead() {
5778:         // A caller-local passed *by name* to a proc that upvar-writes
5779:         // its param (`fill tag`) must not be flagged W211 (unused) or
5780:         // W220 (dead store).
5781:         let mut a = Analyser::new();
5782:         let r = a.analyse(
5783:             "proc ::fill {vn} { upvar 1 $vn v\nset v 1 }\n\
5784:              proc ::f {} { set tag init\nset tag x\nfill tag }\n",
5785:             "tcl",
5786:         );
5787:         assert!(
5788:             r.diagnostics.iter().all(|d| {
5789:                 !((d.code == DiagCode::W211 || d.code == DiagCode::W220)
5790:                     && d.message.contains("tag"))
5791:             }),
5792:             "call-by-name var `tag` must not be flagged unused/dead, got {:?}",
5793:             r.diagnostics,
5794:         );
5795: 
5796:         // Negative control: a genuinely unused local is still flagged
5797:         // (the suppression didn't disable W211 wholesale).
5798:         let mut a2 = Analyser::new();
5799:         let r2 = a2.analyse("proc ::g {} { set unused 1\nputs hi }\n", "tcl");
5800:         assert!(
5801:             r2.diagnostics
5802:                 .iter()
5803:                 .any(|d| d.code == DiagCode::W211 && d.message.contains("unused")),
5804:             "a genuinely unused var should still be flagged, got {:?}",
5805:             r2.diagnostics,
5806:         );
5807:     }
5808: 
5809:     #[test]
5810:     fn dynamic_name_write_does_not_dead_store_the_name_var() {
5811:         // `set $p 1` writes the variable *named by* `$p` and *reads* `p`
5812:         // (verified against tclsh 8.4–9.0).  It must not produce a spurious
5813:         // W220 dead-store on the parameter `p` itself.
5814:         for body in ["set $p 1", "set ${p} 1", "set $p [expr {1}]"] {
5815:             let mut a = Analyser::new();
5816:             let r = a.analyse(&format!("proc ::f {{p}} {{ {body} }}\n"), "tcl");
5817:             assert!(
5818:                 r.diagnostics
5819:                     .iter()
5820:                     .all(|d| !(matches!(d.code.as_str(), "W211" | "W220" | "W214")
5821:                         && d.message.contains("'p'"))),
5822:                 "dynamic-name write `{body}` wrongly flagged `p`, got {:?}",
5823:                 r.diagnostics,
5824:             );
5825:         }
5826:     }
5827: 
5828:     #[test]
5829:     fn dynamic_name_out_var_does_not_suppress_caller_dead_store() {
5830:         // A param used only as a *dynamic name* out-var (`scan`/`lassign`/
5831:         // `regexp`/`regsub` target, or `set $p`) names a callee-local
5832:         // variable — it does NOT write back to the caller's frame, so a
5833:         // caller's literal arg is genuinely dead and must still fire W211 /
5834:         // W220.
5835:         let cases = [
5836:             "proc maybe {target} { scan 42 %d $target }",
5837:             "proc maybe {target} { lassign {1} $target }",
5838:             "proc maybe {target} { regexp {(.)} a -> $target }",
5839:             "proc maybe {target} { regsub a a b $target }",
5840:             "proc maybe {target} { set $target 1 }",
5841:         ];
5842:         for callee in cases {
5843:             let src = format!("{callee}\nproc caller {{}} {{ set x 1; maybe x }}\n");
5844:             let mut a = Analyser::new();
5845:             let r = a.analyse(&src, "tcl");
5846:             assert!(
5847:                 r.diagnostics
5848:                     .iter()
5849:                     .any(|d| (d.code == DiagCode::W211 || d.code == DiagCode::W220)
5850:                         && d.message.contains("'x'")),
5851:                 "caller's dead `x` must still fire for `{callee}`, got {:?}",
5852:                 r.diagnostics,
5853:             );
5854:         }
5855:     }
5856: 
5857:     #[test]
5858:     fn upvar_writeback_still_suppresses_caller_dead_store() {
5859:         // Control: a genuine `upvar`-write-back callee DOES consume the
5860:         // caller's variable, so the dead-store is correctly suppressed.
5861:         let mut a = Analyser::new();
5862:         let r = a.analyse(
5863:             "proc fill {outvar} { upvar $outvar out\nset out 42 }\n\
5864:              proc top {} { set result {}\nfill result\nreturn $result }\n",
5865:             "tcl",
5866:         );
5867:         assert!(
5868:             r.diagnostics
5869:                 .iter()
5870:                 .all(|d| !((d.code == DiagCode::W211 || d.code == DiagCode::W220)
5871:                     && d.message.contains("result"))),
5872:             "upvar write-back must suppress the caller dead-store, got {:?}",
5873:             r.diagnostics,
5874:         );
5875:     }
5876: 
5877:     #[test]
5878:     fn analyse_w128_fires_on_call_to_renamed_command() {
5879:         // A builtin renamed/deleted away earlier in the file → the
5880:         // later call falls through to `unknown` → W128.
5881:         let mut a = Analyser::new();
5882:         let r = a.analyse("rename string {}\nstring toupper x\n", "tcl");
5883:         let w128: Vec<_> = r
5884:             .diagnostics
5885:             .iter()
5886:             .filter(|d| d.code == DiagCode::W128)
5887:             .collect();
5888:         assert_eq!(w128.len(), 1, "expected one W128, got {:?}", r.diagnostics);
5889: 
5890:         // Negative: a normal builtin call with no rename → no W128.
5891:         let mut a2 = Analyser::new();
5892:         let r2 = a2.analyse("string toupper x\n", "tcl");
5893:         assert!(
5894:             r2.diagnostics.iter().all(|d| d.code != DiagCode::W128),
5895:             "unexpected W128: {:?}",
5896:             r2.diagnostics,
5897:         );
5898: 
5899:         // Negative: an ordinary unknown external command (never rebound)
5900:         // resolves opaque but must not fire W128.
5901:         let mut a3 = Analyser::new();
5902:         let r3 = a3.analyse("someunknowncmd a b\n", "tcl");
5903:         assert!(
5904:             r3.diagnostics.iter().all(|d| d.code != DiagCode::W128),
5905:             "unexpected W128: {:?}",
5906:             r3.diagnostics,
5907:         );
5908:     }
5909: 
5910:     #[test]
5911:     fn analyse_w110_no_fire_on_for_clean_condition() {
5912:         // ``for {set i 0} {$i < 10} {incr i} {body}`` — no ``==``
5913:         // anywhere, but ensure the EXPR-role dispatch on ``for``
5914:         // doesn't crash and produces no W110.
5915:         let mut a = Analyser::new();
5916:         let r = a.analyse("for {set i 0} {$i < 10} {incr i} { break }\n", "tcl");
5917:         assert!(
5918:             !r.diagnostics.iter().any(|d| d.code == DiagCode::W110),
5919:             "got {:?}",
5920:             r.diagnostics
5921:         );
5922:     }
5923: 
5924:     #[test]
5925:     fn analyse_w110_fires_on_for_condition() {
5926:         // ``for {set i 0} {$x == "foo"} {incr i} {body}`` —
5927:         // the EXPR-role dispatch runs *before* the hook handlers,
5928:         // so W110 on a ``for`` condition fires whichever walk
5929:         // owns the bodies.
5930:         let mut a = Analyser::new();
5931:         let r = a.analyse("for {set i 0} {$x == \"foo\"} {incr i} { break }\n", "tcl");
5932:         let w110: Vec<_> = r
5933:             .diagnostics
5934:             .iter()
5935:             .filter(|d| d.code == DiagCode::W110)
5936:             .collect();
5937:         assert_eq!(w110.len(), 1, "got {:?}", r.diagnostics);
5938:     }
5939: 
5940:     // -- W302 catch-without-result-var emitter
5941: 
5942:     #[test]
5943:     fn analyse_emits_w302_for_catch_without_result_var() {
5944:         let mut a = Analyser::new();
5945:         let r = a.analyse("catch { puts hi }\n", "tcl");
5946:         let w302: Vec<_> = r
5947:             .diagnostics
5948:             .iter()
5949:             .filter(|d| d.code == DiagCode::W302)
5950:             .collect();
5951:         assert_eq!(w302.len(), 1, "got {:?}", r.diagnostics);
5952:         assert!(
5953:             w302[0].message.contains("silently swallows errors"),
5954:             "got {:?}",
5955:             w302[0].message
5956:         );
5957:         assert!(matches!(w302[0].severity, crate::analyser::Severity::Hint));
5958:     }
5959: 
5960:     #[test]
5961:     fn analyse_no_w302_when_catch_has_result_var() {
5962:         // ``catch BODY result`` — result variable is present, so
5963:         // errors aren't silently swallowed.
5964:         let mut a = Analyser::new();
5965:         let r = a.analyse("catch { puts hi } result\n", "tcl");
5966:         assert!(
5967:             !r.diagnostics.iter().any(|d| d.code == DiagCode::W302),
5968:             "got {:?}",
5969:             r.diagnostics
5970:         );
5971:     }
5972: 
5973:     #[test]
5974:     fn analyse_no_w302_when_catch_has_options_var() {
5975:         // ``catch BODY result options`` — both optional vars
5976:         // present.  Still no W302.
5977:         let mut a = Analyser::new();
5978:         let r = a.analyse("catch { puts hi } result options\n", "tcl");
5979:         assert!(
5980:             !r.diagnostics.iter().any(|d| d.code == DiagCode::W302),
5981:             "got {:?}",
5982:             r.diagnostics
5983:         );
5984:     }
5985: 
5986:     #[test]
5987:     fn analyse_no_w302_for_multi_token_catch_body() {
5988:         // ``catch pre$x`` — a multi-token-word body is a dynamic
5989:         // body (not a single-token word), so it is not treated as a
5990:         // braced catch body and W302 never fires.  The emitter gates
5991:         // on the body being a single-token word.
5992:         let mut a = Analyser::new();
5993:         let r = a.analyse("catch pre$x\n", "tcl");
5994:         assert!(
5995:             !r.diagnostics.iter().any(|d| d.code == DiagCode::W302),
5996:             "got {:?}",
5997:             r.diagnostics
5998:         );
5999:     }
6000: 
6001:     #[test]
6002:     fn analyse_w302_anchors_at_catch_keyword() {
6003:         // W302 highlights just the ``catch`` command token — the
6004:         // narrowest span that identifies the issue — rather than the
6005:         // whole ``catch {…}`` statement
6006:         // (which also dropped the closing brace under the lexer's
6007:         // inner-end convention).
6008:         let mut a = Analyser::new();
6009:         let src = "catch { puts hi }\n";
6010:         let r = a.analyse(src, "tcl");
6011:         let w302: Vec<_> = r
6012:             .diagnostics
6013:             .iter()
6014:             .filter(|d| d.code == DiagCode::W302)
6015:             .collect();
6016:         assert_eq!(w302.len(), 1);
6017:         let span = w302[0].span;
6018:         let text = &src[span.start() as usize..span.end() as usize];
6019:         assert_eq!(text, "catch", "W302 should span only the catch keyword");
6020:     }
6021: 
6022:     // -- W302 quick-fix insertion anchor
6023:     //
6024:     // The diagnostic anchors at the `catch` keyword, so the fix must carry
6025:     // its **own** span: the point past the *body's* closing delimiter.  Each
6026:     // test applies the fix to the source and asserts the resulting text, so a
6027:     // wrong anchor cannot pass by matching only the inserted string.
6028: 
6029:     /// Apply W302's `nth` fix to `src` and return the rewritten source.
6030:     fn apply_w302_fix(src: &str, nth: usize, dialect: &str) -> String {
6031:         let mut a = Analyser::new();
6032:         let r = a.analyse(src, dialect);
6033:         let w302: Vec<_> = r
6034:             .diagnostics
6035:             .iter()
6036:             .filter(|d| d.code == DiagCode::W302)
6037:             .collect();
6038:         assert_eq!(w302.len(), 1, "expected one W302, got {:?}", r.diagnostics);
6039:         let fix = w302[0]
6040:             .fixes
6041:             .get(nth)
6042:             .unwrap_or_else(|| panic!("no fix {nth}: {:?}", w302[0].fixes));
6043:         let mut out = src.to_string();
6044:         out.replace_range(
6045:             fix.span.start() as usize..fix.span.end() as usize,
6046:             &fix.new_text,
6047:         );
6048:         out
6049:     }
6050: 
6051:     #[test]
6052:     fn w302_result_fix_inserts_after_the_body() {
6053:         // The issue's reproducer.  Anchoring at the diagnostic's end would
6054:         // produce `catch result {error oops}`, which C Tcl reads as a catch
6055:         // of the script `result` — completion code 1, result
6056:         // `invalid command name "result"`.
6057:         assert_eq!(
6058:             apply_w302_fix("catch {error oops}\n", 0, "tcl9.0"),
6059:             "catch {error oops} result\n"
6060:         );
6061:     }
6062: 
6063:     #[test]
6064:     fn w302_options_fix_inserts_after_the_body() {
6065:         assert_eq!(
6066:             apply_w302_fix("catch {error oops}\n", 1, "tcl9.0"),
6067:             "catch {error oops} result options\n"
6068:         );
6069:     }
6070: 
6071:     #[test]
6072:     fn w302_fix_handles_a_multiline_body() {
6073:         let src = "catch {\n    error oops\n}\n";
6074:         assert_eq!(
6075:             apply_w302_fix(src, 0, "tcl9.0"),
6076:             "catch {\n    error oops\n} result\n"
6077:         );
6078:     }
6079: 
6080:     #[test]
6081:     fn w302_fix_handles_a_trailing_comment() {
6082:         let src = "catch {error oops} ;# ignore\n";
6083:         assert_eq!(
6084:             apply_w302_fix(src, 0, "tcl9.0"),
6085:             "catch {error oops} result ;# ignore\n"
6086:         );
6087:     }
6088: 
6089:     #[test]
6090:     fn w302_fix_handles_a_semicolon_separated_command() {
6091:         let src = "catch {error oops}; puts done\n";
6092:         assert_eq!(
6093:             apply_w302_fix(src, 0, "tcl9.0"),
6094:             "catch {error oops} result; puts done\n"
6095:         );
6096:     }
6097: 
6098:     #[test]
6099:     fn w302_fix_handles_nested_substitutions_in_the_body() {
6100:         let src = "catch {puts [expr {1 + [foo $x]}]}\n";
6101:         assert_eq!(
6102:             apply_w302_fix(src, 0, "tcl9.0"),
6103:             "catch {puts [expr {1 + [foo $x]}]} result\n"
6104:         );
6105:     }
6106: 
6107:     #[test]
6108:     fn w302_fix_does_not_overshoot_an_empty_body() {
6109:         // `catch {}`'s body span already covers its own closer, so a naive
6110:         // `span.end() + 1` anchor would insert one byte past the brace.
6111:         let src = "catch {}\n";
6112:         assert_eq!(apply_w302_fix(src, 0, "tcl9.0"), "catch {} result\n");
6113:     }
6114: 
6115:     #[test]
6116:     fn w302_fix_handles_a_leading_qualified_head() {
6117:         // `::catch` resolves to the same registry spec (and the same
6118:         // `AnalyserHookId::Catch`), so it is diagnosed and fixed identically.
6119:         let src = "::catch {error oops}\n";
6120:         assert_eq!(
6121:             apply_w302_fix(src, 0, "tcl9.0"),
6122:             "::catch {error oops} result\n"
6123:         );
6124:     }
6125: 
6126:     #[test]
6127:     fn w302_offers_only_the_result_variable_under_tcl84() {
6128:         // Tcl 8.4's `catch script ?varName?` has no options-dictionary
6129:         // argument, so the second fix must not be offered there — the count
6130:         // comes from the dialect-applicable synopsis, not from a constant.
6131:         let mut a = Analyser::new();
6132:         let r = a.analyse("catch {error oops}\n", "tcl8.4");
6133:         let w302: Vec<_> = r
6134:             .diagnostics
6135:             .iter()
6136:             .filter(|d| d.code == DiagCode::W302)
6137:             .collect();
6138:         assert_eq!(w302.len(), 1, "got {:?}", r.diagnostics);
6139:         assert_eq!(
6140:             w302[0].fixes.len(),
6141:             1,
6142:             "8.4 documents one optional word: {:?}",
6143:             w302[0].fixes
6144:         );
6145:         assert_eq!(w302[0].fixes[0].new_text, " var");
6146:     }
6147: 
6148:     #[test]
6149:     fn w302_fixes_are_never_bulk_applicable() {
6150:         // Capturing the result writes a new variable in the caller's frame,
6151:         // which a program already using that name observes — so the fix is
6152:         // hardening, not a semantics-preserving rewrite.
6153:         let mut a = Analyser::new();
6154:         let r = a.analyse("catch {error oops}\n", "tcl9.0");
6155:         let w302 = r
6156:             .diagnostics
6157:             .iter()
6158:             .find(|d| d.code == DiagCode::W302)
6159:             .expect("W302");
6160:         assert_ne!(w302.fixes, [] as [crate::irules_checks::CodeFix; 0]);
6161:         assert!(
6162:             w302.fixes.iter().all(|f| !f.safety.is_bulk_applicable()),
6163:             "got {:?}",
6164:             w302.fixes
6165:         );
6166:     }
6167: 
6168:     #[test]
6169:     fn w302_carries_no_fix_for_a_malformed_catch() {
6170:         // An unterminated body never reaches a well-formed insertion point;
6171:         // whatever the recovery path emits, no W302 fix may point outside
6172:         // the buffer.
6173:         let mut a = Analyser::new();
6174:         let src = "catch {error oops\n";
6175:         let r = a.analyse(src, "tcl9.0");
6176:         for diag in r.diagnostics.iter().filter(|d| d.code == DiagCode::W302) {
6177:             for fix in &diag.fixes {
6178:                 assert!(
6179:                     fix.span.end() as usize <= src.len(),
6180:                     "fix span {:?} outside the buffer",
6181:                     fix.span
6182:                 );
6183:             }
6184:         }
6185:     }
6186: 
6187:     // -- W001 unknown-subcommand emitter
6188: 
6189:     #[test]
6190:     fn analyse_emits_w001_for_unknown_string_subcommand() {
6191:         let mut a = Analyser::new();
6192:         let r = a.analyse("string bogus $x\n", "tcl");
6193:         let w001: Vec<_> = r
6194:             .diagnostics
6195:             .iter()
6196:             .filter(|d| d.code == DiagCode::W001)
6197:             .collect();
6198:         assert_eq!(w001.len(), 1, "got {:?}", r.diagnostics);
6199:         assert!(
6200:             w001[0].message.contains("'bogus'") && w001[0].message.contains("'string'"),
6201:             "got {:?}",
6202:             w001[0].message
6203:         );
6204:         assert!(matches!(
6205:             w001[0].severity,
6206:             crate::analyser::Severity::Warning
6207:         ));
6208:     }
6209: 
6210:     #[test]
6211:     fn analyse_w001_includes_did_you_mean_suggestion() {
6212:         // ``string lenght`` — single-char typo for ``length``,
6213:         // edit distance 2.  ``suggest_similar`` should surface
6214:         // ``length``.
6215:         let mut a = Analyser::new();
6216:         let r = a.analyse("string lenght $x\n", "tcl");
6217:         let w001: Vec<_> = r
6218:             .diagnostics
6219:             .iter()
6220:             .filter(|d| d.code == DiagCode::W001)
6221:             .collect();
6222:         assert_eq!(w001.len(), 1, "got {:?}", r.diagnostics);
6223:         assert!(
6224:             w001[0].message.contains("did you mean 'length'"),
6225:             "got {:?}",
6226:             w001[0].message
6227:         );
6228:         assert!(
6229:             w001[0].fixes.iter().any(|f| f.new_text == "length"),
6230:             "got {:?}",
6231:             w001[0].fixes
6232:         );
6233:     }
6234: 
6235:     #[test]
6236:     fn analyse_no_w001_for_known_subcommand() {
6237:         // ``string length $x`` — known subcommand.  No W001.
6238:         let mut a = Analyser::new();
6239:         let r = a.analyse("string length $x\n", "tcl");
6240:         assert!(
6241:             !r.diagnostics.iter().any(|d| d.code == DiagCode::W001),
6242:             "got {:?}",
6243:             r.diagnostics
6244:         );
6245:     }
6246: 
6247:     #[test]
6248:     fn analyse_no_w001_for_dynamic_subcommand_position() {
6249:         // ``string $sub $x`` — runtime-resolved subcommand;
6250:         // can't statically check.  No W001.
6251:         let mut a = Analyser::new();
6252:         let r = a.analyse("string $sub $x\n", "tcl");
6253:         assert!(
6254:             !r.diagnostics.iter().any(|d| d.code == DiagCode::W001),
6255:             "got {:?}",
6256:             r.diagnostics
6257:         );
6258:     }
6259: 
6260:     #[test]
6261:     fn analyse_no_w001_for_command_substitution_in_subcommand_position() {
6262:         // ``string [pick] $x`` — ``[…]`` in the subcommand
6263:         // position is also a runtime-resolved value.  No W001.
6264:         let mut a = Analyser::new();
6265:         let r = a.analyse("string [pick] $x\n", "tcl");
6266:         assert!(
6267:             !r.diagnostics.iter().any(|d| d.code == DiagCode::W001),
6268:             "got {:?}",
6269:             r.diagnostics
6270:         );
6271:     }
6272: 
6273:     #[test]
6274:     fn analyse_no_w001_for_simple_command() {
6275:         // ``set x 1`` — ``set`` has no SubcommandSig.  No W001.
6276:         let mut a = Analyser::new();
6277:         let r = a.analyse("set x 1\n", "tcl");
6278:         assert!(
6279:             !r.diagnostics.iter().any(|d| d.code == DiagCode::W001),
6280:             "got {:?}",
6281:             r.diagnostics
6282:         );
6283:     }
6284: 
6285:     #[test]
6286:     fn analyse_no_w001_for_unknown_command() {
6287:         // ``unknownthing foo`` — registry doesn't know the
6288:         // command, so no signature lookup, no W001.  (W123
6289:         // owns the unknown-command diagnostic.)
6290:         let mut a = Analyser::new();
6291:         let r = a.analyse("unknownthing foo\n", "tcl");
6292:         assert!(
6293:             !r.diagnostics.iter().any(|d| d.code == DiagCode::W001),
6294:             "got {:?}",
6295:             r.diagnostics
6296:         );
6297:     }
6298: 
6299:     #[test]
6300:     fn analyse_w001_anchors_at_subcommand_token_only() {
6301:         // The squiggle sits tightly on the offending word alone — not the
6302:         // command name too — matching the "did you mean" fix's replacement
6303:         // range and the KCS doc's documented "squiggle under the subcommand
6304:         // token" behaviour.
6305:         let mut a = Analyser::new();
6306:         let src = "string bogus $x\n";
6307:         let r = a.analyse(src, "tcl");
6308:         let w001: Vec<_> = r
6309:             .diagnostics
6310:             .iter()
6311:             .filter(|d| d.code == DiagCode::W001)
6312:             .collect();
6313:         assert_eq!(w001.len(), 1);
6314:         let span = w001[0].span;
6315:         let text = &src[span.start() as usize..span.end() as usize];
6316:         assert_eq!(text, "bogus", "got {text:?}");
6317:     }
6318: 
6319:     #[test]
6320:     fn analyse_emits_w001_for_unknown_dict_subcommand() {
6321:         // ``dict`` is also a SubcommandSig command — confirm
6322:         // dispatch isn't ``string``-specific.
6323:         let mut a = Analyser::new();
6324:         let r = a.analyse("dict froob $d $k\n", "tcl");
6325:         let w001: Vec<_> = r
6326:             .diagnostics
6327:             .iter()
6328:             .filter(|d| d.code == DiagCode::W001)
6329:             .collect();
6330:         assert_eq!(w001.len(), 1, "got {:?}", r.diagnostics);
6331:         assert!(
6332:             w001[0].message.contains("'dict'"),
6333:             "got {:?}",
6334:             w001[0].message
6335:         );
6336:     }
6337: 
6338:     #[test]
6339:     fn analyse_w001_fix_replaces_wrapped_literal_subcommand() {
6340:         // Wrapper tokens (``Str`` braced ``{lenght}`` / ``Esc``
6341:         // quoted ``"lenght"``) carry the opening delimiter via
6342:         // ``content_offset`` and the lexer span excludes the
6343:         // closing delimiter; the W001 code-fix targets the
6344:         // content range so the replacement preserves the
6345:         // wrapping ``}`` / ``"`` rather than leaving a stray
6346:         // trailing delimiter behind.
6347:         for (src, expected) in [
6348:             ("string {lenght} $x\n", "string {length} $x\n"),
6349:             ("string \"lenght\" $x\n", "string \"length\" $x\n"),
6350:             ("string lenght $x\n", "string length $x\n"),
6351:         ] {
6352:             let mut a = Analyser::new();
6353:             let r = a.analyse(src, "tcl");
6354:             let w001: Vec<_> = r
6355:                 .diagnostics
6356:                 .iter()
6357:                 .filter(|d| d.code == DiagCode::W001)
6358:                 .collect();
6359:             assert_eq!(w001.len(), 1, "src={src:?} got {:?}", r.diagnostics);
6360:             assert!(
6361:                 w001[0].message.contains("did you mean 'length'"),
6362:                 "src={src:?} got {:?}",
6363:                 w001[0].message
6364:             );
6365: 
6366:             let fix = w001[0]
6367:                 .fixes
6368:                 .iter()
6369:                 .find(|f| f.new_text == "length")
6370:                 .expect("expected replacement fix to 'length'");
6371: 
6372:             let mut fixed = src.to_string();
6373:             let start = fix.span.start() as usize;
6374:             let end = fix.span.end() as usize;
6375:             fixed.replace_range(start..end, &fix.new_text);
6376: 
6377:             assert_eq!(fixed, expected, "src={src:?} fixes={:?}", w001[0].fixes);
6378:             assert!(!fixed.contains("lenght"), "src={src:?} fixed={fixed:?}");
6379:         }
6380:     }
6381: 
6382:     #[test]
6383:     fn analyse_w001_diagnostic_span_matches_fix_span() {
6384:         // The squiggle and the "did you mean" quick-fix must target the
6385:         // identical range — otherwise accepting the fix visibly leaves part
6386:         // of the squiggled text unchanged.
6387:         let mut a = Analyser::new();
6388:         let src = "string lenght $x\n";
6389:         let r = a.analyse(src, "tcl");
6390:         let w001: Vec<_> = r
6391:             .diagnostics
6392:             .iter()
6393:             .filter(|d| d.code == DiagCode::W001)
6394:             .collect();
6395:         assert_eq!(w001.len(), 1, "got {:?}", r.diagnostics);
6396:         let fix = w001[0]
6397:             .fixes
6398:             .first()
6399:             .expect("expected a 'did you mean' fix");
6400:         assert_eq!(w001[0].span, fix.span, "got {:?}", w001[0]);
6401:     }
6402: 
6403:     #[test]
6404:     fn analyse_w001_no_diagnostic_at_all_when_shadowed_by_proc() {
6405:         // A same-file `proc string {...}` must suppress W001 (and its
6406:         // subcommand-level W002 sibling) completely — not just avoid the
6407:         // specific message text. The FP-STY-17 reproducers live in
6408:         // `analyser/diagnostics/fp/sty.rs::fp_sty_17_*`.
6409:         let mut a = Analyser::new();
6410:         let src = "proc string {op args} { return $op }\nstring reverse hello\n";
6411:         let r = a.analyse(src, "tcl");
6412:         assert!(
6413:             !r.diagnostics
6414:                 .iter()
6415:                 .any(|d| matches!(d.code, DiagCode::W001 | DiagCode::W002)),
6416:             "got {:?}",
6417:             r.diagnostics
6418:         );
6419:     }
6420: 
6421:     #[test]
6422:     fn analyse_w001_shadow_suppression_is_scoped_to_the_shadowed_name() {
6423:         // Shadowing `string` must not suppress W001 for a genuinely unknown
6424:         // subcommand on a different, unshadowed ensemble in the same file.
6425:         let mut a = Analyser::new();
6426:         let src = "proc string {op args} { return $op }\ninfo bogus\n";
6427:         let r = a.analyse(src, "tcl");
6428:         let w001: Vec<_> = r
6429:             .diagnostics
6430:             .iter()
6431:             .filter(|d| d.code == DiagCode::W001)
6432:             .collect();
6433:         assert_eq!(w001.len(), 1, "got {:?}", r.diagnostics);
6434:         assert!(w001[0].message.contains("'info'"), "got {:?}", w001[0]);
6435:     }
6436: 
6437:     #[test]
6438:     fn analyse_no_w001_for_expanded_literal_subcommand() {
6439:         // `{*}{create a b}` splices the elements `create`, `a`, `b` into the
6440:         // argument list (confirmed against tclsh 8.6.14) — the raw source
6441:         // text "create a b" must never be compared against the subcommand
6442:         // set. The FP-STY-18 reproducers live in
6443:         // `analyser/diagnostics/fp/sty.rs::fp_sty_18_*`.
6444:         let mut a = Analyser::new();
6445:         let r = a.analyse("dict {*}{create a b}\n", "tcl");
6446:         assert!(
6447:             !r.diagnostics.iter().any(|d| d.code == DiagCode::W001),
6448:             "got {:?}",
6449:             r.diagnostics
6450:         );
6451:     }
6452: 
6453:     #[test]
6454:     fn analyse_w001_still_fires_for_unexpanded_unknown_subcommand() {
6455:         // TP control for the `{*}`-expansion skip: the identical subcommand
6456:         // set, without expansion, still fires on a genuine typo.
6457:         let mut a = Analyser::new();
6458:         let r = a.analyse("dict bogus a b\n", "tcl");
6459:         assert!(
6460:             r.diagnostics.iter().any(|d| d.code == DiagCode::W001),
6461:             "got {:?}",
6462:             r.diagnostics
6463:         );
6464:     }
6465: 
6466:     // -- E004 malformed-if emitter
6467:     //
6468:     // Fires ``Severity::Error`` when an ``if`` invocation's structural
6469:     // shape doesn't match
6470:     // ``if COND BODY ?elseif COND BODY ...? ?else BODY?``.  Detection
6471:     // reads the registry's walk of `if`'s clause grammar through
6472:     // `CommandRegistry::clause_shape_defect` — the grammar itself is not
6473:     // reimplemented here (see `emit_e004_clause_shape_diagnostic`).
6474:     // Every case is cross-checked against tclsh 8.6 and Tcl 9.0.4's
6475:     // `TclNRIfObjCmd` source; see the truth table in
6476:     // `tcl-registry/src/commands/tcl/if_.rs`'s own tests for the
6477:     // grammar-level cases this integration layer doesn't repeat.
6478: 
6479:     fn e004_diags(src: &str) -> Vec<crate::analyser::types::Diagnostic> {
6480:         let mut a = Analyser::new();
6481:         let r = a.analyse(src, "tcl");
6482:         r.diagnostics
6483:             .into_iter()
6484:             .filter(|d| d.code == DiagCode::E004)
6485:             .collect()
6486:     }
6487: 
6488:     fn span_text(src: &str, span: tcl_lexer::Span) -> &str {
6489:         &src[span.start() as usize..span.end() as usize]
6490:     }
6491: 
6492:     // -- TP: genuinely malformed shapes, with the precise message and a
6493:     // tight span (not the whole `if` statement).
6494: 
6495:     #[test]
6496:     fn tp_bare_if_names_the_invoked_command_in_the_message() {
6497:         // ``if`` alone — no expression at all.  Message and span both
6498:         // name "if" itself (real Tcl: `no expression after "if"
6499:         // argument`), and this must be the *only* diagnostic for the
6500:         // line — no redundant generic arity error alongside it (see
6501:         // `no_duplicate_e002_alongside_e004`).
6502:         let src = "if\n";
6503:         let e004 = e004_diags(src);
6504:         assert_eq!(e004.len(), 1, "got {e004:?}");
6505:         assert_eq!(e004[0].message, "No expression after \"if\" argument");
6506:         assert_eq!(span_text(src, e004[0].span), "if");
6507:     }
6508: 
6509:     #[test]
6510:     fn tp_condition_without_body_names_the_condition_text() {
6511:         // ``if {1}`` — real Tcl: `no script following "1" argument`.
6512:         let src = "if {1}\n";
6513:         let e004 = e004_diags(src);
6514:         assert_eq!(e004.len(), 1, "got {e004:?}");
6515:         assert_eq!(e004[0].message, "No script following \"1\" argument");
6516:         assert_eq!(span_text(src, e004[0].span), "{1}");
6517:     }
6518: 
6519:     #[test]
6520:     fn tp_then_keyword_without_body_names_then() {
6521:         // ``if {1} then`` — real Tcl: `no script following "then"
6522:         // argument`.
6523:         let src = "if {1} then\n";
6524:         let e004 = e004_diags(src);
6525:         assert_eq!(e004.len(), 1, "got {e004:?}");
6526:         assert_eq!(e004[0].message, "No script following \"then\" argument");
6527:         assert_eq!(span_text(src, e004[0].span), "then");
6528:     }
6529: 
6530:     #[test]
6531:     fn tp_bare_else_without_body_names_else() {
6532:         // ``if {1} { a } else`` — real Tcl: `no script following
6533:         // "else" argument`.
6534:         let src = "if {1} { a } else\n";
6535:         let e004 = e004_diags(src);
6536:         assert_eq!(e004.len(), 1, "got {e004:?}");
6537:         assert_eq!(e004[0].message, "No script following \"else\" argument");
6538:         assert_eq!(span_text(src, e004[0].span), "else");
6539:     }
6540: 
6541:     #[test]
6542:     fn tp_elseif_without_expr_names_elseif() {
6543:         // ``if {1} { a } elseif`` — real Tcl: `no expression after
6544:         // "elseif" argument`.
6545:         let src = "if {1} { a } elseif\n";
6546:         let e004 = e004_diags(src);
6547:         assert_eq!(e004.len(), 1, "got {e004:?}");
6548:         assert_eq!(e004[0].message, "No expression after \"elseif\" argument");
6549:         assert_eq!(span_text(src, e004[0].span), "elseif");
6550:     }
6551: 
6552:     #[test]
6553:     fn tp_elseif_condition_without_body_names_the_condition_text() {
6554:         // ``if {1} { a } elseif {2}`` — real Tcl: `no script
6555:         // following "2" argument`.
6556:         let src = "if {1} { a } elseif {2}\n";
6557:         let e004 = e004_diags(src);
6558:         assert_eq!(e004.len(), 1, "got {e004:?}");
6559:         assert_eq!(e004[0].message, "No script following \"2\" argument");
6560:         assert_eq!(span_text(src, e004[0].span), "{2}");
6561:     }
6562: 
6563:     #[test]
6564:     fn tp_extra_words_after_explicit_else_anchors_only_the_extra_words() {
6565:         // ``if {1} { a } else { b } extra`` — the span covers just
6566:         // "extra", not the whole statement.
6567:         let src = "if {1} { a } else { b } extra\n";
6568:         let e004 = e004_diags(src);
6569:         assert_eq!(e004.len(), 1, "got {e004:?}");
6570:         assert_eq!(
6571:             e004[0].message,
6572:             "Extra words after \"else\" clause in \"if\" command"
6573:         );
6574:         assert_eq!(span_text(src, e004[0].span), "extra");
6575:         assert!(matches!(e004[0].severity, crate::analyser::Severity::Error));
6576:     }
6577: 
6578:     #[test]
6579:     fn tp_extra_words_after_implicit_else_anchors_only_the_extra_word() {
6580:         // ``if {1} { a } { b } { c }`` — implicit else (no ``else``
6581:         // keyword); "c" is the first extra word.
6582:         let src = "if {1} { a } { b } { c }\n";
6583:         let e004 = e004_diags(src);
6584:         assert_eq!(e004.len(), 1, "got {e004:?}");
6585:         assert_eq!(span_text(src, e004[0].span), "{ c }");
6586:     }
6587: 
6588:     #[test]
6589:     fn tp_qualified_double_colon_if_is_checked_too() {
6590:         // ``::if`` names the same global command as ``if`` — registry
6591:         // name resolution strips the leading ``::`` for every command,
6592:         // so the dispatch-generic hook lookup picks this up without any
6593:         // `if`-specific handling in the compiler.
6594:         let src = "::if {1} { a } { b } { c }\n";
6595:         let e004 = e004_diags(src);
6596:         assert_eq!(e004.len(), 1, "got {e004:?}");
6597:     }
6598: 
6599:     // -- FP fixed: a leading `else`/`elseif` is a well-formed `if` whose
6600:     // condition happens to be that bareword — not a malformed `if`.
6601:     // Verified against tclsh 8.6: both raise `invalid bareword "else"` /
6602:     // `"elseif"` at *expression*-evaluation time, never a `wrong # args`
6603:     // structural error.
6604: 
6605:     #[test]
6606:     fn fp_leading_else_is_not_malformed() {
6607:         let r_diags = e004_diags("if else { x }\n");
6608:         assert_eq!(r_diags.len(), 0, "got {r_diags:?}");
6609:     }
6610: 
6611:     #[test]
6612:     fn fp_leading_elseif_is_not_malformed() {
6613:         let r_diags = e004_diags("if elseif { x }\n");
6614:         assert_eq!(r_diags.len(), 0, "got {r_diags:?}");
6615:     }
6616: 
6617:     #[test]
6618:     fn fp_else_in_elseif_condition_slot_is_not_malformed() {
6619:         // ``if {1} { a } elseif else { b }`` — "else" sits in the
6620:         // *elseif's* condition slot, never keyword-matched there
6621:         // either (verified against tclsh 8.6: runs body "a", not a
6622:         // wrong-#args error).
6623:         let r_diags = e004_diags("if {1} { a } elseif else { b }\n");
6624:         assert_eq!(r_diags.len(), 0, "got {r_diags:?}");
6625:     }
6626: 
6627:     // -- TN: well-formed shapes never flagged.
6628: 
6629:     #[test]
6630:     fn tn_single_clause_if() {
6631:         assert_eq!(
6632:             e004_diags("if {1} { a }\n"),
6633:             [] as [crate::analyser::types::Diagnostic; 0]
6634:         );
6635:     }
6636: 
6637:     #[test]
6638:     fn tn_if_else() {
6639:         assert_eq!(
6640:             e004_diags("if {1} { a } else { b }\n"),
6641:             [] as [crate::analyser::types::Diagnostic; 0]
6642:         );
6643:     }
6644: 
6645:     #[test]
6646:     fn tn_if_elseif_else_chain() {
6647:         assert_eq!(
6648:             e004_diags("if {$a} { x } elseif {$b} { y } else { z }\n"),
6649:             [] as [crate::analyser::types::Diagnostic; 0]
6650:         );
6651:     }
6652: 
6653:     #[test]
6654:     fn tn_if_with_then_keyword() {
6655:         assert_eq!(
6656:             e004_diags("if {1} then { a }\n"),
6657:             [] as [crate::analyser::types::Diagnostic; 0]
6658:         );
6659:     }
6660: 
6661:     #[test]
6662:     fn tn_implicit_else_single_body() {
6663:         // ``if {1} { a } { b }`` — one implicit-else body, no keyword.
6664:         assert_eq!(
6665:             e004_diags("if {1} { a } { b }\n"),
6666:             [] as [crate::analyser::types::Diagnostic; 0]
6667:         );
6668:     }
6669: 
6670:     #[test]
6671:     fn tn_inside_tcloo_method_body() {
6672:         // `if` structural checking is generic body-walking — it must
6673:         // fire the same way inside a TclOO method body as at top level.
6674:         let src = "oo::class create C {\n  method m {} {\n    if {1} { a } { b } { c }\n  }\n}\n";
6675:         let e004 = e004_diags(src);
6676:         assert_eq!(e004.len(), 1, "got {e004:?}");
6677:     }
6678: 
6679:     // Original move lineage retains the selected clause grammar.
6680:     #[test]
6681:     fn renamed_if_keeps_its_original_clause_shape() {
6682:         // naming.diagnostic.original-control-advice
6683:         // docs/design/analysis/name-resolution-proofs/diagnostic-original-control-advice.md
6684:         let src = "rename if myif\nmyif {1} { a } { b } { c }\n";
6685:         let e004 = e004_diags(src);
6686:         assert_eq!(e004.len(), 1, "got {e004:?}");
6687:     }
6688: 
6689:     // -- Redundant-diagnostic fix: `if`'s registry `arity` floor no
6690:     // longer produces a second, generic E002 alongside the precise
6691:     // E004 for the same defect.
6692: 
6693:     #[test]
6694:     fn no_duplicate_e002_alongside_e004() {
6695:         for src in ["if\n", "if {1}\n"] {
6696:             let mut a = Analyser::new();
6697:             let r = a.analyse(src, "tcl");
6698:             assert!(
6699:                 !r.diagnostics.iter().any(|d| d.code == DiagCode::E002),
6700:                 "src={src:?} got {:?}",
6701:                 r.diagnostics
6702:             );
6703:             assert!(
6704:                 r.diagnostics.iter().any(|d| d.code == DiagCode::E004),
6705:                 "src={src:?} got {:?}",
6706:                 r.diagnostics
6707:             );
6708:         }
6709:     }
6710: 
6711:     // -- Code fixes.
6712: 
6713:     fn apply_fix(src: &str, fix: &crate::analyser::types::CodeFix) -> String {
6714:         let mut fixed = src.to_string();
6715:         fixed.replace_range(
6716:             fix.span.start() as usize..fix.span.end() as usize,
6717:             &fix.new_text,
6718:         );
6719:         fixed
6720:     }
6721: 
6722:     #[test]
6723:     fn fix_merges_extra_words_into_the_final_body() {
6724:         let src = "if {1} { a } { b } { c }";
6725:         let e004 = e004_diags(src);
6726:         assert_eq!(e004.len(), 1, "got {e004:?}");
6727:         assert_eq!(e004[0].fixes.len(), 1, "got {:?}", e004[0].fixes);
6728:         let fixed = apply_fix(src, &e004[0].fixes[0]);
6729:         assert_eq!(fixed, "if {1} { a } {{ b } { c }}");
6730:         // The fixed source must itself be shape-well-formed.
6731:         assert_eq!(e004_diags(&fixed).len(), 0, "fixed={fixed:?}");
6732:     }
6733: 
6734:     #[test]
6735:     fn fix_merges_extra_words_after_explicit_else() {
6736:         let src = "if {1} { a } else { b } extra";
6737:         let e004 = e004_diags(src);
6738:         assert_eq!(e004[0].fixes.len(), 1, "got {:?}", e004[0].fixes);
6739:         let fixed = apply_fix(src, &e004[0].fixes[0]);
6740:         assert_eq!(fixed, "if {1} { a } else {{ b } extra}");
6741:         assert_eq!(e004_diags(&fixed).len(), 0, "fixed={fixed:?}");
6742:     }
6743: 
6744:     #[test]
6745:     fn fix_removes_dangling_elseif_clause() {
6746:         let src = "if {1} { a } elseif";
6747:         let e004 = e004_diags(src);
6748:         assert_eq!(e004[0].fixes.len(), 1, "got {:?}", e004[0].fixes);
6749:         assert_eq!(e004[0].fixes[0].new_text, "");
6750:         let fixed = apply_fix(src, &e004[0].fixes[0]);
6751:         assert_eq!(fixed, "if {1} { a } ");
6752:         assert_eq!(e004_diags(&fixed).len(), 0, "fixed={fixed:?}");
6753:     }
6754: 
6755:     #[test]
6756:     fn fix_removes_dangling_else_with_no_body() {
6757:         let src = "if {1} { a } else";
6758:         let e004 = e004_diags(src);
6759:         assert_eq!(e004[0].fixes.len(), 1, "got {:?}", e004[0].fixes);
6760:         let fixed = apply_fix(src, &e004[0].fixes[0]);
6761:         assert_eq!(fixed, "if {1} { a } ");
6762:         assert_eq!(e004_diags(&fixed).len(), 0, "fixed={fixed:?}");
6763:     }
6764: 
6765:     #[test]
6766:     fn fix_removes_dangling_elseif_condition_without_body() {
6767:         let src = "if {1} { a } elseif {2}";
6768:         let e004 = e004_diags(src);
6769:         assert_eq!(e004[0].fixes.len(), 1, "got {:?}", e004[0].fixes);
6770:         let fixed = apply_fix(src, &e004[0].fixes[0]);
6771:         assert_eq!(fixed, "if {1} { a } ");
6772:         assert_eq!(e004_diags(&fixed).len(), 0, "fixed={fixed:?}");
6773:     }
6774: 
6775:     #[test]
6776:     fn no_fix_offered_when_the_first_clause_never_completed() {
6777:         // ``if`` / ``if {1}`` — there is no well-formed prefix to fall
6778:         // back to, so no fix is offered (never a guessed body).
6779:         for src in ["if", "if {1}", "if {1} then"] {
6780:             let e004 = e004_diags(src);
6781:             assert_eq!(e004.len(), 1, "src={src:?}");
6782:             assert_eq!(
6783:                 e004[0].fixes.len(),
6784:                 0,
6785:                 "src={src:?} got {:?}",
6786:                 e004[0].fixes
6787:             );
6788:         }
6789:     }
6790: 
6791:     // -- W304 missing-option-terminator emitter
6792:     //
6793:     // Resolution profile lives in ``tcl-registry``; tristate severity
6794:     // / two-diagnostic origin / code-fix logic lives in
6795:     // ``analyser/diagnostics.rs``.
6796: 
6797:     fn w304_diags(src: &str) -> Vec<crate::analyser::types::Diagnostic> {
6798:         let mut a = Analyser::new();
6799:         let r = a.analyse(src, "tcl");
6800:         r.diagnostics
6801:             .into_iter()
6802:             .filter(|d| d.code == DiagCode::W304)
6803:             .collect()
6804:     }
6805: 
6806:     #[test]
6807:     fn analyse_emits_w304_for_regexp_pattern_variable() {
6808:         let diags = w304_diags("regexp $pattern $text\n");
6809:         assert_eq!(diags.len(), 1, "got {diags:?}");
6810:         assert!(
6811:             diags[0].message.to_lowercase().contains("option-injection"),
6812:             "got {:?}",
6813:             diags[0].message
6814:         );
6815:         assert!(matches!(
6816:             diags[0].severity,
6817:             crate::analyser::Severity::Suggestion
6818:         ));
6819:     }
6820: 
6821:     #[test]
6822:     fn analyse_no_w304_for_regexp_safe_literal_pattern() {
6823:         // Pattern starts with `(` — non-dynamic, doesn't start with
6824:         // `-`, so the OFF gate suppresses regardless of command.
6825:         let diags = w304_diags("regexp {(a+)+$} $text\n");
6826:         assert_eq!(diags.len(), 0, "got {diags:?}");
6827:     }
6828: 
6829:     #[test]
6830:     fn analyse_emits_w304_for_regexp_literal_dash_pattern() {
6831:         // ``regexp {-[0-9]+} $text`` — the literal pattern starts
6832:         // with `-` so the positional scanner treats it as an
6833:         // unknown option and lands on the next positional
6834:         // (``$text``).  The diagnostic still fires; severity comes
6835:         // from the dynamic-var INFO path because the diag anchors on
6836:         // ``$text``, not the pattern literal.
6837:         let diags = w304_diags("regexp {-[0-9]+} $text\n");
6838:         assert_eq!(diags.len(), 1, "got {diags:?}");
6839:     }
6840: 
6841:     #[test]
6842:     fn analyse_no_w304_for_exec_literal_dash_after_first_positional() {
6843:         // ``exec foo -bad`` — ``first_positional_without_terminator``
6844:         // treats ``foo`` (index 0) as the first positional, so the
6845:         // OFF gate suppresses W304 there (non-dynamic, doesn't start
6846:         // with ``-``).  The later literal ``-bad`` is not
6847:         // re-considered as a candidate "first positional" argument,
6848:         // so no diagnostic fires.
6849:         //
6850:         // This pins the scanner / first-positional behaviour for
6851:         // ``exec`` rather than exercising the literal-dash WARN
6852:         // branch.  The WARN branch is covered by
6853:         // `analyse_emits_w304_for_regexp_literal_dash_pattern`
6854:         // (literal pattern starting with `-`) and
6855:         // `analyse_w304_constant_propagation_dash_value_warns`
6856:         // (variable resolved via constant-prop to a `-`-prefixed
6857:         // value).
6858:         let diags = w304_diags("exec foo -bad\n");
6859:         assert_eq!(diags.len(), 0, "got {diags:?}");
6860:     }
6861: 
6862:     #[test]
6863:     fn analyse_no_w304_for_regexp_with_terminator() {
6864:         let diags = w304_diags("regexp -- $pattern $text\n");
6865:         assert_eq!(diags.len(), 0, "got {diags:?}");
6866:     }
6867: 
6868:     #[test]
6869:     fn analyse_emits_w304_for_regexp_with_option_value_then_variable() {
6870:         // ``-start`` consumes the next arg as its value; the first
6871:         // positional after it is the pattern variable.
6872:         let diags = w304_diags("regexp -start 0 $pattern $text\n");
6873:         assert_eq!(diags.len(), 1, "got {diags:?}");
6874:     }
6875: 
6876:     #[test]
6877:     fn analyse_emits_w304_for_regsub_variable() {
6878:         let diags = w304_diags("regsub $pattern $text X out\n");
6879:         assert_eq!(diags.len(), 1, "got {diags:?}");
6880:     }
6881: 
6882:     #[test]
6883:     fn analyse_no_w304_for_subst() {
6884:         // ``subst`` does not declare a ``--`` option — registry-
6885:         // level filter suppresses W304 entirely.
6886:         let diags = w304_diags("subst $template\n");
6887:         assert_eq!(diags.len(), 0, "got {diags:?}");
6888:     }
6889: 
6890:     #[test]
6891:     fn analyse_emits_w304_for_exec_variable() {
6892:         let diags = w304_diags("exec $cmd\n");
6893:         assert_eq!(diags.len(), 1, "got {diags:?}");
6894:     }
6895: 
6896:     #[test]
6897:     fn analyse_no_w304_for_exec_with_terminator() {
6898:         let diags = w304_diags("exec -- $cmd\n");
6899:         assert_eq!(diags.len(), 0, "got {diags:?}");
6900:     }
6901: 
6902:     #[test]
6903:     fn analyse_no_w304_for_glob_safe_literal() {
6904:         // ``*.tcl`` does not start with `-`; OFF gate suppresses.
6905:         let diags = w304_diags("glob *.tcl\n");
6906:         assert_eq!(diags.len(), 0, "got {diags:?}");
6907:     }
6908: 
6909:     #[test]
6910:     fn analyse_no_w304_for_string_match() {
6911:         // ``string match`` does not support ``--`` — registry filter.
6912:         let diags = w304_diags("string match $pattern $value\n");
6913:         assert_eq!(diags.len(), 0, "got {diags:?}");
6914:     }
6915: 
6916:     #[test]
6917:     fn analyse_no_w304_for_lsearch() {
6918:         // ``lsearch`` does not declare ``--`` either.
6919:         let diags = w304_diags("lsearch -exact $domain c\n");
6920:         assert_eq!(diags.len(), 0, "got {diags:?}");
6921:     }
6922: 
6923:     #[test]
6924:     fn analyse_emits_w304_for_file_delete_variable() {
6925:         // ``file delete`` is subcommand-scoped — profile.scan_start
6926:         // == 1 to skip the ``delete`` keyword.
6927:         let diags = w304_diags("file delete $path\n");
6928:         assert_eq!(diags.len(), 1, "got {diags:?}");
6929:     }
6930: 
6931:     #[test]
6932:     fn analyse_no_w304_for_file_delete_with_terminator() {
6933:         let diags = w304_diags("file delete -- $path\n");
6934:         assert_eq!(diags.len(), 0, "got {diags:?}");
6935:     }
6936: 
6937:     #[test]
6938:     fn analyse_emits_w304_for_load_variable() {
6939:         let diags = w304_diags("load $fileName\n");
6940:         assert_eq!(diags.len(), 1, "got {diags:?}");
6941:     }
6942: 
6943:     #[test]
6944:     fn analyse_w304_constant_propagation_emits_info_with_origin() {
6945:         // ``set X "datagroup"; exec $X`` — the variable resolves to a
6946:         // literal value that doesn't start with `-`, so severity drops
6947:         // to INFO and a second "origin" diagnostic anchors at the
6948:         // literal's range.  (The two-arg braced ``switch $X { ... }``
6949:         // form is exempt from W304 entirely — FP-NAB-05 — so an
6950:         // option-bearing command that still flags is used here.)
6951:         let src = "set totp_key_storage \"datagroup\"\n\
6952:                    exec $totp_key_storage\n";
6953:         let diags = w304_diags(src);
6954:         assert_eq!(diags.len(), 2, "got {diags:?}");
6955: 
6956:         let main = diags
6957:             .iter()
6958:             .find(|d| !d.fixes.is_empty())
6959:             .expect("main diag");
6960:         let origin = diags
6961:             .iter()
6962:             .find(|d| d.fixes.is_empty())
6963:             .expect("origin diag");
6964: 
6965:         assert!(
6966:             matches!(main.severity, crate::analyser::Severity::Suggestion),
6967:             "main severity {:?}",
6968:             main.severity
6969:         );
6970:         assert!(
6971:             main.message.contains("totp_key_storage") && main.message.contains("datagroup"),
6972:             "main message {:?}",
6973:             main.message
6974:         );
6975: 
6976:         let highlighted = &src[main.span.start() as usize..main.span.end() as usize];
6977:         assert_eq!(highlighted, "$totp_key_storage", "got {highlighted:?}");
6978: 
6979:         // The origin diag points at the ``"datagroup"`` literal in
6980:         // the preceding ``set``.
6981:         let origin_text = &src[origin.span.start() as usize..origin.span.end() as usize];
6982:         assert!(
6983:             origin_text.contains("datagroup"),
6984:             "origin span text {origin_text:?}"
6985:         );
6986:     }
6987: 
6988:     #[test]
6989:     fn analyse_w304_constant_propagation_dash_value_warns() {
6990:         // The variable resolves to ``-something`` — escalates to
6991:         // WARNING.
6992:         let src = "set evil \"-rf\"\n\
6993:                    exec $evil /\n";
6994:         let diags = w304_diags(src);
6995:         assert!(!diags.is_empty(), "got {diags:?}");
6996:         let main = diags
6997:             .iter()
6998:             .find(|d| !d.fixes.is_empty())
6999:             .expect("main diag");
7000:         assert!(matches!(main.severity, crate::analyser::Severity::Warning));
7001:     }
7002: 
7003:     // -- W101 eval-string-concat emitter
7004:     //
7005:     // Canonical-list-idiom suppression lives in the registry
7006:     // (``is_canonical_list_command``); substitution-detection
7007:     // approximation lives in the analyser.
7008: 
7009:     fn w101_diags(src: &str) -> Vec<crate::analyser::types::Diagnostic> {
7010:         let mut a = Analyser::new();
7011:         let r = a.analyse(src, "tcl");
7012:         r.diagnostics
7013:             .into_iter()
7014:             .filter(|d| d.code == DiagCode::W101)
7015:             .collect()
7016:     }
7017: 
7018:     #[test]
7019:     fn analyse_emits_w101_for_eval_with_variable() {
7020:         let diags = w101_diags("eval \"puts $x\"\n");
7021:         assert_eq!(diags.len(), 1, "got {diags:?}");
7022:         assert!(
7023:             diags[0].message.to_lowercase().contains("injection"),
7024:             "got {:?}",
7025:             diags[0].message
7026:         );
7027:         assert!(matches!(
7028:             diags[0].severity,
7029:             crate::analyser::Severity::Warning
7030:         ));
7031:     }
7032: 
7033:     #[test]
7034:     fn analyse_no_w101_for_eval_braced_script() {
7035:         let diags = w101_diags("eval {puts hello}\n");
7036:         assert_eq!(diags.len(), 0, "got {diags:?}");
7037:     }
7038: 
7039:     #[test]
7040:     fn analyse_no_w101_for_eval_multiple_braced() {
7041:         let diags = w101_diags("eval {set x 1} {puts $x}\n");
7042:         assert_eq!(diags.len(), 0, "got {diags:?}");
7043:     }
7044: 
7045:     #[test]
7046:     fn analyse_emits_w101_for_eval_with_command_subst() {
7047:         // ``eval [build_cmd]`` — single CMD token, but `build_cmd`
7048:         // isn't a canonical-list-producing command.
7049:         let diags = w101_diags("eval [build_cmd]\n");
7050:         assert_eq!(diags.len(), 1, "got {diags:?}");
7051:     }
7052: 
7053:     #[test]
7054:     fn analyse_no_w101_for_eval_literal_no_substitution() {
7055:         // ``eval puts hello`` — both args are bare literals; no
7056:         // substitution at any level.
7057:         let diags = w101_diags("eval puts hello\n");
7058:         assert_eq!(diags.len(), 0, "got {diags:?}");
7059:     }
7060: 
7061:     #[test]
7062:     fn analyse_no_w101_for_eval_list_idiom() {
7063:         // ``eval [list ...]`` — ``list`` produces a canonical list,
7064:         // safe re-parse.
7065:         let diags = w101_diags("eval [list set $varname $value]\n");
7066:         assert_eq!(diags.len(), 0, "got {diags:?}");
7067:     }
7068: 
7069:     #[test]
7070:     fn analyse_no_w101_for_eval_linsert_idiom() {
7071:         // ``linsert`` returns TclType::List → canonical.
7072:         let diags = w101_diags("eval [linsert $cmdlist 0 extraarg]\n");
7073:         assert_eq!(diags.len(), 0, "got {diags:?}");
7074:     }
7075: 
7076:     #[test]
7077:     fn analyse_no_w101_for_eval_split_idiom() {
7078:         let diags = w101_diags("eval [split $line :]\n");
7079:         assert_eq!(diags.len(), 0, "got {diags:?}");
7080:     }
7081: 
7082:     #[test]
7083:     fn analyse_emits_w101_for_eval_concat_idiom() {
7084:         // ``concat`` is the explicit non-canonical exclusion —
7085:         // strips one level of grouping, not safe for re-parse.
7086:         let diags = w101_diags("eval [concat $script $args]\n");
7087:         assert_eq!(diags.len(), 1, "got {diags:?}");
7088:     }
7089: 
7090:     #[test]
7091:     fn analyse_no_w101_for_non_eval_commands() {
7092:         // The emitter is gated on ``cmd_name == "eval"`` — other
7093:         // substitution-bearing commands are handled elsewhere (W301
7094:         // covers uplevel; W312 covers interp eval).
7095:         let diags = w101_diags("uplevel 1 \"puts $x\"\n");
7096:         assert_eq!(diags.len(), 0, "got {diags:?}");
7097:     }
7098: 
7099:     #[test]
7100:     fn analyse_w101_anchors_at_first_arg_token() {
7101:         let src = "eval \"puts $x\"\n";
7102:         let diags = w101_diags(src);
7103:         assert_eq!(diags.len(), 1);
7104:         let span = diags[0].span;
7105:         let text = &src[span.start() as usize..span.end() as usize];
7106:         // First arg is the quoted string ``"puts $x"`` — the
7107:         // representative token's span anchors the diagnostic.
7108:         assert!(text.contains("puts") || text.contains("$x"), "got {text:?}");
7109:     }
7110: 
7111:     #[test]
7112:     fn analyse_w101_rejects_multi_command_subscript() {
7113:         // ``[list a; set x $user]`` — multi-command script can't be
7114:         // proven safe (last command's result wins, and that's
7115:         // ``set``, not ``list``).
7116:         let diags = w101_diags("eval [list a\\; set x $user]\n");
7117:         assert_eq!(diags.len(), 1, "got {diags:?}");
7118:     }
7119: 
7120:     #[test]
7121:     fn analyse_no_w101_for_eval_literal_multi_token_word() {
7122:         // ``eval foo{bar}`` is a multi-token word (Esc + Str joined,
7123:         // ``single_token_word == false``) that contains no Var/Cmd
7124:         // substitution — W101 only fires on actual VAR/CMD tokens, so
7125:         // this must not trigger it.  The check is a brace/backslash-aware
7126:         // source-byte scan that looks for unescaped ``$`` / ``[``
7127:         // outside ``{...}``.
7128:         let diags = w101_diags("eval foo{bar}\n");
7129:         assert_eq!(diags.len(), 0, "got {diags:?}");
7130:     }
7131: 
7132:     #[test]
7133:     fn analyse_no_w101_for_eval_backslash_escaped_dollar() {
7134:         // ``eval "no\$x"`` — the ``\$`` is a backslash-escape, so
7135:         // the lexer produces a single ESC token with no Var.  The
7136:         // word-span scan must skip the next byte after ``\`` to
7137:         // avoid mis-detecting the literal ``$``.
7138:         let diags = w101_diags("eval no\\$x\n");
7139:         assert_eq!(diags.len(), 0, "got {diags:?}");
7140:     }
7141: 
7142:     #[test]
7143:     fn analyse_w304_code_fix_inserts_terminator() {
7144:         let src = "exec $cmd\n";
7145:         let diags = w304_diags(src);
7146:         assert_eq!(diags.len(), 1, "got {diags:?}");
7147:         let fix = diags[0]
7148:             .fixes
7149:             .first()
7150:             .expect("expected an insert-terminator fix");
7151:         let mut applied = src.to_string();
7152:         let start = fix.span.start() as usize;
7153:         let end = fix.span.end() as usize;
7154:         applied.replace_range(start..end, &fix.new_text);
7155:         assert_eq!(applied, "exec -- $cmd\n", "got {applied:?}");
7156:     }
7157: 
7158:     // -- body-walk and nested-cmd recovery
7159:     //
7160:     // Verify ``when EVENT { body }`` recurses (the registry
7161:     // ``arg_role_resolver`` records BODY at the last index)
7162:     // and that braced expr args (``Str`` tokens) have their
7163:     // outer braces unwrapped before the nested-``[cmd]`` scan
7164:     // (otherwise the scanner skips the entire braced region
7165:     // opaquely).
7166: 
7167:     #[test]
7168:     fn compound_cmd_word_descends_substitution_fragments_only() {
7169:         // A command substitution that is the *first* fragment of a
7170:         // compound word (`[foo]bar`, `[foo]$x`) merges with the trailing
7171:         // literal into one argv token spanning the whole word.  The
7172:         // nested-invocation recorder must descend only the `[…]`
7173:         // fragment(s) — not the merged span — so it records the real
7174:         // inner head (`foo`) rather than a bogus one (`foo]bar`).
7175:         type Inv = (&'static str, u32, u32);
7176:         let cases: &[(&str, &[Inv])] = &[
7177:             ("puts [foo]bar\n", &[("foo", 6, 9)]),
7178:             ("set x [foo]$suffix\n", &[("foo", 7, 10)]),
7179:             // Substitution as the command head of a compound word.
7180:             ("[foo]bar hi\n", &[("foo", 1, 4)]),
7181:             // Two substitutions in one word — both must be found.
7182:             ("puts [foo]bar[baz]\n", &[("foo", 6, 9), ("baz", 14, 17)]),
7183:             // `;`-separated commands inside a compound substitution.
7184:             ("puts [aa; bb]cc\n", &[("aa", 6, 8), ("bb", 10, 12)]),
7185:         ];
7186:         for (src, expected) in cases {
7187:             let mut a = Analyser::new();
7188:             let r = a.analyse(src, "f5-irules");
7189:             let got: Vec<(String, u32, u32)> = r
7190:                 .command_invocations
7191:                 .iter()
7192:                 .map(|c| (c.name.clone(), c.range.start(), c.range.end()))
7193:                 .collect();
7194:             for &(name, start, end) in *expected {
7195:                 assert!(
7196:                     got.iter()
7197:                         .any(|(n, s, e)| n == name && *s == start && *e == end),
7198:                     "src {src:?}: expected ({name:?}, {start}, {end}) in {got:?}",
7199:                 );
7200:             }
7201:             // No over-read: a *descended* substitution head must never
7202:             // carry the literal suffix after the matching `]` (`foo]bar`,
7203:             // `foo]${suffix}`).  A whole-word head recorded verbatim by
7204:             // `process_command` (`[foo]bar`) legitimately starts with `[`
7205:             // and is excluded.
7206:             assert!(
7207:                 !got.iter()
7208:                     .any(|(n, _, _)| n.contains(']') && !n.starts_with('[')),
7209:                 "src {src:?}: a descended head leaked the literal suffix (over-read): {got:?}",
7210:             );
7211:         }
7212:     }
7213: 
7214:     #[test]
7215:     fn analyse_when_body_records_inner_command_invocations() {
7216:         // ``when HTTP_REQUEST { body }`` — ``call`` and the
7217:         // target ``myhelper`` should appear in
7218:         // ``command_invocations`` from the body recursion.
7219:         let mut a = Analyser::new();
7220:         let r = a.analyse(
7221:             "proc myhelper {} {}\nwhen HTTP_REQUEST { call myhelper }\n",
7222:             "f5-irules",
7223:         );
7224:         let names: Vec<&str> = r
7225:             .command_invocations
7226:             .iter()
7227:             .map(|c| c.name.as_str())
7228:             .collect();
7229:         assert!(names.contains(&"call"), "got {names:?}");
7230:         assert!(names.contains(&"myhelper"), "got {names:?}");
7231:     }
7232: 
7233:     #[test]
7234:     fn analyse_braced_expr_arg_records_inner_substitution() {
7235:         // ``if { [HTTP::uri] eq "/foo" } { ... }`` — the
7236:         // ``[HTTP::uri]`` substitution inside the braced expr
7237:         // arg must surface in ``command_invocations``.  Without
7238:         // the ``Str`` unwrap, the nested-cmd scanner sees the
7239:         // outer ``{`` and skips the entire braced region
7240:         // opaquely.
7241:         let mut a = Analyser::new();
7242:         let r = a.analyse("if { [HTTP::uri] eq \"/foo\" } { puts ok }\n", "f5-irules");
7243:         let names: Vec<&str> = r
7244:             .command_invocations
7245:             .iter()
7246:             .map(|c| c.name.as_str())
7247:             .collect();
7248:         assert!(names.contains(&"HTTP::uri"), "got {names:?}");
7249:     }
7250: 
7251:     #[test]
7252:     fn analyse_records_every_command_in_a_substitution() {
7253:         // A command substitution can hold more than one command (`;`- /
7254:         // newline-separated), and substitutions nest.  The CST descent
7255:         // records every inner command head (`set x [foo; bar]` ->
7256:         // {foo, bar, set}).
7257:         // A head is recorded in `word_piece` form for every command,
7258:         // incl. a `$var` head (`${var}`), a `"quoted"` head (unquoted),
7259:         // and a compound head (`set x [$cmd a; bar]` -> {${cmd}, bar,
7260:         // set}).
7261:         let cases: &[(&str, &[&str])] = &[
7262:             ("set x [foo; bar]\n", &["set", "foo", "bar"]),
7263:             ("puts [a; b; c]\n", &["puts", "a", "b", "c"]),
7264:             ("set x [foo [bar; baz]]\n", &["set", "foo", "bar", "baz"]),
7265:             ("set x [foo $y; bar]\n", &["set", "foo", "bar"]),
7266:             ("set x [$cmd a; bar]\n", &["set", "${cmd}", "bar"]),
7267:             ("set x [foo; $y arg]\n", &["set", "foo", "${y}"]),
7268:             ("set x [\"q\" a; bar]\n", &["set", "q", "bar"]),
7269:             // A control-flow command inside a substitution has body
7270:             // arguments whose commands are inner invocations too
7271:             // (descend_command resolves them via the registry).
7272:             // `[if {$c} {puts hi}]` -> {if, puts}.
7273:             ("set x [if {$c} {puts hi}]\n", &["set", "if", "puts"]),
7274:             (
7275:                 "set x [foreach a $l {log $a}]\n",
7276:                 &["set", "foreach", "log"],
7277:             ),
7278:             ("set x [eval {one; two}]\n", &["set", "eval", "one", "two"]),
7279:             // A command substitution inside an *expr* argument of a
7280:             // command nested in a substitution is an invocation too
7281:             // (collect_expr_substitutions). `[if {[check]} {fwd}]`
7282:             // -> {if, check, fwd}; `[expr {[bar] + 1}]` -> {expr, bar}.
7283:             (
7284:                 "set x [if {[check]} {fwd}]\n",
7285:                 &["set", "if", "check", "fwd"],
7286:             ),
7287:             ("set x [expr {[bar] + 1}]\n", &["set", "expr", "bar"]),
7288:             (
7289:                 "set x [while {[cond]} {act}]\n",
7290:                 &["set", "while", "cond", "act"],
7291:             ),
7292:             // argv_texts[0] is recorded for every command, incl. a
7293:             // `[subst]` head (recorded *and* descended) and a `{braced}`
7294:             // head (its inner text).
7295:             ("set x [[gen] arg]\n", &["set", "[gen]", "gen"]),
7296:             ("puts [[a] [b]]\n", &["puts", "[a]", "a", "b"]),
7297:         ];
7298:         for (src, expected) in cases {
7299:             let mut a = Analyser::new();
7300:             let r = a.analyse(src, "tcl8.6");
7301:             let names: Vec<&str> = r
7302:                 .command_invocations
7303:                 .iter()
7304:                 .map(|c| c.name.as_str())
7305:                 .collect();
7306:             for want in *expected {
7307:                 assert!(
7308:                     names.contains(want),
7309:                     "{src:?}: missing {want:?}, got {names:?}"
7310:                 );
7311:             }
7312:         }
7313:     }
7314: 
7315:     #[test]
7316:     fn analyse_records_switch_arm_bodies_not_patterns() {
7317:         // The `switch … {pat body …}` list-form arg is a Tcl *list*,
7318:         // not a script.  The arm *bodies* are scripts (their commands
7319:         // are invocations), but the *patterns* are not — descending
7320:         // the whole list as a script would mis-record a pattern
7321:         // (`a`/`b`) as a command head.  Parse the pairs and descend
7322:         // each body.  A `default` keyword / `-` fall-through is a
7323:         // pattern, not a body.  Result: {cmd1, cmd2, set, switch}.
7324:         let mut a = Analyser::new();
7325:         let r = a.analyse("set x [switch $v {a {cmd1} b {cmd2}}]\n", "tcl8.6");
7326:         let names: Vec<&str> = r
7327:             .command_invocations
7328:             .iter()
7329:             .map(|c| c.name.as_str())
7330:             .collect();
7331:         assert!(names.contains(&"switch"), "got {names:?}");
7332:         assert!(names.contains(&"cmd1"), "arm body missing: {names:?}");
7333:         assert!(names.contains(&"cmd2"), "arm body missing: {names:?}");
7334:         assert!(
7335:             !names.contains(&"a"),
7336:             "pattern recorded as command: {names:?}"
7337:         );
7338:         assert!(
7339:             !names.contains(&"b"),
7340:             "pattern recorded as command: {names:?}"
7341:         );
7342:     }
7343: 
7344:     #[test]
7345:     fn analyse_braced_data_word_is_not_over_recorded() {
7346:         // A `[...]` inside a braced *data* word is literal (braces
7347:         // suppress substitution), so it must not be recorded — only an
7348:         // *expr* arg's substitutions are.  And a command whose name is
7349:         // itself a substitution (`[x] hi`) must still be descended (the
7350:         // head token is iterated too).
7351:         let cases: &[(&str, &[&str], &[&str])] = &[
7352:             // (source, must-contain, must-NOT-contain)
7353:             ("set x {[noeval]}\n", &["set"], &["noeval"]),
7354:             ("set d {literal data}\n", &["set"], &["data", "literal"]),
7355:             ("proc p {} {[x] hi}\n", &["proc", "x"], &[]),
7356:             ("if {[chk]} {puts ok}\n", &["if", "chk", "puts"], &[]),
7357:         ];
7358:         for (src, want, unwant) in cases {
7359:             let mut a = Analyser::new();
7360:             let r = a.analyse(src, "tcl8.6");
7361:             let names: Vec<&str> = r
7362:                 .command_invocations
7363:                 .iter()
7364:                 .map(|c| c.name.as_str())
7365:                 .collect();
7366:             for w in *want {
7367:                 assert!(names.contains(w), "{src:?}: missing {w:?}, got {names:?}");
7368:             }
7369:             for u in *unwant {
7370:                 assert!(
7371:                     !names.contains(u),
7372:                     "{src:?}: over-recorded {u:?}, got {names:?}"
7373:                 );
7374:             }
7375:         }
7376:     }
7377: 
7378:     #[test]
7379:     fn analyse_regexp_var_added_to_regex_vars_set() {
7380:         // Side effect: the var name is recorded in
7381:         // ``regex_vars`` so downstream consumers (var-as-regex
7382:         // hint, future W*-codes) can find the defining set.
7383:         let mut a = Analyser::new();
7384:         let _ = a.analyse("set p {^foo}\nregexp $p $line\n", "tcl");
7385:         // The const-string scope is the global scope (path = []).
7386:         assert!(a.regex_vars.contains(&(Vec::new(), "p".to_string())));
7387:     }
7388: 
7389:     #[test]
7390:     fn analyse_alias_with_prepended_args_recorded() {
7391:         // Prepended args after the target are stored on
7392:         // ``extras``.
7393:         let mut a = Analyser::new();
7394:         let r = a.analyse("interp alias {} logerr {} puts stderr\n", "tcl");
7395:         let alias = r
7396:             .command_aliases
7397:             .get("::logerr")
7398:             .expect("::logerr recorded");
7399:         assert_eq!(alias.target, "puts");
7400:         assert_eq!(alias.extras.as_slice(), &["stderr"]);
7401:     }
7402: 
7403:     #[test]
7404:     fn analyse_tcllib_import_wrapper_does_not_fire_on_namespace_import() {
7405:         // The wrapper detector must not trip on Tcl's own
7406:         // ``namespace import`` — that's handled by
7407:         // ``handle_namespace_import_command`` and is never
7408:         // conjectured.
7409:         let mut a = Analyser::new();
7410:         let r = a.analyse("namespace import ::foo::bar\n", "tcl");
7411:         assert!(r.namespace_imports.iter().all(|i| !i.conjectured));
7412:     }
7413: 
7414:     #[test]
7415:     fn analyse_chunked_seeds_file_suppression_minus_one_sentinel() {
7416:         // ``analyse`` populates ``result.suppressed_lines[-1]`` with
7417:         // the file-level ``# tcl-lsp: disable=`` set; verify
7418:         // ``analyse_chunked`` does the same so consumers see the
7419:         // file-wide directives via the same surface regardless of
7420:         // which entry point dispatched.
7421:         use crate::segmenter::SegmentedCommand;
7422:         let mut a = Analyser::new();
7423:         let cmds: Vec<Vec<SegmentedCommand>> = vec![Vec::new()];
7424:         let (r, _) = a.analyse_chunked("# tcl-lsp: disable=W210,W211\nset x 1\n", cmds, "tcl");
7425:         let codes = r.suppressed_lines.get(&-1).expect("-1 sentinel");
7426:         assert!(codes.contains("W210"));
7427:         assert!(codes.contains("W211"));
7428:     }
7429: 
7430:     #[test]
7431:     fn analyse_commands_seeds_file_suppression_minus_one_sentinel() {
7432:         // Same assertion through ``analyse_commands`` — the
7433:         // snapshot-restore entry point.
7434:         use crate::segmenter::SegmentedCommand;
7435:         let mut a = Analyser::new();
7436:         let cmds: Vec<SegmentedCommand> = Vec::new();
7437:         let r = a.analyse_commands(
7438:             "# tcl-lsp: disable=W210,W211\nset x 1\n",
7439:             &cmds,
7440:             "tcl",
7441:             true,
7442:         );
7443:         let codes = r.suppressed_lines.get(&-1).expect("-1 sentinel");
7444:         assert!(codes.contains("W210"));
7445:         assert!(codes.contains("W211"));
7446:     }
7447: 
7448:     // Incremental analysis differential oracle
7449: 
7450:     /// A projection of `AnalysisResult` capturing the observable
7451:     /// identity an incremental analysis must preserve: sorted
7452:     /// `(code, start, end)` diagnostics, proc names, global vars, and
7453:     /// `(invocation name, start)` pairs.
7454:     type ResultProjection = (
7455:         Vec<(String, u32, u32)>,
7456:         Vec<String>,
7457:         Vec<String>,
7458:         Vec<(String, u32)>,
7459:     );
7460: 
7461:     fn project_result(r: &AnalysisResult) -> ResultProjection {
7462:         let mut diags: Vec<_> = r
7463:             .diagnostics
7464:             .iter()
7465:             .map(|d| (d.code.to_string(), d.span.start(), d.span.end()))
7466:             .collect();
7467:         diags.sort();
7468:         let mut procs: Vec<_> = r.all_procs.keys().cloned().collect();
7469:         procs.sort();
7470:         let mut vars: Vec<_> = r.global_scope.variables.keys().cloned().collect();
7471:         vars.sort();
7472:         let mut invs: Vec<_> = r
7473:             .command_invocations
7474:             .iter()
7475:             .map(|i| (i.name.clone(), i.range.start()))
7476:             .collect();
7477:         invs.sort();
7478:         (diags, procs, vars, invs)
7479:     }
7480: 
7481:     struct IncrLcg(u64);
7482:     impl IncrLcg {
7483:         fn next_u32(&mut self) -> u32 {
7484:             self.0 = self
7485:                 .0
7486:                 .wrapping_mul(6_364_136_223_846_793_005)
7487:                 .wrapping_add(1);
7488:             (self.0 >> 33) as u32
7489:         }
7490:     }
7491: 
7492:     #[test]
7493:     #[ignore = "seeded edit-storm oracle (350 edit/analyse pairs); the deterministic \
7494:                 incremental gates stay in CI — the *_incremental_matches_fresh* family \
7495:                 and per_item_corpus::per_item_matches_analyse_over_repo_samples; \
7496:                 run explicitly with --ignored"]
7497:     fn analyse_incremental_matches_full_under_fuzz() {
7498:         // The acceptance gate: a random edit applied to a base document,
7499:         // then `analyse_incremental` must produce a result observably
7500:         // identical to a full `analyse` of the edited text — diagnostics,
7501:         // procs, globals, and recorded command invocations all match.
7502:         let bases = [
7503:             "set x 1\nputs hi\nproc p {} { return 1 }\np\nset y 2\n",
7504:             "namespace eval n {\n  variable v 1\n  proc q {} { return $v }\n}\nn::q\n",
7505:             "if {$a} {\n  puts a\n} else {\n  puts b\n}\nset z 3\nfoo $undef\n",
7506:             "proc add {a b} { return [expr {$a + $b}] }\nputs [add 1 2]\nset s {x y z}\n",
7507:             "set i 0\nwhile {$i < 10} { incr i }\nputs done\n# trailing comment\n",
7508:         ];
7509:         let inserts = [
7510:             "",
7511:             "z",
7512:             "puts Z\n",
7513:             "set q 9\n",
7514:             " ",
7515:             "\n",
7516:             "x",
7517:             "proc r {} {}\n",
7518:             "incr i\n",
7519:             "1",
7520:         ];
7521:         let mut rng = IncrLcg(0xD1FF_ACE5_1234_9876);
7522:         let mut checked = 0usize;
7523:         for base in bases {
7524:             let prev_cmds = crate::segmenter::segment_commands(base);
7525:             let blen = base.len();
7526:             for _ in 0..70 {
7527:                 let mut s = (rng.next_u32() as usize) % (blen + 1);
7528:                 while !base.is_char_boundary(s) {
7529:                     s -= 1;
7530:                 }
7531:                 let mut e = s + (rng.next_u32() as usize) % (blen + 1 - s);
7532:                 while !base.is_char_boundary(e) {
7533:                     e += 1;
7534:                 }
7535:                 let ins = inserts[(rng.next_u32() as usize) % inserts.len()];
7536:                 let new = format!("{}{}{}", &base[..s], ins, &base[e..]);
7537: 
7538:                 let mut af = Analyser::new();
7539:                 let full = af.analyse(&new, "tcl8.6");
7540:                 let mut ai = Analyser::new();
7541:                 let inc = ai.analyse_incremental(base, &prev_cmds, &new, "tcl8.6");
7542:                 assert_eq!(
7543:                     project_result(&inc),
7544:                     project_result(&full),
7545:                     "incremental != full for base {base:?} edit [{s},{e}) ins {ins:?} -> {new:?}",
7546:                 );
7547:                 checked += 1;
7548:             }
7549:         }
7550:         assert!(checked > 300, "fuzz corpus too small: {checked}");
7551:     }
7552: 
7553:     #[test]
7554:     fn analyse_incremental_falls_back_on_incomplete_and_stubs() {
7555:         let base = "set x 1\nputs hi\n";
7556:         let prev = crate::segmenter::segment_commands(base);
7557:         // Incomplete (unterminated brace) -> full-analyse fallback, still
7558:         // identical to a direct full analyse.
7559:         let incomplete = "set x 1\nproc p {} {\n";
7560:         let mut ai = Analyser::new();
7561:         let inc = ai.analyse_incremental(base, &prev, incomplete, "tcl8.6");
7562:         let mut af = Analyser::new();
7563:         let full = af.analyse(incomplete, "tcl8.6");
7564:         assert_eq!(project_result(&inc), project_result(&full));
7565:         // Stub directive -> fallback path.
7566:         let stubbed = "# tcl-lsp: stub mycmd\nmycmd a b\n";
7567:         let mut ai2 = Analyser::new();
7568:         let inc2 = ai2.analyse_incremental(base, &prev, stubbed, "tcl8.6");
7569:         let mut af2 = Analyser::new();
7570:         let full2 = af2.analyse(stubbed, "tcl8.6");
7571:         assert_eq!(project_result(&inc2), project_result(&full2));
7572:     }
7573: }
