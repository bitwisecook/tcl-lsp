/* ORIGINAL_SOURCE_RANGE 4373..4390 */
4373: #[cfg(test)]
4374: pub(super) fn apply_oo_subcommand(
4375:     grammar: &DefinitionBodyGrammar,
4376:     texts: &[String],
4377:     argv: &[Token],
4378:     class_def: &mut ClassDef,
4379: ) {
4380:     apply_oo_subcommand_in(
4381:         grammar,
4382:         texts,
4383:         argv,
4384:         class_def,
4385:         MemberDialect {
4386:             surface: None,
4387:             rules: WordValueRules::TCL,
4388:         },
4389:     );
4390: }
/* ORIGINAL_SOURCE_RANGE 4643..4664 */
4643: #[cfg(test)]
4644: fn extract_method_def(
4645:     member: &MemberSpec,
4646:     args: &[String],
4647:     arg_tokens: &[Token],
4648:     kind: &str,
4649:     visibility: &str,
4650:     synthetic_name: &str,
4651: ) -> Option<MethodDef> {
4652:     extract_method_def_in(
4653:         member,
4654:         args,
4655:         arg_tokens,
4656:         kind,
4657:         visibility,
4658:         synthetic_name,
4659:         MemberDialect {
4660:             surface: None,
4661:             rules: WordValueRules::TCL,
4662:         },
4663:     )
4664: }
/* ORIGINAL_SOURCE_RANGE 4719..9168 */
4719: #[cfg(test)]
4720: mod tests {
4721:     use super::*;
4722:     use crate::analyser::types::MemberRetractionRecord;
4723: 
4724:     #[test]
4725:     fn original_receiver_declaration_keeps_its_whole_parent_bom_configuration() {
4726:         // naming.tcloo.original-source-receiver-body-declaration
4727:         // docs/design/analysis/name-resolution-proofs/tcloo-original-source-receiver-body-declaration.md
4728:         // Source declaration body only; no allocated class or entered method.
4729:         fn bodies(
4730:             scope: &Scope,
4731:         ) -> Vec<&super::super::types::OriginalSourceReceiverBodyDeclaration> {
4732:             scope
4733:                 .original_receiver_body_declaration
4734:                 .iter()
4735:                 .map(AsRef::as_ref)
4736:                 .chain(scope.children.iter().flat_map(bodies))
4737:                 .collect()
4738:         }
4739:         let body = "interp create -safe s; interp eval s {oo::class create C {method m {} {source a.tcl}}}";
4740:         let mut prepared = Analyser::new();
4741:         let input = prepared.prepare_analysis_input("tcl9.1").unwrap();
4742:         let source = format!("\u{feff}{body}");
4743:         let result = Analyser::new().analyse(&source, "tcl9.1");
4744:         let declarations = bodies(&result.global_scope);
4745:         assert_eq!(declarations.len(), 1, "{:?}", result.diagnostics);
4746:         assert!(declarations[0].matches_source(&tcl_lexer::SourceImage::document(&source), &input));
4747:         for bom in [tcl_lexer::LeadingBom::Skip, tcl_lexer::LeadingBom::Content] {
4748:             let mut supplied = input.clone();
4749:             supplied.config.leading_bom = bom;
4750:             let result = Analyser::new()
4751:                 .with_resolved_input(supplied.clone())
4752:                 .analyse(body, "display-only");
4753:             let declarations = bodies(&result.global_scope);
4754:             assert_eq!(declarations.len(), 1, "{bom:?}: {:?}", result.diagnostics);
4755:             let original = declarations[0];
4756:             let image = tcl_lexer::SourceImage::document(body);
4757:             assert!(original.matches_source(&image, &supplied));
4758:             assert_eq!(original.body_word().config(), supplied.lexer_config());
4759:             assert_eq!(original.parameters_word().config(), supplied.lexer_config());
4760:             let commands = tcl_lexer::native_script_words_in(
4761:                 image.clone(),
4762:                 original.body_word().content_span().unwrap(),
4763:                 supplied.lexer_config(),
4764:             )
4765:             .unwrap();
4766:             assert!(original.owns_invocation(&commands.commands[0].words, &supplied));
4767:             assert!(!original.matches_source(
4768:                 &tcl_lexer::SourceImage::document(&(body.to_owned() + "\n")),
4769:                 &supplied
4770:             ));
4771:             let mut stale = supplied.clone();
4772:             stale.config.strict_quoting = !stale.config.strict_quoting;
4773:             assert!(!original.matches_source(&image, &stale));
4774:             let mut foreign = supplied.clone();
4775:             foreign.context = std::sync::Arc::new(
4776:                 supplied
4777:                     .context
4778:                     .with_command_store(std::sync::Arc::clone(supplied.context.commands())),
4779:             );
4780:             assert!(!original.matches_source(&image, &foreign));
4781:         }
4782:     }
4783: 
4784:     #[test]
4785:     fn logical_method_name_operands_require_selected_original_named_members() {
4786:         let source = "oo::class create C {method {$literal} {} {}; self method {with space} {} {}; method known $formals {}; constructor {} {}; foreach n {generated} {method $n {} {}}; method {*}{expanded} {} {}}";
4787:         let analysis = Analyser::new().analyse(source, "tcl");
4788:         let class = &analysis.all_classes["::C"];
4789:         let input = analysis.resolved_input.as_ref().unwrap();
4790:         let image = analysis
4791:             .retained_command_realm()
4792:             .unwrap()
4793:             .original_source_image()
4794:             .unwrap();
4795:         for (side, method) in [
4796:             (MemberSide::Instance, &class.methods["$literal"]),
4797:             (MemberSide::Instance, &class.methods["known"]),
4798:             (MemberSide::ClassObject, &class.class_methods["with space"]),
4799:         ] {
4800:             let word = class
4801:                 .original_members
4802:                 .logical_name_operand(side, method, input, image)
4803:                 .unwrap();
4804:             assert_eq!(
4805:                 tcl_syntax::word_rules::original_static_word_ascii_presentation(word).unwrap(),
4806:                 method.name.as_bytes(),
4807:             );
4808:             assert!(
4809:                 class
4810:                     .original_members
4811:                     .logical_name_operand(
4812:                         match side {
4813:                             MemberSide::Instance => MemberSide::ClassObject,
4814:                             MemberSide::ClassObject => MemberSide::Instance,
4815:                         },
4816:                         method,
4817:                         input,
4818:                         image,
4819:                     )
4820:                     .is_none()
4821:             );
4822:             let mut changed = method.clone();
4823:             changed.name_span = tcl_lexer::Span::new(0, 1);
4824:             assert!(
4825:                 class
4826:                     .original_members
4827:                     .logical_name_operand(side, &changed, input, image)
4828:                     .is_none()
4829:             );
4830:             let foreign = tcl_lexer::SourceImage::document("different source");
4831:             assert!(
4832:                 class
4833:                     .original_members
4834:                     .logical_name_operand(side, method, input, &foreign)
4835:                     .is_none()
4836:             );
4837:             let mut changed_input = input.clone();
4838:             changed_input.unit_profile = Analyser::new()
4839:                 .analyse(source, "tcl8.6")
4840:                 .resolved_input
4841:                 .unwrap()
4842:                 .unit_profile;
4843:             assert!(
4844:                 class
4845:                     .original_members
4846:                     .logical_name_operand(side, method, &changed_input, image)
4847:                     .is_none()
4848:             );
4849:         }
4850:         assert!(
4851:             class
4852:                 .original_members
4853:                 .logical_name_operand(MemberSide::Instance, &class.constructors[0], input, image)
4854:                 .is_none()
4855:         );
4856:         for name in ["generated", "expanded"] {
4857:             let method = &class.methods[name];
4858:             assert!(
4859:                 class
4860:                     .original_members
4861:                     .logical_name_operand(MemberSide::Instance, method, input, image)
4862:                     .is_none()
4863:             );
4864:         }
4865:     }
4866: 
4867:     #[test]
4868:     fn logical_method_name_roles_follow_the_selected_family_grammar() {
4869:         for source in [
4870:             "snit::type C {method {two words} {} {}}",
4871:             "itcl::class C {method {two words} {} {}}",
4872:         ] {
4873:             let analysis = Analyser::new().analyse(source, "tcl");
4874:             let class = &analysis.all_classes["::C"];
4875:             let method = &class.methods["two words"];
4876:             let input = analysis.resolved_input.as_ref().unwrap();
4877:             let image = analysis
4878:                 .retained_command_realm()
4879:                 .unwrap()
4880:                 .original_source_image()
4881:                 .unwrap();
4882:             let word = class
4883:                 .original_members
4884:                 .logical_name_operand(MemberSide::Instance, method, input, image)
4885:                 .unwrap();
4886:             assert_eq!(
4887:                 tcl_syntax::word_rules::original_static_word_ascii_presentation(word).unwrap(),
4888:                 b"two words"
4889:             );
4890:         }
4891:     }
4892: 
4893:     #[test]
4894:     fn logical_member_opacity_uses_selected_name_words_instead_of_literal_sigils() {
4895:         let source = "oo::class create C {method {$literal} {} {}; method {${literal}} {} {}}";
4896:         let analysis = Analyser::new().analyse(source, "tcl");
4897:         let class = &analysis.all_classes["::C"];
4898:         assert!(class.methods.contains_key("$literal"));
4899:         assert!(class.methods.contains_key("${literal}"));
4900:         assert!(!class.member_set_incomplete);
4901:         let unsupported =
4902:             Analyser::new().analyse("oo::class create C {method {nul\0name} {} {}}", "tcl");
4903:         let class = &unsupported.all_classes["::C"];
4904:         assert!(class.methods.contains_key("nul\0name"));
4905:         assert!(class.member_set_incomplete);
4906:         for body in [
4907:             "method $computed {} {}",
4908:             "method {*}$parts",
4909:             "method {*}{expanded} {} {}",
4910:         ] {
4911:             let source = format!("oo::class create C {{{body}}}");
4912:             let analysis = Analyser::new().analyse(&source, "tcl");
4913:             let class = &analysis.all_classes["::C"];
4914:             assert!(class.member_set_incomplete);
4915:             assert!(class.methods.values().all(|method| {
4916:                 class
4917:                     .original_members
4918:                     .logical_name_operand(
4919:                         MemberSide::Instance,
4920:                         method,
4921:                         analysis.resolved_input.as_ref().unwrap(),
4922:                         analysis
4923:                             .retained_command_realm()
4924:                             .unwrap()
4925:                             .original_source_image()
4926:                             .unwrap(),
4927:                     )
4928:                     .is_none()
4929:             }));
4930:         }
4931:     }
4932: 
4933:     #[test]
4934:     fn logical_member_name_ingress_refuses_reconstructed_wrapper_vectors() {
4935:         let source = "oo::class create C {self {method m {} {}}}";
4936:         let analysis = Analyser::new().analyse(source, "tcl");
4937:         let class = &analysis.all_classes["::C"];
4938:         let input = analysis.resolved_input.as_ref().unwrap();
4939:         let image = analysis
4940:             .retained_command_realm()
4941:             .unwrap()
4942:             .original_source_image()
4943:             .unwrap();
4944:         assert!(
4945:             class
4946:                 .original_members
4947:                 .logical_name_operand(
4948:                     MemberSide::ClassObject,
4949:                     &class.class_methods["m"],
4950:                     input,
4951:                     image
4952:                 )
4953:                 .is_none()
4954:         );
4955: 
4956:         let direct_source = "oo::class create C {method m {} {}}";
4957:         let mut analyser = Analyser::new();
4958:         let analysis = analyser
4959:             .analyse_and_retain_result_for_test(direct_source, "tcl")
4960:             .clone();
4961:         let mut class = analysis.all_classes["::C"].clone();
4962:         class.original_members = Default::default();
4963:         let current = &analysis.all_classes["::C"];
4964:         let actual_input = analysis.resolved_input.as_ref().unwrap();
4965:         let actual_image = analysis
4966:             .retained_command_realm()
4967:             .unwrap()
4968:             .original_source_image()
4969:             .unwrap();
4970:         let outer = crate::segmenter::segment_commands_with_offset_and_config(
4971:             direct_source,
4972:             0,
4973:             actual_input.lexer_config(),
4974:         );
4975:         let [outer] = outer.as_slice() else {
4976:             panic!("one authentic original class command")
4977:         };
4978:         let groups = tcl_lexer::group_commands_bytes(
4979:             &outer.all_tokens,
4980:             actual_image.bytes(),
4981:             actual_input.lexer_config(),
4982:         );
4983:         let body_group = &groups[0].words[3];
4984:         assert_eq!(body_group.span, current.body_span);
4985:         let body = tcl_lexer::NativeWord::from_group(
4986:             actual_image.clone(),
4987:             actual_input.lexer_config(),
4988:             &outer.all_tokens,
4989:             body_group,
4990:         )
4991:         .unwrap();
4992:         let content = crate::registry_invocation::original_written_script_body_span(&body).unwrap();
4993:         let commands = crate::segmenter::segment_commands_with_offset_and_config(
4994:             &direct_source[content.as_range()],
4995:             content.start(),
4996:             actual_input.lexer_config().nested(),
4997:         );
4998:         let mut command = commands
4999:             .into_iter()
5000:             .find(|command| command.name() == "method")
5001:             .unwrap();
5002:         analyser.retain_logical_member_name_operand(
5003:             &tcl_registry::definer::TCLOO_GRAMMAR,
5004:             &command,
5005:             &mut class,
5006:         );
5007:         let actual_input = analysis.resolved_input.as_ref().unwrap();
5008:         let actual_image = analysis
5009:             .retained_command_realm()
5010:             .unwrap()
5011:             .original_source_image()
5012:             .unwrap();
5013:         assert!(
5014:             class
5015:                 .original_members
5016:                 .logical_name_operand(
5017:                     MemberSide::Instance,
5018:                     &class.methods["m"],
5019:                     actual_input,
5020:                     actual_image
5021:                 )
5022:                 .is_some()
5023:         );
5024:         class.original_members = Default::default();
5025:         command.argv[2] = command.argv[1];
5026:         assert!(analyser.member_declaration_is_opaque(
5027:             &tcl_registry::definer::TCLOO_GRAMMAR,
5028:             &command,
5029:             &command.texts,
5030:         ));
5031:         analyser.retain_logical_member_name_operand(
5032:             &tcl_registry::definer::TCLOO_GRAMMAR,
5033:             &command,
5034:             &mut class,
5035:         );
5036:         let actual_input = analysis.resolved_input.as_ref().unwrap();
5037:         let actual_image = analysis
5038:             .retained_command_realm()
5039:             .unwrap()
5040:             .original_source_image()
5041:             .unwrap();
5042:         assert!(
5043:             class
5044:                 .original_members
5045:                 .logical_name_operand(
5046:                     MemberSide::Instance,
5047:                     &class.methods["m"],
5048:                     actual_input,
5049:                     actual_image
5050:                 )
5051:                 .is_none()
5052:         );
5053:     }
5054: 
5055:     #[test]
5056:     fn loop_installed_members_require_the_original_variable_word() {
5057:         let config = tcl_lexer::LexerConfig::for_dialect("tcl9.1");
5058:         let dialect = tcl_registry::model::ingress::static_context_for("tcl9.1")
5059:             .context()
5060:             .authoring_query();
5061:         let shape =
5062:             |body, name| loop_installed_member_shape(tcloo(), body, 7, config, Some(dialect), name);
5063:         for body in [
5064:             "method $name {} {}",
5065:             r#"method "$name" {} {}"#,
5066:             "method ${name} {} {}",
5067:             "private method $name {} {}",
5068:             "self method $name {} {}",
5069:         ] {
5070:             assert!(shape(body, "name").is_some(), "{body}");
5071:         }
5072:         for body in [
5073:             "method {$name} {} {}",
5074:             r"method \$name {} {}",
5075:             "method {${name}} {} {}",
5076:             "method prefix$name {} {}",
5077:             "method $name$suffix {} {}",
5078:             "method $name(key) {} {}",
5079:             "method ${name(key)} {} {}",
5080:             "method {*}{$name} {} {}",
5081:             r#"method " $name" {} {}"#,
5082:         ] {
5083:             assert!(shape(body, "name").is_none(), "{body}");
5084:         }
5085:         assert!(shape("method ${literal:::name} {} {}", "literal:::name").is_some());
5086:         assert!(shape("method ${literal:::name} {} {}", "literal::name").is_none());
5087:         let flat = tcl_lexer::LexerConfig {
5088:             braced_var: tcl_dialect::BracedVarStyle::FirstClose,
5089:             ..config
5090:         };
5091:         assert!(
5092:             loop_installed_member_shape(
5093:                 tcloo(),
5094:                 "method ${a{b} {} {}",
5095:                 7,
5096:                 flat,
5097:                 Some(dialect),
5098:                 "a{b"
5099:             )
5100:             .is_some()
5101:         );
5102:         assert!(shape("method ${a{b} {} {}", "a{b").is_none());
5103:     }
5104: 
5105:     #[test]
5106:     fn original_member_script_projection_keeps_body_bom_as_keyword_content() {
5107:         // naming.source.original-configured-script-completeness
5108:         // docs/design/analysis/name-resolution-proofs/source-original-configured-script-completeness.md
5109:         // Exact member grammar syntax; no installed method or Native worker.
5110:         let config = tcl_lexer::LexerConfig::for_file_grammar(
5111:             crate::environment_ingress::resolve_environment("tcl9.1").grammar(),
5112:         );
5113:         let dialect = tcl_registry::model::ingress::static_context_for("tcl9.1")
5114:             .context()
5115:             .authoring_query();
5116:         let positive = "method $name {} {}";
5117:         assert!(
5118:             loop_installed_member_shape(tcloo(), positive, 7, config, Some(dialect), "name")
5119:                 .is_some()
5120:         );
5121:         assert!(
5122:             loop_installed_member_shape(
5123:                 tcloo(),
5124:                 "\u{feff}method $name {} {}",
5125:                 7,
5126:                 config,
5127:                 Some(dialect),
5128:                 "name"
5129:             )
5130:             .is_none()
5131:         );
5132:         let source = "private {\u{feff}method ghost {} {}}";
5133:         let command = crate::segmenter::segment_commands_with_offset_and_config(source, 0, config)
5134:             .pop()
5135:             .unwrap();
5136:         let expanded =
5137:             expand_wrapper_block_members(source, tcloo(), &command.texts, &command.argv, config)
5138:                 .unwrap();
5139:         assert_eq!(expanded.len(), 1);
5140:         assert_eq!(expanded[0].0[1], "\u{feff}method");
5141:         assert!(tcloo().member(&expanded[0].0[1]).is_none());
5142:     }
5143: 
5144:     #[test]
5145:     fn original_vendor_class_declarations_keep_selected_source_role_and_unavailable_units() {
5146:         // Implementation contract: naming.vendor.original-source-context-input
5147:         // docs/design/analysis/name-resolution-proofs/vendor-original-source-context-input.md
5148:         let source = r"snit::type {Plain} {}
5149: snit::type {C\uD800} {}";
5150:         for profile in ["f5-irules", "f5-iapps", "f5-tmsh"] {
5151:             let result = Analyser::new().analyse(source, profile);
5152:             let classes = result
5153:                 .original_vendor_class_declarations()
5154:                 .collect::<Vec<_>>();
5155:             assert_eq!(classes.len(), 2, "{profile}");
5156:             for class in &classes {
5157:                 assert_eq!(
5158:                     class.purpose(),
5159:                     tcl_syntax::naming::VendorSourceNamePurpose::SourceName
5160:                 );
5161:                 assert_eq!(
5162:                     class.name_input().source_image(),
5163:                     &tcl_lexer::SourceImage::document(source)
5164:                 );
5165:                 assert!(
5166:                     class.metadata().source_name.is_none(),
5167:                     "hosted source cards have no C/Jim slot"
5168:                 );
5169:                 assert_eq!(
5170:                     result.original_vendor_source_name_in_source(
5171:                         class.name_input().source_image(),
5172:                         class.name_input().lexer_config(),
5173:                         class.metadata().name_span,
5174:                     ),
5175:                     Some(class.original_occurrence())
5176:                 );
5177:             }
5178:             assert_eq!(
5179:                 classes[0].name_input().literal_units(classes[0].purpose()),
5180:                 Some(b"Plain".as_slice())
5181:             );
5182:             assert!(
5183:                 classes[1]
5184:                     .name_input()
5185:                     .literal_units(classes[1].purpose())
5186:                     .is_none()
5187:             );
5188:             assert_eq!(result.original_class_declarations().count(), 0);
5189:         }
5190:         let result = Analyser::new().analyse("snit::type Plain {}", "tcl8.6");
5191:         assert_eq!(result.original_vendor_class_declarations().count(), 0);
5192:     }
5193: 
5194:     /// The `TclOO` definition-body grammar the `apply_oo_subcommand` /
5195:     /// `extract_method_def` helpers read their member argument layout from —
5196:     /// the same `&'static` the analyser fetches from the registry at runtime.
5197:     fn tcloo() -> &'static DefinitionBodyGrammar {
5198:         &tcl_registry::definer::TCLOO_GRAMMAR
5199:     }
5200: 
5201:     fn class() -> ClassDef {
5202:         ClassDef {
5203:             name: "C".to_string(),
5204:             qualified_name: "::C".to_string(),
5205:             name_span: tcl_lexer::Span::new(0, 0),
5206:             body_span: tcl_lexer::Span::new(0, 0),
5207:             ..Default::default()
5208:         }
5209:     }
5210: 
5211:     /// The `W315` messages an analysis produced, in emission order — the
5212:     /// "this class definition cannot run" reports.
5213:     fn w315_messages(r: &super::super::types::AnalysisResult) -> Vec<String> {
5214:         r.diagnostics
5215:             .iter()
5216:             .filter(|d| d.code == tcl_core_types::DiagCode::W315)
5217:             .map(|d| d.message.clone())
5218:             .collect()
5219:     }
5220: 
5221:     fn has_w315(r: &super::super::types::AnalysisResult) -> bool {
5222:         !w315_messages(r).is_empty()
5223:     }
5224: 
5225:     fn tok(span: (u32, u32)) -> Token {
5226:         Token::new(TokenType::Esc, tcl_lexer::Span::new(span.0, span.1))
5227:     }
5228: 
5229:     fn str_tok(span: (u32, u32)) -> Token {
5230:         Token {
5231:             kind: TokenType::Str,
5232:             span: tcl_lexer::Span::new(span.0, span.1),
5233:             content_offset: 1,
5234:             in_quote: false,
5235:         }
5236:     }
5237: 
5238:     #[test]
5239:     fn superclass_subcommand_assigns_supers() {
5240:         let mut cd = class();
5241:         let texts: Vec<String> = ["superclass", "::A", "::B"]
5242:             .iter()
5243:             .map(|s| (*s).to_string())
5244:             .collect();
5245:         let argv = [tok((0, 10)), tok((11, 14)), tok((15, 18))];
5246:         apply_oo_subcommand(tcloo(), &texts, &argv, &mut cd);
5247:         assert_eq!(cd.superclasses, vec!["::A", "::B"]);
5248:     }
5249: 
5250:     #[test]
5251:     fn mixin_subcommand_strips_dash_flags() {
5252:         let mut cd = class();
5253:         let texts: Vec<String> = ["mixin", "-append", "::M1", "::M2"]
5254:             .iter()
5255:             .map(|s| (*s).to_string())
5256:             .collect();
5257:         let argv = [tok((0, 5)), tok((6, 13)), tok((14, 18)), tok((19, 23))];
5258:         apply_oo_subcommand(tcloo(), &texts, &argv, &mut cd);
5259:         assert_eq!(cd.mixins, vec!["::M1", "::M2"]);
5260:     }
5261: 
5262:     /// Apply a sequence of definition-body words to one class — the shape
5263:     /// slot folding is about: later words must fold into,
5264:     /// not overwrite, earlier slot state.
5265:     fn apply_words(cd: &mut super::ClassDef, calls: &[&[&str]]) {
5266:         for words in calls {
5267:             let texts: Vec<String> = words.iter().map(|s| (*s).to_string()).collect();
5268:             let argv: Vec<tcl_lexer::Token> = words.iter().map(|_| tok((0, 1))).collect();
5269:             apply_oo_subcommand(tcloo(), &texts, &argv, cd);
5270:         }
5271:     }
5272: 
5273:     // Slot semantics for filter / superclass / mixin / variable (defaults
5274:     // pinned against tclOODefineCmds.c 9.0.4 and confirmed live on
5275:     // tclsh 9.0.4).
5276: 
5277:     // TP: `filter a ; filter b` appends — `info class filters` → `a b`,
5278:     // NOT `b` (which is what a last-writer-wins reading would give).
5279:     #[test]
5280:     fn filter_slot_appends_across_calls() {
5281:         let mut cd = class();
5282:         apply_words(&mut cd, &[&["filter", "a"], &["filter", "b"]]);
5283:         assert_eq!(cd.filters, vec!["a", "b"]);
5284:     }
5285: 
5286:     // TP: the explicit operations fold — `-set` replaces, `-clear` empties,
5287:     // `-prepend` front-inserts (tclsh 9.0.4: `filter a; filter -prepend b`
5288:     // → `b a`), `-remove` deletes.
5289:     #[test]
5290:     fn filter_slot_explicit_operations_fold() {
5291:         let mut cd = class();
5292:         apply_words(&mut cd, &[&["filter", "a", "b"], &["filter", "-set", "x"]]);
5293:         assert_eq!(cd.filters, vec!["x"]);
5294:         apply_words(&mut cd, &[&["filter", "-clear"]]);
5295:         assert_eq!(cd.filters, [] as [std::string::String; 0]);
5296:         apply_words(&mut cd, &[&["filter", "a"], &["filter", "-prepend", "b"]]);
5297:         assert_eq!(cd.filters, vec!["b", "a"]);
5298:         apply_words(&mut cd, &[&["filter", "-remove", "b"]]);
5299:         assert_eq!(cd.filters, vec!["a"]);
5300:     }
5301: 
5302:     // FP guard: an operation word is recognised at argument 0 only —
5303:     // `filter a -set b` appends three literal items (tclsh 9.0.4), it does
5304:     // not replace the slot with `b`.
5305:     #[test]
5306:     fn filter_slot_op_word_only_recognised_first() {
5307:         let mut cd = class();
5308:         apply_words(&mut cd, &[&["filter", "a", "-set", "b"]]);
5309:         assert_eq!(cd.filters, vec!["a", "-set", "b"]);
5310:     }
5311: 
5312:     // TP: `superclass` defaults to `-set` (replace) — the common single
5313:     // declaration keeps its meaning — and `-append` extends (tclsh 9.0.4:
5314:     // `superclass A` after `superclass B` → `::B`; `superclass -append A`
5315:     // → `::B ::A`).
5316:     #[test]
5317:     fn superclass_slot_replaces_by_default_and_appends_explicitly() {
5318:         let mut cd = class();
5319:         apply_words(&mut cd, &[&["superclass", "::A"], &["superclass", "::B"]]);
5320:         assert_eq!(cd.superclasses, vec!["::B"]);
5321:         apply_words(&mut cd, &[&["superclass", "-append", "::A"]]);
5322:         assert_eq!(cd.superclasses, vec!["::B", "::A"]);
5323:     }
5324: 
5325:     // TP: `mixin` defaults to `-set` in 8.6 and 9.0 alike (both C sources
5326:     // forward `--default-operation` to `-set`; tclsh 9.0.4:
5327:     // `mixin M1; mixin M2` → `::M2`).
5328:     #[test]
5329:     fn mixin_slot_replaces_by_default() {
5330:         let mut cd = class();
5331:         apply_words(&mut cd, &[&["mixin", "::M1"], &["mixin", "::M2"]]);
5332:         assert_eq!(cd.mixins, vec!["::M2"]);
5333:     }
5334: 
5335:     // TP: the class `variable` slot appends with dedup (tclsh 9.0.4:
5336:     // `variable a; variable a b` → `a b`) and folds `-set` / `-remove`.
5337:     #[test]
5338:     fn variable_slot_appends_dedups_and_folds_ops() {
5339:         let mut cd = class();
5340:         apply_words(&mut cd, &[&["variable", "a"], &["variable", "a", "b"]]);
5341:         assert_eq!(cd.variables, vec!["a", "b"]);
5342:         apply_words(&mut cd, &[&["variable", "-remove", "a"]]);
5343:         assert_eq!(cd.variables, vec!["b"]);
5344:         apply_words(&mut cd, &[&["variable", "-set", "c"]]);
5345:         assert_eq!(cd.variables, vec!["c"]);
5346:     }
5347: 
5348:     // TN: an unknown leading `-op` aborts the whole definition in real Tcl
5349:     // (`unknown method "-bogus"`), so the fold must leave the slot state
5350:     // unchanged rather than record `-bogus`/`x` as filters.
5351:     #[test]
5352:     fn unknown_slot_op_leaves_slot_untouched() {
5353:         let mut cd = class();
5354:         apply_words(&mut cd, &[&["filter", "a"], &["filter", "-bogus", "x"]]);
5355:         assert_eq!(cd.filters, vec!["a"]);
5356:     }
5357: 
5358:     // TP, full pipeline: the fold carries across definition blocks — the
5359:     // oracle transcript verbatim (tclsh 9.0.4 and 8.6.16, byte-identical):
5360:     //   oo::class create C { filter a; filter b } → info class filters → a b
5361:     //   oo::define C { filter -set x }            →                    → x
5362:     //   oo::define C { filter -clear }            →                    → (empty)
5363:     #[test]
5364:     fn filter_slot_folds_across_oo_define_blocks() {
5365:         let mut a = Analyser::new();
5366:         let r = a.analyse(
5367:             "oo::class create ::C { filter a\nfilter b }\n\
5368:              oo::define ::C { filter -set x }\n",
5369:             "tcl9.0",
5370:         );
5371:         let c = r.all_classes.get("::C").expect("::C recorded");
5372:         assert_eq!(c.filters, vec!["x"]);
5373: 
5374:         let mut a2 = Analyser::new();
5375:         let r2 = a2.analyse(
5376:             "oo::class create ::C { filter a\nfilter b }\n\
5377:              oo::define ::C { filter -append c }\n",
5378:             "tcl9.0",
5379:         );
5380:         let c2 = r2.all_classes.get("::C").expect("::C recorded");
5381:         assert_eq!(c2.filters, vec!["a", "b", "c"]);
5382:     }
5383: 
5384:     // The class-object side folds through the same slot spec: `self filter`
5385:     // appends across calls, and never leaks into the instance slot.
5386:     #[test]
5387:     fn class_side_filter_slot_folds_and_stays_sided() {
5388:         let mut a = Analyser::new();
5389:         let r = a.analyse(
5390:             "oo::class create ::C { self { filter a }\nself { filter b } }\n",
5391:             "tcl9.0",
5392:         );
5393:         let c = r.all_classes.get("::C").expect("::C recorded");
5394:         assert_eq!(c.class_filters, vec!["a", "b"]);
5395:         assert_eq!(c.filters, [] as [std::string::String; 0]);
5396:     }
5397: 
5398:     #[test]
5399:     fn method_subcommand_records_method_def() {
5400:         let mut cd = class();
5401:         let texts: Vec<String> = ["method", "greet", "name", "puts $name"]
5402:             .iter()
5403:             .map(|s| (*s).to_string())
5404:             .collect();
5405:         let argv = [tok((0, 6)), tok((7, 12)), tok((13, 17)), str_tok((18, 32))];
5406:         apply_oo_subcommand(tcloo(), &texts, &argv, &mut cd);
5407:         assert!(cd.methods.contains_key("greet"));
5408:         let md = &cd.methods["greet"];
5409:         assert_eq!(md.kind, "method");
5410:         assert_eq!(md.visibility, "public");
5411:     }
5412: 
5413:     /// Tcl 9's declaration flag sits between a method name and parameter list.
5414:     /// The analyser receives only the generic registry layout and its selected
5415:     /// visibility—not a command-specific option parser.
5416:     #[test]
5417:     fn method_visibility_option_shifts_params_and_sets_visibility() {
5418:         let mut cd = class();
5419:         let texts: Vec<String> = ["method", "internal", "-private", "arg", "puts $arg"]
5420:             .iter()
5421:             .map(|s| (*s).to_string())
5422:             .collect();
5423:         let argv = [
5424:             tok((0, 6)),
5425:             tok((7, 15)),
5426:             tok((16, 24)),
5427:             tok((25, 28)),
5428:             str_tok((29, 38)),
5429:         ];
5430:         apply_oo_subcommand(tcloo(), &texts, &argv, &mut cd);
5431:         let method = cd.methods.get("internal").expect("method recorded");
5432:         assert_eq!(method.visibility, "private");
5433:         assert_eq!(method.params[0].name, "arg");
5434:         assert_eq!(method.body_span, tcl_lexer::Span::new(29, 38));
5435:     }
5436: 
5437:     #[test]
5438:     fn method_visibility_option_is_profile_gated_without_old_layout_reinterpretation() {
5439:         let src = "oo::class create C { method internal -private {} { return ok } }";
5440:         let mut analyser = Analyser::new();
5441:         let tcl86 = analyser.analyse(src, "tcl8.6").clone();
5442:         assert!(
5443:             tcl86
5444:                 .diagnostics
5445:                 .iter()
5446:                 .any(|diagnostic| diagnostic.code.as_str() == "W002"),
5447:             "Tcl 8.6 must diagnose the Tcl 9 method option: {:?}",
5448:             tcl86.diagnostics
5449:         );
5450:         assert!(
5451:             tcl86
5452:                 .all_classes
5453:                 .get("::C")
5454:                 .is_none_or(|class| !class.methods.contains_key("internal")),
5455:             "the invalid Tcl 8.6 member must not be reinterpreted using a shifted layout"
5456:         );
5457: 
5458:         let mut analyser = Analyser::new();
5459:         let tcl90 = analyser.analyse(src, "tcl9.0").clone();
5460:         assert_eq!(
5461:             tcl90.all_classes["::C"].methods["internal"].visibility,
5462:             "private"
5463:         );
5464:     }
5465: 
5466:     #[test]
5467:     fn classmethod_subcommand_records_class_method() {
5468:         let mut cd = class();
5469:         let texts: Vec<String> = ["classmethod", "build", "args", "return $args"]
5470:             .iter()
5471:             .map(|s| (*s).to_string())
5472:             .collect();
5473:         let argv = [
5474:             tok((0, 11)),
5475:             tok((12, 17)),
5476:             tok((18, 22)),
5477:             str_tok((23, 38)),
5478:         ];
5479:         apply_oo_subcommand(tcloo(), &texts, &argv, &mut cd);
5480:         assert!(cd.class_methods.contains_key("build"));
5481:         assert!(!cd.methods.contains_key("build"));
5482:     }
5483: 
5484:     #[test]
5485:     fn constructor_appends_to_constructors_list() {
5486:         let mut cd = class();
5487:         let texts: Vec<String> = ["constructor", "args", "puts ctor"]
5488:             .iter()
5489:             .map(|s| (*s).to_string())
5490:             .collect();
5491:         let argv = [tok((0, 11)), tok((12, 16)), str_tok((17, 28))];
5492:         apply_oo_subcommand(tcloo(), &texts, &argv, &mut cd);
5493:         assert_eq!(cd.constructors.len(), 1);
5494:         assert_eq!(cd.constructors[0].kind, "constructor");
5495:         assert_eq!(cd.constructors[0].name, "<constructor>");
5496:         // Name span anchors on the `constructor` keyword token
5497:         // (argv[0] = 0..11), not the default (0, 0).
5498:         assert_eq!(cd.constructors[0].name_span, tcl_lexer::Span::new(0, 11));
5499:         // Constructors are not mirrored into the methods map.
5500:         assert!(!cd.methods.contains_key("<constructor>"));
5501:     }
5502: 
5503:     #[test]
5504:     fn destructor_sets_destructor_field() {
5505:         let mut cd = class();
5506:         let texts: Vec<String> = ["destructor", "puts dtor"]
5507:             .iter()
5508:             .map(|s| (*s).to_string())
5509:             .collect();
5510:         let argv = [tok((0, 10)), str_tok((11, 22))];
5511:         apply_oo_subcommand(tcloo(), &texts, &argv, &mut cd);
5512:         let dtor = cd.destructor.as_ref().expect("destructor recorded");
5513:         assert_eq!(dtor.kind, "destructor");
5514:         assert_eq!(dtor.name, "<destructor>");
5515:         // Name span anchors on the `destructor` keyword token
5516:         // (argv[0] = 0..10).
5517:         assert_eq!(dtor.name_span, tcl_lexer::Span::new(0, 10));
5518:         assert!(!cd.methods.contains_key("<destructor>"));
5519:     }
5520: 
5521:     #[test]
5522:     fn forward_records_method_with_forward_kind() {
5523:         let mut cd = class();
5524:         let texts: Vec<String> = ["forward", "delegate", "::other::cmd"]
5525:             .iter()
5526:             .map(|s| (*s).to_string())
5527:             .collect();
5528:         let argv = [tok((0, 7)), tok((8, 16)), tok((17, 29))];
5529:         apply_oo_subcommand(tcloo(), &texts, &argv, &mut cd);
5530:         assert!(cd.methods.contains_key("delegate"));
5531:         assert_eq!(cd.methods["delegate"].kind, "forward");
5532:     }
5533: 
5534:     #[test]
5535:     fn private_method_records_with_private_visibility() {
5536:         let mut cd = class();
5537:         let texts: Vec<String> = ["private", "method", "internal", "args", "puts hi"]
5538:             .iter()
5539:             .map(|s| (*s).to_string())
5540:             .collect();
5541:         let argv = [
5542:             tok((0, 7)),
5543:             tok((8, 14)),
5544:             tok((15, 23)),
5545:             tok((24, 28)),
5546:             str_tok((29, 37)),
5547:         ];
5548:         apply_oo_subcommand(tcloo(), &texts, &argv, &mut cd);
5549:         assert!(cd.methods.contains_key("internal"));
5550:         assert_eq!(cd.methods["internal"].visibility, "private");
5551:     }
5552: 
5553:     #[test]
5554:     fn self_method_subcommand_records_class_method_tagged_is_self_method() {
5555:         // TP: `self method NAME ARGS BODY` (TclOO's own spelling of a
5556:         // class-level method, the stock counterpart to ooutil's `classmethod`
5557:         // keyword) must land by its row's type-object receiver, or
5558:         // `class_methods` gains no entry for it. Recorded with
5559:         // `kind: "classmethod"` (both
5560:         // spellings mean "dispatched via the class's own bound command")
5561:         // but tagged `is_self_method` so the class-command MRO walk knows
5562:         // NOT to treat it as inherited the way ooutil's `classmethod` is.
5563:         let mut cd = class();
5564:         let texts: Vec<String> = ["self", "method", "make", "n", "return made"]
5565:             .iter()
5566:             .map(|s| (*s).to_string())
5567:             .collect();
5568:         let argv = [
5569:             tok((0, 4)),
5570:             tok((5, 11)),
5571:             tok((12, 16)),
5572:             tok((17, 18)),
5573:             str_tok((19, 30)),
5574:         ];
5575:         apply_oo_subcommand(tcloo(), &texts, &argv, &mut cd);
5576:         assert!(!cd.methods.contains_key("make"));
5577:         let md = cd
5578:             .class_methods
5579:             .get("make")
5580:             .expect("recorded as a classmethod");
5581:         assert_eq!(md.kind, "classmethod");
5582:         assert!(md.is_self_method);
5583:         assert_eq!(md.visibility, "public");
5584:     }
5585: 
5586:     #[test]
5587:     fn self_classmethod_subcommand_also_records_into_class_methods() {
5588:         // TP — the `self classmethod` inner spelling (rarer, but valid:
5589:         // `self` always retargets to the class object regardless of which
5590:         // inner member follows) must resolve identically to `self method`.
5591:         let mut cd = class();
5592:         let texts: Vec<String> = ["self", "classmethod", "build", "args", "return $args"]
5593:             .iter()
5594:             .map(|s| (*s).to_string())
5595:             .collect();
5596:         let argv = [
5597:             tok((0, 4)),
5598:             tok((5, 16)),
5599:             tok((17, 22)),
5600:             tok((23, 27)),
5601:             str_tok((28, 43)),
5602:         ];
5603:         apply_oo_subcommand(tcloo(), &texts, &argv, &mut cd);
5604:         let md = cd
5605:             .class_methods
5606:             .get("build")
5607:             .expect("recorded as a classmethod");
5608:         assert!(md.is_self_method);
5609:     }
5610: 
5611:     #[test]
5612:     fn self_block_form_is_a_silent_noop_not_a_crash() {
5613:         // FN guard — this helper does not read the `self { method NAME ARGS
5614:         // BODY }` *block* form (nor the symmetric `private` one). It must
5615:         // decline cleanly, never panic on the whole braced blob standing in
5616:         // for an inner keyword.
5617:         let mut cd = class();
5618:         let texts: Vec<String> = ["self", "{ method make {n} { return made } }"]
5619:             .iter()
5620:             .map(|s| (*s).to_string())
5621:             .collect();
5622:         let argv = [tok((0, 4)), str_tok((5, 42))];
5623:         apply_oo_subcommand(tcloo(), &texts, &argv, &mut cd);
5624:         assert_eq!(cd.class_methods.len(), 0);
5625:         assert_eq!(cd.methods.len(), 0);
5626:     }
5627: 
5628:     #[test]
5629:     fn unrecognised_subcommand_is_silent_noop() {
5630:         let mut cd = class();
5631:         let texts: Vec<String> = ["whatever", "x"].iter().map(|s| (*s).to_string()).collect();
5632:         let argv = [tok((0, 8)), tok((9, 10))];
5633:         apply_oo_subcommand(tcloo(), &texts, &argv, &mut cd);
5634:         // No fields populated; no panic.
5635:         assert_eq!(cd.methods.len(), 0);
5636:         assert_eq!(cd.superclasses, [] as [std::string::String; 0]);
5637:         assert_eq!(cd.mixins, [] as [std::string::String; 0]);
5638:     }
5639: 
5640:     #[test]
5641:     fn variable_declaration_spans_use_selected_original_literal_name_operands() {
5642:         let source =
5643:             "variable {$literal} {${braced}} {}; variable $computed; variable {*}{shifted}";
5644:         let profile = tcl_dialect::DialectProfile::find("tcl9.1").unwrap();
5645:         let config = tcl_lexer::LexerConfig::for_profile(Some(profile));
5646:         let image = tcl_lexer::SourceImage::document(source);
5647:         let commands = crate::segmenter::segment_commands_with_offset_and_config(source, 0, config);
5648:         let known = [
5649:             "$literal",
5650:             "${braced}",
5651:             "",
5652:             "computed",
5653:             "$computed",
5654:             "shifted",
5655:         ]
5656:         .map(str::to_owned);
5657:         let spans = collect_var_decl_spans(tcloo(), &commands, &known, &image, config, None);
5658:         for name in ["$literal", "${braced}", ""] {
5659:             assert!(spans.contains_key(name), "{name:?}: {spans:?}");
5660:         }
5661:         assert!(!spans.contains_key("literal") && !spans.contains_key("braced"));
5662:         assert!(
5663:             !spans.contains_key("computed")
5664:                 && !spans.contains_key("$computed")
5665:                 && !spans.contains_key("shifted")
5666:         );
5667:     }
5668: 
5669:     #[test]
5670:     fn variable_subcommand_records_class_variables() {
5671:         let mut cd = class();
5672:         let texts: Vec<String> = ["variable", "x", "y"]
5673:             .iter()
5674:             .map(|s| (*s).to_string())
5675:             .collect();
5676:         let argv = [tok((0, 8)), tok((9, 10)), tok((11, 12))];
5677:         apply_oo_subcommand(tcloo(), &texts, &argv, &mut cd);
5678:         assert_eq!(cd.variables, vec!["x", "y"]);
5679:     }
5680: 
5681:     #[test]
5682:     fn a_second_variable_subcommand_accumulates_rather_than_replacing() {
5683:         // TP — the real corpus shape
5684:         // (georgtree_tclopt's ::tclopt::Mpfit) has TWO separate `variable`
5685:         // statements in the same class body (`variable funct m ftol ...`
5686:         // then, separately, `variable Pars`). tclsh9.0-verified: both
5687:         // statements' names are live, simultaneous instance variables —
5688:         // `variable` inside a class body is additive, never a reset (the
5689:         // same "always present in every method" declaration a `variable`
5690:         // command inside a method body itself would make, just issued
5691:         // once for the whole class). A second statement must not silently
5692:         // discard the first's names.
5693:         let mut cd = class();
5694:         apply_oo_subcommand(
5695:             tcloo(),
5696:             &["variable".to_string(), "funct".to_string(), "m".to_string()],
5697:             &[tok((0, 8)), tok((9, 14)), tok((15, 16))],
5698:             &mut cd,
5699:         );
5700:         apply_oo_subcommand(
5701:             tcloo(),
5702:             &["variable".to_string(), "Pars".to_string()],
5703:             &[tok((20, 28)), tok((29, 33))],
5704:             &mut cd,
5705:         );
5706:         assert_eq!(cd.variables, vec!["funct", "m", "Pars"]);
5707:     }
5708: 
5709:     #[test]
5710:     fn filter_subcommand_records_filters() {
5711:         let mut cd = class();
5712:         let texts: Vec<String> = ["filter", "log", "trace"]
5713:             .iter()
5714:             .map(|s| (*s).to_string())
5715:             .collect();
5716:         let argv = [tok((0, 6)), tok((7, 10)), tok((11, 16))];
5717:         apply_oo_subcommand(tcloo(), &texts, &argv, &mut cd);
5718:         assert_eq!(cd.filters, vec!["log", "trace"]);
5719:         // …and only the instance slot: the class object stays unfiltered.
5720:         assert_eq!(cd.class_filters.len(), 0, "{:?}", cd.class_filters);
5721:     }
5722: 
5723:     #[test]
5724:     fn export_and_unexport_record_sets() {
5725:         let mut cd = class();
5726:         let texts1: Vec<String> = ["export", "foo", "bar"]
5727:             .iter()
5728:             .map(|s| (*s).to_string())
5729:             .collect();
5730:         let argv1 = [tok((0, 6)), tok((7, 10)), tok((11, 14))];
5731:         apply_oo_subcommand(tcloo(), &texts1, &argv1, &mut cd);
5732:         assert!(cd.exports.contains("foo"));
5733:         assert!(cd.exports.contains("bar"));
5734: 
5735:         let texts2: Vec<String> = ["unexport", "baz"]
5736:             .iter()
5737:             .map(|s| (*s).to_string())
5738:             .collect();
5739:         let argv2 = [tok((0, 8)), tok((9, 12))];
5740:         apply_oo_subcommand(tcloo(), &texts2, &argv2, &mut cd);
5741:         assert!(cd.unexports.contains("baz"));
5742:     }
5743: 
5744:     #[test]
5745:     fn property_subcommand_records_property_def() {
5746:         let mut cd = class();
5747:         let texts: Vec<String> = [
5748:             "property",
5749:             "colour",
5750:             "-kind",
5751:             "readable",
5752:             "-get",
5753:             "return red",
5754:         ]
5755:         .iter()
5756:         .map(|s| (*s).to_string())
5757:         .collect();
5758:         let argv = [
5759:             tok((0, 8)),
5760:             tok((9, 15)),
5761:             tok((16, 21)),
5762:             tok((22, 30)),
5763:             tok((31, 35)),
5764:             str_tok((36, 47)),
5765:         ];
5766:         apply_oo_subcommand(tcloo(), &texts, &argv, &mut cd);
5767:         let pd = cd.properties.get("colour").expect("colour recorded");
5768:         assert_eq!(pd.kind, "readable");
5769:         assert!(pd.has_getter);
5770:         assert!(!pd.has_setter);
5771:     }
5772: 
5773:     /// `property` is a 9.0 `TclOO` member: under 8.6 it is flagged
5774:     /// disabled-in-dialect (W002), but from 9.0 on it is accepted silently.
5775:     ///
5776:     /// Either way the member is **recorded** — reporting "this needs Tcl
5777:     /// 9.0" must not also break go-to-definition, references, rename, and
5778:     /// document symbols over the code the user wrote, and the whole-command
5779:     /// W002 behaves the same way (it reports a dialect-unavailable command
5780:     /// while the analyser goes on modelling the call).
5781:     #[test]
5782:     fn property_member_is_gated_to_9_0() {
5783:         let src = "oo::class create C {\n    property color\n}\n";
5784:         let mut a86 = Analyser::new();
5785:         let r86 = a86.analyse(src, "tcl8.6");
5786:         assert!(
5787:             r86.diagnostics
5788:                 .iter()
5789:                 .any(|d| d.code == tcl_core_types::DiagCode::W002),
5790:             "property should be W002 under 8.6",
5791:         );
5792:         assert!(
5793:             r86.all_classes
5794:                 .get("::C")
5795:                 .is_some_and(|c| c.properties.contains_key("color")),
5796:             "the member is still recorded, so editor features keep working",
5797:         );
5798: 
5799:         let mut a90 = Analyser::new();
5800:         let r90 = a90.analyse(src, "tcl9.0");
5801:         assert!(
5802:             !r90.diagnostics
5803:                 .iter()
5804:                 .any(|d| d.code == tcl_core_types::DiagCode::W002),
5805:             "property is available in 9.0",
5806:         );
5807:         assert!(
5808:             r90.all_classes
5809:                 .get("::C")
5810:                 .is_some_and(|c| c.properties.contains_key("color")),
5811:             "9.0 records the property",
5812:         );
5813:     }
5814: 
5815:     /// A configurable class answers `configure` for its properties, so that
5816:     /// generated accessor is folded into its known methods even though no
5817:     /// `method` body defines it.  `cget` is **not** generated
5818:     /// (`configurable.n` documents none in 9.0 or 9.1), so it must not be.
5819:     #[test]
5820:     fn configurable_class_knows_configure_but_not_cget() {
5821:         let mut a = Analyser::new();
5822:         let r = a
5823:             .analyse(
5824:                 "oo::configurable create C {\n    property color\n}\n",
5825:                 "tcl9.0",
5826:             )
5827:             .clone();
5828:         let known = r.class_hierarchy().known_methods(
5829:             Some(tcl_registry::model::ingress::static_context_for("tcl9.0").commands()),
5830:             "::C",
5831:         );
5832:         assert!(known.contains(&"configure".to_owned()), "{known:?}");
5833:         assert!(!known.contains(&"cget".to_owned()), "{known:?}");
5834:     }
5835: 
5836:     /// A command reference the analyser records for a class-body member
5837:     /// argument (`superclass`/`mixin`/`inherit`/`forward` target).  `written`
5838:     /// is the token text; `resolved` the qualified command it denotes.
5839:     fn has_cmd_ref(
5840:         r: &crate::analyser::types::AnalysisResult,
5841:         written: &str,
5842:         resolved: &str,
5843:     ) -> bool {
5844:         r.command_invocations.iter().any(|inv| {
5845:             inv.name == written && inv.resolved_qualified_name.as_deref() == Some(resolved)
5846:         })
5847:     }
5848: 
5849:     // TP: a `superclass ::ns::Base` names the base class — recorded as a
5850:     // command reference so references / go-to-definition / rename reach it.
5851:     #[test]
5852:     fn superclass_records_a_command_reference_to_the_base_class() {
5853:         let mut a = Analyser::new();
5854:         let r = a
5855:             .analyse(
5856:                 "namespace eval ::ns {\n  oo::class create Base {}\n  \
5857:                  oo::class create Sub { superclass ::ns::Base }\n}\n",
5858:                 "tcl9.0",
5859:             )
5860:             .clone();
5861:         assert!(
5862:             has_cmd_ref(&r, "::ns::Base", "::ns::Base"),
5863:             "superclass must record a command reference: {:?}",
5864:             r.command_invocations
5865:                 .iter()
5866:                 .map(|i| &i.name)
5867:                 .collect::<Vec<_>>()
5868:         );
5869:     }
5870: 
5871:     // TP: `mixin ::ns::Role` — the mixed-in class is a command reference.
5872:     #[test]
5873:     fn mixin_records_a_command_reference_to_the_class() {
5874:         let mut a = Analyser::new();
5875:         let r = a
5876:             .analyse(
5877:                 "namespace eval ::ns {\n  oo::class create Role {}\n  \
5878:                  oo::class create C { mixin ::ns::Role }\n}\n",
5879:                 "tcl9.0",
5880:             )
5881:             .clone();
5882:         assert!(has_cmd_ref(&r, "::ns::Role", "::ns::Role"));
5883:     }
5884: 
5885:     // The `forward` target resolves through the member grammar's
5886:     // `ArgRole::CommandName` and records the delegated command.
5887:     #[test]
5888:     fn forward_target_still_records_a_command_reference() {
5889:         let mut a = Analyser::new();
5890:         let r = a
5891:             .analyse(
5892:                 "namespace eval ::ns {\n  proc helper {} {}\n  \
5893:                  oo::class create C { forward f ::ns::helper }\n}\n",
5894:                 "tcl9.0",
5895:             )
5896:             .clone();
5897:         assert!(has_cmd_ref(&r, "::ns::helper", "::ns::helper"));
5898:     }
5899: 
5900:     // TP: a bare `superclass Base` (same namespace) resolves to the enclosing
5901:     // namespace's class — the one-hop call-site resolution, not an ancestor.
5902:     #[test]
5903:     fn bare_superclass_resolves_in_the_class_namespace() {
5904:         let mut a = Analyser::new();
5905:         let r = a
5906:             .analyse(
5907:                 "namespace eval ::ns {\n  oo::class create Base {}\n  \
5908:                  oo::class create Sub { superclass Base }\n}\n",
5909:                 "tcl9.0",
5910:             )
5911:             .clone();
5912:         assert!(has_cmd_ref(&r, "Base", "::ns::Base"));
5913:     }
5914: 
5915:     // TP (itcl): `inherit ::ns::Base` names a base class the same way.
5916:     #[test]
5917:     fn itcl_inherit_records_a_command_reference_to_the_base_class() {
5918:         let mut a = Analyser::new();
5919:         let r = a
5920:             .analyse(
5921:                 "itcl::class ::ns::Base {}\n\
5922:                  itcl::class ::ns::Sub { inherit ::ns::Base }\n",
5923:                 "tcl8.6",
5924:             )
5925:             .clone();
5926:         assert!(
5927:             has_cmd_ref(&r, "::ns::Base", "::ns::Base"),
5928:             "itcl inherit must record a command reference: {:?}",
5929:             r.command_invocations
5930:                 .iter()
5931:                 .map(|i| &i.name)
5932:                 .collect::<Vec<_>>()
5933:         );
5934:     }
5935: 
5936:     // TN: a dynamic base name (`superclass $base`) names no static command —
5937:     // no reference is recorded (nothing to navigate or rename).
5938:     #[test]
5939:     fn dynamic_superclass_records_no_command_reference() {
5940:         let mut a = Analyser::new();
5941:         let r = a
5942:             .analyse(
5943:                 "namespace eval ::ns {\n  \
5944:                  oo::class create Sub { superclass $base }\n}\n",
5945:                 "tcl9.0",
5946:             )
5947:             .clone();
5948:         assert!(
5949:             !r.command_invocations
5950:                 .iter()
5951:                 .any(|inv| inv.name.contains('$')),
5952:             "a dynamic superclass name must not be recorded as a reference"
5953:         );
5954:     }
5955: 
5956:     // FP guard: `mixin -append ::ns::M` — the `-append` flag is not a class,
5957:     // only `::ns::M` is a reference.
5958:     #[test]
5959:     fn mixin_append_flag_is_not_a_command_reference() {
5960:         let mut a = Analyser::new();
5961:         let r = a
5962:             .analyse(
5963:                 "namespace eval ::ns {\n  oo::class create M {}\n  \
5964:                  oo::class create C { mixin -append ::ns::M }\n}\n",
5965:                 "tcl9.0",
5966:             )
5967:             .clone();
5968:         assert!(
5969:             has_cmd_ref(&r, "::ns::M", "::ns::M"),
5970:             "the class is a reference"
5971:         );
5972:         assert!(
5973:             !r.command_invocations
5974:                 .iter()
5975:                 .any(|inv| inv.name == "-append"),
5976:             "the -append flag must not be recorded as a command reference"
5977:         );
5978:     }
5979: 
5980:     // TP: the inline `oo::define Sub superclass Base` form (no `{body}` block)
5981:     // records the base-class reference too — the same as the braced body form.
5982:     // (The inline path is separate from the body walk.)
5983:     #[test]
5984:     fn inline_oo_define_superclass_records_a_command_reference() {
5985:         let mut a = Analyser::new();
5986:         let r = a
5987:             .analyse(
5988:                 "namespace eval ::ns {\n  oo::class create Base {}\n  \
5989:                  oo::class create Sub {}\n  oo::define Sub superclass ::ns::Base\n}\n",
5990:                 "tcl9.0",
5991:             )
5992:             .clone();
5993:         assert!(
5994:             has_cmd_ref(&r, "::ns::Base", "::ns::Base"),
5995:             "inline `oo::define … superclass` must record a command reference: {:?}",
5996:             r.command_invocations
5997:                 .iter()
5998:                 .map(|i| &i.name)
5999:                 .collect::<Vec<_>>()
6000:         );
6001:     }
6002: 
6003:     // TP: a `forward` target may legally begin with `-` (a command named
6004:     // `-foo`).  The `-`-flag filter applies only to class-list members
6005:     // (`mixin -append`), never to the forward command name.
6006:     #[test]
6007:     fn forward_target_beginning_with_dash_is_recorded() {
6008:         let mut a = Analyser::new();
6009:         let r = a
6010:             .analyse(
6011:                 "namespace eval ::ns {\n  oo::class create C { forward f -foo }\n}\n",
6012:                 "tcl9.0",
6013:             )
6014:             .clone();
6015:         assert!(
6016:             r.command_invocations.iter().any(|inv| inv.name == "-foo"),
6017:             "a hyphen-prefixed forward target must be recorded: {:?}",
6018:             r.command_invocations
6019:                 .iter()
6020:                 .map(|i| &i.name)
6021:                 .collect::<Vec<_>>()
6022:         );
6023:     }
6024: 
6025:     #[test]
6026:     fn property_subcommand_with_no_kind_defaults_to_readwrite() {
6027:         let mut cd = class();
6028:         let texts: Vec<String> = ["property", "x"].iter().map(|s| (*s).to_string()).collect();
6029:         let argv = [tok((0, 8)), tok((9, 10))];
6030:         apply_oo_subcommand(tcloo(), &texts, &argv, &mut cd);
6031:         let pd = cd.properties.get("x").expect("x recorded");
6032:         assert_eq!(pd.kind, "readwrite");
6033:         assert!(!pd.has_getter);
6034:         assert!(!pd.has_setter);
6035:     }
6036: 
6037:     #[test]
6038:     fn property_subcommand_records_multiple_names() {
6039:         let mut cd = class();
6040:         let texts: Vec<String> = ["property", "x", "y", "-kind", "writable"]
6041:             .iter()
6042:             .map(|s| (*s).to_string())
6043:             .collect();
6044:         let argv = [
6045:             tok((0, 8)),
6046:             tok((9, 10)),
6047:             tok((11, 12)),
6048:             tok((13, 18)),
6049:             tok((19, 27)),
6050:         ];
6051:         apply_oo_subcommand(tcloo(), &texts, &argv, &mut cd);
6052:         assert_eq!(cd.properties.len(), 2);
6053:         assert_eq!(cd.properties["x"].kind, "writable");
6054:         assert_eq!(cd.properties["y"].kind, "writable");
6055:     }
6056: 
6057:     #[test]
6058:     fn extract_method_def_too_few_args_returns_none() {
6059:         // ``method`` with only 1 arg (just the name) — needs 3 (name, params,
6060:         // body), so the grammar's `Body` word at index 2 is absent.
6061:         let member = tcloo().member("method").expect("method is a member");
6062:         let args: Vec<String> = vec!["foo".to_string()];
6063:         let arg_tokens: Vec<Token> = vec![tok((0, 3))];
6064:         let md = extract_method_def(member, &args, &arg_tokens, "method", "public", "");
6065:         assert!(md.is_none());
6066:     }
6067: 
6068:     fn param(name: &str) -> ParamDef {
6069:         ParamDef {
6070:             name: name.to_string(),
6071:             has_default: false,
6072:             default_value: None,
6073:         }
6074:     }
6075: 
6076:     /// Depth coverage: `walk_unknown_stmt` recurses once per nested
6077:     /// `if`/`for`/`while`/`foreach`/`catch`/`try`/`switch`/`Block`/`UpFrame`
6078:     /// body, with no depth cap of its own. Transitively bounded to
6079:     /// `MAX_LOWER_NEST_DEPTH`
6080:     /// (256) by the lowering pass today, so this is defence-in-depth /
6081:     /// consistency with every other full-tree walker in this crate, not a
6082:     /// currently-reproducible crash. 1000 levels of *source* nesting is
6083:     /// comfortably past this new cap; the assertion is that
6084:     /// `extract_unknown_proc_info` returns at all, not what it returns.
6085:     /// Spawns its own big-stack thread since the lexer/CST/segmenter
6086:     /// stages upstream of `walk_unknown_stmt`'s own new cap still walk the
6087:     /// full un-truncated source nesting before lowering's cap trims it —
6088:     /// same rationale as `structured::tests::deeply_nested_if_survives_structured_walk`.
6089:     #[test]
6090:     fn extract_unknown_proc_info_survives_deep_nesting() {
6091:         const DEPTH: usize = 1000;
6092:         const STACK_SIZE: usize = 64 * 1024 * 1024;
6093:         let mut body = String::new();
6094:         for _ in 0..DEPTH {
6095:             body.push_str("if {1} {\n");
6096:         }
6097:         body.push_str("exec ls\n");
6098:         for _ in 0..DEPTH {
6099:             body.push_str("}\n");
6100:         }
6101:         std::thread::Builder::new()
6102:             .stack_size(STACK_SIZE)
6103:             .spawn(move || {
6104:                 let mut a = Analyser::new();
6105:                 let _ = a.extract_unknown_proc_info(&body, &[param("cmd"), param("args")]);
6106:             })
6107:             .unwrap()
6108:             .join()
6109:             .unwrap();
6110:     }
6111: 
6112:     #[test]
6113:     fn extract_unknown_proc_info_empty_body_marks_empty_stub() {
6114:         let mut a = Analyser::new();
6115:         let info = a.extract_unknown_proc_info("", &[param("cmd"), param("args")]);
6116:         assert!(info.empty_stub);
6117:         assert_eq!(info.dispatch_targets.len(), 0);
6118:     }
6119: 
6120:     #[test]
6121:     fn extract_unknown_proc_info_whitespace_body_marks_empty_stub() {
6122:         let mut a = Analyser::new();
6123:         let info = a.extract_unknown_proc_info("   \n  \t ", &[param("cmd"), param("args")]);
6124:         assert!(info.empty_stub);
6125:     }
6126: 
6127:     fn logical_unknown_input(
6128:         context: std::sync::Arc<tcl_registry::model::ContextRegistry>,
6129:     ) -> super::super::ResolvedAnalysisInput {
6130:         let profile = tcl_dialect::DialectProfile::plain_tcl();
6131:         super::super::ResolvedAnalysisInput::new(
6132:             profile,
6133:             profile,
6134:             context,
6135:             tcl_lexer::LexerConfig::for_profile(Some(profile)),
6136:         )
6137:     }
6138: 
6139:     fn logical_unknown_analyser() -> Analyser {
6140:         let input = logical_unknown_input(tcl_registry::model::ingress::context_for_profile(
6141:             tcl_dialect::DialectProfile::plain_tcl(),
6142:         ));
6143:         assert!(input.has_logical_source_name_context());
6144:         Analyser::new().with_resolved_input(input)
6145:     }
6146: 
6147:     #[test]
6148:     fn original_unknown_source_context_requires_retained_logical_input_and_current_registry() {
6149:         // naming.compiler.original-unknown-handler-source-context
6150:         // docs/design/analysis/name-resolution-proofs/compiler-original-unknown-handler-source-context.md
6151:         let body = "switch -exact $cmd {foo {return 1}}";
6152:         let mut missing = Analyser::new();
6153:         assert!(
6154:             missing
6155:                 .extract_unknown_proc_info(body, &[param("cmd")])
6156:                 .dispatch_targets
6157:                 .is_empty()
6158:         );
6159:         let input = logical_unknown_analyser().resolved_input.unwrap();
6160:         let options =
6161:             crate::command_binding::SourceAnalysisOptions::for_logical_source(&input).unwrap();
6162:         let context = input.context_registry();
6163:         let mut lowerer =
6164:             crate::lowering::Lowerer::with_config(context.commands(), input.lexer_config());
6165:         lowerer.set_source_analysis_options(options);
6166:         let lowered = lowerer.lower(body);
6167:         let statement = lowered.top_level.statements.first().unwrap();
6168:         let binding = lowered
6169:             .top_level
6170:             .retained_source_tokens_for_statement(statement)
6171:             .unwrap()
6172:             .source_binding
6173:             .as_ref()
6174:             .unwrap();
6175:         assert_eq!(binding.logical_source_name_advice_input(), Some(&input));
6176:         assert!(matches!(
6177:             statement,
6178:             Statement::Call { .. } | Statement::Barrier { .. }
6179:         ));
6180:         // The possible source bodies do not settle the unknown option branch.
6181:         let metadata = crate::registry_invocation::InvocationMetadataContext::for_analysis_input(
6182:             context.commands(),
6183:             &input,
6184:         )
6185:         .unwrap();
6186:         let case =
6187:             crate::registry_invocation::source_structure::original_logical_source_case_for_tokens(
6188:                 lowered
6189:                     .top_level
6190:                     .retained_source_tokens_for_statement(statement)
6191:                     .unwrap(),
6192:                 context.commands(),
6193:                 metadata,
6194:             )
6195:             .unwrap();
6196:         assert!(case.body_operands().selection_unknown);
6197:         let mut logical = logical_unknown_analyser();
6198:         assert!(
6199:             logical
6200:                 .extract_unknown_proc_info(body, &[param("cmd")])
6201:                 .dispatch_targets
6202:                 .contains("foo")
6203:         );
6204:         let mut logical = logical_unknown_analyser();
6205:         // Retired analyser registry labels cannot replace the retained input.
6206:         logical.registry = Some(
6207:             tcl_registry::model::ingress::static_context_for("f5-irules")
6208:                 .commands()
6209:                 .snapshot()
6210:                 .shared_registry(),
6211:         );
6212:         assert!(
6213:             logical
6214:                 .extract_unknown_proc_info(body, &[param("cmd")])
6215:                 .dispatch_targets
6216:                 .contains("foo")
6217:         );
6218:         for dialect in [
6219:             "tcl8.4",
6220:             "tcl8.5",
6221:             "tcl8.6",
6222:             "tcl9.0",
6223:             "tcl9.1",
6224:             "jimtcl",
6225:             "f5-irules",
6226:             "f5-iapps",
6227:             "f5-tmsh",
6228:         ] {
6229:             let environment = tcl_registry::model::ingress::resolve_environment(dialect);
6230:             let profile = environment.unit_profile();
6231:             let input = super::super::ResolvedAnalysisInput::new(
6232:                 environment.analyser_profile(),
6233:                 profile,
6234:                 environment.default_context_registry(),
6235:                 tcl_lexer::LexerConfig::for_profile(Some(profile)),
6236:             );
6237:             assert!(!input.has_logical_source_name_context(), "{dialect}");
6238:             let mut native = Analyser::new().with_resolved_input(input);
6239:             assert!(
6240:                 native
6241:                     .extract_unknown_proc_info(body, &[param("cmd")])
6242:                     .dispatch_targets
6243:                     .is_empty(),
6244:                 "{dialect}"
6245:             );
6246:         }
6247:     }
6248: 
6249:     #[test]
6250:     fn original_unknown_case_advice_retains_residuals_in_final_info() {
6251:         // naming.compiler.original-unknown-handler-source-context
6252:         // docs/design/analysis/name-resolution-proofs/compiler-original-unknown-handler-source-context.md
6253:         // Possible source dispatch keeps its selection/error and no-match
6254:         // paths; it supplies no Native occupancy, chosen effect or body entry.
6255:         let mut analyser = logical_unknown_analyser();
6256:         let result = analyser.analyse(
6257:             "proc unknown {cmd args} {switch -exact $cmd {café {return 1} default {return 0}}}",
6258:             "tcl",
6259:         );
6260:         let info = result
6261:             .unknown_proc_info
6262:             .expect("original unknown declaration");
6263:         assert!(info.dispatch_targets.contains("café"));
6264:         assert!(!info.dispatch_targets.contains("default"));
6265:         assert!(!info.has_pattern_dispatch);
6266:         let [residual] = info.case_body_residuals.as_slice() else {
6267:             panic!("the final AnalysisResult must retain its canonical case residual")
6268:         };
6269:         assert!(residual.selection_unknown);
6270:         assert!(!residual.no_match_possible);
6271:         assert_eq!(residual.bodies.len(), 2);
6272:         assert_eq!(residual.patterns.len(), 2);
6273: 
6274:         let input = logical_unknown_analyser().resolved_input.unwrap();
6275:         let context = input.context_registry();
6276:         let closed = "switch -exact -- $cmd {foo {return 1} default {return 0}}";
6277:         let mut lowerer =
6278:             crate::lowering::Lowerer::with_config(context.commands(), input.lexer_config())
6279:                 .with_resolved_analysis_input(input.clone());
6280:         let script = lowerer.lower(closed).top_level.clone();
6281:         assert!(matches!(
6282:             script.statements.first(),
6283:             Some(Statement::Switch { .. })
6284:         ));
6285:         let mut analyser = Analyser::new().with_resolved_input(input);
6286:         let info = analyser.extract_unknown_proc_info(closed, &[param("cmd")]);
6287:         assert!(info.dispatch_targets.contains("foo"));
6288:         assert_eq!(info.case_body_residuals.len(), 1);
6289:         assert!(!info.case_body_residuals[0].selection_unknown);
6290:         assert!(!info.case_body_residuals[0].no_match_possible);
6291:     }
6292: 
6293:     #[test]
6294:     fn original_unknown_case_advice_keeps_captured_ordinals_and_literal_parameter_names() {
6295:         // naming.compiler.original-unknown-handler-source-context
6296:         // docs/design/analysis/name-resolution-proofs/compiler-original-unknown-handler-source-context.md
6297:         let source = "interp alias {} ::choisiré {} switch -exact; ::choisiré $cmd {é {return 1} default {return 0}}";
6298:         let mut analyser = logical_unknown_analyser();
6299:         let info = analyser.extract_unknown_proc_info(source, &[param("cmd")]);
6300:         assert!(info.dispatch_targets.contains("é"));
6301:         let [residual] = info.case_body_residuals.as_slice() else {
6302:             panic!("the captured selector retains a case residual")
6303:         };
6304:         assert!(residual.selection_unknown);
6305:         assert_eq!(residual.bodies[0].argument, 2);
6306:         assert_eq!(residual.bodies[0].list_element, Some(1));
6307:         assert_eq!(residual.patterns[0].argument, 2);
6308:         assert_eq!(residual.patterns[0].list_element, Some(0));
6309: 
6310:         for source in [
6311:             "switch -exact $cmdSuffix {foo {return 1}}",
6312:             "switch -exact {$cmd} {foo {return 1}}",
6313:             "switch -exact $cmd(index) {foo {return 1}}",
6314:         ] {
6315:             let info = analyser.extract_unknown_proc_info(source, &[param("cmd")]);
6316:             assert!(info.dispatch_targets.is_empty(), "{source}");
6317:             assert!(info.case_body_residuals.is_empty(), "{source}");
6318:         }
6319:         let info = analyser.extract_unknown_proc_info(
6320:             "switch -exact ${$cmd} {literal {return 1}}",
6321:             &[param("$cmd")],
6322:         );
6323:         assert!(info.dispatch_targets.contains("literal"));
6324:     }
6325: 
6326:     fn original_case_availability_contexts() -> (
6327:         std::sync::Arc<tcl_registry::model::ContextRegistry>,
6328:         std::sync::Arc<tcl_registry::model::ContextRegistry>,
6329:     ) {
6330:         use std::sync::Arc;
6331:         let baseline = tcl_registry::model::ingress::static_context_for("tcl8.6");
6332:         let mut registry = baseline
6333:             .commands()
6334:             .project_for_profile(tcl_dialect::DialectProfile::find("tcl8.6").unwrap());
6335:         let mut spec = registry.get("switch").unwrap().clone();
6336:         spec.name = "current_case";
6337:         spec.surface = Some(tcl_dialect::model::SpecSurface::TCL86_PLUS);
6338:         registry.insert(spec);
6339:         let current = Arc::new(baseline.with_command_store(Arc::new(registry)));
6340:         let older = Arc::new(
6341:             tcl_registry::model::ingress::static_context_for("tcl8.4")
6342:                 .with_command_store(Arc::clone(current.commands())),
6343:         );
6344:         assert!(Arc::ptr_eq(current.commands(), older.commands()));
6345:         (current, older)
6346:     }
6347: 
6348:     #[test]
6349:     fn original_unknown_case_advice_refuses_missing_foreign_changed_and_shadowed_owners() {
6350:         // naming.compiler.original-unknown-handler-source-context
6351:         // docs/design/analysis/name-resolution-proofs/compiler-original-unknown-handler-source-context.md
6352:         use crate::registry_invocation::{
6353:             InvocationMetadataContext, source_structure::original_logical_source_case_for_tokens,
6354:         };
6355:         use std::sync::Arc;
6356:         let (current, older) = original_case_availability_contexts();
6357:         let input = logical_unknown_input(Arc::clone(&current));
6358:         let profile = input.unit_profile();
6359:         let config = input.lexer_config();
6360:         let source =
6361:             "interp alias {} selecté {} current_case -exact; selecté $cmd {foo {return 1}}";
6362:         let mut analyser = Analyser::new().with_resolved_input(input.clone());
6363:         let positive = analyser.extract_unknown_proc_info(source, &[param("cmd")]);
6364:         assert!(positive.dispatch_targets.contains("foo"));
6365:         assert!(positive.case_body_residuals[0].no_match_possible);
6366:         let mut lowerer = crate::lowering::Lowerer::with_config(current.commands(), config)
6367:             .with_resolved_analysis_input(input.clone());
6368:         let script = lowerer.lower(source).top_level.clone();
6369:         let tokens = script
6370:             .retained_source_tokens_for_statement(script.statements.last().unwrap())
6371:             .unwrap();
6372:         let metadata =
6373:             InvocationMetadataContext::for_analysis_input(current.commands(), &input).unwrap();
6374:         assert!(
6375:             original_logical_source_case_for_tokens(tokens, current.commands(), metadata).is_some()
6376:         );
6377:         assert!(
6378:             original_logical_source_case_for_tokens(
6379:                 tokens,
6380:                 current.commands(),
6381:                 current.as_ref().into()
6382:             )
6383:             .is_none()
6384:         );
6385:         let foreign = logical_unknown_input(
6386:             tcl_registry::model::ingress::resolve_environment("tcl9.1").default_context_registry(),
6387:         );
6388:         let mut changed_config = config;
6389:         changed_config.strict_quoting = !changed_config.strict_quoting;
6390:         let changed = super::super::ResolvedAnalysisInput::new(
6391:             profile,
6392:             profile,
6393:             Arc::clone(&current),
6394:             changed_config,
6395:         );
6396:         for input in [&foreign, &changed] {
6397:             let metadata = InvocationMetadataContext::for_analysis_input(
6398:                 input.borrowed_context_registry().commands(),
6399:                 input,
6400:             )
6401:             .unwrap();
6402:             assert!(
6403:                 original_logical_source_case_for_tokens(tokens, current.commands(), metadata)
6404:                     .is_none()
6405:             );
6406:         }
6407:         let mut missing = tokens.clone();
6408:         missing.source_binding = None;
6409:         assert!(
6410:             original_logical_source_case_for_tokens(&missing, current.commands(), metadata)
6411:                 .is_none()
6412:         );
6413:         let mut altered = tokens.clone();
6414:         let crate::ir::WordExpr::Variable { spelling, .. } = &mut altered.word_exprs[1] else {
6415:             panic!("original written subject")
6416:         };
6417:         *spelling = "$other".into();
6418:         assert!(
6419:             original_logical_source_case_for_tokens(&altered, current.commands(), metadata)
6420:                 .is_none()
6421:         );
6422:         let mut absent = Analyser::new();
6423:         assert!(
6424:             absent
6425:                 .extract_unknown_proc_info(source, &[param("cmd")])
6426:                 .dispatch_targets
6427:                 .is_empty()
6428:         );
6429:         let mut unavailable = Analyser::new().with_resolved_input(logical_unknown_input(older));
6430:         assert!(
6431:             unavailable
6432:                 .extract_unknown_proc_info(source, &[param("cmd")])
6433:                 .dispatch_targets
6434:                 .is_empty()
6435:         );
6436:         for source in [
6437:             "proc current_case args {}; interp alias {} selecté {} current_case -exact; selecté $cmd {foo {return 1}}",
6438:             "interp alias {} selecté {} current_case -exact; proc current_case args {}; selecté $cmd {foo {return 1}}",
6439:             "current_case $option $cmd {foo {return 1}}",
6440:         ] {
6441:             assert!(
6442:                 analyser
6443:                     .extract_unknown_proc_info(source, &[param("cmd")])
6444:                     .dispatch_targets
6445:                     .is_empty(),
6446:                 "{source}"
6447:             );
6448:         }
6449:     }
6450: 
6451:     #[test]
6452:     fn original_unknown_case_advice_selects_the_original_case_fold_child() {
6453:         // naming.compiler.original-unknown-handler-source-context
6454:         // docs/design/analysis/name-resolution-proofs/compiler-original-unknown-handler-source-context.md
6455:         let mut analyser = logical_unknown_analyser();
6456:         let source =
6457:             "interp alias {} foldé {} string tolower; switch -exact [foldé $cmd] {foo {return 1}}";
6458:         let info = analyser.extract_unknown_proc_info(source, &[param("cmd")]);
6459:         assert!(info.dispatch_targets.contains("foo"));
6460:         assert!(info.case_insensitive);
6461:         for source in [
6462:             "proc string args {}; switch -exact [string tolower $cmd] {foo {return 1}}",
6463:             "switch -exact [list {string tolower $cmd}] {foo {return 1}}",
6464:             "switch -exact [string tolower $other] {foo {return 1}}",
6465:         ] {
6466:             let info = analyser.extract_unknown_proc_info(source, &[param("cmd")]);
6467:             assert!(info.dispatch_targets.is_empty(), "{source}");
6468:             assert!(!info.case_insensitive, "{source}");
6469:         }
6470:         let input = logical_unknown_analyser().resolved_input.unwrap();
6471:         let context = input.context_registry();
6472:         let mut lowerer =
6473:             crate::lowering::Lowerer::with_config(context.commands(), input.lexer_config())
6474:                 .with_resolved_analysis_input(input.clone());
6475:         let script = lowerer.lower(source).top_level.clone();
6476:         let mut tokens = script
6477:             .retained_source_tokens_for_statement(script.statements.last().unwrap())
6478:             .unwrap()
6479:             .clone();
6480:         assert!(!tokens.nested_bindings.is_empty());
6481:         tokens.nested_bindings.clear();
6482:         let metadata = crate::registry_invocation::InvocationMetadataContext::for_analysis_input(
6483:             context.commands(),
6484:             &input,
6485:         )
6486:         .unwrap();
6487:         let case =
6488:             crate::registry_invocation::source_structure::original_logical_source_case_for_tokens(
6489:                 &tokens,
6490:                 context.commands(),
6491:                 metadata,
6492:             )
6493:             .unwrap();
6494:         assert!(!case.references_parameter("cmd"));
6495:         assert!(!case.folds_case());
6496:     }
6497: 
6498:     #[test]
6499:     fn original_unknown_native_case_advice_requires_typed_switch_and_original_input() {
6500:         // naming.compiler.original-unknown-handler-source-context
6501:         // docs/design/analysis/name-resolution-proofs/compiler-original-unknown-handler-source-context.md
6502:         // This fixture retains actual registration and compiler entry. The
6503:         // readonly case query grants no successful variable read or body entry.
6504:         use crate::registry_invocation::{
6505:             InvocationMetadataContext, InvocationMetadataInput,
6506:             source_structure::original_native_source_case_for_statement,
6507:         };
6508:         let environment = tcl_registry::model::ingress::resolve_environment("tcl8.6");
6509:         let profile = environment.unit_profile();
6510:         let context = environment.default_context_registry();
6511:         let config = tcl_lexer::LexerConfig::for_profile(Some(profile));
6512:         let input = super::super::ResolvedAnalysisInput::new(
6513:             environment.analyser_profile(),
6514:             profile,
6515:             context.clone(),
6516:             config,
6517:         );
6518:         let (_owner, captured) =
6519:             crate::environment_ingress::captured_native_entry_with_owner(profile);
6520:         let options = crate::command_binding::SourceAnalysisOptions {
6521:             metadata_context: InvocationMetadataInput::SuppliedSource(Some(&input)),
6522:             native_entry: Some(&captured),
6523:             invocation_dialect: Some(tcl_registry::InvocationDialect::of_profile(profile)),
6524:             native_compilation: crate::environment_ingress::authoring_native_compilation(),
6525:             ..Default::default()
6526:         };
6527:         let mut lowerer = crate::lowering::Lowerer::with_config(context.commands(), config)
6528:             .with_dialect(Some(profile))
6529:             .with_resolved_analysis_input(input.clone());
6530:         lowerer.set_source_analysis_options(options);
6531:         let script = lowerer
6532:             .lower("switch -exact -- $cmd {foo {return 1} default {return 0}}")
6533:             .top_level
6534:             .clone();
6535:         let statement = script.statements.first().unwrap();
6536:         assert!(matches!(statement, Statement::Switch { .. }));
6537:         let metadata =
6538:             InvocationMetadataContext::for_analysis_input(context.commands(), &input).unwrap();
6539:         let case = original_native_source_case_for_statement(
6540:             &script,
6541:             statement,
6542:             context.commands(),
6543:             metadata,
6544:         )
6545:         .expect("typed original Native case source");
6546:         assert!(case.references_parameter("cmd"));
6547:         assert_eq!(case.patterns(), &["foo"]);
6548:         assert!(!case.body_operands().selection_unknown);
6549:         assert!(!case.body_operands().no_match_possible);
6550:         let mut info = UnknownProcInfo::default();
6551:         walk_unknown_stmt(
6552:             statement,
6553:             &script,
6554:             &context,
6555:             Some(metadata),
6556:             "cmd",
6557:             &mut info,
6558:             0,
6559:         );
6560:         assert!(info.dispatch_targets.contains("foo"));
6561:         assert_eq!(info.case_body_residuals.len(), 1);
6562:         assert!(
6563:             original_native_source_case_for_statement(
6564:                 &script,
6565:                 statement,
6566:                 context.commands(),
6567:                 context.as_ref().into(),
6568:             )
6569:             .is_none()
6570:         );
6571:         let mut missing = script.clone();
6572:         missing.command_binding_sites = Default::default();
6573:         assert!(
6574:             original_native_source_case_for_statement(
6575:                 &missing,
6576:                 &missing.statements[0],
6577:                 context.commands(),
6578:                 metadata,
6579:             )
6580:             .is_none()
6581:         );
6582:         let mut generic_lowerer = crate::lowering::Lowerer::with_config(context.commands(), config)
6583:             .with_resolved_analysis_input(input.clone());
6584:         let generic = generic_lowerer
6585:             .lower("switch -exact -- $cmd {foo {return 1} default {return 0}}")
6586:             .top_level
6587:             .clone();
6588:         let generic_statement = generic.statements.first().unwrap();
6589:         assert!(!matches!(generic_statement, Statement::Switch { .. }));
6590:         assert!(
6591:             original_native_source_case_for_statement(
6592:                 &generic,
6593:                 generic_statement,
6594:                 context.commands(),
6595:                 metadata,
6596:             )
6597:             .is_none()
6598:         );
6599:     }
6600: 
6601:     #[test]
6602:     fn extract_unknown_proc_info_exact_switch_collects_dispatch_targets() {
6603:         let mut a = logical_unknown_analyser();
6604:         let body = r"switch -exact $cmd {
6605:             foo { return 1 }
6606:             bar { return 2 }
6607:             default { return 0 }
6608:         }";
6609:         let info = a.extract_unknown_proc_info(body, &[param("cmd"), param("args")]);
6610:         assert!(!info.empty_stub);
6611:         assert!(info.dispatch_targets.contains("foo"));
6612:         assert!(info.dispatch_targets.contains("bar"));
6613:         assert!(!info.dispatch_targets.contains("default"));
6614:         assert!(!info.has_pattern_dispatch);
6615:     }
6616: 
6617:     #[test]
6618:     fn extract_unknown_proc_info_glob_switch_marks_pattern_dispatch() {
6619:         let mut a = logical_unknown_analyser();
6620:         let body = r"switch -glob $cmd {
6621:             foo* { return 1 }
6622:             *bar { return 2 }
6623:         }";
6624:         let info = a.extract_unknown_proc_info(body, &[param("cmd"), param("args")]);
6625:         assert!(info.has_pattern_dispatch);
6626:         assert_eq!(info.dispatch_targets.len(), 0);
6627:     }
6628: 
6629:     #[test]
6630:     fn extract_unknown_proc_info_chains_original_via_known_target() {
6631:         let mut a = logical_unknown_analyser();
6632:         let body = r"rename unknown _original_unknown
6633: _original_unknown $cmd $args";
6634:         let info = a.extract_unknown_proc_info(body, &[param("cmd"), param("args")]);
6635:         assert!(info.chains_original);
6636:     }
6637: 
6638:     #[test]
6639:     fn unknown_handler_effects_require_the_live_implementation() {
6640:         for (body, flag) in [
6641:             ("proc exec args {}; exec $cmd", "exec"),
6642:             ("proc auto_load args {}; auto_load $cmd", "load"),
6643:             ("_original_unknown $cmd", "chain"),
6644:             ("if {$condition} {rename exec {}}; exec $cmd", "exec"),
6645:         ] {
6646:             let mut analyser = logical_unknown_analyser();
6647:             let info = analyser.extract_unknown_proc_info(body, &[param("cmd")]);
6648:             let claimed = match flag {
6649:                 "exec" => info.has_exec,
6650:                 "load" => info.has_auto_load,
6651:                 _ => info.chains_original,
6652:             };
6653:             assert!(
6654:                 !claimed,
6655:                 "unproved implementation acquired builtin effects: {body}"
6656:             );
6657:         }
6658:         let mut analyser = Analyser::new();
6659:         let result = analyser.analyse(
6660:             "proc exec args {}; proc unknown {cmd args} {exec $cmd}",
6661:             "tcl8.6",
6662:         );
6663:         assert!(!result.unknown_proc_info.as_ref().unwrap().has_exec);
6664:     }
6665: 
6666:     #[test]
6667:     fn unknown_handler_effects_follow_resolved_alias_arguments() {
6668:         let mut analyser = logical_unknown_analyser();
6669:         let info = analyser.extract_unknown_proc_info(
6670:             "interp alias {} ensure {} package require; ensure Tcl",
6671:             &[param("cmd")],
6672:         );
6673:         assert!(info.has_auto_load);
6674:     }
6675: 
6676:     #[test]
6677:     fn original_unknown_operation_advice_keeps_actual_availability_and_captured_sources() {
6678:         // naming.compiler.original-unknown-handler-source-context
6679:         // docs/design/analysis/name-resolution-proofs/compiler-original-unknown-handler-source-context.md
6680:         // Operation descriptions are conditional source advice, without an
6681:         // executed load, Native handler, cell, frame or Normal certificate.
6682:         use std::sync::Arc;
6683:         let baseline = tcl_registry::model::ingress::static_context_for("tcl8.6");
6684:         let mut registry = baseline
6685:             .commands()
6686:             .project_for_profile(tcl_dialect::DialectProfile::find("tcl8.6").unwrap());
6687:         let mut loader = registry.get("package").unwrap().clone();
6688:         loader.name = "context_package";
6689:         loader.surface = Some(tcl_dialect::model::SpecSurface::TCL86_PLUS);
6690:         let mut subcommands = loader.subcommands.to_vec();
6691:         subcommands
6692:             .iter_mut()
6693:             .find(|subcommand| subcommand.name == "require")
6694:             .unwrap()
6695:             .surface = Some(tcl_dialect::model::SpecSurface::TCL86_PLUS);
6696:         loader.subcommands = Box::leak(subcommands.into_boxed_slice());
6697:         registry.insert(loader);
6698:         let current = Arc::new(baseline.with_command_store(Arc::new(registry)));
6699:         let older = Arc::new(
6700:             tcl_registry::model::ingress::static_context_for("tcl8.4")
6701:                 .with_command_store(Arc::clone(current.commands())),
6702:         );
6703:         assert!(Arc::ptr_eq(current.commands(), older.commands()));
6704:         let profile = tcl_dialect::DialectProfile::plain_tcl();
6705:         let config = tcl_lexer::LexerConfig::for_file_grammar(profile.grammar);
6706:         let input =
6707:             |context| super::super::ResolvedAnalysisInput::new(profile, profile, context, config);
6708:         let source = "interp alias {} ::chargeré {} context_package require; ::chargeré Tcl";
6709:         let mut analyser = Analyser::new().with_resolved_input(input(Arc::clone(&current)));
6710:         assert!(
6711:             analyser
6712:                 .extract_unknown_proc_info(source, &[param("cmd")])
6713:                 .has_auto_load
6714:         );
6715:         analyser.registry = Some(
6716:             tcl_registry::model::ingress::static_context_for("f5-irules")
6717:                 .commands()
6718:                 .snapshot()
6719:                 .shared_registry(),
6720:         );
6721:         assert!(
6722:             analyser
6723:                 .extract_unknown_proc_info(source, &[param("cmd")])
6724:                 .has_auto_load
6725:         );
6726:         let mut unavailable = Analyser::new().with_resolved_input(input(older));
6727:         assert!(
6728:             !unavailable
6729:                 .extract_unknown_proc_info(source, &[param("cmd")])
6730:                 .has_auto_load
6731:         );
6732:         let replaced = "proc context_package args {}; interp alias {} ensure {} context_package require; ensure Tcl";
6733:         assert!(
6734:             !analyser
6735:                 .extract_unknown_proc_info(replaced, &[param("cmd")])
6736:                 .has_auto_load
6737:         );
6738:     }
6739: 
6740:     fn assert_captured_logical_source_target(
6741:         tokens: &crate::ir::CommandTokens,
6742:         context: &tcl_registry::model::ContextRegistry,
6743:         metadata: crate::registry_invocation::InvocationMetadataContext<'_>,
6744:     ) {
6745:         let input = metadata.source_analysis_input().unwrap();
6746:         let original = tokens.source_binding.as_ref().unwrap();
6747:         let target = original
6748:             .proved_execution_target()
6749:             .expect("closed Logical source target");
6750:         assert!(target.registry_backed);
6751:         let dialect = original
6752:             .original_source_word_dialect_for_tokens(tokens)
6753:             .expect("actual Logical source dialect");
6754:         assert!(dialect.native_name_protocol().is_none());
6755:         assert!(
6756:             crate::command_binding::SourceAnalysisOptions::for_logical_source(input)
6757:                 .unwrap()
6758:                 .native_entry
6759:                 .is_none()
6760:         );
6761:         let selected = crate::registry_invocation::original_logical_operation_invocation_with_metadata_context(
6762:             context.commands(), metadata, tokens,
6763:         ).unwrap();
6764:         assert!(
6765:             selected
6766:                 .with_metadata_schema(
6767:                     context.commands(),
6768:                     metadata,
6769:                     original.invocation_realm().unwrap(),
6770:                     |schema| {
6771:                         let target_spec = context.context().resolve_spec_in_realm(
6772:                             context.commands(),
6773:                             &target.command,
6774:                             original.invocation_realm().unwrap(),
6775:                         )?;
6776:                         Some(std::ptr::eq(
6777:                             target_spec,
6778:                             schema.authored_source_descriptors().command,
6779:                         ))
6780:                     },
6781:                 )
6782:                 .unwrap()
6783:         );
6784:         assert_eq!(
6785:             selected.evaluated_words[0].literal_bytes(),
6786:             Some(b"require".as_slice())
6787:         );
6788:         assert_eq!(
6789:             selected.effective.origins[1],
6790:             crate::registry_invocation::InvocationWordOrigin::BindingPrefix(0)
6791:         );
6792:         assert_eq!(selected.effective.written_argument(1), Some(0));
6793:     }
6794: 
6795:     #[test]
6796:     fn original_unknown_operation_advice_refuses_missing_foreign_changed_and_dynamic_source() {
6797:         // naming.compiler.original-unknown-handler-source-context
6798:         // docs/design/analysis/name-resolution-proofs/compiler-original-unknown-handler-source-context.md
6799:         use crate::registry_invocation::InvocationMetadataContext;
6800:         let input = logical_unknown_analyser().resolved_input.unwrap();
6801:         let context = input.context_registry();
6802:         let source = "interp alias {} ensure {} package require; ensure Tcl";
6803:         let mut lowerer =
6804:             crate::lowering::Lowerer::with_config(context.commands(), input.lexer_config())
6805:                 .with_resolved_analysis_input(input.clone());
6806:         let script = lowerer.lower(source).top_level.clone();
6807:         let statement = script.statements.last().unwrap();
6808:         let original = statement.tokens().unwrap().source_binding.as_ref().unwrap();
6809:         assert!(original.original_recorded_head_name_input().is_none());
6810:         let metadata = InvocationMetadataContext::for_source_input(
6811:             context.commands(),
6812:             &input,
6813:             input.lexer_config(),
6814:             Some(input.unit_profile()),
6815:         )
6816:         .unwrap();
6817:         assert_captured_logical_source_target(statement.tokens().unwrap(), &context, metadata);
6818:         let inspect = |statement: &Statement, metadata| {
6819:             let mut info = UnknownProcInfo::default();
6820:             walk_unknown_stmt(statement, &script, &context, metadata, "cmd", &mut info, 0);
6821:             info
6822:         };
6823:         assert!(inspect(statement, Some(metadata)).has_auto_load);
6824:         let foreign = super::super::ResolvedAnalysisInput::new(
6825:             input.analyser_profile(),
6826:             input.unit_profile(),
6827:             tcl_registry::model::ingress::resolve_environment("tcl9.1").default_context_registry(),
6828:             input.lexer_config(),
6829:         );
6830:         let mut config = input.lexer_config();
6831:         config.strict_quoting = !config.strict_quoting;
6832:         let changed = super::super::ResolvedAnalysisInput::new(
6833:             input.analyser_profile(),
6834:             input.unit_profile(),
6835:             input.context_registry(),
6836:             config,
6837:         );
6838:         for metadata in [
6839:             None,
6840:             Some(context.as_ref().into()),
6841:             InvocationMetadataContext::for_analysis_input(
6842:                 foreign.borrowed_context_registry().commands(),
6843:                 &foreign,
6844:             ),
6845:             InvocationMetadataContext::for_analysis_input(context.commands(), &changed),
6846:         ] {
6847:             assert!(!inspect(statement, metadata).has_auto_load);
6848:         }
6849:         let mut missing = statement.clone();
6850:         missing.tokens_mut().unwrap().source_binding = None;
6851:         assert!(!inspect(&missing, Some(metadata)).has_auto_load);
6852:         let mut analyser = logical_unknown_analyser();
6853:         for source in [
6854:             "interp alias {} ensure {} package $selector; ensure Tcl",
6855:             "interp alias {} ensure {} package require; $unknown Tcl",
6856:             "interp alias {} ensure {} package require; proc package args {}; ensure Tcl",
6857:         ] {
6858:             assert!(
6859:                 !analyser
6860:                     .extract_unknown_proc_info(source, &[param("cmd")])
6861:                     .has_auto_load,
6862:                 "{source}"
6863:             );
6864:         }
6865:         assert!(
6866:             !Analyser::new()
6867:                 .extract_unknown_proc_info(source, &[param("cmd")])
6868:                 .has_auto_load
6869:         );
6870:     }
6871: 
6872:     #[test]
6873:     fn original_unknown_operation_purpose_requires_the_complete_original_source_input() {
6874:         // naming.compiler.original-unknown-handler-source-context
6875:         // docs/design/analysis/name-resolution-proofs/compiler-original-unknown-handler-source-context.md
6876:         let input = logical_unknown_analyser().resolved_input.unwrap();
6877:         let context = input.context_registry();
6878:         let source = "interp alias {} ensure {} package require; ensure Tcl";
6879:         let mut lowerer =
6880:             crate::lowering::Lowerer::with_config(context.commands(), input.lexer_config())
6881:                 .with_resolved_analysis_input(input.clone());
6882:         let script = lowerer.lower(source).top_level.clone();
6883:         let statement = script.statements.last().unwrap();
6884:         let metadata = crate::registry_invocation::InvocationMetadataContext::for_analysis_input(
6885:             context.commands(),
6886:             &input,
6887:         )
6888:         .unwrap();
6889:         let mut selected = UnknownProcInfo::default();
6890:         walk_unknown_stmt(
6891:             statement,
6892:             &script,
6893:             &context,
6894:             Some(metadata),
6895:             "cmd",
6896:             &mut selected,
6897:             0,
6898:         );
6899:         assert!(selected.has_auto_load);
6900:         let native_profile =
6901:             tcl_registry::model::ingress::resolve_environment("tcl8.6").analyser_profile();
6902:         let native_input = super::super::ResolvedAnalysisInput::new(
6903:             native_profile,
6904:             native_profile,
6905:             std::sync::Arc::clone(&context),
6906:             input.lexer_config(),
6907:         );
6908:         assert!(!native_input.has_logical_source_name_context());
6909:         for metadata in [
6910:             None,
6911:             Some(context.as_ref().into()),
6912:             crate::registry_invocation::InvocationMetadataContext::for_analysis_input(
6913:                 context.commands(),
6914:                 &native_input,
6915:             ),
6916:         ] {
6917:             let mut refused = UnknownProcInfo::default();
6918:             walk_unknown_stmt(
6919:                 statement,
6920:                 &script,
6921:                 &context,
6922:                 metadata,
6923:                 "cmd",
6924:                 &mut refused,
6925:                 0,
6926:             );
6927:             assert!(!refused.has_auto_load);
6928:             assert!(!refused.has_exec);
6929:             assert!(!refused.chains_original);
6930:             assert!(refused.dispatch_targets.is_empty());
6931:         }
6932:     }
6933: 
6934:     #[test]
6935:     fn extract_unknown_proc_info_detects_exec_call() {
6936:         let mut a = logical_unknown_analyser();
6937:         let body = r"exec $cmd {*}$args";
6938:         let info = a.extract_unknown_proc_info(body, &[param("cmd"), param("args")]);
6939:         assert!(info.has_exec);
6940:     }
6941: 
6942:     #[test]
6943:     fn extract_unknown_proc_info_detects_auto_load_call() {
6944:         let mut a = logical_unknown_analyser();
6945:         let body = r"auto_load $cmd";
6946:         let info = a.extract_unknown_proc_info(body, &[param("cmd"), param("args")]);
6947:         assert!(info.has_auto_load);
6948:     }
6949: 
6950:     #[test]
6951:     fn extract_unknown_proc_info_case_insensitive_via_string_tolower() {
6952:         let mut a = logical_unknown_analyser();
6953:         let body = r"switch -exact [string tolower $cmd] {
6954:             foo { return 1 }
6955:         }";
6956:         let info = a.extract_unknown_proc_info(body, &[param("cmd"), param("args")]);
6957:         assert!(info.case_insensitive);
6958:         assert!(info.dispatch_targets.contains("foo"));
6959:     }
6960: 
6961:     #[test]
6962:     fn extract_unknown_proc_info_no_first_param_defaults_to_cmd() {
6963:         // Empty params list — the helper should fall back to
6964:         // ``"cmd"`` as the dispatch-subject variable name.
6965:         let mut a = logical_unknown_analyser();
6966:         let body = r"switch -exact $cmd { foo { return 1 } }";
6967:         let info = a.extract_unknown_proc_info(body, &[]);
6968:         assert!(info.dispatch_targets.contains("foo"));
6969:     }
6970: 
6971:     // The `self { … }` / `private { … }` block forms.
6972: 
6973:     #[test]
6974:     fn self_block_form_records_every_member_as_a_class_method() {
6975:         // TP. Oracle (tclsh 9.0.4 / 8.6.16, identical):
6976:         //   oo::class create ::C {
6977:         //       self { method make {n} {…} ; method other {} {…} }
6978:         //       method inst {} {…}
6979:         //   }
6980:         //   ::C make 7               -> made-7
6981:         //   info object methods ::C  -> other make   (class-object side)
6982:         //   info class methods ::C   -> inst         (instance side)
6983:         //   oo::class create ::F {superclass ::C} ; ::F make 1
6984:         //                            -> error: unknown method "make"
6985:         // i.e. exactly what the `self method …` prefix form declares — which
6986:         // is why both spellings land on the same recording path.
6987:         let src = "oo::class create ::C {\n\
6988:                    self {\n\
6989:                    method make {n} { return $n }\n\
6990:                    method other {} { return other }\n\
6991:                    }\n\
6992:                    method inst {} { return inst }\n\
6993:                    }";
6994:         let mut a = Analyser::new();
6995:         let r = a.analyse(src, "tcl9.0");
6996:         let c = r.all_classes.get("::C").expect("::C recorded");
6997:         for name in ["make", "other"] {
6998:             let md = c
6999:                 .class_methods
7000:                 .get(name)
7001:                 .unwrap_or_else(|| panic!("`{name}` must record as a class method"));
7002:             assert_eq!(md.kind, "classmethod");
7003:             assert!(
7004:                 md.is_self_method,
7005:                 "`self`-scoped members are not inherited by subclasses",
7006:             );
7007:             assert_eq!(md.visibility, "public");
7008:         }
7009:         // The instance side is untouched — `inst` stays an instance method and
7010:         // the block's members never leak into it.
7011:         assert!(c.methods.contains_key("inst"));
7012:         assert!(!c.methods.contains_key("make"));
7013:         assert!(!c.methods.contains_key("other"));
7014:     }
7015: 
7016:     #[test]
7017:     fn self_block_form_records_through_oo_define_too() {
7018:         // TP. Same block, reached through `oo::define` rather than the class
7019:         // creation body (oracle: `oo::define ::D { self { method mk {} {…} } }`
7020:         // → `info object methods ::D` is `mk`).
7021:         let src = "oo::class create ::D {}\n\
7022:                    oo::define ::D {\n\
7023:                    self {\n\
7024:                    method mk {} { return dmk }\n\
7025:                    }\n\
7026:                    }";
7027:         let mut a = Analyser::new();
7028:         let r = a.analyse(src, "tcl9.0");
7029:         let c = r.all_classes.get("::D").expect("::D recorded");
7030:         assert!(c.class_methods.contains_key("mk"));
7031:     }
7032: 
7033:     #[test]
7034:     fn self_block_scoped_unexport_flips_the_class_side() {
7035:         // TP. Oracle: `oo::class create ::E { self { method
7036:         // hidden {} {…} ; unexport hidden } }` leaves `info object methods
7037:         // ::E` empty while `-all -private` still lists `hidden`, and
7038:         // `::E hidden` errors "unknown method" — so the block's `unexport`
7039:         // really does apply to the class-object side. The member is recorded
7040:         // *and* now carries the visibility the block gave it.
7041:         let src = "oo::class create ::E {\n\
7042:                    self {\n\
7043:                    method hidden {} { return h }\n\
7044:                    unexport hidden\n\
7045:                    }\n\
7046:                    }";
7047:         let mut a = Analyser::new();
7048:         let r = a.analyse(src, "tcl9.0");
7049:         let c = r.all_classes.get("::E").expect("::E recorded");
7050:         assert!(c.class_methods.contains_key("hidden"));
7051:         assert_eq!(c.class_methods["hidden"].visibility, "unexported");
7052:     }
7053: 
7054:     #[test]
7055:     fn self_scoped_unexport_leaves_a_same_named_instance_method_alone() {
7056:         // TN — block and prefix spellings both.
7057:         // Oracle, byte-identical on tclsh 9.0.4 and 8.6.14:
7058:         //   oo::class create C { method m {} {return inst-m}
7059:         //                        self { method m {} {return class-m}
7060:         //                               unexport m } }
7061:         //   info object methods ::C  ->            (class side unexported)
7062:         //   info class methods ::C   -> m          (instance side untouched)
7063:         //   ::C m                    -> unknown method "m"
7064:         //   [::C new] m              -> inst-m
7065:         for src in [
7066:             "oo::class create ::C {\n\
7067:              method m {} { return inst }\n\
7068:              self {\n\
7069:              method m {} { return class }\n\
7070:              unexport m\n\
7071:              }\n\
7072:              }",
7073:             "oo::class create ::C {\n\
7074:              method m {} { return inst }\n\
7075:              self method m {} { return class }\n\
7076:              self unexport m\n\
7077:              }",
7078:         ] {
7079:             let mut a = Analyser::new();
7080:             let r = a.analyse(src, "tcl9.0");
7081:             let c = r.all_classes.get("::C").expect("::C recorded");
7082:             assert_eq!(
7083:                 c.class_methods["m"].visibility, "unexported",
7084:                 "class side must be flipped",
7085:             );
7086:             assert_eq!(
7087:                 c.methods["m"].visibility, "public",
7088:                 "instance side must NOT be flipped by a `self`-scoped unexport",
7089:             );
7090:             assert!(
7091:                 !c.unexports.contains("m"),
7092:                 "the class-level `unexports` set is the instance-side record; a \
7093:                  class-object-side unexport must not enter it",
7094:             );
7095:         }
7096:     }
7097: 
7098:     #[test]
7099:     fn unwrapped_unexport_leaves_the_class_side_alone() {
7100:         // TN, the mirror direction. Oracle:
7101:         //   oo::class create E2 { self { method onlyclass {} {…} } }
7102:         //   oo::define E2 { unexport onlyclass }
7103:         //   info object methods ::E2 -> onlyclass   (still exported)
7104:         //   ::E2 onlyclass           -> oc          (still dispatches)
7105:         // The unwrapped word acts on the instance side, where the name does
7106:         // not exist — a silent no-op in real Tcl.
7107:         let src = "oo::class create ::E2 {\n\
7108:                    self { method onlyclass {} { return oc } }\n\
7109:                    }\n\
7110:                    oo::define ::E2 { unexport onlyclass }";
7111:         let mut a = Analyser::new();
7112:         let r = a.analyse(src, "tcl9.0");
7113:         let c = r.all_classes.get("::E2").expect("::E2 recorded");
7114:         assert_eq!(c.class_methods["onlyclass"].visibility, "public");
7115:     }
7116: 
7117:     #[test]
7118:     fn cross_side_unexport_is_a_silent_no_op_not_an_error() {
7119:         // TN / oracle-shape pin. Unlike `deletemethod` (a hard error that
7120:         // aborts the definition), naming the *other* side's method in an
7121:         // `export`/`unexport` is accepted and does nothing:
7122:         //   oo::class create E { method onlyinst {} {…} }
7123:         //   oo::define E { self unexport onlyinst }   ;# no error
7124:         //   info class methods ::E  -> onlyinst       (still exported)
7125:         //   [::E new] onlyinst      -> oi
7126:         // so we record no visibility change and — crucially — no member stub.
7127:         let src = "oo::class create ::E3 { method onlyinst {} { return oi } }\n\
7128:                    oo::define ::E3 { self unexport onlyinst }";
7129:         let mut a = Analyser::new();
7130:         let r = a.analyse(src, "tcl9.0");
7131:         let c = r.all_classes.get("::E3").expect("::E3 recorded");
7132:         assert_eq!(c.methods["onlyinst"].visibility, "public");
7133:         assert!(!c.class_methods.contains_key("onlyinst"));
7134:     }
7135: 
7136:     #[test]
7137:     fn self_block_export_reexports_a_class_side_member() {
7138:         // TP, the export half — last explicit state wins.
7139:         // Oracle: `oo::class create H1 { self { method lower {} {…} ;
7140:         // unexport lower ; export lower } }` -> `info object methods ::H1`
7141:         // is `lower` on 9.0.4 and 8.6.14 alike.
7142:         let src = "oo::class create ::H1 {\n\
7143:                    self {\n\
7144:                    method lower {} { return l }\n\
7145:                    unexport lower\n\
7146:                    export lower\n\
7147:                    }\n\
7148:                    }";
7149:         let mut a = Analyser::new();
7150:         let r = a.analyse(src, "tcl9.0");
7151:         let c = r.all_classes.get("::H1").expect("::H1 recorded");
7152:         assert_eq!(c.class_methods["lower"].visibility, "public");
7153:     }
7154: 
7155:     #[test]
7156:     fn private_scoped_visibility_members_flip_the_instance_side() {
7157:         // TP, the third routing. `private` is 9.0-only (`invalid command
7158:         // name "private"` on 8.6), and under it a visibility word acts on the
7159:         // instance side exactly as the unwrapped spelling does. Oracle:
7160:         //   oo::class create G1 { method m {} {…}; private { unexport m } }
7161:         //   info class methods ::G1              ->            (unexported)
7162:         //   info class methods ::G1 -all -private -> … m …
7163:         //   oo::class create G3 { method m {} {…}; private export m }
7164:         //   info class methods ::G3              -> m          (exported)
7165:         for (src, want) in [
7166:             (
7167:                 "oo::class create ::G1 {\n\
7168:                  method m {} { return m }\n\
7169:                  private { unexport m }\n\
7170:                  }",
7171:                 "unexported",
7172:             ),
7173:             (
7174:                 "oo::class create ::G2 {\n\
7175:                  method m {} { return m }\n\
7176:                  private unexport m\n\
7177:                  }",
7178:                 "unexported",
7179:             ),
7180:             (
7181:                 "oo::class create ::G3 {\n\
7182:                  method m {} { return m }\n\
7183:                  private export m\n\
7184:                  }",
7185:                 "public",
7186:             ),
7187:         ] {
7188:             let mut a = Analyser::new();
7189:             let r = a.analyse(src, "tcl9.0");
7190:             let c = r
7191:                 .all_classes
7192:                 .values()
7193:                 .find(|c| c.methods.contains_key("m"))
7194:                 .expect("class recorded");
7195:             assert_eq!(c.methods["m"].visibility, want, "{src}");
7196:         }
7197:     }
7198: 
7199:     #[test]
7200:     fn private_block_form_records_instance_methods() {
7201:         // TP, symmetric half — `private` is the other registry member marked
7202:         // wrapper-with-block-body.
7203:         let src = "oo::class create ::P {\n\
7204:                    private {\n\
7205:                    method secret {k} { return $k }\n\
7206:                    }\n\
7207:                    }";
7208:         let mut a = Analyser::new();
7209:         let r = a.analyse(src, "tcl9.0");
7210:         let c = r.all_classes.get("::P").expect("::P recorded");
7211:         assert_eq!(c.methods["secret"].visibility, "private");
7212:         assert!(!c.class_methods.contains_key("secret"));
7213:     }
7214: 
7215:     #[test]
7216:     fn self_block_does_not_declare_instance_variables() {
7217:         // TN / abstention boundary. `self { variable x }` declares a variable
7218:         // on the *class object*, not an instance variable of the class — the
7219:         // prefix form (`self variable x`) is not recorded either, and the
7220:         // block form must not start recording it as one.
7221:         let src = "oo::class create ::V {\n\
7222:                    self {\n\
7223:                    variable classlevel\n\
7224:                    }\n\
7225:                    variable instancelevel\n\
7226:                    }";
7227:         let mut a = Analyser::new();
7228:         let r = a.analyse(src, "tcl9.0");
7229:         let c = r.all_classes.get("::V").expect("::V recorded");
7230:         assert_eq!(c.variables, vec!["instancelevel".to_string()]);
7231:     }
7232: 
7233:     #[test]
7234:     fn self_introspection_prefix_is_not_a_block_member() {
7235:         // TN. Inside a *method body*, `self class` is an introspection call,
7236:         // not a definer member. The body is walked as a script (never as a
7237:         // definition body), so nothing here may reach `class_methods`.
7238:         let src = "oo::class create ::W {\n\
7239:                    method whoami {} { return [self class] }\n\
7240:                    }";
7241:         let mut a = Analyser::new();
7242:         let r = a.analyse(src, "tcl9.0");
7243:         let c = r.all_classes.get("::W").expect("::W recorded");
7244:         assert!(c.methods.contains_key("whoami"));
7245:         assert_eq!(c.class_methods.len(), 0, "{:?}", c.class_methods);
7246:     }
7247: 
7248:     #[test]
7249:     fn dynamic_self_block_abstains() {
7250:         // Abstention boundary: a non-literal block word cannot be re-segmented
7251:         // statically, so the expansion declines and the class records nothing
7252:         // rather than guessing.
7253:         let src = "set b {method make {n} { return $n }}\n\
7254:                    oo::class create ::Dyn {\n\
7255:                    self $b\n\
7256:                    }";
7257:         let mut a = Analyser::new();
7258:         let r = a.analyse(src, "tcl9.0");
7259:         let c = r.all_classes.get("::Dyn").expect("::Dyn recorded");
7260:         assert_eq!(c.class_methods.len(), 0, "{:?}", c.class_methods);
7261:         assert_eq!(c.methods.len(), 0, "{:?}", c.methods);
7262:     }
7263: 
7264:     #[test]
7265:     fn self_block_destructive_member_drops_the_member_it_deletes() {
7266:         // TP. Oracle (tclsh 9.0.4 / 8.6.16, identical):
7267:         //   oo::class create ::C1 {
7268:         //       self { method gone {} {…} ; method kept {} {…} ; deletemethod gone }
7269:         //   }
7270:         //   info object methods ::C1  ->  kept
7271:         //   ::C1 gone                 ->  unknown method "gone"
7272:         // Retaining `gone` would show a stale document symbol and let
7273:         // navigation resolve a name the interpreter does not have.
7274:         let src = "oo::class create ::C {\n                   self {\n                   method gone {} { return g }\n                   method kept {} { return k }\n                   deletemethod gone\n                   }\n                   }";
7275:         let mut a = Analyser::new();
7276:         let r = a.analyse(src, "tcl9.0");
7277:         let c = r.all_classes.get("::C").expect("::C recorded");
7278:         assert!(
7279:             !c.class_methods.contains_key("gone"),
7280:             "{:?}",
7281:             c.class_methods
7282:         );
7283:         assert!(c.class_methods.contains_key("kept"));
7284:     }
7285: 
7286:     #[test]
7287:     fn self_block_renamemethod_moves_the_member_on_the_class_side() {
7288:         // TP, the class-side half. Oracle, byte-identical on tclsh
7289:         // 9.0.4 and 8.6.14:
7290:         //   oo::class create ::R2 { self { method old {} {return CLSOLD}
7291:         //                                  renamemethod old new } }
7292:         //   info object methods ::R2  -> new
7293:         //   ::R2 new                  -> CLSOLD   (shadowing the stock `new`!)
7294:         //   ::R2 old                  -> unknown method
7295:         // The move stays on the wrapper's own side: the instance table is not
7296:         // touched in either direction.
7297:         let src = "oo::class create ::C {\n                   self {\n                   method old {} { return o }\n                   renamemethod old new\n                   }\n                   }";
7298:         let mut a = Analyser::new();
7299:         let r = a.analyse(src, "tcl9.0");
7300:         let c = r.all_classes.get("::C").expect("::C recorded");
7301:         assert!(
7302:             !c.class_methods.contains_key("old"),
7303:             "{:?}",
7304:             c.class_methods
7305:         );
7306:         let md = c.class_methods.get("new").expect("`new` is a class member");
7307:         assert_eq!(md.name, "new");
7308:         assert!(
7309:             src[md.body_span.start() as usize..md.body_span.end() as usize].contains("return o"),
7310:         );
7311:         assert_eq!(
7312:             c.methods.len(),
7313:             0,
7314:             "instance side untouched: {:?}",
7315:             c.methods
7316:         );
7317:         assert!(!has_w315(&r), "{:?}", w315_messages(&r));
7318:     }
7319: 
7320:     #[test]
7321:     fn private_block_destructive_member_drops_the_instance_side_member() {
7322:         // TP, symmetric half. Oracle (9.0 — `private` is a 9.0 member):
7323:         //   oo::class create ::C5 {
7324:         //       private { method secret {} {…} ; method other {} {…} ;
7325:         //                 deletemethod secret }
7326:         //   }
7327:         //   info class methods ::C5 -all -private   ->  no `secret`
7328:         let src = "oo::class create ::C {\n                   private {\n                   method secret {} { return s }\n                   method other {} { return o }\n                   deletemethod secret\n                   }\n                   }";
7329:         let mut a = Analyser::new();
7330:         let r = a.analyse(src, "tcl9.0");
7331:         let c = r.all_classes.get("::C").expect("::C recorded");
7332:         assert!(!c.methods.contains_key("secret"), "{:?}", c.methods);
7333:         assert!(c.methods.contains_key("other"));
7334:     }
7335: 
7336:     #[test]
7337:     fn wrapper_block_and_prefix_forms_retract_identically() {
7338:         // The block form is normalised into the prefix form, so both spellings
7339:         // must land on the same result. Oracle for the prefix side:
7340:         //   oo::define ::C7 { self method sgone {} {…} }
7341:         //   info object methods ::C7                  ->  sgone
7342:         //   oo::define ::C7 { self deletemethod sgone }
7343:         //   info object methods ::C7                  ->  (empty)
7344:         let src = "oo::class create ::C {}\n                   oo::define ::C { self method gone {} { return g } }\n                   oo::define ::C { self deletemethod gone }";
7345:         let mut a = Analyser::new();
7346:         let r = a.analyse(src, "tcl9.0");
7347:         let c = r.all_classes.get("::C").expect("::C recorded");
7348:         assert_eq!(c.class_methods.len(), 0, "{:?}", c.class_methods);
7349:     }
7350: 
7351:     #[test]
7352:     fn a_retraction_does_not_cross_to_the_other_side() {
7353:         // TN. `self deletemethod` touches only the class-object side. Oracle:
7354:         //   oo::class create ::D { method m {} {return inst}
7355:         //                          self { method m {} {return cls} } }
7356:         //   oo::define ::D { self deletemethod m }
7357:         //   info class methods ::D   ->  m        (instance side survives)
7358:         //   info object methods ::D  ->  (empty)
7359:         //   [::D new] m              ->  inst
7360:         let src = "oo::class create ::D {\n                   method m {} { return inst }\n                   self { method m {} { return cls } }\n                   }\n                   oo::define ::D { self deletemethod m }";
7361:         let mut a = Analyser::new();
7362:         let r = a.analyse(src, "tcl9.0");
7363:         let c = r.all_classes.get("::D").expect("::D recorded");
7364:         assert!(c.methods.contains_key("m"), "instance side must survive");
7365:         assert!(!c.class_methods.contains_key("m"), "class side must go");
7366:     }
7367: 
7368:     #[test]
7369:     fn non_retracting_method_reference_members_keep_their_member() {
7370:         // TN, the discrimination the registry flag exists for: `export`,
7371:         // `unexport`, and `filter` are the sibling `MemberRefKind::Method`
7372:         // members — they *name* a method without removing it, so they must not
7373:         // retract. Oracle:
7374:         //   oo::class create ::A { self { method a {} {…} ; unexport a ; export a } }
7375:         //   info object methods ::A  ->  a   ;  ::A a  ->  1
7376:         //   oo::class create ::B { self { method f {} {…} ; filter f } }
7377:         //   info object methods ::B  ->  f
7378:         let mut a = Analyser::new();
7379:         let r = a.analyse(
7380:             "oo::class create ::A {\n self {\n method a {} { return 1 }\n unexport a\n export a\n }\n}",
7381:             "tcl9.0",
7382:         );
7383:         assert!(
7384:             r.all_classes["::A"].class_methods.contains_key("a"),
7385:             "export/unexport must not retract",
7386:         );
7387:         let mut a = Analyser::new();
7388:         let r = a.analyse(
7389:             "oo::class create ::B {\n self {\n method f {} { return 1 }\n filter f\n }\n}",
7390:             "tcl9.0",
7391:         );
7392:         assert!(
7393:             r.all_classes["::B"].class_methods.contains_key("f"),
7394:             "filter must not retract",
7395:         );
7396:     }
7397: 
7398:     #[test]
7399:     fn a_retracted_member_can_be_redeclared_by_a_later_body() {
7400:         // Source-order guard. Oracle:
7401:         //   oo::class create ::C { method m {} {return 1} }
7402:         //   oo::define ::C { self method m {} {return 2} }
7403:         //   oo::define ::C { self deletemethod m }
7404:         //   oo::define ::C { self method m {} {return 3} }
7405:         //   ::C m        ->  3     (class side, redeclared after the delete)
7406:         //   [::C new] m  ->  1     (instance side, never touched)
7407:         // Retraction happens where the body is walked, so a later declaration
7408:         // wins — it is not a whole-document erasure of the name.
7409:         let src = "oo::class create ::C { method m {} { return 1 } }\n                   oo::define ::C { self method m {} { return 2 } }\n                   oo::define ::C { self deletemethod m }\n                   oo::define ::C { self method m {} { return 3 } }";
7410:         let mut a = Analyser::new();
7411:         let r = a.analyse(src, "tcl9.0");
7412:         let c = r.all_classes.get("::C").expect("::C recorded");
7413:         assert!(c.class_methods.contains_key("m"), "redeclaration must win");
7414:         assert!(c.methods.contains_key("m"), "instance side untouched");
7415:     }
7416: 
7417:     #[test]
7418:     fn unwrapped_deletemethod_drops_the_instance_side_member() {
7419:         // TP. An *unwrapped* `deletemethod` — in a class-creation
7420:         // body or an `oo::define` body, with no `self` / `private` wrapper —
7421:         // deletes on the instance side. Oracle, byte-identical on tclsh 9.0.4
7422:         // and 8.6.14:
7423:         //   oo::class create ::I1 { method gone {} {…}; method kept {} {…}
7424:         //                           deletemethod gone }
7425:         //   info class methods ::I1  ->  kept
7426:         //   oo::class create ::I4 { method gone {} {…} }
7427:         //   oo::define ::I4 { deletemethod gone }
7428:         //   info class methods ::I4  ->            (empty)
7429:         for src in [
7430:             "oo::class create ::C {\n\
7431:              method gone {} { return g }\n\
7432:              method kept {} { return k }\n\
7433:              deletemethod gone\n\
7434:              }",
7435:             "oo::class create ::C {\n\
7436:              method gone {} { return g }\n\
7437:              method kept {} { return k }\n\
7438:              }\n\
7439:              oo::define ::C { deletemethod gone }",
7440:         ] {
7441:             let mut a = Analyser::new();
7442:             let r = a.analyse(src, "tcl9.0");
7443:             let c = r.all_classes.get("::C").expect("::C recorded");
7444:             assert!(!c.methods.contains_key("gone"), "deleted member retained");
7445:             assert!(c.methods.contains_key("kept"), "sibling member dropped");
7446:         }
7447:     }
7448: 
7449:     #[test]
7450:     fn unwrapped_renamemethod_moves_the_member_to_the_new_name() {
7451:         // TP. Oracle,
7452:         // byte-identical on tclsh 9.0.4 and 8.6.14:
7453:         //   oo::class create ::I3 { method old {} {return o}; renamemethod old new }
7454:         //   info class methods ::I3        ->  new
7455:         //   [::I3 new] new                 ->  o        (the old body runs)
7456:         //   info class definition ::I3 new ->  {} { return o }
7457:         //   ::I3 old                       ->  unknown method
7458:         // so `new` is a fully navigable member carrying `old`'s body: `old` goes,
7459:         // `new` arrives with the *same* `MethodDef`, its name span moved onto
7460:         // the `renamemethod` call's destination word (the only place the new
7461:         // name is written) and its body span left on the one real body.
7462:         let mut a = Analyser::new();
7463:         let src = "oo::class create ::C { method old {} { return o }\n\
7464:              renamemethod old new }";
7465:         let r = a.analyse(src, "tcl9.0");
7466:         let c = r.all_classes.get("::C").expect("::C recorded");
7467:         assert!(!c.methods.contains_key("old"));
7468:         let md = c.methods.get("new").expect("`new` is a member");
7469:         assert_eq!(md.name, "new");
7470:         // The name span is the `renamemethod`'s destination word …
7471:         assert_eq!(
7472:             &src[md.name_span.start() as usize..md.name_span.end() as usize],
7473:             "new"
7474:         );
7475:         // … and it is the *second* `new` in the source (the one in the
7476:         // `renamemethod` call), not any earlier text.
7477:         assert!(md.name_span.start() as usize > src.find("renamemethod").expect("call"));
7478:         // … while the body span still points at the original body.
7479:         assert!(
7480:             src[md.body_span.start() as usize..md.body_span.end() as usize].contains("return o"),
7481:             "body span must stay on the original body",
7482:         );
7483:         // A rename is not a (re)declaration, so the family's name-based export
7484:         // default is not re-applied — the source's visibility travels with it.
7485:         assert_eq!(md.visibility, "public");
7486:         // TN: a rename onto a fresh name is a legal order.
7487:         assert!(!has_w315(&r), "{:?}", w315_messages(&r));
7488:         // …and the *destination* name leaves no cross-document tombstone: the
7489:         // rename creates `new`, it does not delete it, so another document's
7490:         // `method new` must survive. Registry data decides which arguments a
7491:         // retracting word removes (`MemberRetraction::FirstArgument`).
7492:         assert!(
7493:             !c.retracted_members
7494:                 .iter()
7495:                 .any(|r| r.member == "new" || r.member == "old"),
7496:             "a locally-declared retraction needs no tombstone: {:?}",
7497:             c.retracted_members,
7498:         );
7499:     }
7500: 
7501:     // The class-side visibility + filter channels.
7502: 
7503:     #[test]
7504:     fn self_scoped_visibility_words_fill_the_class_side_sets() {
7505:         // TP. A `self export` / `self unexport` has to leave a
7506:         // record of its own or the flip never travels to another file's
7507:         // class-command dispatch. Oracle, byte-identical on tclsh 9.0.4/8.6.14:
7508:         //   oo::class create ::X { self { method cm {} { return cm } } }
7509:         //   ::X cm                    ;# -> cm
7510:         //   oo::define X { self unexport cm }
7511:         //   ::X cm                    ;# -> unknown method "cm": must be create,
7512:         //                             ;#    destroy or new
7513:         //   info object methods ::X   ;# -> (empty)
7514:         //   info object methods ::X -all -private ;# -> … cm …  (still defined)
7515:         let mut a = Analyser::new();
7516:         let r = a.analyse(
7517:             "oo::class create ::C { self { method cm {} { return c } } }\n\
7518:              oo::define ::C { self unexport cm }",
7519:             "tcl9.0",
7520:         );
7521:         let c = r.all_classes.get("::C").expect("::C recorded");
7522:         assert!(c.class_unexports.contains("cm"), "{:?}", c.class_unexports);
7523:         assert_eq!(c.class_exports.len(), 0, "{:?}", c.class_exports);
7524:         assert_eq!(c.class_methods["cm"].visibility, "unexported");
7525:         // …and the instance-side pair — the one every existing consumer reads
7526:         // as the instance record — stays untouched in both directions.
7527:         assert_eq!(c.exports.len(), 0, "{:?}", c.exports);
7528:         assert_eq!(c.unexports.len(), 0, "{:?}", c.unexports);
7529:     }
7530: 
7531:     #[test]
7532:     fn a_rename_carries_the_sources_visibility_not_the_new_names_default() {
7533:         // CRITICAL pin. A rename is not a (re)declaration, so the
7534:         // family's name-based export default (`[a-z]*` is exported for `TclOO`)
7535:         // is NOT re-applied to the destination — the source's own visibility
7536:         // travels with the body. Both directions, byte-identical on tclsh 9.0.4
7537:         // and 8.6.14:
7538:         //   oo::class create ::R4 { method Priv {} {…} ; renamemethod Priv pub }
7539:         //   info class methods ::R4           ;# -> (empty)   `pub` is UNexported
7540:         //   info class methods ::R4 -private  ;# -> pub       despite the name
7541:         //   [::R4 new] pub                    ;# -> unknown method "pub"
7542:         //   oo::class create ::R5 { method low {} {…} ; renamemethod low Up }
7543:         //   info class methods ::R5           ;# -> Up        still EXPORTED
7544:         //   info class methods ::R5 -private  ;# -> Up        despite the name
7545:         //
7546:         // Applying the destination's default instead would flip both of these
7547:         // the wrong way — offering a `pub` no `$obj pub` can call, and hiding an
7548:         // `Up` that dispatches fine.
7549:         for (src_name, dst_name, want) in [("Priv", "pub", "unexported"), ("low", "Up", "public")] {
7550:             let src = format!(
7551:                 "oo::class create ::C {{ method {src_name} {{}} {{ return 1 }}\n\
7552:                  renamemethod {src_name} {dst_name} }}"
7553:             );
7554:             let mut a = Analyser::new();
7555:             let r = a.analyse(&src, "tcl9.0");
7556:             let c = r.all_classes.get("::C").expect("::C recorded");
7557:             assert_eq!(
7558:                 c.methods[dst_name].visibility, want,
7559:                 "{src_name} -> {dst_name}",
7560:             );
7561:         }
7562:     }
7563: 
7564:     #[test]
7565:     fn the_class_side_visibility_sets_keep_only_the_last_writer() {
7566:         // The class-side pair takes the identical last-writer-exclusive rule as
7567:         // the instance pair, because the workspace consumer reads any `exports`
7568:         // entry as decisive. Oracle: `oo::class create ::H1 { self { method
7569:         // lower {} {…} ; unexport lower ; export lower } }` leaves
7570:         // `info object methods ::H1` -> lower on 9.0.4 and 8.6.14 alike.
7571:         for (body, exported) in [
7572:             ("unexport m\nexport m", true),
7573:             ("export m\nunexport m", false),
7574:         ] {
7575:             let src = format!(
7576:                 "oo::class create ::C {{ self {{ method m {{}} {{ return 1 }}\n{body} }} }}"
7577:             );
7578:             let mut a = Analyser::new();
7579:             let r = a.analyse(&src, "tcl9.0");
7580:             let c = r.all_classes.get("::C").expect("::C recorded");
7581:             let (winner, loser) = if exported {
7582:                 (&c.class_exports, &c.class_unexports)
7583:             } else {
7584:                 (&c.class_unexports, &c.class_exports)
7585:             };
7586:             assert!(winner.contains("m"), "{body}");
7587:             assert!(
7588:                 !loser.contains("m"),
7589:                 "{body}: superseded set still holds `m`"
7590:             );
7591:         }
7592:     }
7593: 
7594:     #[test]
7595:     fn an_unwrapped_visibility_word_never_touches_the_class_side_sets() {
7596:         // TN, the mirror of `a_self_scoped_visibility_word_never_touches_the_
7597:         // instance_sets`. The unwrapped spelling is instance-scoped, so an
7598:         // identically-named class-side member keeps its own state — oracle:
7599:         // `oo::class create E2 { self { method onlyclass {} {…} } }` then
7600:         // `oo::define E2 { unexport onlyclass }` leaves `onlyclass` exported and
7601:         // dispatchable via `::E2 onlyclass` on 9.0.4 and 8.6.14.
7602:         let mut a = Analyser::new();
7603:         let r = a.analyse(
7604:             "oo::class create ::C { self { method m {} { return c } } }\n\
7605:              oo::define ::C { unexport m }",
7606:             "tcl9.0",
7607:         );
7608:         let c = r.all_classes.get("::C").expect("::C recorded");
7609:         assert_eq!(c.class_exports.len(), 0, "{:?}", c.class_exports);
7610:         assert_eq!(c.class_unexports.len(), 0, "{:?}", c.class_unexports);
7611:         assert_eq!(c.class_methods["m"].visibility, "public");
7612:         // The unwrapped word still records its own (instance-side) intent.
7613:         assert!(c.unexports.contains("m"));
7614:     }
7615: 
7616:     #[test]
7617:     fn filters_are_sided_by_the_wrapper_they_are_written_under() {
7618:         // TP + TN — `filters` is sided like every other member table. The two
7619:         // slots are genuinely independent in `TclOO` and
7620:         // intercept different dispatches. Oracle, byte-identical on tclsh 9.0.4
7621:         // and 8.6.14:
7622:         //   oo::class create ::A { method real {} {…} ; method logit {args} {…}
7623:         //                          filter logit }
7624:         //   info class filters ::A   ;# -> logit      info object filters ::A -> {}
7625:         //   [::A new] real           ;# logit fires, `self target` -> `::A real`
7626:         //   oo::class create ::B { method inst {} {…}
7627:         //       self { method cls {} {…} ; method logit {args} {…} ; filter logit } }
7628:         //   info object filters ::B  ;# -> logit      info class filters ::B  -> {}
7629:         //   ::B cls                  ;# logit fires, `self target` -> `::B cls`
7630:         //   ::B new                  ;# logit fires too — the constructor path
7631:         //   [::B new] inst           ;# logit does NOT fire
7632:         let mut a = Analyser::new();
7633:         let r = a.analyse(
7634:             "oo::class create ::A { method real {} { return r }\n\
7635:              method logit {args} { next }\n\
7636:              filter logit }\n\
7637:              oo::class create ::B { method inst {} { return i }\n\
7638:              self { method cls {} { return c }\n\
7639:              method logit {args} { next }\n\
7640:              filter logit } }",
7641:             "tcl9.0",
7642:         );
7643:         let a_cls = r.all_classes.get("::A").expect("::A recorded");
7644:         assert_eq!(a_cls.filters, vec!["logit"]);
7645:         assert_eq!(a_cls.class_filters.len(), 0, "{:?}", a_cls.class_filters);
7646:         let b_cls = r.all_classes.get("::B").expect("::B recorded");
7647:         assert_eq!(b_cls.class_filters, vec!["logit"]);
7648:         assert_eq!(b_cls.filters.len(), 0, "{:?}", b_cls.filters);
7649:     }
7650: 
7651:     #[test]
7652:     fn a_private_scoped_filter_is_instance_side() {
7653:         // TN for the third spelling: `private` is a *visibility* wrapper over
7654:         // the instance side, not a third side, so its `filter` lands in the
7655:         // instance slot. Oracle (9.0 only — `private` does not exist on 8.6,
7656:         // where the same body fails with `invalid command name "private"`):
7657:         //   oo::class create ::P { private { method s {} {} ; filter s } }
7658:         //   info class filters ::P   ;# -> s
7659:         //   info object filters ::P  ;# -> (empty)
7660:         let mut a = Analyser::new();
7661:         let r = a.analyse(
7662:             "oo::class create ::C { private { method s {} { return s }\n\
7663:              filter s } }",
7664:             "tcl9.0",
7665:         );
7666:         let c = r.all_classes.get("::C").expect("::C recorded");
7667:         assert_eq!(c.filters, vec!["s"]);
7668:         assert_eq!(c.class_filters.len(), 0, "{:?}", c.class_filters);
7669:     }
7670: 
7671:     #[test]
7672:     fn per_object_visibility_lands_in_object_member_state() {
7673:         // `oo::objdefine $o { unexport m }` really works — oracle, 9.0.4 and
7674:         // 8.6.14 alike:
7675:         //   oo::class create ::C { method m {} {…} } ; set o [::C new]
7676:         //   oo::objdefine $o { unexport m } ; $o m
7677:         //   ;# -> unknown method "m": must be destroy or n
7678:         // The flip lands in the receiver binding's `ObjectMemberState`
7679:         // — the durable per-object home — while the class itself stays
7680:         // untouched, and the throwaway holder never reaches `all_classes`.
7681:         let mut a = Analyser::new();
7682:         let r = a.analyse(
7683:             "oo::class create ::C { method m {} { return m } }\n\
7684:              set o [::C new]\n\
7685:              oo::objdefine $o { unexport m }",
7686:             "tcl9.0",
7687:         );
7688:         let c = r.all_classes.get("::C").expect("::C recorded");
7689:         assert_eq!(c.methods["m"].visibility, "public");
7690:         assert_eq!(c.unexports.len(), 0, "{:?}", c.unexports);
7691:         assert!(!r.all_classes.contains_key("::@objdefine@::o"));
7692:         let states = r
7693:             .object_member_state
7694:             .get("o")
7695:             .expect("the receiver binding has member state");
7696:         assert_eq!(states.len(), 1, "{states:?}");
7697:         assert!(states[0].unexports.contains("m"), "{states:?}");
7698:         assert_eq!(states[0].exports.len(), 0, "{states:?}");
7699:     }
7700: 
7701:     #[test]
7702:     fn per_object_export_and_unexport_are_last_writer_exclusive() {
7703:         // The per-object pair keeps the same last-writer-exclusive contract
7704:         // as the class-side pairs: a later `export m` cancels the earlier
7705:         // flip, across blocks of the same binding.
7706:         let mut a = Analyser::new();
7707:         let r = a.analyse(
7708:             "oo::class create ::C { method m {} { return m } }\n\
7709:              set o [::C new]\n\
7710:              oo::objdefine $o { unexport m }\n\
7711:              oo::objdefine $o { export m }",
7712:             "tcl9.0",
7713:         );
7714:         let states = r.object_member_state.get("o").expect("state recorded");
7715:         assert_eq!(states.len(), 1, "one binding: {states:?}");
7716:         assert!(states[0].exports.contains("m"), "{states:?}");
7717:         assert!(!states[0].unexports.contains("m"), "{states:?}");
7718:     }
7719: 
7720:     #[test]
7721:     fn per_object_cross_block_retraction_folds_and_stays_silent() {
7722:         // The cross-block hazard that kept W315 out of `oo::objdefine`:
7723:         // a second block retracting what the first declared
7724:         // is legal (tclsh 9.0.4 / 8.6.14 both accept it), so the seeded walk
7725:         // must remove the member silently — no W315 — and the folded state
7726:         // must drop it.
7727:         let mut a = Analyser::new();
7728:         let r = a.analyse(
7729:             "oo::class create ::C {}\n\
7730:              set o [::C new]\n\
7731:              oo::objdefine $o { method im {} { return i } }\n\
7732:              oo::objdefine $o { deletemethod im }",
7733:             "tcl9.0",
7734:         );
7735:         assert_eq!(w315_messages(&r).len(), 0, "{:?}", r.diagnostics);
7736:         let states = r.object_member_state.get("o").expect("state recorded");
7737:         assert_eq!(states.len(), 1, "{states:?}");
7738:         assert_eq!(
7739:             states[0].methods.len(),
7740:             0,
7741:             "the retraction must fold: {states:?}"
7742:         );
7743:     }
7744: 
7745:     #[test]
7746:     fn a_retraction_of_a_locally_declared_member_leaves_no_tombstone() {
7747:         // TN for the cross-document channel. Within one document the member is
7748:         // removed outright and the order is known, so exporting a tombstone
7749:         // would wrongly cancel a *different* document's redeclaration of the
7750:         // name — no ordering evidence supports that.
7751:         let mut a = Analyser::new();
7752:         let r = a.analyse(
7753:             "oo::class create ::C { method gone {} { return g } }\n\
7754:              oo::define ::C { deletemethod gone }",
7755:             "tcl9.0",
7756:         );
7757:         let c = r.all_classes.get("::C").expect("::C recorded");
7758:         assert!(!c.methods.contains_key("gone"));
7759:         assert_eq!(c.retracted_members.len(), 0, "{:?}", c.retracted_members);
7760:     }
7761: 
7762:     // W315, "this class definition cannot run".
7763: 
7764:     #[test]
7765:     fn w315_fires_for_every_definition_aborting_retraction() {
7766:         // naming.diagnostics.original-definition-abort-admission
7767:         // docs/design/analysis/name-resolution-proofs/diagnostic-original-definition-abort-admission.md
7768:         // Explicit Logical source-table compatibility; no Native worker/table claim.
7769:         for (body, want) in [
7770:             (
7771:                 "deletemethod ghost\nmethod ghost {} { return g }",
7772:                 "this class definition cannot run: method \"ghost\" does not exist",
7773:             ),
7774:             (
7775:                 "self { method cm {} { return c } }\ndeletemethod cm",
7776:                 "this class definition cannot run: method \"cm\" does not exist",
7777:             ),
7778:             (
7779:                 "method a {} { return a }\nmethod b {} { return b }\nrenamemethod a b",
7780:                 "this class definition cannot run: method called \"b\" already exists",
7781:             ),
7782:             (
7783:                 "method a {} { return a }\nrenamemethod a a",
7784:                 "this class definition cannot run: cannot rename method to itself",
7785:             ),
7786:             (
7787:                 "method b {} { return b }\nrenamemethod ghost b",
7788:                 "this class definition cannot run: method \"ghost\" does not exist",
7789:             ),
7790:         ] {
7791:             let mut a = logical_object_abort_analyser();
7792:             let r = a.analyse(
7793:                 &format!("oo::class create ::C {{ {body} }}"),
7794:                 "explicit-object-abort-advice",
7795:             );
7796:             assert_eq!(w315_messages(&r), vec![want.to_string()], "body: {body}");
7797:             assert!(r.all_classes.contains_key("::C"), "body: {body}");
7798:         }
7799:     }
7800: 
7801:     #[test]
7802:     fn w315_fires_on_the_class_side_too() {
7803:         // naming.diagnostics.original-definition-abort-admission
7804:         // docs/design/analysis/name-resolution-proofs/diagnostic-original-definition-abort-admission.md
7805:         // Explicit Logical source-table compatibility; no Native worker/table claim.
7806:         for body in [
7807:             "method im {} { return i }\nself { deletemethod im }",
7808:             "method im {} { return i }\nself { renamemethod im other }",
7809:         ] {
7810:             let mut a = logical_object_abort_analyser();
7811:             let r = a.analyse(
7812:                 &format!("oo::class create ::C {{ {body} }}"),
7813:                 "explicit-object-abort-advice",
7814:             );
7815:             assert_eq!(
7816:                 w315_messages(&r),
7817:                 vec!["this class definition cannot run: method \"im\" does not exist".to_string()],
7818:                 "body: {body}",
7819:             );
7820:             assert!(r.all_classes["::C"].methods.contains_key("im"), "{body}");
7821:         }
7822:     }
7823: 
7824:     fn logical_object_abort_analyser() -> Analyser {
7825:         let profile = tcl_dialect::DialectProfile::projected_from_point(
7826:             "explicit-object-abort-advice",
7827:             &[],
7828:             "Logical object definition advice",
7829:             tcl_dialect::model::DialectPoint::canonical(tcl_dialect::model::Release::JIM_0_79),
7830:         )
7831:         .intern();
7832:         let input = super::super::ResolvedAnalysisInput::new(
7833:             profile,
7834:             profile,
7835:             tcl_registry::model::ingress::resolve_environment("tcl9.0").default_context_registry(),
7836:             tcl_lexer::LexerConfig::for_profile(Some(profile)),
7837:         );
7838:         assert!(input.has_logical_source_name_context());
7839:         Analyser::new().with_resolved_input(input)
7840:     }
7841: 
7842:     fn injected_class_abort_candidates() -> ClassDef {
7843:         ClassDef {
7844:             definition_aborts: [
7845:                 DefinitionAbortKind::MissingMember,
7846:                 DefinitionAbortKind::DestinationExists,
7847:                 DefinitionAbortKind::RenameToItself,
7848:             ]
7849:             .into_iter()
7850:             .map(|kind| DefinitionAbort {
7851:                 kind,
7852:                 member: "missing".to_owned(),
7853:                 span: Span::new(0, 1),
7854:             })
7855:             .collect(),
7856:             retracted_members: vec![MemberRetractionRecord::deletion(
7857:                 "missing".to_owned(),
7858:                 MemberSide::Instance,
7859:             )],
7860:             ..Default::default()
7861:         }
7862:     }
7863: 
7864:     #[test]
7865:     fn original_class_abort_refuses_native_and_hosted_reporting_tables() {
7866:         // naming.diagnostics.original-definition-abort-admission
7867:         // docs/design/analysis/name-resolution-proofs/diagnostic-original-definition-abort-admission.md
7868:         // Positive injected candidates check admission, not runtime retractions.
7869:         let source = "oo::class create C {deletemethod ghost; method ghost {} {}}";
7870:         for dialect in [
7871:             "tcl8.4",
7872:             "tcl8.5",
7873:             "tcl8.6",
7874:             "tcl9.0",
7875:             "tcl9.1",
7876:             "jimtcl",
7877:             "f5-irules",
7878:             "f5-tmsh",
7879:             "f5-iapps",
7880:         ] {
7881:             let mut analyser = Analyser::new();
7882:             analyser.result = analyser.analyse(source, dialect);
7883:             assert!(!has_w315(&analyser.result), "{dialect}");
7884:             analyser.result.lexical_declaration_advice = true;
7885:             analyser.result.dialect = "explicit-object-abort-advice".to_owned();
7886:             analyser.result.original_vendor_source_names.clear();
7887:             analyser.result.all_classes.clear();
7888:             let mut class = injected_class_abort_candidates();
7889:             assert_eq!(class.definition_aborts.len(), 3);
7890:             assert!(!class.via_define);
7891:             analyser.emit_w315_definition_cannot_run(&mut class);
7892:             assert!(
7893:                 !has_w315(&analyser.result),
7894:                 "{dialect}: reports grant no Native closure"
7895:             );
7896:             assert!(class.definition_aborts.is_empty());
7897:             assert_eq!(class.retracted_members.len(), 1);
7898:         }
7899:     }
7900: 
7901:     #[test]
7902:     fn original_class_abort_refuses_missing_retained_input() {
7903:         // naming.diagnostics.original-definition-abort-admission
7904:         // docs/design/analysis/name-resolution-proofs/diagnostic-original-definition-abort-admission.md
7905:         let mut analyser = Analyser::new();
7906:         analyser.result.lexical_declaration_advice = true;
7907:         analyser.result.dialect = "explicit-object-abort-advice".to_owned();
7908:         assert!(analyser.result.resolved_input.is_none());
7909:         let mut class = injected_class_abort_candidates();
7910:         analyser.emit_w315_definition_cannot_run(&mut class);
7911:         assert!(!has_w315(&analyser.result));
7912:         assert!(class.definition_aborts.is_empty());
7913:         assert_eq!(class.retracted_members.len(), 1);
7914:     }
7915: 
7916:     #[test]
7917:     fn original_class_abort_keeps_retained_logical_advice_despite_report_mutations() {
7918:         // naming.diagnostics.original-definition-abort-admission
7919:         // docs/design/analysis/name-resolution-proofs/diagnostic-original-definition-abort-admission.md
7920:         let mut analyser = logical_object_abort_analyser();
7921:         analyser.result = analyser.analyse("", "explicit-object-abort-advice");
7922:         assert!(analyser.result.allows_retained_logical_declaration_advice());
7923:         analyser.result.dialect = "tcl9.0".to_owned();
7924:         analyser.result.all_classes.clear();
7925:         analyser.result.command_invocations.clear();
7926:         analyser.result.all_procs.clear();
7927:         let mut class = injected_class_abort_candidates();
7928:         analyser.emit_w315_definition_cannot_run(&mut class);
7929:         assert_eq!(w315_messages(&analyser.result).len(), 3);
7930:         assert!(class.definition_aborts.is_empty());
7931:         assert!(class.retracted_members.is_empty());
7932:         analyser.result.lexical_declaration_advice = false;
7933:         let mut withdrawn = injected_class_abort_candidates();
7934:         analyser.emit_w315_definition_cannot_run(&mut withdrawn);
7935:         assert_eq!(w315_messages(&analyser.result).len(), 3);
7936:         assert!(withdrawn.definition_aborts.is_empty());
7937:         assert_eq!(withdrawn.retracted_members.len(), 1);
7938:     }
7939: 
7940:     fn inject_object_abort_candidates(analyser: &mut Analyser) {
7941:         analyser
7942:             .result
7943:             .instance_classes
7944:             .insert("owned".to_owned(), "::C".to_owned());
7945:         analyser
7946:             .result
7947:             .created_instance_commands
7948:             .insert("owned".to_owned());
7949:         analyser.result.object_methods.clear();
7950:         analyser.objdefine_unresolved_receiver = false;
7951:         for kind in [
7952:             DefinitionAbortKind::MissingMember,
7953:             DefinitionAbortKind::DestinationExists,
7954:             DefinitionAbortKind::RenameToItself,
7955:         ] {
7956:             analyser.objdefine_abort_candidates.push(
7957:                 super::super::state::ObjdefineAbortCandidate {
7958:                     abort: DefinitionAbort {
7959:                         kind,
7960:                         member: "missing".to_owned(),
7961:                         span: Span::new(0, 1),
7962:                     },
7963:                     receiver: "owned".to_owned(),
7964:                     prior_state_conditional: false,
7965:                 },
7966:             );
7967:         }
7968:     }
7969: 
7970:     #[test]
7971:     fn original_object_abort_refuses_native_and_hosted_reporting_tables() {
7972:         // naming.diagnostics.original-object-abort-admission
7973:         // docs/design/analysis/name-resolution-proofs/diagnostic-original-object-abort-admission.md
7974:         // Injected report candidates test admission, without asserting execution.
7975:         let source = "oo::class create C {}\nset o [C new]\noo::objdefine $o {method a {} {}; renamemethod a a}";
7976:         for dialect in [
7977:             "tcl8.4",
7978:             "tcl8.5",
7979:             "tcl8.6",
7980:             "tcl9.0",
7981:             "tcl9.1",
7982:             "jimtcl",
7983:             "f5-irules",
7984:             "f5-tmsh",
7985:             "f5-iapps",
7986:         ] {
7987:             let mut analyser = Analyser::new();
7988:             analyser.result = analyser.analyse(source, dialect);
7989:             assert!(!has_w315(&analyser.result), "{dialect}");
7990:             analyser.result.lexical_declaration_advice = true;
7991:             analyser.result.dialect = "explicit-object-abort-advice".to_owned();
7992:             inject_object_abort_candidates(&mut analyser);
7993:             assert_eq!(analyser.objdefine_abort_candidates.len(), 3);
7994:             analyser.flush_objdefine_abort_diagnostics();
7995:             assert!(
7996:                 !has_w315(&analyser.result),
7997:                 "{dialect}: report maps grant no Native table"
7998:             );
7999:             assert!(analyser.objdefine_abort_candidates.is_empty());
8000:         }
8001:     }
8002: 
8003:     #[test]
8004:     fn original_object_abort_refuses_missing_retained_input() {
8005:         // naming.diagnostics.original-object-abort-admission
8006:         // docs/design/analysis/name-resolution-proofs/diagnostic-original-object-abort-admission.md
8007:         let mut analyser = Analyser::new();
8008:         analyser.result.lexical_declaration_advice = true;
8009:         assert!(analyser.result.resolved_input.is_none());
8010:         inject_object_abort_candidates(&mut analyser);
8011:         analyser.flush_objdefine_abort_diagnostics();
8012:         assert!(!has_w315(&analyser.result));
8013:         assert!(analyser.objdefine_abort_candidates.is_empty());
8014:     }
8015: 
8016:     #[test]
8017:     fn original_object_abort_keeps_explicit_logical_advice_despite_report_label() {
8018:         // naming.diagnostics.original-object-abort-admission
8019:         // docs/design/analysis/name-resolution-proofs/diagnostic-original-object-abort-admission.md
8020:         let mut analyser = logical_object_abort_analyser();
8021:         analyser.result = analyser.analyse("", "explicit-object-abort-advice");
8022:         assert!(analyser.result.allows_lexical_declaration_advice());
8023:         assert!(
8024:             analyser
8025:                 .result
8026:                 .resolved_input
8027:                 .as_ref()
8028:                 .unwrap()
8029:                 .has_logical_source_name_context()
8030:         );
8031:         analyser.result.dialect = "tcl9.0".to_owned();
8032:         inject_object_abort_candidates(&mut analyser);
8033:         analyser.flush_objdefine_abort_diagnostics();
8034:         assert_eq!(w315_messages(&analyser.result).len(), 3);
8035:     }
8036: 
8037:     // Per-object abort reports use explicitly selected Logical source advice.
8038:     // The String table supplies no Native own-method presence or completeness.
8039: 
8040:     #[test]
8041:     fn w315_fires_for_a_per_object_retraction_of_a_never_declared_member() {
8042:         // Explicit Logical compatibility uses the authored object's own table,
8043:         // independently of inherited class metadata. No Native absence is proved.
8044:         let mut a = logical_object_abort_analyser();
8045:         let r = a.analyse(
8046:             "oo::class create ::C { method ghost {} { return g } }\n\
8047:              set o [::C new]\n\
8048:              oo::objdefine $o { deletemethod ghost }",
8049:             "explicit-object-abort-advice",
8050:         );
8051:         assert_eq!(
8052:             w315_messages(&r),
8053:             vec!["this object definition cannot run: method \"ghost\" does not exist".to_string()],
8054:         );
8055:     }
8056: 
8057:     #[test]
8058:     fn w315_fires_for_a_per_object_rename_onto_an_existing_member() {
8059:         // Explicit Logical source order retains a destination declared by an
8060:         // earlier block of the same authored binding. It grants no Native table.
8061:         let mut a = logical_object_abort_analyser();
8062:         let r = a.analyse(
8063:             "oo::class create ::C {}\n\
8064:              set o [::C new]\n\
8065:              oo::objdefine $o { method a {} { return a }\n method b {} { return b } }\n\
8066:              oo::objdefine $o { renamemethod a b }",
8067:             "explicit-object-abort-advice",
8068:         );
8069:         assert_eq!(
8070:             w315_messages(&r),
8071:             vec![
8072:                 "this object definition cannot run: method called \"b\" already exists".to_string()
8073:             ],
8074:         );
8075:     }
8076: 
8077:     #[test]
8078:     fn w315_fires_for_a_per_object_rename_to_itself() {
8079:         // The Logical model selects the same source and destination name;
8080:         // the compatibility assertion does not grant a Native worker receipt.
8081:         let mut a = logical_object_abort_analyser();
8082:         let r = a.analyse(
8083:             "oo::objdefine $o { method x {} { return x }\n renamemethod x x }",
8084:             "explicit-object-abort-advice",
8085:         );
8086:         assert_eq!(
8087:             w315_messages(&r),
8088:             vec!["this object definition cannot run: cannot rename method to itself".to_string()],
8089:         );
8090:     }
8091: 
8092:     #[test]
8093:     fn per_object_w315_abstains_without_the_receivers_construction_in_view() {
8094:         // Logical metadata for an extension lacks a closed authored receiver
8095:         // table; a declaration in another file remains possible.
8096:         let mut a = logical_object_abort_analyser();
8097:         let r = a.analyse(
8098:             "oo::objdefine $o { deletemethod ghost }",
8099:             "explicit-object-abort-advice",
8100:         );
8101:         assert!(!has_w315(&r), "{:?}", w315_messages(&r));
8102:     }
8103: 
8104:     #[test]
8105:     fn per_object_w315_abstains_when_any_key_declares_the_member() {
8106:         // An authored alias can refer to a member declared under another key.
8107:         // Logical metadata with that possibility cannot assert its absence.
8108:         let mut a = logical_object_abort_analyser();
8109:         let r = a.analyse(
8110:             "oo::class create ::C {}\n\
8111:              set p [::C new]\n\
8112:              oo::objdefine $p { method ghost {} { return g } }\n\
8113:              set o [::C new]\n\
8114:              set o $p\n\
8115:              oo::objdefine $o { deletemethod ghost }",
8116:             "explicit-object-abort-advice",
8117:         );
8118:         assert!(!has_w315(&r), "{:?}", w315_messages(&r));
8119:     }
8120: 
8121:     #[test]
8122:     fn per_object_w315_abstains_when_any_receiver_is_unresolved() {
8123:         // An unknown authored receiver can affect any object's source table.
8124:         let mut a = logical_object_abort_analyser();
8125:         let r = a.analyse(
8126:             "oo::class create ::C {}\n\
8127:              set o [::C new]\n\
8128:              oo::objdefine [pick] { method ghost {} { return g } }\n\
8129:              oo::objdefine $o { deletemethod ghost }",
8130:             "explicit-object-abort-advice",
8131:         );
8132:         assert!(!has_w315(&r), "{:?}", w315_messages(&r));
8133:     }
8134: 
8135:     #[test]
8136:     fn w315_stays_silent_for_every_legal_order() {
8137:         // naming.diagnostics.original-definition-abort-admission
8138:         // docs/design/analysis/name-resolution-proofs/diagnostic-original-definition-abort-admission.md
8139:         // Explicit Logical source-table compatibility; no Native worker/table claim.
8140:         for body in [
8141:             "method a {} {}\nmethod b {} {}\ndeletemethod a",
8142:             "self { method a {} {}\nmethod b {} {}\ndeletemethod a }",
8143:             "method a {} {}\nrenamemethod a fresh",
8144:             "method a {} {}\nself { method b {} {} }\nrenamemethod a b",
8145:             "method a {} {}\ndeletemethod a\nmethod a {} {}",
8146:             "method a {} {}\nmethod b {} {}\ndeletemethod b\nrenamemethod a b",
8147:             "method a {} {}\nrenamemethod a b\nrenamemethod b c",
8148:         ] {
8149:             let mut a = logical_object_abort_analyser();
8150:             let r = a.analyse(
8151:                 &format!("oo::class create ::C {{ {body} }}"),
8152:                 "explicit-object-abort-advice",
8153:             );
8154:             assert!(!has_w315(&r), "body: {body} -> {:?}", w315_messages(&r));
8155:         }
8156:     }
8157: 
8158:     #[test]
8159:     fn a_cross_side_visibility_word_is_not_a_w315() {
8160:         // naming.diagnostics.original-definition-abort-admission
8161:         // docs/design/analysis/name-resolution-proofs/diagnostic-original-definition-abort-admission.md
8162:         // Explicit Logical source-table compatibility; no Native worker/table claim.
8163:         for body in [
8164:             "method onlyinst {} {}\nself unexport onlyinst",
8165:             "self { method onlyclass {} {} }\nunexport onlyclass",
8166:             "export ghost",
8167:             "self export ghost",
8168:             "filter ghost",
8169:             "self filter ghost",
8170:         ] {
8171:             let mut a = logical_object_abort_analyser();
8172:             let r = a.analyse(
8173:                 &format!("oo::class create ::C {{ {body} }}"),
8174:                 "explicit-object-abort-advice",
8175:             );
8176:             assert!(!has_w315(&r), "body: {body} -> {:?}", w315_messages(&r));
8177:         }
8178:     }
8179: 
8180:     #[test]
8181:     fn w315_abstains_on_a_dynamic_source_name() {
8182:         // naming.diagnostics.original-definition-abort-admission
8183:         // docs/design/analysis/name-resolution-proofs/diagnostic-original-definition-abort-admission.md
8184:         // Explicit Logical source-table compatibility; no Native worker/table claim.
8185:         for body in [
8186:             "method m {} {}\ndeletemethod $gone",
8187:             "method m {} {}\nrenamemethod $old new",
8188:             "method m {} {}\ndeletemethod [pick]",
8189:         ] {
8190:             let mut a = logical_object_abort_analyser();
8191:             let r = a.analyse(
8192:                 &format!("oo::class create ::C {{ {body} }}"),
8193:                 "explicit-object-abort-advice",
8194:             );
8195:             assert!(!has_w315(&r), "body: {body} -> {:?}", w315_messages(&r));
8196:             assert!(
8197:                 r.all_classes["::C"].methods.contains_key("m"),
8198:                 "body: {body}: a dynamic retraction must not remove a member",
8199:             );
8200:             assert_eq!(
8201:                 r.all_classes["::C"].retracted_members.len(),
8202:                 0,
8203:                 "body: {body}: {:?}",
8204:                 r.all_classes["::C"].retracted_members,
8205:             );
8206:         }
8207:     }
8208: 
8209:     #[test]
8210:     fn a_dynamic_rename_destination_still_retracts_the_source() {
8211:         // TN for the *destination* half, which is not symmetric with the source.
8212:         // Whatever `$n` turns out to be, `renamemethod m $n` definitely takes
8213:         // `m` away — `::C m` is an unknown method afterwards on 9.0.4 and
8214:         // 8.6.14 alike — so retracting the source is the faithful answer even
8215:         // though the arrival name is unknowable. Only the arrival abstains, and
8216:         // with no static destination there is nothing to check for a collision.
8217:         let mut a = Analyser::new();
8218:         let r = a.analyse(
8219:             "oo::class create ::C { method m {} { return m }\n\
8220:              method n {} { return n }\n\
8221:              renamemethod m $n }",
8222:             "tcl9.0",
8223:         );
8224:         let c = r.all_classes.get("::C").expect("::C recorded");
8225:         assert!(!c.methods.contains_key("m"), "{:?}", c.methods);
8226:         assert!(
8227:             c.methods.contains_key("n"),
8228:             "the collision guess is not made"
8229:         );
8230:         assert!(!has_w315(&r), "{:?}", w315_messages(&r));
8231:     }
8232: 
8233:     #[test]
8234:     fn a_cross_file_stub_retraction_is_a_tombstone_not_a_w315() {
8235:         // naming.diagnostics.original-definition-abort-admission
8236:         // docs/design/analysis/name-resolution-proofs/diagnostic-original-definition-abort-admission.md
8237:         // Explicit Logical source-table compatibility; no Native worker/table claim.
8238:         let mut a = logical_object_abort_analyser();
8239:         let r = a.analyse(
8240:             "oo::define ::C { deletemethod m }\n\
8241:              oo::define ::D { self deletemethod cm }\n\
8242:              oo::define ::E { renamemethod old new }",
8243:             "explicit-object-abort-advice",
8244:         );
8245:         assert!(!has_w315(&r), "{:?}", w315_messages(&r));
8246:         assert_eq!(
8247:             r.all_classes["::C"].retracted_members,
8248:             vec![MemberRetractionRecord::deletion(
8249:                 "m".to_string(),
8250:                 MemberSide::Instance
8251:             )],
8252:         );
8253:         assert!(r.all_classes["::C"].via_define);
8254:     }
8255: 
8256:     #[test]
8257:     fn a_same_file_define_extending_a_local_class_is_not_a_stub() {
8258:         // naming.diagnostics.original-definition-abort-admission
8259:         // docs/design/analysis/name-resolution-proofs/diagnostic-original-definition-abort-admission.md
8260:         // Explicit Logical source-table compatibility; no Native worker/table claim.
8261:         let mut a = logical_object_abort_analyser();
8262:         let r = a.analyse(
8263:             "oo::class create ::C { method kept {} { return k } }\n\
8264:              oo::define ::C { deletemethod ghost }",
8265:             "explicit-object-abort-advice",
8266:         );
8267:         assert_eq!(
8268:             w315_messages(&r),
8269:             vec!["this class definition cannot run: method \"ghost\" does not exist".to_string()],
8270:         );
8271:         assert!(!r.all_classes["::C"].via_define);
8272:         assert_eq!(
8273:             r.all_classes["::C"].retracted_members.len(),
8274:             0,
8275:             "{:?}",
8276:             r.all_classes["::C"].retracted_members,
8277:         );
8278:     }
8279: 
8280:     #[test]
8281:     fn a_move_records_the_member_state_it_ran_against() {
8282:         // The moved member's declaration site is the
8283:         // `renamemethod`'s destination word, so a *rename* of it rewrites that
8284:         // word — and the gate that decides whether the result still runs needs
8285:         // the table as it stood at the move. Captured with the source already
8286:         // removed and the destination not yet inserted, which is exactly what
8287:         // the interpreter reads at that point.
8288:         let src = "oo::class create ::C { method old {} { return 1 }\n\
8289:                    method sib {} { return 2 }\n\
8290:                    renamemethod old new }";
8291:         let mut a = Analyser::new();
8292:         let r = a.analyse(src, "tcl9.0");
8293:         let c = r.all_classes.get("::C").expect("::C recorded");
8294:         assert_eq!(c.renamed_members.len(), 1, "{:?}", c.renamed_members);
8295:         let moved = &c.renamed_members[0];
8296:         assert_eq!(moved.source, "old");
8297:         assert_eq!(moved.destination, "new");
8298:         assert_eq!(moved.side, MemberSide::Instance);
8299:         assert_eq!(
8300:             &src[moved.destination_span.start() as usize..moved.destination_span.end() as usize],
8301:             "new",
8302:         );
8303:         // `sib` is live at the move; `old` is not (it was just retracted) and
8304:         // `new` is not (it has not arrived yet).
8305:         assert_eq!(moved.blocked, vec!["sib".to_string()]);
8306:     }
8307: 
8308:     #[test]
8309:     fn the_move_record_answers_which_new_names_would_abort() {
8310:         // The shared fold both consumers use: the walker asks it about the
8311:         // destination actually written (that is how W315 is decided) and the
8312:         // rename gate asks it about the name the user typed. Oracle, identical
8313:         // on tclsh 9.0.4 and 8.6.14 — no class is created in either case:
8314:         //   { method old {} {…} ; renamemethod old old }
8315:         //        -> cannot rename method to itself
8316:         //   { method old {} {…} ; method sib {} {…} ; renamemethod old sib }
8317:         //        -> method called sib already exists
8318:         let mut a = Analyser::new();
8319:         let r = a.analyse(
8320:             "oo::class create ::C { method old {} { return 1 }\n\
8321:              method sib {} { return 2 }\n\
8322:              renamemethod old new }",
8323:             "tcl9.0",
8324:         );
8325:         let moved = &r.all_classes["::C"].renamed_members[0];
8326:         assert_eq!(
8327:             moved.abort_if_renamed_to("old"),
8328:             Some(DefinitionAbortKind::RenameToItself),
8329:         );
8330:         assert_eq!(
8331:             moved.abort_if_renamed_to("sib"),
8332:             Some(DefinitionAbortKind::DestinationExists),
8333:         );
8334:         // TN: a fresh name is fine, and so is the destination it already has.
8335:         assert_eq!(moved.abort_if_renamed_to("fresh"), None);
8336:         // The mirror direction, from the same record.
8337:         assert!(moved.collides_with_renaming("sib", "new"));
8338:         assert!(!moved.collides_with_renaming("sib", "other"));
8339:     }
8340: 
8341:     #[test]
8342:     fn a_cross_side_name_is_not_in_the_move_snapshot() {
8343:         // TN (CRITICAL). Collisions are side-local: `method old {} {…}` +
8344:         // `self { method sib {} {…} }` + `renamemethod old sib` runs fine and
8345:         // leaves `info class methods ::C1` -> sib (9.0.4 / 8.6.14). So a
8346:         // class-side `sib` must not appear in an instance-side move's snapshot.
8347:         let mut a = Analyser::new();
8348:         let r = a.analyse(
8349:             "oo::class create ::C { method old {} { return 1 }\n\
8350:              self { method sib {} { return 2 } }\n\
8351:              renamemethod old new }",
8352:             "tcl9.0",
8353:         );
8354:         let moved = &r.all_classes["::C"].renamed_members[0];
8355:         assert_eq!(moved.blocked.len(), 0, "{:?}", moved.blocked);
8356:         assert_eq!(moved.abort_if_renamed_to("sib"), None);
8357:     }
8358: 
8359:     #[test]
8360:     fn the_move_snapshot_honours_body_order_in_both_directions() {
8361:         // TN ×2, both oracle-pinned legal on 9.0.4 and 8.6.14:
8362:         //   { method old {} {} ; method sib {} {} ; deletemethod sib
8363:         //     renamemethod old sib }                 -> info class methods -> sib
8364:         //   { method old {} {} ; renamemethod old sib ; method sib {} {} }
8365:         //                                            -> info class methods -> sib
8366:         // so a name deleted *before* the move is free, and one declared
8367:         // *after* it never collides with it.
8368:         let mut a = Analyser::new();
8369:         let r = a.analyse(
8370:             "oo::class create ::C { method old {} { return 1 }\n\
8371:              method sib {} { return 2 }\n\
8372:              deletemethod sib\n\
8373:              renamemethod old new }",
8374:             "tcl9.0",
8375:         );
8376:         assert_eq!(
8377:             r.all_classes["::C"].renamed_members[0].abort_if_renamed_to("sib"),
8378:             None,
8379:             "a name deleted before the move is free",
8380:         );
8381:         let mut a = Analyser::new();
8382:         let r = a.analyse(
8383:             "oo::class create ::D { method old {} { return 1 }\n\
8384:              renamemethod old new\n\
8385:              method sib {} { return 2 } }",
8386:             "tcl9.0",
8387:         );
8388:         assert_eq!(
8389:             r.all_classes["::D"].renamed_members[0].abort_if_renamed_to("sib"),
8390:             None,
8391:             "a name declared after the move never collides with it",
8392:         );
8393:     }
8394: 
8395:     #[test]
8396:     fn a_rejected_rename_records_no_move() {
8397:         // naming.diagnostics.original-definition-abort-admission
8398:         // docs/design/analysis/name-resolution-proofs/diagnostic-original-definition-abort-admission.md
8399:         // Explicit Logical source-table compatibility; no Native worker/table claim.
8400:         for body in [
8401:             "method a {} {}\nrenamemethod a a",
8402:             "method a {} {}\nmethod b {} {}\nrenamemethod a b",
8403:         ] {
8404:             let mut a = logical_object_abort_analyser();
8405:             let r = a.analyse(
8406:                 &format!("oo::class create ::C {{ {body} }}"),
8407:                 "explicit-object-abort-advice",
8408:             );
8409:             assert_eq!(
8410:                 r.all_classes["::C"].renamed_members.len(),
8411:                 0,
8412:                 "body: {body}: {:?}",
8413:                 r.all_classes["::C"].renamed_members,
8414:             );
8415:             assert!(has_w315(&r), "body: {body}");
8416:         }
8417:     }
8418: 
8419:     #[test]
8420:     fn a_blocked_rename_keeps_both_members_navigable() {
8421:         // Navigation-resilience pin for the aborting shapes. Real Tcl creates no
8422:         // class at all, so there is no "right" answer to mirror — the useful one
8423:         // keeps every declaration the author wrote reachable rather than letting
8424:         // the wreckage take one with it.
8425:         let src = "oo::class create ::C { method a {} { return a }\n\
8426:                    method b {} { return b }\n\
8427:                    renamemethod a b }";
8428:         let mut a = Analyser::new();
8429:         let r = a.analyse(src, "tcl9.0");
8430:         let c = r.all_classes.get("::C").expect("::C recorded");
8431:         assert!(c.methods.contains_key("a"), "source kept: {:?}", c.methods);
8432:         let b = c.methods.get("b").expect("destination kept");
8433:         assert!(
8434:             src[b.body_span.start() as usize..b.body_span.end() as usize].contains("return b"),
8435:             "the destination keeps its OWN body",
8436:         );
8437:     }
8438: 
8439:     #[test]
8440:     fn w315_is_reported_once_per_offending_word() {
8441:         // naming.diagnostics.original-definition-abort-admission
8442:         // docs/design/analysis/name-resolution-proofs/diagnostic-original-definition-abort-admission.md
8443:         // Explicit Logical source-table compatibility; no Native worker/table claim.
8444:         let mut a = logical_object_abort_analyser();
8445:         let r = a.analyse(
8446:             "oo::class create ::C { method kept {} { return k } }\n\
8447:              oo::define ::C { deletemethod ghost }\n\
8448:              oo::define ::C { method extra {} { return e } }\n\
8449:              oo::define ::C { deletemethod other }",
8450:             "explicit-object-abort-advice",
8451:         );
8452:         assert_eq!(
8453:             w315_messages(&r),
8454:             vec![
8455:                 "this class definition cannot run: method \"ghost\" does not exist".to_string(),
8456:                 "this class definition cannot run: method \"other\" does not exist".to_string(),
8457:             ],
8458:         );
8459:     }
8460: 
8461:     #[test]
8462:     fn w315_points_at_the_offending_word() {
8463:         // naming.diagnostics.original-definition-abort-admission
8464:         // docs/design/analysis/name-resolution-proofs/diagnostic-original-definition-abort-admission.md
8465:         // Explicit Logical source-table compatibility; no Native worker/table claim.
8466:         let src = "oo::class create ::C { deletemethod ghost }";
8467:         let mut a = logical_object_abort_analyser();
8468:         let r = a.analyse(src, "explicit-object-abort-advice");
8469:         let d = r
8470:             .diagnostics
8471:             .iter()
8472:             .find(|d| d.code == tcl_core_types::DiagCode::W315)
8473:             .expect("W315");
8474:         assert_eq!(
8475:             &src[d.span.start() as usize..d.span.end() as usize],
8476:             "ghost"
8477:         );
8478:     }
8479: 
8480:     #[test]
8481:     fn a_stub_retraction_of_an_undeclared_member_leaves_a_tombstone() {
8482:         // naming.source.original-class-reference
8483:         // docs/design/analysis/name-resolution-proofs/source-original-class-reference.md
8484:         // Explicit Logical cross-document advisory channel; no Native class or retraction.
8485:         // TP for the cross-document channel. This document
8486:         // is the `oo::define ::C { deletemethod m }` half of a two-file program:
8487:         // it has no local `m` to remove, so the removal has to travel as a
8488:         // tombstone or the workspace keeps advertising a method that sourcing
8489:         // this file deletes. The side travels with it — a `self`-scoped
8490:         // retraction tombstones the class-object side.
8491:         let mut a = logical_object_abort_analyser();
8492:         let r = a.analyse(
8493:             "oo::define ::C { deletemethod m }\n\
8494:              oo::define ::D { self deletemethod cm }",
8495:             "explicit-object-abort-advice",
8496:         );
8497:         assert_eq!(
8498:             r.all_classes["::C"].retracted_members,
8499:             vec![MemberRetractionRecord::deletion(
8500:                 "m".to_string(),
8501:                 MemberSide::Instance
8502:             )],
8503:         );
8504:         assert_eq!(
8505:             r.all_classes["::D"].retracted_members,
8506:             vec![MemberRetractionRecord::deletion(
8507:                 "cm".to_string(),
8508:                 MemberSide::ClassObject
8509:             )],
8510:         );
8511:     }
8512: 
8513:     #[test]
8514:     fn a_stub_renamemethod_tombstones_only_the_source_name() {
8515:         // naming.source.original-class-reference
8516:         // docs/design/analysis/name-resolution-proofs/source-original-class-reference.md
8517:         // Explicit Logical cross-document advisory channel; no Native move.
8518:         // TN for the tombstone's shape: `renamemethod old new` removes `old` and
8519:         // *creates* `new` (oracle: `info class methods ::I3` -> new, and
8520:         // `[::I3 new] new` answers), so tombstoning `new` would suppress a live
8521:         // member another document legitimately declares. Which arguments a
8522:         // retracting word removes is registry data
8523:         // ([`tcl_registry::definer::MemberRetraction::FirstArgument`]), not a
8524:         // keyword match here.
8525:         let mut a = logical_object_abort_analyser();
8526:         let r = a.analyse(
8527:             "oo::define ::C { renamemethod old new }",
8528:             "explicit-object-abort-advice",
8529:         );
8530:         assert_eq!(
8531:             r.all_classes["::C"]
8532:                 .retracted_members
8533:                 .iter()
8534:                 .map(|r| (r.member.clone(), r.side))
8535:                 .collect::<Vec<_>>(),
8536:             vec![("old".to_string(), MemberSide::Instance)],
8537:         );
8538:         // …and the arrival travels with it: the stub has no
8539:         // `MethodDef` to move, so the destination name is what lets the
8540:         // workspace join re-key the defining file's record.
8541:         assert_eq!(
8542:             r.all_classes["::C"].retracted_members[0].arrival.as_deref(),
8543:             Some("new"),
8544:         );
8545:     }
8546: 
8547:     #[test]
8548:     fn missing_class_source_cannot_publish_native_definition_stubs() {
8549:         // naming.source.original-class-reference
8550:         // docs/design/analysis/name-resolution-proofs/source-original-class-reference.md
8551:         let source = "oo::define ::C {deletemethod m}; oo::define ::D {renamemethod old new}";
8552:         for profile in ["tcl8.6", "tcl9.0", "tcl9.1", "f5-irules"] {
8553:             let result = Analyser::new().analyse(source, profile);
8554:             assert!(!result.all_classes.contains_key("::C"), "{profile}");
8555:             assert!(!result.all_classes.contains_key("::D"), "{profile}");
8556:         }
8557:         let mut missing = logical_object_abort_analyser();
8558:         let mut baseline = logical_object_abort_analyser();
8559:         missing.result = baseline.analyse(source, "explicit-object-abort-advice");
8560:         assert!(missing.result.all_classes.contains_key("::C"));
8561:         missing.result.resolved_input = None;
8562:         missing.result.all_classes.clear();
8563:         missing.source = source.to_owned();
8564:         let command = crate::segmenter::segment_commands_with_offset_and_config(
8565:             source,
8566:             0,
8567:             missing.lexer_config(),
8568:         )
8569:         .remove(0);
8570:         assert!(missing.handle_oo_define_command(
8571:             command.name(),
8572:             command.args(),
8573:             command.arg_tokens(),
8574:             command.arg_single_token(),
8575:             &[],
8576:         ));
8577:         assert!(missing.result.all_classes.is_empty());
8578:     }
8579: 
8580:     #[test]
8581:     fn visibility_sets_keep_only_the_last_writer() {
8582:         // `exports` / `unexports` each record the
8583:         // *last* explicit writer for a name, and the cross-file consumer
8584:         // (`workspace_index::method_dispatch_chain`) reads any `exports` entry
8585:         // as decisive — so a name must never sit in both. Oracle, identical on
8586:         // tclsh 9.0.4 and 8.6.14:
8587:         //   oo::class create L1 { method m {} {…}; export m; unexport m }
8588:         //   info class methods ::L1  ->            ;  [L1 new] m -> unknown method
8589:         //   oo::class create L2 { method m {} {…}; unexport m; export m }
8590:         //   info class methods ::L2  -> m          ;  [L2 new] m -> 1
8591:         // Both unwrapped and `private`-scoped writers must leave each name
8592:         // in exactly the set selected by its last explicit visibility operation.
8593:         for (body, last, want_vis) in [
8594:             ("export m\nunexport m", "unexports", "unexported"),
8595:             ("unexport m\nexport m", "exports", "public"),
8596:             (
8597:                 "private export m\nprivate unexport m",
8598:                 "unexports",
8599:                 "unexported",
8600:             ),
8601:             ("private unexport m\nprivate export m", "exports", "public"),
8602:             (
8603:                 "private { export m }\nprivate { unexport m }",
8604:                 "unexports",
8605:                 "unexported",
8606:             ),
8607:         ] {
8608:             let src = format!("oo::class create ::C {{ method m {{}} {{ return 1 }}\n{body} }}");
8609:             let mut a = Analyser::new();
8610:             let r = a.analyse(&src, "tcl9.0");
8611:             let c = r.all_classes.get("::C").expect("::C recorded");
8612:             let (winner, loser) = if last == "exports" {
8613:                 (&c.exports, &c.unexports)
8614:             } else {
8615:                 (&c.unexports, &c.exports)
8616:             };
8617:             assert!(winner.contains("m"), "{body}: {last} must hold `m`");
8618:             assert!(
8619:                 !loser.contains("m"),
8620:                 "{body}: the superseded set still holds `m` — cross-file dispatch \
8621:                  reads any `exports` entry as decisive",
8622:             );
8623:             assert_eq!(c.methods["m"].visibility, want_vis, "{body}");
8624:         }
8625:     }
8626: 
8627:     #[test]
8628:     fn a_self_scoped_visibility_word_never_touches_the_instance_sets() {
8629:         // TN for the same sets: they are the *instance*-side record, so a
8630:         // class-object-side flip must stay out of them entirely (in either
8631:         // direction) — otherwise it would re-state an unrelated instance
8632:         // method's export bit cross-file.
8633:         let src = "oo::class create ::C {\n\
8634:                    method m {} { return 1 }\n\
8635:                    self { method m {} { return 2 }\n\
8636:                    unexport m\n\
8637:                    export m\n\
8638:                    }\n\
8639:                    }";
8640:         let mut a = Analyser::new();
8641:         let r = a.analyse(src, "tcl9.0");
8642:         let c = r.all_classes.get("::C").expect("::C recorded");
8643:         assert_eq!(c.exports.len(), 0, "{:?}", c.exports);
8644:         assert_eq!(c.unexports.len(), 0, "{:?}", c.unexports);
8645:         assert_eq!(c.methods["m"].visibility, "public");
8646:         assert_eq!(c.class_methods["m"].visibility, "public");
8647:     }
8648: 
8649:     #[test]
8650:     fn unwrapped_deletemethod_does_not_touch_the_class_side() {
8651:         // TN. The unwrapped word is instance-scoped; a class-object-side member
8652:         // of the same name survives it. (Real Tcl goes further and makes the
8653:         // cross-side form a hard definition-aborting error — `oo::define ::I5
8654:         // { deletemethod cm }` over a `self`-only `cm` raises `method cm does
8655:         // not exist` and leaves `info object methods ::I5` -> cm — so a
8656:         // document that reaches this shape never ran; keeping the class-side
8657:         // entry is the abstaining answer either way.)
8658:         let src = "oo::class create ::C {\n\
8659:                    self { method cm {} { return c } }\n\
8660:                    }\n\
8661:                    oo::define ::C { deletemethod cm }";
8662:         let mut a = Analyser::new();
8663:         let r = a.analyse(src, "tcl9.0");
8664:         let c = r.all_classes.get("::C").expect("::C recorded");
8665:         assert!(c.class_methods.contains_key("cm"));
8666:     }
8667: 
8668:     #[test]
8669:     fn unwrapped_non_destructive_members_do_not_retract() {
8670:         // TN for the registry flag: `export` / `unexport` / `filter` name a
8671:         // method without removing it, so the unwrapped arm must leave them be.
8672:         for member in ["export", "unexport", "filter"] {
8673:             let src =
8674:                 format!("oo::class create ::C {{ method m {{}} {{ return 1 }}\n{member} m }}");
8675:             let mut a = Analyser::new();
8676:             let r = a.analyse(&src, "tcl9.0");
8677:             assert!(
8678:                 r.all_classes["::C"].methods.contains_key("m"),
8679:                 "`{member}` must not retract",
8680:             );
8681:         }
8682:     }
8683: 
8684:     #[test]
8685:     fn source_configuration_accumulates_redeclared_members_under_original_class_owner() {
8686:         // naming.source.original-class-reference
8687:         // docs/design/analysis/name-resolution-proofs/source-original-class-reference.md
8688:         // Conditional source chronology and canonical metadata, without an
8689:         // executed configuration worker or a live Native method table.
8690:         for source in [
8691:             "oo::class create C {method m {} {return FIRST}}; oo::define C {deletemethod m}; oo::define C {method m {} {return LAST}}",
8692:             "oo::class create C {method m {} {return FIRST}}; rename C Held; interp alias {} configure {} oo::define Held; configure {deletemethod m}; configure {method m {} {return LAST}}",
8693:         ] {
8694:             let mut result = Analyser::new().analyse(source, "tcl9.0");
8695:             let declaration = result.original_class_declarations().next().unwrap();
8696:             assert!(declaration.metadata().methods.contains_key("m"));
8697:             let last = source.find("return LAST").unwrap();
8698:             assert!(
8699:                 declaration.metadata().methods["m"]
8700:                     .body_span
8701:                     .as_range()
8702:                     .contains(&last)
8703:             );
8704:             let methods = declaration
8705:                 .metadata()
8706:                 .original_members
8707:                 .methods(MemberSide::Instance)
8708:                 .unwrap();
8709:             let method = methods
8710:                 .iter()
8711:                 .find(|method| method.original_name_input().bytes() == b"m")
8712:                 .unwrap();
8713:             assert!(method.metadata().body_span.as_range().contains(&last));
8714:             let canonical = declaration.clone();
8715:             result.all_classes.clear();
8716:             assert_eq!(
8717:                 result.original_class_declarations().next(),
8718:                 Some(&canonical)
8719:             );
8720:         }
8721:         let source = "oo::class create C {}; rename C {}; oo::define C {method ghost {} {}}";
8722:         let result = Analyser::new().analyse(source, "tcl9.0");
8723:         assert_eq!(result.original_class_declarations().count(), 1);
8724:         assert!(result.original_class_declarations().all(|declaration| {
8725:             !declaration.metadata().methods.contains_key("ghost")
8726:                 && declaration
8727:                     .metadata()
8728:                     .original_members
8729:                     .declarations()
8730:                     .all(|method| method.original_name_input().bytes() != b"ghost")
8731:         }));
8732:     }
8733: 
8734:     #[test]
8735:     fn an_unwrapped_retracted_member_can_be_redeclared_by_a_later_body() {
8736:         // Source-order guard, unwrapped half. Retraction happens where the body
8737:         // is walked, so a later `oo::define` redeclaration wins rather than the
8738:         // name being erased document-wide.
8739:         let src = "oo::class create ::C { method m {} { return 1 } }\n\
8740:                    oo::define ::C { deletemethod m }\n\
8741:                    oo::define ::C { method m {} { return 2 } }";
8742:         let mut a = Analyser::new();
8743:         let r = a.analyse(src, "tcl9.0");
8744:         assert!(r.all_classes["::C"].methods.contains_key("m"));
8745:     }
8746: 
8747:     #[test]
8748:     fn objdefine_deletemethod_drops_the_per_object_member() {
8749:         // The per-object table is the same instance-side routing. Oracle:
8750:         //   oo::objdefine $o { method im {} {…}; deletemethod im }
8751:         //   info object methods $o  ->            (empty)
8752:         // `oo::objdefine` records into a throwaway `ClassDef` that never
8753:         // reaches `all_classes`, so this asserts the walk simply does not
8754:         // panic or resurrect the name anywhere.
8755:         let src = "oo::class create ::C { method m {} { return m } }\n\
8756:                    set o [::C new]\n\
8757:                    oo::objdefine $o { method im {} { return i }\n\
8758:                    deletemethod im }";
8759:         let mut a = Analyser::new();
8760:         let r = a.analyse(src, "tcl9.0");
8761:         assert!(!r.all_classes.contains_key("::@objdefine@::o"));
8762:         assert!(r.all_classes["::C"].methods.contains_key("m"));
8763:     }
8764: 
8765:     // snit (tcllib) type / widget support.  Verified against real
8766:     // `tclsh8.6` + tcllib.
8767: 
8768:     #[test]
8769:     fn snit_type_recorded_as_class_with_members() {
8770:         let src = "snit::type ::foo::Bar {\n\
8771:                    variable v1\n\
8772:                    typevariable tv1\n\
8773:                    method m1 {a b} { return [expr {$a+$b+$v1}] }\n\
8774:                    typemethod tm1 {} { return $tv1 }\n\
8775:                    constructor {args} { set v1 0 }\n\
8776:                    destructor { unset v1 }\n\
8777:                    typeconstructor { set tv1 0 }\n\
8778:                    }";
8779:         let mut a = Analyser::new();
8780:         let r = a.analyse(src, "tcl8.6");
8781:         let c = r.all_classes.get("::foo::Bar").expect("Bar class recorded");
8782:         assert_eq!(c.metaclass, "snit::type");
8783:         assert!(c.methods.contains_key("m1"));
8784:         assert!(c.class_methods.contains_key("tm1"));
8785:         assert!(c.class_methods.contains_key("<typeconstructor>"));
8786:         assert_eq!(c.constructors.len(), 1);
8787:         assert!(c.destructor.is_some());
8788:         assert_eq!(c.variables, vec!["v1".to_string(), "tv1".to_string()]);
8789:     }
8790: 
8791:     #[test]
8792:     fn snit_widget_keeps_win_and_hull_vars() {
8793:         // A snit::widget injects `win` and `hull` instance variables — both
8794:         // are recorded (only the four implicit scalars are filtered).
8795:         let src = "snit::widget Dial {\n\
8796:                    variable state\n\
8797:                    method draw {} { return $win }\n\
8798:                    }";
8799:         let mut a = Analyser::new();
8800:         let r = a.analyse(src, "tcl8.6");
8801:         let c = r.all_classes.get("::Dial").expect("Dial recorded");
8802:         assert_eq!(c.metaclass, "snit::widget");
8803:         assert_eq!(
8804:             c.variables,
8805:             vec!["win".to_string(), "hull".to_string(), "state".to_string()]
8806:         );
8807:     }
8808: 
8809:     #[test]
8810:     fn snit_method_body_suppresses_self_dispatch_and_implicit_vars() {
8811:         // Inside a snit method, `$self`/`$component` dispatch and reads of
8812:         // instance variables must not false-fire W307 (non-literal command),
8813:         // W210 (read-before-set), or W211/W214 (unused).
8814:         let src = "snit::widget mywidget {\n\
8815:                    variable helper\n\
8816:                    component inner\n\
8817:                    method draw {} {\n\
8818:                        $self configure -bg white\n\
8819:                        $inner render\n\
8820:                        $helper compute\n\
8821:                        return $win\n\
8822:                    }\n\
8823:                    }";
8824:         let r = crate::provider_fixtures::analyse(
8825:             &format!("package require snit\n{src}"),
8826:             "tcl8.6",
8827:             &[crate::provider_fixtures::Provider::Snit],
8828:         );
8829:         for code in ["W210", "W211", "W214", "W307", "W308"] {
8830:             assert!(
8831:                 !r.diagnostics.iter().any(|d| d.code.as_str() == code),
8832:                 "{code} must not fire in a snit method body: {:?}",
8833:                 r.diagnostics
8834:             );
8835:         }
8836:     }
8837: 
8838:     #[test]
8839:     fn snit_widgetadaptor_and_qualified_definer() {
8840:         let mut a = Analyser::new();
8841:         let r = a.analyse("::snit::widgetadaptor Foo { method m {} {} }", "tcl8.6");
8842:         let c = r.all_classes.get("::Foo").expect("Foo recorded");
8843:         assert_eq!(c.metaclass, "::snit::widgetadaptor");
8844:         assert!(c.methods.contains_key("m"));
8845:     }
8846: 
8847:     #[test]
8848:     fn non_snit_command_is_not_a_class() {
8849:         // A plain command that merely starts with `snit` is not a definer.
8850:         let mut a = Analyser::new();
8851:         let r = a.analyse("snitch foo { bar }", "tcl8.6");
8852:         assert_eq!(r.all_classes.len(), 0);
8853:     }
8854: 
8855:     // [incr Tcl] `itcl::class` — recorded as a `ClassDef` with method scopes,
8856:     // access modifiers unwrapped, `inherit` → superclasses, `this` implicit.
8857: 
8858:     #[test]
8859:     fn itcl_class_recorded_with_members() {
8860:         let src = "itcl::class ::widgets::Dial {\n\
8861:                    inherit Base\n\
8862:                    variable value 0\n\
8863:                    common count 0\n\
8864:                    constructor {args} { set value 0 }\n\
8865:                    destructor { unset value }\n\
8866:                    method spin {delta} { incr value $delta }\n\
8867:                    proc reset {} { set count 0 }\n\
8868:                    }";
8869:         let mut a = Analyser::new();
8870:         let r = a.analyse(src, "tcl8.6");
8871:         let c = r
8872:             .all_classes
8873:             .get("::widgets::Dial")
8874:             .expect("Dial class recorded");
8875:         assert_eq!(c.metaclass, "itcl::class");
8876:         assert_eq!(c.superclasses, vec!["Base".to_string()]);
8877:         assert!(c.methods.contains_key("spin"));
8878:         assert!(
8879:             c.class_methods.contains_key("reset"),
8880:             "proc is a class method"
8881:         );
8882:         assert_eq!(c.constructors.len(), 1);
8883:         assert!(c.destructor.is_some());
8884:         // `variable` + `common` declarations are recorded (implicit `this` is
8885:         // filtered).
8886:         assert_eq!(c.variables, vec!["value".to_string(), "count".to_string()]);
8887:     }
8888: 
8889:     #[test]
8890:     fn itcl_access_modifiers_unwrap_with_visibility() {
8891:         let src = "itcl::class C {\n\
8892:                    public method api {} {}\n\
8893:                    private method helper {} {}\n\
8894:                    protected variable state 0\n\
8895:                    }";
8896:         let mut a = Analyser::new();
8897:         let r = a.analyse(src, "tcl8.6");
8898:         let c = r.all_classes.get("::C").expect("C recorded");
8899:         assert_eq!(c.methods["api"].visibility, "public");
8900:         assert_eq!(c.methods["helper"].visibility, "private");
8901:         // The wrapped `protected variable state` is still a declared variable.
8902:         assert!(c.variables.contains(&"state".to_string()));
8903:     }
8904: 
8905:     #[test]
8906:     fn itcl_method_body_suppresses_this_and_instance_vars() {
8907:         // Inside an itcl method, `$this` dispatch and reads of instance /
8908:         // `common` variables must not false-fire W210/W211/W307.
8909:         let src = "itcl::class C {\n\
8910:                    variable handler\n\
8911:                    common registry\n\
8912:                    method run {} {\n\
8913:                        $this configure\n\
8914:                        $handler process\n\
8915:                        return $registry\n\
8916:                    }\n\
8917:                    }";
8918:         let mut a = Analyser::new();
8919:         let r = a.analyse(src, "tcl8.6");
8920:         for code in ["W210", "W211", "W214", "W307", "W308"] {
8921:             assert!(
8922:                 !r.diagnostics.iter().any(|d| d.code.as_str() == code),
8923:                 "{code} must not fire in an itcl method body: {:?}",
8924:                 r.diagnostics
8925:             );
8926:         }
8927:     }
8928: 
8929:     #[test]
8930:     fn non_itcl_command_is_not_a_class() {
8931:         // A command that merely starts with `itcl` is not a definer.
8932:         let mut a = Analyser::new();
8933:         let r = a.analyse("itclish foo { bar }", "tcl8.6");
8934:         assert_eq!(r.all_classes.len(), 0);
8935:     }
8936: 
8937:     // OO body-walks: `initialise` body, `property -get/-set` accessor bodies,
8938:     // and the `new` / `createWithNamespace` class-command variants.
8939: 
8940:     #[test]
8941:     fn oo_initialise_body_is_walked() {
8942:         // A `variable` read inside `initialise { … }` must not false-fire
8943:         // W210 read-before-set — the class-level init body is walked with the
8944:         // class's instance variables visible.
8945:         let src = "oo::class create Foo {\n\
8946:                    variable cache\n\
8947:                    initialise { set cache [dict create] }\n\
8948:                    method get {k} { return [dict get $cache $k] }\n\
8949:                    }";
8950:         let mut a = Analyser::new();
8951:         let r = a.analyse(src, "tcl8.6");
8952:         assert!(
8953:             !r.diagnostics
8954:                 .iter()
8955:                 .any(|d| matches!(d.code.as_str(), "W210" | "W211")),
8956:             "initialise body should be walked cleanly: {:?}",
8957:             r.diagnostics
8958:         );
8959:     }
8960: 
8961:     /// A class-shared variable set up by the class-level `initialize` script
8962:     /// and reached from a method through `classvariable` must not draw a
8963:     /// read-before-set.
8964:     ///
8965:     /// Oracled on tclsh 9.0.4: this exact class answers `5e-6`. The
8966:     /// `initialize` body runs in the class's own object namespace, so the
8967:     /// write and the read live in different frames — which is precisely why
8968:     /// `classvariable` has to be modelled as a declaration rather than as a
8969:     /// plain local.
8970:     #[test]
8971:     fn classvariable_reaches_a_variable_initialise_declared() {
8972:         let src = "oo::class create Foo {\n\
8973:                    initialize {\n\
8974:                    variable Pitch\n\
8975:                    const Pitch 5e-6\n\
8976:                    }\n\
8977:                    method m {} { classvariable Pitch; return $Pitch }\n\
8978:                    }";
8979:         let mut a = Analyser::new();
8980:         let r = a.analyse(src, "tcl9.0");
8981:         assert!(
8982:             !r.diagnostics.iter().any(|d| d.code.as_str() == "W210"),
8983:             "classvariable reaches the initialise-declared cell: {:?}",
8984:             r.diagnostics
8985:         );
8986:     }
8987: 
8988:     /// Near variants of the same shape, each **run** on tclsh
8989:     /// 9.0.4: a plain `set` instead of `const`, a value-bearing
8990:     /// `variable`, the British `initialise` spelling, the `oo::define`
8991:     /// form, two names in one `classvariable` call (both must bind — a
8992:     /// `VarWrite` role on index 0 alone leaves the second unbound), and a
8993:     /// write/read split across two methods.
8994:     ///
8995:     /// The `variable Pitch` before the `const` is load-bearing,
8996:     /// not noise: an `initialize` script runs in a call frame, so a bare
8997:     /// `const Pitch 5e-6` there makes a *frame-local* constant that no
8998:     /// method can reach (tclsh 9.0.4: `can't read "Pitch": no such
8999:     /// variable`). Only the `variable` declaration aims the write at the
9000:     /// class-shared cell — which is why that shape is absent from this
9001:     /// clean-list.
9002:     #[test]
9003:     fn classvariable_variants_stay_clean() {
9004:         for (label, src) in [
9005:             (
9006:                 "set instead of const",
9007:                 "oo::class create Foo {\n\
9008:                  initialize { variable Pitch; set Pitch 5e-6 }\n\
9009:                  method m {} { classvariable Pitch; return $Pitch }\n\
9010:                  }",
9011:             ),
9012:             (
9013:                 "value-bearing variable",
9014:                 "oo::class create Foo {\n\
9015:                  initialize { variable Pitch 5e-6 }\n\
9016:                  method m {} { classvariable Pitch; return $Pitch }\n\
9017:                  }",
9018:             ),
9019:             (
9020:                 "initialise spelling",
9021:                 "oo::class create Foo {\n\
9022:                  initialise { variable Pitch; const Pitch 5e-6 }\n\
9023:                  method m {} { classvariable Pitch; return $Pitch }\n\
9024:                  }",
9025:             ),
9026:             (
9027:                 "oo::define form",
9028:                 "oo::class create Foo {}\n\
9029:                  oo::define Foo {\n\
9030:                  initialize { variable Pitch; const Pitch 5e-6 }\n\
9031:                  method m {} { classvariable Pitch; return $Pitch }\n\
9032:                  }",
9033:             ),
9034:             (
9035:                 "two names in one call",
9036:                 "oo::class create Foo {\n\
9037:                  initialize { variable a 1; variable b 2 }\n\
9038:                  method m {} { classvariable a b; return [list $a $b] }\n\
9039:                  }",
9040:             ),
9041:             (
9042:                 "written in one method, read in another",
9043:                 "oo::class create Foo {\n\
9044:                  method w {} { classvariable Count; set Count 1 }\n\
9045:                  method r {} { classvariable Count; return $Count }\n\
9046:                  }",
9047:             ),
9048:             (
9049:                 // The `classvariable(n)` manual page's own example.
9050:                 "manual-page Counted example",
9051:                 "oo::class create Counted {\n\
9052:                  initialise { variable count 0 }\n\
9053:                  variable number\n\
9054:                  constructor {} { classvariable count; set number [incr count] }\n\
9055:                  method report {} { classvariable count; puts \"$number of $count\" }\n\
9056:                  }",
9057:             ),
9058:         ] {
9059:             let mut a = Analyser::new();
9060:             let r = a.analyse(src, "tcl9.0");
9061:             assert!(
9062:                 !r.diagnostics
9063:                     .iter()
9064:                     .any(|d| matches!(d.code.as_str(), "W210" | "W211")),
9065:                 "{label}: {:?}",
9066:                 r.diagnostics
9067:             );
9068:         }
9069:     }
9070: 
9071:     /// The other half: the classvariable handling must not silence a genuine
9072:     /// unbound read. Without `classvariable`, a method's `$Pitch` is an
9073:     /// *instance* variable that the class-level `initialize` never wrote —
9074:     /// tclsh 9.0.4 raises `can't read "Pitch": no such variable` — so W210
9075:     /// is correct and has to stay.
9076:     #[test]
9077:     fn a_method_read_without_classvariable_still_warns() {
9078:         let src = "oo::class create Foo {\n\
9079:                    initialize { variable Pitch; const Pitch 5e-6 }\n\
9080:                    method m {} { ::return $Pitch }\n\
9081:                    }";
9082:         let mut a = Analyser::new();
9083:         let r = a.analyse(src, "tcl9.0");
9084:         assert!(
9085:             r.diagnostics.iter().any(|d| d.code.as_str() == "W210"),
9086:             "an instance-side read of a class-scoped cell is a real bug: {:?}",
9087:             r.diagnostics
9088:         );
9089:     }
9090: 
9091:     /// The same snippet under 8.6 reports what 8.6 actually lacks —
9092:     /// `initialize` and `const` are both 9.0 members — and never W210.
9093:     /// `classvariable` itself is reachable there only through Tcllib's
9094:     /// `ooutil`, which the document requires.
9095:     #[test]
9096:     fn the_reporter_snippet_under_86_reports_the_missing_commands() {
9097:         let src = "package require ooutil\n\
9098:                    oo::class create Foo {\n\
9099:                    initialize { variable Pitch; const Pitch 5e-6 }\n\
9100:                    method m {} { classvariable Pitch; return $Pitch }\n\
9101:                    }";
9102:         let mut a = Analyser::new();
9103:         let r = a.analyse(src, "tcl8.6");
9104:         let codes: Vec<&str> = r.diagnostics.iter().map(|d| d.code.as_str()).collect();
9105:         assert!(
9106:             !codes.contains(&"W210"),
9107:             "8.6 must not add a read-before-set: {:?}",
9108:             r.diagnostics
9109:         );
9110:         assert!(
9111:             r.diagnostics
9112:                 .iter()
9113:                 .any(|d| d.code.as_str() == "W002" && d.message.contains("'const'")),
9114:             "8.6 has no `const` (TIP 677 is 9.0): {:?}",
9115:             r.diagnostics
9116:         );
9117:     }
9118: 
9119:     /// `classvariable` binds only literal, unqualified names: a
9120:     /// substitution names no cell the analyser can see, so it stays the
9121:     /// W212 it already was rather than silently declaring `$dyn`.
9122:     #[test]
9123:     fn a_dynamic_classvariable_name_is_not_a_declaration() {
9124:         let src = "oo::class create Foo { method m {} { classvariable $dyn; return $Pitch } }";
9125:         let mut a = Analyser::new();
9126:         let r = a.analyse(src, "tcl9.0");
9127:         assert!(
9128:             r.diagnostics.iter().any(|d| d.code.as_str() == "W212"),
9129:             "a substituted name is still reported: {:?}",
9130:             r.diagnostics
9131:         );
9132:     }
9133: 
9134:     #[test]
9135:     fn oo_property_accessor_bodies_are_walked() {
9136:         // `-get`/`-set` accessor bodies are walked with the instance variable
9137:         // `val` and the implicit `value` visible — no false W210 / W307.
9138:         // `property` is a 9.0 member, so the vector runs under a 9.0 dialect.
9139:         let src = "oo::configurable create Bar {\n\
9140:                    variable val\n\
9141:                    property color -get { return $val } -set { set val $value }\n\
9142:                    }";
9143:         let mut a = Analyser::new();
9144:         let r = a.analyse(src, "tcl9.0");
9145:         assert!(r.all_classes.contains_key("::Bar"));
9146:         assert!(
9147:             !r.diagnostics
9148:                 .iter()
9149:                 .any(|d| matches!(d.code.as_str(), "W210" | "W307")),
9150:             "property accessor bodies should be walked cleanly: {:?}",
9151:             r.diagnostics
9152:         );
9153:     }
9154: 
9155:     #[test]
9156:     fn oo_class_create_with_namespace_is_not_exported() {
9157:         // C Tcl 9.0.4 and 8.6 both reject this ordinary command dispatch:
9158:         // createWithNamespace exists internally but is not exported on
9159:         // oo::class. A rejected call cannot introduce a class.
9160:         let mut a = Analyser::new();
9161:         let r = a.analyse("oo::class createWithNamespace MyCls ::ns { }", "tcl8.6");
9162:         assert!(
9163:             !r.all_classes.keys().any(|k| k.contains("MyCls")),
9164:             "an unexported manufacturer must not record a class: {:?}",
9165:             r.all_classes.keys().collect::<Vec<_>>()
9166:         );
9167:     }
9168: }
/* ORIGINAL_SOURCE_RANGE 9170..9236 */
9170: #[cfg(test)]
9171: mod lifecycle_formal_tests {
9172:     use crate::analyser::Analyser;
9173:     use tcl_core_types::DiagCode;
9174: 
9175:     #[test]
9176:     fn original_tcloo_formals_follow_counted_lifecycle_body_applicability() {
9177:         // naming.tcloo.empty-lifecycle-definition
9178:         // docs/design/analysis/name-resolution-proofs/tcloo-empty-lifecycle-definition.md
9179:         // Original ASCII source-script contract; no entered frame is asserted.
9180:         for dialect in ["tcl8.6", "tcl9.0", "tcl9.1"] {
9181:             for (source, expected) in [
9182:                 ("oo::class create C {constructor {{a b c}} {}}", 0),
9183:                 ("oo::class create C {constructor {{a b c}} { }}", 1),
9184:                 ("oo::class create C {constructor {{a b c}} {# body}}", 1),
9185:                 ("oo::class create C {constructor {\"a} {}}", 0),
9186:                 ("oo::class create C {constructor {\"a} { }}", 1),
9187:                 (
9188:                     "oo::class create C {}; oo::define C constructor {{a b c}} {}",
9189:                     0,
9190:                 ),
9191:                 (
9192:                     "oo::class create C {}; oo::define C constructor {{a b c}} { }",
9193:                     1,
9194:                 ),
9195:                 (
9196:                     "oo::class create P {constructor {a b} { }}; oo::class create C {superclass P; constructor {{a b c}} {}}",
9197:                     0,
9198:                 ),
9199:                 ("oo::class create C {method m {{a b c}} {}}", 1),
9200:             ] {
9201:                 let analysis = Analyser::new().analyse(source, dialect);
9202:                 let diagnostics = analysis
9203:                     .diagnostics
9204:                     .iter()
9205:                     .filter(|diagnostic| diagnostic.code == DiagCode::E006)
9206:                     .collect::<Vec<_>>();
9207:                 assert_eq!(
9208:                     diagnostics.len(),
9209:                     expected,
9210:                     "{dialect}: {source}: {diagnostics:?}"
9211:                 );
9212:             }
9213:         }
9214:     }
9215: 
9216:     #[test]
9217:     fn original_tcloo_formal_applicability_preserves_dynamic_body_uncertainty() {
9218:         // naming.tcloo.empty-lifecycle-definition
9219:         // docs/design/analysis/name-resolution-proofs/tcloo-empty-lifecycle-definition.md
9220:         // Dynamic source bodies are not evaluated or promoted to empty values.
9221:         for source in [
9222:             "oo::class create C {constructor {{a b c}} $body}",
9223:             "oo::class create C {constructor {{a b c}} [body]}",
9224:             "oo::class create C {}; oo::define C constructor {{a b c}} $body",
9225:         ] {
9226:             let analysis = Analyser::new().analyse(source, "tcl9.0");
9227:             assert!(
9228:                 !analysis
9229:                     .diagnostics
9230:                     .iter()
9231:                     .any(|diagnostic| diagnostic.code == DiagCode::E006),
9232:                 "{source}"
9233:             );
9234:         }
9235:     }
9236: }
