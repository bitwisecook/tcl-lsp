/* ORIGINAL_SOURCE_RANGE 1..4262 */
1: // tcl-lsp — a language server and toolchain for Tcl
2: // Copyright (C) 2026 James Deucker (bitwisecook) <https://github.com/bitwisecook>
3: //
4: // This program is free software: you can redistribute it and/or modify
5: // it under the terms of the GNU Affero General Public License as published by
6: // the Free Software Foundation, either version 3 of the License, or
7: // (at your option) any later version.
8: //
9: // This program is distributed in the hope that it will be useful,
10: // but WITHOUT ANY WARRANTY; without even the implied warranty of
11: // MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
12: // GNU Affero General Public License for more details.
13: //
14: // You should have received a copy of the GNU Affero General Public License
15: // along with this program.  If not, see <https://www.gnu.org/licenses/>.
16: //
17: // SPDX-License-Identifier: AGPL-3.0-or-later
18: 
19: //! Taint-analysis tests.
20: //!
21: //! These drive the taint pass and assert over the returned `TaintWarning` list
22: //! (`.code` / `.variable` / `.sink_command` / `.message`), plus a block of
23: //! pure-lattice tests over `TaintLattice` / `TaintColour` / `taint_join`. The
24: //! driver is [`tcl_compiler::taint::find_taint_warnings_for_cu`] (the
25: //! whole-unit taint pass that `run_all_checks` also drives), over the `pub`
26: //! [`tcl_compiler::taint::TaintLattice`] / [`TaintColour`] types.
27: //!
28: //! ## Driving a snippet
29: //!
30: //! [`warns`] builds a [`CompilationUnit`] for the snippet and runs
31: //! `find_taint_warnings_for_cu`, the `TaintWarning`-producing surface (sink
32: //! detection T100–T106, setter constraints IRULE3101, iRules URI-split
33: //! IRULE3103, destructive-file W313). [`codes`] returns the sorted diagnostic
34: //! codes; [`of_code`] filters warnings by diagnostic code. The lattice join is
35: //! [`TaintLattice::join`].
36: //!
37: //! ## Dialect handling
38: //!
39: //! The dialect is threaded explicitly into `find_taint_warnings_for_cu`, so
40: //! each test passes the dialect it needs:
41: //!   * Dialect-agnostic tests run under [`D`] (`tcl8.6`).
42: //!     iRules *sources* (`HTTP::uri`, `IP::client_addr`, …) still taint there —
43: //!     they are registered in every dialect (registry test
44: //!     `http_uri_is_a_source_in_every_dialect`) — so the T100/T101/T102/T103
45: //!     source+sink tests work under plain Tcl.
46: //!   * iRules *sinks* (IRULE3001–3004, `log` → IRULE3003) only fire under
47: //!     [`IR`] (`f5-irules`); those tests pass `IR`.
48: //!   * The `…_not_in_tcl86` / `…_tcl_dialect_clean` cases pass `D`
49: //!     explicitly to prove the iRules sink does NOT fire under plain Tcl.
50: //!
51: //! ## Policy-vs-semantic proof split (C-Tcl)
52: //!
53: //! Taint is a *security/policy* analysis, not a runtime value. Most assertions
54: //! are policy-level — "this source is tainted", "this sink is flagged", "this
55: //! colour suppresses that code" — and have no tclsh ground truth to pin: tclsh
56: //! does not implement taint, so there is nothing to compare against. Those are
57: //! pure policy checks.
58: //!
59: //! Where a test's *premise* is a Tcl-semantic fact — a command's actual
60: //! behaviour, a string transform, whether the first list element becomes the
61: //! command word — it is verified against `scripts/dev/tclsh_check.sh` (tclsh8.6
62: //! + tclsh9.0) and cited in a `// tclsh:` comment.
63: //!
64: //! The headline facts proven while authoring this file:
65: //!
66: //!   * `eval [list $raw]`        → tclsh runs `$raw` as the command word
67: //!     (`proc marker args {puts EXECUTED}; eval [list marker]` prints
68: //!     `EXECUTED`) — so `LIST_CANONICAL` does NOT suppress T100 (D5-T100).
69: //!   * `eval [list puts $raw]`   → tclsh prints `marker` (`puts` is the command
70: //!     word, `$raw` is its argument) — so a literal `[list <known-cmd> …]` head
71: //!     DOES suppress T100.
72: //!   * `string length $x`        → tclsh returns an int (`11` for an 11-char
73: //!     value) — confirming it is a taint sanitiser (fixed numeric return).
74: //!   * `regexp -- …`             → tclsh treats `--` as the option terminator
75: //!     (`regexp -- -foo bar` → `0`, not a `bad switch` error).
76: //!
77: //! F5/iRules-specific taint sources and sinks (`HTTP::*`, `IP::*`, `SSL::*`,
78: //! `HTTP::respond`, …) are NOT core-tclsh commands, so snippets that mention
79: //! them carry a `// f5-dialect` note — there is no tclsh proof to cite for the
80: //! command itself, only the policy verdict.
81: 
82: use tcl_compiler::compilation_unit::CompilationUnit;
83: use tcl_compiler::taint::{TaintColour, TaintLattice, TaintWarning, find_taint_warnings_for_cu};
84: use tcl_registry::model::ingress::static_context_for;
85: 
86: /// Default dialect for snippets that are not dialect-sensitive. iRules sources
87: /// still taint under this dialect (registered globally), so the generic
88: /// T100–T106 tests use it.
89: const D: &str = "tcl8.6";
90: /// iRules dialect — gates the IRULE3001–3004 / IRULE3101 / IRULE3103 sinks and
91: /// `log` → IRULE3003.
92: const IR: &str = "f5-irules";
93: 
94: /// Every `TaintWarning` the whole-unit taint pass surfaces for `src` under
95: /// `dialect`.
96: fn warns(src: &str, dialect: &str) -> Vec<TaintWarning> {
97:     let registry = static_context_for(dialect).commands();
98:     let cu = CompilationUnit::build_for(src, registry, false);
99:     let dialect_opt = (!dialect.is_empty())
100:         .then(|| tcl_registry::model::ingress::resolve_environment(dialect).analyser_profile());
101:     find_taint_warnings_for_cu(&cu, registry, dialect_opt)
102: }
103: 
104: /// Sorted list of diagnostic codes from the taint pass.
105: fn codes(src: &str, dialect: &str) -> Vec<String> {
106:     let mut out: Vec<String> = warns(src, dialect)
107:         .iter()
108:         .map(|w| w.code.to_string())
109:         .collect();
110:     out.sort();
111:     out
112: }
113: 
114: /// Taint warnings of one diagnostic `code`.
115: fn of_code(src: &str, dialect: &str, code: &str) -> Vec<TaintWarning> {
116:     warns(src, dialect)
117:         .into_iter()
118:         .filter(|w| w.code.to_string() == code)
119:         .collect()
120: }
121: 
122: // Lattice join semantics (`taint_join` → `TaintLattice::join`).
123: //
124: // Pure lattice algebra: taint is a may-have (union), mitigating colours are a
125: // must-have (intersection). No tclsh analogue — this is the analyser's internal
126: // data structure.
127: mod taint_join {
128:     use super::*;
129: 
130:     fn lat(colour: TaintColour) -> TaintLattice {
131:         TaintLattice { colours: colour }
132:     }
133:     const UNTAINTED: TaintColour = TaintColour::empty();
134:     const TAINTED: TaintColour = TaintColour::TAINTED;
135: 
136:     fn join(a: TaintColour, b: TaintColour) -> TaintLattice {
137:         lat(a).join(lat(b))
138:     }
139: 
140:     #[test]
141:     fn untainted_untainted() {
142:         assert!(!join(UNTAINTED, UNTAINTED).is_tainted());
143:     }
144: 
145:     #[test]
146:     fn tainted_untainted() {
147:         assert!(join(TAINTED, UNTAINTED).is_tainted());
148:     }
149: 
150:     #[test]
151:     fn untainted_tainted() {
152:         assert!(join(UNTAINTED, TAINTED).is_tainted());
153:     }
154: 
155:     #[test]
156:     fn tainted_tainted() {
157:         assert!(join(TAINTED, TAINTED).is_tainted());
158:     }
159: 
160:     #[test]
161:     fn path_prefixed_join_preserves_colour() {
162:         let p = TAINTED | TaintColour::PATH_PREFIXED;
163:         let r = join(p, p);
164:         assert!(r.is_tainted());
165:         assert!(r.colours.contains(TaintColour::PATH_PREFIXED));
166:     }
167: 
168:     #[test]
169:     fn path_prefixed_join_with_generic_loses_colour() {
170:         let r = join(TAINTED | TaintColour::PATH_PREFIXED, TAINTED);
171:         assert!(r.is_tainted());
172:         assert!(!r.colours.contains(TaintColour::PATH_PREFIXED));
173:     }
174: 
175:     #[test]
176:     fn path_prefixed_join_with_untainted() {
177:         // Joining PATH with untainted returns PATH unchanged (untainted is the
178:         // join *identity*), so PATH_PREFIXED survives.
179:         let r = join(TAINTED | TaintColour::PATH_PREFIXED, UNTAINTED);
180:         assert!(r.is_tainted());
181:         // FIXED: clean is now the join identity (not a mitigation annihilator),
182:         // so PATH_PREFIXED survives.
183:         assert!(r.colours.contains(TaintColour::PATH_PREFIXED));
184:     }
185: 
186:     #[test]
187:     fn ip_join_preserves_colour() {
188:         let ip = TAINTED | TaintColour::IP_ADDRESS;
189:         let r = join(ip, ip);
190:         assert!(r.is_tainted());
191:         assert!(r.colours.contains(TaintColour::IP_ADDRESS));
192:     }
193: 
194:     #[test]
195:     fn ip_join_with_generic_loses_colour() {
196:         let r = join(TAINTED | TaintColour::IP_ADDRESS, TAINTED);
197:         assert!(r.is_tainted());
198:         assert!(!r.colours.contains(TaintColour::IP_ADDRESS));
199:     }
200: 
201:     #[test]
202:     fn port_join_preserves_colour() {
203:         let port = TAINTED | TaintColour::PORT;
204:         let r = join(port, port);
205:         assert!(r.is_tainted());
206:         assert!(r.colours.contains(TaintColour::PORT));
207:     }
208: 
209:     #[test]
210:     fn fqdn_join_with_untainted() {
211:         let r = join(TAINTED | TaintColour::FQDN, UNTAINTED);
212:         assert!(r.is_tainted());
213:         // FIXED: clean is the join identity, so FQDN survives.
214:         assert!(r.colours.contains(TaintColour::FQDN));
215:     }
216: 
217:     #[test]
218:     fn different_colours_lose_both() {
219:         // IP_ADDRESS & PORT = 0 (different flags) → join keeps neither.
220:         let r = join(
221:             TAINTED | TaintColour::IP_ADDRESS,
222:             TAINTED | TaintColour::PORT,
223:         );
224:         assert!(r.is_tainted());
225:         assert!(!r.colours.contains(TaintColour::IP_ADDRESS));
226:         assert!(!r.colours.contains(TaintColour::PORT));
227:     }
228: }
229: 
230: // Join semantics for the extended colour set.
231: mod lattice_join_new_colours {
232:     use super::*;
233: 
234:     fn lat(colour: TaintColour) -> TaintLattice {
235:         TaintLattice { colours: colour }
236:     }
237:     const TAINTED: TaintColour = TaintColour::TAINTED;
238:     fn join(a: TaintColour, b: TaintColour) -> TaintLattice {
239:         lat(a).join(lat(b))
240:     }
241:     fn t(c: TaintColour) -> TaintColour {
242:         TAINTED | c
243:     }
244: 
245:     #[test]
246:     fn crlf_free_self() {
247:         let r = join(t(TaintColour::CRLF_FREE), t(TaintColour::CRLF_FREE));
248:         assert!(r.is_tainted() && r.colours.contains(TaintColour::CRLF_FREE));
249:     }
250: 
251:     #[test]
252:     fn crlf_free_with_generic_loses() {
253:         let r = join(t(TaintColour::CRLF_FREE), TAINTED);
254:         assert!(r.is_tainted() && !r.colours.contains(TaintColour::CRLF_FREE));
255:     }
256: 
257:     #[test]
258:     fn crlf_free_with_untainted() {
259:         let r = join(t(TaintColour::CRLF_FREE), TaintColour::empty());
260:         assert!(r.is_tainted());
261:         // FIXED: clean is the join identity, so CRLF_FREE survives.
262:         assert!(r.colours.contains(TaintColour::CRLF_FREE));
263:     }
264: 
265:     #[test]
266:     fn shell_atom_self() {
267:         let r = join(t(TaintColour::SHELL_ATOM), t(TaintColour::SHELL_ATOM));
268:         assert!(r.is_tainted() && r.colours.contains(TaintColour::SHELL_ATOM));
269:     }
270: 
271:     #[test]
272:     fn shell_atom_with_generic_loses() {
273:         let r = join(t(TaintColour::SHELL_ATOM), TAINTED);
274:         assert!(!r.colours.contains(TaintColour::SHELL_ATOM));
275:     }
276: 
277:     #[test]
278:     fn list_canonical_self() {
279:         let r = join(
280:             t(TaintColour::LIST_CANONICAL),
281:             t(TaintColour::LIST_CANONICAL),
282:         );
283:         assert!(r.colours.contains(TaintColour::LIST_CANONICAL));
284:     }
285: 
286:     #[test]
287:     fn regex_literal_with_html_escaped_loses_both() {
288:         let r = join(t(TaintColour::REGEX_LITERAL), t(TaintColour::HTML_ESCAPED));
289:         assert!(!r.colours.contains(TaintColour::REGEX_LITERAL));
290:         assert!(!r.colours.contains(TaintColour::HTML_ESCAPED));
291:     }
292: 
293:     #[test]
294:     fn path_normalised_self() {
295:         let r = join(
296:             t(TaintColour::PATH_NORMALISED),
297:             t(TaintColour::PATH_NORMALISED),
298:         );
299:         assert!(r.colours.contains(TaintColour::PATH_NORMALISED));
300:     }
301: 
302:     #[test]
303:     fn header_token_safe_self() {
304:         let r = join(
305:             t(TaintColour::HEADER_TOKEN_SAFE),
306:             t(TaintColour::HEADER_TOKEN_SAFE),
307:         );
308:         assert!(r.colours.contains(TaintColour::HEADER_TOKEN_SAFE));
309:     }
310: 
311:     #[test]
312:     fn html_escaped_self() {
313:         let r = join(t(TaintColour::HTML_ESCAPED), t(TaintColour::HTML_ESCAPED));
314:         assert!(r.colours.contains(TaintColour::HTML_ESCAPED));
315:     }
316: 
317:     #[test]
318:     fn url_encoded_self() {
319:         let r = join(t(TaintColour::URL_ENCODED), t(TaintColour::URL_ENCODED));
320:         assert!(r.colours.contains(TaintColour::URL_ENCODED));
321:     }
322: 
323:     #[test]
324:     fn url_encoded_with_generic_loses() {
325:         let r = join(t(TaintColour::URL_ENCODED), TAINTED);
326:         assert!(!r.colours.contains(TaintColour::URL_ENCODED));
327:     }
328: 
329:     #[test]
330:     fn multi_colour_join_preserves_shared() {
331:         let both = t(TaintColour::CRLF_FREE | TaintColour::URL_ENCODED);
332:         let r = join(both, both);
333:         assert!(r.colours.contains(TaintColour::CRLF_FREE));
334:         assert!(r.colours.contains(TaintColour::URL_ENCODED));
335:     }
336: 
337:     #[test]
338:     fn multi_colour_partial_overlap() {
339:         let a = t(TaintColour::CRLF_FREE | TaintColour::URL_ENCODED);
340:         let r = join(a, t(TaintColour::CRLF_FREE));
341:         assert!(r.colours.contains(TaintColour::CRLF_FREE));
342:         assert!(!r.colours.contains(TaintColour::URL_ENCODED));
343:     }
344: }
345: 
346: // Clean code produces no taint warnings.
347: //
348: // tclsh: each snippet is ordinary, side-effect-free Tcl with no attacker
349: // source, so flagging it would be a false positive.
350: mod no_false_positives {
351:     use super::*;
352: 
353:     #[test]
354:     fn literal_set() {
355:         assert_eq!(codes("set x 42", D), Vec::<String>::new());
356:     }
357: 
358:     #[test]
359:     fn incr() {
360:         assert_eq!(codes("set x 0\nincr x", D), Vec::<String>::new());
361:     }
362: 
363:     #[test]
364:     fn safe_eval() {
365:         // `eval $x` where x is a literal string — no taint reaches the sink.
366:         assert_eq!(
367:             codes("set x \"puts hello\"\neval $x", D),
368:             Vec::<String>::new()
369:         );
370:     }
371: 
372:     #[test]
373:     fn safe_expr() {
374:         assert_eq!(codes("set x 42\nexpr {$x + 1}", D), Vec::<String>::new());
375:     }
376: 
377:     #[test]
378:     fn list_operations() {
379:         assert_eq!(
380:             codes("set x [list a b c]\nset n [llength $x]", D),
381:             Vec::<String>::new()
382:         );
383:     }
384: }
385: 
386: // Tcl-core I/O commands taint their results (T100 at the
387: // eval sink). `read`/`gets`/`exec`/`socket`/`chan` are real tclsh commands.
388: mod tcl_taint_sources {
389:     use super::*;
390: 
391:     #[test]
392:     fn read_taints() {
393:         // tclsh: `read $fd` returns channel contents — attacker-influenced I/O.
394:         let ws = of_code("set data [read $fd]\neval $data", D, "T100");
395:         assert!(!ws.is_empty());
396:         assert_eq!(ws[0].variable, "data");
397:     }
398: 
399:     #[test]
400:     fn gets_taints() {
401:         // tclsh: `gets $fd` (no varName) returns the line read from the channel.
402:         let ws = of_code("set line [gets $fd]\neval $line", D, "T100");
403:         assert!(!ws.is_empty());
404:         assert_eq!(ws[0].variable, "line");
405:     }
406: 
407:     #[test]
408:     fn a_call_the_module_cannot_see_leaves_what_its_words_read_tainted() {
409:         // `foo` may rewrite `line`, but nothing it does cleans the value the
410:         // read before it held.
411:         let ws = of_code("set line [gets stdin]\nfoo $line\neval $line", D, "T100");
412:         assert!(
413:             ws.iter().any(|warning| warning.variable == "line"),
414:             "the read after the call is as tainted as the read before it: {ws:?}"
415:         );
416:     }
417: 
418:     #[test]
419:     fn constant_variable_command_head_reaches_sink_at_the_use_site() {
420:         let ws = of_code(
421:             "set command eval\nset line [gets stdin]\n$command $line",
422:             D,
423:             "T100",
424:         );
425:         assert!(
426:             ws.iter().any(|warning| warning.variable == "line"),
427:             "a phase-correct constant command head must retain eval's sink semantics: {ws:?}"
428:         );
429:     }
430: 
431:     #[test]
432:     fn eval_braced_nested_command_substitution_reaches_inner_sink() {
433:         for source in [
434:             "set x [gets stdin]\neval {[eval $x]}",
435:             r"set x [gets stdin]
436: [e\166al $x]",
437:             "set x [gets stdin]\n[{eval} $x]",
438:             "set x [gets stdin]\n[\"eval\" $x]",
439:         ] {
440:             let ws = of_code(source, D, "T100");
441:             assert!(
442:                 ws.iter().any(|warning| warning.variable == "x"),
443:                 "a variable in a nested statically-headed eval reaches its sink: {source:?}: {ws:?}"
444:             );
445:         }
446:     }
447: 
448:     #[test]
449:     fn braced_literal_command_name_does_not_execute_its_bracket_text() {
450:         assert!(
451:             of_code("set x [gets stdin]\n{[eval $x]}", D, "T100").is_empty(),
452:             "a braced command name is literal; its bracket text is never evaluated"
453:         );
454:     }
455: 
456:     #[test]
457:     fn quoted_whole_command_substitution_reaches_inner_sink() {
458:         let ws = of_code("set x [gets stdin]\n\"[eval $x]\"", D, "T100");
459:         assert!(
460:             ws.iter().any(|warning| warning.variable == "x"),
461:             "quotes do not suppress a whole command substitution in command position: {ws:?}"
462:         );
463:     }
464: 
465:     #[test]
466:     fn escaped_static_command_head_obeys_release_grammar() {
467:         let source = r"set x [gets stdin]
468: [e\x76al $x]";
469:         assert!(
470:             of_code(source, "tcl8.4", "T100").is_empty(),
471:             "Tcl 8.4 consumes more than two hex digits, so this command is not eval"
472:         );
473:         assert!(
474:             of_code(source, "tcl8.6", "T100")
475:                 .iter()
476:                 .any(|warning| warning.variable == "x"),
477:             "Tcl 8.6 consumes two hex digits, so this command is eval"
478:         );
479:     }
480: 
481:     #[test]
482:     fn static_expanded_command_head_preserves_argv_semantics() {
483:         let positive = of_code("set x [gets stdin]\n{*}{{eval} safe} $x", "tcl9.0", "T100");
484:         assert!(
485:             positive.iter().any(|warning| warning.variable == "x"),
486:             "the first expanded list element is the command and the rest prefix its argv: {positive:?}"
487:         );
488:         assert!(
489:             of_code("set x [gets stdin]\n{*}{{puts} safe} $x", "tcl9.0", "T100",).is_empty(),
490:             "an expanded non-sink command head must stay clean"
491:         );
492:         assert!(
493:             !of_code("set x [gets stdin]\n{*}{} eval $x", "tcl9.0", "T100",).is_empty(),
494:             "an empty leading expansion removes itself and exposes the next command word"
495:         );
496:     }
497: 
498:     #[test]
499:     fn reaching_list_value_expands_into_command_and_argv() {
500:         for source in [
501:             "set prefix [list eval safe]\nset x [gets stdin]\n{*}$prefix $x",
502:             "set prefix {}\nset x [gets stdin]\n{*}$prefix eval $x",
503:             "if {$flag} {set prefix [list eval safe]} else {set prefix [list puts safe]}\nset x [gets stdin]\n{*}$prefix $x",
504:         ] {
505:             assert!(
506:                 !of_code(source, "tcl9.0", "T100").is_empty(),
507:                 "a reaching list constant must retain expanded dispatch semantics: {source}"
508:             );
509:         }
510:         assert!(
511:             of_code(
512:                 "set prefix [list puts safe]\nset x [gets stdin]\n{*}$prefix $x",
513:                 "tcl9.0",
514:                 "T100",
515:             )
516:             .is_empty(),
517:             "a reaching expanded non-sink must stay clean"
518:         );
519:     }
520: 
521:     #[test]
522:     fn unknown_expansion_arms_do_not_erase_a_reaching_sink() {
523:         for source in [
524:             r"if {$flag} {set command eval} else {set command \x7b}
525: set x [gets stdin]
526: {*}$command $x",
527:             "if {$flag} {set command eval} else {set command {}}\nset next puts\nset x [gets stdin]\n{*}$command $next $x",
528:         ] {
529:             assert!(
530:                 !of_code(source, "tcl9.0", "T100").is_empty(),
531:                 "a malformed or unresolved expansion arm must not erase another arm's eval sink: {source}"
532:             );
533:         }
534:     }
535: 
536:     #[test]
537:     fn nested_command_head_sink_does_not_consume_outer_arguments() {
538:         for (source, code) in [
539:             ("set x [gets stdin]\n[eval {string cat puts}] $x", "T100"),
540:             ("set x [gets stdin]\n[puts {$x}] $x", "T101"),
541:         ] {
542:             assert!(
543:                 of_code(source, D, code).is_empty(),
544:                 "a nested sink must not consume a braced literal or a later outer argument: {source:?}"
545:             );
546:         }
547:     }
548: 
549:     #[test]
550:     fn whole_command_substitution_classifies_each_executed_inner_sink() {
551:         for (source, code) in [
552:             ("set x [gets stdin]\n[puts $x]", "T101"),
553:             ("set x [gets stdin]\n[puts safe; eval $x]", "T100"),
554:             ("set x [gets stdin]\nprefix[eval $x]", "T100"),
555:             ("set x [gets stdin]\n\"[puts safe][eval $x]\"", "T100"),
556:         ] {
557:             let ws = of_code(source, D, code);
558:             assert!(
559:                 ws.iter().any(|warning| warning.variable == "x"),
560:                 "every inner command receives only its own substituted arguments: {source:?}: {ws:?}"
561:             );
562:         }
563:     }
564: 
565:     #[test]
566:     fn nested_script_sink_distinguishes_deferred_from_literal_arguments() {
567:         let ws = of_code("set x [gets stdin]\n[eval {$x}]", D, "T100");
568:         assert!(
569:             ws.iter().any(|warning| warning.variable == "x"),
570:             "eval reparses its braced argument as Tcl source: {ws:?}"
571:         );
572: 
573:         assert!(
574:             of_code("set x [gets stdin]\n[exec {$x}]", D, "T100").is_empty(),
575:             "exec receives a literal dollar spelling; it does not evaluate Tcl source"
576:         );
577: 
578:         let ws = of_code("set x [gets stdin]\n[interp eval child {$x}]", D, "T105");
579:         assert!(
580:             ws.iter().any(|warning| warning.variable == "x"),
581:             "interp eval reparses only its registry-declared body tail: {ws:?}"
582:         );
583:         assert!(
584:             of_code(
585:                 "set x [gets stdin]\n[interp eval {$x} {set y safe}] $x",
586:                 D,
587:                 "T105",
588:             )
589:             .is_empty(),
590:             "a braced interpreter path and an outer argument are not child-interpreter code"
591:         );
592: 
593:         let ws = of_code("set x [gets stdin]\n[set y $x; eval {$y}]", D, "T100");
594:         assert!(
595:             ws.iter().any(|warning| warning.variable == "y"),
596:             "inner commands must propagate taint in Tcl evaluation order: {ws:?}"
597:         );
598:         assert!(
599:             of_code(
600:                 "set x [gets stdin]\n[eval {set x safe; puts $x}]",
601:                 D,
602:                 "T100",
603:             )
604:             .is_empty(),
605:             "a script-local clean overwrite must cut off the enclosing tainted version"
606:         );
607:         assert!(
608:             of_code(
609:                 "proc eval args {}\nset x [gets stdin]\n[eval $x]",
610:                 D,
611:                 "T100",
612:             )
613:             .is_empty(),
614:             "a nested call inherits the enclosing user-proc rebinding"
615:         );
616:         let ws = of_code(
617:             "interp alias {} myEval {} eval\nset x [gets stdin]\n[myEval $x]",
618:             D,
619:             "T100",
620:         );
621:         assert!(
622:             ws.iter().any(|warning| warning.variable == "x"),
623:             "a nested call inherits the enclosing static alias: {ws:?}"
624:         );
625:         for source in [
626:             "set command eval\nset x [gets stdin]\n[$command $x]",
627:             "set x [gets stdin]\nset script {$x}\n[eval $script]",
628:         ] {
629:             assert!(
630:                 !of_code(source, D, "T100").is_empty(),
631:                 "nested analysis inherits phase-correct outer constants: {source}"
632:             );
633:         }
634:     }
635: 
636:     #[test]
637:     fn variable_command_head_uses_reaching_not_lexically_earlier_value() {
638:         assert!(
639:             of_code(
640:                 "set command eval\nset command string\nset line [gets stdin]\n$command length $line",
641:                 D,
642:                 "T100",
643:             )
644:             .is_empty(),
645:             "a superseded eval spelling must not classify the later string call as a sink"
646:         );
647:     }
648: 
649:     #[test]
650:     fn variable_command_head_warns_when_any_reaching_literal_is_a_sink() {
651:         let ws = of_code(
652:             "if {$flag} {set command eval} else {set command puts}\n\
653:              set line [gets stdin]\n$command $line",
654:             D,
655:             "T100",
656:         );
657:         assert!(
658:             ws.iter().any(|warning| warning.variable == "line"),
659:             "a may-dispatch to eval is security-relevant even when another arm is safe: {ws:?}"
660:         );
661:     }
662: 
663:     #[test]
664:     fn equivalent_variable_command_head_spellings_emit_one_warning() {
665:         let ws = of_code(
666:             "if {$flag} {set command eval} else {set command ::eval}\n\
667:              set line [gets stdin]\n$command $line",
668:             D,
669:             "T100",
670:         );
671:         assert_eq!(
672:             ws.len(),
673:             1,
674:             "equivalent qualified sink spellings must not duplicate one use-site diagnostic: {ws:?}"
675:         );
676:         assert_eq!(ws[0].sink_command, "eval");
677:     }
678: 
679:     #[test]
680:     fn namespace_shadowed_variable_command_head_is_not_a_builtin_sink() {
681:         assert!(
682:             of_code(
683:                 "proc ::ns::eval args {}\n\
684:                  proc ::ns::run {} {set command eval; set line [gets stdin]; $command $line}\n\
685:                  ::ns::run",
686:                 D,
687:                 "T100",
688:             )
689:             .is_empty(),
690:             "a namespace-local proc named eval must not inherit the builtin's sink semantics"
691:         );
692:     }
693: 
694:     #[test]
695:     fn namespace_shadowed_catch_cannot_hijack_nested_analysis_scaffolding() {
696:         let ws = of_code(
697:             "proc ::ns::catch args {}\n\
698:              proc ::ns::run {} {set x [gets stdin]; [catch {}; eval $x]}\n\
699:              ::ns::run",
700:             D,
701:             "T100",
702:         );
703:         assert!(
704:             ws.iter().any(|warning| warning.variable == "x"),
705:             "a user proc named catch must not suppress the real nested eval sink: {ws:?}"
706:         );
707:     }
708: 
709:     #[test]
710:     fn exec_taints() {
711:         // tclsh: `exec ls` returns subprocess stdout.
712:         let ws = of_code("set output [exec ls]\neval $output", D, "T100");
713:         assert!(!ws.is_empty());
714:         assert_eq!(ws[0].variable, "output");
715:     }
716: 
717:     #[test]
718:     fn socket_taints() {
719:         let ws = of_code("set s [socket localhost 80]\neval $s", D, "T100");
720:         assert!(!ws.is_empty());
721:     }
722: 
723:     #[test]
724:     fn chan_read_taints() {
725:         let ws = of_code("set data [chan read $fd]\neval $data", D, "T100");
726:         assert!(!ws.is_empty());
727:     }
728: 
729:     #[test]
730:     fn chan_gets_taints() {
731:         let ws = of_code("set data [chan gets $fd]\neval $data", D, "T100");
732:         assert!(!ws.is_empty());
733:     }
734: 
735:     #[test]
736:     fn chan_configure_does_not_taint() {
737:         // tclsh: `chan configure $fd` returns channel options, not I/O content —
738:         // not a taint source.
739:         assert_eq!(
740:             codes("set x [chan configure $fd]\neval $x", D),
741:             Vec::<String>::new()
742:         );
743:     }
744: }
745: 
746: // Registry object-instance sources.  Widget paths and object variables are
747: // commands at runtime, so the constructor's `object_class` / `creates_instance_at`
748: // metadata must carry the `TAINT_SOURCE` trait on `get` through that dispatch.
749: // These cases deliberately name no widget or getter in compiler code.
750: mod object_instance_taint_sources {
751:     use super::*;
752: 
753:     #[test]
754:     fn literal_widget_path_get_taints() {
755:         let source = "ttk::entry .user\nset value [.user get]\neval $value";
756:         let warnings = of_code(source, D, "T100");
757:         assert!(
758:             warnings.iter().any(|warning| warning.variable == "value"),
759:             "registry instance source should reach eval: {warnings:?}"
760:         );
761:     }
762: 
763:     #[test]
764:     fn instance_taint_sources_follow_the_resolved_widget_lifecycle() {
765:         // ttk::treeview `current` is a zero-argument taint source added in
766:         // Tk 9.1. The generic instance-invocation resolver must not replay
767:         // that source fact for a tcl9.0 profile merely because the class is
768:         // otherwise known there.
769:         let source = "ttk::treeview .tree\nset value [.tree current]\neval $value";
770:         for (dialect, expects_taint) in [("tcl9.0", false), ("tcl9.1", true)] {
771:             assert_eq!(
772:                 !of_code(source, dialect, "T100").is_empty(),
773:                 expects_taint,
774:                 "ttk::treeview current taint source under {dialect}"
775:             );
776:         }
777:     }
778: 
779:     #[test]
780:     fn widget_handle_variable_get_taints() {
781:         let source = "set widget [ttk::entry .user]\nset value [$widget get]\neval $value";
782:         let warnings = of_code(source, D, "T100");
783:         assert!(
784:             warnings.iter().any(|warning| warning.variable == "value"),
785:             "typed object handle source should reach eval: {warnings:?}"
786:         );
787:     }
788: 
789:     #[test]
790:     fn instance_source_flows_through_proc_summary() {
791:         let source = "proc user_value {} {\n    ttk::entry .user\n    return [.user get]\n}\nset value [user_value]\neval $value";
792:         let warnings = of_code(source, D, "T100");
793:         assert!(
794:             warnings.iter().any(|warning| warning.variable == "value"),
795:             "instance source in a proc return should reach eval: {warnings:?}"
796:         );
797:     }
798: 
799:     #[test]
800:     fn top_level_widget_is_a_source_inside_callback_procedure() {
801:         let source = "ttk::entry .user\nproc submit {} {\n    set value [.user get]\n    eval $value\n}\nsubmit";
802:         let warnings = of_code(source, D, "T100");
803:         assert!(
804:             warnings.iter().any(|warning| warning.variable == "value"),
805:             "top-level widget commands remain visible in callback procedures: {warnings:?}"
806:         );
807:     }
808: 
809:     #[test]
810:     fn text_dump_and_file_chooser_results_are_input_sources() {
811:         for source in [
812:             "text .editor\nset value [.editor dump 1.0 end]\neval $value",
813:             "set value [tk_getOpenFile]\neval $value",
814:             "set value [tk_chooseDirectory]\neval $value",
815:         ] {
816:             let warnings = of_code(source, D, "T100");
817:             assert!(
818:                 warnings.iter().any(|warning| warning.variable == "value"),
819:                 "user-selected or user-authored Tk value must be tainted: {warnings:?}"
820:             );
821:         }
822:     }
823: 
824:     #[test]
825:     fn ambiguous_instance_class_abstains() {
826:         let source = "ttk::entry .widget\nlistbox .widget\nset value [.widget get]\neval $value";
827:         assert!(
828:             of_code(source, D, "T100").is_empty(),
829:             "a receiver with incompatible registry classes must not be guessed"
830:         );
831:     }
832: 
833:     #[test]
834:     fn linked_entry_variable_is_user_input_and_show_is_not_a_sanitiser() {
835:         let source = "entry .password -show * -textvariable password\neval $password";
836:         let warnings = of_code(source, D, "T100");
837:         assert!(
838:             warnings
839:                 .iter()
840:                 .any(|warning| warning.variable == "password"),
841:             "password masking must not sanitize linked user input: {warnings:?}"
842:         );
843:     }
844: 
845:     #[test]
846:     fn deferred_validation_callback_preserves_link_and_instance_taint() {
847:         let source = "entry .password -textvariable password -validatecommand {return 1}\nset typed [.password get]\neval $password\neval $typed";
848:         let warnings = of_code(source, D, "T100");
849:         assert!(
850:             warnings
851:                 .iter()
852:                 .any(|warning| warning.variable == "password"),
853:             "the deferred callback must not hide the linked-variable definition: {warnings:?}"
854:         );
855:         assert!(
856:             warnings.iter().any(|warning| warning.variable == "typed"),
857:             "the deferred callback must not hide the constructor's instance class: {warnings:?}"
858:         );
859:     }
860: 
861:     #[test]
862:     fn validation_percent_values_taint_inline_and_list_prefix_callbacks() {
863:         for source in [
864:             "entry .password -validatecommand {set proposed %P; eval $proposed}",
865:             "entry .password -validatecommand [list eval %P]",
866:             "entry .password -validatecommand \"[list eval %P]\"",
867:             "entry .password -validatecommand \"eval %P\"",
868:             r"entry .password -validatecommand eval\ %P",
869:             "bind .password <Key> {set typed %A; eval $typed}",
870:         ] {
871:             assert!(
872:                 !of_code(source, D, "T100").is_empty(),
873:                 "registry-declared callback input must reach its sink: {source}"
874:             );
875:         }
876:     }
877: 
878:     #[test]
879:     fn validation_percent_value_in_command_position_is_dynamic_dispatch() {
880:         for source in [
881:             "entry .password -validatecommand {%P}",
882:             "entry .password -validatecommand {{*}%P}",
883:             "entry .password -validatecommand [list %P]",
884:         ] {
885:             assert!(
886:                 !of_code(source, D, "T100").is_empty(),
887:                 "a callback-provided command head is tainted dynamic dispatch: {source}"
888:             );
889:         }
890:     }
891: 
892:     #[test]
893:     fn callback_replay_scaffold_ignores_user_catch_and_proc_commands() {
894:         for source in [
895:             "proc catch args {}\nentry .password -validatecommand {eval %P}",
896:             "proc proc args {}\nentry .password -validatecommand {eval %P}",
897:         ] {
898:             assert!(
899:                 !of_code(source, D, "T100").is_empty(),
900:                 "user commands named like replay plumbing must not suppress the callback sink: {source}"
901:             );
902:         }
903:     }
904: 
905:     #[test]
906:     fn resolved_widget_instance_callbacks_replay_registry_declared_inputs() {
907:         for source in [
908:             "canvas .canvas\n.canvas bind all <Key> {eval %A}",
909:             "entry .entry\n.entry configure -validatecommand {eval %P}",
910:         ] {
911:             assert!(
912:                 !of_code(source, D, "T100").is_empty(),
913:                 "a statically typed instance callback must use its registry descriptor: {source}"
914:             );
915:         }
916:     }
917: 
918:     #[test]
919:     fn dynamic_or_unknown_widget_receivers_do_not_invent_callback_sources() {
920:         for source in [
921:             ".unknown bind all <Key> {eval %A}",
922:             "canvas .canvas\nset receiver .canvas\n$receiver bind all <Key> {eval %A}",
923:         ] {
924:             assert!(
925:                 of_code(source, D, "T100").is_empty(),
926:                 "a non-singleton/literal receiver must not be guessed as a callback host: {source}"
927:             );
928:         }
929:     }
930: 
931:     #[test]
932:     fn validation_callback_percent_source_survives_braced_quoted_and_embedded_words() {
933:         for source in [
934:             // Tk substitutes `%P` before evaluating this script. Its braced
935:             // word is a user value, not a trusted literal for the later eval.
936:             "entry .password -validatecommand {eval {%P}}",
937:             "entry .password -validatecommand {eval \"prefix-%P\"}",
938:             "entry .password -validatecommand {set proposed {%P}; eval $proposed}",
939:         ] {
940:             assert!(
941:                 !of_code(source, D, "T100").is_empty(),
942:                 "Tk callback replacement must remain tainted across word quoting: {source}"
943:             );
944:         }
945:     }
946: 
947:     #[test]
948:     fn validation_callback_replay_preserves_later_word_substitutions() {
949:         for source in [
950:             "entry .password -validatecommand {set x %P; eval \"puts $x\"}",
951:             "entry .password -validatecommand {set x %P; eval prefix-$x}",
952:             "entry .password -validatecommand {set x %P; eval \"puts [set y $x]\"}",
953:             "entry .password -validatecommand {set command eval; $command %P}",
954:             r"entry .password -validatecommand {set x %P; e\166al $x}",
955:             r"entry .password -validatecommand {set x %P; eval \[eval\ \$x\]}",
956:             r"entry .password -validatecommand {set x %P; [e\166al $x]}",
957:             "entry .password -validatecommand {set x %P; [puts safe; eval $x]}",
958:             "entry .password -validatecommand {set command eval; set x %P; [$command $x]}",
959:             "entry .password -validatecommand {set x %P; [set y $x; eval {$y}]}",
960:             r"entry .password -validatecommand [list e\166al %P]",
961:             r"entry .password -validatecommand {set x %P; eval {eval\
962:  $x}}",
963:         ] {
964:             assert!(
965:                 !of_code(source, D, "T100").is_empty(),
966:                 "replay must preserve quoted, compound, and command substitutions: {source}"
967:             );
968:         }
969:     }
970: 
971:     #[test]
972:     fn validation_callback_replay_preserves_argument_expansion() {
973:         for source in [
974:             "entry .password -validatecommand {set x %P; {*}{{eval} safe} $x}",
975:             "entry .password -validatecommand {set x %P; set prefix [list eval safe]; {*}$prefix $x}",
976:             "entry .password -validatecommand [list {*}{{eval} safe} %P]",
977:         ] {
978:             assert!(
979:                 !of_code(source, D, "T100").is_empty(),
980:                 "callback replay must retain the list-expanded eval prefix: {source}"
981:             );
982:         }
983:         assert!(
984:             of_code(
985:                 "entry .password -validatecommand {set x %P; {*}{{puts} safe} $x}",
986:                 D,
987:                 "T100",
988:             )
989:             .is_empty(),
990:             "a list-expanded non-sink callback command must remain clean"
991:         );
992:     }
993: 
994:     #[test]
995:     fn validation_list_prefix_builder_uses_source_position_command_identity() {
996:         for source in [
997:             "interp alias {} make {} list\nentry .password -validatecommand [make eval %P]",
998:             "interp alias {} make {} list\nentry .password -validatecommand \"[make eval %P]\"",
999:             "rename list make\nentry .password -validatecommand [make eval %P]",
1000:         ] {
1001:             assert!(
1002:                 !of_code(source, D, "T100").is_empty(),
1003:                 "an alias or rename of list constructs the same callback prefix: {source}"
1004:             );
1005:         }
1006:         for source in [
1007:             "proc list args {return {puts safe}}\nentry .password -validatecommand [list eval %P]",
1008:             "interp alias {} make {} list puts\nentry .password -validatecommand [make eval %P]",
1009:         ] {
1010:             assert!(
1011:                 of_code(source, D, "T100").is_empty(),
1012:                 "a rebound builder or alias with prepended argv must not inherit bare list semantics: {source}"
1013:             );
1014:         }
1015:     }
1016: 
1017:     #[test]
1018:     fn validation_callback_replay_decodes_static_non_head_backslashes() {
1019:         let source = r"entry .password -validatecommand {set x %P; eval puts\ \$x}";
1020:         assert!(
1021:             !of_code(source, D, "T101").is_empty(),
1022:             "a backslash-built script argument must retain its decoded output-sink semantics"
1023:         );
1024:     }
1025: 
1026:     #[test]
1027:     fn validation_list_prefix_preserves_a_quoted_command_name() {
1028:         assert!(
1029:             of_code(
1030:                 "entry .password -validatecommand [list {eval foo} %P]",
1031:                 D,
1032:                 "T100",
1033:             )
1034:             .is_empty(),
1035:             "a list element naming one command with a space must not be replayed as builtin eval"
1036:         );
1037:     }
1038: 
1039:     #[test]
1040:     fn validation_callback_replay_input_name_cannot_collide_with_program_variables() {
1041:         let source =
1042:             "entry .password -validatecommand {set __tcl_lsp_callback_input trusted; eval {%P}}";
1043:         assert!(
1044:             !of_code(source, D, "T100").is_empty(),
1045:             "the replay source name must avoid a callback/program variable collision"
1046:         );
1047:     }
1048: 
1049:     #[test]
1050:     fn validation_callback_seed_ignores_shadowed_scaffolding_commands() {
1051:         let source = "proc gets {args} { return trusted }\n\
1052:                       proc set {args} { return trusted }\n\
1053:                       entry .password -validatecommand {eval {%P}}";
1054:         assert!(
1055:             !of_code(source, D, "T100").is_empty(),
1056:             "Tk callback input is an external source even when gets/set are shadowed"
1057:         );
1058:     }
1059: 
1060:     #[test]
1061:     fn validation_callback_direct_input_diagnostic_hides_synthetic_state() {
1062:         let source = "entry .password -validatecommand {eval %P}";
1063:         let warnings = of_code(source, D, "T100");
1064:         let warning = warnings
1065:             .iter()
1066:             .find(|warning| warning.variable == "Tk callback input %P")
1067:             .expect("direct Tk input warning: {warnings:?}");
1068:         assert!(
1069:             warning.message.contains("Tk callback input %P"),
1070:             "the user-facing message must identify the Tk source: {warning:?}"
1071:         );
1072:         assert!(
1073:             !warning.message.contains("__tcl_lsp_callback"),
1074:             "synthetic replay state must not leak to the user: {warning:?}"
1075:         );
1076:         assert_eq!(
1077:             warning.span.start(),
1078:             u32::try_from(source.find("{eval %P}").expect("callback span"))
1079:                 .expect("test source fits in u32"),
1080:             "the direct callback sink maps back to its registration"
1081:         );
1082:         assert!(
1083:             warning.replacement.is_none() && warning.fixes.is_empty(),
1084:             "synthetic replay diagnostics cannot carry synthetic-source edits: {warning:?}"
1085:         );
1086:     }
1087: 
1088:     #[test]
1089:     fn callback_replays_isolate_abnormal_completion_and_handler_locals() {
1090:         for first in ["return %P", "error %P"] {
1091:             let source = format!(
1092:                 "entry .first -validatecommand {{{first}}}\n\
1093:                  entry .second -validatecommand {{eval %P}}"
1094:             );
1095:             let second_start = u32::try_from(source.rfind("{eval %P}").expect("second callback"))
1096:                 .expect("test source fits in u32");
1097:             assert!(
1098:                 of_code(&source, D, "T100")
1099:                     .iter()
1100:                     .any(|warning| warning.span.start() == second_start),
1101:                 "an abnormal first callback cannot make its sibling unreachable: {source}"
1102:             );
1103:         }
1104: 
1105:         let clean_then_tainted = "entry .first -validatecommand {set x safe; return %P}\n\
1106:                                   entry .second -validatecommand {set x %P; eval $x}";
1107:         assert!(
1108:             !of_code(clean_then_tainted, D, "T100").is_empty(),
1109:             "a prior callback's clean local cannot kill the later handler's source"
1110:         );
1111: 
1112:         let tainted_then_clean = "entry .first -validatecommand {set x %P}\n\
1113:                                   entry .second -validatecommand {set unused %P; eval $x}";
1114:         assert!(
1115:             of_code(tainted_then_clean, D, "T100").is_empty(),
1116:             "a prior callback's local cannot invent a warning in a sibling handler"
1117:         );
1118:     }
1119: 
1120:     #[test]
1121:     fn validation_list_prefix_taints_a_named_proc_parameter() {
1122:         let source = "proc validate {proposed} { eval $proposed }\nentry .password -validatecommand [list validate %P]";
1123:         let warnings = of_code(source, D, "T100");
1124:         assert!(
1125:             warnings
1126:                 .iter()
1127:                 .any(|warning| warning.variable == "proposed"),
1128:             "a list-built callback prefix must seed its procedure parameter: {warnings:?}"
1129:         );
1130:         let sink_start = u32::try_from(source.find("$proposed").expect("procedure sink variable"))
1131:             .expect("test source fits in u32");
1132:         assert!(
1133:             warnings
1134:                 .iter()
1135:                 .any(|warning| warning.variable == "proposed" && warning.span.start() == sink_start),
1136:             "a proc-prefix warning belongs on the real sink, not the registration: {warnings:?}"
1137:         );
1138:     }
1139: 
1140:     #[test]
1141:     fn callback_framework_metadata_and_escaped_percent_stay_clean() {
1142:         for source in [
1143:             "entry .password -validatecommand {eval %W}",
1144:             "entry .password -validatecommand {eval %%P}",
1145:             "bind .password <Key> {eval %W}",
1146:             "bind .password <Key> {eval %K}",
1147:             "entry .password -validatecommand [format {eval %P}]",
1148:         ] {
1149:             assert!(
1150:                 of_code(source, D, "T100").is_empty(),
1151:                 "metadata, escaped markers, and dynamic callback builders stay untainted: {source}"
1152:             );
1153:         }
1154:     }
1155: 
1156:     #[test]
1157:     fn user_controlled_non_text_widget_variable_is_tainted() {
1158:         let source = "checkbutton .choice -variable choice\neval $choice";
1159:         let warnings = of_code(source, D, "T100");
1160:         assert!(
1161:             warnings.iter().any(|warning| warning.variable == "choice"),
1162:             "user-controlled linked widget state must be tainted: {warnings:?}"
1163:         );
1164:     }
1165: 
1166:     #[test]
1167:     fn display_only_textvariable_and_widget_handle_stay_clean() {
1168:         assert!(
1169:             of_code(
1170:                 "set safe fixed\nlabel .display -textvariable safe\neval $safe",
1171:                 D,
1172:                 "T100"
1173:             )
1174:             .is_empty(),
1175:             "a display-only textvariable is not a user-input source"
1176:         );
1177:         assert!(
1178:             of_code("set widget [entry .user]\neval $widget", D, "T100").is_empty(),
1179:             "a widget constructor's trusted handle is not user input"
1180:         );
1181:     }
1182: 
1183:     #[test]
1184:     fn mixed_widget_links_taint_only_the_user_editable_variable() {
1185:         let source = "set caption fixed\ncheckbutton .choice -textvariable caption -variable choice\neval $caption\neval $choice";
1186:         let warnings = of_code(source, D, "T100");
1187:         assert!(
1188:             warnings.iter().any(|warning| warning.variable == "choice"),
1189:             "the selection variable is user controlled: {warnings:?}"
1190:         );
1191:         assert!(
1192:             warnings.iter().all(|warning| warning.variable != "caption"),
1193:             "the display-only textvariable must stay clean: {warnings:?}"
1194:         );
1195:     }
1196: 
1197:     #[test]
1198:     fn instance_configure_adds_a_phase_correct_external_input_definition() {
1199:         let source = "entry .user\neval $value\n.user configure -textvariable value\neval $value";
1200:         let warnings = of_code(source, D, "T100");
1201:         assert_eq!(
1202:             warnings
1203:                 .iter()
1204:                 .filter(|warning| warning.variable == "value")
1205:                 .count(),
1206:             1,
1207:             "only the use after the registry-typed configure link is tainted: {warnings:?}"
1208:         );
1209: 
1210:         let source = "set widget [ttk::entry .user]\n$widget configure -textvariable value\nset copy $value\neval $copy";
1211:         let warnings = of_code(source, D, "T100");
1212:         assert!(
1213:             warnings.iter().any(|warning| warning.variable == "copy"),
1214:             "a typed variable receiver's configured input link must propagate: {warnings:?}"
1215:         );
1216:     }
1217: 
1218:     #[test]
1219:     fn display_only_instance_configure_does_not_taint_its_variable() {
1220:         let source = "label .caption\n.caption configure -textvariable caption\neval $caption";
1221:         assert!(
1222:             of_code(source, D, "T100").is_empty(),
1223:             "a display-only class option must not become an input source"
1224:         );
1225:     }
1226: 
1227:     #[test]
1228:     fn argument_sensitive_widget_getters_taint_only_user_state_forms() {
1229:         for source in [
1230:             "scale .s\nset user [.s get]\nset derived [.s get 10 20]\neval $user\neval $derived",
1231:             "ttk::toggleswitch .s\nset user [.s get]\nset derived [.s get min]\neval $user\neval $derived",
1232:             "ttk::toggleswitch .s\nset user [.s switchstate]\nset derived [.s switchstate true]\neval $user\neval $derived",
1233:             "ttk::toggleswitch .s\nset user [.s xcoord]\nset derived [.s xcoord 0.5]\neval $user\neval $derived",
1234:         ] {
1235:             let warnings = of_code(source, D, "T100");
1236:             assert!(
1237:                 warnings.iter().any(|warning| warning.variable == "user"),
1238:                 "the zero-argument getter reads user state: {warnings:?}"
1239:             );
1240:             assert!(
1241:                 !warnings.iter().any(|warning| warning.variable == "derived"),
1242:                 "the explicit coordinate/selector getter is derived, not input: {warnings:?}"
1243:             );
1244:         }
1245:     }
1246: 
1247:     #[test]
1248:     fn overloaded_treeview_and_notebook_getters_only_taint_zero_arg_queries() {
1249:         for (dialect, query, setter) in [
1250:             (
1251:                 D,
1252:                 "ttk::combobox .combo\nset user [.combo current]\neval $user",
1253:                 "ttk::combobox .combo\nset value [.combo current 0]\neval $value",
1254:             ),
1255:             (
1256:                 D,
1257:                 "ttk::treeview .tree\nset user [.tree selection]\neval $user",
1258:                 "ttk::treeview .tree\nset value [.tree selection set item]\neval $value",
1259:             ),
1260:             (
1261:                 "tcl9.0",
1262:                 "ttk::treeview .tree\nset user [.tree cellselection]\neval $user",
1263:                 "ttk::treeview .tree\nset value [.tree cellselection set item]\neval $value",
1264:             ),
1265:             (
1266:                 "tcl9.1",
1267:                 "ttk::treeview .tree\nset user [.tree current]\neval $user",
1268:                 "ttk::treeview .tree\nset value [.tree current ignored]\neval $value",
1269:             ),
1270:             (
1271:                 D,
1272:                 "ttk::treeview .tree\nset user [.tree focus]\neval $user",
1273:                 "ttk::treeview .tree\nset value [.tree focus item]\neval $value",
1274:             ),
1275:             (
1276:                 "tcl9.1",
1277:                 "ttk::treeview .tree\nset user [.tree cellfocus]\neval $user",
1278:                 "ttk::treeview .tree\nset value [.tree cellfocus 0,0]\neval $value",
1279:             ),
1280:             (
1281:                 D,
1282:                 "ttk::notebook .book\nset user [.book select]\neval $user",
1283:                 "ttk::notebook .book\nset value [.book select .tab]\neval $value",
1284:             ),
1285:         ] {
1286:             assert!(
1287:                 of_code(query, dialect, "T100")
1288:                     .iter()
1289:                     .any(|warning| warning.variable == "user"),
1290:                 "zero-argument Tk UI query must be a source under {dialect}: {query}"
1291:             );
1292:             assert!(
1293:                 of_code(setter, dialect, "T100").is_empty(),
1294:                 "setter/argument overload must not be a source under {dialect}: {setter}"
1295:             );
1296:         }
1297:     }
1298: 
1299:     #[test]
1300:     fn pointer_position_queries_are_user_input_sources() {
1301:         for query in [
1302:             "winfo pointerx .",
1303:             "winfo pointery .",
1304:             "winfo pointerxy .",
1305:             "winfo containing 10 20",
1306:             "winfo containing -displayof . 10 20",
1307:         ] {
1308:             let source = format!("set user [{query}]\neval $user");
1309:             let warnings = of_code(&source, D, "T100");
1310:             assert!(
1311:                 warnings.iter().any(|warning| warning.variable == "user"),
1312:                 "pointer-dependent query must be a source: {query}; {warnings:?}"
1313:             );
1314:         }
1315:     }
1316: 
1317:     #[test]
1318:     fn later_constructor_does_not_retroactively_type_an_earlier_receiver() {
1319:         assert!(
1320:             of_code(
1321:                 "set value [.future get]\nttk::entry .future\neval $value",
1322:                 D,
1323:                 "T100"
1324:             )
1325:             .is_empty(),
1326:             "receiver typing must respect source order"
1327:         );
1328:     }
1329: 
1330:     #[test]
1331:     fn destroy_kills_local_instance_class_and_recreate_restores_it() {
1332:         assert!(
1333:             of_code(
1334:                 "entry .user\ndestroy .user\nset value [.user get]\neval $value",
1335:                 D,
1336:                 "T100"
1337:             )
1338:             .is_empty(),
1339:             "a registry teardown must remove the destroyed widget from local receiver facts"
1340:         );
1341:         assert!(
1342:             of_code(
1343:                 "entry .user\ndestroy .user\nentry .user\nset value [.user get]\neval $value",
1344:                 D,
1345:                 "T100"
1346:             )
1347:             .iter()
1348:             .any(|warning| warning.variable == "value"),
1349:             "a later constructor must recreate the receiver class after teardown"
1350:         );
1351: 
1352:         assert!(
1353:             of_code(
1354:                 "frame .panel\nentry .panel.user\ndestroy .\nset value [.panel.user get]\neval $value",
1355:                 D,
1356:                 "T100"
1357:             )
1358:             .is_empty(),
1359:             "destroying the Tk root must kill every descendant receiver fact"
1360:         );
1361:     }
1362: 
1363:     #[test]
1364:     fn rename_moves_local_and_global_instance_class_facts() {
1365:         let local = "entry .user\nrename .user .renamed\nset value [.renamed get]\neval $value";
1366:         assert!(
1367:             of_code(local, D, "T100")
1368:                 .iter()
1369:                 .any(|warning| warning.variable == "value"),
1370:             "registry command-table rename must move a local widget class"
1371:         );
1372: 
1373:         let global = "entry .user\nrename .user .renamed\nproc read_value {} {\n    set value [.renamed get]\n    eval $value\n}\nread_value";
1374:         assert!(
1375:             of_code(global, D, "T100")
1376:                 .iter()
1377:                 .any(|warning| warning.variable == "value"),
1378:             "registry command-table rename must move global callback class facts"
1379:         );
1380:     }
1381: 
1382:     #[test]
1383:     fn global_destroy_kills_callback_instance_class_facts() {
1384:         let source = "entry .user\ndestroy .user\nproc read_value {} {\n    set value [.user get]\n    eval $value\n}\nread_value";
1385:         assert!(
1386:             of_code(source, D, "T100").is_empty(),
1387:             "a top-level registry teardown must not leave a stale global callback receiver"
1388:         );
1389:     }
1390: 
1391:     #[test]
1392:     fn instance_method_abbreviations_resolve_only_when_unique() {
1393:         let warnings = of_code(
1394:             "entry .user\nset value [.user g]\neval $value\n.user co -textvariable linked\neval $linked",
1395:             D,
1396:             "T100",
1397:         );
1398:         assert!(
1399:             warnings.iter().any(|warning| warning.variable == "value"),
1400:             "the unique `get` prefix must retain source semantics: {warnings:?}"
1401:         );
1402:         assert!(
1403:             warnings.iter().any(|warning| warning.variable == "linked"),
1404:             "the unique `configure` prefix must retain option-write semantics: {warnings:?}"
1405:         );
1406: 
1407:         assert!(
1408:             of_code(
1409:                 "entry .user\n.user c -textvariable linked\neval $linked",
1410:                 D,
1411:                 "T100"
1412:             )
1413:             .is_empty(),
1414:             "`c` is ambiguous between cget/configure and must abstain"
1415:         );
1416:     }
1417: 
1418:     #[test]
1419:     fn literal_global_receiver_configure_taints_across_procedures() {
1420:         let source = "entry .user\nproc link_input {} {\n    .user configure -textvariable ::value\n}\nlink_input\neval $::value";
1421:         let warnings = of_code(source, D, "T100");
1422:         assert!(
1423:             warnings.iter().any(|warning| warning.variable == "::value"),
1424:             "a callee's proven widget link must define and taint the caller's global: {warnings:?}"
1425:         );
1426: 
1427:         let nested = "entry .user\nproc inner {} {\n    .user configure -textvariable ::value\n}\nproc outer {} { inner }\nouter\neval $::value";
1428:         let warnings = of_code(nested, D, "T100");
1429:         assert!(
1430:             warnings.iter().any(|warning| warning.variable == "::value"),
1431:             "instance-option global writes must close transitively over calls: {warnings:?}"
1432:         );
1433:     }
1434: 
1435:     #[test]
1436:     fn tk_unqualified_link_targets_global_not_proc_local_state() {
1437:         let false_positive = "package require Tk\nproc p {} {\n    set value safe\n    entry .e -textvariable value\n    eval $value\n}\np";
1438:         let warnings = of_code(false_positive, D, "T100");
1439:         assert!(
1440:             warnings.is_empty(),
1441:             "Tk's unqualified link is ::value; it must not taint proc-local value: {warnings:?}"
1442:         );
1443: 
1444:         let false_negative = "package require Tk\nproc p {} {\n    entry .e -textvariable value\n}\np\neval $::value";
1445:         let warnings = of_code(false_negative, D, "T100");
1446:         assert!(
1447:             warnings.iter().any(|warning| warning.variable == "::value"),
1448:             "Tk's unqualified link must taint the documented global ::value: {warnings:?}"
1449:         );
1450:     }
1451: 
1452:     #[test]
1453:     fn constructor_and_configure_global_links_close_over_proc_calls() {
1454:         for source in [
1455:             "proc inner {} { entry .user -textvariable value }\nproc outer {} { inner }\nouter\neval $::value",
1456:             "entry .user\nproc inner {} { .user configure -textvariable value }\nproc outer {} { inner }\nouter\neval $::value",
1457:             "proc inner {} { entry .user -textvariable ::value }\ninner\neval $::value",
1458:         ] {
1459:             let warnings = of_code(source, D, "T100");
1460:             assert!(
1461:                 warnings.iter().any(|warning| warning.variable == "::value"),
1462:                 "registry-global Tk link must propagate through callers: {warnings:?}"
1463:             );
1464:         }
1465:     }
1466: 
1467:     #[test]
1468:     fn dynamic_parameter_receiver_configure_abstains() {
1469:         let source = "entry .user\nproc link_input {widget} {\n    $widget configure -textvariable ::value\n}\nlink_input .user\neval $::value";
1470:         assert!(
1471:             of_code(source, D, "T100").is_empty(),
1472:             "a parameter receiver has no uniform class proof and must not be guessed"
1473:         );
1474:     }
1475: 
1476:     #[test]
1477:     fn eager_call_and_conditional_constructor_do_not_create_global_receiver_facts() {
1478:         let called_too_early = "proc link_input {} {\n    .user configure -textvariable ::value\n}\nlink_input\nentry .user\neval $::value";
1479:         assert!(
1480:             of_code(called_too_early, D, "T100").is_empty(),
1481:             "a constructor after an eager call cannot type that invocation"
1482:         );
1483: 
1484:         let conditional = "if {$flag} { entry .user }\nproc link_input {} {\n    .user configure -textvariable ::value\n}\nlink_input\neval $::value";
1485:         assert!(
1486:             of_code(conditional, D, "T100").is_empty(),
1487:             "a conditional constructor does not prove a receiver exists"
1488:         );
1489: 
1490:         let conditional_rebind = "entry .user\nif {$flag} { label .user }\nproc read_input {} {\n    set value [.user get]\n    eval $value\n}\nread_input";
1491:         assert!(
1492:             of_code(conditional_rebind, D, "T100").is_empty(),
1493:             "a possible later constructor withdraws an earlier receiver proof"
1494:         );
1495:     }
1496: 
1497:     #[test]
1498:     fn receiver_rebinding_and_branch_joins_use_reaching_classes() {
1499:         assert!(
1500:             of_code(
1501:                 "set widget [entry .user]\nset widget [label .display]\nset value [$widget get]\neval $value",
1502:                 D,
1503:                 "T100"
1504:             )
1505:             .is_empty(),
1506:             "a later non-source receiver binding must kill the earlier entry class"
1507:         );
1508: 
1509:         let rebound = "set widget [label .display]\nset widget [entry .user]\nset value [$widget get]\neval $value";
1510:         assert!(
1511:             of_code(rebound, D, "T100")
1512:                 .iter()
1513:                 .any(|warning| warning.variable == "value"),
1514:             "the currently reaching entry binding must be used"
1515:         );
1516: 
1517:         let same_class_join = "if {$flag} {\n    set widget [entry .one]\n} else {\n    set widget [entry .two]\n}\nset value [$widget get]\neval $value";
1518:         assert!(
1519:             of_code(same_class_join, D, "T100")
1520:                 .iter()
1521:                 .any(|warning| warning.variable == "value"),
1522:             "a join whose paths agree on class remains typed"
1523:         );
1524: 
1525:         let mixed_join = "if {$flag} {\n    set widget [entry .one]\n} else {\n    set widget [label .two]\n}\nset value [$widget get]\neval $value";
1526:         assert!(
1527:             of_code(mixed_join, D, "T100").is_empty(),
1528:             "a join with multiple possible classes must abstain"
1529:         );
1530: 
1531:         let global_rebound = "entry .shared\nlabel .shared\nproc use_value {} {\n    set value [.shared get]\n    eval $value\n}\nuse_value";
1532:         assert!(
1533:             of_code(global_rebound, D, "T100").is_empty(),
1534:             "the last unconditional constructor determines a global literal receiver"
1535:         );
1536: 
1537:         let global_rebound_to_source = "label .shared\nentry .shared\nproc use_value {} {\n    set value [.shared get]\n    eval $value\n}\nuse_value";
1538:         assert!(
1539:             of_code(global_rebound_to_source, D, "T100")
1540:                 .iter()
1541:                 .any(|warning| warning.variable == "value"),
1542:             "a global literal receiver rebound to an entry remains a source"
1543:         );
1544:     }
1545: }
1546: 
1547: // iRules I/O getters taint their results.
1548: // f5-dialect: HTTP::*, TCP::*, IP::* are not core-tclsh commands.
1549: mod irules_taint_sources {
1550:     use super::*;
1551: 
1552:     #[test]
1553:     fn http_payload_taints() {
1554:         // f5-dialect: HTTP::payload returns the request body.
1555:         let ws = of_code("set body [HTTP::payload]\neval $body", D, "T100");
1556:         assert!(!ws.is_empty());
1557:         assert_eq!(ws[0].variable, "body");
1558:     }
1559: 
1560:     #[test]
1561:     fn http_header_taints() {
1562:         // f5-dialect.
1563:         let ws = of_code("set hdr [HTTP::header \"Host\"]\neval $hdr", D, "T100");
1564:         assert!(!ws.is_empty());
1565:     }
1566: 
1567:     #[test]
1568:     fn http_uri_taints() {
1569:         // f5-dialect.
1570:         let ws = of_code("set uri [HTTP::uri]\neval $uri", D, "T100");
1571:         assert!(!ws.is_empty());
1572:     }
1573: 
1574:     #[test]
1575:     fn tcp_payload_taints() {
1576:         // f5-dialect.
1577:         let ws = of_code("set data [TCP::payload]\neval $data", D, "T100");
1578:         assert!(!ws.is_empty());
1579:     }
1580: 
1581:     #[test]
1582:     fn ip_client_addr_taints_with_colour() {
1583:         // f5-dialect: IP addresses are tainted but carry the IP_ADDRESS colour.
1584:         let ws = of_code("set addr [IP::client_addr]\neval $addr", D, "T100");
1585:         assert!(!ws.is_empty());
1586:         assert_eq!(ws[0].variable, "addr");
1587:     }
1588: }
1589: 
1590: // Taint flows through assignments and interpolation.
1591: mod taint_propagation {
1592:     use super::*;
1593: 
1594:     #[test]
1595:     fn variable_copy_propagates() {
1596:         let ws = of_code("set x [read $fd]\nset y $x\neval $y", D, "T100");
1597:         assert!(ws.iter().any(|w| w.variable == "y"));
1598:     }
1599: 
1600:     #[test]
1601:     fn string_interpolation_propagates() {
1602:         let ws = of_code(
1603:             "set x [read $fd]\nset y \"prefix${x}suffix\"\neval $y",
1604:             D,
1605:             "T100",
1606:         );
1607:         assert!(ws.iter().any(|w| w.variable == "y"));
1608:     }
1609: 
1610:     #[test]
1611:     fn command_subst_concat_propagates() {
1612:         let ws = of_code("set x [read $fd]/suffix\neval $x", D, "T100");
1613:         assert!(ws.iter().any(|w| w.variable == "x"));
1614:     }
1615: 
1616:     #[test]
1617:     fn sanitiser_blocks_taint() {
1618:         // tclsh: `string length $x` returns an int (`11` for an 11-char value) —
1619:         // a fixed numeric return cannot carry taint, so the result is clean.
1620:         assert_eq!(
1621:             codes("set x [read $fd]\nset n [string length $x]\nexpr $n", D),
1622:             Vec::<String>::new()
1623:         );
1624:     }
1625: 
1626:     #[test]
1627:     fn llength_sanitises() {
1628:         // tclsh: `llength` returns an int (element count) — sanitises taint.
1629:         assert_eq!(
1630:             codes("set x [read $fd]\nset n [llength $x]\nexpr $n", D),
1631:             Vec::<String>::new()
1632:         );
1633:     }
1634: 
1635:     #[test]
1636:     fn taint_through_if_branch() {
1637:         let source =
1638:             "set x [read $fd]\nif {1} {\n    set y $x\n} else {\n    set y \"safe\"\n}\neval $y\n";
1639:         let ws = of_code(source, D, "T100");
1640:         assert!(ws.iter().any(|w| w.variable == "y"));
1641:     }
1642: }
1643: 
1644: // Proc summaries propagate taint across calls.
1645: mod interprocedural_taint {
1646:     use super::*;
1647: 
1648:     #[test]
1649:     fn helper_sanitiser_suppresses_taint() {
1650:         // tclsh: the helper returns `string length` (an int) → clean result.
1651:         let source = "proc safe_len {x} { return [string length $x] }\nset raw [read $fd]\nset n [safe_len $raw]\nexpr $n\n";
1652:         assert_eq!(codes(source, D), Vec::<String>::new());
1653:     }
1654: 
1655:     #[test]
1656:     fn tainted_return_from_helper_reaches_sink() {
1657:         // f5-dialect: helper returns HTTP::payload (tainted) → flows to eval.
1658:         let source = "proc payload {} { return [HTTP::payload] }\nset data [payload]\neval $data\n";
1659:         let ws = of_code(source, D, "T100");
1660:         assert!(!ws.is_empty());
1661:         assert!(ws.iter().any(|w| w.variable == "data"));
1662:     }
1663: 
1664:     #[test]
1665:     fn tainted_argument_into_sinking_helper_warns() {
1666:         let source = "proc do_eval {x} { eval $x }\nset data [read $fd]\ndo_eval $data\n";
1667:         let ws = of_code(source, D, "T100");
1668:         assert!(!ws.is_empty());
1669:         assert!(ws.iter().any(|w| w.sink_command == "eval"));
1670:     }
1671: 
1672:     #[test]
1673:     fn tainted_variadic_args_into_sinking_helper_warns() {
1674:         // `proc log {args} { puts $args }` packs every trailing actual
1675:         // argument into the `args` list parameter — a tainted actual must
1676:         // still be traced (via the interprocedural entry-taint solve's
1677:         // `args`-packing rule) into the sink inside the callee body.
1678:         let source = "proc log {args} { puts $args }\nset data [read $fd]\nlog $data\n";
1679:         let ws = of_code(source, D, "T101");
1680:         assert!(
1681:             !ws.is_empty(),
1682:             "expected T101 for tainted args-packed data, got {ws:?}"
1683:         );
1684:     }
1685: }
1686: 
1687: // Dangerous sinks (T100) — tainted data in eval/expr/exec/uplevel/subst.
1688: //
1689: // tclsh: each of these re-parses/executes its argument, so a tainted value is a
1690: // code-execution vector. (eval/uplevel/subst/exec run the value; unbraced expr
1691: // re-parses it.)
1692: mod dangerous_sinks {
1693:     use super::*;
1694: 
1695:     #[test]
1696:     fn eval_sink() {
1697:         let ws = of_code("set x [read $fd]\neval $x", D, "T100");
1698:         assert!(!ws.is_empty());
1699:         assert_eq!(ws[0].sink_command, "eval");
1700:     }
1701: 
1702:     #[test]
1703:     fn expr_sink() {
1704:         let ws = of_code("set x [read $fd]\nexpr $x", D, "T100");
1705:         assert!(!ws.is_empty());
1706:     }
1707: 
1708:     #[test]
1709:     fn exec_sink() {
1710:         let ws = of_code("set x [read $fd]\nexec $x", D, "T100");
1711:         assert!(!ws.is_empty());
1712:         assert_eq!(ws[0].sink_command, "exec");
1713:     }
1714: 
1715:     #[test]
1716:     fn uplevel_sink() {
1717:         let ws = of_code("set x [read $fd]\nuplevel $x", D, "T100");
1718:         assert!(!ws.is_empty());
1719:     }
1720: 
1721:     #[test]
1722:     fn subst_sink() {
1723:         let ws = of_code("set x [read $fd]\nsubst $x", D, "T100");
1724:         assert!(!ws.is_empty());
1725:     }
1726: 
1727:     #[test]
1728:     fn coroprobe_command_prefix_sink() {
1729:         // `coroprobe coroName command ?arg ...?` evaluates `command` in a
1730:         // suspended coroutine's frame right now — it carries
1731:         // `Traits::EVALUATES_CODE` but (unlike `eval`/`exec`/`uplevel`) not
1732:         // `Traits::TAINT_SINK`, so the registry-driven sink classification
1733:         // must still route it to T100 via the `EVALUATES_CODE` trait rather
1734:         // than silently losing it now that sink classification is
1735:         // registry-driven instead of hardcoded per-trait checks in the
1736:         // compiler.
1737:         let ws = of_code(
1738:             "set cmd [read $fd]\ncoroprobe myCoro $cmd",
1739:             "tcl9.0",
1740:             "T100",
1741:         );
1742:         assert!(!ws.is_empty(), "expected T100 for coroprobe, got none");
1743:     }
1744: 
1745:     #[test]
1746:     fn coroinject_command_prefix_sink() {
1747:         let ws = of_code(
1748:             "set cmd [read $fd]\ncoroinject myCoro $cmd",
1749:             "tcl9.0",
1750:             "T100",
1751:         );
1752:         assert!(!ws.is_empty(), "expected T100 for coroinject, got none");
1753:     }
1754: }
1755: 
1756: // The T100 message names the sink and the variable.
1757: mod warning_messages {
1758:     use super::*;
1759: 
1760:     #[test]
1761:     fn taint_warning_message() {
1762:         let ws = of_code("set x [read $fd]\neval $x", D, "T100");
1763:         assert!(!ws.is_empty());
1764:         assert!(ws[0].message.contains("eval"));
1765:         assert!(ws[0].message.contains("$x") || ws[0].message.contains('x'));
1766:     }
1767: }
1768: 
1769: // Output sinks (T101) — tainted data flowing into `puts`.
1770: //
1771: // tclsh: `puts ?-nonewline? ?channelId? string` — only the trailing content
1772: // word is output content; a tainted channel id is a destination handle and must
1773: // not flag T101.
1774: mod output_sinks {
1775:     use super::*;
1776: 
1777:     #[test]
1778:     fn puts_tainted_data_span_is_tight_around_argument() {
1779:         // The diagnostic must underline just the tainted `$x` argument word,
1780:         // not the whole `puts $x` statement — precise highlighting is what
1781:         // lets the developer see exactly which value is the problem.
1782:         let src = "set x [read $fd]\nputs $x";
1783:         let ws = of_code(src, D, "T101");
1784:         assert_eq!(ws.len(), 1);
1785:         let want_start = u32::try_from(src.find("$x").unwrap()).unwrap();
1786:         let want_end = want_start + 2; // "$x" is 2 bytes.
1787:         assert_eq!(
1788:             (ws[0].span.start(), ws[0].span.end()),
1789:             (want_start, want_end),
1790:             "expected the span to cover only `$x`, not the whole statement"
1791:         );
1792:     }
1793: 
1794:     #[test]
1795:     fn puts_tainted_data() {
1796:         let ws = of_code("set x [read $fd]\nputs $x", D, "T101");
1797:         assert!(!ws.is_empty());
1798:         assert_eq!(ws[0].variable, "x");
1799:         assert!(ws[0].sink_command.contains("puts"));
1800:     }
1801: 
1802:     #[test]
1803:     fn puts_literal_clean() {
1804:         assert!(of_code("puts \"hello world\"", D, "T101").is_empty());
1805:     }
1806: 
1807:     #[test]
1808:     fn puts_sanitised_clean() {
1809:         assert!(
1810:             of_code(
1811:                 "set x [read $fd]\nset n [string length $x]\nputs $n",
1812:                 D,
1813:                 "T101",
1814:             )
1815:             .is_empty()
1816:         );
1817:     }
1818: 
1819:     #[test]
1820:     fn puts_tainted_channel_position_silent() {
1821:         // tclsh: in `puts -nonewline $chan {hello}`, $chan is the destination
1822:         // channel, not injectable content (tcllib imap4.tcl idiom). No T101.
1823:         assert!(
1824:             of_code(
1825:                 "set chan [read $fd]\nputs -nonewline $chan {hello}",
1826:                 D,
1827:                 "T101",
1828:             )
1829:             .is_empty()
1830:         );
1831:     }
1832: 
1833:     #[test]
1834:     fn t100_tainted_inside_cmd_subst_in_expr_silent() {
1835:         // tclsh: in `expr {([string length $data] / 8) * 8}`, $data is consumed
1836:         // by the inner `string length`; expr sees only the int result, not the
1837:         // original $data. No injection risk → T100 must not fire on $data.
1838:         assert!(
1839:             of_code(
1840:                 "set data [read $fd]\nset n [expr {([string length $data] / 8) * 8}]",
1841:                 D,
1842:                 "T100",
1843:             )
1844:             .is_empty()
1845:         );
1846:     }
1847: 
1848:     #[test]
1849:     fn t100_tainted_direct_expr_operand_still_fires() {
1850:         // Control: $data as a DIRECT expr operand IS the injection vector.
1851:         let ws = of_code("set data [read $fd]\nset v [expr {$data + 1}]", D, "T100");
1852:         assert_eq!(ws.len(), 1);
1853:         assert_eq!(ws[0].variable, "data");
1854:     }
1855: 
1856:     #[test]
1857:     fn t100_tainted_expr_func_arg_still_fires() {
1858:         // `abs($data)` — a math-func arg is a direct expr operand → T100 fires.
1859:         let ws = of_code("set data [read $fd]\nset v [expr {abs($data)}]", D, "T100");
1860:         assert_eq!(ws.len(), 1);
1861:     }
1862: 
1863:     #[test]
1864:     fn puts_tainted_output_alongside_tainted_chan() {
1865:         // Control: when BOTH channel and content are tainted, only the content
1866:         // word flags T101.
1867:         let ws = of_code(
1868:             "set chan [read $fd]\nset msg [read $fd]\nputs -nonewline $chan $msg",
1869:             D,
1870:             "T101",
1871:         );
1872:         assert_eq!(ws.len(), 1);
1873:         assert_eq!(ws[0].variable, "msg");
1874:     }
1875: 
1876:     #[test]
1877:     fn puts_interpolation_propagates() {
1878:         let ws = of_code("set x [read $fd]\nputs \"data: $x\"", D, "T101");
1879:         assert!(!ws.is_empty());
1880:     }
1881: 
1882:     #[test]
1883:     fn puts_nonewline_alone_is_content_not_channel() {
1884:         // `puts -nonewline $x` has only ONE positional arg after the flag,
1885:         // so per Tcl semantics `$x` is the content written to stdout, not a
1886:         // channel — the `-nonewline`-shifted `ArgRole::Channel` position
1887:         // (declared dynamically since the channel slot moves with the
1888:         // optional flag) must not exempt it.
1889:         let ws = of_code("set x [read $fd]\nputs -nonewline $x", D, "T101");
1890:         assert_eq!(ws.len(), 1);
1891:         assert_eq!(ws[0].variable, "x");
1892:     }
1893: 
1894:     #[test]
1895:     fn puts_via_interp_alias_still_fires() {
1896:         // `interp alias {} myputs {} puts` makes `myputs` a genuine
1897:         // current-interpreter alias for the real `puts` builtin. The sink
1898:         // classification must resolve the call through the lowerer's
1899:         // `canonical_command` (populated for a resolved alias) rather than
1900:         // the literal source spelling `"myputs"`, which isn't itself a
1901:         // registered command and would otherwise silently miss the sink.
1902:         let ws = of_code(
1903:             "interp alias {} myputs {} puts\nset x [read $fd]\nmyputs $x",
1904:             D,
1905:             "T101",
1906:         );
1907:         assert_eq!(ws.len(), 1, "expected T101 via interp alias, got {ws:?}");
1908:         assert_eq!(ws[0].variable, "x");
1909:     }
1910: 
1911:     #[test]
1912:     fn puts_inside_tcloo_method_body_still_fires() {
1913:         // TclOO method bodies are analysable functions like any proc — the
1914:         // sink check must not be limited to top-level / plain-proc bodies.
1915:         // Qualify the core heads because an instance method executes in its
1916:         // runtime-selected object namespace: a relative `puts` may denote an
1917:         // object-local command, for which deep analysis correctly abstains.
1918:         let ws = of_code(
1919:             "oo::class create Foo {\n\
1920:              method bar {} {\n\
1921:              ::set x [::read $fd]\n\
1922:              ::puts $x\n\
1923:              }\n\
1924:              }",
1925:             D,
1926:             "T101",
1927:         );
1928:         assert_eq!(
1929:             ws.len(),
1930:             1,
1931:             "expected T101 inside TclOO method body, got {ws:?}"
1932:         );
1933:         assert_eq!(ws[0].variable, "x");
1934:     }
1935: 
1936:     #[test]
1937:     fn puts_inside_namespace_eval_body_still_fires() {
1938:         // `namespace eval` registers its block as a synthetic body unit
1939:         // (`Module::body_units`) — a fresh-frame body outside any proc —
1940:         // which must be covered by the same sink check as the top level.
1941:         let ws = of_code(
1942:             "namespace eval ::myns {\n\
1943:              set x [read $fd]\n\
1944:              puts $x\n\
1945:              }",
1946:             D,
1947:             "T101",
1948:         );
1949:         assert_eq!(
1950:             ws.len(),
1951:             1,
1952:             "expected T101 inside namespace eval body, got {ws:?}"
1953:         );
1954:         assert_eq!(ws[0].variable, "x");
1955:     }
1956: }
1957: 
1958: // Option injection (T102) — tainted value in option position, no `--`.
1959: //
1960: // tclsh: option-bearing commands (`regexp`, `glob`, …) parse a leading `-` as a
1961: // switch, so a tainted value whose runtime content could start with `-` is an
1962: // option-injection vector unless a `--` terminator ends switch scanning. A
1963: // later *literal* positional also ends scanning (a tainted *subject* after a
1964: // literal pattern is safe). Verified: `regexp -- -foo bar` → `0` (-- ends scan).
1965: mod option_injection {
1966:     use super::*;
1967: 
1968:     #[test]
1969:     fn regexp_tainted_without_terminator() {
1970:         let ws = of_code("set x [read $fd]\nregexp $x test", D, "T102");
1971:         assert!(!ws.is_empty());
1972:         assert!(ws[0].sink_command.contains("regexp"));
1973:     }
1974: 
1975:     #[test]
1976:     fn regexp_tainted_with_terminator() {
1977:         // tclsh: `--` ends switch scanning, so $x can only be the pattern.
1978:         assert!(of_code("set x [read $fd]\nregexp -- $x test", D, "T102").is_empty());
1979:     }
1980: 
1981:     #[test]
1982:     fn glob_tainted_without_terminator() {
1983:         let ws = of_code("set x [read $fd]\nglob $x", D, "T102");
1984:         assert!(!ws.is_empty());
1985:     }
1986: 
1987:     #[test]
1988:     fn glob_tainted_with_terminator() {
1989:         assert!(of_code("set x [read $fd]\nglob -- $x", D, "T102").is_empty());
1990:     }
1991: 
1992:     #[test]
1993:     fn literal_no_warning() {
1994:         assert!(of_code("regexp {^/api} test", D, "T102").is_empty());
1995:     }
1996: 
1997:     #[test]
1998:     fn untainted_var_no_warning() {
1999:         assert!(of_code("set x \"pattern\"\nregexp $x test", D, "T102").is_empty());
2000:     }
2001: 
2002:     #[test]
2003:     fn tainted_subject_after_literal_pattern_no_warning() {
2004:         // tclsh: the literal pattern `{version ([0-9]+)}` is a definite
2005:         // positional that ends switch scanning, so the tainted subject `$x` in a
2006:         // later slot can't be misread as a switch. No T102.
2007:         assert!(
2008:             of_code(
2009:                 "set x [read $fd]\nregexp {version ([0-9]+)} $x -> m",
2010:                 D,
2011:                 "T102",
2012:             )
2013:             .is_empty()
2014:         );
2015:     }
2016: 
2017:     #[test]
2018:     fn braced_exec_argument_is_not_option_injection() {
2019:         assert!(
2020:             of_code("set x [read $fd]\nexec {$x}", D, "T102").is_empty(),
2021:             "a braced dollar spelling is literal and cannot become an exec option"
2022:         );
2023:     }
2024: 
2025:     #[test]
2026:     fn regsub_tainted_subject_after_literal_pattern_no_warning() {
2027:         // `regsub -all {literal} $subject {}` — $subject is positional after the
2028:         // literal pattern, not a switch position.
2029:         assert!(
2030:             of_code(
2031:                 "set x [read $fd]\nset y [regsub -all {/\\*.*?\\*/} $x {}]",
2032:                 D,
2033:                 "T102",
2034:             )
2035:             .is_empty()
2036:         );
2037:     }
2038: 
2039:     #[test]
2040:     fn unset_literal_name_no_warning() {
2041:         // tclsh: `unset name` takes a literal variable name that cannot start
2042:         // with `-`, so even a tainted var by that name is not option-injectable.
2043:         assert!(of_code("set thelongname [read $fd]\nunset thelongname", D, "T102").is_empty());
2044:     }
2045: 
2046:     #[test]
2047:     fn regexp_tainted_pattern_still_warns() {
2048:         // A tainted *pattern* (leading substitution, could expand to `-x`)
2049:         // remains a T102 candidate even when a later positional is literal.
2050:         let ws = of_code("set x [read $fd]\nregexp $x hello", D, "T102");
2051:         assert_eq!(ws.len(), 1);
2052:         assert_eq!(ws[0].variable, "x");
2053:         assert!(ws[0].sink_command.contains("regexp"));
2054:     }
2055: 
2056:     #[test]
2057:     fn switch_after_dash_option_no_warning_for_literal_arg() {
2058:         // `regexp -nocase {ab} $x` — after `-nocase` the literal pattern ends
2059:         // scanning, so the tainted subject is safe.
2060:         assert!(of_code("set x [read $fd]\nregexp -nocase {ab} $x", D, "T102").is_empty());
2061:     }
2062: }
2063: 
2064: // IRULE3001 (HTTP::respond body) / IRULE3002
2065: // (HTTP::header|cookie insert|replace). f5-dialect; gated on the iRules dialect.
2066: mod irules_output_sinks {
2067:     use super::*;
2068: 
2069:     #[test]
2070:     fn http_respond_tainted_body() {
2071:         // f5-dialect.
2072:         let ws = of_code(
2073:             "set data [HTTP::payload]\nHTTP::respond 200 content $data",
2074:             IR,
2075:             "IRULE3001",
2076:         );
2077:         assert!(!ws.is_empty());
2078:         assert!(ws[0].sink_command.contains("HTTP::respond"));
2079:     }
2080: 
2081:     #[test]
2082:     fn http_respond_literal_clean() {
2083:         assert!(of_code("HTTP::respond 200 content \"ok\"", IR, "IRULE3001").is_empty());
2084:     }
2085: 
2086:     #[test]
2087:     fn http_header_insert_tainted() {
2088:         // f5-dialect.
2089:         let ws = of_code(
2090:             "set val [HTTP::header Host]\nHTTP::header insert X-Foo $val",
2091:             IR,
2092:             "IRULE3002",
2093:         );
2094:         assert!(!ws.is_empty());
2095:         assert!(ws[0].sink_command.to_lowercase().contains("header"));
2096:     }
2097: 
2098:     #[test]
2099:     fn http_header_remove_clean() {
2100:         // `remove` is not an insert/replace value sink.
2101:         assert!(of_code("HTTP::header remove X-Bad", IR, "IRULE3002").is_empty());
2102:     }
2103: 
2104:     #[test]
2105:     fn http_cookie_insert_tainted() {
2106:         // f5-dialect.
2107:         let ws = of_code(
2108:             "set val [HTTP::cookie value session]\nHTTP::cookie insert name \"track\" value $val",
2109:             IR,
2110:             "IRULE3002",
2111:         );
2112:         assert!(!ws.is_empty());
2113:     }
2114: 
2115:     #[test]
2116:     fn not_in_tcl86_dialect() {
2117:         // Under plain tcl8.6 the HTTP::respond sink is not classified → no
2118:         // IRULE3001 even though `read` taints `$data`.
2119:         assert!(
2120:             of_code(
2121:                 "set data [read $fd]\nHTTP::respond 200 content $data",
2122:                 D,
2123:                 "IRULE3001",
2124:             )
2125:             .is_empty()
2126:         );
2127:     }
2128: }
2129: 
2130: // Log injection (IRULE3003) — tainted data in `log`. f5-dialect.
2131: mod log_injection {
2132:     use super::*;
2133: 
2134:     #[test]
2135:     fn log_tainted_data() {
2136:         // f5-dialect.
2137:         let ws = of_code("set x [HTTP::uri]\nlog local0. $x", IR, "IRULE3003");
2138:         assert!(!ws.is_empty());
2139:         assert!(ws[0].sink_command.contains("log"));
2140:     }
2141: 
2142:     #[test]
2143:     fn log_literal_clean() {
2144:         assert!(of_code("log local0. \"static message\"", IR, "IRULE3003").is_empty());
2145:     }
2146: 
2147:     #[test]
2148:     fn log_not_in_tcl86() {
2149:         assert!(of_code("set x [read $fd]\nlog local0. $x", D, "IRULE3003").is_empty());
2150:     }
2151: }
2152: 
2153: // PATH_PREFIXED / NON_DASH colours propagate through copies
2154: // and interpolation, keeping later T102 suppressed. f5-dialect sources.
2155: mod taint_colours {
2156:     use super::*;
2157: 
2158:     #[test]
2159:     fn http_uri_getter_has_path_colour() {
2160:         // T100 still fires (dangerous sink regardless of colour).
2161:         let ws = of_code("set uri [HTTP::uri]\neval $uri", D, "T100");
2162:         assert!(!ws.is_empty());
2163:         assert_eq!(ws[0].variable, "uri");
2164:     }
2165: 
2166:     #[test]
2167:     fn http_path_getter_has_path_colour() {
2168:         let ws = of_code("set p [HTTP::path]\neval $p", D, "T100");
2169:         assert!(!ws.is_empty());
2170:         assert_eq!(ws[0].variable, "p");
2171:     }
2172: 
2173:     #[test]
2174:     fn colour_propagates_through_copy() {
2175:         let ws = of_code("set x [HTTP::uri]\nset y $x\neval $y", D, "T100");
2176:         assert!(ws.iter().any(|w| w.variable == "y"));
2177:     }
2178: 
2179:     #[test]
2180:     fn non_dash_literal_prefix_stays_t102_safe() {
2181:         // `"prefix${uri}"` no longer starts with `/` but still cannot start with
2182:         // `-` → NON_DASH_PREFIXED, T102 safe.
2183:         assert!(
2184:             of_code(
2185:                 "set uri [HTTP::uri]\nset z \"prefix${uri}\"\nregexp $z test",
2186:                 D,
2187:                 "T102",
2188:             )
2189:             .is_empty()
2190:         );
2191:     }
2192: 
2193:     #[test]
2194:     fn colour_kept_when_dynamic_leading_piece_is_path_prefixed() {
2195:         // `${uri}/suffix` keeps PATH_PREFIXED (the leading dynamic
2196:         // piece is the path-prefixed uri), so T102 stays suppressed.
2197:         // FIXED (lattice-join identity): `word_taint` seeds the interpolation
2198:         // with `clean()` and folds `join` over each piece; with clean now the
2199:         // join identity (not an annihilator) the first join keeps PATH_PREFIXED,
2200:         // so the T102_SAFE colour survives and T102 stays suppressed on `$z`.
2201:         assert!(
2202:             of_code(
2203:                 "set uri [HTTP::uri]\nset z ${uri}/suffix\nregexp $z test",
2204:                 D,
2205:                 "T102",
2206:             )
2207:             .is_empty()
2208:         );
2209:     }
2210: 
2211:     #[test]
2212:     fn leading_slash_concat_sets_path_prefixed() {
2213:         // A literal leading `/` keeps the option-injection-safe PATH_PREFIXED.
2214:         assert!(
2215:             of_code(
2216:                 "set h [HTTP::header Host]\nset z /${h}\nregexp $z test",
2217:                 D,
2218:                 "T102",
2219:             )
2220:             .is_empty()
2221:         );
2222:     }
2223: }
2224: 
2225: // TestT102Suppression — PATH_PREFIXED / IP / PORT / FQDN colours suppress T102
2226: // (cannot start with `-`); generic taint still fires it. f5-dialect sources.
2227: mod t102_suppression {
2228:     use super::*;
2229: 
2230:     #[test]
2231:     fn http_uri_no_t102() {
2232:         // f5-dialect: HTTP::uri always starts with `/` → no option injection.
2233:         assert!(of_code("set uri [HTTP::uri]\nregexp $uri test", D, "T102").is_empty());
2234:     }
2235: 
2236:     #[test]
2237:     fn http_path_no_t102() {
2238:         assert!(of_code("set p [HTTP::path]\nregexp $p test", D, "T102").is_empty());
2239:     }
2240: 
2241:     #[test]
2242:     fn literal_prefix_concat_no_t102() {
2243:         // A fixed non-dash literal prefix is option-injection-safe.
2244:         assert!(of_code("set foo \"path_[HTTP::path]\"\nregexp $foo test", D, "T102",).is_empty());
2245:     }
2246: 
2247:     #[test]
2248:     fn literal_dash_prefix_concat_still_warns() {
2249:         // A fixed `-` prefix is still option-like → warn.
2250:         let ws = of_code("set foo \"-[HTTP::path]\"\nregexp $foo test", D, "T102");
2251:         assert!(!ws.is_empty());
2252:     }
2253: 
2254:     #[test]
2255:     fn generic_taint_still_warns() {
2256:         let ws = of_code("set x [read $fd]\nregexp $x test", D, "T102");
2257:         assert!(!ws.is_empty());
2258:     }
2259: 
2260:     #[test]
2261:     fn http_header_still_warns() {
2262:         // f5-dialect: HTTP::header is generic-tainted (no path colour) → T102.
2263:         let ws = of_code("set h [HTTP::header Host]\nregexp $h test", D, "T102");
2264:         assert!(!ws.is_empty());
2265:     }
2266: 
2267:     #[test]
2268:     fn path_prefixed_copy_suppresses() {
2269:         assert!(of_code("set uri [HTTP::uri]\nset x $uri\nregexp $x test", D, "T102",).is_empty());
2270:     }
2271: 
2272:     #[test]
2273:     fn ip_client_addr_no_t102() {
2274:         // f5-dialect: IP::client_addr starts with digit/colon → no `-` prefix.
2275:         assert!(of_code("set addr [IP::client_addr]\nregexp $addr test", D, "T102").is_empty());
2276:     }
2277: 
2278:     #[test]
2279:     fn ip_remote_addr_no_t102() {
2280:         assert!(of_code("set addr [IP::remote_addr]\nregexp $addr test", D, "T102").is_empty());
2281:     }
2282: 
2283:     #[test]
2284:     fn tcp_client_port_no_t102() {
2285:         // f5-dialect: TCP::client_port is always numeric.
2286:         assert!(of_code("set port [TCP::client_port]\nregexp $port test", D, "T102").is_empty());
2287:     }
2288: 
2289:     #[test]
2290:     fn tcp_remote_port_no_t102() {
2291:         assert!(of_code("set port [TCP::remote_port]\nregexp $port test", D, "T102").is_empty());
2292:     }
2293: 
2294:     #[test]
2295:     fn ssl_sni_no_t102() {
2296:         // f5-dialect: SSL::sni is an FQDN — starts with letter/digit, not `-`.
2297:         assert!(of_code("set sni [SSL::sni]\nregexp $sni test", D, "T102").is_empty());
2298:     }
2299: 
2300:     #[test]
2301:     fn ip_addr_copy_preserves_colour() {
2302:         assert!(
2303:             of_code(
2304:                 "set addr [IP::client_addr]\nset x $addr\nregexp $x test",
2305:                 D,
2306:                 "T102",
2307:             )
2308:             .is_empty()
2309:         );
2310:     }
2311: 
2312:     #[test]
2313:     fn ip_addr_still_fires_t100() {
2314:         // IP_ADDRESS does NOT suppress T100 — still dangerous for eval.
2315:         let ws = of_code("set addr [IP::client_addr]\neval $addr", D, "T100");
2316:         assert!(!ws.is_empty());
2317:     }
2318: 
2319:     #[test]
2320:     fn port_still_fires_t100() {
2321:         let ws = of_code("set port [TCP::client_port]\neval $port", D, "T100");
2322:         assert!(!ws.is_empty());
2323:     }
2324: 
2325:     #[test]
2326:     fn phi_same_colour_preserves() {
2327:         // Both branches IP_ADDRESS → colour preserved at the phi, no T102.
2328:         let source = "set a [IP::client_addr]\nset b [IP::remote_addr]\nif {1} {\n    set x $a\n} else {\n    set x $b\n}\nregexp $x test\n";
2329:         assert!(of_code(source, D, "T102").is_empty());
2330:     }
2331: 
2332:     #[test]
2333:     fn phi_mixed_colours_preserves_non_dash() {
2334:         // IP_ADDRESS and PORT both augment to NON_DASH_PREFIXED; T102 safe.
2335:         let source = "set a [IP::client_addr]\nset p [TCP::client_port]\nif {$cond} {\n    set x $a\n} else {\n    set x $p\n}\nregexp $x test\n";
2336:         assert!(of_code(source, D, "T102").is_empty());
2337:     }
2338: 
2339:     #[test]
2340:     fn phi_generic_with_coloured_loses() {
2341:         // One branch generic taint, the other IP_ADDRESS → T102 fires.
2342:         let source = "set a [IP::client_addr]\nset g [read $fd]\nif {$cond} {\n    set x $a\n} else {\n    set x $g\n}\nregexp $x test\n";
2343:         assert!(!of_code(source, D, "T102").is_empty());
2344:     }
2345: }
2346: 
2347: // Setter constraints (IRULE3101) — HTTP::uri / HTTP::path set to a value not
2348: // provably starting with `/`. f5-dialect.
2349: mod setter_constraints {
2350:     use super::*;
2351: 
2352:     #[test]
2353:     fn literal_slash_prefix_clean() {
2354:         assert!(of_code("HTTP::uri /newpath", IR, "IRULE3101").is_empty());
2355:     }
2356: 
2357:     #[test]
2358:     fn literal_no_slash_warns() {
2359:         let ws = of_code("HTTP::uri newpath", IR, "IRULE3101");
2360:         assert_eq!(ws.len(), 1);
2361:         assert!(ws[0].sink_command.contains("HTTP::uri"));
2362:     }
2363: 
2364:     #[test]
2365:     fn path_prefixed_var_clean() {
2366:         // f5-dialect: $uri carries PATH_PREFIXED (HTTP::uri getter).
2367:         assert!(of_code("set uri [HTTP::uri]\nHTTP::uri $uri", IR, "IRULE3101").is_empty());
2368:     }
2369: 
2370:     #[test]
2371:     fn generic_tainted_var_warns() {
2372:         let ws = of_code("set x [read $fd]\nHTTP::uri $x", IR, "IRULE3101");
2373:         assert_eq!(ws.len(), 1);
2374:     }
2375: 
2376:     #[test]
2377:     fn http_path_literal_clean() {
2378:         assert!(of_code("HTTP::path /foo/bar", IR, "IRULE3101").is_empty());
2379:     }
2380: 
2381:     #[test]
2382:     fn http_path_literal_warns() {
2383:         let ws = of_code("HTTP::path relative/path", IR, "IRULE3101");
2384:         assert_eq!(ws.len(), 1);
2385:     }
2386: 
2387:     #[test]
2388:     fn path_to_path_clean() {
2389:         assert!(of_code("set p [HTTP::path]\nHTTP::path $p", IR, "IRULE3101").is_empty());
2390:     }
2391: 
2392:     /// #2055: a path the lattice proves at the setter is checked as a
2393:     /// literal is — `set p /a; HTTP::path $p` is clean — and a proven value
2394:     /// without the `/` still warns.
2395:     #[test]
2396:     fn irule3101_reads_the_proven_path() {
2397:         assert!(of_code("set p /a\nHTTP::path $p", IR, "IRULE3101").is_empty());
2398:         let ws = of_code("set p a\nHTTP::path $p", IR, "IRULE3101");
2399:         assert_eq!(ws.len(), 1);
2400:         assert_eq!(ws[0].variable, "p");
2401:     }
2402: 
2403:     /// A computed operand reads as the constant the lattice proves:
2404:     /// `[HTTP::uri] starts_with $p` over `set p [string range /api/v1 0 3]`
2405:     /// is IRULE3103, as the literal `/api` is, and the same test over a
2406:     /// header value is not.
2407:     #[test]
2408:     fn irule3103_reads_a_proven_operand() {
2409:         let proven = "set p [string range /api/v1 0 3]\n\
2410:                       if {[HTTP::uri] starts_with $p} { pool api }";
2411:         assert_eq!(of_code(proven, IR, "IRULE3103").len(), 1);
2412:         let unknown = "set p [HTTP::header value X-Prefix]\n\
2413:                        if {[HTTP::uri] starts_with $p} { pool api }";
2414:         assert!(of_code(unknown, IR, "IRULE3103").is_empty());
2415:     }
2416: 
2417:     #[test]
2418:     fn untainted_var_warns() {
2419:         // Untainted var without a known `/` prefix → can't prove safety → warn.
2420:         let ws = of_code("set x \"something\"\nHTTP::uri $x", IR, "IRULE3101");
2421:         assert_eq!(ws.len(), 1);
2422:     }
2423: }
2424: 
2425: // CRLF_FREE colour suppresses IRULE3002 (header) and IRULE3003
2426: // (log). Produced by IP/PORT/FQDN sources and URI::/HTML::encode. f5-dialect.
2427: mod crlf_free {
2428:     use super::*;
2429: 
2430:     #[test]
2431:     fn ip_client_addr_augments_crlf_free() {
2432:         assert!(
2433:             of_code(
2434:                 "set addr [IP::client_addr]\nlog local0. $addr",
2435:                 IR,
2436:                 "IRULE3003"
2437:             )
2438:             .is_empty()
2439:         );
2440:     }
2441: 
2442:     #[test]
2443:     fn tcp_client_port_augments_crlf_free() {
2444:         assert!(
2445:             of_code(
2446:                 "set port [TCP::client_port]\nlog local0. $port",
2447:                 IR,
2448:                 "IRULE3003"
2449:             )
2450:             .is_empty()
2451:         );
2452:     }
2453: 
2454:     #[test]
2455:     fn ssl_sni_augments_crlf_free() {
2456:         assert!(of_code("set sni [SSL::sni]\nlog local0. $sni", IR, "IRULE3003").is_empty());
2457:     }
2458: 
2459:     #[test]
2460:     fn uri_encode_adds_crlf_free() {
2461:         // f5-dialect: URI::encode strips CR/LF → suppresses IRULE3003.
2462:         assert!(
2463:             of_code(
2464:                 "set raw [HTTP::query]\nset enc [URI::encode $raw]\nlog local0. $enc",
2465:                 IR,
2466:                 "IRULE3003",
2467:             )
2468:             .is_empty()
2469:         );
2470:     }
2471: 
2472:     #[test]
2473:     fn html_encode_adds_crlf_free() {
2474:         assert!(
2475:             of_code(
2476:                 "set raw [HTTP::query]\nset enc [HTML::encode $raw]\nlog local0. $enc",
2477:                 IR,
2478:                 "IRULE3003",
2479:             )
2480:             .is_empty()
2481:         );
2482:     }
2483: 
2484:     #[test]
2485:     fn generic_taint_irule3003_still_warns() {
2486:         let ws = of_code("set raw [HTTP::query]\nlog local0. $raw", IR, "IRULE3003");
2487:         assert!(!ws.is_empty());
2488:     }
2489: 
2490:     #[test]
2491:     fn crlf_free_suppresses_irule3002() {
2492:         assert!(
2493:             of_code(
2494:                 "set raw [HTTP::header Host]\nset enc [URI::encode $raw]\nHTTP::header insert X-Fwd $enc",
2495:                 IR,
2496:                 "IRULE3002",
2497:             )
2498:             .is_empty()
2499:         );
2500:     }
2501: 
2502:     #[test]
2503:     fn crlf_free_survives_safe_concat() {
2504:         // CRLF_FREE from an IP addr survives safe prefix/suffix
2505:         // interpolation, so IRULE3003 stays suppressed.
2506:         // FIXED (lattice-join identity): `word_taint` seeds the interpolated
2507:         // value with `clean()` then joins each `$var`; with clean now the join
2508:         // identity the first `clean().join(addr)` keeps CRLF_FREE, so IRULE3003
2509:         // stays suppressed on `$msg`.
2510:         assert!(
2511:             of_code(
2512:                 "set addr [IP::client_addr]\nset msg \"src=${addr}:80\"\nlog local0. $msg",
2513:                 IR,
2514:                 "IRULE3003",
2515:             )
2516:             .is_empty()
2517:         );
2518:     }
2519: 
2520:     #[test]
2521:     fn interpolation_without_crlf_preserves() {
2522:         // Interpolation with no literal CR/LF preserves CRLF_FREE →
2523:         // IRULE3003 suppressed.
2524:         // FIXED (lattice-join identity): CRLF_FREE now survives the
2525:         // interpolation `"client:${addr}"` (clean is the join identity), so
2526:         // IRULE3003 stays suppressed.
2527:         assert!(
2528:             of_code(
2529:                 "set addr [IP::client_addr]\nset x \"client:${addr}\"\nlog local0. $x",
2530:                 IR,
2531:                 "IRULE3003",
2532:             )
2533:             .is_empty()
2534:         );
2535:     }
2536: }
2537: 
2538: // SHELL_ATOM augmented from IP/PORT/FQDN; does NOT suppress
2539: // T100. f5-dialect sources.
2540: mod shell_atom {
2541:     use super::*;
2542: 
2543:     #[test]
2544:     fn ip_addr_augments_shell_atom() {
2545:         let ws = of_code("set addr [IP::client_addr]\neval $addr", D, "T100");
2546:         assert!(!ws.is_empty());
2547:     }
2548: 
2549:     #[test]
2550:     fn port_augments_shell_atom() {
2551:         let ws = of_code("set port [TCP::client_port]\neval $port", D, "T100");
2552:         assert!(!ws.is_empty());
2553:     }
2554: 
2555:     #[test]
2556:     fn fqdn_augments_shell_atom() {
2557:         let ws = of_code("set sni [SSL::sni]\neval $sni", D, "T100");
2558:         assert!(!ws.is_empty());
2559:     }
2560: 
2561:     #[test]
2562:     fn shell_atom_lost_at_phi_with_generic() {
2563:         // Both paths tainted → T100 fires regardless of the lost colour.
2564:         let source = "set a [IP::client_addr]\nset g [read $fd]\nif {$cond} {\n    set x $a\n} else {\n    set x $g\n}\neval $x\n";
2565:         assert!(!of_code(source, D, "T100").is_empty());
2566:     }
2567: }
2568: 
2569: // [list]/concat produce LIST_CANONICAL, but `eval $lst`
2570: // still fires T100: the tainted first list element becomes the command word.
2571: //
2572: // tclsh (8.6 + 9.0): `proc marker args {puts EXECUTED}; set raw marker;
2573: // set lst [list $raw]; eval $lst` prints `EXECUTED`. LIST_CANONICAL proves
2574: // list-quoting, NOT that the synthesised command word is trusted (D5-T100).
2575: mod list_canonical {
2576:     use super::*;
2577: 
2578:     #[test]
2579:     fn list_command_propagates_taint_to_eval_fires() {
2580:         // tclsh: `eval [list $raw]` runs $raw as the command word → T100.
2581:         let ws = of_code(
2582:             "set raw [read $fd]\nset lst [list $raw]\neval $lst",
2583:             D,
2584:             "T100",
2585:         );
2586:         assert!(!ws.is_empty());
2587:         assert!(ws.iter().any(|w| w.sink_command == "eval"));
2588:     }
2589: 
2590:     #[test]
2591:     fn lsort_eval_fires() {
2592:         // tclsh: lsort returns a canonical list but its first element is still
2593:         // user-controlled — no command-word safety.
2594:         let ws = of_code(
2595:             "set raw [read $fd]\nset sorted [lsort $raw]\neval $sorted",
2596:             D,
2597:             "T100",
2598:         );
2599:         assert!(!ws.is_empty());
2600:         assert!(ws.iter().any(|w| w.sink_command == "eval"));
2601:     }
2602: 
2603:     #[test]
2604:     fn lrange_eval_fires() {
2605:         let ws = of_code(
2606:             "set raw [read $fd]\nset sub [lrange $raw 0 2]\neval $sub",
2607:             D,
2608:             "T100",
2609:         );
2610:         assert!(!ws.is_empty());
2611:         assert!(ws.iter().any(|w| w.sink_command == "eval"));
2612:     }
2613: 
2614:     #[test]
2615:     fn split_eval_fires() {
2616:         let ws = of_code(
2617:             "set raw [read $fd]\nset parts [split $raw :]\neval $parts",
2618:             D,
2619:             "T100",
2620:         );
2621:         assert!(!ws.is_empty());
2622:         assert!(ws.iter().any(|w| w.sink_command == "eval"));
2623:     }
2624: 
2625:     #[test]
2626:     fn list_command_propagates_taint_to_puts() {
2627:         let ws = of_code(
2628:             "set raw [read $fd]\nset lst [list $raw]\nputs $lst",
2629:             D,
2630:             "T101",
2631:         );
2632:         assert!(!ws.is_empty());
2633:     }
2634: 
2635:     #[test]
2636:     fn concat_of_canonical_lists_eval_fires() {
2637:         let ws = of_code(
2638:             "set raw [read $fd]\nset a [list $raw]\nset raw2 [read $fd2]\nset b [list $raw2]\nset c [concat $a $b]\neval $c",
2639:             D,
2640:             "T100",
2641:         );
2642:         assert!(!ws.is_empty());
2643:         assert!(ws.iter().any(|w| w.sink_command == "eval"));
2644:     }
2645: 
2646:     #[test]
2647:     fn interpolation_preserves_taint_from_list() {
2648:         let ws = of_code(
2649:             "set raw [read $fd]\nset lst [list $raw]\nset broken \"prefix $lst\"\neval $broken",
2650:             D,
2651:             "T100",
2652:         );
2653:         assert!(!ws.is_empty());
2654:     }
2655: 
2656:     #[test]
2657:     fn list_canonical_copy_eval_fires() {
2658:         // Suppression requires a literal `[list <known-cmd> …]` at the eval site,
2659:         // which is invisible when eval reads a propagated variable → T100 fires.
2660:         let ws = of_code(
2661:             "set raw [read $fd]\nset lst [list $raw]\nset copy $lst\neval $copy",
2662:             D,
2663:             "T100",
2664:         );
2665:         assert!(!ws.is_empty());
2666:         assert!(ws.iter().any(|w| w.sink_command == "eval"));
2667:     }
2668: 
2669:     #[test]
2670:     fn list_canonical_copy_still_tainted() {
2671:         let ws = of_code(
2672:             "set raw [read $fd]\nset lst [list $raw]\nset copy $lst\nputs $copy",
2673:             D,
2674:             "T101",
2675:         );
2676:         assert!(!ws.is_empty());
2677:     }
2678: }
2679: 
2680: // regex::quote / regexp::quote produce REGEX_LITERAL, lost
2681: // on interpolation, propagated through copies. (Does not suppress T100.)
2682: mod regex_literal {
2683:     use super::*;
2684: 
2685:     #[test]
2686:     fn regex_quote_produces_colour() {
2687:         let ws = of_code(
2688:             "set raw [read $fd]\nset safe [regex::quote $raw]\neval $safe",
2689:             D,
2690:             "T100",
2691:         );
2692:         assert!(!ws.is_empty());
2693:     }
2694: 
2695:     #[test]
2696:     fn regexp_quote_produces_colour() {
2697:         let ws = of_code(
2698:             "set raw [read $fd]\nset safe [regexp::quote $raw]\neval $safe",
2699:             D,
2700:             "T100",
2701:         );
2702:         assert!(!ws.is_empty());
2703:     }
2704: 
2705:     #[test]
2706:     fn interpolation_invalidates_regex_literal() {
2707:         let ws = of_code(
2708:             "set raw [read $fd]\nset safe [regex::quote $raw]\nset pat \"prefix${safe}suffix\"\neval $pat",
2709:             D,
2710:             "T100",
2711:         );
2712:         assert!(!ws.is_empty());
2713:     }
2714: 
2715:     #[test]
2716:     fn regex_literal_propagates_through_copy() {
2717:         let ws = of_code(
2718:             "set raw [read $fd]\nset safe [regex::quote $raw]\nset copy $safe\neval $copy",
2719:             D,
2720:             "T100",
2721:         );
2722:         assert!(!ws.is_empty());
2723:     }
2724: }
2725: 
2726: // `file normalize` produces PATH_NORMALISED, lost on
2727: // interpolation, propagated through copies. (Does not suppress T100.)
2728: mod path_normalised {
2729:     use super::*;
2730: 
2731:     #[test]
2732:     fn file_normalize_produces_colour() {
2733:         let ws = of_code(
2734:             "set raw [read $fd]\nset norm [file normalize $raw]\neval $norm",
2735:             D,
2736:             "T100",
2737:         );
2738:         assert!(!ws.is_empty());
2739:     }
2740: 
2741:     #[test]
2742:     fn interpolation_invalidates_path_normalised() {
2743:         let ws = of_code(
2744:             "set raw [read $fd]\nset norm [file normalize $raw]\nset broken \"${norm}/extra\"\neval $broken",
2745:             D,
2746:             "T100",
2747:         );
2748:         assert!(!ws.is_empty());
2749:     }
2750: 
2751:     #[test]
2752:     fn path_normalised_propagates_through_copy() {
2753:         let ws = of_code(
2754:             "set raw [read $fd]\nset norm [file normalize $raw]\nset copy $norm\neval $copy",
2755:             D,
2756:             "T100",
2757:         );
2758:         assert!(!ws.is_empty());
2759:     }
2760: }
2761: 
2762: // HTML::encode / html_encode produce HTML_ESCAPED (+ CRLF_FREE);
2763: // suppress IRULE3001; lost on interpolation; T106 on double-encode. f5-dialect.
2764: mod html_escaped {
2765:     use super::*;
2766: 
2767:     #[test]
2768:     fn html_encode_produces_colour() {
2769:         assert!(of_code(
2770:             "set raw [HTTP::query]\nset safe [HTML::encode $raw]\nHTTP::respond 200 content $safe",
2771:             IR,
2772:             "IRULE3001",
2773:         )
2774:         .is_empty());
2775:     }
2776: 
2777:     #[test]
2778:     fn generic_taint_irule3001_fires() {
2779:         let ws = of_code(
2780:             "set raw [HTTP::query]\nHTTP::respond 200 content $raw",
2781:             IR,
2782:             "IRULE3001",
2783:         );
2784:         assert!(!ws.is_empty());
2785:     }
2786: 
2787:     #[test]
2788:     fn interpolation_invalidates_html_escaped() {
2789:         let ws = of_code(
2790:             "set raw [HTTP::query]\nset safe [HTML::encode $raw]\nset broken \"<b>${safe}</b>\"\nHTTP::respond 200 content $broken",
2791:             IR,
2792:             "IRULE3001",
2793:         );
2794:         assert!(!ws.is_empty());
2795:     }
2796: 
2797:     #[test]
2798:     fn html_escaped_propagates_through_copy() {
2799:         assert!(
2800:             of_code(
2801:                 "set raw [HTTP::query]\nset safe [HTML::encode $raw]\nset copy $safe\nHTTP::respond 200 content $copy",
2802:                 IR,
2803:                 "IRULE3001",
2804:             )
2805:             .is_empty()
2806:         );
2807:     }
2808: 
2809:     #[test]
2810:     fn html_encode_also_sets_crlf_free() {
2811:         assert!(
2812:             of_code(
2813:                 "set raw [HTTP::query]\nset safe [HTML::encode $raw]\nlog local0. $safe",
2814:                 IR,
2815:                 "IRULE3003",
2816:             )
2817:             .is_empty()
2818:         );
2819:     }
2820: 
2821:     #[test]
2822:     fn html_encode_recognised_as_sanitiser() {
2823:         // f5-dialect: html_encode (portable helper) produces HTML_ESCAPED.
2824:         assert!(of_code(
2825:             "set raw [HTTP::query]\nset safe [html_encode $raw]\nHTTP::respond 200 content $safe",
2826:             IR,
2827:             "IRULE3001",
2828:         )
2829:         .is_empty());
2830:     }
2831: 
2832:     #[test]
2833:     fn html_encode_produces_crlf_free() {
2834:         assert!(
2835:             of_code(
2836:                 "set raw [HTTP::query]\nset safe [html_encode $raw]\nlog local0. $safe",
2837:                 IR,
2838:                 "IRULE3003",
2839:             )
2840:             .is_empty()
2841:         );
2842:     }
2843: 
2844:     #[test]
2845:     fn html_encode_double_encode_detected() {
2846:         // T106: html_encode on already HTML_ESCAPED data.
2847:         let ws = of_code(
2848:             "set raw [read $fd]\nset safe [HTML::encode $raw]\nset dup [html_encode $safe]",
2849:             IR,
2850:             "T106",
2851:         );
2852:         assert!(!ws.is_empty());
2853:     }
2854: }
2855: 
2856: // URI::encode / encode_component / escape produce URL_ENCODED
2857: // (+ CRLF_FREE); lost on interpolation; propagated through copies. f5-dialect.
2858: mod url_encoded {
2859:     use super::*;
2860: 
2861:     #[test]
2862:     fn uri_encode_produces_colour() {
2863:         let ws = of_code(
2864:             "set raw [read $fd]\nset enc [URI::encode $raw]\neval $enc",
2865:             D,
2866:             "T100",
2867:         );
2868:         assert!(!ws.is_empty());
2869:     }
2870: 
2871:     #[test]
2872:     fn uri_encode_component_produces_colour() {
2873:         let ws = of_code(
2874:             "set raw [read $fd]\nset enc [URI::encode_component $raw]\neval $enc",
2875:             D,
2876:             "T100",
2877:         );
2878:         assert!(!ws.is_empty());
2879:     }
2880: 
2881:     #[test]
2882:     fn uri_escape_produces_colour() {
2883:         let ws = of_code(
2884:             "set raw [read $fd]\nset enc [URI::escape $raw]\neval $enc",
2885:             D,
2886:             "T100",
2887:         );
2888:         assert!(!ws.is_empty());
2889:     }
2890: 
2891:     #[test]
2892:     fn interpolation_invalidates_url_encoded() {
2893:         let ws = of_code(
2894:             "set raw [read $fd]\nset enc [URI::encode $raw]\nset broken \"prefix${enc}\"\neval $broken",
2895:             D,
2896:             "T100",
2897:         );
2898:         assert!(!ws.is_empty());
2899:     }
2900: 
2901:     #[test]
2902:     fn url_encoded_propagates_through_copy() {
2903:         let ws = of_code(
2904:             "set raw [read $fd]\nset enc [URI::encode $raw]\nset copy $enc\neval $copy",
2905:             D,
2906:             "T100",
2907:         );
2908:         assert!(!ws.is_empty());
2909:     }
2910: 
2911:     #[test]
2912:     fn uri_encode_also_sets_crlf_free() {
2913:         assert!(
2914:             of_code(
2915:                 "set raw [HTTP::query]\nset enc [URI::encode $raw]\nlog local0. $enc",
2916:                 IR,
2917:                 "IRULE3003",
2918:             )
2919:             .is_empty()
2920:         );
2921:     }
2922: }
2923: 
2924: // CRLF_FREE in header/cookie value position suppresses
2925: // IRULE3002; generic taint fires it. f5-dialect.
2926: mod header_token_safe {
2927:     use super::*;
2928: 
2929:     #[test]
2930:     fn crlf_free_in_header_value_suppresses_irule3002() {
2931:         assert!(
2932:             of_code(
2933:                 "set val [IP::client_addr]\nHTTP::header insert X-Fwd $val",
2934:                 IR,
2935:                 "IRULE3002",
2936:             )
2937:             .is_empty()
2938:         );
2939:     }
2940: 
2941:     #[test]
2942:     fn crlf_free_in_cookie_value_suppresses_irule3002() {
2943:         assert!(
2944:             of_code(
2945:                 "set val [IP::client_addr]\nHTTP::cookie insert name \"track\" value $val",
2946:                 IR,
2947:                 "IRULE3002",
2948:             )
2949:             .is_empty()
2950:         );
2951:     }
2952: 
2953:     #[test]
2954:     fn generic_taint_in_header_value_warns() {
2955:         let ws = of_code(
2956:             "set val [HTTP::header Host]\nHTTP::header insert X-Fwd $val",
2957:             IR,
2958:             "IRULE3002",
2959:         );
2960:         assert!(!ws.is_empty());
2961:     }
2962: }
2963: 
2964: // IP/PORT/FQDN/PATH sources suppress T102;
2965: // generic taint does not. f5-dialect sources.
2966: mod source_colour_augmentation {
2967:     use super::*;
2968: 
2969:     #[test]
2970:     fn ip_client_addr_non_dash() {
2971:         assert!(of_code("set addr [IP::client_addr]\nregexp $addr test", D, "T102").is_empty());
2972:     }
2973: 
2974:     #[test]
2975:     fn tcp_client_port_non_dash() {
2976:         assert!(of_code("set port [TCP::client_port]\nregexp $port test", D, "T102").is_empty());
2977:     }
2978: 
2979:     #[test]
2980:     fn ssl_sni_non_dash() {
2981:         assert!(of_code("set sni [SSL::sni]\nregexp $sni test", D, "T102").is_empty());
2982:     }
2983: 
2984:     #[test]
2985:     fn path_prefixed_augments_non_dash() {
2986:         assert!(of_code("set uri [HTTP::uri]\nregexp $uri test", D, "T102").is_empty());
2987:     }
2988: 
2989:     #[test]
2990:     fn generic_taint_no_augmentation() {
2991:         let ws = of_code("set raw [read $fd]\nregexp $raw test", D, "T102");
2992:         assert!(!ws.is_empty());
2993:     }
2994: }
2995: 
2996: // Leading literal char of an interpolated
2997: // word controls NON_DASH_PREFIXED / PATH_PREFIXED. f5-dialect sources.
2998: mod non_dash_prefixed_interpolation {
2999:     use super::*;
3000: 
3001:     #[test]
3002:     fn literal_alpha_prefix() {
3003:         // `key_${x}` starts with `k` → NON_DASH_PREFIXED.
3004:         assert!(
3005:             of_code(
3006:                 "set x [HTTP::header Host]\nset y \"key_${x}\"\nregexp $y test",
3007:                 D,
3008:                 "T102",
3009:             )
3010:             .is_empty()
3011:         );
3012:     }
3013: 
3014:     #[test]
3015:     fn literal_digit_prefix() {
3016:         assert!(
3017:             of_code(
3018:                 "set x [HTTP::header Host]\nset y \"0${x}\"\nregexp $y test",
3019:                 D,
3020:                 "T102",
3021:             )
3022:             .is_empty()
3023:         );
3024:     }
3025: 
3026:     #[test]
3027:     fn literal_slash_prefix() {
3028:         assert!(
3029:             of_code(
3030:                 "set x [HTTP::header Host]\nset y \"/${x}\"\nregexp $y test",
3031:                 D,
3032:                 "T102",
3033:             )
3034:             .is_empty()
3035:         );
3036:     }
3037: 
3038:     #[test]
3039:     fn literal_dash_prefix_warns() {
3040:         // `-${x}` starts with `-` → T102 fires.
3041:         let ws = of_code(
3042:             "set x [HTTP::header Host]\nset y \"-${x}\"\nregexp $y test",
3043:             D,
3044:             "T102",
3045:         );
3046:         assert!(!ws.is_empty());
3047:     }
3048: 
3049:     #[test]
3050:     fn dynamic_leading_piece_inherits_original() {
3051:         // Lattice-join identity: `${uri}/suffix` inherits PATH_PREFIXED and
3052:         // suppresses T102 — clean is the join identity, so the interpolation
3053:         // does not drop the colour.
3054:         assert!(
3055:             of_code(
3056:                 "set uri [HTTP::uri]\nset z ${uri}/suffix\nregexp $z test",
3057:                 D,
3058:                 "T102",
3059:             )
3060:             .is_empty()
3061:         );
3062:     }
3063: 
3064:     #[test]
3065:     fn command_subst_prefix() {
3066:         // `path_[HTTP::path]` starts with `p` → NON_DASH_PREFIXED.
3067:         assert!(of_code("set z \"path_[HTTP::path]\"\nregexp $z test", D, "T102").is_empty());
3068:     }
3069: }
3070: 
3071: // Colour-aware interprocedural propagation.
3072: // f5-dialect helpers.
3073: mod interprocedural_colours {
3074:     use super::*;
3075: 
3076:     #[test]
3077:     fn helper_returning_uri_encode_suppresses_irule3003() {
3078:         // A proc that returns `[URI::encode $x]` returns a CRLF_FREE
3079:         // value, so the caller's `log local0. $safe` is IRULE3003-suppressed.
3080:         let source = "proc encode_it {x} { return [URI::encode $x] }\nset raw [HTTP::query]\nset safe [encode_it $raw]\nlog local0. $safe\n";
3081:         // FIXED (lattice-join identity): the return summary joins the helper's
3082:         // CRLF_FREE scenario onto a clean base; with clean now the join identity
3083:         // the colour survives into the caller's `$safe`, so IRULE3003 stays
3084:         // suppressed.
3085:         assert!(of_code(source, IR, "IRULE3003").is_empty());
3086:     }
3087: 
3088:     #[test]
3089:     fn helper_returning_html_encode_suppresses_irule3001() {
3090:         // A proc returning `[HTML::encode $x]` returns HTML_ESCAPED →
3091:         // caller's HTTP::respond is IRULE3001-suppressed.
3092:         let source = "proc html_safe {x} { return [HTML::encode $x] }\nset raw [HTTP::query]\nset safe [html_safe $raw]\nHTTP::respond 200 content $safe\n";
3093:         // FIXED (lattice-join identity): the HTML_ESCAPED return scenario now
3094:         // survives the summary join into the caller, so IRULE3001 stays
3095:         // suppressed.
3096:         assert!(of_code(source, IR, "IRULE3001").is_empty());
3097:     }
3098: 
3099:     #[test]
3100:     fn helper_passthrough_generic_taint_fires_t102() {
3101:         let source = "proc identity {x} { return $x }\nset raw [read $fd]\nset x [identity $raw]\nregexp $x test\n";
3102:         assert!(!of_code(source, D, "T102").is_empty());
3103:     }
3104: 
3105:     #[test]
3106:     fn helper_list_wrapper_eval_still_fires() {
3107:         // tclsh: even via a helper, `eval [list $x]` runs $x as the command word.
3108:         let source = "proc wrap_list {x} { return [list $x] }\nset raw [read $fd]\nset lst [wrap_list $raw]\neval $lst\n";
3109:         let ws = of_code(source, D, "T100");
3110:         assert!(!ws.is_empty());
3111:         assert!(ws.iter().any(|w| w.sink_command == "eval"));
3112:     }
3113: 
3114:     #[test]
3115:     fn helper_list_wrapper_still_tainted() {
3116:         let source = "proc wrap_list {x} { return [list $x] }\nset raw [read $fd]\nset lst [wrap_list $raw]\nputs $lst\n";
3117:         assert!(!of_code(source, D, "T101").is_empty());
3118:     }
3119: 
3120:     #[test]
3121:     fn helper_with_ip_addr_param_augmented() {
3122:         // Passing an IP_ADDRESS (CRLF_FREE) value into a helper that
3123:         // logs it keeps the colour at the parameter, so IRULE3003 is suppressed.
3124:         let source =
3125:             "proc log_addr {addr} { log local0. $addr }\nset a [IP::client_addr]\nlog_addr $a\n";
3126:         // Passing an IP_ADDRESS (CRLF_FREE) value into a helper that logs it
3127:         // must keep the colour at the parameter, so the in-helper
3128:         // `log local0. $addr` is IRULE3003-suppressed.
3129:         assert!(of_code(source, IR, "IRULE3003").is_empty());
3130:     }
3131: }
3132: 
3133: // Structural colours stripped on
3134: // interpolation; CRLF_FREE preserved (no literal CRLF). f5-dialect sources.
3135: mod interpolation_colour_invalidation {
3136:     use super::*;
3137: 
3138:     #[test]
3139:     fn list_canonical_stripped() {
3140:         // `[list [read $fd]]` is tainted (LIST_CANONICAL), the
3141:         // interpolation `"pre $x suf"` strips that colour, and the now-generic
3142:         // tainted `$y` fires T100 at eval.
3143:         let source = "set x [list [read $fd]]\nset y \"pre $x suf\"\neval $y";
3144:         // FIXED: parse_command_substitution now splits args respecting `[...]`
3145:         // nesting, so the `read` source nested inside `[list [read $fd]]` is
3146:         // recovered, `$x`/`$y` are tainted, and T100 fires at `eval $y`.
3147:         assert!(!of_code(source, D, "T100").is_empty());
3148:     }
3149: 
3150:     #[test]
3151:     fn path_normalised_stripped() {
3152:         // `[file normalize [read $fd]]` is tainted; interpolation
3153:         // strips PATH_NORMALISED and T100 fires at eval.
3154:         let source = "set x [file normalize [read $fd]]\nset y \"pre $x\"\neval $y";
3155:         // FIXED: the `read` source nested inside `[file normalize [read $fd]]`
3156:         // is now recovered (nesting-aware arg split), so T100 fires at eval.
3157:         assert!(!of_code(source, D, "T100").is_empty());
3158:     }
3159: 
3160:     #[test]
3161:     fn html_escaped_stripped() {
3162:         let source = "set raw [HTTP::query]\nset safe [HTML::encode $raw]\nset broken \"<b>$safe</b>\"\nHTTP::respond 200 content $broken";
3163:         assert!(!of_code(source, IR, "IRULE3001").is_empty());
3164:     }
3165: 
3166:     #[test]
3167:     fn url_encoded_stripped() {
3168:         let source = "set raw [read $fd]\nset enc [URI::encode $raw]\nset y \"pre$enc\"\neval $y";
3169:         assert!(!of_code(source, D, "T100").is_empty());
3170:     }
3171: 
3172:     #[test]
3173:     fn regex_literal_stripped() {
3174:         let source = "set raw [read $fd]\nset q [regex::quote $raw]\nset y \"^$q\"\neval $y";
3175:         assert!(!of_code(source, D, "T100").is_empty());
3176:     }
3177: 
3178:     #[test]
3179:     fn shell_atom_stripped() {
3180:         let source = "set addr [IP::client_addr]\nset y \"host:$addr\"\neval $y";
3181:         assert!(!of_code(source, D, "T100").is_empty());
3182:     }
3183: 
3184:     #[test]
3185:     fn crlf_free_preserved_without_literal_crlf() {
3186:         let source = "set addr [IP::client_addr]\nset msg \"client:${addr}\"\nlog local0. $msg";
3187:         // FIXED (lattice-join identity): CRLF_FREE survives the interpolation, so
3188:         // IRULE3003 stays suppressed.
3189:         assert!(of_code(source, IR, "IRULE3003").is_empty());
3190:     }
3191: }
3192: 
3193: // Transforms on untainted input stay clean;
3194: // concat of mixed canonicality still propagates taint. f5-dialect sources.
3195: mod transform_colour_edge_cases {
3196:     use super::*;
3197: 
3198:     #[test]
3199:     fn list_with_literal_untainted() {
3200:         // [list hello] is untainted → eval is clean.
3201:         assert!(of_code("set x [list hello]\neval $x", D, "T100").is_empty());
3202:     }
3203: 
3204:     #[test]
3205:     fn concat_of_mixed_canonicality() {
3206:         let source = "set raw [read $fd]\nset a [list $raw]\nset b [read $fd2]\nset c [concat $a $b]\neval $c";
3207:         assert!(!of_code(source, D, "T100").is_empty());
3208:     }
3209: 
3210:     #[test]
3211:     fn uri_encode_with_untainted_no_colour() {
3212:         // f5-dialect: URI::encode on untainted data is still untainted.
3213:         assert!(of_code("set enc [URI::encode \"hello\"]\neval $enc", D, "T100").is_empty());
3214:     }
3215: 
3216:     #[test]
3217:     fn file_normalize_with_untainted_no_colour() {
3218:         assert!(
3219:             of_code(
3220:                 "set norm [file normalize \"/tmp/foo\"]\neval $norm",
3221:                 D,
3222:                 "T100"
3223:             )
3224:             .is_empty()
3225:         );
3226:     }
3227: }
3228: 
3229: // The colour→diagnostic suppression matrix.
3230: // f5-dialect sources.
3231: mod sink_suppression_matrix {
3232:     use super::*;
3233: 
3234:     #[test]
3235:     fn irule3001_not_suppressed_by_crlf_free() {
3236:         // URL_ENCODED/CRLF_FREE does NOT suppress IRULE3001 (XSS).
3237:         let source =
3238:             "set raw [HTTP::query]\nset enc [URI::encode $raw]\nHTTP::respond 200 content $enc";
3239:         assert!(!of_code(source, IR, "IRULE3001").is_empty());
3240:     }
3241: 
3242:     #[test]
3243:     fn irule3001_suppressed_by_html_escaped() {
3244:         let source =
3245:             "set raw [HTTP::query]\nset enc [HTML::encode $raw]\nHTTP::respond 200 content $enc";
3246:         assert!(of_code(source, IR, "IRULE3001").is_empty());
3247:     }
3248: 
3249:     #[test]
3250:     fn irule3002_suppressed_by_ip_address() {
3251:         let source = "set addr [IP::client_addr]\nHTTP::header insert X-Client $addr";
3252:         assert!(of_code(source, IR, "IRULE3002").is_empty());
3253:     }
3254: 
3255:     #[test]
3256:     fn irule3002_suppressed_by_port() {
3257:         let source = "set port [TCP::client_port]\nHTTP::header insert X-Port $port";
3258:         assert!(of_code(source, IR, "IRULE3002").is_empty());
3259:     }
3260: 
3261:     #[test]
3262:     fn irule3003_suppressed_by_fqdn() {
3263:         let source = "set sni [SSL::sni]\nlog local0. $sni";
3264:         assert!(of_code(source, IR, "IRULE3003").is_empty());
3265:     }
3266: 
3267:     #[test]
3268:     fn t102_not_suppressed_by_crlf_free() {
3269:         let source = "set raw [read $fd]\nset enc [URI::encode $raw]\nregexp $enc test";
3270:         assert!(!of_code(source, D, "T102").is_empty());
3271:     }
3272: 
3273:     #[test]
3274:     fn t102_not_suppressed_by_html_escaped() {
3275:         let source = "set raw [read $fd]\nset enc [HTML::encode $raw]\nregexp $enc test";
3276:         assert!(!of_code(source, D, "T102").is_empty());
3277:     }
3278: 
3279:     #[test]
3280:     fn t100_not_suppressed_by_path_prefixed() {
3281:         let source = "set raw [HTTP::uri]\neval $raw";
3282:         assert!(!of_code(source, D, "T100").is_empty());
3283:     }
3284: }
3285: 
3286: // TestT100SinkSuppression — exec+SHELL_ATOM and eval+literal-[list-head]
3287: // suppress T100; generic taint and propagated lists do not.
3288: //
3289: // tclsh facts (8.6 + 9.0):
3290: //   * `eval [list puts $raw]` → prints `marker` (puts is the cmd word; $raw is
3291: //     its argument) → suppressed.
3292: //   * `eval [list $raw]`      → prints `EXECUTED` ($raw becomes the cmd word) →
3293: //     fires.
3294: mod t100_sink_suppression {
3295:     use super::*;
3296: 
3297:     #[test]
3298:     fn exec_with_shell_atom_suppressed() {
3299:         // f5-dialect: IP::client_addr → IP_ADDRESS augments to SHELL_ATOM, which
3300:         // suppresses T100 for `exec` (a shell atom can't word-split).
3301:         let source = "set addr [IP::client_addr]\nexec ping $addr";
3302:         // FIXED: emit_sink_warnings now consults the registry's
3303:         // taint_sink_safe_colour — exec's SHELL_ATOM (augmented from IP_ADDRESS)
3304:         // suppresses T100 (an IP atom can't word-split an exec argument).
3305:         assert!(of_code(source, IR, "T100").is_empty());
3306:     }
3307: 
3308:     #[test]
3309:     fn exec_with_generic_taint_not_suppressed() {
3310:         let source = "set raw [read $fd]\nexec echo $raw";
3311:         assert!(!of_code(source, D, "T100").is_empty());
3312:     }
3313: 
3314:     #[test]
3315:     fn eval_with_list_canonical_fires() {
3316:         // tclsh: `eval [list $raw]` runs $raw as the command word.
3317:         let source = "set raw [read $fd]\nset safe [list $raw]\neval $safe";
3318:         let ws = of_code(source, D, "T100");
3319:         assert!(!ws.is_empty());
3320:         assert!(ws.iter().any(|w| w.sink_command == "eval"));
3321:     }
3322: 
3323:     #[test]
3324:     fn eval_with_generic_taint_not_suppressed() {
3325:         let source = "set raw [read $fd]\neval $raw";
3326:         assert!(!of_code(source, D, "T100").is_empty());
3327:     }
3328: 
3329:     #[test]
3330:     fn uplevel_with_list_canonical_fires() {
3331:         // tclsh: same hazard as eval — uplevel runs the substituted $raw.
3332:         let source = "set raw [read $fd]\nset safe [list $raw]\nuplevel $safe";
3333:         let ws = of_code(source, D, "T100");
3334:         assert!(!ws.is_empty());
3335:         assert!(ws.iter().any(|w| w.sink_command == "uplevel"));
3336:     }
3337: 
3338:     #[test]
3339:     fn eval_with_literal_list_known_head_suppressed() {
3340:         // tclsh: `eval [list puts $raw]` → prints `marker`; $raw is the ARG, not
3341:         // the cmd word → no code-execution vector → T100 suppressed.
3342:         let source = "set raw [read $fd]\neval [list puts $raw]";
3343:         assert!(of_code(source, D, "T100").is_empty());
3344:     }
3345: 
3346:     #[test]
3347:     fn eval_with_literal_list_tainted_head_fires() {
3348:         // tclsh: `eval [list $raw]` → $raw becomes the cmd word → T100 fires.
3349:         let source = "set raw [read $fd]\neval [list $raw]";
3350:         let ws = of_code(source, D, "T100");
3351:         assert!(!ws.is_empty());
3352:         assert!(ws.iter().any(|w| w.sink_command == "eval"));
3353:     }
3354: 
3355:     #[test]
3356:     fn uplevel_with_generic_taint_not_suppressed() {
3357:         let source = "set raw [read $fd]\nuplevel $raw";
3358:         assert!(!of_code(source, D, "T100").is_empty());
3359:     }
3360: 
3361:     #[test]
3362:     fn subst_not_suppressed_by_shell_atom() {
3363:         // subst is never suppressed by SHELL_ATOM.
3364:         let source = "set addr [IP::client_addr]\nsubst $addr";
3365:         assert!(!of_code(source, IR, "T100").is_empty());
3366:     }
3367: 
3368:     #[test]
3369:     fn expr_not_suppressed_by_list_canonical() {
3370:         let source = "set raw [read $fd]\nset safe [list $raw]\nexpr $safe";
3371:         assert!(!of_code(source, D, "T100").is_empty());
3372:     }
3373: 
3374:     #[test]
3375:     fn exec_with_port_suppressed() {
3376:         // f5-dialect: PORT augments to SHELL_ATOM → suppresses exec T100.
3377:         let source = "set port [TCP::client_port]\nexec firewall-cmd $port";
3378:         // FIXED: exec's SHELL_ATOM safe colour (augmented from PORT) now
3379:         // suppresses T100.
3380:         assert!(of_code(source, IR, "T100").is_empty());
3381:     }
3382: }
3383: 
3384: // TestT103RegexpPatternInjection — tainted data in a regexp/regsub pattern.
3385: //
3386: // tclsh: the pattern argument of regexp/regsub is compiled as a regex; a tainted
3387: // pattern is a regex-injection / ReDoS vector. The string (subject) position is
3388: // not a pattern → no T103. REGEX_LITERAL (regex::quote) suppresses.
3389: mod t103_regexp_pattern_injection {
3390:     use super::*;
3391: 
3392:     #[test]
3393:     fn tainted_regexp_pattern_fires() {
3394:         let ws = of_code("set pat [read $fd]\nregexp $pat teststring", D, "T103");
3395:         assert!(!ws.is_empty());
3396:         assert_eq!(ws[0].code.to_string(), "T103");
3397:     }
3398: 
3399:     #[test]
3400:     fn tainted_regsub_pattern_fires() {
3401:         let ws = of_code(
3402:             "set pat [read $fd]\nregsub $pat teststring replacement",
3403:             D,
3404:             "T103",
3405:         );
3406:         assert!(!ws.is_empty());
3407:     }
3408: 
3409:     #[test]
3410:     fn tainted_regexp_with_options_fires() {
3411:         let ws = of_code(
3412:             "set pat [read $fd]\nregexp -nocase -- $pat teststring",
3413:             D,
3414:             "T103",
3415:         );
3416:         assert!(!ws.is_empty());
3417:     }
3418: 
3419:     #[test]
3420:     fn regex_literal_suppresses_t103() {
3421:         let source = "set raw [read $fd]\nset safe [regex::quote $raw]\nregexp $safe teststring";
3422:         assert!(of_code(source, D, "T103").is_empty());
3423:     }
3424: 
3425:     #[test]
3426:     fn braced_regexp_argument_is_not_a_tainted_pattern() {
3427:         assert!(
3428:             of_code("set x [read $fd]\nregexp {$x} literal", D, "T103").is_empty(),
3429:             "a braced dollar spelling is a literal regular expression, not a tainted use"
3430:         );
3431:     }
3432: 
3433:     #[test]
3434:     fn untainted_regexp_no_warning() {
3435:         assert!(of_code("regexp {^[a-z]+$} teststring", D, "T103").is_empty());
3436:     }
3437: 
3438:     #[test]
3439:     fn tainted_non_pattern_arg_no_t103() {
3440:         // tclsh: $input is the subject (string) position, not the pattern.
3441:         assert!(of_code("set input [read $fd]\nregexp {^\\d+$} $input", D, "T103").is_empty());
3442:     }
3443: 
3444:     #[test]
3445:     fn tainted_regsub_with_options_fires() {
3446:         let ws = of_code(
3447:             "set pat [read $fd]\nregsub -all -nocase -- $pat teststring replacement",
3448:             D,
3449:             "T103",
3450:         );
3451:         assert!(!ws.is_empty());
3452:     }
3453: 
3454:     #[test]
3455:     fn t103_message_format() {
3456:         let ws = of_code("set pat [read $fd]\nregexp $pat teststring", D, "T103");
3457:         assert!(!ws.is_empty());
3458:         assert!(ws[0].message.contains("pat"));
3459:         assert!(ws[0].message.contains("regexp") || ws[0].message.to_lowercase().contains("regex"));
3460:     }
3461: }
3462: 
3463: // PATH_NORMALISED / PATH_PREFIXED satisfy
3464: // the IRULE3101 setter constraint. f5-dialect.
3465: mod path_normalised_setter_constraint {
3466:     use super::*;
3467: 
3468:     #[test]
3469:     fn path_normalised_suppresses_irule3101() {
3470:         let source = "set raw [HTTP::uri]\nset norm [file normalize $raw]\nHTTP::uri $norm";
3471:         assert!(of_code(source, IR, "IRULE3101").is_empty());
3472:     }
3473: 
3474:     #[test]
3475:     fn generic_taint_still_fires_irule3101() {
3476:         let source = "set raw [HTTP::query]\nHTTP::uri $raw";
3477:         assert!(!of_code(source, IR, "IRULE3101").is_empty());
3478:     }
3479: 
3480:     #[test]
3481:     fn path_prefixed_still_suppresses_irule3101() {
3482:         let source = "set path [HTTP::path]\nHTTP::uri $path";
3483:         assert!(of_code(source, IR, "IRULE3101").is_empty());
3484:     }
3485: }
3486: 
3487: // HTTP::redirect with a tainted URL. f5-dialect.
3488: // PATH_PREFIXED / PATH_NORMALISED (same-origin) suppress; HTML_ESCAPED does not.
3489: mod irule3004_open_redirect {
3490:     use super::*;
3491: 
3492:     #[test]
3493:     fn tainted_redirect_fires() {
3494:         let ws = of_code(
3495:             "set dest [HTTP::query]\nHTTP::redirect $dest",
3496:             IR,
3497:             "IRULE3004",
3498:         );
3499:         assert!(!ws.is_empty());
3500:         assert!(ws[0].message.to_lowercase().contains("redirect"));
3501:     }
3502: 
3503:     #[test]
3504:     fn tainted_header_redirect_fires() {
3505:         let ws = of_code(
3506:             "set url [HTTP::header value Redirect-To]\nHTTP::redirect $url",
3507:             IR,
3508:             "IRULE3004",
3509:         );
3510:         assert!(!ws.is_empty());
3511:     }
3512: 
3513:     #[test]
3514:     fn path_prefixed_suppresses_irule3004() {
3515:         let source = "set p [HTTP::path]\nHTTP::redirect $p";
3516:         assert!(of_code(source, IR, "IRULE3004").is_empty());
3517:     }
3518: 
3519:     #[test]
3520:     fn path_normalised_suppresses_irule3004() {
3521:         let source = "set raw [HTTP::query]\nset norm [file normalize $raw]\nHTTP::redirect $norm";
3522:         assert!(of_code(source, IR, "IRULE3004").is_empty());
3523:     }
3524: 
3525:     #[test]
3526:     fn html_escaped_does_not_suppress_irule3004() {
3527:         // HTML_ESCAPED is the wrong encoding for a redirect target.
3528:         let source = "set raw [HTTP::query]\nset safe [HTML::encode $raw]\nHTTP::redirect $safe";
3529:         assert!(!of_code(source, IR, "IRULE3004").is_empty());
3530:     }
3531: 
3532:     #[test]
3533:     fn literal_redirect_clean() {
3534:         assert!(
3535:             of_code(
3536:                 "HTTP::redirect \"https://example.com/home\"",
3537:                 IR,
3538:                 "IRULE3004"
3539:             )
3540:             .is_empty()
3541:         );
3542:     }
3543: 
3544:     #[test]
3545:     fn not_in_tcl86() {
3546:         assert!(of_code("set dest [read $fd]\nHTTP::redirect $dest", D, "IRULE3004").is_empty());
3547:     }
3548: 
3549:     #[test]
3550:     fn message_format() {
3551:         let ws = of_code(
3552:             "set url [HTTP::query]\nHTTP::redirect $url",
3553:             IR,
3554:             "IRULE3004",
3555:         );
3556:         assert!(!ws.is_empty());
3557:         assert!(ws[0].message.contains("$url"));
3558:         assert!(ws[0].message.contains("HTTP::redirect"));
3559:     }
3560: }
3561: 
3562: // TestT106DoubleEncoding — re-encoding already-encoded data fires T106;
3563: // cross-encode / first-encode / untainted do not. f5-dialect encoders.
3564: mod t106_double_encoding {
3565:     use super::*;
3566: 
3567:     #[test]
3568:     fn double_html_encode() {
3569:         let source =
3570:             "set raw [read $fd]\nset safe [HTML::encode $raw]\nset double [HTML::encode $safe]";
3571:         let ws = of_code(source, IR, "T106");
3572:         assert!(!ws.is_empty());
3573:         assert!(ws[0].message.contains("HTML-escaped"));
3574:     }
3575: 
3576:     #[test]
3577:     fn double_uri_encode() {
3578:         let source =
3579:             "set raw [read $fd]\nset enc [URI::encode $raw]\nset double [URI::encode $enc]";
3580:         let ws = of_code(source, IR, "T106");
3581:         assert!(!ws.is_empty());
3582:         assert!(ws[0].message.contains("URL-encoded"));
3583:     }
3584: 
3585:     #[test]
3586:     fn double_regex_quote() {
3587:         let source =
3588:             "set raw [read $fd]\nset esc [regex::quote $raw]\nset double [regex::quote $esc]";
3589:         let ws = of_code(source, IR, "T106");
3590:         assert!(!ws.is_empty());
3591:         assert!(ws[0].message.contains("regex-escaped"));
3592:     }
3593: 
3594:     #[test]
3595:     fn cross_encode_no_fire() {
3596:         // HTML::encode on URL_ENCODED data is a different colour → no T106.
3597:         let source = "set raw [read $fd]\nset enc [URI::encode $raw]\nset html [HTML::encode $enc]";
3598:         assert!(of_code(source, IR, "T106").is_empty());
3599:     }
3600: 
3601:     #[test]
3602:     fn first_encode_no_fire() {
3603:         let source = "set raw [read $fd]\nset safe [HTML::encode $raw]";
3604:         assert!(of_code(source, IR, "T106").is_empty());
3605:     }
3606: 
3607:     #[test]
3608:     fn double_encode_through_copy() {
3609:         let source = "set raw [read $fd]\nset enc [URI::encode $raw]\nset copy $enc\nset double [URI::encode $copy]";
3610:         assert!(!of_code(source, IR, "T106").is_empty());
3611:     }
3612: 
3613:     #[test]
3614:     fn double_encode_nested_no_intermediate_fires() {
3615:         // FN fix: `URI::encode [URI::encode $raw]` — the inner encoder's result
3616:         // never lands on a named variable, so the argument-word scan catches
3617:         // it where the named-uses loop could not.
3618:         let source = "set raw [read $fd]\nset double [URI::encode [URI::encode $raw]]";
3619:         assert!(!of_code(source, IR, "T106").is_empty());
3620:     }
3621: 
3622:     #[test]
3623:     fn single_encode_nested_no_fire() {
3624:         // A single nested encode does not double-encode.
3625:         let source = "set raw [read $fd]\nset once [URI::encode $raw]";
3626:         assert!(of_code(source, IR, "T106").is_empty());
3627:     }
3628: 
3629:     #[test]
3630:     fn untainted_no_fire() {
3631:         // Literal data through an encoder does not fire T106.
3632:         let source = "set x [HTML::encode \"hello\"]\nset y [HTML::encode $x]";
3633:         assert!(of_code(source, IR, "T106").is_empty());
3634:     }
3635: 
3636:     #[test]
3637:     fn braced_encoder_argument_is_not_a_second_encoding() {
3638:         let source = "set raw [read $fd]\nset x [URI::encode $raw]\nURI::encode {$x}";
3639:         assert!(
3640:             of_code(source, IR, "T106").is_empty(),
3641:             "a braced dollar spelling is literal data, not a second use of the encoded variable"
3642:         );
3643:     }
3644: 
3645:     #[test]
3646:     fn message_format() {
3647:         let source = "set raw [read $fd]\nset enc [HTML::encode $raw]\nset dup [HTML::encode $enc]";
3648:         let ws = of_code(source, IR, "T106");
3649:         assert!(!ws.is_empty());
3650:         assert!(ws[0].message.contains("$enc"));
3651:         assert!(ws[0].message.contains("HTML::encode"));
3652:         assert!(ws[0].message.contains("HTML-escaped"));
3653:     }
3654: }
3655: 
3656: // TestT104NetworkSinks — tainted data in a network-address argument (SSRF).
3657: // `socket` / `http::geturl` are core-tclsh commands.
3658: mod t104_network_sinks {
3659:     use super::*;
3660: 
3661:     #[test]
3662:     fn socket_tainted_host() {
3663:         let ws = of_code("set host [read $fd]\nsocket $host 80", D, "T104");
3664:         assert!(!ws.is_empty());
3665:         assert!(ws.iter().any(|w| w.sink_command == "socket"));
3666:     }
3667: 
3668:     #[test]
3669:     fn socket_literal_clean() {
3670:         assert!(of_code("socket localhost 80", D, "T104").is_empty());
3671:     }
3672: 
3673:     #[test]
3674:     fn http_geturl_tainted_url() {
3675:         let ws = of_code("set url [read $fd]\nhttp::geturl $url", D, "T104");
3676:         assert!(!ws.is_empty());
3677:         assert!(ws.iter().any(|w| w.sink_command == "http::geturl"));
3678:     }
3679: 
3680:     #[test]
3681:     fn http_geturl_literal_clean() {
3682:         assert!(of_code("http::geturl \"http://example.com\"", D, "T104").is_empty());
3683:     }
3684: 
3685:     #[test]
3686:     fn socket_propagation_through_copy() {
3687:         let ws = of_code(
3688:             "set host [read $fd]\nset h2 $host\nsocket $h2 443",
3689:             D,
3690:             "T104",
3691:         );
3692:         assert!(ws.iter().any(|w| w.variable == "h2"));
3693:     }
3694: 
3695:     #[test]
3696:     fn message_format() {
3697:         let ws = of_code("set host [read $fd]\nsocket $host 80", D, "T104");
3698:         assert!(!ws.is_empty());
3699:         let msg = &ws[0].message;
3700:         assert!(msg.contains("SSRF"));
3701:         assert!(msg.contains("socket"));
3702:     }
3703: }
3704: 
3705: // TestT105InterpEvalSinks — tainted data in an interp eval/invokehidden script.
3706: // `interp eval` is a core-tclsh command. LIST_CANONICAL does NOT suppress; a
3707: // literal [list <known-cmd> …] head does (same tclsh facts as the eval cases).
3708: mod t105_interp_eval_sinks {
3709:     use super::*;
3710: 
3711:     #[test]
3712:     fn interp_eval_tainted() {
3713:         let ws = of_code(
3714:             "set script [read $fd]\ninterp eval $child $script",
3715:             D,
3716:             "T105",
3717:         );
3718:         assert!(!ws.is_empty());
3719:         assert!(ws.iter().any(|w| w.sink_command.contains("interp eval")));
3720:     }
3721: 
3722:     #[test]
3723:     fn interp_eval_literal_clean() {
3724:         assert!(of_code("interp eval $child \"puts hello\"", D, "T105").is_empty());
3725:     }
3726: 
3727:     #[test]
3728:     fn interp_invokehidden_tainted() {
3729:         let ws = of_code(
3730:             "set cmd [read $fd]\ninterp invokehidden $child $cmd",
3731:             D,
3732:             "T105",
3733:         );
3734:         assert!(!ws.is_empty());
3735:     }
3736: 
3737:     #[test]
3738:     fn list_does_not_suppress_t105() {
3739:         // tclsh: same hazard as eval — the child re-parses $safe and the first
3740:         // list element becomes the command word.
3741:         let source = "set x [read $fd]\nset safe [list $x]\ninterp eval $child $safe";
3742:         let ws = of_code(source, D, "T105");
3743:         assert!(!ws.is_empty());
3744:         assert!(ws.iter().any(|w| w.sink_command == "interp eval"));
3745:     }
3746: 
3747:     #[test]
3748:     fn interp_eval_literal_list_known_head_suppressed() {
3749:         // tclsh: literal `[list puts $x]` → puts is the cmd word, $x the arg.
3750:         let source = "set x [read $fd]\ninterp eval $child [list puts $x]";
3751:         assert!(of_code(source, D, "T105").is_empty());
3752:     }
3753: 
3754:     #[test]
3755:     fn message_format() {
3756:         let ws = of_code("set data [read $fd]\ninterp eval $child $data", D, "T105");
3757:         assert!(!ws.is_empty());
3758:         let msg = &ws[0].message;
3759:         assert!(msg.contains("interp eval"));
3760:         assert!(msg.to_lowercase().contains("injection"));
3761:     }
3762: }
3763: 
3764: // Splitting HTTP::uri on `?` / `&` instead of using
3765: // HTTP::path / HTTP::query. f5-dialect.
3766: mod irule3103_uri_split {
3767:     use super::*;
3768: 
3769:     #[test]
3770:     fn split_uri_on_question_mark() {
3771:         let ws = of_code(
3772:             "set uri [HTTP::uri]\nset parts [split $uri \"?\"]",
3773:             IR,
3774:             "IRULE3103",
3775:         );
3776:         assert_eq!(ws.len(), 1);
3777:         assert!(ws[0].message.contains("HTTP::path"));
3778:         assert!(ws[0].message.contains("HTTP::query"));
3779:     }
3780: 
3781:     #[test]
3782:     fn split_uri_on_ampersand() {
3783:         let ws = of_code(
3784:             "set uri [HTTP::uri]\nset parts [split $uri \"&\"]",
3785:             IR,
3786:             "IRULE3103",
3787:         );
3788:         assert_eq!(ws.len(), 1);
3789:         assert!(ws[0].message.contains("HTTP::query"));
3790:     }
3791: 
3792:     #[test]
3793:     fn split_uri_on_question_and_ampersand() {
3794:         let ws = of_code(
3795:             "set uri [HTTP::uri]\nset parts [split $uri \"?&\"]",
3796:             IR,
3797:             "IRULE3103",
3798:         );
3799:         assert_eq!(ws.len(), 1);
3800:         assert!(ws[0].message.contains("HTTP::path"));
3801:         assert!(ws[0].message.contains("HTTP::query"));
3802:     }
3803: 
3804:     #[test]
3805:     fn inline_command_substitution() {
3806:         let ws = of_code("set parts [split [HTTP::uri] \"?\"]", IR, "IRULE3103");
3807:         assert_eq!(ws.len(), 1);
3808:     }
3809: 
3810:     #[test]
3811:     fn split_non_uri_clean() {
3812:         let ws = of_code(
3813:             "set x \"foo?bar\"\nset parts [split $x \"?\"]",
3814:             IR,
3815:             "IRULE3103",
3816:         );
3817:         assert!(ws.is_empty());
3818:     }
3819: 
3820:     #[test]
3821:     fn split_http_path_clean() {
3822:         let ws = of_code(
3823:             "set p [HTTP::path]\nset parts [split $p \"?\"]",
3824:             IR,
3825:             "IRULE3103",
3826:         );
3827:         assert!(ws.is_empty());
3828:     }
3829: 
3830:     #[test]
3831:     fn split_uri_on_slash_clean() {
3832:         let ws = of_code(
3833:             "set uri [HTTP::uri]\nset parts [split $uri \"/\"]",
3834:             IR,
3835:             "IRULE3103",
3836:         );
3837:         assert!(ws.is_empty());
3838:     }
3839: 
3840:     #[test]
3841:     fn copy_propagation() {
3842:         let ws = of_code(
3843:             "set uri [HTTP::uri]\nset copy $uri\nset parts [split $copy \"?\"]",
3844:             IR,
3845:             "IRULE3103",
3846:         );
3847:         assert_eq!(ws.len(), 1);
3848:     }
3849: 
3850:     #[test]
3851:     fn tcl_dialect_clean() {
3852:         let ws = of_code("set x \"foo\"\nset parts [split $x \"?\"]", D, "IRULE3103");
3853:         assert!(ws.is_empty());
3854:     }
3855: 
3856:     #[test]
3857:     fn uri_setter_not_flagged() {
3858:         // The HTTP::uri setter form (with arg) is not a getter origin.
3859:         let ws = of_code(
3860:             "HTTP::uri \"/new\"\nset parts [split [HTTP::uri /path] \"?\"]",
3861:             IR,
3862:             "IRULE3103",
3863:         );
3864:         assert!(ws.is_empty());
3865:     }
3866: }
3867: 
3868: // Expression operators on HTTP::uri suggesting
3869: // HTTP::path / HTTP::query. f5-dialect.
3870: mod irule3103_expr_operators {
3871:     use super::*;
3872: 
3873:     #[test]
3874:     fn starts_with_path_pattern() {
3875:         let ws = of_code(
3876:             "if { [HTTP::uri] starts_with \"/api\" } { log local0. x }",
3877:             IR,
3878:             "IRULE3103",
3879:         );
3880:         assert_eq!(ws.len(), 1);
3881:         assert!(ws[0].message.contains("HTTP::path"));
3882:         assert!(ws[0].message.contains("starts_with"));
3883:     }
3884: 
3885:     #[test]
3886:     fn starts_with_via_variable() {
3887:         let ws = of_code(
3888:             "set uri [HTTP::uri]\nif { $uri starts_with \"/api\" } { log local0. x }",
3889:             IR,
3890:             "IRULE3103",
3891:         );
3892:         assert_eq!(ws.len(), 1);
3893:         assert!(ws[0].message.contains("HTTP::path"));
3894:     }
3895: 
3896:     #[test]
3897:     fn ends_with_extension() {
3898:         let ws = of_code(
3899:             "if { [HTTP::uri] ends_with \".html\" } { log local0. x }",
3900:             IR,
3901:             "IRULE3103",
3902:         );
3903:         assert_eq!(ws.len(), 1);
3904:         assert!(ws[0].message.contains("HTTP::path"));
3905:     }
3906: 
3907:     #[test]
3908:     fn contains_query_param() {
3909:         let ws = of_code(
3910:             "if { [HTTP::uri] contains \"&key=\" } { log local0. x }",
3911:             IR,
3912:             "IRULE3103",
3913:         );
3914:         assert_eq!(ws.len(), 1);
3915:         assert!(ws[0].message.contains("HTTP::query"));
3916:     }
3917: 
3918:     #[test]
3919:     fn contains_equals_query() {
3920:         let ws = of_code(
3921:             "if { [HTTP::uri] contains \"user=test\" } { log local0. x }",
3922:             IR,
3923:             "IRULE3103",
3924:         );
3925:         assert_eq!(ws.len(), 1);
3926:         assert!(ws[0].message.contains("HTTP::query"));
3927:     }
3928: 
3929:     #[test]
3930:     fn matches_glob_path() {
3931:         let ws = of_code(
3932:             "if { [HTTP::uri] matches_glob \"/api/*\" } { log local0. x }",
3933:             IR,
3934:             "IRULE3103",
3935:         );
3936:         assert_eq!(ws.len(), 1);
3937:         assert!(ws[0].message.contains("HTTP::path"));
3938:     }
3939: 
3940:     #[test]
3941:     fn matches_glob_query() {
3942:         let ws = of_code(
3943:             "if { [HTTP::uri] matches_glob \"*&key=*\" } { log local0. x }",
3944:             IR,
3945:             "IRULE3103",
3946:         );
3947:         assert_eq!(ws.len(), 1);
3948:         assert!(ws[0].message.contains("HTTP::query"));
3949:     }
3950: 
3951:     #[test]
3952:     fn non_uri_clean() {
3953:         let ws = of_code(
3954:             "set p [HTTP::path]\nif { $p starts_with \"/api\" } { log local0. x }",
3955:             IR,
3956:             "IRULE3103",
3957:         );
3958:         assert!(ws.is_empty());
3959:     }
3960: 
3961:     #[test]
3962:     fn ambiguous_operand_clean() {
3963:         let ws = of_code(
3964:             "if { [HTTP::uri] contains \"something\" } { log local0. x }",
3965:             IR,
3966:             "IRULE3103",
3967:         );
3968:         assert!(ws.is_empty());
3969:     }
3970: }
3971: 
3972: // string match / string first on HTTP::uri.
3973: // f5-dialect.
3974: mod irule3103_string_match {
3975:     use super::*;
3976: 
3977:     #[test]
3978:     fn string_match_path_pattern() {
3979:         let ws = of_code(
3980:             "set uri [HTTP::uri]\nset m [string match \"/api/*\" $uri]",
3981:             IR,
3982:             "IRULE3103",
3983:         );
3984:         assert_eq!(ws.len(), 1);
3985:         assert!(ws[0].message.contains("HTTP::path"));
3986:     }
3987: 
3988:     #[test]
3989:     fn string_match_query_pattern() {
3990:         let ws = of_code(
3991:             "set uri [HTTP::uri]\nset m [string match \"*&key=*\" $uri]",
3992:             IR,
3993:             "IRULE3103",
3994:         );
3995:         assert_eq!(ws.len(), 1);
3996:         assert!(ws[0].message.contains("HTTP::query"));
3997:     }
3998: 
3999:     #[test]
4000:     fn string_first_question_mark() {
4001:         let ws = of_code(
4002:             "set uri [HTTP::uri]\nset pos [string first \"?\" $uri]",
4003:             IR,
4004:             "IRULE3103",
4005:         );
4006:         assert_eq!(ws.len(), 1);
4007:         assert!(ws[0].message.contains("HTTP::path") || ws[0].message.contains("HTTP::query"));
4008:     }
4009: 
4010:     #[test]
4011:     fn string_match_non_uri_clean() {
4012:         let ws = of_code(
4013:             "set p [HTTP::path]\nset m [string match \"/api/*\" $p]",
4014:             IR,
4015:             "IRULE3103",
4016:         );
4017:         assert!(ws.is_empty());
4018:     }
4019: 
4020:     #[test]
4021:     fn string_match_ambiguous_pattern_clean() {
4022:         let ws = of_code(
4023:             "set uri [HTTP::uri]\nset m [string match \"*something*\" $uri]",
4024:             IR,
4025:             "IRULE3103",
4026:         );
4027:         assert!(ws.is_empty());
4028:     }
4029: 
4030:     #[test]
4031:     fn string_match_in_if_condition() {
4032:         let ws = of_code(
4033:             "set uri [HTTP::uri]\nif { [string match \"/static/*\" $uri] } { log local0. x }",
4034:             IR,
4035:             "IRULE3103",
4036:         );
4037:         assert_eq!(ws.len(), 1);
4038:         assert!(ws[0].message.contains("HTTP::path"));
4039:     }
4040: 
4041:     #[test]
4042:     fn string_first_in_if_condition() {
4043:         let ws = of_code(
4044:             "set uri [HTTP::uri]\nif { [string first \"?\" $uri] >= 0 } { log local0. x }",
4045:             IR,
4046:             "IRULE3103",
4047:         );
4048:         assert_eq!(ws.len(), 1);
4049:     }
4050: }
4051: 
4052: // glob/regex classifier edge cases and SSA correctness.
4053: // f5-dialect.
4054: //
4055: // tclsh-semantic premises (glob/regex metacharacter meanings): glob `?` is a
4056: // single-char wildcard (not a query delimiter); regex `?` is a quantifier; an
4057: // escaped `\?` / `\&` is a literal char (query signal). These are about how a
4058: // pattern's characters classify, not a runtime side-effect to observe.
4059: mod irule3103_edge_cases {
4060:     use super::*;
4061: 
4062:     #[test]
4063:     fn glob_question_mark_is_wildcard_not_query() {
4064:         // glob `??` is a wildcard; `/api/??` is path-like (starts with `/`).
4065:         let ws = of_code(
4066:             "set uri [HTTP::uri]\nset m [string match \"/api/??\" $uri]",
4067:             IR,
4068:             "IRULE3103",
4069:         );
4070:         assert_eq!(ws.len(), 1);
4071:         assert!(ws[0].message.contains("HTTP::path"));
4072:     }
4073: 
4074:     #[test]
4075:     fn glob_bare_question_not_query() {
4076:         // Bare `??` wildcard with no path prefix → ambiguous → no fire.
4077:         let ws = of_code(
4078:             "set uri [HTTP::uri]\nset m [string match \"??\" $uri]",
4079:             IR,
4080:             "IRULE3103",
4081:         );
4082:         assert!(ws.is_empty());
4083:     }
4084: 
4085:     #[test]
4086:     fn glob_question_path_with_wildcard() {
4087:         let ws = of_code(
4088:             "if { [HTTP::uri] matches_glob \"/api/?\" } { log local0. x }",
4089:             IR,
4090:             "IRULE3103",
4091:         );
4092:         assert_eq!(ws.len(), 1);
4093:         assert!(ws[0].message.contains("HTTP::path"));
4094:     }
4095: 
4096:     #[test]
4097:     fn regex_question_is_quantifier_not_query() {
4098:         // regex `?` is a quantifier; `/api/v[0-9]+/?` is path-like. Braced,
4099:         // because in quotes the `[0-9]` is a command substitution (#2227).
4100:         let ws = of_code(
4101:             "if { [HTTP::uri] matches_regex {^/api/v[0-9]+/?$} } { log local0. x }",
4102:             IR,
4103:             "IRULE3103",
4104:         );
4105:         assert_eq!(ws.len(), 1);
4106:         assert!(ws[0].message.contains("HTTP::path"));
4107:     }
4108: 
4109:     #[test]
4110:     fn regex_escaped_question_is_query() {
4111:         // regex `\?` is a literal `?` → query signal.
4112:         let ws = of_code(
4113:             "if { [HTTP::uri] matches_regex \"\\\\?key=\" } { log local0. x }",
4114:             IR,
4115:             "IRULE3103",
4116:         );
4117:         assert_eq!(ws.len(), 1);
4118:         assert!(ws[0].message.contains("HTTP::query"));
4119:     }
4120: 
4121:     #[test]
4122:     fn later_reassignment_no_false_positive() {
4123:         // $uri is "foo" at the expr check; reassigned to HTTP::uri afterwards.
4124:         let ws = of_code(
4125:             "set uri \"foo\"\nset ok [expr { $uri starts_with \"/api\" }]\nset uri [HTTP::uri]",
4126:             IR,
4127:             "IRULE3103",
4128:         );
4129:         assert!(ws.is_empty());
4130:     }
4131: 
4132:     #[test]
4133:     fn string_match_nocase_in_if_condition() {
4134:         let ws = of_code(
4135:             "set uri [HTTP::uri]\nif { [string match -nocase \"/STATIC/*\" $uri] } { log local0. x }",
4136:             IR,
4137:             "IRULE3103",
4138:         );
4139:         assert_eq!(ws.len(), 1);
4140:         assert!(ws[0].message.contains("HTTP::path"));
4141:     }
4142: 
4143:     #[test]
4144:     fn split_separator_from_constant_variable() {
4145:         // SCCP-resolved separator variable still triggers the split warning.
4146:         let ws = of_code(
4147:             "set uri [HTTP::uri]\nset sep \"?\"\nset parts [split $uri $sep]",
4148:             IR,
4149:             "IRULE3103",
4150:         );
4151:         assert_eq!(ws.len(), 1);
4152:         assert!(ws[0].message.contains("HTTP::path"));
4153:         assert!(ws[0].message.contains("HTTP::query"));
4154:     }
4155: 
4156:     #[test]
4157:     fn phi_mixed_uri_and_non_uri_no_warning() {
4158:         // Mixed-origin phi (URI + non-URI) → no warning.
4159:         let source = "set cond 0\nif { $cond } {\n    set candidate [HTTP::uri]\n} else {\n    set candidate \"/not-uri\"\n}\nset out [string match \"/api/*\" $candidate]";
4160:         assert!(of_code(source, IR, "IRULE3103").is_empty());
4161:     }
4162: 
4163:     #[test]
4164:     fn string_first_with_ampersand_in_if_condition() {
4165:         let ws = of_code(
4166:             "set uri [HTTP::uri]\nif { [string first \"&\" $uri] >= 0 } { log local0. x }",
4167:             IR,
4168:             "IRULE3103",
4169:         );
4170:         assert_eq!(ws.len(), 1);
4171:         assert!(ws[0].message.contains("HTTP::path"));
4172:         assert!(ws[0].message.contains("HTTP::query"));
4173:     }
4174: 
4175:     #[test]
4176:     fn split_separator_from_copied_constant_variable() {
4177:         let ws = of_code(
4178:             "set uri [HTTP::uri]\nset sep \"?\"\nset sep_copy $sep\nset parts [split $uri $sep_copy]",
4179:             IR,
4180:             "IRULE3103",
4181:         );
4182:         assert_eq!(ws.len(), 1);
4183:         assert!(ws[0].message.contains("HTTP::path"));
4184:         assert!(ws[0].message.contains("HTTP::query"));
4185:     }
4186: 
4187:     #[test]
4188:     fn nested_boolean_expression_emits_one_hit_per_uri_use() {
4189:         // One warning per concrete URI-pattern use.
4190:         let source = "set uri [HTTP::uri]\nif { ([string match \"/api/*\" $uri] && ([HTTP::uri] contains \"&id=\")) } {\n    log local0. ok\n}";
4191:         let ws = of_code(source, IR, "IRULE3103");
4192:         assert_eq!(ws.len(), 2);
4193:         let mut sinks: Vec<String> = ws.iter().map(|w| w.sink_command.clone()).collect();
4194:         sinks.sort();
4195:         assert_eq!(
4196:             sinks,
4197:             vec!["contains".to_string(), "string match".to_string()]
4198:         );
4199:     }
4200: 
4201:     #[test]
4202:     fn phi_both_branches_uri_still_warns() {
4203:         let source = "set cond 1\nif { $cond } {\n    set candidate [HTTP::uri]\n} else {\n    set tmp [HTTP::uri]\n    set candidate $tmp\n}\nset out [string match \"/api/*\" $candidate]";
4204:         let ws = of_code(source, IR, "IRULE3103");
4205:         assert_eq!(ws.len(), 1);
4206:         assert!(ws[0].message.contains("HTTP::path"));
4207:     }
4208: 
4209:     #[test]
4210:     fn regex_escaped_ampersand_is_query() {
4211:         // regex `\&` is a literal `&` → query signal.
4212:         let ws = of_code(
4213:             "if { [HTTP::uri] matches_regex \"key\\\\&id\" } { log local0. x }",
4214:             IR,
4215:             "IRULE3103",
4216:         );
4217:         assert_eq!(ws.len(), 1);
4218:         assert!(ws[0].message.contains("HTTP::query"));
4219:     }
4220: }
4221: 
4222: // Interpreter special-variable taint sources (`env`, `argv`, `argv0`).
4223: //
4224: // Reading the process environment or the command line is attacker-influenced
4225: // external input, seeded from the dialect-aware special-variable registry
4226: // (`tcl_registry::special_vars`). The restricted iRules interpreter provides
4227: // none of them, so they are sources only in the standard Tcl dialects.
4228: mod special_variable_sources {
4229:     use super::*;
4230: 
4231:     #[test]
4232:     fn env_read_flows_tainted_into_code_sink() {
4233:         let ws = of_code("eval $env(CMD)", D, "T100");
4234:         assert!(!ws.is_empty(), "eval of $env(...) should fire T100");
4235:     }
4236: 
4237:     #[test]
4238:     fn argv_read_flows_tainted_into_code_sink() {
4239:         let ws = of_code("eval $argv", D, "T100");
4240:         assert!(!ws.is_empty(), "eval of $argv should fire T100");
4241:     }
4242: 
4243:     #[test]
4244:     fn argv0_read_flows_tainted_into_code_sink() {
4245:         let ws = of_code("eval $argv0", D, "T100");
4246:         assert!(!ws.is_empty(), "eval of $argv0 should fire T100");
4247:     }
4248: 
4249:     #[test]
4250:     fn local_shadow_is_not_a_source() {
4251:         // A local `set argv …` shadows the interpreter global: the read sees
4252:         // the clean literal (higher SSA version), so no taint reaches the sink.
4253:         assert_eq!(codes("set argv clean\neval $argv", D), Vec::<String>::new());
4254:     }
4255: 
4256:     #[test]
4257:     fn env_is_not_a_source_in_irules() {
4258:         // The restricted iRules interpreter has no `env`, so it is not seeded
4259:         // as a taint source there.
4260:         assert!(of_code("eval $env(CMD)", IR, "T100").is_empty());
4261:     }
4262: }
