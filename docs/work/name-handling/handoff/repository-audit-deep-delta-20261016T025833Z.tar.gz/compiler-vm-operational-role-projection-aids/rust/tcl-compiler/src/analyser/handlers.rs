/* ORIGINAL_SOURCE_RANGE 1286..1332 */
1286:     #[cfg(test)]
1287:     pub fn handle_global_command(
1288:         &mut self,
1289:         args: &[String],
1290:         arg_tokens: &[Token],
1291:         scope_path: &[usize],
1292:     ) {
1293:         // `global ::ns::v` makes the *unqualified tail* (`v`) a local alias
1294:         // to the global variable, so define the tail name locally (matches
1295:         // Tcl + completion's expectation of both `$v` and `$::ns::v`).
1296:         for (i, name) in args.iter().enumerate() {
1297:             let Some(local) = self.declaration_local_alias(
1298:                 name,
1299:                 i,
1300:                 tcl_registry::state_transition::VariableAliasNamePurpose::Global,
1301:             ) else {
1302:                 continue;
1303:             };
1304:             // A dynamic name (`global $dyn`) computes its name at runtime — not
1305:             // a static declaration.
1306:             if let Some(tok) = arg_tokens.get(i)
1307:                 && !crate::naming::is_dynamic_word(name)
1308:             {
1309:                 self.define_var(&local, *tok, scope_path, false, None);
1310:                 // `global v` aliases the global cell `::v`; `global ::ns::v`
1311:                 // aliases `::ns::v` as written.  Record the target so every
1312:                 // `global` alias and the global declaration unify.
1313:                 let Some(target) = self.declaration_alias_target("::", name) else {
1314:                     continue;
1315:                 };
1316:                 // The declaration word *is* the cell's name here (`global v`
1317:                 // / `global ::ns::v`), so a rename of the cell rewrites this
1318:                 // very word — see `VarDef::link_target_span`.
1319:                 self.set_var_link_target(
1320:                     &local,
1321:                     scope_path,
1322:                     super::scope::VariableLinkTarget {
1323:                         target,
1324:                         target_span: tok.span,
1325:                         local_span: tok.span,
1326:                         original_target_namespace: self.original_variable_root_namespace(),
1327:                         original_target_receiver: crate::signature_scan::variable_symbol::OriginalVariableSymbolReceiver::NamespaceAlias,
1328:                     },
1329:                 );
1330:             }
1331:         }
1332:     }
/* ORIGINAL_SOURCE_RANGE 1340..1405 */
1340:     #[cfg(test)]
1341:     pub fn handle_variable_command(
1342:         &mut self,
1343:         args: &[String],
1344:         arg_tokens: &[Token],
1345:         scope_path: &[usize],
1346:     ) {
1347:         // `variable name ?value? name ?value? ...`
1348:         // Each `name` aliases the cell `<current-namespace>::<name>`; every
1349:         // `variable name` across that namespace's procs, plus the namespace
1350:         // -level declaration, shares that target and so unifies.
1351:         let ns = self.command_resolution_namespace(scope_path);
1352:         let mut i = 0;
1353:         while i < args.len() {
1354:             // A dynamic name (`variable $dyn` / `variable [f]`) is computed at
1355:             // runtime — its literal text is not the variable's name, so it is
1356:             // not a static declaration.  Skip it rather than record the
1357:             // substitution text as a variable.
1358:             if let Some(tok) = arg_tokens.get(i)
1359:                 && !crate::naming::is_dynamic_word(&args[i])
1360:             {
1361:                 // Mirror `global` above: the *unqualified tail* is the local
1362:                 // alias name, but the target keeps the FULL qualified path so a
1363:                 // relative `variable child::v` aliases `<ns>::child::v` (and an
1364:                 // absolute `variable ::x::v` aliases `::x::v`), never the
1365:                 // tail-collapsed `<ns>::v`.  Keying the link on the tail is what
1366:                 // lets a later `$v` reference share the target and unify.
1367:                 let Some(local) = self.declaration_local_alias(
1368:                     &args[i],
1369:                     i,
1370:                     tcl_registry::state_transition::VariableAliasNamePurpose::NamespaceVariable,
1371:                 ) else {
1372:                     i += if i + 1 < args.len() { 2 } else { 1 };
1373:                     continue;
1374:                 };
1375:                 self.define_var(&local, *tok, scope_path, false, None);
1376:                 let Some(target) = self.declaration_alias_target(&ns, &args[i]) else {
1377:                     i += if i + 1 < args.len() { 2 } else { 1 };
1378:                     continue;
1379:                 };
1380:                 // As with `global`, the declaration word names the cell.
1381:                 self.set_var_link_target(
1382:                     &local,
1383:                     scope_path,
1384:                     super::scope::VariableLinkTarget {
1385:                         target,
1386:                         target_span: tok.span,
1387:                         local_span: tok.span,
1388:                         original_target_namespace: self.original_variable_namespace_at(scope_path),
1389:                         original_target_receiver: if self.head_identities.source_bindings_ref().original_variable_uses_global_frame_at_span(tok.span, self.file_lexer_config())
1390:                         && self.original_variable_namespace_at(scope_path).is_some_and(|namespace| match namespace {
1391:                             crate::signature_scan::scope::SignatureNamespaceScope::C(path) => path.is_root(),
1392:                             crate::signature_scan::scope::SignatureNamespaceScope::Jim(object) => object.is_empty(),
1393:                             crate::signature_scan::scope::SignatureNamespaceScope::Symbolic(_) => false,
1394:                         })
1395:                     {
1396:                         crate::signature_scan::variable_symbol::OriginalVariableSymbolReceiver::NamespaceVariableWithoutLink
1397:                     } else {
1398:                         crate::signature_scan::variable_symbol::OriginalVariableSymbolReceiver::NamespaceAlias
1399:                     },
1400:                     },
1401:                 );
1402:             }
1403:             i += if i + 1 < args.len() { 2 } else { 1 };
1404:         }
1405:     }
/* ORIGINAL_SOURCE_RANGE 1407..1422 */
1407:     #[cfg(test)]
1408:     fn declaration_local_alias(
1409:         &self,
1410:         name: &str,
1411:         argument_index: usize,
1412:         purpose: tcl_registry::state_transition::VariableAliasNamePurpose,
1413:     ) -> Option<String> {
1414:         let dialect = self.declaration_name_dialect();
1415:         let subject = tcl_registry::state_transition::local_alias_name(
1416:             &tcl_registry::TransitionSubject::Literal(name.to_owned()),
1417:             argument_index,
1418:             purpose,
1419:             Some(dialect),
1420:         )?;
1421:         subject.literal().map(str::to_owned)
1422:     }
/* ORIGINAL_SOURCE_RANGE 1510..1528 */
1510:     #[cfg(test)]
1511:     fn declaration_alias_target(&self, namespace: &str, name: &str) -> Option<String> {
1512:         let dialect = self.declaration_name_dialect();
1513:         if dialect.native_name_protocol().is_none()
1514:             && dialect.family() == Some(tcl_dialect::model::Family::Tcl)
1515:             && !name.contains('\0')
1516:         {
1517:             return Some(crate::naming::qualify(namespace, name));
1518:         }
1519:         Some(match dialect.native_name_protocol()? {
1520:             tcl_syntax::naming::NativeNameProtocol::C(_) => crate::naming::qualify(namespace, name),
1521:             tcl_syntax::naming::NativeNameProtocol::Jim084 => {
1522:                 format!(
1523:                     "::{}",
1524:                     crate::naming::jim_global_variable_key(namespace, name)
1525:                 )
1526:             }
1527:         })
1528:     }
/* ORIGINAL_SOURCE_RANGE 7214..7215 */
7214:         #[cfg(test)]
7215:         let trace_enabled = std::env::var_os("TCL_LSP_TRACE_ORIGINAL_CHILD_GUARDS").is_some();
/* ORIGINAL_SOURCE_RANGE 7216..7221 */
7216:         #[cfg(test)]
7217:         let trace = |label: &str, passed: bool| {
7218:             if trace_enabled {
7219:                 eprintln!("ORIGINAL_COMPLETION_GUARD label={label} passed={passed}");
7220:             }
7221:         };
/* ORIGINAL_SOURCE_RANGE 7241..7268 */
7241:         #[cfg(test)]
7242:         if trace_enabled {
7243:             trace("source.logical", logical_source);
7244:             trace("source.retained", retained.is_some());
7245:             trace("metadata.request", metadata.is_some());
7246:             trace("tokens.binding", tokens.source_binding.is_some());
7247:             let binding = tokens.source_binding.as_ref();
7248:             trace(
7249:                 "tokens.config",
7250:                 binding.and_then(|binding| binding.original_lexer_config_for_tokens(&tokens))
7251:                     == Some(self.file_lexer_config()),
7252:             );
7253:             trace(
7254:                 "metadata.original",
7255:                 binding.zip(retained).is_some_and(|(binding, input)| {
7256:                     binding
7257:                         .original_invocation_metadata_for_input(&tokens, input, registry)
7258:                         .is_some()
7259:                 }),
7260:             );
7261:             let advice =
7262:                 binding.and_then(|binding| binding.declaration_operand_layout_advice(&tokens));
7263:             trace("declaration.layout", advice.is_some());
7264:             trace(
7265:                 "declaration.closed",
7266:                 advice.is_some_and(|advice| advice.closed_logical_source_lookup()),
7267:             );
7268:         }
/* ORIGINAL_SOURCE_RANGE 7276..7277 */
7276:             #[cfg(test)]
7277:             trace("operation.selected", invocation.is_some());
/* ORIGINAL_SOURCE_RANGE 7288..7289 */
7288:             #[cfg(test)]
7289:             trace("realm.original", realm.is_some());
/* ORIGINAL_SOURCE_RANGE 7297..7298 */
7297:             #[cfg(test)]
7298:             trace("completion.schema", completion.is_some());
/* ORIGINAL_SOURCE_RANGE 7299..7303 */
7299:             #[cfg(test)]
7300:             trace(
7301:                 "completion.known",
7302:                 completion.is_some_and(|completion| completion != InvocationCompletion::Unknown),
7303:             );
/* ORIGINAL_SOURCE_RANGE 12077..19679 */
12077: #[cfg(test)]
12078: mod tests {
12079:     use super::*;
12080:     use tcl_lexer::Span;
12081: 
12082:     fn command_name_pattern_with_closer(
12083:         word: &str,
12084:         candidate: &str,
12085:         closer: tcl_lexer::BracedVarStyle,
12086:     ) -> bool {
12087:         let mut input = Analyser::new().prepare_analysis_input("tcl").unwrap();
12088:         input.config.braced_var = closer;
12089:         let config = input.lexer_config();
12090:         let source = format!("marker {word}");
12091:         let segment =
12092:             crate::segmenter::segment_commands_with_offset_and_config(&source, 0, config).remove(0);
12093:         let tokens = crate::ir::CommandTokens::from_segmented(
12094:             &tcl_lexer::SourceMap::new(&source),
12095:             config,
12096:             &segment,
12097:         );
12098:         let original = crate::registry_invocation::original_native_compiler_words(
12099:             &tcl_lexer::SourceImage::document(&source),
12100:             tokens.words(),
12101:             0,
12102:             config,
12103:         )
12104:         .unwrap();
12105:         let metadata = crate::registry_invocation::InvocationMetadataContext::for_source_input(
12106:             input.borrowed_context_registry().commands(),
12107:             &input,
12108:             config,
12109:             Some(input.unit_profile()),
12110:         );
12111:         crate::dynamic_names::original_command_name_overlap(&original[1], candidate, metadata)
12112:             .unwrap()
12113:             .may_equal
12114:     }
12115: 
12116:     fn dynamic_command_name_may_equal(word: &str, candidate: &str) -> bool {
12117:         command_name_pattern_with_closer(word, candidate, tcl_lexer::BracedVarStyle::FirstClose)
12118:     }
12119: 
12120:     #[test]
12121:     fn original_registry_class_definers_require_the_selected_source_and_complete_arguments() {
12122:         for (source, expected) in [
12123:             ("oo::class create Made {}", true),
12124:             ("proc oo::class args {}; oo::class create Made {}", false),
12125:         ] {
12126:             let mut analyser = Analyser::new();
12127:             analyser.analyse_and_retain_result_for_test(source, "tcl");
12128:             analyser.registry = Some(analyser.profile_registry());
12129:             let segment = crate::segmenter::segment_commands_with_offset_and_config(
12130:                 source,
12131:                 0,
12132:                 analyser.file_lexer_config(),
12133:             )
12134:             .pop()
12135:             .unwrap();
12136:             assert_eq!(
12137:                 analyser
12138:                     .resolve_class_creation(segment.args(), segment.arg_tokens(), segment.argv[0])
12139:                     .is_some_and(|creation| creation.registry_metaclass.is_some()),
12140:                 expected,
12141:                 "{source}",
12142:             );
12143:             if expected {
12144:                 let mut changed = segment.args().to_vec();
12145:                 changed[0] = "new".to_owned();
12146:                 assert!(
12147:                     analyser
12148:                         .resolve_class_creation(&changed, segment.arg_tokens(), segment.argv[0])
12149:                         .is_none()
12150:                 );
12151:                 analyser.source.push(' ');
12152:                 assert!(
12153:                     analyser
12154:                         .resolve_class_creation(
12155:                             segment.args(),
12156:                             segment.arg_tokens(),
12157:                             segment.argv[0]
12158:                         )
12159:                         .is_none()
12160:                 );
12161:             }
12162:         }
12163:     }
12164: 
12165:     #[test]
12166:     fn original_factory_overrides_require_readable_original_member_layout() {
12167:         for (source, represented) in [
12168:             (
12169:                 "oo::class create Meta {superclass ::oo::class; self method create {name body} {next $name $body}}",
12170:                 true,
12171:             ),
12172:             (
12173:                 "oo::class create Meta {superclass ::oo::class; self method create {name body} {return opaque}}",
12174:                 false,
12175:             ),
12176:             (
12177:                 "oo::class create Meta {superclass ::oo::class; self forward create opaque}",
12178:                 false,
12179:             ),
12180:         ] {
12181:             let mut analyser = Analyser::new();
12182:             analyser.analyse_and_retain_result_for_test(source, "tcl8.6");
12183:             let class = analyser
12184:                 .result
12185:                 .all_classes
12186:                 .values()
12187:                 .find(|class| class.name == "Meta")
12188:                 .unwrap();
12189:             let factory = analyser.class_factory_of(class);
12190:             assert_eq!(factory.is_some(), represented, "{source}");
12191:             if let Some(factory) = factory {
12192:                 let layout = factory.overrides.get("create").unwrap();
12193:                 assert_eq!((layout.name_arg, layout.body_arg), (1, 2));
12194:                 let mut report_only = class.clone();
12195:                 report_only.class_methods.clear();
12196:                 report_only.class_unexports.insert("create".to_owned());
12197:                 assert_eq!(analyser.class_factory_of(&report_only), Some(factory));
12198:             }
12199:         }
12200:     }
12201: 
12202:     #[test]
12203:     fn original_factory_headers_require_the_actual_graph_occupancy_and_arguments() {
12204:         for (source, key, expected) in [
12205:             ("External create Made {}", "::External", true),
12206:             ("puts create Made {}", "::puts", false),
12207:             (
12208:                 "proc External args {}; External create Made {}",
12209:                 "::External",
12210:                 false,
12211:             ),
12212:             (
12213:                 "interp alias {} External {} puts; External create Made {}",
12214:                 "::External",
12215:                 false,
12216:             ),
12217:             (
12218:                 "unknown_effect; External create Made {}",
12219:                 "::External",
12220:                 false,
12221:             ),
12222:             ("External create [set name] {}", "::External", false),
12223:         ] {
12224:             let mut analyser = Analyser::new();
12225:             analyser.analyse_and_retain_result_for_test(source, "tcl");
12226:             analyser.registry = Some(analyser.profile_registry());
12227:             analyser.workspace_class_factories = Some(std::sync::Arc::new(
12228:                 [(
12229:                     key.to_owned(),
12230:                     ClassFactory {
12231:                         root_metaclass: "::oo::class".to_owned(),
12232:                         ..ClassFactory::default()
12233:                     },
12234:                 )]
12235:                 .into_iter()
12236:                 .collect(),
12237:             ));
12238:             let segment = crate::segmenter::segment_commands_with_offset_and_config(
12239:                 source,
12240:                 0,
12241:                 analyser.file_lexer_config(),
12242:             )
12243:             .pop()
12244:             .unwrap();
12245:             assert_eq!(
12246:                 analyser
12247:                     .class_factory_for_command(
12248:                         segment.args(),
12249:                         segment.arg_tokens(),
12250:                         segment.argv[0].span.start(),
12251:                     )
12252:                     .is_some(),
12253:                 expected,
12254:                 "{source}",
12255:             );
12256:             if expected {
12257:                 let mut changed = segment.arg_tokens().to_vec();
12258:                 changed.swap(0, 1);
12259:                 assert!(
12260:                     analyser
12261:                         .class_factory_for_command(
12262:                             segment.args(),
12263:                             &changed,
12264:                             segment.argv[0].span.start()
12265:                         )
12266:                         .is_none()
12267:                 );
12268:                 let mut changed = segment.args().to_vec();
12269:                 changed[0] = "new".to_owned();
12270:                 assert!(
12271:                     analyser
12272:                         .class_factory_for_command(
12273:                             &changed,
12274:                             segment.arg_tokens(),
12275:                             segment.argv[0].span.start()
12276:                         )
12277:                         .is_none()
12278:                 );
12279:                 analyser.source.push(' ');
12280:                 assert!(
12281:                     analyser
12282:                         .class_factory_for_command(
12283:                             segment.args(),
12284:                             segment.arg_tokens(),
12285:                             segment.argv[0].span.start()
12286:                         )
12287:                         .is_none()
12288:                 );
12289:             }
12290:         }
12291:     }
12292: 
12293:     #[test]
12294:     fn manufacturer_prologue_components_keep_original_reference_and_group_geometry() {
12295:         for (source, expected) in [
12296:             ("next $a:b", vec!["a", "opaque"]),
12297:             ("next ${a:b}", vec!["a:b"]),
12298:             ("next {$body}", vec!["opaque"]),
12299:             (
12300:                 "next \"[list superclass {a]b}]\\;$body\"",
12301:                 vec!["group", "separator", "body"],
12302:             ),
12303:         ] {
12304:             let image = tcl_lexer::SourceImage::document(source);
12305:             let config = tcl_lexer::LexerConfig::default();
12306:             let plan = tcl_lexer::native_script_words_in(
12307:                 image,
12308:                 Span::new(0, u32::try_from(source.len()).unwrap()),
12309:                 config,
12310:             )
12311:             .unwrap();
12312:             let observed = prologue_pieces(&plan.commands[0].words[1]);
12313:             let labels = observed
12314:                 .iter()
12315:                 .map(|piece| match piece {
12316:                     ProloguePiece::VarRead(name) => *name,
12317:                     ProloguePiece::Separator => "separator",
12318:                     ProloguePiece::Substitution(_) => "group",
12319:                     ProloguePiece::Opaque => "opaque",
12320:                 })
12321:                 .collect::<Vec<_>>();
12322:             assert_eq!(labels, expected, "{source}");
12323:         }
12324:     }
12325: 
12326:     #[test]
12327:     fn original_if_conditions_keep_selected_grammar_and_unknown_evaluation_boundaries() {
12328:         for (dialect, condition, expected) in [
12329:             ("tcl8.6", "1 + 2 * 3", Some(true)),
12330:             ("tcl8.6", "0", Some(false)),
12331:             ("tcl8.6", "1 / 0", None),
12332:             ("tcl8.6", "$unknown", None),
12333:             ("tcl8.6", "[unknown]", None),
12334:             ("tcl8.6", "abs(1)", None),
12335:             ("tcl8.6", "\"1\"", None),
12336:             ("tcl8.6", "1_0", None),
12337:             ("tcl9.0", "1_0", Some(true)),
12338:         ] {
12339:             let source = format!("if {{{condition}}} {{set x 1}}");
12340:             let mut analyser = Analyser::new();
12341:             analyser.analyse_and_retain_result_for_test(&source, dialect);
12342:             let segment = crate::segmenter::segment_commands_with_offset_and_config(
12343:                 &source,
12344:                 0,
12345:                 analyser.file_lexer_config(),
12346:             )
12347:             .remove(0);
12348:             assert_eq!(
12349:                 analyser.original_condition_boolean(&segment, 1),
12350:                 expected,
12351:                 "{dialect}: {source}"
12352:             );
12353:             assert!(
12354:                 analyser.original_condition_boolean(&segment, 2).is_none(),
12355:                 "a Body role cannot donate an expression"
12356:             );
12357:             let mut foreign = segment.clone();
12358:             foreign.texts[1] = "0".to_owned();
12359:             if condition != "0" {
12360:                 assert!(
12361:                     analyser.original_condition_boolean(&foreign, 1).is_none(),
12362:                     "foreign operand data cannot borrow the original expression owner"
12363:                 );
12364:             }
12365:             let mut input = analyser.result.resolved_input.clone().unwrap();
12366:             input.config.strict_quoting = !input.config.strict_quoting;
12367:             analyser.resolved_input = Some(input);
12368:             assert!(analyser.original_condition_boolean(&segment, 1).is_none());
12369:         }
12370:         let mut prepared = Analyser::new();
12371:         let input = prepared.prepare_analysis_input("tcl9.0").unwrap();
12372:         for escapes in [
12373:             tcl_dialect::EscapeSyntax::Tcl84,
12374:             tcl_dialect::EscapeSyntax::Tcl90,
12375:             tcl_dialect::EscapeSyntax::Jim,
12376:         ] {
12377:             let mut input = input.clone();
12378:             input.config.escapes = escapes;
12379:             let mut analyser = Analyser::new().with_resolved_input(input.clone());
12380:             let source = "if {1} break";
12381:             analyser.analyse_and_retain_result_for_test(source, "display-only");
12382:             assert_eq!(analyser.result.resolved_input.as_ref(), Some(&input));
12383:             let segment = crate::segmenter::segment_commands_with_offset_and_config(
12384:                 source,
12385:                 0,
12386:                 input.lexer_config(),
12387:             )
12388:             .remove(0);
12389:             assert_eq!(analyser.original_condition_boolean(&segment, 1), Some(true));
12390:         }
12391:     }
12392: 
12393:     #[test]
12394:     fn original_if_branches_use_clause_order_and_complete_original_bodies() {
12395:         for (source, selected_bodies, fallthrough) in [
12396:             ("if {1} {set x 1} else {set x 2}", vec!["set x 1"], false),
12397:             (
12398:                 "if {0} {set x 1} elseif {1} {set x 2} else {set x 3}",
12399:                 vec!["set x 2"],
12400:                 false,
12401:             ),
12402:             ("if {0} {set x 1}", Vec::new(), true),
12403:             (
12404:                 "if {$unknown} {set x 1} else {set x 2}",
12405:                 vec!["set x 1", "set x 2"],
12406:                 false,
12407:             ),
12408:             ("if {1 / 0} {set x 1}", vec!["set x 1"], true),
12409:             (
12410:                 "if {1} {set x 1} elseif {1 / 0} {set x 2}",
12411:                 vec!["set x 1"],
12412:                 false,
12413:             ),
12414:             ("if {0} break else continue", vec!["continue"], false),
12415:         ] {
12416:             let mut analyser = Analyser::new();
12417:             analyser.analyse_and_retain_result_for_test(source, "tcl8.6");
12418:             let config = analyser.file_lexer_config();
12419:             let segment =
12420:                 crate::segmenter::segment_commands_with_offset_and_config(source, 0, config)
12421:                     .remove(0);
12422:             let (spans, actual_fallthrough) = analyser
12423:                 .possible_if_body_spans(&segment, "unused")
12424:                 .expect("actual selected source If and complete original bodies");
12425:             let image = tcl_lexer::SourceImage::document(source);
12426:             let original = crate::registry_invocation::original_native_compiler_words(
12427:                 &image,
12428:                 crate::ir::CommandTokens::from_segmented(
12429:                     &tcl_lexer::SourceMap::from_image(&image),
12430:                     config,
12431:                     &segment,
12432:                 )
12433:                 .words(),
12434:                 0,
12435:                 config,
12436:             )
12437:             .unwrap();
12438:             let selected = spans
12439:                 .iter()
12440:                 .map(|span| {
12441:                     let word = original
12442:                         .iter()
12443:                         .find(|word| {
12444:                             word.tokens()
12445:                                 .first()
12446:                                 .is_some_and(|token| token.span == *span)
12447:                         })
12448:                         .unwrap();
12449:                     source.get(word.content_span().unwrap().as_range()).unwrap()
12450:                 })
12451:                 .collect::<Vec<_>>();
12452:             assert_eq!(selected, selected_bodies, "{source}");
12453:             assert_eq!(actual_fallthrough, fallthrough, "{source}");
12454:             analyser.source.push(' ');
12455:             assert!(
12456:                 analyser
12457:                     .possible_if_body_spans(&segment, "unused")
12458:                     .is_none()
12459:             );
12460:         }
12461:     }
12462: 
12463:     #[test]
12464:     fn control_arm_metadata_requires_the_actual_selected_body_source() {
12465:         use tcl_registry::registry::ControlArmSemantics as Arm;
12466:         for (source, body_ordinal, expected) in [
12467:             ("if {1} {set x 1}", 1, Some(Arm::Selected)),
12468:             (
12469:                 "interp alias {} choose {} if; choose {1} {set x 1}",
12470:                 1,
12471:                 Some(Arm::Selected),
12472:             ),
12473:             ("interp alias {} choose {} if 1; choose {set x 1}", 0, None),
12474:             ("proc if args {}; if {1} {set x 1}", 1, None),
12475:             ("namespace eval N {set x 1}", 2, Some(Arm::FrameBoundary)),
12476:             ("namespace eval N {set x 1;} {set y 2}", 2, None),
12477:             ("apply {{} {set x 1}}", 0, None),
12478:         ] {
12479:             let mut analyser = Analyser::new();
12480:             analyser.analyse_and_retain_result_for_test(source, "tcl8.6");
12481:             let controller = crate::segmenter::segment_commands_with_offset_and_config(
12482:                 source,
12483:                 0,
12484:                 analyser.file_lexer_config(),
12485:             )
12486:             .pop()
12487:             .unwrap();
12488:             let mut arm = ControlArm {
12489:                 body_span: controller.arg_tokens()[body_ordinal].span,
12490:                 controller,
12491:             };
12492:             assert_eq!(
12493:                 analyser.control_arm_semantics_for(&arm),
12494:                 expected,
12495:                 "{source}"
12496:             );
12497:             let supplied = analyser.resolved_input.clone();
12498:             let mut foreign = analyser.result.resolved_input.clone().unwrap();
12499:             foreign.config.strict_quoting = !foreign.config.strict_quoting;
12500:             analyser.resolved_input = Some(foreign);
12501:             assert!(
12502:                 analyser.control_arm_semantics_for(&arm).is_none(),
12503:                 "a changed current input cannot borrow old structural advice"
12504:             );
12505:             analyser.resolved_input = supplied;
12506:             let actual_span = arm.body_span;
12507:             arm.body_span = Span::new(arm.body_span.start(), arm.body_span.start());
12508:             assert!(
12509:                 analyser.control_arm_semantics_for(&arm).is_none(),
12510:                 "an arbitrary contained point is not an original body"
12511:             );
12512:             arm.body_span = actual_span;
12513:             analyser.source.push(' ');
12514:             assert!(analyser.control_arm_semantics_for(&arm).is_none());
12515:         }
12516:     }
12517: 
12518:     #[test]
12519:     fn control_arm_positions_require_actual_original_body_containers() {
12520:         for (source, expected) in [
12521:             (
12522:                 "if {0} {set x 1} else {set x 2}",
12523:                 vec![(1, Some(false)), (3, Some(true))],
12524:             ),
12525:             (
12526:                 "switch x {x {set a 1} default {set a 2}}",
12527:                 vec![(1, None), (1, None)],
12528:             ),
12529:             ("apply {{} {puts body}}", vec![(0, None)]),
12530:         ] {
12531:             let mut analyser = Analyser::new();
12532:             analyser.analyse_and_retain_result_for_test(source, "tcl8.6");
12533:             let config = analyser.file_lexer_config();
12534:             let controller =
12535:                 crate::segmenter::segment_commands_with_offset_and_config(source, 0, config)
12536:                     .remove(0);
12537:             let context = analyser.retained_static_source_context().unwrap();
12538:             let words = crate::registry_invocation::source_structure::source_registry_words_at(
12539:                 source,
12540:                 &analyser.result,
12541:                 0,
12542:             )
12543:             .unwrap();
12544:             let bodies = words
12545:                 .source_script_bodies_for(
12546:                     &context,
12547:                     crate::registry_invocation::OriginalSourceScriptPurpose::PotentialEvaluation,
12548:                 )
12549:                 .into_iter()
12550:                 .chain(words.original_lambda_body_geometry(&context))
12551:                 .collect::<Vec<_>>();
12552:             assert_eq!(bodies.len(), expected.len(), "{source}");
12553:             for (body, (ordinal, selected)) in bodies.iter().zip(expected) {
12554:                 let mut arm = ControlArm {
12555:                     controller: controller.clone(),
12556:                     body_span: body.extent_span(),
12557:                 };
12558:                 assert_eq!(
12559:                     analyser.control_arm_body_index(&arm),
12560:                     Some(ordinal),
12561:                     "{source}"
12562:                 );
12563:                 if let Some(selected) = selected {
12564:                     assert_eq!(
12565:                         analyser.control_body_is_selected(
12566:                             "",
12567:                             &arm,
12568:                             &std::collections::HashMap::new(),
12569:                             0
12570:                         ),
12571:                         Some(selected),
12572:                         "{source}"
12573:                     );
12574:                 }
12575:                 let mut foreign = arm.clone();
12576:                 foreign.controller.texts[0] = "another-head".to_owned();
12577:                 assert!(analyser.control_arm_body_index(&foreign).is_none());
12578:                 let mut foreign = arm.clone();
12579:                 foreign.controller.texts[1] = "altered-argument".to_owned();
12580:                 assert!(analyser.control_arm_body_index(&foreign).is_none());
12581:                 let mut foreign = arm.clone();
12582:                 foreign.controller.argv[1].span = Span::new(0, 0);
12583:                 assert!(analyser.control_arm_body_index(&foreign).is_none());
12584:                 arm.body_span = body.container_extent_span();
12585:                 if arm.body_span != body.extent_span() {
12586:                     assert!(
12587:                         analyser.control_arm_body_index(&arm).is_none(),
12588:                         "container is not its script child"
12589:                     );
12590:                 }
12591:                 arm.body_span = Span::new(body.content_span().start(), body.content_span().start());
12592:                 assert!(
12593:                     analyser.control_arm_body_index(&arm).is_none(),
12594:                     "interior point cannot donate body authority"
12595:                 );
12596:             }
12597:             analyser.source.push(' ');
12598:             let arm = ControlArm {
12599:                 controller,
12600:                 body_span: bodies[0].extent_span(),
12601:             };
12602:             assert!(analyser.control_arm_body_index(&arm).is_none());
12603:         }
12604:     }
12605: 
12606:     #[test]
12607:     fn factory_splices_keep_original_list_data_geometry_and_grammar() {
12608:         let member = FactoryMember {
12609:             words: vec![FactoryWord::CallerSplice(0)],
12610:         };
12611:         for (source, expected) in [
12612:             ("maker {A B}", Some(vec!["A", "B"])),
12613:             (
12614:                 "maker {A $literal [data]}",
12615:                 Some(vec!["A", "$literal", "[data]"]),
12616:             ),
12617:             (r"maker {escaped\ name}", Some(vec!["escaped name"])),
12618:             ("maker {}", Some(Vec::new())),
12619:             ("maker $dynamic", None),
12620:             ("maker {*}{one two}", None),
12621:             (r"maker {\uD800}", None),
12622:             ("maker {one \"two}", None),
12623:         ] {
12624:             let config = tcl_lexer::LexerConfig {
12625:                 expand_syntax: true,
12626:                 ..tcl_lexer::LexerConfig::default()
12627:             };
12628:             let plan = tcl_lexer::native_script_words_in(
12629:                 tcl_lexer::SourceImage::document(source),
12630:                 Span::new(0, u32::try_from(source.len()).unwrap()),
12631:                 config,
12632:             )
12633:             .unwrap();
12634:             let original = &plan.commands[0].words[1..];
12635:             let result = resolve_factory_member(&member, Some(original));
12636:             assert_eq!(
12637:                 result.as_ref().map(|member| member
12638:                     .texts
12639:                     .iter()
12640:                     .map(String::as_str)
12641:                     .collect::<Vec<_>>()),
12642:                 expected,
12643:                 "{source}"
12644:             );
12645:             if let Some(result) = result {
12646:                 let content = original[0].content_span().unwrap();
12647:                 assert_eq!(result.texts.len(), result.argv.len());
12648:                 assert!(
12649:                     result
12650:                         .argv
12651:                         .iter()
12652:                         .all(|token| content.start() <= token.span.start()
12653:                             && token.span.end() <= content.end())
12654:                 );
12655:             }
12656:             assert!(
12657:                 resolve_factory_member(&member, None).is_none(),
12658:                 "a report-only caller cannot donate an empty splice"
12659:             );
12660:         }
12661:     }
12662: 
12663:     #[test]
12664:     fn factory_list_templates_require_actual_constructor_and_scalar_formal_splices() {
12665:         for (prefix, constructor, operand, expected) in [
12666:             ("", "list", "$parents", true),
12667:             ("", "::list", "${parents}", true),
12668:             ("", "list", "$parents:tail", false),
12669:             ("", "list", "$parents(key)", false),
12670:             ("", "list", "[set parents]", false),
12671:             ("", "split", "$parents", false),
12672:             ("", "lreverse", "$parents", false),
12673:             (
12674:                 "proc list {args} {return opaque}\n",
12675:                 "list",
12676:                 "$parents",
12677:                 false,
12678:             ),
12679:         ] {
12680:             let source = format!(
12681:                 "{prefix}oo::class create Meta {{superclass ::oo::class; self method create {{name parents body}} {{next $name \"[{constructor} super\\u0063lass {{*}}{operand}];$body\"}}}}"
12682:             );
12683:             let mut analyser = Analyser::new();
12684:             analyser.analyse_and_retain_result_for_test(&source, "tcl8.6");
12685:             let class = analyser
12686:                 .result
12687:                 .all_classes
12688:                 .values()
12689:                 .find(|class| class.name == "Meta")
12690:                 .unwrap();
12691:             let meta = analyser
12692:                 .user_metaclass_of_class(class)
12693:                 .expect("actual retained Registry root relation");
12694:             let methods = crate::analyser::class_hierarchy::original_metadata::original_definition_members_for_class(
12695:                 &analyser.result, class, MemberSide::ClassObject,
12696:             ).unwrap();
12697:             let method = methods
12698:                 .iter()
12699:                 .find(|method| method.original_name_input().bytes() == b"create")
12700:                 .unwrap();
12701:             let original = method
12702:                 .original_parameter_names_and_body(&analyser.result)
12703:                 .unwrap();
12704:             let body = original.body_word();
12705:             let plan = tcl_lexer::native_script_words_in(
12706:                 body.image().clone(),
12707:                 body.content_span().unwrap(),
12708:                 body.config(),
12709:             )
12710:             .unwrap();
12711:             let prologue = &plan.commands[0].words[2];
12712:             let group = prologue_pieces(prologue)
12713:                 .into_iter()
12714:                 .find_map(|part| match part {
12715:                     ProloguePiece::Substitution(group) => Some(group),
12716:                     _ => None,
12717:                 })
12718:                 .unwrap();
12719:             let template = analyser.injected_member_from_group(&meta, group, &original);
12720:             assert_eq!(template.is_some(), expected, "{source}");
12721:             if let Some(template) = template {
12722:                 assert!(
12723:                     matches!(template.words.as_slice(), [FactoryWord::Literal { text, .. }, FactoryWord::CallerSplice(2)] if text == "superclass")
12724:                 );
12725:             }
12726:         }
12727:     }
12728: 
12729:     #[test]
12730:     fn bound_parameter_substitution_uses_the_complete_shared_reference_grammar() {
12731:         let parameters = vec![
12732:             "a".to_owned(),
12733:             "a:b".to_owned(),
12734:             "a{b}".to_owned(),
12735:             "a{b".to_owned(),
12736:         ];
12737:         let arguments = vec![
12738:             "SCALAR".to_owned(),
12739:             "LITERAL".to_owned(),
12740:             "NESTED".to_owned(),
12741:             "FIRST".to_owned(),
12742:         ];
12743:         let mut config = Analyser::new()
12744:             .prepare_analysis_input("tcl")
12745:             .unwrap()
12746:             .lexer_config();
12747:         assert_eq!(
12748:             substitute_bound_words("$a:b", &parameters, &arguments, config).as_deref(),
12749:             Some("SCALAR:b")
12750:         );
12751:         assert_eq!(
12752:             substitute_bound_words("${a:b}", &parameters, &arguments, config).as_deref(),
12753:             Some("LITERAL")
12754:         );
12755:         assert!(substitute_bound_words("$a(index)", &parameters, &arguments, config).is_none());
12756:         config.braced_var = tcl_lexer::BracedVarStyle::Tcl9Nesting;
12757:         assert_eq!(
12758:             substitute_bound_words("${a{b}}", &parameters, &arguments, config).as_deref(),
12759:             Some("NESTED")
12760:         );
12761:         config.braced_var = tcl_lexer::BracedVarStyle::FirstClose;
12762:         assert_eq!(
12763:             substitute_bound_words("${a{b}}", &parameters, &arguments, config).as_deref(),
12764:             Some("FIRST}")
12765:         );
12766:     }
12767: 
12768:     #[test]
12769:     fn command_mutation_overlap_retains_the_original_configured_closer() {
12770:         assert!(dynamic_command_name_may_equal("a:::$x:b", "::a::b"));
12771:         assert!(!dynamic_command_name_may_equal("a:::$x:b", "::a::OTHER"));
12772:         assert!(command_name_pattern_with_closer(
12773:             "${a{b}}",
12774:             "::string",
12775:             tcl_lexer::BracedVarStyle::Tcl9Nesting
12776:         ));
12777:         assert!(!command_name_pattern_with_closer(
12778:             "${a{b}}",
12779:             "::string",
12780:             tcl_lexer::BracedVarStyle::FirstClose
12781:         ));
12782:         for (closer, trusted) in [
12783:             (tcl_lexer::BracedVarStyle::FirstClose, true),
12784:             (tcl_lexer::BracedVarStyle::Tcl9Nesting, false),
12785:         ] {
12786:             let mut input = Analyser::new().prepare_analysis_input("tcl").unwrap();
12787:             input.config.braced_var = closer;
12788:             let mut analyser = Analyser::new().with_resolved_input(input);
12789:             analyser.analyse_and_retain_result_for_test("proc ${a{b}} {} {}", "tcl");
12790:             assert_eq!(
12791:                 analyser.static_provenance_command_is_trusted("::string"),
12792:                 trusted
12793:             );
12794:         }
12795:     }
12796: 
12797:     #[test]
12798:     fn segment_completion_retains_return_depth_and_implementation_identity() {
12799:         use tcl_registry::registry::InvocationCompletion;
12800:         for (source, expected) in [
12801:             ("return VALUE", InvocationCompletion::ReturnsResult(Some(0))),
12802:             ("return -level 2 VALUE", InvocationCompletion::Terminates),
12803:             (
12804:                 "proc p {depth} {return -level $depth VALUE}",
12805:                 InvocationCompletion::Unknown,
12806:             ),
12807:             (
12808:                 "proc return args {list CUSTOM}; return VALUE",
12809:                 InvocationCompletion::Unknown,
12810:             ),
12811:             (
12812:                 "rename return savedReturn; savedReturn VALUE",
12813:                 InvocationCompletion::ReturnsResult(Some(0)),
12814:             ),
12815:         ] {
12816:             let mut analyser = Analyser::new();
12817:             analyser.analyse_and_retain_result_for_test(source, "tcl9.0");
12818:             // The public walk clears transient registry state after returning.
12819:             analyser.registry = Some(analyser.profile_registry());
12820:             let segments = crate::segmenter::segment_commands_with_offset_and_config(
12821:                 source,
12822:                 0,
12823:                 analyser.lexer_config(),
12824:             );
12825:             let segment = segments.last().unwrap();
12826:             let segment = if source.starts_with("proc p") {
12827:                 analyser
12828:                     .direct_statements_in_span(segment.arg_tokens()[2].span)
12829:                     .unwrap()
12830:                     .pop()
12831:                     .unwrap()
12832:             } else {
12833:                 segment.clone()
12834:             };
12835:             let binding = analyser
12836:                 .head_identities
12837:                 .invocation_at_source(segment.name(), segment.argv[0].span.start());
12838:             assert_eq!(
12839:                 analyser.segment_invocation_completion(&segment),
12840:                 expected,
12841:                 "{source}; unknown={} absent={} targets={:?} execution={:?} handler={:?} compilation={:?}",
12842:                 binding.unknown,
12843:                 binding.may_be_absent,
12844:                 binding
12845:                     .targets
12846:                     .iter()
12847:                     .map(|target| (&target.command, target.registry_backed))
12848:                     .collect::<Vec<_>>(),
12849:                 binding
12850:                     .proved_execution_target()
12851:                     .map(|target| &target.command),
12852:                 binding
12853:                     .proved_handler_target()
12854:                     .map(|target| &target.command),
12855:                 binding.native_compilation_selection(),
12856:             );
12857:         }
12858:     }
12859: 
12860:     #[test]
12861:     fn original_static_proc_selection_does_not_borrow_final_names_or_caller_labels() {
12862:         // Implementation contract: naming.compiler.original-static-procedure-selection
12863:         // docs/design/analysis/name-resolution-proofs/original-static-procedure-selection.md
12864:         let sources = [
12865:             "namespace eval N {proc helper {} {return OLD}}; proc N::helper {} {return NEW}",
12866:             "namespace eval N {proc helper {} {return OLD}}; rename N::helper N::saved",
12867:             "namespace eval N {proc helper {} {return OLD}}; interp alias {} N::helper {} puts",
12868:             "namespace eval N {proc helper {} {return NAMESPACE}}; proc helper {} {return GLOBAL}",
12869:         ];
12870:         for dialect in [
12871:             "tcl8.4",
12872:             "tcl8.5",
12873:             "tcl8.6",
12874:             "tcl9.0",
12875:             "tcl9.1",
12876:             "jim",
12877:             "f5-irules",
12878:         ] {
12879:             for source in sources {
12880:                 let mut analyser = Analyser::new();
12881:                 analyser.analyse_and_retain_result_for_test(source, dialect);
12882:                 analyser.registry = Some(analyser.profile_registry());
12883:                 assert!(
12884:                     analyser
12885:                         .resolve_static_proc_name("::N::caller", "helper")
12886:                         .is_none(),
12887:                     "{dialect}: {source}"
12888:                 );
12889:                 assert!(
12890:                     analyser
12891:                         .static_proc_result("::N::helper", &[], &mut Vec::new(), 0)
12892:                         .is_none(),
12893:                     "{dialect}: {source}"
12894:                 );
12895:                 assert!(
12896:                     analyser
12897:                         .static_command_value(
12898:                             "helper",
12899:                             &[],
12900:                             "::N::caller",
12901:                             &std::collections::HashMap::new(),
12902:                             &mut Vec::new(),
12903:                             0,
12904:                         )
12905:                         .is_none(),
12906:                     "{dialect}: source-free command folding has no occupied target"
12907:                 );
12908:             }
12909:         }
12910:         // A replaced Registry head is also an occupied implementation, not
12911:         // authority supplied by the builtin spelling in a fold table.
12912:         let mut shadowed = Analyser::new();
12913:         shadowed.analyse_and_retain_result_for_test(
12914:             "proc string args {return USER}; string length abc",
12915:             "tcl8.6",
12916:         );
12917:         shadowed.registry = Some(shadowed.profile_registry());
12918:         assert!(
12919:             shadowed
12920:                 .static_command_value(
12921:                     "string",
12922:                     &[Some("length".to_owned()), Some("abc".to_owned())],
12923:                     "::caller",
12924:                     &std::collections::HashMap::new(),
12925:                     &mut Vec::new(),
12926:                     0,
12927:                 )
12928:                 .is_none()
12929:         );
12930:         let mut logical = Analyser::new();
12931:         logical.analyse_and_retain_result_for_test(sources[3], "tcl");
12932:         logical.registry = Some(logical.profile_registry());
12933:         assert_eq!(
12934:             logical
12935:                 .resolve_static_proc_name("::N::caller", "helper")
12936:                 .as_deref(),
12937:             Some("::N::helper")
12938:         );
12939:         assert_eq!(
12940:             logical
12941:                 .static_proc_result("::N::helper", &[], &mut Vec::new(), 0)
12942:                 .as_deref(),
12943:             Some("NAMESPACE")
12944:         );
12945:     }
12946: 
12947:     #[test]
12948:     fn original_logical_static_completion_keeps_alias_ordinals_and_source_owners() {
12949:         // naming.compiler.original-analysis-metadata-context
12950:         // docs/design/analysis/name-resolution-proofs/original-analysis-metadata-context.md
12951:         // Conditional source result advice, without Native return completion.
12952:         let profile = tcl_dialect::DialectProfile::plain_tcl();
12953:         let context =
12954:             tcl_registry::model::ingress::resolve_environment("tcl8.6").default_context_registry();
12955:         let config = tcl_lexer::LexerConfig::for_file_grammar(profile.grammar);
12956:         let input =
12957:             |context| super::super::ResolvedAnalysisInput::new(profile, profile, context, config);
12958:         let analyse = |source: &str, input| {
12959:             let mut analyser = Analyser::new().with_resolved_input(input);
12960:             analyser.analyse_and_retain_result_for_test(source, "tcl");
12961:             analyser
12962:         };
12963:         for (source, expected) in [
12964:             ("proc p {} {return café}", Some("café")),
12965:             (
12966:                 "interp alias {} answer {} return; proc p {} {answer WRITTEN}",
12967:                 Some("WRITTEN"),
12968:             ),
12969:             (
12970:                 "interp alias {} answer {} return CAPTURED; proc p {} {answer}",
12971:                 None,
12972:             ),
12973:             (
12974:                 "interp alias {} answer {} return -level 2; proc p {} {answer VALUE}",
12975:                 None,
12976:             ),
12977:             (
12978:                 "proc return args {return CHANGED}; proc p {} {return VALUE}",
12979:                 None,
12980:             ),
12981:         ] {
12982:             let mut analyser = analyse(source, input(std::sync::Arc::clone(&context)));
12983:             assert_eq!(
12984:                 analyser
12985:                     .static_proc_result("::p", &[], &mut Vec::new(), 0)
12986:                     .as_deref(),
12987:                 expected,
12988:                 "{source}"
12989:             );
12990:         }
12991:         let mut availability_store = tcl_registry::CommandRegistry::build_default();
12992:         availability_store.insert(tcl_registry::CommandSpec {
12993:             name: "metadata_return_current",
12994:             surface: Some(tcl_dialect::model::SpecSurface::TCL86_PLUS),
12995:             ..availability_store.get("return").unwrap().clone()
12996:         });
12997:         let shared = availability_store.snapshot().shared_registry();
12998:         let current =
12999:             std::sync::Arc::new(context.with_command_store(std::sync::Arc::clone(&shared)));
13000:         let older = std::sync::Arc::new(
13001:             tcl_registry::model::ingress::resolve_environment("tcl8.4")
13002:                 .default_context_registry()
13003:                 .with_command_store(shared),
13004:         );
13005:         assert!(std::sync::Arc::ptr_eq(current.commands(), older.commands()));
13006:         let selected_source = "proc p {} {metadata_return_current VALUE}";
13007:         let mut selected = analyse(selected_source, input(current));
13008:         assert_eq!(
13009:             selected
13010:                 .static_proc_result("::p", &[], &mut Vec::new(), 0)
13011:                 .as_deref(),
13012:             Some("VALUE")
13013:         );
13014:         let mut unavailable = analyse(selected_source, input(older));
13015:         assert!(
13016:             unavailable
13017:                 .static_proc_result("::p", &[], &mut Vec::new(), 0)
13018:                 .is_none()
13019:         );
13020:         let source = "proc p {} {return VALUE}";
13021:         let mut missing = analyse(source, input(std::sync::Arc::clone(&context)));
13022:         missing.resolved_input = None;
13023:         missing.result.resolved_input = None;
13024:         assert!(
13025:             missing
13026:                 .static_proc_result("::p", &[], &mut Vec::new(), 0)
13027:                 .is_none()
13028:         );
13029:         let mut changed = analyse(source, input(std::sync::Arc::clone(&context)));
13030:         let mut altered = config;
13031:         altered.strict_quoting = !altered.strict_quoting;
13032:         let changed_input = super::super::ResolvedAnalysisInput::new(
13033:             profile,
13034:             profile,
13035:             std::sync::Arc::clone(&context),
13036:             altered,
13037:         );
13038:         changed.resolved_input = Some(changed_input.clone());
13039:         changed.result.resolved_input = Some(changed_input);
13040:         assert!(
13041:             changed
13042:                 .static_proc_result("::p", &[], &mut Vec::new(), 0)
13043:                 .is_none()
13044:         );
13045:         let mut store = tcl_registry::CommandRegistry::build_default();
13046:         store.insert(tcl_registry::CommandSpec {
13047:             name: "foreign_completion_axis",
13048:             ..tcl_registry::CommandSpec::DEFAULT
13049:         });
13050:         let foreign = std::sync::Arc::new(context.with_command_store(std::sync::Arc::new(store)));
13051:         let mut changed = analyse(source, input(std::sync::Arc::clone(&context)));
13052:         let foreign_input = input(foreign);
13053:         changed.resolved_input = Some(foreign_input.clone());
13054:         changed.result.resolved_input = Some(foreign_input);
13055:         assert!(
13056:             changed
13057:                 .static_proc_result("::p", &[], &mut Vec::new(), 0)
13058:                 .is_none()
13059:         );
13060:     }
13061: 
13062:     fn original_value_use_token(analyser: &Analyser, needle: &str) -> Token {
13063:         let start = u32::try_from(analyser.source.rfind(needle).unwrap()).unwrap();
13064:         let commands = crate::segmenter::segment_commands_with_offset_and_config(
13065:             analyser
13066:                 .source
13067:                 .get(usize::try_from(start).unwrap()..)
13068:                 .unwrap(),
13069:             start,
13070:             analyser.file_lexer_config().nested(),
13071:         );
13072:         commands.first().unwrap().argv[0]
13073:     }
13074: 
13075:     #[test]
13076:     fn logical_dynamic_word_keeps_exact_braced_name_and_interpolation_sources() {
13077:         let source =
13078:             "set n WRONG; set {$n} RIGHT; set {scalar(open} SCALAR; puts ${n}:${$n}:${scalar(open}";
13079:         let mut analyser = Analyser::new();
13080:         analyser.analyse_and_retain_result_for_test(source, "tcl");
13081:         let token = original_value_use_token(&analyser, "${n}:${$n}:${scalar(open}");
13082:         assert_eq!(
13083:             analyser.resolve_dynamic_word("${n}:${$n}:${scalar(open}", Some(token), false, &[]),
13084:             Some("WRONG:RIGHT:SCALAR".to_owned())
13085:         );
13086:         analyser.source = source.replace("RIGHT", "OTHER");
13087:         assert!(
13088:             analyser
13089:                 .resolve_dynamic_word("${n}:${$n}:${scalar(open}", Some(token), false, &[])
13090:                 .is_none()
13091:         );
13092:     }
13093: 
13094:     #[test]
13095:     fn logical_nested_constant_fold_uses_original_variable_components() {
13096:         let source = "set n WRONG; set {$n} RIGHT; set result [list $n [list ${$n}]]; puts $result";
13097:         let mut analyser = Analyser::new();
13098:         analyser.analyse_and_retain_result_for_test(source, "tcl");
13099:         let token = original_value_use_token(&analyser, "$result");
13100:         assert_eq!(
13101:             analyser
13102:                 .lookup_logical_const_substitution(token)
13103:                 .map(|(value, _)| value),
13104:             Some("WRONG RIGHT")
13105:         );
13106:     }
13107: 
13108:     #[test]
13109:     fn logical_regex_value_metadata_uses_original_scope_and_source_provenance() {
13110:         let source = "set pattern {ROOT}; proc p {} {set pattern {LOCAL}; regexp $pattern text}";
13111:         let mut analyser = Analyser::new();
13112:         analyser.analyse_and_retain_result_for_test(source, "tcl");
13113:         let source_use = source.rfind("$pattern").unwrap();
13114:         assert!(analyser.result.regex_patterns.iter().any(|pattern| {
13115:             pattern.pattern == "LOCAL"
13116:                 && usize::try_from(pattern.range.start()).unwrap() == source_use
13117:         }));
13118:         assert!(
13119:             !analyser
13120:                 .result
13121:                 .regex_patterns
13122:                 .iter()
13123:                 .any(|pattern| pattern.pattern == "ROOT")
13124:         );
13125:     }
13126: 
13127:     #[test]
13128:     fn logical_interpreter_handle_value_keeps_distinct_path_provenance_and_snapshot() {
13129:         let source = "set child [interp create named]; interp eval $child {set x VALUE}";
13130:         let mut analyser = Analyser::new();
13131:         analyser.analyse_and_retain_result_for_test(source, "tcl");
13132:         let token = original_value_use_token(&analyser, "$child");
13133:         assert_eq!(
13134:             analyser.resolve_dynamic_interp_path(Some(token)).as_deref(),
13135:             Some("named")
13136:         );
13137:         let snapshot = analyser.snapshot();
13138:         analyser.source = source.replace("VALUE", "OTHER");
13139:         assert!(analyser.resolve_dynamic_interp_path(Some(token)).is_none());
13140:         analyser.source = source.to_owned();
13141:         analyser.restore(snapshot);
13142:         assert_eq!(
13143:             analyser.resolve_dynamic_interp_path(Some(token)).as_deref(),
13144:             Some("named")
13145:         );
13146:         let source = "set child named; interp eval $child {set x VALUE}";
13147:         let mut scalar = Analyser::new();
13148:         scalar.analyse_and_retain_result_for_test(source, "tcl");
13149:         let token = original_value_use_token(&scalar, "$child");
13150:         assert!(scalar.resolve_dynamic_interp_path(Some(token)).is_none());
13151:     }
13152: 
13153:     #[test]
13154:     fn logical_dictionary_keys_have_metadata_and_data_geometry_without_variable_declarations() {
13155:         let source = "set d {alpha A beta B}; dict with d {puts $alpha}";
13156:         let mut analyser = Analyser::new();
13157:         analyser.analyse_and_retain_result_for_test(source, "tcl");
13158:         let scope = &analyser.result.global_scope;
13159:         assert!(!scope.variables.contains_key("alpha"));
13160:         assert!(!scope.variables.contains_key("beta"));
13161:         let alpha = scope.readonly_dictionary_keys.get("alpha").unwrap();
13162:         assert_eq!(
13163:             &source[alpha.original_key_span().unwrap().as_range()],
13164:             "alpha"
13165:         );
13166:         let image = tcl_lexer::SourceImage::document(source);
13167:         let advice = analyser
13168:             .result
13169:             .logical_variable_scope_advice(
13170:                 &image,
13171:                 analyser.file_lexer_config(),
13172:                 u32::try_from(source.rfind("$alpha").unwrap()).unwrap(),
13173:             )
13174:             .unwrap();
13175:         assert!(advice.readonly_variable_names().contains(&"alpha"));
13176:         assert!(advice.variable_definition("alpha").is_none());
13177:     }
13178: 
13179:     #[test]
13180:     fn logical_dictionary_metadata_retains_an_empty_variable_name() {
13181:         let source = "set d {{} EMPTY}; dict with d {puts ${}}";
13182:         let mut analyser = Analyser::new();
13183:         analyser.analyse_and_retain_result_for_test(source, "tcl");
13184:         let scope = &analyser.result.global_scope;
13185:         assert!(scope.readonly_dictionary_keys.contains_key(""));
13186:         assert!(!scope.variables.contains_key(""));
13187:     }
13188: 
13189:     #[test]
13190:     fn logical_dictionary_write_invalidates_the_previous_constant_value() {
13191:         let source = "set x OLD; set d {x NEW}; dict with d {puts $x}; puts $x";
13192:         let mut analyser = Analyser::new();
13193:         analyser.analyse_and_retain_result_for_test(source, "tcl");
13194:         let token = original_value_use_token(&analyser, "$x");
13195:         assert!(analyser.lookup_logical_const_substitution(token).is_none());
13196:         assert!(analyser.result.global_scope.variables.contains_key("x"));
13197:     }
13198: 
13199:     #[test]
13200:     fn logical_dictionary_write_invalidates_interpreter_handle_provenance() {
13201:         let source = "set child [interp create named]; set d {child other}; dict with d {}; interp eval $child {set x VALUE}";
13202:         let mut analyser = Analyser::new();
13203:         analyser.analyse_and_retain_result_for_test(source, "tcl");
13204:         let token = original_value_use_token(&analyser, "$child");
13205:         assert!(analyser.resolve_dynamic_interp_path(Some(token)).is_none());
13206:     }
13207: 
13208:     #[test]
13209:     fn logical_dictionary_metadata_masks_an_outer_procedure_name() {
13210:         let source = "set x ROOT; proc p {} {set d {x LOCAL}; dict with d {puts $x}}";
13211:         let mut analyser = Analyser::new();
13212:         analyser.analyse_and_retain_result_for_test(source, "tcl");
13213:         let token = original_value_use_token(&analyser, "$x");
13214:         let image = tcl_lexer::SourceImage::document(source);
13215:         let advice = analyser
13216:             .result
13217:             .logical_variable_scope_advice(&image, analyser.file_lexer_config(), token.span.start())
13218:             .unwrap();
13219:         assert!(advice.readonly_variable_names().contains(&"x"));
13220:         assert!(advice.variable_definition("x").is_none());
13221:         assert!(analyser.lookup_logical_const_substitution(token).is_none());
13222:     }
13223: 
13224:     #[test]
13225:     fn dynamic_apply_value_uses_checked_logical_variable_declaration() {
13226:         let source = "namespace eval N {set lambda {{p} {puts $p} ::N}}; apply $::N::lambda VALUE";
13227:         let mut analyser = Analyser::new();
13228:         analyser.analyse_and_retain_result_for_test(source, "tcl");
13229:         let token = tcl_lexer::Lexer::with_config(source, analyser.file_lexer_config())
13230:             .tokenise_all()
13231:             .unwrap()
13232:             .into_iter()
13233:             .find(|token| token.kind == TokenType::Var)
13234:             .unwrap();
13235:         let elements = analyser
13236:             .resolve_dynamic_apply_lambda(token)
13237:             .expect("original Logical namespace value");
13238:         assert_eq!(
13239:             elements
13240:                 .iter()
13241:                 .map(|(_, value)| value.as_str())
13242:                 .collect::<Vec<_>>(),
13243:             vec!["p", "puts $p", "::N"]
13244:         );
13245:         analyser.source = source.replace("VALUE", "OTHER");
13246:         assert!(analyser.resolve_dynamic_apply_lambda(token).is_none());
13247:     }
13248: 
13249:     #[test]
13250:     fn logical_defined_symbol_word_uses_current_value_provenance() {
13251:         let source = "set name SYMBOL; puts $name";
13252:         let mut analyser = Analyser::new();
13253:         analyser.analyse_and_retain_result_for_test(source, "tcl");
13254:         let token = tcl_lexer::Lexer::with_config(source, analyser.file_lexer_config())
13255:             .tokenise_all()
13256:             .unwrap()
13257:             .into_iter()
13258:             .find(|token| token.kind == TokenType::Var)
13259:             .unwrap();
13260:         assert_eq!(
13261:             analyser.defined_symbol_reporting_name(None, None, "$name", token, true, &[]),
13262:             Some("SYMBOL".to_owned())
13263:         );
13264:         let original = analyser.snapshot();
13265:         analyser.result.resolved_input = None;
13266:         assert!(
13267:             analyser
13268:                 .defined_symbol_reporting_name(None, None, "$name", token, true, &[])
13269:                 .is_none()
13270:         );
13271:         analyser.restore(original);
13272:         assert_eq!(
13273:             analyser.resolve_const_word("$name", token, true),
13274:             Some("SYMBOL".to_owned())
13275:         );
13276:     }
13277: 
13278:     #[test]
13279:     fn dict_with_value_uses_checked_logical_scope() {
13280:         let source =
13281:             "set d {root ROOT}; namespace eval N {set d {local LOCAL}; dict with d {puts $local}}";
13282:         let mut analyser = Analyser::new();
13283:         analyser.analyse_and_retain_result_for_test(source, "tcl");
13284:         let namespace = analyser
13285:             .result
13286:             .global_scope
13287:             .children
13288:             .iter()
13289:             .find(|scope| scope.kind == super::super::types::ScopeKind::Namespace)
13290:             .unwrap();
13291:         assert!(namespace.readonly_dictionary_keys.contains_key("local"));
13292:         assert!(!namespace.readonly_dictionary_keys.contains_key("root"));
13293:         assert!(!namespace.variables.contains_key("local"));
13294:         let key = &namespace.readonly_dictionary_keys["local"];
13295:         assert_eq!(
13296:             &source[key.original_key_span().unwrap().as_range()],
13297:             "local"
13298:         );
13299:         let source = "set d {root ROOT}; proc p {} {dict with d {puts $root}}";
13300:         let mut procedure = Analyser::new();
13301:         procedure.analyse_and_retain_result_for_test(source, "tcl");
13302:         let local = procedure
13303:             .result
13304:             .global_scope
13305:             .children
13306:             .iter()
13307:             .find(|scope| scope.kind == super::super::types::ScopeKind::Proc)
13308:             .unwrap();
13309:         assert!(!local.variables.contains_key("root"));
13310:     }
13311: 
13312:     #[test]
13313:     fn dynamic_apply_scanner_uses_irules_brace_boundary_config() {
13314:         // naming.compiler.original-analysis-metadata-context
13315:         // docs/design/analysis/name-resolution-proofs/original-analysis-metadata-context.md
13316:         // An original Logical builder with the supplied lexer overlay, without
13317:         // any Native/F5 list execution or lambda-frame claim.
13318:         let source = "set lambda [list {p} {set y}{set z}]";
13319:         let profile = tcl_dialect::DialectProfile::plain_tcl();
13320:         let config = tcl_lexer::LexerConfig::for_dialect("f5-irules");
13321:         let context =
13322:             tcl_registry::model::ingress::resolve_environment("tcl9.0").default_context_registry();
13323:         let input = super::super::ResolvedAnalysisInput::new(profile, profile, context, config);
13324:         let mut analyser = Analyser::new().with_resolved_input(input);
13325:         analyser.result = analyser.analyse(source, "tcl");
13326:         let token = tcl_lexer::Lexer::with_source_map(tcl_lexer::SourceMap::new(source), config)
13327:             .tokenise_all()
13328:             .expect("valid command substitution")
13329:             .into_iter()
13330:             .find(|token| token.kind == tcl_lexer::TokenType::Cmd)
13331:             .expect("command token");
13332:         let elements = analyser
13333:             .resolve_dynamic_apply_lambda(token)
13334:             .expect("original literal list lambda");
13335:         assert_eq!(elements.len(), 3, "iRules list elements: {elements:?}");
13336:         let mut missing = Analyser::new();
13337:         missing.source = source.to_owned();
13338:         missing.profile = tcl_dialect::DialectProfile::irules();
13339:         assert!(
13340:             missing.resolve_dynamic_apply_lambda(token).is_none(),
13341:             "a profile and authored source do not supply the original builder"
13342:         );
13343:     }
13344: 
13345:     #[test]
13346:     fn builtin_next_completion_requires_the_actual_mro_end() {
13347:         assert_eq!(
13348:             Analyser::builtin_next_completion(
13349:                 &tcl_registry::definer::TCLOO_GRAMMAR,
13350:                 "unknown",
13351:                 0,
13352:                 2,
13353:             ),
13354:             None
13355:         );
13356:         assert_eq!(
13357:             Analyser::builtin_next_completion(
13358:                 &tcl_registry::definer::TCLOO_GRAMMAR,
13359:                 "unknown",
13360:                 1,
13361:                 2,
13362:             ),
13363:             Some(true)
13364:         );
13365:     }
13366: 
13367:     #[test]
13368:     fn dynamic_command_name_patterns_keep_only_proven_fixed_fragments() {
13369:         assert!(!dynamic_command_name_may_equal(
13370:             "${ns}::define::$method",
13371:             "::string"
13372:         ));
13373:         assert!(dynamic_command_name_may_equal("$name", "::string"));
13374:         assert!(dynamic_command_name_may_equal(
13375:             "${ns}::::helper",
13376:             "::T::helper"
13377:         ));
13378:         assert!(dynamic_command_name_may_equal(
13379:             "$array(index)::define",
13380:             "::anything"
13381:         ));
13382:     }
13383: 
13384:     #[test]
13385:     fn static_write_invalidation_preserves_scalar_parenthesis_names() {
13386:         for name in ["a(b", "a(b)tail", "a(b)"] {
13387:             let source = format!("set {name} VALUE");
13388:             let mut analyser = Analyser::new();
13389:             analyser.analyse_and_retain_result_for_test(&source, "tcl");
13390:             let command = crate::segmenter::segment_commands_with_offset_and_config(
13391:                 &source,
13392:                 0,
13393:                 analyser.file_lexer_config().nested(),
13394:             )
13395:             .remove(0);
13396:             let mut values = std::collections::HashMap::from([
13397:                 ("a".to_owned(), "ROOT".to_owned()),
13398:                 ("a(b".to_owned(), "OPEN".to_owned()),
13399:                 ("a(b)tail".to_owned(), "SUFFIX".to_owned()),
13400:             ]);
13401:             analyser
13402:                 .invalidate_static_facts_written_by_segment(&command, &mut values, 0)
13403:                 .unwrap();
13404:             let root = if name == "a(b)" { "a" } else { name };
13405:             assert!(!values.contains_key(root));
13406:             assert_eq!(values.len(), 2);
13407:         }
13408:     }
13409: 
13410:     #[test]
13411:     fn command_mutation_matching_preserves_constructed_colon_keys() {
13412:         assert!(dynamic_command_name_may_equal("p", ":::::p"));
13413:         assert!(dynamic_command_name_may_equal(":p", ":::p"));
13414:         assert!(!dynamic_command_name_may_equal(":p", ":::::p"));
13415:         // Written separator runs canonicalise once; an already constructed
13416:         // namespace key must not be interpreted as that written spelling.
13417:         assert!(dynamic_command_name_may_equal(":::::p", "::p"));
13418:         assert!(!dynamic_command_name_may_equal(":::::p", ":::::p"));
13419:         assert!(dynamic_command_name_may_equal("x:::y", "::x::y"));
13420:         assert!(dynamic_command_name_may_equal("x:::", "::x::"));
13421:         assert!(!dynamic_command_name_may_equal("x:::y", "::x:::y"));
13422:     }
13423: 
13424:     fn class_observation(superclass: Option<&str>, factory: bool) -> ClassDef {
13425:         ClassDef {
13426:             name: "class".to_owned(),
13427:             qualified_name: "::T::D::class".to_owned(),
13428:             superclasses: superclass.into_iter().map(str::to_owned).collect(),
13429:             factory: factory.then(|| ClassFactory {
13430:                 root_metaclass: "oo::class".to_owned(),
13431:                 ..ClassFactory::default()
13432:             }),
13433:             ..ClassDef::default()
13434:         }
13435:     }
13436: 
13437:     #[test]
13438:     fn parameterised_class_join_is_monotone_across_incomplete_observations() {
13439:         let proved = class_observation(Some("::T::Mother"), true);
13440:         let incomplete = class_observation(None, false);
13441: 
13442:         let later_incomplete = join_parameterised_class_observations(&proved, &incomplete).unwrap();
13443:         assert_eq!(later_incomplete.superclasses, vec!["::T::Mother"]);
13444:         assert!(later_incomplete.factory.is_some());
13445: 
13446:         let later_proof = join_parameterised_class_observations(&incomplete, &proved).unwrap();
13447:         assert_eq!(later_proof.superclasses, vec!["::T::Mother"]);
13448:         assert!(later_proof.factory.is_some());
13449:     }
13450: 
13451:     #[test]
13452:     fn parameterised_class_join_abstains_on_conflicting_concrete_relations() {
13453:         let left = class_observation(Some("::T::Mother"), true);
13454:         let right = class_observation(Some("::T::OtherMother"), true);
13455:         assert!(join_parameterised_class_observations(&left, &right).is_none());
13456:     }
13457: 
13458:     #[test]
13459:     fn parameterised_class_join_ignores_an_unobserved_metaclass() {
13460:         // The `oo::define` stub's `"oo::class"` is
13461:         // `ClassDef::default()`'s stand-in, not something a walk read, so it
13462:         // must neither contradict the proved `::T::Mother` nor survive into
13463:         // the joined record.
13464:         let stub = class_observation(None, false);
13465:         assert_ne!(stub.metaclass_provenance, MetaclassProvenance::Observed);
13466:         let proved = ClassDef {
13467:             metaclass: "::T::Mother".to_owned(),
13468:             metaclass_provenance: MetaclassProvenance::Observed,
13469:             ..class_observation(Some("::T::Mother"), true)
13470:         };
13471: 
13472:         for (existing, observed) in [(&stub, &proved), (&proved, &stub)] {
13473:             let joined = join_parameterised_class_observations(existing, observed)
13474:                 .expect("a stand-in metaclass is not conflicting evidence");
13475:             assert_eq!(joined.metaclass, "::T::Mother");
13476:             assert_eq!(joined.metaclass_provenance, MetaclassProvenance::Observed);
13477:             assert_eq!(joined.superclasses, vec!["::T::Mother"]);
13478:             assert!(joined.factory.is_some());
13479:         }
13480:     }
13481: 
13482:     #[test]
13483:     fn parameterised_class_join_abstains_on_two_observed_metaclasses() {
13484:         // FP guard for the gate above: once *both* sides read a head word,
13485:         // a disagreement is still a real conflict.
13486:         let left = ClassDef {
13487:             metaclass: "::T::Mother".to_owned(),
13488:             metaclass_provenance: MetaclassProvenance::Observed,
13489:             ..class_observation(None, true)
13490:         };
13491:         let right = ClassDef {
13492:             metaclass: "::T::OtherMother".to_owned(),
13493:             metaclass_provenance: MetaclassProvenance::Observed,
13494:             ..class_observation(None, true)
13495:         };
13496:         assert!(join_parameterised_class_observations(&left, &right).is_none());
13497:         // …and identical observed metaclasses still join.
13498:         assert!(join_parameterised_class_observations(&left, &left).is_some());
13499:     }
13500: 
13501:     fn esc_tok(span: Span) -> Token {
13502:         Token::new(TokenType::Esc, span)
13503:     }
13504: 
13505:     fn str_tok(span: Span) -> Token {
13506:         Token {
13507:             kind: TokenType::Str,
13508:             span,
13509:             content_offset: 1,
13510:             in_quote: false,
13511:         }
13512:     }
13513: 
13514:     fn span(start: u32, end: u32) -> Span {
13515:         Span::new(start, end)
13516:     }
13517: 
13518:     // Explicit standalone word-shape controls use the shared lexer owner.
13519:     fn elements(text: &str) -> Option<Vec<String>> {
13520:         let (head, args) = crate::value_shapes::parse_command_substitution_with_config(
13521:             text,
13522:             tcl_lexer::LexerConfig::default(),
13523:         )?;
13524:         Some(std::iter::once(head).chain(args).collect())
13525:     }
13526: 
13527:     #[test]
13528:     fn interp_create_value_words_strip_a_single_braced_path_issue_1025() {
13529:         // TP — `{child}` is one Tcl word naming interpreter `child`; the
13530:         // direct handler sees it segmenter-decoded, so the value-flow path
13531:         // must strip the braces too rather than binding to `"{child}"`.
13532:         assert_eq!(
13533:             elements("[interp create {child}]"),
13534:             Some(vec!["interp".into(), "create".into(), "child".into()])
13535:         );
13536:     }
13537: 
13538:     #[test]
13539:     fn interp_create_value_words_keep_a_nested_path_as_one_word_issue_1025() {
13540:         // TP — `{parent child}` is one word (a descent path), not two.
13541:         // `split_whitespace` would yield `["{parent", "child}"]`, whose first
13542:         // fragment would become the bound key.
13543:         assert_eq!(
13544:             elements("[interp create {parent child}]"),
13545:             Some(vec![
13546:                 "interp".into(),
13547:                 "create".into(),
13548:                 "parent child".into()
13549:             ])
13550:         );
13551:     }
13552: 
13553:     #[test]
13554:     fn interp_create_value_words_unchanged_for_bare_and_flagged_forms_issue_1025() {
13555:         // TN — the shapes that already worked must be byte-for-byte
13556:         // unchanged by the switch to list parsing.
13557:         assert_eq!(
13558:             elements("[interp create -safe -- name]"),
13559:             Some(vec![
13560:                 "interp".into(),
13561:                 "create".into(),
13562:                 "-safe".into(),
13563:                 "--".into(),
13564:                 "name".into()
13565:             ])
13566:         );
13567:         assert_eq!(
13568:             elements("[interp create]"),
13569:             Some(vec!["interp".into(), "create".into()])
13570:         );
13571:         // Only one whole bracketed substitution is a call.
13572:         assert_eq!(elements("interp create child"), None);
13573:     }
13574: 
13575:     #[test]
13576:     fn interp_create_value_words_reject_an_unmatched_brace_issue_1025() {
13577:         // A malformed (mid-edit) path is not a list at all, so the whole
13578:         // substitution is rejected. Returning the prefix parsed before the
13579:         // error instead would read as a bare `interp create`, binding the
13580:         // variable to an auto-named interpreter real Tcl never creates.
13581:         // Later `$i eval` / `interp alias $i …` sites then resolve against
13582:         // that phantom.
13583:         assert_eq!(elements("[interp create {child]"), None);
13584:         assert_eq!(
13585:             elements("[interp create good {child]"),
13586:             None,
13587:             "a valid prefix does not rescue a malformed tail",
13588:         );
13589:     }
13590: 
13591:     // `interp create` — the registry's `InterpreterTransition::Create`,
13592:     // whose option scan mirrors tclInterp.c (`create_reads_the_c_option_scan`
13593:     // in `tcl-registry`'s `interp.rs` pins every row against tclsh 8.4–9.1).
13594: 
13595:     /// Dispatch `interp create WORDS…` and report whether `path` was
13596:     /// recorded, and as safe.
13597:     fn created_by(words: &[&str], path: &str) -> Option<bool> {
13598:         let mut a = Analyser::new();
13599:         let call: Vec<&str> = ["interp", "create"]
13600:             .into_iter()
13601:             .chain(words.iter().copied())
13602:             .collect();
13603:         dispatch_words(&mut a, &call);
13604:         let key = a.qualified_interp_key(path);
13605:         a.interpreters.get(&key).map(|state| state.safe)
13606:     }
13607: 
13608:     #[test]
13609:     fn interp_create_flags_are_still_scanned_after_the_path() {
13610:         // C Tcl examines every word and treats a `-` word as a flag until
13611:         // `--`, whether or not the path has been read. tclsh8.6/9.0:
13612:         // `interp create x -safe` yields `interp issafe x` == 1. Stopping at
13613:         // the path recorded `x` as an *unsafe* interpreter.
13614:         assert_eq!(created_by(&["x", "-safe"], "x"), Some(true));
13615:         assert_eq!(created_by(&["-safe", "y"], "y"), Some(true));
13616:         // `-safe` matches by unique prefix.
13617:         assert_eq!(created_by(&["-s", "x"], "x"), Some(true));
13618:     }
13619: 
13620:     #[test]
13621:     fn interp_create_double_dash_ends_flag_parsing() {
13622:         // tclsh8.6/9.0: `interp create -safe -- z` creates a safe `z`, and
13623:         // `interp create -- -safe` creates an *unsafe* interpreter whose
13624:         // path is the literal `-safe`.
13625:         assert_eq!(created_by(&["-safe", "--", "z"], "z"), Some(true));
13626:         assert_eq!(created_by(&["--", "-safe"], "-safe"), Some(false));
13627:     }
13628: 
13629:     #[test]
13630:     fn interp_create_two_path_words_record_no_path() {
13631:         // tclsh8.6/9.0: `interp create a b` is `wrong # args`, and `interp
13632:         // create n -bogus` a bad option. No interpreter is created, so
13633:         // recording either word would bind a name that does not exist.
13634:         assert_eq!(created_by(&["a", "b"], "a"), None);
13635:         assert_eq!(created_by(&["a", "b"], "b"), None);
13636:         assert_eq!(created_by(&["n", "-bogus"], "n"), None);
13637:         assert_eq!(
13638:             created_by(&["--", "x", "-safe"], "x"),
13639:             None,
13640:             "after `--` a second `-` word is a path word, so this is the error shape too",
13641:         );
13642:     }
13643: 
13644:     #[test]
13645:     fn interp_create_bare_and_flag_only_forms_are_unchanged() {
13646:         // TN control: a named child is recorded; an auto-named one has no
13647:         // name this file can reference, so nothing is.
13648:         assert_eq!(created_by(&["child"], "child"), Some(false));
13649:         let mut a = Analyser::new();
13650:         dispatch_words(&mut a, &["interp", "create", "-safe"]);
13651:         assert!(a.interpreters.is_empty());
13652:         // A computed path makes interpreter existence unknowable.
13653:         let mut a = Analyser::new();
13654:         dispatch_words(&mut a, &["interp", "create", "$name"]);
13655:         assert!(a.interpreters.is_empty());
13656:         assert!(a.dynamic_interp_ops);
13657:     }
13658: 
13659:     // `set`'s binding through the generic dispatch tail — the role binding
13660:     // and `bind_value_word_assignment`; `set` has no analyser hook.
13661: 
13662:     /// Dispatch one command whose words carry the given tokens and
13663:     /// single-token flags, through `process_command` exactly as a walked
13664:     /// command reaches it.
13665:     fn dispatch_tokens(a: &mut Analyser, words: &[(&str, Token, bool)]) {
13666:         let owned: Vec<String> = words.iter().map(|(w, _, _)| (*w).to_string()).collect();
13667:         let toks: Vec<Token> = words.iter().map(|&(_, tok, _)| tok).collect();
13668:         let single: Vec<bool> = words.iter().map(|&(_, _, single)| single).collect();
13669:         let expanded = vec![false; owned.len()];
13670:         a.process_command(&owned, &toks, &single, &expanded, &[]);
13671:     }
13672: 
13673:     #[test]
13674:     fn handle_set_defines_variable() {
13675:         let mut a = Analyser::new();
13676:         dispatch_tokens(
13677:             &mut a,
13678:             &[
13679:                 ("set", esc_tok(span(0, 3)), true),
13680:                 ("x", esc_tok(span(4, 5)), true),
13681:                 ("1", esc_tok(span(6, 7)), true),
13682:             ],
13683:         );
13684:         assert!(a.result.global_scope.variables.contains_key("x"));
13685:         assert!(a.result.global_scope.variables["x"].warn_if_unused);
13686:     }
13687: 
13688:     #[test]
13689:     fn handle_set_tracks_single_token_literal_value() {
13690:         let mut a = Analyser::new();
13691:         dispatch_tokens(
13692:             &mut a,
13693:             &[
13694:                 ("set", esc_tok(span(0, 3)), true),
13695:                 ("x", esc_tok(span(4, 5)), true),
13696:                 ("hello", esc_tok(span(6, 11)), true),
13697:             ],
13698:         );
13699:         assert_eq!(
13700:             a.const_strings
13701:                 .get(&Vec::new())
13702:                 .and_then(|values| values.get("x"))
13703:                 .map(|(value, _)| value.as_str()),
13704:             Some("hello")
13705:         );
13706:     }
13707: 
13708:     #[test]
13709:     fn handle_set_tracks_braced_string_value() {
13710:         let mut a = Analyser::new();
13711:         dispatch_tokens(
13712:             &mut a,
13713:             &[
13714:                 ("set", esc_tok(span(0, 3)), true),
13715:                 ("x", esc_tok(span(4, 5)), true),
13716:                 ("hello world", str_tok(span(6, 19)), true),
13717:             ],
13718:         );
13719:         assert_eq!(
13720:             a.const_strings
13721:                 .get(&Vec::new())
13722:                 .and_then(|values| values.get("x"))
13723:                 .map(|(value, _)| value.as_str()),
13724:             Some("hello world")
13725:         );
13726:     }
13727: 
13728:     #[test]
13729:     fn handle_set_clears_const_string_for_interpolated_value() {
13730:         let mut a = Analyser::new();
13731:         // Pre-seed a constant tracking entry.
13732:         a.set_const_string("x", "old".to_string(), span(0, 0), &[]);
13733:         // Re-assign with a multi-token (interpolation) value — the value
13734:         // word is not one token, so the const string is cleared.
13735:         dispatch_tokens(
13736:             &mut a,
13737:             &[
13738:                 ("set", esc_tok(span(0, 3)), true),
13739:                 ("x", esc_tok(span(4, 5)), true),
13740:                 ("$other", esc_tok(span(6, 12)), false),
13741:             ],
13742:         );
13743:         assert_eq!(
13744:             a.const_strings
13745:                 .get(&Vec::new())
13746:                 .and_then(|values| values.get("x"))
13747:                 .map(|(value, _)| value.as_str()),
13748:             None
13749:         );
13750:     }
13751: 
13752:     #[test]
13753:     fn handle_set_no_value_records_read_not_definition() {
13754:         // ``set x`` (one-arg form) is a *read*, not a definition — Tcl
13755:         // returns the current value of ``x`` — recorded by the walk's
13756:         // `VarRead`-role reference pass, with no const-string tracking.
13757:         let src = "set x 1\nset x\n";
13758:         let mut a = Analyser::new();
13759:         let r = a.analyse(src, "tcl8.6");
13760:         let read = u32::try_from(src.rfind('x').expect("the read")).expect("an offset");
13761:         assert_eq!(
13762:             r.global_scope.variables["x"].references,
13763:             vec![span(read, read + 1)],
13764:         );
13765:         let mut read_only = Analyser::new();
13766:         dispatch_tokens(
13767:             &mut read_only,
13768:             &[
13769:                 ("set", esc_tok(span(0, 3)), true),
13770:                 ("x", esc_tok(span(4, 5)), true),
13771:             ],
13772:         );
13773:         assert_eq!(
13774:             read_only
13775:                 .const_strings
13776:                 .get(&Vec::new())
13777:                 .and_then(|values| values.get("x"))
13778:                 .map(|(value, _)| value.as_str()),
13779:             None
13780:         );
13781:     }
13782: 
13783:     /// A literal value word is recorded as Tcl reads it: the
13784:     /// `CellWrite` evaluation cooks a bare or quoted token, so `set p
13785:     /// "a\\d"` holds `a\d` — tclsh 8.4.20 to 9.1b0 print `a\d`.
13786:     #[test]
13787:     fn a_literal_value_word_is_recorded_as_tcl_reads_it() {
13788:         let mut a = Analyser::new();
13789:         dispatch_tokens(
13790:             &mut a,
13791:             &[
13792:                 ("set", esc_tok(span(0, 3)), true),
13793:                 ("p", esc_tok(span(4, 5)), true),
13794:                 ("a\\\\d", esc_tok(span(6, 12)), true),
13795:             ],
13796:         );
13797:         assert_eq!(
13798:             a.const_strings
13799:                 .get(&Vec::new())
13800:                 .and_then(|values| values.get("p"))
13801:                 .map(|(value, _)| value.as_str()),
13802:             Some("a\\d")
13803:         );
13804:     }
13805: 
13806:     /// A computed target defines no variable: `set $n 1` writes
13807:     /// the variable `n` names — tclsh 8.4.20 to 9.1b0 leave `n` as it was
13808:     /// — so the role binding's static-name rule binds nothing.
13809:     #[test]
13810:     fn a_computed_set_target_defines_no_variable() {
13811:         let r = Analyser::new().analyse("set $n 1\n", "tcl8.6");
13812:         assert!(!r.global_scope.variables.contains_key("n"));
13813:     }
13814: 
13815:     #[test]
13816:     fn handle_set_no_value_undefined_var_is_silent() {
13817:         // ``set x`` on an undefined variable is still a read; the read
13818:         // recording silently no-ops when the name isn't in scope, so no
13819:         // spurious binding lands.
13820:         let r = Analyser::new().analyse("set x\n", "tcl8.6");
13821:         assert!(!r.global_scope.variables.contains_key("x"));
13822:     }
13823: 
13824:     // Scope aliases through the generic consumer — the dispatch tail's
13825:     // `apply_state_transitions`, reached by `process_command` exactly as a
13826:     // walked command reaches it.
13827: 
13828:     /// Dispatch one command whose words are bare (`Esc`) tokens four bytes
13829:     /// apart — a word carrying `$` or `[` reads as computed, as it would in
13830:     /// source.
13831:     fn dispatch_words(a: &mut Analyser, words: &[&str]) {
13832:         let owned: Vec<String> = words.iter().map(|s| (*s).to_string()).collect();
13833:         let toks: Vec<Token> = (0..owned.len())
13834:             .map(|i| {
13835:                 let at = u32::try_from(i).unwrap() * 4;
13836:                 esc_tok(span(at, at + 1))
13837:             })
13838:             .collect();
13839:         let single = vec![true; owned.len()];
13840:         let expanded = vec![false; owned.len()];
13841:         a.process_command(&owned, &toks, &single, &expanded, &[]);
13842:     }
13843: 
13844:     #[test]
13845:     fn handle_global_defines_each_name() {
13846:         let mut a = Analyser::new();
13847:         dispatch_words(&mut a, &["global", "x", "y", "z"]);
13848:         for name in ["x", "y", "z"] {
13849:             assert!(a.result.global_scope.variables.contains_key(name));
13850:             assert!(!a.result.global_scope.variables[name].warn_if_unused);
13851:             assert_eq!(
13852:                 a.result.global_scope.variables[name].link_target.as_deref(),
13853:                 Some(format!("::{name}").as_str()),
13854:             );
13855:         }
13856:     }
13857: 
13858:     #[test]
13859:     fn global_binds_the_tail_of_a_qualified_name_and_skips_a_computed_one() {
13860:         let mut a = Analyser::new();
13861:         dispatch_words(&mut a, &["global", "::ns::v", "$dyn"]);
13862:         let v = &a.result.global_scope.variables["v"];
13863:         assert_eq!(v.link_target.as_deref(), Some("::ns::v"));
13864:         // The declaration word names the cell, so a rename rewrites it.
13865:         assert_eq!(v.link_target_span, Some(span(4, 5)));
13866:         assert!(!a.result.global_scope.variables.contains_key("dyn"));
13867:         assert!(!a.result.global_scope.variables.contains_key("$dyn"));
13868:     }
13869: 
13870:     #[test]
13871:     fn handle_variable_defines_only_names_skipping_values() {
13872:         let mut a = Analyser::new();
13873:         // `variable x 1 y 2 z` — names at 0, 2, 4; values at 1, 3.
13874:         dispatch_words(&mut a, &["variable", "x", "1", "y", "2", "z"]);
13875:         for name in ["x", "y", "z"] {
13876:             assert!(a.result.global_scope.variables.contains_key(name));
13877:         }
13878:         // Numbers should NOT be variable names.
13879:         assert!(!a.result.global_scope.variables.contains_key("1"));
13880:         assert!(!a.result.global_scope.variables.contains_key("2"));
13881:     }
13882: 
13883:     #[test]
13884:     fn handle_variable_single_name_no_value() {
13885:         let mut a = Analyser::new();
13886:         dispatch_words(&mut a, &["variable", "x"]);
13887:         assert!(a.result.global_scope.variables.contains_key("x"));
13888:         // At the top level the current namespace is the global one.
13889:         assert_eq!(
13890:             a.result.global_scope.variables["x"].link_target.as_deref(),
13891:             Some("::x"),
13892:         );
13893:     }
13894: 
13895:     #[test]
13896:     fn declaration_aliases_use_selected_native_name_owner() {
13897:         for version in tcl_dialect::TclVersion::ALL {
13898:             let mut analyser = Analyser::new();
13899:             analyser.source_analysis_entry = Some(std::sync::Arc::new(
13900:                 crate::command_binding::SourceAnalysisEntry {
13901:                     invocation_dialect: Some(tcl_registry::InvocationDialect::for_version(version)),
13902:                     ..Default::default()
13903:                 },
13904:             ));
13905:             analyser.handle_global_command(&["ns:::v".to_owned()], &[esc_tok(span(0, 6))], &[]);
13906:             assert!(analyser.result.global_scope.variables.contains_key("v"));
13907:             assert!(!analyser.result.global_scope.variables.contains_key(":v"));
13908:             assert_eq!(
13909:                 analyser.result.global_scope.variables["v"]
13910:                     .link_target
13911:                     .as_deref(),
13912:                 Some("::ns::v"),
13913:             );
13914:         }
13915:         let mut analyser = Analyser::new();
13916:         analyser.source_analysis_entry = Some(std::sync::Arc::new(
13917:             crate::command_binding::SourceAnalysisEntry {
13918:                 invocation_dialect: Some(tcl_registry::InvocationDialect::of_profile(
13919:                     tcl_registry::model::ingress::resolve_environment("jim").unit_profile(),
13920:                 )),
13921:                 ..Default::default()
13922:             },
13923:         ));
13924:         analyser.handle_global_command(&["::ns::v".to_owned()], &[esc_tok(span(0, 7))], &[]);
13925:         assert!(!analyser.result.global_scope.variables.contains_key("v"));
13926:         analyser.handle_variable_command(&["::ns:::v".to_owned()], &[esc_tok(span(0, 8))], &[]);
13927:         assert!(analyser.result.global_scope.variables.contains_key("v"));
13928:     }
13929: 
13930:     // handle_upvar_command — the `otherVar` link
13931: 
13932:     #[test]
13933:     fn namespace_upvar_links_each_local_to_its_namespace_cell() {
13934:         // `namespace upvar ns other local` — `other` resolved within `ns`
13935:         // and kept whole (`b::c` is `::a::b::c`, not the tail-collapsed
13936:         // `::a::c`), `ns` relative to the current namespace; the rename span
13937:         // is the `other` word, not the local.
13938:         let mut a = Analyser::new();
13939:         dispatch_words(
13940:             &mut a,
13941:             &["namespace", "upvar", "::a", "b::c", "l", "d", "m"],
13942:         );
13943:         let l = &a.result.global_scope.variables["l"];
13944:         assert_eq!(l.link_target.as_deref(), Some("::a::b::c"));
13945:         assert_eq!(l.link_target_span, Some(span(12, 13)));
13946:         assert_eq!(
13947:             a.result.global_scope.variables["m"].link_target.as_deref(),
13948:             Some("::a::d"),
13949:         );
13950:     }
13951: 
13952:     #[test]
13953:     fn namespace_upvar_with_a_computed_word_keeps_the_cell_as_written() {
13954:         // A computed local binds nothing.
13955:         let mut a = Analyser::new();
13956:         dispatch_words(&mut a, &["namespace", "upvar", "::a", "x", "$local"]);
13957:         assert!(!a.result.global_scope.variables.contains_key("local"));
13958:         // Legacy alias reports preserve computed namespace/otherVar spellings.
13959:         // Core candidates and rename coverage use typed source receipts instead.
13960:         let mut a = Analyser::new();
13961:         dispatch_words(&mut a, &["namespace", "upvar", "$ns", "x", "l"]);
13962:         assert_eq!(
13963:             a.result.global_scope.variables["l"].link_target.as_deref(),
13964:             Some("::$ns::x"),
13965:         );
13966:         // The cell is named by the `otherVar` word, not the local.
13967:         assert_eq!(
13968:             a.result.global_scope.variables["l"].link_target_span,
13969:             Some(span(12, 13)),
13970:         );
13971:         let mut a = Analyser::new();
13972:         dispatch_words(&mut a, &["namespace", "upvar", "::mypkg", "$v", "l"]);
13973:         assert_eq!(
13974:             a.result.global_scope.variables["l"].link_target.as_deref(),
13975:             Some("::mypkg::$v"),
13976:         );
13977:         // An absolute `otherVar` names its cell whatever the namespace word.
13978:         let mut a = Analyser::new();
13979:         dispatch_words(&mut a, &["namespace", "upvar", "$ns", "::abs", "l"]);
13980:         assert_eq!(
13981:             a.result.global_scope.variables["l"].link_target.as_deref(),
13982:             Some("::abs"),
13983:         );
13984:     }
13985: 
13986:     // `upvar` — the `otherVar` link
13987: 
13988:     /// Dispatch `upvar <args>` and report the alias's link target, if it got
13989:     /// one.
13990:     fn upvar_link_of(args: &[&str], local: &str) -> Option<String> {
13991:         let mut a = Analyser::new();
13992:         let words: Vec<&str> = std::iter::once("upvar")
13993:             .chain(args.iter().copied())
13994:             .collect();
13995:         dispatch_words(&mut a, &words);
13996:         a.result
13997:             .global_scope
13998:             .variables
13999:             .get(local)
14000:             .and_then(|v| v.link_target.clone())
14001:     }
14002: 
14003:     #[test]
14004:     fn upvar_links_a_fully_qualified_other_var_at_any_level() {
14005:         // `upvar 1 ::myns::q g` binds `::myns::q` from any call depth
14006:         // (tclsh 9.0.4 / 8.6.14: reached identically through `upvar 1` and
14007:         // `upvar 2`), so the alias has a stable cell to link to.
14008:         assert_eq!(
14009:             upvar_link_of(&["1", "::myns::q", "g"], "g"),
14010:             Some("::myns::q".to_string()),
14011:         );
14012:         assert_eq!(
14013:             upvar_link_of(&["2", "::myns::q", "g"], "g"),
14014:             Some("::myns::q".to_string()),
14015:         );
14016:     }
14017: 
14018:     #[test]
14019:     fn upvar_links_an_array_other_var_to_its_base() {
14020:         // tk.tcl:177 `upvar ::tk::FocusGrab($index) data` — the element key
14021:         // is runtime data, the array is the named cell every sibling access
14022:         // shares.
14023:         assert_eq!(
14024:             upvar_link_of(&["::tk::FocusGrab($index)", "data"], "data"),
14025:             Some("::tk::FocusGrab".to_string()),
14026:         );
14027:     }
14028: 
14029:     #[test]
14030:     fn logical_upvar_targets_share_literal_scalar_and_element_geometry() {
14031:         // naming.compiler.logical-upvar-target-element-geometry
14032:         // docs/design/analysis/name-resolution-proofs/logical-upvar-target-element-geometry.md
14033:         // These are readonly Logical source coordinates, not executed links.
14034:         // Literal name parsing must preserve a scalar's unmatched parenthesis
14035:         // and must not strip substitution sigils before the dynamic refusal.
14036:         for (other, expected) in [
14037:             ("a(b", Some("::a(b")),
14038:             ("a(b)c", Some("::a(b)c")),
14039:             ("a(b)", Some("::a")),
14040:             ("π(β", Some("::π(β")),
14041:             ("π(β)", Some("::π")),
14042:             ("a($key)", Some("::a")),
14043:             ("::ns::a(b", Some("::ns::a(b")),
14044:             ("$computed", None),
14045:         ] {
14046:             let source = format!("upvar #0 {{{other}}} local");
14047:             let analysis = Analyser::new().analyse(&source, "tcl");
14048:             assert!(analysis.allows_retained_logical_declaration_advice());
14049:             assert_eq!(
14050:                 analysis.global_scope.variables["local"]
14051:                     .link_target
14052:                     .as_deref(),
14053:                 expected,
14054:                 "{source}",
14055:             );
14056:         }
14057:     }
14058: 
14059:     #[test]
14060:     fn upvar_at_level_hash_zero_links_to_the_global_cell() {
14061:         // tclsh 9.0.4 / 8.6.14: `upvar #0 counter c` reaches `::counter`
14062:         // however deep the stack is.
14063:         assert_eq!(
14064:             upvar_link_of(&["#0", "counter", "c"], "c"),
14065:             Some("::counter".to_string()),
14066:         );
14067:     }
14068: 
14069:     #[test]
14070:     fn upvar_does_not_link_a_frame_relative_other_var() {
14071:         // TN — `upvar 1 x y` names whatever local the *caller* happens to
14072:         // have; there is no namespace path for it, so inventing one would
14073:         // unify unrelated cells.
14074:         assert_eq!(upvar_link_of(&["1", "x", "y"], "y"), None);
14075:         assert_eq!(upvar_link_of(&["x", "y"], "y"), None);
14076:         // A computed target has no readable name at all.
14077:         assert_eq!(upvar_link_of(&["1", "$name", "obj"], "obj"), None);
14078:         // A computed *level* could be `#0`, but could equally be `1` — the
14079:         // alias must not be linked on a guess.
14080:         assert_eq!(upvar_link_of(&["$lvl", "counter", "c"], "c"), None);
14081:     }
14082: 
14083:     #[test]
14084:     fn upvar_level_word_presence_follows_argument_count_parity() {
14085:         // `upvar 1 b` is TWO words, so there is no level word and `1` is the
14086:         // caller-side variable name — the alias is `b` (tclsh 9.0.4 /
14087:         // 8.6.14: with `set 1 ONE` in the caller, the callee reads `ONE`).
14088:         let mut a = Analyser::new();
14089:         dispatch_words(&mut a, &["upvar", "1", "b"]);
14090:         assert!(a.result.global_scope.variables.contains_key("b"));
14091:         assert!(!a.result.global_scope.variables.contains_key("1"));
14092:     }
14093: 
14094:     // handle_proc_command
14095: 
14096:     #[test]
14097:     fn handle_proc_command_records_every_declaration_site_even_when_shadowed() {
14098:         // TP: a proc declared twice
14099:         // verbatim at different spans (plain Tcl's own "last redefinition
14100:         // wins" semantics) must still leave BOTH declarations' own name
14101:         // spans in `proc_declaration_sites`, even though `all_procs`
14102:         // (keyed by qualified name) only ever retains the winner's.
14103:         let mut a = Analyser::new();
14104:         a.handle_proc_command(
14105:             "proc",
14106:             &["foo".to_string(), String::new(), "return ONE".to_string()],
14107:             &[
14108:                 esc_tok(span(5, 8)),
14109:                 esc_tok(span(9, 9)),
14110:                 str_tok(span(10, 20)),
14111:             ],
14112:             &[],
14113:             &[],
14114:         );
14115:         a.handle_proc_command(
14116:             "proc",
14117:             &["foo".to_string(), String::new(), "return TWO".to_string()],
14118:             &[
14119:                 esc_tok(span(30, 33)),
14120:                 esc_tok(span(34, 34)),
14121:                 str_tok(span(35, 45)),
14122:             ],
14123:             &[],
14124:             &[],
14125:         );
14126:         assert_eq!(a.result.all_procs["::foo"].body_span, span(35, 45));
14127:         let sites: Vec<(&str, tcl_lexer::Span)> = a
14128:             .result
14129:             .proc_declaration_sites
14130:             .iter()
14131:             .map(|(q, s)| (q.as_str(), *s))
14132:             .collect();
14133:         assert_eq!(
14134:             sites,
14135:             vec![("::foo", span(5, 8)), ("::foo", span(30, 33))],
14136:             "both declaration sites must be recorded, in source order"
14137:         );
14138:     }
14139: 
14140:     #[test]
14141:     fn handle_proc_records_proc_at_global() {
14142:         let mut a = Analyser::new();
14143:         let handled = a.handle_proc_command(
14144:             "proc",
14145:             &["foo".to_string(), "a b".to_string(), "set x $a".to_string()],
14146:             &[
14147:                 esc_tok(span(5, 8)),
14148:                 esc_tok(span(9, 14)),
14149:                 str_tok(span(15, 25)),
14150:             ],
14151:             &[],
14152:             &[],
14153:         );
14154:         assert!(handled);
14155:         assert!(a.result.all_procs.contains_key("::foo"));
14156:         let proc = &a.result.all_procs["::foo"];
14157:         assert_eq!(proc.name, "foo");
14158:         assert_eq!(proc.qualified_name, "::foo");
14159:         assert_eq!(proc.params.len(), 2);
14160:         assert_eq!(proc.params[0].name, "a");
14161:         assert_eq!(proc.params[1].name, "b");
14162:     }
14163: 
14164:     #[test]
14165:     fn handle_proc_qualifies_under_namespace() {
14166:         use crate::analyser::types::{Scope, ScopeKind};
14167:         let mut a = Analyser::new();
14168:         a.result
14169:             .global_scope
14170:             .children
14171:             .push(Scope::new(ScopeKind::Namespace, "ns1"));
14172:         let handled = a.handle_proc_command(
14173:             "proc",
14174:             &["foo".to_string(), String::new(), String::new()],
14175:             &[
14176:                 esc_tok(span(5, 8)),
14177:                 str_tok(span(9, 11)),
14178:                 str_tok(span(12, 14)),
14179:             ],
14180:             &[],
14181:             &[0],
14182:         );
14183:         assert!(handled);
14184:         assert!(a.result.all_procs.contains_key("::ns1::foo"));
14185:     }
14186: 
14187:     #[test]
14188:     fn handle_proc_keys_scope_procs_by_simple_name() {
14189:         // ``scope.procs`` is keyed by the simple name so per-scope
14190:         // lookups and shadowing rules work locally. The
14191:         // qualified name lives on ``ProcDef.qualified_name`` and
14192:         // is the key for ``result.all_procs``.
14193:         use crate::analyser::types::{Scope, ScopeKind};
14194:         let mut a = Analyser::new();
14195:         a.result
14196:             .global_scope
14197:             .children
14198:             .push(Scope::new(ScopeKind::Namespace, "ns1"));
14199:         a.handle_proc_command(
14200:             "proc",
14201:             &["foo".to_string(), String::new(), String::new()],
14202:             &[
14203:                 esc_tok(span(5, 8)),
14204:                 str_tok(span(9, 11)),
14205:                 str_tok(span(12, 14)),
14206:             ],
14207:             &[],
14208:             &[0],
14209:         );
14210:         let scope = &a.result.global_scope.children[0];
14211:         // Scope's procs map keyed by simple name, NOT qualified.
14212:         assert!(
14213:             scope.procs.contains_key("foo"),
14214:             "scope.procs should be keyed by simple `foo`, got keys: {:?}",
14215:             scope.procs.keys().collect::<Vec<_>>(),
14216:         );
14217:         assert!(
14218:             !scope.procs.contains_key("::ns1::foo"),
14219:             "scope.procs must not be keyed by qualified name",
14220:         );
14221:         // The qualified name is still on the ProcDef.
14222:         assert_eq!(scope.procs["foo"].qualified_name, "::ns1::foo");
14223:         // ...and result.all_procs is keyed by qualified name.
14224:         assert!(a.result.all_procs.contains_key("::ns1::foo"));
14225:     }
14226: 
14227:     #[test]
14228:     fn handle_proc_absolute_name_rebases() {
14229:         use crate::analyser::types::{Scope, ScopeKind};
14230:         let mut a = Analyser::new();
14231:         a.result
14232:             .global_scope
14233:             .children
14234:             .push(Scope::new(ScopeKind::Namespace, "outer"));
14235:         let handled = a.handle_proc_command(
14236:             "proc",
14237:             &["::other::foo".to_string(), String::new(), String::new()],
14238:             &[
14239:                 esc_tok(span(5, 17)),
14240:                 str_tok(span(18, 20)),
14241:                 str_tok(span(21, 23)),
14242:             ],
14243:             &[],
14244:             &[0],
14245:         );
14246:         assert!(handled);
14247:         // Absolute name rebases — does NOT nest under outer.
14248:         assert!(a.result.all_procs.contains_key("::other::foo"));
14249:         assert!(!a.result.all_procs.contains_key("::outer::other::foo"));
14250:     }
14251: 
14252:     #[test]
14253:     fn handle_proc_consumes_last_comment_as_doc() {
14254:         let mut a = Analyser::new();
14255:         a.last_comment = "doc string".to_string();
14256:         a.handle_proc_command(
14257:             "proc",
14258:             &["foo".to_string(), String::new(), String::new()],
14259:             &[
14260:                 esc_tok(span(0, 3)),
14261:                 str_tok(span(4, 6)),
14262:                 str_tok(span(7, 9)),
14263:             ],
14264:             &[],
14265:             &[],
14266:         );
14267:         assert_eq!(a.result.all_procs["::foo"].doc, "doc string");
14268:         // last_comment is consumed.
14269:         assert_eq!(a.last_comment, "");
14270:     }
14271: 
14272:     #[test]
14273:     fn handle_proc_too_few_args_returns_false() {
14274:         let mut a = Analyser::new();
14275:         let handled = a.handle_proc_command(
14276:             "proc",
14277:             &["foo".to_string()],
14278:             &[esc_tok(span(0, 3))],
14279:             &[],
14280:             &[],
14281:         );
14282:         assert!(!handled);
14283:         assert_eq!(a.result.all_procs.len(), 0);
14284:     }
14285: 
14286:     // handle_proc_command W113 shadow check
14287: 
14288:     #[test]
14289:     fn handle_proc_emits_w113_for_builtin_shadow() {
14290:         // ``proc set {} {}`` — the proc name is a built-in.
14291:         // W113 should anchor at the proc-name span and carry
14292:         // the canonical message shape. A *real* dialect is named in the
14293:         // parenthetical label; the permissive fallback (both the empty
14294:         // string and its canonical "tcl" spelling resolve there —
14295:         // dialect-profile-model.md §8, one sink) carries no label, covered
14296:         // by the sibling no-label test below.
14297:         let mut a = Analyser::new();
14298:         a.profile = tcl_registry::model::ingress::resolve_environment("tcl8.6").analyser_profile();
14299:         a.handle_proc_command(
14300:             "proc",
14301:             &["set".to_string(), String::new(), String::new()],
14302:             &[
14303:                 esc_tok(span(5, 8)),
14304:                 str_tok(span(9, 11)),
14305:                 str_tok(span(12, 14)),
14306:             ],
14307:             &[],
14308:             &[],
14309:         );
14310:         let w113s: Vec<&crate::analyser::types::Diagnostic> = a
14311:             .result
14312:             .diagnostics
14313:             .iter()
14314:             .filter(|d| d.code == DiagCode::W113)
14315:             .collect();
14316:         assert_eq!(w113s.len(), 1);
14317:         assert_eq!(w113s[0].span, span(5, 8));
14318:         assert!(w113s[0].message.contains("'set' shadows built-in"));
14319:         assert!(w113s[0].message.contains("(tcl8.6)"));
14320:         assert_eq!(w113s[0].severity, crate::analyser::types::Severity::Warning);
14321:     }
14322: 
14323:     #[test]
14324:     fn irules_profile_without_attached_registry_keeps_valid_proc_semantics() {
14325:         let mut analyser = Analyser::new();
14326:         analyser.profile = tcl_dialect::DialectProfile::irules();
14327:         analyser.source = "proc set {} {}".to_owned();
14328:         assert!(analyser.registry.is_none());
14329:         let handled = analyser.handle_proc_command(
14330:             "proc",
14331:             &["set".to_owned(), String::new(), String::new()],
14332:             &[
14333:                 esc_tok(span(5, 8)),
14334:                 str_tok(span(9, 11)),
14335:                 str_tok(span(12, 14)),
14336:             ],
14337:             &[true, true, true],
14338:             &[],
14339:         );
14340:         assert!(handled);
14341:         assert!(analyser.result.all_procs.contains_key("::set"));
14342:         assert!(
14343:             analyser
14344:                 .result
14345:                 .diagnostics
14346:                 .iter()
14347:                 .any(|diagnostic| diagnostic.code == DiagCode::W113)
14348:         );
14349:     }
14350: 
14351:     #[test]
14352:     fn irules_profile_without_attached_registry_rejects_malformed_proc() {
14353:         let mut analyser = Analyser::new();
14354:         analyser.profile = tcl_dialect::DialectProfile::irules();
14355:         assert!(analyser.registry.is_none());
14356:         let handled = analyser.handle_proc_command(
14357:             "proc",
14358:             &[
14359:                 "set".to_owned(),
14360:                 String::new(),
14361:                 "set leaked 1".to_owned(),
14362:                 "extra".to_owned(),
14363:             ],
14364:             &[
14365:                 esc_tok(span(5, 8)),
14366:                 str_tok(span(9, 11)),
14367:                 str_tok(span(12, 26)),
14368:                 esc_tok(span(27, 32)),
14369:             ],
14370:             &[],
14371:             &[],
14372:         );
14373:         assert!(handled);
14374:         assert_eq!(analyser.result.all_procs.len(), 0);
14375:         assert_eq!(analyser.result.global_scope.variables.len(), 0);
14376:         assert_eq!(
14377:             analyser.result.diagnostics,
14378:             [] as [crate::analyser::types::Diagnostic; 0]
14379:         );
14380:     }
14381: 
14382:     #[test]
14383:     fn handle_proc_no_w113_for_non_builtin_name() {
14384:         // ``foo`` is not a built-in — no W113.
14385:         let mut a = Analyser::new();
14386:         a.profile = tcl_registry::model::ingress::resolve_environment("tcl").analyser_profile();
14387:         a.handle_proc_command(
14388:             "proc",
14389:             &["foo".to_string(), String::new(), String::new()],
14390:             &[
14391:                 esc_tok(span(5, 8)),
14392:                 str_tok(span(9, 11)),
14393:                 str_tok(span(12, 14)),
14394:             ],
14395:             &[],
14396:             &[],
14397:         );
14398:         assert!(
14399:             !a.result
14400:                 .diagnostics
14401:                 .iter()
14402:                 .any(|d| d.code == DiagCode::W113),
14403:             "should NOT emit W113 for non-built-in name 'foo'",
14404:         );
14405:     }
14406: 
14407:     #[test]
14408:     fn handle_proc_w113_matches_qualified_form() {
14409:         // ``proc ::set {} {}`` — qualified form also shadows
14410:         // ``set`` because the registry indexes by bare command
14411:         // name (``::`` is trimmed at lookup).
14412:         let mut a = Analyser::new();
14413:         a.profile = tcl_registry::model::ingress::resolve_environment("tcl").analyser_profile();
14414:         a.handle_proc_command(
14415:             "proc",
14416:             &["::set".to_string(), String::new(), String::new()],
14417:             &[
14418:                 esc_tok(span(5, 10)),
14419:                 str_tok(span(11, 13)),
14420:                 str_tok(span(14, 16)),
14421:             ],
14422:             &[],
14423:             &[],
14424:         );
14425:         assert!(
14426:             a.result
14427:                 .diagnostics
14428:                 .iter()
14429:                 .any(|d| d.code == DiagCode::W113)
14430:         );
14431:     }
14432: 
14433:     #[test]
14434:     fn handle_proc_w113_no_dialect_label_when_dialect_empty() {
14435:         // Empty dialect → no parenthetical label in the message.
14436:         let mut a = Analyser::new();
14437:         // dialect intentionally left empty
14438:         a.handle_proc_command(
14439:             "proc",
14440:             &["set".to_string(), String::new(), String::new()],
14441:             &[
14442:                 esc_tok(span(5, 8)),
14443:                 str_tok(span(9, 11)),
14444:                 str_tok(span(12, 14)),
14445:             ],
14446:             &[],
14447:             &[],
14448:         );
14449:         let w113 = a
14450:             .result
14451:             .diagnostics
14452:             .iter()
14453:             .find(|d| d.code == DiagCode::W113)
14454:             .expect("W113 expected");
14455:         assert!(w113.message.contains("'set' shadows built-in"));
14456:         assert!(!w113.message.contains('('), "no dialect label expected");
14457:     }
14458: 
14459:     #[test]
14460:     fn handle_proc_w113_dialect_specific_command_only_shadows_in_that_dialect() {
14461:         // ``pool`` is an *unqualified* iRules-specific command; under the
14462:         // ``f5-irules`` dialect a proc named ``pool`` shadows a built-in,
14463:         // but under plain ``tcl`` it does not.  (A *namespace-qualified*
14464:         // iRules command like ``HTTP::respond`` is never flagged, because a
14465:         // qualified match is a library/package command living in its own
14466:         // namespace, not a core-global shadow.)
14467:         let mut a = Analyser::new();
14468:         a.profile = tcl_dialect::DialectProfile::irules();
14469:         a.source = "proc pool {} {}".to_owned();
14470:         a.handle_proc_command(
14471:             "proc",
14472:             &["pool".to_string(), String::new(), String::new()],
14473:             &[
14474:                 esc_tok(span(5, 9)),
14475:                 str_tok(span(10, 12)),
14476:                 str_tok(span(13, 15)),
14477:             ],
14478:             &[true, true, true],
14479:             &[],
14480:         );
14481:         assert!(
14482:             a.result
14483:                 .diagnostics
14484:                 .iter()
14485:                 .any(|d| d.code == DiagCode::W113),
14486:             "f5-irules dialect should treat pool as built-in",
14487:         );
14488: 
14489:         // Same proc, plain tcl dialect → no W113.
14490:         let mut b = Analyser::new();
14491:         b.profile = tcl_registry::model::ingress::resolve_environment("tcl").analyser_profile();
14492:         b.handle_proc_command(
14493:             "proc",
14494:             &["pool".to_string(), String::new(), String::new()],
14495:             &[
14496:                 esc_tok(span(5, 9)),
14497:                 str_tok(span(10, 12)),
14498:                 str_tok(span(13, 15)),
14499:             ],
14500:             &[],
14501:             &[],
14502:         );
14503:         assert!(
14504:             !b.result
14505:                 .diagnostics
14506:                 .iter()
14507:                 .any(|d| d.code == DiagCode::W113),
14508:             "plain tcl dialect should NOT flag pool",
14509:         );
14510:     }
14511: 
14512:     #[test]
14513:     fn handle_proc_w113_silent_on_namespace_qualified_shadow() {
14514:         // FP: a namespace-qualified match (`HTTP::respond` under f5-irules)
14515:         // is a library/package command in its own namespace, not a
14516:         // core-global shadow — never W113.
14517:         let mut a = Analyser::new();
14518:         a.profile = tcl_dialect::DialectProfile::irules();
14519:         a.handle_proc_command(
14520:             "proc",
14521:             &["HTTP::respond".to_string(), String::new(), String::new()],
14522:             &[
14523:                 esc_tok(span(5, 18)),
14524:                 str_tok(span(19, 21)),
14525:                 str_tok(span(22, 24)),
14526:             ],
14527:             &[],
14528:             &[],
14529:         );
14530:         assert!(
14531:             !a.result
14532:                 .diagnostics
14533:                 .iter()
14534:                 .any(|d| d.code == DiagCode::W113),
14535:             "namespace-qualified HTTP::respond must not fire W113",
14536:         );
14537:     }
14538: 
14539:     // handle_proc_command body recursion
14540: 
14541:     #[test]
14542:     fn handle_proc_creates_proc_scope_for_braced_body() {
14543:         // ``proc foo {} {}`` — empty braced body still opens a
14544:         // proc scope so subsequent body-walking handlers have a
14545:         // place to record locals.
14546:         let mut a = Analyser::new();
14547:         a.handle_proc_command(
14548:             "proc",
14549:             &["foo".to_string(), String::new(), String::new()],
14550:             &[
14551:                 esc_tok(span(5, 8)),
14552:                 str_tok(span(9, 11)),
14553:                 str_tok(span(12, 14)),
14554:             ],
14555:             &[],
14556:             &[],
14557:         );
14558:         assert_eq!(a.result.global_scope.children.len(), 1);
14559:         let proc_scope = &a.result.global_scope.children[0];
14560:         assert_eq!(proc_scope.kind, crate::analyser::types::ScopeKind::Proc);
14561:         assert_eq!(proc_scope.name, "foo");
14562:         assert_eq!(proc_scope.body_span, Some(span(12, 14)));
14563:     }
14564: 
14565:     #[test]
14566:     fn handle_proc_defines_params_in_proc_scope() {
14567:         // ``proc foo {a b} {}`` — a, b become locals in the
14568:         // proc scope, not in the outer scope.
14569:         let mut a = Analyser::new();
14570:         a.handle_proc_command(
14571:             "proc",
14572:             &["foo".to_string(), "a b".to_string(), String::new()],
14573:             &[
14574:                 esc_tok(span(5, 8)),
14575:                 esc_tok(span(9, 14)),
14576:                 str_tok(span(15, 17)),
14577:             ],
14578:             &[],
14579:             &[],
14580:         );
14581:         let proc_scope = &a.result.global_scope.children[0];
14582:         assert!(proc_scope.variables.contains_key("a"));
14583:         assert!(proc_scope.variables.contains_key("b"));
14584:         // Outer scope must be untouched.
14585:         assert!(!a.result.global_scope.variables.contains_key("a"));
14586:     }
14587: 
14588:     #[test]
14589:     fn handle_proc_walks_body_set_defines_local() {
14590:         // ``proc foo {} {set x 1}`` — body walk segments the
14591:         // body and dispatches `set x 1` against the proc scope,
14592:         // landing the local in proc_scope.variables, not global.
14593:         // The body token's span must mirror the outer source so
14594:         // the segmenter rebases correctly: source layout is
14595:         // ``proc foo {} {set x 1}`` with the body occupying [13, 22].
14596:         // ``content_offset = 1`` skips the leading ``{`` so the
14597:         // re-segmented inner runs at base 14.
14598:         let mut a = Analyser::new();
14599:         a.handle_proc_command(
14600:             "proc",
14601:             &["foo".to_string(), String::new(), "set x 1".to_string()],
14602:             &[
14603:                 esc_tok(span(5, 8)),
14604:                 str_tok(span(9, 11)),
14605:                 str_tok(span(13, 22)),
14606:             ],
14607:             &[],
14608:             &[],
14609:         );
14610:         let proc_scope = &a.result.global_scope.children[0];
14611:         assert!(
14612:             proc_scope.variables.contains_key("x"),
14613:             "body walk should land 'x' in proc scope; vars: {:?}",
14614:             proc_scope.variables.keys().collect::<Vec<_>>(),
14615:         );
14616:         assert!(!a.result.global_scope.variables.contains_key("x"));
14617:     }
14618: 
14619:     #[test]
14620:     fn handle_proc_walks_body_global_falls_into_proc_scope() {
14621:         // ``proc foo {} {global a b}`` — the ``global`` handler
14622:         // defines bindings in the proc scope so the body's later
14623:         // reads/writes resolve correctly. Real ``global`` semantics
14624:         // (link to outer var) live with diagnostic emission later.
14625:         let mut a = Analyser::new();
14626:         a.handle_proc_command(
14627:             "proc",
14628:             &["foo".to_string(), String::new(), "global a b".to_string()],
14629:             &[
14630:                 esc_tok(span(5, 8)),
14631:                 str_tok(span(9, 11)),
14632:                 str_tok(span(13, 25)),
14633:             ],
14634:             &[],
14635:             &[],
14636:         );
14637:         let proc_scope = &a.result.global_scope.children[0];
14638:         assert!(proc_scope.variables.contains_key("a"));
14639:         assert!(proc_scope.variables.contains_key("b"));
14640:     }
14641: 
14642:     #[test]
14643:     fn handle_proc_nested_proc_creates_nested_scopes() {
14644:         // Body-walk recursion must dispatch `proc` inside the body,
14645:         // creating a nested proc scope under the outer proc.
14646:         let mut a = Analyser::new();
14647:         a.handle_proc_command(
14648:             "proc",
14649:             &[
14650:                 "outer".to_string(),
14651:                 String::new(),
14652:                 "proc inner {} {}".to_string(),
14653:             ],
14654:             &[
14655:                 esc_tok(span(5, 10)),
14656:                 str_tok(span(11, 13)),
14657:                 str_tok(span(15, 33)),
14658:             ],
14659:             &[],
14660:             &[],
14661:         );
14662:         // Outer proc registered.
14663:         assert!(a.result.all_procs.contains_key("::outer"));
14664:         // A nested definition homes to the enclosing proc's *defining*
14665:         // namespace (`command_resolution_namespace` /
14666:         // `advance_command_resolution_namespace`), not to a namespace named
14667:         // after the proc. ``outer`` is unqualified, so its defining namespace
14668:         // is ``::`` and the nested ``inner`` qualifies as ``::inner``.
14669:         assert!(a.result.all_procs.contains_key("::inner"));
14670:         // Outer's proc scope holds the nested proc scope as a child.
14671:         let outer_scope = &a.result.global_scope.children[0];
14672:         assert_ne!(
14673:             outer_scope.children,
14674:             [] as [crate::analyser::types::Scope; 0]
14675:         );
14676:         assert_eq!(
14677:             outer_scope.children[0].kind,
14678:             crate::analyser::types::ScopeKind::Proc,
14679:         );
14680:         assert_eq!(outer_scope.children[0].name, "inner");
14681:     }
14682: 
14683:     #[test]
14684:     fn handle_proc_dynamic_body_skips_walk() {
14685:         // ``proc foo {} $body`` — the body is a Var token, not a
14686:         // Str token; we cannot statically re-segment a dynamic
14687:         // body, so the body walk is skipped. The proc record
14688:         // itself still lands so downstream signature consumers see
14689:         // the proc; only the inner walk is gated.
14690:         let mut a = Analyser::new();
14691:         let var_tok = Token::new(TokenType::Var, span(13, 18));
14692:         a.handle_proc_command(
14693:             "proc",
14694:             &["foo".to_string(), String::new(), "$body".to_string()],
14695:             &[esc_tok(span(5, 8)), str_tok(span(9, 11)), var_tok],
14696:             &[],
14697:             &[],
14698:         );
14699:         assert!(a.result.all_procs.contains_key("::foo"));
14700:         // No proc scope opened — Str gate failed.
14701:         assert_eq!(
14702:             a.result.global_scope.children,
14703:             [] as [crate::analyser::types::Scope; 0]
14704:         );
14705:     }
14706: 
14707:     #[test]
14708:     fn handle_proc_body_walk_increments_body_depth_temporarily() {
14709:         // ``body_depth`` is bumped for the duration of the body
14710:         // walk and restored on exit — top-level-only command
14711:         // checks rely on the depth being zero outside any body.
14712:         let mut a = Analyser::new();
14713:         assert_eq!(a.body_depth, 0);
14714:         a.handle_proc_command(
14715:             "proc",
14716:             &["foo".to_string(), String::new(), String::new()],
14717:             &[
14718:                 esc_tok(span(5, 8)),
14719:                 str_tok(span(9, 11)),
14720:                 str_tok(span(12, 14)),
14721:             ],
14722:             &[],
14723:             &[],
14724:         );
14725:         assert_eq!(a.body_depth, 0);
14726:     }
14727: 
14728:     #[test]
14729:     fn handle_proc_body_walk_does_not_leak_inner_doc_comment() {
14730:         // A trailing comment inside the body should not bleed into
14731:         // ``last_comment`` for whatever follows the proc at the
14732:         // outer scope. The outer comment ("doc string") is consumed
14733:         // as the proc's own doc; after the walk, ``last_comment``
14734:         // is restored to empty.
14735:         let mut a = Analyser::new();
14736:         a.last_comment = "doc string".to_string();
14737:         a.handle_proc_command(
14738:             "proc",
14739:             &["foo".to_string(), String::new(), String::new()],
14740:             &[
14741:                 esc_tok(span(5, 8)),
14742:                 str_tok(span(9, 11)),
14743:                 str_tok(span(12, 14)),
14744:             ],
14745:             &[],
14746:             &[],
14747:         );
14748:         assert_eq!(a.result.all_procs["::foo"].doc, "doc string");
14749:         assert_eq!(a.last_comment, "");
14750:     }
14751: 
14752:     // handle_namespace_eval_command
14753: 
14754:     // handle_namespace_export_command
14755: 
14756:     #[test]
14757:     fn handle_namespace_export_records_pattern() {
14758:         let mut a = Analyser::new();
14759:         a.handle_namespace_export_command(
14760:             &["export".to_string(), "bar".to_string()],
14761:             &[esc_tok(span(0, 6)), esc_tok(span(7, 10))],
14762:             &[],
14763:         );
14764:         assert_eq!(a.result.namespace_exports.len(), 1);
14765:         assert_eq!(a.result.namespace_exports[0].ns, "::");
14766:         assert_eq!(a.result.namespace_exports[0].pattern, "bar");
14767:     }
14768: 
14769:     #[test]
14770:     fn handle_namespace_export_records_multiple_patterns() {
14771:         let mut a = Analyser::new();
14772:         a.handle_namespace_export_command(
14773:             &["export".to_string(), "bar".to_string(), "b*".to_string()],
14774:             &[
14775:                 esc_tok(span(0, 6)),
14776:                 esc_tok(span(7, 10)),
14777:                 esc_tok(span(11, 13)),
14778:             ],
14779:             &[],
14780:         );
14781:         let patterns: Vec<&str> = a
14782:             .result
14783:             .namespace_exports
14784:             .iter()
14785:             .map(|e| e.pattern.as_str())
14786:             .collect();
14787:         assert_eq!(patterns, vec!["bar", "b*"]);
14788:     }
14789: 
14790:     /// `NamespaceExportCmd` calls `Tcl_Export` per pattern and returns on the
14791:     /// first failure, so a qualified pattern aborts the loop — the patterns
14792:     /// *before* it are committed, the ones after are never exported at all.
14793:     /// Oracle rows (identical on tclsh 8.6.16 and 9.0.4, `namespace export`
14794:     /// read back from the namespace afterwards):
14795:     ///
14796:     /// | script | exports |
14797:     /// |---|---|
14798:     /// | `namespace export ::bad ok` | nothing |
14799:     /// | `namespace export ok ::bad` | `ok` |
14800:     /// | `namespace export one ::bad three` | `one` |
14801:     #[test]
14802:     fn handle_namespace_export_stops_at_the_first_qualified_pattern() {
14803:         let recorded = |words: &[&str]| -> Vec<String> {
14804:             let mut a = Analyser::new();
14805:             let args: Vec<String> = std::iter::once("export".to_string())
14806:                 .chain(words.iter().map(|w| (*w).to_string()))
14807:                 .collect();
14808:             let tokens: Vec<Token> = (0..args.len())
14809:                 .map(|i| {
14810:                     let start = u32::try_from(i).expect("small index") * 10;
14811:                     esc_tok(span(start, start + 5))
14812:                 })
14813:                 .collect();
14814:             a.handle_namespace_export_command(&args, &tokens, &[]);
14815:             a.result
14816:                 .namespace_exports
14817:                 .iter()
14818:                 .map(|e| e.pattern.clone())
14819:                 .collect()
14820:         };
14821: 
14822:         // The bad pattern is first: nothing is exported.
14823:         assert_eq!(recorded(&["::bad", "ok"]), [] as [std::string::String; 0]);
14824:         // …and after a valid one: only the valid one survives.
14825:         assert_eq!(recorded(&["ok", "::bad"]), vec!["ok".to_string()]);
14826:         assert_eq!(
14827:             recorded(&["one", "::bad", "three"]),
14828:             vec!["one".to_string()]
14829:         );
14830:         // A *relative* qualifier is equally invalid (oracle: `namespace
14831:         // export sub::pat` errors), so it aborts too.
14832:         assert_eq!(
14833:             recorded(&["sub::pat", "ok"]),
14834:             [] as [std::string::String; 0]
14835:         );
14836:         // A lone colon is not a separator, so `a:b` is a perfectly valid
14837:         // pattern and must not abort (oracle: exports `a:b`).
14838:         assert_eq!(
14839:             recorded(&["a:b", "ok"]),
14840:             vec!["a:b".to_string(), "ok".to_string()]
14841:         );
14842:         // The empty pattern is valid too (oracle: exports `{} ok`).
14843:         assert_eq!(recorded(&["", "ok"]), vec![String::new(), "ok".to_string()]);
14844:     }
14845: 
14846:     #[test]
14847:     fn handle_namespace_export_clear_commits_before_an_invalid_pattern() {
14848:         // C spends a whole `Tcl_Export(…, "::", 1)` call on `-clear`, which
14849:         // resets the list before any pattern is looked at, so a later bad
14850:         // pattern cannot undo it. Oracle: a namespace exporting `keep`, then
14851:         // `namespace export -clear ::bad`, exports nothing afterwards.
14852:         let mut a = Analyser::new();
14853:         a.registry = Some(std::sync::Arc::clone(
14854:             tcl_registry::model::ingress::static_context_for("tcl").commands(),
14855:         ));
14856:         a.handle_namespace_export_command(
14857:             &[
14858:                 "export".to_string(),
14859:                 "-clear".to_string(),
14860:                 "::bad".to_string(),
14861:             ],
14862:             &[
14863:                 esc_tok(span(0, 6)),
14864:                 esc_tok(span(7, 13)),
14865:                 esc_tok(span(14, 19)),
14866:             ],
14867:             &[],
14868:         );
14869:         let events: Vec<(&str, bool)> = a
14870:             .result
14871:             .namespace_exports
14872:             .iter()
14873:             .map(|e| (e.pattern.as_str(), e.clears))
14874:             .collect();
14875:         assert_eq!(events, vec![("", true)]);
14876:     }
14877: 
14878:     #[test]
14879:     fn handle_namespace_export_clear_records_an_ordered_tombstone() {
14880:         let mut a = Analyser::new();
14881:         a.registry = Some(std::sync::Arc::clone(
14882:             tcl_registry::model::ingress::static_context_for("tcl").commands(),
14883:         ));
14884:         a.handle_namespace_export_command(
14885:             &["export".to_string(), "bar".to_string()],
14886:             &[esc_tok(span(0, 6)), esc_tok(span(7, 10))],
14887:             &[],
14888:         );
14889:         a.handle_namespace_export_command(
14890:             &[
14891:                 "export".to_string(),
14892:                 "-clear".to_string(),
14893:                 "baz".to_string(),
14894:             ],
14895:             &[
14896:                 esc_tok(span(11, 17)),
14897:                 esc_tok(span(18, 24)),
14898:                 esc_tok(span(25, 28)),
14899:             ],
14900:             &[],
14901:         );
14902:         // `-clear` is an ordered event, not an eager delete: the earlier
14903:         // `bar` entry stays on the log so a `namespace import` that ran
14904:         // *before* the `-clear` can still see it.
14905:         let events: Vec<(&str, bool, u32)> = a
14906:             .result
14907:             .namespace_exports
14908:             .iter()
14909:             .map(|e| (e.pattern.as_str(), e.clears, e.range.start()))
14910:             .collect();
14911:         assert_eq!(
14912:             events,
14913:             vec![("bar", false, 7), ("", true, 18), ("baz", false, 25)]
14914:         );
14915:     }
14916: 
14917:     #[test]
14918:     fn handle_namespace_export_consumes_only_one_clear_flag() {
14919:         // `NamespaceExportCmd` compares `objv[1]`
14920:         // against `-clear` once, so a *second* `-clear` is an ordinary export
14921:         // pattern. Oracle (tclsh 8.6.14 / 9.0.4): `namespace export -clear
14922:         // -clear p` leaves exactly `-clear p` exported, and a command really
14923:         // named `-clear` is then importable through `namespace import
14924:         // ::src::*`. Consuming every matching word instead records two
14925:         // tombstones and silently drops the `-clear` export.
14926:         let mut a = Analyser::new();
14927:         a.registry = Some(std::sync::Arc::clone(
14928:             tcl_registry::model::ingress::static_context_for("tcl").commands(),
14929:         ));
14930:         a.handle_namespace_export_command(
14931:             &[
14932:                 "export".to_string(),
14933:                 "-clear".to_string(),
14934:                 "-clear".to_string(),
14935:                 "p".to_string(),
14936:             ],
14937:             &[
14938:                 esc_tok(span(0, 6)),
14939:                 esc_tok(span(7, 13)),
14940:                 esc_tok(span(14, 20)),
14941:                 esc_tok(span(21, 22)),
14942:             ],
14943:             &[],
14944:         );
14945:         let events: Vec<(&str, bool)> = a
14946:             .result
14947:             .namespace_exports
14948:             .iter()
14949:             .map(|e| (e.pattern.as_str(), e.clears))
14950:             .collect();
14951:         assert_eq!(events, vec![("", true), ("-clear", false), ("p", false)]);
14952:     }
14953: 
14954:     #[test]
14955:     fn handle_namespace_export_flag_after_a_pattern_is_a_pattern() {
14956:         // The flag is only ever the *first* word: oracle `namespace export a
14957:         // -clear` → `namespace export` returns `a -clear`.
14958:         let mut a = Analyser::new();
14959:         a.registry = Some(std::sync::Arc::clone(
14960:             tcl_registry::model::ingress::static_context_for("tcl").commands(),
14961:         ));
14962:         a.handle_namespace_export_command(
14963:             &["export".to_string(), "a".to_string(), "-clear".to_string()],
14964:             &[
14965:                 esc_tok(span(0, 6)),
14966:                 esc_tok(span(7, 8)),
14967:                 esc_tok(span(9, 15)),
14968:             ],
14969:             &[],
14970:         );
14971:         let events: Vec<(&str, bool)> = a
14972:             .result
14973:             .namespace_exports
14974:             .iter()
14975:             .map(|e| (e.pattern.as_str(), e.clears))
14976:             .collect();
14977:         assert_eq!(events, vec![("a", false), ("-clear", false)]);
14978:     }
14979: 
14980:     #[test]
14981:     fn handle_namespace_import_consumes_only_one_force_flag() {
14982:         // Symmetric to the export case: `namespace import -force -force
14983:         // ::src::*` reads the second `-force` as an import *pattern* (and
14984:         // aborts with `no namespace specified in import pattern "-force"`,
14985:         // tclsh 8.6.14/9.0.4). Only the first is skipped as a flag, so the
14986:         // second is recorded as the pattern word it is — one whose empty
14987:         // source namespace both wildcard resolvers already decline.
14988:         let mut a = Analyser::new();
14989:         a.registry = Some(std::sync::Arc::clone(
14990:             tcl_registry::model::ingress::static_context_for("tcl").commands(),
14991:         ));
14992:         a.handle_namespace_import_command(
14993:             &[
14994:                 "import".to_string(),
14995:                 "-force".to_string(),
14996:                 "-force".to_string(),
14997:                 "::src::*".to_string(),
14998:             ],
14999:             &[
15000:                 esc_tok(span(0, 6)),
15001:                 esc_tok(span(7, 13)),
15002:                 esc_tok(span(14, 20)),
15003:                 esc_tok(span(21, 29)),
15004:             ],
15005:             &[],
15006:         );
15007:         let patterns: Vec<&str> = a
15008:             .result
15009:             .namespace_imports
15010:             .iter()
15011:             .map(|i| i.pattern.as_str())
15012:             .collect();
15013:         assert_eq!(patterns, vec!["::-force", "::src::*"]);
15014:     }
15015: 
15016:     #[test]
15017:     fn handle_namespace_export_bare_clear_records_a_tombstone() {
15018:         let mut a = Analyser::new();
15019:         a.registry = Some(std::sync::Arc::clone(
15020:             tcl_registry::model::ingress::static_context_for("tcl").commands(),
15021:         ));
15022:         a.handle_namespace_export_command(
15023:             &["export".to_string(), "-clear".to_string()],
15024:             &[esc_tok(span(0, 6)), esc_tok(span(7, 13))],
15025:             &[],
15026:         );
15027:         assert_eq!(a.result.namespace_exports.len(), 1);
15028:         assert!(a.result.namespace_exports[0].clears);
15029:         assert_eq!(a.result.namespace_exports[0].pattern, "");
15030:     }
15031: 
15032:     #[test]
15033:     fn handle_namespace_export_skips_dynamic_pattern() {
15034:         let mut a = Analyser::new();
15035:         a.handle_namespace_export_command(
15036:             &["export".to_string(), "$dyn".to_string()],
15037:             &[esc_tok(span(0, 6)), esc_tok(span(7, 11))],
15038:             &[],
15039:         );
15040:         assert_eq!(
15041:             a.result.namespace_exports.len(),
15042:             0,
15043:             "a dynamic pattern can't be statically recorded"
15044:         );
15045:     }
15046: 
15047:     // handle_namespace_path_command
15048: 
15049:     /// The two-word literal set form records entries under the declaring
15050:     /// namespace; a later declaration replaces the whole path (C Tcl
15051:     /// semantics), and entries are kept as written (rooting happens in the
15052:     /// shared candidate builder).
15053:     #[test]
15054:     fn handle_namespace_path_records_and_replaces() {
15055:         let mut a = Analyser::new();
15056:         a.handle_namespace_path_command(&["path".to_string(), "::u ::v".to_string()], &[], &[]);
15057:         assert_eq!(
15058:             a.namespace_paths.get("::").map(Vec::as_slice),
15059:             Some(&["::u".to_string(), "::v".to_string()][..]),
15060:         );
15061:         a.handle_namespace_path_command(&["path".to_string(), "inner".to_string()], &[], &[]);
15062:         assert_eq!(
15063:             a.namespace_paths.get("::").map(Vec::as_slice),
15064:             Some(&["inner".to_string()][..]),
15065:             "each namespace path declaration replaces the whole path",
15066:         );
15067:     }
15068: 
15069:     /// A **braced** path word is literal, not dynamic. The word
15070:     /// arrives with braces stripped, so a text-only dynamism scan sees the
15071:     /// `$` and abstains from the whole command; the token kind is the
15072:     /// authority.
15073:     ///
15074:     /// tclsh-proof: tclsh8.6.14 —
15075:     /// `set nn {::$ns}; namespace eval $nn {}; namespace eval a {}` then
15076:     /// `namespace eval n { namespace path {::$ns ::a} }` and
15077:     /// `namespace eval n { namespace path }` answers `{::$ns} ::a` — the
15078:     /// entry is a namespace literally *named* `::$ns`.
15079:     #[test]
15080:     fn handle_namespace_path_records_a_braced_dollar_bearing_word() {
15081:         let mut a = Analyser::new();
15082:         a.handle_namespace_path_command(
15083:             &["path".to_string(), "::$ns ::a".to_string()],
15084:             &[esc_tok(span(0, 4)), str_tok(span(5, 16))],
15085:             &[],
15086:         );
15087:         assert_eq!(
15088:             a.namespace_paths.get("::").map(Vec::as_slice),
15089:             Some(&["::$ns".to_string(), "::a".to_string()][..]),
15090:             "a braced word never substitutes, so its entries are literal names",
15091:         );
15092:     }
15093: 
15094:     /// TN control — the same text **unbraced** really is a substitution, so
15095:     /// the command still abstains.
15096:     #[test]
15097:     fn handle_namespace_path_still_skips_an_unbraced_dollar_word() {
15098:         let mut a = Analyser::new();
15099:         a.handle_namespace_path_command(
15100:             &["path".to_string(), "$entries".to_string()],
15101:             &[esc_tok(span(0, 4)), Token::new(TokenType::Var, span(5, 13))],
15102:             &[],
15103:         );
15104:         assert_eq!(a.namespace_paths.len(), 0);
15105:     }
15106: 
15107:     /// The query form (no list) and a dynamic list (`$var` / `[cmd]`)
15108:     /// record nothing — the conservative empty path stands.
15109:     #[test]
15110:     fn handle_namespace_path_skips_query_and_dynamic_forms() {
15111:         let mut a = Analyser::new();
15112:         a.handle_namespace_path_command(&["path".to_string()], &[], &[]);
15113:         a.handle_namespace_path_command(&["path".to_string(), "$entries".to_string()], &[], &[]);
15114:         a.handle_namespace_path_command(
15115:             &["path".to_string(), "[current_path]".to_string()],
15116:             &[],
15117:             &[],
15118:         );
15119:         assert_eq!(a.namespace_paths.len(), 0);
15120:     }
15121: 
15122:     /// A declaration inside a namespace scope keys to that namespace's
15123:     /// accumulated name, so settlement applies it to the right call sites.
15124:     #[test]
15125:     fn handle_namespace_path_keys_to_declaring_namespace() {
15126:         let mut a = Analyser::new();
15127:         a.result
15128:             .global_scope
15129:             .children
15130:             .push(crate::analyser::types::Scope::new(
15131:                 crate::analyser::types::ScopeKind::Namespace,
15132:                 "outer",
15133:             ));
15134:         a.handle_namespace_path_command(&["path".to_string(), "::helpers".to_string()], &[], &[0]);
15135:         assert_eq!(
15136:             a.namespace_paths.get("::outer").map(Vec::as_slice),
15137:             Some(&["::helpers".to_string()][..]),
15138:         );
15139:     }
15140: 
15141:     /// The `namespace path` resolution tier is 8.5+: a bare call under a path
15142:     /// gains the path namespace as a candidate from 8.5 on, but under 8.4 it
15143:     /// must not (8.4 has no path tier, so the call never reaches it).
15144:     #[test]
15145:     fn bare_call_honours_namespace_path_only_from_8_5() {
15146:         let src = "namespace eval ::app { namespace path ::mymod\n    proc run {} { helper } }\n";
15147:         let candidates = |dialect: &str| {
15148:             let mut a = Analyser::new();
15149:             a.analyse(src, dialect)
15150:                 .command_invocations
15151:                 .iter()
15152:                 .find(|i| i.name == "helper")
15153:                 .map(|i| i.resolution_candidates.clone())
15154:                 .unwrap_or_default()
15155:         };
15156:         assert!(
15157:             candidates("tcl8.6").iter().any(|c| c == "::mymod::helper"),
15158:             "8.6 should add the path namespace as a candidate: {:?}",
15159:             candidates("tcl8.6"),
15160:         );
15161:         assert!(
15162:             !candidates("tcl8.4").iter().any(|c| c == "::mymod::helper"),
15163:             "8.4 has no path tier, so it must not: {:?}",
15164:             candidates("tcl8.4"),
15165:         );
15166:     }
15167: 
15168:     /// A command-table mutation inside a child interpreter's eval body
15169:     /// belongs to *that* interpreter, not to a flat file-wide map.
15170:     ///
15171:     /// tclsh 9.0.4, verified: after `interp create c; c eval { rename puts
15172:     /// myputs }` the parent's `puts` still works, the parent has no `myputs`,
15173:     /// the child has `myputs` and no `puts`; and `c eval { rename set {} }`
15174:     /// leaves the parent's `set` alone.
15175:     #[test]
15176:     fn rename_inside_a_child_body_does_not_touch_the_parent_command_table() {
15177:         let src = "interp create c\nc eval { rename puts myputs }\nputs hi\n";
15178:         let r = Analyser::new().analyse(src, "tcl8.6");
15179:         assert_eq!(
15180:             r.renamed_commands.len(),
15181:             0,
15182:             "a child's rename must not enter the parent's rename map: {:?}",
15183:             r.renamed_commands
15184:         );
15185:         assert!(
15186:             !r.diagnostics.iter().any(|d| d.message.contains("'puts'")),
15187:             "the parent's own `puts` is still a live builtin: {:?}",
15188:             r.diagnostics
15189:                 .iter()
15190:                 .map(|d| (d.code.to_string(), d.message.clone()))
15191:                 .collect::<Vec<_>>()
15192:         );
15193:     }
15194: 
15195:     /// The incremental per-item path must agree with full analysis here: a
15196:     /// deferred proc body is walked by a fresh `Analyser` that does not
15197:     /// inherit the interpreter stack, so a `rename` buried in a proc defined
15198:     /// inside a child body is the shape most likely to diverge.
15199:     #[test]
15200:     fn per_item_agrees_on_a_rename_nested_in_a_child_body() {
15201:         let src = "interp create c\n\
15202:                    c eval { proc setup {} { rename puts myputs } }\n\
15203:                    puts hi\n";
15204:         let codes = |r: &super::super::types::AnalysisResult| {
15205:             let mut v: Vec<(String, u32)> = r
15206:                 .diagnostics
15207:                 .iter()
15208:                 .map(|d| (d.code.to_string(), d.span.start()))
15209:                 .collect();
15210:             v.sort();
15211:             v
15212:         };
15213:         let full = Analyser::new().analyse(src, "tcl8.6");
15214:         let per_item = Analyser::new().analyse_per_item(src, "tcl8.6");
15215:         assert_eq!(codes(&full), codes(&per_item));
15216:         assert!(
15217:             !full
15218:                 .diagnostics
15219:                 .iter()
15220:                 .any(|d| d.message.contains("'puts'")),
15221:             "{:?}",
15222:             codes(&full)
15223:         );
15224:     }
15225: 
15226:     /// The same rename written in the parent still records normally — the
15227:     /// guard narrows the fact to its interpreter, it does not disable it.
15228:     #[test]
15229:     fn rename_in_the_parent_still_records_the_command_move() {
15230:         let src = "interp create c\nrename puts myputs\n";
15231:         let r = Analyser::new().analyse(src, "tcl8.6");
15232:         assert_eq!(
15233:             r.renamed_commands.get("::myputs").map(String::as_str),
15234:             Some("::puts"),
15235:             "{:?}",
15236:             r.renamed_commands
15237:         );
15238:     }
15239: 
15240:     /// `interp alias {} A {} B` inside a child's eval body creates the alias
15241:     /// in the *child* (an empty srcPath is "the interpreter I am running
15242:     /// in"), so it must home under that child's `@interp@` domain rather than
15243:     /// at the parent's global root.
15244:     #[test]
15245:     fn empty_path_interp_alias_inside_a_child_body_homes_in_that_child() {
15246:         let src = "interp create c\nc eval { interp alias {} shout {} puts }\n";
15247:         let r = Analyser::new().analyse(src, "tcl8.6");
15248:         assert!(
15249:             !r.command_aliases.contains_key("::shout"),
15250:             "the parent gained no alias: {:?}",
15251:             r.command_aliases.keys().collect::<Vec<_>>()
15252:         );
15253:         assert!(
15254:             r.command_aliases.contains_key("::@interp@c::shout"),
15255:             "the child's alias homes under its own domain: {:?}",
15256:             r.command_aliases.keys().collect::<Vec<_>>()
15257:         );
15258:     }
15259: 
15260:     /// The same alias written at the top level is unchanged.
15261:     #[test]
15262:     fn empty_path_interp_alias_at_top_level_still_homes_globally() {
15263:         let src = "interp alias {} shout {} puts\n";
15264:         let r = Analyser::new().analyse(src, "tcl8.6");
15265:         assert!(
15266:             r.command_aliases.contains_key("::shout"),
15267:             "{:?}",
15268:             r.command_aliases.keys().collect::<Vec<_>>()
15269:         );
15270:     }
15271: 
15272:     /// `interp eval child { proc foo }` runs in a child interpreter, so `foo`
15273:     /// is isolated from the parent's `::foo` — the two stay distinct commands,
15274:     /// so a parent rename of `::foo` can never reach the child body.
15275:     #[test]
15276:     fn interp_eval_child_isolates_definitions_from_the_parent() {
15277:         // Runnable Tcl (tclsh 9.0.4): the child is created before the
15278:         // eval.  The child's `foo` homes under the synthetic
15279:         // `@interp@child` domain — unrepresentable as a real namespace,
15280:         // so a parent namespace literally named `child` can never
15281:         // collide with the interpreter's definitions (the
15282:         // child-global-vs-parent-namespace identity split).
15283:         let mut a = Analyser::new();
15284:         let r = a.analyse(
15285:             "interp create child\nproc foo {} {}\ninterp eval child { proc foo {} {} }\n",
15286:             "tcl8.6",
15287:         );
15288:         let keys: Vec<&str> = r.all_procs.keys().map(String::as_str).collect();
15289:         assert!(r.all_procs.contains_key("::foo"), "parent proc: {keys:?}");
15290:         assert!(
15291:             r.all_procs.contains_key("::@interp@child::foo"),
15292:             "child proc isolated under the interpreter domain: {keys:?}",
15293:         );
15294:         assert!(
15295:             !r.all_procs.contains_key("::child::foo"),
15296:             "the child's global is not the parent namespace `::child`: {keys:?}",
15297:         );
15298:     }
15299: 
15300:     /// `sandbox eval { proc foo }` via the interpreter's own object command
15301:     /// (`interp create sandbox` binds `sandbox` itself as a callable
15302:     /// command) isolates definitions from the parent exactly like the
15303:     /// literal `interp eval sandbox { … }` form above — the far more common
15304:     /// real-world spelling (`docstrip_util.tcl`'s `$c eval {...}`, reduced to
15305:     /// a literal name here so it resolves statically).
15306:     #[test]
15307:     fn interp_handle_eval_isolates_definitions_from_the_parent() {
15308:         let mut a = Analyser::new();
15309:         let r = a.analyse(
15310:             "interp create sandbox\nproc foo {} {}\nsandbox eval { proc foo {} {} }\n",
15311:             "tcl8.6",
15312:         );
15313:         let keys: Vec<&str> = r.all_procs.keys().map(String::as_str).collect();
15314:         assert!(r.all_procs.contains_key("::foo"), "parent proc: {keys:?}");
15315:         assert!(
15316:             r.all_procs.contains_key("::@interp@sandbox::foo"),
15317:             "child proc isolated under the interpreter domain: {keys:?}",
15318:         );
15319:     }
15320: 
15321:     #[test]
15322:     fn renamed_away_interp_handle_reused_as_a_proc_is_not_treated_as_interp_eval() {
15323:         // TP: `self.interpreters` is only cleared by `interp delete`, so a plain
15324:         // `rename sandbox {}` (deleting the interpreter's own object
15325:         // command — confirmed against tclsh9.0: afterwards `info commands
15326:         // sandbox` is empty and the child interpreter is only reachable
15327:         // through whatever name, if any, it was renamed *to*) left a stale
15328:         // `sandbox` entry. A later, wholly unrelated `proc sandbox {sub
15329:         // body} {...}` reusing the freed name would then have any
15330:         // `sandbox eval …` call misidentified as isolated interpreter-eval
15331:         // (walking the literal second argument as a *script*) instead of an
15332:         // ordinary two-arg proc call — confirmed against tclsh9.0 that the
15333:         // real dispatch reaches the new proc, never the (now nameless,
15334:         // orphaned) interpreter.
15335:         let mut a = Analyser::new();
15336:         let r = a.analyse(
15337:             "interp create sandbox\n\
15338:              rename sandbox {}\n\
15339:              proc sandbox {sub body} {}\n\
15340:              sandbox eval { proc shouldNotBeIsolated {} {} }\n",
15341:             "tcl8.6",
15342:         );
15343:         let keys: Vec<&str> = r.all_procs.keys().map(String::as_str).collect();
15344:         assert!(
15345:             !r.all_procs
15346:                 .contains_key("::@interp@sandbox::shouldNotBeIsolated"),
15347:             "the call must not be isolated into the (deleted) interpreter's \
15348:              domain once `sandbox` has been renamed away and reused: {keys:?}",
15349:         );
15350:     }
15351: 
15352:     #[test]
15353:     fn renamed_interp_handle_still_isolates_under_its_new_name() {
15354:         // TP — the other half of the same fix: a rename that *moves* the
15355:         // interpreter handle (`NEW` non-empty) rather than deleting it must
15356:         // keep the tracking, now keyed by `NEW` — confirmed against
15357:         // tclsh9.0 that `rename sandbox t; t eval {...}` still talks to the
15358:         // same child interpreter. A name-only invalidation (removing `OLD`
15359:         // without transferring state to `NEW`) would wrongly stop isolating
15360:         // `t eval { ... }` too (falling through to an ordinary, unisolated
15361:         // command call). The domain name itself is always derived from
15362:         // whichever key the call site actually writes — `@interp@t`, not
15363:         // the original `@interp@sandbox` — exactly like every other
15364:         // interpreter-domain lookup in this module (e.g. the literal
15365:         // `interp eval` form re-derives its domain from its own `PATH`
15366:         // argument text the same way); this test only asserts that the
15367:         // call is isolated *at all* under the new name, not which domain
15368:         // string it lands in.
15369:         let mut a = Analyser::new();
15370:         let r = a.analyse(
15371:             "interp create sandbox\n\
15372:              rename sandbox t\n\
15373:              t eval { proc shouldBeIsolated {} {} }\n",
15374:             "tcl8.6",
15375:         );
15376:         let keys: Vec<&str> = r.all_procs.keys().map(String::as_str).collect();
15377:         assert!(
15378:             r.all_procs.contains_key("::@interp@t::shouldBeIsolated"),
15379:             "the renamed handle must still be tracked as an interpreter, \
15380:              isolating the eval body under its new name's domain: {keys:?}",
15381:         );
15382:     }
15383: 
15384:     #[test]
15385:     fn interp_handle_eval_and_literal_interp_eval_agree_on_the_same_domain() {
15386:         // The two spellings of the same operation must home under the
15387:         // *same* synthetic domain — the analyser can't tell them apart at
15388:         // run time (both dispatch on the identical interpreter object
15389:         // command), so it must not tell them apart statically either.
15390:         let mut a = Analyser::new();
15391:         let r = a.analyse(
15392:             "interp create sandbox\ninterp eval sandbox { proc viaLiteral {} {} }\n\
15393:              sandbox eval { proc viaHandle {} {} }\n",
15394:             "tcl8.6",
15395:         );
15396:         let keys: Vec<&str> = r.all_procs.keys().map(String::as_str).collect();
15397:         assert!(
15398:             r.all_procs.contains_key("::@interp@sandbox::viaLiteral"),
15399:             "{keys:?}"
15400:         );
15401:         assert!(
15402:             r.all_procs.contains_key("::@interp@sandbox::viaHandle"),
15403:             "{keys:?}"
15404:         );
15405:     }
15406: 
15407:     #[test]
15408:     fn two_interp_handles_never_cross_contaminate_same_named_procs() {
15409:         // TP: two
15410:         // separate safe child interpreters, each independently defining
15411:         // their own same-named `helper`, must never merge — a call inside
15412:         // one script must resolve to *that* interpreter's helper, never
15413:         // the other's.
15414:         let mut a = Analyser::new();
15415:         let r = a.analyse(
15416:             "interp create sandboxA\ninterp create sandboxB\n\
15417:              interp eval sandboxA { proc helper {} { return A } }\n\
15418:              sandboxB eval { proc helper {} { return B } }\n",
15419:             "tcl8.6",
15420:         );
15421:         let keys: Vec<&str> = r.all_procs.keys().map(String::as_str).collect();
15422:         assert!(
15423:             r.all_procs.contains_key("::@interp@sandboxA::helper"),
15424:             "{keys:?}"
15425:         );
15426:         assert!(
15427:             r.all_procs.contains_key("::@interp@sandboxB::helper"),
15428:             "{keys:?}"
15429:         );
15430:         // Each interpreter's own `helper` is a genuinely distinct
15431:         // ProcDef, not the same entry aliased twice.
15432:         assert_ne!(
15433:             r.all_procs["::@interp@sandboxA::helper"].body_span,
15434:             r.all_procs["::@interp@sandboxB::helper"].body_span,
15435:         );
15436:     }
15437: 
15438:     #[test]
15439:     fn untracked_bareword_eval_is_not_isolated() {
15440:         // TN / FN guard — a bareword shaped exactly like the tracked-handle
15441:         // idiom (`NAME eval { script }`) but never created via `interp
15442:         // create` must fall through to the generic dispatch untouched: no
15443:         // isolated scope, no crash.
15444:         let mut a = Analyser::new();
15445:         let r = a.analyse("untracked eval { proc foo {} {} }\n", "tcl8.6");
15446:         assert!(
15447:             !r.all_procs.keys().any(|k| k.contains("@interp@")),
15448:             "an untracked head must never open an interpreter domain: {:?}",
15449:             r.all_procs.keys().collect::<Vec<_>>(),
15450:         );
15451:     }
15452: 
15453:     #[test]
15454:     fn ordinary_proc_with_eval_as_sole_argument_is_untouched() {
15455:         // FP guard — an unrelated proc whose single argument merely happens
15456:         // to be the literal text `eval` must resolve as an ordinary call,
15457:         // never trip the arity/shape check into isolating anything.
15458:         let mut a = Analyser::new();
15459:         let r = a.analyse("proc foo {a} { return $a }\nfoo eval\n", "tcl8.6");
15460:         assert!(
15461:             !r.all_procs.keys().any(|k| k.contains("@interp@")),
15462:             "a 1-arg call must never be treated as NAME eval SCRIPT: {:?}",
15463:             r.all_procs.keys().collect::<Vec<_>>(),
15464:         );
15465:     }
15466: 
15467:     #[test]
15468:     fn interp_eval_into_uncreated_interp_warns_and_multiword_stays_isolated_945() {
15469:         // `interp eval ghost { … }` with no `interp create ghost` anywhere
15470:         // raises `could not find interpreter` at run time — W140.
15471:         let mut a = Analyser::new();
15472:         let r = a.analyse("interp eval ghost { proc foo {} {} }\n", "tcl8.6");
15473:         assert!(
15474:             r.diagnostics
15475:                 .iter()
15476:                 .any(|d| d.code == tcl_core_types::DiagCode::W140),
15477:             "eval into a never-created interpreter warns: {:?}",
15478:             r.diagnostics
15479:         );
15480:         // A dynamic create makes existence unknowable — W140 abstains.
15481:         let mut a2 = Analyser::new();
15482:         let r2 = a2.analyse(
15483:             "interp create $name\ninterp eval ghost { proc foo {} {} }\n",
15484:             "tcl8.6",
15485:         );
15486:         assert!(
15487:             !r2.diagnostics
15488:                 .iter()
15489:                 .any(|d| d.code == tcl_core_types::DiagCode::W140),
15490:             "dynamic interp creation abstains: {:?}",
15491:             r2.diagnostics
15492:         );
15493:         // Multi-word scripts concatenate at run time — the words must not
15494:         // be analysed in the *parent* scope, nor
15495:         // walked per-word (commands span word boundaries).
15496:         let mut a3 = Analyser::new();
15497:         let r3 = a3.analyse(
15498:             "interp create c\ninterp eval c {proc leak {} {}} {puts hi}\n",
15499:             "tcl8.6",
15500:         );
15501:         assert!(
15502:             !r3.all_procs.contains_key("::leak"),
15503:             "multi-word eval must not leak definitions into the parent: {:?}",
15504:             r3.all_procs.keys().collect::<Vec<_>>(),
15505:         );
15506:     }
15507: 
15508:     #[test]
15509:     fn deleted_and_recreated_interp_is_a_fresh_domain_945() {
15510:         // C: `interp delete s; interp create s` starts with an empty
15511:         // command table — the first lifetime's definitions are gone.  The
15512:         // epoch-stamped
15513:         // domain keeps the two lifetimes apart: the first eval's `foo`
15514:         // homes under `@interp@s`, the recreated interpreter's under
15515:         // `@interp@s#1`, and they never merge.
15516:         let mut a = Analyser::new();
15517:         let r = a.analyse(
15518:             "interp create s\ninterp eval s { proc foo {} {} }\n\
15519:              interp delete s\ninterp create s\n\
15520:              interp eval s { proc bar {} {} }\n",
15521:             "tcl8.6",
15522:         );
15523:         let keys: Vec<&str> = r.all_procs.keys().map(String::as_str).collect();
15524:         assert!(
15525:             r.all_procs.contains_key("::@interp@s::foo"),
15526:             "first lifetime's proc: {keys:?}"
15527:         );
15528:         assert!(
15529:             r.all_procs.contains_key("::@interp@s#1::bar"),
15530:             "recreated interpreter is a fresh domain: {keys:?}"
15531:         );
15532:         assert!(
15533:             !r.all_procs.contains_key("::@interp@s::bar"),
15534:             "the recreated child never merges with its predecessor: {keys:?}"
15535:         );
15536:     }
15537: 
15538:     #[test]
15539:     fn nested_interp_ops_qualify_against_the_enclosing_child_945() {
15540:         // `interp create t` inside `interp eval s {…}` creates `s t` —
15541:         // paths are relative to the *current* interpreter, so a top-level
15542:         // `interp eval {s t} {…}` reaches the grandchild without W140 and
15543:         // its definitions home under the composed domain.
15544:         let mut a = Analyser::new();
15545:         let r = a.analyse(
15546:             "interp create s\n\
15547:              interp eval s { interp create t }\n\
15548:              interp eval {s t} { proc deep {} {} }\n",
15549:             "tcl8.6",
15550:         );
15551:         assert!(
15552:             !r.diagnostics
15553:                 .iter()
15554:                 .any(|d| d.code == tcl_core_types::DiagCode::W140),
15555:             "the nested create makes `s t` exist: {:?}",
15556:             r.diagnostics
15557:         );
15558:         assert!(
15559:             r.all_procs.contains_key("::@interp@s t::deep"),
15560:             "grandchild definitions home under the composed domain: {:?}",
15561:             r.all_procs.keys().collect::<Vec<_>>()
15562:         );
15563:     }
15564: 
15565:     #[test]
15566:     fn cross_domain_interp_alias_links_child_calls_to_the_parent_target_945() {
15567:         // `interp alias s helper {} ::parent_helper` makes `helper`
15568:         // callable *inside the child* running the parent's proc — the
15569:         // alias deliberately crosses interpreter domains while
15570:         // definitions do not.  The child-side call
15571:         // resolves through the alias link to the parent target.
15572:         let mut a = Analyser::new();
15573:         let r = a.analyse(
15574:             "proc parent_helper {} {}\ninterp create s\n\
15575:              interp alias s helper {} parent_helper\n\
15576:              interp eval s { helper }\n",
15577:             "tcl8.6",
15578:         );
15579:         let alias = r
15580:             .command_aliases
15581:             .get("::@interp@s::helper")
15582:             .unwrap_or_else(|| {
15583:                 panic!(
15584:                     "child-domain alias recorded: {:?}",
15585:                     r.command_aliases.keys().collect::<Vec<_>>()
15586:                 )
15587:             });
15588:         assert_eq!(
15589:             alias.target, "::parent_helper",
15590:             "the alias target resolves in the parent domain",
15591:         );
15592:     }
15593: 
15594:     #[test]
15595:     fn safe_interp_hides_unsafe_commands_and_expose_restores_945() {
15596:         // naming.interpreter.original-source-visibility-advice
15597:         // docs/design/analysis/name-resolution-proofs/interpreter-original-source-visibility-advice.md
15598:         // tclsh 9.0.4: a `-safe` child hides `source` (and the rest of the
15599:         // non-CMD_IS_SAFE set) — calling it raises `invalid command name`.
15600:         // The source warning retains its explicit child/source assumptions.
15601:         // It does not establish an actual selected hidden command, so the
15602:         // possible source edge remains available to workspace consumers.
15603:         let mut a = Analyser::new();
15604:         let r = a.analyse(
15605:             "interp create -safe s\ninterp eval s { source b.tcl }\n",
15606:             "tcl8.6",
15607:         );
15608:         assert!(
15609:             r.diagnostics
15610:                 .iter()
15611:                 .any(|d| d.code == tcl_core_types::DiagCode::W129
15612:                     && d.conditional_interpreter_visibility().is_some()),
15613:             "hidden `source` in a safe interp warns: {:?}",
15614:             r.diagnostics
15615:         );
15616:         assert_eq!(
15617:             r.source_targets.len(),
15618:             1,
15619:             "conditional visibility does not discard the possible source edge: {:?}",
15620:             r.source_targets
15621:         );
15622:         // A safe command (`puts`) draws no W129; a non-safe interp draws
15623:         // none either.
15624:         let mut a2 = Analyser::new();
15625:         let r2 = a2.analyse(
15626:             "interp create -safe s\ninterp eval s { puts hi }\n\
15627:              interp create n\ninterp eval n { source b.tcl }\n",
15628:             "tcl8.6",
15629:         );
15630:         assert!(
15631:             !r2.diagnostics
15632:                 .iter()
15633:                 .any(|d| d.code == tcl_core_types::DiagCode::W129),
15634:             "safe commands and non-safe interps draw no W129: {:?}",
15635:             r2.diagnostics
15636:         );
15637:         // `interp expose s source` restores the command.
15638:         let mut a3 = Analyser::new();
15639:         let r3 = a3.analyse(
15640:             "interp create -safe s\ninterp expose s source\n\
15641:              interp eval s { source b.tcl }\n",
15642:             "tcl8.6",
15643:         );
15644:         assert!(
15645:             !r3.diagnostics
15646:                 .iter()
15647:                 .any(|d| d.code == tcl_core_types::DiagCode::W129),
15648:             "an exposed command is callable again: {:?}",
15649:             r3.diagnostics
15650:         );
15651:         // `interp hide n source` hides it in a *normal* interp too.
15652:         let mut a4 = Analyser::new();
15653:         let r4 = a4.analyse(
15654:             "interp create n\ninterp hide n source\n\
15655:              interp eval n { source b.tcl }\n",
15656:             "tcl8.6",
15657:         );
15658:         assert!(
15659:             r4.diagnostics
15660:                 .iter()
15661:                 .any(|d| d.code == tcl_core_types::DiagCode::W129
15662:                     && d.conditional_interpreter_visibility().is_some()),
15663:             "an explicitly hidden command warns in a normal interp: {:?}",
15664:             r4.diagnostics
15665:         );
15666:     }
15667: 
15668:     #[test]
15669:     fn safe_interp_child_redefinition_of_a_hidden_builtin_is_callable_945() {
15670:         // naming.interpreter.original-source-visibility-advice
15671:         // docs/design/analysis/name-resolution-proofs/interpreter-original-source-visibility-advice.md
15672:         // tclsh 9.0.4: `proc source {} {…}` inside a safe interp creates a
15673:         // real command in the ordinary command table — a table entirely
15674:         // separate from the hidden set — so calling `source` afterwards
15675:         // runs the user's proc, never `invalid command name`.  The gate
15676:         // must not draw W129 for the call, and the call must still be
15677:         // fully analysed (resolving to the local proc), not skipped as an
15678:         // effect-free hidden call.
15679:         let mut a = Analyser::new();
15680:         let r = a.analyse(
15681:             "interp create -safe s\n\
15682:              interp eval s { proc source {} { return ok }; source }\n",
15683:             "tcl8.6",
15684:         );
15685:         assert!(
15686:             !r.diagnostics
15687:                 .iter()
15688:                 .any(|d| d.code == tcl_core_types::DiagCode::W129),
15689:             "a locally-redefined name is callable, not hidden: {:?}",
15690:             r.diagnostics
15691:         );
15692:         assert!(
15693:             r.all_procs.contains_key("::@interp@s::source"),
15694:             "the local proc is recorded, not skipped: {:?}",
15695:             r.all_procs.keys().collect::<Vec<_>>()
15696:         );
15697:         // A call *preceding* the redefinition is unaffected by this file's
15698:         // whole-body approximation in the other direction — still hidden
15699:         // until the walk has seen a local definition — is not asserted
15700:         // here (the analyser's per-body model is not that finely ordered);
15701:         // what matters is that a real, common redefinition idiom never
15702:         // produces a false-positive W129 that also drops the call's facts.
15703:     }
15704: 
15705:     #[test]
15706:     fn interp_expose_with_a_new_name_tracks_the_new_name_945() {
15707:         // tclsh 9.0.4: `interp expose s source src` restores the hidden
15708:         // `source` implementation under the name `src` — `source` itself
15709:         // stays absent from ordinary lookup, and `src` becomes callable.
15710:         let mut a = Analyser::new();
15711:         let r = a.analyse(
15712:             "interp create -safe s\ninterp expose s source src\n\
15713:              interp eval s { source b.tcl }\n",
15714:             "tcl8.6",
15715:         );
15716:         assert!(
15717:             r.diagnostics
15718:                 .iter()
15719:                 .any(|d| d.code == tcl_core_types::DiagCode::W129
15720:                     && d.conditional_interpreter_visibility().is_some()),
15721:             "the hidden name itself stays hidden after an exposed rename: {:?}",
15722:             r.diagnostics
15723:         );
15724:         let mut a2 = Analyser::new();
15725:         let r2 = a2.analyse(
15726:             "interp create -safe s\ninterp expose s source src\n\
15727:              interp eval s { src b.tcl }\n",
15728:             "tcl8.6",
15729:         );
15730:         assert!(
15731:             !r2.diagnostics
15732:                 .iter()
15733:                 .any(|d| d.code == tcl_core_types::DiagCode::W129),
15734:             "the new exposed name is callable: {:?}",
15735:             r2.diagnostics
15736:         );
15737:     }
15738: 
15739:     // W129 through `[...]` bracket-substitution indirection.
15740: 
15741:     /// Conditional source visibility, independently of actual dispatch.
15742:     /// Original command/list operands and the enclosing source child are required.
15743:     #[test]
15744:     fn safe_interp_w129_list_quoted_apply_lambda_body_reports_hidden_source_1001() {
15745:         // naming.interpreter.original-source-visibility-advice
15746:         // docs/design/analysis/name-resolution-proofs/interpreter-original-source-visibility-advice.md
15747:         let mut a = Analyser::new();
15748:         let r = a.analyse(
15749:             "interp create -safe s\n\
15750:              interp eval s {\n\
15751:                  package ifneeded myPackage 1.0 [list apply {dir {\n\
15752:                      source [file join $dir font.tcl]\n\
15753:                  }} $dir]\n\
15754:              }\n",
15755:             "tcl8.6",
15756:         );
15757:         assert!(
15758:             r.diagnostics
15759:                 .iter()
15760:                 .any(|d| d.code == tcl_core_types::DiagCode::W129
15761:                     && d.conditional_interpreter_visibility().is_some()),
15762:             "hidden `source` nested inside a list-quoted apply lambda body \
15763:              (reached only via `package ifneeded`'s deferred script) warns: {:?}",
15764:             r.diagnostics
15765:         );
15766:     }
15767: 
15768:     /// Conditional source visibility, independently of actual dispatch.
15769:     /// Original command/list operands and the enclosing source child are required.
15770:     #[test]
15771:     fn safe_interp_w129_list_quoted_apply_in_command_prefix_position_1001() {
15772:         let mut a = Analyser::new();
15773:         let r = a.analyse(
15774:             "interp create -safe s\n\
15775:              interp eval s {\n\
15776:                  trace add variable x write [list apply {{a b c} {\n\
15777:                      exec ls\n\
15778:                  }} $x]\n\
15779:              }\n",
15780:             "tcl8.6",
15781:         );
15782:         assert!(
15783:             r.diagnostics
15784:                 .iter()
15785:                 .any(|d| d.code == tcl_core_types::DiagCode::W129
15786:                     && d.conditional_interpreter_visibility().is_some()),
15787:             "hidden `exec` nested inside a list-quoted apply lambda body \
15788:              reached via a CommandPrefix (`trace add … command`) position warns: {:?}",
15789:             r.diagnostics
15790:         );
15791:     }
15792: 
15793:     /// Conditional source visibility, independently of actual dispatch.
15794:     /// Original command/list operands and the enclosing source child are required.
15795:     #[test]
15796:     fn safe_interp_w129_list_quoted_apply_after_idle_1001() {
15797:         let mut a = Analyser::new();
15798:         let r = a.analyse(
15799:             "interp create -safe s\n\
15800:              interp eval s {\n\
15801:                  after idle [list apply {x {\n\
15802:                      file delete $x\n\
15803:                  }} val]\n\
15804:              }\n",
15805:             "tcl8.6",
15806:         );
15807:         assert!(
15808:             r.diagnostics
15809:                 .iter()
15810:                 .any(|d| d.code == tcl_core_types::DiagCode::W129
15811:                     && d.conditional_interpreter_visibility().is_some()),
15812:             "hidden `file` nested inside a list-quoted apply lambda body \
15813:              reached via `after idle` warns: {:?}",
15814:             r.diagnostics
15815:         );
15816:     }
15817: 
15818:     /// Conditional source visibility, independently of actual dispatch.
15819:     /// Original command/list operands and the enclosing source child are required.
15820:     #[test]
15821:     fn safe_interp_w129_list_quoted_hidden_command_directly_1001() {
15822:         let mut a = Analyser::new();
15823:         let r = a.analyse(
15824:             "interp create -safe s\n\
15825:              interp eval s { after idle [list source b.tcl] }\n",
15826:             "tcl8.6",
15827:         );
15828:         assert!(
15829:             r.diagnostics
15830:                 .iter()
15831:                 .any(|d| d.code == tcl_core_types::DiagCode::W129
15832:                     && d.conditional_interpreter_visibility().is_some()),
15833:             "a bare `[list source …]` in a deferred-call position warns \
15834:              directly, with no `apply` indirection needed: {:?}",
15835:             r.diagnostics
15836:         );
15837:     }
15838: 
15839:     /// Conditional source visibility, independently of actual dispatch.
15840:     /// Original command/list operands and the enclosing source child are required.
15841:     #[test]
15842:     fn safe_interp_w129_list_quoted_apply_in_plain_data_is_not_flagged_1001() {
15843:         let mut a = Analyser::new();
15844:         let r = a.analyse(
15845:             "interp create -safe s\n\
15846:              interp eval s {\n\
15847:                  set data [list apply {x { source $x }} value]\n\
15848:              }\n",
15849:             "tcl8.6",
15850:         );
15851:         assert!(
15852:             !r.diagnostics
15853:                 .iter()
15854:                 .any(|d| d.code == tcl_core_types::DiagCode::W129),
15855:             "a `[list apply …]` value that is only ever stored, never \
15856:              invoked, must not warn: {:?}",
15857:             r.diagnostics
15858:         );
15859:     }
15860: 
15861:     /// Conditional source visibility, independently of actual dispatch.
15862:     /// Original command/list operands and the enclosing source child are required.
15863:     #[test]
15864:     fn list_quoted_apply_lambda_outside_any_safe_interp_is_untouched_1001() {
15865:         let mut a = Analyser::new();
15866:         let r = a.analyse(
15867:             "package ifneeded myPackage 1.0 [list apply {dir {source [file join $dir x]}} $dir]\n",
15868:             "tcl8.6",
15869:         );
15870:         assert!(
15871:             !r.diagnostics
15872:                 .iter()
15873:                 .any(|d| d.code == tcl_core_types::DiagCode::W129),
15874:             "no safe interpreter is involved, so no W129 can ever fire: {:?}",
15875:             r.diagnostics
15876:         );
15877:         assert_eq!(
15878:             r.all_procs.len(),
15879:             0,
15880:             "this fix must not widen the general analyser's scope — \
15881:              the list-quoted lambda body stays un-analysed outside a \
15882:              safe-interpreter context, exactly as before #1001: {:?}",
15883:             r.all_procs.keys().collect::<Vec<_>>()
15884:         );
15885:     }
15886: 
15887:     /// Conditional source visibility, independently of actual dispatch.
15888:     /// Original command/list operands and the enclosing source child are required.
15889:     #[test]
15890:     fn safe_interp_w129_direct_nested_bracket_substitution_1001() {
15891:         let mut a = Analyser::new();
15892:         let r = a.analyse(
15893:             "interp create -safe s\ninterp eval s { set x [source b.tcl] }\n",
15894:             "tcl8.6",
15895:         );
15896:         assert!(
15897:             r.diagnostics
15898:                 .iter()
15899:                 .any(|d| d.code == tcl_core_types::DiagCode::W129
15900:                     && d.conditional_interpreter_visibility().is_some()),
15901:             "a directly nested `[source …]` substitution warns: {:?}",
15902:             r.diagnostics
15903:         );
15904:     }
15905: 
15906:     /// Conditional source visibility, independently of actual dispatch.
15907:     /// Original command/list operands and the enclosing source child are required.
15908:     #[test]
15909:     fn safe_interp_w129_direct_nested_bracket_substitution_deep_1001() {
15910:         let mut a = Analyser::new();
15911:         let r = a.analyse(
15912:             "interp create -safe s\n\
15913:              interp eval s { if {[catch {set y [exec ls]} err]} { puts $err } }\n",
15914:             "tcl8.6",
15915:         );
15916:         assert!(
15917:             r.diagnostics
15918:                 .iter()
15919:                 .any(|d| d.code == tcl_core_types::DiagCode::W129
15920:                     && d.conditional_interpreter_visibility().is_some()),
15921:             "a deeply nested `[exec …]` substitution still warns: {:?}",
15922:             r.diagnostics
15923:         );
15924:     }
15925: 
15926:     /// Conditional source visibility, independently of actual dispatch.
15927:     /// Original command/list operands and the enclosing source child are required.
15928:     #[test]
15929:     fn safe_interp_w129_expand_list_quoted_head_1001() {
15930:         let mut a = Analyser::new();
15931:         let r = a.analyse(
15932:             "interp create -safe s\ninterp eval s { {*}[list source b.tcl] }\n",
15933:             "tcl8.6",
15934:         );
15935:         assert!(
15936:             r.diagnostics
15937:                 .iter()
15938:                 .any(|d| d.code == tcl_core_types::DiagCode::W129
15939:                     && d.conditional_interpreter_visibility().is_some()),
15940:             "`{{*}}[list source …]` used as the whole statement warns \
15941:              on the effective (expanded) head: {:?}",
15942:             r.diagnostics
15943:         );
15944:     }
15945: 
15946:     /// Conditional source visibility, independently of actual dispatch.
15947:     /// Original command/list operands and the enclosing source child are required.
15948:     #[test]
15949:     fn safe_interp_w129_expand_dynamic_var_head_not_flagged_1001() {
15950:         let mut a = Analyser::new();
15951:         let r = a.analyse(
15952:             "interp create -safe s\n\
15953:              interp eval s { set cmdList [list source b.tcl]; {*}$cmdList }\n",
15954:             "tcl8.6",
15955:         );
15956:         assert!(
15957:             !r.diagnostics
15958:                 .iter()
15959:                 .any(|d| d.code == tcl_core_types::DiagCode::W129),
15960:             "an opaque `{{*}}$var` expansion is not statically resolvable \
15961:              and must not warn: {:?}",
15962:             r.diagnostics
15963:         );
15964:     }
15965: 
15966:     /// Conditional source visibility, independently of actual dispatch.
15967:     /// Original command/list operands and the enclosing source child are required.
15968:     #[test]
15969:     fn safe_interp_w129_dynamic_variable_dispatch_not_flagged_1001() {
15970:         let mut a = Analyser::new();
15971:         let r = a.analyse(
15972:             "interp create -safe s\n\
15973:              interp eval s { set cmd source; $cmd b.tcl }\n",
15974:             "tcl8.6",
15975:         );
15976:         assert!(
15977:             !r.diagnostics
15978:                 .iter()
15979:                 .any(|d| d.code == tcl_core_types::DiagCode::W129),
15980:             "dynamic dispatch through a variable is not statically \
15981:              resolvable and must not warn: {:?}",
15982:             r.diagnostics
15983:         );
15984:     }
15985: 
15986:     /// Conditional source visibility, independently of actual dispatch.
15987:     /// Original command/list operands and the enclosing source child are required.
15988:     #[test]
15989:     fn safe_interp_w129_eval_list_quoted_hidden_command_1001() {
15990:         let mut a = Analyser::new();
15991:         let r = a.analyse(
15992:             "interp create -safe s\ninterp eval s { eval [list source b.tcl] }\n",
15993:             "tcl8.6",
15994:         );
15995:         assert!(
15996:             r.diagnostics
15997:                 .iter()
15998:                 .any(|d| d.code == tcl_core_types::DiagCode::W129
15999:                     && d.conditional_interpreter_visibility().is_some()),
16000:             "`eval [list source …]` warns on the resolved head: {:?}",
16001:             r.diagnostics
16002:         );
16003:     }
16004: 
16005:     /// Conditional source visibility, independently of actual dispatch.
16006:     /// Original command/list operands and the enclosing source child are required.
16007:     #[test]
16008:     fn safe_interp_w129_uplevel_list_quoted_hidden_command_1001() {
16009:         let mut a = Analyser::new();
16010:         let r = a.analyse(
16011:             "interp create -safe s\ninterp eval s { uplevel [list source b.tcl] }\n",
16012:             "tcl8.6",
16013:         );
16014:         assert!(
16015:             r.diagnostics
16016:                 .iter()
16017:                 .any(|d| d.code == tcl_core_types::DiagCode::W129
16018:                     && d.conditional_interpreter_visibility().is_some()),
16019:             "`uplevel [list source …]` warns on the resolved head: {:?}",
16020:             r.diagnostics
16021:         );
16022:     }
16023: 
16024:     /// Conditional source visibility, independently of actual dispatch.
16025:     /// Original command/list operands and the enclosing source child are required.
16026:     #[test]
16027:     fn safe_interp_w129_list_quoted_apply_safe_command_not_flagged_1001() {
16028:         let mut a = Analyser::new();
16029:         let r = a.analyse(
16030:             "interp create -safe s\n\
16031:              interp eval s { after idle [list apply {x { puts $x }} val] }\n",
16032:             "tcl8.6",
16033:         );
16034:         assert!(
16035:             !r.diagnostics
16036:                 .iter()
16037:                 .any(|d| d.code == tcl_core_types::DiagCode::W129),
16038:             "a safe command (`puts`) reached via list-quoted apply must \
16039:              not warn: {:?}",
16040:             r.diagnostics
16041:         );
16042:     }
16043: 
16044:     /// Conditional source visibility, independently of actual dispatch.
16045:     /// Original command/list operands and the enclosing source child are required.
16046:     #[test]
16047:     fn safe_interp_w129_redefined_command_not_flagged_through_indirection_1001() {
16048:         let mut a = Analyser::new();
16049:         let r = a.analyse(
16050:             "interp create -safe s\n\
16051:              interp eval s {\n\
16052:                  proc source {} { return ok }\n\
16053:                  after idle [list apply {{} { source }}]\n\
16054:              }\n",
16055:             "tcl8.6",
16056:         );
16057:         assert!(
16058:             !r.diagnostics
16059:                 .iter()
16060:                 .any(|d| d.code == tcl_core_types::DiagCode::W129),
16061:             "a locally-redefined name reached via list-quoted apply is \
16062:              callable, not hidden: {:?}",
16063:             r.diagnostics
16064:         );
16065:     }
16066: 
16067:     /// Conditional source visibility, independently of actual dispatch.
16068:     /// Original command/list operands and the enclosing source child are required.
16069:     #[test]
16070:     fn safe_interp_w129_alias_bridged_command_not_flagged_through_indirection_1001() {
16071:         let mut a = Analyser::new();
16072:         let r = a.analyse(
16073:             "interp create -safe s\n\
16074:              interp alias s foo {} source\n\
16075:              interp eval s { after idle [list apply {{} { foo }}] }\n",
16076:             "tcl8.6",
16077:         );
16078:         assert!(
16079:             !r.diagnostics
16080:                 .iter()
16081:                 .any(|d| d.code == tcl_core_types::DiagCode::W129),
16082:             "an alias bridging a capability in from the trusted parent is \
16083:              not itself a hidden registry name, so it must not warn: {:?}",
16084:             r.diagnostics
16085:         );
16086:     }
16087: 
16088:     /// `namespace inscope ::x { proc foo }` runs the body in `::x`, so `foo`
16089:     /// homes to `::x::foo` — the same namespace frame as `namespace eval`, not
16090:     /// the caller's scope.
16091:     #[test]
16092:     fn namespace_inscope_runs_the_body_in_the_named_namespace() {
16093:         let mut a = Analyser::new();
16094:         let r = a.analyse("namespace inscope ::x { proc foo {} {} }\n", "tcl8.6");
16095:         let keys: Vec<&str> = r.all_procs.keys().map(String::as_str).collect();
16096:         assert!(
16097:             r.all_procs.contains_key("::x::foo"),
16098:             "inscope body should home to the named namespace: {keys:?}",
16099:         );
16100:         assert!(
16101:             !r.all_procs.contains_key("::foo"),
16102:             "the body must not resolve in the caller's global scope: {keys:?}",
16103:         );
16104:     }
16105: 
16106:     /// `namespace code { proc foo }` captures the *current* namespace, so its
16107:     /// script is analysed in this scope — inside `::x`, `foo` homes to
16108:     /// `::x::foo`.
16109:     #[test]
16110:     fn namespace_code_analyses_the_script_in_the_current_namespace() {
16111:         let mut a = Analyser::new();
16112:         let r = a.analyse(
16113:             "namespace eval ::x { namespace code { proc foo {} {} } }\n",
16114:             "tcl8.6",
16115:         );
16116:         let keys: Vec<&str> = r.all_procs.keys().map(String::as_str).collect();
16117:         assert!(
16118:             r.all_procs.contains_key("::x::foo"),
16119:             "namespace code script should analyse in the current namespace: {keys:?}",
16120:         );
16121:     }
16122: 
16123:     /// `interp eval {} { proc foo }` targets the *current* interpreter, so
16124:     /// `foo` is the parent's `::foo` (no isolation, no synthetic namespace).
16125:     #[test]
16126:     fn interp_eval_empty_path_is_the_current_interpreter() {
16127:         let mut a = Analyser::new();
16128:         let r = a.analyse("interp eval {} { proc foo {} {} }\n", "tcl8.6");
16129:         let keys: Vec<&str> = r.all_procs.keys().map(String::as_str).collect();
16130:         assert!(
16131:             r.all_procs.contains_key("::foo"),
16132:             "current-interp proc: {keys:?}"
16133:         );
16134:         assert!(
16135:             !keys.iter().any(|k| k.contains("::::")),
16136:             "an empty path must not open a synthetic namespace: {keys:?}",
16137:         );
16138:     }
16139: 
16140:     #[test]
16141:     fn handle_namespace_eval_creates_child_scope() {
16142:         let mut a = Analyser::new();
16143:         let handled = a.handle_namespace_eval_command(
16144:             &[
16145:                 "eval".to_string(),
16146:                 "ns1".to_string(),
16147:                 "proc inner {} {}".to_string(),
16148:             ],
16149:             &[
16150:                 esc_tok(span(10, 14)),
16151:                 esc_tok(span(15, 18)),
16152:                 str_tok(span(19, 35)),
16153:             ],
16154:             &[],
16155:             &[],
16156:         );
16157:         assert!(handled);
16158:         assert_eq!(a.result.global_scope.children.len(), 1);
16159:         assert_eq!(a.result.global_scope.children[0].name, "ns1");
16160:         assert_eq!(
16161:             a.result.global_scope.children[0].kind,
16162:             crate::analyser::types::ScopeKind::Namespace,
16163:         );
16164:     }
16165: 
16166:     #[test]
16167:     fn namespace_scope_geometry_retains_the_actual_point_operand() {
16168:         // naming.source.original-point-operand-projection
16169:         // docs/design/analysis/name-resolution-proofs/original-point-operand-projection.md
16170:         let source = "set target A; namespace eval $target {namespace eval B {set x 1}}";
16171:         let result = Analyser::new().analyse(source, "tcl8.6");
16172:         let outer = &result.global_scope.children[0];
16173:         let inner = &outer.children[0];
16174:         let outer_input = result
16175:             .namespace_refs
16176:             .iter()
16177:             .find(|reference| {
16178:                 reference
16179:                     .original_name_input
16180:                     .as_ref()
16181:                     .is_some_and(|input| input.bytes() == b"A")
16182:             })
16183:             .unwrap()
16184:             .original_name_input
16185:             .as_ref()
16186:             .unwrap();
16187:         let inner_input = result
16188:             .namespace_refs
16189:             .iter()
16190:             .find(|reference| {
16191:                 reference
16192:                     .original_name_input
16193:                     .as_ref()
16194:                     .is_some_and(|input| input.bytes() == b"B")
16195:             })
16196:             .unwrap()
16197:             .original_name_input
16198:             .as_ref()
16199:             .unwrap();
16200:         assert_eq!(
16201:             outer.naming_scope,
16202:             result
16203:                 .global_scope
16204:                 .naming_scope
16205:                 .as_ref()
16206:                 .unwrap()
16207:                 .child_from_input(outer_input)
16208:         );
16209:         assert!(outer.naming_scope.is_some());
16210:         assert_eq!(
16211:             inner.naming_scope,
16212:             outer
16213:                 .naming_scope
16214:                 .as_ref()
16215:                 .unwrap()
16216:                 .child_from_input(inner_input)
16217:         );
16218:         assert!(inner.naming_scope.is_some());
16219:         let unknown = Analyser::new().analyse("namespace eval $missing {set x 1}", "tcl8.6");
16220:         assert!(unknown.global_scope.children[0].naming_scope.is_none());
16221:     }
16222: 
16223:     #[test]
16224:     fn handle_namespace_eval_records_body_span() {
16225:         let mut a = Analyser::new();
16226:         a.handle_namespace_eval_command(
16227:             &["eval".to_string(), "ns1".to_string(), String::new()],
16228:             &[
16229:                 esc_tok(span(10, 14)),
16230:                 esc_tok(span(15, 18)),
16231:                 str_tok(span(19, 35)),
16232:             ],
16233:             &[],
16234:             &[],
16235:         );
16236:         assert_eq!(
16237:             a.result.global_scope.children[0].body_span,
16238:             Some(span(19, 35))
16239:         );
16240:     }
16241: 
16242:     #[test]
16243:     fn handle_namespace_eval_dynamic_target_gets_a_synthetic_span_keyed_name() {
16244:         // TP (corpus shape: irc.tcl's per-connection
16245:         // `namespace eval $name { … }` idiom): a
16246:         // dynamic target must never become the scope's `.name` verbatim (two
16247:         // unrelated occurrences sharing the same variable name would then
16248:         // collapse into one scope), so it's replaced with a synthetic name
16249:         // keyed on this occurrence's own token offset.
16250:         let mut a = Analyser::new();
16251:         a.handle_namespace_eval_command(
16252:             &[
16253:                 "eval".to_string(),
16254:                 "$name".to_string(),
16255:                 "proc inner {} {}".to_string(),
16256:             ],
16257:             &[
16258:                 esc_tok(span(10, 14)),
16259:                 esc_tok(span(15, 20)),
16260:                 str_tok(span(21, 37)),
16261:             ],
16262:             &[],
16263:             &[],
16264:         );
16265:         assert_eq!(a.result.global_scope.children[0].name, "@dynns@15");
16266:     }
16267: 
16268:     #[test]
16269:     fn handle_namespace_eval_literal_target_keeps_its_written_name() {
16270:         // FN guard — a literal (non-dynamic) target must still use its own
16271:         // written text verbatim.
16272:         let mut a = Analyser::new();
16273:         a.handle_namespace_eval_command(
16274:             &["eval".to_string(), "ns1".to_string(), String::new()],
16275:             &[
16276:                 esc_tok(span(10, 14)),
16277:                 esc_tok(span(15, 18)),
16278:                 str_tok(span(19, 35)),
16279:             ],
16280:             &[],
16281:             &[],
16282:         );
16283:         assert_eq!(a.result.global_scope.children[0].name, "ns1");
16284:     }
16285: 
16286:     #[test]
16287:     fn two_dynamic_namespace_eval_blocks_sharing_a_variable_name_never_collide() {
16288:         // TP — the full-pipeline shape from irc.tcl: two lexically
16289:         // unrelated procs each open `namespace eval $name { … }` with a
16290:         // same-named local `name` (an unremarkable choice for this exact
16291:         // idiom) and each define their own `helper`. Keying both blocks'
16292:         // scope on the literal text "$name" would let the second `helper`
16293:         // silently overwrite the first in the flat `all_procs` map.
16294:         let mut a = Analyser::new();
16295:         let r = a.analyse(
16296:             "proc setupA {} {\n    set name connA\n    namespace eval $name {\n        proc helper {} { return A }\n    }\n}\n\
16297:              proc setupB {} {\n    set name connB\n    namespace eval $name {\n        proc helper {} { return B }\n    }\n}\n",
16298:             "tcl8.6",
16299:         );
16300:         // drift-ok: test assertion counting distinct entries by simple name
16301:         // to prove no cross-occurrence merge, not a resolution decision.
16302:         let helpers: Vec<_> = r
16303:             .all_procs
16304:             .iter()
16305:             .filter(|(_, p)| p.name == "helper")
16306:             .collect();
16307:         assert_eq!(
16308:             helpers.len(),
16309:             2,
16310:             "both blocks' helper must survive as distinct entries: {:?}",
16311:             r.all_procs.keys().collect::<Vec<_>>(),
16312:         );
16313:         assert_ne!(
16314:             helpers[0].0, helpers[1].0,
16315:             "distinct call sites must get distinct qualified keys: {helpers:?}",
16316:         );
16317:         assert_ne!(
16318:             helpers[0].1.body_span, helpers[1].1.body_span,
16319:             "each is genuinely its own definition, not the same one twice: {helpers:?}",
16320:         );
16321:     }
16322: 
16323:     // handle_namespace_ensemble
16324: 
16325:     #[test]
16326:     fn handle_namespace_ensemble_records_in_set() {
16327:         use crate::analyser::types::{Scope, ScopeKind};
16328:         let mut a = Analyser::new();
16329:         a.result
16330:             .global_scope
16331:             .children
16332:             .push(Scope::new(ScopeKind::Namespace, "myns"));
16333:         a.handle_namespace_ensemble(&["ensemble".to_string(), "create".to_string()], &[], &[0]);
16334:         assert!(a.ensemble_namespaces.contains("::myns"));
16335:     }
16336: 
16337:     #[test]
16338:     fn handle_namespace_ensemble_command_option_recorded() {
16339:         use crate::analyser::types::{Scope, ScopeKind};
16340:         let mut a = Analyser::new();
16341:         // `-command` recognition is registry-driven (`ENSEMBLE_CREATE_OPTIONS`).
16342:         a.registry = Some(std::sync::Arc::clone(
16343:             tcl_registry::model::ingress::static_context_for("tcl").commands(),
16344:         ));
16345:         a.result
16346:             .global_scope
16347:             .children
16348:             .push(Scope::new(ScopeKind::Namespace, "myns"));
16349:         a.handle_namespace_ensemble(
16350:             &[
16351:                 "ensemble".to_string(),
16352:                 "create".to_string(),
16353:                 "-command".to_string(),
16354:                 "::ens".to_string(),
16355:             ],
16356:             &[],
16357:             &[0],
16358:         );
16359:         assert!(a.ensemble_namespaces.contains("::myns"));
16360:         assert!(a.ensemble_namespaces.contains("::ens"));
16361:     }
16362: 
16363:     #[test]
16364:     fn handle_namespace_ensemble_command_option_qualifies_relative_name() {
16365:         use crate::analyser::types::{Scope, ScopeKind};
16366:         let mut a = Analyser::new();
16367:         // `-command` recognition is registry-driven (`ENSEMBLE_CREATE_OPTIONS`).
16368:         a.registry = Some(std::sync::Arc::clone(
16369:             tcl_registry::model::ingress::static_context_for("tcl").commands(),
16370:         ));
16371:         a.result
16372:             .global_scope
16373:             .children
16374:             .push(Scope::new(ScopeKind::Namespace, "myns"));
16375:         a.handle_namespace_ensemble(
16376:             &[
16377:                 "ensemble".to_string(),
16378:                 "create".to_string(),
16379:                 "-command".to_string(),
16380:                 "ens".to_string(),
16381:             ],
16382:             &[],
16383:             &[0],
16384:         );
16385:         assert!(a.ensemble_namespaces.contains("::myns::ens"));
16386:     }
16387: 
16388:     #[test]
16389:     fn handle_namespace_ensemble_command_option_dynamic_value_not_recorded() {
16390:         use crate::analyser::types::{Scope, ScopeKind};
16391:         let mut a = Analyser::new();
16392:         a.result
16393:             .global_scope
16394:             .children
16395:             .push(Scope::new(ScopeKind::Namespace, "myns"));
16396:         a.handle_namespace_ensemble(
16397:             &[
16398:                 "ensemble".to_string(),
16399:                 "create".to_string(),
16400:                 "-command".to_string(),
16401:                 "$dyn".to_string(),
16402:             ],
16403:             &[],
16404:             &[0],
16405:         );
16406:         assert_eq!(
16407:             a.ensemble_namespaces,
16408:             std::collections::HashSet::from(["::myns".to_string()])
16409:         );
16410:     }
16411: 
16412:     #[test]
16413:     fn namespace_ensemble_map_and_subcommands_record_command_references() {
16414:         // `-map {get ::foo::getImpl}` — the odd element is the target command;
16415:         // `-subcommands {show}` maps `show` to `::foo::show`.  Both become
16416:         // command references so navigation reaches the implementing procs.
16417:         let mut a = Analyser::new();
16418:         let src = "namespace eval ::foo {\n    \
16419:                    proc getImpl {} {}\n    \
16420:                    proc show {} {}\n    \
16421:                    namespace ensemble create -map {get ::foo::getImpl} -subcommands {show}\n\
16422:                    }\n";
16423:         let r = a.analyse(src, "tcl8.6");
16424:         let resolved: Vec<&str> = r
16425:             .command_invocations
16426:             .iter()
16427:             .filter_map(|i| i.resolved_qualified_name.as_deref())
16428:             .collect();
16429:         assert!(
16430:             resolved.contains(&"::foo::getImpl"),
16431:             "the -map target should be a command reference: {resolved:?}",
16432:         );
16433:         assert!(
16434:             resolved.contains(&"::foo::show"),
16435:             "the -subcommands name should map to `<ns>::show`: {resolved:?}",
16436:         );
16437:     }
16438: 
16439:     /// A tk-shaped ensemble: the ensemble-creating command runs inside
16440:     /// a proc whose *qualified name* homes it to `::tk`, but which is declared
16441:     /// at the top level with no enclosing `namespace eval`.  `namespace
16442:     /// current` there is `::tk` (tclsh 8.6.16 / 9.0.4-verified: the ensemble
16443:     /// created is `::tk` and `tk alpha` dispatches to `::tk::alpha`), so the
16444:     /// subcommand must map to `::tk::alpha`; a purely lexical namespace walk
16445:     /// skips proc scopes and would map it to `::alpha`.
16446:     #[test]
16447:     fn namespace_ensemble_create_in_a_qualified_name_proc_homes_to_that_namespace_923_idx85() {
16448:         let mut a = Analyser::new();
16449:         let src = "namespace eval ::tk {}\n\
16450:                    proc ::tk::alpha {} {}\n\
16451:                    proc ::tk::SetupEnsemble {} {\n    \
16452:                    namespace ensemble create -subcommands {alpha}\n\
16453:                    }\n";
16454:         let r = a.analyse(src, "tcl8.6");
16455:         let resolved: Vec<&str> = r
16456:             .command_invocations
16457:             .iter()
16458:             .filter_map(|i| i.resolved_qualified_name.as_deref())
16459:             .collect();
16460:         assert!(
16461:             resolved.contains(&"::tk::alpha"),
16462:             "the subcommand should map to the proc's defining namespace: {resolved:?}",
16463:         );
16464:         assert!(
16465:             !resolved.contains(&"::alpha"),
16466:             "the lexical (global) namespace is the wrong home: {resolved:?}",
16467:         );
16468:         assert!(
16469:             a.ensemble_namespaces.contains("::tk"),
16470:             "the ensemble command itself is `::tk`: {:?}",
16471:             a.ensemble_namespaces,
16472:         );
16473:     }
16474: 
16475:     /// TN control for the above: the ordinary lexical case — the ensemble is
16476:     /// created directly inside `namespace eval ::foo`, so both the lexical and
16477:     /// the command-resolution namespace agree on `::foo`.  Pinned so the common
16478:     /// shape cannot regress.
16479:     #[test]
16480:     fn namespace_ensemble_create_lexically_inside_namespace_eval_is_unchanged_923_idx85() {
16481:         let mut a = Analyser::new();
16482:         let src = "namespace eval ::foo {\n    \
16483:                    proc alpha {} {}\n    \
16484:                    namespace ensemble create -subcommands {alpha}\n\
16485:                    }\n";
16486:         let r = a.analyse(src, "tcl8.6");
16487:         let resolved: Vec<&str> = r
16488:             .command_invocations
16489:             .iter()
16490:             .filter_map(|i| i.resolved_qualified_name.as_deref())
16491:             .collect();
16492:         assert!(
16493:             resolved.contains(&"::foo::alpha"),
16494:             "lexical case still maps to `::foo::alpha`: {resolved:?}",
16495:         );
16496:         assert!(a.ensemble_namespaces.contains("::foo"));
16497:     }
16498: 
16499:     /// The definition-homing sweep: every analyser site that asks "which
16500:     /// namespace is current here?" answers with
16501:     /// [`Analyser::command_resolution_namespace`], so a definition made inside
16502:     /// a qualified-name proc's body homes to that proc's *defining* namespace.
16503:     /// These are cases (A)–(D) from `docs/design/analysis/name-resolution.md`
16504:     /// §3.5, each with the real interpreter's answer as the expectation.
16505:     #[test]
16506:     fn definitions_inside_a_qualified_name_proc_home_to_its_defining_namespace_923_idx85() {
16507:         // (A) The already-correct lexical control.
16508:         let mut a = Analyser::new();
16509:         let r = a.analyse(
16510:             "namespace eval ::x { proc mk {} { proc helper {} {} } }\n",
16511:             "tcl8.6",
16512:         );
16513:         assert!(
16514:             r.all_procs.contains_key("::x::helper"),
16515:             "(A) lexical case: {:?}",
16516:             r.all_procs.keys().collect::<Vec<_>>(),
16517:         );
16518: 
16519:         // (B) A qualified-name proc with no enclosing `namespace eval`.
16520:         let mut a = Analyser::new();
16521:         let r = a.analyse("proc ::x::mk {} { proc helper {} {} }\n", "tcl8.6");
16522:         assert!(
16523:             r.all_procs.contains_key("::x::helper"),
16524:             "(B) qualified encloser: {:?}",
16525:             r.all_procs.keys().collect::<Vec<_>>(),
16526:         );
16527: 
16528:         // (C) A qualified-name proc whose own name overrides the lexical
16529:         // `namespace eval` it sits in.
16530:         let mut a = Analyser::new();
16531:         let r = a.analyse(
16532:             "namespace eval ::x { proc ::y::mk {} { proc helper {} {} } }\n",
16533:             "tcl8.6",
16534:         );
16535:         assert!(
16536:             r.all_procs.contains_key("::y::helper"),
16537:             "(C) absolute name rebases: {:?}",
16538:             r.all_procs.keys().collect::<Vec<_>>(),
16539:         );
16540: 
16541:         // (D) The same rule for a class, not a proc.
16542:         let mut a = Analyser::new();
16543:         let r = a.analyse("proc ::x::mk {} { oo::class create Helper {} }\n", "tcl8.6");
16544:         assert!(
16545:             r.all_classes.contains_key("::x::Helper"),
16546:             "(D) class create: {:?}",
16547:             r.all_classes.keys().collect::<Vec<_>>(),
16548:         );
16549:     }
16550: 
16551:     /// A nested definition that mis-homes to `::` collides with a real global
16552:     /// of the same name, and one silently overwrites the other.  Both must
16553:     /// survive under their own keys.
16554:     #[test]
16555:     fn a_nested_definition_no_longer_overwrites_a_same_named_global_923_idx85() {
16556:         let mut a = Analyser::new();
16557:         let r = a.analyse(
16558:             "proc helper {} { return global }\n\
16559:              proc ::x::mk {} { proc helper {} { return nested } }\n",
16560:             "tcl8.6",
16561:         );
16562:         let keys: Vec<&str> = r.all_procs.keys().map(String::as_str).collect();
16563:         assert!(
16564:             r.all_procs.contains_key("::helper"),
16565:             "global lost: {keys:?}"
16566:         );
16567:         assert!(
16568:             r.all_procs.contains_key("::x::helper"),
16569:             "nested lost: {keys:?}",
16570:         );
16571:     }
16572: 
16573:     /// `namespace import` written inside a qualified-name proc imports into
16574:     /// that proc's defining namespace, not the global one.
16575:     #[test]
16576:     fn namespace_import_inside_a_qualified_name_proc_targets_that_namespace_923_idx85() {
16577:         let mut a = Analyser::new();
16578:         let r = a.analyse(
16579:             "namespace eval ::src { proc thing {} {} namespace export thing }\n\
16580:              proc ::dst::setup {} { namespace import ::src::thing }\n",
16581:             "tcl8.6",
16582:         );
16583:         let targets: Vec<&str> = r.namespace_imports.iter().map(|i| i.ns.as_str()).collect();
16584:         assert!(
16585:             targets.contains(&"::dst"),
16586:             "the import lands in the proc's defining namespace: {targets:?}",
16587:         );
16588:     }
16589: 
16590:     /// A `-map` target inside the same qualified-name proc resolves the same
16591:     /// way — the `-map` half.
16592:     #[test]
16593:     fn namespace_ensemble_map_in_a_qualified_name_proc_resolves_targets_923_idx85() {
16594:         let mut a = Analyser::new();
16595:         let src = "namespace eval ::tk {}\n\
16596:                    proc ::tk::getImpl {} {}\n\
16597:                    proc ::tk::SetupEnsemble {} {\n    \
16598:                    namespace ensemble create -map {get getImpl}\n\
16599:                    }\n";
16600:         let r = a.analyse(src, "tcl8.6");
16601:         let resolved: Vec<&str> = r
16602:             .command_invocations
16603:             .iter()
16604:             .filter_map(|i| i.resolved_qualified_name.as_deref())
16605:             .collect();
16606:         assert!(
16607:             resolved.contains(&"::tk::getImpl"),
16608:             "the -map target resolves in the proc's defining namespace: {resolved:?}",
16609:         );
16610:     }
16611: 
16612:     // The tk-shaped ensemble's *call-site* half.  Everything above pins the
16613:     // ensemble's own declaration (where the `-map`/`-subcommands` targets
16614:     // home to); these pin the downstream `<ensemble> <sub>` dispatch sites,
16615:     // which is what find-references / rename / code-lens / call-hierarchy
16616:     // enumerate.  Oracle — tclsh 8.6.16 and 9.0.4 both print
16617:     // `shown` then `configured:-x 1` for `VIAPROC_SRC`, so
16618:     // `::app::widget show` really does dispatch to `::app::widget::Show`.
16619: 
16620:     /// The shape: `namespace ensemble create -map` inside a
16621:     /// proc declared with a fully-qualified name at top level, with no
16622:     /// enclosing `namespace eval`, and the dispatch call sites written after
16623:     /// it — one nested in a `[…]` substitution, one at the top level.
16624:     const VIAPROC_SRC: &str = "namespace eval ::app::widget {\n    \
16625:          variable state 0\n\
16626:          }\n\
16627:          proc ::app::widget::Setup {} {\n    \
16628:          namespace ensemble create -map {\n        \
16629:          show      ::app::widget::Show\n        \
16630:          configure ::app::widget::Configure\n    \
16631:          }\n\
16632:          }\n\
16633:          proc ::app::widget::Show {} { puts \"shown\" }\n\
16634:          proc ::app::widget::Configure {args} { puts \"configured:$args\" }\n\
16635:          ::app::widget::Setup\n\
16636:          puts [::app::widget show]\n\
16637:          ::app::widget configure -x 1\n";
16638: 
16639:     /// Every `(written name, resolved name)` pair recorded as an
16640:     /// existence-probed reference — the shape
16641:     /// `record_ensemble_subcommand_invocation` gives a subcommand word.
16642:     fn probe_refs(r: &super::super::types::AnalysisResult) -> Vec<(String, String)> {
16643:         r.command_invocations
16644:             .iter()
16645:             .filter(|i| i.existence_probe)
16646:             .map(|i| {
16647:                 (
16648:                     i.name.clone(),
16649:                     i.resolved_qualified_name.clone().unwrap_or_default(),
16650:                 )
16651:             })
16652:             .collect()
16653:     }
16654: 
16655:     #[test]
16656:     fn ensemble_call_sites_resolve_when_the_ensemble_is_created_in_a_qualified_proc_923_idx85() {
16657:         let r = Analyser::new().analyse(VIAPROC_SRC, "tcl8.6").clone();
16658:         let probes = probe_refs(&r);
16659:         assert!(
16660:             probes.contains(&("show".to_owned(), "::app::widget::Show".to_owned())),
16661:             "the `[::app::widget show]` dispatch must be a reference to Show: {probes:?}",
16662:         );
16663:         assert!(
16664:             probes.contains(&(
16665:                 "configure".to_owned(),
16666:                 "::app::widget::Configure".to_owned()
16667:             )),
16668:             "the top-level `::app::widget configure` dispatch must be a reference \
16669:              to Configure: {probes:?}",
16670:         );
16671:     }
16672: 
16673:     #[test]
16674:     fn per_item_records_the_same_ensemble_call_sites_as_the_whole_file_walk_923_idx85() {
16675:         // The per-item shell pass defers `::app::widget::Setup`'s body, so the
16676:         // ensemble map is empty when the two call sites below it are
16677:         // walked: without the deferred replay neither subcommand reference
16678:         // is recorded — go-to-definition (an on-demand lookup against the
16679:         // finished analysis) still answers, find-references cannot.  Comparing
16680:         // the two walk strategies directly is the assertion that cannot drift.
16681:         let whole = Analyser::new().analyse(VIAPROC_SRC, "tcl8.6").clone();
16682:         let per_item = Analyser::new().analyse_per_item(VIAPROC_SRC, "tcl8.6");
16683:         assert_eq!(
16684:             probe_refs(&per_item),
16685:             probe_refs(&whole),
16686:             "per-item must record the same ensemble dispatch references as the \
16687:              whole-file walk",
16688:         );
16689:         assert!(
16690:             probe_refs(&per_item)
16691:                 .iter()
16692:                 .any(|(_, res)| res == "::app::widget::Show"),
16693:             "and both must actually find Show's call site: {:?}",
16694:             probe_refs(&per_item),
16695:         );
16696:     }
16697: 
16698:     #[test]
16699:     fn a_dynamic_ensemble_map_records_no_call_site_reference_923_idx85() {
16700:         // TN — deliberate abstention.  `-map [list …]` is not a literal
16701:         // list, so no `subcommand -> target` fact exists at all; the
16702:         // dispatch site must stay unattributed rather than being guessed
16703:         // at from the surrounding text.  Both walk strategies abstain.
16704:         let src = "proc ::app::widget::Setup {} {\n    \
16705:                    namespace ensemble create -map [list show ::app::widget::Show]\n\
16706:                    }\n\
16707:                    proc ::app::widget::Show {} {}\n\
16708:                    ::app::widget::Setup\n\
16709:                    ::app::widget show\n";
16710:         for r in [
16711:             Analyser::new().analyse(src, "tcl8.6").clone(),
16712:             Analyser::new().analyse_per_item(src, "tcl8.6"),
16713:         ] {
16714:             assert!(
16715:                 !probe_refs(&r)
16716:                     .iter()
16717:                     .any(|(_, res)| res == "::app::widget::Show"),
16718:                 "a dynamic -map must not attribute the dispatch site: {:?}",
16719:                 probe_refs(&r),
16720:             );
16721:         }
16722:     }
16723: 
16724:     #[test]
16725:     fn an_ensemble_call_site_above_its_declaration_is_not_attributed_923_idx85() {
16726:         // TN — the whole-file DFS walks a proc body at its *definition*
16727:         // point, so a dispatch written above the proc that creates the
16728:         // ensemble sees no map.  The deferred replay reproduces that
16729:         // visibility rule rather than widening it, which is what keeps the
16730:         // two walk strategies byte-identical.
16731:         let src = "proc ::app::widget::Show {} {}\n\
16732:                    ::app::widget show\n\
16733:                    proc ::app::widget::Setup {} {\n    \
16734:                    namespace ensemble create -map {show ::app::widget::Show}\n\
16735:                    }\n";
16736:         for r in [
16737:             Analyser::new().analyse(src, "tcl8.6").clone(),
16738:             Analyser::new().analyse_per_item(src, "tcl8.6"),
16739:         ] {
16740:             assert!(
16741:                 !probe_refs(&r)
16742:                     .iter()
16743:                     .any(|(_, res)| res == "::app::widget::Show"),
16744:                 "a dispatch above the declaration must not be attributed: {:?}",
16745:                 probe_refs(&r),
16746:             );
16747:         }
16748:     }
16749: 
16750:     // `namespace ensemble configure`: the real
16751:     // `tk/library/systray.tcl` idiom splices new subcommands onto a
16752:     // *pre-existing* ensemble via `configure`, not `create`, so
16753:     // `handle_namespace_ensemble` has to recognise both.
16754: 
16755:     #[test]
16756:     fn namespace_ensemble_configure_extends_a_preexisting_ensembles_map() {
16757:         // TP — the mechanism in isolation, with a literal `-map` value and a
16758:         // deliberately non-tk ensemble name (`myens`), proving the mechanism is
16759:         // registry-agnostic rather than hardcoded to `tk`.
16760:         let mut a = Analyser::new();
16761:         let src = "namespace eval ::myens {\n    \
16762:                    namespace ensemble create -subcommands {}\n\
16763:                    }\n\
16764:                    proc ::myens::extra {args} {}\n\
16765:                    namespace ensemble configure ::myens -map {extra ::myens::extra}\n\
16766:                    myens extra\n";
16767:         let r = a.analyse(src, "tcl8.6");
16768:         let resolved: Vec<&str> = r
16769:             .command_invocations
16770:             .iter()
16771:             .filter_map(|i| i.resolved_qualified_name.as_deref())
16772:             .collect();
16773:         assert!(
16774:             resolved.contains(&"::myens::extra"),
16775:             "a configure-spliced -map target should be a command reference: {resolved:?}",
16776:         );
16777:     }
16778: 
16779:     #[test]
16780:     fn namespace_ensemble_configure_dynamic_name_is_not_recorded() {
16781:         // FP-guard — `namespace ensemble configure $x -map {...}` can't be
16782:         // resolved statically; the whole call must abstain rather than
16783:         // recording a `-map` splice under a guessed/wrong key.
16784:         let mut a = Analyser::new();
16785:         a.handle_namespace_ensemble(
16786:             &[
16787:                 "ensemble".to_string(),
16788:                 "configure".to_string(),
16789:                 "$x".to_string(),
16790:                 "-map".to_string(),
16791:                 "sub".to_string(),
16792:                 "::real::target".to_string(),
16793:             ],
16794:             &[],
16795:             &[],
16796:         );
16797:         assert_eq!(a.result.ensemble_subcommand_targets.len(), 0);
16798:     }
16799: 
16800:     #[test]
16801:     fn namespace_ensemble_configure_with_no_name_argument_is_a_no_op() {
16802:         // TN — the bare query form `namespace ensemble configure` (no NAME,
16803:         // no options) must not panic on `args[2]` indexing.
16804:         let mut a = Analyser::new();
16805:         a.handle_namespace_ensemble(&["ensemble".to_string(), "configure".to_string()], &[], &[]);
16806:         assert_eq!(a.result.ensemble_subcommand_targets.len(), 0);
16807:     }
16808: 
16809:     #[test]
16810:     fn namespace_ensemble_configure_dict_merge_literal_tail_is_extracted() {
16811:         // TP — the real, exact idiom:
16812:         // `namespace ensemble configure NAME -map [dict merge [namespace
16813:         // ensemble configure NAME -map] {literal}]`. The self-referential
16814:         // query argument is left unknown, but the literal tail's own pairs
16815:         // are statically known regardless of what it evaluates to.
16816:         let mut a = Analyser::new();
16817:         let src = "namespace eval ::myens {\n    \
16818:                    namespace ensemble create -subcommands {}\n\
16819:                    }\n\
16820:                    proc ::myens::extra {args} {}\n\
16821:                    proc ::myens::other {args} {}\n\
16822:                    namespace ensemble configure ::myens -map \
16823:                    [dict merge [namespace ensemble configure ::myens -map] \
16824:                    {extra ::myens::extra other ::myens::other}]\n\
16825:                    myens extra\n\
16826:                    myens other\n";
16827:         let r = a.analyse(src, "tcl8.6");
16828:         let resolved: Vec<&str> = r
16829:             .command_invocations
16830:             .iter()
16831:             .filter_map(|i| i.resolved_qualified_name.as_deref())
16832:             .collect();
16833:         assert!(
16834:             resolved.contains(&"::myens::extra"),
16835:             "the dict-merge literal tail's first pair should resolve: {resolved:?}",
16836:         );
16837:         assert!(
16838:             resolved.contains(&"::myens::other"),
16839:             "the dict-merge literal tail's second pair should resolve too, \
16840:              proving the extraction isn't overfit to a single pair: {resolved:?}",
16841:         );
16842:     }
16843: 
16844:     #[test]
16845:     fn namespace_ensemble_configure_unrecognised_dynamic_map_shape_abstains_safely() {
16846:         // Safety guard: a `-map` value that is itself one whole
16847:         // dynamic `[...]` substitution NOT matching the narrow `dict merge
16848:         // ARG {literal}` shape must abstain entirely — not naively
16849:         // word-split the expression's own source text into bogus
16850:         // subcommand/target pairs. `[linsert {} 0 foo bar]` evaluates to
16851:         // the *string* "foo bar" at runtime (one call to `linsert`; "foo"/
16852:         // "bar" are plain data words, never independently invoked) — were
16853:         // the value's raw text naively whitespace-split instead of
16854:         // abstained on, "foo" would land at an odd (target) index and
16855:         // wrongly resolve to the real `::myens::foo` defined below,
16856:         // recording a spurious command reference to it.
16857:         let mut a = Analyser::new();
16858:         let src = "namespace eval ::myens {\n    \
16859:                    namespace ensemble create -subcommands {}\n\
16860:                    }\n\
16861:                    proc ::myens::foo {} {}\n\
16862:                    namespace ensemble configure ::myens -map [linsert {} 0 foo bar]\n";
16863:         let r = a.analyse(src, "tcl8.6");
16864:         assert!(
16865:             r.ensemble_subcommand_targets
16866:                 .get("::myens")
16867:                 .is_none_or(std::collections::HashMap::is_empty),
16868:             "an unrecognised dynamic -map shape must record no subcommand \
16869:              targets: {:?}",
16870:             r.ensemble_subcommand_targets.get("::myens"),
16871:         );
16872:         let resolved: Vec<&str> = r
16873:             .command_invocations
16874:             .iter()
16875:             .filter_map(|i| i.resolved_qualified_name.as_deref())
16876:             .collect();
16877:         assert!(
16878:             !resolved.contains(&"::myens::foo"),
16879:             "must not record a spurious command reference from splitting \
16880:              the dynamic expression's own text: {resolved:?}",
16881:         );
16882:     }
16883: 
16884:     #[test]
16885:     fn ensemble_subcommand_targets_record_which_option_declared_them() {
16886:         // The two options bind the subcommand word to its
16887:         // target in opposite ways, so the recorded fact has to say which one
16888:         // wrote it. Oracle (tclsh 8.6.14 / 9.0.4, identical): with `-map
16889:         // {show ::app::widget::Show}` the call `::app::widget Show` is
16890:         // `unknown or ambiguous subcommand "Show": must be show` — the key is
16891:         // arbitrary; with `-subcommands {alpha}` the ensemble derives
16892:         // `::app::widget::alpha` from the entry, and a `-subcommands {alpha}`
16893:         // whose proc is named `beta` is `invalid command name "alpha"`.
16894:         use crate::signature_scan::types::EnsembleSubcommandProvenance;
16895: 
16896:         let mut a = Analyser::new();
16897:         let map_src = "namespace eval ::app::widget {}\n\
16898:                        proc ::app::widget::Show {} {}\n\
16899:                        namespace ensemble create -command ::app::widget \
16900:                        -map {show ::app::widget::Show}\n";
16901:         let r = a.analyse(map_src, "tcl8.6");
16902:         let entry = r
16903:             .ensemble_subcommand_targets
16904:             .get("::app::widget")
16905:             .and_then(|subs| subs.get("show"))
16906:             .expect("the literal -map pair is recorded");
16907:         assert_eq!(entry.target, "::app::widget::Show");
16908:         assert_eq!(
16909:             entry.provenance,
16910:             EnsembleSubcommandProvenance::Map,
16911:             "a -map pair must be tagged as such",
16912:         );
16913: 
16914:         let mut a = Analyser::new();
16915:         let sub_src = "namespace eval ::app::widget {\n    \
16916:                        proc alpha {} {}\n    \
16917:                        namespace ensemble create -command ::app::widget \
16918:                        -subcommands {alpha}\n\
16919:                        }\n";
16920:         let r = a.analyse(sub_src, "tcl8.6");
16921:         let entry = r
16922:             .ensemble_subcommand_targets
16923:             .get("::app::widget")
16924:             .and_then(|subs| subs.get("alpha"))
16925:             .expect("the literal -subcommands entry is recorded");
16926:         assert_eq!(entry.target, "::app::widget::alpha");
16927:         assert_eq!(
16928:             entry.provenance,
16929:             EnsembleSubcommandProvenance::Subcommands,
16930:             "a -subcommands entry must be tagged as such",
16931:         );
16932:     }
16933: 
16934:     #[test]
16935:     fn ensemble_dispatch_call_sites_carry_their_mapping_provenance() {
16936:         // The dispatch word's own invocation record carries the provenance,
16937:         // because only the recording site knows *this span* is
16938:         // a subcommand word: a `-map {Show ::app::widget::Show}` whose key
16939:         // happens to equal the target's tail is textually indistinguishable
16940:         // from an ordinary bare call to the target, so a consumer that
16941:         // re-derived the fact by name would gate the wrong spans.
16942:         use crate::signature_scan::types::EnsembleSubcommandProvenance;
16943: 
16944:         let mut a = Analyser::new();
16945:         let map_src = "namespace eval ::app::widget {}\n\
16946:                        proc ::app::widget::Show {} {}\n\
16947:                        namespace ensemble create -command ::app::widget \
16948:                        -map {show ::app::widget::Show}\n\
16949:                        ::app::widget show\n";
16950:         let r = a.analyse(map_src, "tcl8.6");
16951:         let tagged: Vec<(&str, Option<EnsembleSubcommandProvenance>)> = r
16952:             .command_invocations
16953:             .iter()
16954:             .filter(|i| i.resolved_qualified_name.as_deref() == Some("::app::widget::Show"))
16955:             .map(|i| (i.name.as_str(), i.ensemble_dispatch))
16956:             .collect();
16957:         assert!(
16958:             tagged.contains(&("show", Some(EnsembleSubcommandProvenance::Map))),
16959:             "the dispatch word is tagged with the -map provenance: {tagged:?}",
16960:         );
16961:         assert!(
16962:             tagged
16963:                 .iter()
16964:                 .any(|(name, prov)| *name == "::app::widget::Show" && prov.is_none()),
16965:             "the -map *value* is an ordinary reference, not a dispatch word — \
16966:              it carries the target's own name and rename must rewrite it: {tagged:?}",
16967:         );
16968: 
16969:         let mut a = Analyser::new();
16970:         let sub_src = "namespace eval ::app::widget {\n    \
16971:                        proc alpha {} {}\n    \
16972:                        namespace ensemble create -command ::app::widget \
16973:                        -subcommands {alpha}\n\
16974:                        }\n\
16975:                        ::app::widget alpha\n";
16976:         let r = a.analyse(sub_src, "tcl8.6");
16977:         let tagged: Vec<(&str, Option<EnsembleSubcommandProvenance>)> = r
16978:             .command_invocations
16979:             .iter()
16980:             .filter(|i| i.resolved_qualified_name.as_deref() == Some("::app::widget::alpha"))
16981:             .map(|i| (i.name.as_str(), i.ensemble_dispatch))
16982:             .collect();
16983:         assert!(
16984:             tagged.contains(&("alpha", Some(EnsembleSubcommandProvenance::Subcommands))),
16985:             "the dispatch word is tagged with the -subcommands provenance: {tagged:?}",
16986:         );
16987:     }
16988: 
16989:     #[test]
16990:     fn handle_namespace_ensemble_other_options_value_word_is_not_mistaken_for_command_flag() {
16991:         // `-map`'s value here is (pathologically, but syntactically legally)
16992:         // the string `-command`. A scan checking *every* word for literal
16993:         // equality with `-command`, another option's own value word
16994:         // included, misreads that value as the
16995:         // `-command` flag itself and steals the *next* word (the real
16996:         // `-command`'s own flag) as if it were a namespace name. Walking
16997:         // by each option's declared value arity instead correctly skips
16998:         // `-map`'s whole value before ever looking for `-command` again,
16999:         // so only the genuine `-command ::real::target` is recorded.
17000:         use crate::analyser::types::{Scope, ScopeKind};
17001:         let mut a = Analyser::new();
17002:         a.registry = Some(std::sync::Arc::clone(
17003:             tcl_registry::model::ingress::static_context_for("tcl").commands(),
17004:         ));
17005:         a.result
17006:             .global_scope
17007:             .children
17008:             .push(Scope::new(ScopeKind::Namespace, "myns"));
17009:         a.handle_namespace_ensemble(
17010:             &[
17011:                 "ensemble".to_string(),
17012:                 "create".to_string(),
17013:                 "-map".to_string(),
17014:                 "-command".to_string(),
17015:                 "-command".to_string(),
17016:                 "::real::target".to_string(),
17017:             ],
17018:             &[],
17019:             &[0],
17020:         );
17021:         assert_eq!(
17022:             a.ensemble_namespaces,
17023:             std::collections::HashSet::from(["::myns".to_string(), "::real::target".to_string()]),
17024:             "only the genuine -command flag's value must be recorded, \
17025:              not -map's value word that happens to read \"-command\""
17026:         );
17027:     }
17028: 
17029:     #[test]
17030:     fn handle_namespace_ensemble_global_scope_no_op() {
17031:         let mut a = Analyser::new();
17032:         a.handle_namespace_ensemble(&["ensemble".to_string(), "create".to_string()], &[], &[]);
17033:         assert_eq!(a.ensemble_namespaces.len(), 0);
17034:     }
17035: 
17036:     #[test]
17037:     fn handle_namespace_ensemble_wrong_subcommand_no_op() {
17038:         use crate::analyser::types::{Scope, ScopeKind};
17039:         let mut a = Analyser::new();
17040:         a.result
17041:             .global_scope
17042:             .children
17043:             .push(Scope::new(ScopeKind::Namespace, "myns"));
17044:         a.handle_namespace_ensemble(&["eval".to_string(), "myns".to_string()], &[], &[0]);
17045:         assert_eq!(a.ensemble_namespaces.len(), 0);
17046:     }
17047: 
17048:     // handle_foreach_command
17049: 
17050:     #[test]
17051:     fn handle_foreach_defines_single_loop_var() {
17052:         let result = Analyser::new().analyse("foreach i {1 2 3} {puts $i}", "tcl");
17053:         assert!(result.global_scope.variables.contains_key("i"));
17054:     }
17055: 
17056:     #[test]
17057:     fn handle_foreach_defines_multiple_loop_vars() {
17058:         let source = "foreach {k v} {a 1 b 2} {}";
17059:         let result = Analyser::new().analyse(source, "tcl");
17060:         let k = &result.global_scope.variables["k"];
17061:         let v = &result.global_scope.variables["v"];
17062:         assert_eq!(k.definition_span, span(9, 10));
17063:         assert_eq!(v.definition_span, span(11, 12));
17064:         assert!(k.definition_span.start() < v.definition_span.start());
17065:     }
17066: 
17067:     #[test]
17068:     fn handle_foreach_varlist_uses_tcl_list_names_and_source_ranges() {
17069:         let source = r#"foreach {{one name} "two name" three\ name plain} {values} {}"#;
17070:         let result = Analyser::new().analyse(source, "tcl");
17071:         let variables = &result.global_scope.variables;
17072:         for (name, spelling) in [
17073:             ("one name", "one name"),
17074:             ("two name", "two name"),
17075:             ("three name", r"three\ name"),
17076:             ("plain", "plain"),
17077:         ] {
17078:             let start = u32::try_from(source.find(spelling).expect("original element")).unwrap();
17079:             let end = start + u32::try_from(spelling.len()).unwrap();
17080:             assert_eq!(variables[name].definition_span, span(start, end));
17081:         }
17082:     }
17083: 
17084:     #[test]
17085:     fn malformed_foreach_varlist_defines_no_variables() {
17086:         let result = Analyser::new().analyse(r#"foreach "{unterminated" values {}"#, "tcl");
17087:         assert!(result.global_scope.variables.is_empty());
17088:     }
17089: 
17090:     #[test]
17091:     fn literal_foreach_binding_parses_single_variable_as_tcl_list() {
17092:         assert_eq!(
17093:             Analyser::literal_foreach_binding(
17094:                 r"{one name}",
17095:                 "alpha beta",
17096:                 true,
17097:                 tcl_syntax::word_rules::WordValueRules::TCL
17098:             ),
17099:             Some((
17100:                 "one name".to_string(),
17101:                 vec!["alpha".to_string(), "beta".to_string()]
17102:             ))
17103:         );
17104:         assert!(
17105:             Analyser::literal_foreach_binding(
17106:                 "{unterminated",
17107:                 "alpha",
17108:                 true,
17109:                 tcl_syntax::word_rules::WordValueRules::TCL
17110:             )
17111:             .is_none()
17112:         );
17113:         assert!(
17114:             Analyser::literal_foreach_binding(
17115:                 "one two",
17116:                 "alpha",
17117:                 true,
17118:                 tcl_syntax::word_rules::WordValueRules::TCL
17119:             )
17120:             .is_none()
17121:         );
17122:     }
17123: 
17124:     #[test]
17125:     fn handle_foreach_defines_every_varlist_in_the_multi_list_lock_step_form() {
17126:         let result = Analyser::new().analyse(
17127:             "foreach dirName {src src {src core}} name {alpha beta gamma} {puts $dirName-$name}",
17128:             "tcl",
17129:         );
17130:         assert!(result.global_scope.variables.contains_key("dirName"));
17131:         assert!(result.global_scope.variables.contains_key("name"));
17132:     }
17133: 
17134:     #[test]
17135:     fn handle_foreach_multi_list_form_binds_a_third_pair_too() {
17136:         let result =
17137:             Analyser::new().analyse("foreach a {1 2} b {3 4} c {5 6} {puts $a$b$c}", "tcl");
17138:         for name in ["a", "b", "c"] {
17139:             assert!(result.global_scope.variables.contains_key(name));
17140:         }
17141:     }
17142: 
17143:     #[test]
17144:     fn handle_foreach_too_few_args_returns_false() {
17145:         let mut a = Analyser::new();
17146:         let handled = a.handle_foreach_command(
17147:             "foreach",
17148:             &["i".to_string(), "{1 2}".to_string()],
17149:             &[esc_tok(span(0, 1)), str_tok(span(2, 7))],
17150:             &[],
17151:         );
17152:         assert!(!handled);
17153:     }
17154: 
17155:     // Dynamic proc names + the foreach rename-and-reinstall idiom:
17156:     // `tk/library/accessibility.tcl`'s `foreach wtype {...} {
17157:     // rename ::$wtype ::tk::accessible::orig_$wtype ; proc ::$wtype {args}
17158:     // {...} }` renames each classic widget command away and reinstalls a
17159:     // wrapper under the same original name.
17160: 
17161:     #[test]
17162:     fn handle_proc_command_dynamic_name_resolves_via_constant_fold() {
17163:         // TP — no loop at all: a plain `set` constant. `proc ::$wtype {...}` must
17164:         // constant-fold its name, as `rename` does, rather than register under
17165:         // the literal garbled text.
17166:         let mut a = Analyser::new();
17167:         let src = "set wtype button\nproc ::$wtype {} {return ok}\n";
17168:         let r = a.analyse(src, "tcl8.6");
17169:         assert!(
17170:             r.all_procs.contains_key("::button"),
17171:             "{:?}",
17172:             r.all_procs.keys().collect::<Vec<_>>()
17173:         );
17174:         assert!(
17175:             !r.all_procs.keys().any(|k| k.contains('$')),
17176:             "{:?}",
17177:             r.all_procs.keys().collect::<Vec<_>>()
17178:         );
17179:     }
17180: 
17181:     #[test]
17182:     fn handle_proc_command_unresolvable_dynamic_name_keeps_raw_text() {
17183:         // TN — a genuinely dynamic name (no constant to fold against) keeps the
17184:         // raw-text fallback behaviour; only the resolvable case folds.
17185:         let mut a = Analyser::new();
17186:         let src = "proc ::$wtype {} {return ok}\n";
17187:         let r = a.analyse(src, "tcl8.6");
17188:         assert!(
17189:             r.all_procs.keys().any(|k| k.contains("wtype")),
17190:             "{:?}",
17191:             r.all_procs.keys().collect::<Vec<_>>()
17192:         );
17193:     }
17194: 
17195:     #[test]
17196:     fn handle_foreach_rename_reinstall_idiom_resolves_every_literal_element() {
17197:         // TP — `tk/library/accessibility.tcl` renames each classic widget
17198:         // command away and
17199:         // reinstalls a wrapper proc under the same name, once per element
17200:         // of a literal `foreach` list. tclsh9.0/8.6 both prove `button`/
17201:         // `entry` are the *new* wrapper procs afterwards; the original bodies
17202:         // live only at `::tk::accessible::orig_button`/`orig_entry`.
17203:         let mut a = Analyser::new();
17204:         let src = "proc button {args} {return orig_button}\n\
17205:                    proc entry {args} {return orig_entry}\n\
17206:                    namespace eval ::tk::accessible {\n    \
17207:                    foreach wtype {button entry} {\n        \
17208:                    rename ::$wtype ::tk::accessible::orig_$wtype\n        \
17209:                    proc ::$wtype {args} {return wrapped}\n    \
17210:                    }\n\
17211:                    }\n";
17212:         let r = a.analyse(src, "tcl8.6");
17213:         // Both wrapper redefinitions are registered, at the *same* physical
17214:         // source location (the one templated `proc ::$wtype ...`
17215:         // statement) — genuinely correct: there is only one place in the
17216:         // source that defines either of them.
17217:         let button_def = r.all_procs.get("::button").expect("::button registered");
17218:         let entry_def = r.all_procs.get("::entry").expect("::entry registered");
17219:         assert_eq!(button_def.body_span, entry_def.body_span);
17220:         // No garbled `${wtype}`-named entry left behind.
17221:         assert!(
17222:             !r.all_procs.keys().any(|k| k.contains('$')),
17223:             "{:?}",
17224:             r.all_procs.keys().collect::<Vec<_>>()
17225:         );
17226:         // The old, pre-rename bodies are reachable only via their new
17227:         // `orig_*` names.
17228:         assert_eq!(
17229:             r.renamed_commands.get("::tk::accessible::orig_button"),
17230:             Some(&"::button".to_string())
17231:         );
17232:         assert_eq!(
17233:             r.renamed_commands.get("::tk::accessible::orig_entry"),
17234:             Some(&"::entry".to_string())
17235:         );
17236:     }
17237: 
17238:     #[test]
17239:     fn handle_foreach_rename_reinstall_idiom_is_not_overfit_to_two_elements() {
17240:         // FP guard — a third element proves the per-iteration simulation
17241:         // isn't hardcoded to exactly the corpus's own two widget names.
17242:         let mut a = Analyser::new();
17243:         let src = "namespace eval ::ns {\n    \
17244:                    foreach wtype {button entry checkbutton} {\n        \
17245:                    rename ::$wtype ::ns::orig_$wtype\n        \
17246:                    proc ::$wtype {args} {return wrapped}\n    \
17247:                    }\n\
17248:                    }\n";
17249:         let r = a.analyse(src, "tcl8.6");
17250:         for name in ["::button", "::entry", "::checkbutton"] {
17251:             assert!(
17252:                 r.all_procs.contains_key(name),
17253:                 "{name} missing: {:?}",
17254:                 r.all_procs.keys().collect::<Vec<_>>()
17255:             );
17256:         }
17257:     }
17258: 
17259:     #[test]
17260:     fn handle_foreach_multi_pair_form_does_not_trigger_the_literal_simulation() {
17261:         // TN — the multi-list lock-step form (`foreach v1 l1 v2 l2
17262:         // body`) is a different arg shape; the single-pair-only literal
17263:         // simulation must not misfire on it.
17264:         let mut a = Analyser::new();
17265:         let src = "foreach a {1 2} b {3 4} {\n    rename ::$a ::orig_$a\n}\n";
17266:         let r = a.analyse(src, "tcl8.6");
17267:         assert_eq!(r.renamed_commands.len(), 0, "{:?}", r.renamed_commands);
17268:     }
17269: 
17270:     #[test]
17271:     fn handle_foreach_dynamic_list_does_not_trigger_the_literal_simulation() {
17272:         // TN — a non-literal list (a variable, not a literal element list)
17273:         // can't be simulated; must abstain.
17274:         let mut a = Analyser::new();
17275:         let src = "set items {button entry}\nforeach wtype $items {\n    rename ::$wtype ::orig_$wtype\n}\n";
17276:         let r = a.analyse(src, "tcl8.6");
17277:         assert_eq!(r.renamed_commands.len(), 0, "{:?}", r.renamed_commands);
17278:     }
17279: 
17280:     #[test]
17281:     fn handle_foreach_non_idiom_body_is_unaffected() {
17282:         // TN — an ordinary literal-list foreach with no rename/proc inside
17283:         // must see no new side effects from the idiom-recognition code.
17284:         let mut a = Analyser::new();
17285:         let src = "foreach x {a b c} {\n    puts $x\n}\n";
17286:         let r = a.analyse(src, "tcl8.6");
17287:         assert_eq!(r.renamed_commands.len(), 0);
17288:         assert!(!r.all_procs.keys().any(|k| k.contains('$')));
17289:     }
17290: 
17291:     // handle_switch_command
17292: 
17293:     fn switch_analyser() -> Analyser {
17294:         let mut analyser = Analyser::new();
17295:         analyser.registry = Some(std::sync::Arc::clone(
17296:             tcl_registry::model::ingress::static_context_for("tcl").commands(),
17297:         ));
17298:         analyser
17299:     }
17300: 
17301:     #[test]
17302:     fn handle_switch_returns_true_for_canonical_shape() {
17303:         let mut a = switch_analyser();
17304:         let handled = a.handle_switch_command(
17305:             "switch",
17306:             &["$x".to_string(), "{a {puts a} b {puts b}}".to_string()],
17307:             &[esc_tok(span(7, 9)), str_tok(span(10, 36))],
17308:             &[],
17309:         );
17310:         assert!(handled);
17311:     }
17312: 
17313:     #[test]
17314:     fn handle_switch_too_few_args_returns_false() {
17315:         let mut a = switch_analyser();
17316:         let handled = a.handle_switch_command("switch", &["$x".to_string()], &[], &[]);
17317:         assert!(!handled);
17318:     }
17319: 
17320:     #[test]
17321:     fn handle_switch_form1_walks_each_arm_body() {
17322:         // Form 1: ``switch $x a {set y 1} b {set z 2}``.
17323:         // Each arm body should land its ``set`` in the
17324:         // surrounding scope.  Source layout has the bodies at
17325:         // offsets 13..23 (``{set y 1}``) and 27..37 (``{set z 2}``).
17326:         let mut a = switch_analyser();
17327:         a.handle_switch_command(
17328:             "switch",
17329:             &[
17330:                 "$x".to_string(),
17331:                 "a".to_string(),
17332:                 "set y 1".to_string(),
17333:                 "b".to_string(),
17334:                 "set z 2".to_string(),
17335:             ],
17336:             &[
17337:                 esc_tok(span(7, 9)),
17338:                 esc_tok(span(10, 11)),
17339:                 str_tok(span(13, 22)),
17340:                 esc_tok(span(24, 25)),
17341:                 str_tok(span(27, 36)),
17342:             ],
17343:             &[],
17344:         );
17345:         assert!(a.result.global_scope.variables.contains_key("y"));
17346:         assert!(a.result.global_scope.variables.contains_key("z"));
17347:     }
17348: 
17349:     #[test]
17350:     fn handle_switch_form2_braced_body_walks_each_arm() {
17351:         // Form 2: ``switch $x { a {set y 1} b {set z 2} }``.
17352:         // The single braced body holds all pattern/body pairs;
17353:         // ``flatten_clause_list_elements`` uses Tcl list offsets to surface
17354:         // each pair, then each body recurses.
17355:         let mut a = switch_analyser();
17356:         let body_text = " a {set y 1} b {set z 2} ".to_string();
17357:         // body span: outer source positions 10..(10 + len(body)+2).
17358:         // body_text has 25 chars, plus surrounding braces → token
17359:         // span 10..37, content_offset = 1 to skip the opening ``{``.
17360:         a.handle_switch_command(
17361:             "switch",
17362:             &["$x".to_string(), body_text],
17363:             &[esc_tok(span(7, 9)), str_tok(span(10, 37))],
17364:             &[],
17365:         );
17366:         assert!(a.result.global_scope.variables.contains_key("y"));
17367:         assert!(a.result.global_scope.variables.contains_key("z"));
17368:     }
17369: 
17370:     #[test]
17371:     fn handle_switch_form1_skips_fallthrough_marker() {
17372:         // ``switch $x a - b {set y 1}`` — the ``-`` body for
17373:         // pattern ``a`` is fall-through (next arm fires); only
17374:         // ``b``'s body should be walked.
17375:         let mut a = switch_analyser();
17376:         a.handle_switch_command(
17377:             "switch",
17378:             &[
17379:                 "$x".to_string(),
17380:                 "a".to_string(),
17381:                 "-".to_string(),
17382:                 "b".to_string(),
17383:                 "set y 1".to_string(),
17384:             ],
17385:             &[
17386:                 esc_tok(span(7, 9)),
17387:                 esc_tok(span(10, 11)),
17388:                 esc_tok(span(12, 13)),
17389:                 esc_tok(span(14, 15)),
17390:                 str_tok(span(17, 26)),
17391:             ],
17392:             &[],
17393:         );
17394:         assert!(a.result.global_scope.variables.contains_key("y"));
17395:     }
17396: 
17397:     #[test]
17398:     fn handle_switch_recognises_dashdash_options_terminator() {
17399:         // ``switch -- $x a {set y 1}`` — ``--`` ends the option
17400:         // section; the string arg follows.  Walker still finds
17401:         // the arm body and lands ``y``.
17402:         let mut a = switch_analyser();
17403:         a.handle_switch_command(
17404:             "switch",
17405:             &[
17406:                 "--".to_string(),
17407:                 "$x".to_string(),
17408:                 "a".to_string(),
17409:                 "set y 1".to_string(),
17410:             ],
17411:             &[
17412:                 esc_tok(span(7, 9)),
17413:                 esc_tok(span(10, 12)),
17414:                 esc_tok(span(13, 14)),
17415:                 str_tok(span(16, 25)),
17416:             ],
17417:             &[],
17418:         );
17419:         assert!(a.result.global_scope.variables.contains_key("y"));
17420:     }
17421: 
17422:     #[test]
17423:     fn handle_switch_dynamic_form2_body_skips_walk() {
17424:         // Form 2 with a dynamic body (``$body`` instead of a
17425:         // braced literal) yields no elements; the walk no-ops.
17426:         let mut a = switch_analyser();
17427:         let var_tok = Token::new(TokenType::Var, span(10, 15));
17428:         a.handle_switch_command(
17429:             "switch",
17430:             &["$x".to_string(), "$body".to_string()],
17431:             &[esc_tok(span(7, 9)), var_tok],
17432:             &[],
17433:         );
17434:         // No body walked → no vars defined.
17435:         assert_eq!(a.result.global_scope.variables.len(), 0);
17436:     }
17437: 
17438:     // handle_catch_command
17439: 
17440:     #[test]
17441:     fn handle_catch_canonical_returns_true() {
17442:         let mut a = Analyser::new();
17443:         let handled = a.handle_catch_command(&["body".to_string()], &[esc_tok(span(0, 4))], &[]);
17444:         assert!(handled);
17445:     }
17446: 
17447:     #[test]
17448:     fn handle_catch_with_result_var_defines_it() {
17449:         let mut a = Analyser::new();
17450:         // The binding positions come from the registry's VarWrite roles.
17451:         a.registry = Some(std::sync::Arc::clone(
17452:             tcl_registry::model::ingress::static_context_for("tcl").commands(),
17453:         ));
17454:         a.handle_catch_command(
17455:             &["body".to_string(), "res".to_string()],
17456:             &[esc_tok(span(0, 4)), esc_tok(span(5, 8))],
17457:             &[],
17458:         );
17459:         assert!(a.result.global_scope.variables.contains_key("res"));
17460:     }
17461: 
17462:     #[test]
17463:     fn handle_catch_with_options_var_defines_both() {
17464:         let mut a = Analyser::new();
17465:         a.registry = Some(std::sync::Arc::clone(
17466:             tcl_registry::model::ingress::static_context_for("tcl").commands(),
17467:         ));
17468:         a.handle_catch_command(
17469:             &["body".to_string(), "res".to_string(), "opts".to_string()],
17470:             &[
17471:                 esc_tok(span(0, 4)),
17472:                 esc_tok(span(5, 8)),
17473:                 esc_tok(span(9, 13)),
17474:             ],
17475:             &[],
17476:         );
17477:         assert!(a.result.global_scope.variables.contains_key("res"));
17478:         assert!(a.result.global_scope.variables.contains_key("opts"));
17479:     }
17480: 
17481:     #[test]
17482:     fn handle_catch_no_args_returns_false() {
17483:         let mut a = Analyser::new();
17484:         let handled = a.handle_catch_command(&[], &[], &[]);
17485:         assert!(!handled);
17486:     }
17487: 
17488:     // try (no handler of its own: it goes through the generic dispatch `for`
17489:     // uses; `try`'s own clause-timing resolution is `clause_grammar.rs`'s
17490:     // `try_grammar_agrees_with_the_retired_walk` and its neighbours)
17491: 
17492:     #[test]
17493:     fn handle_try_walks_main_body() {
17494:         // ``try {set y 1}`` — main body walks and lands ``y``.
17495:         let mut a = Analyser::new();
17496:         let r = a.analyse("try {set y 1}\n", "tcl8.6");
17497:         assert!(r.global_scope.variables.contains_key("y"));
17498:     }
17499: 
17500:     #[test]
17501:     fn handle_try_walks_finally_body() {
17502:         // ``try {} finally {set z 1}`` — finally clause body walks.
17503:         let mut a = Analyser::new();
17504:         let r = a.analyse("try {} finally {set z 1}\n", "tcl8.6");
17505:         assert!(r.global_scope.variables.contains_key("z"));
17506:     }
17507: 
17508:     #[test]
17509:     fn handle_try_walks_on_handler_body() {
17510:         // ``try {} on error {result options} {set q 1}`` — the handler
17511:         // body walks and its var-list binds both names (so completion
17512:         // offers `$result` / `$options`).
17513:         let mut a = Analyser::new();
17514:         let r = a.analyse("try {} on error {result options} {set q 1}\n", "tcl8.6");
17515:         assert!(r.global_scope.variables.contains_key("q"));
17516:         assert!(r.global_scope.variables.contains_key("result"));
17517:         assert!(r.global_scope.variables.contains_key("options"));
17518:     }
17519: 
17520:     #[test]
17521:     fn handle_try_walks_trap_handler_body() {
17522:         // ``try {} trap NONE {result} {set q 1}`` — same shape as ``on``,
17523:         // but the keyword is ``trap`` and the var-list has one name.
17524:         let mut a = Analyser::new();
17525:         let r = a.analyse("try {} trap NONE {result} {set q 1}\n", "tcl8.6");
17526:         assert!(r.global_scope.variables.contains_key("q"));
17527:         assert!(r.global_scope.variables.contains_key("result"));
17528:     }
17529: 
17530:     // resolve_proc_call
17531: 
17532:     #[test]
17533:     fn resolve_proc_call_absolute_qualified_name() {
17534:         // ``::foo`` resolves directly when registered.
17535:         let mut a = Analyser::new();
17536:         a.handle_proc_command(
17537:             "proc",
17538:             &["foo".to_string(), String::new(), String::new()],
17539:             &[
17540:                 esc_tok(span(5, 8)),
17541:                 str_tok(span(9, 11)),
17542:                 str_tok(span(12, 14)),
17543:             ],
17544:             &[],
17545:             &[],
17546:         );
17547:         let resolved = a.resolve_proc_call("::foo", &[]);
17548:         assert!(resolved.is_some());
17549:         assert_eq!(resolved.unwrap().qualified_name, "::foo");
17550:     }
17551: 
17552:     #[test]
17553:     fn resolve_proc_call_bare_name_walks_namespace_chain() {
17554:         // ``foo`` declared inside ``ns1`` is found when resolved
17555:         // from ``ns1``'s scope.
17556:         use crate::analyser::types::{Scope, ScopeKind};
17557:         let mut a = Analyser::new();
17558:         a.result
17559:             .global_scope
17560:             .children
17561:             .push(Scope::new(ScopeKind::Namespace, "ns1"));
17562:         a.handle_proc_command(
17563:             "proc",
17564:             &["foo".to_string(), String::new(), String::new()],
17565:             &[
17566:                 esc_tok(span(5, 8)),
17567:                 str_tok(span(9, 11)),
17568:                 str_tok(span(12, 14)),
17569:             ],
17570:             &[],
17571:             &[0],
17572:         );
17573:         // Resolve from inside ns1 — should find ::ns1::foo.
17574:         let resolved = a.resolve_proc_call("foo", &[0]);
17575:         assert!(resolved.is_some());
17576:         assert_eq!(resolved.unwrap().qualified_name, "::ns1::foo");
17577:     }
17578: 
17579:     #[test]
17580:     fn resolve_proc_call_falls_back_to_global() {
17581:         // Bare ``foo`` declared at global is found from any scope.
17582:         use crate::analyser::types::{Scope, ScopeKind};
17583:         let mut a = Analyser::new();
17584:         a.handle_proc_command(
17585:             "proc",
17586:             &["foo".to_string(), String::new(), String::new()],
17587:             &[
17588:                 esc_tok(span(5, 8)),
17589:                 str_tok(span(9, 11)),
17590:                 str_tok(span(12, 14)),
17591:             ],
17592:             &[],
17593:             &[],
17594:         );
17595:         a.result
17596:             .global_scope
17597:             .children
17598:             .push(Scope::new(ScopeKind::Namespace, "ns1"));
17599:         // Resolve from inside ns1 — chain misses ::ns1::foo,
17600:         // falls back to ::foo.
17601:         let resolved = a.resolve_proc_call("foo", &[0]);
17602:         assert!(resolved.is_some());
17603:         assert_eq!(resolved.unwrap().qualified_name, "::foo");
17604:     }
17605: 
17606:     #[test]
17607:     fn resolve_proc_call_qualified_relative_name() {
17608:         // ``a::b`` (qualified but not absolute) prepends ``::``.
17609:         let mut a = Analyser::new();
17610:         a.result.all_procs.insert(
17611:             "::a::b".to_string(),
17612:             super::ProcDef {
17613:                 source_name: None,
17614:                 name: "b".to_string(),
17615:                 qualified_name: "::a::b".to_string(),
17616:                 params: Vec::new(),
17617:                 params_computed: false,
17618:                 formal_count: crate::signature_scan::formal_count::SourceFormalCount::Authored(
17619:                     tcl_dialect::ParameterGrammar::Tcl,
17620:                 ),
17621:                 name_span: span(0, 0),
17622:                 body_span: span(0, 0),
17623:                 doc: String::new(),
17624:                 param_traits: std::collections::HashMap::new(),
17625:                 caller_frame_params: std::collections::HashSet::new(),
17626:                 caller_frame_literals: std::collections::HashMap::new(),
17627:             },
17628:         );
17629:         let resolved = a.resolve_proc_call("a::b", &[]);
17630:         assert!(resolved.is_some());
17631:         assert_eq!(resolved.unwrap().qualified_name, "::a::b");
17632:     }
17633: 
17634:     #[test]
17635:     fn resolve_proc_call_relative_dotted_name_prefers_current_namespace() {
17636:         // A relative dotted word (`ns2::inner`, containing `::` but not
17637:         // starting with it) must resolve against the current namespace
17638:         // first, not be rooted straight at global (confirmed against tclsh
17639:         // 9.0.4 — see `bareword_resolution_candidates`).
17640:         use crate::analyser::types::{Scope, ScopeKind};
17641:         let mut a = Analyser::new();
17642:         for qname in ["::ns2::inner", "::ns::ns2::inner"] {
17643:             a.result.all_procs.insert(
17644:                 qname.to_string(),
17645:                 super::ProcDef {
17646:                     source_name: None,
17647:                     name: "inner".to_string(),
17648:                     qualified_name: qname.to_string(),
17649:                     params: Vec::new(),
17650:                     params_computed: false,
17651:                     formal_count: crate::signature_scan::formal_count::SourceFormalCount::Authored(
17652:                         tcl_dialect::ParameterGrammar::Tcl,
17653:                     ),
17654:                     name_span: span(0, 0),
17655:                     body_span: span(0, 0),
17656:                     doc: String::new(),
17657:                     param_traits: std::collections::HashMap::new(),
17658:                     caller_frame_params: std::collections::HashSet::new(),
17659:                     caller_frame_literals: std::collections::HashMap::new(),
17660:                 },
17661:             );
17662:         }
17663:         a.result
17664:             .global_scope
17665:             .children
17666:             .push(Scope::new(ScopeKind::Namespace, "ns"));
17667:         let resolved = a.resolve_proc_call("ns2::inner", &[0]);
17668:         assert_eq!(
17669:             resolved.unwrap().qualified_name,
17670:             "::ns::ns2::inner",
17671:             "must prefer the current-namespace proc over the root one",
17672:         );
17673:         // Falls back to the root proc when there is no current-namespace
17674:         // candidate.
17675:         let resolved = a.resolve_proc_call("ns2::inner", &[]);
17676:         assert_eq!(resolved.unwrap().qualified_name, "::ns2::inner");
17677:     }
17678: 
17679:     #[test]
17680:     fn resolve_proc_call_does_not_walk_ancestor_namespaces() {
17681:         // Real Tcl bareword resolution is exactly two levels — current
17682:         // namespace, then global — absent an explicit `namespace path`. A
17683:         // proc defined in a *grandparent* namespace must not resolve for a
17684:         // bare call from a nested `::a::b::c` scope.
17685:         use crate::analyser::types::{Scope, ScopeKind};
17686:         let mut a = Analyser::new();
17687:         let mut ns_a = Scope::new(ScopeKind::Namespace, "a");
17688:         let mut ns_b = Scope::new(ScopeKind::Namespace, "b");
17689:         ns_b.children.push(Scope::new(ScopeKind::Namespace, "c"));
17690:         ns_a.children.push(ns_b);
17691:         a.result.global_scope.children.push(ns_a);
17692:         // scope_path [0] = ::a — define `foo` there.
17693:         a.handle_proc_command(
17694:             "proc",
17695:             &["foo".to_string(), String::new(), String::new()],
17696:             &[
17697:                 esc_tok(span(5, 8)),
17698:                 str_tok(span(9, 11)),
17699:                 str_tok(span(12, 14)),
17700:             ],
17701:             &[],
17702:             &[0],
17703:         );
17704:         // Resolving from ::a::b::c (scope_path [0, 0, 0]) must NOT reach
17705:         // the grandparent's ::a::foo.
17706:         assert!(
17707:             a.resolve_proc_call("foo", &[0, 0, 0]).is_none(),
17708:             "a grandparent-namespace proc must not resolve for a bare call",
17709:         );
17710:         // Control: resolving directly from ::a still finds it.
17711:         assert!(a.resolve_proc_call("foo", &[0]).is_some());
17712:     }
17713: 
17714:     #[test]
17715:     fn resolve_proc_call_unknown_name_returns_none() {
17716:         let a = Analyser::new();
17717:         assert!(a.resolve_proc_call("nope", &[]).is_none());
17718:     }
17719: 
17720:     #[test]
17721:     fn resolve_proc_call_empty_name_returns_none() {
17722:         let a = Analyser::new();
17723:         assert!(a.resolve_proc_call("", &[]).is_none());
17724:     }
17725: 
17726:     // handle_interp_alias
17727: 
17728:     #[test]
17729:     fn handle_interp_alias_records_canonical_form() {
17730:         let mut a = Analyser::new();
17731:         a.registry = Some(std::sync::Arc::clone(
17732:             tcl_registry::model::ingress::static_context_for("tcl").commands(),
17733:         ));
17734:         a.handle_interp_alias(
17735:             &[
17736:                 "alias".to_string(),
17737:                 String::new(),
17738:                 "myset".to_string(),
17739:                 String::new(),
17740:                 "set".to_string(),
17741:             ],
17742:             &[],
17743:             42,
17744:         );
17745:         assert!(a.command_aliases.contains_key("::myset"));
17746:         assert!(a.result.command_aliases.contains_key("::myset"));
17747:         let (target, prepended) = &a.command_aliases["::myset"];
17748:         assert_eq!(target, "set");
17749:         assert_eq!(prepended.as_slice(), [] as [String; 0]);
17750:         assert_eq!(a.alias_offsets.get("::myset"), Some(&42));
17751:         // The offset is also promoted onto the finalised `AnalysisResult`
17752:         // (not just the in-progress `Analyser`), so a cross-document
17753:         // consumer such as `tcl_lsp_core::WorkspaceIndex` can tell an
17754:         // unconditional alias apart from one nested in a proc/class body.
17755:         assert_eq!(a.result.alias_offsets.get("::myset"), Some(&42));
17756:     }
17757: 
17758:     #[test]
17759:     fn handle_interp_alias_with_prepended_args() {
17760:         let mut a = Analyser::new();
17761:         a.registry = Some(std::sync::Arc::clone(
17762:             tcl_registry::model::ingress::static_context_for("tcl").commands(),
17763:         ));
17764:         a.handle_interp_alias(
17765:             &[
17766:                 "alias".to_string(),
17767:                 String::new(),
17768:                 "logerr".to_string(),
17769:                 String::new(),
17770:                 "puts".to_string(),
17771:                 "stderr".to_string(),
17772:             ],
17773:             &[],
17774:             0,
17775:         );
17776:         let (target, prepended) = &a.command_aliases["::logerr"];
17777:         assert_eq!(target, "puts");
17778:         assert_eq!(prepended, &vec!["stderr".to_string()]);
17779:     }
17780: 
17781:     #[test]
17782:     fn handle_interp_alias_wrong_shape_no_op() {
17783:         let mut a = Analyser::new();
17784:         a.registry = Some(std::sync::Arc::clone(
17785:             tcl_registry::model::ingress::static_context_for("tcl").commands(),
17786:         ));
17787:         a.handle_interp_alias(&["alias".to_string()], &[], 0);
17788:         assert_eq!(a.command_aliases.len(), 0);
17789:         assert_eq!(a.alias_offsets.len(), 0);
17790:     }
17791: 
17792:     // resolve_dynamic_word
17793: 
17794:     #[test]
17795:     fn resolve_dynamic_word_braced_literal_dollar_is_not_mistaken_for_dynamic() {
17796:         // A brace-quoted word containing a literal `$`/`[` character is
17797:         // legitimately STATIC — Tcl suppresses substitution inside
17798:         // `{}` — so this must return it as-is via `resolve_const_word`'s
17799:         // `Str`/`Esc` branch, even though `is_dynamic_word`'s naive text
17800:         // scan alone would call it dynamic.
17801:         let a = Analyser::new();
17802:         let tok = Token {
17803:             kind: TokenType::Str,
17804:             span: span(0, 10),
17805:             content_offset: 1,
17806:             in_quote: false,
17807:         };
17808:         assert_eq!(
17809:             a.resolve_dynamic_word("::pkg::$c", Some(tok), true, &[]),
17810:             Some("::pkg::$c".to_string())
17811:         );
17812:     }
17813: 
17814:     #[test]
17815:     fn resolve_dynamic_word_missing_token_is_none() {
17816:         // A dynamic word with no token to inspect (the handful of
17817:         // existing handle_rename unit tests pass `arg_tokens: &[]`)
17818:         // must fall through to None, not panic.
17819:         let a = Analyser::new();
17820:         assert_eq!(a.resolve_dynamic_word("$x", None, false, &[]), None);
17821:     }
17822: 
17823:     // handle_rename
17824: 
17825:     #[test]
17826:     fn handle_rename_records_static_move() {
17827:         let mut a = Analyser::new();
17828:         let dynamic = a.handle_rename(
17829:             &["target".to_string(), "target_orig".to_string()],
17830:             &[],
17831:             &[],
17832:             &[],
17833:             42,
17834:         );
17835:         assert!(!dynamic, "a fully static rename is not dynamic");
17836:         assert_eq!(
17837:             a.renamed_commands.get("::target_orig").map(String::as_str),
17838:             Some("::target")
17839:         );
17840:         assert_eq!(
17841:             a.result
17842:                 .renamed_commands
17843:                 .get("::target_orig")
17844:                 .map(String::as_str),
17845:             Some("::target")
17846:         );
17847:         assert_eq!(a.rename_offsets.get("::target_orig"), Some(&42));
17848:         // The old name is recorded as deleted from this offset —
17849:         // confirmed against tclsh 9.0.4: `target` becomes an unknown
17850:         // command, not still callable under its original arity.
17851:         assert_eq!(a.deleted_commands.get("::target"), Some(&42));
17852:     }
17853: 
17854:     #[test]
17855:     fn handle_rename_deletion_records_old_name_as_deleted() {
17856:         // `rename OLD {}` deletes OLD — no new binding to record (it is
17857:         // not a "dynamic" rename either, nothing to widen for), but OLD
17858:         // itself must be recorded as gone (confirmed against tclsh
17859:         // 9.0.4: also "invalid command name" afterwards).
17860:         let mut a = Analyser::new();
17861:         let dynamic = a.handle_rename(&["target".to_string(), String::new()], &[], &[], &[], 7);
17862:         assert!(!dynamic);
17863:         assert_eq!(a.renamed_commands.len(), 0);
17864:         assert_eq!(a.deleted_commands.get("::target"), Some(&7));
17865:     }
17866: 
17867:     #[test]
17868:     fn handle_rename_dynamic_old_name_reports_dynamic() {
17869:         let mut a = Analyser::new();
17870:         let dynamic = a.handle_rename(&["$x".to_string(), "y".to_string()], &[], &[], &[], 0);
17871:         assert!(dynamic, "rename $x y cannot be resolved statically");
17872:         assert_eq!(a.renamed_commands.len(), 0);
17873:         assert_eq!(a.deleted_commands.len(), 0);
17874:     }
17875: 
17876:     #[test]
17877:     fn handle_rename_dynamic_new_name_reports_dynamic() {
17878:         let mut a = Analyser::new();
17879:         let dynamic = a.handle_rename(&["x".to_string(), "y[z]".to_string()], &[], &[], &[], 0);
17880:         assert!(dynamic, "rename x y[z] cannot be resolved statically");
17881:         assert_eq!(a.renamed_commands.len(), 0);
17882:         assert_eq!(a.deleted_commands.len(), 0);
17883:     }
17884: 
17885:     #[test]
17886:     fn handle_rename_wrong_shape_no_op() {
17887:         let mut a = Analyser::new();
17888:         let dynamic = a.handle_rename(&["onlyone".to_string()], &[], &[], &[], 0);
17889:         assert!(!dynamic);
17890:         assert_eq!(a.renamed_commands.len(), 0);
17891:         assert_eq!(a.deleted_commands.len(), 0);
17892:     }
17893: 
17894:     // handle_source_command
17895: 
17896:     #[test]
17897:     fn handle_source_command_resolves_a_same_file_constant_variable() {
17898:         // The simplest possible case: a straight-line `set`, zero branches, zero
17899:         // external input, immediately followed by `source $var` — the real
17900:         // corpus's `set p "e.tcl"; source $p` shape, resolved through the
17901:         // same constant-string lattice `rename`'s OLD/NEW words use, via the
17902:         // shared `resolve_dynamic_word`.
17903:         let mut a = Analyser::new();
17904:         let r = a.analyse("namespace eval ::z { set p \"e.tcl\"; source $p }\n", "tcl");
17905:         let target = r
17906:             .source_targets
17907:             .iter()
17908:             .find(|s| s.raw_path == "e.tcl")
17909:             .unwrap_or_else(|| panic!("resolved literal not found: {:?}", r.source_targets));
17910:         assert!(target.is_literal, "{target:?}");
17911:     }
17912: 
17913:     #[test]
17914:     fn handle_source_command_resolves_a_concatenated_constant_variable() {
17915:         // A multi-token word (`${base}.tcl`, a Var fragment concatenated
17916:         // with a literal) goes through `fold_interpolation_single` rather
17917:         // than the single-token `resolve_const_word` fast path — covered
17918:         // separately since it's a different code path inside
17919:         // `resolve_dynamic_word`.
17920:         let mut a = Analyser::new();
17921:         let r = a.analyse(
17922:             "namespace eval ::z { set base \"helper\"; source ${base}.tcl }\n",
17923:             "tcl",
17924:         );
17925:         let target = r
17926:             .source_targets
17927:             .iter()
17928:             .find(|s| s.raw_path == "helper.tcl")
17929:             .unwrap_or_else(|| panic!("resolved literal not found: {:?}", r.source_targets));
17930:         assert!(target.is_literal, "{target:?}");
17931:     }
17932: 
17933:     #[test]
17934:     fn handle_source_command_a_dynamic_variable_with_no_known_value_stays_dynamic() {
17935:         // A proc parameter is never constant-tracked (the same limitation
17936:         // `resolve_dynamic_word` already documents for `rename`) — `source
17937:         // $p` here must stay conservatively dynamic rather than guess.
17938:         let mut a = Analyser::new();
17939:         let r = a.analyse("proc f {p} { source $p }\n", "tcl");
17940:         assert_eq!(r.source_targets.len(), 1, "{:?}", r.source_targets);
17941:         assert!(!r.source_targets[0].is_literal, "{:?}", r.source_targets[0]);
17942:     }
17943: 
17944:     #[test]
17945:     fn handle_source_command_leaves_a_bracket_wrapped_variable_dynamic() {
17946:         // A same-file constant wrapped inside a `[file join ...]` command
17947:         // substitution — the real corpus's `source [file join $edir
17948:         // extra.tcl]` shape — can't be folded by the same-word constant
17949:         // lattice (`fold_interpolation_single` rejects any word containing
17950:         // `[` outright, by design — a command substitution can have
17951:         // arbitrary side effects), and `evaluate_auto_path_expr`'s
17952:         // separate `[info script]`-anchored folder doesn't evaluate `$var`
17953:         // at all.
17954:         let mut a = Analyser::new();
17955:         let r = a.analyse(
17956:             "namespace eval ::z { set dir \"lib\"; source [file join $dir extra.tcl] }\n",
17957:             "tcl",
17958:         );
17959:         assert_eq!(r.source_targets.len(), 1, "{:?}", r.source_targets);
17960:         assert!(!r.source_targets[0].is_literal, "{:?}", r.source_targets[0]);
17961:     }
17962: 
17963:     // The `INSTALLS_NAMED_DEFINITION` re-dispatch contract.
17964: 
17965:     #[test]
17966:     fn every_installer_spec_lands_on_a_live_redispatch_arm() {
17967:         // Drift gate — the trait is a *promise* that
17968:         // `simulate_remaining_foreach_iterations` re-runs the command once
17969:         // per literal `foreach` element.  A spec that carries it but whose
17970:         // analyser hook has no arm in that match silently promises nothing
17971:         // (`oo::objdefine` is exactly that shape).
17972:         // Registry-driven, so a newly-stamped spec fails here rather than
17973:         // in a corpus months later.
17974:         use tcl_registry::hooks::AnalyserHookId as Hook;
17975:         let redispatched = [Hook::Proc, Hook::Rename, Hook::OoDefine, Hook::OoObjdefine];
17976:         let registry = tcl_registry::CommandRegistry::build_default();
17977:         let mut checked = 0usize;
17978:         for name in registry.command_names() {
17979:             for spec in registry.specs(name) {
17980:                 if !spec
17981:                     .traits
17982:                     .contains(tcl_registry::Traits::INSTALLS_NAMED_DEFINITION)
17983:                 {
17984:                     continue;
17985:                 }
17986:                 checked += 1;
17987:                 let hook = spec.analyser_hook.unwrap_or_else(|| {
17988:                     panic!("{name} carries INSTALLS_NAMED_DEFINITION but has no analyser hook")
17989:                 });
17990:                 assert!(
17991:                     redispatched.contains(&hook),
17992:                     "{name} carries INSTALLS_NAMED_DEFINITION but its hook {hook:?} has no \
17993:                      arm in the foreach re-dispatch — the trait promises a re-dispatch \
17994:                      the match does not deliver",
17995:                 );
17996:             }
17997:         }
17998:         assert!(
17999:             checked >= 4,
18000:             "expected proc/rename/oo::define/oo::objdefine, saw {checked}"
18001:         );
18002:     }
18003: 
18004:     #[test]
18005:     fn foreach_objdefine_records_per_object_facts_for_every_literal_element() {
18006:         // TP — the sibling shape.  tclsh 9.0.4 and 8.6.16
18007:         // both run `foreach o {::a ::b} { oo::objdefine $o { method probe
18008:         // {} {…} } }` and report `probe` in `info object methods` for
18009:         // *both* objects, so both must carry the per-object method fact.
18010:         let mut a = Analyser::new();
18011:         let r = a.analyse(
18012:             "oo::class create Base { method hello {} { return hi } }\n\
18013:              Base create ::a\n\
18014:              Base create ::b\n\
18015:              foreach o {::a ::b} {\n    oo::objdefine $o {\n        method probe {} { return probed }\n    }\n}\n",
18016:             "tcl9.0",
18017:         );
18018:         for obj in ["::a", "::b"] {
18019:             let methods = r
18020:                 .object_methods
18021:                 .get(obj)
18022:                 .unwrap_or_else(|| panic!("{obj} has per-object methods: {:?}", r.object_methods));
18023:             assert!(
18024:                 methods.iter().any(|m| m.def.name == "probe"),
18025:                 "{obj} gained probe: {methods:?}",
18026:             );
18027:         }
18028:     }
18029: 
18030:     #[test]
18031:     fn foreach_objdefine_does_not_double_record_the_first_element() {
18032:         // FP guard — the ordinary body walk covers the first element and
18033:         // the simulation covers the rest, so the first element's site is
18034:         // visited twice under the loop variable's own key.  One source site
18035:         // can never declare the same member twice, so it must appear once.
18036:         let mut a = Analyser::new();
18037:         let r = a.analyse(
18038:             "oo::class create Base { method hello {} { return hi } }\n\
18039:              Base create ::a\n\
18040:              Base create ::b\n\
18041:              foreach o {::a ::b} {\n    oo::objdefine $o {\n        method probe {} { return probed }\n    }\n}\n",
18042:             "tcl9.0",
18043:         );
18044:         for (key, methods) in &r.object_methods {
18045:             let probes = methods.iter().filter(|m| m.def.name == "probe").count();
18046:             assert!(
18047:                 probes <= 1,
18048:                 "{key} recorded probe {probes} times: {methods:?}",
18049:             );
18050:         }
18051:     }
18052: 
18053:     #[test]
18054:     fn foreach_objdefine_does_not_duplicate_body_diagnostics() {
18055:         // FP guard — re-running the installer per element re-walks the
18056:         // per-object method bodies, so a diagnostic raised inside one must
18057:         // still be reported once per site, never once per iteration.
18058:         let mut a = Analyser::new();
18059:         let r = a.analyse(
18060:             "oo::class create Base { method hello {} { return hi } }\n\
18061:              Base create ::a\n\
18062:              Base create ::b\n\
18063:              foreach o {::a ::b} {\n    oo::objdefine $o {\n        method probe {} { return $undefinedVar }\n    }\n}\n",
18064:             "tcl9.0",
18065:         );
18066:         let mut seen = std::collections::HashSet::new();
18067:         for diag in &r.diagnostics {
18068:             assert!(
18069:                 seen.insert((diag.code.to_string(), diag.span)),
18070:                 "duplicate diagnostic {:?} at {:?}",
18071:                 diag.code,
18072:                 diag.span,
18073:             );
18074:         }
18075:     }
18076: 
18077:     #[test]
18078:     fn foreach_objdefine_over_a_dynamic_list_abstains() {
18079:         // TN — a runtime element list names no object the walk can know, so
18080:         // the per-object facts stay under the loop variable's own key and
18081:         // are never attributed to a literal object.
18082:         let mut a = Analyser::new();
18083:         let r = a.analyse(
18084:             "oo::class create Base { method hello {} { return hi } }\n\
18085:              Base create ::a\n\
18086:              foreach o $objects {\n    oo::objdefine $o {\n        method probe {} { return probed }\n    }\n}\n",
18087:             "tcl9.0",
18088:         );
18089:         assert!(
18090:             !r.object_methods.contains_key("::a"),
18091:             "a runtime receiver must not be attributed to a literal object: {:?}",
18092:             r.object_methods,
18093:         );
18094:         assert!(
18095:             r.object_methods.contains_key("o"),
18096:             "the facts stay under the receiver variable: {:?}",
18097:             r.object_methods,
18098:         );
18099:     }
18100: 
18101:     // handle_oo_objdefine
18102: 
18103:     #[test]
18104:     fn handle_oo_objdefine_records_dollar_var() {
18105:         let mut a = Analyser::new();
18106:         a.handle_oo_objdefine(&["$obj".to_string()], &[], &[], &[]);
18107:         assert!(a.objdefined_vars.contains("obj"));
18108:     }
18109: 
18110:     #[test]
18111:     fn handle_oo_objdefine_records_braced_dollar_var() {
18112:         let mut a = Analyser::new();
18113:         a.handle_oo_objdefine(&["${obj}".to_string()], &[], &[], &[]);
18114:         assert!(a.objdefined_vars.contains("obj"));
18115:     }
18116: 
18117:     #[test]
18118:     fn handle_oo_objdefine_records_bare_name() {
18119:         let mut a = Analyser::new();
18120:         a.handle_oo_objdefine(&["obj".to_string()], &[], &[], &[]);
18121:         assert!(a.objdefined_vars.contains("obj"));
18122:     }
18123: 
18124:     #[test]
18125:     fn oo_objdefine_body_methods_are_analysed() {
18126:         // Before: the `oo::objdefine` body was never parsed, so nothing inside
18127:         // a per-object method resolved.  Now the body walks like any method
18128:         // body — the call it makes is recorded as an invocation.
18129:         let mut a = Analyser::new();
18130:         let src = "proc helper {} {}\n\
18131:                    oo::class create Foo {}\n\
18132:                    set o [Foo new]\n\
18133:                    oo::objdefine $o {\n    \
18134:                        method greet {} { helper }\n\
18135:                    }\n";
18136:         let r = a.analyse(src, "tcl8.6");
18137:         assert!(
18138:             r.command_invocations.iter().any(|i| i.name == "helper"),
18139:             "the call inside the per-object method body should be analysed: {:?}",
18140:             r.command_invocations
18141:                 .iter()
18142:                 .map(|i| &i.name)
18143:                 .collect::<Vec<_>>(),
18144:         );
18145:     }
18146: 
18147:     // handle_oo_class_command
18148: 
18149:     #[test]
18150:     fn handle_oo_class_create_records_class() {
18151:         let mut a = Analyser::new();
18152:         // Metaclass recognition is now registry-trait-driven (`IS_OO_METACLASS`).
18153:         a.registry = Some(std::sync::Arc::clone(
18154:             tcl_registry::model::ingress::static_context_for("tcl").commands(),
18155:         ));
18156:         let handled = a.handle_oo_class_command(
18157:             "oo::class",
18158:             &["create".to_string(), "MyClass".to_string()],
18159:             &[
18160:                 esc_tok(span(0, 9)),
18161:                 esc_tok(span(10, 16)),
18162:                 esc_tok(span(17, 24)),
18163:             ],
18164:             &[],
18165:             esc_tok(span(0, 9)),
18166:         );
18167:         assert!(handled);
18168:         assert!(a.result.all_classes.contains_key("::MyClass"));
18169:         let cls = &a.result.all_classes["::MyClass"];
18170:         assert_eq!(cls.name, "MyClass");
18171:     }
18172: 
18173:     #[test]
18174:     fn handle_oo_class_create_with_body() {
18175:         // arg_tokens stripped of cmd_name (matching the
18176:         // ``process_command`` dispatch convention).
18177:         let mut a = Analyser::new();
18178:         a.registry = Some(std::sync::Arc::clone(
18179:             tcl_registry::model::ingress::static_context_for("tcl").commands(),
18180:         ));
18181:         let handled = a.handle_oo_class_command(
18182:             "oo::class",
18183:             &[
18184:                 "create".to_string(),
18185:                 "MyClass".to_string(),
18186:                 "method m {} {}".to_string(),
18187:             ],
18188:             &[
18189:                 esc_tok(span(10, 16)),
18190:                 esc_tok(span(17, 24)),
18191:                 str_tok(span(25, 41)),
18192:             ],
18193:             &[],
18194:             esc_tok(span(0, 9)),
18195:         );
18196:         assert!(handled);
18197:         assert_eq!(a.result.all_classes["::MyClass"].body_span, span(25, 41));
18198:     }
18199: 
18200:     #[test]
18201:     fn handle_oo_class_wrong_subcommand_returns_false() {
18202:         let mut a = Analyser::new();
18203:         let handled = a.handle_oo_class_command(
18204:             "oo::class",
18205:             &["destroy".to_string(), "MyClass".to_string()],
18206:             &[
18207:                 esc_tok(span(0, 9)),
18208:                 esc_tok(span(10, 17)),
18209:                 esc_tok(span(18, 25)),
18210:             ],
18211:             &[],
18212:             esc_tok(span(0, 9)),
18213:         );
18214:         assert!(!handled);
18215:         assert_eq!(a.result.all_classes.len(), 0);
18216:     }
18217: 
18218:     // handle_oo_class_command body walking
18219: 
18220:     #[test]
18221:     fn analyse_oo_class_body_records_superclass_and_methods() {
18222:         // End-to-end: ``oo::class create Sub`` with a body
18223:         // declaring a superclass and a method.  After analyse
18224:         // ``::Sub`` should carry both fields.
18225:         let mut a = crate::analyser::Analyser::new();
18226:         let r = a.analyse(
18227:             "oo::class create Sub { superclass ::Base\nmethod greet {} { puts hi } }",
18228:             "tcl",
18229:         );
18230:         assert!(r.all_classes.contains_key("::Sub"));
18231:         let cls = &r.all_classes["::Sub"];
18232:         assert_eq!(cls.superclasses, vec!["::Base"]);
18233:         assert!(cls.methods.contains_key("greet"));
18234:         assert_eq!(cls.methods["greet"].kind, "method");
18235:     }
18236: 
18237:     #[test]
18238:     fn analyse_oo_class_body_records_classmethod_and_mixin() {
18239:         let mut a = crate::analyser::Analyser::new();
18240:         let r = a.analyse(
18241:             "oo::class create C { mixin ::M\nclassmethod build {} { return ok } }",
18242:             "tcl",
18243:         );
18244:         let cls = &r.all_classes["::C"];
18245:         assert_eq!(cls.mixins, vec!["::M"]);
18246:         assert!(cls.class_methods.contains_key("build"));
18247:         assert!(!cls.methods.contains_key("build"));
18248:     }
18249: 
18250:     // handle_oo_define_command body walking
18251: 
18252:     #[test]
18253:     fn analyse_oo_define_body_extends_existing_class() {
18254:         // ``oo::class create C {}`` followed by ``oo::define
18255:         // C { method m {} {} }`` — the method ends up in the
18256:         // already-recorded class.
18257:         let mut a = crate::analyser::Analyser::new();
18258:         let r = a.analyse(
18259:             "oo::class create C {}\noo::define C { method m {} {} }",
18260:             "tcl",
18261:         );
18262:         assert!(r.all_classes.contains_key("::C"));
18263:         let cls = &r.all_classes["::C"];
18264:         assert!(cls.methods.contains_key("m"));
18265:     }
18266: 
18267:     #[test]
18268:     fn oo_define_extending_an_existing_class_adds_its_own_class_body_span() {
18269:         // `class_body_spans` must record BOTH the
18270:         // creation site's own span AND the separate `oo::define` block's
18271:         // own span for the same qualified class — a class extended via a
18272:         // *separate* `oo::define ClassName { ... }` block has textually
18273:         // disjoint body spans, not one contiguous range, and `my`-dispatch
18274:         // resolution (a lexical "which class's body am I inside" query)
18275:         // needs every contributing span, not just the first one recorded.
18276:         let mut a = crate::analyser::Analyser::new();
18277:         let src = "oo::class create C {}\noo::define C { method m {} {} }";
18278:         let r = a.analyse(src, "tcl");
18279:         let spans: Vec<tcl_lexer::Span> = r
18280:             .class_body_spans
18281:             .iter()
18282:             .filter(|(name, _)| name == "::C")
18283:             .map(|(_, span)| *span)
18284:             .collect();
18285:         assert_eq!(spans.len(), 2, "{spans:?}");
18286:         // One of the two recorded spans must cover the `oo::define`
18287:         // block's own `method m {} {}` text — the token whose containment
18288:         // `enclosing_class_at` checks for a cursor inside it.
18289:         let inside_define_block = u32::try_from(src.find("method m").unwrap()).unwrap();
18290:         assert!(
18291:             spans
18292:                 .iter()
18293:                 .any(|span| span.start() <= inside_define_block
18294:                     && inside_define_block < span.end()),
18295:             "no recorded span covers the oo::define block's own body: {spans:?}"
18296:         );
18297:     }
18298: 
18299:     #[test]
18300:     fn oo_define_extends_class_named_like_a_create_subcommand() {
18301:         // `oo::define` / `oo::objdefine` carry a TclOO
18302:         // `definition_body` but no `IS_OO_METACLASS` trait, so a class literally
18303:         // named `create` must be *extended* by `handle_oo_define_command`, not
18304:         // stolen by `handle_oo_class_command` (which would record a bogus class
18305:         // named `method`).  The class-creator check requires the metaclass
18306:         // trait, which define/objdefine lack.
18307:         let mut a = crate::analyser::Analyser::new();
18308:         let r = a.analyse("oo::define create method greet {} { return hi }", "tcl");
18309:         // The real class is `create`, with method `greet` — not a bogus class.
18310:         let cls = r
18311:             .all_classes
18312:             .get("::create")
18313:             .expect("class `create` recorded by oo::define");
18314:         assert!(
18315:             cls.methods.contains_key("greet"),
18316:             "method greet must be recorded on class `create`: {:?}",
18317:             cls.methods.keys().collect::<Vec<_>>()
18318:         );
18319:         assert!(
18320:             !r.all_classes.contains_key("::method"),
18321:             "no bogus class named `method` should be created",
18322:         );
18323:     }
18324: 
18325:     #[test]
18326:     fn analyse_oo_define_inline_form_extends_class() {
18327:         // ``oo::define C method m {} {}`` — inline form,
18328:         // single subcommand.  Works whether or not the class
18329:         // was already declared (creates a stub if absent).
18330:         let mut a = crate::analyser::Analyser::new();
18331:         let r = a.analyse("oo::define MyClass method greet {} { puts hi }", "tcl");
18332:         assert!(r.all_classes.contains_key("::MyClass"));
18333:         let cls = &r.all_classes["::MyClass"];
18334:         assert!(cls.methods.contains_key("greet"));
18335:     }
18336: 
18337:     #[test]
18338:     fn two_dynamic_oo_define_targets_sharing_a_variable_name_never_merge() {
18339:         // TP — clay.tcl's `current_class`-based Ensemble DSL shape: two lexically
18340:         // unrelated procs each write `oo::define $class method ... ` with a
18341:         // same-named local `class` (an unremarkable choice for this exact
18342:         // idiom) and each add their own method. Keying such a call on the raw
18343:         // text `$class` gives both calls the identical key, so the second
18344:         // `remove`+`insert` round-trip silently merges the first proc's
18345:         // method into the second's ClassDef (and vice versa via the
18346:         // dual-registration into `scope.classes`), producing a document
18347:         // symbol whose child method range sits outside its own parent's.
18348:         // The targets here are *parameters*, so no constant dominates
18349:         // either call and both stay genuinely dynamic — the shape this
18350:         // guard is about.  (A target bound to a dominating constant is a
18351:         // different, statically-resolvable case: see
18352:         // `oo_define_resolves_a_dominating_constant_target`.)
18353:         let mut a = Analyser::new();
18354:         let r = a.analyse(
18355:             "proc addFoo {class} {\n    oo::define $class method foo {} { return foo }\n}\n\
18356:              proc addBar {class} {\n    oo::define $class method bar {} { return bar }\n}\n",
18357:             "tcl8.6",
18358:         );
18359:         let synthetic: Vec<_> = r
18360:             .all_classes
18361:             .iter()
18362:             .filter(|(k, _)| k.contains("@dynclass@"))
18363:             .collect();
18364:         assert_eq!(
18365:             synthetic.len(),
18366:             2,
18367:             "each dynamic oo::define call site gets its own ClassDef: {:?}",
18368:             r.all_classes.keys().collect::<Vec<_>>(),
18369:         );
18370:         let has_foo_only = synthetic
18371:             .iter()
18372:             .any(|(_, c)| c.methods.contains_key("foo") && !c.methods.contains_key("bar"));
18373:         let has_bar_only = synthetic
18374:             .iter()
18375:             .any(|(_, c)| c.methods.contains_key("bar") && !c.methods.contains_key("foo"));
18376:         assert!(
18377:             has_foo_only && has_bar_only,
18378:             "neither call site's method may leak into the other's ClassDef: {:?}",
18379:             synthetic
18380:                 .iter()
18381:                 .map(|(k, c)| (k, c.methods.keys().collect::<Vec<_>>()))
18382:                 .collect::<Vec<_>>(),
18383:         );
18384:     }
18385: 
18386:     #[test]
18387:     fn dynamic_oo_define_target_does_not_touch_a_same_named_literal_class() {
18388:         // FP guard — a class whose *written* name matches nothing knowable
18389:         // (`$class` bound to a parameter) must never be found/extended
18390:         // through a literal class that happens to share the variable's
18391:         // source text: the synthetic key can never collide with a real
18392:         // qualified name.  A target bound to a dominating constant *is*
18393:         // resolvable and does extend the real class — tclsh 9.0.4/8.6.16
18394:         // agree — which is
18395:         // `oo_define_resolves_a_dominating_constant_target`'s case, not
18396:         // this one.
18397:         let mut a = Analyser::new();
18398:         let r = a.analyse(
18399:             "oo::class create Widget {\n    method real {} {}\n}\n\
18400:              proc addDynamic {class} {\n    oo::define $class method dynamic {} {}\n}\n",
18401:             "tcl8.6",
18402:         );
18403:         let widget = &r.all_classes["::Widget"];
18404:         assert!(widget.methods.contains_key("real"), "{widget:?}");
18405:         assert!(
18406:             !widget.methods.contains_key("dynamic"),
18407:             "the dynamic call must not extend the literal same-named class: {widget:?}",
18408:         );
18409:     }
18410: 
18411:     // handle_oo_define_command
18412: 
18413:     #[test]
18414:     fn handle_oo_define_recognises_canonical_form() {
18415:         let mut a = Analyser::new();
18416:         let handled = a.handle_oo_define_command(
18417:             "oo::define",
18418:             &["MyClass".to_string(), "method m {} {}".to_string()],
18419:             &[],
18420:             &[],
18421:             &[],
18422:         );
18423:         assert!(handled);
18424:     }
18425: 
18426:     #[test]
18427:     fn handle_oo_define_no_args_returns_false() {
18428:         let mut a = Analyser::new();
18429:         let handled = a.handle_oo_define_command("oo::define", &[], &[], &[], &[]);
18430:         assert!(!handled);
18431:     }
18432: 
18433:     // `incr` / `append` / `lappend` / `dict` — bound by role
18434: 
18435:     #[test]
18436:     fn incr_binds_its_target_by_role() {
18437:         let mut a = Analyser::new();
18438:         dispatch_words(&mut a, &["incr", "counter"]);
18439:         assert!(a.result.global_scope.variables.contains_key("counter"));
18440:         // A read-modify-write target is read before it is written, so the
18441:         // binding is a side effect, never a "set but unused" write.
18442:         assert!(!a.result.global_scope.variables["counter"].warn_if_unused);
18443:     }
18444: 
18445:     #[test]
18446:     fn handle_incr_with_amount() {
18447:         let mut a = Analyser::new();
18448:         dispatch_words(&mut a, &["incr", "counter", "5"]);
18449:         assert!(a.result.global_scope.variables.contains_key("counter"));
18450:         assert!(!a.result.global_scope.variables.contains_key("5"));
18451:     }
18452: 
18453:     #[test]
18454:     fn handle_incr_no_args_no_op() {
18455:         let mut a = Analyser::new();
18456:         dispatch_words(&mut a, &["incr"]);
18457:         assert!(a.result.global_scope.variables.is_empty());
18458:     }
18459: 
18460:     #[test]
18461:     fn a_written_array_element_binds_its_array_and_a_computed_name_binds_nothing() {
18462:         // `incr hits($word)` writes an element of `hits` whatever the key;
18463:         // `append $name x` and `incr $count` write a variable no static name
18464:         // spells.
18465:         let mut a = Analyser::new();
18466:         dispatch_words(&mut a, &["incr", "hits($word)"]);
18467:         dispatch_words(&mut a, &["append", "$name", "x"]);
18468:         dispatch_words(&mut a, &["incr", "$count"]);
18469:         dispatch_words(&mut a, &["lappend", "items", "x"]);
18470:         assert!(a.result.global_scope.variables.contains_key("hits"));
18471:         assert!(a.result.global_scope.variables.contains_key("items"));
18472:         assert!(!a.result.global_scope.variables.contains_key("name"));
18473:         assert!(!a.result.global_scope.variables.contains_key("count"));
18474:         assert!(!a.result.global_scope.variables.contains_key("$count"));
18475:     }
18476: 
18477:     #[test]
18478:     fn dict_for_and_dict_update_bind_their_loop_variables_by_role() {
18479:         let mut a = Analyser::new();
18480:         dispatch_words(&mut a, &["dict", "for", "k v", "$d", ""]);
18481:         dispatch_words(&mut a, &["dict", "update", "d", "key", "w", ""]);
18482:         for name in ["k", "v", "w"] {
18483:             assert!(
18484:                 a.result.global_scope.variables.contains_key(name),
18485:                 "{name}: {:?}",
18486:                 a.result.global_scope.variables.keys().collect::<Vec<_>>()
18487:             );
18488:         }
18489:         // Neither the key word nor the dictionary variable is a loop variable.
18490:         assert!(!a.result.global_scope.variables.contains_key("key"));
18491:     }
18492: 
18493:     // ClassDef extended fields + UnknownProcInfo
18494: 
18495:     #[test]
18496:     fn analyse_oo_class_records_metaclass_from_command_name() {
18497:         let mut a = crate::analyser::Analyser::new();
18498:         let r = a.analyse("oo::class create C {}", "tcl");
18499:         let cls = &r.all_classes["::C"];
18500:         assert_eq!(cls.metaclass, "oo::class");
18501:     }
18502: 
18503:     #[test]
18504:     fn analyse_oo_class_body_records_constructors_and_destructor() {
18505:         let mut a = crate::analyser::Analyser::new();
18506:         let r = a.analyse(
18507:             "oo::class create C { constructor args { puts ctor }\ndestructor { puts dtor } }",
18508:             "tcl",
18509:         );
18510:         let cls = &r.all_classes["::C"];
18511:         assert_eq!(cls.constructors.len(), 1);
18512:         assert_eq!(cls.constructors[0].kind, "constructor");
18513:         assert!(cls.destructor.is_some());
18514:         assert_eq!(cls.destructor.as_ref().unwrap().kind, "destructor");
18515:     }
18516: 
18517:     #[test]
18518:     fn analyse_oo_class_body_records_variables_filters_exports() {
18519:         let mut a = crate::analyser::Analyser::new();
18520:         let r = a.analyse(
18521:             "oo::class create C { variable x y\nfilter log\nexport foo bar\nunexport hidden }",
18522:             "tcl",
18523:         );
18524:         let cls = &r.all_classes["::C"];
18525:         assert_eq!(cls.variables, vec!["x", "y"]);
18526:         assert_eq!(cls.filters, vec!["log"]);
18527:         assert!(cls.exports.contains("foo"));
18528:         assert!(cls.exports.contains("bar"));
18529:         assert!(cls.unexports.contains("hidden"));
18530:     }
18531: 
18532:     #[test]
18533:     fn analyse_oo_class_body_records_property_def() {
18534:         let mut a = crate::analyser::Analyser::new();
18535:         let r = a.analyse(
18536:             "oo::class create C { property colour -kind readwrite -get { return red } }",
18537:             "tcl",
18538:         );
18539:         let cls = &r.all_classes["::C"];
18540:         let pd = cls.properties.get("colour").expect("colour recorded");
18541:         assert_eq!(pd.kind, "readwrite");
18542:         assert!(pd.has_getter);
18543:         assert!(!pd.has_setter);
18544:     }
18545: 
18546:     #[test]
18547:     fn analyse_unknown_proc_records_dispatch_targets_end_to_end() {
18548:         // End-to-end: a ``proc unknown {cmd args} {...}`` with
18549:         // an exact-match switch should populate
18550:         // ``result.unknown_proc_info`` with the arm labels as
18551:         // dispatch targets.  This is what gates W123.
18552:         let mut a = crate::analyser::Analyser::new();
18553:         let r = a.analyse(
18554:             "proc unknown {cmd args} { switch -exact $cmd { foo { return 1 } bar { return 2 } } }",
18555:             "tcl",
18556:         );
18557:         let info = r.unknown_proc_info.expect("unknown_proc_info populated");
18558:         assert!(!info.empty_stub);
18559:         assert!(info.dispatch_targets.contains("foo"));
18560:         assert!(info.dispatch_targets.contains("bar"));
18561:     }
18562: 
18563:     #[test]
18564:     fn analyse_without_unknown_proc_leaves_unknown_proc_info_none() {
18565:         let mut a = crate::analyser::Analyser::new();
18566:         let r = a.analyse("proc foo {} { return 1 }", "tcl");
18567:         assert!(r.unknown_proc_info.is_none());
18568:     }
18569: 
18570:     #[test]
18571:     fn analyse_unknown_proc_with_empty_body_marks_empty_stub() {
18572:         let mut a = crate::analyser::Analyser::new();
18573:         let r = a.analyse("proc unknown {cmd args} {}", "tcl");
18574:         let info = r.unknown_proc_info.expect("unknown_proc_info populated");
18575:         assert!(info.empty_stub);
18576:     }
18577: 
18578:     /// `conditional_depth` is driven by
18579:     /// `Traits::BRANCH_SELECTED_BODY`, so exactly the branch-selected bodies
18580:     /// mark a `package require` conditional.
18581:     ///
18582:     /// `if` and `try` bodies are branch-selected: at most one runs, chosen at
18583:     /// run time, so nothing inside dominates the code after the command. A
18584:     /// `while` body is skippable *and* repeatable — a different question,
18585:     /// owned by `control_flow_body_depth` — and does **not** mark the require
18586:     /// conditional. A top-level require is unconditional.
18587:     #[test]
18588:     fn package_require_conditionality_follows_the_branch_selected_body_trait() {
18589:         let conditional_flags = |src: &str| -> Vec<bool> {
18590:             let mut a = crate::analyser::Analyser::new();
18591:             a.analyse(src, "tcl8.6")
18592:                 .package_requires
18593:                 .iter()
18594:                 .map(|p| p.conditional)
18595:                 .collect()
18596:         };
18597:         assert_eq!(conditional_flags("package require Tcl 8.6\n"), vec![false]);
18598:         assert_eq!(
18599:             conditional_flags("if {$x} { package require Tcl 8.6 }\n"),
18600:             vec![true],
18601:         );
18602:         assert_eq!(
18603:             conditional_flags("while {$x} { package require Tcl 8.6 }\n"),
18604:             vec![false],
18605:             "a loop body is skippable-and-repeatable, a different question",
18606:         );
18607:         // `try`'s bodies take the generic body walk at their clause's timing:
18608:         // the protected body is a guarded probe, so it is conditional like
18609:         // `if`'s.
18610:         assert_eq!(
18611:             conditional_flags("try { package require Tcl 8.6 } on error {} {}\n"),
18612:             vec![true],
18613:         );
18614:     }
18615: 
18616:     /// The generic body walk raises the branch-selected depth per clause
18617:     /// timing (`body_depths`), so a `package require` records the right
18618:     /// conditionality wherever in a `try` it sits.
18619:     ///
18620:     /// Clause semantics are C Tcl's (Tcl 9.0.4 `try(n)`, `TclNRTryObjCmd` in
18621:     /// `generic/tclCmdMZ.c`): the main body may be cut short by an exception a
18622:     /// handler swallows and the `on`/`trap` handlers run only on a match — both
18623:     /// branch-selected — while `finally` always runs, so it is not.
18624:     #[test]
18625:     fn package_require_conditionality_per_try_clause_kind() {
18626:         let conditional_flags = |src: &str| -> Vec<bool> {
18627:             let mut a = crate::analyser::Analyser::new();
18628:             a.analyse(src, "tcl8.6")
18629:                 .package_requires
18630:                 .iter()
18631:                 .map(|p| p.conditional)
18632:                 .collect()
18633:         };
18634:         // TP — the guarded optional-dependency idiom.
18635:         assert_eq!(
18636:             conditional_flags("try { package require Foo } on error {} {}\n"),
18637:             vec![true],
18638:             "a require in the main try body is conditional",
18639:         );
18640:         // TP — an `on` handler body.
18641:         assert_eq!(
18642:             conditional_flags("try { set x 1 } on error {} { package require Foo }\n"),
18643:             vec![true],
18644:             "a require in an `on` handler is conditional",
18645:         );
18646:         // TP — a `trap` handler body.
18647:         assert_eq!(
18648:             conditional_flags(
18649:                 "try { set x 1 } trap {POSIX ENOENT} {m o} { package require Foo }\n"
18650:             ),
18651:             vec![true],
18652:             "a require in a `trap` handler is conditional",
18653:         );
18654:         // TN — a `finally` body always runs, so it is not branch-selected.
18655:         assert_eq!(
18656:             conditional_flags("try { set x 1 } finally { package require Foo }\n"),
18657:             vec![false],
18658:             "a `finally` body always runs — the require is unconditional",
18659:         );
18660:         // TN — a top-level require, the control.
18661:         assert_eq!(conditional_flags("package require Foo\n"), vec![false]);
18662:         // FN guard — the depth is restored after the walk, so a require that
18663:         // follows the whole `try` command is still unconditional.
18664:         assert_eq!(
18665:             conditional_flags(
18666:                 "try { package require A } on error {} { package require B } finally { package require C }\npackage require D\n"
18667:             ),
18668:             vec![true, true, false, false],
18669:             "main body + handler conditional; finally and the following \
18670:              top-level require unconditional",
18671:         );
18672:         // FP guard — nesting a `try` inside an `if` must not leave the depth
18673:         // stuck: the require after both is still unconditional.
18674:         assert_eq!(
18675:             conditional_flags(
18676:                 "if {$x} { try { package require A } finally { set y 1 } }\npackage require B\n"
18677:             ),
18678:             vec![true, false],
18679:         );
18680:     }
18681: 
18682:     /// `for`'s bodies take the generic body walk at their clause's timing
18683:     /// (D2.55), the reading the retired `handle_for_command` gave: `start`
18684:     /// runs once, at the enclosing depth; `next` and the body run per
18685:     /// iteration, at a control-flow depth. None is branch-selected.
18686:     #[test]
18687:     fn for_start_runs_at_the_enclosing_depth_and_next_and_body_per_iteration() {
18688:         let mut a = crate::analyser::Analyser::new();
18689:         let depths: Vec<(bool, bool)> = a
18690:             .analyse(
18691:                 "for {package require A} {$i < 3} {package require B} {package require C}\n\
18692:                  package require D\n",
18693:                 "tcl8.6",
18694:             )
18695:             .package_requires
18696:             .iter()
18697:             .map(|p| (p.conditional, p.control_flow))
18698:             .collect();
18699:         assert_eq!(
18700:             depths,
18701:             vec![(false, false), (false, true), (false, true), (false, false)],
18702:             "start straight-line; next and body control flow; the depth \
18703:              restored after the loop",
18704:         );
18705:     }
18706: 
18707:     /// A `try` handler body is `Selected` — conditional and control flow — so
18708:     /// a `rename` there may never run and is not a straight-line deletion,
18709:     /// as one inside a loop body is not. A
18710:     /// `finally` body always runs, so its `rename` still is one.
18711:     #[test]
18712:     fn a_rename_in_a_try_handler_is_not_a_straight_line_deletion() {
18713:         let destroys_foo = |src: &str| {
18714:             let mut a = crate::analyser::Analyser::new();
18715:             a.analyse(src, "tcl8.6")
18716:                 .destroyed_commands
18717:                 .contains_key("::foo")
18718:         };
18719:         assert!(!destroys_foo(
18720:             "proc foo {} {}\ntry { set x 1 } on error {} { rename foo {} }\n"
18721:         ));
18722:         assert!(!destroys_foo(
18723:             "proc foo {} {}\ntry { set x 1 } trap {POSIX ENOENT} {} { rename foo {} }\n"
18724:         ));
18725:         assert!(destroys_foo(
18726:             "proc foo {} {}\ntry { set x 1 } finally { rename foo {} }\n"
18727:         ));
18728:         assert!(destroys_foo("proc foo {} {}\nrename foo {}\n"));
18729:     }
18730: 
18731:     /// A `proc unknown` nested inside `namespace eval`
18732:     /// is an ordinary namespace proc, not the interpreter's handler, so it
18733:     /// must not seed `unknown_proc_info` and suppress W123 file-wide.
18734:     ///
18735:     /// The body is the dynamic (`exec`-dispatching) shape that *would*
18736:     /// suppress W123 file-wide if this were the global handler, so the test
18737:     /// isolates the scope question rather than the body-shape one.
18738:     ///
18739:     /// Oracle (tclsh8.6.14 and tclsh9.0.4): with
18740:     /// `namespace eval ::mylib { proc unknown {args} { return handled } }`,
18741:     /// calling `totallyBogusCommand` still fails
18742:     /// `invalid command name "totallyBogusCommand"` — only a *global*
18743:     /// `proc unknown` makes it return `handled`.
18744:     #[test]
18745:     fn analyse_namespace_local_unknown_proc_does_not_seed_the_global_handler() {
18746:         let mut a = crate::analyser::Analyser::new();
18747:         let r = a.analyse(
18748:             "namespace eval ::mylib { proc unknown {cmd args} { exec $cmd {*}$args } }\n\
18749:              totallyBogusCommand\n",
18750:             "tcl9.0",
18751:         );
18752:         assert!(
18753:             r.unknown_proc_info.is_none(),
18754:             "a namespace-local proc named unknown is not the global handler",
18755:         );
18756:         assert!(
18757:             r.diagnostics
18758:                 .iter()
18759:                 .any(|d| d.code == tcl_core_types::DiagCode::W123),
18760:             "so the bogus command is still unresolved; got {:?}",
18761:             r.diagnostics,
18762:         );
18763:     }
18764: 
18765:     /// TP guard — the global handler still seeds the info (and still
18766:     /// suppresses W123), which is the behaviour the C2 fix must not disturb.
18767:     #[test]
18768:     fn analyse_global_unknown_proc_still_seeds_the_handler() {
18769:         let mut a = crate::analyser::Analyser::new();
18770:         let r = a.analyse(
18771:             "proc unknown {cmd args} { exec $cmd {*}$args }\ntotallyBogusCommand\n",
18772:             "tcl9.0",
18773:         );
18774:         assert!(
18775:             r.unknown_proc_info.is_some(),
18776:             "a global proc unknown is the handler",
18777:         );
18778:         assert!(
18779:             !r.diagnostics
18780:                 .iter()
18781:                 .any(|d| d.code == tcl_core_types::DiagCode::W123),
18782:             "and it suppresses the unresolved-command warning; got {:?}",
18783:             r.diagnostics,
18784:         );
18785:     }
18786: 
18787:     #[test]
18788:     fn analyse_qualified_unknown_proc_also_populates_info() {
18789:         // ``::tcl::unknown`` (the canonical fully-qualified
18790:         // name) should trigger detection too.
18791:         let mut a = crate::analyser::Analyser::new();
18792:         let r = a.analyse("proc ::tcl::unknown {cmd args} { exec $cmd }", "tcl");
18793:         let info = r.unknown_proc_info.expect("unknown_proc_info populated");
18794:         assert!(info.has_exec);
18795:     }
18796: 
18797:     // stray-close-bracket recovery
18798: 
18799:     #[test]
18800:     fn analyse_top_level_repairs_stray_close_bracket() {
18801:         // ``set x string]`` is a typo for ``set x [string ...]``.
18802:         // The recovery should rewrite the third argv entry into
18803:         // a virtual ``CMD`` token before dispatch so the var
18804:         // record is registered with the recovered shape.
18805:         let mut a = crate::analyser::Analyser::new();
18806:         let r = a.analyse("set x string]", "tcl");
18807:         // ``x`` ends up in scope as a single-arg ``set`` (a var
18808:         // read), not as a two-arg ``set`` with the broken text
18809:         // — recovery yields the synthetic ``[string]`` command
18810:         // word so dispatch sees the intended shape.
18811:         assert!(r.global_scope.variables.contains_key("x"));
18812:     }
18813: 
18814:     // unknown_proc_info / package require
18815: 
18816:     #[test]
18817:     fn analyse_records_package_require() {
18818:         let mut a = crate::analyser::Analyser::new();
18819:         let r = a.analyse("package require Tcl 8.6", "tcl");
18820:         assert_eq!(r.package_requires.len(), 1);
18821:         let p = &r.package_requires[0];
18822:         assert_eq!(p.name, "Tcl");
18823:         assert_eq!(p.version.as_deref(), Some("8.6"));
18824:         assert_eq!(p.requirements, ["8.6"]);
18825:         assert!(!p.conditional);
18826:         assert!(!p.control_flow);
18827:         assert!(!p.exact, "no `-exact` word means the ranged requirement");
18828:     }
18829: 
18830:     #[test]
18831:     fn analyse_records_every_package_requirement_alternative() {
18832:         let mut a = crate::analyser::Analyser::new();
18833:         let r = a.analyse("package require Foo 1.0 2.0-2.5", "tcl8.6");
18834:         let p = &r.package_requires[0];
18835:         assert_eq!(p.version.as_deref(), Some("1.0"));
18836:         assert_eq!(p.requirements, ["1.0", "2.0-2.5"]);
18837:     }
18838: 
18839:     #[test]
18840:     fn analyse_marks_package_requires_in_control_flow() {
18841:         let cases = [
18842:             (
18843:                 "while {$enabled} { package require WhileDep 1.0 }",
18844:                 "tcl8.6",
18845:                 "WhileDep",
18846:             ),
18847:             (
18848:                 "foreach item $items { package require ForeachDep 1.0 }",
18849:                 "tcl8.6",
18850:                 "ForeachDep",
18851:             ),
18852:             (
18853:                 "lmap item $items { package require LmapDep 1.0 }",
18854:                 "tcl8.6",
18855:                 "LmapDep",
18856:             ),
18857:             (
18858:                 "dict for {key value} {} { package require DictForDep 1.0 }",
18859:                 "tcl8.6",
18860:                 "DictForDep",
18861:             ),
18862:             (
18863:                 "dict map {key value} {} { package require DictMapDep 1.0 }",
18864:                 "tcl8.6",
18865:                 "DictMapDep",
18866:             ),
18867:             (
18868:                 "::tcl::dict::for {key value} {} { package require QualifiedDictForDep 1.0 }",
18869:                 "tcl8.6",
18870:                 "QualifiedDictForDep",
18871:             ),
18872:             (
18873:                 "array for {key value} values { package require ArrayForDep 1.0 }",
18874:                 "tcl9.0",
18875:                 "ArrayForDep",
18876:             ),
18877:             (
18878:                 "switch $kind a { package require SwitchDep 1.0 }",
18879:                 "tcl8.6",
18880:                 "SwitchDep",
18881:             ),
18882:             (
18883:                 "timerate { package require TimerateDep 1.0 } 10 1",
18884:                 "tcl9.0",
18885:                 "TimerateDep",
18886:             ),
18887:         ];
18888:         for (source, dialect, name) in cases {
18889:             let mut a = crate::analyser::Analyser::new();
18890:             let r = a.analyse(source, dialect);
18891:             let p = r
18892:                 .package_requires
18893:                 .iter()
18894:                 .find(|p| p.name == name)
18895:                 .unwrap_or_else(|| panic!("missing {name} from {source:?}"));
18896:             assert!(
18897:                 p.control_flow,
18898:                 "{name} is inside a skippable or repeatable body: {source:?}",
18899:             );
18900:         }
18901:     }
18902: 
18903:     #[test]
18904:     fn analyse_marks_only_the_repeatable_for_scripts_as_control_flow() {
18905:         let mut a = crate::analyser::Analyser::new();
18906:         let r = a.analyse(
18907:             "for {package require InitDep 1.0} {$enabled} \
18908:              {package require NextDep 1.0} {package require BodyDep 1.0}\n\
18909:              package require TailDep 1.0",
18910:             "tcl8.6",
18911:         );
18912:         let flags: Vec<_> = r
18913:             .package_requires
18914:             .iter()
18915:             .map(|p| (p.name.as_str(), p.control_flow))
18916:             .collect();
18917:         assert_eq!(
18918:             flags,
18919:             [
18920:                 ("InitDep", false),
18921:                 ("NextDep", true),
18922:                 ("BodyDep", true),
18923:                 ("TailDep", false),
18924:             ],
18925:         );
18926:     }
18927: 
18928:     #[test]
18929:     fn analyse_records_package_require_exact_flag() {
18930:         let mut a = crate::analyser::Analyser::new();
18931:         let r = a.analyse("package require -exact Tcl 8.6", "tcl");
18932:         let p = &r.package_requires[0];
18933:         assert_eq!(p.name, "Tcl");
18934:         assert_eq!(p.version.as_deref(), Some("8.6"));
18935:         // TP: the flag reaches the record, so the resolver can
18936:         // narrow `8.6` to the degenerate range `8.6-8.6`.
18937:         assert!(p.exact);
18938:         // A lone `-exact` is the option with no package after it — tclsh
18939:         // 8.4–9.0: `wrong # args` (`PkgRequireCore` compares the word with
18940:         // `strcmp(…, "-exact")` whatever follows) — so nothing is required.
18941:         let r = a.analyse("package require -exact", "tcl");
18942:         assert!(r.package_requires.is_empty(), "{:?}", r.package_requires);
18943:         // FP guard — only the exact spelling is the flag: `-e` is not
18944:         // `-exact` (tclsh: `package require -e Tcl` asks for a package named
18945:         // `-e`). The registry's option scan reads a dash word naming no
18946:         // option as a call Tcl rejects, so the layout is unproven and no
18947:         // requirement — exact or not — is recorded for it.
18948:         let r = a.analyse("package require -e 1.0", "tcl");
18949:         assert!(
18950:             !r.package_requires.iter().any(|p| p.exact),
18951:             "{:?}",
18952:             r.package_requires
18953:         );
18954:     }
18955: 
18956:     /// `package ifneeded NAME VER SCRIPT` registers a load script; the
18957:     /// two-word query form registers nothing.
18958:     #[test]
18959:     fn analyse_records_package_ifneeded_registrations_only() {
18960:         let mut a = crate::analyser::Analyser::new();
18961:         // TP — the setter form, the shape every `pkgIndex.tcl` writes.
18962:         let r = a.analyse(
18963:             "package ifneeded base64 2.5 [list source [file join $dir base64.tcl]]",
18964:             "tcl",
18965:         );
18966:         assert_eq!(r.package_ifneededs.len(), 1);
18967:         assert_eq!(r.package_ifneededs[0].name, "base64");
18968:         assert_eq!(r.package_ifneededs[0].version, "2.5");
18969:         // TP — a braced script body is equally a registration.
18970:         let r = a.analyse("package ifneeded mylib 1.0 {source lib.tcl}", "tcl");
18971:         assert_eq!(r.package_ifneededs.len(), 1);
18972:         // TN — the two-word form is a *query*; it registers nothing, so a
18973:         // document that merely asks what is registered must not be read as
18974:         // making the package's loading dynamic.
18975:         let r = a.analyse("package ifneeded base64 2.5", "tcl");
18976:         assert_eq!(
18977:             r.package_ifneededs,
18978:             [] as [crate::analyser::types::PackageIfneeded; 0]
18979:         );
18980:     }
18981: 
18982:     /// `package prefer latest` is recorded; every other spelling of the
18983:     /// subcommand changes no state and is not.
18984:     #[test]
18985:     fn analyse_records_package_prefer_latest() {
18986:         let mut a = crate::analyser::Analyser::new();
18987:         // TP — the one transition that exists.
18988:         let r = a.analyse("package prefer latest", "tcl");
18989:         assert_eq!(r.package_prefer_latest.len(), 1);
18990:         assert!(!r.package_prefer_latest[0].conditional);
18991:         // TP — inside a guarded branch the record carries `conditional`, so a
18992:         // consumer can refuse to flip the selection rule on it.
18993:         let r = a.analyse("catch {package prefer latest}", "tcl");
18994:         assert_eq!(r.package_prefer_latest.len(), 1);
18995:         assert!(r.package_prefer_latest[0].conditional);
18996:         // TN — `stable` is a no-op from the default and silently ineffective
18997:         // afterwards; the bare form is a query; a dynamic mode word is not
18998:         // guessed at.
18999:         for src in [
19000:             "package prefer stable",
19001:             "package prefer",
19002:             "package prefer $mode",
19003:             "package prefer [mode]",
19004:         ] {
19005:             let r = a.analyse(src, "tcl");
19006:             assert_eq!(r.package_prefer_latest.len(), 0, "{src}");
19007:         }
19008:     }
19009: 
19010:     #[test]
19011:     fn analyse_w123_suppressed_when_package_require_seen() {
19012:         // W123 is suppressed when any package require is on
19013:         // file — package may load arbitrary commands.
19014:         let mut a = crate::analyser::Analyser::new();
19015:         let r = a.analyse("package require Foo\nbogus_command arg", "tcl");
19016:         assert!(!r.diagnostics.iter().any(|d| d.code == DiagCode::W123));
19017:     }
19018: 
19019:     #[test]
19020:     fn analyse_w123_suppressed_when_unknown_proc_chains_original() {
19021:         // ``proc unknown`` that chains the original handler is
19022:         // a *dynamic* shape — W123 is suppressed entirely
19023:         // because runtime can resolve any command name.
19024:         let mut a = crate::analyser::Analyser::new();
19025:         let r = a.analyse(
19026:             "proc unknown {cmd args} { _original_unknown $cmd {*}$args }\nbogus_command arg",
19027:             "tcl",
19028:         );
19029:         assert!(!r.diagnostics.iter().any(|d| d.code == DiagCode::W123));
19030:     }
19031: 
19032:     #[test]
19033:     fn analyse_w123_suppressed_for_every_chain_spelling_of_the_handler() {
19034:         // `chains_original` is the registry's
19035:         // `Traits::UNRESOLVED_COMMAND_HANDLER`, so every spelling of the
19036:         // handler counts.  The old `CHAIN_TARGETS` list named the `tcl::`
19037:         // pair by hand and omitted `unknown` / `::unknown` entirely, so a
19038:         // handler chaining through the plain spelling read as
19039:         // self-contained and every unresolved command in the file collected
19040:         // a spurious W123.
19041:         for chain in ["unknown", "::unknown", "::tcl::unknown", "_orig_unknown"] {
19042:             let mut a = crate::analyser::Analyser::new();
19043:             let src =
19044:                 format!("proc unknown {{cmd args}} {{ {chain} $cmd {{*}}$args }}\nbogus_cmd arg");
19045:             let r = a.analyse(&src, "tcl");
19046:             assert!(
19047:                 !r.diagnostics.iter().any(|d| d.code == DiagCode::W123),
19048:                 "chaining through {chain} should suppress W123",
19049:             );
19050:         }
19051:     }
19052: 
19053:     #[test]
19054:     fn analyse_w123_suppressed_when_unknown_proc_calls_exec() {
19055:         // ``exec $cmd`` inside ``unknown`` is a dynamic shape;
19056:         // any command may be a real binary on PATH.
19057:         let mut a = crate::analyser::Analyser::new();
19058:         let r = a.analyse(
19059:             "proc unknown {cmd args} { exec $cmd {*}$args }\nbogus_command arg",
19060:             "tcl",
19061:         );
19062:         assert!(!r.diagnostics.iter().any(|d| d.code == DiagCode::W123));
19063:     }
19064: 
19065:     #[test]
19066:     fn analyse_w123_still_fires_outside_explicit_dispatch_targets() {
19067:         // ``proc unknown`` with ONLY explicit dispatch targets
19068:         // (no exec / auto_load / chain / pattern / case-fold)
19069:         // is *not* dynamic — W123 should still fire for
19070:         // commands not in the explicit target set.
19071:         let mut a = crate::analyser::Analyser::new();
19072:         let r = a.analyse(
19073:             "proc unknown {cmd args} { switch -exact $cmd { foo { return 1 } } }\nbogus_command arg",
19074:             "tcl",
19075:         );
19076:         assert!(
19077:             r.diagnostics.iter().any(|d| d.code == DiagCode::W123),
19078:             "W123 expected for ``bogus_command`` outside explicit dispatch targets; got {:?}",
19079:             r.diagnostics,
19080:         );
19081:     }
19082: 
19083:     #[test]
19084:     fn analyse_w123_suppressed_for_explicit_dispatch_target() {
19085:         // ``foo`` is in the explicit dispatch_targets — even
19086:         // for the non-dynamic shape, the per-invocation loop
19087:         // suppresses W123 for it.
19088:         let mut a = crate::analyser::Analyser::new();
19089:         let r = a.analyse(
19090:             "proc unknown {cmd args} { switch -exact $cmd { foo { return 1 } } }\nfoo arg",
19091:             "tcl",
19092:         );
19093:         assert!(
19094:             !r.diagnostics
19095:                 .iter()
19096:                 .any(|d| d.code == DiagCode::W123 && d.message.contains("'foo'")),
19097:             "W123 should not fire for command listed in dispatch_targets; got {:?}",
19098:             r.diagnostics,
19099:         );
19100:     }
19101: 
19102:     #[test]
19103:     fn analyse_w123_still_fires_for_empty_unknown_stub() {
19104:         // An empty ``unknown`` stub resolves nothing — W123
19105:         // should still emit.
19106:         let mut a = crate::analyser::Analyser::new();
19107:         let r = a.analyse("proc unknown {cmd args} {}\nbogus_command arg", "tcl");
19108:         // ``bogus_command`` should be flagged.
19109:         assert!(r.diagnostics.iter().any(|d| d.code == DiagCode::W123));
19110:     }
19111: 
19112:     // deep_param_traits plumbing
19113:     //
19114:     // These tests pin the contract that flipping
19115:     // `Analyser::deep_param_traits` actually changes the
19116:     // `ProcDef.param_traits` surface: the shallow pass alone
19117:     // misses traits hidden inside braced bodies, the deep pass
19118:     // catches them, and the union of both is what the analyser
19119:     // exposes.  The call-graph / symbol-graph / dataflow-graph /
19120:     // semantic-graph builders flip this on.
19121: 
19122:     #[test]
19123:     fn analyse_with_deep_param_traits_surfaces_nested_eval() {
19124:         // `$body` is buried inside a `foreach` body — the
19125:         // shallow pass walks only top-level commands and misses
19126:         // it.  Flipping `deep_param_traits` on must surface
19127:         // `Eval`.
19128:         let source = "proc f {items body} {\n  foreach item $items {\n    uplevel 1 $body\n  }\n}";
19129:         let mut shallow = crate::analyser::Analyser::new();
19130:         let shallow_r = shallow.analyse(source, "tcl");
19131:         let shallow_proc = shallow_r.all_procs.get("::f").expect("::f proc registered");
19132:         let shallow_body_traits = shallow_proc.param_traits.get("body");
19133:         assert!(
19134:             !shallow_body_traits.is_some_and(|s| s.contains(&crate::analyser::ProcArgTrait::Eval)),
19135:             "shallow pass should miss nested Eval, got {shallow_body_traits:?}",
19136:         );
19137: 
19138:         let mut deep = crate::analyser::Analyser::new();
19139:         deep.deep_param_traits = true;
19140:         let deep_r = deep.analyse(source, "tcl");
19141:         let deep_proc = deep_r.all_procs.get("::f").expect("::f proc registered");
19142:         let deep_body_traits = deep_proc
19143:             .param_traits
19144:             .get("body")
19145:             .expect("body traits present with deep_param_traits on");
19146:         assert!(
19147:             deep_body_traits.contains(&crate::analyser::ProcArgTrait::Eval),
19148:             "deep pass should surface nested Eval, got {deep_body_traits:?}",
19149:         );
19150:     }
19151: 
19152:     #[test]
19153:     fn analyse_with_deep_param_traits_off_matches_shallow() {
19154:         // For procs without nested-body usage, deep + shallow
19155:         // produce the same trait map.  This pins that the deep
19156:         // pass doesn't accidentally lose any shallow trait.
19157:         let source = "proc g {body} { uplevel 1 $body }";
19158:         let mut shallow = crate::analyser::Analyser::new();
19159:         let shallow_r = shallow.analyse(source, "tcl");
19160: 
19161:         let mut deep = crate::analyser::Analyser::new();
19162:         deep.deep_param_traits = true;
19163:         let deep_r = deep.analyse(source, "tcl");
19164: 
19165:         let shallow_traits = shallow_r
19166:             .all_procs
19167:             .get("::g")
19168:             .expect("::g registered")
19169:             .param_traits
19170:             .clone();
19171:         let deep_traits = deep_r
19172:             .all_procs
19173:             .get("::g")
19174:             .expect("::g registered")
19175:             .param_traits
19176:             .clone();
19177:         assert_eq!(
19178:             shallow_traits, deep_traits,
19179:             "deep + shallow should match for top-level-only bodies",
19180:         );
19181:     }
19182: 
19183:     #[test]
19184:     fn uplevel_nonzero_isolates_body_vars_from_proc() {
19185:         // `uplevel 1 {set x 5}` runs in the caller's frame, not the enclosing
19186:         // proc's — its `x` must not merge into the proc's locals (they are
19187:         // different variables), and it lands in an isolated `Uplevel` child
19188:         // scope tagged with the level word.
19189:         let mut a = crate::analyser::Analyser::new();
19190:         let r = a.analyse(
19191:             "proc f {} {\n    uplevel 1 {set x 5}\n    set y 1\n}\n",
19192:             "tcl8.6",
19193:         );
19194:         let f_scope = r
19195:             .global_scope
19196:             .children
19197:             .iter()
19198:             .find(|c| c.name == "f")
19199:             .expect("f proc scope");
19200:         assert!(f_scope.variables.contains_key("y"), "y is a proc local");
19201:         assert!(
19202:             !f_scope.variables.contains_key("x"),
19203:             "uplevel body's `x` must not merge into the proc scope",
19204:         );
19205:         let up = f_scope
19206:             .children
19207:             .iter()
19208:             .find(|c| c.kind == crate::analyser::ScopeKind::Uplevel)
19209:             .expect("isolated uplevel scope");
19210:         assert_eq!(up.name, "1", "the level word tags the frame");
19211:         assert!(up.variables.contains_key("x"));
19212:     }
19213: 
19214:     #[test]
19215:     fn nested_def_in_qualified_encloser_does_not_overwrite_global() {
19216:         // `proc a::outer { proc helper ... }`: the nested `helper` homes to the
19217:         // encloser's *defining* namespace (`::a::helper`), not the lexical
19218:         // global — so the real global `proc helper` is preserved rather than
19219:         // overwritten in `all_procs`.
19220:         let mut a = crate::analyser::Analyser::new();
19221:         let r = a.analyse(
19222:             "proc helper {} { puts global }\nproc a::outer {} {\n    proc helper {} { puts nested }\n}\n",
19223:             "tcl8.6",
19224:         );
19225:         assert!(
19226:             r.all_procs.contains_key("::a::helper"),
19227:             "nested helper must home to ::a::helper: {:?}",
19228:             r.all_procs.keys().collect::<Vec<_>>(),
19229:         );
19230:         let global = r
19231:             .all_procs
19232:             .get("::helper")
19233:             .expect("global ::helper preserved");
19234:         assert_eq!(
19235:             global.name_span.start(),
19236:             5,
19237:             "::helper must remain the global declaration (line 0), not the nested one",
19238:         );
19239:         // The same for a nested class.
19240:         let mut b = crate::analyser::Analyser::new();
19241:         let rc = b.analyse(
19242:             "oo::class create Widget {}\nproc a::outer {} {\n    oo::class create Widget {}\n}\n",
19243:             "tcl8.6",
19244:         );
19245:         assert!(
19246:             rc.all_classes.contains_key("::a::Widget"),
19247:             "nested class homes to ::a::Widget: {:?}",
19248:             rc.all_classes.keys().collect::<Vec<_>>(),
19249:         );
19250:         assert!(
19251:             rc.all_classes.contains_key("::Widget"),
19252:             "global ::Widget preserved",
19253:         );
19254:     }
19255: 
19256:     #[test]
19257:     fn variable_global_upvar_skip_dynamic_names() {
19258:         // A `variable` / `global` / `upvar` / `namespace upvar` whose name word
19259:         // is computed (`$dyn` / `[f]`) is not a static declaration — the literal
19260:         // substitution text must not be recorded as a variable.
19261:         let mut a = crate::analyser::Analyser::new();
19262:         let r = a.analyse(
19263:             "namespace eval ns {\n    variable $dyn\n    variable realvar 1\n}\nproc p {} {\n    global $g\n    upvar 1 other $loc\n}\n",
19264:             "tcl8.6",
19265:         );
19266:         let ns = r
19267:             .global_scope
19268:             .children
19269:             .iter()
19270:             .find(|c| c.name == "ns")
19271:             .expect("ns scope");
19272:         assert!(
19273:             ns.variables.contains_key("realvar"),
19274:             "a static `variable` name is still recorded",
19275:         );
19276:         assert!(
19277:             !ns.variables.contains_key("dyn"),
19278:             "`variable $dyn` must not record `dyn`: {:?}",
19279:             ns.variables.keys().collect::<Vec<_>>(),
19280:         );
19281:         let p = r
19282:             .global_scope
19283:             .children
19284:             .iter()
19285:             .find(|c| c.name == "p")
19286:             .expect("p scope");
19287:         assert!(
19288:             !p.variables.contains_key("g") && !p.variables.contains_key("loc"),
19289:             "dynamic `global`/`upvar` names must not be recorded: {:?}",
19290:             p.variables.keys().collect::<Vec<_>>(),
19291:         );
19292:     }
19293: 
19294:     #[test]
19295:     fn uplevel_zero_still_resets_to_global_frame() {
19296:         // `uplevel #0` keeps the global-frame tag so variable resolution
19297:         // resolves outward to the global namespace (not the caller-frame
19298:         // abstention a non-`#0` level uses).
19299:         let mut a = crate::analyser::Analyser::new();
19300:         let r = a.analyse("proc g {} {\n    uplevel #0 {set z 5}\n}\n", "tcl8.6");
19301:         let g_scope = r
19302:             .global_scope
19303:             .children
19304:             .iter()
19305:             .find(|c| c.name == "g")
19306:             .expect("g proc scope");
19307:         let up = g_scope
19308:             .children
19309:             .iter()
19310:             .find(|c| c.kind == crate::analyser::ScopeKind::Uplevel)
19311:             .expect("uplevel scope");
19312:         assert_eq!(up.name, "#0");
19313:         assert!(up.variables.contains_key("z"));
19314:     }
19315: 
19316:     // stub-overlay end-to-end
19317:     //
19318:     // These tests pin the contract that the stub overlay built
19319:     // from `# tcl-lsp: stub` directives during `analyse()`
19320:     // propagates into the per-proc `param_traits` map.
19321: 
19322:     #[test]
19323:     fn analyse_with_declared_stub_propagates_role_to_param_traits() {
19324:         // The source declares a `# tcl-lsp: stub my_eval
19325:         // {script:body}` directive, then defines a proc that
19326:         // invokes `my_eval $body`.  The body arg's role flows
19327:         // from the stub overlay → `param_traits["body"]
19328:         // .contains(Body)`.
19329:         let source = "\
19330: # tcl-lsp: stubs-begin\n\
19331: # tcl-lsp: stub my_eval {script:body}\n\
19332: # tcl-lsp: stubs-end\n\
19333: proc runs {body} {\n\
19334:     my_eval $body\n\
19335: }\n";
19336:         let mut a = crate::analyser::Analyser::new();
19337:         let r = a.analyse(source, "tcl");
19338:         let proc = r.all_procs.get("::runs").expect("::runs registered");
19339:         let body_traits = proc
19340:             .param_traits
19341:             .get("body")
19342:             .expect("body param has traits");
19343:         assert!(
19344:             body_traits.contains(&crate::analyser::ProcArgTrait::Body),
19345:             "expected Body trait via stub overlay, got {body_traits:?}",
19346:         );
19347:     }
19348: 
19349:     #[test]
19350:     fn analyse_without_stub_directive_leaves_body_untyped() {
19351:         // Same proc, no stub directive — without the overlay
19352:         // entry, `my_eval` isn't a known command, so the body
19353:         // arg has no recorded role and `param_traits` is empty
19354:         // for `body`.  This pins that the stub directive (not
19355:         // some background heuristic) is what gives the
19356:         // parameter its `Body` trait.
19357:         let source = "proc runs {body} { my_eval $body }";
19358:         let mut a = crate::analyser::Analyser::new();
19359:         let r = a.analyse(source, "tcl");
19360:         let proc = r.all_procs.get("::runs").expect("::runs registered");
19361:         assert!(
19362:             !proc
19363:                 .param_traits
19364:                 .get("body")
19365:                 .is_some_and(|s| s.contains(&crate::analyser::ProcArgTrait::Body)),
19366:             "expected NO Body trait without stub directive, got {:?}",
19367:             proc.param_traits.get("body"),
19368:         );
19369:     }
19370: 
19371:     // Safe-interp visibility survives `analyse_per_item`.
19372: 
19373:     /// Conditional source visibility, independently of actual dispatch.
19374:     /// Original command/list operands and the enclosing source child are required.
19375:     #[test]
19376:     fn safe_interp_w129_reaches_deferred_proc_body_under_per_item_1001() {
19377:         let mut a = Analyser::new();
19378:         let r = a.analyse_per_item(
19379:             "interp create -safe s\ninterp eval s { proc f {} { source foo }; f }\n",
19380:             "tcl8.6",
19381:         );
19382:         assert!(
19383:             r.diagnostics
19384:                 .iter()
19385:                 .any(|d| d.code == tcl_core_types::DiagCode::W129
19386:                     && d.conditional_interpreter_visibility().is_some()),
19387:             "a hidden call inside a deferred proc body warns under \
19388:              incremental (per-item) analysis, matching `Analyser::analyse`: {:?}",
19389:             r.diagnostics
19390:         );
19391:     }
19392: 
19393:     /// Conditional source visibility, independently of actual dispatch.
19394:     /// Original command/list operands and the enclosing source child are required.
19395:     #[test]
19396:     fn safe_interp_w129_reaches_deferred_apply_body_under_per_item_1001() {
19397:         // naming.interpreter.original-source-visibility-advice
19398:         // docs/design/analysis/name-resolution-proofs/interpreter-original-source-visibility-advice.md
19399:         let mut a = Analyser::new();
19400:         let r = a.analyse_per_item(
19401:             "interp create -safe s\ninterp eval s { apply {{} { source foo }} }\n",
19402:             "tcl8.6",
19403:         );
19404:         assert!(
19405:             r.diagnostics
19406:                 .iter()
19407:                 .any(|d| d.code == tcl_core_types::DiagCode::W129
19408:                     && d.conditional_interpreter_visibility().is_some()),
19409:             "a hidden call inside a deferred apply-lambda body warns under \
19410:              incremental (per-item) analysis: {:?}",
19411:             r.diagnostics
19412:         );
19413:     }
19414: 
19415:     /// Conditional source visibility, independently of actual dispatch.
19416:     /// Original command/list operands and the enclosing source child are required.
19417:     #[test]
19418:     fn safe_interp_w129_reaches_deferred_method_body_under_per_item_1001() {
19419:         // naming.interpreter.original-source-visibility-advice
19420:         // docs/design/analysis/name-resolution-proofs/interpreter-original-source-visibility-advice.md
19421:         let mut a = Analyser::new();
19422:         let r = a.analyse_per_item(
19423:             "interp create -safe s\n\
19424:              interp eval s {\n\
19425:                  oo::class create C { method m {} { source foo } }\n\
19426:                  [C new] m\n\
19427:              }\n",
19428:             "tcl8.6",
19429:         );
19430:         assert!(
19431:             r.diagnostics
19432:                 .iter()
19433:                 .any(|d| d.code == tcl_core_types::DiagCode::W129
19434:                     && d.conditional_interpreter_visibility().is_some()),
19435:             "a hidden call inside a deferred TclOO method body warns under \
19436:              incremental (per-item) analysis: {:?}",
19437:             r.diagnostics
19438:         );
19439:     }
19440: 
19441:     /// Conditional source visibility, independently of actual dispatch.
19442:     /// Original command/list operands and the enclosing source child are required.
19443:     #[test]
19444:     fn deferred_proc_body_outside_any_safe_interp_is_untouched_under_per_item_1001() {
19445:         let mut a = Analyser::new();
19446:         let r = a.analyse_per_item("proc f {} { source foo }\nf\n", "tcl8.6");
19447:         assert!(
19448:             !r.diagnostics
19449:                 .iter()
19450:                 .any(|d| d.code == tcl_core_types::DiagCode::W129),
19451:             "no safe interpreter is involved, so no W129 can ever fire: {:?}",
19452:             r.diagnostics
19453:         );
19454:     }
19455: 
19456:     /// Conditional source visibility, independently of actual dispatch.
19457:     /// Original command/list operands and the enclosing source child are required.
19458:     #[test]
19459:     fn safe_interp_deferred_body_redefinition_updates_its_source_visibility() {
19460:         let mut a = Analyser::new();
19461:         let r = a.analyse_per_item(
19462:             "interp create -safe s\n\
19463:              interp eval s {\n\
19464:                  proc f {} { proc source {} { return ok }; source }\n\
19465:                  f\n\
19466:              }\n",
19467:             "tcl8.6",
19468:         );
19469:         assert!(
19470:             !r.diagnostics
19471:                 .iter()
19472:                 .any(|d| d.code == tcl_core_types::DiagCode::W129),
19473:             "the deferred body retains its own original source definition before the later call: {:?}",
19474:             r.diagnostics
19475:         );
19476:     }
19477: 
19478:     /// Conditional source visibility, independently of actual dispatch.
19479:     /// Original command/list operands and the enclosing source child are required.
19480:     #[test]
19481:     fn safe_interp_w129_expand_list_quoted_apply_lambda_body_1001() {
19482:         let mut a = Analyser::new();
19483:         let r = a.analyse(
19484:             "interp create -safe s\n\
19485:              interp eval s { {*}[list apply {dir {source $dir/evil.tcl}} $env(HOME)] }\n",
19486:             "tcl8.6",
19487:         );
19488:         assert!(
19489:             r.diagnostics
19490:                 .iter()
19491:                 .any(|d| d.code == tcl_core_types::DiagCode::W129
19492:                     && d.conditional_interpreter_visibility().is_some()),
19493:             "hidden `source` nested inside a `{{*}}[list apply ...]`-invoked \
19494:              lambda body warns: {:?}",
19495:             r.diagnostics
19496:         );
19497:     }
19498: 
19499:     /// Conditional source visibility, independently of actual dispatch.
19500:     /// Original command/list operands and the enclosing source child are required.
19501:     #[test]
19502:     fn safe_interp_w129_list_quoted_apply_package_ifneeded_then_require_1001() {
19503:         let mut a = Analyser::new();
19504:         let r = a.analyse(
19505:             "interp create -safe s\n\
19506:              interp eval s {\n\
19507:                  package ifneeded evil 1.0 [list apply {dir {source $dir/evil.tcl}} $env(HOME)]\n\
19508:                  package require evil\n\
19509:              }\n",
19510:             "tcl8.6",
19511:         );
19512:         assert!(
19513:             r.diagnostics
19514:                 .iter()
19515:                 .any(|d| d.code == tcl_core_types::DiagCode::W129
19516:                     && d.conditional_interpreter_visibility().is_some()),
19517:             "the deferred script's hidden `source` warns once `package \
19518:              require` is present too: {:?}",
19519:             r.diagnostics
19520:         );
19521:     }
19522: 
19523:     // Namespace ensemble -map redirection.
19524: 
19525:     /// Conditional source visibility, independently of actual dispatch.
19526:     /// A reporting ensemble map does not own the original mapped target.
19527:     #[test]
19528:     fn safe_interp_w129_ensemble_create_map_redirect_to_hidden_command_1001() {
19529:         let mut a = Analyser::new();
19530:         let r = a.analyse(
19531:             "interp create -safe s\n\
19532:              interp eval s {\n\
19533:                  namespace ensemble create -command myens -map {go source}\n\
19534:                  myens go pkg.tcl\n\
19535:              }\n",
19536:             "tcl8.6",
19537:         );
19538:         assert!(
19539:             !r.diagnostics
19540:                 .iter()
19541:                 .any(|d| d.code == tcl_core_types::DiagCode::W129),
19542:             "a reporting map does not supply an original mapped-target receipt: {:?}",
19543:             r.diagnostics
19544:         );
19545:     }
19546: 
19547:     /// Conditional source visibility, independently of actual dispatch.
19548:     /// A reporting ensemble map does not own the original mapped target.
19549:     #[test]
19550:     fn safe_interp_w129_ensemble_configure_map_redirect_to_hidden_command_1001() {
19551:         let mut a = Analyser::new();
19552:         let r = a.analyse(
19553:             "interp create -safe s\n\
19554:              interp eval s {\n\
19555:                  namespace ensemble create -command myens\n\
19556:                  namespace ensemble configure myens -map {go source}\n\
19557:                  myens go pkg.tcl\n\
19558:              }\n",
19559:             "tcl8.6",
19560:         );
19561:         assert!(
19562:             !r.diagnostics
19563:                 .iter()
19564:                 .any(|d| d.code == tcl_core_types::DiagCode::W129),
19565:             "a reporting map does not supply an original mapped-target receipt: {:?}",
19566:             r.diagnostics
19567:         );
19568:     }
19569: 
19570:     /// Conditional source visibility, independently of actual dispatch.
19571:     /// A reporting ensemble map does not own the original mapped target.
19572:     #[test]
19573:     fn safe_interp_w129_ensemble_default_name_map_redirect_to_hidden_command_1001() {
19574:         let mut a = Analyser::new();
19575:         let r = a.analyse(
19576:             "interp create -safe s\n\
19577:              interp eval s {\n\
19578:                  namespace eval myns { namespace ensemble create -map {go source} }\n\
19579:                  myns go pkg.tcl\n\
19580:              }\n",
19581:             "tcl8.6",
19582:         );
19583:         assert!(
19584:             !r.diagnostics
19585:                 .iter()
19586:                 .any(|d| d.code == tcl_core_types::DiagCode::W129),
19587:             "a reporting map does not supply an original mapped-target receipt: {:?}",
19588:             r.diagnostics
19589:         );
19590:     }
19591: 
19592:     /// Conditional source visibility, independently of actual dispatch.
19593:     /// A reporting ensemble map does not own the original mapped target.
19594:     #[test]
19595:     fn safe_interp_w129_ensemble_map_redirect_to_safe_command_not_flagged_1001() {
19596:         let mut a = Analyser::new();
19597:         let r = a.analyse(
19598:             "interp create -safe s\n\
19599:              interp eval s {\n\
19600:                  namespace ensemble create -command myens -map {go puts}\n\
19601:                  myens go hi\n\
19602:              }\n",
19603:             "tcl8.6",
19604:         );
19605:         assert!(
19606:             !r.diagnostics
19607:                 .iter()
19608:                 .any(|d| d.code == tcl_core_types::DiagCode::W129),
19609:             "an ensemble redirect to a safe command must not warn: {:?}",
19610:             r.diagnostics
19611:         );
19612:     }
19613: 
19614:     /// Conditional source visibility, independently of actual dispatch.
19615:     /// A reporting ensemble map does not own the original mapped target.
19616:     #[test]
19617:     fn ensemble_map_redirect_outside_any_safe_interp_is_untouched_1001() {
19618:         let mut a = Analyser::new();
19619:         let r = a.analyse(
19620:             "namespace ensemble create -command myens -map {go source}\n\
19621:              myens go pkg.tcl\n",
19622:             "tcl8.6",
19623:         );
19624:         assert!(
19625:             !r.diagnostics
19626:                 .iter()
19627:                 .any(|d| d.code == tcl_core_types::DiagCode::W129),
19628:             "no safe interpreter is involved, so no W129 can ever fire: {:?}",
19629:             r.diagnostics
19630:         );
19631:     }
19632: 
19633:     /// Conditional source visibility, independently of actual dispatch.
19634:     /// A reporting ensemble map does not own the original mapped target.
19635:     #[test]
19636:     fn safe_interp_w129_ensemble_map_redirect_multiword_target_1001() {
19637:         let mut a = Analyser::new();
19638:         let r = a.analyse(
19639:             "interp create -safe s\n\
19640:              interp eval s {\n\
19641:                  namespace ensemble create -command myens -map {go {source b.tcl}}\n\
19642:                  myens go\n\
19643:              }\n",
19644:             "tcl8.6",
19645:         );
19646:         assert!(
19647:             !r.diagnostics
19648:                 .iter()
19649:                 .any(|d| d.code == tcl_core_types::DiagCode::W129),
19650:             "a multiword reporting prefix does not own its effective head: {:?}",
19651:             r.diagnostics
19652:         );
19653:     }
19654: 
19655:     /// Conditional source visibility, independently of actual dispatch.
19656:     /// A reporting ensemble map does not own the original mapped target.
19657:     #[test]
19658:     fn safe_interp_w129_ensemble_configure_map_replaces_not_merges_1001() {
19659:         let mut a = Analyser::new();
19660:         let r = a.analyse(
19661:             "interp create -safe s\n\
19662:              interp eval s {\n\
19663:                  namespace ensemble create -command myens \
19664:                      -map {bad source ok puts}\n\
19665:                  namespace ensemble configure myens -map {ok puts}\n\
19666:                  myens bad\n\
19667:              }\n",
19668:             "tcl8.6",
19669:         );
19670:         assert!(
19671:             !r.diagnostics
19672:                 .iter()
19673:                 .any(|d| d.code == tcl_core_types::DiagCode::W129),
19674:             "a subcommand dropped by a later `-map` must not keep warning \
19675:              through its stale mapping: {:?}",
19676:             r.diagnostics
19677:         );
19678:     }
19679: }
/* ORIGINAL_SOURCE_RANGE 19681..19710 */
19681: #[cfg(test)]
19682: mod original_native_namespace_path_tests {
19683:     use crate::analyser::Analyser;
19684: 
19685:     #[test]
19686:     fn original_namespace_path_retains_all_native_children_after_quoted_escape_rendering() {
19687:         let source =
19688:             r#"namespace eval ::first {}; namespace path "::first ::opaque\uD800 ::third""#;
19689:         let result = Analyser::new().analyse(source, "tcl8.6");
19690:         let values = result
19691:             .namespace_refs
19692:             .iter()
19693:             .filter_map(|reference| reference.original_name_input.as_ref())
19694:             .filter(|input| {
19695:                 input
19696:                     .original_static_list_container()
19697:                     .is_some_and(|container| !container.ordinals().is_empty())
19698:             })
19699:             .map(|input| input.bytes().to_vec())
19700:             .collect::<Vec<_>>();
19701:         assert_eq!(
19702:             values,
19703:             [
19704:                 b"::first".to_vec(),
19705:                 b"::opaque\xed\xa0\x80".to_vec(),
19706:                 b"::third".to_vec()
19707:             ]
19708:         );
19709:     }
19710: }
/* ORIGINAL_SOURCE_RANGE 19712..19760 */
19712: #[cfg(test)]
19713: mod original_static_declaration_tests {
19714:     use crate::analyser::Analyser;
19715:     use tcl_lexer::SourceImage;
19716: 
19717:     #[test]
19718:     fn original_nested_procedure_metadata_retains_full_source_words_and_namespace_geometry() {
19719:         let source = r"namespace eval N {proc p\uD800 {} {return A}; proc p\uD801 {} {return B}}";
19720:         let mut result = Analyser::new().analyse(source, "tcl8.6");
19721:         let declarations = result.original_procedure_declarations().collect::<Vec<_>>();
19722:         assert_eq!(declarations.len(), 2);
19723:         assert_ne!(declarations[0].name().slot(), declarations[1].name().slot());
19724:         for (declaration, written, bytes) in [
19725:             (declarations[0], r"p\uD800", b"p\xed\xa0\x80".as_slice()),
19726:             (declarations[1], r"p\uD801", b"p\xed\xa0\x81".as_slice()),
19727:         ] {
19728:             assert_eq!(declaration.name_input().bytes(), bytes);
19729:             assert_eq!(
19730:                 declaration.name_input().source_image(),
19731:                 &SourceImage::document(source)
19732:             );
19733:             assert_eq!(
19734:                 declaration.name_input().span().start(),
19735:                 u32::try_from(source.find(written).unwrap()).unwrap()
19736:             );
19737:             assert_eq!(declaration.name().reported_full_name(), None);
19738:         }
19739:         let body = u32::try_from(source.find("proc p").unwrap()).unwrap();
19740:         let namespace = result.original_namespace_scope_at(body).unwrap().clone();
19741:         let input = crate::signature_scan::scope::SignatureSourceNameInput::OriginalWord(
19742:             declarations[0].name_input().clone(),
19743:         );
19744:         result.all_procs.clear();
19745:         result.global_scope.children[0].procs.clear();
19746:         assert_eq!(
19747:             result
19748:                 .procedures_for_original_name(&input, &namespace)
19749:                 .len(),
19750:             1
19751:         );
19752:     }
19753: 
19754:     #[test]
19755:     fn original_static_declaration_advice_does_not_fabricate_a_computed_word() {
19756:         let source = r"proc $unknown {} {return A}";
19757:         let result = Analyser::new().analyse(source, "tcl8.6");
19758:         assert!(result.original_procedure_declarations().next().is_none());
19759:     }
19760: }
/* ORIGINAL_SOURCE_RANGE 19762..19788 */
19762: #[cfg(test)]
19763: mod original_optlist_declaration_tests {
19764:     use crate::analyser::Analyser;
19765: 
19766:     #[test]
19767:     fn original_optlist_procedure_retains_its_name_without_fabricating_native_formals() {
19768:         let source = r"tcl::OptProc p\uD800 {{-option DEFAULT}} {return $args}";
19769:         let mut result = Analyser::new().analyse(source, "tcl8.6");
19770:         let record = result.original_procedure_declarations().next().unwrap();
19771:         assert_eq!(record.name_input().bytes(), b"p\xed\xa0\x80");
19772:         assert_eq!(record.metadata().params.len(), 1);
19773:         assert_eq!(record.metadata().params[0].name, "args");
19774:         assert!(!record.metadata().params[0].has_default);
19775:         let input = crate::signature_scan::scope::SignatureSourceNameInput::OriginalWord(
19776:             record.name_input().clone(),
19777:         );
19778:         let namespace = result.original_namespace_scope_at(0).unwrap().clone();
19779:         result.all_procs.clear();
19780:         result.global_scope.procs.clear();
19781:         assert_eq!(
19782:             result
19783:                 .procedures_for_original_name(&input, &namespace)
19784:                 .len(),
19785:             1
19786:         );
19787:     }
19788: }
/* ORIGINAL_SOURCE_RANGE 19790..20031 */
19790: #[cfg(test)]
19791: mod original_registry_symbol_tests {
19792:     use crate::analyser::Analyser;
19793: 
19794:     #[test]
19795:     fn original_registry_symbol_names_keep_opaque_inputs_without_command_identity_from_labels() {
19796:         // Implementation contract: naming.compiler.original-symbol-declaration-advice
19797:         // docs/design/analysis/name-resolution-proofs/original-symbol-declaration-advice.md
19798:         let source = r"package require tcltest; tcltest::test case\uD800 {first} -body {} -result {}; tcltest::test case\uD801 {second} -body {} -result {}";
19799:         let result = Analyser::new().analyse(source, "tcl8.6");
19800:         assert_eq!(result.all_defined_symbols.len(), 2);
19801:         let original = result
19802:             .original_symbol_declarations()
19803:             .cloned()
19804:             .collect::<Vec<_>>();
19805:         assert_eq!(original.len(), 2);
19806:         assert!(original.iter().all(|record| {
19807:             record
19808:                 .original_namespace()
19809:                 .is_some_and(crate::signature_scan::scope::SignatureNamespaceScope::is_root)
19810:         }));
19811:         assert_ne!(
19812:             original[0].name_input().bytes(),
19813:             original[1].name_input().bytes()
19814:         );
19815:         let mut cleared = result.clone();
19816:         cleared.all_defined_symbols.clear();
19817:         cleared.global_scope.defined_symbols.clear();
19818:         assert_eq!(cleared.original_symbol_declarations().count(), 2);
19819:         assert!(original.iter().all(|record| record.matches_source(
19820:             &tcl_lexer::SourceImage::document(source),
19821:             result.body_lexer_config.unwrap()
19822:         )));
19823:         assert!(original.iter().all(|record| !record.matches_source(
19824:             &tcl_lexer::SourceImage::document(&format!("# displaced\n{source}")),
19825:             result.body_lexer_config.unwrap()
19826:         )));
19827:         let inputs = result
19828:             .all_defined_symbols
19829:             .iter()
19830:             .map(|symbol| symbol.original_name_input.as_ref().unwrap().bytes())
19831:             .collect::<Vec<_>>();
19832:         assert_eq!(
19833:             inputs,
19834:             [
19835:                 b"case\xed\xa0\x80".as_slice(),
19836:                 b"case\xed\xa0\x81".as_slice()
19837:             ]
19838:         );
19839:         assert_ne!(
19840:             result.all_defined_symbols[0].name,
19841:             result.all_defined_symbols[1].name
19842:         );
19843:         let shadow = Analyser::new().analyse(
19844:             "proc ::tcltest::test args {}; tcltest::test ordinary {description} -body {}",
19845:             "tcl8.6",
19846:         );
19847:         assert!(shadow.all_defined_symbols.is_empty());
19848:     }
19849: 
19850:     #[test]
19851:     fn original_conditional_registry_symbol_cards_retain_unknown_applicability() {
19852:         // Implementation contract: naming.compiler.conditional-registry-source-metadata
19853:         // docs/design/analysis/name-resolution-proofs/conditional-registry-source-metadata.md
19854:         let source = r"package require tcltest; ::tcltest::test case\uD800 {first} -body {} -result {}; ::tcltest::test case\uD801 {second} -body {} -result {}";
19855:         let result = Analyser::new().analyse(source, "tcl8.6");
19856:         let cards = result.original_symbol_declarations().collect::<Vec<_>>();
19857:         assert_eq!(cards.len(), 2);
19858:         let registry = result.resolved_registry().unwrap();
19859:         for card in cards {
19860:             let metadata = card
19861:                 .conditional_metadata()
19862:                 .expect("unknown package execution stays explicit");
19863:             assert!(!metadata.obligations().is_empty());
19864:             assert!(metadata.matches_source(
19865:                 &tcl_lexer::SourceImage::document(source),
19866:                 result.body_lexer_config.unwrap()
19867:             ));
19868:             assert!(metadata.matches_registry(registry));
19869:             assert_eq!(
19870:                 metadata.symbol_definition().as_ref(),
19871:                 Some(card.descriptor())
19872:             );
19873:             assert!(!metadata.matches_source(
19874:                 &tcl_lexer::SourceImage::document(&format!("# changed\n{source}")),
19875:                 result.body_lexer_config.unwrap()
19876:             ));
19877:             assert!(!metadata.matches_registry(
19878:                 tcl_registry::model::ingress::static_context_for("jimtcl").commands()
19879:             ));
19880:         }
19881:         assert!(
19882:             result.original_completed_command_world().is_none(),
19883:             "source cards do not close the execution world"
19884:         );
19885:     }
19886: 
19887:     #[test]
19888:     fn original_registry_symbol_cards_retain_the_actual_namespace_geometry() {
19889:         // Implementation contract: naming.compiler.original-symbol-declaration-advice
19890:         // docs/design/analysis/name-resolution-proofs/original-symbol-declaration-advice.md
19891:         let source =
19892:             "namespace eval suite {::tcltest::test scoped {description} -body {} -result {}}";
19893:         let result = Analyser::new().analyse(source, "tcl8.6");
19894:         let cards = result.original_symbol_declarations().collect::<Vec<_>>();
19895:         assert_eq!(cards.len(), 1);
19896:         let scope = result
19897:             .global_scope
19898:             .children
19899:             .iter()
19900:             .find(|scope| scope.kind == super::super::types::ScopeKind::Namespace)
19901:             .unwrap();
19902:         assert!(cards[0].original_namespace().is_some());
19903:         assert_eq!(cards[0].original_namespace(), scope.naming_scope.as_ref());
19904:         assert!(!cards[0].original_namespace().unwrap().is_root());
19905:         assert!(cards[0].matches_source(
19906:             &tcl_lexer::SourceImage::document(source),
19907:             result.body_lexer_config.unwrap()
19908:         ));
19909:         assert!(!cards[0].matches_source(
19910:             &tcl_lexer::SourceImage::document(&format!("# changed\n{source}")),
19911:             result.body_lexer_config.unwrap()
19912:         ));
19913:     }
19914: 
19915:     #[test]
19916:     fn original_registry_symbol_advice_preserves_hosted_source_event_declarations() {
19917:         // Implementation contract: naming.compiler.original-symbol-declaration-advice
19918:         // docs/design/analysis/name-resolution-proofs/original-symbol-declaration-advice.md
19919:         let result = Analyser::new().analyse("when HTTP_REQUEST {}", "f5-irules");
19920:         assert!(!result.allows_lexical_declaration_advice());
19921:         assert!(result.has_original_vendor_source_names());
19922:         let original = result.original_vendor_symbol_declarations().next().unwrap();
19923:         assert_eq!(
19924:             original.name_input().literal_units(original.purpose()),
19925:             Some(b"HTTP_REQUEST".as_slice())
19926:         );
19927:         assert!(original.metadata().original_name_input.is_none());
19928:         assert_eq!(result.all_defined_symbols.len(), 1);
19929:         assert_eq!(result.all_defined_symbols[0].name, "HTTP_REQUEST");
19930:         assert_eq!(
19931:             result.all_defined_symbols[0].kind,
19932:             tcl_registry::DefinedSymbolKind::Event
19933:         );
19934:         assert!(result.all_defined_symbols[0].original_name_input.is_none());
19935:         let invalid = Analyser::new().analyse("when HTTP_REQUEST set", "f5-irules");
19936:         assert!(invalid.all_defined_symbols.is_empty());
19937:         let shadowed =
19938:             Analyser::new().analyse("proc when {args} {}; when HTTP_REQUEST {}", "f5-irules");
19939:         assert_eq!(shadowed.original_vendor_symbol_declarations().count(), 0);
19940:         assert!(shadowed.all_defined_symbols.is_empty());
19941:         let uncertain =
19942:             Analyser::new().analyse("unknown_mutator; when HTTP_REQUEST {}", "f5-irules");
19943:         assert_eq!(
19944:             uncertain.original_vendor_symbol_declarations().count(),
19945:             1,
19946:             "unknown applicability retains a source card without a runtime claim"
19947:         );
19948:     }
19949:     #[test]
19950:     fn original_formal_counts_survive_procedure_and_signature_records() {
19951:         // naming.procedure.original-formal-count-shape
19952:         // docs/design/analysis/name-resolution-proofs/procedure-original-formal-count-shape.md
19953:         use crate::signature_scan::formal_count::SourceFormalCountOrigin;
19954:         let cases: &[(&str, &[usize], &[usize])] = &[
19955:             ("", &[0], &[0]),
19956:             ("a {b 2} c", &[3], &[2, 3]),
19957:             ("a args b", &[3], &[2, 3, 4, 5]),
19958:             ("a {args tail} b", &[3], &[2, 3, 4, 5]),
19959:             ("a args", &[1, 2, 3, 4, 5], &[1, 2, 3, 4, 5]),
19960:             ("a {b 2} args {c 3}", &[3, 4], &[1, 2, 3, 4, 5]),
19961:             ("{a 1} {b 2}", &[0, 1, 2], &[0, 1, 2]),
19962:         ];
19963:         for profile in ["tcl8.4", "tcl8.5", "tcl8.6", "tcl9.0", "tcl9.1", "jim"] {
19964:             for &(formals, c_counts, jim_counts) in cases {
19965:                 let source = format!("proc target {{{formals}}} {{return ok}}");
19966:                 let analysis = Analyser::new().analyse(&source, profile);
19967:                 let proc = analysis.all_procs.get("::target").expect(profile);
19968:                 let scan = crate::signature_scan::extract_signatures(
19969:                     &source,
19970:                     analysis.resolved_registry().unwrap(),
19971:                 );
19972:                 let signature = scan.procs.get("::target").expect(profile);
19973:                 let expected = if profile == "jim" {
19974:                     jim_counts
19975:                 } else {
19976:                     c_counts
19977:                 };
19978:                 assert_eq!(
19979:                     proc.formal_count_projection().origin(),
19980:                     SourceFormalCountOrigin::OriginalSource
19981:                 );
19982:                 assert_eq!(
19983:                     signature.formal_count_projection(),
19984:                     proc.formal_count_projection()
19985:                 );
19986:                 for count in 0..=5 {
19987:                     let accepts = |arity: tcl_registry::Arity| {
19988:                         usize::from(arity.min) <= count
19989:                             && (arity.is_unlimited() || count <= usize::from(arity.max))
19990:                     };
19991:                     assert_eq!(
19992:                         accepts(proc.arity()),
19993:                         expected.contains(&count),
19994:                         "{profile} {formals:?} argc={count}"
19995:                     );
19996:                     assert_eq!(
19997:                         accepts(signature.arity()),
19998:                         expected.contains(&count),
19999:                         "scanned {profile} {formals:?} argc={count}"
20000:                     );
20001:                 }
20002:             }
20003:         }
20004:         // An extra grouping level is a legal single formal named "a b c";
20005:         // it cannot stand in for a malformed three-field parameter.
20006:         let legal = Analyser::new().analyse("proc target {{{a b c}}} {return ok}", "jim");
20007:         assert_eq!(
20008:             legal.all_procs["::target"]
20009:                 .formal_count_projection()
20010:                 .origin(),
20011:             SourceFormalCountOrigin::OriginalSource
20012:         );
20013:         assert_eq!(
20014:             legal.all_procs["::target"].arity(),
20015:             tcl_registry::Arity::exact(1)
20016:         );
20017:         for source in [
20018:             "proc target $formals {return ok}",
20019:             // Three fields in one formal, matching the native malformed row.
20020:             "proc target {{a b c}} {return ok}",
20021:         ] {
20022:             let analysis = Analyser::new().analyse(source, "jim");
20023:             let proc = analysis.all_procs.get("::target").unwrap();
20024:             assert_eq!(
20025:                 proc.formal_count_projection().origin(),
20026:                 SourceFormalCountOrigin::Unknown
20027:             );
20028:             assert_eq!(proc.arity(), tcl_registry::Arity::any());
20029:         }
20030:     }
20031: }
/* ORIGINAL_SOURCE_RANGE 20033..20113 */
20033: #[cfg(test)]
20034: mod original_parent_purpose_tests {
20035:     use super::*;
20036: 
20037:     #[test]
20038:     fn original_procedure_receipts_keep_file_config_and_extracted_body_bom() {
20039:         // naming.source.original-configured-script-completeness
20040:         // docs/design/analysis/name-resolution-proofs/source-original-configured-script-completeness.md
20041:         // Original declaration/body syntax, without entered procedure or frame authority.
20042:         let body = r"namespace eval N {proc p\uD800 {x} {return $x}}";
20043:         let mut prepared = Analyser::new();
20044:         let input = prepared.prepare_analysis_input("tcl9.1").unwrap();
20045:         for (supplied, source) in [
20046:             (None, format!("\u{feff}{body}")),
20047:             (Some(input.clone()), format!("\u{feff}{body}")),
20048:             (
20049:                 {
20050:                     let mut content = input.clone();
20051:                     content.config.leading_bom = tcl_lexer::LeadingBom::Content;
20052:                     content.config.braced_var = tcl_lexer::BracedVarStyle::FirstClose;
20053:                     Some(content)
20054:                 },
20055:                 body.to_owned(),
20056:             ),
20057:         ] {
20058:             let mut analyser = supplied.as_ref().map_or_else(Analyser::new, |input| {
20059:                 Analyser::new().with_resolved_input(input.clone())
20060:             });
20061:             analyser.analyse_and_retain_result_for_test(&source, "tcl9.1");
20062:             let config = analyser.file_lexer_config();
20063:             let image = tcl_lexer::SourceImage::document(&source);
20064:             let declarations = analyser
20065:                 .result
20066:                 .original_procedure_declarations()
20067:                 .collect::<Vec<_>>();
20068:             let [declaration] = declarations.as_slice() else {
20069:                 panic!("original nested declaration: {source}");
20070:             };
20071:             assert_eq!(declaration.name_input().bytes(), b"p\xed\xa0\x80");
20072:             assert_eq!(declaration.name_input().source_image(), &image);
20073:             assert_eq!(declaration.name_input().lexer_config(), config);
20074:             let name = u32::try_from(source.find(r"p\uD800").unwrap()).unwrap();
20075:             assert_eq!(declaration.name_input().span().start(), name);
20076:             if let Some(supplied) = supplied {
20077:                 assert_eq!(analyser.result.resolved_input.as_ref(), Some(&supplied));
20078:             }
20079:             let mut foreign = config;
20080:             foreign.strict_quoting = !foreign.strict_quoting;
20081:             assert!(
20082:                 !analyser
20083:                     .result
20084:                     .matches_original_source_image(&image, foreign)
20085:             );
20086:             assert!(!analyser.result.matches_original_source_image(
20087:                 &tcl_lexer::SourceImage::document(&(source + "\n")),
20088:                 config
20089:             ));
20090:         }
20091:         for bom in [tcl_lexer::LeadingBom::Skip, tcl_lexer::LeadingBom::Content] {
20092:             let mut supplied = input.clone();
20093:             supplied.config.leading_bom = bom;
20094:             let source = "proc p {} {\u{feff}set hidden 1; set visible 2}";
20095:             let mut analyser = Analyser::new().with_resolved_input(supplied.clone());
20096:             analyser.analyse_and_retain_result_for_test(source, "display-only");
20097:             let proc = analyser.result.all_procs.get("::p").unwrap();
20098:             let statements = analyser.direct_statements_in_span(proc.body_span).unwrap();
20099:             assert_eq!(
20100:                 statements
20101:                     .iter()
20102:                     .map(SegmentedCommand::name)
20103:                     .collect::<Vec<_>>(),
20104:                 ["\u{feff}set", "set"]
20105:             );
20106:             assert_eq!(
20107:                 statements[0].argv[0].span.start(),
20108:                 u32::try_from(source.find('\u{feff}').unwrap()).unwrap()
20109:             );
20110:             assert_eq!(analyser.result.resolved_input.as_ref(), Some(&supplied));
20111:         }
20112:     }
20113: }
/* ORIGINAL_SOURCE_RANGE 20115..20116 */
20115: #[cfg(test)]
20116: mod retained_static_context_tests;
/* ORIGINAL_SOURCE_RANGE 20118..20149 */
20118: #[cfg(test)]
20119: mod constructed_projection_tests {
20120:     use super::*;
20121: 
20122:     #[test]
20123:     fn computed_creation_placeholder_preserves_constructed_procedure_holder() {
20124:         // Implementation contract: naming.analysis.constructed-key-consumer-projections
20125:         // docs/design/analysis/name-resolution-proofs/constructed-key-consumer-projections.md
20126:         // Only a metadata placeholder is constructed; no creation is executed.
20127:         for (procedure, expected) in [
20128:             ("p", "::${ns}::C"),
20129:             ("::a::p", "::a::${ns}::C"),
20130:             ("::a::::p", "::a::${ns}::C"),
20131:             ("::::::", ":::::${ns}::C"),
20132:             ("::é::λ", "::é::${ns}::C"),
20133:         ] {
20134:             let mut candidate = ParameterisedCreation {
20135:                 proc_qname: procedure.to_owned(),
20136:                 params: Vec::new(),
20137:                 name_word: "${ns}::C".to_owned(),
20138:                 call_off: 0,
20139:                 control_path: Vec::new(),
20140:             };
20141:             assert_eq!(
20142:                 Analyser::unresolved_class_name(&candidate).as_deref(),
20143:                 Some(expected)
20144:             );
20145:             candidate.name_word = "C".to_owned();
20146:             assert!(Analyser::unresolved_class_name(&candidate).is_none());
20147:         }
20148:     }
20149: }
