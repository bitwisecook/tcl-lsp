/* ORIGINAL_SOURCE_RANGE 1..9433 */
1: // tcl-lsp — a language server and toolchain for Tcl
2: // Copyright (C) 2026 James Deucker (bitwisecook) <https://github.com/bitwisecook>
3: //
4: // This program is free software: you can redistribute it and/or modify
5: // it under the terms of the GNU Affero General Public License as published by
6: // the Free Software Foundation, either version 3 of the License, or
7: // (at your option) any later version.
8: //
9: // This program is distributed in the hope that it will be useful,
10: // but WITHOUT ANY WARRANTY; without even the implied warranty of
11: // MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
12: // GNU Affero General Public License for more details.
13: //
14: // You should have received a copy of the GNU Affero General Public License
15: // along with this program.  If not, see <https://www.gnu.org/licenses/>.
16: //
17: // SPDX-License-Identifier: AGPL-3.0-or-later
18: 
19: //! Semantic-analyser tests.
20: //!
21: //! These drive `analyser.analyse(src)` and assert over the
22: //! returned result's `.diagnostics` (W###/E###/I###/H### codes) *and* its
23: //! structured semantic model (`global_scope`, `all_procs`, `all_classes`,
24: //! `regex_patterns`, `package_requires`, `command_aliases`, `source_targets`,
25: //! `unknown_proc_info`). [`tcl_compiler::analyser::AnalysisResult`]
26: //! exposes all these fields.
27: //!
28: //! ## Diagnostic surface
29: //!
30: //! Diagnostic assertions go through [`codes`]/[`fires`], copied verbatim from
31: //! the in-crate harness `src/analyser/diagnostics/fp/mod.rs`: they merge the
32: //! analyser pass with the `run_all_checks` compiler-checks pass (shimmer /
33: //! taint / dead-store) and drop optimisation codes, exactly mirroring the
34: //! user-facing `tcl diag` surface.
35: //!
36: //! ## C-Tcl ground truth
37: //!
38: //! Diagnostics that mirror a real tclsh error are pinned to ground truth from
39: //! `scripts/dev/tclsh_check.sh` (tclsh8.6 + tclsh9.0 on PATH). The headline
40: //! correspondences, verified while authoring this file:
41: //!   * `puts $x`            → `can't read "x": no such variable`      (W210)
42: //!   * `set`                → `wrong # args: should be "set …"`       (E002)
43: //!   * `break extra`        → `wrong # args: should be "break"`       (E003)
44: //!   * `regsub a b c d e`   → `wrong # args: should be "regsub …"`    (E003)
45: //!   * `string bogus hello` → `unknown … subcommand "bogus"`          (W001)
46: //!   * `namespace`          → `wrong # args: should be "namespace …"` (E001)
47: //!   * `unset x` (unset)    → `can't unset "x": no such variable`     (W213)
48: //!
49: //! Pure static-analysis heuristics with no direct runtime analogue (unused
50: //! params, dead stores, paste-error hints, etc.) are noted as such inline.
51: //!
52: //! ## Behavioural notes
53: //!
54: //! A handful of cases target features the single-document analyser +
55: //! `run_all_checks` surface does not reproduce (they live in the cross-file
56: //! workspace index). Each is asserted against the actual verdict with an
57: //! explanatory comment; where the behaviour is tracked elsewhere it is omitted.
58: //! See the per-section notes below.
59: 
60: use tcl_compiler::analyser::{Analyser, Severity};
61: use tcl_compiler::compilation_unit::CompilationUnit;
62: use tcl_compiler::compiler_checks::run_all_checks;
63: use tcl_registry::model::ingress::static_context_for;
64: 
65: /// Default dialect for reproducers that are not dialect-sensitive.
66: const D: &str = "tcl8.6";
67: 
68: #[test]
69: fn numeral_release_diagnostic_tracks_profile() {
70:     assert!(fires("set x 0d5; set y 1_000", "tcl8.4", "W148"));
71:     assert!(fires("set x 0d5; set y 1_000", "tcl8.6", "W148"));
72:     assert!(!fires("set x 0d5; set y 1_000", "tcl9.0", "W148"));
73:     assert!(!fires("set x 010", "tcl8.6", "W148"));
74:     assert!(!fires("set x 010", "tcl9.0", "W148"));
75: }
76: 
77: /// Every diagnostic code the full pipeline surfaces for `src` under `dialect`,
78: /// mirroring the user-facing `tcl diag` path: the analyser pass plus the
79: /// `run_all_checks` compiler-checks pass (shimmer / taint / dead-store), with
80: /// optimisation codes excluded exactly as `diag` excludes them.
81: ///
82: /// Copied verbatim from `src/analyser/diagnostics/fp/mod.rs::codes`.
83: fn codes(src: &str, dialect: &str) -> Vec<String> {
84:     let mut out: Vec<String> = Analyser::new()
85:         .analyse(src, dialect)
86:         .diagnostics
87:         .iter()
88:         .map(|d| d.code.to_string())
89:         .collect();
90:     let registry = static_context_for(dialect).commands();
91:     let cu = CompilationUnit::build_for(src, registry, false);
92:     let dialect_opt = (!dialect.is_empty())
93:         .then(|| tcl_registry::model::ingress::resolve_environment(dialect).analyser_profile());
94:     for d in run_all_checks(&cu, registry, dialect_opt) {
95:         if d.code.is_optimisation() {
96:             continue;
97:         }
98:         out.push(d.code.to_string());
99:     }
100:     out
101: }
102: 
103: /// True if `code` appears anywhere in the full diagnostic set for `src`.
104: fn fires(src: &str, dialect: &str, code: &str) -> bool {
105:     codes(src, dialect).iter().any(|c| c == code)
106: }
107: 
108: /// Count of how many times `code` appears in the merged diagnostic set.
109: fn count(src: &str, dialect: &str, code: &str) -> usize {
110:     codes(src, dialect)
111:         .iter()
112:         .filter(|c| c.as_str() == code)
113:         .count()
114: }
115: 
116: /// Full `(code, message)` pairs from the *analyser pass only* — used when a
117: /// test pins a message substring or message-scoped count (the analyser
118: /// pass owns every code those tests inspect: W210/W211/W213/W214/W215/W216/
119: /// W123/E001/E002/E003/W001).
120: fn analyser_diags(src: &str, dialect: &str) -> Vec<(String, String, Severity)> {
121:     Analyser::new()
122:         .analyse(src, dialect)
123:         .diagnostics
124:         .iter()
125:         .map(|d| (d.code.to_string(), d.message.clone(), d.severity))
126:         .collect()
127: }
128: 
129: /// Count of W210 diagnostics whose message names `var`.
130: fn w210_for(src: &str, var: &str) -> usize {
131:     analyser_diags(src, D)
132:         .iter()
133:         .filter(|(c, m, _)| c == "W210" && m.contains(var))
134:         .count()
135: }
136: 
137: // Proc records in the semantic model.
138: mod proc_analysis {
139:     use super::*;
140: 
141:     #[test]
142:     fn simple_proc_records_name_and_params() {
143:         let r = Analyser::new().analyse("proc greet {name} { puts $name }", D);
144:         let proc = r.global_scope.procs.get("greet").expect("greet recorded");
145:         assert_eq!(proc.name, "greet");
146:         assert_eq!(proc.qualified_name, "::greet");
147:         assert_eq!(proc.params.len(), 1);
148:         assert_eq!(proc.params[0].name, "name");
149:     }
150: 
151:     #[test]
152:     fn multiple_params_in_order() {
153:         let r = Analyser::new().analyse("proc add {a b} { return [+ $a $b] }", D);
154:         let proc = &r.global_scope.procs["add"];
155:         assert_eq!(
156:             proc.params
157:                 .iter()
158:                 .map(|p| p.name.as_str())
159:                 .collect::<Vec<_>>(),
160:             ["a", "b"]
161:         );
162:     }
163: 
164:     #[test]
165:     fn default_param_value_captured() {
166:         let r = Analyser::new().analyse("proc greet {{name World}} { puts $name }", D);
167:         let p = &r.global_scope.procs["greet"].params[0];
168:         assert_eq!(p.name, "name");
169:         assert!(p.has_default);
170:         assert_eq!(p.default_value.as_deref(), Some("World"));
171:     }
172: 
173:     #[test]
174:     fn no_params_is_empty() {
175:         let r = Analyser::new().analyse("proc noop {} { }", D);
176:         assert_eq!(r.global_scope.procs["noop"].params.len(), 0);
177:     }
178: 
179:     #[test]
180:     fn proc_in_all_procs_qualified() {
181:         let r = Analyser::new().analyse("proc foo {} {}", D);
182:         assert!(r.all_procs.contains_key("::foo"));
183:     }
184: 
185:     #[test]
186:     fn doc_harvested_from_preceding_comment() {
187:         let src = "# Adds two numbers\nproc add {a b} { return [+ $a $b] }\n";
188:         let r = Analyser::new().analyse(src, D);
189:         assert!(r.global_scope.procs["add"].doc.contains("Adds two numbers"));
190:     }
191: 
192:     #[test]
193:     fn multiple_procs_each_recorded() {
194:         let r = Analyser::new().analyse("proc foo {} {}\nproc bar {x} { return $x }\n", D);
195:         assert!(r.global_scope.procs.contains_key("foo"));
196:         assert!(r.global_scope.procs.contains_key("bar"));
197:     }
198: 
199:     #[test]
200:     fn proc_creates_child_scope_with_param_and_local() {
201:         let r = Analyser::new().analyse("proc foo {x} { set y 1 }", D);
202:         assert_eq!(r.global_scope.children.len(), 1);
203:         let s = &r.global_scope.children[0];
204:         assert_eq!(s.kind, tcl_compiler::analyser::ScopeKind::Proc);
205:         assert_eq!(s.name, "foo"); // proc-scope is keyed by the simple name
206:         assert!(s.variables.contains_key("x"));
207:         assert!(s.variables.contains_key("y"));
208:     }
209: }
210: 
211: // `tcl::OptProc` — the `opt` package's automatic-option-parsing proc
212: // definer. Runtime mechanism (tclsh9.0/8.6-verified):
213: // installs `::proc $name args {...}` unconditionally — the real Tcl-level
214: // signature is always the single `args` catch-all, regardless of what
215: // `optlist` declares; `optlist`'s own descriptor words are bound as local
216: // variables in the body by `::tcl::OptKeyParse`, with a leading `-` on a
217: // flag descriptor stripped for the bound name.
218: mod opt_proc_definer {
219:     use super::*;
220: 
221:     #[test]
222:     fn records_proc_with_real_args_only_arity() {
223:         // TP — the analyser must record the *real* Tcl-level signature,
224:         // never `optlist`'s own descriptor words.
225:         let r = Analyser::new().analyse(
226:             "tcl::OptProc greet {child -use -display} { return $child }",
227:             D,
228:         );
229:         let proc = r.all_procs.get("::greet").expect("greet recorded");
230:         assert_eq!(
231:             proc.params
232:                 .iter()
233:                 .map(|p| p.name.as_str())
234:                 .collect::<Vec<_>>(),
235:             ["args"],
236:             "the real Tcl-level signature is always the single args catch-all"
237:         );
238:     }
239: 
240:     #[test]
241:     fn fully_qualified_spelling_also_registers() {
242:         // TP — real corpus code commonly writes this fully qualified;
243:         // `resolve_analyser_hook` must resolve it identically to the bare
244:         // spelling.
245:         let r = Analyser::new().analyse(
246:             "::tcl::OptProc greet {child -use -display} { return $child }",
247:             D,
248:         );
249:         assert!(r.all_procs.contains_key("::greet"), "{:?}", r.all_procs);
250:     }
251: 
252:     #[test]
253:     fn call_with_any_arity_draws_no_wrong_arg_count_diagnostic() {
254:         // TP: every real call must not report "wrong number of arguments" —
255:         // the stub proc's `{}`-arity `ProcDef` must be overwritten with the
256:         // real signature.
257:         let src = "tcl::OptProc greet {child -use -display} { return $child }\ngreet a b c d\n";
258:         assert!(!fires(src, D, "E003"), "{:?}", codes(src, D));
259:     }
260: 
261:     /// The **accepted trade-off**, pinned as a choice rather than left to
262:     /// read as an oversight.
263:     ///
264:     /// C Tcl does enforce a positional-argument bound for an `OptProc`, at
265:     /// call time, from the parsed optlist — tclsh 9.0.4 and 8.6.16 agree
266:     /// exactly:
267:     ///
268:     /// ```text
269:     /// ::tcl::OptProc ::safe::loadTk {{child -tkAppName} {-use …} {-display …}} {…}
270:     /// ::safe::loadTk interp1                       → OK (one positional arg)
271:     /// ::safe::loadTk interp1 extraPositionalArg    → too many arguments
272:     ///                                                (unexpected argument(s): …)
273:     /// ```
274:     ///
275:     /// The definer installs `::proc $name args {…}`, so nothing in the
276:     /// *declaration* bounds the call; reproducing the bound would mean
277:     /// modelling `::tcl::OptKeyParse`'s runtime dispatch over the optlist
278:     /// (flag descriptors, defaults, `-…` terminators).  Until that exists,
279:     /// the choice is between a false E003 on every legitimate call — the
280:     /// defect the audit found, `::safe::loadTk interp1` reported as "too
281:     /// many arguments: expected at most 0" — and silence on a genuine
282:     /// overflow.  Silence is the abstaining direction this whole cluster
283:     /// takes, so the overflow goes unreported **on purpose**.
284:     ///
285:     /// The scope of that silence is what keeps it honest, so it is asserted
286:     /// here too: an ordinary proc is still arity-checked
287:     /// (`unrelated_proc_still_gets_real_arity_checked`), and this is a
288:     /// definer-scoped abstention, not a retreat from arity checking.
289:     #[test]
290:     fn a_genuine_opt_proc_arity_overflow_is_deliberately_unreported() {
291:         let src = "tcl::OptProc greet {child -use -display} { return $child }\n\
292:                    greet interp1 extraPositionalArg\n";
293:         assert!(
294:             !fires(src, D, "E002") && !fires(src, D, "E003"),
295:             "the overflow is real in C Tcl but deliberately not modelled here: {:?}",
296:             codes(src, D)
297:         );
298:         // …and the legitimate call is silent for the same reason, which is
299:         // the half the audit was actually about.
300:         let ok = "tcl::OptProc greet {child -use -display} { return $child }\ngreet interp1\n";
301:         assert!(
302:             !fires(ok, D, "E002") && !fires(ok, D, "E003"),
303:             "a legitimate OptProc call must never draw arity noise: {:?}",
304:             codes(ok, D)
305:         );
306:     }
307: 
308:     #[test]
309:     fn optlist_flag_descriptor_dash_is_stripped_for_the_bound_local() {
310:         // TP — `::tcl::OptKeyParse` binds `-use`/`-display` as `use`/
311:         // `display`, never with the leading dash.
312:         let src =
313:             "tcl::OptProc greet {child -use -display} { return \"$use $display\" }\ngreet a\n";
314:         assert!(
315:             !fires(src, D, "W210"),
316:             "use/display must resolve as bound locals, not read-before-set: {:?}",
317:             codes(src, D)
318:         );
319:     }
320: 
321:     #[test]
322:     fn args_catch_all_is_readable_in_the_body() {
323:         // TP — `$args` still holds the whole original argument list after
324:         // `OptKeyParse` runs, so a body reference to it (inspecting
325:         // leftovers) is legitimate, not a false read-before-set.
326:         let src = "tcl::OptProc greet {child} { return $args }\ngreet a\n";
327:         assert!(!fires(src, D, "W210"), "{:?}", codes(src, D));
328:     }
329: 
330:     #[test]
331:     fn dash_stripped_local_does_not_collide_with_its_own_optlist_declaration() {
332:         // FN guard: a naive anchor for the synthetic `args` binding (this
333:         // idiom writes no literal `args` word anywhere) could collide with
334:         // another symbol's own span and silently hide it — every
335:         // optlist-derived local must still resolve to its own name, not
336:         // `args` (anchoring `args` to the whole `optlist` word instead
337:         // would swallow every one of its own descriptor sub-spans).
338:         let r = Analyser::new().analyse(
339:             "tcl::OptProc greet {child -use -display} { return $child }",
340:             D,
341:         );
342:         let scope = &r.global_scope.children[0];
343:         assert!(
344:             scope.variables.contains_key("child"),
345:             "{:?}",
346:             scope.variables
347:         );
348:         assert!(scope.variables.contains_key("use"), "{:?}", scope.variables);
349:         assert!(
350:             scope.variables.contains_key("display"),
351:             "{:?}",
352:             scope.variables
353:         );
354:         assert!(
355:             scope.variables.contains_key("args"),
356:             "{:?}",
357:             scope.variables
358:         );
359:     }
360: 
361:     #[test]
362:     fn unrelated_proc_still_gets_real_arity_checked() {
363:         // FP guard: the fix must not loosen arity checking for ordinary
364:         // procs elsewhere in the same document.
365:         let src = "proc real {a b} { return [+ $a $b] }\nreal 1\n";
366:         assert!(fires(src, D, "E002"), "{:?}", codes(src, D));
367:     }
368: 
369:     #[test]
370:     fn plain_double_proc_redefinition_still_last_definition_wins() {
371:         // TN — control: an ordinary double-`proc` redefinition (unrelated
372:         // to `tcl::OptProc`) is unaffected by any of this fix's changes.
373:         let r = Analyser::new().analyse(
374:             "proc greet {} { return 1 }\nproc greet {x} { return $x }\n",
375:             D,
376:         );
377:         let proc = r.all_procs.get("::greet").expect("greet recorded");
378:         assert_eq!(
379:             proc.params
380:                 .iter()
381:                 .map(|p| p.name.as_str())
382:                 .collect::<Vec<_>>(),
383:             ["x"],
384:             "last definition wins: {:?}",
385:             proc.params
386:         );
387:     }
388: }
389: 
390: // Variable definitions across scopes.
391: mod variable_analysis {
392:     use super::*;
393: 
394:     #[test]
395:     fn set_defines_var() {
396:         let r = Analyser::new().analyse("set x 42", D);
397:         assert!(r.global_scope.variables.contains_key("x"));
398:     }
399: 
400:     #[test]
401:     fn multiple_sets_define_each() {
402:         let r = Analyser::new().analyse("set x 1\nset y 2\nset z 3", D);
403:         for v in ["x", "y", "z"] {
404:             assert!(r.global_scope.variables.contains_key(v), "{v} missing");
405:         }
406:     }
407: 
408:     #[test]
409:     fn incr_defines_var() {
410:         let r = Analyser::new().analyse("incr counter", D);
411:         assert!(r.global_scope.variables.contains_key("counter"));
412:     }
413: 
414:     #[test]
415:     fn array_set_defines_base_name() {
416:         let r = Analyser::new().analyse("set arr(key) value", D);
417:         assert!(r.global_scope.variables.contains_key("arr"));
418:     }
419: 
420:     #[test]
421:     fn proc_local_not_in_global_scope() {
422:         let r = Analyser::new().analyse("proc foo {} { set local 1 }", D);
423:         assert!(!r.global_scope.variables.contains_key("local"));
424:         assert!(r.global_scope.children[0].variables.contains_key("local"));
425:     }
426: 
427:     #[test]
428:     fn set_one_arg_is_read_only() {
429:         // `set x` (1 arg) is a *read*, not a definition. C-Tcl: `set x` on an
430:         // undefined var errors `can't read "x"`, confirming it is a read.
431:         let r = Analyser::new().analyse("set x", D);
432:         assert!(!r.global_scope.variables.contains_key("x"));
433:     }
434: 
435:     #[test]
436:     fn variable_command_skips_value_word() {
437:         let r = Analyser::new().analyse("variable port 8080", D);
438:         assert!(r.global_scope.variables.contains_key("port"));
439:         assert!(!r.global_scope.variables.contains_key("8080"));
440:     }
441: }
442: 
443: // A registry `VarRead`-role name word is a reference site.
444: //
445: // A variable is read by more than `$name`. Any command whose spec puts an
446: // argument in `ArgRole::VarRead` reads the cell that word names, and tclsh
447: // agrees (9.0.4 and 8.6.16, byte-identical):
448: //
449: //   proc f {} {set m 1; puts [set m]};        f   -> 1
450: //   proc f {} {set m 1; puts [info exists m]}; f  -> 1
451: //   proc f {} {set m 1; return [set m]};      f   -> 1
452: //
453: // `VarDef::references` must include every one of these sites, not just
454: // `$m` and the *statement* form `set m` — otherwise Find References /
455: // document-highlight / the minifier's rename pass under-report them.
456: mod var_read_role_references {
457:     use super::*;
458: 
459:     /// The read spans recorded for `name` in the first proc scope, as the
460:     /// source text each one covers.
461:     fn read_texts(src: &str, name: &str) -> Vec<String> {
462:         fn walk(
463:             scope: &tcl_compiler::analyser::Scope,
464:             name: &str,
465:             src: &str,
466:         ) -> Option<Vec<String>> {
467:             if let Some(v) = scope.variables.get(name) {
468:                 return Some(
469:                     v.references
470:                         .iter()
471:                         .map(|r| src[r.start() as usize..r.end() as usize].to_owned())
472:                         .collect(),
473:                 );
474:             }
475:             scope.children.iter().find_map(|c| walk(c, name, src))
476:         }
477:         walk(&Analyser::new().analyse(src, D).global_scope, name, src).unwrap_or_default()
478:     }
479: 
480:     #[test]
481:     fn tp_a_substituted_set_read_is_recorded() {
482:         // FN before the fix: `refs` was empty.
483:         assert_eq!(
484:             read_texts("proc f {} {\n    set m 1\n    puts [set m]\n}\n", "m"),
485:             vec!["m".to_owned()],
486:             "`[set m]` is a read of `m`"
487:         );
488:     }
489: 
490:     #[test]
491:     fn tp_every_var_read_role_contributes_not_just_set() {
492:         // Registry-driven, so the fix is not about `set`: `info exists` and
493:         // `array get` declare `VarRead` positions too.
494:         for (src, name) in [
495:             ("proc f {} {\n    set m 1\n    info exists m\n}\n", "m"),
496:             (
497:                 "proc f {} {\n    set m 1\n    puts [info exists m]\n}\n",
498:                 "m",
499:             ),
500:             (
501:                 "proc f {} {\n    array set a {k 1}\n    puts [array get a]\n}\n",
502:                 "a",
503:             ),
504:         ] {
505:             assert_eq!(
506:                 read_texts(src, name),
507:                 vec![name.to_owned()],
508:                 "a `VarRead`-role word must be a reference site: {src:?}"
509:             );
510:         }
511:     }
512: 
513:     #[test]
514:     fn tn_the_write_form_records_no_read() {
515:         // `set m 1` is a definition, not a read — the two-argument form has no
516:         // `VarRead` role at all, so nothing new appears.
517:         assert!(
518:             read_texts("proc f {} {\n    set m 1\n}\n", "m").is_empty(),
519:             "a plain write must not become its own reference"
520:         );
521:     }
522: 
523:     #[test]
524:     fn tn_a_computed_name_records_nothing() {
525:         // `set $n` reads whatever *value* `n` holds; which cell that is cannot
526:         // be known statically, so no read is attributed to `m`.
527:         assert!(
528:             read_texts(
529:                 "proc f {} {\n    set m 1\n    set n m\n    puts [set $n]\n}\n",
530:                 "m"
531:             )
532:             .is_empty(),
533:             "a `$`-computed name must not be credited to a same-spelled cell"
534:         );
535:     }
536: 
537:     #[test]
538:     fn fp_the_statement_form_is_recorded_exactly_once() {
539:         // `set m` is recorded by `set`'s own handler *and* by the generic
540:         // role pass; the sink dedupes by span, so the site appears once. A
541:         // duplicate would make hover's "N reference(s)" count read double.
542:         assert_eq!(
543:             read_texts("proc f {} {\n    set m 1\n    set m\n}\n", "m"),
544:             vec!["m".to_owned()],
545:             "one source location is one reference"
546:         );
547:     }
548: 
549:     #[test]
550:     fn tp_a_brace_quoted_name_word_reads_the_literal_cell() {
551:         // The cell read through the role path: `{$n}` names the
552:         // variable *called* `$n`. tclsh 9.0.4 / 8.6.16: `set {$n} v; set {$n}`
553:         // -> v, while `info exists n` -> 0.
554:         let src = "proc f {} {\n    set {$n} 1\n    puts [set {$n}]\n}\n";
555:         // The recorded span is the word token's, which follows the inner-end
556:         // convention — the closing `}` sits one past its end, exactly as the
557:         // `{$n}` *declaration*'s span does.
558:         assert_eq!(
559:             read_texts(src, "$n"),
560:             vec!["{$n".to_owned()],
561:             "the literal cell owns the read"
562:         );
563:         assert!(
564:             read_texts(src, "n").is_empty(),
565:             "the unrelated plain cell must own nothing"
566:         );
567:     }
568: }
569: 
570: // A script argument *built* with `list` is walked as the command it
571: // provably is.
572: //
573: // tclsh 9.0.4 and 8.6.16 agree that the three spellings are functionally
574: // identical:
575: //
576: //   proc f {} {upvar #0 g l; set l 1}
577: //   proc f {} {uplevel #0 {upvar #0 g l}; …}
578: //   proc f {} {uplevel #0 [list upvar #0 g l]; …}
579: //
580: // `list` packs its already-substituted arguments into exactly one command,
581: // so the built form is not dynamic — yet every pass keyed on a literal
582: // `{…}` body skipped it.
583: mod list_quoted_script_arguments {
584:     use super::*;
585: 
586:     fn scope_named(
587:         scope: &tcl_compiler::analyser::Scope,
588:         kind: tcl_compiler::analyser::ScopeKind,
589:     ) -> Option<&tcl_compiler::analyser::Scope> {
590:         if scope.kind == kind {
591:             return Some(scope);
592:         }
593:         scope.children.iter().find_map(|c| scope_named(c, kind))
594:     }
595: 
596:     #[test]
597:     fn tp_a_list_built_uplevel_body_declares_in_the_uplevel_frame() {
598:         use tcl_compiler::analyser::ScopeKind;
599:         for src in [
600:             "proc f {} {\n    uplevel 1 [list set inner 1]\n}\n",
601:             // The braced control, which already worked — both must agree.
602:             "proc f {} {\n    uplevel 1 {set inner 1}\n}\n",
603:         ] {
604:             let r = Analyser::new().analyse(src, D);
605:             let up = scope_named(&r.global_scope, ScopeKind::Uplevel)
606:                 .unwrap_or_else(|| panic!("an uplevel frame scope must open for {src:?}"));
607:             assert!(
608:                 up.variables.contains_key("inner"),
609:                 "`inner` belongs to the uplevel frame, not the proc: {src:?}"
610:             );
611:         }
612:     }
613: 
614:     #[test]
615:     fn tp_a_list_built_namespace_body_declares_in_the_namespace() {
616:         let src = "namespace eval ::ns [list set v 1]\n";
617:         let r = Analyser::new().analyse(src, D);
618:         let ns = &r.global_scope.children[0];
619:         assert!(
620:             ns.variables.contains_key("v"),
621:             "the built `set v 1` runs in `::ns`: {:?}",
622:             ns.variables.keys().collect::<Vec<_>>()
623:         );
624:     }
625: 
626:     #[test]
627:     fn fp_a_list_built_uplevel_body_does_not_claim_the_substitution_bytes() {
628:         let src = "proc p {file} {\n    uplevel #0 [list source [file join $file]]\n}\n";
629:         let r = Analyser::new().analyse(src, D);
630:         let proc_scope = &r.global_scope.children[0];
631:         let file_var = proc_scope.variables.get("file").expect("param");
632:         let read_off = u32::try_from(src.find("$file").unwrap()).unwrap();
633:         assert!(
634:             file_var.references.iter().any(|s| s.start() == read_off),
635:             "the $file read at {read_off} must attach to the proc param; refs {:?}",
636:             file_var.references
637:         );
638:         let up = scope_named(&r.global_scope, tcl_compiler::analyser::ScopeKind::Uplevel)
639:             .expect("uplevel scope opens");
640:         assert!(
641:             up.body_span.is_none(),
642:             "a list-built uplevel body must not claim the substitution bytes: {:?}",
643:             up.body_span
644:         );
645:     }
646: 
647:     #[test]
648:     fn fp_a_rewalked_built_body_emits_no_duplicate_diagnostics() {
649:         let src = "proc p {} {\n    namespace eval :: [list puts [string index abc 99]]\n}\n";
650:         let r = Analyser::new().analyse(src, D);
651:         let mut spans: Vec<_> = r
652:             .diagnostics
653:             .iter()
654:             .map(|d| (d.code.as_str().to_owned(), d.span.start(), d.span.end()))
655:             .collect();
656:         let n = spans.len();
657:         spans.sort();
658:         spans.dedup();
659:         eprintln!(
660:             "diags: {:?}",
661:             r.diagnostics
662:                 .iter()
663:                 .map(|d| (d.code.as_str(), d.span, d.message.clone()))
664:                 .collect::<Vec<_>>()
665:         );
666:         assert_eq!(n, spans.len(), "duplicate diagnostics from the re-walk");
667:     }
668: 
669:     #[test]
670:     fn fp_a_nested_subst_in_a_built_body_is_not_rerecorded_in_the_target_scope() {
671:         let src = "namespace eval ::app {\n    proc helper {} { return 1 }\n    proc user {} { namespace eval :: [list puts [helper]] }\n}\n";
672:         let r = Analyser::new().analyse(src, D);
673:         let inv: Vec<_> = r
674:             .command_invocations
675:             .iter()
676:             .filter(|i| i.name.contains("helper"))
677:             .collect();
678:         eprintln!("helper invocations: {inv:?}");
679:         assert!(inv.len() <= 1, "double-recorded invocation: {inv:?}");
680:     }
681: 
682:     #[test]
683:     fn tn_a_dynamic_build_stays_an_opaque_barrier() {
684:         // `[list $cb inner 1]` names no statically known command, and
685:         // `[$build …]` is not a list build at all — both keep today's
686:         // behaviour rather than guessing.
687:         use tcl_compiler::analyser::ScopeKind;
688:         for src in [
689:             "proc f {} {\n    uplevel 1 [list $cb inner 1]\n}\n",
690:             "proc f {} {\n    uplevel 1 [$build inner]\n}\n",
691:         ] {
692:             let r = Analyser::new().analyse(src, D);
693:             assert!(
694:                 scope_named(&r.global_scope, ScopeKind::Uplevel).is_none(),
695:                 "an unresolvable body must not be walked: {src:?}"
696:             );
697:         }
698:     }
699: 
700:     #[test]
701:     fn tp_a_substituted_read_in_a_built_body_belongs_to_the_building_frame() {
702:         // `::tk::SourceLibFile`'s real shape. `$file` is the proc's own
703:         // parameter, substituted in the proc frame *before* `namespace eval`
704:         // enters `::` — so the read is the proc's, and the namespace scope
705:         // must not claim those bytes.
706:         let src = "proc ::tk::SourceLibFile {file} {\n    \
707: namespace eval :: [list source [file join $::tk_library $file.tcl]]\n\
708: }\n";
709:         let r = Analyser::new().analyse(src, D);
710:         let proc_scope = &r.global_scope.children[0];
711:         let file_var = &proc_scope.variables["file"];
712:         assert_eq!(
713:             file_var
714:                 .references
715:                 .iter()
716:                 .map(|s| &src[s.start() as usize..s.end() as usize])
717:                 .collect::<Vec<_>>(),
718:             vec!["$file"],
719:             "the parameter's read must be recorded"
720:         );
721:         let ns = proc_scope
722:             .children
723:             .iter()
724:             .find(|c| c.kind == tcl_compiler::analyser::ScopeKind::Namespace)
725:             .expect("the `namespace eval ::` scope exists");
726:         assert!(
727:             ns.body_span.is_none(),
728:             "a `[…]` body is evaluated in the calling frame, so the namespace \
729: scope must not own its bytes — owning them made the scope-chain lookup stop \
730: there and answer nothing for `$file`"
731:         );
732:     }
733: 
734:     #[test]
735:     fn tn_a_braced_namespace_body_still_owns_its_bytes() {
736:         // Control for the span above: a literal `{…}` body really does run in
737:         // the namespace frame, so it keeps its `body_span`.
738:         let src = "namespace eval ::ns {\n    variable v 1\n}\n";
739:         let r = Analyser::new().analyse(src, D);
740:         assert!(
741:             r.global_scope.children[0].body_span.is_some(),
742:             "a literal braced body is the namespace's own"
743:         );
744:     }
745: }
746: 
747: // Namespace scopes + qualified procs.
748: mod namespace_analysis {
749:     use super::*;
750: 
751:     #[test]
752:     fn namespace_eval_creates_namespace_scope() {
753:         let src = "namespace eval myns {\n    proc helper {} { return 1 }\n}\n";
754:         let r = Analyser::new().analyse(src, D);
755:         assert_eq!(r.global_scope.children.len(), 1);
756:         let ns = &r.global_scope.children[0];
757:         assert_eq!(ns.kind, tcl_compiler::analyser::ScopeKind::Namespace);
758:         assert_eq!(ns.name, "myns");
759:         assert!(ns.procs.contains_key("helper"));
760:     }
761: 
762:     #[test]
763:     fn namespace_qualified_proc_in_all_procs() {
764:         let src = "namespace eval math {\n    proc add {a b} { return [+ $a $b] }\n}\n";
765:         let r = Analyser::new().analyse(src, D);
766:         assert!(r.all_procs.contains_key("::math::add"));
767:     }
768: }
769: 
770: // Arity (E001/E002/E003), unknown subcommand (W001),
771: // read-before-set (W210), and the constant-branch family (I230).
772: mod diagnostics {
773:     use super::*;
774: 
775:     // Builtin arity (E001/E002/E003), all tclsh-observable `wrong # args`.
776: 
777:     #[test]
778:     fn too_few_args_set_fires_e002() {
779:         // tclsh8.6/9.0: `set` → wrong # args: should be "set varName ?newValue?".
780:         let ds = analyser_diags("set", D);
781:         let errs: Vec<_> = ds
782:             .iter()
783:             .filter(|(_, _, s)| *s == Severity::Error)
784:             .collect();
785:         assert!(!errs.is_empty());
786:         assert!(errs.iter().any(|(_, m, _)| m.contains("Too few")));
787:     }
788: 
789:     #[test]
790:     fn too_many_args_break_fires_e003() {
791:         // tclsh8.6/9.0: `break extra` → wrong # args: should be "break".
792:         let ds = analyser_diags("break extra", D);
793:         let errs: Vec<_> = ds
794:             .iter()
795:             .filter(|(_, _, s)| *s == Severity::Error)
796:             .collect();
797:         assert!(!errs.is_empty());
798:         assert!(errs.iter().any(|(_, m, _)| m.contains("Too many")));
799:     }
800: 
801:     #[test]
802:     fn correct_arity_no_error() {
803:         // `set x 42` is valid in tclsh; no Error-severity diagnostic.
804:         let ds = analyser_diags("set x 42", D);
805:         assert!(!ds.iter().any(|(_, _, s)| *s == Severity::Error));
806:     }
807: 
808:     #[test]
809:     fn puts_arity_options_not_counted() {
810:         // `puts -nonewline stderr hello` is valid (the switch is not a
811:         // positional); `puts a b c` is over-arity. tclsh agrees.
812:         assert!(!fires("puts -nonewline stderr hello", D, "E003"));
813:         assert!(fires("puts a b c", D, "E003"));
814:     }
815: 
816:     #[test]
817:     fn declared_switches_not_counted_as_positional() {
818:         // Declared option flags are skipped before counting.
819:         // These regsub switches exist in every supported dialect.
820:         for snippet in [
821:             "regsub -all -line {\\n} $args {} str",
822:             "regsub -all {a} $b {} c",
823:             "regsub -nocase -all -- $pat $s {} out",
824:         ] {
825:             assert!(
826:                 !fires(snippet, D, "E003"),
827:                 "unexpected E003 for {snippet:?}"
828:             );
829:         }
830:         // Genuine over-arity (5 positional, max 4) still fires.
831:         // tclsh: `regsub a b c d e` → wrong # args.
832:         assert!(fires("regsub a b c d e", D, "E003"));
833:     }
834: 
835:     #[test]
836:     fn while_too_few_args_is_error() {
837:         let ds = analyser_diags("while {1}", D);
838:         assert!(ds.iter().any(|(_, _, s)| *s == Severity::Error));
839:     }
840: 
841:     #[test]
842:     fn for_too_few_args_is_error() {
843:         let ds = analyser_diags("for {set i 0} {$i < 10}", D);
844:         assert!(ds.iter().any(|(_, _, s)| *s == Severity::Error));
845:     }
846: 
847:     #[test]
848:     fn missing_subcommand_namespace_fires_e001() {
849:         // tclsh: bare `namespace` → wrong # args: should be "namespace subcommand …".
850:         let ds = analyser_diags("namespace", D);
851:         let errs: Vec<_> = ds
852:             .iter()
853:             .filter(|(_, _, s)| *s == Severity::Error)
854:             .collect();
855:         assert!(!errs.is_empty());
856:         assert!(
857:             errs.iter()
858:                 .any(|(_, m, _)| m.to_lowercase().contains("subcommand"))
859:         );
860:     }
861: 
862:     #[test]
863:     fn unknown_command_not_arity_checked() {
864:         // Unknown user commands get no arity error (W123 only, not E00x).
865:         let ds = analyser_diags("mycommand a b c d e", D);
866:         assert!(!ds.iter().any(|(_, _, s)| *s == Severity::Error));
867:     }
868: 
869:     // Unknown subcommand (W001), tclsh-observable `unknown … subcommand`.
870: 
871:     #[test]
872:     fn unknown_subcommand_warns_w001() {
873:         // tclsh: `string bogus hello` → unknown or ambiguous subcommand "bogus".
874:         let ds = analyser_diags("string bogus hello", D);
875:         assert!(
876:             ds.iter()
877:                 .any(|(c, m, _)| c == "W001" && m.contains("Unknown subcommand"))
878:         );
879:     }
880: 
881:     #[test]
882:     fn widget_creation_pathname_is_not_a_subcommand_no_w001() {
883:         // A widget-creation command's first word is a window pathname
884:         // (`.e`), not a subcommand — even though the creator carries an
885:         // instance-command `subcommands` table. It must never trip W001.
886:         for src in [
887:             "entry .e -textvariable v",
888:             "canvas .c -background white",
889:             "menu .m -tearoff 0",
890:             "text .t -width 40",
891:             "listbox .lb -listvariable items",
892:             "ttk::treeview .tv",
893:             "ttk::notebook .nb",
894:         ] {
895:             assert!(
896:                 !fires(src, D, "W001"),
897:                 "widget creation `{src}` must not fire W001",
898:             );
899:         }
900:         // A genuine mistyped subcommand (no leading `.`) still fires.
901:         assert!(fires("string bogus hello", D, "W001"));
902:     }
903: 
904:     #[test]
905:     fn package_prefer_is_a_real_subcommand_no_w001() {
906:         // `package prefer` is real in every supported dialect — tclsh returns
907:         // "stable" and it must not be flagged "Unknown subcommand".
908:         let ds = analyser_diags("package prefer", D);
909:         assert!(!ds.iter().any(|(_, m, _)| m.contains("Unknown subcommand")));
910:     }
911: 
912:     #[test]
913:     fn package_files_is_disabled_under_tcl86_per_tclsh() {
914:         // Under tcl8.6 `package files` is NOT a subcommand — tclsh8.6 errors
915:         //   `bad option "files": must be forget, ifneeded, names, …`
916:         // (tclsh9.0 added `files`; this test pins 8.6.)  Because `files` *is* a
917:         // real subcommand in 9.0, this is W002 ("disabled in the active dialect
918:         // profile"), not W001 ("Unknown subcommand") which is reserved for a
919:         // name that exists in no dialect.
920:         assert!(fires("package files mypackage", D, "W002"));
921:         assert!(!fires("package files mypackage", D, "W001"));
922:     }
923: 
924:     #[test]
925:     fn zipfs_is_a_9_0_ensemble_gated_out_of_earlier_dialects() {
926:         // `zipfs` ships in Tcl 9.0 (TIP 430); the 8.x profiles have no such
927:         // command.  Under 9.0 a real subcommand resolves cleanly, and a bogus
928:         // one is W001 (unknown subcommand) — proving the subcommand set is
929:         // modelled.  Under 8.6 the whole command is dialect-gated, so it is
930:         // W002 ("disabled in the active dialect profile"), which points the
931:         // user at the version rather than a bare "unknown command".
932:         assert!(!fires("zipfs mount archive.zip /mnt", "tcl9.0", "W123"));
933:         assert!(!fires("zipfs mount archive.zip /mnt", "tcl9.0", "W001"));
934:         assert!(!fires("zipfs mount archive.zip /mnt", "tcl9.0", "W002"));
935:         assert!(fires("zipfs bogus x", "tcl9.0", "W001"));
936:         assert!(fires("zipfs mount archive.zip /mnt", "tcl8.6", "W002"));
937:     }
938: 
939:     #[test]
940:     fn namespace_which_command_probe_does_not_flag_unknown() {
941:         // `namespace which -command foo` is an existence PROBE — it returns ""
942:         // for an unknown command rather than failing, so probing a name no
943:         // command defines must NOT draw W123.  (Navigation to a command that
944:         // *does* exist still works; that's a separate reference.)
945:         let src = "namespace which -command no_such_command_xyz\n";
946:         assert!(
947:             !fires(src, D, "W123"),
948:             "namespace which probe must not W123: {:?}",
949:             analyser_diags(src, D),
950:         );
951:     }
952: 
953:     #[test]
954:     fn proc_shadowing_ensemble_command_suppresses_w001() {
955:         // tclsh8.6: `proc string {op args} {...}` completely replaces the
956:         // builtin `string` ensemble at the call site — `string reverse x`
957:         // dispatches to the user proc, not the registry subcommand set, so
958:         // it must not be flagged "Unknown subcommand".  See FP-STY-17.
959:         let src = "proc string {op args} { return $op }\nstring reverse x\n";
960:         assert!(!fires(src, D, "W001"), "got {:?}", analyser_diags(src, D));
961:     }
962: 
963:     #[test]
964:     fn ensemble_shadowing_does_not_hide_a_genuinely_unknown_subcommand() {
965:         // The proc-shadow suppression above is scoped to `string` only — a
966:         // different, unshadowed ensemble in the same file still fires.
967:         let src = "proc string {op args} { return $op }\ninfo bogus\n";
968:         assert!(fires(src, D, "W001"), "got {:?}", analyser_diags(src, D));
969:     }
970: 
971:     #[test]
972:     fn dynamically_mapped_dict_ensemble_subcommand_suppresses_w001() {
973:         // FP: the real tcllib `dicttool.tcl` idiom patches the `dict`
974:         // ensemble's `-map` at
975:         // runtime to add `getnull` (`namespace ensemble configure dict -map
976:         // [dict replace [namespace ensemble configure dict -map] getnull
977:         // ::tcl::dict::getnull]`), which a static `SUBCOMMANDS` table can't
978:         // reflect. Must not fire "Unknown subcommand 'getnull' for 'dict'"
979:         // once the backing proc exists at `::tcl::dict::getnull` — hover
980:         // and definition already resolve the same call site correctly, and
981:         // W001 must agree with them.
982:         let src = "proc ::tcl::dict::getnull {dictionary args} {\n\
983:              if {[exists $dictionary {*}$args]} { get $dictionary {*}$args }\n\
984:              }\n\
985:              namespace ensemble configure dict -map \
986:              [dict replace [namespace ensemble configure dict -map] \
987:              getnull ::tcl::dict::getnull]\n\
988:              proc demo {} {\n\
989:              set clay [dict create a 1 b 2]\n\
990:              return [dict getnull $clay a]\n\
991:              }\n";
992:         assert!(!fires(src, D, "W001"), "got {:?}", analyser_diags(src, D));
993:     }
994: 
995:     #[test]
996:     fn dynamically_mapped_dict_ensemble_fix_is_not_overfit_to_getnull() {
997:         // FP — a second, differently-named sibling from the same real
998:         // tcllib idiom (`is_dict`), proving the fix isn't hardcoded to one
999:         // subcommand name. This block never calls bare `exists`/`get`, so it
1000:         // exercises Part B in isolation from Part A.
1001:         let src = "proc ::tcl::dict::is_dict {d} {\n\
1002:              if {[catch {dict size $d} err]} { return 0 }\n\
1003:              return 1\n\
1004:              }\n\
1005:              namespace ensemble configure dict -map \
1006:              [dict replace [namespace ensemble configure dict -map] \
1007:              is_dict ::tcl::dict::is_dict]\n\
1008:              dict is_dict [dict create a 1]\n";
1009:         assert!(!fires(src, D, "W001"), "got {:?}", analyser_diags(src, D));
1010:     }
1011: 
1012:     #[test]
1013:     fn genuinely_unknown_dict_subcommand_still_fires_w001() {
1014:         // TP — regression guard: a real, non-existent `dict` subcommand
1015:         // (no proc named `zzzznotreal` anywhere, no ensemble patch) must
1016:         // still fire — proves `dynamic_ensemble_subcommand_known` doesn't
1017:         // over-suppress.
1018:         let src = "proc demo {} {\n\
1019:              set d [dict create a 1 b 2]\n\
1020:              return [dict zzzznotreal $d a]\n\
1021:              }\n";
1022:         assert!(fires(src, D, "W001"), "got {:?}", analyser_diags(src, D));
1023:     }
1024: 
1025:     #[test]
1026:     fn dict_proc_at_conventional_location_without_ensemble_patch_is_an_accepted_false_negative() {
1027:         // FN — deliberately ACCEPTED gap (the primary/simple design, chosen
1028:         // over the more precise "observed an actual
1029:         // `namespace ensemble configure -map` call" variant): a proc
1030:         // defined at `::tcl::dict::<name>` is treated as "this ensemble
1031:         // subcommand is known" even when the ensemble's `-map` was never
1032:         // actually reconfigured to include it. Real tclsh would still error
1033:         // `unknown or ambiguous subcommand "stray"` here. If this gap is
1034:         // ever closed (tracking whether `-map` was truly reconfigured),
1035:         // this test's assertion flips and documents the improvement.
1036:         let src = "proc ::tcl::dict::stray {d} { return $d }\n\
1037:              dict stray [dict create a 1]\n";
1038:         assert!(
1039:             !fires(src, D, "W001"),
1040:             "documents the accepted FN gap; got {:?}",
1041:             analyser_diags(src, D),
1042:         );
1043:     }
1044: 
1045:     #[test]
1046:     fn namespace_ensemble_configure_on_tk_suppresses_w001_for_systray_and_sysnotify() {
1047:         // FP: the real `tk/library/systray.tcl` (and `print.tcl`, `fileicon.tcl`,
1048:         // `accessibility.tcl`) idiom splices `systray`/`sysnotify` into the
1049:         // *pre-existing, registry-builtin* `tk` ensemble via `namespace
1050:         // ensemble configure tk -map [dict merge [namespace ensemble
1051:         // configure tk -map] {systray ::tk::systray sysnotify
1052:         // ::tk::sysnotify::sysnotify}]` — a `CONFIGURE`, not `CREATE`, on an
1053:         // ensemble this file never itself created. tclsh9.0/8.6 both
1054:         // confirm `tk systray create`/`tk sysnotify ...` are correct,
1055:         // documented calls; must not fire "Unknown subcommand".
1056:         let src = "proc ::tk::systray {args} {}\n\
1057:              proc ::tk::sysnotify::sysnotify {a b} {}\n\
1058:              namespace ensemble configure tk -map \
1059:              [dict merge [namespace ensemble configure tk -map] \
1060:              {systray ::tk::systray sysnotify ::tk::sysnotify::sysnotify}]\n\
1061:              tk systray create -image book\n\
1062:              tk sysnotify Alert message\n";
1063:         assert!(!fires(src, D, "W001"), "got {:?}", analyser_diags(src, D));
1064:     }
1065: 
1066:     #[test]
1067:     fn namespace_ensemble_configure_genuinely_unknown_tk_subcommand_still_fires_w001() {
1068:         // TP — regression guard: a real, non-existent `tk` subcommand (no
1069:         // splice recorded for it) must still fire — proves
1070:         // `statically_mapped_ensemble_subcommand_known` doesn't over-suppress
1071:         // the whole `tk` ensemble once *any* subcommand has been spliced in.
1072:         let src = "namespace ensemble configure tk -map \
1073:              [dict merge [namespace ensemble configure tk -map] \
1074:              {systray ::tk::systray}]\n\
1075:              tk zzznotreal\n";
1076:         assert!(fires(src, D, "W001"), "got {:?}", analyser_diags(src, D));
1077:     }
1078: 
1079:     #[test]
1080:     fn ensemble_without_implementation_namespace_is_unaffected_by_dynamic_map_check() {
1081:         // TN — regression guard: `dynamic_ensemble_subcommand_known` is
1082:         // inert for every ensemble whose `CommandSpec` doesn't set
1083:         // `implementation_namespace` (only `dict`, currently) — a
1084:         // same-named proc existing elsewhere must not suppress an unrelated
1085:         // ensemble's genuinely unknown subcommand.
1086:         let src = "proc bogus {} {}\nstring bogus hello\n";
1087:         assert!(fires(src, D, "W001"), "got {:?}", analyser_diags(src, D));
1088:     }
1089: 
1090:     #[test]
1091:     fn error_diagnostics_have_a_span() {
1092:         // The error anchors at the start of the script. The diagnostic carries
1093:         // a byte `span`; assert it starts at offset 0 (the `set` token).
1094:         let r = Analyser::new().analyse("set", D);
1095:         assert!(!r.diagnostics.is_empty());
1096:         assert_eq!(r.diagnostics[0].span.start(), 0);
1097:     }
1098: 
1099:     #[test]
1100:     fn multiline_diagnostic_anchors_on_offending_line() {
1101:         // `break extra` sits on line 1; its span starts after the first line's
1102:         // newline. We check the byte offset lands within the second line.
1103:         let src = "set x 1\nbreak extra\nset y 2";
1104:         let r = Analyser::new().analyse(src, D);
1105:         let err = r
1106:             .diagnostics
1107:             .iter()
1108:             .find(|d| d.severity == Severity::Error)
1109:             .expect("an error");
1110:         let line_start = src.find("break").unwrap();
1111:         assert!(
1112:             (err.span.start() as usize) >= line_start,
1113:             "error span should be on the `break` line"
1114:         );
1115:     }
1116: 
1117:     // Read-before-set (W210), tclsh `can't read "x"`.
1118: 
1119:     #[test]
1120:     fn read_before_set_warns_w210() {
1121:         // tclsh8.6/9.0: `puts $x` → can't read "x": no such variable.
1122:         assert_eq!(count("puts $x", D, "W210"), 1);
1123:         let ds = analyser_diags("puts $x", D);
1124:         assert!(
1125:             ds.iter()
1126:                 .any(|(c, _, s)| c == "W210" && *s == Severity::Warning)
1127:         );
1128:     }
1129: 
1130:     #[test]
1131:     fn read_before_set_in_expr_warns_w210() {
1132:         // tclsh: `if {$x > 0} …` with x unset → can't read "x".
1133:         assert_eq!(count("if {$x > 0} { puts yes }", D, "W210"), 1);
1134:     }
1135: 
1136:     #[test]
1137:     fn read_before_set_cleared_after_assignment() {
1138:         assert!(!fires("set x 1\nputs $x", D, "W210"));
1139:     }
1140: 
1141:     #[test]
1142:     fn array_read_uses_base_variable_no_w210() {
1143:         assert!(!fires("set arr(key) 1\nputs $arr(key)", D, "W210"));
1144:     }
1145: 
1146:     // Output-var writers suppress W210 on the written var.
1147:     // (regexp/scan/lassign write their target vars; reading them is safe.)
1148: 
1149:     #[test]
1150:     fn regexp_capture_vars_not_read_before_set() {
1151:         // The `email` read still fires (it is genuinely unset), but the capture
1152:         // targets `user`/`domain` do not.
1153:         assert_eq!(
1154:             w210_for(
1155:                 "regexp {^(\\w+)@(\\w+)$} $email -> user domain\nputs $user",
1156:                 "user"
1157:             ),
1158:             0
1159:         );
1160:     }
1161: 
1162:     #[test]
1163:     fn regexp_match_var_not_read_before_set() {
1164:         assert_eq!(
1165:             w210_for("regexp {\\d+} $text match\nputs $match", "match"),
1166:             0
1167:         );
1168:     }
1169: 
1170:     #[test]
1171:     fn scan_capture_vars_not_read_before_set() {
1172:         assert_eq!(
1173:             w210_for("scan \"42 hello\" \"%d %s\" num word\nputs $num", "num"),
1174:             0
1175:         );
1176:     }
1177: 
1178:     #[test]
1179:     fn lassign_vars_not_read_before_set() {
1180:         assert_eq!(w210_for("lassign {a b c} x y z\nputs \"$x $y $z\"", "x"), 0);
1181:     }
1182: 
1183:     // `regsub … result` writes its trailing `result` variable (recognised via
1184:     // the registry's `VarWrite` arg-role, like `set`/`lassign`/`scan`), so a
1185:     // later `$result` read is NOT read-before-set.
1186:     // The `$text` argument is still unset and fires its own W210 (tclsh would
1187:     // error on that first at runtime).
1188:     #[test]
1189:     fn regsub_result_var_suppresses_w210_at_top_level() {
1190:         assert_eq!(
1191:             w210_for("regsub {old} $text new result\nputs $result", "result"),
1192:             0
1193:         );
1194:         // The unset input `$text` still reports read-before-set.
1195:         assert_eq!(
1196:             w210_for("regsub {old} $text new result\nputs $result", "text"),
1197:             1
1198:         );
1199:     }
1200: 
1201:     // Unused / dead-store / paste hints (pure static heuristics).
1202: 
1203:     #[test]
1204:     fn unused_assigned_variable_hint_w211() {
1205:         // Heuristic (no direct tclsh analogue): `set x 1` never read.
1206:         let ds = analyser_diags("proc foo {} { set x 1 }", D);
1207:         assert!(
1208:             ds.iter()
1209:                 .any(|(c, _, s)| c == "W211" && *s == Severity::Hint)
1210:         );
1211:     }
1212: 
1213:     #[test]
1214:     fn used_variable_no_unused_hint() {
1215:         assert!(!fires("proc foo {} { set x 1; puts $x }", D, "W211"));
1216:     }
1217: 
1218:     #[test]
1219:     fn dead_assignment_detected_w220() {
1220:         // Heuristic: `set x 1; set x 2; puts $x` — first store is dead.
1221:         let ds = analyser_diags("proc foo {} { set x 1; set x 2; puts $x }", D);
1222:         let dead: Vec<_> = ds.iter().filter(|(c, _, _)| c == "W220").collect();
1223:         assert_eq!(dead.len(), 1);
1224:         assert!(dead[0].1.contains('x'));
1225:     }
1226: 
1227:     // The trace names `::g`, the top-level store is spelled
1228:     // `g`, and both name the same global variable; the write trace observes
1229:     // every store (tclsh prints `trace` on each `set`), so W220 must stay
1230:     // suppressed for the unqualified spelling exactly as it already is for
1231:     // `set ::g …`.
1232:     #[test]
1233:     fn traced_global_unqualified_store_suppresses_w220() {
1234:         let unqualified = "proc onw {a b c} { puts trace }\ntrace add variable ::g write ::onw\nset g 1\nset g 2\nputs $g";
1235:         assert!(!fires(unqualified, D, "W220"));
1236:         let qualified = "proc onw {a b c} { puts trace }\ntrace add variable ::g write ::onw\nset ::g 1\nset ::g 2\nputs $::g";
1237:         assert!(!fires(qualified, D, "W220"));
1238:     }
1239: 
1240:     #[test]
1241:     fn paste_error_hint_for_duplicate_static_assignment_h300() {
1242:         // Heuristic: repeated assignment of the *same* literal value.
1243:         let ds = analyser_diags("proc foo {} { set x 0; set x 0; puts $x }", D);
1244:         let h: Vec<_> = ds.iter().filter(|(c, _, _)| c == "H300").collect();
1245:         assert_eq!(h.len(), 1);
1246:         assert_eq!(h[0].2, Severity::Hint);
1247:         assert!(h[0].1.contains('x'));
1248:     }
1249: 
1250:     #[test]
1251:     fn paste_error_not_emitted_when_value_changes_or_dynamic() {
1252:         assert!(!fires(
1253:             "proc foo {} { set x 0; set x 1; puts $x }",
1254:             D,
1255:             "H300"
1256:         ));
1257:         assert!(!fires(
1258:             "proc foo {} { set x $y; set x $y; puts $x }",
1259:             D,
1260:             "H300"
1261:         ));
1262:     }
1263: 
1264:     // Constant-branch family (I230).
1265: 
1266:     #[test]
1267:     fn constant_if_unreachable_branch_i230() {
1268:         assert!(fires("if {1} { set x 1 } else { set y 2 }", D, "I230"));
1269:     }
1270: 
1271:     #[test]
1272:     fn constant_string_eq_and_double_equals_fold_i230() {
1273:         // With x provably "foo", `$x == "foo"` / `$x eq "foo"` is always true →
1274:         // alternate branch unreachable. tclsh: expr {"foo" == "foo"} → 1.
1275:         for op in ["==", "eq"] {
1276:             let src = format!("set x foo\nif {{$x {op} \"foo\"}} {{ puts hi }}");
1277:             assert_eq!(count(&src, D, "I230"), 1, "expected I230 for {op:?}");
1278:         }
1279:     }
1280: 
1281:     #[test]
1282:     fn constant_string_ne_and_bang_equals_fold_i230() {
1283:         // `$x != "foo"` with x=="foo" is always false → then-branch unreachable.
1284:         for op in ["!=", "ne"] {
1285:             let src = format!("set x foo\nif {{$x {op} \"foo\"}} {{ puts hi }}");
1286:             assert_eq!(count(&src, D, "I230"), 1, "expected I230 for {op:?}");
1287:         }
1288:     }
1289: 
1290:     #[test]
1291:     fn infinite_loop_idiom_not_flagged_i230() {
1292:         // `while 1` / `for … 1 …` are intentional infinite loops (exit via
1293:         // break/return); a constant-true loop condition must not be I230.
1294:         for src in [
1295:             "proc f {} { while 1 { if {[g]} break } }",
1296:             "proc f {} { while true { if {[g]} break } }",
1297:             "proc f {} { for {set i 0} 1 {incr i} { if {$i > 9} break } }",
1298:         ] {
1299:             assert!(!fires(src, D, "I230"), "unexpected I230 for {src:?}");
1300:         }
1301:     }
1302: 
1303:     #[test]
1304:     fn dead_while_zero_still_flagged() {
1305:         // A constant-*false* loop condition means the body never runs.
1306:         // This is reported as W240 (loop-never-executes) rather than I230;
1307:         // the dead-loop fact is still surfaced.
1308:         assert!(fires("proc f {} { while 0 { puts dead } }", D, "W240"));
1309:     }
1310: 
1311:     // NOTE — no I231 for a constant switch: `switch 1 {1 {…} …}` does not fire
1312:     // I231. The analyser + run_all_checks surface does not fold a constant
1313:     // switch subject into an unreachable-arm diagnostic.
1314: }
1315: 
1316: // `set` dual-shape role resolution, observed through behaviour.
1317: mod set_dual_shape {
1318:     use super::*;
1319: 
1320:     #[test]
1321:     fn set_two_arg_is_write_one_arg_is_read() {
1322:         // 2-arg `set x 1` is a write: defines `x`, no W210.
1323:         assert!(!fires("set x 1\nputs $x", D, "W210"));
1324:         assert!(
1325:             Analyser::new()
1326:                 .analyse("set x 1", D)
1327:                 .global_scope
1328:                 .variables
1329:                 .contains_key("x")
1330:         );
1331:         // 1-arg `set x` is a read: does NOT define `x`.
1332:         assert!(
1333:             !Analyser::new()
1334:                 .analyse("set x", D)
1335:                 .global_scope
1336:                 .variables
1337:                 .contains_key("x")
1338:         );
1339:     }
1340: }
1341: 
1342: // `when` body recursion is dialect-gated (iRules-only builtin).
1343: mod when_dialect_gating {
1344:     use super::*;
1345: 
1346:     #[test]
1347:     fn when_body_not_analysed_under_plain_tcl() {
1348:         // Under tcl8.6 `when` is an unknown command; its braced arg is opaque
1349:         // data, NOT a handler script — so the body command `boguscmd` must not
1350:         // get its own W123, and no spurious W210 on the body read.
1351:         let src = "when HTTP_REQUEST {\n    boguscmd $undefvar\n}\n";
1352:         let ds = analyser_diags(src, D);
1353:         assert!(
1354:             !ds.iter()
1355:                 .any(|(c, m, _)| c == "W123" && m.contains("boguscmd")),
1356:             "when body must not be analysed under tcl8.6"
1357:         );
1358:         assert!(
1359:             !ds.iter().any(|(c, _, _)| c == "W210"),
1360:             "no spurious W210 in opaque body"
1361:         );
1362:     }
1363: 
1364:     #[test]
1365:     fn when_body_analysed_under_irules() {
1366:         // Under f5-irules `when` IS a handler; the body is analysed and the
1367:         // bogus inner command earns its own W123.
1368:         let src = "when HTTP_REQUEST {\n    boguscmd $undefvar\n}\n";
1369:         let ds = analyser_diags(src, "f5-irules");
1370:         assert_eq!(
1371:             ds.iter()
1372:                 .filter(|(c, m, _)| c == "W123" && m.contains("boguscmd"))
1373:                 .count(),
1374:             1,
1375:             "when body IS analysed under f5-irules"
1376:         );
1377:     }
1378: }
1379: 
1380: // Bodies of if/while/for/foreach/dict-for are walked.
1381: mod control_flow {
1382:     use super::*;
1383: 
1384:     fn vars(src: &str) -> std::collections::HashSet<String> {
1385:         Analyser::new()
1386:             .analyse(src, D)
1387:             .global_scope
1388:             .variables
1389:             .keys()
1390:             .cloned()
1391:             .collect()
1392:     }
1393: 
1394:     #[test]
1395:     fn if_while_for_bodies_analysed() {
1396:         assert!(vars("if {1} { set x 42 }").contains("x"));
1397:         assert!(vars("while {1} { set x 42; break }").contains("x"));
1398:         let v = vars("for {set i 0} {$i < 10} {incr i} { set x $i }");
1399:         assert!(v.contains("i") && v.contains("x"));
1400:     }
1401: 
1402:     #[test]
1403:     fn if_expr_records_var_reference() {
1404:         let r = Analyser::new().analyse("set x 1\nif {$x > 0} { set y 1 }", D);
1405:         let xv = r.global_scope.variables.get("x").expect("x defined");
1406:         assert!(!xv.references.is_empty());
1407:     }
1408: 
1409:     #[test]
1410:     fn foreach_defines_loop_var() {
1411:         assert!(vars("foreach item {a b c} { puts $item }").contains("item"));
1412:     }
1413: 
1414:     #[test]
1415:     fn foreach_multi_var_each_defined_with_distinct_ranges() {
1416:         let r = Analyser::new().analyse("foreach {a b c} {1 2 3} { puts $a }", D);
1417:         for v in ["a", "b", "c"] {
1418:             assert!(r.global_scope.variables.contains_key(v), "{v} missing");
1419:         }
1420:         // Each binding gets its own span, not the whole varList token's.
1421:         let ra = r.global_scope.variables["a"].definition_span;
1422:         let rb = r.global_scope.variables["b"].definition_span;
1423:         let rc = r.global_scope.variables["c"].definition_span;
1424:         assert_ne!(ra.start(), rb.start());
1425:         assert_ne!(rb.start(), rc.start());
1426:     }
1427: 
1428:     #[test]
1429:     fn if_elseif_else_all_bodies_analysed() {
1430:         let v = vars("if {$x} { set a 1 } elseif {$y} { set b 2 } else { set c 3 }");
1431:         assert!(v.contains("a") && v.contains("b") && v.contains("c"));
1432:     }
1433: 
1434:     #[test]
1435:     fn dict_for_body_analysed() {
1436:         assert!(vars("dict for {k v} $d { set seen 1 }").contains("seen"));
1437:     }
1438: 
1439:     #[test]
1440:     fn command_subst_inside_expr_records_outer_var() {
1441:         // The analyser records the outer `n` but does not hoist the nested
1442:         // `[set y 1]` write (inside the `[expr {…}]` command-substitution) into
1443:         // `global_scope.variables`.
1444:         let v = vars("set n [expr {[set y 1] + 2}]");
1445:         assert!(v.contains("n"), "outer assignment `n` is recorded");
1446:     }
1447: 
1448:     #[test]
1449:     fn nested_proc_and_if_records_proc() {
1450:         let src = "proc check {x} {\n    if {== $x 0} {\n        set result zero\n    } else {\n        set result nonzero\n    }\n    return $result\n}\n";
1451:         let r = Analyser::new().analyse(src, D);
1452:         assert!(r.global_scope.procs.contains_key("check"));
1453:     }
1454: 
1455:     #[test]
1456:     fn tcloo_method_body_in_method_scope() {
1457:         let src =
1458:             "oo::class create Dog {\n    method bark {} {\n        set message woof\n    }\n}\n";
1459:         let r = Analyser::new().analyse(src, D);
1460:         assert!(r.all_classes.contains_key("::Dog"));
1461:         // The method scope is named `::Dog::bark`.
1462:         let scope = r
1463:             .global_scope
1464:             .children
1465:             .iter()
1466:             .find(|c| c.name.ends_with("Dog::bark"))
1467:             .expect("bark method scope");
1468:         assert!(scope.variables.contains_key("message"));
1469:     }
1470: }
1471: 
1472: // Recorded regex literals.
1473: mod regex_patterns {
1474:     use super::*;
1475: 
1476:     fn pats(src: &str) -> Vec<(String, String)> {
1477:         Analyser::new()
1478:             .analyse(src, D)
1479:             .regex_patterns
1480:             .iter()
1481:             .map(|p| (p.pattern.clone(), p.command.clone()))
1482:             .collect()
1483:     }
1484: 
1485:     #[test]
1486:     fn regexp_simple_records_pattern_and_command() {
1487:         let p = pats("regexp {^[a-z]+$} $str");
1488:         assert_eq!(p, [("^[a-z]+$".to_string(), "regexp".to_string())]);
1489:     }
1490: 
1491:     #[test]
1492:     fn regexp_with_options_and_terminator_and_start() {
1493:         assert_eq!(pats("regexp -nocase -expanded {\\d+} $str")[0].0, "\\d+");
1494:         assert_eq!(pats("regexp -nocase -- {^test} $str")[0].0, "^test");
1495:         assert_eq!(pats("regexp -start 5 {pattern} $str")[0].0, "pattern");
1496:     }
1497: 
1498:     #[test]
1499:     fn regsub_simple_and_with_options() {
1500:         let p = pats("regsub {\\d+} $str replacement result");
1501:         assert_eq!(p, [("\\d+".to_string(), "regsub".to_string())]);
1502:         assert_eq!(
1503:             pats("regsub -all -nocase {foo} $str bar result")[0].0,
1504:             "foo"
1505:         );
1506:     }
1507: 
1508:     #[test]
1509:     fn switch_regexp_braced_and_inline_record_arms() {
1510:         for src in [
1511:             "switch -regexp $x { {^a} {puts a} {^b} {puts b} }",
1512:             "switch -regexp $x {^a} {puts a} {^b} {puts b}",
1513:         ] {
1514:             let p = pats(src);
1515:             assert_eq!(p.len(), 2, "for {src:?}");
1516:             let pset: Vec<_> = p.iter().map(|(pat, _)| pat.as_str()).collect();
1517:             assert!(pset.contains(&"^a") && pset.contains(&"^b"));
1518:             assert!(p.iter().all(|(_, c)| c == "switch"));
1519:         }
1520:     }
1521: 
1522:     #[test]
1523:     fn switch_regexp_excludes_default_arm() {
1524:         let p = pats("switch -regexp $x { {^a} {puts a} default {puts other} }");
1525:         assert_eq!(p, [("^a".to_string(), "switch".to_string())]);
1526:     }
1527: 
1528:     #[test]
1529:     fn switch_glob_exact_default_record_no_regex() {
1530:         assert!(pats("switch -glob $x { a* {puts a} b* {puts b} }").is_empty());
1531:         assert!(pats("switch -exact $x { hello {puts hi} }").is_empty());
1532:         assert!(pats("switch $x { hello {puts hi} }").is_empty());
1533:     }
1534: 
1535:     #[test]
1536:     fn no_regex_in_other_commands() {
1537:         assert!(pats("set x 1\nputs hello\nif {$x > 0} { puts yes }").is_empty());
1538:     }
1539: 
1540:     #[test]
1541:     fn multiple_regex_commands_in_one_file() {
1542:         let p = pats("regexp {^a} $x\nregsub {^b} $y c result");
1543:         assert_eq!(p.len(), 2);
1544:         let cmds: std::collections::HashSet<_> = p.iter().map(|(_, c)| c.clone()).collect();
1545:         assert_eq!(
1546:             cmds,
1547:             ["regexp".to_string(), "regsub".to_string()]
1548:                 .into_iter()
1549:                 .collect()
1550:         );
1551:     }
1552: 
1553:     #[test]
1554:     fn regexp_inside_proc_recorded() {
1555:         let p = pats("proc check {s} { regexp {^\\d+$} $s }");
1556:         assert_eq!(p.len(), 1);
1557:         assert_eq!(p[0].1, "regexp");
1558:     }
1559: 
1560:     // Variable propagation.
1561: 
1562:     #[test]
1563:     fn set_then_regexp_and_regsub_propagate_constant_pattern() {
1564:         // `set pat {re}; regexp $pat …` records two patterns (def + use site).
1565:         let p = pats("set pat {^\\d+$}\nregexp $pat $str");
1566:         assert_eq!(p.len(), 2);
1567:         assert!(p.iter().all(|(pat, _)| pat == "^\\d+$"));
1568:         let p2 = pats("set pat {foo}\nregsub $pat $str bar result");
1569:         assert_eq!(p2.len(), 2);
1570:         assert!(p2.iter().all(|(pat, _)| pat == "foo"));
1571:     }
1572: 
1573:     /// A rooted `::set` still binds its constant as `set` does: the
1574:     /// binding reads the `CellWrite` declaration of the command the head
1575:     /// resolves to, never the
1576:     /// spelling (tclsh 8.4.20 to 9.1b0: `::set pat {^\d+$}; regexp $pat 123`
1577:     /// is 1).
1578:     #[test]
1579:     fn a_rooted_set_propagates_its_constant_pattern() {
1580:         let p = pats("::set pat {^\\d+$}\nregexp $pat $str");
1581:         assert_eq!(p.len(), 2);
1582:         assert!(p.iter().all(|(pat, _)| pat == "^\\d+$"));
1583:     }
1584: 
1585:     #[test]
1586:     fn set_then_switch_regexp_propagates() {
1587:         let p = pats("set pat {^hello}\nswitch -regexp $x $pat {puts matched}");
1588:         assert!(p.iter().any(|(pat, _)| pat == "^hello"));
1589:     }
1590: 
1591:     #[test]
1592:     fn dynamic_or_interpolated_pattern_not_recorded() {
1593:         assert!(pats("set pat $dynamic_value\nregexp $pat $str").is_empty());
1594:         assert!(pats("set pat \"^$prefix\"\nregexp $pat $str").is_empty());
1595:         // Reassigned to non-constant loses tracking.
1596:         assert!(pats("set pat {^\\d+}\nset pat $other\nregexp $pat $str").is_empty());
1597:     }
1598: 
1599:     #[test]
1600:     fn variable_pattern_in_proc_scope() {
1601:         let p = pats("proc check {s} { set pat {^\\w+$}; regexp $pat $s }");
1602:         assert_eq!(p.len(), 2);
1603:         assert!(p.iter().all(|(pat, _)| pat == "^\\w+$"));
1604:     }
1605: 
1606:     #[test]
1607:     fn literal_and_variable_patterns_mixed() {
1608:         let p = pats("set pat {^a}\nregexp $pat $str\nregexp {^b} $str2");
1609:         let pset: Vec<_> = p.iter().map(|(pat, _)| pat.as_str()).collect();
1610:         assert!(pset.contains(&"^a") && pset.contains(&"^b"));
1611:     }
1612: }
1613: 
1614: // package require / provide records.
1615: mod package_require {
1616:     use super::*;
1617: 
1618:     #[test]
1619:     fn simple_require_no_version() {
1620:         let r = Analyser::new().analyse("package require http", D);
1621:         assert_eq!(r.package_requires.len(), 1);
1622:         assert_eq!(r.package_requires[0].name, "http");
1623:         assert!(r.package_requires[0].version.is_none());
1624:     }
1625: 
1626:     #[test]
1627:     fn require_with_version_and_exact() {
1628:         for src in [
1629:             "package require http 2.9",
1630:             "package require -exact http 2.9",
1631:         ] {
1632:             let r = Analyser::new().analyse(src, D);
1633:             assert_eq!(r.package_requires.len(), 1, "for {src:?}");
1634:             assert_eq!(r.package_requires[0].name, "http");
1635:             assert_eq!(r.package_requires[0].version.as_deref(), Some("2.9"));
1636:         }
1637:     }
1638: 
1639:     #[test]
1640:     fn multiple_requires() {
1641:         let r = Analyser::new().analyse("package require http\npackage require tls", D);
1642:         assert_eq!(r.package_requires.len(), 2);
1643:         let names: std::collections::HashSet<_> =
1644:             r.package_requires.iter().map(|p| p.name.clone()).collect();
1645:         assert_eq!(
1646:             names,
1647:             ["http".to_string(), "tls".to_string()]
1648:                 .into_iter()
1649:                 .collect()
1650:         );
1651:     }
1652: 
1653:     #[test]
1654:     fn provide_and_unrelated_not_recorded() {
1655:         assert!(
1656:             Analyser::new()
1657:                 .analyse("package provide mylib 1.0", D)
1658:                 .package_requires
1659:                 .is_empty()
1660:         );
1661:         assert!(
1662:             Analyser::new()
1663:                 .analyse("set x 42", D)
1664:                 .package_requires
1665:                 .is_empty()
1666:         );
1667:     }
1668: }
1669: 
1670: // Unused proc parameters (W214) — pure static heuristic.
1671: mod unused_proc_parameters {
1672:     use super::*;
1673: 
1674:     fn w214(src: &str) -> Vec<String> {
1675:         analyser_diags(src, D)
1676:             .into_iter()
1677:             .filter(|(c, _, _)| c == "W214")
1678:             .map(|(_, m, _)| m)
1679:             .collect()
1680:     }
1681: 
1682:     #[test]
1683:     fn unused_param_detected() {
1684:         let w = w214("proc foo {x y} { puts $x }");
1685:         assert_eq!(w.len(), 1);
1686:         assert!(w[0].contains('y'));
1687:         // Severity is Hint.
1688:         assert!(
1689:             analyser_diags("proc foo {x y} { puts $x }", D)
1690:                 .iter()
1691:                 .any(|(c, _, s)| c == "W214" && *s == Severity::Hint)
1692:         );
1693:     }
1694: 
1695:     #[test]
1696:     fn all_params_used_no_warning() {
1697:         assert!(w214("proc foo {a b} { puts $a; puts $b }").is_empty());
1698:     }
1699: 
1700:     #[test]
1701:     fn args_param_not_flagged() {
1702:         // `args` is the variadic catch-all and is never "unused".
1703:         assert!(w214("proc foo {args} { puts hello }").is_empty());
1704:     }
1705: 
1706:     #[test]
1707:     fn underscore_prefixed_param_is_still_flagged_rust_behaviour() {
1708:         // A leading `_` is not treated as a deliberate "unused" marker —
1709:         // `_unused` still fires W214.
1710:         let w = w214("proc foo {_unused x} { puts $x }");
1711:         assert_eq!(w.len(), 1);
1712:         assert!(w[0].contains("_unused"));
1713:     }
1714: 
1715:     #[test]
1716:     fn multiple_unused_params_each_flagged() {
1717:         assert_eq!(w214("proc foo {a b c} { puts hello }").len(), 3);
1718:     }
1719: 
1720:     #[test]
1721:     fn param_used_in_return_or_branch_condition() {
1722:         assert!(w214("proc foo {x} { return $x }").is_empty());
1723:         assert!(w214("proc foo {x} { if {$x > 0} { puts yes } }").is_empty());
1724:     }
1725: 
1726:     #[test]
1727:     fn param_used_in_expr_alias_counts_as_read() {
1728:         // interp alias for expr — refs inside the aliased expr arg are reads.
1729:         let src = "interp alias {} = {} expr\nproc foo {x y} {\n    set result [= {$x + $y}]\n    return $result\n}\n";
1730:         assert!(w214(src).is_empty());
1731:     }
1732: 
1733:     #[test]
1734:     fn param_used_in_dict_for_and_dict_map_bodies() {
1735:         // dict for/map bodies are lowered into real CFG blocks in the analysis
1736:         // build, so a param read nested in the body is a first-class SSA
1737:         // use, with the deep body scan / text fallback as belt-and-braces.
1738:         let used = [
1739:             "proc f {but} {\n    dict for {k v} $d {\n        if {$but ne \"\"} { puts $but }\n    }\n}\n",
1740:             "proc f {scale} {\n    dict map {k v} $d { expr {$v * $scale} }\n}\n",
1741:             "proc foo {targetKey} {\n    set d [dict create]\n    dict for {k v} $d {\n        if {[dict exists $v $targetKey]} { puts hi }\n    }\n}\n",
1742:         ];
1743:         for src in used {
1744:             assert!(w214(src).is_empty(), "unexpected W214 for {src:?}");
1745:         }
1746:     }
1747: 
1748:     #[test]
1749:     fn unused_param_alongside_used_in_dict_for_still_flagged() {
1750:         let src = "proc f {{count 0} other} {\n    dict for {k v} $d {\n        if {$count>0} { incr count }\n    }\n}\n";
1751:         let w = w214(src);
1752:         assert_eq!(w.len(), 1);
1753:         assert!(w[0].contains("other"));
1754:     }
1755: 
1756:     #[test]
1757:     fn param_read_inside_catch_body() {
1758:         assert!(w214("proc f {x} {\n    catch { puts $x }\n}\n").is_empty());
1759:     }
1760: 
1761:     #[test]
1762:     fn param_used_only_by_dict_with_or_update() {
1763:         // dict with / dict update mark the dict var VAR_READ+VAR_WRITE; the read
1764:         // must survive the defs filter.
1765:         assert!(w214("proc f {pdata} {\n    dict with pdata {}\n}\n").is_empty());
1766:         assert!(w214("proc f {d} {\n    dict update d k v {}\n}\n").is_empty());
1767:     }
1768: 
1769:     #[test]
1770:     fn pure_write_to_param_inside_opaque_body_still_flags() {
1771:         let src = "proc f {x} {\n    dict for {k v} $d { set x 1 }\n}\n";
1772:         let w = w214(src);
1773:         assert_eq!(w.len(), 1);
1774:         assert!(w[0].contains('x'));
1775:     }
1776: 
1777:     #[test]
1778:     fn unrelated_namespaced_for_does_not_get_dict_body_fallback() {
1779:         // Only ::tcl::dict::for|map get the synthetic body-arg fallback.
1780:         let src = "proc f {x} {\n    ::my::for a b { set x 1 }\n}\n";
1781:         let w = w214(src);
1782:         assert_eq!(w.len(), 1);
1783:         assert!(w[0].contains('x'));
1784:     }
1785: 
1786:     #[test]
1787:     fn return_expr_and_cmd_subst_do_not_false_flag() {
1788:         for src in [
1789:             "proc foo {x} { return [expr {$x + 1}] }",
1790:             "proc foo {x} { return [string length $x] }",
1791:         ] {
1792:             assert!(w214(src).is_empty(), "unexpected W214 for {src:?}");
1793:         }
1794:         // …but a genuinely-unused param still warns alongside.
1795:         let w = w214("proc foo {x y} { return [expr {$x + 1}] }");
1796:         assert_eq!(w.len(), 1);
1797:         assert!(w[0].contains('y'));
1798:     }
1799: 
1800:     #[test]
1801:     fn dict_for_braced_data_word_use_divergence() {
1802:         // `{$unused}` is a braced literal (braces inhibit substitution), so it
1803:         // would not count as a use. The deep-body scan over the opaque
1804:         // ::tcl::dict::for barrier does NOT flag `unused` here (it does not
1805:         // exclude the braced data word), so no W214 fires.
1806:         let src = "proc foo {used unused} {\n    set d [dict create]\n    dict for {k v} $d {\n        set msg {$unused}\n        puts $used\n    }\n}\n";
1807:         assert!(
1808:             w214(src).is_empty(),
1809:             "Rust does not flag `unused` in this shape"
1810:         );
1811:     }
1812: 
1813:     // NOTE — trace-callback W214 (see `trace_callbacks` module): the analyser +
1814:     // run_all_checks surface does NOT special-case trace callbacks, so W214
1815:     // fires on a `trace add variable … watcher` callback's `name1 name2 op`
1816:     // params. The control test `unrelated_proc_unused_param_still_flagged`
1817:     // (which fires either way) covers this.
1818: }
1819: 
1820: // Trace callbacks.
1821: mod trace_callbacks {
1822:     use super::*;
1823: 
1824:     #[test]
1825:     fn unrelated_proc_unused_param_still_flagged() {
1826:         // Whatever the trace-callback handling, an *unrelated* proc's unused
1827:         // param must still fire W214.
1828:         let src = "proc watcher {name1 name2 op} { puts hello }\nproc other {a b} { puts $a }\ntrace add variable x write watcher\n";
1829:         // Message shape: `Parameter 'b' of proc '::other' is unused`.
1830:         let w214: Vec<_> = analyser_diags(src, D)
1831:             .into_iter()
1832:             .filter(|(c, m, _)| c == "W214" && m.contains("'b'") && m.contains("::other"))
1833:             .collect();
1834:         assert_eq!(
1835:             w214.len(),
1836:             1,
1837:             "unrelated `other`'s unused `b` must fire W214"
1838:         );
1839:     }
1840: }
1841: 
1842: // interp alias records in `command_aliases`.
1843: mod interp_alias {
1844:     use super::*;
1845: 
1846:     fn alias(src: &str, name: &str) -> Option<(String, Vec<String>)> {
1847:         Analyser::new()
1848:             .analyse(src, D)
1849:             .command_aliases
1850:             .get(name)
1851:             .map(|a| (a.target.as_str().to_owned(), a.extras.clone()))
1852:     }
1853: 
1854:     #[test]
1855:     fn alias_recorded_with_target() {
1856:         assert_eq!(
1857:             alias("interp alias {} = {} expr", "::="),
1858:             Some(("expr".to_string(), vec![]))
1859:         );
1860:     }
1861: 
1862:     #[test]
1863:     fn alias_with_prepended_args() {
1864:         assert_eq!(
1865:             alias("interp alias {} myput {} puts stdout", "::myput"),
1866:             Some(("puts".to_string(), vec!["stdout".to_string()]))
1867:         );
1868:     }
1869: 
1870:     #[test]
1871:     fn alias_non_current_interp_not_recorded() {
1872:         assert!(alias("interp alias child = {} expr", "::=").is_none());
1873:     }
1874: 
1875:     #[test]
1876:     fn alias_qualified_name_normalised() {
1877:         assert!(
1878:             Analyser::new()
1879:                 .analyse("interp alias {} ::myexpr {} expr", D)
1880:                 .command_aliases
1881:                 .contains_key("::myexpr")
1882:         );
1883:     }
1884: 
1885:     #[test]
1886:     fn alias_chain_not_resolved_transitively() {
1887:         let src = "interp alias {} a {} b\ninterp alias {} b {} expr\n";
1888:         assert_eq!(alias(src, "::a"), Some(("b".to_string(), vec![])));
1889:         assert_eq!(alias(src, "::b"), Some(("expr".to_string(), vec![])));
1890:     }
1891: 
1892:     #[test]
1893:     fn alias_dynamic_name_not_recorded() {
1894:         assert!(alias("set n \"=\"\ninterp alias {} $n {} expr", "::=").is_none());
1895:     }
1896: 
1897:     #[test]
1898:     fn alias_redefinition_overwrites() {
1899:         let src = "interp alias {} myop {} expr\ninterp alias {} myop {} puts\n";
1900:         assert_eq!(alias(src, "::myop"), Some(("puts".to_string(), vec![])));
1901:     }
1902: 
1903:     #[test]
1904:     fn alias_too_few_args_no_crash() {
1905:         assert!(alias("interp alias {} = {}", "::=").is_none());
1906:     }
1907: 
1908:     #[test]
1909:     fn alias_target_in_child_interp_is_domain_qualified_945() {
1910:         // A cross-domain alias deliberately crosses interpreter domains:
1911:         // the current-interp `myexpr` runs the *child's* `expr`, so the
1912:         // recorded target is qualified into the child's `@interp@` domain
1913:         // — never treated as the parent's own `expr` — since skipping the
1914:         // record entirely would lose the cross-domain link.
1915:         assert_eq!(
1916:             alias("interp alias {} myexpr child expr", "::myexpr"),
1917:             Some(("::@interp@child::expr".to_string(), vec![])),
1918:         );
1919:     }
1920: 
1921:     #[test]
1922:     fn alias_query_form_no_crash() {
1923:         assert!(alias("interp alias {} myexpr", "::myexpr").is_none());
1924:     }
1925: 
1926:     #[test]
1927:     fn alias_for_expr_and_body_taking_commands_no_w214() {
1928:         // Aliases for expr / eval / foreach route the role analysis through the
1929:         // alias target, so params used via the alias are not W214.
1930:         let cases = [
1931:             "interp alias {} = {} expr\nproc foo {x y} {\n    set result [= {$x + $y}]\n    return $result\n}\n",
1932:             "interp alias {} myeval {} eval\nproc foo {x} {\n    myeval { set y 1 }\n    return $x\n}\n",
1933:             "interp alias {} myforeach {} foreach\nproc foo {items} {\n    myforeach item $items { puts $item }\n    return $item\n}\n",
1934:         ];
1935:         for src in cases {
1936:             assert!(!fires(src, D, "W214"), "unexpected W214 for {src:?}");
1937:         }
1938:     }
1939: 
1940:     #[test]
1941:     fn alias_resolved_from_namespace_and_global_fallback_no_w214() {
1942:         let cases = [
1943:             "interp alias {} ::math::= {} expr\nnamespace eval math {\n    proc calc {x y} {\n        set result [= {$x + $y}]\n        return $result\n    }\n}\n",
1944:             "interp alias {} = {} expr\nnamespace eval utils {\n    proc calc {x y} {\n        set result [= {$x + $y}]\n        return $result\n    }\n}\n",
1945:             "interp alias {} = {} expr\nproc calc {x y} {\n    set result [::= {$x + $y}]\n    return $result\n}\n",
1946:         ];
1947:         for src in cases {
1948:             assert!(!fires(src, D, "W214"), "unexpected W214 for {src:?}");
1949:         }
1950:     }
1951: 
1952:     #[test]
1953:     fn alias_standalone_expr_call_has_no_error() {
1954:         let src = "interp alias {} = {} expr\n= {1 + 2}\n";
1955:         assert!(
1956:             !analyser_diags(src, D)
1957:                 .iter()
1958:                 .any(|(_, _, s)| *s == Severity::Error)
1959:         );
1960:     }
1961: 
1962:     #[test]
1963:     fn real_world_file_shortcuts_record_extras() {
1964:         let src = "interp alias {} cp {} file copy -force\ninterp alias {} mkdir {} file mkdir\ninterp alias {} rm {} file delete -force\n";
1965:         assert_eq!(
1966:             alias(src, "::cp"),
1967:             Some((
1968:                 "file".to_string(),
1969:                 vec!["copy".to_string(), "-force".to_string()]
1970:             ))
1971:         );
1972:         assert_eq!(
1973:             alias(src, "::mkdir"),
1974:             Some(("file".to_string(), vec!["mkdir".to_string()]))
1975:         );
1976:         assert_eq!(
1977:             alias(src, "::rm"),
1978:             Some((
1979:                 "file".to_string(),
1980:                 vec!["delete".to_string(), "-force".to_string()]
1981:             ))
1982:         );
1983:     }
1984: 
1985:     #[test]
1986:     fn real_world_safe_and_cross_interp_aliases_945() {
1987:         // A dynamic source path bound by a tracked `set i [interp create
1988:         // ...]` resolves through that binding rather
1989:         // than aborting: `add` is defined *inside* `$i`'s domain (calling
1990:         // `::api::add` back in the parent), so it homes under `$i`'s
1991:         // synthetic `@interp@@autoname@<offset>` domain — never under the
1992:         // bare `::add` a plain top-level alias would use.
1993:         let safe = "set i [interp create -safe]\ninterp alias $i add {} ::api::add\nproc ::api::add {a b} {\n    return [expr {$a + $b}]\n}\n";
1994:         assert!(alias(safe, "::add").is_none());
1995:         assert_eq!(
1996:             alias(safe, "::@interp@@autoname@6::add"),
1997:             Some(("::api::add".to_string(), vec![])),
1998:         );
1999:         // A literal parent-side alias into a live child is tracked with a
2000:         // domain-qualified target: `localGreet` runs
2001:         // the child's `greet`, so navigation follows the alias link into
2002:         // the child's `@interp@` domain, where `interp eval` homed the
2003:         // proc's definition.
2004:         let cross = "interp create child\ninterp eval child { proc greet {} { return hello } }\ninterp alias {} localGreet child greet\nlocalGreet\ninterp delete child\n";
2005:         assert_eq!(
2006:             alias(cross, "::localGreet"),
2007:             Some(("::@interp@child::greet".to_string(), vec![])),
2008:         );
2009:     }
2010: 
2011:     #[test]
2012:     fn real_world_dynamic_html_tag_aliases_not_tracked() {
2013:         let src = "proc html_tag {tag args} { return \"<$tag>$args</$tag>\" }\nforeach tag {h1 h2 h3 p div span} {\n    interp alias {} $tag {} html_tag $tag\n}\n";
2014:         assert!(alias(src, "::h1").is_none());
2015:     }
2016: 
2017:     #[test]
2018:     fn alias_deletion_form_keeps_prior_definition() {
2019:         // `interp alias {} name {}` (4 args) deletes; not recorded as a new
2020:         // alias, and the prior definition survives (we don't track deletions).
2021:         let src = "interp alias {} myalias {} list\ninterp alias {} myalias {}\n";
2022:         assert_eq!(alias(src, "::myalias"), Some(("list".to_string(), vec![])));
2023:     }
2024: 
2025:     #[test]
2026:     fn return_expr_alias_and_braced_no_w214() {
2027:         let cases = [
2028:             "proc foo {x} { return [expr {$x + 1}] }",
2029:             "interp alias {} = {} expr\nproc pdPsCalc {width length} {\n    return [= {2*$width+2*$length}]\n}\n",
2030:         ];
2031:         for src in cases {
2032:             assert!(!fires(src, D, "W214"), "unexpected W214 for {src:?}");
2033:         }
2034:     }
2035: 
2036:     #[test]
2037:     fn issue_42_examples_no_w214() {
2038:         let original = "interp alias {} = {} expr\nproc moveKeyInDict {dict key relPos} {\n    set keys [dkeys $dict]\n    set index [lsearch -exact $keys $key]\n    set newIndex [= {$index+$relPos}]\n    set prevKey [@ $keys $newIndex]\n    set newKeysOrder [lreplace [lreplace $keys $index $index $prevKey] $newIndex $newIndex $key]\n    foreach key $newKeysOrder {\n        dict append newDict $key [dget $dict $key]\n    }\n    return $newDict\n}\n";
2039:         assert!(!fires(original, D, "W214"));
2040:         let reopened = "interp alias {} = {} expr\nset scriptPath [file dirname [file normalize [info script]]]\nproc pdPsCalc {width length} {\n    return [= {2*$width+2*$length}]\n}\nset vSupply 2.0\nset inpFreq 850e6\n";
2041:         assert!(!fires(reopened, D, "W214"));
2042:     }
2043: }
2044: 
2045: // interp_value_flow — `set VAR [interp create ...]`
2046: // binds VAR to an interpreter-domain key, so a later dynamic `$VAR` operand
2047: // to `interp alias` / `interp eval` / the handle's own object command can
2048: // resolve through the tracked binding instead of abstaining outright.
2049: mod interp_value_flow {
2050:     use super::*;
2051: 
2052:     fn command_alias_targets(src: &str) -> std::collections::HashMap<String, String> {
2053:         Analyser::new()
2054:             .analyse(src, D)
2055:             .command_aliases
2056:             .iter()
2057:             .map(|(k, v)| (k.clone(), v.target.as_str().to_owned()))
2058:             .collect()
2059:     }
2060: 
2061:     #[test]
2062:     fn primary_repro_cross_domain_alias_through_tracked_binding_resolves() {
2063:         // TP: tclsh9.0-verified, prints 42. `set s [interp create -safe]`
2064:         // binds `s`; `interp alias $s greet {} ::app::Helper` must resolve
2065:         // through that binding rather than abstaining outright because the
2066:         // source path is dynamic text — otherwise `greet` is left
2067:         // unresolved inside the child's eval body (spurious W123 + 0
2068:         // definition locations).
2069:         let src = "namespace eval ::app {}\nproc ::app::Helper {} { return 42 }\nset s [interp create -safe]\ninterp alias $s greet {} ::app::Helper\ninterp eval $s { greet }\n";
2070:         assert!(codes(src, D).is_empty(), "{:?}", codes(src, D));
2071:     }
2072: 
2073:     #[test]
2074:     fn object_command_handle_eval_form_resolves_through_tracked_binding() {
2075:         // TP — the object-command spelling (`$mpip eval { ... }`) doctools.tcl
2076:         // actually uses, exercising `handle_interp_handle_eval_command` rather
2077:         // than the literal `interp eval PATH` form. `$mpip eval {...}` is
2078:         // itself a non-literal command dispatch — `mpip` is tracked only as
2079:         // an interpreter handle, not a known TclOO object
2080:         // (`var_command.rs`'s separate, unrelated dispatch-suppression
2081:         // system), so it legitimately still draws W307 the same as any
2082:         // other untracked `$var subcommand` call. What this fix controls is
2083:         // narrower: `greet` must resolve *inside* the eval body — no W123
2084:         // (unknown command) and no W140 (never-created interpreter).
2085:         let src = "namespace eval ::app {}\nproc ::app::Helper {} { return 42 }\nset mpip [interp create -safe]\ninterp alias $mpip greet {} ::app::Helper\n$mpip eval { greet }\n";
2086:         let diags = analyser_diags(src, D);
2087:         assert!(
2088:             diags.iter().all(|(c, _, _)| c != "W123" && c != "W140"),
2089:             "{diags:?}"
2090:         );
2091:     }
2092: 
2093:     #[test]
2094:     fn explicit_literal_name_variant_records_no_spurious_w140() {
2095:         // TP — `set s [interp create -safe literalName]` must record
2096:         // `literalName` in the interpreter map via the value-flow path, so a
2097:         // later literal `interp eval literalName {...}` does not see an
2098:         // apparently-uncreated interpreter, even though the path never
2099:         // reaches `handle_interp_create_command` directly (it's nested
2100:         // inside a `set`, not a bare top-level statement).
2101:         let src = "namespace eval ::app {}\nproc ::app::Helper {} { return 42 }\nset s [interp create -safe literalName]\ninterp alias literalName greet {} ::app::Helper\ninterp eval literalName { greet }\n";
2102:         assert!(!fires(src, D, "W140"), "{:?}", codes(src, D));
2103:     }
2104: 
2105:     #[test]
2106:     fn two_procs_sharing_a_variable_name_never_collide() {
2107:         // TP — cross-contamination guard: each proc's
2108:         // `set s [interp create -safe]` must get its own per-call-site
2109:         // `@autoname@<offset>` domain, not one shared domain keyed off the
2110:         // raw variable text `s` — sharing one domain would let makeA's
2111:         // `helper` call resolve into makeB's definition.
2112:         let src = "proc makeA {} {\n    set s [interp create -safe]\n    interp eval $s {\n        proc helper {} { return A }\n        helper\n    }\n}\nproc makeB {} {\n    set s [interp create -safe]\n    interp eval $s {\n        proc helper {} { return B }\n        helper\n    }\n}\n";
2113:         let r = Analyser::new().analyse(src, D);
2114:         let helper_keys: Vec<&String> = r
2115:             .all_procs
2116:             .keys()
2117:             .filter(|k| k.ends_with("::helper"))
2118:             .collect();
2119:         assert_eq!(
2120:             helper_keys.len(),
2121:             2,
2122:             "expected 2 distinct helper domains: {:?}",
2123:             r.all_procs.keys().collect::<Vec<_>>()
2124:         );
2125:         assert_ne!(helper_keys[0], helper_keys[1]);
2126:     }
2127: 
2128:     #[test]
2129:     fn untracked_dynamic_interp_path_stays_conservative() {
2130:         // FP guard — a `$VAR` never bound by `set VAR [interp create ...]`
2131:         // (here a bare proc parameter) must stay exactly as conservative as
2132:         // before this fix: no crash, no spurious W140 (existence stays
2133:         // unknowable for a genuinely untracked dynamic path).
2134:         let src = "proc useEval {ip} {\n    interp eval $ip { someCmd }\n}\n";
2135:         assert!(!fires(src, D, "W140"), "{:?}", codes(src, D));
2136:     }
2137: 
2138:     #[test]
2139:     fn reassigning_the_variable_clears_the_stale_interp_binding() {
2140:         // FP guard — a later plain-string `set` of the same variable must
2141:         // clear the interp binding, so a stale domain is never resolved and
2142:         // the cross-domain alias falls through exactly as it does today for
2143:         // a genuinely-unresolvable dynamic src_path.
2144:         let src = "namespace eval ::app {}\nproc ::app::Helper {} { return 42 }\nset mpip [interp create -safe]\nset mpip \"not an interpreter\"\ninterp alias $mpip greet {} ::app::Helper\n";
2145:         assert!(
2146:             command_alias_targets(src).is_empty(),
2147:             "{:?}",
2148:             command_alias_targets(src)
2149:         );
2150:     }
2151: 
2152:     #[test]
2153:     fn existing_literal_top_level_behaviour_is_unchanged() {
2154:         // TN — byte-for-byte unchanged control (scratchpad/audit/a): the
2155:         // same shape as the primary repro, but with a literal path
2156:         // throughout instead of a tracked variable binding.
2157:         let src = "namespace eval ::app {}\nproc ::app::Helper {} { return 42 }\ninterp create -safe s\ninterp alias s greet {} ::app::Helper\ninterp eval s { greet }\n";
2158:         assert!(codes(src, D).is_empty(), "{:?}", codes(src, D));
2159:     }
2160: 
2161:     #[test]
2162:     fn builtins_only_dynamic_interp_eval_body_stays_silent() {
2163:         // TN — a tracked dynamic-path eval body containing only builtins
2164:         // must stay diagnostic-free, confirming the fix doesn't newly
2165:         // over-fire (scratchpad/audit/c).
2166:         let src = "set s [interp create -safe]\ninterp eval $s {\n    set x 1\n    expr {$x + 1}\n    puts \"hi\"\n}\n";
2167:         assert!(codes(src, D).is_empty(), "{:?}", codes(src, D));
2168:     }
2169: 
2170:     #[test]
2171:     fn builtins_only_literal_interp_eval_body_stays_silent() {
2172:         // TN — the same false-fire (W210 on `x`) reproduced with a *literal*
2173:         // interpreter path, no dynamic tracking involved at all: `interp
2174:         // eval`'s script argument is a `Plain`-body-kind `ArgRole::Body`
2175:         // (unlike an `if`/`while`/`catch` body, never flattened into its
2176:         // own CFG since the target interpreter is opaque to static
2177:         // analysis), so it was scanned as ordinary value text with no
2178:         // notion of its own `set x 1` write before the later `$x` read.
2179:         let src = "interp create child\ninterp eval child {\n    set x 1\n    expr {$x + 1}\n}\n";
2180:         assert!(codes(src, D).is_empty(), "{:?}", codes(src, D));
2181:     }
2182: 
2183:     /// The `@interp@<key>` synthetic namespaces a source's definitions
2184:     /// land in — the observable projection of the interpreter-domain key.
2185:     fn interp_domains(src: &str) -> Vec<String> {
2186:         let mut keys: Vec<String> = Analyser::new()
2187:             .analyse(src, D)
2188:             .all_procs
2189:             .keys()
2190:             .filter_map(|k| k.split("::").find(|s| s.starts_with("@interp@")))
2191:             .map(str::to_owned)
2192:             .collect();
2193:         keys.sort();
2194:         keys.dedup();
2195:         keys
2196:     }
2197: 
2198:     #[test]
2199:     fn braced_path_value_flow_key_matches_the_direct_handler_issue_1025() {
2200:         // TP — `interp create {child}` names interpreter `child`
2201:         // (tclsh8.6/9.0: `interp exists child` → 1, `interp slaves` →
2202:         // `child`). The value-flow path must not `split_whitespace` the raw
2203:         // substitution text: doing so would bind `$i` to `"{child}"`, a
2204:         // domain the direct handler never records.
2205:         let via_value = "set i [interp create {child}]\n$i eval { proc helper {} {} }\n";
2206:         let direct = "interp create {child}\ninterp eval child { proc helper {} {} }\n";
2207:         assert_eq!(
2208:             interp_domains(via_value),
2209:             interp_domains(direct),
2210:             "value-flow and direct keys must agree"
2211:         );
2212:         assert_eq!(interp_domains(via_value), vec!["@interp@child".to_string()]);
2213:     }
2214: 
2215:     #[test]
2216:     fn nested_path_value_flow_key_matches_the_direct_handler_issue_1025() {
2217:         // TP — `{parent child}` is one word: a descent path (tclsh8.6/9.0:
2218:         // `interp create {parent child}` returns `parent child` and
2219:         // `interp slaves parent` → `child`). `split_whitespace` must not
2220:         // split it into `"{parent"` + `"child}"` and bind the first
2221:         // fragment.
2222:         let via_value = "interp create parent\nset i [interp create {parent child}]\n$i eval { proc helper {} {} }\n";
2223:         let direct = "interp create parent\ninterp create {parent child}\ninterp eval {parent child} { proc helper {} {} }\n";
2224:         assert_eq!(interp_domains(via_value), interp_domains(direct));
2225:         assert!(
2226:             interp_domains(via_value).contains(&"@interp@parent child".to_string()),
2227:             "{:?}",
2228:             interp_domains(via_value)
2229:         );
2230:     }
2231: 
2232:     #[test]
2233:     fn braced_path_binding_links_a_later_literal_eval_issue_1025() {
2234:         // TP — the linkage the diverging key broke: a proc defined through
2235:         // the tracked `$i eval` handle must resolve for a later literal
2236:         // `interp eval child` call, with no W123.
2237:         let src = "set i [interp create {child}]\n$i eval { proc helper {} { return 1 } }\ninterp eval child { helper }\n";
2238:         assert!(!fires(src, D, "W123"), "{:?}", codes(src, D));
2239:         assert!(!fires(src, D, "W140"), "{:?}", codes(src, D));
2240:     }
2241: 
2242:     #[test]
2243:     fn synthetic_autoname_key_used_for_pathless_interp_create() {
2244:         // TP — pins the synthetic per-call-site key convention (mirrors
2245:         // `handle_namespace_eval_dynamic_target_gets_a_synthetic_span_keyed_name`'s
2246:         // `@dynns@15` pin): a pathless `interp create` inside `set` gets an
2247:         // `@autoname@<offset-of-the-substitution's-opening-bracket>` key,
2248:         // not the variable's raw text, so `foo`'s definition homes under a
2249:         // synthetic, call-site-unique domain rather than one keyed on `s`.
2250:         let src = "set s [interp create -safe]\ninterp eval $s { proc foo {} {} }\n";
2251:         let r = Analyser::new().analyse(src, D);
2252:         assert!(
2253:             r.all_procs.keys().any(|k| k.contains("@autoname@6")),
2254:             "{:?}",
2255:             r.all_procs.keys().collect::<Vec<_>>()
2256:         );
2257:     }
2258: }
2259: 
2260: // rename — constant-folding a dynamic-but-resolvable
2261: // `rename OLD NEW` argument instead of unconditionally giving up.
2262: mod rename {
2263:     use super::*;
2264: 
2265:     fn renamed_commands(src: &str) -> std::collections::HashMap<String, String> {
2266:         Analyser::new().analyse(src, D).renamed_commands.clone()
2267:     }
2268: 
2269:     #[test]
2270:     fn static_rename_recorded_unchanged() {
2271:         // TN — control check: a fully literal rename never even reaches
2272:         // the new constant-folding resolver and must keep working
2273:         // byte-for-byte as before.
2274:         let src = "proc ::foo_impl {} { return impl }\nrename ::foo_impl ::foo\n";
2275:         assert_eq!(
2276:             renamed_commands(src).get("::foo"),
2277:             Some(&"::foo_impl".to_string())
2278:         );
2279:     }
2280: 
2281:     #[test]
2282:     fn single_var_old_name_resolves_via_constant_folding() {
2283:         // TP — finding's own simplest repro #1: a single whole-word
2284:         // `$var` holding a known-constant command name.
2285:         let src = "proc ::foo_impl {} { return impl }\nset old ::foo_impl\nrename $old ::foo\n";
2286:         assert_eq!(
2287:             renamed_commands(src).get("::foo"),
2288:             Some(&"::foo_impl".to_string())
2289:         );
2290:     }
2291: 
2292:     #[test]
2293:     fn concatenated_var_new_name_resolves_via_constant_folding() {
2294:         // TP — finding's own simplest repro #2: a literal-plus-`$var`
2295:         // concatenation.
2296:         let src = "proc ::foo_impl {} { return impl }\nset key impl\nrename ::foo_$key ::foo\n";
2297:         assert_eq!(
2298:             renamed_commands(src).get("::foo"),
2299:             Some(&"::foo_impl".to_string())
2300:         );
2301:     }
2302: 
2303:     #[test]
2304:     fn two_concatenated_vars_in_same_straight_line_scope_resolve() {
2305:         // TP — both OLD and NEW built from resolvable variables in the
2306:         // same straight-line proc scope, the closest Tier-1-fixable
2307:         // approximation of the tcllib `json::SwitchTo` idiom (which
2308:         // additionally needs a `foreach` var and a proc parameter — see
2309:         // the two FN tests below, deliberately out of scope for Tier 1).
2310:         let src = "namespace eval ::mypkg {}\n\
2311:              proc ::mypkg::greet_tcl {name} { return \"hi $name\" }\n\
2312:              proc ::mypkg::activate {} {\n    \
2313:                  set c greet\n    \
2314:                  set key tcl\n    \
2315:                  rename ::mypkg::${c}_$key ::mypkg::${c}\n\
2316:              }\n";
2317:         assert_eq!(
2318:             renamed_commands(src).get("::mypkg::greet"),
2319:             Some(&"::mypkg::greet_tcl".to_string())
2320:         );
2321:     }
2322: 
2323:     #[test]
2324:     fn genuinely_dynamic_value_stays_unresolved() {
2325:         // TN — regression guard against over-eager folding: a value
2326:         // that's never a compile-time constant (piped through `gets`)
2327:         // must still be reported dynamic (no entry recorded).
2328:         let src = "proc ::foo_impl {} { return impl }\nset old [gets stdin]\nrename $old ::foo\n";
2329:         assert!(!renamed_commands(src).contains_key("::foo"));
2330:     }
2331: 
2332:     #[test]
2333:     fn foreach_loop_variable_over_a_literal_list_is_constant_folded() {
2334:         // A `foreach VAR {literal list} { ... }` loop over a fully
2335:         // literal list must bind `VAR` to each element in turn before
2336:         // simulating the body's own `rename`/`proc` sub-commands (the two
2337:         // constant-fold-sensitive callers go-to-definition/references/
2338:         // rename care about), rather than leaving the loop variable out of
2339:         // the constant-string lattice entirely. `renamed_commands` is
2340:         // populated the same as if `c` had been a plain top-level `set`
2341:         // constant.
2342:         let src =
2343:             "proc ::foo_impl {} { return impl }\nforeach c {foo} { rename ::${c}_impl ::${c} }\n";
2344:         assert_eq!(
2345:             renamed_commands(src).get("::foo"),
2346:             Some(&"::foo_impl".to_string())
2347:         );
2348:     }
2349: 
2350:     #[test]
2351:     fn foreach_over_a_braced_list_element_is_not_mis_split_on_whitespace() {
2352:         // The literal-`foreach` simulation must parse its value as a real
2353:         // Tcl list, not with `split_whitespace`: a braced element
2354:         // `{bar baz}` in `foreach c {a {bar baz}} { proc ::$c {} {} }` is
2355:         // exactly two elements — `a` and `bar baz` — never `{bar` + `baz}`,
2356:         // so the re-dispatched `proc` never creates bogus commands
2357:         // `::{bar` / `::baz}` and no brace-fragment proc is ever recorded.
2358:         let procs = Analyser::new()
2359:             .analyse("foreach c {a {bar baz}} { proc ::$c {} {} }\n", D)
2360:             .all_procs;
2361:         assert!(
2362:             !procs.keys().any(|k| k.contains('{') || k.contains('}')),
2363:             "no brace-fragment proc from a mis-split braced element: {:?}",
2364:             procs.keys().collect::<Vec<_>>()
2365:         );
2366:     }
2367: 
2368:     #[test]
2369:     fn rename_target_set_only_in_a_conditional_branch_does_not_resolve() {
2370:         // A `rename`/`source` target read from the last-write-wins const map
2371:         // is unsound across an `if` join. Here `t`
2372:         // is `::foo` straight-line but reassigned `::bar` inside an `if`
2373:         // body, so at the `rename` it could be either — the analyser must
2374:         // abstain (leave the rename dynamic), never pin it to the branch
2375:         // value `::bar` the lexical map happens to hold last.
2376:         let renamed = renamed_commands(
2377:             "proc ::foo_impl {} {}\nset t ::foo\nif {$cond} { set t ::bar }\nrename ::foo_impl $t\n",
2378:         );
2379:         assert!(
2380:             !renamed.contains_key("::bar") && !renamed.contains_key("::foo"),
2381:             "a branch-dependent rename target must not resolve to either branch: {renamed:?}"
2382:         );
2383:     }
2384: 
2385:     #[test]
2386:     fn rename_target_set_straight_line_still_resolves() {
2387:         // Control for the above: without the conditional, the single
2388:         // straight-line `set` dominates the `rename`, so it still resolves.
2389:         let renamed =
2390:             renamed_commands("proc ::foo_impl {} {}\nset t ::foo\nrename ::foo_impl $t\n");
2391:         assert_eq!(renamed.get("::foo"), Some(&"::foo_impl".to_string()));
2392:     }
2393: 
2394:     #[test]
2395:     fn proc_parameter_is_not_constant_folded() {
2396:         // FN (expected, documented — explicitly out of scope: closing this
2397:         // needs interprocedural single-call-site literal-argument
2398:         // propagation, a materially larger, separate feature).
2399:         let src = "proc ::foo_impl {} { return impl }\n\
2400:              proc activate {key} { rename ::foo_$key ::foo }\n\
2401:              activate impl\n";
2402:         assert!(!renamed_commands(src).contains_key("::foo"));
2403:     }
2404: 
2405:     #[test]
2406:     fn resolvable_dynamic_rename_no_longer_widens_has_dynamic_providers() {
2407:         // TN: a dynamic-*looking* rename that resolves statically must not
2408:         // set `has_dynamic_providers` — which otherwise blanket-suppresses
2409:         // W123 for the whole file (diagnostics/unresolved.rs) — so W123
2410:         // keeps firing on genuinely unknown commands elsewhere in the file.
2411:         let src = "proc ::foo_impl {} { return impl }\nset old ::foo_impl\nrename $old ::foo\n";
2412:         assert!(!Analyser::new().analyse(src, D).has_dynamic_providers);
2413:     }
2414: 
2415:     #[test]
2416:     fn unresolvable_rename_still_widens_has_dynamic_providers() {
2417:         // TN — control check for the above: a genuinely unresolvable
2418:         // dynamic rename must still widen `has_dynamic_providers`.
2419:         let src = "proc ::foo_impl {} { return impl }\nset old [gets stdin]\nrename $old ::foo\n";
2420:         assert!(Analyser::new().analyse(src, D).has_dynamic_providers);
2421:     }
2422: }
2423: 
2424: // EvalUplevelIndirectDispatch — a bare `$var` body of an
2425: // `ArgRole::Body`-marked argument (`eval $cmd`, `uplevel #0 $cmd …`)
2426: // dynamically evaluates $var's value as a script at runtime, whose first
2427: // word is the command actually dispatched. `command_invocations` must
2428: // record it: hover/go-to-definition reach it via an independent
2429: // cursor-token walk, but references/rename read `command_invocations`
2430: // directly, so it must appear there too.
2431: mod eval_uplevel_indirect_dispatch {
2432:     use super::*;
2433: 
2434:     fn invocations(
2435:         src: &str,
2436:     ) -> Vec<tcl_compiler::signature_scan::types::SignatureCommandInvocation> {
2437:         Analyser::new().analyse(src, D).command_invocations.clone()
2438:     }
2439: 
2440:     #[test]
2441:     fn eval_of_a_list_computed_var_resolves_the_real_head() {
2442:         // TP — the finding's own minimal repro: `eval $cmdD` where `$cmdD`
2443:         // is built via `[list greetD World]` — a computed value, not a
2444:         // simple lexical literal the *lowering*-phase's simpler const-map
2445:         // can fold (see `try_lower_eval_static`'s `const_map_lookup`), so
2446:         // only the analyser's own flow-sensitive SSA-based
2447:         // `settle_const_dispatches` can resolve it. Real tclsh9.0/8.6-
2448:         // verified: `eval $cmdD` dispatches to `greetD World`.
2449:         let src = "proc greetD {n} {puts \"D $n\"}\nset cmdD [list greetD World]\neval $cmdD\n";
2450:         let invs = invocations(src);
2451:         assert!(
2452:             invs.iter()
2453:                 .any(|i| i.indirect && i.resolved_qualified_name.as_deref() == Some("::greetD")),
2454:             "expected an indirect invocation resolving to ::greetD: {invs:?}"
2455:         );
2456:         // The `greetD` word inside `[list greetD World]` is also a
2457:         // separate, *direct*, rename-writable invocation at its own span
2458:         // (byte 45..51, `&src[45..51] == "greetD"`) — the actual command
2459:         // name as written, not just the `$cmdD` dispatch anchor.
2460:         assert!(
2461:             invs.iter().any(|i| !i.indirect
2462:                 && i.rename_safe
2463:                 && i.range == tcl_lexer::Span::new(45, 51)
2464:                 && i.resolved_qualified_name.as_deref() == Some("::greetD")),
2465:             "expected a direct, rename-safe invocation anchored on greetD's own word: {invs:?}"
2466:         );
2467:     }
2468: 
2469:     #[test]
2470:     fn uplevel_hash_zero_of_a_var_headed_script_resolves_the_real_head() {
2471:         // TP — the real `tk/library/tearoff.tcl` `MenuDup`-analogue shape:
2472:         // `uplevel #0 $cmd [list $w $newMenu]`. `$cmd`'s own value is the
2473:         // command name; the trailing `[list …]` argument supplies its
2474:         // arguments (uplevel concatenates all its post-level arguments into
2475:         // one script). tclsh9.0/8.6-verified: dispatches to `target`.
2476:         let src =
2477:             "proc target {a b} {puts \"$a-$b\"}\nset cmd target\nuplevel #0 $cmd [list x y]\n";
2478:         let invs = invocations(src);
2479:         assert!(
2480:             invs.iter()
2481:                 .any(|i| i.indirect && i.resolved_qualified_name.as_deref() == Some("::target")),
2482:             "expected an indirect invocation resolving to ::target: {invs:?}"
2483:         );
2484:     }
2485: 
2486:     #[test]
2487:     fn plain_eval_of_a_braced_literal_body_is_unaffected() {
2488:         // TN — control check: the ordinary literal-body `eval {…}` shape
2489:         // (handled entirely by `analyse_body`'s existing `Str`-token path)
2490:         // must keep resolving exactly as before; the new `Var`-token branch
2491:         // is additive, not a replacement.
2492:         let src = "proc target {} { return hi }\neval { target }\n";
2493:         let invs = invocations(src);
2494:         assert!(
2495:             invs.iter()
2496:                 .any(|i| !i.indirect && i.resolved_qualified_name.as_deref() == Some("::target")),
2497:             "expected a direct (non-indirect) invocation resolving to ::target: {invs:?}"
2498:         );
2499:     }
2500: 
2501:     #[test]
2502:     fn genuinely_dynamic_eval_body_stays_unresolved() {
2503:         // TN — regression guard: a value with no provable constant origin
2504:         // (piped through `gets`) must still abstain — no invocation
2505:         // recorded, matching the analyser's existing conservative default.
2506:         let src = "proc target {} { return hi }\nset cmd [gets stdin]\neval $cmd\n";
2507:         let invs = invocations(src);
2508:         assert!(
2509:             !invs
2510:                 .iter()
2511:                 .any(|i| i.resolved_qualified_name.as_deref() == Some("::target")),
2512:             "a genuinely dynamic eval body must not resolve: {invs:?}"
2513:         );
2514:     }
2515: 
2516:     #[test]
2517:     fn resolves_identically_inside_a_proc_body() {
2518:         // TN (confirms a hypothesis in the finding's own root-cause hint is
2519:         // moot): the auditor flagged "worth checking whether per-proc
2520:         // FunctionUnits reach settle_one_site with usable SSA/def-use data
2521:         // the same way the top-level unit does" as a second, compounding
2522:         // gap. Empirically it isn't one — `function_unit_at`/
2523:         // `const_contributors` have no top-level-vs-proc special-casing,
2524:         // and this resolves identically to the top-level repro above.
2525:         let src = "proc greetD {n} {puts \"D $n\"}\nproc caller {} {\n    set cmdD [list greetD World]\n    eval $cmdD\n}\n";
2526:         let invs = invocations(src);
2527:         assert!(
2528:             invs.iter()
2529:                 .any(|i| i.indirect && i.resolved_qualified_name.as_deref() == Some("::greetD")),
2530:             "expected an indirect invocation resolving to ::greetD even inside a proc body: {invs:?}"
2531:         );
2532:     }
2533: }
2534: 
2535: // `apply [list {params} {body} ns]` — the list-constructor lambda idiom.
2536: // Each list element must reach the body walk with its list delimiters
2537: // removed, exactly as a literal braced lambda does.
2538: mod apply_list_lambda {
2539:     use super::*;
2540: 
2541:     #[test]
2542:     fn apply_list_constructor_body_element_is_delimiter_stripped() {
2543:         // `resolve_dynamic_apply_lambda`'s `[list …]` path must strip each
2544:         // element's list delimiters (zipped from the segmenter's `texts`,
2545:         // the same shape the literal-lambda path uses) rather than slicing
2546:         // raw source spans — otherwise a `{frobnicate arg}` body element
2547:         // keeps its braces, the body re-segments as a single braced word,
2548:         // and the real `frobnicate` call is never seen. With delimiters
2549:         // stripped, the body walks as `frobnicate arg` and records
2550:         // `frobnicate` as its own command invocation.
2551:         let invs = Analyser::new()
2552:             .analyse("apply [list {} {frobnicate arg} ::myns]\n", D)
2553:             .command_invocations;
2554:         assert!(
2555:             invs.iter().any(|i| i.name == "frobnicate"),
2556:             "apply [list ...] body must segment to the real `frobnicate` call: {:?}",
2557:             invs.iter().map(|i| &i.name).collect::<Vec<_>>()
2558:         );
2559:     }
2560: }
2561: 
2562: // `::tcl::dict::*` standalone spellings must carry the same analysis
2563: // contract as the `dict` subcommands they mirror, not a
2564: // `CommandSpec::DEFAULT` stub.
2565: mod dict_qualified_specs {
2566:     use super::*;
2567: 
2568:     #[test]
2569:     fn qualified_dict_for_binds_loop_vars_and_walks_body() {
2570:         // The standalone `::tcl::dict::for` must carry `dict for`'s arg-roles
2571:         // (`LoopVarList` + `Body`) and its `DictFor` analyser hook, so its
2572:         // body is analysed and `k`/`v` are bound — `CommandSpec::DEFAULT`
2573:         // left it inert, so a call inside the body was never seen.
2574:         let invs = Analyser::new()
2575:             .analyse(
2576:                 "set d {a 1 b 2}\n::tcl::dict::for {k v} $d { frobnicate $k $v }\n",
2577:                 D,
2578:             )
2579:             .command_invocations;
2580:         assert!(
2581:             invs.iter().any(|i| i.name == "frobnicate"),
2582:             "::tcl::dict::for body must be analysed like dict for: {:?}",
2583:             invs.iter().map(|i| &i.name).collect::<Vec<_>>()
2584:         );
2585:     }
2586: 
2587:     #[test]
2588:     fn qualified_dict_set_body_walks_a_nested_dict_for() {
2589:         // A `::tcl::dict::for` nested inside another command's body still
2590:         // carries its analysis contract, so the inner body's own call is
2591:         // seen — a stronger check than a top-level call that the generic
2592:         // walk would reach anyway.
2593:         let invs = Analyser::new()
2594:             .analyse(
2595:                 "proc p {d} { ::tcl::dict::for {k v} $d { frobnicate $k } }\n",
2596:                 D,
2597:             )
2598:             .command_invocations;
2599:         assert!(
2600:             invs.iter().any(|i| i.name == "frobnicate"),
2601:             "nested ::tcl::dict::for body must be analysed: {:?}",
2602:             invs.iter().map(|i| &i.name).collect::<Vec<_>>()
2603:         );
2604:     }
2605: }
2606: 
2607: // TestW123UnresolvedCommand — unknown-command detection.
2608: mod unresolved_command {
2609:     use super::*;
2610: 
2611:     fn w123(src: &str) -> Vec<String> {
2612:         analyser_diags(src, D)
2613:             .into_iter()
2614:             .filter(|(c, _, _)| c == "W123")
2615:             .map(|(_, m, _)| m)
2616:             .collect()
2617:     }
2618: 
2619:     #[test]
2620:     fn unknown_command_emits_w123() {
2621:         let d = w123("mycommand a b c");
2622:         assert_eq!(d.len(), 1);
2623:         assert!(d[0].contains("mycommand"));
2624:     }
2625: 
2626:     #[test]
2627:     fn known_builtin_and_user_proc_no_w123() {
2628:         assert!(w123("set x 1").is_empty());
2629:         assert!(w123("proc mycommand {x} { puts $x }\nmycommand hello").is_empty());
2630:         // Forward-defined proc still suppresses.
2631:         assert!(w123("mycommand hello\nproc mycommand {x} { puts $x }").is_empty());
2632:     }
2633: 
2634:     #[test]
2635:     fn namespace_qualified_and_variable_command_skipped() {
2636:         assert!(w123("::myns::cmd arg1").is_empty());
2637:         // `$cmd hello` — the head starts with `$`, not a literal command name.
2638:         assert!(
2639:             w123("set cmd puts\n$cmd hello")
2640:                 .iter()
2641:                 .all(|m| !m.contains("$cmd"))
2642:         );
2643:     }
2644: 
2645:     #[test]
2646:     fn package_require_suppresses_w123() {
2647:         // A `package require` may register the missing command at runtime →
2648:         // suppressed (e.g. `package require Tk` provides `button`).
2649:         assert!(w123("package require Tk\nbutton .b -text hi").is_empty());
2650:     }
2651: 
2652:     #[test]
2653:     fn dynamic_providers_suppress_w123() {
2654:         // `has_dynamic_providers` gates W123 exactly as it gates W120: a
2655:         // `load` / `auto_path` mutation / dynamic import may register
2656:         // commands at runtime the analyser can't see, so the resolvable
2657:         // command set is unknowable and W123 must abstain file-wide.
2658:         for src in [
2659:             "load mylib.so\nmycommand arg1",
2660:             "lappend auto_path /opt/mylib\nmycmd arg",
2661:             "namespace import ::foo::[computed]::*\nbar arg",
2662:         ] {
2663:             assert!(w123(src).is_empty(), "expected no W123 for {src:?}");
2664:         }
2665:     }
2666: 
2667:     #[test]
2668:     fn glob_namespace_import_suppresses_matching_tail_only() {
2669:         // A literal glob import provides every source command matching the
2670:         // pattern's tail — `render_box` matches `render_*` (silent), while an
2671:         // unrelated name matches nothing and still fires.
2672:         let src = "namespace import ::acme::widgets::render_*\nrender_box 10 20\nfrobnicate 1\n";
2673:         let d = w123(src);
2674:         assert_eq!(d.len(), 1, "only the unrelated name fires; got {d:?}");
2675:         assert!(d[0].contains("frobnicate"));
2676:         // A full `*` tail conservatively resolves every bare name (the
2677:         // imported namespace's export set is unknowable single-file).
2678:         assert!(w123("namespace import ::foo::*\nbar arg").is_empty());
2679:     }
2680: 
2681:     #[test]
2682:     fn literal_namespace_import_suppresses_exactly_that_name() {
2683:         let src =
2684:             "namespace import ::acme::widgets::render_box\nrender_box 10 20\nrender_circle 5\n";
2685:         let d = w123(src);
2686:         assert_eq!(d.len(), 1, "only the un-imported name fires; got {d:?}");
2687:         assert!(d[0].contains("render_circle"));
2688:     }
2689: 
2690:     #[test]
2691:     fn bare_dict_ensemble_builtin_resolves_from_inside_tcl_dict_namespace() {
2692:         // FP: `exists`/`get` are real,
2693:         // separately-callable commands (`::tcl::dict::exists`,
2694:         // `::tcl::dict::get`), backing the `dict` ensemble's own
2695:         // subcommands (confirmed against tclsh9.0.4/8.6.14: `info commands
2696:         // ::tcl::dict::*` lists them). A proc lexically defined *inside*
2697:         // `::tcl::dict` (the real tcllib `dicttool.tcl` idiom) resolves a
2698:         // bare call to them via ordinary current-namespace-then-global
2699:         // lookup, so it must not fire W123 — isolated from any
2700:         // `namespace ensemble configure` patching (tested separately) to
2701:         // prove this half is a pure namespace-resolution fact.
2702:         let src = "proc ::tcl::dict::myhelper {d k} {\n\
2703:              if {[exists $d $k]} { return [get $d $k] }\n\
2704:              return MISSING\n\
2705:              }\n\
2706:              ::tcl::dict::myhelper [dict create a 1 b 2] a\n";
2707:         assert!(w123(src).is_empty(), "got {:?}", w123(src));
2708:     }
2709: 
2710:     #[test]
2711:     fn bare_dict_ensemble_builtin_outside_tcl_dict_namespace_still_fires_w123() {
2712:         // TP — regression guard: `exists`/`get` called bare *outside*
2713:         // `::tcl::dict` must still fire (tclsh-confirmed real error:
2714:         // "invalid command name \"exists\"") — proves the fix is properly
2715:         // namespace-scoped, not a blanket allow-list for these two names.
2716:         let d = w123("proc foo {} { return [exists bar] }\n");
2717:         assert_eq!(d.len(), 1, "got {d:?}");
2718:         assert!(d[0].contains("exists"));
2719:     }
2720: 
2721:     #[test]
2722:     fn fully_qualified_tcl_dict_builtin_calls_are_unaffected() {
2723:         // TN — regression guard: the qualified spelling already worked via
2724:         // the pre-existing `name.contains("::")` conservative skip; the new
2725:         // resolution-candidate check must not change that.
2726:         let src = "proc demo {} {\n\
2727:              set d [dict create a 1 b 2]\n\
2728:              if {[::tcl::dict::exists $d a]} { return [::tcl::dict::get $d a] }\n\
2729:              }\n";
2730:         assert!(w123(src).is_empty(), "got {:?}", w123(src));
2731:     }
2732: 
2733:     #[test]
2734:     fn ordinary_namespace_bare_name_resolution_is_unaffected_by_dict_fix() {
2735:         // TN — regression guard: the common case (a bare call resolving to
2736:         // an ordinary user proc via its own namespace) must be unaffected by
2737:         // the new resolution-candidate check, which is a no-op there (the
2738:         // bare-name check above it already resolves it).
2739:         assert!(
2740:             w123(
2741:                 "namespace eval ::foo {\n\
2742:                  proc helper {} { return 42 }\n\
2743:                  proc bar {} { return [helper] }\n\
2744:                  }\n"
2745:             )
2746:             .is_empty()
2747:         );
2748:     }
2749: 
2750:     // tcllib `textutil::adjust` submodule commands must be registered
2751:     // under their real 3-segment name, not the umbrella-only 2-segment
2752:     // name, so calls through the common `package require textutil::adjust;
2753:     // namespace import textutil::adjust::*` idiom (georgtree_argparse's
2754:     // `argparse.tcl:380-382`) resolve. Ground truth (tclsh 9.0.4 + real
2755:     // tcllib-2.0): `package require
2756:     // textutil::adjust` creates `::textutil::adjust::adjust` /
2757:     // `::textutil::adjust::indent`, never a bare `::textutil::adjust`.
2758:     mod textutil_adjust_idx3_idx4 {
2759:         use super::*;
2760: 
2761:         #[test]
2762:         fn qualified_submodule_calls_resolve_after_package_require() {
2763:             // A call to the real, canonical name resolves once the
2764:             // submodule package is required. Note `package require` (any
2765:             // package, this file's
2766:             // included) blanket-suppresses W123 file-wide (`emit_unresolved_
2767:             // command_diagnostics`'s conservative "package may define
2768:             // anything at runtime" gate) — so this pins that the call
2769:             // resolves under the real-world idiom, while the two tests below
2770:             // isolate the registry-data fact itself (no `package require` in
2771:             // scope, so the file-wide suppression gate does not mask it).
2772:             let src = "package require textutil::adjust\n\
2773:                        namespace import textutil::adjust::*\n\
2774:                        set a [adjust hello -length 20]\n\
2775:                        set b [indent $a \"  \"]\n";
2776:             assert!(w123(src).is_empty(), "got {:?}", w123(src));
2777:         }
2778: 
2779:         #[test]
2780:         fn qualified_submodule_names_are_directly_registry_known() {
2781:             // TP, isolating the registry-data fact with no `package require`
2782:             // in scope (so the blanket suppression gate above cannot mask
2783:             // it): the literal, fully-qualified 3-segment names must be
2784:             // directly known to W123's registry-name set.
2785:             let src = "textutil::adjust::adjust hello -length 20\n\
2786:                        textutil::adjust::indent hello \"  \"\n";
2787:             assert!(w123(src).is_empty(), "got {:?}", w123(src));
2788:         }
2789: 
2790:         #[test]
2791:         fn a_bare_unimported_flat_name_still_unresolved() {
2792:             // TN/FN contrast: with no `package require`, no `namespace
2793:             // import`, and no umbrella alias in play, the *bare* flattened
2794:             // names (`adjust`/`indent` with no qualification at all) are
2795:             // correctly still unknown — the fix adds the submodule's real
2796:             // names, it does not fabricate a global bare alias that only
2797:             // the `textutil` umbrella actually provides.
2798:             let d = w123("adjust hello -length 20\n");
2799:             assert_eq!(d.len(), 1, "got {d:?}");
2800:             assert!(d[0].contains("adjust"));
2801:         }
2802:     }
2803: 
2804:     #[test]
2805:     fn coroutine_name_is_a_known_command() {
2806:         // `coroutine NAME cmd ?arg …?` creates the command NAME
2807:         // (`TclNRCoroutineObjCmd`) — calling it is not an unknown command,
2808:         // while a typo'd name in the same file still fires.
2809:         let src = "proc gen {} { while 1 { yield 1 } }\ncoroutine nextNum gen\nnextNum\n";
2810:         assert!(w123(src).is_empty(), "got {:?}", w123(src));
2811:         let typo = "proc gen {} { while 1 { yield 1 } }\ncoroutine nextNum gen\nnextNun\n";
2812:         let d = w123(typo);
2813:         assert_eq!(d.len(), 1, "the typo'd name fires; got {d:?}");
2814:         assert!(d[0].contains("nextNun"));
2815:     }
2816: 
2817:     #[test]
2818:     fn interp_create_name_is_a_known_command() {
2819:         // `interp create NAME` binds NAME as the child interpreter's
2820:         // command — `NAME eval {…}` dispatches on it.
2821:         assert!(w123("interp create child\nchild eval { puts hi }\n").is_empty());
2822:         // The `-safe` flag at the name index is an option, never a name; a
2823:         // missing name is auto-generated — nothing to record, nothing fires.
2824:         assert!(w123("interp create -safe\n").is_empty());
2825:         let r = Analyser::new().analyse("interp create -safe\n", D);
2826:         assert!(
2827:             !r.created_instance_commands.contains("-safe"),
2828:             "an option flag must not be recorded as a created command"
2829:         );
2830:     }
2831: 
2832:     #[test]
2833:     fn renamed_away_builtin_call_fires_w123() {
2834:         // `rename puts {}` (or a rename-away) deletes the builtin — a later
2835:         // call fails "invalid command name" (tclsh 9.0.4), so W123 fires.
2836:         let d = w123("rename puts {}\nputs x\n");
2837:         assert_eq!(d.len(), 1, "deleted builtin fires; got {d:?}");
2838:         assert!(d[0].contains("'puts'"));
2839:         assert_eq!(w123("rename puts myputs\nputs x\n").len(), 1);
2840:         // The rename target stays known, and calls lexically BEFORE the
2841:         // rename still resolve to the builtin.
2842:         assert!(w123("rename puts myputs\nmyputs x\n").is_empty());
2843:         assert!(w123("puts before\nrename puts myputs\n").is_empty());
2844:         // A re-binding after the deletion makes the name callable again.
2845:         assert!(w123("rename puts {}\nproc puts {args} {}\nputs x\n").is_empty());
2846:         // A rename buried in a proc body is conditional — it runs only if
2847:         // the proc is ever called — so the builtin stays known at top level.
2848:         assert!(w123("proc hook {} { rename puts _p }\nputs hi\n").is_empty());
2849:     }
2850: 
2851:     #[test]
2852:     fn namespace_unknown_handler_suppresses_w123() {
2853:         // Installing a per-namespace unknown handler (TIP 181) makes command
2854:         // resolution unknowable — file-wide suppression, like a dynamic
2855:         // `proc unknown`.
2856:         let src = "proc handler {args} { puts $args }\nnamespace unknown handler\nmystery_cmd 1\n";
2857:         assert!(w123(src).is_empty(), "got {:?}", w123(src));
2858:         // The bare query form installs nothing; an empty handler resets to
2859:         // the default — neither suppresses.
2860:         assert_eq!(w123("namespace unknown\nmystery_cmd 1\n").len(), 1);
2861:         assert_eq!(w123("namespace unknown {}\nmystery_cmd 1\n").len(), 1);
2862:     }
2863: 
2864:     #[test]
2865:     fn list_wrapped_namespace_unknown_installer_suppresses_w123() {
2866:         // FP: `namespace eval $ns [list namespace
2867:         // unknown $handler]` (tcllib's `namespacex::hook::Set` idiom) is
2868:         // a `Cmd`-kind body — `analyse_body`'s literal-`{...}`-only gate
2869:         // never walks it, and the generic nested-substitution scan
2870:         // resolves the head to `list`, never `namespace unknown` — so
2871:         // this installer shape must be recognised separately, or it stays
2872:         // invisible to every path.
2873:         let src = "proc handler {args} { puts $args }\nnamespace eval ::target [list namespace unknown handler]\nmystery_cmd 1\n";
2874:         assert!(w123(src).is_empty(), "got {:?}", w123(src));
2875:     }
2876: 
2877:     #[test]
2878:     fn list_wrapped_namespace_unknown_full_tcllib_idiom_suppresses_w123() {
2879:         // FP — the full attested shape (mirrors tcllib
2880:         // modules/namespacex/namespacex.tcl:157-162's `hook::Set`, and
2881:         // the finding's own repro): the installer is itself wrapped in
2882:         // another proc, and the handler is installed from inside a
2883:         // namespace body.
2884:         let src = "proc ::hooklib::Set {ns handler} {\n    namespace eval $ns [list namespace unknown $handler]\n}\nnamespace eval ::target {\n    proc fallbackHandler {args} { return \"handled:$args\" }\n    ::hooklib::Set ::target [namespace code fallbackHandler]\n    proc run {} { return [mystery arg1 arg2] }\n}\n";
2885:         assert!(w123(src).is_empty(), "got {:?}", w123(src));
2886:     }
2887: 
2888:     #[test]
2889:     fn list_wrapped_namespace_unknown_via_namespace_inscope_suppresses_w123() {
2890:         // FP — `namespace inscope` shares the same
2891:         // `AnalyserHookId::NamespaceEval` hook as `namespace eval`, so
2892:         // one fix covers both call forms.
2893:         let src = "proc handler {args} { puts $args }\nnamespace inscope ::target [list namespace unknown handler]\nmystery_cmd 1\n";
2894:         assert!(w123(src).is_empty(), "got {:?}", w123(src));
2895:     }
2896: 
2897:     #[test]
2898:     fn list_wrapped_namespace_unknown_requires_the_exact_shape() {
2899:         // TP — over-suppression guards: each of these must still fire
2900:         // W123, proving the recogniser requires the literal `list
2901:         // namespace unknown` head with a non-empty handler, not "any
2902:         // list-wrapped namespace eval body".
2903:         assert_eq!(
2904:             w123("namespace eval ::target [list puts hello]\nmystery_cmd 1\n").len(),
2905:             1,
2906:             "an unrelated list-wrapped body must not suppress W123"
2907:         );
2908:         assert_eq!(
2909:             w123("namespace eval ::target [list namespace export foo]\nmystery_cmd 1\n").len(),
2910:             1,
2911:             "a different namespace subcommand must not suppress W123"
2912:         );
2913:         assert_eq!(
2914:             w123("namespace eval ::target [list namespace unknown]\nmystery_cmd 1\n").len(),
2915:             1,
2916:             "the bare query form installs nothing"
2917:         );
2918:         assert_eq!(
2919:             w123("namespace eval ::target [list namespace unknown {}]\nmystery_cmd 1\n").len(),
2920:             1,
2921:             "an empty handler resets to the default, installs nothing"
2922:         );
2923:     }
2924: 
2925:     #[test]
2926:     fn list_wrapped_namespace_unknown_does_not_blanket_suppress_the_namespace() {
2927:         // TP — negative control: with no `namespace unknown` installer
2928:         // anywhere, a genuinely unknown command inside the namespace
2929:         // body must still be flagged.
2930:         let src = "namespace eval ::target {\n    proc run {} { return [mystery arg1 arg2] }\n}\n";
2931:         assert_eq!(w123(src).len(), 1);
2932:     }
2933: 
2934:     #[test]
2935:     fn list_wrapped_namespace_unknown_via_concat_is_a_known_remaining_gap() {
2936:         // FP (documented, intentionally not covered) — the same idiom
2937:         // built via `concat` instead of a literal `list` call is out of
2938:         // scope: the recogniser is narrow to the exact attested
2939:         // `list namespace unknown` shape. Pinned so nobody mistakes the
2940:         // narrow fix for a full generalisation.
2941:         let src = "proc handler {args} { puts $args }\nnamespace eval ::target [concat namespace unknown handler]\nmystery_cmd 1\n";
2942:         assert_eq!(
2943:             w123(src).len(),
2944:             1,
2945:             "concat-built installers are a documented, out-of-scope gap"
2946:         );
2947:     }
2948: 
2949:     #[test]
2950:     fn static_rename_target_is_a_known_command() {
2951:         // A static `rename OLD NEW` *defines* NEW (confirmed against tclsh
2952:         // 9.0.4: `rename puts myputs; info commands myputs` lists it), so a
2953:         // call to the renamed name must not draw W123 — while a genuinely
2954:         // unknown name in the same file still does.
2955:         assert!(w123("rename puts myputs\nmyputs hello").is_empty());
2956:         assert_eq!(w123("rename puts myputs\nmyputz hello").len(), 1);
2957:     }
2958: 
2959:     #[test]
2960:     fn stub_directive_suppresses_w123() {
2961:         let src = "# tcl-lsp: stubs-begin\n# tcl-lsp: stub mycommand {arg1 arg2}\n# tcl-lsp: stubs-end\nmycommand x y\n";
2962:         assert!(w123(src).is_empty());
2963:     }
2964: 
2965:     #[test]
2966:     fn alias_command_no_w123_and_alias_in_did_you_mean() {
2967:         assert!(w123("interp alias {} = {} expr\n= {1 + 2}").is_empty());
2968:         let d = w123("interp alias {} myput {} puts stdout\nmyptu hello");
2969:         assert_eq!(d.len(), 1);
2970:         assert!(d[0].contains("myput"));
2971:     }
2972: 
2973:     // Did you mean?
2974: 
2975:     #[test]
2976:     fn did_you_mean_suggestion_for_near_name() {
2977:         // `putz` is one edit from `puts` (a real builtin).
2978:         let r = Analyser::new().analyse("putz hello", D);
2979:         let d: Vec<_> = r
2980:             .diagnostics
2981:             .iter()
2982:             .filter(|d| d.code.to_string() == "W123")
2983:             .collect();
2984:         assert_eq!(d.len(), 1);
2985:         assert!(d[0].message.contains("puts"));
2986:         assert!(!d[0].fixes.is_empty());
2987:         assert_eq!(d[0].fixes[0].new_text, "puts");
2988:     }
2989: 
2990:     #[test]
2991:     fn no_suggestion_for_distant_name() {
2992:         let d = w123("xyzzyplugh arg1");
2993:         assert_eq!(d.len(), 1);
2994:         assert!(!d[0].contains("did you mean"));
2995:     }
2996: 
2997:     // Unknown-proc dispatch analysis.
2998: 
2999:     #[test]
3000:     fn unknown_proc_switch_dispatch_covers_targets() {
3001:         let handled = "proc unknown {cmd args} {\n    switch $cmd {\n        foo { puts foo }\n        bar { puts bar }\n    }\n}\nfoo x\nbar y\n";
3002:         assert!(w123(handled).is_empty());
3003:         let unhandled = "proc unknown {cmd args} {\n    switch $cmd {\n        foo { puts foo }\n    }\n}\nfoo x\nbaz y\n";
3004:         let d = w123(unhandled);
3005:         assert_eq!(d.len(), 1);
3006:         assert!(d[0].contains("baz"));
3007:     }
3008: 
3009:     #[test]
3010:     fn unknown_proc_empty_stub_does_not_suppress() {
3011:         let d = w123("proc unknown {args} {}\nmycommand arg1");
3012:         assert_eq!(d.len(), 1);
3013:         assert!(d[0].contains("mycommand"));
3014:     }
3015: 
3016:     #[test]
3017:     fn unknown_proc_opaque_dispatch_suppresses() {
3018:         // chains-original / auto_load / exec / glob-switch make dispatch opaque.
3019:         for src in [
3020:             "proc unknown {cmd args} {\n    _original_unknown $cmd {*}$args\n}\nmycommand arg1\n",
3021:             "proc unknown {cmd args} {\n    auto_load $cmd\n}\nmycommand arg1\n",
3022:             "proc unknown {cmd args} {\n    exec $cmd {*}$args\n}\nmycommand arg1\n",
3023:             "proc unknown {cmd args} {\n    switch -glob $cmd {\n        fo* { puts foo }\n    }\n}\nfoobar x\n",
3024:         ] {
3025:             assert!(w123(src).is_empty(), "unexpected W123 for {src:?}");
3026:         }
3027:     }
3028: 
3029:     #[test]
3030:     fn unknown_if_else_chains_original_suppresses() {
3031:         let src = "proc unknown {cmd args} {\n    if {$cmd eq \"foo\"} {\n        puts foo\n    } else {\n        _original_unknown $cmd {*}$args\n    }\n}\nbaz x\n";
3032:         assert!(w123(src).is_empty());
3033:         let r = Analyser::new().analyse(src, D);
3034:         let upi = r.unknown_proc_info.as_ref().expect("upi");
3035:         assert!(upi.chains_original);
3036:     }
3037: 
3038:     #[test]
3039:     fn multiple_unknown_procs_last_wins() {
3040:         let src = "proc unknown {cmd args} {\n    _original_unknown $cmd {*}$args\n}\nproc unknown {cmd args} {\n    switch $cmd {\n        foo { puts foo }\n    }\n}\nfoo x\nbaz y\n";
3041:         let r = Analyser::new().analyse(src, D);
3042:         let upi = r.unknown_proc_info.as_ref().expect("upi");
3043:         assert!(!upi.chains_original);
3044:         assert!(upi.dispatch_targets.contains("foo"));
3045:         assert!(
3046:             r.diagnostics
3047:                 .iter()
3048:                 .any(|d| d.code.to_string() == "W123" && d.message.contains("baz"))
3049:         );
3050:     }
3051: 
3052:     // Unknown_proc_info population.
3053: 
3054:     #[test]
3055:     fn unknown_proc_info_populated_for_switch_dispatch() {
3056:         let src = "proc unknown {cmd args} {\n    switch $cmd {\n        foo { puts foo }\n        bar { puts bar }\n    }\n}\n";
3057:         let r = Analyser::new().analyse(src, D);
3058:         let upi = r.unknown_proc_info.as_ref().expect("upi");
3059:         assert!(upi.dispatch_targets.contains("foo"));
3060:         assert!(upi.dispatch_targets.contains("bar"));
3061:         assert!(!upi.empty_stub);
3062:         assert!(!upi.chains_original);
3063:     }
3064: 
3065:     #[test]
3066:     fn unknown_proc_info_empty_stub_flag() {
3067:         let r = Analyser::new().analyse("proc unknown {args} {}", D);
3068:         assert!(r.unknown_proc_info.as_ref().expect("upi").empty_stub);
3069:     }
3070: 
3071:     #[test]
3072:     fn no_unknown_proc_info_by_default() {
3073:         assert!(
3074:             Analyser::new()
3075:                 .analyse("set x 1", D)
3076:                 .unknown_proc_info
3077:                 .is_none()
3078:         );
3079:     }
3080: 
3081:     #[test]
3082:     fn unknown_glob_switch_sets_pattern_dispatch_flag() {
3083:         let src = "proc unknown {cmd args} {\n    switch -glob $cmd {\n        fo* { puts foo }\n    }\n}\nfoobar x\n";
3084:         let r = Analyser::new().analyse(src, D);
3085:         let upi = r.unknown_proc_info.as_ref().expect("upi");
3086:         assert!(upi.has_pattern_dispatch);
3087:         assert!(!r.diagnostics.iter().any(|d| d.code.to_string() == "W123"));
3088:     }
3089: 
3090:     #[test]
3091:     fn tcl_unknown_qualified_recognised() {
3092:         let src = "proc ::tcl::unknown {cmd args} {\n    switch $cmd {\n        foo { puts foo }\n    }\n}\n";
3093:         let r = Analyser::new().analyse(src, D);
3094:         let upi = r.unknown_proc_info.as_ref().expect("upi");
3095:         assert!(upi.dispatch_targets.contains("foo"));
3096:     }
3097: 
3098:     // Dead/live short-circuit arms.
3099:     // The analyser surfaces W123 for an unknown command like `[missingCommand]`
3100:     // even inside a provably-dead `&&`/`||`/`?:` arm (which tclsh never
3101:     // executes). The *live*-arm control — where tclsh genuinely errors — is
3102:     // below.
3103: 
3104:     #[test]
3105:     fn live_short_circuit_arm_command_still_w123() {
3106:         // tclsh: `expr {1 && [missingCommand]}` runs the right arm and errors.
3107:         assert_eq!(w123("expr {1 && [missingCommand]}").len(), 1);
3108:         assert_eq!(w123("expr {[missingCommand] && 1}").len(), 1);
3109:         assert_eq!(
3110:             w123("proc f {c} { expr {$c && [missingCommand]} }").len(),
3111:             1
3112:         );
3113:     }
3114: }
3115: 
3116: // `source` command extraction.
3117: mod source_targets {
3118:     use super::*;
3119: 
3120:     #[test]
3121:     fn literal_source_recorded() {
3122:         let r = Analyser::new().analyse("source lib/utils.tcl", D);
3123:         assert_eq!(r.source_targets.len(), 1);
3124:         assert_eq!(r.source_targets[0].raw_path, "lib/utils.tcl");
3125:         assert!(r.source_targets[0].is_literal);
3126:     }
3127: 
3128:     #[test]
3129:     fn variable_and_cmd_subst_sources_not_literal() {
3130:         let r = Analyser::new().analyse("source $dir/utils.tcl", D);
3131:         assert_eq!(r.source_targets.len(), 1);
3132:         assert!(!r.source_targets[0].is_literal);
3133:         let r2 = Analyser::new().analyse(
3134:             "source [file join [file dirname [info script]] helper.tcl]",
3135:             D,
3136:         );
3137:         assert_eq!(r2.source_targets.len(), 1);
3138:         assert!(!r2.source_targets[0].is_literal);
3139:     }
3140: 
3141:     #[test]
3142:     fn source_with_encoding_option() {
3143:         let r = Analyser::new().analyse("source -encoding utf-8 myfile.tcl", D);
3144:         assert_eq!(r.source_targets.len(), 1);
3145:         assert_eq!(r.source_targets[0].raw_path, "myfile.tcl");
3146:         assert!(r.source_targets[0].is_literal);
3147:     }
3148: 
3149:     #[test]
3150:     fn multiple_sources_mixed_literal() {
3151:         let r = Analyser::new().analyse("source a.tcl\nsource b.tcl\nsource $c", D);
3152:         assert_eq!(r.source_targets.len(), 3);
3153:         assert!(r.source_targets[0].is_literal);
3154:         assert!(r.source_targets[1].is_literal);
3155:         assert!(!r.source_targets[2].is_literal);
3156:     }
3157: }
3158: 
3159: // TclOO class definition extraction.
3160: mod tcloo_classes {
3161:     use super::*;
3162:     use tcl_compiler::analyser::ClassDef;
3163: 
3164:     fn class(src: &str, qn: &str) -> ClassDef {
3165:         class_in(src, qn, D)
3166:     }
3167: 
3168:     /// [`class`] under an explicit dialect — for the members `TclOO` only
3169:     /// gained in 9.0 (`classmethod`, `private`, `initialise`/`initialize`,
3170:     /// `definitionnamespace`), which the 8.6 grammar rejects.
3171:     fn class_in(src: &str, qn: &str, dialect: &str) -> ClassDef {
3172:         Analyser::new()
3173:             .analyse(src, dialect)
3174:             .all_classes
3175:             .get(qn)
3176:             .cloned()
3177:             .expect("class recorded")
3178:     }
3179: 
3180:     #[test]
3181:     fn class_create_basic() {
3182:         let cd = class(
3183:             "oo::class create Dog {\n    method bark {} { return \"woof\" }\n}\n",
3184:             "::Dog",
3185:         );
3186:         assert_eq!(cd.name, "Dog");
3187:         assert_eq!(cd.metaclass, "oo::class");
3188:         assert!(cd.methods.contains_key("bark"));
3189:         assert_eq!(cd.methods["bark"].kind, "method");
3190:     }
3191: 
3192:     #[test]
3193:     fn class_superclass() {
3194:         let src = "oo::class create Animal {\n    method speak {} { error \"abstract\" }\n}\noo::class create Dog {\n    superclass Animal\n    method bark {} { return \"woof\" }\n}\n";
3195:         assert_eq!(class(src, "::Dog").superclasses, ["Animal"]);
3196:     }
3197: 
3198:     /// Integration (full analyse → resolved hierarchy): a bare
3199:     /// `superclass Base` in a deeply-nested `::a::b::Sub`, where `Base` exists
3200:     /// only in an *ancestor* namespace (`::a::Base`) and the tail is ambiguous
3201:     /// (a second `::x::Base`), must NOT resolve — real Tcl errors there.  The
3202:     /// former ancestor walk manufactured a `Sub ⊂ ::a::Base` edge.
3203:     #[test]
3204:     fn class_superclass_no_ancestor_namespace_walk() {
3205:         let src = "namespace eval ::a {\n    oo::class create Base {}\n}\nnamespace eval ::x {\n    oo::class create Base {}\n}\nnamespace eval ::a::b {\n    oo::class create Sub {\n        superclass Base\n    }\n}\n";
3206:         let analysis = Analyser::new().analyse(src, D).clone();
3207:         let h = analysis.class_hierarchy();
3208:         assert!(
3209:             !h.is_subtype("::a::b::Sub", "::a::Base"),
3210:             "must not manufacture an ancestor-namespace inheritance edge"
3211:         );
3212:     }
3213: 
3214:     /// TP: a base in the class's own namespace resolves, so
3215:     /// the inheritance edge is real.
3216:     #[test]
3217:     fn class_superclass_same_namespace_resolves() {
3218:         let src = "namespace eval ::a {\n    oo::class create Base {}\n    oo::class create Sub {\n        superclass Base\n    }\n}\n";
3219:         let analysis = Analyser::new().analyse(src, D).clone();
3220:         assert!(
3221:             analysis
3222:                 .class_hierarchy()
3223:                 .is_subtype("::a::Sub", "::a::Base"),
3224:             "a same-namespace superclass must resolve"
3225:         );
3226:     }
3227: 
3228:     #[test]
3229:     fn class_variables_and_constructor() {
3230:         let src = "oo::class create Dog {\n    variable name breed\n    constructor {n b} { set name $n; set breed $b }\n}\n";
3231:         let cd = class(src, "::Dog");
3232:         assert_eq!(cd.variables, ["name", "breed"]);
3233:         assert_eq!(cd.constructors.len(), 1);
3234:         assert_eq!(cd.constructors[0].kind, "constructor");
3235:         assert_eq!(
3236:             cd.constructors[0]
3237:                 .params
3238:                 .iter()
3239:                 .map(|p| p.name.as_str())
3240:                 .collect::<Vec<_>>(),
3241:             ["n", "b"]
3242:         );
3243:     }
3244: 
3245:     #[test]
3246:     fn class_method_params() {
3247:         let src = "oo::class create Calc {\n    method add {a b} { expr {$a + $b} }\n}\n";
3248:         let cd = class(src, "::Calc");
3249:         assert_eq!(
3250:             cd.methods["add"]
3251:                 .params
3252:                 .iter()
3253:                 .map(|p| p.name.as_str())
3254:                 .collect::<Vec<_>>(),
3255:             ["a", "b"]
3256:         );
3257:     }
3258: 
3259:     #[test]
3260:     fn class_destructor() {
3261:         let cd = class(
3262:             "oo::class create Conn {\n    destructor { close $fd }\n}\n",
3263:             "::Conn",
3264:         );
3265:         let d = cd.destructor.as_ref().expect("destructor");
3266:         assert_eq!(d.kind, "destructor");
3267:     }
3268: 
3269:     #[test]
3270:     fn class_mixins() {
3271:         let cd = class(
3272:             "oo::class create Dog {\n    mixin Serializable Comparable\n}\n",
3273:             "::Dog",
3274:         );
3275:         assert_eq!(cd.mixins, ["Serializable", "Comparable"]);
3276:     }
3277: 
3278:     #[test]
3279:     fn class_forward() {
3280:         let cd = class(
3281:             "oo::class create Dog {\n    forward run ::dog::run_impl\n}\n",
3282:             "::Dog",
3283:         );
3284:         assert_eq!(cd.methods["run"].kind, "forward");
3285:     }
3286: 
3287:     #[test]
3288:     fn class_filter_export_unexport() {
3289:         let src = "oo::class create Dog {\n    method bark {} {}\n    method internal {} {}\n    filter myfilter\n    export bark\n    unexport internal\n}\n";
3290:         let cd = class(src, "::Dog");
3291:         assert_eq!(cd.filters, ["myfilter"]);
3292:         assert!(cd.exports.contains("bark"));
3293:         assert!(cd.unexports.contains("internal"));
3294:     }
3295: 
3296:     #[test]
3297:     fn oo_define_body_merges_methods() {
3298:         // `classmethod` is 9.0-only, so this merge case runs under tcl9.0.
3299:         let src = "oo::class create Dog {\n    method bark {} { return \"woof\" }\n}\noo::define Dog {\n    method fetch {item} { return $item }\n    classmethod count {} { return 0 }\n}\n";
3300:         let cd = class_in(src, "::Dog", "tcl9.0");
3301:         assert!(cd.methods.contains_key("bark"));
3302:         assert!(cd.methods.contains_key("fetch"));
3303:         assert!(cd.class_methods.contains_key("count"));
3304:     }
3305: 
3306:     #[test]
3307:     fn oo_define_inline_and_partial_class() {
3308:         let cd = class(
3309:             "oo::define Dog method sit {} { return \"sitting\" }",
3310:             "::Dog",
3311:         );
3312:         assert!(cd.methods.contains_key("sit"));
3313:         // oo::define on an unseen class creates a partial ClassDef.
3314:         let cd2 = class(
3315:             "oo::define MyClass {\n    method foo {} {}\n}\n",
3316:             "::MyClass",
3317:         );
3318:         assert!(cd2.methods.contains_key("foo"));
3319:     }
3320: 
3321:     #[test]
3322:     fn metaclass_variants() {
3323:         let cfg = class(
3324:             "oo::configurable create Point {\n    property x y\n}\n",
3325:             "::Point",
3326:         );
3327:         assert_eq!(cfg.metaclass, "oo::configurable");
3328:         assert!(cfg.properties.contains_key("x") && cfg.properties.contains_key("y"));
3329:         assert_eq!(
3330:             class(
3331:                 "oo::abstract create Shape {\n    method area {} { error \"abstract\" }\n}\n",
3332:                 "::Shape"
3333:             )
3334:             .metaclass,
3335:             "oo::abstract"
3336:         );
3337:         assert_eq!(
3338:             class(
3339:                 "oo::singleton create Logger {\n    method log {msg} { puts $msg }\n}\n",
3340:                 "::Logger"
3341:             )
3342:             .metaclass,
3343:             "oo::singleton"
3344:         );
3345:     }
3346: 
3347:     #[test]
3348:     fn fully_qualified_oo_class_head_normalised() {
3349:         let cd = class(
3350:             "::oo::class create ::Dog {\n    method bark {} { return woof }\n}\n",
3351:             "::Dog",
3352:         );
3353:         assert_eq!(cd.metaclass, "oo::class");
3354:     }
3355: 
3356:     #[test]
3357:     fn method_body_instance_variables_in_scope() {
3358:         let src = "oo::class create Dog {\n    variable name\n    constructor {n} { set name $n }\n    method bark {} { return $name }\n}\n";
3359:         let r = Analyser::new().analyse(src, D);
3360:         let bark = r
3361:             .global_scope
3362:             .children
3363:             .iter()
3364:             .find(|s| s.name.ends_with("Dog::bark"))
3365:             .expect("bark scope");
3366:         assert!(bark.variables.contains_key("name"));
3367:     }
3368: 
3369:     #[test]
3370:     fn classmethod_and_private_method() {
3371:         // Both members are 9.0-only (TIP 478); under 8.6 they draw W002
3372:         // instead, which `oo_90_only_members_*` below pins.
3373:         let cd = class_in(
3374:             "oo::class create Counter {\n    classmethod instances {} { return 0 }\n}\n",
3375:             "::Counter",
3376:             "tcl9.0",
3377:         );
3378:         assert_eq!(cd.class_methods["instances"].kind, "classmethod");
3379:         let cd2 = class_in(
3380:             "oo::class create Foo {\n    private method helper {} { return 1 }\n}\n",
3381:             "::Foo",
3382:             "tcl9.0",
3383:         );
3384:         assert_eq!(cd2.methods["helper"].visibility, "private");
3385:     }
3386: 
3387:     #[test]
3388:     fn class_in_namespace_and_registered_on_scope() {
3389:         let src = "namespace eval shapes {\n    oo::class create Circle {\n        variable radius\n        method area {} { expr {3.14 * $radius * $radius} }\n    }\n}\n";
3390:         let r = Analyser::new().analyse(src, D);
3391:         assert!(r.all_classes.contains_key("::shapes::Circle"));
3392:         let cd = &r.all_classes["::shapes::Circle"];
3393:         assert_eq!(cd.variables, ["radius"]);
3394:         assert!(cd.methods.contains_key("area"));
3395:         // ClassDef registered on the enclosing scope by simple name.
3396:         let r2 = Analyser::new().analyse("oo::class create Dog {\n    method bark {} {}\n}\n", D);
3397:         assert!(r2.global_scope.classes.contains_key("Dog"));
3398:     }
3399: 
3400:     #[test]
3401:     fn self_method_body_is_walked_for_internal_diagnostics() {
3402:         // TP: a wrong-arity call inside a `self method`/`private method`
3403:         // body must draw a diagnostic — the body itself must be walked,
3404:         // not just the literal keywords
3405:         // "method"/"classmethod"/"constructor"/"destructor", with
3406:         // "self"/"private" falling through untouched. `string length`
3407:         // takes exactly one argument.
3408:         let src = "oo::class create Widget {\n    self method make {n} {\n        string length a b c d\n        return \"made $n\"\n    }\n}\n";
3409:         assert_eq!(
3410:             count(src, D, "E003"),
3411:             1,
3412:             "the wrong-arity call inside a self-method body must now be walked: {:?}",
3413:             codes(src, D)
3414:         );
3415:     }
3416: 
3417:     #[test]
3418:     fn private_method_body_is_also_walked_for_internal_diagnostics() {
3419:         // TP — the sibling gap `private method` shared with `self method`
3420:         // (both go through the same `unwrap_wrapper_member`-based
3421:         // `collect_method_body`), confirming the fix isn't scoped to
3422:         // `self` alone.
3423:         // `private` is 9.0-only, so the body walk is exercised under tcl9.0.
3424:         let src = "oo::class create Widget {\n    private method helper {} {\n        string length a b c d\n    }\n}\n";
3425:         assert_eq!(
3426:             count(src, "tcl9.0", "E003"),
3427:             1,
3428:             "the wrong-arity call inside a private-method body must now be walked: {:?}",
3429:             codes(src, "tcl9.0")
3430:         );
3431:     }
3432: 
3433:     /// The `TclOO` definition members Tcl added in 9.0 — `classmethod`
3434:     /// (TIP 478), `private`, `initialise`/`initialize`, and
3435:     /// `definitionnamespace` (TIP 524) — do not exist in the 8.6 grammar.
3436:     ///
3437:     /// Oracle: each of the three call shapes below fails on real tclsh8.6
3438:     /// with `invalid command name "<member>"` and succeeds on tclsh9.0
3439:     /// (probes cm2 / cm3 / cm4). The registry's hover text already said
3440:     /// "Tcl 9.0 also added the classmethod, private, initialise/initialize,
3441:     /// and definitionnamespace subcommands (none exist under Tcl 8.6)"
3442:     /// while the analyser accepted them silently.
3443:     #[test]
3444:     fn oo_90_only_members_are_flagged_under_86() {
3445:         // Shape 1 — a member inside the metaclass's own `create` body.
3446:         for member in [
3447:             "classmethod count {} { return 0 }",
3448:             "private { method secret {} { return s } }",
3449:             "initialise { set n 1 }",
3450:             "initialize { set n 1 }",
3451:             "definitionnamespace ::mydefs",
3452:         ] {
3453:             let src =
3454:                 format!("oo::class create Dog {{\n    method bark {{}} {{}}\n    {member}\n}}\n");
3455:             assert!(
3456:                 fires(&src, D, "W002"),
3457:                 "[create body] {member:?} must draw W002 under tcl8.6; got {:?}",
3458:                 codes(&src, D)
3459:             );
3460:             // Shape 2 — the same member inside an `oo::define Cls { … }` block.
3461:             let block = format!(
3462:                 "oo::class create Dog {{ method bark {{}} {{}} }}\noo::define Dog {{\n    {member}\n}}\n"
3463:             );
3464:             assert!(
3465:                 fires(&block, D, "W002"),
3466:                 "[oo::define block] {member:?} must draw W002 under tcl8.6; got {:?}",
3467:                 codes(&block, D)
3468:             );
3469:             // Shape 3 — the single-command `oo::define Cls <member> …` form.
3470:             let single = format!(
3471:                 "oo::class create Dog {{ method bark {{}} {{}} }}\noo::define Dog {member}\n"
3472:             );
3473:             assert!(
3474:                 fires(&single, D, "W002"),
3475:                 "[oo::define single] {member:?} must draw W002 under tcl8.6; got {:?}",
3476:                 codes(&single, D)
3477:             );
3478:         }
3479:     }
3480: 
3481:     /// TN — the same three shapes are clean under tcl9.0, where the members
3482:     /// exist.
3483:     #[test]
3484:     fn oo_90_only_members_are_clean_under_90() {
3485:         for member in [
3486:             "classmethod count {} { return 0 }",
3487:             "private { method secret {} { return s } }",
3488:             "initialise { set n 1 }",
3489:             "definitionnamespace ::mydefs",
3490:         ] {
3491:             for src in [
3492:                 format!("oo::class create Dog {{\n    method bark {{}} {{}}\n    {member}\n}}\n"),
3493:                 format!(
3494:                     "oo::class create Dog {{ method bark {{}} {{}} }}\noo::define Dog {{\n    {member}\n}}\n"
3495:                 ),
3496:                 format!(
3497:                     "oo::class create Dog {{ method bark {{}} {{}} }}\noo::define Dog {member}\n"
3498:                 ),
3499:             ] {
3500:                 assert!(
3501:                     !fires(&src, "tcl9.0", "W002"),
3502:                     "{member:?} exists in 9.0 and must be clean; got {:?}",
3503:                     codes(&src, "tcl9.0")
3504:                 );
3505:             }
3506:         }
3507:     }
3508: 
3509:     /// Reporting a 9.0-only member must not *erase* it: the analyser still
3510:     /// records the member under 8.6, so go-to-definition, references,
3511:     /// rename, document symbols, and code lenses keep working over the code
3512:     /// the user actually wrote. Same contract as the whole-command W002,
3513:     /// which reports a dialect-unavailable command while the analyser goes
3514:     /// on modelling the call.
3515:     #[test]
3516:     fn a_gated_oo_member_is_reported_but_still_recorded() {
3517:         let cd = class_in(
3518:             "oo::class create Counter {\n    classmethod instances {} { return 0 }\n}\n",
3519:             "::Counter",
3520:             D,
3521:         );
3522:         assert!(
3523:             cd.class_methods.contains_key("instances"),
3524:             "the classmethod must still be recorded under tcl8.6; got {:?}",
3525:             cd.class_methods.keys().collect::<Vec<_>>()
3526:         );
3527:         let cd2 = class_in(
3528:             "oo::class create Dog { }\noo::define Dog classmethod count {} { return 0 }\n",
3529:             "::Dog",
3530:             D,
3531:         );
3532:         assert!(
3533:             cd2.class_methods.contains_key("count"),
3534:             "the single-command form's member must still be recorded; got {:?}",
3535:             cd2.class_methods.keys().collect::<Vec<_>>()
3536:         );
3537:     }
3538: 
3539:     /// TN — the members that have existed since `TclOO` shipped in 8.6 are
3540:     /// never gated, in any of the three shapes.
3541:     #[test]
3542:     fn always_available_oo_members_are_clean_under_86() {
3543:         for member in [
3544:             "method bark {} { return \"woof\" }",
3545:             "constructor {n} { set n $n }",
3546:             "destructor { return }",
3547:             "variable name",
3548:             "forward run puts",
3549:         ] {
3550:             for src in [
3551:                 format!("oo::class create Dog {{\n    {member}\n}}\n"),
3552:                 format!("oo::class create Dog {{ }}\noo::define Dog {{\n    {member}\n}}\n"),
3553:                 format!("oo::class create Dog {{ }}\noo::define Dog {member}\n"),
3554:             ] {
3555:                 assert!(
3556:                     !fires(&src, D, "W002"),
3557:                     "{member:?} is 8.6 `TclOO` and must be clean; got {:?}",
3558:                     codes(&src, D)
3559:                 );
3560:             }
3561:         }
3562:     }
3563: 
3564:     #[test]
3565:     fn self_method_declaration_site_recorded_as_a_classmethod() {
3566:         // TP — proves Part 1 alone (record shape + span), independent of
3567:         // the definition.rs-side call-site receiver-resolution bug Part 2
3568:         // fixes.
3569:         let cd = class(
3570:             "oo::class create Widget {\n    self method make {n} { return \"made $n\" }\n}\n",
3571:             "::Widget",
3572:         );
3573:         assert!(!cd.methods.contains_key("make"));
3574:         let md = cd
3575:             .class_methods
3576:             .get("make")
3577:             .expect("recorded as a classmethod");
3578:         assert_eq!(md.kind, "classmethod");
3579:         assert!(md.is_self_method);
3580:     }
3581: }
3582: 
3583: // oo::Helpers::link — ClassDef::linked_members population.
3584: // Consumer-side (definition/hover resolution) is covered in
3585: // tcl-lsp-core; this module is about `collect_oo_links` itself.
3586: mod oo_link {
3587:     use super::*;
3588:     use tcl_compiler::analyser::ClassDef;
3589: 
3590:     fn class(src: &str, qn: &str) -> ClassDef {
3591:         Analyser::new()
3592:             .analyse(src, D)
3593:             .all_classes
3594:             .get(qn)
3595:             .cloned()
3596:             .expect("class recorded")
3597:     }
3598: 
3599:     #[test]
3600:     fn single_name_link_records_alias_to_itself() {
3601:         let cd = class(
3602:             "oo::class create C {\n    constructor {} { link foo }\n    method foo {x} { return $x }\n}\n",
3603:             "::C",
3604:         );
3605:         assert_eq!(
3606:             cd.linked_members.get("foo").map(String::as_str),
3607:             Some("foo")
3608:         );
3609:     }
3610: 
3611:     #[test]
3612:     fn two_element_link_records_alias_to_a_different_target() {
3613:         let cd = class(
3614:             "oo::class create C {\n    constructor {} { link {shortcut realMethod} }\n    method realMethod {x} { return $x }\n}\n",
3615:             "::C",
3616:         );
3617:         assert_eq!(
3618:             cd.linked_members.get("shortcut").map(String::as_str),
3619:             Some("realMethod")
3620:         );
3621:     }
3622: 
3623:     #[test]
3624:     fn link_called_from_destructor_is_recorded() {
3625:         // TP — `collect_method_body` covers constructor/method/destructor
3626:         // uniformly, and the link scan must too.
3627:         let cd = class(
3628:             "oo::class create C {\n    method foo {x} {return $x}\n    destructor { link foo }\n}\n",
3629:             "::C",
3630:         );
3631:         assert_eq!(
3632:             cd.linked_members.get("foo").map(String::as_str),
3633:             Some("foo")
3634:         );
3635:     }
3636: 
3637:     #[test]
3638:     fn multiple_single_name_aliases_in_one_link_call_all_record() {
3639:         // `link foo bar` is TWO independent one-element arguments, not a
3640:         // single two-element pair — both must be recorded.
3641:         let cd = class(
3642:             "oo::class create C {\n    constructor {} { link foo bar }\n    method foo {x} {return $x}\n    method bar {y} {return $y}\n}\n",
3643:             "::C",
3644:         );
3645:         assert_eq!(
3646:             cd.linked_members.get("foo").map(String::as_str),
3647:             Some("foo")
3648:         );
3649:         assert_eq!(
3650:             cd.linked_members.get("bar").map(String::as_str),
3651:             Some("bar")
3652:         );
3653:     }
3654: 
3655:     #[test]
3656:     fn links_from_different_method_bodies_all_accumulate() {
3657:         // Links recorded from different member bodies (not just the
3658:         // constructor) must all accumulate onto the same ClassDef.
3659:         let cd = class(
3660:             "oo::class create C {\n    constructor {} { link foo }\n    method setup {} { link bar }\n    method foo {x} {return $x}\n    method bar {y} {return $y}\n}\n",
3661:             "::C",
3662:         );
3663:         assert_eq!(
3664:             cd.linked_members.get("foo").map(String::as_str),
3665:             Some("foo")
3666:         );
3667:         assert_eq!(
3668:             cd.linked_members.get("bar").map(String::as_str),
3669:             Some("bar")
3670:         );
3671:     }
3672: 
3673:     #[test]
3674:     fn dynamic_link_target_is_not_recorded() {
3675:         // TN — a dynamic `link $which` is skipped (mirrors
3676:         // `detect_interp_alias`'s literal-only requirement): no
3677:         // fabricated alias, conservative fallback to "not reachable".
3678:         let cd = class(
3679:             "oo::class create C {\n    variable which\n    constructor {w} { set which $w; link $which }\n    method foo {x} {return $x}\n}\n",
3680:             "::C",
3681:         );
3682:         assert!(cd.linked_members.is_empty(), "{:?}", cd.linked_members);
3683:     }
3684: 
3685:     #[test]
3686:     fn link_for_one_name_does_not_blanket_legitimize_others() {
3687:         // Precision guard — a link for a DIFFERENT name must not
3688:         // blanket-legitimise every bareword in the class.
3689:         let cd = class(
3690:             "oo::class create C {\n    constructor {} { link foo }\n    method foo {x} {return $x}\n    method other {y} {return $y}\n}\n",
3691:             "::C",
3692:         );
3693:         assert!(cd.linked_members.contains_key("foo"));
3694:         assert!(!cd.linked_members.contains_key("other"));
3695:     }
3696: 
3697:     #[test]
3698:     fn link_nested_inside_a_conditional_is_not_recorded() {
3699:         // Deliberately shallow — only a top-level `link` call is
3700:         // recognised, not one nested inside an `if`/`catch`/… body
3701:         // argument (matches `scan_my_method_region`'s own accepted
3702:         // scope boundary for this class of problem).
3703:         let cd = class(
3704:             "oo::class create C {\n    constructor {} { if {1} { link foo } }\n    method foo {x} {return $x}\n}\n",
3705:             "::C",
3706:         );
3707:         assert!(cd.linked_members.is_empty(), "{:?}", cd.linked_members);
3708:     }
3709: 
3710:     #[test]
3711:     fn link_is_not_recorded_under_a_dialect_without_it() {
3712:         // The head is recognised through the registry's
3713:         // `TCLOO_BINDS_METHOD_ALIAS` trait, not by its spelling, so an 8.5
3714:         // dialect — which has no TclOO at all, let alone `oo::Helpers::link`
3715:         // — records nothing. (tclsh 8.6.14 without `ooutil` likewise:
3716:         // `invalid command name "link"` even inside a method.)
3717:         let cd = class(
3718:             "oo::class create C {\n    constructor {} { link foo }\n    method foo {x} { return $x }\n}\n",
3719:             "::C",
3720:         );
3721:         assert!(cd.linked_members.contains_key("foo"));
3722:         let cd85 = Analyser::new()
3723:             .analyse(
3724:                 "oo::class create C {\n    constructor {} { link foo }\n    method foo {x} { return $x }\n}\n",
3725:                 "tcl8.5",
3726:             )
3727:             .all_classes
3728:             .get("::C")
3729:             .cloned();
3730:         assert!(
3731:             cd85.is_none_or(|c| c.linked_members.is_empty()),
3732:             "no `link` in the 8.5 registry, so no aliases",
3733:         );
3734:     }
3735: }
3736: 
3737: // The `oo::Helpers` family is method-context-scoped.
3738: //
3739: // tclsh 9.0.4, at the top level:
3740: //     link foo          -> invalid command name "link"
3741: //     my foo            -> invalid command name "my"
3742: //     next / nextto     -> invalid command name "next" / "nextto"
3743: //     self              -> invalid command name "self"
3744: //     classvariable v   -> invalid command name "classvariable"
3745: //     info commands ::link  -> {}   (empty)
3746: // and inside `oo::class create C { method m {} { … } }`:
3747: //     namespace current -> ::oo::Obj22       namespace path -> ::oo::Helpers
3748: //     namespace which -command link -> ::oo::Helpers::link
3749: //     namespace which -command my   -> ::oo::Obj22::my   (NOT a helper)
3750: // while an `apply` lambda written inside that same method body loses the
3751: // context entirely (`invalid command name "link"` / `"my"` / `"self"`).
3752: //
3753: // tclsh 8.6.14 agrees for the four members it has (`next`/`nextto`/`self`
3754: // are `::oo::Helpers::*`, `my` is `::oo::ObjN::my`), and adding
3755: // `::oo::Helpers::link` the way Tcllib's `ooutil` does still leaves the
3756: // top-level bare `link` an `invalid command name`.
3757: mod oo_helpers_scoping {
3758:     use super::*;
3759: 
3760:     /// Every family member, with the dialect that has it.
3761:     const FAMILY: &[(&str, &str)] = &[
3762:         ("link", "tcl9.0"),
3763:         ("my", "tcl8.6"),
3764:         ("next", "tcl8.6"),
3765:         ("nextto", "tcl8.6"),
3766:         ("self", "tcl8.6"),
3767:         ("classvariable", "tcl9.0"),
3768:     ];
3769: 
3770:     #[test]
3771:     fn top_level_use_draws_w123() {
3772:         for (word, dialect) in FAMILY {
3773:             let src = format!("{word} foo\n");
3774:             assert!(
3775:                 fires(&src, dialect, "W123"),
3776:                 "top-level `{word}` is `invalid command name` in real Tcl",
3777:             );
3778:         }
3779:     }
3780: 
3781:     #[test]
3782:     fn method_body_use_is_clean() {
3783:         for (word, dialect) in FAMILY {
3784:             let src = format!(
3785:                 "oo::class create C {{\n    method foo {{}} {{ return 1 }}\n    method m {{}} {{ {word} foo }}\n}}\n"
3786:             );
3787:             assert!(
3788:                 !fires(&src, dialect, "W123"),
3789:                 "`{word}` resolves inside a method body: {:?}",
3790:                 codes(&src, dialect),
3791:             );
3792:         }
3793:     }
3794: 
3795:     #[test]
3796:     fn constructor_destructor_and_class_side_bodies_are_clean() {
3797:         // tclsh 9.0.4: `link`/`self`/`my` all work in a constructor, a
3798:         // destructor, a `self method` body, and an `oo::objdefine method`
3799:         // body.
3800:         for (word, dialect) in FAMILY {
3801:             for body in [
3802:                 format!(
3803:                     "oo::class create C {{\n    method foo {{}} {{ return 1 }}\n    constructor {{}} {{ {word} foo }}\n}}\n"
3804:                 ),
3805:                 format!(
3806:                     "oo::class create C {{\n    method foo {{}} {{ return 1 }}\n    destructor {{ {word} foo }}\n}}\n"
3807:                 ),
3808:                 format!(
3809:                     "oo::class create C {{\n    method foo {{}} {{ return 1 }}\n    self method cm {{}} {{ {word} foo }}\n}}\n"
3810:                 ),
3811:                 format!(
3812:                     "oo::class create C {{}}\nC create c1\noo::objdefine c1 {{\n    method om {{}} {{ {word} foo }}\n}}\n"
3813:                 ),
3814:             ] {
3815:                 assert!(
3816:                     !fires(&body, dialect, "W123"),
3817:                     "`{word}` resolves in every method context: {:?}\n{body}",
3818:                     codes(&body, dialect),
3819:                 );
3820:             }
3821:         }
3822:     }
3823: 
3824:     #[test]
3825:     fn apply_lambda_inside_a_method_body_draws_w123() {
3826:         // TP — `apply` runs its body in the global namespace, so the object
3827:         // context is gone (tclsh 9.0.4, inside a method:
3828:         // `apply {{} { link Helper }}` -> `invalid command name "link"`).
3829:         for (word, dialect) in FAMILY {
3830:             let src = format!(
3831:                 "oo::class create C {{\n    method foo {{}} {{ return 1 }}\n    method m {{}} {{ apply {{{{}} {{ {word} foo }}}} }}\n}}\n"
3832:             );
3833:             assert!(
3834:                 fires(&src, dialect, "W123"),
3835:                 "an apply lambda loses the method context: {:?}",
3836:                 codes(&src, dialect),
3837:             );
3838:         }
3839:     }
3840: 
3841:     #[test]
3842:     fn a_linked_bareword_resolves_inside_the_objects_method_bodies() {
3843:         // TN — `link foo` installs a real command `foo` in the object's own
3844:         // namespace that dispatches `my foo` (tclsh 9.0.4: after `link
3845:         // Helper` in a constructor, `namespace which -command Helper`
3846:         // answers `::oo::ObjN::Helper` from every method body), so a later
3847:         // bare `foo 1` is not an unknown command.
3848:         let src = "oo::class create Widget {\n    method foo {x} { return $x }\n    method bar {} {\n        link foo\n        return [foo 1]\n    }\n}\n";
3849:         assert!(!fires(src, "tcl9.0", "W123"), "{:?}", codes(src, "tcl9.0"));
3850:     }
3851: 
3852:     #[test]
3853:     fn an_unlinked_sibling_method_bareword_still_draws_w123() {
3854:         // TP — `link` for one name must not blanket-legitimise every
3855:         // bareword in the class: tclsh 9.0.4 raises `invalid command name
3856:         // "other"` for an un-linked sibling method called bare.
3857:         let src = "oo::class create Widget {\n    method foo {x} { return $x }\n    method other {} { return 2 }\n    method bar {} {\n        link foo\n        return [other]\n    }\n}\n";
3858:         assert!(fires(src, "tcl9.0", "W123"), "{:?}", codes(src, "tcl9.0"));
3859:     }
3860: 
3861:     #[test]
3862:     fn a_linked_bareword_still_draws_w123_at_the_top_level() {
3863:         // TP — the alias lives in the object's namespace, so it is not
3864:         // callable from outside a method body.
3865:         let src = "oo::class create Widget {\n    method foo {x} { return $x }\n    method bar {} { link foo }\n}\nfoo 1\n";
3866:         assert!(fires(src, "tcl9.0", "W123"), "{:?}", codes(src, "tcl9.0"));
3867:     }
3868: 
3869:     #[test]
3870:     fn proc_body_draws_w123() {
3871:         // TP — an ordinary proc is not a method context, however it is
3872:         // nested.
3873:         for (word, dialect) in FAMILY {
3874:             let src = format!("proc helper {{}} {{ {word} foo }}\n");
3875:             assert!(fires(&src, dialect, "W123"), "`{word}` in a plain proc");
3876:         }
3877:     }
3878: 
3879:     #[test]
3880:     fn qualified_spelling_resolves_anywhere() {
3881:         // TN — `::oo::Helpers::link` is a genuine global command
3882:         // (`info commands ::oo::Helpers::link` answers it under tclsh
3883:         // 9.0.4); calling it outside a method is a *runtime* error, not an
3884:         // unknown command.
3885:         for spelling in [
3886:             "::oo::Helpers::link foo",
3887:             "oo::Helpers::link foo",
3888:             "::oo::Helpers::self",
3889:             "::oo::Helpers::classvariable v",
3890:         ] {
3891:             let src = format!("{spelling}\n");
3892:             assert!(
3893:                 !fires(&src, "tcl9.0", "W123"),
3894:                 "{spelling}: {:?}",
3895:                 codes(&src, "tcl9.0"),
3896:             );
3897:         }
3898:     }
3899: 
3900:     #[test]
3901:     fn a_user_proc_of_the_same_name_still_resolves_at_the_top_level() {
3902:         // FP guard — the scope rule must not swallow a real, user-defined
3903:         // global command that happens to share the name.
3904:         let src = "proc link {args} { return $args }\nlink foo\n";
3905:         assert!(!fires(src, "tcl9.0", "W123"), "{:?}", codes(src, "tcl9.0"));
3906:     }
3907: 
3908:     /// A class-level `initialise` / `initialize` body, both spellings.
3909:     fn init_body(word: &str, spelling: &str) -> String {
3910:         format!(
3911:             "oo::class create C {{\n    {spelling} {{\n        {word} foo\n    }}\n    method m {{}} {{ return 1 }}\n}}\n"
3912:         )
3913:     }
3914: 
3915:     /// **W123 keys on resolution, and the family genuinely resolves in a
3916:     /// class `initialise` body** — so it must stay silent there.
3917:     ///
3918:     /// tclsh 9.0.4, inside `oo::class create ::P { initialize { … } }`:
3919:     /// `namespace current` is `::oo::Obj20`, `namespace path` is
3920:     /// `::oo::Helpers ::oo`, and `namespace which -command link` answers
3921:     /// `::oo::Helpers::link` — exactly as it does in a method body. Warning
3922:     /// "unknown command" here would be a plain false positive.
3923:     #[test]
3924:     fn init_body_use_draws_no_w123() {
3925:         for (word, _) in FAMILY {
3926:             for spelling in ["initialize", "initialise"] {
3927:                 let src = init_body(word, spelling);
3928:                 assert!(
3929:                     !fires(&src, "tcl9.0", "W123"),
3930:                     "`{word}` resolves in an `{spelling}` body: {:?}",
3931:                     codes(&src, "tcl9.0"),
3932:                 );
3933:             }
3934:         }
3935:     }
3936: 
3937:     /// ...but **callability** is a different fact, and the two diverge in
3938:     /// exactly this body.
3939:     ///
3940:     /// Same interpreter, same frame: every `::oo::Helpers` member raises
3941:     /// `… may only be called from inside a method` when actually called,
3942:     /// while `my` runs — it is `::oo::Obj20::my`, the *class object's* own
3943:     /// dispatch command, and `my new` there really does make an instance.
3944:     /// So the scope tree must mark the init frame as "resolves, but not a
3945:     /// method frame".
3946:     #[test]
3947:     fn init_body_is_not_a_method_frame_but_still_reaches_oo_helpers() {
3948:         use tcl_compiler::analyser::{
3949:             innermost_scope_is_oo_method_frame, innermost_scope_reaches_oo_helpers,
3950:         };
3951:         let src = init_body("link", "initialize");
3952:         let mut a = Analyser::new();
3953:         let result = a.analyse(&src, "tcl9.0").clone();
3954:         let init_off = u32::try_from(src.find("link foo").expect("the init-body call")).unwrap();
3955:         let method_off = u32::try_from(src.find("return 1").expect("the method body")).unwrap();
3956:         assert!(
3957:             innermost_scope_reaches_oo_helpers(&result.global_scope, init_off),
3958:             "an `initialize` body has ::oo::Helpers on its namespace path",
3959:         );
3960:         assert!(
3961:             !innermost_scope_is_oo_method_frame(&result.global_scope, init_off),
3962:             "an `initialize` body is not a method invocation",
3963:         );
3964:         // A real method body answers `true` to both, and the top level to
3965:         // neither — the two predicates must not have collapsed into one.
3966:         assert!(innermost_scope_reaches_oo_helpers(
3967:             &result.global_scope,
3968:             method_off
3969:         ));
3970:         assert!(innermost_scope_is_oo_method_frame(
3971:             &result.global_scope,
3972:             method_off
3973:         ));
3974:         assert!(!innermost_scope_reaches_oo_helpers(&result.global_scope, 0));
3975:         assert!(!innermost_scope_is_oo_method_frame(&result.global_scope, 0));
3976:     }
3977: 
3978:     /// The per-class `initialise` scoping must
3979:     /// survive being marked "not a method frame": two sibling classes'
3980:     /// same-named class variables stay independent.
3981:     #[test]
3982:     fn init_body_scoping_still_separates_sibling_classes() {
3983:         let src = "oo::class create A {\n    initialize { variable Colours {red} }\n}\noo::class create B {\n    initialize { variable Colours {blue} }\n}\n";
3984:         assert!(!fires(src, "tcl9.0", "W123"), "{:?}", codes(src, "tcl9.0"));
3985:     }
3986: }
3987: 
3988: // Diagnostics keyed on command name must hit identically across bare /
3989: // qualified / aliased spellings.
3990: //
3991: // Several of these equalities hold (W211 set, W215/W216, the W210
3992: // variable/upvar/global suppressions); others do NOT — qualified `::unset` and
3993: // aliased `unset` do not currently canonicalise to the W213 path. Each arm is
3994: // asserted against the actual verdict, with the exceptions flagged inline.
3995: mod canonicalisation_matrix {
3996:     use super::*;
3997: 
3998:     // W215 (unreachable variable name).
3999: 
4000:     #[test]
4001:     fn w215_brace_in_var_name() {
4002:         // `set "weird}name" 1` makes a var no $-form can read. Heuristic, but the
4003:         // unreachability is verified against tclsh's ${...} parser semantics.
4004:         let ds = analyser_diags("set \"weird}name\" 1", D);
4005:         let w215: Vec<_> = ds.iter().filter(|(c, _, _)| c == "W215").collect();
4006:         assert_eq!(w215.len(), 1);
4007:         assert!(w215[0].1.contains("weird}name"));
4008:         assert!(w215[0].1.contains('}'));
4009:     }
4010: 
4011:     #[test]
4012:     fn w215_trailing_backslash_in_var_name() {
4013:         // `set "back\\" 1` creates `back\`. Under the Tcl 9 nesting rule
4014:         // `${back\}` reads the `\}` as an inert pair and runs out of input
4015:         // (missing close-brace) — unreachable, W215 fires (verified against
4016:         // tclsh 9.0.3). Under the 8.x first-`}` rule there is no backslash
4017:         // processing: `${back\}` simply names `back\` — reachable, silent.
4018:         let ds = analyser_diags("set \"back\\\\\" 1", "tcl9.0");
4019:         let w215: Vec<_> = ds.iter().filter(|(c, _, _)| c == "W215").collect();
4020:         assert_eq!(w215.len(), 1);
4021:         assert!(w215[0].1.contains("trailing") || w215[0].1.contains("missing close-brace"));
4022: 
4023:         assert!(
4024:             !fires("set \"back\\\\\" 1", D, "W215"),
4025:             "8.x reads ${{back\\}} as the name back\\ — reachable, no W215"
4026:         );
4027:     }
4028: 
4029:     #[test]
4030:     fn w215_does_not_fire_when_brace_form_reaches_the_name() {
4031:         // Names reachable via ${...} under BOTH `${…}` delimiting rules
4032:         // (Tcl 9 nesting and the 8.x first-`}` scan): mid-name backslash
4033:         // (no `}` involved) and ordinary names.
4034:         for src in [
4035:             "set \"back\\\\slash\" 1",
4036:             "set \"foo-bar\" 1\nset normal 2\nset ::globalvar 3\nset arr(name) 4",
4037:         ] {
4038:             for dialect in [D, "tcl9.0"] {
4039:                 assert!(
4040:                     !fires(src, dialect, "W215"),
4041:                     "unexpected W215 for {src:?} under {dialect}"
4042:                 );
4043:             }
4044:         }
4045:     }
4046: 
4047:     #[test]
4048:     fn w215_balanced_inner_braces_are_dialect_dependent() {
4049:         // A name with balanced inner braces is reachable only under the Tcl 9
4050:         // nesting rule. tclsh8.6-verified: `set "a{b}c" 1; set ${a{b}c}` →
4051:         // can't read "a{b" (the 8.x form ends at the FIRST `}`), while tclsh
4052:         // 9.0.3 reads it fine.
4053:         let src = "set \"a{b}c\" 1";
4054:         assert!(
4055:             !fires(src, "tcl9.0", "W215"),
4056:             "Tcl 9 nesting reaches a{{b}}c — no W215"
4057:         );
4058:         assert!(
4059:             fires(src, D, "W215"),
4060:             "the 8.x first-close rule cannot reach a{{b}}c — W215 must fire"
4061:         );
4062:     }
4063: 
4064:     #[test]
4065:     fn w215_close_paren_in_array_index() {
4066:         let ds = analyser_diags("set \"arr(weird)stuff)\" 1", D);
4067:         let w215: Vec<_> = ds.iter().filter(|(c, _, _)| c == "W215").collect();
4068:         assert_eq!(w215.len(), 1);
4069:         assert!(w215[0].1.contains("array element index contains ')'"));
4070:     }
4071: 
4072:     // W216 (brace-then-paren array misuse).
4073: 
4074:     #[test]
4075:     fn w216_brace_then_paren_with_fix() {
4076:         let r = Analyser::new().analyse("set arr(name) hello\nputs ${arr}(name)", D);
4077:         let w216: Vec<_> = r
4078:             .diagnostics
4079:             .iter()
4080:             .filter(|d| d.code.to_string() == "W216")
4081:             .collect();
4082:         assert_eq!(w216.len(), 1);
4083:         assert!(!w216[0].fixes.is_empty());
4084:         assert_eq!(w216[0].fixes[0].new_text, "$arr(name)");
4085:     }
4086: 
4087:     #[test]
4088:     fn w216_brace_array_with_dollar_index() {
4089:         let r = Analyser::new().analyse("set foo bar\nputs ${arr($foo)}", D);
4090:         let w216: Vec<_> = r
4091:             .diagnostics
4092:             .iter()
4093:             .filter(|d| d.code.to_string() == "W216")
4094:             .collect();
4095:         assert_eq!(w216.len(), 1);
4096:         assert_eq!(w216[0].fixes[0].new_text, "$arr($foo)");
4097:     }
4098: 
4099:     #[test]
4100:     fn w216_funny_name_falls_back_to_set_indirection() {
4101:         let r = Analyser::new().analyse("set \"funny name\" 1\nputs ${funny name($foo)}", D);
4102:         let w216: Vec<_> = r
4103:             .diagnostics
4104:             .iter()
4105:             .filter(|d| d.code.to_string() == "W216")
4106:             .collect();
4107:         assert_eq!(w216.len(), 1);
4108:         assert_eq!(w216[0].fixes[0].new_text, "[set \"funny name($foo)\"]");
4109:     }
4110: 
4111:     #[test]
4112:     fn w216_does_not_fire_on_correct_forms() {
4113:         for src in [
4114:             "puts ${arr(name)}",
4115:             "puts $arr($foo)",
4116:             "puts ${arr}",
4117:             "set foo bar\nputs $arr($foo)",
4118:         ] {
4119:             assert!(!fires(src, D, "W216"), "unexpected W216 for {src:?}");
4120:         }
4121:     }
4122: 
4123:     // W213 (unset of possibly-undefined var).
4124: 
4125:     #[test]
4126:     fn w213_unset_bare_fires() {
4127:         // tclsh: `unset x` on undefined x → can't unset "x": no such variable.
4128:         assert_eq!(count("proc f {} { unset x }", D, "W213"), 1);
4129:     }
4130: 
4131:     #[test]
4132:     fn w213_nocomplain_silenced() {
4133:         // `-nocomplain` opts out (tclsh suppresses the error too).
4134:         assert_eq!(count("proc f {} { unset -nocomplain x }", D, "W213"), 0);
4135:     }
4136: 
4137:     // Qualified `::unset x` and aliased `myunset x` do NOT fire W213 — the
4138:     // qualified / aliased spelling is not canonicalised onto the W213 path on
4139:     // this surface.
4140:     #[test]
4141:     fn w213_qualified_and_aliased_do_not_fire_rust_behaviour() {
4142:         // The qualified / aliased spellings stay silent:
4143:         assert_eq!(count("proc f {} { ::unset x }", D, "W213"), 0);
4144:         assert_eq!(
4145:             count(
4146:                 "interp alias {} myunset {} unset\nproc f {} { myunset x }",
4147:                 D,
4148:                 "W213"
4149:             ),
4150:             0
4151:         );
4152:         // The qualified+nocomplain combination is likewise silent.
4153:         assert_eq!(count("proc f {} { ::unset -nocomplain x }", D, "W213"), 0);
4154:     }
4155: 
4156:     // W211 (set but never used) canonicalisation.
4157: 
4158:     #[test]
4159:     fn w211_set_bare_and_qualified_both_fire() {
4160:         // Both bare `set y 1` and qualified `::set y 1` canonicalise to the W211
4161:         // path.
4162:         assert_eq!(count("proc f {} { set y 1 }", D, "W211"), 1);
4163:         assert_eq!(count("proc f {} { ::set y 1 }", D, "W211"), 1);
4164:     }
4165: 
4166:     // An aliased `s y 1` (→ set) does not fire W211 on this surface.
4167:     #[test]
4168:     fn w211_aliased_set_rust_behaviour() {
4169:         let n = count("interp alias {} s {} set\nproc f {} { s y 1 }", D, "W211");
4170:         // Record the actual count; the alias-rewrite-to-`set` W211 path is not
4171:         // reproduced here.
4172:         assert_eq!(
4173:             n, 0,
4174:             "aliased-set W211 not reproduced on this surface (divergence)"
4175:         );
4176:     }
4177: 
4178:     // W210 suppression by variable/upvar/global declarations.
4179: 
4180:     #[test]
4181:     fn w210_variable_decl_silences_bare_and_qualified() {
4182:         // `variable v` introduces v from the namespace → reading it is not W210.
4183:         for decl in ["variable v", "::variable v"] {
4184:             let src =
4185:                 format!("namespace eval ns {{ variable v; proc f {{}} {{ {decl}; puts $v }} }}");
4186:             assert_eq!(w210_for(&src, "'v'"), 0, "for {decl:?}");
4187:         }
4188:     }
4189: 
4190:     #[test]
4191:     fn w210_upvar_decl_silences_bare_and_qualified() {
4192:         // `upvar 1 caller_v local` aliases `local`; reads are not W210. Both the
4193:         // bare and `::upvar` qualified spellings canonicalise onto this path.
4194:         assert_eq!(
4195:             w210_for(
4196:                 "proc f {} { upvar 1 caller_v local; puts $local }",
4197:                 "'local'"
4198:             ),
4199:             0
4200:         );
4201:         assert_eq!(
4202:             w210_for(
4203:                 "proc f {} { ::upvar 1 caller_v local; puts $local }",
4204:                 "'local'"
4205:             ),
4206:             0
4207:         );
4208:     }
4209: 
4210:     #[test]
4211:     fn w210_upvar_aliased_silences_the_name_it_links() {
4212:         // An aliased `upvar` (`interp alias {} link {} upvar` then
4213:         // `link 1 caller_v local`) reaches `upvar` through another binding,
4214:         // a registry command whose traits say it raises a barrier, so the
4215:         // flow graph lowers no frame effect for it and marks the call as one
4216:         // to code the module cannot see. Such a callee may create the caller's
4217:         // names it is handed, and `local` is one: reading it draws no W210.
4218:         // tclsh 8.4 to 9.1 print `5` for the procedure called after
4219:         // `set caller_v 5`.
4220:         assert_eq!(
4221:             w210_for(
4222:                 "interp alias {} link {} upvar\nproc f {} { link 1 caller_v local; puts $local }",
4223:                 "'local'"
4224:             ),
4225:             0
4226:         );
4227:     }
4228: 
4229:     #[test]
4230:     fn w210_global_decl_silences_bare_qualified_aliased() {
4231:         // `global g` recognises g as a global alias → no W210 on g.
4232:         for src in [
4233:             "set g 0\nproc f {} { global g; set g 1 }",
4234:             "set g 0\nproc f {} { ::global g; set g 1 }",
4235:             "set g 0\ninterp alias {} mkglobal {} global\nproc f {} { mkglobal g; set g 1 }",
4236:         ] {
4237:             assert_eq!(w210_for(src, "'g'"), 0, "unexpected W210 'g' for {src:?}");
4238:         }
4239:     }
4240: 
4241:     // NOTE — IRULE4005 / W120 canonicalisation: these poke iRules-flow /
4242:     // global-write internals. The IRULE4005 case asserts a *negative*
4243:     // (bare/qualified/aliased `unset` does NOT fire IRULE4005); the W120 case
4244:     // asserts the global-alias suppression already covered by
4245:     // `w210_global_decl_silences_*` above. The IRULE4005 negative is covered
4246:     // here for the bare spelling under the iRules dialect.
4247: 
4248:     #[test]
4249:     fn irule4005_not_fired_by_bare_unset_under_irules() {
4250:         // A bare `unset static::z` is not a "real write" → no IRULE4005.
4251:         assert!(!fires(
4252:             "when CLIENT_ACCEPTED { unset static::z }",
4253:             "f5-irules",
4254:             "IRULE4005"
4255:         ));
4256:     }
4257: }
4258: 
4259: // report::defstyle scoped command environment.
4260: //
4261: // The style script exposes the report configuration methods (`top`, `data`,
4262: // `columns`, …) as commands available only inside the body.  The registry-
4263: // driven scoped environment resolves them there (no W123 / arity false
4264: // positives) while still catching genuine typos and misuse (TP), and keeps
4265: // them unknown outside the body (correct scoping).  Organised as a
4266: // TP / FP / TN / FN matrix.
4267: mod report_scoped_commands {
4268:     use super::*;
4269: 
4270:     fn codes_of(src: &str) -> Vec<String> {
4271:         codes(src, D)
4272:     }
4273:     fn w123(src: &str) -> Vec<String> {
4274:         analyser_diags(src, D)
4275:             .into_iter()
4276:             .filter(|(c, _, _)| c == "W123")
4277:             .map(|(_, m, _)| m)
4278:             .collect()
4279:     }
4280: 
4281:     // TN: valid scoped usage draws no unknown-command / arity error.
4282: 
4283:     #[test]
4284:     fn tn_valid_body_no_w123() {
4285:         // A representative shape: line codes + operations.
4286:         let src = "::report::defstyle simpletable {} {\n\
4287:                    \x20 top set [split \"x\"]\n\
4288:                    \x20 data set [split \"y\"]\n\
4289:                    \x20 bottom enable\n\
4290:                    \x20 topdatasep enable\n\
4291:                    \x20 columns\n\
4292:                    }\n";
4293:         assert!(
4294:             w123(src).is_empty(),
4295:             "no W123 inside a valid style body: {:?}",
4296:             w123(src)
4297:         );
4298:         assert!(!fires(src, D, "E001"));
4299:         assert!(!fires(src, D, "E002"));
4300:         assert!(!fires(src, D, "E003"));
4301:         assert!(!fires(src, D, "W001"));
4302:     }
4303: 
4304:     #[test]
4305:     fn tn_nested_substitution_scoped_command_resolves() {
4306:         // `[columns]` nested inside a `set` value is still a scoped command.
4307:         let src = "::report::defstyle st {} {\n\
4308:                    \x20 top set [string repeat \"= \" [columns]]\n\
4309:                    }\n";
4310:         assert!(
4311:             w123(src).is_empty(),
4312:             "columns in a substitution resolves: {:?}",
4313:             w123(src)
4314:         );
4315:     }
4316: 
4317:     #[test]
4318:     fn tn_sibling_style_resolves() {
4319:         // A later style body may invoke a previously-defined style by name.
4320:         let src = "::report::defstyle simpletable {} {\n\
4321:                    \x20 top enable\n\
4322:                    }\n\
4323:                    ::report::defstyle captionedtable {n} {\n\
4324:                    \x20 simpletable\n\
4325:                    \x20 tcaption $n\n\
4326:                    }\n";
4327:         assert!(
4328:             w123(src).is_empty(),
4329:             "sibling style resolves: {:?}",
4330:             w123(src)
4331:         );
4332:     }
4333: 
4334:     #[test]
4335:     fn tn_config_methods_valid_arity() {
4336:         let src = "::report::defstyle st {} {\n\
4337:                    \x20 size 0 10\n\
4338:                    \x20 size 1 dyn\n\
4339:                    \x20 pad 0 both { }\n\
4340:                    \x20 justify 0 center\n\
4341:                    \x20 tcaption 1\n\
4342:                    \x20 top get\n\
4343:                    }\n";
4344:         for code in ["W123", "E001", "E002", "E003", "W001"] {
4345:             assert!(
4346:                 !fires(src, D, code),
4347:                 "{code} should not fire: {:?}",
4348:                 codes_of(src)
4349:             );
4350:         }
4351:     }
4352: 
4353:     // TP: genuine errors inside the body are still reported.
4354: 
4355:     #[test]
4356:     fn tp_typo_command_flagged() {
4357:         // `toop` / `dataa` are not scoped commands → still W123.
4358:         let src = "::report::defstyle st {} {\n  toop set x\n  dataa set y\n}\n";
4359:         let w = w123(src);
4360:         assert!(
4361:             w.iter().any(|m| m.contains("toop")),
4362:             "typo `toop` flagged: {w:?}"
4363:         );
4364:         assert!(
4365:             w.iter().any(|m| m.contains("dataa")),
4366:             "typo `dataa` flagged: {w:?}"
4367:         );
4368:     }
4369: 
4370:     #[test]
4371:     fn tp_unknown_operation_flagged_w001() {
4372:         let src = "::report::defstyle st {} {\n  top bogus\n}\n";
4373:         assert!(
4374:             fires(src, D, "W001"),
4375:             "unknown op `top bogus` → W001: {:?}",
4376:             codes_of(src)
4377:         );
4378:     }
4379: 
4380:     #[test]
4381:     fn tp_bare_ensemble_requires_operation_e001() {
4382:         let src = "::report::defstyle st {} {\n  top\n}\n";
4383:         assert!(
4384:             fires(src, D, "E001"),
4385:             "bare `top` → E001: {:?}",
4386:             codes_of(src)
4387:         );
4388:     }
4389: 
4390:     #[test]
4391:     fn tp_operation_too_few_args_e002() {
4392:         // `top set` needs the template value.
4393:         let src = "::report::defstyle st {} {\n  top set\n}\n";
4394:         assert!(
4395:             fires(src, D, "E002"),
4396:             "`top set` (no value) → E002: {:?}",
4397:             codes_of(src)
4398:         );
4399:     }
4400: 
4401:     #[test]
4402:     fn tp_plain_command_too_many_args_e003() {
4403:         // `columns` takes no arguments.
4404:         let src = "::report::defstyle st {} {\n  columns extra\n}\n";
4405:         assert!(
4406:             fires(src, D, "E003"),
4407:             "`columns extra` → E003: {:?}",
4408:             codes_of(src)
4409:         );
4410:     }
4411: 
4412:     // FP guard: the scoped env must not wrongly suppress real code.
4413: 
4414:     #[test]
4415:     fn fp_core_commands_still_checked_in_body() {
4416:         // Core commands inside the body keep their normal arity checks — a
4417:         // scoped env must not swallow them.  `set` with one arg is fine; a
4418:         // genuinely unknown core-looking head is still W123.
4419:         let src = "::report::defstyle st {} {\n  set x 1\n  frobnicate a b\n}\n";
4420:         assert!(
4421:             w123(src).iter().any(|m| m.contains("frobnicate")),
4422:             "unknown non-scoped head still W123: {:?}",
4423:             w123(src)
4424:         );
4425:     }
4426: 
4427:     // FN guard / scoping: scoped commands are unknown OUTSIDE the body.
4428: 
4429:     #[test]
4430:     fn fn_scoped_command_unknown_outside_body() {
4431:         // `top` / `columns` at top level are not real commands.
4432:         let src = "top set x\ncolumns\n";
4433:         let w = w123(src);
4434:         assert!(
4435:             w.iter().any(|m| m.contains("top")),
4436:             "`top` unknown outside body: {w:?}"
4437:         );
4438:         assert!(
4439:             w.iter().any(|m| m.contains("columns")),
4440:             "`columns` unknown outside body: {w:?}"
4441:         );
4442:     }
4443: 
4444:     // Report namespace + object commands.
4445: 
4446:     #[test]
4447:     fn report_namespace_commands_known() {
4448:         // The dedicated specs make the introspection commands resolvable
4449:         // (only W120 missing-require remains, which is correct).
4450:         let src = "::report::styles\n::report::rmstyle foo\n::report::stylebody foo\n\
4451:                    ::report::stylearguments foo\n";
4452:         assert!(
4453:             w123(src).is_empty(),
4454:             "report namespace commands known: {:?}",
4455:             w123(src)
4456:         );
4457:     }
4458: 
4459:     #[test]
4460:     fn report_object_methods_resolve() {
4461:         // `report::report` binds `r` as an object command; `r <method>` resolves
4462:         // through the registry object class — no W123 on `r`.
4463:         let src = "package require report\n::report::report r 3\nr data set x\nr printmatrix m\n";
4464:         assert!(
4465:             w123(src).is_empty(),
4466:             "report object methods resolve: {:?}",
4467:             w123(src)
4468:         );
4469:     }
4470: }
4471: 
4472: // Class factories and dynamically-installed members.
4473: //
4474: // C-Tcl ground truth for every case below comes from tclsh 9.0.4 and
4475: // tclsh 8.6.16, which agree on all of them:
4476: //
4477: // * `oo::class create Megawidget { superclass oo::class; self method create
4478: //   {name superclasses body} { next $name [list superclass MegawidgetClass
4479: //   {*}$superclasses]\;$body } }` then `Megawidget create SimpleWidget {}
4480: //   {…}` / `Megawidget create FocusableWidget SimpleWidget {…}` /
4481: //   `Megawidget create IconList FocusableWidget {…}` report
4482: //   `info class superclasses` = `::MegawidgetClass`,
4483: //   `::MegawidgetClass ::SimpleWidget`, and
4484: //   `::MegawidgetClass ::FocusableWidget` respectively, and `my CreateHull`
4485: //   from an `IconList` instance really runs `FocusableWidget`'s override.
4486: // * `oo::define S { method {*}{foo {} {return foo-ran}} }` defines a real,
4487: //   callable `foo`; so does the same `{*}` form inside an `oo::class create`
4488: //   body.  `constructor {*}[info class constructor ::Base]` /
4489: //   `method $m {*}[info class definition ::Base $m]` are equally real but
4490: //   carry no statically-knowable element list.
4491: // * `set ns tc; ${ns}::setdef …` dispatches to `::tc::setdef`.
4492: mod class_factories {
4493:     use super::*;
4494:     use tcl_compiler::analyser::{AnalysisResult, ClassDef, MetaclassProvenance};
4495: 
4496:     fn analysis(src: &str, dialect: &str) -> AnalysisResult {
4497:         Analyser::new().analyse(src, dialect)
4498:     }
4499: 
4500:     fn class(src: &str, qn: &str) -> ClassDef {
4501:         analysis(src, "tcl9.0")
4502:             .all_classes
4503:             .get(qn)
4504:             .cloned()
4505:             .unwrap_or_else(|| panic!("class {qn} recorded"))
4506:     }
4507: 
4508:     /// The Tk `library/megawidget.tcl` factory, reduced to its mechanism.
4509:     const MEGAWIDGET: &str = concat!(
4510:         "oo::class create Megawidget {\n",
4511:         "    superclass oo::class\n",
4512:         "    self method create {name superclasses body} {\n",
4513:         "        next $name [list superclass MegawidgetClass {*}$superclasses]\\;$body\n",
4514:         "    }\n",
4515:         "}\n",
4516:         "oo::class create MegawidgetClass {\n",
4517:         "    method TraceOption {a b} { return traced }\n",
4518:         "}\n",
4519:         "Megawidget create SimpleWidget {} {\n",
4520:         "    method CreateHull {} { my TraceOption a b }\n",
4521:         "}\n",
4522:         "Megawidget create FocusableWidget SimpleWidget {\n",
4523:         "    method CreateHull {} { my TraceOption c d }\n",
4524:         "}\n",
4525:         "Megawidget create IconList FocusableWidget {\n",
4526:         "    method GetSpecs {} { return iconlist }\n",
4527:         "}\n",
4528:     );
4529: 
4530:     #[test]
4531:     fn user_metaclass_creates_real_classes() {
4532:         // TP: a class whose own superclass chain reaches `oo::class` is a
4533:         // class factory, so its `create` calls must introduce real
4534:         // classes — entering `all_classes` with an outline entry,
4535:         // references, and `next` resolution.
4536:         let r = analysis(MEGAWIDGET, "tcl9.0");
4537:         for name in ["::SimpleWidget", "::FocusableWidget", "::IconList"] {
4538:             assert!(
4539:                 r.all_classes.contains_key(name),
4540:                 "{name} recorded: {:?}",
4541:                 r.all_classes.keys().collect::<Vec<_>>()
4542:             );
4543:         }
4544:     }
4545: 
4546:     #[test]
4547:     fn user_metaclass_body_argument_is_read_from_the_create_override() {
4548:         // TP — the override's signature is `{name superclasses body}`, so
4549:         // the body is argument 3, not the builtin `create Name Body`
4550:         // argument 2.  Reading the builtin position would walk the
4551:         // superclass word as a script and lose every member.
4552:         assert!(
4553:             class(MEGAWIDGET, "::SimpleWidget")
4554:                 .methods
4555:                 .contains_key("CreateHull")
4556:         );
4557:         assert!(
4558:             class(MEGAWIDGET, "::IconList")
4559:                 .methods
4560:                 .contains_key("GetSpecs")
4561:         );
4562:     }
4563: 
4564:     #[test]
4565:     fn user_metaclass_splices_its_own_and_the_callers_superclasses() {
4566:         // TP — matches `info class superclasses` on tclsh 9.0.4 / 8.6.16
4567:         // exactly, including the implicit `MegawidgetClass` the factory
4568:         // injects and the caller-supplied list spliced by `{*}$superclasses`.
4569:         assert_eq!(
4570:             class(MEGAWIDGET, "::SimpleWidget").superclasses,
4571:             ["MegawidgetClass"]
4572:         );
4573:         assert_eq!(
4574:             class(MEGAWIDGET, "::FocusableWidget").superclasses,
4575:             ["MegawidgetClass", "SimpleWidget"]
4576:         );
4577:         assert_eq!(
4578:             class(MEGAWIDGET, "::IconList").superclasses,
4579:             ["MegawidgetClass", "FocusableWidget"]
4580:         );
4581:     }
4582: 
4583:     #[test]
4584:     fn a_factory_made_class_with_a_readable_override_is_not_opaque() {
4585:         // TN — inheritance is fully known here, so method checks stay live
4586:         // rather than being blanket-suppressed.
4587:         assert!(!class(MEGAWIDGET, "::FocusableWidget").inheritance_unknown);
4588:     }
4589: 
4590:     #[test]
4591:     fn an_unreadable_manufacturer_override_marks_inheritance_unknown() {
4592:         // Abstention — the override builds its prologue from a runtime
4593:         // value, so the superclass list cannot be known.  The class is
4594:         // still recorded (it exists), but its inheritance is flagged
4595:         // opaque so no method-existence check fires against a guess.
4596:         let src = concat!(
4597:             "oo::class create Meta {\n",
4598:             "    superclass oo::class\n",
4599:             "    self method create {name extra body} {\n",
4600:             "        next $name [list superclass [pickBase $extra]]\\;$body\n",
4601:             "    }\n",
4602:             "}\n",
4603:             "Meta create Widget somewhere {\n",
4604:             "    method m {} { return 1 }\n",
4605:             "}\n",
4606:         );
4607:         let cd = class(src, "::Widget");
4608:         assert!(cd.inheritance_unknown, "{cd:?}");
4609:         assert!(cd.superclasses.is_empty(), "{cd:?}");
4610:         assert!(cd.methods.contains_key("m"), "{cd:?}");
4611:     }
4612: 
4613:     /// A factory whose `create` override composes the definition body as a
4614:     /// **string** — no nested command anywhere — yet really does inject a
4615:     /// superclass.  tclsh 9.0.4 and 8.6.16 both report `StrWidget supers:
4616:     /// ::StrBase` for this and run `[[StrWidget new] inherited]`.
4617:     const STRING_PROLOGUE_META: &str = concat!(
4618:         "oo::class create StrBase {\n",
4619:         "    method inherited {} { return inherited-ran }\n",
4620:         "}\n",
4621:         "oo::class create StrMeta {\n",
4622:         "    superclass oo::class\n",
4623:         "    self method create {name body} {\n",
4624:         "        next $name \"superclass StrBase\\n$body\"\n",
4625:         "    }\n",
4626:         "}\n",
4627:         "StrMeta create StrWidget {\n",
4628:         "    method own {} { return own-ran }\n",
4629:         "}\n",
4630:     );
4631: 
4632:     /// The same shape with the override passing `$body` straight through —
4633:     /// nothing composed, nothing injected.  tclsh 9.0.4 / 8.6.16 report
4634:     /// only the implicit `::oo::object` for it, i.e. a genuinely empty
4635:     /// injection.
4636:     const DIRECT_BODY_META: &str = concat!(
4637:         "oo::class create PlainMeta {\n",
4638:         "    superclass oo::class\n",
4639:         "    self method create {name body} {\n",
4640:         "        next $name $body\n",
4641:         "    }\n",
4642:         "}\n",
4643:         "PlainMeta create PlainWidget {\n",
4644:         "    method own {} { return plain-own }\n",
4645:         "}\n",
4646:     );
4647: 
4648:     #[test]
4649:     fn a_string_built_prologue_is_opaque_not_empty() {
4650:         // TP — the prologue injects `superclass StrBase` with no command
4651:         // substitution at all, so the scan finds nothing to read.  Claiming
4652:         // a *known-empty* injection would assert the class has no
4653:         // superclass and let W308 fire on every inherited method; the only
4654:         // sound answer is opaque.
4655:         let cd = class(STRING_PROLOGUE_META, "::StrWidget");
4656:         assert!(cd.inheritance_unknown, "{cd:?}");
4657:         assert!(
4658:             cd.methods.contains_key("own"),
4659:             "the class is still real: {cd:?}"
4660:         );
4661:     }
4662: 
4663:     #[test]
4664:     fn an_opaque_prologue_suppresses_w308_on_inherited_methods() {
4665:         // TP (consumer) — `inherited` really runs on both interpreters, so
4666:         // no unknown-method warning may fire for it.
4667:         let src = concat!(
4668:             "oo::class create StrBase {\n",
4669:             "    method inherited {} { return inherited-ran }\n",
4670:             "}\n",
4671:             "oo::class create StrMeta {\n",
4672:             "    superclass oo::class\n",
4673:             "    self method create {name body} {\n",
4674:             "        next $name \"superclass StrBase\\n$body\"\n",
4675:             "    }\n",
4676:             "}\n",
4677:             "StrMeta create StrWidget {\n",
4678:             "    method own {} { return own-ran }\n",
4679:             "}\n",
4680:             "set w [StrWidget new]\n",
4681:             "$w inherited\n",
4682:         );
4683:         assert!(
4684:             !fires(src, "tcl9.0", "W308"),
4685:             "an unreadable prologue must abstain: {:?}",
4686:             codes(src, "tcl9.0")
4687:         );
4688:     }
4689: 
4690:     #[test]
4691:     fn a_provably_direct_body_still_yields_a_known_empty_injection() {
4692:         // TN — `next $name $body` composes nothing, so the injection is
4693:         // known-empty and the class's inheritance is fully known.  This is
4694:         // the half that must *not* become opaque, or the abstention above
4695:         // would cost every precise diagnostic on a factory-made class.
4696:         let cd = class(DIRECT_BODY_META, "::PlainWidget");
4697:         assert!(!cd.inheritance_unknown, "{cd:?}");
4698:         assert!(cd.superclasses.is_empty(), "{cd:?}");
4699:         assert!(cd.methods.contains_key("own"), "{cd:?}");
4700:     }
4701: 
4702:     #[test]
4703:     fn a_provably_direct_body_keeps_method_checks_live() {
4704:         // FN guard — the known-empty case must stay precise: a method that
4705:         // exists nowhere on the class still warns.
4706:         let src = concat!(
4707:             "oo::class create PlainMeta {\n",
4708:             "    superclass oo::class\n",
4709:             "    self method create {name body} {\n",
4710:             "        next $name $body\n",
4711:             "    }\n",
4712:             "}\n",
4713:             "PlainMeta create PlainWidget {\n",
4714:             "    method own {} { return plain-own }\n",
4715:             "}\n",
4716:             "set w [PlainWidget new]\n",
4717:             "$w nosuchmethod\n",
4718:         );
4719:         assert!(
4720:             fires(src, "tcl9.0", "W308"),
4721:             "a known-empty injection keeps method checks live: {:?}",
4722:             codes(src, "tcl9.0")
4723:         );
4724:     }
4725: 
4726:     #[test]
4727:     fn a_relative_superclass_reaches_the_metaclass_in_its_own_namespace() {
4728:         // TP — `::n::DerivedMeta` declares `superclass Meta`, which Tcl
4729:         // resolves in the declaring class's own namespace: tclsh 9.0.4 /
4730:         // 8.6.16 both report `info class superclasses ::n::DerivedMeta` =
4731:         // `::n::Meta`, and `::n::DerivedMeta create ::NsWidget {…}` really
4732:         // makes a class.  Looking only at `Meta` / `::Meta` missed it.
4733:         let src = concat!(
4734:             "namespace eval ::n {\n",
4735:             "    oo::class create Meta {\n",
4736:             "        superclass oo::class\n",
4737:             "        self method create {name body} { next $name $body }\n",
4738:             "    }\n",
4739:             "    oo::class create DerivedMeta {\n",
4740:             "        superclass Meta\n",
4741:             "    }\n",
4742:             "}\n",
4743:             "::n::DerivedMeta create ::NsWidget {\n",
4744:             "    method nsown {} { return ns-own }\n",
4745:             "}\n",
4746:         );
4747:         let cd = class(src, "::NsWidget");
4748:         assert!(cd.methods.contains_key("nsown"), "{cd:?}");
4749:     }
4750: 
4751:     #[test]
4752:     fn a_relative_superclass_prefers_its_own_namespace_over_a_decoy() {
4753:         // TN (cross-link guard) — a same-tailed class
4754:         // in an unrelated namespace must not be picked when the declaring
4755:         // namespace has its own.  Here `::other::Meta` is a plain class and
4756:         // `::n::Meta` is the real metaclass; picking the decoy would leave
4757:         // `::NsWidget` unrecorded.
4758:         let src = concat!(
4759:             "namespace eval ::other {\n",
4760:             "    oo::class create Meta {\n",
4761:             "        method notafactory {} { return 1 }\n",
4762:             "    }\n",
4763:             "}\n",
4764:             "namespace eval ::n {\n",
4765:             "    oo::class create Meta {\n",
4766:             "        superclass oo::class\n",
4767:             "        self method create {name body} { next $name $body }\n",
4768:             "    }\n",
4769:             "    oo::class create DerivedMeta {\n",
4770:             "        superclass Meta\n",
4771:             "    }\n",
4772:             "}\n",
4773:             "::n::DerivedMeta create ::NsWidget {\n",
4774:             "    method nsown {} { return ns-own }\n",
4775:             "}\n",
4776:         );
4777:         assert!(class(src, "::NsWidget").methods.contains_key("nsown"));
4778:     }
4779: 
4780:     #[test]
4781:     fn a_relative_superclass_does_not_cross_link_to_another_namespace() {
4782:         // TN — the declaring namespace's own `Meta` is an ordinary class,
4783:         // so the chain ends there.  Reaching sideways into `::other::Meta`
4784:         // (which *is* a metaclass) would manufacture a class creation real
4785:         // Tcl never performs — `::n::Meta` shadows it from `::n`.
4786:         let src = concat!(
4787:             "namespace eval ::other {\n",
4788:             "    oo::class create Meta {\n",
4789:             "        superclass oo::class\n",
4790:             "        self method create {name body} { next $name $body }\n",
4791:             "    }\n",
4792:             "}\n",
4793:             "namespace eval ::n {\n",
4794:             "    oo::class create Meta {\n",
4795:             "        method notafactory {} { return 1 }\n",
4796:             "    }\n",
4797:             "    oo::class create DerivedMeta {\n",
4798:             "        superclass Meta\n",
4799:             "    }\n",
4800:             "}\n",
4801:             "::n::DerivedMeta create ::NsWidget {\n",
4802:             "    method nsown {} { return ns-own }\n",
4803:             "}\n",
4804:         );
4805:         assert!(
4806:             !analysis(src, "tcl9.0")
4807:                 .all_classes
4808:                 .contains_key("::NsWidget"),
4809:             "a non-factory chain must not manufacture a class: {:?}",
4810:             analysis(src, "tcl9.0")
4811:                 .all_classes
4812:                 .keys()
4813:                 .collect::<Vec<_>>(),
4814:         );
4815:     }
4816: 
4817:     #[test]
4818:     fn an_ordinary_class_is_not_treated_as_a_factory() {
4819:         // TN — `Dog` is a plain class, so `Dog create rex` makes an
4820:         // *instance*, never a class.  Only a chain that reaches
4821:         // `oo::class` manufactures classes.
4822:         let src = concat!(
4823:             "oo::class create Dog {\n",
4824:             "    method bark {} { return woof }\n",
4825:             "}\n",
4826:             "Dog create rex\n",
4827:         );
4828:         assert!(
4829:             !analysis(src, "tcl9.0").all_classes.contains_key("::rex"),
4830:             "an instance is not a class"
4831:         );
4832:     }
4833: 
4834:     #[test]
4835:     fn a_factory_without_a_create_override_keeps_the_builtin_layout() {
4836:         // TP — no override means the inherited `oo::class` manufacturer
4837:         // runs, so `Meta create Name Body` has its body at argument 2 and
4838:         // splices no extra superclass.
4839:         let src = concat!(
4840:             "oo::class create Meta {\n",
4841:             "    superclass oo::class\n",
4842:             "}\n",
4843:             "Meta create Plain {\n",
4844:             "    method m {} { return 1 }\n",
4845:             "}\n",
4846:         );
4847:         let cd = class(src, "::Plain");
4848:         assert!(cd.methods.contains_key("m"), "{cd:?}");
4849:         assert!(cd.superclasses.is_empty(), "{cd:?}");
4850:         assert!(!cd.inheritance_unknown, "{cd:?}");
4851:     }
4852: 
4853:     #[test]
4854:     fn anonymous_derived_metaclass_new_does_not_invent_a_class_name_from_its_body() {
4855:         // FP guard: `new` on Tcl 9's derived metaclasses generates the class
4856:         // command name. Its first word is the definition body, not a name, so
4857:         // the static class index must not create a nonsense source key.
4858:         let result = analysis(
4859:             "set cls [oo::abstract new { method probe {} { return ok } }]\n",
4860:             "tcl9.0",
4861:         );
4862:         assert!(
4863:             result.all_classes.is_empty(),
4864:             "an anonymous class has no statically nameable index key: {:?}",
4865:             result.all_classes.keys().collect::<Vec<_>>()
4866:         );
4867:     }
4868: 
4869:     #[test]
4870:     fn unexported_create_with_namespace_does_not_manufacture_a_class() {
4871:         // TN pinned against C Tcl 9.0.4 and 8.6: the structural method exists
4872:         // but is unexported, so ordinary command dispatch on oo::class fails.
4873:         // The analyser must not index a class that the interpreter never made.
4874:         let result = analysis(
4875:             "oo::class createWithNamespace ::WithNs ::objns { method probe {} {} }\n",
4876:             "tcl9.0",
4877:         );
4878:         assert!(!result.all_classes.contains_key("::WithNs"));
4879:     }
4880: 
4881:     /// The Tk `library/megawidget.tcl` unknown-dispatch constructor, reduced
4882:     /// to its mechanism: an unrecognised first word is a widget path, so the
4883:     /// metaclass constructs the object and hands the path straight back.
4884:     ///
4885:     /// tclsh 9.0.4 confirms the return value really is the word — with the
4886:     /// construction made globally (`[self] create ::$w`, which is what makes
4887:     /// the created command reachable from the caller's namespace rather than
4888:     /// the method's own), `set w [::D::Widget .w]; $w go` answers `went`.
4889:     const UNKNOWN_CTOR: &str = concat!(
4890:         "oo::class create Meta {\n",
4891:         "    superclass oo::class\n",
4892:         "    method unknown {w args} {\n",
4893:         "        if {[string match .* $w]} {\n",
4894:         "            [self] create ::$w {*}$args\n",
4895:         "            return $w\n",
4896:         "        }\n",
4897:         "        next $w {*}$args\n",
4898:         "    }\n",
4899:         "    unexport new unknown\n",
4900:         "}\n",
4901:     );
4902: 
4903:     fn factory_of(src: &str, qn: &str) -> tcl_compiler::analyser::ClassFactory {
4904:         class(src, qn)
4905:             .factory
4906:             .unwrap_or_else(|| panic!("{qn} is a class factory"))
4907:     }
4908: 
4909:     #[test]
4910:     fn unknown_dispatch_that_constructs_and_returns_the_word_is_proved() {
4911:         // TP — the Tk idiom. The metaclass declares `unknown`, that
4912:         // body constructs an object named from its first parameter, and it
4913:         // returns exactly that parameter, so a bare `Widget .w` call binds an
4914:         // instance.
4915:         assert!(
4916:             factory_of(UNKNOWN_CTOR, "::Meta").unknown_binds_instance,
4917:             "the Tk megawidget unknown-dispatch constructor must be proved"
4918:         );
4919:     }
4920: 
4921:     #[test]
4922:     fn unknown_dispatch_cannot_construct_after_return_completion() {
4923:         // FP guard: Tcl stops the path at `return`; a later construction is
4924:         // unreachable and cannot prove that the returned word names an
4925:         // object.
4926:         let src = concat!(
4927:             "oo::class create Meta {\n",
4928:             "    superclass oo::class\n",
4929:             "    method unknown {w args} {\n",
4930:             "        return $w\n",
4931:             "        [self] create ::$w {*}$args\n",
4932:             "    }\n",
4933:             "}\n",
4934:         );
4935:         assert!(!factory_of(src, "::Meta").unknown_binds_instance);
4936:     }
4937: 
4938:     #[test]
4939:     fn unknown_dispatch_ignores_an_unselected_construction_arm() {
4940:         let src = concat!(
4941:             "oo::class create Meta {\n",
4942:             "    superclass oo::class\n",
4943:             "    method unknown {w args} {\n",
4944:             "        if {0} { [self] create ::$w; return $w }\n",
4945:             "    }\n",
4946:             "}\n",
4947:         );
4948:         assert!(!factory_of(src, "::Meta").unknown_binds_instance);
4949:     }
4950: 
4951:     #[test]
4952:     fn unknown_dispatch_requires_construction_on_every_dynamic_return_path() {
4953:         let src = concat!(
4954:             "oo::class create Meta {\n",
4955:             "    superclass oo::class\n",
4956:             "    method unknown {w args} {\n",
4957:             "        if {$runtime} { [self] create ::$w }\n",
4958:             "        return $w\n",
4959:             "    }\n",
4960:             "}\n",
4961:         );
4962:         assert!(!factory_of(src, "::Meta").unknown_binds_instance);
4963:     }
4964: 
4965:     #[test]
4966:     fn unknown_dispatch_dynamic_arm_cannot_leave_a_normal_fallthrough_path() {
4967:         let src = concat!(
4968:             "oo::class create Meta {\n",
4969:             "    superclass oo::class\n",
4970:             "    method unknown {w args} {\n",
4971:             "        if {$runtime} { [self] create ::$w; return $w }\n",
4972:             "    }\n",
4973:             "}\n",
4974:         );
4975:         assert!(!factory_of(src, "::Meta").unknown_binds_instance);
4976:     }
4977: 
4978:     #[test]
4979:     fn unknown_dispatch_next_to_a_normally_returning_provider_abstains() {
4980:         let src = concat!(
4981:             "oo::class create ParentMeta {\n",
4982:             "    superclass oo::class\n",
4983:             "    method unknown {w args} { return inherited }\n",
4984:             "}\n",
4985:             "oo::class create Meta {\n",
4986:             "    superclass ParentMeta\n",
4987:             "    method unknown {w args} {\n",
4988:             "        if {[string match .* $w]} {\n",
4989:             "            [self] create ::$w {*}$args\n",
4990:             "            return $w\n",
4991:             "        }\n",
4992:             "        next $w {*}$args\n",
4993:             "    }\n",
4994:             "}\n",
4995:         );
4996:         assert!(
4997:             !factory_of(src, "::Meta").unknown_binds_instance,
4998:             "a normal inherited fallback result prevents a handle proof"
4999:         );
5000:     }
5001: 
5002:     #[test]
5003:     fn unknown_dispatch_nextto_uses_its_registry_declared_anchor() {
5004:         let src = concat!(
5005:             "oo::class create ParentMeta {\n",
5006:             "    superclass oo::class\n",
5007:             "    method unknown {w args} { return inherited }\n",
5008:             "}\n",
5009:             "oo::class create Meta {\n",
5010:             "    superclass ParentMeta\n",
5011:             "    method unknown {w args} {\n",
5012:             "        if {[string match .* $w]} {\n",
5013:             "            [self] create ::$w {*}$args\n",
5014:             "            return $w\n",
5015:             "        }\n",
5016:             "        nextto ParentMeta $w {*}$args\n",
5017:             "    }\n",
5018:             "}\n",
5019:         );
5020:         assert!(!factory_of(src, "::Meta").unknown_binds_instance);
5021:     }
5022: 
5023:     #[test]
5024:     fn unknown_dispatch_next_abstains_on_a_cyclic_hierarchy() {
5025:         // Malformed-input conservatism: C Tcl 9.0.4 rejects the forward
5026:         // mixin names below, and also rejects an equivalent post-definition
5027:         // CycleA <-> CycleB update with "may not mix a class into itself".
5028:         // The analyser still records enough partial structure to encounter
5029:         // the relation cycle, but must never treat its truncated MRO as a
5030:         // proved route to the terminal builtin fallback.
5031:         let src = concat!(
5032:             "oo::class create CycleA { mixin CycleB }\n",
5033:             "oo::class create CycleB { mixin CycleA }\n",
5034:             "oo::class create Meta {\n",
5035:             "    superclass oo::class\n",
5036:             "    mixin CycleA\n",
5037:             "    method unknown {w args} {\n",
5038:             "        if {[string match .* $w]} {\n",
5039:             "            [self] create ::$w {*}$args\n",
5040:             "            return $w\n",
5041:             "        }\n",
5042:             "        next $w {*}$args\n",
5043:             "    }\n",
5044:             "}\n",
5045:         );
5046:         assert!(!factory_of(src, "::Meta").unknown_binds_instance);
5047:     }
5048: 
5049:     #[test]
5050:     fn unknown_dispatch_next_abstains_on_an_incomplete_hierarchy() {
5051:         let src = concat!(
5052:             "oo::class create Meta {\n",
5053:             "    superclass oo::class ::External\n",
5054:             "    method unknown {w args} {\n",
5055:             "        if {[string match .* $w]} {\n",
5056:             "            [self] create ::$w {*}$args\n",
5057:             "            return $w\n",
5058:             "        }\n",
5059:             "        next $w {*}$args\n",
5060:             "    }\n",
5061:             "}\n",
5062:         );
5063:         assert!(!factory_of(src, "::Meta").unknown_binds_instance);
5064:     }
5065: 
5066:     #[test]
5067:     fn unknown_dispatch_rejects_a_malformed_if_path() {
5068:         let src = concat!(
5069:             "oo::class create Meta {\n",
5070:             "    superclass oo::class\n",
5071:             "    method unknown {w args} {\n",
5072:             "        if {1}\n",
5073:             "        [self] create ::$w\n",
5074:             "        return $w\n",
5075:             "    }\n",
5076:             "}\n",
5077:         );
5078:         assert!(!factory_of(src, "::Meta").unknown_binds_instance);
5079:     }
5080: 
5081:     #[test]
5082:     fn unknown_dispatch_non_normal_return_does_not_prove_a_handle() {
5083:         let src = concat!(
5084:             "oo::class create Meta {\n",
5085:             "    superclass oo::class\n",
5086:             "    method unknown {w args} {\n",
5087:             "        [self] create ::$w\n",
5088:             "        return -code error $w\n",
5089:             "    }\n",
5090:             "}\n",
5091:         );
5092:         assert!(!factory_of(src, "::Meta").unknown_binds_instance);
5093:     }
5094: 
5095:     #[test]
5096:     fn unknown_dispatch_stops_at_an_earlier_terminating_command() {
5097:         let src = concat!(
5098:             "oo::class create Meta {\n",
5099:             "    superclass oo::class\n",
5100:             "    method unknown {w args} {\n",
5101:             "        error stopped\n",
5102:             "        [self] create ::$w\n",
5103:             "        return $w\n",
5104:             "    }\n",
5105:             "}\n",
5106:         );
5107:         assert!(!factory_of(src, "::Meta").unknown_binds_instance);
5108:     }
5109: 
5110:     #[test]
5111:     fn unknown_dispatch_returning_something_else_abstains() {
5112:         // TN — it constructs, but hands back the *class*, so the
5113:         // caller's variable is not the new object's name. Guessing here would
5114:         // type a handle that does not exist.
5115:         let src = concat!(
5116:             "oo::class create Meta {\n",
5117:             "    superclass oo::class\n",
5118:             "    method unknown {w args} {\n",
5119:             "        [self] create ::$w {*}$args\n",
5120:             "        return [self]\n",
5121:             "    }\n",
5122:             "}\n",
5123:         );
5124:         assert!(
5125:             !factory_of(src, "::Meta").unknown_binds_instance,
5126:             "an unknown that returns the class must not be read as returning the object"
5127:         );
5128:     }
5129: 
5130:     #[test]
5131:     fn unknown_dispatch_that_does_not_construct_abstains() {
5132:         // TN — an `unknown` that merely echoes its argument creates
5133:         // no object at all, so binding a handle to it would be a fabrication.
5134:         let src = concat!(
5135:             "oo::class create Meta {\n",
5136:             "    superclass oo::class\n",
5137:             "    method unknown {w args} { return $w }\n",
5138:             "}\n",
5139:         );
5140:         assert!(
5141:             !factory_of(src, "::Meta").unknown_binds_instance,
5142:             "an unknown that constructs nothing must abstain"
5143:         );
5144:     }
5145: 
5146:     #[test]
5147:     fn unknown_dispatch_with_no_return_abstains() {
5148:         // TN — a pure delegation to `next` proves nothing about the
5149:         // value the call yields.
5150:         let src = concat!(
5151:             "oo::class create Meta {\n",
5152:             "    superclass oo::class\n",
5153:             "    method unknown {w args} { next $w {*}$args }\n",
5154:             "}\n",
5155:         );
5156:         assert!(
5157:             !factory_of(src, "::Meta").unknown_binds_instance,
5158:             "an unknown with no proved result must abstain"
5159:         );
5160:     }
5161: 
5162:     #[test]
5163:     fn unknown_dispatch_returning_a_derived_word_abstains() {
5164:         // TN — `return $w.hull` is not the caller's word, and a
5165:         // consumer binding the caller's variable to the class would be wrong.
5166:         let src = concat!(
5167:             "oo::class create Meta {\n",
5168:             "    superclass oo::class\n",
5169:             "    method unknown {w args} {\n",
5170:             "        [self] create ::$w {*}$args\n",
5171:             "        return $w.hull\n",
5172:             "    }\n",
5173:             "}\n",
5174:         );
5175:         assert!(
5176:             !factory_of(src, "::Meta").unknown_binds_instance,
5177:             "a derived return word must abstain"
5178:         );
5179:     }
5180: 
5181:     #[test]
5182:     fn unknown_dispatch_constructing_a_derived_word_abstains() {
5183:         // FP guard — the returned value is exactly the caller's word,
5184:         // but the constructed command has a suffix. Seeing the parameter
5185:         // somewhere in the name word is not proof that the returned handle
5186:         // names that object.
5187:         let src = concat!(
5188:             "oo::class create Meta {\n",
5189:             "    superclass oo::class\n",
5190:             "    method unknown {w args} {\n",
5191:             "        [self] create $w.hull {*}$args\n",
5192:             "        return $w\n",
5193:             "    }\n",
5194:             "}\n",
5195:         );
5196:         assert!(
5197:             !factory_of(src, "::Meta").unknown_binds_instance,
5198:             "constructing a derived name must not type the returned word"
5199:         );
5200:     }
5201: 
5202:     #[test]
5203:     fn unknown_dispatch_cannot_combine_evidence_from_different_branches() {
5204:         // FP guard: One branch constructs but does not return the
5205:         // handle; the other returns the requested word without constructing
5206:         // it. No successful path proves both facts, so flattening nested
5207:         // scripts and combining their evidence would invent an object type.
5208:         let src = concat!(
5209:             "oo::class create Meta {\n",
5210:             "    superclass oo::class\n",
5211:             "    method unknown {w args} {\n",
5212:             "        if {$w eq .construct} { [self] create ::$w }\n",
5213:             "        if {$w eq .echo} { return $w }\n",
5214:             "        next $w {*}$args\n",
5215:             "    }\n",
5216:             "}\n",
5217:         );
5218:         assert!(
5219:             !factory_of(src, "::Meta").unknown_binds_instance,
5220:             "construction and return evidence from disjoint branches must not be joined"
5221:         );
5222:     }
5223: 
5224:     #[test]
5225:     fn a_metaclass_without_unknown_dispatch_abstains() {
5226:         // TN: the ordinary metaclass shape must keep answering `false` —
5227:         // without the constructor idiom, a bare word must not silently
5228:         // bind to an instance.
5229:         let src = concat!(
5230:             "oo::class create Meta {\n",
5231:             "    superclass oo::class\n",
5232:             "}\n",
5233:         );
5234:         assert!(
5235:             !factory_of(src, "::Meta").unknown_binds_instance,
5236:             "a metaclass with no unknown member must abstain"
5237:         );
5238:     }
5239: 
5240:     #[test]
5241:     fn unknown_dispatch_proof_survives_the_cross_document_rehome() {
5242:         // The fact is a property of the metaclass's body and carries no
5243:         // token, so it must cross a document boundary unchanged — otherwise
5244:         // the Tk shape would resolve only in the file that declares the
5245:         // metaclass.
5246:         let elsewhere =
5247:             tcl_lexer::Token::new(tcl_lexer::TokenType::Esc, tcl_lexer::Span::new(0, 1));
5248:         assert!(
5249:             factory_of(UNKNOWN_CTOR, "::Meta")
5250:                 .resolve_in_other_document(elsewhere, &|_| false)
5251:                 .unknown_binds_instance,
5252:             "the proof must survive `resolve_in_other_document`"
5253:         );
5254:     }
5255: 
5256:     #[test]
5257:     fn oo_define_over_a_literal_foreach_list_extends_every_named_class() {
5258:         // TP: the ticklecharts `etsb.tcl` monkey-patch.  Each
5259:         // literal element names a real class, so each gets the injected
5260:         // method; nothing lands under a synthetic `@dynclass@` key.
5261:         let src = concat!(
5262:             "oo::class create chart { method Render {} { return 1 } }\n",
5263:             "oo::class create timeline { method Render {} { return 1 } }\n",
5264:             "foreach cls {chart timeline} {\n",
5265:             "    oo::define $cls {\n",
5266:             "        method RenderTsb {} { return tsb }\n",
5267:             "    }\n",
5268:             "}\n",
5269:         );
5270:         let r = analysis(src, "tcl9.0");
5271:         for name in ["::chart", "::timeline"] {
5272:             assert!(
5273:                 r.all_classes[name].methods.contains_key("RenderTsb"),
5274:                 "{name} gained RenderTsb: {:?}",
5275:                 r.all_classes[name].methods.keys().collect::<Vec<_>>()
5276:             );
5277:         }
5278:         assert!(
5279:             !r.all_classes.keys().any(|k| k.contains("@dynclass@")),
5280:             "no synthetic class survives: {:?}",
5281:             r.all_classes.keys().collect::<Vec<_>>()
5282:         );
5283:     }
5284: 
5285:     #[test]
5286:     fn the_foreach_simulation_does_not_duplicate_body_diagnostics() {
5287:         // FP guard — the simulation re-dispatches only the named-definition
5288:         // installer, once per element.  A diagnostic raised inside the
5289:         // injected member's own body must still be reported exactly once
5290:         // per class it lands on, never once per (class × iteration).
5291:         let src = concat!(
5292:             "oo::class create chart { method Render {} { return 1 } }\n",
5293:             "oo::class create timeline { method Render {} { return 1 } }\n",
5294:             "foreach cls {chart timeline} {\n",
5295:             "    oo::define $cls {\n",
5296:             "        method RenderTsb {} { return $undefinedVar }\n",
5297:             "    }\n",
5298:             "}\n",
5299:         );
5300:         let spans: Vec<_> = analysis(src, "tcl9.0")
5301:             .diagnostics
5302:             .iter()
5303:             .map(|d| (d.code.to_string(), d.span))
5304:             .collect();
5305:         let mut seen = std::collections::HashSet::new();
5306:         for entry in &spans {
5307:             assert!(
5308:                 seen.insert(entry.clone()),
5309:                 "duplicate diagnostic {entry:?} in {spans:?}",
5310:             );
5311:         }
5312:     }
5313: 
5314:     /// tcllib 2.0's `oo::dialect` shape, retaining its namespace-normalising
5315:     /// helper and intermediate `NSPACE` assignment: the metaclass is created
5316:     /// under a name computed from that local, and the one call site passes a
5317:     /// literal.
5318:     ///
5319:     /// tclsh 9.0.4: the whole three-file chain really runs — `::T::mkdialect
5320:     /// ::T::D` then `::T::D::class create ::T::W {method go {} {return went}}`
5321:     /// then `[[::T::W new] go]` answers `went`.
5322:     const COMPUTED_METACLASS: &str = concat!(
5323:         "namespace eval ::T {}\n",
5324:         "oo::class create ::T::Mother { superclass oo::class }\n",
5325:         "proc ::T::NSNormalize {namespace qualname} {\n",
5326:         "    if {![string match ::* $qualname]} {\n",
5327:         "        set qualname ${namespace}::$qualname\n",
5328:         "    }\n",
5329:         "    regsub -all {::+} $qualname \"::\"\n",
5330:         "}\n",
5331:         "proc ::T::mkdialect {name} {\n",
5332:         "    set NSPACE [NSNormalize [uplevel 1 {namespace current}] $name]\n",
5333:         "    ::T::Mother create ${NSPACE}::class { superclass ::T::Mother }\n",
5334:         "}\n",
5335:         "::T::mkdialect ::T::D\n",
5336:     );
5337: 
5338:     #[test]
5339:     fn a_computed_metaclass_name_resolves_through_a_literal_call_site() {
5340:         // TP — the literal argument proves `${ns}::class` is
5341:         // `::T::D::class`, so the metaclass enters the factory index and
5342:         // everything it later manufactures becomes visible.
5343:         let result = analysis(COMPUTED_METACLASS, "tcl9.0");
5344:         assert!(
5345:             result.all_classes.contains_key("::T::D::class"),
5346:             "expected ::T::D::class; got {:?}",
5347:             result.all_classes.keys().collect::<Vec<_>>()
5348:         );
5349:         assert!(
5350:             result.class_factories().contains_key("::T::D::class"),
5351:             "the resolved metaclass must publish a factory"
5352:         );
5353:     }
5354: 
5355:     #[test]
5356:     fn disjoint_dynamic_command_table_names_preserve_provenance() {
5357:         // TP/FP control: the alias target words retain the fixed
5358:         // `::define::` fragment, so neither the earlier nor later mutation
5359:         // can denote NSNormalize, string, or regsub. This is the command-table
5360:         // shape used by tcllib's dialect factory.
5361:         let src = COMPUTED_METACLASS.replace(
5362:             "    ::T::Mother create ${NSPACE}::class { superclass ::T::Mother }\n",
5363:             concat!(
5364:                 "    set method current_class\n",
5365:                 "    interp alias {} ${NSPACE}::define::$method {} puts\n",
5366:                 "    ::T::Mother create ${NSPACE}::class { superclass ::T::Mother }\n",
5367:                 "    interp alias {} ${NSPACE}::define::later {} puts\n",
5368:             ),
5369:         );
5370:         assert!(
5371:             analysis(&src, "tcl9.0")
5372:                 .all_classes
5373:                 .contains_key("::T::D::class"),
5374:             "disjoint dynamic command names must not poison every identity"
5375:         );
5376:     }
5377: 
5378:     #[test]
5379:     fn dormant_dynamic_command_table_words_do_not_mutate_load_time_identity() {
5380:         // TN control: declaring a proc does not execute its body. A broad
5381:         // dynamic command-table target in that dormant body can therefore
5382:         // coexist with the proved helper identity; the exact tcllib corpus
5383:         // contains this shape in unrelated factory bodies.
5384:         let src = COMPUTED_METACLASS.replace(
5385:             "::T::mkdialect ::T::D\n",
5386:             concat!(
5387:                 "proc ::T::dormant {name} { proc ${name} {} {} }\n",
5388:                 "::T::mkdialect ::T::D\n",
5389:             ),
5390:         );
5391:         assert!(
5392:             analysis(&src, "tcl9.0")
5393:                 .class_factories()
5394:                 .contains_key("::T::D::class"),
5395:             "a dormant body must not mutate the load-time command table"
5396:         );
5397:     }
5398: 
5399:     #[test]
5400:     fn unrelated_multi_arm_writes_preserve_provenance() {
5401:         // TN control: branch selection is unknown, but every arm writes only
5402:         // `other`. The dominating NSPACE fact remains valid.
5403:         let src = COMPUTED_METACLASS.replace(
5404:             "    ::T::Mother create ${NSPACE}::class { superclass ::T::Mother }\n",
5405:             concat!(
5406:                 "    if {$runtime} {set other a} else {set other b}\n",
5407:                 "    ::T::Mother create ${NSPACE}::class { superclass ::T::Mother }\n",
5408:             ),
5409:         );
5410:         assert!(
5411:             analysis(&src, "tcl9.0")
5412:                 .all_classes
5413:                 .contains_key("::T::D::class"),
5414:             "a branch writing an unrelated local must preserve NSPACE"
5415:         );
5416:     }
5417: 
5418:     #[test]
5419:     fn a_multi_arm_write_to_the_provenance_variable_abstains() {
5420:         // FP guard: either arm may replace the computed name.
5421:         let src = COMPUTED_METACLASS.replace(
5422:             "    ::T::Mother create ${NSPACE}::class { superclass ::T::Mother }\n",
5423:             concat!(
5424:                 "    if {$runtime} {set NSPACE ::Bad} else {set other b}\n",
5425:                 "    ::T::Mother create ${NSPACE}::class { superclass ::T::Mother }\n",
5426:             ),
5427:         );
5428:         assert!(
5429:             !analysis(&src, "tcl9.0")
5430:                 .all_classes
5431:                 .contains_key("::T::D::class"),
5432:             "a branch write to NSPACE must invalidate its provenance"
5433:         );
5434:     }
5435: 
5436:     #[test]
5437:     fn an_unknown_same_frame_branch_write_abstains() {
5438:         // FP guard: eval's registry-declared same-frame body may write any
5439:         // local, so a dynamic script invalidates NSPACE.
5440:         let src = COMPUTED_METACLASS.replace(
5441:             "    ::T::Mother create ${NSPACE}::class { superclass ::T::Mother }\n",
5442:             concat!(
5443:                 "    if {$runtime} {eval $script}\n",
5444:                 "    ::T::Mother create ${NSPACE}::class { superclass ::T::Mother }\n",
5445:             ),
5446:         );
5447:         assert!(
5448:             !analysis(&src, "tcl9.0")
5449:                 .all_classes
5450:                 .contains_key("::T::D::class"),
5451:             "an unknown same-frame write must invalidate provenance"
5452:         );
5453:     }
5454: 
5455:     #[test]
5456:     fn a_collection_loop_in_the_dominating_prefix_preserves_provenance() {
5457:         // TP — `foreach` iterates a value the invocation itself
5458:         // supplies, so it runs a bounded number of times and control reaches
5459:         // the creation below it exactly when the loop body falls through.
5460:         // Nothing is read *out* of the loop: the body writes only its own
5461:         // iteration variable and an unrelated local, so NSPACE's provenance
5462:         // survives. This is tcllib clay's `foreach command [info commands
5463:         // ::oo::define::*] {…}`, which must not abstain the whole walk
5464:         // merely by standing between `set NSPACE …` and the creation.
5465:         let src = COMPUTED_METACLASS.replace(
5466:             "    ::T::Mother create ${NSPACE}::class { superclass ::T::Mother }\n",
5467:             concat!(
5468:                 "    foreach command [info commands ::oo::define::*] {\n",
5469:                 "        set procname [namespace tail $command]\n",
5470:                 "    }\n",
5471:                 "    ::T::Mother create ${NSPACE}::class { superclass ::T::Mother }\n",
5472:             ),
5473:         );
5474:         let result = analysis(&src, "tcl9.0");
5475:         assert!(
5476:             result.all_classes.contains_key("::T::D::class"),
5477:             "a bounded collection loop must not abstain the walk; got {:?}",
5478:             result.all_classes.keys().collect::<Vec<_>>()
5479:         );
5480:         assert!(
5481:             result.class_factories().contains_key("::T::D::class"),
5482:             "the resolved metaclass must still publish a factory"
5483:         );
5484:     }
5485: 
5486:     #[test]
5487:     fn a_collection_loop_writing_the_provenance_variable_abstains() {
5488:         // FP guard for the above — the relaxation covers *reachability*
5489:         // only. Which iteration ran, or whether any did, stays undecidable,
5490:         // so a loop body that writes NSPACE destroys the fact exactly as an
5491:         // unknown-selection `if` arm does.
5492:         let src = COMPUTED_METACLASS.replace(
5493:             "    ::T::Mother create ${NSPACE}::class { superclass ::T::Mother }\n",
5494:             concat!(
5495:                 "    foreach command {a b} {\n",
5496:                 "        set NSPACE $command\n",
5497:                 "    }\n",
5498:                 "    ::T::Mother create ${NSPACE}::class { superclass ::T::Mother }\n",
5499:             ),
5500:         );
5501:         assert!(
5502:             !analysis(&src, "tcl9.0")
5503:                 .all_classes
5504:                 .contains_key("::T::D::class"),
5505:             "a loop write to NSPACE must invalidate its provenance"
5506:         );
5507:     }
5508: 
5509:     #[test]
5510:     fn a_collection_loop_whose_body_diverges_abstains() {
5511:         // FP guard: "bounded" buys the termination fact, nothing else. If the
5512:         // body cannot reach its own end, the loop reaches the statement after
5513:         // it only when the collection was empty — which is exactly what this
5514:         // walk cannot decide — so the creation below stays unproved.
5515:         let src = COMPUTED_METACLASS.replace(
5516:             "    ::T::Mother create ${NSPACE}::class { superclass ::T::Mother }\n",
5517:             concat!(
5518:                 "    foreach command {a b} {\n",
5519:                 "        return\n",
5520:                 "    }\n",
5521:                 "    ::T::Mother create ${NSPACE}::class { superclass ::T::Mother }\n",
5522:             ),
5523:         );
5524:         assert!(
5525:             !analysis(&src, "tcl9.0")
5526:                 .all_classes
5527:                 .contains_key("::T::D::class"),
5528:             "a loop body that cannot fall through must abstain"
5529:         );
5530:     }
5531: 
5532:     #[test]
5533:     fn a_creation_inside_a_collection_loop_body_abstains() {
5534:         // FP guard on the *selection* axis: a bounded loop is still not a
5535:         // selectable arm. A creation written inside the body runs once per
5536:         // element and not at all for an empty collection, so the walk must
5537:         // not claim it the way it claims a creation in the unconditional
5538:         // statement stream.
5539:         let src = COMPUTED_METACLASS.replace(
5540:             "    ::T::Mother create ${NSPACE}::class { superclass ::T::Mother }\n",
5541:             concat!(
5542:                 "    foreach x {a} {\n",
5543:                 "        ::T::Mother create ${NSPACE}::class { superclass ::T::Mother }\n",
5544:                 "    }\n",
5545:             ),
5546:         );
5547:         assert!(
5548:             !analysis(&src, "tcl9.0")
5549:                 .all_classes
5550:                 .contains_key("::T::D::class"),
5551:             "a creation inside a loop body must not be claimed"
5552:         );
5553:     }
5554: 
5555:     #[test]
5556:     fn a_condition_loop_in_the_dominating_prefix_abstains() {
5557:         // FP guard for the same relaxation, on the other axis: a `while` /
5558:         // `for` trip count depends on state no descriptor here can read, so
5559:         // the loop may never terminate and nothing is claimed about the
5560:         // statement after it. Only *collection* loops carry the termination
5561:         // guarantee the relaxation rests on.
5562:         for loop_text in [
5563:             "    while {[incr n] < $limit} {\n        set zz 1\n    }\n",
5564:             "    for {set i 0} {$i < $limit} {incr i} {\n        set zz 1\n    }\n",
5565:         ] {
5566:             let src = COMPUTED_METACLASS.replace(
5567:                 "    ::T::Mother create ${NSPACE}::class { superclass ::T::Mother }\n",
5568:                 &format!(
5569:                     "{loop_text}    ::T::Mother create ${{NSPACE}}::class {{ superclass ::T::Mother }}\n"
5570:                 ),
5571:             );
5572:             assert!(
5573:                 !analysis(&src, "tcl9.0")
5574:                     .all_classes
5575:                     .contains_key("::T::D::class"),
5576:                 "an unbounded loop must abstain: {loop_text:?}"
5577:             );
5578:         }
5579:     }
5580: 
5581:     #[test]
5582:     fn a_declaration_body_the_walk_cannot_read_is_not_a_blocker() {
5583:         // TP — `proc NAME ARGS [string map … {…}]` *stores* its body;
5584:         // nothing in it runs at this call, so an unreadable body word says
5585:         // nothing about whether the declaration falls through. `proc` says so
5586:         // itself, through `Traits::DEFERS_BODY` — see
5587:         // `an_immediately_executed_body_the_walk_cannot_read_still_abstains`
5588:         // for why that has to be a declared fact rather than an inference.
5589:         // This is tcllib clay's `proc ${NSPACE}::define {oclass args}
5590:         // [string map [list %NSPACE% $NSPACE] {…}]`.
5591:         let src = COMPUTED_METACLASS.replace(
5592:             "    ::T::Mother create ${NSPACE}::class { superclass ::T::Mother }\n",
5593:             concat!(
5594:                 "    proc ${NSPACE}::define {oclass args} [string map [list %NSPACE% $NSPACE] {\n",
5595:                 "        set class $oclass\n",
5596:                 "    }]\n",
5597:                 "    ::T::Mother create ${NSPACE}::class { superclass ::T::Mother }\n",
5598:             ),
5599:         );
5600:         let result = analysis(&src, "tcl9.0");
5601:         assert!(
5602:             result.all_classes.contains_key("::T::D::class"),
5603:             "an unreadable proc body must not abstain the walk; got {:?}",
5604:             result.all_classes.keys().collect::<Vec<_>>()
5605:         );
5606:         assert!(
5607:             result.class_factories().contains_key("::T::D::class"),
5608:             "the resolved metaclass must still publish a factory"
5609:         );
5610:     }
5611: 
5612:     #[test]
5613:     fn a_running_body_the_walk_cannot_read_still_abstains() {
5614:         // FP guard: `namespace eval $ns $script` runs its body at this very
5615:         // call and the registry types that arm (`FrameBoundary`), so a body
5616:         // word the walk cannot read there is a fact it genuinely needed.
5617:         let src = COMPUTED_METACLASS.replace(
5618:             "    ::T::Mother create ${NSPACE}::class { superclass ::T::Mother }\n",
5619:             concat!(
5620:                 "    namespace eval ::T [string map [list a b] {\n",
5621:                 "        set class 1\n",
5622:                 "    }]\n",
5623:                 "    ::T::Mother create ${NSPACE}::class { superclass ::T::Mother }\n",
5624:             ),
5625:         );
5626:         assert!(
5627:             !analysis(&src, "tcl9.0")
5628:                 .all_classes
5629:                 .contains_key("::T::D::class"),
5630:             "an unreadable body that runs now must still abstain"
5631:         );
5632:     }
5633: 
5634:     #[test]
5635:     fn an_immediately_executed_body_the_walk_cannot_read_still_abstains() {
5636:         // FP guard, and the reason dormancy has to be *declared* rather than
5637:         // inferred.
5638:         //
5639:         // None of these commands carries control-arm semantics, exactly like
5640:         // `proc`. Unlike `proc`, every one of them **runs** its script as part
5641:         // of this very call, so the script can raise, `return`, or otherwise
5642:         // stop control ever reaching the creation below it. Reading "no typed
5643:         // control semantics" as proof of dormancy would therefore let the walk
5644:         // materialise a class created after a script that aborts.
5645:         //
5646:         // `BodyKind` cannot separate them either: `proc` and `uplevel` are
5647:         // both `Structural`, because that descriptor answers *which frame*,
5648:         // not *when*. Only `Traits::DEFERS_BODY` does, and it is unset here.
5649:         for prefix in [
5650:             "    uplevel 1 $script\n",
5651:             "    uplevel 0 $script\n",
5652:             "    uplevel #0 $script\n",
5653:             "    oo::define ::T::Mother $script\n",
5654:         ] {
5655:             let src = COMPUTED_METACLASS.replace(
5656:                 "    ::T::Mother create ${NSPACE}::class { superclass ::T::Mother }\n",
5657:                 &format!(
5658:                     "{prefix}    ::T::Mother create ${{NSPACE}}::class {{ superclass ::T::Mother }}\n"
5659:                 ),
5660:             );
5661:             let result = analysis(&src, "tcl9.0");
5662:             assert!(
5663:                 !result.all_classes.contains_key("::T::D::class"),
5664:                 "an immediately-executed unreadable body must abstain: {prefix:?}; got {:?}",
5665:                 result.all_classes.keys().collect::<Vec<_>>()
5666:             );
5667:         }
5668:     }
5669: 
5670:     #[test]
5671:     fn an_aborting_uplevel_script_cannot_be_walked_past() {
5672:         // The concrete harm the guard above prevents, in one vector: the
5673:         // script `uplevel` runs really does end the procedure before the
5674:         // creation, so a walk that claimed the class would be reporting a
5675:         // class no interpreter ever makes.
5676:         let src = COMPUTED_METACLASS.replace(
5677:             "    ::T::Mother create ${NSPACE}::class { superclass ::T::Mother }\n",
5678:             concat!(
5679:                 "    uplevel 1 $script\n",
5680:                 "    ::T::Mother create ${NSPACE}::class { superclass ::T::Mother }\n",
5681:             ),
5682:         );
5683:         let result = analysis(&src, "tcl9.0");
5684:         assert!(
5685:             !result.class_factories().contains_key("::T::D::class"),
5686:             "no factory may be published past an aborting script; got {:?}",
5687:             result.class_factories().keys().collect::<Vec<_>>()
5688:         );
5689:     }
5690: 
5691:     #[test]
5692:     fn a_post_pass_metaclass_classifies_a_creation_in_its_own_file() {
5693:         // TP — `::T::D::class` is proved a metaclass only by the
5694:         // parameterised-class join, which runs *after* the walk, so a
5695:         // creation call naming it in the same document had nothing to be
5696:         // classified against and the class it makes went unrecorded: no
5697:         // factory, no members, no completion.
5698:         //
5699:         // tclsh 8.6.16 / 9.0.4 run the whole chain: `::T::W` exists, is a
5700:         // class, `info object class ::T::W` is `::T::D::class`, its methods
5701:         // are `go`, and `[[::T::W new] go]` answers `went`.
5702:         let src = format!(
5703:             "{COMPUTED_METACLASS}::T::D::class create ::T::W {{ method go {{}} {{ return went }} }}\n"
5704:         );
5705:         let result = analysis(&src, "tcl9.0");
5706:         let w = result
5707:             .all_classes
5708:             .get("::T::W")
5709:             .expect("the class the post-pass metaclass makes must be recorded");
5710:         assert!(
5711:             w.methods.contains_key("go"),
5712:             "its members come from the creation body; got {:?}",
5713:             w.methods.keys().collect::<Vec<_>>()
5714:         );
5715:         assert!(
5716:             w.metaclass.ends_with("T::D::class"),
5717:             "the recorded metaclass is the head the source wrote; got {:?}",
5718:             w.metaclass
5719:         );
5720:         // `::T::W` declares no superclass, so it is an ordinary class rather
5721:         // than another factory — the replay must not manufacture one.
5722:         assert!(
5723:             !result.class_factories().contains_key("::T::W"),
5724:             "a plain class must publish no factory; got {:?}",
5725:             result.class_factories().keys().collect::<Vec<_>>()
5726:         );
5727:     }
5728: 
5729:     #[test]
5730:     fn a_replayed_creation_can_itself_prove_the_next_one() {
5731:         // The replay runs in document order, so a chain settles in one pass:
5732:         // `::T::Sub` is created by the post-pass metaclass *and* declares it
5733:         // as its superclass, which makes `::T::Sub` a factory in turn, which
5734:         // is what classifies `::T::Leaf`.
5735:         //
5736:         // tclsh 8.6.16 / 9.0.4: `info object class ::T::Sub` is
5737:         // `::T::D::class`, `info object class ::T::Leaf` is `::T::Sub`, and
5738:         // `[[::T::Leaf new] go]` answers `leafy`.
5739:         let src = format!(
5740:             "{COMPUTED_METACLASS}\
5741:              ::T::D::class create ::T::Sub {{ superclass ::T::D::class }}\n\
5742:              ::T::Sub create ::T::Leaf {{ method go {{}} {{ return leafy }} }}\n"
5743:         );
5744:         let result = analysis(&src, "tcl9.0");
5745:         assert!(
5746:             result.class_factories().contains_key("::T::Sub"),
5747:             "a replayed class that inherits the metaclass is a factory too; got {:?}",
5748:             result.class_factories().keys().collect::<Vec<_>>()
5749:         );
5750:         let leaf = result
5751:             .all_classes
5752:             .get("::T::Leaf")
5753:             .expect("the second link of the chain must be recorded");
5754:         assert!(
5755:             leaf.methods.contains_key("go"),
5756:             "got {:?}",
5757:             leaf.methods.keys().collect::<Vec<_>>()
5758:         );
5759:     }
5760: 
5761:     #[test]
5762:     fn an_unknown_head_that_never_becomes_a_factory_records_nothing() {
5763:         // FP guard: deferring a call is not a claim about it. A head that is
5764:         // still unknown when the join has settled — no proc, no class, no
5765:         // registry command — must record exactly what it did before this
5766:         // pass existed, which is nothing at all.
5767:         let src = concat!(
5768:             "namespace eval ::T {}\n",
5769:             "::T::NoSuchMeta create ::T::Q { method m {} {} }\n",
5770:         );
5771:         let result = analysis(src, "tcl9.0");
5772:         assert!(
5773:             !result.all_classes.contains_key("::T::Q"),
5774:             "an unproved head must manufacture nothing; got {:?}",
5775:             result.all_classes.keys().collect::<Vec<_>>()
5776:         );
5777:     }
5778: 
5779:     #[test]
5780:     fn the_incremental_path_records_the_same_classes_as_a_full_analysis() {
5781:         // The deferred creation is *pending verdict* state, so it has to
5782:         // survive a snapshot/restore exactly as the pending-arity buffers
5783:         // do. The LSP's incremental path
5784:         // restores a snapshot covering the clean prefix and re-walks only the
5785:         // dirty chunk: if the buffer is not in the snapshot, a creation call
5786:         // written in that prefix is gone, while the evidence that proves its
5787:         // metaclass — the placeholder and the load-time call — is restored
5788:         // with the result. The join then proves `::T::D::class` and nothing
5789:         // recreates `::T::W`, so the same document answers differently
5790:         // depending on which entry point analysed it.
5791:         let src = format!(
5792:             "{COMPUTED_METACLASS}\
5793:              ::T::D::class create ::T::W {{ method go {{}} {{ return went }} }}\n\
5794:              set unrelated 1\n"
5795:         );
5796:         let full = analysis(&src, "tcl9.0");
5797:         assert!(
5798:             full.all_classes.contains_key("::T::W"),
5799:             "precondition: the full analysis records the class"
5800:         );
5801: 
5802:         let commands = tcl_compiler::segmenter::segment_commands(&src);
5803:         let split = commands.len() - 1;
5804:         let (prefix, dirty) = commands.split_at(split);
5805:         let mut analyser = Analyser::new();
5806:         let (_, snapshots) =
5807:             analyser.analyse_chunked(&src, vec![prefix.to_vec(), dirty.to_vec()], "tcl9.0");
5808:         // Re-analyse the dirty chunk from the clean prefix's snapshot, which
5809:         // is what an edit to the last line does.
5810:         let mut incremental = Analyser::new();
5811:         incremental.restore(snapshots[0].clone());
5812:         let restored = incremental.analyse_commands(&src, dirty, "tcl9.0", true);
5813: 
5814:         let mut full_classes: Vec<&String> = full.all_classes.keys().collect();
5815:         let mut restored_classes: Vec<&String> = restored.all_classes.keys().collect();
5816:         full_classes.sort();
5817:         restored_classes.sort();
5818:         assert_eq!(
5819:             restored_classes, full_classes,
5820:             "incremental analysis must record the same classes as a full one"
5821:         );
5822:     }
5823: 
5824:     #[test]
5825:     fn a_deferred_creation_never_leaks_into_the_next_document() {
5826:         // The other half of owning per-run state: an analyser is reused, and
5827:         // a walk that never runs the post-walk tail (`finalise: false`, the
5828:         // partial-snapshot path) leaves the buffer full. Those calls belong
5829:         // to a document that is over — their tokens index its source — so
5830:         // carrying them forward would let the *next* document, which happens
5831:         // to prove the same metaclass, record a class it never wrote.
5832:         let mut analyser = Analyser::new();
5833:         let first =
5834:             format!("{COMPUTED_METACLASS}::T::D::class create ::T::W {{ method go {{}} {{}} }}\n");
5835:         let first_commands = tcl_compiler::segmenter::segment_commands(&first);
5836:         let _ = analyser.analyse_commands(&first, &first_commands, "tcl9.0", false);
5837: 
5838:         let second = COMPUTED_METACLASS.to_owned();
5839:         let second_commands = tcl_compiler::segmenter::segment_commands(&second);
5840:         let result = analyser.analyse_commands(&second, &second_commands, "tcl9.0", true);
5841:         assert!(
5842:             !result.all_classes.contains_key("::T::W"),
5843:             "the second document writes no creation call; got {:?}",
5844:             result.all_classes.keys().collect::<Vec<_>>()
5845:         );
5846:     }
5847: 
5848:     #[test]
5849:     fn a_creation_written_before_its_metaclass_is_proved_stays_unrecorded() {
5850:         // The limit this deliberately keeps. Written in this order the
5851:         // program does not run at all: tclsh 8.6.16 / 9.0.4 both raise
5852:         // `invalid command name "::U::D::class"`, because the metaclass does
5853:         // not exist until `::U::mk` is called on the next line. The walk's
5854:         // own reachability proof stops at the unknown head, so nothing is
5855:         // claimed — the correct answer for a program with no successful run.
5856:         let src = concat!(
5857:             "namespace eval ::U {}\n",
5858:             "oo::class create ::U::Mother { superclass oo::class }\n",
5859:             "proc ::U::mk {name} { ::U::Mother create ${name}::class { superclass ::U::Mother } }\n",
5860:             "namespace eval ::U::D {}\n",
5861:             "::U::D::class create ::U::W { method go {} {} }\n",
5862:             "::U::mk ::U::D\n",
5863:         );
5864:         let result = analysis(src, "tcl9.0");
5865:         assert!(
5866:             !result.all_classes.contains_key("::U::W"),
5867:             "a creation that cannot have run must not be recorded; got {:?}",
5868:             result.all_classes.keys().collect::<Vec<_>>()
5869:         );
5870:     }
5871: 
5872:     #[test]
5873:     fn a_replayed_creation_keeps_the_members_its_define_stub_already_held() {
5874:         // The regression the replay would otherwise cause. While the creation
5875:         // was invisible, `oo::define ::T::W` had nothing to extend, so the
5876:         // walk made a *stub* and put `extra` in it. Recording the creation
5877:         // afterwards under the same name must not throw that away — the class
5878:         // really has both members (tclsh 8.6.16 / 9.0.4: `info class methods
5879:         // ::T::W` is `go extra`).
5880:         let src = format!(
5881:             "{COMPUTED_METACLASS}\
5882:              ::T::D::class create ::T::W {{ method go {{}} {{ return went }} }}\n\
5883:              ::oo::define ::T::W {{ method extra {{}} {{}} }}\n"
5884:         );
5885:         let result = analysis(&src, "tcl9.0");
5886:         let w = result
5887:             .all_classes
5888:             .get("::T::W")
5889:             .expect("the created class is recorded");
5890:         assert!(
5891:             w.methods.contains_key("go") && w.methods.contains_key("extra"),
5892:             "both the creation body's member and the stub's must survive; got {:?}",
5893:             w.methods.keys().collect::<Vec<_>>()
5894:         );
5895:         assert!(
5896:             !w.via_define,
5897:             "this file creates the class, so the record is not an extension stub"
5898:         );
5899:         assert!(
5900:             w.metaclass.ends_with("T::D::class"),
5901:             "got {:?}",
5902:             w.metaclass
5903:         );
5904:     }
5905: 
5906:     #[test]
5907:     fn a_replayed_creation_with_a_relative_name_homes_where_it_was_written() {
5908:         // A replayed creation goes back through the handler the walk uses, so
5909:         // its name homes by the same rule: `create W` written inside
5910:         // `namespace eval ::T` is `::T::W`, not a global `::W`. Recording it
5911:         // anywhere else would put a class in the index no interpreter has.
5912:         //
5913:         // tclsh 8.6.16 / 9.0.4: `info commands ::T::W` finds it and
5914:         // `info commands ::W` does not.
5915:         let src = format!(
5916:             "{COMPUTED_METACLASS}namespace eval ::T {{\n    ::T::D::class create W {{ method go {{}} {{}} }}\n}}\n"
5917:         );
5918:         let result = analysis(&src, "tcl9.0");
5919:         assert!(
5920:             result.all_classes.contains_key("::T::W"),
5921:             "the relative name homes to the enclosing namespace; got {:?}",
5922:             result.all_classes.keys().collect::<Vec<_>>()
5923:         );
5924:         assert!(
5925:             !result.all_classes.contains_key("::W"),
5926:             "and nowhere else; got {:?}",
5927:             result.all_classes.keys().collect::<Vec<_>>()
5928:         );
5929:     }
5930: 
5931:     #[test]
5932:     fn a_head_the_walk_knew_only_as_a_define_stub_is_still_deferred() {
5933:         // "Known" is not "judged". The `oo::define` here records `::T::D::class`
5934:         // during the walk — as a stub with no factory, because the creation
5935:         // that proves it is still a computed name — so a creation call naming
5936:         // it looks like a call to a *recorded class*. Its verdict is no more
5937:         // final than an unknown head's: the post-pass join is what gives that
5938:         // stub its factory, and only then can this call be classified.
5939:         //
5940:         // tclsh 8.6.16 / 9.0.4 run it: `::T::D::class` has method `extra`,
5941:         // `info object class ::T::W` is `::T::D::class`, and `[[::T::W new] go]`
5942:         // answers `went`.
5943:         let src = format!(
5944:             "{COMPUTED_METACLASS}\
5945:              ::oo::define ::T::D::class {{ method extra {{}} {{ return e }} }}\n\
5946:              ::T::D::class create ::T::W {{ method go {{}} {{ return went }} }}\n"
5947:         );
5948:         let result = analysis(&src, "tcl9.0");
5949:         let w = result
5950:             .all_classes
5951:             .get("::T::W")
5952:             .expect("a stub-known metaclass must still classify its creation");
5953:         assert!(
5954:             w.methods.contains_key("go"),
5955:             "got {:?}",
5956:             w.methods.keys().collect::<Vec<_>>()
5957:         );
5958:         assert!(
5959:             result
5960:                 .all_classes
5961:                 .get("::T::D::class")
5962:                 .is_some_and(|meta| meta.methods.contains_key("extra")),
5963:             "and the metaclass keeps the stub's own member"
5964:         );
5965:     }
5966: 
5967:     #[test]
5968:     fn a_stub_that_contradicts_the_replayed_creation_abstains_but_keeps_members() {
5969:         // The other side of that join: the stub and the creation body declare
5970:         // *different* superclasses. Two observations that disagree publish the
5971:         // abstaining record — no factory, inheritance unknown — exactly as a
5972:         // pair of disagreeing creations does, while both sides' declarations
5973:         // stay, because they are declarations of this class either way.
5974:         let src = format!(
5975:             "{COMPUTED_METACLASS}\
5976:              oo::class create ::T::Other {{}}\n\
5977:              ::T::D::class create ::T::W {{ superclass ::T::Mother\n method go {{}} {{}} }}\n\
5978:              ::oo::define ::T::W {{ superclass ::T::Other\n method extra {{}} {{}} }}\n"
5979:         );
5980:         let result = analysis(&src, "tcl9.0");
5981:         let w = result
5982:             .all_classes
5983:             .get("::T::W")
5984:             .expect("the contested class is still recorded");
5985:         assert!(
5986:             w.inheritance_unknown,
5987:             "two disagreeing superclass observations must abstain"
5988:         );
5989:         assert!(
5990:             w.methods.contains_key("go") && w.methods.contains_key("extra"),
5991:             "an abstaining record still holds every declaration; got {:?}",
5992:             w.methods.keys().collect::<Vec<_>>()
5993:         );
5994:         assert!(
5995:             !result.class_factories().contains_key("::T::W"),
5996:             "an abstaining record publishes no factory"
5997:         );
5998:     }
5999: 
6000:     #[test]
6001:     fn a_readable_body_that_runs_now_but_is_untyped_still_abstains() {
6002:         // TP — the readable twin of the guard above. These commands carry
6003:         // no typed control-arm semantics, so the walk must not claim the
6004:         // creation below merely on the strength of having no descriptor —
6005:         // it must actually read the body.
6006:         //
6007:         // Every one of them runs its script as part of this call, and tclsh
6008:         // 8.6.16 / 9.0.4 agree the statement after it is not reached — the
6009:         // class does not exist afterwards — for both blocking completions the
6010:         // registry can prove: a raise (`error stop`, `Terminates`) and a
6011:         // propagating return (`return`, `ReturnsResult`). The `return` row is
6012:         // not merely the conservative reading: both interpreters really do
6013:         // leave the enclosing procedure, `oo::define`'s definition script
6014:         // included.
6015:         for prefix in [
6016:             "    uplevel 1 {error stop}\n",
6017:             "    eval {error stop}\n",
6018:             "    oo::define ::T::Mother {error stop}\n",
6019:             "    uplevel 1 {return}\n",
6020:             "    eval {return}\n",
6021:             "    oo::define ::T::Mother {return}\n",
6022:         ] {
6023:             let src = COMPUTED_METACLASS.replace(
6024:                 "    ::T::Mother create ${NSPACE}::class { superclass ::T::Mother }\n",
6025:                 &format!(
6026:                     "{prefix}    ::T::Mother create ${{NSPACE}}::class {{ superclass ::T::Mother }}\n"
6027:                 ),
6028:             );
6029:             let result = analysis(&src, "tcl9.0");
6030:             assert!(
6031:                 !result.all_classes.contains_key("::T::D::class"),
6032:                 "an aborting body that runs now must abstain: {prefix:?}; got {:?}",
6033:                 result.all_classes.keys().collect::<Vec<_>>()
6034:             );
6035:         }
6036:     }
6037: 
6038:     #[test]
6039:     fn a_readable_body_that_runs_now_and_completes_is_not_a_blocker() {
6040:         // TP control: the rule must cost nothing when the body does not block.
6041:         // tclsh 8.6.16 / 9.0.4 agree the class *is* created after every prefix
6042:         // here.
6043:         //
6044:         // The third vector is the one that sets the burden of proof. A
6045:         // definition script is written in a vocabulary this walk cannot type —
6046:         // `method` is not a command, it is a word `oo::define` understands —
6047:         // so requiring an untyped body to *prove* it falls through would
6048:         // abstain here, and on `oo::class create C { superclass D }`, which is
6049:         // the construct the computed-metaclass walk exists to read. The rule is
6050:         // therefore the other way round: walk past unless the body proves it
6051:         // blocks (see `untyped_body_provably_blocks`).
6052:         for prefix in [
6053:             "    eval {set zz 1}\n",
6054:             "    uplevel 1 {set zz 1}\n",
6055:             "    oo::define ::T::Mother {method extra {} {}}\n",
6056:         ] {
6057:             let src = COMPUTED_METACLASS.replace(
6058:                 "    ::T::Mother create ${NSPACE}::class { superclass ::T::Mother }\n",
6059:                 &format!(
6060:                     "{prefix}    ::T::Mother create ${{NSPACE}}::class {{ superclass ::T::Mother }}\n"
6061:                 ),
6062:             );
6063:             let result = analysis(&src, "tcl9.0");
6064:             assert!(
6065:                 result.all_classes.contains_key("::T::D::class"),
6066:                 "a body that completes must not abstain: {prefix:?}; got {:?}",
6067:                 result.all_classes.keys().collect::<Vec<_>>()
6068:             );
6069:         }
6070:     }
6071: 
6072:     #[test]
6073:     fn a_stored_body_that_cannot_fall_through_is_still_not_a_blocker() {
6074:         // FP guard, and the reason the rule is "runs now" rather than
6075:         // "readable": a `proc` body is *stored*. It never runs at this call,
6076:         // so what it would do to control flow says nothing about the
6077:         // declaration, which completes normally — tclsh 8.6.16 / 9.0.4 both
6078:         // create the class after `proc helper {a} {return $a}`, whose body
6079:         // manifestly does not fall through.
6080:         //
6081:         // `after` is the same fact with a different mechanism: the script is
6082:         // scheduled, not run, so both oracles reach the creation even when the
6083:         // scheduled script would raise.
6084:         // The rest of the list enumerates and measures every store-only form
6085:         // the registry ships: reading the *absence* of `DEFERS_BODY` as
6086:         // "runs now" would make a missing trait a silent wrong answer. Each
6087:         // row below is one
6088:         // that gained the trait, and each was proved on tclsh 8.6.16 and
6089:         // 9.0.4 with `proc p {} { FORM {error stop}; set ::reached 1 }` —
6090:         // `::reached` is set on both for all of them.
6091:         for prefix in [
6092:             "    proc helper {a} {return $a}\n",
6093:             "    after 0 {error stop}\n",
6094:             "    after idle {error stop}\n",
6095:             "    package ifneeded probe 1.0 {error stop}\n",
6096:             "    fileevent $ch readable {error stop}\n",
6097:             "    ::tcl::OptProc probe {} {error stop}\n",
6098:             "    tcltest::loadScript {error stop}\n",
6099:             "    lambda {} {error stop}\n",
6100:             "    lambda@ :: {} {error stop}\n",
6101:             "    defer::defer {error stop}\n",
6102:             "    defer::with {} {error stop}\n",
6103:             "    defer::autowith {error stop}\n",
6104:             "    processman::onexit probe {error stop}\n",
6105:             "    report::defstyle probe {} {error stop}\n",
6106:             "    snit::macro probe {} {error stop}\n",
6107:             "    snit::method ::T probe {} {error stop}\n",
6108:             "    snit::typemethod ::T probe {} {error stop}\n",
6109:         ] {
6110:             let src = COMPUTED_METACLASS.replace(
6111:                 "    ::T::Mother create ${NSPACE}::class { superclass ::T::Mother }\n",
6112:                 &format!(
6113:                     "{prefix}    ::T::Mother create ${{NSPACE}}::class {{ superclass ::T::Mother }}\n"
6114:                 ),
6115:             );
6116:             let result = analysis(&src, "tcl9.0");
6117:             assert!(
6118:                 result.all_classes.contains_key("::T::D::class"),
6119:                 "a stored body must stay ignorable: {prefix:?}; got {:?}",
6120:                 result.all_classes.keys().collect::<Vec<_>>()
6121:             );
6122:         }
6123:     }
6124: 
6125:     #[test]
6126:     fn a_deferred_tk_option_body_is_not_a_load_time_blocker() {
6127:         // A widget constructor stores -command for a later UI event.  The
6128:         // callback's `error` therefore cannot stop the constructor invocation
6129:         // or the computed metaclass creation that follows it.  This timing is
6130:         // attached to the exact option value, not inferred from BodyKind or a
6131:         // command-wide DEFERS_BODY bit.
6132:         let src = COMPUTED_METACLASS.replace(
6133:             "    ::T::Mother create ${NSPACE}::class { superclass ::T::Mother }\n",
6134:             concat!(
6135:                 "    button .b -command {error stop}\n",
6136:                 "    ::T::Mother create ${NSPACE}::class { superclass ::T::Mother }\n",
6137:             ),
6138:         );
6139:         let result = analysis(&src, "tcl9.0");
6140:         assert!(
6141:             result.all_classes.contains_key("::T::D::class"),
6142:             "a deferred Tk callback must not abort the load-time walk; got {:?}",
6143:             result.all_classes.keys().collect::<Vec<_>>()
6144:         );
6145:     }
6146: 
6147:     #[test]
6148:     fn an_apply_of_an_unreadable_lambda_still_abstains() {
6149:         // FP guard — the same soundness class as the `uplevel` vector
6150:         // above, reached through the *other* role. `apply`'s argument is
6151:         // `ArgRole::LambdaLiteral`, not `Body`, so before this fix
6152:         // `control_arms_for_segment` never saw it: the walk neither read the
6153:         // lambda nor abstained on it, and claimed the creation below.
6154:         //
6155:         // A lambda word this walk cannot read can be anything, including a
6156:         // body that raises — tclsh 8.6.16 and 9.0.4 agree that the statement
6157:         // after `apply $lambda` is not reached when it does.
6158:         // The last two vectors are readable as *text* but not as a script: a
6159:         // body element that is not `{braced}` is list-decoded before `apply`
6160:         // evaluates it, so its source slice is not the script that runs.
6161:         //
6162:         // The quoted one is the sharp case, and the reason this walk takes
6163:         // only a braced body. Its slice is `puts a\;error stop` — an escaped
6164:         // semicolon, so *as source* it is one `puts` command that falls
6165:         // through. The script `apply` actually runs is the list-decoded
6166:         // `puts a;error stop`: two commands, the second of which raises.
6167:         // tclsh 8.6.16 / 9.0.4 agree (both print `a`, raise `stop`, and never
6168:         // create the class), so a walk that read the slice would claim a
6169:         // creation neither interpreter performs.
6170:         for prefix in [
6171:             "    apply $lambda\n",
6172:             "    apply $lambda a b\n",
6173:             "    apply [set lambda]\n",
6174:             "    apply {{} error\\ stop}\n",
6175:             "    apply {{} \"puts a\\;error stop\"}\n",
6176:         ] {
6177:             let src = COMPUTED_METACLASS.replace(
6178:                 "    ::T::Mother create ${NSPACE}::class { superclass ::T::Mother }\n",
6179:                 &format!(
6180:                     "{prefix}    ::T::Mother create ${{NSPACE}}::class {{ superclass ::T::Mother }}\n"
6181:                 ),
6182:             );
6183:             let result = analysis(&src, "tcl9.0");
6184:             assert!(
6185:                 !result.all_classes.contains_key("::T::D::class"),
6186:                 "an unreadable lambda must abstain: {prefix:?}; got {:?}",
6187:                 result.all_classes.keys().collect::<Vec<_>>()
6188:             );
6189:         }
6190:     }
6191: 
6192:     #[test]
6193:     fn an_aborting_literal_lambda_cannot_be_walked_past() {
6194:         // The concrete harm, with the lambda in plain sight: both oracles
6195:         // agree the creation never happens.
6196:         //
6197:         //   proc mk {name} { apply {{} {error stop}}; Mother create … }
6198:         //
6199:         // tclsh 8.6.16 / 9.0.4: `::T::D::class` does not exist afterwards.
6200:         for prefix in [
6201:             "    apply {{} {error stop}}\n",
6202:             "    apply {{} {return -code error stop}}\n",
6203:         ] {
6204:             let src = COMPUTED_METACLASS.replace(
6205:                 "    ::T::Mother create ${NSPACE}::class { superclass ::T::Mother }\n",
6206:                 &format!(
6207:                     "{prefix}    ::T::Mother create ${{NSPACE}}::class {{ superclass ::T::Mother }}\n"
6208:                 ),
6209:             );
6210:             let result = analysis(&src, "tcl9.0");
6211:             assert!(
6212:                 !result.class_factories().contains_key("::T::D::class"),
6213:                 "no factory may be published past an aborting lambda: {prefix:?}; got {:?}",
6214:                 result.class_factories().keys().collect::<Vec<_>>()
6215:             );
6216:         }
6217:     }
6218: 
6219:     #[test]
6220:     fn a_readable_lambda_that_falls_through_is_not_a_blocker() {
6221:         // TP control for the two guards above: the fix must not cost the walk
6222:         // every `apply`. This lambda's body is right there, it completes
6223:         // normally, and tclsh 8.6.16 / 9.0.4 both reach the statement after
6224:         // it — so the creation stays proved.
6225:         let src = COMPUTED_METACLASS.replace(
6226:             "    ::T::Mother create ${NSPACE}::class { superclass ::T::Mother }\n",
6227:             concat!(
6228:                 "    apply {{} {set q 1}}\n",
6229:                 "    ::T::Mother create ${NSPACE}::class { superclass ::T::Mother }\n",
6230:             ),
6231:         );
6232:         let result = analysis(&src, "tcl9.0");
6233:         assert!(
6234:             result.all_classes.contains_key("::T::D::class"),
6235:             "a readable falling-through lambda must not abstain the walk; got {:?}",
6236:             result.all_classes.keys().collect::<Vec<_>>()
6237:         );
6238:         assert!(
6239:             result.class_factories().contains_key("::T::D::class"),
6240:             "the resolved metaclass must still publish a factory"
6241:         );
6242:     }
6243: 
6244:     #[test]
6245:     fn four_hundred_nested_foreach_bodies_do_not_abort_the_process() {
6246:         // Run on this test's own default-sized thread — which is
6247:         // the whole point: the walks this drives must contain themselves on
6248:         // the 2 MiB every unremarkable caller gets, not only on the 64 MiB
6249:         // the CLI and the LSP worker ask for. No parameterised creation
6250:         // anywhere in the file, so none of the machinery above runs; this
6251:         // is the plain braced-body descent, whose caps were hand-picked at
6252:         // 256 and wanted about 4.6 MiB to reach it.
6253:         //
6254:         // Past the cap the analyser abstains with a notice rather than
6255:         // truncating in silence, so the assertion is E207 and a returned
6256:         // result — not a resolution of anything inside.
6257:         let src: String = (0..400)
6258:             .map(|i| format!("foreach v{i} {{a b}} {{\n"))
6259:             .chain(std::iter::once("set inner 1\n".to_owned()))
6260:             .chain((0..400).map(|_| "}\n".to_owned()))
6261:             .collect();
6262:         let codes: Vec<_> = analysis(&src, "tcl9.0")
6263:             .diagnostics
6264:             .iter()
6265:             .map(|d| d.code.to_string())
6266:             .collect();
6267:         assert!(
6268:             codes.iter().any(|code| code == "E207"),
6269:             "past the cap the walk must say it stopped; got {codes:?}"
6270:         );
6271:     }
6272: 
6273:     #[test]
6274:     fn deeply_nested_untyped_bodies_do_not_blow_the_static_walk_stack() {
6275:         // The same native-stack safety net for the *untyped* body relaxation.
6276:         // `untyped_body_provably_blocks` re-enters the statement walk,
6277:         // which can re-enter it: `eval {eval {eval {…}}}` drives that recursion
6278:         // by nesting alone, so it carries the same `MAX_UNKNOWN_BODY_DEPTH`
6279:         // bound. Past the cap it abstains, the direction it takes for anything
6280:         // it cannot read, so this asserts termination and a well-formed result
6281:         // rather than a resolution.
6282:         //
6283:         // 40 is many times the cap (8) and well under the braced-body descent's
6284:         // own limit, so a failure here is this walk's recursion, not that one's.
6285:         let mut nest = "    set zz 1\n".to_owned();
6286:         for _ in 0..40 {
6287:             nest = format!("    eval {{\n{nest}    }}\n");
6288:         }
6289:         let src = COMPUTED_METACLASS.replace(
6290:             "    ::T::Mother create ${NSPACE}::class { superclass ::T::Mother }\n",
6291:             &format!(
6292:                 "{nest}    ::T::Mother create ${{NSPACE}}::class {{ superclass ::T::Mother }}\n"
6293:             ),
6294:         );
6295:         let result = analysis(&src, "tcl9.0");
6296:         assert!(
6297:             result.all_classes.contains_key("::T::Mother"),
6298:             "the literally-written metaclass must survive the deep walk"
6299:         );
6300:     }
6301: 
6302:     #[test]
6303:     fn deeply_nested_collection_loops_do_not_blow_the_static_walk_stack() {
6304:         // Native-stack safety net for the relaxation above: the fall-through
6305:         // walk re-enters itself once per control body it descends into,
6306:         // including loop bodies, so it carries the same
6307:         // `MAX_UNKNOWN_BODY_DEPTH` bound every other recursive walk in the
6308:         // analyser has. Past the cap it abstains — the
6309:         // direction it already takes for anything it cannot read — so this
6310:         // asserts termination and a well-formed result, not a resolution.
6311:         //
6312:         // 40 is many times this walk's cap (8) and comfortably below the
6313:         // braced-body descent's own limit (`MAX_BODY_DEPTH`, derived from a
6314:         // stack budget in `depth_guard`), so a failure
6315:         // here is this walk's recursion and not the generic one's.
6316:         let nest: String = (0..40)
6317:             .map(|i| format!("    foreach v{i} {{a b}} {{\n"))
6318:             .chain(std::iter::once("    set zz 1\n".to_owned()))
6319:             .chain((0..40).map(|_| "    }\n".to_owned()))
6320:             .collect();
6321:         let src = COMPUTED_METACLASS.replace(
6322:             "    ::T::Mother create ${NSPACE}::class { superclass ::T::Mother }\n",
6323:             &format!(
6324:                 "{nest}    ::T::Mother create ${{NSPACE}}::class {{ superclass ::T::Mother }}\n"
6325:             ),
6326:         );
6327:         let result = analysis(&src, "tcl9.0");
6328:         assert!(
6329:             result.all_classes.contains_key("::T::Mother"),
6330:             "the literally-written metaclass must survive the deep walk"
6331:         );
6332:     }
6333: 
6334:     #[test]
6335:     fn full_tcllib_clay_dialect_metaclass_resolves_when_the_corpus_is_available() {
6336:         // Exact tcllib 2.0 corpus oracle. Developer/bootstrap environments
6337:         // fetch this source under tmp; a source-only distribution may omit it.
6338:         //
6339:         // Corpus-gated: a checkout without the corpus must not
6340:         // read as a silent pass — announce the skip on stderr, matching the
6341:         // convention `tcl-lsp-db/tests/compiler_check_corpus.rs` already uses
6342:         // for the same tcllib-2.0 corpus ("skip: {path} not present"), so
6343:         // `cargo test -- --nocapture` (or a failure elsewhere in the run)
6344:         // makes it obvious this test asserted nothing.
6345:         //
6346:         // # What this pins, and why not more
6347:         //
6348:         // `::clay::dialect::MotherOfAllMetaClasses` is written literally
6349:         // (`::oo::class create … { superclass ::oo::class }`), so it is a
6350:         // straight true positive: the corpus must publish its factory, and
6351:         // `::clay::class` must be recorded as a class.
6352:         //
6353:         // What is deliberately *not* asserted is that `::clay::class`
6354:         // publishes a factory of its own. That class is manufactured inside
6355:         // `::clay::dialect::create` under the computed name
6356:         // `${NSPACE}::class`, so proving the name needs the whole dominating
6357:         // prefix to be statically executable — from the file's first command
6358:         // to the `::clay::dialect::create ::clay` call site, and from the
6359:         // procedure's first statement to the creation. Four constructs stand
6360:         // in that prefix. Two were *over-broad* abstentions and are fixed
6361:         // alongside this test (see
6362:         // `a_collection_loop_in_the_dominating_prefix_preserves_provenance`
6363:         // and `a_declaration_body_the_walk_cannot_read_is_not_a_blocker`).
6364:         // The other two are genuine limits of the static-execution walk, both
6365:         // inside the `::clay::PROC` helper the file calls at load time:
6366:         //
6367:         //  * `if {[info commands $name] ne {}} return` — a conditional
6368:         //    `return` selected by the live command table. The walk treats "an
6369:         //    arm may not reach the next statement" as a reason to abstain
6370:         //    rather than distinguishing an early *normal* completion from an
6371:         //    abnormal one;
6372:         //  * `eval $ninja` — the fall-through proof carries no argument
6373:         //    binding, so it cannot see that this call site leaves `ninja` at
6374:         //    its `{}` default.
6375:         //
6376:         // Asserting the *absence* of a `::clay::class` factory would ossify
6377:         // those two limits: lifting either is a strict improvement and must
6378:         // not be reported here as a failure. So this test asserts only what
6379:         // is proved, and the prose above records the boundary instead.
6380:         let corpus = std::env::var_os("TCLLIB_2_0_DIR").map_or_else(
6381:             || std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../../tmp/tcllib-2.0"),
6382:             std::path::PathBuf::from,
6383:         );
6384:         let path = corpus.join("modules/clay/clay.tcl");
6385:         let Ok(src) = std::fs::read_to_string(&path) else {
6386:             eprintln!(
6387:                 "skip: {} not present (fetch tcllib 2.0 under tmp/, or set TCLLIB_2_0_DIR)",
6388:                 path.display()
6389:             );
6390:             return;
6391:         };
6392:         let result = analysis(&src, "tcl9.0");
6393:         assert!(
6394:             result.all_classes.contains_key("::clay::class"),
6395:             "the exact tcllib 2.0 corpus must record ::clay::class; got {:?}",
6396:             result.all_classes.keys().collect::<Vec<_>>()
6397:         );
6398:         assert_eq!(
6399:             result
6400:                 .all_classes
6401:                 .get("::clay::dialect::MotherOfAllMetaClasses")
6402:                 .map(|class| class.superclasses.as_slice()),
6403:             Some(&["::oo::class".to_owned()][..]),
6404:             "the literally-written dialect root must keep its superclass"
6405:         );
6406:         assert!(
6407:             result
6408:                 .class_factories()
6409:                 .contains_key("::clay::dialect::MotherOfAllMetaClasses"),
6410:             "the literally-written dialect root must publish its factory; factories={:?}",
6411:             result.class_factories().keys().collect::<Vec<_>>()
6412:         );
6413:     }
6414: 
6415:     #[test]
6416:     fn the_unresolvable_record_is_retracted_once_a_real_name_is_proved() {
6417:         // FP guard — a class literally named `::T::${ns}::class`
6418:         // exists in no interpreter, so once the real name is proved the
6419:         // phantom must not remain beside it in the class index.
6420:         let result = analysis(COMPUTED_METACLASS, "tcl9.0");
6421:         assert!(
6422:             !result.all_classes.contains_key("::T::${ns}::class"),
6423:             "the unresolved placeholder must be retracted; got {:?}",
6424:             result.all_classes.keys().collect::<Vec<_>>()
6425:         );
6426:     }
6427: 
6428:     #[test]
6429:     fn a_later_define_stub_does_not_cost_the_metaclass_its_factory() {
6430:         // TP — an `oo::define` on the computed-name class creates a
6431:         // stub whose `metaclass` was never written, so it holds
6432:         // `ClassDef::default()`'s `"oo::class"`. That default is not an
6433:         // observation: joining it against the proved `::T::Mother` must not
6434:         // read as two walks disagreeing — treating it that way would
6435:         // abstain the record down to `factory: None` with no superclasses.
6436:         let src =
6437:             format!("{COMPUTED_METACLASS}::oo::define ::T::D::class {{ method m {{}} {{}} }}\n");
6438:         let result = analysis(&src, "tcl9.0");
6439:         let class = result
6440:             .all_classes
6441:             .get("::T::D::class")
6442:             .expect("the resolved metaclass must still be recorded");
6443:         assert_eq!(
6444:             class.superclasses.as_slice(),
6445:             &["::T::Mother".to_owned()][..],
6446:             "the proved superclass must survive the stub join"
6447:         );
6448:         assert!(
6449:             result.class_factories().contains_key("::T::D::class"),
6450:             "the resolved metaclass must keep its factory; factories={:?}",
6451:             result.class_factories().keys().collect::<Vec<_>>()
6452:         );
6453:         assert!(
6454:             class.metaclass.ends_with("T::Mother"),
6455:             "the joined record must name the metaclass the source wrote, \
6456:              not the default stand-in; got {:?}",
6457:             class.metaclass
6458:         );
6459:         assert!(
6460:             class.methods.contains_key("m"),
6461:             "the stub's own member must still land; methods={:?}",
6462:             class.methods.keys().collect::<Vec<_>>()
6463:         );
6464:         assert!(
6465:             !class.via_define,
6466:             "the class is created in this file, so it is not an extension stub"
6467:         );
6468:     }
6469: 
6470:     #[test]
6471:     fn a_define_stub_replaces_a_member_the_creation_body_also_declared() {
6472:         // The two records the join unions are ordered whenever one
6473:         // of them is an `oo::define`: the class has to exist before it can
6474:         // be extended, so the stub ran second and its `method m` replaces.
6475:         // tclsh 8.6.16 on the same shape answers `{a b} …` for
6476:         // `info class definition ::T::D::class m`.
6477:         let src = format!(
6478:             "{}::oo::define ::T::D::class {{ method m {{a b}} {{}} }}\n",
6479:             COMPUTED_METACLASS.replace(
6480:                 "    ::T::Mother create ${NSPACE}::class { superclass ::T::Mother }\n",
6481:                 "    ::T::Mother create ${NSPACE}::class {\n\
6482:                  \x20       superclass ::T::Mother\n\
6483:                  \x20       method m {a} {}\n\
6484:                  \x20   }\n",
6485:             )
6486:         );
6487:         let result = analysis(&src, "tcl9.0");
6488:         let method = result
6489:             .all_classes
6490:             .get("::T::D::class")
6491:             .and_then(|class| class.methods.get("m"))
6492:             .expect("the contested member is recorded once");
6493:         assert_eq!(
6494:             method.params.len(),
6495:             2,
6496:             "the `oo::define` body's declaration is the live one; got {:?}",
6497:             method.params
6498:         );
6499:     }
6500: 
6501:     #[test]
6502:     fn two_creations_naming_one_class_under_different_metaclasses_abstain() {
6503:         // FP guard at the source level: the gate added there must
6504:         // stay a statement about *unobserved* metaclasses only. Both of
6505:         // these creations read a head word, and they disagree, so the
6506:         // record must still abstain — no factory, inheritance unknown —
6507:         // exactly as it did before the gate existed. Without this, dropping
6508:         // the `metaclass_provenance: Observed` at the creation site is invisible.
6509:         let src = concat!(
6510:             "namespace eval ::T {}\n",
6511:             "oo::class create ::T::MotherA { superclass oo::class }\n",
6512:             "oo::class create ::T::MotherB { superclass oo::class }\n",
6513:             "::T::MotherA create ::T::D::class { method m {} {} }\n",
6514:             "proc ::T::mk {name} {\n",
6515:             "    ::T::MotherB create ${name}::class { method m {} {} }\n",
6516:             "}\n",
6517:             "::T::mk ::T::D\n",
6518:         );
6519:         let result = analysis(src, "tcl9.0");
6520:         let class = result
6521:             .all_classes
6522:             .get("::T::D::class")
6523:             .expect("the contested class is still recorded");
6524:         assert!(
6525:             class.superclasses.is_empty()
6526:                 && class.metaclass_provenance == MetaclassProvenance::Observed,
6527:             "both bodies declare no superclass, so the metaclass is the only \
6528:              thing this pair disagrees about"
6529:         );
6530:         assert!(
6531:             class.inheritance_unknown,
6532:             "two observed, disagreeing metaclasses must abstain the record"
6533:         );
6534:         assert!(
6535:             class.factory.is_none(),
6536:             "an abstaining record must publish no factory"
6537:         );
6538:     }
6539: 
6540:     #[test]
6541:     fn a_define_stub_that_wins_the_join_still_sheds_its_stub_provenance() {
6542:         // The mirror of the case above: the stub declares the
6543:         // superclass and the creation body does not, so the *stub* is the
6544:         // more complete observation and wins the join. It is still not a
6545:         // cross-file extension record — this file creates the class — and
6546:         // the creation observation's own facts must survive underneath it.
6547:         let src = format!(
6548:             "{}::oo::define ::T::D::class {{ superclass ::T::Mother }}\n",
6549:             COMPUTED_METACLASS.replace(
6550:                 "    ::T::Mother create ${NSPACE}::class { superclass ::T::Mother }\n",
6551:                 "    ::T::Mother create ${NSPACE}::class { method m {} {} }\n",
6552:             )
6553:         );
6554:         let result = analysis(&src, "tcl9.0");
6555:         let class = result
6556:             .all_classes
6557:             .get("::T::D::class")
6558:             .expect("the resolved metaclass must still be recorded");
6559:         assert_eq!(
6560:             class.superclasses.as_slice(),
6561:             &["::T::Mother".to_owned()][..],
6562:             "the stub's superclass must survive"
6563:         );
6564:         assert!(
6565:             class.methods.contains_key("m"),
6566:             "the creation body's member must survive the stub winning; methods={:?}",
6567:             class.methods.keys().collect::<Vec<_>>()
6568:         );
6569:         assert!(
6570:             class.metaclass.ends_with("T::Mother")
6571:                 && class.metaclass_provenance == MetaclassProvenance::Observed,
6572:             "the winning stub never read a metaclass, so it must adopt the \
6573:              one the creation observed; got {:?}",
6574:             class.metaclass
6575:         );
6576:         assert!(
6577:             !class.via_define,
6578:             "a record one of whose observations is the creation is not a stub"
6579:         );
6580:     }
6581: 
6582:     #[test]
6583:     fn each_literal_call_site_proves_its_own_metaclass() {
6584:         // TP — two call sites, two literals, two real metaclasses.
6585:         // This is the clay / practcl shape: one `oo::dialect::create` proc
6586:         // manufacturing a per-dialect metaclass for each caller.
6587:         let src = concat!(
6588:             "namespace eval ::T {}\n",
6589:             "oo::class create ::T::Mother { superclass oo::class }\n",
6590:             "proc ::T::mkdialect {ns} {\n",
6591:             "    ::T::Mother create ${ns}::class { superclass ::T::Mother }\n",
6592:             "}\n",
6593:             "::T::mkdialect ::T::D\n",
6594:             "::T::mkdialect ::T::E\n",
6595:         );
6596:         let result = analysis(src, "tcl9.0");
6597:         for want in ["::T::D::class", "::T::E::class"] {
6598:             assert!(
6599:                 result.all_classes.contains_key(want),
6600:                 "expected {want}; got {:?}",
6601:                 result.all_classes.keys().collect::<Vec<_>>()
6602:             );
6603:         }
6604:     }
6605: 
6606:     #[test]
6607:     fn computed_creation_materialises_only_the_selected_if_arm() {
6608:         let source = |enabled: &str| {
6609:             format!(
6610:                 "namespace eval ::T {{}}\n\
6611:                  oo::class create ::T::Mother {{ superclass oo::class }}\n\
6612:                  proc ::T::mk {{name enabled}} {{\n\
6613:                      if {{$enabled}} {{ ::T::Mother create ${{name}}::class {{}} }}\n\
6614:                  }}\n\
6615:                  ::T::mk ::T::D {enabled}\n"
6616:             )
6617:         };
6618:         assert!(
6619:             analysis(&source("1"), "tcl9.0")
6620:                 .all_classes
6621:                 .contains_key("::T::D::class")
6622:         );
6623:         assert!(
6624:             !analysis(&source("0"), "tcl9.0")
6625:                 .all_classes
6626:                 .contains_key("::T::D::class")
6627:         );
6628:         assert!(
6629:             !analysis(&source("$runtime"), "tcl9.0")
6630:                 .all_classes
6631:                 .contains_key("::T::D::class")
6632:         );
6633:     }
6634: 
6635:     #[test]
6636:     fn computed_creation_requires_the_load_time_call_path_to_execute() {
6637:         let source = |condition: &str| {
6638:             format!(
6639:                 "namespace eval ::T {{}}\n\
6640:                  oo::class create ::T::Mother {{ superclass oo::class }}\n\
6641:                  proc ::T::mk {{name}} {{\n\
6642:                      ::T::Mother create ${{name}}::class {{}}\n\
6643:                  }}\n\
6644:                  if {{{condition}}} {{ ::T::mk ::T::Ghost }}\n"
6645:             )
6646:         };
6647:         assert!(
6648:             !analysis(&source("0"), "tcl9.0")
6649:                 .all_classes
6650:                 .contains_key("::T::Ghost::class")
6651:         );
6652:         assert!(
6653:             analysis(&source("1"), "tcl9.0")
6654:                 .all_classes
6655:                 .contains_key("::T::Ghost::class")
6656:         );
6657:         assert!(
6658:             !analysis(&source("$runtime"), "tcl9.0")
6659:                 .all_classes
6660:                 .contains_key("::T::Ghost::class")
6661:         );
6662:     }
6663: 
6664:     #[test]
6665:     fn load_time_call_requires_every_dominating_prefix_to_fall_through() {
6666:         let base = concat!(
6667:             "namespace eval ::T {}\n",
6668:             "oo::class create ::T::Mother { superclass oo::class }\n",
6669:             "proc ::T::mk {name} { ::T::Mother create ${name}::class {} }\n",
6670:         );
6671:         let top = format!("{base}error stopped\n::T::mk ::T::TopGhost\n");
6672:         assert!(
6673:             !analysis(&top, "tcl9.0")
6674:                 .all_classes
6675:                 .contains_key("::T::TopGhost::class")
6676:         );
6677: 
6678:         let arm = format!("{base}if {{1}} {{\n  error stopped\n  ::T::mk ::T::ArmGhost\n}}\n");
6679:         assert!(
6680:             !analysis(&arm, "tcl9.0")
6681:                 .all_classes
6682:                 .contains_key("::T::ArmGhost::class")
6683:         );
6684: 
6685:         let live = format!("{base}if {{1}} {{ set x ok; ::T::mk ::T::Live }}\n");
6686:         assert!(
6687:             analysis(&live, "tcl9.0")
6688:                 .all_classes
6689:                 .contains_key("::T::Live::class")
6690:         );
6691: 
6692:         let proc_error = format!(
6693:             "{base}proc ::T::stop {{}} {{ error stopped }}\n::T::stop\n::T::mk ::T::ProcGhost\n"
6694:         );
6695:         assert!(
6696:             !analysis(&proc_error, "tcl9.0")
6697:                 .all_classes
6698:                 .contains_key("::T::ProcGhost::class"),
6699:             "a prior user procedure with non-normal completion blocks the later call"
6700:         );
6701:     }
6702: 
6703:     #[test]
6704:     fn load_time_call_requires_nested_control_to_reach_its_end() {
6705:         let base = concat!(
6706:             "namespace eval ::T {}\n",
6707:             "oo::class create ::T::Mother { superclass oo::class }\n",
6708:             "proc ::T::mk {name} { ::T::Mother create ${name}::class {} }\n",
6709:         );
6710:         for prefix in [
6711:             "if {1} { error stopped }",
6712:             "switch yes { yes { error stopped } }",
6713:             "try {} finally { error stopped }",
6714:             "while {0} {}",
6715:             "notARegisteredCommand",
6716:         ] {
6717:             let src = format!("{base}{prefix}\n::T::mk ::T::Ghost\n");
6718:             assert!(
6719:                 !analysis(&src, "tcl9.0")
6720:                     .all_classes
6721:                     .contains_key("::T::Ghost::class"),
6722:                 "prefix must abstain: {prefix}"
6723:             );
6724:         }
6725: 
6726:         let live = format!("{base}if {{0}} {{ error stopped }}\n::T::mk ::T::Live\n");
6727:         assert!(
6728:             analysis(&live, "tcl9.0")
6729:                 .all_classes
6730:                 .contains_key("::T::Live::class")
6731:         );
6732:     }
6733: 
6734:     #[test]
6735:     fn malformed_and_handler_dependent_prefixes_do_not_publish_factories() {
6736:         let base = concat!(
6737:             "namespace eval ::T {}\n",
6738:             "oo::class create ::T::Mother { superclass oo::class }\n",
6739:             "proc ::T::mk {name} { ::T::Mother create ${name}::class {} }\n",
6740:         );
6741:         for prefix in [
6742:             "set",
6743:             "if {1}",
6744:             "if {1} then",
6745:             "if {0} {} else \"error stopped\"",
6746:             "switch yes { yes \"error stopped\" }",
6747:             "try {} finally \"error stopped\"",
6748:             "try {} on ok {} { error stopped }",
6749:         ] {
6750:             let src = format!("{base}{prefix}\n::T::mk ::T::Ghost\n");
6751:             assert!(
6752:                 !analysis(&src, "tcl9.0")
6753:                     .all_classes
6754:                     .contains_key("::T::Ghost::class"),
6755:                 "prefix must abstain: {prefix}"
6756:             );
6757:         }
6758:     }
6759: 
6760:     #[test]
6761:     fn load_time_switch_and_try_paths_select_only_executed_factory_calls() {
6762:         let src = concat!(
6763:             "namespace eval ::T {}\n",
6764:             "oo::class create ::T::Mother { superclass oo::class }\n",
6765:             "proc ::T::mk {name} { ::T::Mother create ${name}::class {} }\n",
6766:             "switch no {\n",
6767:             "    yes { ::T::mk ::T::SwitchGhost }\n",
6768:             "    default { ::T::mk ::T::SwitchReal }\n",
6769:             "}\n",
6770:             "try {} on error {message options} {\n",
6771:             "    ::T::mk ::T::HandlerGhost\n",
6772:             "} finally {\n",
6773:             "    ::T::mk ::T::FinallyReal\n",
6774:             "}\n",
6775:         );
6776:         let result = analysis(src, "tcl9.0");
6777:         assert!(result.all_classes.contains_key("::T::SwitchReal::class"));
6778:         assert!(result.all_classes.contains_key("::T::FinallyReal::class"));
6779:         assert!(!result.all_classes.contains_key("::T::SwitchGhost::class"));
6780:         assert!(!result.all_classes.contains_key("::T::HandlerGhost::class"));
6781:     }
6782: 
6783:     #[test]
6784:     fn computed_creation_after_a_non_normal_completion_is_unreachable() {
6785:         for terminator in [
6786:             "error stopped",
6787:             "throw {TEST STOP} stopped",
6788:             "break",
6789:             "continue",
6790:         ] {
6791:             let src = format!(
6792:                 "namespace eval ::T {{}}\n\
6793:                  oo::class create ::T::Mother {{ superclass oo::class }}\n\
6794:                  proc ::T::mk {{name}} {{\n\
6795:                      {terminator}\n\
6796:                      ::T::Mother create ${{name}}::class {{}}\n\
6797:                  }}\n\
6798:                  ::T::mk ::T::Ghost\n"
6799:             );
6800:             assert!(
6801:                 !analysis(&src, "tcl9.0")
6802:                     .all_classes
6803:                     .contains_key("::T::Ghost::class"),
6804:                 "{terminator} must stop provenance"
6805:             );
6806:         }
6807:     }
6808: 
6809:     #[test]
6810:     fn computed_creation_materialises_only_the_selected_switch_arm() {
6811:         let source = |selector: &str| {
6812:             format!(
6813:                 "namespace eval ::T {{}}\n\
6814:                  oo::class create ::T::Mother {{ superclass oo::class }}\n\
6815:                  proc ::T::mk {{name selector}} {{\n\
6816:                      switch $selector {{\n\
6817:                          yes {{ ::T::Mother create ${{name}}::class {{}} }}\n\
6818:                          default {{ set unrelated no }}\n\
6819:                      }}\n\
6820:                  }}\n\
6821:                  ::T::mk ::T::D {selector}\n"
6822:             )
6823:         };
6824:         assert!(
6825:             analysis(&source("yes"), "tcl9.0")
6826:                 .all_classes
6827:                 .contains_key("::T::D::class")
6828:         );
6829:         assert!(
6830:             !analysis(&source("no"), "tcl9.0")
6831:                 .all_classes
6832:                 .contains_key("::T::D::class")
6833:         );
6834:         assert!(
6835:             !analysis(&source("$runtime"), "tcl9.0")
6836:                 .all_classes
6837:                 .contains_key("::T::D::class")
6838:         );
6839:     }
6840: 
6841:     #[test]
6842:     fn computed_creation_switch_supports_registry_modes_and_fallthrough() {
6843:         let src = concat!(
6844:             "namespace eval ::T {}\n",
6845:             "oo::class create ::T::Mother { superclass oo::class }\n",
6846:             "proc ::T::mk {name selector} {\n",
6847:             "    switch -glob -- $selector {\n",
6848:             "        D* -\n",
6849:             "        fallback { ::T::Mother create ${name}::class {} }\n",
6850:             "        default {}\n",
6851:             "    }\n",
6852:             "}\n",
6853:             "::T::mk ::T::D Dialect\n",
6854:         );
6855:         assert!(
6856:             analysis(src, "tcl9.0")
6857:                 .all_classes
6858:                 .contains_key("::T::D::class")
6859:         );
6860: 
6861:         let exact = src.replace("switch -glob", "switch -exact");
6862:         assert!(
6863:             !analysis(&exact, "tcl9.0")
6864:                 .all_classes
6865:                 .contains_key("::T::D::class")
6866:         );
6867: 
6868:         let nocase = src
6869:             .replace("switch -glob", "switch -glob -nocase")
6870:             .replace("::T::mk ::T::D Dialect", "::T::mk ::T::D dialect");
6871:         assert!(
6872:             analysis(&nocase, "tcl9.0")
6873:                 .all_classes
6874:                 .contains_key("::T::D::class")
6875:         );
6876: 
6877:         // `D*` as a regular expression matches `Dialect` (zero or more `D`
6878:         // from the start), so the regexp selection falls through into the
6879:         // creating body; tclsh 9.0 makes the class.
6880:         let regexp = src.replace("switch -glob", "switch -regexp");
6881:         assert!(
6882:             analysis(&regexp, "tcl9.0")
6883:                 .all_classes
6884:                 .contains_key("::T::D::class"),
6885:             "the regexp selection reaches the creating body"
6886:         );
6887:         // A pattern the regexp engine rejects is a selection nothing makes.
6888:         let malformed = src
6889:             .replace("switch -glob", "switch -regexp")
6890:             .replace("D* -", "{(} -");
6891:         assert!(
6892:             !analysis(&malformed, "tcl9.0")
6893:                 .all_classes
6894:                 .contains_key("::T::D::class"),
6895:             "a malformed pattern must abstain"
6896:         );
6897:     }
6898: 
6899:     /// A quoted `-` body of the separate-words form reads two ways on 9.1b0
6900:     /// (its byte-compiled `switch` runs it as a command), so the selection
6901:     /// declines there and the class is not made; 9.0 reads it by value and
6902:     /// falls through into the creating body, and the bare spelling reads
6903:     /// alike everywhere.
6904:     #[test]
6905:     fn computed_creation_declines_a_delimited_fallthrough_body_on_91() {
6906:         let src = concat!(
6907:             "namespace eval ::T {}\n",
6908:             "oo::class create ::T::Mother { superclass oo::class }\n",
6909:             "proc ::T::mk {name selector} {\n",
6910:             "    switch -glob -- $selector D* \"-\" fallback {\n",
6911:             "        ::T::Mother create ${name}::class {}\n",
6912:             "    } default {}\n",
6913:             "}\n",
6914:             "::T::mk ::T::D Dialect\n",
6915:         );
6916:         let made = |source: &str, dialect: &str| {
6917:             analysis(source, dialect)
6918:                 .all_classes
6919:                 .contains_key("::T::D::class")
6920:         };
6921:         assert!(made(src, "tcl9.0"));
6922:         assert!(!made(src, "tcl9.1"));
6923:         let bare = src.replace("\"-\"", "-");
6924:         assert!(made(&bare, "tcl9.0"));
6925:         assert!(made(&bare, "tcl9.1"));
6926:     }
6927: 
6928:     #[test]
6929:     fn switch_default_is_special_only_in_the_final_clause() {
6930:         let src = concat!(
6931:             "namespace eval ::T {}\n",
6932:             "oo::class create ::T::Mother { superclass oo::class }\n",
6933:             "proc ::T::mk {name selector} {\n",
6934:             "    switch $selector {\n",
6935:             "        default { ::T::Mother create ${name}::class {} }\n",
6936:             "        yes {}\n",
6937:             "    }\n",
6938:             "}\n",
6939:             "::T::mk ::T::Ghost no\n",
6940:         );
6941:         assert!(
6942:             !analysis(src, "tcl9.0")
6943:                 .all_classes
6944:                 .contains_key("::T::Ghost::class")
6945:         );
6946:     }
6947: 
6948:     #[test]
6949:     fn switch_with_an_orphan_braced_clause_never_materialises_a_class() {
6950:         let src = concat!(
6951:             "namespace eval ::T {}\n",
6952:             "oo::class create ::T::Mother { superclass oo::class }\n",
6953:             "proc ::T::mk {name selector} {\n",
6954:             "    switch $selector {\n",
6955:             "        yes { ::T::Mother create ${name}::class {} }\n",
6956:             "        orphan\n",
6957:             "    }\n",
6958:             "}\n",
6959:             "::T::mk ::T::Ghost yes\n",
6960:         );
6961:         assert!(
6962:             !analysis(src, "tcl9.0")
6963:                 .all_classes
6964:                 .contains_key("::T::Ghost::class")
6965:         );
6966:     }
6967: 
6968:     #[test]
6969:     fn switch_with_a_final_fallthrough_body_never_materialises_a_class() {
6970:         let src = concat!(
6971:             "namespace eval ::T {}\n",
6972:             "oo::class create ::T::Mother { superclass oo::class }\n",
6973:             "proc ::T::mk {name selector} {\n",
6974:             "    switch $selector {\n",
6975:             "        yes { ::T::Mother create ${name}::class {} }\n",
6976:             "        default -\n",
6977:             "    }\n",
6978:             "}\n",
6979:             "::T::mk ::T::Ghost yes\n",
6980:         );
6981:         assert!(
6982:             !analysis(src, "tcl9.0")
6983:                 .all_classes
6984:                 .contains_key("::T::Ghost::class")
6985:         );
6986:     }
6987: 
6988:     #[test]
6989:     fn computed_creation_reuses_nested_prefix_reachability() {
6990:         let src = concat!(
6991:             "namespace eval ::T {}\n",
6992:             "oo::class create ::T::Mother { superclass oo::class }\n",
6993:             "proc ::T::mk {name} {\n",
6994:             "    if {1} { error stopped }\n",
6995:             "    ::T::Mother create ${name}::class {}\n",
6996:             "}\n",
6997:             "::T::mk ::T::Ghost\n",
6998:         );
6999:         assert!(
7000:             !analysis(src, "tcl9.0")
7001:                 .all_classes
7002:                 .contains_key("::T::Ghost::class")
7003:         );
7004:     }
7005: 
7006:     #[test]
7007:     fn helper_proc_branch_result_drives_computed_creation() {
7008:         let src = concat!(
7009:             "namespace eval ::T {}\n",
7010:             "oo::class create ::T::Mother { superclass oo::class }\n",
7011:             "proc ::T::choose {enabled yes no} {\n",
7012:             "    if {$enabled} { return $yes } else { return $no }\n",
7013:             "}\n",
7014:             "proc ::T::mk {name} {\n",
7015:             "    set selected [::T::choose 1 $name ::T::Wrong]\n",
7016:             "    ::T::Mother create ${selected}::class {}\n",
7017:             "}\n",
7018:             "::T::mk ::T::Right\n",
7019:         );
7020:         let result = analysis(src, "tcl9.0");
7021:         assert!(result.all_classes.contains_key("::T::Right::class"));
7022:         assert!(!result.all_classes.contains_key("::T::Wrong::class"));
7023:     }
7024: 
7025:     #[test]
7026:     fn malformed_helper_branch_cannot_fabricate_a_computed_creation_name() {
7027:         let src = concat!(
7028:             "namespace eval ::T {}\n",
7029:             "oo::class create ::T::Mother { superclass oo::class }\n",
7030:             "proc ::T::choose {name} {\n",
7031:             "    if {1} then\n",
7032:             "    return $name\n",
7033:             "}\n",
7034:             "proc ::T::mk {name} {\n",
7035:             "    set selected [::T::choose $name]\n",
7036:             "    ::T::Mother create ${selected}::class {}\n",
7037:             "}\n",
7038:             "::T::mk ::T::Ghost\n",
7039:         );
7040:         assert!(
7041:             !analysis(src, "tcl9.0")
7042:                 .all_classes
7043:                 .contains_key("::T::Ghost::class")
7044:         );
7045:     }
7046: 
7047:     #[test]
7048:     fn deep_helper_call_chain_cannot_exhaust_the_provenance_budget() {
7049:         use std::fmt::Write as _;
7050: 
7051:         let mut src = concat!(
7052:             "namespace eval ::T {}\n",
7053:             "oo::class create ::T::Mother { superclass oo::class }\n",
7054:         )
7055:         .to_owned();
7056:         for index in 0..10 {
7057:             let next = index + 1;
7058:             let _ = writeln!(
7059:                 src,
7060:                 "proc ::T::step{index} {{name}} {{ return [::T::step{next} $name] }}"
7061:             );
7062:         }
7063:         src.push_str("proc ::T::step10 {name} { return $name }\n");
7064:         src.push_str(concat!(
7065:             "proc ::T::mk {name} {\n",
7066:             "    set selected [::T::step0 $name]\n",
7067:             "    ::T::Mother create ${selected}::class {}\n",
7068:             "}\n",
7069:             "::T::mk ::T::Ghost\n",
7070:         ));
7071: 
7072:         assert!(
7073:             !analysis(&src, "tcl9.0")
7074:                 .all_classes
7075:                 .contains_key("::T::Ghost::class"),
7076:             "a helper chain beyond the bounded proof budget must abstain"
7077:         );
7078:     }
7079: 
7080:     #[test]
7081:     fn computed_creation_in_try_finally_is_selected_but_handler_abstains() {
7082:         let finally_src = concat!(
7083:             "namespace eval ::T {}\n",
7084:             "oo::class create ::T::Mother { superclass oo::class }\n",
7085:             "proc ::T::mk {name} {\n",
7086:             "    try {} finally { ::T::Mother create ${name}::class {} }\n",
7087:             "}\n",
7088:             "::T::mk ::T::D\n",
7089:         );
7090:         assert!(
7091:             analysis(finally_src, "tcl9.0")
7092:                 .all_classes
7093:                 .contains_key("::T::D::class")
7094:         );
7095: 
7096:         let handler_src = concat!(
7097:             "namespace eval ::T {}\n",
7098:             "oo::class create ::T::Mother { superclass oo::class }\n",
7099:             "proc ::T::mk {name} {\n",
7100:             "    try {} on error {message options} {\n",
7101:             "        ::T::Mother create ${name}::class {}\n",
7102:             "    }\n",
7103:             "}\n",
7104:             "::T::mk ::T::D\n",
7105:         );
7106:         assert!(
7107:             !analysis(handler_src, "tcl9.0")
7108:                 .all_classes
7109:                 .contains_key("::T::D::class")
7110:         );
7111:     }
7112: 
7113:     #[test]
7114:     fn computed_creation_does_not_carry_proc_locals_across_namespace_eval() {
7115:         let src = concat!(
7116:             "namespace eval ::T {}\n",
7117:             "oo::class create ::T::Mother { superclass oo::class }\n",
7118:             "proc ::T::mk {name} {\n",
7119:             "    namespace eval ::Other {\n",
7120:             "        ::T::Mother create ${name}::class {}\n",
7121:             "    }\n",
7122:             "}\n",
7123:             "::T::mk ::T::Ghost\n",
7124:         );
7125:         assert!(
7126:             !analysis(src, "tcl9.0")
7127:                 .all_classes
7128:                 .contains_key("::T::Ghost::class")
7129:         );
7130:     }
7131: 
7132:     #[test]
7133:     fn computed_creation_uses_default_proc_formals() {
7134:         let src = concat!(
7135:             "namespace eval ::T {}\n",
7136:             "oo::class create ::T::Mother { superclass oo::class }\n",
7137:             "proc ::T::mk {{name ::T::D}} {\n",
7138:             "    ::T::Mother create ${name}::class {}\n",
7139:             "}\n",
7140:             "::T::mk\n",
7141:         );
7142:         assert!(
7143:             analysis(src, "tcl9.0")
7144:                 .all_classes
7145:                 .contains_key("::T::D::class")
7146:         );
7147:     }
7148: 
7149:     #[test]
7150:     fn a_renamed_namespace_normaliser_abstains() {
7151:         // TN/rename guard — registry-derived command-table trust, not
7152:         // textual resemblance, controls the helper call. Once its binding is
7153:         // moved, the evaluator must not run the old body under the new name.
7154:         let src = COMPUTED_METACLASS.replace(
7155:             "::T::mkdialect ::T::D\n",
7156:             "rename ::T::NSNormalize ::T::MovedNormalize\n::T::mkdialect ::T::D\n",
7157:         );
7158:         assert!(
7159:             !analysis(&src, "tcl9.0")
7160:                 .all_classes
7161:                 .contains_key("::T::D::class"),
7162:             "a renamed helper cannot prove the computed metaclass"
7163:         );
7164:     }
7165: 
7166:     #[test]
7167:     fn a_wildcard_compatible_later_rename_abstains() {
7168:         // FP guard: a fully dynamic target is compatible with every command
7169:         // identity. The trust scan is deliberately flow-insensitive, so a
7170:         // later mutation blocks the proof too.
7171:         let src = COMPUTED_METACLASS.replace(
7172:             "::T::mkdialect ::T::D\n",
7173:             "::T::mkdialect ::T::D\nrename $victim ::T::Moved\n",
7174:         );
7175:         assert!(
7176:             !analysis(&src, "tcl9.0")
7177:                 .all_classes
7178:                 .contains_key("::T::D::class"),
7179:             "a compatible later rename must block provenance"
7180:         );
7181:     }
7182: 
7183:     #[test]
7184:     fn an_aliased_namespace_normaliser_abstains() {
7185:         // TN/alias guard — an alias can replace the helper's result
7186:         // relation, so registry/user-proc provenance must decline it.
7187:         let src = COMPUTED_METACLASS
7188:             .replace(
7189:                 "set NSPACE [NSNormalize [uplevel 1 {namespace current}] $name]",
7190:                 "set NSPACE [AliasNormalize [uplevel 1 {namespace current}] $name]",
7191:             )
7192:             .replace(
7193:                 "::T::mkdialect ::T::D\n",
7194:                 concat!(
7195:                     "interp alias {} ::T::AliasNormalize {} ::T::NSNormalize\n",
7196:                     "::T::mkdialect ::T::D\n",
7197:                 ),
7198:             );
7199:         assert!(
7200:             !analysis(&src, "tcl9.0")
7201:                 .all_classes
7202:                 .contains_key("::T::D::class"),
7203:             "an aliased helper cannot inherit the original proc's provenance"
7204:         );
7205:     }
7206: 
7207:     #[test]
7208:     fn a_wildcard_compatible_earlier_alias_abstains() {
7209:         // FP guard: `$victim` could bind the normaliser or either folded
7210:         // builtin, so the proof must not depend on its runtime value.
7211:         let src = COMPUTED_METACLASS.replace(
7212:             "::T::mkdialect ::T::D\n",
7213:             "interp alias {} $victim {} puts\n::T::mkdialect ::T::D\n",
7214:         );
7215:         assert!(
7216:             !analysis(&src, "tcl9.0")
7217:                 .all_classes
7218:                 .contains_key("::T::D::class"),
7219:             "a compatible dynamic alias name must block provenance"
7220:         );
7221:     }
7222: 
7223:     #[test]
7224:     fn an_unknown_namespace_normaliser_abstains() {
7225:         // TN/unknown guard — dependency on the literal argument alone
7226:         // is not an identity proof; an unresolved helper may return anything.
7227:         let src = concat!(
7228:             "namespace eval ::T {}\n",
7229:             "oo::class create ::T::Mother { superclass oo::class }\n",
7230:             "proc ::T::mkdialect {name} {\n",
7231:             "    set NSPACE [UnknownNormalize $name]\n",
7232:             "    ::T::Mother create ${NSPACE}::class { superclass ::T::Mother }\n",
7233:             "}\n",
7234:             "::T::mkdialect ::T::D\n",
7235:         );
7236:         assert!(
7237:             !analysis(src, "tcl9.0")
7238:                 .all_classes
7239:                 .contains_key("::T::D::class"),
7240:             "an unknown transform cannot prove an identity result"
7241:         );
7242:     }
7243: 
7244:     #[test]
7245:     fn a_dynamic_call_site_argument_proves_nothing() {
7246:         // TN — the sole call site passes a runtime value, so no name
7247:         // is knowable and the pass must record nothing. Abstention is the
7248:         // documented contract; a guess here would invent a class.
7249:         let src = concat!(
7250:             "namespace eval ::T {}\n",
7251:             "oo::class create ::T::Mother { superclass oo::class }\n",
7252:             "proc ::T::mkdialect {ns} {\n",
7253:             "    ::T::Mother create ${ns}::class { superclass ::T::Mother }\n",
7254:             "}\n",
7255:             "set target [getNamespace]\n",
7256:             "::T::mkdialect $target\n",
7257:         );
7258:         let result = analysis(src, "tcl9.0");
7259:         let recorded: Vec<&String> = result
7260:             .all_classes
7261:             .keys()
7262:             .filter(|k| k.ends_with("::class") && !k.contains("${"))
7263:             .collect();
7264:         assert!(
7265:             recorded.is_empty(),
7266:             "a dynamic call-site argument must prove no class name; got {recorded:?}"
7267:         );
7268:     }
7269: 
7270:     #[test]
7271:     fn a_call_site_inside_another_proc_body_proves_nothing() {
7272:         // TN — the call runs at *call* time, if the enclosing proc is
7273:         // ever invoked, so sourcing the file creates nothing. Same load-level
7274:         // rule the destruction filter applies.
7275:         let src = concat!(
7276:             "namespace eval ::T {}\n",
7277:             "oo::class create ::T::Mother { superclass oo::class }\n",
7278:             "proc ::T::mkdialect {ns} {\n",
7279:             "    ::T::Mother create ${ns}::class { superclass ::T::Mother }\n",
7280:             "}\n",
7281:             "proc ::T::setup {} { ::T::mkdialect ::T::D }\n",
7282:         );
7283:         assert!(
7284:             !analysis(src, "tcl9.0")
7285:                 .all_classes
7286:                 .contains_key("::T::D::class"),
7287:             "a call inside a proc body must not prove a load-time creation"
7288:         );
7289:     }
7290: 
7291:     #[test]
7292:     fn a_relative_computed_name_still_abstains() {
7293:         // TN — the resolved name has no absolute written form, so
7294:         // homing it needs the call site's namespace, which this pass does not
7295:         // model. Abstaining beats homing it into the wrong namespace.
7296:         let src = concat!(
7297:             "namespace eval ::T {}\n",
7298:             "oo::class create ::T::Mother { superclass oo::class }\n",
7299:             "proc ::T::mkdialect {ns} {\n",
7300:             "    ::T::Mother create ${ns}::class { superclass ::T::Mother }\n",
7301:             "}\n",
7302:             "::T::mkdialect Rel\n",
7303:         );
7304:         let result = analysis(src, "tcl9.0");
7305:         let recorded: Vec<&String> = result
7306:             .all_classes
7307:             .keys()
7308:             .filter(|k| k.contains("Rel"))
7309:             .collect();
7310:         assert!(
7311:             recorded.is_empty(),
7312:             "a relative resolved name must abstain; got {recorded:?}"
7313:         );
7314:     }
7315: 
7316:     #[test]
7317:     fn a_proc_nobody_calls_proves_nothing() {
7318:         // TN — no call site, no binding, nothing proved. The
7319:         // regression guard for the whole pass: a workspace whose procs are
7320:         // never called must analyse exactly as it did before.
7321:         let src = concat!(
7322:             "namespace eval ::T {}\n",
7323:             "oo::class create ::T::Mother { superclass oo::class }\n",
7324:             "proc ::T::mkdialect {ns} {\n",
7325:             "    ::T::Mother create ${ns}::class { superclass ::T::Mother }\n",
7326:             "}\n",
7327:         );
7328:         let result = analysis(src, "tcl9.0");
7329:         let recorded: Vec<&String> = result
7330:             .all_classes
7331:             .keys()
7332:             .filter(|k| !k.contains("${") && k.ends_with("::class"))
7333:             .collect();
7334:         assert!(
7335:             recorded.is_empty(),
7336:             "an uncalled proc must prove no class name; got {recorded:?}"
7337:         );
7338:     }
7339: 
7340:     #[test]
7341:     fn oo_define_over_a_dynamic_list_still_abstains() {
7342:         // TN — the element list is a runtime value, so no class name is
7343:         // knowable and the members stay on a per-call-site synthetic key
7344:         // rather than being attributed to a guess.
7345:         let src = concat!(
7346:             "oo::class create chart { method Render {} { return 1 } }\n",
7347:             "foreach cls $classes {\n",
7348:             "    oo::define $cls {\n",
7349:             "        method RenderTsb {} { return tsb }\n",
7350:             "    }\n",
7351:             "}\n",
7352:         );
7353:         let r = analysis(src, "tcl9.0");
7354:         assert!(
7355:             !r.all_classes["::chart"].methods.contains_key("RenderTsb"),
7356:             "a runtime target must not be attributed to a literal class"
7357:         );
7358:         assert!(
7359:             r.all_classes.keys().any(|k| k.contains("@dynclass@")),
7360:             "the members land on a synthetic key: {:?}",
7361:             r.all_classes.keys().collect::<Vec<_>>()
7362:         );
7363:     }
7364: 
7365:     #[test]
7366:     fn oo_define_resolves_a_dominating_constant_target() {
7367:         // TP — the narrowest form of the same fact: a target bound by a
7368:         // plain `set` that dominates the call extends the real class.
7369:         let src = concat!(
7370:             "oo::class create Widget {\n",
7371:             "    method real {} { return 1 }\n",
7372:             "}\n",
7373:             "set cls Widget\n",
7374:             "oo::define $cls method added {} { return 2 }\n",
7375:         );
7376:         let cd = class(src, "::Widget");
7377:         assert!(cd.methods.contains_key("real"), "{cd:?}");
7378:         assert!(cd.methods.contains_key("added"), "{cd:?}");
7379:     }
7380: 
7381:     #[test]
7382:     fn static_brace_expansion_splices_a_member_signature() {
7383:         // TP: `{*}` of a braced literal is spliced by the parser,
7384:         // so `method {*}{foo {} {…}}` defines a real `foo` (verified on
7385:         // tclsh 9.0.4 and 8.6.16, in both the `oo::class create` body and
7386:         // an `oo::define` body).
7387:         let src = concat!(
7388:             "oo::class create S {\n",
7389:             "    method {*}{foo {x} {return foo-$x}}\n",
7390:             "    constructor {*}{{a b} {return ctor}}\n",
7391:             "}\n",
7392:         );
7393:         let cd = class(src, "::S");
7394:         assert!(cd.methods.contains_key("foo"), "{cd:?}");
7395:         assert_eq!(cd.methods["foo"].params.len(), 1);
7396:         assert_eq!(cd.constructors.len(), 1, "{cd:?}");
7397:         assert_eq!(cd.constructors[0].params.len(), 2);
7398:     }
7399: 
7400:     #[test]
7401:     fn static_brace_expansion_splices_in_an_oo_define_body_too() {
7402:         // TP — same mechanism through the `oo::define` body form.
7403:         let src = concat!(
7404:             "oo::class create S {}\n",
7405:             "oo::define S {\n",
7406:             "    method {*}{bar {} {return bar}}\n",
7407:             "}\n",
7408:         );
7409:         assert!(class(src, "::S").methods.contains_key("bar"));
7410:     }
7411: 
7412:     #[test]
7413:     fn substituted_brace_expansion_still_abstains() {
7414:         // TN — `{*}[info class definition …]` reflects a signature whose
7415:         // words are only known at run time, so the member is left
7416:         // unrecorded rather than invented with wrong parameters or a body
7417:         // span pointing at the wrong text.
7418:         let src = concat!(
7419:             "oo::class create chart3D {\n",
7420:             "    constructor {*}[info class constructor chart]\n",
7421:             "    method options {*}[classDef chart options]\n",
7422:             "    method getType {} { return chart3D }\n",
7423:             "}\n",
7424:         );
7425:         let cd = class(src, "::chart3D");
7426:         assert!(cd.methods.contains_key("getType"), "{cd:?}");
7427:         assert!(!cd.methods.contains_key("options"), "{cd:?}");
7428:         assert!(cd.constructors.is_empty(), "{cd:?}");
7429:         // …and the abstention is *recorded*, so the tables read as a lower
7430:         // bound rather than as the class's whole surface.
7431:         assert!(cd.member_set_incomplete, "{cd:?}");
7432:     }
7433: 
7434:     #[test]
7435:     fn a_foreach_member_installer_marks_the_member_set_incomplete() {
7436:         // TP: the ticklecharts `chart3D` installer
7437:         // loop.  `foreach` is not a member word and carries a script the
7438:         // member walk never descends into, so the class must say its member
7439:         // tables are a lower bound. tclsh 9.0.4 / 8.6.16: `info class
7440:         // methods ::C3` really lists `options` and `globalOptions`.
7441:         //
7442:         // The loop's own literal list means the two
7443:         // *names* are not invisible either (see
7444:         // `a_literal_foreach_installer_records_member_names_as_signature_unknown`
7445:         // below for the full positive case) — but the set stays incomplete
7446:         // regardless, because knowing these two names is not the same as
7447:         // knowing there could never be a third from elsewhere.
7448:         let src = concat!(
7449:             "oo::class create C3 {\n",
7450:             "    foreach m {options globalOptions} {\n",
7451:             "        method $m {} { return $m }\n",
7452:             "    }\n",
7453:             "    method getType {} { return c3 }\n",
7454:             "}\n",
7455:         );
7456:         let cd = class(src, "::C3");
7457:         assert!(cd.methods.contains_key("getType"), "{cd:?}");
7458:         assert!(cd.methods.contains_key("options"), "{cd:?}");
7459:         assert!(cd.methods.contains_key("globalOptions"), "{cd:?}");
7460:         assert!(cd.member_set_incomplete, "{cd:?}");
7461:     }
7462: 
7463:     #[test]
7464:     fn a_literal_foreach_installer_records_member_names_as_signature_unknown() {
7465:         // TP: the headline case: `foreach m {alpha beta gamma} {
7466:         // method $m {args} {…} }`. tclsh 9.0.4 / 8.6.16 both agree `alpha`,
7467:         // `beta`, `gamma` are real members of any arity (`args`); the walk can read their
7468:         // *names* off the loop's own literal list even though it still
7469:         // cannot say anything honest about their signatures.
7470:         let src = concat!(
7471:             "oo::class create C3 {\n",
7472:             "    foreach m {alpha beta gamma} {\n",
7473:             "        method $m {args} { return $args }\n",
7474:             "    }\n",
7475:             "    method getType {} { return c3 }\n",
7476:             "}\n",
7477:         );
7478:         let cd = class(src, "::C3");
7479:         for name in ["alpha", "beta", "gamma"] {
7480:             let md = cd
7481:                 .methods
7482:                 .get(name)
7483:                 .unwrap_or_else(|| panic!("{name} recorded: {cd:?}"));
7484:             assert!(md.params.is_empty(), "{name}: {md:?}");
7485:             assert!(md.params_computed, "{name}: {md:?}");
7486:             // Abstains rather than validating against an invented
7487:             // parameter list (E002/E003/E005) — `arity()` reads as
7488:             // unbounded, not "zero args".
7489:             assert_eq!(
7490:                 md.arity(),
7491:                 tcl_registry::Arity::new(0, tcl_registry::Arity::UNLIMITED),
7492:                 "{name}: {md:?}"
7493:             );
7494:         }
7495:         // A directly-written literal declaration is untouched by the loop.
7496:         let getter = cd.methods.get("getType").expect("getType recorded");
7497:         assert!(!getter.params_computed, "{getter:?}");
7498:         // The lower bound still holds even though three names are now known
7499:         // (the subtle half of the acceptance criteria: knowing three names
7500:         // is not knowing them all).
7501:         assert!(cd.member_set_incomplete, "{cd:?}");
7502:     }
7503: 
7504:     #[test]
7505:     fn a_computed_foreach_member_name_still_abstains_entirely() {
7506:         // TN — the loop-installed name must be *exactly* a reference to the
7507:         // loop variable; anything else built from it (or a name that isn't
7508:         // the loop variable at all) is left exactly as opaque, matching
7509:         // the pre-existing `method $someVar …` abstention.
7510:         let src = concat!(
7511:             "oo::class create C4 {\n",
7512:             "    set prefix pre\n",
7513:             "    foreach m {alpha beta} {\n",
7514:             "        method ${prefix}_$m {args} { return $args }\n",
7515:             "    }\n",
7516:             "    method getType {} { return c4 }\n",
7517:             "}\n",
7518:         );
7519:         let cd = class(src, "::C4");
7520:         assert!(cd.methods.contains_key("getType"), "{cd:?}");
7521:         assert!(!cd.methods.contains_key("alpha"), "{cd:?}");
7522:         assert!(!cd.methods.contains_key("pre_alpha"), "{cd:?}");
7523:         assert_eq!(cd.methods.len(), 1, "{cd:?}");
7524:         assert!(cd.member_set_incomplete, "{cd:?}");
7525:     }
7526: 
7527:     #[test]
7528:     fn a_multi_pair_foreach_installer_still_abstains_entirely() {
7529:         // TN — two var/list pairs share one body; no single member `$var`
7530:         // word could unambiguously mean one pair over the other, so this is
7531:         // left exactly as opaque as any other unreadable installer.
7532:         let src = concat!(
7533:             "oo::class create C5 {\n",
7534:             "    foreach m {alpha beta} n {1 2} {\n",
7535:             "        method $m {args} { return $n }\n",
7536:             "    }\n",
7537:             "    method getType {} { return c5 }\n",
7538:             "}\n",
7539:         );
7540:         let cd = class(src, "::C5");
7541:         assert!(cd.methods.contains_key("getType"), "{cd:?}");
7542:         assert!(!cd.methods.contains_key("alpha"), "{cd:?}");
7543:         assert_eq!(cd.methods.len(), 1, "{cd:?}");
7544:         assert!(cd.member_set_incomplete, "{cd:?}");
7545:     }
7546: 
7547:     #[test]
7548:     fn an_ordinary_class_body_keeps_a_complete_member_set() {
7549:         // TN — the flag is not a blanket "TclOO is hard" switch: a class
7550:         // whose body is nothing but readable member declarations (including
7551:         // the *statically spliceable* `{*}` form and a `self` wrapper block)
7552:         // still reports a complete member set, so W308 keeps its teeth.
7553:         let src = concat!(
7554:             "oo::class create Plain {\n",
7555:             "    superclass ::oo::object\n",
7556:             "    variable a b\n",
7557:             "    constructor {x} { set a $x }\n",
7558:             "    method {*}{spliced {} {return 1}}\n",
7559:             "    self { method make {} { return made } }\n",
7560:             "    method run {} { return $a }\n",
7561:             "    destructor { return }\n",
7562:             "}\n",
7563:         );
7564:         assert!(!class(src, "::Plain").member_set_incomplete);
7565:     }
7566: 
7567:     #[test]
7568:     fn w308_abstains_on_a_class_whose_members_are_installed_reflectively() {
7569:         // TP: `$c3 options` must not draw
7570:         // "Unknown method 'options'" on a call tclsh proves succeeds.  A
7571:         // class whose member tables are a lower bound cannot support a
7572:         // missing-method claim, so W308 must abstain — while the sibling
7573:         // class in the same file, whose body *is* fully readable, keeps
7574:         // being checked (the TN half, guarding against a blanket
7575:         // suppression).
7576:         let src = concat!(
7577:             "oo::class create Donor {\n",
7578:             "    method options {} { return 1 }\n",
7579:             "}\n",
7580:             "oo::class create C3 {\n",
7581:             "    constructor {*}[info class constructor ::Donor]\n",
7582:             "    foreach m {options} { method $m {*}[info class definition ::Donor $m] }\n",
7583:             "}\n",
7584:             "set c3 [C3 new]\n",
7585:             "$c3 options\n",
7586:             "set d [Donor new]\n",
7587:             "$d nosuch\n",
7588:         );
7589:         let r = analysis(src, "tcl9.0");
7590:         let codes: Vec<&str> = r
7591:             .diagnostics
7592:             .iter()
7593:             .filter(|d| d.code.to_string() == "W308")
7594:             .map(|d| d.message.as_str())
7595:             .collect();
7596:         assert_eq!(
7597:             codes.len(),
7598:             1,
7599:             "only the readable class draws W308: {codes:?}"
7600:         );
7601:         assert!(codes[0].contains("nosuch"), "{codes:?}");
7602:     }
7603: 
7604:     /// A user metaclass whose own definition is in **another file** and whose
7605:     /// declaration the host never indexed cannot be recognised: the analyser
7606:     /// is per-file, and nothing in `X create Name Supers Body` distinguishes
7607:     /// a class factory from `interp create`, `image create`, or any ordinary
7608:     /// proc taking a script argument.  Guessing would invent classes out of
7609:     /// unrelated commands, so the LSP abstains — records no class, and emits
7610:     /// no diagnostic about the members it therefore cannot see.
7611:     ///
7612:     /// This is the **floor** the workspace factory index raises, not
7613:     /// replaces: with no index (every single-file analysis, and every host
7614:     /// that has not enumerated the project) the behaviour is unchanged.  The
7615:     /// resolving half is `a_workspace_indexed_metaclass_creates_real_classes`
7616:     /// below; Tk's own `library/iconlist.tcl` is that shape.
7617:     #[test]
7618:     fn a_metaclass_defined_in_another_file_abstains_rather_than_guessing() {
7619:         let src = concat!(
7620:             "::Megawidget create IconList FocusableWidget {\n",
7621:             "    method GetSpecs {} { return \"iconlist+[next]\" }\n",
7622:             "}\n",
7623:         );
7624:         let r = analysis(src, "tcl9.0");
7625:         assert!(
7626:             !r.all_classes.contains_key("::IconList"),
7627:             "no class may be invented from an unknown command: {:?}",
7628:             r.all_classes.keys().collect::<Vec<_>>()
7629:         );
7630:         assert!(
7631:             r.diagnostics
7632:                 .iter()
7633:                 .all(|d| d.code.to_string() != "W308" && d.code.to_string() != "W001"),
7634:             "abstention must be silent, not a wrong answer: {:?}",
7635:             r.diagnostics
7636:         );
7637:     }
7638: 
7639:     // Cross-file class factories.
7640:     //
7641:     // Ground truth, byte-identical on tclsh 8.6.14 and 9.0.4, for the
7642:     // three-file shape below (`megawidget.tcl` / `base.tcl` /
7643:     // `iconlist.tcl`, each `source`d in turn):
7644:     //
7645:     //   info object isa class ::IconList          -> 1
7646:     //   info class superclasses ::IconList        -> ::tk::MegawidgetClass ::FocusableWidget
7647:     //   info class methods ::IconList -private    -> CreateHull GetSpecs
7648:     //   info class superclasses ::FocusableWidget -> ::tk::MegawidgetClass
7649:     //   [::IconList new] CreateHull               -> iconlist-hull/hull-from-FocusableWidget
7650:     //   [::IconList new] TraceOption a b          -> traced-from-MegawidgetClass
7651:     //
7652:     // i.e. the class, its members, its spliced superclass, and the `next`
7653:     // chain through the injected base are all real — the file that writes
7654:     // `::tk::Megawidget create IconList …` just cannot see any of it on its
7655:     // own.
7656: 
7657:     /// The metaclass file of the three-file shape.
7658:     const META_FILE: &str = concat!(
7659:         "oo::class create ::tk::MegawidgetClass {\n",
7660:         "    method TraceOption {a b} { return traced-from-MegawidgetClass }\n",
7661:         "}\n",
7662:         "oo::class create ::tk::Megawidget {\n",
7663:         "    superclass oo::class\n",
7664:         "    self method create {name superclasses body} {\n",
7665:         "        next $name [list superclass ::tk::MegawidgetClass {*}$superclasses]\\;$body\n",
7666:         "    }\n",
7667:         "}\n",
7668:     );
7669: 
7670:     /// The consumer file — Tk's `library/iconlist.tcl` shape, reduced.
7671:     const CONSUMER_FILE: &str = concat!(
7672:         "::tk::Megawidget create IconList FocusableWidget {\n",
7673:         "    method GetSpecs {} { return iconlist }\n",
7674:         "    method CreateHull {} { return hull }\n",
7675:         "}\n",
7676:     );
7677: 
7678:     /// The workspace factory index `src` publishes — what a host merges and
7679:     /// hands back to a consumer document's analysis.
7680:     fn factories_of(src: &str) -> std::sync::Arc<tcl_compiler::analyser::ClassFactoryIndex> {
7681:         std::sync::Arc::new(analysis(src, "tcl9.0").class_factories())
7682:     }
7683: 
7684:     /// Analyse `src` with `index` supplied as the workspace factory oracle.
7685:     fn analysis_with_factories(
7686:         src: &str,
7687:         index: &std::sync::Arc<tcl_compiler::analyser::ClassFactoryIndex>,
7688:     ) -> AnalysisResult {
7689:         Analyser::new()
7690:             .with_workspace_class_factories(Some(std::sync::Arc::clone(index)))
7691:             .analyse(src, "tcl9.0")
7692:     }
7693: 
7694:     #[test]
7695:     fn a_metaclass_file_publishes_exactly_one_factory() {
7696:         // Non-vacuity floor for every test below: the index really carries
7697:         // `::tk::Megawidget` (and only it — `::tk::MegawidgetClass` is an
7698:         // ordinary class, not a factory), and the factory really describes
7699:         // the `{name superclasses body}` layout rather than the builtin one.
7700:         let index = factories_of(META_FILE);
7701:         assert_eq!(
7702:             index.keys().collect::<Vec<_>>(),
7703:             ["::tk::Megawidget"],
7704:             "{index:?}"
7705:         );
7706:         let spec = &index["::tk::Megawidget"].overrides["create"];
7707:         assert_eq!((spec.name_arg, spec.body_arg), (1, 3), "{spec:?}");
7708:         assert!(spec.injected.is_some(), "readable prologue: {spec:?}");
7709:     }
7710: 
7711:     #[test]
7712:     fn a_workspace_indexed_metaclass_creates_real_classes() {
7713:         // TP — the multi-file half.  The consumer file names
7714:         // `::tk::Megawidget` and nothing else about it; the index proves it
7715:         // is a factory, so the class, its members, and the superclasses the
7716:         // manufacturer splices all come out matching the tclsh oracle above.
7717:         let index = factories_of(META_FILE);
7718:         let r = analysis_with_factories(CONSUMER_FILE, &index);
7719:         let cd = r
7720:             .all_classes
7721:             .get("::IconList")
7722:             .unwrap_or_else(|| panic!("::IconList recorded: {:?}", r.all_classes.keys()));
7723:         let mut methods: Vec<&str> = cd.methods.keys().map(String::as_str).collect();
7724:         methods.sort_unstable();
7725:         assert_eq!(methods, ["CreateHull", "GetSpecs"], "{cd:?}");
7726:         assert_eq!(
7727:             cd.superclasses,
7728:             ["::tk::MegawidgetClass", "FocusableWidget"],
7729:             "{cd:?}"
7730:         );
7731:         assert!(!cd.inheritance_unknown, "{cd:?}");
7732:     }
7733: 
7734:     #[test]
7735:     fn the_cross_file_result_matches_the_same_file_result() {
7736:         // The two tiers must describe the same class: concatenating the
7737:         // metaclass file with the consumer is the same program, so the
7738:         // recorded members / superclasses / opacity flags must agree
7739:         // field-for-field.  (Spans differ — the text is at a different
7740:         // offset — so the comparison is over the modelled facts.)
7741:         let index = factories_of(META_FILE);
7742:         let cross = analysis_with_factories(CONSUMER_FILE, &index);
7743:         let same = analysis(&format!("{META_FILE}{CONSUMER_FILE}"), "tcl9.0");
7744:         let a = &cross.all_classes["::IconList"];
7745:         let b = &same.all_classes["::IconList"];
7746:         assert_eq!(a.superclasses, b.superclasses, "{a:?}\n{b:?}");
7747:         assert_eq!(a.inheritance_unknown, b.inheritance_unknown);
7748:         assert_eq!(a.member_set_incomplete, b.member_set_incomplete);
7749:         let mut ma: Vec<&str> = a.methods.keys().map(String::as_str).collect();
7750:         let mut mb: Vec<&str> = b.methods.keys().map(String::as_str).collect();
7751:         ma.sort_unstable();
7752:         mb.sort_unstable();
7753:         assert_eq!(ma, mb);
7754:     }
7755: 
7756:     #[test]
7757:     fn the_per_item_walk_agrees_with_the_whole_file_walk_cross_file() {
7758:         // The per-item (incremental) strategy defers proc / method bodies to
7759:         // an isolated second pass, and this campaign has already found two
7760:         // bugs where that path silently lost a fact the whole-file walk kept.
7761:         // A creation call at load level *and* one inside a proc body are both
7762:         // exercised, and the two strategies must produce identical results —
7763:         // asserted directly rather than assumed.
7764:         let index = factories_of(META_FILE);
7765:         let src = concat!(
7766:             "::tk::Megawidget create IconList FocusableWidget {\n",
7767:             "    method GetSpecs {} { return iconlist }\n",
7768:             "}\n",
7769:             "proc late {} {\n",
7770:             "    ::tk::Megawidget create Deferred FocusableWidget {\n",
7771:             "        method Inner {} { return inner }\n",
7772:             "    }\n",
7773:             "}\n",
7774:         );
7775:         let whole = analysis_with_factories(src, &index);
7776:         let per_item = Analyser::new()
7777:             .with_workspace_class_factories(Some(std::sync::Arc::clone(&index)))
7778:             .analyse_per_item(src, "tcl9.0");
7779:         for name in ["::IconList", "::Deferred"] {
7780:             assert!(
7781:                 whole.all_classes.contains_key(name),
7782:                 "{name} on the whole-file walk: {:?}",
7783:                 whole.all_classes.keys().collect::<Vec<_>>()
7784:             );
7785:         }
7786:         assert_eq!(
7787:             whole.all_classes, per_item.all_classes,
7788:             "per-item and whole-file class tables must be identical"
7789:         );
7790:         assert_eq!(whole.diagnostics, per_item.diagnostics);
7791:     }
7792: 
7793:     #[test]
7794:     fn a_dynamic_metaclass_name_still_abstains() {
7795:         // TN, the non-negotiable half — the command word is a runtime value,
7796:         // so *no* index can prove what it names.  The abstention is narrowed
7797:         // to provable names, never removed.
7798:         let index = factories_of(META_FILE);
7799:         let src = concat!(
7800:             "set meta ::tk::Megawidget\n",
7801:             "$meta create IconList FocusableWidget {\n",
7802:             "    method GetSpecs {} { return iconlist }\n",
7803:             "}\n",
7804:         );
7805:         let r = analysis_with_factories(src, &index);
7806:         assert!(
7807:             !r.all_classes.contains_key("::IconList"),
7808:             "a dynamic head proves nothing: {:?}",
7809:             r.all_classes.keys().collect::<Vec<_>>()
7810:         );
7811:     }
7812: 
7813:     #[test]
7814:     fn an_unindexed_metaclass_still_abstains() {
7815:         // TN — the index is populated, but with a different metaclass.  A
7816:         // name it does not carry stays exactly as unrecognised as it was
7817:         // before the index existed.
7818:         let index = factories_of(META_FILE);
7819:         let src = concat!(
7820:             "::some::OtherFactory create IconList FocusableWidget {\n",
7821:             "    method GetSpecs {} { return iconlist }\n",
7822:             "}\n",
7823:         );
7824:         let r = analysis_with_factories(src, &index);
7825:         assert!(
7826:             !r.all_classes.contains_key("::IconList"),
7827:             "{:?}",
7828:             r.all_classes.keys().collect::<Vec<_>>()
7829:         );
7830:     }
7831: 
7832:     #[test]
7833:     fn a_workspace_metaclass_is_not_reached_by_a_same_tailed_bare_name() {
7834:         // TN (cross-link guard) —
7835:         // the index holds `::tk::Megawidget`; a *global* `Megawidget create …`
7836:         // names `::Megawidget`, which real Tcl does not resolve to it.
7837:         // Matching on the tail would manufacture a class the interpreter
7838:         // never makes.
7839:         let index = factories_of(META_FILE);
7840:         let src = concat!(
7841:             "Megawidget create IconList FocusableWidget {\n",
7842:             "    method GetSpecs {} { return iconlist }\n",
7843:             "}\n",
7844:         );
7845:         let r = analysis_with_factories(src, &index);
7846:         assert!(
7847:             !r.all_classes.contains_key("::IconList"),
7848:             "{:?}",
7849:             r.all_classes.keys().collect::<Vec<_>>()
7850:         );
7851:     }
7852: 
7853:     #[test]
7854:     fn a_bare_name_inside_the_metaclass_namespace_does_resolve() {
7855:         // TP — the mirror of the guard above: inside `namespace eval ::tk`,
7856:         // a bare `Megawidget` *is* `::tk::Megawidget` by Tcl's own
7857:         // current-namespace-then-global rule, so it resolves.  Without this
7858:         // the guard could be satisfied by never resolving anything.
7859:         let index = factories_of(META_FILE);
7860:         let src = concat!(
7861:             "namespace eval ::tk {\n",
7862:             "    Megawidget create IconList FocusableWidget {\n",
7863:             "        method GetSpecs {} { return iconlist }\n",
7864:             "    }\n",
7865:             "}\n",
7866:         );
7867:         let r = analysis_with_factories(src, &index);
7868:         assert!(
7869:             r.all_classes.contains_key("::tk::IconList"),
7870:             "{:?}",
7871:             r.all_classes.keys().collect::<Vec<_>>()
7872:         );
7873:     }
7874: 
7875:     #[test]
7876:     fn a_local_metaclass_shadows_the_workspace_one() {
7877:         // TN — a class of the same qualified name written *here* is what the
7878:         // interpreter would have; the index must not override it.  The local
7879:         // `::tk::Megawidget` is an ordinary class, so its `create` makes an
7880:         // instance and no `::IconList` class may appear.
7881:         let index = factories_of(META_FILE);
7882:         let src = concat!(
7883:             "oo::class create ::tk::Megawidget {\n",
7884:             "    method notafactory {} { return 1 }\n",
7885:             "}\n",
7886:             "::tk::Megawidget create IconList FocusableWidget {\n",
7887:             "    method GetSpecs {} { return iconlist }\n",
7888:             "}\n",
7889:         );
7890:         let r = analysis_with_factories(src, &index);
7891:         assert!(
7892:             !r.all_classes.contains_key("::IconList"),
7893:             "the local definition wins: {:?}",
7894:             r.all_classes.keys().collect::<Vec<_>>()
7895:         );
7896:     }
7897: 
7898:     #[test]
7899:     fn an_unreadable_cross_file_prologue_marks_inheritance_unknown() {
7900:         // Abstention preserved across the index: the factory's own prologue
7901:         // is built from a runtime value, so it publishes `injected: None` and
7902:         // the consumer records the class with its inheritance opaque —
7903:         // exactly what the same-file path does.
7904:         let meta = concat!(
7905:             "oo::class create ::ns::Meta {\n",
7906:             "    superclass oo::class\n",
7907:             "    self method create {name extra body} {\n",
7908:             "        next $name [list superclass [pickBase $extra]]\\;$body\n",
7909:             "    }\n",
7910:             "}\n",
7911:         );
7912:         let index = factories_of(meta);
7913:         assert!(
7914:             index["::ns::Meta"].overrides["create"].injected.is_none(),
7915:             "{index:?}"
7916:         );
7917:         let src = concat!(
7918:             "::ns::Meta create Widget somewhere {\n",
7919:             "    method m {} { return 1 }\n",
7920:             "}\n",
7921:         );
7922:         let cd = analysis_with_factories(src, &index)
7923:             .all_classes
7924:             .get("::Widget")
7925:             .cloned()
7926:             .expect("::Widget recorded");
7927:         assert!(cd.inheritance_unknown, "{cd:?}");
7928:         assert!(cd.superclasses.is_empty(), "{cd:?}");
7929:         assert!(cd.methods.contains_key("m"), "{cd:?}");
7930:     }
7931: 
7932:     #[test]
7933:     fn a_cross_file_factory_keeps_method_checks_live_when_it_can() {
7934:         // FN guard — resolving cross-file must not blanket-suppress W308.
7935:         // `PlainMeta` injects nothing provably, so a method that exists
7936:         // nowhere on the manufactured class still warns.
7937:         let meta = concat!(
7938:             "oo::class create ::ns::PlainMeta {\n",
7939:             "    superclass oo::class\n",
7940:             "    self method create {name body} { next $name $body }\n",
7941:             "}\n",
7942:         );
7943:         let index = factories_of(meta);
7944:         let src = concat!(
7945:             "::ns::PlainMeta create PlainWidget {\n",
7946:             "    method own {} { return plain-own }\n",
7947:             "}\n",
7948:             "set w [PlainWidget new]\n",
7949:             "$w nosuchmethod\n",
7950:         );
7951:         let r = analysis_with_factories(src, &index);
7952:         assert!(
7953:             r.diagnostics.iter().any(|d| d.code.to_string() == "W308"),
7954:             "{:?}",
7955:             r.diagnostics
7956:                 .iter()
7957:                 .map(|d| d.code.to_string())
7958:                 .collect::<Vec<_>>()
7959:         );
7960:     }
7961: 
7962:     #[test]
7963:     fn a_braced_variable_command_head_resolves_through_its_constant() {
7964:         // TP: the head's *variable* is `ns`, not the whole token
7965:         // text `ns}::setdef` the lexer hands over for a braced composite
7966:         // word.  Reading the true source bytes makes the call resolve to
7967:         // the proc it really dispatches to (tclsh 9.0.4 / 8.6.16 both run
7968:         // `::tc::setdef`).
7969:         let src = concat!(
7970:             "namespace eval tc { proc setdef {a b} { return 1 } }\n",
7971:             "set ns tc\n",
7972:             "${ns}::setdef x y\n",
7973:         );
7974:         let resolved: Vec<String> = analysis(src, "tcl8.6")
7975:             .command_invocations
7976:             .iter()
7977:             .filter(|inv| inv.name.contains("${ns}"))
7978:             .filter_map(|inv| inv.resolved_qualified_name.clone())
7979:             .collect();
7980:         assert_eq!(resolved, ["::tc::setdef"]);
7981:     }
7982: 
7983:     #[test]
7984:     fn a_resolved_braced_variable_head_is_a_reference_not_a_rename_target() {
7985:         // FP guard — the head's span is `${ns}::setdef`, which spells only
7986:         // the tail.  Rewriting that span with a new name would splice it
7987:         // over the substitution and corrupt the source,
7988:         // so the invocation is marked `indirect`: references report it,
7989:         // rename skips it.
7990:         let src = concat!(
7991:             "namespace eval tc { proc setdef {a b} { return 1 } }\n",
7992:             "set ns tc\n",
7993:             "${ns}::setdef x y\n",
7994:         );
7995:         let r = analysis(src, "tcl8.6");
7996:         let inv = r
7997:             .command_invocations
7998:             .iter()
7999:             .find(|inv| inv.name.contains("${ns}"))
8000:             .expect("the composite head is recorded");
8001:         assert!(inv.indirect, "{inv:?}");
8002:     }
8003: 
8004:     #[test]
8005:     fn a_whole_word_variable_head_is_left_to_the_flow_sensitive_engine() {
8006:         // TN — `$cmd` is M7's shape, settled from the CFG/SSA value model
8007:         // rather than the walk's lexical map.  The walk must not
8008:         // pre-resolve it from a last-write-wins constant, or the two
8009:         // disagree about which sites are safe to rewrite.
8010:         let src = "proc target {} { return hi }\nset cmd target\n$cmd\n";
8011:         let r = analysis(src, "tcl8.6");
8012:         let inv = r
8013:             .command_invocations
8014:             .iter()
8015:             .find(|inv| inv.name == "${cmd}")
8016:             .expect("the variable head is recorded");
8017:         assert_eq!(
8018:             inv.resolved_qualified_name.as_deref(),
8019:             Some("::${cmd}"),
8020:             "the walk leaves this head unfolded for M7 to settle: {inv:?}",
8021:         );
8022:     }
8023: 
8024:     #[test]
8025:     fn a_braced_variable_command_head_abstains_on_a_branch_binding() {
8026:         // TN — a head whose variable is written differently on two
8027:         // branches has no single dominating value, so resolution must not
8028:         // pin either one.
8029:         let src = concat!(
8030:             "namespace eval a { proc go {} { return 1 } }\n",
8031:             "namespace eval b { proc go {} { return 1 } }\n",
8032:             "set ns a\n",
8033:             "if {$cond} { set ns b }\n",
8034:             "${ns}::go\n",
8035:         );
8036:         let resolved: Vec<String> = analysis(src, "tcl8.6")
8037:             .command_invocations
8038:             .iter()
8039:             .filter(|inv| inv.name.contains("${ns}"))
8040:             .filter_map(|inv| inv.resolved_qualified_name.clone())
8041:             .collect();
8042:         assert_eq!(
8043:             resolved,
8044:             ["::${ns}::go"],
8045:             "an unresolved head stays as written"
8046:         );
8047:     }
8048: 
8049:     #[test]
8050:     fn foreach_installed_procs_are_enumerated_per_literal_element() {
8051:         // The ticklecharts `etypes.tcl` ensemble shape: the
8052:         // `foreach`-literal simulation covers `proc`, so every element's
8053:         // proc is registered under its real qualified name.
8054:         let src = concat!(
8055:             "namespace eval ticklecharts {}\n",
8056:             "foreach ptype {elist elist.n elist.s} {\n",
8057:             "    proc ticklecharts::${ptype} {args} { return $args }\n",
8058:             "}\n",
8059:         );
8060:         let r = analysis(src, "tcl8.6");
8061:         for name in [
8062:             "::ticklecharts::elist",
8063:             "::ticklecharts::elist.n",
8064:             "::ticklecharts::elist.s",
8065:         ] {
8066:             assert!(
8067:                 r.all_procs.contains_key(name),
8068:                 "{name} registered: {:?}",
8069:                 r.all_procs.keys().collect::<Vec<_>>()
8070:             );
8071:         }
8072:         assert!(
8073:             !r.all_procs.keys().any(|k| k.contains('$')),
8074:             "no proc is filed under the unsubstituted template: {:?}",
8075:             r.all_procs.keys().collect::<Vec<_>>()
8076:         );
8077:     }
8078: 
8079:     // The chained factory index.
8080:     //
8081:     // The workspace index is published by the host as a *fixpoint*, because a
8082:     // metaclass manufactured by another file's metaclass is only provable once
8083:     // the manufacturing one is already in the index.  The salsa-layer loop is
8084:     // covered by `tcl-lsp-db`'s `class_factory_fixpoint` suite; what belongs
8085:     // here is the analyser half of the same fact — that a round handed the
8086:     // deeper index really does prove the next link, and that the surfaces the
8087:     // language allows around it behave.
8088:     //
8089:     // Ground truth, byte-identical on tclsh 8.6.16 and 9.0.4, for the chain
8090:     // below sourced as one script:
8091:     //
8092:     //   info object isa class ::MC::MetaB      -> 1
8093:     //   info class superclasses ::MC::MetaB    -> ::oo::class
8094:     //   info object isa class ::MC::Widget     -> 1
8095:     //   info class methods ::MC::Widget        -> go
8096:     //   [::MC::Widget new] go                  -> went
8097: 
8098:     const CHAIN_META_A: &str =
8099:         "namespace eval ::MC {}\noo::class create ::MC::MetaA { superclass oo::class }\n";
8100:     const CHAIN_META_B: &str = "::MC::MetaA create ::MC::MetaB { superclass oo::class }\n";
8101:     const CHAIN_WIDGET: &str = "::MC::MetaB create ::MC::Widget { method go {} { return went } }\n";
8102: 
8103:     #[test]
8104:     fn a_second_link_metaclass_publishes_a_factory_once_the_first_is_indexed() {
8105:         // TP: Round 1's index (`MetaA` alone,
8106:         // provable with no index at all) is exactly what lets the file holding
8107:         // `MetaA create MetaB` publish `MetaB` — so the host's next round has
8108:         // something new to merge. Without the index the same file publishes
8109:         // nothing, which is the false negative this fixpoint closes.
8110:         let round1 = factories_of(CHAIN_META_A);
8111:         assert_eq!(round1.keys().collect::<Vec<_>>(), ["::MC::MetaA"]);
8112: 
8113:         let bare = Analyser::new()
8114:             .analyse(CHAIN_META_B, "tcl9.0")
8115:             .class_factories();
8116:         assert!(
8117:             bare.is_empty(),
8118:             "with no oracle the middle link proves nothing: {:?}",
8119:             bare.keys().collect::<Vec<_>>()
8120:         );
8121: 
8122:         let round2 = analysis_with_factories(CHAIN_META_B, &round1).class_factories();
8123:         assert_eq!(
8124:             round2.keys().collect::<Vec<_>>(),
8125:             ["::MC::MetaB"],
8126:             "handed the first link, the file proves the second"
8127:         );
8128:         assert_eq!(round2["::MC::MetaB"].root_metaclass, "oo::class");
8129:     }
8130: 
8131:     #[test]
8132:     fn the_third_link_records_the_class_and_its_members() {
8133:         // TP. With both metaclasses in the index the consuming file records a
8134:         // real class with a real method — the fact go-to-definition on `$w go`
8135:         // needs, and the one that came back empty before the fixpoint.
8136:         let mut index = (*factories_of(CHAIN_META_A)).clone();
8137:         for (name, factory) in
8138:             analysis_with_factories(CHAIN_META_B, &factories_of(CHAIN_META_A)).class_factories()
8139:         {
8140:             index.insert(name, factory);
8141:         }
8142:         let index = std::sync::Arc::new(index);
8143:         let r = analysis_with_factories(CHAIN_WIDGET, &index);
8144:         let cd = r
8145:             .all_classes
8146:             .get("::MC::Widget")
8147:             .unwrap_or_else(|| panic!("::MC::Widget: {:?}", r.all_classes.keys()));
8148:         assert_eq!(cd.methods.keys().collect::<Vec<_>>(), ["go"], "{cd:?}");
8149:         assert!(!cd.inheritance_unknown, "{cd:?}");
8150:     }
8151: 
8152:     #[test]
8153:     fn oo_define_after_the_fact_extends_a_chained_factory_made_class() {
8154:         // The `oo::define` surface: a class manufactured by a second-link
8155:         // metaclass takes later `oo::define` members like any other class.
8156:         //
8157:         // Oracle (tclsh 9.0.4 / 8.6.16): `info class methods ::MC::Widget`
8158:         // -> `go later` after the `oo::define`.
8159:         let index = chained_index();
8160:         let src = concat!(
8161:             "::MC::MetaB create ::MC::Widget { method go {} { return went } }\n",
8162:             "oo::define ::MC::Widget { method later {} { return l } }\n",
8163:         );
8164:         let r = analysis_with_factories(src, &index);
8165:         let cd = &r.all_classes["::MC::Widget"];
8166:         let mut methods: Vec<&str> = cd.methods.keys().map(String::as_str).collect();
8167:         methods.sort_unstable();
8168:         assert_eq!(methods, ["go", "later"], "{cd:?}");
8169:     }
8170: 
8171:     #[test]
8172:     fn an_unproved_second_link_still_abstains() {
8173:         // TN. Handed an index that names only `MetaA`, a file writing
8174:         // `::MC::MetaB create …` has no proof `::MC::MetaB` manufactures
8175:         // anything — it could be `interp create` for all the walk knows — so it
8176:         // must record nothing rather than guessing the deeper link.
8177:         let r = analysis_with_factories(CHAIN_WIDGET, &factories_of(CHAIN_META_A));
8178:         assert!(
8179:             r.all_classes.is_empty(),
8180:             "no guess from a partially-published index: {:?}",
8181:             r.all_classes.keys().collect::<Vec<_>>()
8182:         );
8183:     }
8184: 
8185:     /// The index a two-round publish produces for this chain:
8186:     /// `MetaA` proved with no oracle, `MetaB` proved with `MetaA` published.
8187:     fn chained_index() -> std::sync::Arc<tcl_compiler::analyser::ClassFactoryIndex> {
8188:         let first = factories_of(CHAIN_META_A);
8189:         let mut index = (*first).clone();
8190:         for (name, factory) in analysis_with_factories(CHAIN_META_B, &first).class_factories() {
8191:             index.insert(name, factory);
8192:         }
8193:         std::sync::Arc::new(index)
8194:     }
8195: 
8196:     // A `rename`d metaclass command manufactures nothing, unless the rename
8197:     // is in effect and actually called through.
8198: 
8199:     /// TP: `oo::class create ::R::M`, `rename ::R::M
8200:     /// ::R::Mk`, then `::R::Mk create ::R::W { method go {} {…} }` records
8201:     /// `::R::W` with `go`, exactly as calling the metaclass under its
8202:     /// original name would.
8203:     #[test]
8204:     fn a_renamed_metaclass_still_manufactures_its_class() {
8205:         let src = concat!(
8206:             "namespace eval ::R {}\n",
8207:             "oo::class create ::R::M { superclass oo::class }\n",
8208:             "rename ::R::M ::R::Mk\n",
8209:             "::R::Mk create ::R::W { method go {} { return went } }\n",
8210:         );
8211:         let cd = class(src, "::R::W");
8212:         assert!(
8213:             cd.methods.contains_key("go"),
8214:             "renamed-metaclass creation must still record members: {cd:?}"
8215:         );
8216:         assert!(
8217:             !cd.inheritance_unknown,
8218:             "a proved renamed-metaclass creation is not inheritance-unknown: {cd:?}"
8219:         );
8220:     }
8221: 
8222:     /// TP control — the un-renamed form (metaclass created directly as
8223:     /// `::R::Mk`) records the identical class, so the rename case above is
8224:     /// judged against its own oracle rather than an assumption.
8225:     #[test]
8226:     fn the_control_without_a_rename_records_the_same_class() {
8227:         let src = concat!(
8228:             "namespace eval ::R {}\n",
8229:             "oo::class create ::R::Mk { superclass oo::class }\n",
8230:             "::R::Mk create ::R::W { method go {} { return went } }\n",
8231:         );
8232:         let cd = class(src, "::R::W");
8233:         assert!(cd.methods.contains_key("go"), "{cd:?}");
8234:     }
8235: 
8236:     /// FN guard — a rename written *after* the creation call it would have
8237:     /// covered must not retroactively enable it: order-gating is inherited
8238:     /// unchanged from `indirection::walk`'s "in effect" rule.
8239:     #[test]
8240:     fn a_rename_written_after_the_creation_call_does_not_apply() {
8241:         let src = concat!(
8242:             "namespace eval ::R {}\n",
8243:             "oo::class create ::R::M { superclass oo::class }\n",
8244:             "::R::Mk create ::R::W { method go {} { return went } }\n",
8245:             "rename ::R::M ::R::Mk\n",
8246:         );
8247:         let r = analysis(src, "tcl9.0");
8248:         assert!(
8249:             !r.all_classes.contains_key("::R::W"),
8250:             "a rename written after the call site must not retroactively apply: {:?}",
8251:             r.all_classes.keys().collect::<Vec<_>>()
8252:         );
8253:     }
8254: 
8255:     /// FN guard — a `rename` to a name that is never actually used as a
8256:     /// metaclass call must not spuriously manufacture anything (the rename
8257:     /// machinery is exercised, but the renamed-through call itself is
8258:     /// missing).
8259:     #[test]
8260:     fn a_rename_with_no_call_through_the_new_name_manufactures_nothing() {
8261:         let src = concat!(
8262:             "namespace eval ::R {}\n",
8263:             "oo::class create ::R::M { superclass oo::class }\n",
8264:             "rename ::R::M ::R::Mk\n",
8265:         );
8266:         let r = analysis(src, "tcl9.0");
8267:         assert!(
8268:             !r.all_classes.contains_key("::R::W"),
8269:             "no creation call means no manufactured class: {:?}",
8270:             r.all_classes.keys().collect::<Vec<_>>()
8271:         );
8272:     }
8273: }
8274: 
8275: // Constant command-substitution `set` RHS folding.
8276: //
8277: // The analyser's constant lattice folds `set VAR [cmd …]` through the
8278: // registry `const_fold` / frame-fact engine (`crate::const_subst`), so the
8279: // `${ns}::setdef` navigation chain resolves when `ns` was assigned a
8280: // constant command substitution rather than a bare literal.
8281: //
8282: // C-Tcl ground truth (tclsh 9.0.4, run while authoring): `namespace
8283: // qualifiers ::tc::X` → `::tc`; inside an instance method of `::tc::Chart`
8284: // the full chain really dispatches (`set ns [namespace qualifiers [self
8285: // class]]; ${ns}::setdef x y` → `::tc::setdef` runs); inside a `self
8286: // method`, `self class` raises `method not defined by a class`; inside a
8287: // `classmethod` it answers the internal `::oo::ObjN:: oo ::delegate` class,
8288: // never the written one.
8289: mod const_cmd_subst_set_rhs {
8290:     use super::*;
8291:     use tcl_compiler::analyser::AnalysisResult;
8292: 
8293:     fn analysis(src: &str, dialect: &str) -> AnalysisResult {
8294:         Analyser::new().analyse(src, dialect)
8295:     }
8296: 
8297:     fn resolutions_of(r: &AnalysisResult, head_contains: &str) -> Vec<String> {
8298:         r.command_invocations
8299:             .iter()
8300:             .filter(|inv| inv.name.contains(head_contains))
8301:             .filter_map(|inv| inv.resolved_qualified_name.clone())
8302:             .collect()
8303:     }
8304: 
8305:     #[test]
8306:     fn a_constant_namespace_qualifiers_rhs_folds_and_resolves_the_head() {
8307:         // TP — the probe shape: zero OO involvement, a
8308:         // plain proc, a constant `[namespace qualifiers …]` RHS.
8309:         let src = concat!(
8310:             "namespace eval tc { proc setdef {a b} { return 1 } }\n",
8311:             "proc user {} {\n",
8312:             "    set ns [namespace qualifiers ::tc::X]\n",
8313:             "    ${ns}::setdef x y\n",
8314:             "}\n",
8315:         );
8316:         let r = analysis(src, "tcl8.6");
8317:         assert_eq!(
8318:             resolutions_of(&r, "${ns}"),
8319:             ["::tc::setdef"],
8320:             "the folded constant must drive head resolution"
8321:         );
8322:     }
8323: 
8324:     #[test]
8325:     fn a_vendor_profile_folds_a_version_sensitive_constant_only_where_its_release_was_measured() {
8326:         // The version-sensitive `format %d 010` is 8 under Tcl 8.4 (a leading
8327:         // zero is octal) and 10 under 9.0. iRules is an 8.4 fork whose release
8328:         // was measured, so it folds as 8.4 does; `expect` models an 8.6 base that
8329:         // nobody measured, so a fold under it stays unresolved rather than being
8330:         // folded as one release's semantics.
8331:         let src = concat!(
8332:             "namespace eval tc { proc setdef {a b} { return 1 } }\n",
8333:             "proc user {} {\n",
8334:             "    set value [format %d 010]\n",
8335:             "    ${value}::setdef x y\n",
8336:             "}\n",
8337:         );
8338:         let measured = analysis(src, "f5-irules");
8339:         assert_eq!(
8340:             resolutions_of(&measured, "${value}"),
8341:             ["::8::setdef"],
8342:             "a measured vendor release folds as that release"
8343:         );
8344:         let unmeasured = analysis(src, "expect");
8345:         assert_eq!(
8346:             resolutions_of(&unmeasured, "${value}"),
8347:             ["::${value}::setdef"],
8348:             "a vendor base nothing measured must abstain"
8349:         );
8350:     }
8351: 
8352:     #[test]
8353:     fn a_self_class_chain_folds_inside_an_instance_method() {
8354:         // TP — the ticklecharts idiom one level removed: `set ns
8355:         // [namespace qualifiers [self class]]` inside an instance method of
8356:         // `::tc::Chart`. Every registry dependency is exact, so the
8357:         // runtime-selected receiver namespace cannot change the fold.
8358:         let src = concat!(
8359:             "namespace eval tc { proc setdef {a b} { return 1 } }\n",
8360:             "oo::class create ::tc::Chart {\n",
8361:             "    method go {} {\n",
8362:             "        ::set ns [::namespace qualifiers [::oo::Helpers::self class]]\n",
8363:             "        ${ns}::setdef x y\n",
8364:             "    }\n",
8365:             "}\n",
8366:         );
8367:         let r = analysis(src, "tcl9.0");
8368:         assert_eq!(
8369:             resolutions_of(&r, "${ns}"),
8370:             ["::tc::setdef"],
8371:             "the frame-fact fold must feed the constant lattice"
8372:         );
8373:     }
8374: 
8375:     #[test]
8376:     fn a_class_side_method_abstains_from_the_self_class_fold() {
8377:         // FP guard: `self class` never
8378:         // answers the written class in a class-side frame (tclsh 9.0.4:
8379:         // raises in a `self method`; answers the internal delegate class
8380:         // in a `classmethod`) — folding it would invent a value. The head
8381:         // must stay unresolved-as-written.
8382:         for member in ["classmethod go {}", "self method go {}"] {
8383:             let src = format!(
8384:                 concat!(
8385:                     "namespace eval tc {{ proc setdef {{a b}} {{ return 1 }} }}\n",
8386:                     "oo::class create ::tc::Chart {{\n",
8387:                     "    {} {{\n",
8388:                     "        set ns [namespace qualifiers [self class]]\n",
8389:                     "        ${{ns}}::setdef x y\n",
8390:                     "    }}\n",
8391:                     "}}\n",
8392:                 ),
8393:                 member
8394:             );
8395:             let r = analysis(&src, "tcl9.0");
8396:             assert_eq!(
8397:                 resolutions_of(&r, "${ns}"),
8398:                 ["::${ns}::setdef"],
8399:                 "{member}: a class-side frame must not fold [self class]"
8400:             );
8401:         }
8402:     }
8403: 
8404:     #[test]
8405:     fn a_later_rename_of_the_folding_head_blocks_the_fold() {
8406:         // FP guard: the trust oracle is
8407:         // whole-module — a `rename` AFTER the `set`, buried inside a proc
8408:         // body, still unbinds `namespace` from its builtin semantics
8409:         // before some later call can run. The mid-walk `renamed_commands`
8410:         // map cannot see it; the fold must still decline.
8411:         let src = concat!(
8412:             "namespace eval tc { proc setdef {a b} { return 1 } }\n",
8413:             "proc user {} {\n",
8414:             "    set ns [namespace qualifiers ::tc::X]\n",
8415:             "    ${ns}::setdef x y\n",
8416:             "}\n",
8417:             "proc sabotage {} { rename namespace nsx }\n",
8418:         );
8419:         let r = analysis(src, "tcl8.6");
8420:         assert_eq!(
8421:             resolutions_of(&r, "${ns}"),
8422:             ["::${ns}::setdef"],
8423:             "a whole-module rename of the head must block the fold"
8424:         );
8425:     }
8426: 
8427:     #[test]
8428:     fn a_shadowing_proc_definition_blocks_the_fold() {
8429:         // FP guard — a user `proc namespace …` anywhere in the module
8430:         // shadows the builtin, so `[namespace qualifiers …]` no longer has
8431:         // builtin semantics (flow-insensitive: cross-proc call order is
8432:         // not statically known).
8433:         let src = concat!(
8434:             "namespace eval tc { proc setdef {a b} { return 1 } }\n",
8435:             "proc user {} {\n",
8436:             "    set ns [namespace qualifiers ::tc::X]\n",
8437:             "    ${ns}::setdef x y\n",
8438:             "}\n",
8439:             "proc namespace {args} { return ::evil }\n",
8440:         );
8441:         let r = analysis(src, "tcl8.6");
8442:         assert_eq!(
8443:             resolutions_of(&r, "${ns}"),
8444:             ["::${ns}::setdef"],
8445:             "a shadowed builtin must not const-fold"
8446:         );
8447:     }
8448: 
8449:     #[test]
8450:     fn a_branch_dependent_argument_abstains() {
8451:         // TN — the substitution's `$q` argument has no dominating constant
8452:         // (two branch values), so the fold must abstain rather than pick
8453:         // the last-written branch.
8454:         let src = concat!(
8455:             "namespace eval a { proc go {} { return 1 } }\n",
8456:             "namespace eval b { proc go {} { return 1 } }\n",
8457:             "proc user {c} {\n",
8458:             "    set q ::a::X\n",
8459:             "    if {$c} { set q ::b::X }\n",
8460:             "    set ns [namespace qualifiers $q]\n",
8461:             "    ${ns}::go\n",
8462:             "}\n",
8463:         );
8464:         let r = analysis(src, "tcl8.6");
8465:         assert_eq!(
8466:             resolutions_of(&r, "${ns}"),
8467:             ["::${ns}::go"],
8468:             "a branch-dependent argument must not fold"
8469:         );
8470:     }
8471: 
8472:     #[test]
8473:     fn per_item_path_folds_and_abstains_identically_to_the_whole_file_walk() {
8474:         // The per-item (incremental) path analyses each proc body in
8475:         // ISOLATION — it cannot see a `rename` elsewhere in the file, so
8476:         // the shell attaches a whole-file trust snapshot to every deferred
8477:         // body with a fold candidate (`DeferredBody::command_trust`).
8478:         // Both directions must match the whole-file walk byte-for-byte:
8479:         // the TP still folds, the FP still abstains.
8480:         let tp = concat!(
8481:             "namespace eval tc { proc setdef {a b} { return 1 } }\n",
8482:             "proc user {} {\n",
8483:             "    set ns [namespace qualifiers ::tc::X]\n",
8484:             "    ${ns}::setdef x y\n",
8485:             "}\n",
8486:         );
8487:         let fp = concat!(
8488:             "namespace eval tc { proc setdef {a b} { return 1 } }\n",
8489:             "proc user {} {\n",
8490:             "    set ns [namespace qualifiers ::tc::X]\n",
8491:             "    ${ns}::setdef x y\n",
8492:             "}\n",
8493:             "proc sabotage {} { rename namespace nsx }\n",
8494:         );
8495:         for (src, expected) in [(tp, "::tc::setdef"), (fp, "::${ns}::setdef")] {
8496:             let whole = analysis(src, "tcl8.6");
8497:             let per_item = Analyser::new().analyse_per_item(src, "tcl8.6");
8498:             assert_eq!(
8499:                 resolutions_of(&whole, "${ns}"),
8500:                 [expected],
8501:                 "whole-file walk for {src:?}"
8502:             );
8503:             assert_eq!(
8504:                 resolutions_of(&per_item, "${ns}"),
8505:                 resolutions_of(&whole, "${ns}"),
8506:                 "per-item must match the whole-file walk for {src:?}"
8507:             );
8508:         }
8509:     }
8510: 
8511:     #[test]
8512:     fn a_dominating_constant_argument_folds_through_the_lattice() {
8513:         // TP — the substitution reads a `$q` that IS a dominating
8514:         // constant; the fold chains through the constant lattice.
8515:         let src = concat!(
8516:             "namespace eval tc { proc setdef {a b} { return 1 } }\n",
8517:             "proc user {} {\n",
8518:             "    set q ::tc::X\n",
8519:             "    set ns [namespace qualifiers $q]\n",
8520:             "    ${ns}::setdef x y\n",
8521:             "}\n",
8522:         );
8523:         let r = analysis(src, "tcl8.6");
8524:         assert_eq!(resolutions_of(&r, "${ns}"), ["::tc::setdef"]);
8525:     }
8526: }
8527: 
8528: // Leading byte-order mark.
8529: mod leading_bom {
8530:     use super::{Analyser, analyser_diags, fires};
8531: 
8532:     /// A file whose first byte is a UTF-8 BOM: Tcl 9's `source` strips it
8533:     /// before evaluating, so the first command is an ordinary `set` and must
8534:     /// draw no unresolved-command diagnostic.
8535:     #[test]
8536:     fn tcl9_skips_a_leading_bom() {
8537:         let src = "\u{FEFF}set x 1\nputs $x\n";
8538:         assert!(
8539:             !fires(src, "tcl9.0", "W123"),
8540:             "diagnostics: {:?}",
8541:             analyser_diags(src, "tcl9.0"),
8542:         );
8543:     }
8544: 
8545:     /// Tcl 8.x's `source` does **not** strip it — such a file really does fail
8546:     /// with `invalid command name "<BOM>set"`, so the diagnostic stays.
8547:     #[test]
8548:     fn tcl86_still_reports_a_leading_bom() {
8549:         let src = "\u{FEFF}set x 1\nputs $x\n";
8550:         assert!(
8551:             fires(src, "tcl8.6", "W123"),
8552:             "diagnostics: {:?}",
8553:             analyser_diags(src, "tcl8.6"),
8554:         );
8555:     }
8556: 
8557:     /// The mark is skipped by starting the scan past it, never by rewriting
8558:     /// the buffer — so every span keeps its true byte offset and the first
8559:     /// command's own span still points at the real name word.  This is the
8560:     /// position-maths guarantee: a client that did send the BOM sees line 0
8561:     /// columns that still land on the text it holds.
8562:     #[test]
8563:     fn skipping_the_bom_leaves_byte_offsets_untouched() {
8564:         let src = "\u{FEFF}proc greet {} { return 1 }\n";
8565:         let r = Analyser::new().analyse(src, "tcl9.0");
8566:         let proc = r
8567:             .global_scope
8568:             .procs
8569:             .values()
8570:             .next()
8571:             .expect("the proc must be recorded once the BOM is skipped");
8572:         assert_eq!(
8573:             proc.name_span.start() as usize,
8574:             "\u{FEFF}proc ".len(),
8575:             "name span must be in original-source offsets",
8576:         );
8577:         assert_eq!(
8578:             &src[proc.name_span.start() as usize..proc.name_span.end() as usize],
8579:             "greet",
8580:         );
8581:     }
8582: 
8583:     /// A BOM that is not at offset 0 is ordinary data in every dialect — the
8584:     /// skip is a file-prologue rule, not a "U+FEFF is whitespace" rule.
8585:     #[test]
8586:     fn a_bom_mid_file_is_not_skipped() {
8587:         let src = "set x 1\n\u{FEFF}set y 2\n";
8588:         assert!(
8589:             fires(src, "tcl9.0", "W123"),
8590:             "diagnostics: {:?}",
8591:             analyser_diags(src, "tcl9.0"),
8592:         );
8593:     }
8594: }
8595: 
8596: // A TclOO member body's implicit `namespace path`.
8597: //
8598: // tclsh 8.6.16 and 9.0.4, inside `oo::class create C { method m {} { … } }`:
8599: //     namespace current -> ::oo::ObjN        namespace path -> ::oo::Helpers
8600: // so a bare word is looked up in the object namespace, then `::oo::Helpers`,
8601: // then global. The documented "TclOO Tricks" idiom installs helpers directly
8602: // (`proc ::oo::Helpers::callback {…} {…}`) and calls them bare from method
8603: // bodies — which is what nico-robert/ticklecharts does, with the helper in
8604: // `utils.tcl` and the calls in `esnap.tcl`.
8605: //
8606: // The candidate list is where that path belongs: `resolve_workspace_symbols`
8607: // (the one cross-file resolver) walks it, so recording it once here fixes
8608: // definition, references, rename, call hierarchy, and W123 together, across
8609: // files, instead of each consumer growing its own lenient fallback.
8610: mod oo_helpers_namespace_path {
8611:     use super::Analyser;
8612: 
8613:     fn candidates_for(src: &str, dialect: &str, name: &str) -> Vec<String> {
8614:         Analyser::new()
8615:             .analyse(src, dialect)
8616:             .command_invocations
8617:             .iter()
8618:             .find(|inv| inv.name == name)
8619:             .map(|inv| inv.resolution_candidates.clone())
8620:             .unwrap_or_default()
8621:     }
8622: 
8623:     fn resolution_of(src: &str, dialect: &str, name: &str) -> Option<String> {
8624:         Analyser::new()
8625:             .analyse(src, dialect)
8626:             .command_invocations
8627:             .iter()
8628:             .find(|inv| inv.name == name)
8629:             .and_then(|inv| inv.resolved_qualified_name.clone())
8630:     }
8631: 
8632:     #[test]
8633:     fn tp_a_method_body_call_carries_the_helpers_candidate_first() {
8634:         // TP — `::oo::Helpers::callback` must be a candidate, and must rank
8635:         // ahead of the global one: with both defined, real Tcl reaches the
8636:         // helper.
8637:         let src = "oo::class create C {\n    method Go {} {\n        callback Read\n    }\n}\n";
8638:         assert_eq!(
8639:             candidates_for(src, "tcl9.0", "callback"),
8640:             ["::oo::Helpers::callback", "::callback"],
8641:         );
8642:     }
8643: 
8644:     #[test]
8645:     fn tp_the_same_holds_for_a_constructor_body() {
8646:         let src = "oo::class create C {\n    constructor {} {\n        callback Read\n    }\n}\n";
8647:         assert_eq!(
8648:             candidates_for(src, "tcl9.0", "callback"),
8649:             ["::oo::Helpers::callback", "::callback"],
8650:         );
8651:     }
8652: 
8653:     #[test]
8654:     fn tp_a_helper_declared_in_the_same_file_settles_the_call_onto_it() {
8655:         // TP — with the helper present the call settles on it, not on a
8656:         // phantom `::callback`.
8657:         let src = "proc ::oo::Helpers::callback {m args} { return $m }\noo::class create C {\n    method Go {} {\n        callback Read\n    }\n}\n";
8658:         assert_eq!(
8659:             resolution_of(src, "tcl9.0", "callback").as_deref(),
8660:             Some("::oo::Helpers::callback"),
8661:         );
8662:     }
8663: 
8664:     #[test]
8665:     fn fp_a_top_level_call_gets_no_helpers_candidate() {
8666:         // FP guard — `::oo::Helpers` is on a *method body's* namespace path
8667:         // only. tclsh raises `invalid command name` for a bare `callback`
8668:         // at the top level, so the candidate must not appear there.
8669:         let src = "proc ::oo::Helpers::callback {m args} { return $m }\ncallback Read\n";
8670:         assert_eq!(candidates_for(src, "tcl9.0", "callback"), ["::callback"]);
8671:     }
8672: 
8673:     #[test]
8674:     fn fp_an_apply_lambda_inside_a_method_loses_the_path() {
8675:         // FP guard — `apply` runs its body in the global namespace, so the
8676:         // object context (and its path) is gone. tclsh 9.0.4 raises
8677:         // `invalid command name "link"` for exactly this shape.
8678:         let src = "oo::class create C {\n    method Go {} {\n        apply {{} { callback Read }}\n    }\n}\n";
8679:         assert_eq!(candidates_for(src, "tcl9.0", "callback"), ["::callback"]);
8680:     }
8681: 
8682:     #[test]
8683:     fn tn_a_snit_method_body_gets_no_helpers_candidate() {
8684:         // TN — snit member bodies run in the type namespace with no
8685:         // injected path; only the TclOO grammar declares one.
8686:         let src = "snit::type T {\n    method Go {} {\n        callback Read\n    }\n}\n";
8687:         let cands = candidates_for(src, "tcl9.0", "callback");
8688:         assert!(
8689:             !cands.iter().any(|c| c.starts_with("::oo::Helpers")),
8690:             "snit gets no TclOO helper path: {cands:?}",
8691:         );
8692:     }
8693: 
8694:     #[test]
8695:     fn tn_an_ordinary_builtin_still_settles_globally_from_a_method_body() {
8696:         // TN — the extra candidate must not divert an ordinary call: `puts`
8697:         // has no `::oo::Helpers` member, so it still reaches `::puts`.
8698:         let src = "oo::class create C {\n    method Go {} {\n        puts hi\n    }\n}\n";
8699:         assert_eq!(
8700:             resolution_of(src, "tcl9.0", "puts").as_deref(),
8701:             Some("::puts"),
8702:         );
8703:     }
8704: }
8705: 
8706: // A constant-dominated computed `namespace eval` target.
8707: //
8708: // `set ns ::app; namespace eval $ns { … }` creates `::app` on every run, so
8709: // the block's procs really do home to `::app::…`.  The word is settled by the
8710: // same identity-resolution helper the command head, `source`,
8711: // `rename`, and `oo::define`'s target already use, so its dominance rule —
8712: // a branch-conditional binding proves nothing — applies here unchanged.
8713: // Anything it cannot settle keeps the per-site `@dynns@` domain.
8714: mod const_dominated_namespace_eval {
8715:     use super::Analyser;
8716: 
8717:     fn proc_names(src: &str) -> Vec<String> {
8718:         let mut names: Vec<String> = Analyser::new()
8719:             .analyse(src, "tcl9.0")
8720:             .all_procs
8721:             .keys()
8722:             .cloned()
8723:             .collect();
8724:         names.sort();
8725:         names
8726:     }
8727: 
8728:     fn scope_names(src: &str) -> Vec<String> {
8729:         Analyser::new()
8730:             .analyse(src, "tcl9.0")
8731:             .global_scope
8732:             .children
8733:             .iter()
8734:             .map(|c| c.name.clone())
8735:             .collect()
8736:     }
8737: 
8738:     #[test]
8739:     fn tp_a_constant_target_homes_the_blocks_procs_to_the_real_namespace() {
8740:         let src = "set ns ::app\nnamespace eval $ns {\n    proc go {} { return 1 }\n}\n";
8741:         assert_eq!(proc_names(src), ["::app::go"]);
8742:         assert_eq!(scope_names(src), ["::app"]);
8743:     }
8744: 
8745:     #[test]
8746:     fn tp_the_word_is_recorded_as_a_declaring_occurrence() {
8747:         // Navigation's half: the `$ns` word is where `::app` is created, so
8748:         // it is the answer a `namespace children ::app` elsewhere jumps to.
8749:         let src = "set ns ::app\nnamespace eval $ns { proc go {} { return 1 } }\n";
8750:         let r = Analyser::new().analyse(src, "tcl9.0").clone();
8751:         let decls: Vec<&str> = r
8752:             .namespace_refs
8753:             .iter()
8754:             .filter(|n| n.declares && n.qualified_name == "::app")
8755:             .map(|n| &src[n.span.start() as usize..n.span.end() as usize])
8756:             .collect();
8757:         assert_eq!(decls, ["$ns"], "{:?}", r.namespace_refs);
8758:     }
8759: 
8760:     #[test]
8761:     fn fp_a_branch_conditional_binding_keeps_the_synthetic_domain() {
8762:         // FP guard — the dominance rule.  Which namespace this creates is a
8763:         // run-time question, so claiming either would be a wrong answer.
8764:         let src = "set ns ::a\nif {$c} { set ns ::b }\nnamespace eval $ns {\n    proc go {} { return 1 }\n}\n";
8765:         assert!(
8766:             proc_names(src).iter().all(|n| n.contains("@dynns@")),
8767:             "{:?}",
8768:             proc_names(src),
8769:         );
8770:     }
8771: 
8772:     #[test]
8773:     fn tn_a_parameter_target_keeps_the_synthetic_domain() {
8774:         // TN — the irc.tcl per-connection idiom the synthetic domain exists
8775:         // for: nothing constant reaches `$n`, so each occurrence stays its
8776:         // own scope.
8777:         let src =
8778:             "proc mk {n} {\n    namespace eval $n {\n        proc go {} { return 1 }\n    }\n}\n";
8779:         let names = proc_names(src);
8780:         assert!(names.iter().any(|n| n.contains("@dynns@")), "{names:?}");
8781:     }
8782: 
8783:     #[test]
8784:     fn tn_a_literal_target_is_unchanged() {
8785:         let src = "namespace eval ::app {\n    proc go {} { return 1 }\n}\n";
8786:         assert_eq!(proc_names(src), ["::app::go"]);
8787:         assert_eq!(scope_names(src), ["::app"]);
8788:     }
8789: }
8790: 
8791: // A brace-quoted word's *elements* are literal too.
8792: //
8793: // The IR/analyser word arrives with its braces already stripped, so scanning
8794: // the element text alone reports "dynamic" for content Tcl never substitutes.
8795: // The whole-word question for `namespace path` is already answered; these
8796: // are the two remaining places that ask it per element with the token in
8797: // hand.
8798: //
8799: // tclsh-proof (8.6.16 / 9.0.4):
8800: //   namespace eval x {}
8801: //   namespace eval {::$ns} {}
8802: //   namespace eval n { namespace path {::$ns ::x} ; namespace path }
8803: //     ->  {::$ns} ::x        (an entry literally named `::$ns`, no var read)
8804: //   foreach n {aa {$b} cc} { puts $n }
8805: //     ->  aa / $b / cc       (three literal iterations, no read of `b`)
8806: mod braced_word_elements_are_literal {
8807:     use super::*;
8808: 
8809:     /// Namespace-reference source texts recorded for `src`.
8810:     fn ns_ref_texts(src: &str) -> Vec<String> {
8811:         let r = Analyser::new().analyse(src, "tcl9.0").clone();
8812:         let mut out: Vec<String> = r
8813:             .namespace_refs
8814:             .iter()
8815:             .map(|n| src[n.span.start() as usize..n.span.end() as usize].to_owned())
8816:             .collect();
8817:         out.sort();
8818:         out
8819:     }
8820: 
8821:     /// Diagnostic codes emitted for `src`.
8822:     fn diag_codes(src: &str) -> Vec<String> {
8823:         Analyser::new()
8824:             .analyse(src, "tcl9.0")
8825:             .diagnostics
8826:             .iter()
8827:             .map(|d| d.code.to_string())
8828:             .collect()
8829:     }
8830: 
8831:     #[test]
8832:     fn tp_namespace_path_records_a_braced_dollar_element_as_a_reference() {
8833:         // The whole-word gate already lets the path be *recorded*; the
8834:         // element-reference walk must not skip the same word — both must
8835:         // see `::$ns`, or the function disagrees with itself.
8836:         let src = "namespace eval n { namespace path {::$ns ::x} }\n";
8837:         assert!(
8838:             ns_ref_texts(src).iter().any(|t| t == "::$ns"),
8839:             "the braced element is a namespace literally named `::$ns`; got {:?}",
8840:             ns_ref_texts(src)
8841:         );
8842:     }
8843: 
8844:     #[test]
8845:     fn fp_namespace_path_still_skips_a_substituting_element() {
8846:         // FP guard: an unbraced path word does substitute, so its `$ns` names
8847:         // nothing static and must stay unrecorded.
8848:         let src = "namespace eval n { namespace path ::$ns }\n";
8849:         assert!(
8850:             !ns_ref_texts(src).iter().any(|t| t.contains('$')),
8851:             "a substituting path word must record no element reference; got {:?}",
8852:             ns_ref_texts(src)
8853:         );
8854:     }
8855: 
8856:     #[test]
8857:     fn tn_namespace_path_literal_elements_unchanged() {
8858:         let src = "namespace eval n { namespace path {::x ::y} }\n";
8859:         let refs = ns_ref_texts(src);
8860:         assert!(refs.iter().any(|t| t == "::x"), "{refs:?}");
8861:         assert!(refs.iter().any(|t| t == "::y"), "{refs:?}");
8862:     }
8863: 
8864:     #[test]
8865:     fn tp_foreach_simulation_survives_a_braced_dollar_element() {
8866:         // One odd element must not abstain the whole simulation — otherwise
8867:         // every proc the loop installs goes missing and each call raises
8868:         // W123.
8869:         let src = "foreach n {aa {$b} cc} { proc $n {} {} }\naa\ncc\n";
8870:         assert!(
8871:             !diag_codes(src).iter().any(|c| c == "W123"),
8872:             "the braced element must not abstain the whole simulation; got {:?}",
8873:             diag_codes(src)
8874:         );
8875:     }
8876: 
8877:     #[test]
8878:     fn fp_foreach_simulation_still_abstains_on_a_substituting_list() {
8879:         // FP guard: a quoted list word *does* substitute, so its elements are
8880:         // not knowable and the simulation must still decline.
8881:         let src = "foreach n \"aa $b cc\" { proc $n {} {} }\naa\n";
8882:         assert!(
8883:             diag_codes(src).iter().any(|c| c == "W123"),
8884:             "a substituting list word must still abstain; got {:?}",
8885:             diag_codes(src)
8886:         );
8887:     }
8888: 
8889:     #[test]
8890:     fn tn_foreach_simulation_literal_elements_unchanged() {
8891:         let src = "foreach n {aa cc} { proc $n {} {} }\naa\ncc\n";
8892:         assert!(
8893:             !diag_codes(src).iter().any(|c| c == "W123"),
8894:             "{:?}",
8895:             diag_codes(src)
8896:         );
8897:     }
8898: }
8899: 
8900: /// A named object (`CLASS create NAME`) must resolve its members like
8901: /// `[CLASS new]` already does for W308 on an unknown method: the dispatch
8902: /// resolver must consult `AnalysisResult::created_instance_commands` /
8903: /// `instance_classes` for a bareword receiver too.
8904: mod issue_1312_named_object_dispatch {
8905:     use super::*;
8906: 
8907:     /// TP: `C create obj` then `obj nosuchmethod` must draw the same W308
8908:     /// the handle form (`[C new]`) already does.
8909:     #[test]
8910:     fn named_object_draws_w308_on_an_unknown_method() {
8911:         let src = "oo::class create C {\n\
8912:                      method mrun {} { return 1 }\n\
8913:                    }\n\
8914:                    C create obj\n\
8915:                    obj nosuchmethod\n";
8916:         assert!(
8917:             fires(src, "tcl9.0", "W308"),
8918:             "named-object dispatch must draw W308 like the handle form: {:?}",
8919:             codes(src, "tcl9.0")
8920:         );
8921:     }
8922: 
8923:     /// TP — parity check: the handle form and the named form must draw
8924:     /// exactly the same W308 message for the identical class/method pair,
8925:     /// so the two construction forms are provably treated alike.
8926:     #[test]
8927:     fn named_object_and_handle_object_draw_the_same_w308_message() {
8928:         let handle = "oo::class create C { method mrun {} { return 1 } }\n\
8929:                        set h [C new]\n\
8930:                        $h nosuchmethod\n";
8931:         let named = "oo::class create C { method mrun {} { return 1 } }\n\
8932:                       C create obj\n\
8933:                       obj nosuchmethod\n";
8934:         let handle_msg = analyser_diags(handle, "tcl9.0")
8935:             .into_iter()
8936:             .find(|(c, _, _)| c == "W308")
8937:             .map(|(_, m, _)| m)
8938:             .expect("handle form draws W308");
8939:         let named_msg = analyser_diags(named, "tcl9.0")
8940:             .into_iter()
8941:             .find(|(c, _, _)| c == "W308")
8942:             .map(|(_, m, _)| m)
8943:             .expect("named form draws W308");
8944:         assert_eq!(handle_msg, named_msg);
8945:     }
8946: 
8947:     /// TN — a named object calling a method its class actually declares
8948:     /// must not draw a spurious W308.
8949:     #[test]
8950:     fn named_object_calling_a_real_method_draws_no_w308() {
8951:         let src = "oo::class create C { method mrun {} { return 1 } }\n\
8952:                    C create obj\n\
8953:                    obj mrun\n";
8954:         assert!(
8955:             !fires(src, "tcl9.0", "W308"),
8956:             "a real method must not draw W308: {:?}",
8957:             codes(src, "tcl9.0")
8958:         );
8959:     }
8960: 
8961:     /// FP guard — a bareword command that merely *looks* like a named
8962:     /// instance (an ordinary proc call, never bound via `CLASS create
8963:     /// NAME`) must not be swept into the object-dispatch check and must
8964:     /// never draw W307 "non-literal command name" — the whole point of
8965:     /// gating the bareword site on `instance_classes`, not on bareword
8966:     /// shape alone.
8967:     #[test]
8968:     fn an_ordinary_proc_call_never_draws_w307_or_w308() {
8969:         let src = "proc obj {args} { return 1 }\nobj nosuchmethod\n";
8970:         let got = codes(src, "tcl9.0");
8971:         assert!(
8972:             !got.iter().any(|c| c == "W307" || c == "W308"),
8973:             "an ordinary proc call must draw neither: {got:?}"
8974:         );
8975:     }
8976: 
8977:     /// FP guard — `interp create child` binds `child` as a *command*
8978:     /// (`created_instance_commands`), but never as a class instance
8979:     /// (`instance_classes` stays unset for it) — the coroutine / `interp
8980:     /// create` carve-out `record_bareword_instance_dispatch_site` documents.
8981:     /// `child eval …` must draw neither W307 nor W308.
8982:     #[test]
8983:     fn interp_create_bareword_dispatch_draws_no_diagnostic() {
8984:         let src = "interp create child\nchild eval { puts hi }\n";
8985:         let got = codes(src, "tcl9.0");
8986:         assert!(
8987:             !got.iter().any(|c| c == "W307" || c == "W308"),
8988:             "an `interp create` handle must draw neither: {got:?}"
8989:         );
8990:     }
8991: 
8992:     /// TP — the per-item (incremental) analysis path must agree with the
8993:     /// whole-file `analyse` path byte-for-byte on this shape, including when
8994:     /// the class is declared inside a proc body the per-item shell pass
8995:     /// defers (`Analyser::analyse_per_item`, `replay_deferred_instances`,
8996:     /// `finalise_bareword_dispatch_sites`).
8997:     #[test]
8998:     fn per_item_analysis_agrees_with_whole_file_analysis() {
8999:         let src = "proc def {} { oo::class create ::K { method poke {} {} } }\n\
9000:                    def\n\
9001:                    ::K create inst\n\
9002:                    inst nosuchmethod\n";
9003:         let whole = Analyser::new().analyse(src, "tcl9.0");
9004:         let per_item = Analyser::new().analyse_per_item(src, "tcl9.0");
9005:         assert_eq!(
9006:             per_item, whole,
9007:             "per_item != analyse for:\n{src}\nper_item diagnostics: {:?}\nwhole diagnostics: {:?}",
9008:             per_item.diagnostics, whole.diagnostics
9009:         );
9010:         assert!(
9011:             whole
9012:                 .diagnostics
9013:                 .iter()
9014:                 .any(|d| d.code.to_string() == "W308"),
9015:             "expected W308 on the named object created inside a deferred proc body: {:?}",
9016:             whole.diagnostics
9017:         );
9018:     }
9019: }
9020: 
9021: /// `$obj configure` on an `oo::configurable` class must not draw
9022: /// `Unknown method 'configure' on class '::UnifiedTest'; did you mean
9023: /// 'configure'?`: the accessors a configurable class generates for its
9024: /// `property` members are declared by no `method` body, so they reach
9025: /// neither the class's member tables nor the hierarchy's `method_providers`
9026: /// on their own.
9027: ///
9028: /// Both the existence check and the W308 *suggestion* list must go through
9029: /// `ClassHierarchy::configures_by_property`, so they cannot drift apart —
9030: /// otherwise the diagnostic could suggest the very word it had just called
9031: /// unknown.
9032: mod issue_1362_configurable_property_accessors {
9033:     use super::*;
9034: 
9035:     /// All three dispatch spellings: a handle
9036:     /// (`[C new]`), a named object (`C create obj`), and self-dispatch
9037:     /// (`my configure` inside a method body).
9038:     #[test]
9039:     fn configure_on_a_configurable_class_draws_no_w308() {
9040:         for src in [
9041:             "oo::configurable create UnifiedTest {\n    property name\n}\n\
9042:              set t [UnifiedTest new]\n$t configure -name x\n",
9043:             "oo::configurable create UnifiedTest {\n    property name\n}\n\
9044:              UnifiedTest create t\nt configure -name x\n",
9045:             "oo::configurable create UnifiedTest {\n    property name\n\
9046:              method go {} { my configure -name x }\n}\n",
9047:         ] {
9048:             assert!(
9049:                 !fires(src, "tcl9.0", "W308"),
9050:                 "configure is generated by the property: {:?} for {src:?}",
9051:                 codes(src, "tcl9.0")
9052:             );
9053:         }
9054:     }
9055: 
9056:     /// TP guard — `cget` is **not** generated. `configurable.n` documents
9057:     /// only `configure` (plus the internal `<ReadProp-name>` /
9058:     /// `<WriteProp-name>` accessors) in both 9.0 and 9.1, and this
9059:     /// workspace's own VM implements the same single method
9060:     /// (`tcl-vm/src/cmd_oo.rs`), so `$obj cget -name` is a real
9061:     /// unknown-method error and must keep drawing W308.
9062:     #[test]
9063:     fn cget_on_a_configurable_class_still_draws_w308() {
9064:         let src = "oo::configurable create UnifiedTest {\n    property name\n}\n\
9065:                    set t [UnifiedTest new]\n$t cget -name\n";
9066:         assert!(
9067:             fires(src, "tcl9.0", "W308"),
9068:             "oo::configurable generates no cget: {:?}",
9069:             codes(src, "tcl9.0")
9070:         );
9071:     }
9072: 
9073:     /// A configurable class with no `property` of its own still answers the
9074:     /// accessors — the metaclass supplies them, so the abstention must rest
9075:     /// on `Traits::CONFIGURES_BY_PROPERTY` rather than on the property list
9076:     /// being non-empty (tclsh 9.0.4: `[C new] configure` on an empty
9077:     /// `oo::configurable` class returns the empty dict, not an error).
9078:     #[test]
9079:     fn configurable_class_without_properties_draws_no_w308() {
9080:         let src = "oo::configurable create C {}\nset c [C new]\n$c configure\n";
9081:         assert!(!fires(src, "tcl9.0", "W308"), "{:?}", codes(src, "tcl9.0"));
9082:     }
9083: 
9084:     /// The accessors are real methods on the configurable ancestor, so a
9085:     /// plain `oo::class` subclass of one inherits them.
9086:     #[test]
9087:     fn subclass_of_a_configurable_class_draws_no_w308() {
9088:         let src = "oo::configurable create Base {\n    property name\n}\n\
9089:                    oo::class create Sub {\n    superclass Base\n}\n\
9090:                    set s [Sub new]\n$s configure -name x\n";
9091:         assert!(!fires(src, "tcl9.0", "W308"), "{:?}", codes(src, "tcl9.0"));
9092:     }
9093: 
9094:     /// TP guard — the abstention is scoped to configurable classes. A plain
9095:     /// `oo::class` instance really does fail with `unknown method
9096:     /// "configure"` (tclsh 9.0.4), so W308 must keep firing there.
9097:     #[test]
9098:     fn configure_on_a_plain_oo_class_still_draws_w308() {
9099:         let src = "oo::class create C {\n    method mrun {} { return 1 }\n}\n\
9100:                    set c [C new]\n$c configure -name x\n";
9101:         assert!(
9102:             fires(src, "tcl9.0", "W308"),
9103:             "a non-configurable class has no configure: {:?}",
9104:             codes(src, "tcl9.0")
9105:         );
9106:     }
9107: 
9108:     /// TP guard — a genuinely unknown method on a configurable class is
9109:     /// still unknown; the fix must not blanket-suppress W308 for the class.
9110:     #[test]
9111:     fn unknown_method_on_a_configurable_class_still_draws_w308() {
9112:         let src = "oo::configurable create C {\n    property name\n}\n\
9113:                    set c [C new]\n$c nosuchmethod\n";
9114:         assert!(fires(src, "tcl9.0", "W308"), "{:?}", codes(src, "tcl9.0"));
9115:     }
9116: 
9117:     /// A W308 must never suggest the word it just called unknown — the
9118:     /// signature of the drift this fix removes, asserted generically so any
9119:     /// future re-divergence between the existence check and the suggestion
9120:     /// list is caught whatever the method name.
9121:     #[test]
9122:     fn w308_never_suggests_the_method_it_calls_unknown() {
9123:         for src in [
9124:             "oo::configurable create C {\n    property name\n}\nset c [C new]\n$c configure\n",
9125:             "oo::configurable create C {\n    property name\n}\nset c [C new]\n$c cget -name\n",
9126:             "oo::configurable create C {\n    property name\n}\nset c [C new]\n$c configur\n",
9127:             "oo::class create C {\n    method mrun {} { return 1 }\n}\nset c [C new]\n$c mrunn\n",
9128:         ] {
9129:             for (code, msg, _) in analyser_diags(src, "tcl9.0") {
9130:                 if code != "W308" {
9131:                     continue;
9132:                 }
9133:                 let unknown = msg
9134:                     .split_once('\'')
9135:                     .and_then(|(_, rest)| rest.split_once('\''))
9136:                     .map(|(name, _)| name.to_owned())
9137:                     .expect("W308 names the method in quotes");
9138:                 assert!(
9139:                     !msg.contains(&format!("did you mean '{unknown}'?")),
9140:                     "W308 suggested the method it called unknown: {msg}"
9141:                 );
9142:             }
9143:         }
9144:     }
9145: }
9146: 
9147: mod issue_1367_template_method_self_dispatch {
9148:     use super::*;
9149: 
9150:     /// The ruff `Formatter` shape: an abstract base whose method bodies
9151:     /// `my`-dispatch a method written only by concrete subclasses.  `my`
9152:     /// late-binds on the actual receiver — always a subclass instance —
9153:     /// and reaches unexported members, so the capitalised (unexported)
9154:     /// subclass method is genuinely callable and W308 must abstain.
9155:     #[test]
9156:     fn my_dispatch_to_a_subclass_provided_method_draws_no_w308() {
9157:         let src = "oo::class create Base {\n\
9158:                    \x20   method run {} { my Render }\n\
9159:                    }\n\
9160:                    oo::class create Concrete {\n\
9161:                    \x20   superclass Base\n\
9162:                    \x20   method Render {} { return ok }\n\
9163:                    }\n";
9164:         assert!(
9165:             !fires(src, "tcl8.6", "W308"),
9166:             "a subclass defines the template method: {:?}",
9167:             codes(src, "tcl8.6")
9168:         );
9169:     }
9170: 
9171:     /// The subclass may itself get the template method from a mixin — the
9172:     /// descendant check resolves through the subclass's whole MRO, not
9173:     /// just its own member table.
9174:     #[test]
9175:     fn my_dispatch_to_a_mixin_provided_template_method_draws_no_w308() {
9176:         let src = "oo::class create Renderer {\n\
9177:                    \x20   method Render {} { return ok }\n\
9178:                    }\n\
9179:                    oo::class create Base {\n\
9180:                    \x20   method run {} { my Render }\n\
9181:                    }\n\
9182:                    oo::class create Concrete {\n\
9183:                    \x20   superclass Base\n\
9184:                    \x20   mixin Renderer\n\
9185:                    }\n";
9186:         assert!(
9187:             !fires(src, "tcl8.6", "W308"),
9188:             "the subclass inherits the template method from its mixin: {:?}",
9189:             codes(src, "tcl8.6")
9190:         );
9191:     }
9192: 
9193:     /// TP guard — a `my` typo stays a warning even when subclasses exist:
9194:     /// the abstention needs a subclass that *defines* the method, not
9195:     /// merely a subclass.
9196:     #[test]
9197:     fn my_dispatch_to_a_method_no_subclass_defines_still_draws_w308() {
9198:         let src = "oo::class create Base {\n\
9199:                    \x20   method run {} { my Rendr }\n\
9200:                    }\n\
9201:                    oo::class create Concrete {\n\
9202:                    \x20   superclass Base\n\
9203:                    \x20   method Render {} { return ok }\n\
9204:                    }\n";
9205:         assert!(
9206:             fires(src, "tcl8.6", "W308"),
9207:             "no subclass defines 'Rendr': {:?}",
9208:             codes(src, "tcl8.6")
9209:         );
9210:     }
9211: 
9212:     /// TP guard — the abstention is `my`-only.  `[self] M` dispatches
9213:     /// through the object's own command, where the capitalised subclass
9214:     /// method is unexported and genuinely unreachable (the same reach
9215:     /// split as `my varname` vs `[self] varname`, tclsh 9.0.4), so the
9216:     /// identical template shape keeps its W308 on the `[self]` spelling.
9217:     #[test]
9218:     fn self_command_dispatch_to_a_subclass_method_still_draws_w308() {
9219:         let src = "oo::class create Base {\n\
9220:                    \x20   method run {} { [self] Render }\n\
9221:                    }\n\
9222:                    oo::class create Concrete {\n\
9223:                    \x20   superclass Base\n\
9224:                    \x20   method Render {} { return ok }\n\
9225:                    }\n";
9226:         assert!(
9227:             fires(src, "tcl8.6", "W308"),
9228:             "[self] cannot reach an unexported subclass method: {:?}",
9229:             codes(src, "tcl8.6")
9230:         );
9231:     }
9232: 
9233:     /// Baseline stays intact: with no subclass in the index at all, an
9234:     /// unresolved `my` dispatch is still a warning — the pattern needs
9235:     /// evidence, and a single-file view of only the base class has none.
9236:     #[test]
9237:     fn my_dispatch_with_no_subclass_in_view_still_draws_w308() {
9238:         let src = "oo::class create Base {\n\
9239:                    \x20   method run {} { my Render }\n\
9240:                    }\n";
9241:         assert!(
9242:             fires(src, "tcl8.6", "W308"),
9243:             "no defining subclass in view: {:?}",
9244:             codes(src, "tcl8.6")
9245:         );
9246:     }
9247: 
9248:     /// The cross-file half (the ruff corpus's actual shape): the defining
9249:     /// subclass lives in another document, delivered as the host-injected
9250:     /// [`SubclassProvidedMethods`] view.  Same source as the test above —
9251:     /// the view is the only difference, so together they pin that the
9252:     /// abstention keys on the evidence, not the source shape.
9253:     #[test]
9254:     fn an_injected_workspace_subclass_view_clears_the_w308() {
9255:         use tcl_compiler::analyser::{Analyser, SubclassProvidedMethods};
9256:         let src = "oo::class create Base {\n\
9257:                    \x20   method run {} { my Render }\n\
9258:                    \x20   method oops {} { my Rendr }\n\
9259:                    }\n";
9260:         let mut view = SubclassProvidedMethods::new();
9261:         view.entry("::Base".to_owned())
9262:             .or_default()
9263:             .insert("Render".to_owned());
9264:         let mut analyser =
9265:             Analyser::new().with_workspace_subclass_methods(Some(std::sync::Arc::new(view)));
9266:         let result = analyser.analyse(src, "tcl8.6");
9267:         let w308_methods: Vec<&str> = result
9268:             .diagnostics
9269:             .iter()
9270:             .filter(|d| d.code.to_string() == "W308")
9271:             .filter_map(|d| {
9272:                 d.message
9273:                     .split_once('\'')
9274:                     .and_then(|(_, rest)| rest.split_once('\''))
9275:                     .map(|(name, _)| name)
9276:             })
9277:             .collect();
9278:         assert_eq!(
9279:             w308_methods,
9280:             vec!["Rendr"],
9281:             "the injected view clears 'Render' and leaves the typo: {:?}",
9282:             result.diagnostics
9283:         );
9284:     }
9285: }
9286: 
9287: // ── Pack-declared transitions and special variables ─────────────────────────
9288: 
9289: mod pack_declared_transitions {
9290:     use super::*;
9291: 
9292:     /// Load `source` as a workspace pack and return an analyser bound to the
9293:     /// registry generation it installs — the path the language server takes
9294:     /// for a document under `.tcl-lsp/`.
9295:     fn analyser_with_pack(source: &str) -> Analyser {
9296:         let packs = tcl_spectcl::pack::load_in_memory(vec![(
9297:             tcl_spectcl::PackFile {
9298:                 tier: tcl_spectcl::Tier::Workspace,
9299:                 path: std::path::PathBuf::from("/workspace/.tcl-lsp/scoped.tclspec"),
9300:                 origin: tcl_spectcl::discovery::Origin::DotDir,
9301:                 dependency_tier: None,
9302:             },
9303:             source.to_owned(),
9304:         )]);
9305:         let _registry = tcl_spectcl::install::registry_for_dialect_with_packs(D, &packs);
9306:         Analyser::new().with_pack_overlay(packs.key)
9307:     }
9308: 
9309:     /// A command no shipped registry knows, crossing frames exactly as
9310:     /// `upvar` does: its `frame_effect` is `upvar`'s, and its
9311:     /// `state_transitions` resolver derives the alias facts from it.
9312:     const LINKER_PACK: &str = "speclib scoped 1.0 {\n\
9313:         \x20   command scoped_link {\n\
9314:         \x20       arity 2..\n\
9315:         \x20       frame_effect -level-word ArityParity -layout AliasPairs\n\
9316:         \x20       state_transitions {\n\
9317:         \x20           argument_shape Positional\n\
9318:         \x20           resolver from-frame-effect\n\
9319:         \x20           widen -operands EveryArgument -domains {VariableCells VariableTraces}\n\
9320:         \x20           commit MayCommitBeforeAbruptCompletion\n\
9321:         \x20       }\n\
9322:         \x20   }\n\
9323:         }\n";
9324: 
9325:     /// The analyser binds a pack command's alias facts as it binds
9326:     /// `upvar`'s — it reads the invocation's transitions, never the
9327:     /// command's name: `scoped_link #0 counter c` defines `c` and links it to the
9328:     /// global cell. Negative: with a computed level word the derived
9329:     /// resolver abstains for the whole call (the shipped `upvar` would state
9330:     /// its alias with an unknown frame), so nothing binds.
9331:     #[test]
9332:     fn a_pack_declared_scope_alias_binds_its_local() {
9333:         let bound = analyser_with_pack(LINKER_PACK).analyse(
9334:             "proc p {} {\n    scoped_link #0 counter c\n    return $c\n}\n",
9335:             D,
9336:         );
9337:         let proc_scope = &bound.global_scope.children[0];
9338:         let c = proc_scope
9339:             .variables
9340:             .get("c")
9341:             .unwrap_or_else(|| panic!("`c` is bound: {:?}", proc_scope.variables.keys()));
9342:         assert_eq!(c.link_target.as_deref(), Some("::counter"));
9343:         assert!(!c.warn_if_unused);
9344: 
9345:         let unbound = analyser_with_pack(LINKER_PACK)
9346:             .analyse("proc p {lvl} {\n    scoped_link $lvl counter c\n}\n", D);
9347:         assert!(
9348:             !unbound.global_scope.children[0].variables.contains_key("c"),
9349:             "a computed level word binds nothing"
9350:         );
9351:     }
9352: 
9353:     /// A pack command whose grammar gives one clause two `LoopVarList`
9354:     /// slots — the shipped `catch` shape — with no `arg` rows stating them
9355:     /// again as flat roles, so the clause is the only place they are named.
9356:     const TWO_LISTS_PACK: &str = "speclib twolists 2.1 {\n\
9357:         \x20   command cmd {\n\
9358:         \x20       arity 1..3\n\
9359:         \x20       clause_grammar {\n\
9360:         \x20           head {Body} -timing protected\n\
9361:         \x20           tail {{LoopVarList optional} {LoopVarList optional}}\n\
9362:         \x20       }\n\
9363:         \x20   }\n\
9364:         }\n";
9365: 
9366:     /// The generic tail binds every variable-list operand a clause fills,
9367:     /// not only the first: `cmd {} a b` binds `a` and `b`. Negative: the
9368:     /// optional second slot left unfilled binds nothing more.
9369:     #[test]
9370:     fn a_clause_with_two_variable_lists_binds_both() {
9371:         let both = analyser_with_pack(TWO_LISTS_PACK).analyse("cmd {} a b\n", D);
9372:         for name in ["a", "b"] {
9373:             assert!(
9374:                 both.global_scope.variables.contains_key(name),
9375:                 "`{name}` is bound: {:?}",
9376:                 both.global_scope.variables.keys().collect::<Vec<_>>()
9377:             );
9378:         }
9379:         let one = analyser_with_pack(TWO_LISTS_PACK).analyse("cmd {} a\n", D);
9380:         assert!(one.global_scope.variables.contains_key("a"));
9381:         assert_eq!(
9382:             one.global_scope.variables.len(),
9383:             1,
9384:             "{:?}",
9385:             one.global_scope.variables.keys().collect::<Vec<_>>()
9386:         );
9387:     }
9388: 
9389:     /// A pack declaring an interpreter-provided global bound at startup.
9390:     const HOST_PACK: &str = "speclib hosted 2.1 {\n\
9391:         \x20   special_var sim_home -kind Scalar -access ReadOnly -origin Dialect -startup Interpreter\n\
9392:         \x20   special_var sim_opts -kind Array -access ReadWrite -origin Environment\n\
9393:         }\n";
9394: 
9395:     /// A pack's `special_var` row reaches the registry generation the
9396:     /// analyser walks under through the one door every reader asks
9397:     /// (`CommandRegistry::special_vars`), with the facts the shipped table
9398:     /// states: `sim_home` is readable before user code, `sim_opts` exists but
9399:     /// is not. Negative: the generation without the pack knows neither.
9400:     #[test]
9401:     fn a_pack_declared_special_variable_is_readable_at_startup() {
9402:         let packs = tcl_spectcl::pack::load_in_memory(vec![(
9403:             tcl_spectcl::PackFile {
9404:                 tier: tcl_spectcl::Tier::Workspace,
9405:                 path: std::path::PathBuf::from("/workspace/.tcl-lsp/hosted.tclspec"),
9406:                 origin: tcl_spectcl::discovery::Origin::DotDir,
9407:                 dependency_tier: None,
9408:             },
9409:             HOST_PACK.to_owned(),
9410:         )]);
9411:         assert!(
9412:             !packs.is_empty(),
9413:             "a pack of special variables is not empty"
9414:         );
9415:         let overlaid = tcl_spectcl::install::registry_for_dialect_with_packs(D, &packs);
9416:         let query = Some(tcl_dialect::model::SurfaceQuery::core(
9417:             tcl_dialect::model::Family::Tcl,
9418:             "8.6",
9419:         ));
9420:         assert!(overlaid.is_readable_at_startup("sim_home", query));
9421:         assert!(overlaid.special_var_in_dialect("sim_opts", query).is_some());
9422:         assert!(!overlaid.is_readable_at_startup("sim_opts", query));
9423:         // The shipped rows still answer through the same door.
9424:         assert!(overlaid.is_readable_at_startup("tcl_version", query));
9425: 
9426:         let plain = tcl_spectcl::install::registry_for_dialect_with_packs(
9427:             D,
9428:             &tcl_spectcl::PackSet::default(),
9429:         );
9430:         assert!(plain.special_var("sim_home").is_none());
9431:         assert!(!plain.is_readable_at_startup("sim_home", query));
9432:     }
9433: }
