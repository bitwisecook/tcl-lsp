/* ORIGINAL_SOURCE_RANGE 670..681 */
670: #[cfg(test)]
671: pub(crate) fn local_instance_classes(
672:     cfg: &CfgFunction,
673:     registry: &CommandRegistry,
674: ) -> LocalInstanceClasses {
675:     local_instance_classes_with_source(
676:         cfg,
677:         registry,
678:         &InstanceClassState::new(),
679:         TaintSourceContext::standalone(registry, registry.profile()),
680:     )
681: }
/* ORIGINAL_SOURCE_RANGE 800..803 */
800: #[cfg(test)]
801: std::thread_local! {
802:     static INSTANCE_CLASS_SOLVES: std::cell::Cell<usize> = const { std::cell::Cell::new(0) };
803: }
/* ORIGINAL_SOURCE_RANGE 805..808 */
805: #[cfg(test)]
806: pub(crate) fn reset_instance_class_solve_count() {
807:     INSTANCE_CLASS_SOLVES.with(|count| count.set(0));
808: }
/* ORIGINAL_SOURCE_RANGE 810..813 */
810: #[cfg(test)]
811: pub(crate) fn instance_class_solve_count() -> usize {
812:     INSTANCE_CLASS_SOLVES.with(std::cell::Cell::get)
813: }
/* ORIGINAL_SOURCE_RANGE 825..826 */
825:     #[cfg(test)]
826:     INSTANCE_CLASS_SOLVES.with(|count| count.set(count.get() + 1));
/* ORIGINAL_SOURCE_RANGE 918..932 */
918: #[cfg(test)]
919: fn compiler_colour(c: TaintColour) -> tcl_registry::TaintColour {
920:     let mut out = tcl_registry::TaintColour::empty();
921:     for atom in TaintColourAtom::ALL {
922:         if c.contains(compiler_colour_atom(atom)) {
923:             out |= atom.colour();
924:         }
925:     }
926:     assert_eq!(
927:         out.bits(),
928:         c.bits(),
929:         "compiler and registry TaintColour definitions must stay aligned"
930:     );
931:     out
932: }
/* ORIGINAL_SOURCE_RANGE 2802..2813 */
2802: #[cfg(test)]
2803: fn arg_var_names(arg: &str, braced_var: tcl_dialect::BracedVarStyle) -> HashSet<String> {
2804:     let config = tcl_lexer::LexerConfig {
2805:         braced_var,
2806:         ..tcl_lexer::LexerConfig::default()
2807:     };
2808:     arg_var_names_with_config(arg, config)
2809:         .names()
2810:         .iter()
2811:         .cloned()
2812:         .collect()
2813: }
/* ORIGINAL_SOURCE_RANGE 3262..3269 */
3262: #[cfg(test)]
3263: fn find_taint_warnings_for_cu_base(
3264:     cu: &crate::compilation_unit::CompilationUnit,
3265:     registry: &CommandRegistry,
3266:     dialect: Option<&'static tcl_dialect::DialectProfile>,
3267: ) -> Vec<TaintWarning> {
3268:     find_taint_warnings_for_cu_base_with_external_variable_seeds(cu, registry, dialect, None)
3269: }
/* ORIGINAL_SOURCE_RANGE 3276..3290 */
3276: #[cfg(test)]
3277: fn find_taint_warnings_for_cu_base_with_external_variable_seeds(
3278:     cu: &crate::compilation_unit::CompilationUnit,
3279:     registry: &CommandRegistry,
3280:     dialect: Option<&'static tcl_dialect::DialectProfile>,
3281:     external_variable_seeds: Option<&HashMap<String, TaintLattice>>,
3282: ) -> Vec<TaintWarning> {
3283:     taint_warning_report_for_cu_base_with_external_variable_seeds(
3284:         cu,
3285:         registry,
3286:         dialect,
3287:         external_variable_seeds,
3288:     )
3289:     .warnings
3290: }
/* ORIGINAL_SOURCE_RANGE 3407..3413 */
3407: #[cfg(test)]
3408: std::thread_local! {
3409:     /// Number of synthetic compilation units built by one warning pass.
3410:     static CALLBACK_REPLAY_BUILDS: std::cell::Cell<usize> = const { std::cell::Cell::new(0) };
3411:     /// Number of source scans used to reserve synthetic replay identifiers.
3412:     static CALLBACK_REPLAY_NAME_SEARCHES: std::cell::Cell<usize> = const { std::cell::Cell::new(0) };
3413: }
/* ORIGINAL_SOURCE_RANGE 3415..3418 */
3415: #[cfg(test)]
3416: fn reset_callback_replay_build_count() {
3417:     CALLBACK_REPLAY_BUILDS.with(|count| count.set(0));
3418: }
/* ORIGINAL_SOURCE_RANGE 3420..3423 */
3420: #[cfg(test)]
3421: fn callback_replay_build_count() -> usize {
3422:     CALLBACK_REPLAY_BUILDS.with(std::cell::Cell::get)
3423: }
/* ORIGINAL_SOURCE_RANGE 3425..3428 */
3425: #[cfg(test)]
3426: fn reset_callback_replay_name_search_count() {
3427:     CALLBACK_REPLAY_NAME_SEARCHES.with(|count| count.set(0));
3428: }
/* ORIGINAL_SOURCE_RANGE 3430..3433 */
3430: #[cfg(test)]
3431: fn callback_replay_name_search_count() -> usize {
3432:     CALLBACK_REPLAY_NAME_SEARCHES.with(std::cell::Cell::get)
3433: }
/* ORIGINAL_SOURCE_RANGE 3448..3449 */
3448:     #[cfg(test)]
3449:     CALLBACK_REPLAY_NAME_SEARCHES.with(|count| count.set(count.get() + 1));
/* ORIGINAL_SOURCE_RANGE 3545..3553 */
3545: #[cfg(test)]
3546: fn find_callback_substitution_warnings(
3547:     cu: &crate::compilation_unit::CompilationUnit,
3548:     registry: &CommandRegistry,
3549:     dialect: Option<&'static tcl_dialect::DialectProfile>,
3550:     baseline: &[TaintWarning],
3551: ) -> Vec<TaintWarning> {
3552:     taint_callback_substitution_report(cu, registry, dialect, baseline).warnings
3553: }
/* ORIGINAL_SOURCE_RANGE 3801..3802 */
3801:         #[cfg(test)]
3802:         CALLBACK_REPLAY_BUILDS.with(|count| count.set(count.get() + 1));
/* ORIGINAL_SOURCE_RANGE 4318..4355 */
4318: #[cfg(test)]
4319: #[must_use]
4320: fn shadowed_builtin_names<'a>(
4321:     namespace: &str,
4322:     proc_qnames: impl Iterator<Item = &'a str>,
4323:     registry: &CommandRegistry,
4324: ) -> HashSet<String> {
4325:     /// `qname`'s bare tail when it sits directly under `ns_prefix` (e.g.
4326:     /// `"::foo::"` or the global `"::"`) — `None` for a name that's either
4327:     /// outside `ns_prefix` or in one of ITS OWN nested children.
4328:     fn direct_member<'a>(qname: &'a str, ns_prefix: &str) -> Option<&'a str> {
4329:         let bare = qname.strip_prefix(ns_prefix)?;
4330:         (!bare.is_empty() && !bare.contains("::")).then_some(bare)
4331:     }
4332: 
4333:     let ns_norm = crate::naming::normalise_qualified_name(namespace);
4334:     let own_prefix = if ns_norm == "::" {
4335:         "::".to_owned()
4336:     } else {
4337:         format!("{ns_norm}::")
4338:     };
4339:     let is_global = own_prefix == "::";
4340: 
4341:     let mut out = HashSet::new();
4342:     for q in proc_qnames {
4343:         let bare = match direct_member(q, &own_prefix) {
4344:             Some(bare) => Some(bare),
4345:             None if is_global => None,
4346:             None => direct_member(q, "::"),
4347:         };
4348:         if let Some(bare) = bare
4349:             && registry.get(bare).is_some()
4350:         {
4351:             out.insert(bare.to_owned());
4352:         }
4353:     }
4354:     out
4355: }
/* ORIGINAL_SOURCE_RANGE 8341..14097 */
8341: #[cfg(test)]
8342: mod tests {
8343:     #[test]
8344:     fn original_module_sink_candidates_keep_conditional_source_and_refuse_foreign_owners() {
8345:         let environment = tcl_registry::model::ingress::resolve_environment("tcl8.6");
8346:         let context = environment.default_context_registry();
8347:         let registry = context.commands();
8348:         let profile = environment.unit_profile();
8349:         let config = tcl_lexer::LexerConfig::for_profile(Some(profile));
8350:         let input = crate::analyser::ResolvedAnalysisInput::new(
8351:             profile,
8352:             profile,
8353:             std::sync::Arc::clone(&context),
8354:             config,
8355:         );
8356:         let build = |source| {
8357:             crate::compilation_unit::CompilationUnit::build_with_analysis_input(
8358:                 source,
8359:                 crate::compilation_unit::UnitBuildOptions {
8360:                     registry,
8361:                     defer_top_level: false,
8362:                     config,
8363:                     dialect: Some(profile),
8364:                     external_call_sites: None,
8365:                     declared_commands: None,
8366:                 },
8367:                 None,
8368:                 &input,
8369:             )
8370:             .with_interprocedural(registry, Some(profile))
8371:         };
8372:         let source = "proc pass {x} {return $x}; proc danger {} {set u [gets stdin]; set p [pass $u]; exec $p}";
8373:         let unit = build(source);
8374:         let (body, procedure) = unit
8375:             .ir_module
8376:             .original_source_procedure_bodies()
8377:             .find(|(_, procedure)| {
8378:                 procedure
8379:                     .body_source
8380:                     .as_deref()
8381:                     .is_some_and(|source| source.contains("exec $p"))
8382:             })
8383:             .unwrap();
8384:         assert_eq!(
8385:             procedure.body_kind,
8386:             crate::ir::ProcedureBodyKind::OriginalDeclaration
8387:         );
8388:         assert!(!unit.ir_module.procedures.contains_key(body));
8389:         assert!(unit.ir_module.source_entry.native_entry.is_none());
8390:         let warnings = |unit: &crate::compilation_unit::CompilationUnit,
8391:                         registry: &CommandRegistry| {
8392:             let solved =
8393:                 crate::taint_interproc::solve_interprocedural_taints(unit, registry, Some(profile));
8394:             let mut warnings = Vec::new();
8395:             let _ = crate::compiler_checks::push_taint_and_module_checks(
8396:                 unit,
8397:                 registry,
8398:                 Some(profile),
8399:                 &solved,
8400:                 None,
8401:                 &mut warnings,
8402:             );
8403:             warnings
8404:         };
8405:         assert!(
8406:             warnings(&unit, registry)
8407:                 .iter()
8408:                 .any(|warning| warning.code == DiagCode::T100)
8409:         );
8410:         let mut missing = unit.clone();
8411:         missing.ir_module.retained_source_bindings = None;
8412:         assert!(
8413:             !warnings(&missing, registry)
8414:                 .iter()
8415:                 .any(|warning| warning.code == DiagCode::T100)
8416:         );
8417:         let mut changed = unit.clone();
8418:         changed.ir_module.source = tcl_lexer::SourceImage::document("proc danger {} {return SAFE}");
8419:         assert!(
8420:             !warnings(&changed, registry)
8421:                 .iter()
8422:                 .any(|warning| warning.code == DiagCode::T100)
8423:         );
8424:         let foreign = tcl_registry::model::ingress::static_context_for("tcl9.0").commands();
8425:         assert!(
8426:             !warnings(&unit, foreign)
8427:                 .iter()
8428:                 .any(|warning| warning.code == DiagCode::T100)
8429:         );
8430:         let shadowed =
8431:             build("proc exec args {return SAFE}; proc danger {} {set u [gets stdin]; exec $u}");
8432:         assert!(
8433:             !warnings(&shadowed, registry)
8434:                 .iter()
8435:                 .any(|warning| warning.code == DiagCode::T100)
8436:         );
8437:     }
8438: 
8439:     use super::*;
8440:     use crate::sccp::SccpResult;
8441:     use tcl_dialect::model::{Family, SurfaceLayer};
8442: 
8443:     #[test]
8444:     fn original_instance_receiver_names_preserve_head_kind_and_actual_grammar() {
8445:         let classes = LocalInstanceClasses {
8446:             at: HashMap::from([(
8447:                 42,
8448:                 HashMap::from([
8449:                     ("$literal".into(), HashSet::from(["LiteralClass".into()])),
8450:                     ("${literal}".into(), HashSet::from(["BraceClass".into()])),
8451:                     ("literal".into(), HashSet::from(["ReferenceClass".into()])),
8452:                     ("".into(), HashSet::from(["EmptyClass".into()])),
8453:                     ("arr".into(), HashSet::from(["ScalarClass".into()])),
8454:                     ("arr(key)".into(), HashSet::from(["CommandClass".into()])),
8455:                     ("a{b}c".into(), HashSet::from(["NestedClass".into()])),
8456:                 ]),
8457:             )]),
8458:         };
8459:         for label in ["tcl8.6", "tcl9.1"] {
8460:             let registry = tcl_registry::model::ingress::static_context_for(label).commands();
8461:             let config = TaintSourceContext::standalone(registry, registry.profile()).config;
8462:             for (source, expected) in [
8463:                 ("{$literal}", "LiteralClass"),
8464:                 ("{${literal}}", "BraceClass"),
8465:                 ("$literal", "ReferenceClass"),
8466:                 ("${$literal}", "LiteralClass"),
8467:                 ("{}", "EmptyClass"),
8468:                 ("${}", "EmptyClass"),
8469:                 ("arr(key)", "CommandClass"),
8470:             ] {
8471:                 let word = crate::value_shapes::value_word_with_config(source, config).unwrap();
8472:                 assert_eq!(
8473:                     unique_instance_class(Some((&word, config)), Some(&classes), Some(42)),
8474:                     Some(expected),
8475:                     "{label}: {source}"
8476:                 );
8477:                 assert!(
8478:                     unique_instance_class(Some((&word, config)), Some(&classes), Some(43))
8479:                         .is_none()
8480:                 );
8481:             }
8482:             for source in [
8483:                 "$arr(key)",
8484:                 "${arr(key)}",
8485:                 "prefix$literal",
8486:                 "[pick]",
8487:                 "{*}{literal}",
8488:                 "${nul\0name}",
8489:             ] {
8490:                 let word = crate::value_shapes::value_word_with_config(source, config).unwrap();
8491:                 assert!(
8492:                     unique_instance_class(Some((&word, config)), Some(&classes), Some(42))
8493:                         .is_none(),
8494:                     "{label}: {source}"
8495:                 );
8496:             }
8497:             let nested = crate::value_shapes::value_word_with_config("${a{b}c}", config).unwrap();
8498:             assert_eq!(
8499:                 unique_instance_class(Some((&nested, config)), Some(&classes), Some(42)),
8500:                 if label == "tcl9.1" {
8501:                     Some("NestedClass")
8502:                 } else {
8503:                     None
8504:                 }
8505:             );
8506:         }
8507:         assert!(unique_instance_class(None, Some(&classes), Some(42)).is_none());
8508:     }
8509: 
8510:     #[test]
8511:     fn configured_word_taint_keeps_literal_reference_names_and_index_reads() {
8512:         for label in ["tcl8.6", "tcl9.1"] {
8513:             let registry = tcl_registry::model::ingress::static_context_for(label).commands();
8514:             let cfg = crate::cfg::Function::new("model", "entry");
8515:             let mut ssa = SsaFunction::trivial("model", cfg.entry, cfg.block_names().to_vec());
8516:             let mut uses = HashMap::new();
8517:             let mut taints = HashMap::new();
8518:             for (name, tainted) in [
8519:                 ("literal", false),
8520:                 ("$literal", true),
8521:                 ("", true),
8522:                 ("arr", false),
8523:                 ("index", true),
8524:                 ("a{b", false),
8525:                 ("a{b}c", true),
8526:             ] {
8527:                 let symbol = ssa.intern_var(name);
8528:                 uses.insert(symbol, 1);
8529:                 taints.insert(
8530:                     (symbol, 1),
8531:                     if tainted {
8532:                         TaintLattice::tainted()
8533:                     } else {
8534:                         TaintLattice::clean()
8535:                     },
8536:                 );
8537:             }
8538:             let ctx = TaintCtx {
8539:                 registry,
8540:                 ssa: &ssa,
8541:                 interproc: None,
8542:                 known_procs: None,
8543:                 dialect: registry.profile(),
8544:                 source: TaintSourceContext::standalone(registry, registry.profile()),
8545:                 taint_summaries: None,
8546:                 instance_classes: None,
8547:                 source_position: None,
8548:                 source_tokens: None,
8549:                 word_offset: None,
8550:                 source_word: None,
8551:             };
8552:             for (word, tainted) in [
8553:                 ("$literal", false),
8554:                 ("${$literal}", true),
8555:                 ("${}", true),
8556:                 ("prefix${$literal}", true),
8557:                 (r"prefix\$literal", false),
8558:                 ("$arr($index)", true),
8559:                 ("[missing $literal", true),
8560:             ] {
8561:                 assert_eq!(
8562:                     word_taint(word, &uses, &taints, ctx).is_tainted(),
8563:                     tainted,
8564:                     "{label}: {word}"
8565:                 );
8566:             }
8567:             assert_eq!(
8568:                 word_taint("${a{b}c}", &uses, &taints, ctx).is_tainted(),
8569:                 label == "tcl9.1"
8570:             );
8571:             assert!(!word_taint(r"prefix\[gets stdin\]", &uses, &taints, ctx).is_tainted());
8572:         }
8573:     }
8574: 
8575:     #[test]
8576:     fn incr_taint_uses_the_selected_definition_name_without_reparsing_data() {
8577:         let registry = tcl_registry::model::ingress::static_context_for("tcl8.6").commands();
8578:         let cfg = crate::cfg::Function::new("model", "entry");
8579:         let mut ssa = SsaFunction::trivial("model", cfg.entry, cfg.block_names().to_vec());
8580:         let literal = ssa.intern_var("$literal");
8581:         let stripped = ssa.intern_var("literal");
8582:         let uses = HashMap::from([(literal, 1), (stripped, 1)]);
8583:         let taints = HashMap::from([
8584:             ((literal, 1), TaintLattice::tainted()),
8585:             ((stripped, 1), TaintLattice::clean()),
8586:         ]);
8587:         let ctx = TaintCtx {
8588:             registry,
8589:             ssa: &ssa,
8590:             interproc: None,
8591:             known_procs: None,
8592:             dialect: registry.profile(),
8593:             source: TaintSourceContext::standalone(registry, registry.profile()),
8594:             taint_summaries: None,
8595:             instance_classes: None,
8596:             source_position: None,
8597:             source_tokens: None,
8598:             word_offset: None,
8599:             source_word: None,
8600:         };
8601:         let statement = Statement::Incr {
8602:             span: Span::new(0, 0),
8603:             name: "$literal".into(),
8604:             name_braced: true,
8605:             amount: None,
8606:             amount_braced: false,
8607:             safe_on_uninit: false,
8608:         };
8609:         assert!(evaluate_taint_def(&statement, literal, &uses, &taints, ctx, &ssa).is_tainted());
8610:         assert!(
8611:             evaluate_taint_def(&statement, literal, &HashMap::new(), &taints, ctx, &ssa)
8612:                 .is_tainted()
8613:         );
8614:     }
8615: 
8616:     #[test]
8617:     fn unrepresented_variable_contents_have_no_clean_taint_proof() {
8618:         let registry = tcl_registry::model::ingress::static_context_for("tcl8.6").commands();
8619:         let unit = crate::compilation_unit::CompilationUnit::build_for(
8620:             "set represented SAFE",
8621:             registry,
8622:             false,
8623:         );
8624:         let symbol = unit.top_level.ssa.var_symbol("represented").unwrap();
8625:         let uses = HashMap::from([(symbol, 0)]);
8626:         let taints = HashMap::<ValueKey, TaintLattice>::new();
8627:         assert!(var_taint("unrepresented", &uses, &taints, &unit.top_level.ssa).is_tainted());
8628:         assert!(!var_taint("represented", &uses, &taints, &unit.top_level.ssa).is_tainted());
8629:         assert!(
8630:             var_taint("represented", &HashMap::new(), &taints, &unit.top_level.ssa).is_tainted()
8631:         );
8632:         assert!(unit.top_level.ssa.var_symbol("unrepresented").is_none());
8633:     }
8634: 
8635:     #[test]
8636:     fn original_operand_reference_names_keep_data_and_current_grammar_without_ssa_grants() {
8637:         for label in ["tcl8.6", "tcl9.1"] {
8638:             let registry = tcl_registry::model::ingress::static_context_for(label).commands();
8639:             let source = TaintSourceContext::standalone(registry, registry.profile());
8640:             let cfg = crate::cfg::Function::new("model", "entry");
8641:             let ssa = SsaFunction::trivial("model", cfg.entry, cfg.block_names().to_vec());
8642:             let uses = HashMap::new();
8643:             let taints = HashMap::<ValueKey, TaintLattice>::new();
8644:             let env = TaintScan {
8645:                 uses: &uses,
8646:                 taints: &taints,
8647:                 ssa: &ssa,
8648:                 quoted_uses: None,
8649:                 source_read: None,
8650:                 source,
8651:             };
8652:             for (reference, name) in [
8653:                 ("${$literal}", "$literal"),
8654:                 ("${}", ""),
8655:                 ("${arr($literal)}", "arr"),
8656:             ] {
8657:                 let word =
8658:                     crate::value_shapes::value_word_with_config(reference, source.config).unwrap();
8659:                 assert!(
8660:                     operand_read_taint(&env, name, Some(&word))
8661:                         .is_some_and(TaintLattice::is_tainted)
8662:                 );
8663:                 assert!(operand_read_taint(&env, "donated", Some(&word)).is_none());
8664:                 assert!(ssa.var_symbol(name).is_none());
8665:             }
8666:             assert_eq!(
8667:                 reference_root_with_config("${a{b}c}", source.config),
8668:                 if label == "tcl9.1" {
8669:                     Some("a{b}c")
8670:                 } else {
8671:                     None
8672:                 }
8673:             );
8674:             for unavailable in [
8675:                 "prefix${literal}",
8676:                 r"\$literal",
8677:                 "${literal",
8678:                 "${literal\0tail}",
8679:             ] {
8680:                 assert!(reference_root_with_config(unavailable, source.config).is_none());
8681:             }
8682:         }
8683:     }
8684: 
8685:     #[test]
8686:     fn original_sink_read_keeps_missing_ssa_contents_unknown() {
8687:         let registry = tcl_registry::model::ingress::static_context_for("tcl8.6").commands();
8688:         for (source, expected) in [
8689:             ("regexp $missing test", true),
8690:             ("regexp {$missing} test", false),
8691:         ] {
8692:             let unit = crate::compilation_unit::CompilationUnit::build_for(source, registry, false);
8693:             let tokens = unit
8694:                 .top_level
8695:                 .cfg
8696:                 .blocks
8697:                 .values()
8698:                 .flat_map(|block| &block.statements)
8699:                 .find_map(Statement::tokens)
8700:                 .unwrap();
8701:             let uses = HashMap::new();
8702:             let taints = HashMap::<ValueKey, TaintLattice>::new();
8703:             let env = TaintScan {
8704:                 uses: &uses,
8705:                 taints: &taints,
8706:                 ssa: &unit.top_level.ssa,
8707:                 quoted_uses: None,
8708:                 source_read: None,
8709:                 source: TaintSourceContext::for_function(registry, &unit.top_level),
8710:             };
8711:             assert_eq!(
8712:                 operand_read_taint(&env, "missing", tokens.words().get(1))
8713:                     .is_some_and(TaintLattice::is_tainted),
8714:                 expected,
8715:                 "{source}"
8716:             );
8717:             assert!(uses.is_empty());
8718:         }
8719:     }
8720: 
8721:     #[test]
8722:     fn native_byte_escapes_cannot_become_unicode_text_provenance() {
8723:         use tcl_dialect::EscapeSyntax;
8724:         assert_eq!(decoded_text_fragment(r"\xff", EscapeSyntax::Jim), None);
8725:         assert_eq!(
8726:             decoded_text_fragment(r"\x41", EscapeSyntax::Jim).as_deref(),
8727:             Some("A")
8728:         );
8729:         assert_eq!(
8730:             decoded_text_fragment(r"\xff", EscapeSyntax::Tcl90).as_deref(),
8731:             Some("ÿ")
8732:         );
8733:     }
8734: 
8735:     #[test]
8736:     fn opaque_native_accesses_withdraw_receiver_and_clean_taint_proofs() {
8737:         let registry = tcl_registry::model::ingress::static_context_for("tcl8.6").commands();
8738:         let mut unit =
8739:             crate::compilation_unit::CompilationUnit::build_for("set value KNOWN", registry, false);
8740:         let native = crate::ir::native_call_for_test(b"opaque \xff");
8741:         unit.top_level
8742:             .cfg
8743:             .blocks
8744:             .get_mut(&unit.top_level.cfg.entry)
8745:             .unwrap()
8746:             .statements
8747:             .push(native.clone());
8748:         let graph = TaintGraph::new(
8749:             &unit.top_level.cfg,
8750:             &unit.top_level.ssa,
8751:             &unit.top_level.sccp,
8752:         );
8753:         let taints = propagate_taints(
8754:             &graph,
8755:             TaintPropagationInputs {
8756:                 registry,
8757:                 rendered_props: None,
8758:                 interproc: None,
8759:                 source: TaintSourceContext::standalone(registry, registry.profile()),
8760:                 param_taints: None,
8761:                 taint_summaries: None,
8762:                 instance_classes: &LocalInstanceClasses::default(),
8763:             },
8764:         );
8765:         let keys: Vec<_> = unit
8766:             .top_level
8767:             .ssa
8768:             .blocks
8769:             .values()
8770:             .flat_map(|block| &block.statements)
8771:             .flat_map(|statement| {
8772:                 statement
8773:                     .defs
8774:                     .iter()
8775:                     .map(|(&symbol, &version)| (symbol, version))
8776:             })
8777:             .collect();
8778:         assert!(!keys.is_empty());
8779:         assert!(
8780:             keys.iter()
8781:                 .all(|key| taints.get(key) == Some(&TaintLattice::tainted()))
8782:         );
8783:         let mut classes = HashMap::from([("widget".into(), HashSet::from(["Entry".into()]))]);
8784:         transfer_instance_statement(
8785:             &mut classes,
8786:             &native,
8787:             registry,
8788:             TaintSourceContext::for_input(registry, None, tcl_lexer::LexerConfig::default()),
8789:             None,
8790:         );
8791:         assert!(classes.is_empty());
8792:     }
8793: 
8794:     #[test]
8795:     fn alias_prefix_values_and_braced_literals_do_not_resubstitute_variables() {
8796:         let registry = tcl_registry::model::ingress::static_context_for("tcl8.6").commands();
8797:         for source in [
8798:             "interp alias {} collect {} list {$attacker}\nset value [collect]",
8799:             "set value [list {$attacker}]",
8800:         ] {
8801:             let module = crate::lowering::lower_to_ir(source, registry);
8802:             let (value, tokens) = module
8803:                 .top_level
8804:                 .statements
8805:                 .iter()
8806:                 .rev()
8807:                 .find_map(|statement| {
8808:                     if let Statement::AssignValue {
8809:                         value,
8810:                         tokens: Some(tokens),
8811:                         ..
8812:                     } = statement
8813:                     {
8814:                         Some((value, tokens))
8815:                     } else {
8816:                         None
8817:                     }
8818:                 })
8819:                 .expect("assignment carrier");
8820:             let cfg = crate::cfg::Function::new("::top", "entry");
8821:             let mut ssa =
8822:                 crate::ssa::SsaFunction::trivial("::top", cfg.entry, cfg.block_names().to_vec());
8823:             let attacker = ssa.intern_var("attacker");
8824:             let ctx = TaintCtx {
8825:                 registry,
8826:                 ssa: &ssa,
8827:                 interproc: None,
8828:                 known_procs: None,
8829:                 dialect: registry.profile(),
8830:                 source: TaintSourceContext::standalone(registry, registry.profile()),
8831:                 taint_summaries: None,
8832:                 instance_classes: None,
8833:                 source_position: Some(tokens.argv[0].start()),
8834:                 source_tokens: Some(tokens),
8835:                 word_offset: tokens.argv.last().map(|span| span.start()),
8836:                 source_word: tokens.word_exprs.last(),
8837:             };
8838:             let uses = HashMap::from([(attacker, 1)]);
8839:             let taints = HashMap::from([((attacker, 1), TaintLattice::tainted())]);
8840:             assert!(
8841:                 !word_taint(value, &uses, &taints, ctx).is_tainted(),
8842:                 "{source}"
8843:             );
8844:         }
8845:     }
8846: 
8847:     #[test]
8848:     fn nested_sanitiser_requires_the_actual_point_binding() {
8849:         let registry = tcl_registry::model::ingress::static_context_for("tcl8.6").commands();
8850:         for (source, tainted) in [
8851:             ("set value [string length [gets stdin]]", false),
8852:             (
8853:                 "interp alias {} measure {} string length\nset value [measure [gets stdin]]",
8854:                 false,
8855:             ),
8856:             (
8857:                 "rename string core_string\nproc string args {return [lindex $args end]}\nset value [string length [gets stdin]]",
8858:                 true,
8859:             ),
8860:             (
8861:                 "interp alias {} measure {} string length\nrename string core_string\nproc string args {return [lindex $args end]}\nset value [measure [gets stdin]]",
8862:                 true,
8863:             ),
8864:             (
8865:                 "rename string core_string\nproc string args {return [lindex $args end]}\nset value \"[string length [gets stdin]]\"",
8866:                 true,
8867:             ),
8868:         ] {
8869:             let module = crate::lowering::lower_to_ir(source, registry);
8870:             let (value, tokens) = module
8871:                 .top_level
8872:                 .statements
8873:                 .iter()
8874:                 .rev()
8875:                 .find_map(|statement| {
8876:                     let tokens = statement.tokens()?;
8877:                     Some((tokens.argv_texts.last()?, tokens))
8878:                 })
8879:                 .expect("retained source value carrier");
8880:             let cfg = crate::cfg::Function::new("::top", "entry");
8881:             let ssa =
8882:                 crate::ssa::SsaFunction::trivial("::top", cfg.entry, cfg.block_names().to_vec());
8883:             let ctx = TaintCtx {
8884:                 registry,
8885:                 ssa: &ssa,
8886:                 interproc: None,
8887:                 known_procs: None,
8888:                 dialect: registry.profile(),
8889:                 source: TaintSourceContext::standalone(registry, registry.profile()),
8890:                 taint_summaries: None,
8891:                 instance_classes: None,
8892:                 source_position: Some(tokens.argv[0].start()),
8893:                 source_tokens: Some(tokens),
8894:                 word_offset: tokens.argv.last().map(|span| span.start()),
8895:                 source_word: tokens.word_exprs.last(),
8896:             };
8897:             assert_eq!(
8898:                 word_taint(value, &HashMap::new(), &HashMap::new(), ctx).is_tainted(),
8899:                 tainted,
8900:                 "{source}"
8901:             );
8902:         }
8903:     }
8904: 
8905:     fn measured_source_taint(
8906:         unit: &crate::compilation_unit::CompilationUnit,
8907:         registry: &CommandRegistry,
8908:     ) -> TaintLattice {
8909:         let script = &unit.ir_module.top_level;
8910:         let statement = script.statements.last().expect("source statement");
8911:         let tokens = script
8912:             .retained_source_tokens_for_statement(statement)
8913:             .expect("genuine original source vector");
8914:         let value = tokens.argv_texts.last().expect("original value operand");
8915:         let source =
8916:             TaintSourceContext::for_module_function(registry, &unit.ir_module, &unit.top_level);
8917:         let ctx = TaintCtx {
8918:             registry,
8919:             ssa: &unit.top_level.ssa,
8920:             interproc: None,
8921:             known_procs: None,
8922:             dialect: source.dialect,
8923:             source,
8924:             taint_summaries: None,
8925:             instance_classes: None,
8926:             source_position: tokens.argv.first().map(|span| span.start()),
8927:             source_tokens: Some(tokens),
8928:             word_offset: tokens.argv.last().map(|span| span.start()),
8929:             source_word: tokens.word_exprs.last(),
8930:         };
8931:         word_taint(value, &HashMap::new(), &HashMap::new(), ctx)
8932:     }
8933: 
8934:     fn retained_warning_unit(
8935:         source: &str,
8936:         context: &std::sync::Arc<tcl_registry::model::ContextRegistry>,
8937:     ) -> (tcl_vm::Vm, crate::compilation_unit::CompilationUnit) {
8938:         let profile = tcl_dialect::DialectProfile::find("tcl8.6").unwrap();
8939:         let (owner, native) = crate::environment_ingress::captured_native_entry_with_owner(profile);
8940:         let entry = crate::command_binding::SourceAnalysisEntry {
8941:             native_entry: Some(std::sync::Arc::new(native)),
8942:             invocation_dialect: Some(tcl_registry::InvocationDialect::of_profile(profile)),
8943:             native_compilation: crate::environment_ingress::authoring_native_compilation(),
8944:             ..Default::default()
8945:         };
8946:         let unit = crate::compilation_unit::CompilationUnit::build_with_context_registry(
8947:             source,
8948:             crate::compilation_unit::UnitBuildOptions {
8949:                 registry: context.commands(),
8950:                 defer_top_level: false,
8951:                 config: tcl_lexer::LexerConfig::for_file_grammar(profile.grammar),
8952:                 dialect: Some(profile),
8953:                 external_call_sites: None,
8954:                 declared_commands: None,
8955:             },
8956:             Some(&entry),
8957:             std::sync::Arc::clone(context),
8958:         );
8959:         (owner, unit)
8960:     }
8961: 
8962:     fn source_option_context() -> std::sync::Arc<tcl_registry::model::ContextRegistry> {
8963:         let profile = tcl_dialect::DialectProfile::find("tcl8.6").unwrap();
8964:         let baseline = tcl_registry::model::ingress::static_context_for("tcl8.6");
8965:         let mut catalogue = baseline.commands().project_for_profile(profile);
8966:         let mut descriptor = catalogue.get("regexp").unwrap().clone();
8967:         let options = descriptor
8968:             .options
8969:             .iter()
8970:             .cloned()
8971:             .map(|mut option| {
8972:                 if option.name == "--" {
8973:                     option.surface = Some(tcl_dialect::model::SpecSurface::TCL86_PLUS);
8974:                 }
8975:                 option
8976:             })
8977:             .collect::<Vec<_>>();
8978:         descriptor.options = Box::leak(options.into_boxed_slice());
8979:         catalogue.insert(descriptor);
8980:         std::sync::Arc::new(baseline.with_command_store(std::sync::Arc::new(catalogue)))
8981:     }
8982: 
8983:     #[test]
8984:     fn actual_option_advice_keeps_selected_terminator_availability_and_source_vector() {
8985:         // naming.compiler.original-analysis-metadata-context
8986:         // docs/design/analysis/name-resolution-proofs/original-analysis-metadata-context.md
8987:         // Conditional descriptor/operand admission, independently of the kept
8988:         // Native entry. No regexp handler or option value is executed here.
8989:         let profile = tcl_dialect::DialectProfile::find("tcl8.6").unwrap();
8990:         let current = source_option_context();
8991:         let registry = current.commands();
8992:         let (_owner, unit) = retained_warning_unit("regexp $payload haystack", &current);
8993:         let tokens = unit
8994:             .ir_module
8995:             .top_level
8996:             .statements
8997:             .last()
8998:             .unwrap()
8999:             .tokens()
9000:             .unwrap();
9001:         let source =
9002:             TaintSourceContext::for_module_function(registry, &unit.ir_module, &unit.top_level);
9003:         let (selected, _) =
9004:             crate::registry_invocation::conditional_option_arguments_with_metadata_context(
9005:                 registry,
9006:                 source.metadata.unwrap(),
9007:                 tokens,
9008:             )
9009:             .expect("genuine selected source option layout");
9010:         let args = selected
9011:             .effective
9012:             .argument_spellings(tokens.argv_texts.get(1..).unwrap())
9013:             .unwrap();
9014:         let call = SinkCall {
9015:             source,
9016:             command: &selected.facts.canonical_command,
9017:             args: &args,
9018:             registry,
9019:             tokens: Some(tokens),
9020:             effective: Some(&selected.effective),
9021:             source_read: None,
9022:             argument_offset: 0,
9023:         };
9024:         assert_eq!(
9025:             option_injection_arguments(&call, Some(profile)).unwrap().1,
9026:             [0]
9027:         );
9028:         let input = unit.top_level.source_metadata_input().unwrap();
9029:         let older = std::sync::Arc::new(
9030:             tcl_registry::model::ingress::static_context_for("tcl8.4")
9031:                 .with_command_store(std::sync::Arc::clone(registry)),
9032:         );
9033:         let foreign =
9034:             tcl_registry::model::ingress::resolve_environment("tcl9.1").default_context_registry();
9035:         for context in [Some(older), Some(foreign), None] {
9036:             let changed = context.map(|context| {
9037:                 crate::analyser::ResolvedAnalysisInput::new(
9038:                     input.analyser_profile(),
9039:                     input.unit_profile(),
9040:                     context,
9041:                     input.lexer_config(),
9042:                 )
9043:             });
9044:             let unavailable = SinkCall {
9045:                 source: TaintSourceContext::for_input(registry, changed.as_ref(), source.config),
9046:                 ..call
9047:             };
9048:             assert!(option_injection_arguments(&unavailable, Some(profile)).is_none());
9049:         }
9050:         let mut stale = source.config;
9051:         stale.strict_quoting = !stale.strict_quoting;
9052:         let stale = SinkCall {
9053:             source: TaintSourceContext::for_input(registry, Some(input), stale),
9054:             ..call
9055:         };
9056:         assert!(option_injection_arguments(&stale, Some(profile)).is_none());
9057:         let detached = SinkCall {
9058:             effective: None,
9059:             ..call
9060:         };
9061:         assert!(option_injection_arguments(&detached, Some(profile)).is_none());
9062:     }
9063: 
9064:     #[test]
9065:     fn actual_option_terminator_withdraws_possible_source_positions() {
9066:         // naming.compiler.original-analysis-metadata-context
9067:         // docs/design/analysis/name-resolution-proofs/original-analysis-metadata-context.md
9068:         let current = source_option_context();
9069:         let registry = current.commands();
9070:         let (_terminated_owner, terminated) =
9071:             retained_warning_unit("regexp -- $payload haystack", &current);
9072:         let tokens = terminated
9073:             .ir_module
9074:             .top_level
9075:             .statements
9076:             .last()
9077:             .unwrap()
9078:             .tokens()
9079:             .unwrap();
9080:         let source = TaintSourceContext::for_module_function(
9081:             registry,
9082:             &terminated.ir_module,
9083:             &terminated.top_level,
9084:         );
9085:         let (_, topology) =
9086:             crate::registry_invocation::conditional_option_arguments_with_metadata_context(
9087:                 registry,
9088:                 source.metadata.unwrap(),
9089:                 tokens,
9090:             )
9091:             .unwrap();
9092:         assert!(topology.arguments.is_empty());
9093:     }
9094: 
9095:     fn source_regexp_warnings(
9096:         unit: &crate::compilation_unit::CompilationUnit,
9097:         registry: &CommandRegistry,
9098:         source: TaintSourceContext<'_>,
9099:     ) -> Vec<TaintWarning> {
9100:         let statement = unit.ir_module.top_level.statements.last().unwrap();
9101:         let tokens = statement.tokens().unwrap();
9102:         let uses = HashMap::new();
9103:         let taints: HashMap<ValueKey, TaintLattice> = HashMap::new();
9104:         let scan = TaintScan {
9105:             uses: &uses,
9106:             taints: &taints,
9107:             ssa: &unit.top_level.ssa,
9108:             quoted_uses: None,
9109:             source_read: None,
9110:             source,
9111:         };
9112:         let mut warnings = Vec::new();
9113:         emit_regexp_pattern_warnings(
9114:             &scan,
9115:             statement.span(),
9116:             registry,
9117:             &mut warnings,
9118:             Some(tokens),
9119:             source,
9120:         );
9121:         warnings
9122:     }
9123: 
9124:     #[test]
9125:     fn whole_unit_warning_query_requires_its_retained_positioned_source_owner() {
9126:         // naming.source.retained-positioned-command-realm
9127:         // docs/design/analysis/name-resolution-proofs/retained-positioned-command-realm.md
9128:         // Explicit source ingress supplies the tainted value; no external evaluation is performed.
9129:         let current =
9130:             tcl_registry::model::ingress::resolve_environment("tcl8.6").default_context_registry();
9131:         let registry = current.commands();
9132:         let (_owner, unit) = retained_warning_unit(
9133:             "set payload [gets stdin]\nregexp -- $payload haystack",
9134:             &current,
9135:         );
9136:         let positive = find_taint_warnings_for_cu_base(&unit, registry, None);
9137:         assert!(
9138:             positive
9139:                 .iter()
9140:                 .any(|warning| { warning.code == DiagCode::T103 && warning.variable == "payload" }),
9141:             "the actual original source keeps its warning: {positive:?}"
9142:         );
9143:         let mut missing = unit.clone();
9144:         missing.ir_module.retained_source_bindings = None;
9145:         let mut changed = unit.clone();
9146:         changed.ir_module.source = tcl_lexer::SourceImage::document("regexp -- fixed haystack");
9147:         let mut missing_snapshot = unit.clone();
9148:         missing_snapshot.ir_module.registry_snapshot = None;
9149:         for refused in [missing, changed, missing_snapshot] {
9150:             assert!(find_taint_warnings_for_cu_base(&refused, registry, None).is_empty());
9151:         }
9152:         assert_eq!(
9153:             find_taint_warnings_for_cu_base(&unit, registry, None),
9154:             positive
9155:         );
9156:     }
9157: 
9158:     #[test]
9159:     fn actual_regexp_warning_refuses_missing_and_foreign_source_metadata() {
9160:         // naming.compiler.original-analysis-metadata-context
9161:         // docs/design/analysis/name-resolution-proofs/original-analysis-metadata-context.md
9162:         // A retained literal terminator establishes source pattern topology;
9163:         // the original variable read remains unknown, with no observed value.
9164:         let current =
9165:             tcl_registry::model::ingress::resolve_environment("tcl8.6").default_context_registry();
9166:         let registry = current.commands();
9167:         let (_owner, unit) = retained_warning_unit("regexp -- $payload haystack", &current);
9168:         let source =
9169:             TaintSourceContext::for_module_function(registry, &unit.ir_module, &unit.top_level);
9170:         assert!(
9171:             source_regexp_warnings(&unit, registry, source)
9172:                 .iter()
9173:                 .any(|warning| warning.code == DiagCode::T103 && warning.variable == "payload")
9174:         );
9175:         let missing = TaintSourceContext::for_input(registry, None, source.config);
9176:         assert!(source_regexp_warnings(&unit, registry, missing).is_empty());
9177:         let input = unit.top_level.source_metadata_input().unwrap();
9178:         let foreign = crate::analyser::ResolvedAnalysisInput::new(
9179:             input.analyser_profile(),
9180:             input.unit_profile(),
9181:             tcl_registry::model::ingress::resolve_environment("tcl9.1").default_context_registry(),
9182:             input.lexer_config(),
9183:         );
9184:         let foreign = TaintSourceContext::for_input(registry, Some(&foreign), source.config);
9185:         assert!(source_regexp_warnings(&unit, registry, foreign).is_empty());
9186:         let mut stale = source.config;
9187:         stale.strict_quoting = !stale.strict_quoting;
9188:         let stale = TaintSourceContext::for_input(registry, Some(input), stale);
9189:         assert!(source_regexp_warnings(&unit, registry, stale).is_empty());
9190:         let standalone = TaintSourceContext::standalone(registry, registry.profile());
9191:         assert!(!source_regexp_warnings(&unit, registry, standalone).is_empty());
9192:     }
9193: 
9194:     #[test]
9195:     fn constant_command_head_candidates_use_retained_escape_grammar() {
9196:         // naming.compiler.original-analysis-metadata-context
9197:         // docs/design/analysis/name-resolution-proofs/original-analysis-metadata-context.md
9198:         // SSA source-value candidates only; no command lookup, target identity
9199:         // or actual invocation follows from the decoded presentation value.
9200:         let profile = tcl_dialect::DialectProfile::find("tcl").unwrap();
9201:         let context =
9202:             tcl_registry::model::ingress::resolve_environment("tcl8.6").default_context_registry();
9203:         for (escapes, expected) in [
9204:             (tcl_dialect::EscapeSyntax::Tcl84, "U0001f600"),
9205:             (tcl_dialect::EscapeSyntax::Tcl90, "😀"),
9206:         ] {
9207:             let config = tcl_lexer::LexerConfig {
9208:                 escapes,
9209:                 ..tcl_lexer::LexerConfig::for_file_grammar(profile.grammar)
9210:             };
9211:             let input = crate::analyser::ResolvedAnalysisInput::new(
9212:                 profile,
9213:                 profile,
9214:                 std::sync::Arc::clone(&context),
9215:                 config,
9216:             );
9217:             let unit = crate::compilation_unit::CompilationUnit::build_with_analysis_input(
9218:                 "set command \\U0001f600\n$command argument",
9219:                 crate::compilation_unit::UnitBuildOptions {
9220:                     registry: context.commands(),
9221:                     defer_top_level: false,
9222:                     config,
9223:                     dialect: Some(profile),
9224:                     external_call_sites: None,
9225:                     declared_commands: None,
9226:                 },
9227:                 None,
9228:                 &input,
9229:             );
9230:             let statement = unit.ir_module.top_level.statements.last().unwrap();
9231:             let heads = resolve_taint_command_heads(
9232:                 "$command",
9233:                 statement,
9234:                 None,
9235:                 Some(CommandHeadContext {
9236:                     fu: &unit.top_level,
9237:                     module_traces: crate::compilation_unit::ModuleTraceFacts {
9238:                         traced_variables: &unit.ir_module.traced_variables,
9239:                         has_dynamic_variable_trace: unit.ir_module.has_dynamic_variable_trace,
9240:                         deferred_writes: &crate::ir::NO_DEFERRED_WRITES,
9241:                     },
9242:                     identities: crate::realm::CommandBindingRealm::none(),
9243:                 }),
9244:             );
9245:             assert_eq!(
9246:                 heads
9247:                     .iter()
9248:                     .map(|head| head.command.as_str())
9249:                     .collect::<Vec<_>>(),
9250:                 [expected]
9251:             );
9252:         }
9253:     }
9254: 
9255:     #[test]
9256:     fn actual_taint_lattice_keeps_availability_and_refuses_missing_source_owners() {
9257:         // naming.compiler.original-analysis-metadata-context
9258:         // docs/design/analysis/name-resolution-proofs/original-analysis-metadata-context.md
9259:         // Source-lattice result and owner refusals, with an independently kept
9260:         // Native entry. This test does not execute gets or observe its result.
9261:         let profile = tcl_dialect::DialectProfile::find("tcl8.6").unwrap();
9262:         let baseline = tcl_registry::model::ingress::static_context_for("tcl8.6");
9263:         let mut catalogue = baseline.commands().project_for_profile(profile);
9264:         let mut descriptor = catalogue.get("string").unwrap().clone();
9265:         descriptor.surface = Some(tcl_dialect::model::SpecSurface::TCL86_PLUS);
9266:         catalogue.insert(descriptor);
9267:         let current =
9268:             std::sync::Arc::new(baseline.with_command_store(std::sync::Arc::new(catalogue)));
9269:         let registry = current.commands();
9270:         let (_owner, native) =
9271:             crate::environment_ingress::captured_native_entry_with_owner(profile);
9272:         let entry = crate::command_binding::SourceAnalysisEntry {
9273:             native_entry: Some(std::sync::Arc::new(native)),
9274:             invocation_dialect: Some(tcl_registry::InvocationDialect::of_profile(profile)),
9275:             native_compilation: crate::environment_ingress::authoring_native_compilation(),
9276:             ..Default::default()
9277:         };
9278:         let mut unit = crate::compilation_unit::CompilationUnit::build_with_context_registry(
9279:             "set measured [string length [gets stdin]]",
9280:             crate::compilation_unit::UnitBuildOptions {
9281:                 registry,
9282:                 defer_top_level: false,
9283:                 config: tcl_lexer::LexerConfig::for_file_grammar(profile.grammar),
9284:                 dialect: Some(profile),
9285:                 external_call_sites: None,
9286:                 declared_commands: None,
9287:             },
9288:             Some(&entry),
9289:             std::sync::Arc::clone(&current),
9290:         );
9291:         assert!(!measured_source_taint(&unit, registry).is_tainted());
9292:         let input = unit.ir_module.source_metadata_input.clone().unwrap();
9293:         let older = std::sync::Arc::new(
9294:             tcl_registry::model::ingress::static_context_for("tcl8.4")
9295:                 .with_command_store(std::sync::Arc::clone(registry)),
9296:         );
9297:         let foreign =
9298:             tcl_registry::model::ingress::resolve_environment("tcl9.1").default_context_registry();
9299:         for context in [Some(older), Some(foreign), None] {
9300:             let changed = context.map(|context| {
9301:                 crate::analyser::ResolvedAnalysisInput::new(
9302:                     input.analyser_profile(),
9303:                     input.unit_profile(),
9304:                     context,
9305:                     input.lexer_config(),
9306:                 )
9307:             });
9308:             unit.ir_module.source_metadata_input = changed.clone();
9309:             unit.top_level.source_metadata_input = changed;
9310:             assert!(measured_source_taint(&unit, registry).is_tainted());
9311:         }
9312:         unit.top_level.source_metadata_input = Some(input.clone());
9313:         assert!(
9314:             measured_source_taint(&unit, registry).is_tainted(),
9315:             "missing Module owner"
9316:         );
9317:         unit.ir_module.source_metadata_input = Some(input.clone());
9318:         unit.ir_module.lexer_config.strict_quoting = !input.lexer_config().strict_quoting;
9319:         assert!(
9320:             measured_source_taint(&unit, registry).is_tainted(),
9321:             "stale Module grammar"
9322:         );
9323:         unit.ir_module.lexer_config = input.lexer_config();
9324:         unit.ir_module.dialect_profile = Some(tcl_dialect::DialectProfile::find("tcl9.1").unwrap());
9325:         assert!(
9326:             measured_source_taint(&unit, registry).is_tainted(),
9327:             "stale Module profile"
9328:         );
9329:         unit.ir_module.dialect_profile = Some(input.unit_profile());
9330:         assert!(!measured_source_taint(&unit, registry).is_tainted());
9331:     }
9332: 
9333:     #[test]
9334:     fn actual_warning_wrapper_uses_the_retained_context_and_lexer() {
9335:         // naming.compiler.original-analysis-metadata-context
9336:         // docs/design/analysis/name-resolution-proofs/original-analysis-metadata-context.md
9337:         // The sink's nested wrapper uses the same source-lattice owner as an
9338:         // assigned value. No source-channel execution or mitigation is observed.
9339:         let profile = tcl_dialect::DialectProfile::find("tcl8.6").unwrap();
9340:         let current =
9341:             tcl_registry::model::ingress::resolve_environment("tcl8.6").default_context_registry();
9342:         let registry = current.commands();
9343:         let (_owner, native) =
9344:             crate::environment_ingress::captured_native_entry_with_owner(profile);
9345:         let entry = crate::command_binding::SourceAnalysisEntry {
9346:             native_entry: Some(std::sync::Arc::new(native)),
9347:             invocation_dialect: Some(tcl_registry::InvocationDialect::of_profile(profile)),
9348:             native_compilation: crate::environment_ingress::authoring_native_compilation(),
9349:             ..Default::default()
9350:         };
9351:         let unit = crate::compilation_unit::CompilationUnit::build_with_context_registry(
9352:             "set payload [gets stdin]; puts [string length $payload]",
9353:             crate::compilation_unit::UnitBuildOptions {
9354:                 registry,
9355:                 defer_top_level: false,
9356:                 config: tcl_lexer::LexerConfig::for_file_grammar(profile.grammar),
9357:                 dialect: Some(profile),
9358:                 external_call_sites: None,
9359:                 declared_commands: None,
9360:             },
9361:             Some(&entry),
9362:             std::sync::Arc::clone(&current),
9363:         );
9364:         let tokens = unit
9365:             .ir_module
9366:             .top_level
9367:             .retained_source_tokens_for_statement(
9368:                 unit.ir_module.top_level.statements.last().unwrap(),
9369:             )
9370:             .unwrap();
9371:         let args = vec![tokens.argv_texts.last().unwrap().clone()];
9372:         let source =
9373:             TaintSourceContext::for_module_function(registry, &unit.ir_module, &unit.top_level);
9374:         let call = SinkCall {
9375:             command: "puts",
9376:             args: &args,
9377:             registry,
9378:             source,
9379:             tokens: Some(tokens),
9380:             effective: None,
9381:             source_read: None,
9382:             argument_offset: 0,
9383:         };
9384:         assert!(var_consumed_by_sanitiser(&call, "payload"));
9385:         let missing = SinkCall {
9386:             source: TaintSourceContext::for_input(registry, None, source.config),
9387:             ..call
9388:         };
9389:         assert!(!var_consumed_by_sanitiser(&missing, "payload"));
9390:         let mut stale = source.config;
9391:         stale.strict_quoting = !stale.strict_quoting;
9392:         let stale = SinkCall {
9393:             source: TaintSourceContext::for_input(
9394:                 registry,
9395:                 unit.top_level.source_metadata_input(),
9396:                 stale,
9397:             ),
9398:             ..call
9399:         };
9400:         assert!(!var_consumed_by_sanitiser(&stale, "payload"));
9401:     }
9402: 
9403:     #[test]
9404:     fn public_module_warning_projection_requires_matching_source_owners() {
9405:         // naming.compiler.original-analysis-metadata-context
9406:         // docs/design/analysis/name-resolution-proofs/original-analysis-metadata-context.md
9407:         // These conditional source warnings retain metadata; no channel read
9408:         // or output handler is executed by the source analysis.
9409:         let profile = tcl_dialect::DialectProfile::find("tcl8.6").unwrap();
9410:         let context =
9411:             tcl_registry::model::ingress::resolve_environment("tcl8.6").default_context_registry();
9412:         let registry = context.commands();
9413:         let (_owner, native) =
9414:             crate::environment_ingress::captured_native_entry_with_owner(profile);
9415:         let entry = crate::command_binding::SourceAnalysisEntry {
9416:             native_entry: Some(std::sync::Arc::new(native)),
9417:             invocation_dialect: Some(tcl_registry::InvocationDialect::of_profile(profile)),
9418:             native_compilation: crate::environment_ingress::authoring_native_compilation(),
9419:             ..Default::default()
9420:         };
9421:         let mut unit = crate::compilation_unit::CompilationUnit::build_with_context_registry(
9422:             "set payload [gets stdin]; puts $payload",
9423:             crate::compilation_unit::UnitBuildOptions {
9424:                 registry,
9425:                 defer_top_level: false,
9426:                 config: tcl_lexer::LexerConfig::for_file_grammar(profile.grammar),
9427:                 dialect: Some(profile),
9428:                 external_call_sites: None,
9429:                 declared_commands: None,
9430:             },
9431:             Some(&entry),
9432:             std::sync::Arc::clone(&context),
9433:         );
9434:         let input = unit.ir_module.source_metadata_input.clone().unwrap();
9435:         let has_sink = |unit: &crate::compilation_unit::CompilationUnit| {
9436:             let traces = crate::compilation_unit::ModuleTraceFacts {
9437:                 traced_variables: &unit.ir_module.traced_variables,
9438:                 has_dynamic_variable_trace: unit.ir_module.has_dynamic_variable_trace,
9439:                 deferred_writes: &crate::ir::NO_DEFERRED_WRITES,
9440:             };
9441:             find_taint_warnings_for_module_function(
9442:                 &unit.top_level,
9443:                 &unit.top_level.taints,
9444:                 &unit.top_level.sccp.executable_blocks,
9445:                 registry,
9446:                 &unit.ir_module,
9447:                 &HashSet::<String>::new(),
9448:                 traces,
9449:             )
9450:             .iter()
9451:             .any(|warning| warning.code == DiagCode::T101)
9452:         };
9453:         assert!(has_sink(&unit));
9454:         unit.ir_module.source_metadata_input = None;
9455:         assert!(!has_sink(&unit), "missing module owner");
9456:         unit.ir_module.source_metadata_input = Some(input.clone());
9457:         unit.ir_module.lexer_config.strict_quoting = !input.lexer_config().strict_quoting;
9458:         assert!(!has_sink(&unit), "stale module lexer");
9459:         unit.ir_module.lexer_config = input.lexer_config();
9460:         unit.ir_module.dialect_profile = Some(tcl_dialect::DialectProfile::find("tcl9.1").unwrap());
9461:         assert!(!has_sink(&unit), "stale module profile");
9462:         unit.ir_module.dialect_profile = Some(profile);
9463:         assert!(has_sink(&unit));
9464:     }
9465: 
9466:     #[test]
9467:     fn inline_sanitiser_mitigation_requires_its_retained_implementation() {
9468:         let profile = tcl_dialect::DialectProfile::find("tcl8.6").unwrap();
9469:         let current =
9470:             tcl_registry::model::ingress::resolve_environment("tcl8.6").default_context_registry();
9471:         let registry = current.commands();
9472:         for (body, warn) in [
9473:             ("puts [string length $x]", false),
9474:             (
9475:                 "rename string saved; proc string args {return [lindex $args end]}; puts [string length $x]",
9476:                 true,
9477:             ),
9478:             (
9479:                 "interp alias {} measure {} string length; puts [measure $x]",
9480:                 false,
9481:             ),
9482:             (
9483:                 "interp alias {} measure {} string length; rename string saved; proc string args {return [lindex $args end]}; puts [measure $x]",
9484:                 true,
9485:             ),
9486:         ] {
9487:             let source = format!("set x [gets stdin]; {body}");
9488:             let (_owner, native) =
9489:                 crate::environment_ingress::captured_native_entry_with_owner(profile);
9490:             let entry = crate::command_binding::SourceAnalysisEntry {
9491:                 native_entry: Some(std::sync::Arc::new(native)),
9492:                 invocation_dialect: Some(tcl_registry::InvocationDialect::of_profile(profile)),
9493:                 native_compilation: crate::environment_ingress::authoring_native_compilation(),
9494:                 ..Default::default()
9495:             };
9496:             let unit = crate::compilation_unit::CompilationUnit::build_with_context_registry(
9497:                 &source,
9498:                 crate::compilation_unit::UnitBuildOptions {
9499:                     registry,
9500:                     defer_top_level: false,
9501:                     config: tcl_lexer::LexerConfig::for_file_grammar(profile.grammar),
9502:                     dialect: Some(profile),
9503:                     external_call_sites: None,
9504:                     declared_commands: None,
9505:                 },
9506:                 Some(&entry),
9507:                 std::sync::Arc::clone(&current),
9508:             )
9509:             .with_interprocedural(registry, Some(profile));
9510:             let warnings = find_taint_warnings_for_cu(&unit, registry, Some(profile));
9511:             assert_eq!(
9512:                 warnings
9513:                     .iter()
9514:                     .any(|warning| warning.code == DiagCode::T101),
9515:                 warn,
9516:                 "{source}: {warnings:?}"
9517:             );
9518:         }
9519:     }
9520: 
9521:     #[test]
9522:     fn explicit_unknown_binding_cannot_recover_a_same_spelled_sink() {
9523:         let source = "eval $x";
9524:         let command = crate::segmenter::segment_commands(source).remove(0);
9525:         let tokens = CommandTokens::from_segmented(
9526:             &tcl_lexer::SourceMap::new(source),
9527:             tcl_lexer::LexerConfig::default(),
9528:             &command,
9529:         )
9530:         .with_source_binding(crate::command_binding::SourceInvocationBinding::unknown());
9531:         let mut statement = call_stmt("eval", &["$x"]);
9532:         match &mut statement {
9533:             Statement::Call { tokens: target, .. } => *target = Some(tokens),
9534:             _ => panic!("call fixture"),
9535:         }
9536:         let warnings = warnings_for_tainted_sink(statement, &[("x", 1)]);
9537:         assert!(
9538:             warnings
9539:                 .iter()
9540:                 .all(|warning| warning.sink_command != "eval"),
9541:             "{warnings:?}"
9542:         );
9543:     }
9544: 
9545:     #[test]
9546:     fn point_binding_supplies_sink_alias_prefix_once() {
9547:         let registry = CommandRegistry::build_default();
9548:         let module = crate::lowering::lower_to_ir(
9549:             "interp alias {} invoke {} exec safe-program\ninvoke $x",
9550:             &registry,
9551:         );
9552:         let tokens = module
9553:             .top_level
9554:             .statements
9555:             .last()
9556:             .unwrap()
9557:             .tokens()
9558:             .unwrap();
9559:         let statement = call_stmt("invoke", &["$x"]);
9560:         let heads = resolve_taint_command_heads("invoke", &statement, Some(tokens), None);
9561:         assert_eq!(heads.len(), 1);
9562:         assert_eq!(heads[0].command, "::exec");
9563:         assert_eq!(
9564:             heads[0].effective_args(&["$x".into()]),
9565:             Some(vec!["safe-program".into(), "$x".into()])
9566:         );
9567:         let arguments = vec!["safe-program".into(), "$x".into()];
9568:         let call = SinkCall {
9569:             source: TaintSourceContext::standalone(&registry, registry.profile()),
9570:             command: &heads[0].command,
9571:             args: &arguments,
9572:             registry: &registry,
9573:             tokens: Some(tokens),
9574:             effective: None,
9575:             source_read: None,
9576:             argument_offset: 0,
9577:         };
9578:         assert_eq!(sink_arg_span(&call, "x", statement.span()), tokens.argv[1]);
9579:     }
9580: 
9581:     fn simple_sccp(blocks: &[BlockId]) -> SccpResult {
9582:         SccpResult {
9583:             required_math_invocations: Vec::new(),
9584:             required_expression_preparations: Vec::new(),
9585:             explanations: Vec::new(),
9586:             route_tally: crate::value_transfer::RouteTally::default(),
9587:             folded_types: HashMap::new(),
9588:             preserved: HashMap::new(),
9589:             raised: HashSet::default(),
9590:             template_plans: Vec::new(),
9591:             selections: Vec::new(),
9592:             existence: HashMap::new(),
9593:             existence_reads: HashMap::new(),
9594:             existence_exits: HashMap::new(),
9595:             existence_entries: HashMap::new(),
9596:             refinements: Vec::new(),
9597:             refinements_at: HashMap::new(),
9598:             value_entries: HashMap::new(),
9599:             query_places: Vec::new(),
9600:             existence_guards: Vec::new(),
9601:             loop_enumerations: Vec::new(),
9602:             reads_module: false,
9603:             completion: crate::sccp::RunCompletion::default(),
9604:             values: HashMap::new(),
9605:             executable_blocks: blocks.iter().copied().collect(),
9606:             executable_edges: HashSet::new(),
9607:             constant_branches: Vec::new(),
9608:         }
9609:     }
9610: 
9611:     /// Bare intra-procedural propagation with no optional inputs.
9612:     fn plain_taints(
9613:         cfg: &CfgFunction,
9614:         ssa: &SsaFunction,
9615:         sccp: &SccpResult,
9616:         registry: &CommandRegistry,
9617:     ) -> HashMap<ValueKey, TaintLattice> {
9618:         let instance_classes = local_instance_classes(cfg, registry);
9619:         propagate_taints(
9620:             &TaintGraph::new(cfg, ssa, sccp),
9621:             TaintPropagationInputs {
9622:                 registry,
9623:                 rendered_props: None,
9624:                 interproc: None,
9625:                 source: TaintSourceContext::standalone(registry, None),
9626:                 param_taints: None,
9627:                 taint_summaries: None,
9628:                 instance_classes: &instance_classes,
9629:             },
9630:         )
9631:     }
9632: 
9633:     #[test]
9634:     fn clean_and_tainted_constructors() {
9635:         let c = TaintLattice::clean();
9636:         assert!(!c.is_tainted());
9637:         let t = TaintLattice::tainted();
9638:         assert!(t.is_tainted());
9639:     }
9640: 
9641:     #[test]
9642:     fn join_propagates_taint_intersects_mitigations() {
9643:         // Two TAINTED operands: taint unions, mitigations are must-have so only
9644:         // the colour present on both survives the intersection.
9645:         let a = TaintLattice {
9646:             colours: TaintColour::TAINTED | TaintColour::CRLF_FREE | TaintColour::PATH_PREFIXED,
9647:         };
9648:         let b = TaintLattice {
9649:             colours: TaintColour::TAINTED | TaintColour::CRLF_FREE | TaintColour::NON_DASH_PREFIXED,
9650:         };
9651:         let j = a.join(b);
9652:         assert!(j.colours.contains(TaintColour::TAINTED));
9653:         assert!(j.colours.contains(TaintColour::CRLF_FREE));
9654:         assert!(!j.colours.contains(TaintColour::PATH_PREFIXED));
9655:         assert!(!j.colours.contains(TaintColour::NON_DASH_PREFIXED));
9656:     }
9657: 
9658:     #[test]
9659:     fn join_with_untainted_is_identity() {
9660:         // A clean/untainted operand is the join identity: it contributes no
9661:         // taint, so it must not dilute the tainted operand's mitigation
9662:         // colours: joining with the annihilating empty set would strip
9663:         // PATH_PREFIXED.
9664:         let tainted = TaintLattice {
9665:             colours: TaintColour::TAINTED | TaintColour::PATH_PREFIXED,
9666:         };
9667:         assert_eq!(tainted.join(TaintLattice::clean()).colours, tainted.colours);
9668:         assert_eq!(TaintLattice::clean().join(tainted).colours, tainted.colours);
9669:         // An untainted operand that happens to carry colours is still the
9670:         // identity — its taint contribution is nil, so it cannot remove a
9671:         // mitigation from the tainted side.
9672:         let untainted_coloured = TaintLattice {
9673:             colours: TaintColour::CRLF_FREE,
9674:         };
9675:         assert_eq!(tainted.join(untainted_coloured).colours, tainted.colours);
9676:     }
9677: 
9678:     #[test]
9679:     fn with_and_sanitised() {
9680:         let v = TaintLattice::tainted().with(TaintColour::CRLF_FREE);
9681:         assert!(v.is_tainted());
9682:         assert!(v.colours.contains(TaintColour::CRLF_FREE));
9683:         let s = v.sanitised();
9684:         assert!(!s.is_tainted());
9685:         assert!(s.colours.contains(TaintColour::CRLF_FREE));
9686:     }
9687: 
9688:     #[test]
9689:     fn t102_safe_mask_excludes_tainted() {
9690:         assert!(!TaintColour::T102_SAFE.contains(TaintColour::TAINTED));
9691:         assert!(TaintColour::T102_SAFE.contains(TaintColour::PATH_PREFIXED));
9692:     }
9693: 
9694:     #[test]
9695:     fn crlf_safe_mask_composition() {
9696:         // `CRLF_SAFE = CRLF_FREE | IP_ADDRESS | PORT | FQDN`.
9697:         // HEADER_TOKEN_SAFE only suppresses IRULE3002 in the name position
9698:         // (handled by `irule3002_name_position_safe`); HTML_ESCAPED / URL_ENCODED
9699:         // do not prove CRLF-injection safety in the value position.
9700:         assert!(TaintColour::CRLF_SAFE.contains(TaintColour::CRLF_FREE));
9701:         assert!(TaintColour::CRLF_SAFE.contains(TaintColour::IP_ADDRESS));
9702:         assert!(TaintColour::CRLF_SAFE.contains(TaintColour::PORT));
9703:         assert!(TaintColour::CRLF_SAFE.contains(TaintColour::FQDN));
9704:         assert!(!TaintColour::CRLF_SAFE.contains(TaintColour::HEADER_TOKEN_SAFE));
9705:         assert!(!TaintColour::CRLF_SAFE.contains(TaintColour::HTML_ESCAPED));
9706:         assert!(!TaintColour::CRLF_SAFE.contains(TaintColour::URL_ENCODED));
9707:         assert!(!TaintColour::CRLF_SAFE.contains(TaintColour::TAINTED));
9708:     }
9709: 
9710:     /// A deeply-nested `[a [a [a … x]]]` command-substitution word and a
9711:     /// deeply-nested `ExprNode` tree, plus a minimal [`TaintCtx`], for the
9712:     /// two ctx-taking recursion caps below.
9713:     fn deep_bracket_word(depth: usize) -> String {
9714:         format!("{}x{}", "[a ".repeat(depth), "]".repeat(depth))
9715:     }
9716: 
9717:     /// `word_taint` recurses once per nested `[cmd …]` command substitution
9718:     /// inside a single word's raw text (Tier 1B), and `expr_command_taint`
9719:     /// recurses once per `ExprNode` operator-tree level (Tier 1A) — both
9720:     /// genuinely unbounded axes, independent of any statement-tree cap.
9721:     /// Uncapped, each overflows the native stack (SIGABRT) in the low
9722:     /// thousands of levels
9723:     /// on a 2 MiB thread (`cargo test`'s default). 3000 is comfortably past
9724:     /// that crash range and past both caps (256); the assertion is that each
9725:     /// returns at all.
9726:     #[test]
9727:     fn deeply_nested_taint_walks_survive() {
9728:         use crate::cfg::Function;
9729:         use crate::ssa::SsaFunction;
9730: 
9731:         let registry = CommandRegistry::build_default();
9732:         let cfg = Function::new("::top", "entry");
9733:         let entry = cfg.entry;
9734:         let ssa = SsaFunction::trivial("::top", entry, cfg.block_names().to_vec());
9735:         let uses: HashMap<Symbol, u32> = HashMap::new();
9736:         let taints: HashMap<ValueKey, TaintLattice> = HashMap::new();
9737:         let ctx = TaintCtx {
9738:             registry: &registry,
9739:             ssa: &ssa,
9740:             interproc: None,
9741:             known_procs: None,
9742:             dialect: None,
9743:             source: TaintSourceContext::standalone(&registry, None),
9744:             taint_summaries: None,
9745:             instance_classes: None,
9746:             source_position: None,
9747:             source_tokens: None,
9748:             word_offset: None,
9749:             source_word: None,
9750:         };
9751: 
9752:         // Tier 1B: nested `[a [a [a … x]]]` command-substitution text.
9753:         let _ = word_taint(&deep_bracket_word(3000), &uses, &taints, ctx);
9754: 
9755:         // Tier 1A: a 3000-deep `ExprNode` tree (nested unary `!`).
9756:         let mut node = ExprNode::Literal {
9757:             text: "1".into(),
9758:             start: 0,
9759:             end: 1,
9760:         };
9761:         for _ in 0..3000 {
9762:             node = ExprNode::Unary {
9763:                 op: crate::expr_ast::UnaryOp::Not,
9764:                 operand: Box::new(node),
9765:             };
9766:         }
9767:         let _ = expr_command_taint(&node, &uses, &taints, ctx, 0);
9768:     }
9769: 
9770:     #[test]
9771:     fn raw_coercion_references_use_current_grammar_and_keep_empty_name_data() {
9772:         for label in ["tcl8.6", "tcl9.1"] {
9773:             let registry = tcl_registry::model::ingress::static_context_for(label).commands();
9774:             let source = TaintSourceContext::standalone(registry, registry.profile());
9775:             let grammar = source
9776:                 .config
9777:                 .grammar_over(registry.profile().unwrap().grammar);
9778:             for (text, name) in [
9779:                 ("${$literal}", "$literal"),
9780:                 ("${}", ""),
9781:                 ("$arr(key)", "arr"),
9782:             ] {
9783:                 let names = HashSet::from([name.to_owned()]);
9784:                 assert!(holds_one_whole_var_ref(text, &names, source.config));
9785:                 assert!(!holds_one_whole_var_ref(
9786:                     text,
9787:                     &HashSet::from(["donated".to_owned()]),
9788:                     source.config
9789:                 ));
9790:                 let mut hits = Vec::new();
9791:                 collect_coercion_operands(
9792:                     &ExprNode::Raw {
9793:                         text: text.to_owned(),
9794:                     },
9795:                     false,
9796:                     &mut hits,
9797:                     0,
9798:                     (source.config, grammar),
9799:                 );
9800:                 assert!(hits.is_empty(), "{label}: {text}");
9801:             }
9802:             let names = HashSet::from(["a{b}c".to_owned()]);
9803:             assert_eq!(
9804:                 holds_one_whole_var_ref("${a{b}c}", &names, source.config),
9805:                 label == "tcl9.1"
9806:             );
9807:             for text in ["prefix$x", "$x + 1", "${x", r"\$x", "${x\0tail}"] {
9808:                 assert!(!holds_one_whole_var_ref(
9809:                     text,
9810:                     &HashSet::from(["x".to_owned()]),
9811:                     source.config
9812:                 ));
9813:             }
9814:             let mut hits = Vec::new();
9815:             collect_coercion_operands(
9816:                 &ExprNode::Var {
9817:                     text: "${}".into(),
9818:                     name: String::new(),
9819:                     start: 0,
9820:                     end: 2,
9821:                 },
9822:                 true,
9823:                 &mut hits,
9824:                 0,
9825:                 (source.config, grammar),
9826:             );
9827:             assert_eq!(hits.len(), 1);
9828:             assert!(hits[0].name.is_empty());
9829:             assert!(hits[0].variable.is_some());
9830:             assert_eq!(hits[0].rel_span, Some((0, 3)));
9831:         }
9832:     }
9833: 
9834:     /// `extract_guard_var` and `collect_coercion_operands` each recurse once
9835:     /// per `ExprNode` level, so both need a depth cap. 3000-deep trees are
9836:     /// past the crash range and past `MAX_EXPR_NODE_DEPTH` (256); the
9837:     /// assertion is that each returns at all.
9838:     #[test]
9839:     fn deeply_nested_expr_guard_and_coercion_walks_survive() {
9840:         // A 3000-deep nested-unary tree drives both walkers' recursion.
9841:         let mut node = ExprNode::Var {
9842:             text: "$x".into(),
9843:             name: "x".into(),
9844:             start: 0,
9845:             end: 2,
9846:         };
9847:         for _ in 0..3000 {
9848:             node = ExprNode::Unary {
9849:                 op: crate::expr_ast::UnaryOp::Not,
9850:                 operand: Box::new(node),
9851:             };
9852:         }
9853:         let _ = extract_guard_var(&node, false, 0, tcl_lexer::LexerConfig::default());
9854:         let mut out = Vec::new();
9855:         collect_coercion_operands(
9856:             &node,
9857:             true,
9858:             &mut out,
9859:             0,
9860:             (
9861:                 tcl_lexer::LexerConfig::default(),
9862:                 tcl_dialect::LexerGrammar::default(),
9863:             ),
9864:         );
9865:     }
9866: 
9867:     #[test]
9868:     fn propagate_taints_gets_is_source() {
9869:         use crate::cfg::{Function, Terminator};
9870:         use crate::ssa::{SsaBlock, SsaFunction};
9871:         use tcl_lexer::Span;
9872: 
9873:         let registry = CommandRegistry::build_default();
9874: 
9875:         // Minimal CFG: entry block with `set x [gets stdin]`.
9876:         let stmt = Statement::AssignValue {
9877:             span: Span::new(0, 20),
9878:             name: "x".into(),
9879:             name_braced: false,
9880:             value: "[gets stdin]".into(),
9881:             value_needs_backsubst: false,
9882:             tokens: None,
9883:         };
9884:         let mut cfg = Function::new("::top", "entry");
9885:         let entry = cfg.entry;
9886:         cfg.blocks
9887:             .get_mut(&entry)
9888:             .unwrap()
9889:             .statements
9890:             .push(stmt.clone());
9891:         cfg.blocks.get_mut(&entry).unwrap().terminator = Some(Terminator::Return {
9892:             expr_base: None,
9893:             tokens: None,
9894:             value: None,
9895:             value_word: None,
9896:             span: None,
9897:             expr: None,
9898:             braced: false,
9899:         });
9900: 
9901:         let mut ssa = SsaFunction::trivial("::top", entry, cfg.block_names().to_vec());
9902:         let x = ssa.intern_var("x");
9903:         let ssa_stmt = ssa_stmt(stmt, HashMap::new(), [(x, 1u32)].into_iter().collect());
9904:         ssa.blocks.insert(
9905:             entry,
9906:             SsaBlock {
9907:                 name: "entry".into(),
9908:                 phis: Vec::new(),
9909:                 statements: vec![ssa_stmt],
9910:                 entry_versions: HashMap::new(),
9911:                 exit_versions: HashMap::new(),
9912:             },
9913:         );
9914: 
9915:         let sccp = simple_sccp(&[entry]);
9916:         let taints = plain_taints(&cfg, &ssa, &sccp, &registry);
9917:         assert!(
9918:             taints.get(&(x, 1)).is_some_and(|t| t.is_tainted()),
9919:             "gets stdin result should be tainted"
9920:         );
9921:     }
9922: 
9923:     #[test]
9924:     fn find_taint_warnings_eval_with_tainted_var() {
9925:         use crate::cfg::{Function, Terminator};
9926:         use crate::ssa::{SsaBlock, SsaFunction};
9927:         use tcl_lexer::Span;
9928: 
9929:         let registry = CommandRegistry::build_default();
9930: 
9931:         // Statements: set x [gets stdin]; eval $x
9932:         let assign = Statement::AssignValue {
9933:             span: Span::new(0, 12),
9934:             name: "x".into(),
9935:             name_braced: false,
9936:             value: "[gets stdin]".into(),
9937:             value_needs_backsubst: false,
9938:             tokens: None,
9939:         };
9940:         let eval_call = Statement::Call {
9941:             span: Span::new(13, 20),
9942:             command: "eval".into(),
9943:             canonical_command: None,
9944:             args: vec!["$x".into()],
9945:             defs: Vec::new(),
9946:             reads: Vec::new(),
9947:             reads_own_defs: false,
9948:             safe_on_uninit: false,
9949:             tokens: None,
9950:             foreach_groups: None,
9951:         };
9952: 
9953:         let mut cfg = Function::new("::top", "entry");
9954:         let entry = cfg.entry;
9955:         cfg.blocks
9956:             .get_mut(&entry)
9957:             .unwrap()
9958:             .statements
9959:             .push(assign.clone());
9960:         cfg.blocks
9961:             .get_mut(&entry)
9962:             .unwrap()
9963:             .statements
9964:             .push(eval_call.clone());
9965:         cfg.blocks.get_mut(&entry).unwrap().terminator = Some(Terminator::Return {
9966:             expr_base: None,
9967:             tokens: None,
9968:             value: None,
9969:             value_word: None,
9970:             span: None,
9971:             expr: None,
9972:             braced: false,
9973:         });
9974: 
9975:         let mut ssa = SsaFunction::trivial("::top", entry, cfg.block_names().to_vec());
9976:         let x = ssa.intern_var("x");
9977:         let ssa_assign = ssa_stmt(assign, HashMap::new(), [(x, 1u32)].into_iter().collect());
9978:         let ssa_eval = ssa_stmt(eval_call, [(x, 1u32)].into_iter().collect(), HashMap::new());
9979: 
9980:         ssa.blocks.insert(
9981:             entry,
9982:             SsaBlock {
9983:                 name: "entry".into(),
9984:                 phis: Vec::new(),
9985:                 statements: vec![ssa_assign, ssa_eval],
9986:                 entry_versions: HashMap::new(),
9987:                 exit_versions: HashMap::new(),
9988:             },
9989:         );
9990: 
9991:         let sccp = simple_sccp(&[entry]);
9992:         let taints = plain_taints(&cfg, &ssa, &sccp, &registry);
9993:         let warnings = find_taint_warnings(
9994:             &cfg,
9995:             &ssa,
9996:             &taints,
9997:             &sccp.executable_blocks,
9998:             &registry,
9999:             None,
10000:             &HashSet::new(),
10001:         );
10002: 
10003:         assert!(
10004:             warnings
10005:                 .iter()
10006:                 .any(|w| w.code == DiagCode::T100 && w.variable == "x"),
10007:             "expected T100 for tainted $x passed to eval, got {warnings:?}"
10008:         );
10009:     }
10010: 
10011:     /// Wire `set x [gets stdin]` (a taint source) followed by `sink`
10012:     /// (which uses `$x`) and return the taint warnings.  Shared by the
10013:     /// T104 / T105 sink tests.
10014:     fn warnings_for_tainted_sink(sink: Statement, sink_uses: &[(&str, u32)]) -> Vec<TaintWarning> {
10015:         use crate::cfg::{Function, Terminator};
10016:         use crate::ssa::{SsaBlock, SsaFunction};
10017:         use tcl_lexer::Span;
10018: 
10019:         let registry = CommandRegistry::build_default();
10020:         let assign = Statement::AssignValue {
10021:             span: Span::new(0, 12),
10022:             name: "x".into(),
10023:             name_braced: false,
10024:             value: "[gets stdin]".into(),
10025:             value_needs_backsubst: false,
10026:             tokens: None,
10027:         };
10028:         let mut cfg = Function::new("::top", "entry");
10029:         let entry = cfg.entry;
10030:         {
10031:             let b = cfg.blocks.get_mut(&entry).unwrap();
10032:             b.statements.push(assign.clone());
10033:             b.statements.push(sink.clone());
10034:             b.terminator = Some(Terminator::Return {
10035:                 expr_base: None,
10036:                 tokens: None,
10037:                 value: None,
10038:                 value_word: None,
10039:                 span: None,
10040:                 expr: None,
10041:                 braced: false,
10042:             });
10043:         }
10044:         let mut ssa = SsaFunction::trivial("::top", entry, cfg.block_names().to_vec());
10045:         let ssa_assign = ssa_stmt(
10046:             assign,
10047:             HashMap::new(),
10048:             [(ssa.intern_var("x"), 1u32)].into_iter().collect(),
10049:         );
10050:         let ssa_sink = ssa_stmt(
10051:             sink,
10052:             sink_uses
10053:                 .iter()
10054:                 .map(|&(n, v)| (ssa.intern_var(n), v))
10055:                 .collect(),
10056:             HashMap::new(),
10057:         );
10058:         ssa.blocks.insert(
10059:             entry,
10060:             SsaBlock {
10061:                 name: "entry".into(),
10062:                 phis: Vec::new(),
10063:                 statements: vec![ssa_assign, ssa_sink],
10064:                 entry_versions: HashMap::new(),
10065:                 exit_versions: HashMap::new(),
10066:             },
10067:         );
10068:         let sccp = simple_sccp(&[entry]);
10069:         let taints = plain_taints(&cfg, &ssa, &sccp, &registry);
10070:         find_taint_warnings(
10071:             &cfg,
10072:             &ssa,
10073:             &taints,
10074:             &sccp.executable_blocks,
10075:             &registry,
10076:             None,
10077:             &HashSet::new(),
10078:         )
10079:     }
10080: 
10081:     fn call_stmt(command: &str, args: &[&str]) -> Statement {
10082:         Statement::Call {
10083:             span: tcl_lexer::Span::new(13, 30),
10084:             command: command.into(),
10085:             canonical_command: None,
10086:             args: args.iter().map(|a| (*a).to_string()).collect(),
10087:             defs: Vec::new(),
10088:             reads: Vec::new(),
10089:             reads_own_defs: false,
10090:             safe_on_uninit: false,
10091:             tokens: None,
10092:             foreach_groups: None,
10093:         }
10094:     }
10095: 
10096:     #[test]
10097:     fn t104_ssrf_for_tainted_socket_address() {
10098:         // `socket $x 80` with tainted `$x` → SSRF (T104).
10099:         let sink = call_stmt("socket", &["$x", "80"]);
10100:         let w = warnings_for_tainted_sink(sink, &[("x", 1)]);
10101:         assert!(
10102:             w.iter()
10103:                 .any(|w| w.code == DiagCode::T104 && w.variable == "x"),
10104:             "expected T104 for tainted socket address; got {w:?}"
10105:         );
10106:     }
10107: 
10108:     #[test]
10109:     fn t105_cross_interp_for_tainted_interp_eval() {
10110:         // `interp eval $child $x` with tainted `$x` → cross-interp (T105).
10111:         let sink = call_stmt("interp", &["eval", "$child", "$x"]);
10112:         let w = warnings_for_tainted_sink(sink, &[("x", 1)]);
10113:         let t105 = w
10114:             .iter()
10115:             .find(|w| w.code == DiagCode::T105 && w.variable == "x");
10116:         assert!(t105.is_some(), "expected T105 for interp eval; got {w:?}");
10117:         assert_eq!(t105.unwrap().sink_command, "interp eval");
10118:     }
10119: 
10120:     #[test]
10121:     fn t105_cross_interp_for_tainted_console_eval() {
10122:         // `console eval $x` with tainted `$x` → cross-interp (T105): the
10123:         // script runs in the separate console interpreter, the same
10124:         // category as `interp eval`.
10125:         let sink = call_stmt("console", &["eval", "$x"]);
10126:         let w = warnings_for_tainted_sink(sink, &[("x", 1)]);
10127:         let t105 = w
10128:             .iter()
10129:             .find(|w| w.code == DiagCode::T105 && w.variable == "x");
10130:         assert!(t105.is_some(), "expected T105 for console eval; got {w:?}");
10131:         assert_eq!(t105.unwrap().sink_command, "console eval");
10132:     }
10133: 
10134:     #[test]
10135:     fn t105_cross_interp_for_tainted_consoleinterp_eval_and_record() {
10136:         // `consoleinterp eval $x` / `consoleinterp record $x` with tainted
10137:         // `$x` → cross-interp (T105): both cross back into the interpreter
10138:         // the console is attached to.
10139:         for sub in ["eval", "record"] {
10140:             let sink = call_stmt("consoleinterp", &[sub, "$x"]);
10141:             let w = warnings_for_tainted_sink(sink, &[("x", 1)]);
10142:             let t105 = w
10143:                 .iter()
10144:                 .find(|w| w.code == DiagCode::T105 && w.variable == "x");
10145:             assert!(
10146:                 t105.is_some(),
10147:                 "expected T105 for consoleinterp {sub}; got {w:?}"
10148:             );
10149:             assert_eq!(t105.unwrap().sink_command, format!("consoleinterp {sub}"));
10150:         }
10151:     }
10152: 
10153:     /// A hand-built SSA statement with no may-defs, quoted uses or name-only
10154:     /// uses — the shape every fixture in this module wants.
10155:     fn ssa_stmt(
10156:         statement: Statement,
10157:         uses: HashMap<crate::ssa::Symbol, u32>,
10158:         defs: HashMap<crate::ssa::Symbol, u32>,
10159:     ) -> crate::ssa::SsaStatement {
10160:         crate::ssa::SsaStatement {
10161:             statement,
10162:             uses,
10163:             defs,
10164:             may_defs: std::collections::HashSet::new(),
10165:             destruction_defs: std::collections::HashSet::new(),
10166:             quoted_uses: std::collections::HashSet::new(),
10167:             name_only_uses: std::collections::HashSet::new(),
10168:         }
10169:     }
10170: 
10171:     #[test]
10172:     fn destruction_versions_preserve_predecessor_taint_without_sanitising() {
10173:         use crate::cfg::Function;
10174:         use crate::ssa::{SsaBlock, SsaFunction};
10175:         let registry = CommandRegistry::build_default();
10176:         let cfg = Function::new("::top", "entry");
10177:         let mut ssa = SsaFunction::trivial("::top", cfg.entry, cfg.block_names().to_vec());
10178:         let symbol = ssa.intern_var("payload");
10179:         let ctx = TaintCtx {
10180:             registry: &registry,
10181:             ssa: &ssa,
10182:             interproc: None,
10183:             known_procs: None,
10184:             dialect: None,
10185:             source: TaintSourceContext::standalone(&registry, None),
10186:             taint_summaries: None,
10187:             instance_classes: None,
10188:             source_position: None,
10189:             source_tokens: None,
10190:             word_offset: None,
10191:             source_word: None,
10192:         };
10193:         for conditional in [false, true] {
10194:             for predecessor in [
10195:                 TaintLattice::clean(),
10196:                 TaintLattice::tainted(),
10197:                 TaintLattice::tainted().with(TaintColour::CRLF_FREE),
10198:             ] {
10199:                 let mut statement = ssa_stmt(
10200:                     call_stmt("unset", &["payload"]),
10201:                     HashMap::from([(symbol, 1)]),
10202:                     HashMap::from([(symbol, 2)]),
10203:                 );
10204:                 statement.destruction_defs.insert(symbol);
10205:                 if conditional {
10206:                     statement.may_defs.insert(symbol);
10207:                 }
10208:                 let block = SsaBlock {
10209:                     name: "entry".into(),
10210:                     phis: Vec::new(),
10211:                     statements: vec![statement],
10212:                     entry_versions: HashMap::new(),
10213:                     exit_versions: HashMap::new(),
10214:                 };
10215:                 let mut taints = HashMap::from([((symbol, 1), predecessor)]);
10216:                 propagate_statement_taints(&mut taints, &block, ctx, &ssa, None);
10217:                 assert_eq!(
10218:                     taints[&(symbol, 2)],
10219:                     predecessor,
10220:                     "conditional={conditional}: unset supplies neither cleaning nor new mitigation"
10221:                 );
10222:                 let uses = HashMap::from([(symbol, 2)]);
10223:                 assert_eq!(
10224:                     word_taint("$payload", &uses, &taints, ctx),
10225:                     predecessor,
10226:                     "the downstream script operand keeps its possible predecessor influence"
10227:                 );
10228:             }
10229:         }
10230:     }
10231: 
10232:     #[test]
10233:     fn t106_double_encode_through_uri_encode() {
10234:         // `set x [URI::encode $tainted]` stamps URL_ENCODED on x; passing
10235:         // x back through `URI::encode` double-encodes → T106.
10236:         use crate::cfg::{Function, Terminator};
10237:         use crate::ssa::{SsaBlock, SsaFunction};
10238:         use tcl_lexer::Span;
10239: 
10240:         let mut registry = CommandRegistry::build_default();
10241:         registry.load_surface(SurfaceLayer::Core(Family::F5Irules, ""));
10242: 
10243:         // set x [gets stdin]      (taint source)
10244:         // set y [URI::encode $x]  (x tainted → y URL_ENCODED)
10245:         // URI::encode $y          (y already URL_ENCODED → T106)
10246:         let s0 = Statement::AssignValue {
10247:             span: Span::new(0, 12),
10248:             name: "x".into(),
10249:             name_braced: false,
10250:             value: "[gets stdin]".into(),
10251:             value_needs_backsubst: false,
10252:             tokens: None,
10253:         };
10254:         let s1 = Statement::AssignValue {
10255:             span: Span::new(13, 35),
10256:             name: "y".into(),
10257:             name_braced: false,
10258:             value: "[URI::encode $x]".into(),
10259:             value_needs_backsubst: false,
10260:             tokens: None,
10261:         };
10262:         let s2 = call_stmt("URI::encode", &["$y"]);
10263: 
10264:         let mut cfg = Function::new("::top", "entry");
10265:         let entry = cfg.entry;
10266:         {
10267:             let b = cfg.blocks.get_mut(&entry).unwrap();
10268:             b.statements.push(s0.clone());
10269:             b.statements.push(s1.clone());
10270:             b.statements.push(s2.clone());
10271:             b.terminator = Some(Terminator::Return {
10272:                 expr_base: None,
10273:                 tokens: None,
10274:                 value: None,
10275:                 value_word: None,
10276:                 span: None,
10277:                 expr: None,
10278:                 braced: false,
10279:             });
10280:         }
10281:         let mut ssa = SsaFunction::trivial("::top", entry, cfg.block_names().to_vec());
10282:         let x = ssa.intern_var("x");
10283:         let y = ssa.intern_var("y");
10284:         let ssa_s0 = ssa_stmt(s0, HashMap::new(), [(x, 1u32)].into_iter().collect());
10285:         let ssa_s1 = ssa_stmt(
10286:             s1,
10287:             [(x, 1u32)].into_iter().collect(),
10288:             [(y, 1u32)].into_iter().collect(),
10289:         );
10290:         let ssa_s2 = ssa_stmt(s2, [(y, 1u32)].into_iter().collect(), HashMap::new());
10291:         ssa.blocks.insert(
10292:             entry,
10293:             SsaBlock {
10294:                 name: "entry".into(),
10295:                 phis: Vec::new(),
10296:                 statements: vec![ssa_s0, ssa_s1, ssa_s2],
10297:                 entry_versions: HashMap::new(),
10298:                 exit_versions: HashMap::new(),
10299:             },
10300:         );
10301:         let sccp = simple_sccp(&[entry]);
10302:         let taints = plain_taints(&cfg, &ssa, &sccp, &registry);
10303:         // The transform colour must have propagated to y.
10304:         assert!(
10305:             taints
10306:                 .get(&(y, 1))
10307:                 .is_some_and(|t| t.colours.intersects(TaintColour::URL_ENCODED)),
10308:             "y should carry URL_ENCODED after URI::encode; got {:?}",
10309:             taints.get(&(y, 1))
10310:         );
10311:         let warnings = find_taint_warnings(
10312:             &cfg,
10313:             &ssa,
10314:             &taints,
10315:             &sccp.executable_blocks,
10316:             &registry,
10317:             Some(tcl_dialect::DialectProfile::irules()),
10318:             &HashSet::new(),
10319:         );
10320:         let t106 = warnings
10321:             .iter()
10322:             .find(|w| w.code == DiagCode::T106 && w.variable == "y");
10323:         assert!(
10324:             t106.is_some(),
10325:             "expected T106 double-encode; got {warnings:?}"
10326:         );
10327:         assert!(
10328:             t106.unwrap().message.contains("already URL-encoded"),
10329:             "{:?}",
10330:             t106.unwrap().message
10331:         );
10332:     }
10333: 
10334:     /// Run W313 over a single-block function whose SSA statements are built by
10335:     /// `build` against the function's variable interner.
10336:     fn w313_warnings(
10337:         build: impl FnOnce(&mut SsaFunction) -> Vec<crate::ssa::SsaStatement>,
10338:     ) -> Vec<TaintWarning> {
10339:         use crate::cfg::{Function, Terminator};
10340:         use crate::ssa::{SsaBlock, SsaFunction};
10341: 
10342:         let registry = CommandRegistry::build_default();
10343:         let mut cfg = Function::new("::top", "entry");
10344:         let entry = cfg.entry;
10345:         let mut ssa = SsaFunction::trivial("::top", entry, cfg.block_names().to_vec());
10346:         let ssa_stmts = build(&mut ssa);
10347:         {
10348:             let b = cfg.blocks.get_mut(&entry).unwrap();
10349:             for s in &ssa_stmts {
10350:                 b.statements.push(s.statement.clone());
10351:             }
10352:             b.terminator = Some(Terminator::Return {
10353:                 expr_base: None,
10354:                 tokens: None,
10355:                 value: None,
10356:                 value_word: None,
10357:                 span: None,
10358:                 expr: None,
10359:                 braced: false,
10360:             });
10361:         }
10362:         ssa.blocks.insert(
10363:             entry,
10364:             SsaBlock {
10365:                 name: "entry".into(),
10366:                 phis: Vec::new(),
10367:                 statements: ssa_stmts,
10368:                 entry_versions: HashMap::new(),
10369:                 exit_versions: HashMap::new(),
10370:             },
10371:         );
10372:         let sccp = simple_sccp(&[entry]);
10373:         let taints = plain_taints(&cfg, &ssa, &sccp, &registry);
10374:         find_destructive_file_warnings(
10375:             &cfg,
10376:             &ssa,
10377:             &taints,
10378:             &sccp.executable_blocks,
10379:             &registry,
10380:             None,
10381:         )
10382:     }
10383: 
10384:     fn file_call(args: &[&str]) -> Statement {
10385:         Statement::Call {
10386:             span: tcl_lexer::Span::new(0, 20),
10387:             command: "file".into(),
10388:             canonical_command: Some("::file".into()),
10389:             args: args.iter().map(|a| (*a).to_string()).collect(),
10390:             defs: Vec::new(),
10391:             reads: Vec::new(),
10392:             reads_own_defs: false,
10393:             safe_on_uninit: false,
10394:             tokens: None,
10395:             foreach_groups: None,
10396:         }
10397:     }
10398: 
10399:     #[test]
10400:     fn w313_variable_path_to_file_delete() {
10401:         use crate::ssa::SsaStatement;
10402:         let w = w313_warnings(|ssa| {
10403:             vec![SsaStatement {
10404:                 statement: file_call(&["delete", "$p"]),
10405:                 uses: [(ssa.intern_var("p"), 1u32)].into_iter().collect(),
10406:                 defs: HashMap::new(),
10407:                 may_defs: std::collections::HashSet::new(),
10408:                 destruction_defs: std::collections::HashSet::new(),
10409:                 quoted_uses: std::collections::HashSet::new(),
10410:                 name_only_uses: std::collections::HashSet::new(),
10411:             }]
10412:         });
10413:         let d = w.iter().find(|w| w.code == DiagCode::W313).expect("W313");
10414:         assert_eq!(d.variable, "p");
10415:         assert!(
10416:             d.message
10417:                 .contains("file delete with a variable path ($p) risks path-traversal"),
10418:             "{}",
10419:             d.message
10420:         );
10421:     }
10422: 
10423:     #[test]
10424:     fn w313_normalised_path_gets_softer_message() {
10425:         use crate::ssa::SsaStatement;
10426:         use tcl_lexer::Span;
10427:         // set p [file normalize $base]; file delete $p
10428:         let assign = Statement::AssignValue {
10429:             span: Span::new(0, 25),
10430:             name: "p".into(),
10431:             name_braced: false,
10432:             value: "[file normalize $base]".into(),
10433:             value_needs_backsubst: false,
10434:             tokens: None,
10435:         };
10436:         let w = w313_warnings(|ssa| {
10437:             let base = ssa.intern_var("base");
10438:             let p = ssa.intern_var("p");
10439:             let s0 = ssa_stmt(
10440:                 assign,
10441:                 [(base, 0u32)].into_iter().collect(),
10442:                 [(p, 1u32)].into_iter().collect(),
10443:             );
10444:             let s1 = SsaStatement {
10445:                 statement: file_call(&["delete", "$p"]),
10446:                 uses: [(p, 1u32)].into_iter().collect(),
10447:                 defs: HashMap::new(),
10448:                 may_defs: std::collections::HashSet::new(),
10449:                 destruction_defs: std::collections::HashSet::new(),
10450:                 quoted_uses: std::collections::HashSet::new(),
10451:                 name_only_uses: std::collections::HashSet::new(),
10452:             };
10453:             vec![s0, s1]
10454:         });
10455:         let d = w.iter().find(|w| w.code == DiagCode::W313).expect("W313");
10456:         assert!(
10457:             d.message.contains("file delete with normalised path ($p)"),
10458:             "{}",
10459:             d.message
10460:         );
10461:         // The `[string match …]` example must interpolate the variable
10462:         // name (`${p}`), not render the literal placeholder `${name}`.
10463:         assert!(
10464:             d.message.contains("[string match \"$base/*\" ${p}]"),
10465:             "{}",
10466:             d.message
10467:         );
10468:         assert!(!d.message.contains("${name}"), "{}", d.message);
10469:     }
10470: 
10471:     #[test]
10472:     fn w313_silent_for_literal_path() {
10473:         use crate::ssa::SsaStatement;
10474:         // `file delete /tmp/foo` has no variable path argument.
10475:         assert_eq!(
10476:             w313_warnings(|_ssa| {
10477:                 vec![SsaStatement {
10478:                     statement: file_call(&["delete", "/tmp/foo"]),
10479:                     uses: HashMap::new(),
10480:                     defs: HashMap::new(),
10481:                     may_defs: std::collections::HashSet::new(),
10482:                     destruction_defs: std::collections::HashSet::new(),
10483:                     quoted_uses: std::collections::HashSet::new(),
10484:                     name_only_uses: std::collections::HashSet::new(),
10485:                 }]
10486:             })
10487:             .len(),
10488:             0
10489:         );
10490:     }
10491: 
10492:     #[test]
10493:     fn standalone_guard_names_follow_original_operand_kind_and_supplied_config() {
10494:         for label in ["tcl8.6", "tcl9.1"] {
10495:             let registry = tcl_registry::model::ingress::static_context_for(label).commands();
10496:             let config = TaintSourceContext::standalone(registry, registry.profile()).config;
10497:             for (source, expected) in [
10498:                 ("[string match SAFE ${$literal}]", Some("$literal")),
10499:                 ("[string match SAFE ${}]", Some("")),
10500:                 ("[string match SAFE {$literal}]", None),
10501:                 ("[string match SAFE {${literal}}]", None),
10502:                 (
10503:                     "[string first SAFE ${qualified::literal}]",
10504:                     Some("qualified::literal"),
10505:                 ),
10506:                 ("[string first SAFE $arr(key)]", None),
10507:                 ("[string equal SAFE ${arr(key)}]", None),
10508:                 ("[string equal SAFE prefix$x]", None),
10509:                 ("[string match SAFE {*}$x]", None),
10510:             ] {
10511:                 assert_eq!(
10512:                     guard_var_from_string_command(source, config).as_deref(),
10513:                     expected,
10514:                     "{label}: {source}"
10515:                 );
10516:             }
10517:             assert_eq!(
10518:                 guard_var_from_string_command("[string match SAFE ${a{b}c}]", config).as_deref(),
10519:                 if label == "tcl9.1" {
10520:                     Some("a{b}c")
10521:                 } else {
10522:                     None
10523:                 }
10524:             );
10525:         }
10526:     }
10527: 
10528:     #[test]
10529:     fn w313_helpers_parse_vars_and_guards() {
10530:         assert!(arg_var_names("$p", tcl_dialect::BracedVarStyle::default()).contains("p"));
10531:         assert!(
10532:             arg_var_names("${dir}/$file", tcl_dialect::BracedVarStyle::default()).contains("dir")
10533:         );
10534:         assert!(
10535:             arg_var_names("${dir}/$file", tcl_dialect::BracedVarStyle::default()).contains("file")
10536:         );
10537:         assert_eq!(
10538:             extract_var_name("$p", tcl_lexer::LexerConfig::default()).as_deref(),
10539:             Some("p")
10540:         );
10541:         assert_eq!(
10542:             extract_var_name("${p}", tcl_lexer::LexerConfig::default()).as_deref(),
10543:             Some("p")
10544:         );
10545:         assert_eq!(
10546:             guard_var_from_string_command(
10547:                 "[string match \"$base/*\" $p]",
10548:                 tcl_lexer::LexerConfig::default()
10549:             )
10550:             .as_deref(),
10551:             Some("p")
10552:         );
10553:         assert_eq!(
10554:             guard_var_from_string_command(
10555:                 "[string equal -length 4 $a $p]",
10556:                 tcl_lexer::LexerConfig::default()
10557:             )
10558:             .as_deref(),
10559:             Some("a")
10560:         );
10561:     }
10562: 
10563:     #[test]
10564:     fn classify_network_interp_sinks_maps_socket_and_interp() {
10565:         let reg = CommandRegistry::build_default();
10566:         assert_eq!(
10567:             classify_network_interp_sinks(&reg, "socket", &["host".into(), "80".into()]),
10568:             vec![(DiagCode::T104, "socket".to_owned())]
10569:         );
10570:         assert_eq!(
10571:             classify_network_interp_sinks(&reg, "interp", &["eval".into(), "$c".into()]),
10572:             vec![(DiagCode::T105, "interp eval".to_owned())]
10573:         );
10574:         // A non-eval interp subcommand and a plain command map to nothing.
10575:         assert_eq!(
10576:             classify_network_interp_sinks(&reg, "interp", &["share".into()]).len(),
10577:             0
10578:         );
10579:         assert_eq!(
10580:             classify_network_interp_sinks(&reg, "puts", &["hi".into()]).len(),
10581:             0
10582:         );
10583:     }
10584: 
10585:     #[test]
10586:     fn const_assignment_is_not_tainted() {
10587:         use crate::cfg::{Function, Terminator};
10588:         use crate::ssa::{SsaBlock, SsaFunction};
10589:         use tcl_lexer::Span;
10590: 
10591:         let registry = CommandRegistry::build_default();
10592: 
10593:         let stmt = Statement::AssignConst {
10594:             span: Span::new(0, 10),
10595:             name: "x".into(),
10596:             name_braced: false,
10597:             value: "hello".into(),
10598:             value_span: None,
10599:         };
10600:         let mut cfg = Function::new("::top", "entry");
10601:         let entry = cfg.entry;
10602:         cfg.blocks
10603:             .get_mut(&entry)
10604:             .unwrap()
10605:             .statements
10606:             .push(stmt.clone());
10607:         cfg.blocks.get_mut(&entry).unwrap().terminator = Some(Terminator::Return {
10608:             expr_base: None,
10609:             tokens: None,
10610:             value: None,
10611:             value_word: None,
10612:             span: None,
10613:             expr: None,
10614:             braced: false,
10615:         });
10616: 
10617:         let mut ssa = SsaFunction::trivial("::top", entry, cfg.block_names().to_vec());
10618:         let x = ssa.intern_var("x");
10619:         let ssa_stmt = ssa_stmt(stmt, HashMap::new(), [(x, 1u32)].into_iter().collect());
10620:         ssa.blocks.insert(
10621:             entry,
10622:             SsaBlock {
10623:                 name: "entry".into(),
10624:                 phis: Vec::new(),
10625:                 statements: vec![ssa_stmt],
10626:                 entry_versions: HashMap::new(),
10627:                 exit_versions: HashMap::new(),
10628:             },
10629:         );
10630: 
10631:         let sccp = simple_sccp(&[entry]);
10632:         let taints = plain_taints(&cfg, &ssa, &sccp, &registry);
10633:         assert!(
10634:             taints.get(&(x, 1)).is_none_or(|t| !t.is_tainted()),
10635:             "constant assignment should not be tainted"
10636:         );
10637:     }
10638: 
10639:     /// T102: tainted variable passed to `regexp` without `--` terminator.
10640:     #[test]
10641:     fn t102_emitted_for_tainted_regexp_pattern() {
10642:         use crate::cfg::{Function, Terminator};
10643:         use crate::ssa::{SsaBlock, SsaFunction};
10644:         use tcl_lexer::Span;
10645: 
10646:         let registry = CommandRegistry::build_default();
10647: 
10648:         // set pattern [gets stdin] ; regexp $pattern $haystack
10649:         let assign = Statement::AssignValue {
10650:             span: Span::new(0, 25),
10651:             name: "pattern".into(),
10652:             name_braced: false,
10653:             value: "[gets stdin]".into(),
10654:             value_needs_backsubst: false,
10655:             tokens: None,
10656:         };
10657:         let regexp_call = Statement::Call {
10658:             span: Span::new(26, 50),
10659:             command: "regexp".into(),
10660:             canonical_command: None,
10661:             args: vec!["$pattern".into(), "haystack_value".into()],
10662:             defs: Vec::new(),
10663:             reads: Vec::new(),
10664:             reads_own_defs: false,
10665:             safe_on_uninit: false,
10666:             tokens: None,
10667:             foreach_groups: None,
10668:         };
10669: 
10670:         let mut cfg = Function::new("::top", "entry");
10671:         let entry = cfg.entry;
10672:         cfg.blocks
10673:             .get_mut(&entry)
10674:             .unwrap()
10675:             .statements
10676:             .push(assign.clone());
10677:         cfg.blocks
10678:             .get_mut(&entry)
10679:             .unwrap()
10680:             .statements
10681:             .push(regexp_call.clone());
10682:         cfg.blocks.get_mut(&entry).unwrap().terminator = Some(Terminator::Return {
10683:             expr_base: None,
10684:             tokens: None,
10685:             value: None,
10686:             value_word: None,
10687:             span: None,
10688:             expr: None,
10689:             braced: false,
10690:         });
10691: 
10692:         let mut ssa = SsaFunction::trivial("::top", entry, cfg.block_names().to_vec());
10693:         let pattern = ssa.intern_var("pattern");
10694:         let ssa_assign = ssa_stmt(
10695:             assign,
10696:             HashMap::new(),
10697:             [(pattern, 1u32)].into_iter().collect(),
10698:         );
10699:         let ssa_regexp = ssa_stmt(
10700:             regexp_call,
10701:             [(pattern, 1u32)].into_iter().collect(),
10702:             HashMap::new(),
10703:         );
10704: 
10705:         ssa.blocks.insert(
10706:             entry,
10707:             SsaBlock {
10708:                 name: "entry".into(),
10709:                 phis: Vec::new(),
10710:                 statements: vec![ssa_assign, ssa_regexp],
10711:                 entry_versions: HashMap::new(),
10712:                 exit_versions: HashMap::new(),
10713:             },
10714:         );
10715: 
10716:         let sccp = simple_sccp(&[entry]);
10717:         let taints = plain_taints(&cfg, &ssa, &sccp, &registry);
10718:         let warnings = find_taint_warnings(
10719:             &cfg,
10720:             &ssa,
10721:             &taints,
10722:             &sccp.executable_blocks,
10723:             &registry,
10724:             None,
10725:             &HashSet::new(),
10726:         );
10727: 
10728:         assert!(
10729:             warnings
10730:                 .iter()
10731:                 .any(|w| w.code == DiagCode::T102 && w.variable == "pattern"),
10732:             "expected T102 for tainted $pattern passed to regexp, got {warnings:?}"
10733:         );
10734:     }
10735: 
10736:     /// T102 is suppressed when a `--` terminator precedes the tainted argument.
10737:     #[test]
10738:     fn t102_suppressed_with_terminator() {
10739:         use crate::cfg::{Function, Terminator};
10740:         use crate::ssa::{SsaBlock, SsaFunction};
10741:         use tcl_lexer::Span;
10742: 
10743:         let registry = CommandRegistry::build_default();
10744: 
10745:         let assign = Statement::AssignValue {
10746:             span: Span::new(0, 25),
10747:             name: "pattern".into(),
10748:             name_braced: false,
10749:             value: "[gets stdin]".into(),
10750:             value_needs_backsubst: false,
10751:             tokens: None,
10752:         };
10753:         // regexp -- $pattern $haystack  (safe: -- terminates option parsing)
10754:         let regexp_call = Statement::Call {
10755:             span: Span::new(26, 55),
10756:             command: "regexp".into(),
10757:             canonical_command: None,
10758:             args: vec!["--".into(), "$pattern".into(), "haystack_value".into()],
10759:             defs: Vec::new(),
10760:             reads: Vec::new(),
10761:             reads_own_defs: false,
10762:             safe_on_uninit: false,
10763:             tokens: None,
10764:             foreach_groups: None,
10765:         };
10766: 
10767:         let mut cfg = Function::new("::top", "entry");
10768:         let entry = cfg.entry;
10769:         cfg.blocks
10770:             .get_mut(&entry)
10771:             .unwrap()
10772:             .statements
10773:             .push(assign.clone());
10774:         cfg.blocks
10775:             .get_mut(&entry)
10776:             .unwrap()
10777:             .statements
10778:             .push(regexp_call.clone());
10779:         cfg.blocks.get_mut(&entry).unwrap().terminator = Some(Terminator::Return {
10780:             expr_base: None,
10781:             tokens: None,
10782:             value: None,
10783:             value_word: None,
10784:             span: None,
10785:             expr: None,
10786:             braced: false,
10787:         });
10788: 
10789:         let mut ssa = SsaFunction::trivial("::top", entry, cfg.block_names().to_vec());
10790:         let pattern = ssa.intern_var("pattern");
10791:         let ssa_assign = ssa_stmt(
10792:             assign,
10793:             HashMap::new(),
10794:             [(pattern, 1u32)].into_iter().collect(),
10795:         );
10796:         let ssa_regexp = ssa_stmt(
10797:             regexp_call,
10798:             [(pattern, 1u32)].into_iter().collect(),
10799:             HashMap::new(),
10800:         );
10801: 
10802:         ssa.blocks.insert(
10803:             entry,
10804:             SsaBlock {
10805:                 name: "entry".into(),
10806:                 phis: Vec::new(),
10807:                 statements: vec![ssa_assign, ssa_regexp],
10808:                 entry_versions: HashMap::new(),
10809:                 exit_versions: HashMap::new(),
10810:             },
10811:         );
10812: 
10813:         let sccp = simple_sccp(&[entry]);
10814:         let taints = plain_taints(&cfg, &ssa, &sccp, &registry);
10815:         let warnings = find_taint_warnings(
10816:             &cfg,
10817:             &ssa,
10818:             &taints,
10819:             &sccp.executable_blocks,
10820:             &registry,
10821:             None,
10822:             &HashSet::new(),
10823:         );
10824: 
10825:         let t102: Vec<_> = warnings
10826:             .iter()
10827:             .filter(|w| w.code == DiagCode::T102)
10828:             .collect();
10829:         assert_eq!(
10830:             t102.len(),
10831:             0,
10832:             "expected no T102 when '--' terminator present, got {t102:?}"
10833:         );
10834:     }
10835: 
10836:     /// Taint propagates through an interpolated-string word that embeds a
10837:     /// tainted variable: `set out "prefix_${x}_suffix"` where `$x` is tainted.
10838:     #[test]
10839:     fn interpolated_string_word_propagates_taint() {
10840:         use crate::compilation_unit::CompilationUnit;
10841:         use tcl_registry::CommandRegistry;
10842: 
10843:         let registry = CommandRegistry::build_default();
10844:         let cu = CompilationUnit::build_for(
10845:             "set x [gets stdin]\nset out \"prefix_${x}_suffix\"",
10846:             &registry,
10847:             false,
10848:         );
10849:         let fu = cu.function("::top").unwrap();
10850:         let out_tainted = fu
10851:             .taints
10852:             .iter()
10853:             .any(|((name, _ver), t)| fu.ssa.var_name(*name) == "out" && t.is_tainted());
10854:         assert!(
10855:             out_tainted,
10856:             "expected 'out' to be tainted via interpolated string embedding tainted $x"
10857:         );
10858:     }
10859: 
10860:     /// Actual F5 getter properties survive an optional diagnostic dialect
10861:     /// filter; an unloaded catalogue spelling supplies no security properties.
10862:     #[test]
10863:     fn irules_http_uri_is_a_dialect_agnostic_source() {
10864:         use crate::compilation_unit::CompilationUnit;
10865: 
10866:         let profile = tcl_dialect::DialectProfile::irules();
10867:         let mut registry = CommandRegistry::build_default();
10868:         registry.load_irules();
10869:         let registry = registry.project_for_profile(profile);
10870:         for dialect in [None, Some(profile)] {
10871:             let cu =
10872:                 CompilationUnit::build_for_profile("set u [HTTP::uri]", &registry, false, profile)
10873:                     .with_interprocedural(&registry, dialect);
10874:             let fu = cu.function("::top").unwrap();
10875:             let u = fu
10876:                 .taints
10877:                 .iter()
10878:                 .find(|((n, _), _)| fu.ssa.var_name(*n) == "u")
10879:                 .map(|(_, t)| *t);
10880:             assert!(
10881:                 u.is_some_and(TaintLattice::is_tainted),
10882:                 "HTTP::uri should be a taint source (dialect={dialect:?})",
10883:             );
10884:             assert!(
10885:                 u.is_some_and(|t| t.colours.contains(TaintColour::PATH_PREFIXED)),
10886:                 "HTTP::uri getter should carry PATH_PREFIXED (dialect={dialect:?})",
10887:             );
10888:         }
10889:         let plain = CommandRegistry::build_default();
10890:         let unit = CompilationUnit::build_for("set u [HTTP::uri]", &plain, false);
10891:         assert!(
10892:             unit.top_level
10893:                 .taints
10894:                 .values()
10895:                 .all(|taint| { !taint.colours.contains(TaintColour::PATH_PREFIXED) }),
10896:             "an unloaded F5 name must not donate getter safety properties"
10897:         );
10898:     }
10899: 
10900:     /// Inter-procedural: `proc id {x} { return $x }` + tainted actual
10901:     /// should taint the call's result because the passthrough parameter
10902:     /// forwards the tainted value through the proc.
10903:     #[test]
10904:     fn interprocedural_passthrough_transfers_taint() {
10905:         use crate::compilation_unit::CompilationUnit;
10906: 
10907:         let registry = CommandRegistry::build_default();
10908:         let cu = CompilationUnit::build_for(
10909:             "proc ::id {x} { return $x }\n\
10910:              set tainted [gets stdin]\n\
10911:              set out [::id $tainted]",
10912:             &registry,
10913:             false,
10914:         )
10915:         .with_interprocedural(&registry, None);
10916:         let fu = cu.function("::top").unwrap();
10917:         assert!(
10918:             fu.taints
10919:                 .iter()
10920:                 .any(|((n, _), t)| fu.ssa.var_name(*n) == "out" && t.is_tainted()),
10921:             "expected 'out' to be tainted via passthrough proc: {:?}",
10922:             fu.taints,
10923:         );
10924:     }
10925: 
10926:     /// Global-write seeding must be scoped to procs actually reachable
10927:     /// from the current function. An unrelated helper that writes to
10928:     /// `::state` should not taint `::other_global` in a function that
10929:     /// never calls it.
10930:     #[test]
10931:     fn global_write_seeding_is_scoped_to_reachable_callees() {
10932:         use crate::compilation_unit::CompilationUnit;
10933: 
10934:         let registry = CommandRegistry::build_default();
10935:         // `::writer` writes ::state. `::top` never calls ::writer, so
10936:         // reads of other globals here must stay clean.
10937:         let cu = CompilationUnit::build_for(
10938:             "proc ::writer {} { set ::state 1 }\n\
10939:              set local $::safe",
10940:             &registry,
10941:             false,
10942:         )
10943:         .with_interprocedural(&registry, None);
10944:         let fu = cu.function("::top").unwrap();
10945:         let local_tainted = fu
10946:             .taints
10947:             .iter()
10948:             .any(|((n, _), t)| fu.ssa.var_name(*n) == "local" && t.is_tainted());
10949:         assert!(
10950:             !local_tainted,
10951:             "`local` must stay clean — `::writer` is unreachable from top-level: {:?}",
10952:             fu.taints,
10953:         );
10954:     }
10955: 
10956:     /// Rendered-property colouring: a value starting with `/` should
10957:     /// pick up `PATH_PREFIXED` (implying `NON_DASH_PREFIXED`).
10958:     #[test]
10959:     fn rendered_props_colour_slash_value_path_prefixed() {
10960:         use crate::compilation_unit::CompilationUnit;
10961: 
10962:         let registry = CommandRegistry::build_default();
10963:         let cu = CompilationUnit::build_for("set path /etc/hosts", &registry, false);
10964:         let fu = cu.function("::top").unwrap();
10965:         let entry = fu
10966:             .taints
10967:             .iter()
10968:             .find(|((n, _), _)| fu.ssa.var_name(*n) == "path")
10969:             .expect("path taint entry");
10970:         assert!(
10971:             entry.1.colours.contains(TaintColour::PATH_PREFIXED),
10972:             "expected PATH_PREFIXED colour on /-prefixed literal",
10973:         );
10974:     }
10975: 
10976:     // IRULE3001–3004 sink classifier + end-to-end detection
10977: 
10978:     fn irules_warnings_for(source: &str) -> Vec<TaintWarning> {
10979:         use crate::compilation_unit::CompilationUnit;
10980:         // Mirror production (tcl-lsp-db): build_default + load the iRules
10981:         // dialect, so the iRules command *specs* (with their subcommands and
10982:         // taint_output_sink_subcommands) are present for the registry-driven,
10983:         // prefix-aware sink classification.
10984:         let mut registry = CommandRegistry::build_default();
10985:         registry.load_surface(SurfaceLayer::Core(Family::F5Irules, ""));
10986:         let profile = tcl_dialect::DialectProfile::irules();
10987:         let registry = registry.project_for_profile(profile);
10988:         let cu = CompilationUnit::build_for_profile(source, &registry, false, profile)
10989:             .with_interprocedural(&registry, Some(profile));
10990:         let mut out: Vec<TaintWarning> = Vec::new();
10991:         for fu in cu.analysable_functions() {
10992:             out.extend(find_taint_warnings(
10993:                 &fu.cfg,
10994:                 &fu.ssa,
10995:                 &fu.taints,
10996:                 &fu.sccp.executable_blocks,
10997:                 &registry,
10998:                 Some(tcl_dialect::DialectProfile::irules()),
10999:                 &HashSet::new(),
11000:             ));
11001:         }
11002:         out
11003:     }
11004: 
11005:     #[test]
11006:     fn redirect_safe_mask_includes_path_prefixed() {
11007:         assert!(TaintColour::REDIRECT_SAFE.contains(TaintColour::PATH_PREFIXED));
11008:         assert!(TaintColour::REDIRECT_SAFE.contains(TaintColour::PATH_NORMALISED));
11009:         // Must not spill into unrelated colours.
11010:         assert!(!TaintColour::REDIRECT_SAFE.contains(TaintColour::TAINTED));
11011:         assert!(!TaintColour::REDIRECT_SAFE.contains(TaintColour::CRLF_FREE));
11012:     }
11013: 
11014:     /// The compiler and registry colour domains are a bijection.
11015:     /// Keep both directions pinned so a future colour cannot be silently
11016:     /// dropped by a permissive bitflags conversion.
11017:     #[test]
11018:     fn registry_taint_colour_bridge_preserves_every_bit_in_both_directions() {
11019:         let registry_all = tcl_registry::TaintColour::all();
11020:         let compiler_all = TaintColour::all();
11021:         assert_eq!(reg_colour(registry_all), compiler_all);
11022:         assert_eq!(compiler_colour(compiler_all), registry_all);
11023:         for colour in [
11024:             tcl_registry::TaintColour::TAINTED,
11025:             tcl_registry::TaintColour::PATH_PREFIXED,
11026:             tcl_registry::TaintColour::NON_DASH_PREFIXED,
11027:             tcl_registry::TaintColour::CRLF_FREE,
11028:             tcl_registry::TaintColour::SHELL_ATOM,
11029:             tcl_registry::TaintColour::LIST_CANONICAL,
11030:             tcl_registry::TaintColour::REGEX_LITERAL,
11031:             tcl_registry::TaintColour::PATH_NORMALISED,
11032:             tcl_registry::TaintColour::PATH_BOUNDED,
11033:             tcl_registry::TaintColour::HEADER_TOKEN_SAFE,
11034:             tcl_registry::TaintColour::HTML_ESCAPED,
11035:             tcl_registry::TaintColour::URL_ENCODED,
11036:             tcl_registry::TaintColour::IP_ADDRESS,
11037:             tcl_registry::TaintColour::PORT,
11038:             tcl_registry::TaintColour::FQDN,
11039:             tcl_registry::TaintColour::PATH_JOINED,
11040:             tcl_registry::TaintColour::CHANNEL,
11041:         ] {
11042:             let compiler = reg_colour(colour);
11043:             assert_eq!(compiler_colour(compiler), colour, "round-trip {colour:?}");
11044:         }
11045:     }
11046: 
11047:     #[test]
11048:     fn file_join_transform_reaches_the_live_cfg_taint_lattice() {
11049:         use crate::compilation_unit::CompilationUnit;
11050: 
11051:         let registry = CommandRegistry::build_default();
11052:         let colour_for = |source: &str, name: &str| {
11053:             let cu = CompilationUnit::build_for(source, &registry, false);
11054:             let fu = cu.function("::top").expect("top-level CFG built");
11055:             fu.taints
11056:                 .iter()
11057:                 .find(|((symbol, _), _)| fu.ssa.var_name(*symbol) == name)
11058:                 .map(|(_, taint)| *taint)
11059:                 .expect("assignment has a live SSA taint value")
11060:         };
11061: 
11062:         let joined = colour_for(
11063:             "set raw [gets stdin]\nset joined [file join /base $raw]",
11064:             "joined",
11065:         );
11066:         assert!(joined.is_tainted(), "the source taint must reach file join");
11067:         assert!(
11068:             joined.colours.contains(TaintColour::PATH_JOINED),
11069:             "file join's registry transform must reach the CFG taint lattice: {joined:?}"
11070:         );
11071: 
11072:         // Mutation control: replacing the transform-bearing `file join` with
11073:         // a same-shape non-transform command removes the only PATH_JOINED
11074:         // producer. If `word_taint_at` stopped applying registry transforms,
11075:         // this and the live vector above would become indistinguishable.
11076:         let without_transform = colour_for(
11077:             "set raw [gets stdin]\nset joined [file tail $raw]",
11078:             "joined",
11079:         );
11080:         assert!(without_transform.is_tainted());
11081:         assert!(
11082:             !without_transform.colours.contains(TaintColour::PATH_JOINED),
11083:             "the mutation control must not inherit file join's transform: {without_transform:?}"
11084:         );
11085:     }
11086: 
11087:     #[test]
11088:     fn classify_irules_sink_http_respond() {
11089:         let reg = tcl_registry::model::ingress::static_context_for("f5-irules").commands();
11090:         let hit = classify_sink(
11091:             reg,
11092:             "HTTP::respond",
11093:             &[],
11094:             Some(tcl_dialect::DialectProfile::irules()),
11095:         );
11096:         assert_eq!(hit.as_ref().map(|(c, _)| *c), Some(DiagCode::Irule3001));
11097:     }
11098: 
11099:     #[test]
11100:     fn classify_irules_sink_http_header_insert() {
11101:         let reg = tcl_registry::model::ingress::static_context_for("f5-irules").commands();
11102:         let hit = classify_sink(
11103:             reg,
11104:             "HTTP::header",
11105:             &["insert".to_owned(), "X-Foo".to_owned(), "bar".to_owned()],
11106:             Some(tcl_dialect::DialectProfile::irules()),
11107:         );
11108:         assert_eq!(hit.as_ref().map(|(c, _)| *c), Some(DiagCode::Irule3002));
11109:         assert_eq!(hit.as_ref().unwrap().1, "HTTP::header insert");
11110:     }
11111: 
11112:     #[test]
11113:     fn classify_irules_sink_http_cookie_replace() {
11114:         let reg = tcl_registry::model::ingress::static_context_for("f5-irules").commands();
11115:         let hit = classify_sink(
11116:             reg,
11117:             "HTTP::cookie",
11118:             &["replace".to_owned(), "sid".to_owned(), "val".to_owned()],
11119:             Some(tcl_dialect::DialectProfile::irules()),
11120:         );
11121:         assert_eq!(hit.as_ref().map(|(c, _)| *c), Some(DiagCode::Irule3002));
11122:         assert_eq!(hit.as_ref().unwrap().1, "HTTP::cookie replace");
11123:     }
11124: 
11125:     #[test]
11126:     fn classify_irules_sink_prefix_abbreviation() {
11127:         // `HTTP::cookie ins` is a legal abbreviation of `insert`
11128:         // and must still classify as the IRULE3002 output sink.
11129:         let reg = tcl_registry::model::ingress::static_context_for("f5-irules").commands();
11130:         let hit = classify_sink(
11131:             reg,
11132:             "HTTP::cookie",
11133:             &["ins".to_owned(), "sid".to_owned(), "val".to_owned()],
11134:             Some(tcl_dialect::DialectProfile::irules()),
11135:         );
11136:         assert_eq!(hit.as_ref().map(|(c, _)| *c), Some(DiagCode::Irule3002));
11137:         // The label reports the canonical subcommand name.
11138:         assert_eq!(hit.as_ref().unwrap().1, "HTTP::cookie insert");
11139:     }
11140: 
11141:     #[test]
11142:     fn classify_irules_sink_http_header_remove_is_none() {
11143:         let reg = tcl_registry::model::ingress::static_context_for("f5-irules").commands();
11144:         let hit = classify_sink(
11145:             reg,
11146:             "HTTP::header",
11147:             &["remove".to_owned(), "X-Foo".to_owned()],
11148:             Some(tcl_dialect::DialectProfile::irules()),
11149:         );
11150:         assert!(hit.is_none(), "remove subcommand must not emit IRULE3002");
11151:     }
11152: 
11153:     #[test]
11154:     fn classify_irules_sink_log_and_redirect() {
11155:         let reg = tcl_registry::model::ingress::static_context_for("f5-irules").commands();
11156:         assert_eq!(
11157:             classify_sink(
11158:                 reg,
11159:                 "log",
11160:                 &["local0.info".to_owned(), "x".to_owned()],
11161:                 Some(tcl_dialect::DialectProfile::irules())
11162:             )
11163:             .as_ref()
11164:             .map(|(c, _)| *c),
11165:             Some(DiagCode::Irule3003),
11166:         );
11167:         assert_eq!(
11168:             classify_sink(
11169:                 reg,
11170:                 "HTTP::redirect",
11171:                 &["https://evil".to_owned()],
11172:                 Some(tcl_dialect::DialectProfile::irules())
11173:             )
11174:             .as_ref()
11175:             .map(|(c, _)| *c),
11176:             Some(DiagCode::Irule3004),
11177:         );
11178:     }
11179: 
11180:     #[test]
11181:     fn classify_sink_skips_irules_without_dialect() {
11182:         let registry = CommandRegistry::build_default();
11183:         let hit = classify_sink(&registry, "HTTP::respond", &["body".to_owned()], None);
11184:         assert!(hit.is_none(), "no dialect → no IRULE3001, got {hit:?}");
11185:     }
11186: 
11187:     #[test]
11188:     fn classify_sink_skips_irules_without_dialect_even_when_specs_loaded() {
11189:         // Stronger than `classify_sink_skips_irules_without_dialect`: the
11190:         // registry here *does* have the iRules specs loaded (as a shared
11191:         // multi-dialect registry might), so `registry.get("HTTP::respond")`
11192:         // succeeds. The IRULE3001 classification must still be withheld
11193:         // because the active *document* dialect (`None`) isn't iRules —
11194:         // mirrors `find_setter_constraint_warnings`'s explicit
11195:         // `is_irules_dialect` gate for IRULE3101.
11196:         let mut registry = CommandRegistry::build_default();
11197:         registry.load_irules();
11198:         assert!(registry.get("HTTP::respond").is_some());
11199:         let hit = classify_sink(&registry, "HTTP::respond", &["body".to_owned()], None);
11200:         assert!(
11201:             hit.is_none(),
11202:             "no dialect → no IRULE3001 even with iRules specs loaded, got {hit:?}"
11203:         );
11204:     }
11205: 
11206:     #[test]
11207:     fn classify_sink_exec_stays_t100_under_irules_dialect() {
11208:         // `exec` is universal spec data (`surface: None`); under f5-irules
11209:         // it is *banned* by the profile's §9 disable list, not by its own
11210:         // surface. T100
11211:         // classification must not route through profile availability —
11212:         // it's a plain trait fact, independent of the active document
11213:         // dialect — or `exec` would lose its T100 sink status in exactly
11214:         // the dialect where flagging it matters most.
11215:         let mut registry = CommandRegistry::build_default();
11216:         registry.load_irules();
11217:         let hit = classify_sink(
11218:             &registry,
11219:             "exec",
11220:             &["$cmd".to_owned()],
11221:             Some(tcl_dialect::DialectProfile::irules()),
11222:         );
11223:         assert_eq!(hit.as_ref().map(|(c, _)| *c), Some(DiagCode::T100));
11224:     }
11225: 
11226:     #[test]
11227:     fn irule3001_fires_on_tainted_respond_body() {
11228:         let w = irules_warnings_for("set u [HTTP::uri]\nHTTP::respond 200 content $u");
11229:         assert!(
11230:             w.iter().any(|x| x.code == DiagCode::Irule3001),
11231:             "expected IRULE3001, got {w:?}"
11232:         );
11233:     }
11234: 
11235:     #[test]
11236:     fn irule3001_no_warning_for_literal_body() {
11237:         let w = irules_warnings_for("HTTP::respond 200 content \"hello\"");
11238:         assert!(
11239:             w.iter().all(|x| x.code != DiagCode::Irule3001),
11240:             "expected no IRULE3001 on literal body, got {w:?}"
11241:         );
11242:     }
11243: 
11244:     #[test]
11245:     fn irule3002_fires_on_tainted_header_value() {
11246:         let w = irules_warnings_for("set v [HTTP::header X-Src]\nHTTP::header insert X-Echo $v");
11247:         assert!(
11248:             w.iter().any(|x| x.code == DiagCode::Irule3002),
11249:             "expected IRULE3002, got {w:?}"
11250:         );
11251:     }
11252: 
11253:     #[test]
11254:     fn irule3002_fires_in_command_sub_form() {
11255:         // Regression: `set _ [HTTP::header insert X-Foo $v]` — sink is
11256:         // inside a command substitution, so the AssignValue branch must
11257:         // preserve the subcommand args so classify_irules_sink sees
11258:         // "insert" at arg-index 0.
11259:         let w = irules_warnings_for(
11260:             "set v [HTTP::header X-Src]\nset _ [HTTP::header insert X-Echo $v]",
11261:         );
11262:         assert!(
11263:             w.iter().any(|x| x.code == DiagCode::Irule3002),
11264:             "expected IRULE3002 inside command-sub sink, got {w:?}"
11265:         );
11266:     }
11267: 
11268:     #[test]
11269:     fn irule3002_skipped_on_remove_subcommand() {
11270:         let w = irules_warnings_for("set v [HTTP::header X-Src]\nHTTP::header remove $v");
11271:         assert!(
11272:             w.iter().all(|x| x.code != DiagCode::Irule3002),
11273:             "remove subcommand must not fire IRULE3002, got {w:?}"
11274:         );
11275:     }
11276: 
11277:     #[test]
11278:     fn irule3003_fires_on_tainted_log() {
11279:         let w = irules_warnings_for("set u [HTTP::uri]\nlog local0.info $u");
11280:         assert!(
11281:             w.iter().any(|x| x.code == DiagCode::Irule3003),
11282:             "expected IRULE3003, got {w:?}"
11283:         );
11284:     }
11285: 
11286:     #[test]
11287:     fn irule3004_fires_on_tainted_redirect() {
11288:         let w = irules_warnings_for("set target [HTTP::header Location]\nHTTP::redirect $target");
11289:         assert!(
11290:             w.iter().any(|x| x.code == DiagCode::Irule3004),
11291:             "expected IRULE3004, got {w:?}"
11292:         );
11293:     }
11294: 
11295:     #[test]
11296:     fn irule3004_redirect_safe_suppresses_via_lattice() {
11297:         // Direct lattice check: tainted + REDIRECT_SAFE must suppress.
11298:         // (Latent as an end-to-end test until iRules sources are tagged
11299:         // with PATH_PREFIXED from their `taint_hints` — `HTTP::path`
11300:         // carries PATH_PREFIXED on the getter form.)
11301:         let lat = TaintLattice::tainted().with(TaintColour::PATH_PREFIXED);
11302:         assert!(sink_colour_mitigated(DiagCode::Irule3004, lat));
11303:         let lat = TaintLattice::tainted().with(TaintColour::PATH_NORMALISED);
11304:         assert!(sink_colour_mitigated(DiagCode::Irule3004, lat));
11305:         // Plain tainted should not suppress.
11306:         assert!(!sink_colour_mitigated(
11307:             DiagCode::Irule3004,
11308:             TaintLattice::tainted()
11309:         ));
11310:     }
11311: 
11312:     #[test]
11313:     fn t102_uses_ensemble_subcommand_label_and_t103_for_regexp() {
11314:         use crate::compilation_unit::CompilationUnit;
11315:         let registry = CommandRegistry::build_default();
11316:         // `file delete $u` → T102 labelled "file delete" (ensemble
11317:         // subcommand, via resolve_option_terminator). `regexp $u …` →
11318:         // T103 (regex injection) then T102 (regexp also takes `--`).
11319:         let cu = CompilationUnit::build_for(
11320:             "set u [gets stdin]\nfile delete $u\nregexp $u \"abc\"",
11321:             &registry,
11322:             false,
11323:         );
11324:         let fu = cu.function("::top").unwrap();
11325:         let warnings = find_taint_warnings(
11326:             &fu.cfg,
11327:             &fu.ssa,
11328:             &fu.taints,
11329:             &fu.sccp.executable_blocks,
11330:             &registry,
11331:             Some(tcl_registry::model::ingress::resolve_environment("tcl8.6").analyser_profile()),
11332:             &HashSet::new(),
11333:         );
11334:         let t102 = warnings.iter().find(|w| w.code == DiagCode::T102);
11335:         assert!(
11336:             t102.is_some_and(|w| w.sink_command == "file delete"),
11337:             "expected a T102 with ensemble label 'file delete', got {warnings:?}",
11338:         );
11339:         assert!(
11340:             warnings
11341:                 .iter()
11342:                 .any(|w| w.code == DiagCode::T103 && w.sink_command == "regexp"),
11343:             "expected T103 for tainted regexp pattern, got {warnings:?}",
11344:         );
11345:         // T103 must precede the regexp T102 (the pattern check is
11346:         // emitted before the sink loop).
11347:         let regexp_codes: Vec<&str> = warnings
11348:             .iter()
11349:             .filter(|w| w.sink_command == "regexp")
11350:             .map(|w| w.code.as_str())
11351:             .collect();
11352:         assert_eq!(
11353:             regexp_codes,
11354:             vec!["T103", "T102"],
11355:             "regexp warnings must be ordered T103 then T102",
11356:         );
11357:     }
11358: 
11359:     #[test]
11360:     fn t102_suppressed_after_double_dash_terminator() {
11361:         use crate::compilation_unit::CompilationUnit;
11362:         let registry = CommandRegistry::build_default();
11363:         // `file delete -- $u`: the `--` terminator protects the path
11364:         // position, so no T102 (W313 still fires elsewhere).
11365:         let cu =
11366:             CompilationUnit::build_for("set u [gets stdin]\nfile delete -- $u", &registry, false);
11367:         let fu = cu.function("::top").unwrap();
11368:         let warnings = find_taint_warnings(
11369:             &fu.cfg,
11370:             &fu.ssa,
11371:             &fu.taints,
11372:             &fu.sccp.executable_blocks,
11373:             &registry,
11374:             Some(tcl_registry::model::ingress::resolve_environment("tcl8.6").analyser_profile()),
11375:             &HashSet::new(),
11376:         );
11377:         assert!(
11378:             warnings.iter().all(|w| w.code != DiagCode::T102),
11379:             "no T102 when `--` precedes the tainted path, got {warnings:?}",
11380:         );
11381:     }
11382: 
11383:     /// FN regression (see `emit_statement_warnings`): T102 must fire for
11384:     /// a `set matched [regexp $pattern $s]` capture exactly as it does for
11385:     /// the bare `regexp $pattern $s` call it wraps — the earlier code only
11386:     /// ran the option-injection check on `Statement::Call`, silently
11387:     /// skipping the (dominant, in real Tcl) `set x [cmd ...]` idiom.
11388:     #[test]
11389:     fn t102_fires_for_assign_value_wrapped_call() {
11390:         use crate::compilation_unit::CompilationUnit;
11391:         let registry = CommandRegistry::build_default();
11392:         let cu = CompilationUnit::build_for(
11393:             "set pattern [gets stdin]\nset result [regexp $pattern $haystack]",
11394:             &registry,
11395:             false,
11396:         );
11397:         let fu = cu.function("::top").unwrap();
11398:         let warnings = find_taint_warnings(
11399:             &fu.cfg,
11400:             &fu.ssa,
11401:             &fu.taints,
11402:             &fu.sccp.executable_blocks,
11403:             &registry,
11404:             Some(tcl_registry::model::ingress::resolve_environment("tcl8.6").analyser_profile()),
11405:             &HashSet::new(),
11406:         );
11407:         assert!(
11408:             warnings
11409:                 .iter()
11410:                 .any(|w| w.code == DiagCode::T102 && w.variable == "pattern"),
11411:             "expected T102 for tainted $pattern inside `set result [regexp ...]`, got {warnings:?}"
11412:         );
11413:     }
11414: 
11415:     /// T102's diagnostic span must cover only the offending argument
11416:     /// (`$pattern`), not the whole statement — tight enough that the
11417:     /// editor squiggle sits on the actual problem, matching what W304
11418:     /// already does for the same position.
11419:     #[test]
11420:     fn t102_span_is_tight_around_the_tainted_argument_bare_call() {
11421:         use crate::compilation_unit::CompilationUnit;
11422:         let registry = CommandRegistry::build_default();
11423:         let src = "set pattern [gets stdin]\nregexp $pattern $haystack";
11424:         let cu = CompilationUnit::build_for(src, &registry, false);
11425:         let fu = cu.function("::top").unwrap();
11426:         let warnings = find_taint_warnings(
11427:             &fu.cfg,
11428:             &fu.ssa,
11429:             &fu.taints,
11430:             &fu.sccp.executable_blocks,
11431:             &registry,
11432:             Some(tcl_registry::model::ingress::resolve_environment("tcl8.6").analyser_profile()),
11433:             &HashSet::new(),
11434:         );
11435:         let t102 = warnings
11436:             .iter()
11437:             .find(|w| w.code == DiagCode::T102)
11438:             .expect("expected a T102 warning");
11439:         let slice = &src[t102.span.start() as usize..t102.span.end() as usize];
11440:         assert_eq!(
11441:             slice, "$pattern",
11442:             "T102 span should cover exactly the tainted argument, got {slice:?} from {t102:?}"
11443:         );
11444:     }
11445: 
11446:     /// Same tight-span requirement for the `set x [cmd ...]` shape: the
11447:     /// embedded command's argument has no token of its own on the
11448:     /// `AssignValue` statement, so the span is re-derived from the
11449:     /// bracketed value text — this pins that derivation to the exact
11450:     /// same byte range as the bare-call case above.
11451:     #[test]
11452:     fn t102_span_is_tight_around_the_tainted_argument_assign_value() {
11453:         use crate::compilation_unit::CompilationUnit;
11454:         let registry = CommandRegistry::build_default();
11455:         let src = "set pattern [gets stdin]\nset result [regexp $pattern $haystack]";
11456:         let cu = CompilationUnit::build_for(src, &registry, false);
11457:         let fu = cu.function("::top").unwrap();
11458:         let warnings = find_taint_warnings(
11459:             &fu.cfg,
11460:             &fu.ssa,
11461:             &fu.taints,
11462:             &fu.sccp.executable_blocks,
11463:             &registry,
11464:             Some(tcl_registry::model::ingress::resolve_environment("tcl8.6").analyser_profile()),
11465:             &HashSet::new(),
11466:         );
11467:         let t102 = warnings
11468:             .iter()
11469:             .find(|w| w.code == DiagCode::T102)
11470:             .expect("expected a T102 warning");
11471:         let slice = &src[t102.span.start() as usize..t102.span.end() as usize];
11472:         assert_eq!(
11473:             slice, "$pattern",
11474:             "T102 span should cover exactly the tainted argument, got {slice:?} from {t102:?}"
11475:         );
11476:     }
11477: 
11478:     /// T102 must carry a `--`-insertion fix anchored immediately before
11479:     /// the tainted argument, so applying it turns the flagged call into
11480:     /// the documented safe form (`regexp -- $pattern ...`).
11481:     #[test]
11482:     fn t102_carries_insert_terminator_fix_at_the_argument_start() {
11483:         use crate::compilation_unit::CompilationUnit;
11484:         let registry = CommandRegistry::build_default();
11485:         let src = "set pattern [gets stdin]\nregexp $pattern $haystack";
11486:         let cu = CompilationUnit::build_for(src, &registry, false);
11487:         let fu = cu.function("::top").unwrap();
11488:         let warnings = find_taint_warnings(
11489:             &fu.cfg,
11490:             &fu.ssa,
11491:             &fu.taints,
11492:             &fu.sccp.executable_blocks,
11493:             &registry,
11494:             Some(tcl_registry::model::ingress::resolve_environment("tcl8.6").analyser_profile()),
11495:             &HashSet::new(),
11496:         );
11497:         let t102 = warnings
11498:             .iter()
11499:             .find(|w| w.code == DiagCode::T102)
11500:             .expect("expected a T102 warning");
11501:         assert_eq!(t102.fixes.len(), 1, "expected exactly one fix: {t102:?}");
11502:         let fix = &t102.fixes[0];
11503:         assert_eq!(
11504:             fix.span.start(),
11505:             fix.span.end(),
11506:             "fix must be a pure insertion"
11507:         );
11508:         assert_eq!(fix.span.start(), t102.span.start());
11509:         assert_eq!(fix.new_text, "-- ");
11510:         let mut fixed = src.to_owned();
11511:         fixed.insert_str(fix.span.start() as usize, &fix.new_text);
11512:         assert_eq!(
11513:             fixed,
11514:             "set pattern [gets stdin]\nregexp -- $pattern $haystack"
11515:         );
11516:     }
11517: 
11518:     /// `interp alias {} myregexp {} regexp` makes `myregexp` behave
11519:     /// exactly like `regexp` at runtime (tclsh 9.0.4-verified), including
11520:     /// its option parsing — so a tainted argument reaching `myregexp`
11521:     /// must trip T102 just as it would through the bare `regexp` name.
11522:     /// `emit_statement_warnings`'s `canonical_command_or_source()` dispatch
11523:     /// (shared by the whole sink family, see the `t100_fires_through_*`
11524:     /// tests) resolves the alias for registry classification, while the
11525:     /// message and span still anchor on the alias call the source
11526:     /// actually wrote.
11527:     #[test]
11528:     fn t102_fires_through_an_interp_alias() {
11529:         use crate::compilation_unit::CompilationUnit;
11530:         let registry = CommandRegistry::build_default();
11531:         let src = "interp alias {} myregexp {} regexp\nset pattern [gets stdin]\nmyregexp $pattern $haystack";
11532:         let cu = CompilationUnit::build_for(src, &registry, false);
11533:         let fu = cu.function("::top").unwrap();
11534:         let warnings = find_taint_warnings(
11535:             &fu.cfg,
11536:             &fu.ssa,
11537:             &fu.taints,
11538:             &fu.sccp.executable_blocks,
11539:             &registry,
11540:             Some(tcl_registry::model::ingress::resolve_environment("tcl8.6").analyser_profile()),
11541:             &HashSet::new(),
11542:         );
11543:         let t102 = warnings
11544:             .iter()
11545:             .find(|w| w.code == DiagCode::T102)
11546:             .unwrap_or_else(|| {
11547:                 panic!("expected a T102 warning through the alias, got {warnings:?}")
11548:             });
11549:         assert_eq!(t102.variable, "pattern");
11550:         assert!(
11551:             t102.message.contains("'regexp'"),
11552:             "message should name the resolved target command, got {:?}",
11553:             t102.message
11554:         );
11555:         // The span/fix still anchor on the alias call's own argument,
11556:         // not some fabricated position for the aliased-to command.
11557:         assert_eq!(t102.fixes.len(), 1);
11558:         let fix = &t102.fixes[0];
11559:         let mut fixed = src.to_owned();
11560:         fixed.insert_str(fix.span.start() as usize, &fix.new_text);
11561:         assert_eq!(
11562:             fixed,
11563:             "interp alias {} myregexp {} regexp\nset pattern [gets stdin]\nmyregexp -- $pattern $haystack"
11564:         );
11565:     }
11566: 
11567:     /// `rename regexp myregexp` resolves through the same `CommandAliasMap`
11568:     /// mechanism as `interp alias` (`detect_rename`, see the T100 sibling
11569:     /// tests `t100_fires_through_rename_indirection` /
11570:     /// `t100_silent_for_unaliased_lookalike_command`), so T102 must also
11571:     /// fire through a renamed command name, not just an `interp alias`.
11572:     #[test]
11573:     fn t102_fires_through_a_rename() {
11574:         use crate::compilation_unit::CompilationUnit;
11575:         let registry = CommandRegistry::build_default();
11576:         let src = "rename regexp myregexp\nset pattern [gets stdin]\nmyregexp $pattern $haystack";
11577:         let cu = CompilationUnit::build_for(src, &registry, false);
11578:         let fu = cu.function("::top").unwrap();
11579:         let warnings = find_taint_warnings(
11580:             &fu.cfg,
11581:             &fu.ssa,
11582:             &fu.taints,
11583:             &fu.sccp.executable_blocks,
11584:             &registry,
11585:             Some(tcl_registry::model::ingress::resolve_environment("tcl8.6").analyser_profile()),
11586:             &HashSet::new(),
11587:         );
11588:         assert!(
11589:             warnings
11590:                 .iter()
11591:                 .any(|w| w.code == DiagCode::T102 && w.variable == "pattern"),
11592:             "expected T102 for tainted $pattern through the `myregexp` rename, got {warnings:?}"
11593:         );
11594:     }
11595: 
11596:     #[test]
11597:     fn irule_sinks_do_not_fire_without_dialect() {
11598:         use crate::compilation_unit::CompilationUnit;
11599:         let registry = CommandRegistry::build_default();
11600:         // Without `with_interprocedural(Some(tcl_dialect::DialectProfile::irules()))`, no dialect
11601:         // is active, and HTTP commands aren't sinks.
11602:         let cu = CompilationUnit::build_for(
11603:             "set u [HTTP::uri]\nHTTP::respond 200 content $u",
11604:             &registry,
11605:             false,
11606:         );
11607:         let fu = cu.function("::top").unwrap();
11608:         let warnings = find_taint_warnings(
11609:             &fu.cfg,
11610:             &fu.ssa,
11611:             &fu.taints,
11612:             &fu.sccp.executable_blocks,
11613:             &registry,
11614:             None,
11615:             &HashSet::new(),
11616:         );
11617:         assert!(
11618:             warnings
11619:                 .iter()
11620:                 .all(|w| !w.code.as_str().starts_with("IRULE")),
11621:             "no IRULE warnings without dialect, got {warnings:?}"
11622:         );
11623:     }
11624: 
11625:     #[test]
11626:     fn sink_colour_mitigated_html_escaped_only_mitigates_3001() {
11627:         let tainted_html = TaintLattice::tainted().with(TaintColour::HTML_ESCAPED);
11628:         // IRULE3001 (HTTP response body) — HTML_ESCAPED directly mitigates.
11629:         assert!(sink_colour_mitigated(DiagCode::Irule3001, tainted_html));
11630:         // IRULE3002/3003 (header / log) — HTML_ESCAPED does NOT prove
11631:         // CRLF-injection safety (the escape rewrites `<`/`>`/`&` but
11632:         // leaves raw CR/LF untouched). The CRLF-safe mask excludes
11633:         // `HTML_ESCAPED`.
11634:         assert!(!sink_colour_mitigated(DiagCode::Irule3002, tainted_html));
11635:         assert!(!sink_colour_mitigated(DiagCode::Irule3003, tainted_html));
11636:         // IRULE3004 (redirect) — also not mitigated by HTML_ESCAPED.
11637:         assert!(!sink_colour_mitigated(DiagCode::Irule3004, tainted_html));
11638: 
11639:         // `CRLF_FREE` does suppress IRULE3002/3003 (the one mitigation
11640:         // accepted in the value position).
11641:         let tainted_crlf_free = TaintLattice::tainted().with(TaintColour::CRLF_FREE);
11642:         assert!(sink_colour_mitigated(
11643:             DiagCode::Irule3002,
11644:             tainted_crlf_free
11645:         ));
11646:         assert!(sink_colour_mitigated(
11647:             DiagCode::Irule3003,
11648:             tainted_crlf_free
11649:         ));
11650:     }
11651: 
11652:     #[test]
11653:     fn original_scalar_reference_consumers_keep_literal_words_and_current_closers() {
11654:         for label in ["tcl8.6", "tcl9.1"] {
11655:             let registry = tcl_registry::model::ingress::static_context_for(label).commands();
11656:             let config = TaintSourceContext::standalone(registry, registry.profile()).config;
11657:             for (spelling, expected) in [
11658:                 ("${$literal}", Some("$literal")),
11659:                 ("${}", Some("")),
11660:                 ("{$literal}", None),
11661:                 ("{${literal}}", None),
11662:                 ("$arr(key)", None),
11663:                 ("${arr(key)}", None),
11664:                 ("prefix$x", None),
11665:                 (r"\$x", None),
11666:             ] {
11667:                 let word = crate::value_shapes::value_word_with_config(spelling, config).unwrap();
11668:                 assert_eq!(
11669:                     original_scalar_reference_name(&word, config),
11670:                     expected,
11671:                     "{label}: {spelling}"
11672:                 );
11673:             }
11674:             let cfg = crate::cfg::Function::new("model", "entry");
11675:             let mut ssa = SsaFunction::trivial("model", cfg.entry, cfg.block_names().to_vec());
11676:             let symbol = ssa.intern_var("$literal");
11677:             let statement = ssa_stmt(
11678:                 Statement::Incr {
11679:                     span: Span::new(0, 0),
11680:                     name: "$literal".into(),
11681:                     name_braced: true,
11682:                     amount: None,
11683:                     amount_braced: false,
11684:                     safe_on_uninit: false,
11685:                 },
11686:                 HashMap::from([(symbol, 1)]),
11687:                 HashMap::new(),
11688:             );
11689:             let taints = HashMap::from([((symbol, 1), TaintLattice::tainted())]);
11690:             for (spelling, expected) in [("${$literal}", 1), ("{$literal}", 0)] {
11691:                 let word = crate::value_shapes::value_word_with_config(spelling, config).unwrap();
11692:                 let mut warnings = Vec::new();
11693:                 emit_dynamic_command_head_warning(
11694:                     Some((&word, config)),
11695:                     &statement,
11696:                     &taints,
11697:                     &mut warnings,
11698:                     &ssa,
11699:                 );
11700:                 assert_eq!(warnings.len(), expected, "{label}: {spelling}");
11701:                 if let Some(warning) = warnings.first() {
11702:                     assert_eq!(warning.variable, "$literal");
11703:                 }
11704:             }
11705:             let mut warnings = Vec::new();
11706:             emit_dynamic_command_head_warning(None, &statement, &taints, &mut warnings, &ssa);
11707:             assert!(warnings.is_empty());
11708:             let word = crate::value_shapes::value_word_with_config("${a{b}c}", config).unwrap();
11709:             assert_eq!(
11710:                 original_scalar_reference_name(&word, config),
11711:                 if label == "tcl9.1" {
11712:                     Some("a{b}c")
11713:                 } else {
11714:                     None
11715:                 }
11716:             );
11717:         }
11718:         let registry = tcl_registry::model::ingress::static_context_for("f5-irules").commands();
11719:         let config = TaintSourceContext::standalone(registry, registry.profile()).config;
11720:         let lat = TaintLattice::tainted().with(TaintColour::HEADER_TOKEN_SAFE);
11721:         for (spelling, name, expected) in [
11722:             ("${$literal}", "$literal", true),
11723:             ("${}", "", true),
11724:             ("{$literal}", "literal", false),
11725:         ] {
11726:             let args = vec![
11727:                 "insert".to_owned(),
11728:                 spelling.to_owned(),
11729:                 "$value".to_owned(),
11730:             ];
11731:             let word = crate::value_shapes::value_word_with_config(spelling, config).unwrap();
11732:             assert_eq!(
11733:                 irule3002_name_position_safe(
11734:                     registry,
11735:                     "HTTP::header",
11736:                     &args,
11737:                     name,
11738:                     lat,
11739:                     Some(&word),
11740:                     config
11741:                 ),
11742:                 expected
11743:             );
11744:             assert!(!irule3002_name_position_safe(
11745:                 registry,
11746:                 "HTTP::header",
11747:                 &args,
11748:                 name,
11749:                 lat,
11750:                 None,
11751:                 config
11752:             ));
11753:         }
11754:     }
11755: 
11756:     #[test]
11757:     fn irule3002_header_token_safe_name_position_suppresses() {
11758:         let registry = tcl_registry::model::ingress::static_context_for("f5-irules").commands();
11759:         let args = vec!["insert".to_owned(), "$name".to_owned(), "$value".to_owned()];
11760:         let config = TaintSourceContext::standalone(registry, registry.profile()).config;
11761:         let name_word = crate::value_shapes::value_word_with_config(&args[1], config).unwrap();
11762:         let lat = TaintLattice::tainted().with(TaintColour::HEADER_TOKEN_SAFE);
11763:         // Var `name` occupies arg-index 1 (name position) → suppressed.
11764:         assert!(irule3002_name_position_safe(
11765:             registry,
11766:             "HTTP::header",
11767:             &args,
11768:             "name",
11769:             lat,
11770:             Some(&name_word),
11771:             config,
11772:         ));
11773:         // Var `value` occupies arg-index 2 (value position) → not suppressed.
11774:         assert!(!irule3002_name_position_safe(
11775:             registry,
11776:             "HTTP::header",
11777:             &args,
11778:             "value",
11779:             lat,
11780:             Some(&name_word),
11781:             config,
11782:         ));
11783:         // Without HEADER_TOKEN_SAFE colour: never suppressed, even at name position.
11784:         let plain = TaintLattice::tainted();
11785:         assert!(!irule3002_name_position_safe(
11786:             registry,
11787:             "HTTP::header",
11788:             &args,
11789:             "name",
11790:             plain,
11791:             Some(&name_word),
11792:             config,
11793:         ));
11794:         // Wrong subcommand: not suppressed.
11795:         let rm_args = vec!["remove".to_owned(), "$name".to_owned()];
11796:         assert!(!irule3002_name_position_safe(
11797:             registry,
11798:             "HTTP::header",
11799:             &rm_args,
11800:             "name",
11801:             lat,
11802:             Some(&name_word),
11803:             config,
11804:         ));
11805:     }
11806: 
11807:     // IRULE3101 — setter-constraint violations
11808: 
11809:     /// Default helper: run the setter check under the `f5-irules` dialect
11810:     /// (which is the only dialect that can surface IRULE3101 post-internal-gate).
11811:     fn setter_warnings_for(source: &str) -> Vec<TaintWarning> {
11812:         setter_warnings_for_dialect(source, Some(tcl_dialect::DialectProfile::irules()))
11813:     }
11814: 
11815:     fn setter_warnings_for_dialect(
11816:         source: &str,
11817:         dialect: Option<&'static tcl_dialect::DialectProfile>,
11818:     ) -> Vec<TaintWarning> {
11819:         use crate::compilation_unit::CompilationUnit;
11820:         let mut registry = CommandRegistry::build_default();
11821:         // The IRULE3101 setter constraints live on the iRules specs, so the
11822:         // registry must have them loaded for the dialect-gated check to see
11823:         // anything.
11824:         registry.load_irules();
11825:         let mut cu = CompilationUnit::build_for(source, &registry, false);
11826:         if dialect.is_some() {
11827:             cu = cu.with_interprocedural(&registry, dialect);
11828:         }
11829:         let mut out: Vec<TaintWarning> = Vec::new();
11830:         for fu in cu.analysable_functions() {
11831:             out.extend(find_setter_constraint_warnings(
11832:                 &registry,
11833:                 &fu.cfg,
11834:                 &fu.ssa,
11835:                 &fu.taints,
11836:                 Some(&fu.sccp.values),
11837:                 &fu.sccp.executable_blocks,
11838:                 dialect,
11839:             ));
11840:         }
11841:         out
11842:     }
11843: 
11844:     #[test]
11845:     fn irule3101_literal_missing_slash_warns() {
11846:         let w = setter_warnings_for("HTTP::uri foo");
11847:         assert_eq!(w.len(), 1);
11848:         assert_eq!(w[0].code, DiagCode::Irule3101);
11849:         assert!(w[0].message.contains("HTTP::uri value must start"));
11850:     }
11851: 
11852:     #[test]
11853:     fn irule3101_literal_with_slash_clean() {
11854:         let w = setter_warnings_for("HTTP::uri /foo");
11855:         assert_eq!(w.len(), 0, "literal /foo must be clean, got {w:?}");
11856:     }
11857: 
11858:     #[test]
11859:     fn irule3101_http_path_literal_variants() {
11860:         let bad = setter_warnings_for("HTTP::path bar");
11861:         assert_eq!(bad.len(), 1);
11862:         assert_eq!(bad[0].code, DiagCode::Irule3101);
11863:         let good = setter_warnings_for("HTTP::path /bar");
11864:         assert_eq!(good.len(), 0);
11865:     }
11866: 
11867:     #[test]
11868:     fn irule3101_generic_taint_warns() {
11869:         // `HTTP::header X-Foo` is a tainted source; reusing it as a path
11870:         // has generic taint (no PATH_PREFIXED / _NORMALISED / _BOUNDED).
11871:         let w = setter_warnings_for("set v [HTTP::header X-Foo]\nHTTP::uri $v");
11872:         assert!(
11873:             w.iter().any(|x| x.code == DiagCode::Irule3101),
11874:             "generic taint must fire IRULE3101, got {w:?}"
11875:         );
11876:     }
11877: 
11878:     #[test]
11879:     fn irule3101_pure_var_ref_always_warns_without_safe_colour() {
11880:         // A plain `$p` setter value (no taint + no provable path colour)
11881:         // that the lattice cannot pin — two arms set two values — cannot be
11882:         // proved `/`-prefixed by the static analyser, so IRULE3101 fires.
11883:         // Latent suppression paths via tainted-with-PATH_PREFIXED /
11884:         // _NORMALISED / _BOUNDED colours will light up once iRules source
11885:         // `taint_hints` reach the lattice. A value the lattice proves is
11886:         // checked as a literal is (#2055): `set p /safe` is clean.
11887:         let w = setter_warnings_for(
11888:             "if {[HTTP::has_responded]} { set p /safe } else { set p safe }\nHTTP::uri $p",
11889:         );
11890:         assert!(
11891:             w.iter().any(|x| x.code == DiagCode::Irule3101),
11892:             "pure var-ref setter value must warn without tainted-safe-colour, got {w:?}"
11893:         );
11894:         let w = setter_warnings_for("set p /safe\nHTTP::uri $p");
11895:         assert!(
11896:             !w.iter().any(|x| x.code == DiagCode::Irule3101),
11897:             "a proven `/` path is clean, got {w:?}"
11898:         );
11899:     }
11900: 
11901:     #[test]
11902:     fn irule3101_dynamic_command_sub_warns() {
11903:         // RHS is a command sub `[foo]` → hits the dynamic branch, which
11904:         // always warns. The literal-check also bails on `[`.
11905:         let w = setter_warnings_for("HTTP::uri [something]");
11906:         assert!(
11907:             w.iter().any(|x| x.code == DiagCode::Irule3101),
11908:             "command-sub setter value must warn, got {w:?}"
11909:         );
11910:     }
11911: 
11912:     #[test]
11913:     fn irule3101_internally_gated_on_dialect() {
11914:         // Defence-in-depth: even if a caller invokes
11915:         // `find_setter_constraint_warnings` directly (bypassing
11916:         // `run_all_checks`), IRULE3101 must not fire under a non-iRules
11917:         // dialect against user-defined commands named `HTTP::uri` /
11918:         // `HTTP::path`.
11919:         let under_irules = setter_warnings_for_dialect(
11920:             "HTTP::uri foo",
11921:             Some(tcl_dialect::DialectProfile::irules()),
11922:         );
11923:         assert_eq!(under_irules.len(), 1);
11924:         assert_eq!(under_irules[0].code, DiagCode::Irule3101);
11925: 
11926:         let under_none = setter_warnings_for_dialect("HTTP::uri foo", None);
11927:         assert_eq!(
11928:             under_none.len(),
11929:             0,
11930:             "no IRULE3101 under None dialect, got {under_none:?}"
11931:         );
11932: 
11933:         let under_tcl = setter_warnings_for_dialect(
11934:             "HTTP::uri foo",
11935:             Some(tcl_registry::model::ingress::resolve_environment("tcl").analyser_profile()),
11936:         );
11937:         assert_eq!(
11938:             under_tcl.len(),
11939:             0,
11940:             "no IRULE3101 under tcl dialect, got {under_tcl:?}"
11941:         );
11942:     }
11943: 
11944:     // registry-driven source / sink / setter-constraint coverage
11945: 
11946:     /// The Tcl-core source classification flows from the registry's
11947:     /// [`Traits::TAINT_SOURCE`] flag: registry-side query and
11948:     /// end-to-end taint-warning emission must agree on `gets` /
11949:     /// `read` / `exec` / `socket`.
11950:     #[test]
11951:     fn arch3_tcl_core_source_is_registry_driven() {
11952:         use crate::compilation_unit::CompilationUnit;
11953:         let registry = CommandRegistry::build_default();
11954:         // Registry-side: TAINT_SOURCE trait is stamped on these.
11955:         for cmd in ["gets", "read", "exec", "socket"] {
11956:             let spec = registry.get(cmd).unwrap_or_else(|| panic!("{cmd} missing"));
11957:             assert!(
11958:                 spec.traits.contains(tcl_registry::Traits::TAINT_SOURCE),
11959:                 "{cmd} must carry TAINT_SOURCE in the registry",
11960:             );
11961:         }
11962:         // Same fact via the registry-side taint helper.
11963:         assert!(tcl_registry::taint::is_taint_source(
11964:             &registry,
11965:             "gets",
11966:             &["stdin"],
11967:             None,
11968:         ));
11969: 
11970:         // End-to-end: `gets` → `eval` raises T100. The fact reaches
11971:         // the diagnostic via the registry, not via a compiler-side
11972:         // command-name table.
11973:         let cu = CompilationUnit::build_for("set x [gets stdin]\neval $x", &registry, false)
11974:             .with_interprocedural(&registry, None);
11975:         let mut warnings: Vec<TaintWarning> = Vec::new();
11976:         for fu in cu.analysable_functions() {
11977:             warnings.extend(find_taint_warnings(
11978:                 &fu.cfg,
11979:                 &fu.ssa,
11980:                 &fu.taints,
11981:                 &fu.sccp.executable_blocks,
11982:                 &registry,
11983:                 None,
11984:                 &HashSet::new(),
11985:             ));
11986:         }
11987:         assert!(
11988:             warnings.iter().any(|w| w.code == DiagCode::T100),
11989:             "expected T100 from gets→eval with registry-driven source, got {warnings:?}",
11990:         );
11991:     }
11992: 
11993:     /// The iRules sink classification is registry-driven (via
11994:     /// `TAINT_SINK` and `EVALUATES_CODE` traits): tainted data into
11995:     /// `expr` (which carries `TAINT_SINK`) raises T100. The trait
11996:     /// is the single source of truth — flipping it removes the
11997:     /// classification.
11998:     #[test]
11999:     fn arch3_irules_sink_is_registry_driven() {
12000:         let registry = CommandRegistry::build_default();
12001:         let expr_spec = registry.get("expr").expect("expr in registry");
12002:         assert!(
12003:             expr_spec.traits.contains(tcl_registry::Traits::TAINT_SINK),
12004:             "expr must carry TAINT_SINK in the registry",
12005:         );
12006: 
12007:         // End-to-end: tainted iRules data (`HTTP::uri`) into expr
12008:         // surfaces T100 under the iRules dialect.
12009:         let w = irules_warnings_for("set u [HTTP::uri]\nexpr $u");
12010:         assert!(
12011:             w.iter().any(|d| d.code == DiagCode::T100),
12012:             "expected T100 on tainted expr sink under iRules, got {w:?}",
12013:         );
12014:     }
12015: 
12016:     /// IRULE3101 setter-constraint violations are gated by the
12017:     /// iRules dialect filter — the diagnostic must not fire under
12018:     /// the plain Tcl dialect because the setter constraint comes
12019:     /// from the iRules-only registry entry.
12020:     #[test]
12021:     fn arch3_setter_constraint_is_dialect_driven() {
12022:         // `HTTP::uri foo` (no leading slash) under iRules produces
12023:         // an IRULE3101 setter-constraint violation.
12024:         let irules = setter_warnings_for_dialect(
12025:             "HTTP::uri foo",
12026:             Some(tcl_dialect::DialectProfile::irules()),
12027:         );
12028:         assert!(
12029:             irules.iter().any(|w| w.code == DiagCode::Irule3101),
12030:             "expected IRULE3101 under iRules dialect, got {irules:?}",
12031:         );
12032: 
12033:         // The same source under plain Tcl: a user-defined proc named
12034:         // `HTTP::uri` is legal and the setter check must stay silent.
12035:         let plain = setter_warnings_for_dialect("HTTP::uri foo", None);
12036:         assert!(
12037:             plain.iter().all(|w| w.code != DiagCode::Irule3101),
12038:             "no IRULE3101 outside iRules, got {plain:?}",
12039:         );
12040:     }
12041: 
12042:     #[test]
12043:     fn taint_warnings_emitted_in_deterministic_proc_order() {
12044:         use crate::compilation_unit::CompilationUnit;
12045:         let registry = CommandRegistry::build_default();
12046:         // `bbb` is defined *before* `aaa` in source. Per-proc warning order
12047:         // must follow qualified name (aaa, then bbb) — not source order and
12048:         // not the (random) HashMap order — so the output is reproducible.
12049:         let source = "proc bbb {p} { set v [exec $p]\n eval $v }\n\
12050:                       proc aaa {p} { set v [exec $p]\n eval $v }\n";
12051:         let cu = CompilationUnit::build_for(source, &registry, false)
12052:             .with_interprocedural(&registry, None);
12053:         let warnings = find_taint_warnings_for_cu(&cu, &registry, None);
12054:         assert_eq!(warnings.len(), 2, "one eval sink per proc: {warnings:?}");
12055:         // `aaa` is defined later in source (larger span) yet sorts first.
12056:         assert!(
12057:             warnings[0].span.start() > warnings[1].span.start(),
12058:             "expected name order (aaa before bbb) regardless of source order: {warnings:?}",
12059:         );
12060:     }
12061: 
12062:     /// The fixture driver supplies Tk 8.6.13 before analysing registrations.
12063:     /// Its `tkWindow.c` entry/bind rows use `Tcl_CreateObjCommand`; neither
12064:     /// installs a compiler hook. This is actual loader provenance, separately
12065:     /// from the callback metadata queried by taint analysis.
12066:     fn loaded_tk_callback_unit(
12067:         source: &str,
12068:     ) -> (crate::compilation_unit::CompilationUnit, CommandRegistry) {
12069:         let registry = CommandRegistry::build_default().project_for_profile(
12070:             tcl_dialect::DialectProfile::find("tcl8.6").expect("selected native profile"),
12071:         );
12072:         let mut entry =
12073:             crate::provider_fixtures::entry(&registry, &[crate::provider_fixtures::Provider::Tk])
12074:                 .as_ref()
12075:                 .clone();
12076:         let loader = entry
12077:             .trusted_package_loaders
12078:             .first_mut()
12079:             .expect("Tk provider");
12080:         for command in ["entry", "bind"] {
12081:             loader.compiler_hooks.insert(
12082:                 command.to_owned(),
12083:                 tcl_runtime_api::native_compilation::NativeCompilerHookPresence::Absent,
12084:             );
12085:         }
12086:         let source = format!("package require Tk\n{source}");
12087:         let unit = crate::compilation_unit::CompilationUnit::build_with_source_entry(
12088:             &source,
12089:             crate::compilation_unit::UnitBuildOptions {
12090:                 registry: &registry,
12091:                 defer_top_level: false,
12092:                 config: tcl_lexer::LexerConfig::for_profile(registry.profile()),
12093:                 dialect: registry.profile(),
12094:                 external_call_sites: None,
12095:                 declared_commands: None,
12096:             },
12097:             &entry,
12098:         )
12099:         .with_interprocedural(&registry, None);
12100:         (unit, registry)
12101:     }
12102: 
12103:     #[test]
12104:     fn command_substitution_callbacks_stop_before_replay_when_original_owner_is_refused() {
12105:         // naming.source.retained-positioned-command-realm
12106:         // docs/design/analysis/name-resolution-proofs/retained-positioned-command-realm.md
12107:         // The loaded fixture supplies Tk provenance. These are compiler replay
12108:         // controls, not claims about executing an external Tk event.
12109:         let (unit, registry) = loaded_tk_callback_unit(
12110:             "proc helper {value} {eval $value}\nentry .entry -validatecommand [list helper %P]",
12111:         );
12112:         reset_callback_replay_build_count();
12113:         reset_callback_replay_name_search_count();
12114:         let positive = find_callback_substitution_warnings(&unit, &registry, None, &[]);
12115:         assert!(
12116:             positive
12117:                 .iter()
12118:                 .any(|warning| warning.code == DiagCode::T100),
12119:             "the owned list-prefix callback remains replayable: {positive:?}"
12120:         );
12121:         assert_eq!(callback_replay_build_count(), 1);
12122:         assert_eq!(callback_replay_name_search_count(), 1);
12123:         let mut missing = unit.clone();
12124:         missing.ir_module.retained_source_bindings = None;
12125:         let mut changed = unit.clone();
12126:         changed.ir_module.source =
12127:             tcl_lexer::SourceImage::document("entry .entry -validatecommand {};");
12128:         for refused in [missing, changed] {
12129:             reset_callback_replay_build_count();
12130:             reset_callback_replay_name_search_count();
12131:             assert!(find_callback_substitution_warnings(&refused, &registry, None, &[]).is_empty());
12132:             assert_eq!(callback_replay_build_count(), 0);
12133:             assert_eq!(callback_replay_name_search_count(), 0);
12134:         }
12135:     }
12136: 
12137:     #[test]
12138:     fn callback_replays_batch_into_one_extra_interprocedural_build() {
12139:         let source = "entry .one -validatecommand {eval %P}\n\
12140:                       entry .two -validatecommand {eval %S}\n\
12141:                       bind .two <Key> {eval %A}";
12142:         let (cu, registry) = loaded_tk_callback_unit(source);
12143:         reset_callback_replay_build_count();
12144:         let warnings = find_taint_warnings_for_cu(&cu, &registry, None);
12145:         assert_eq!(
12146:             callback_replay_build_count(),
12147:             1,
12148:             "every statically recoverable callback must share one replay solve"
12149:         );
12150:         assert_eq!(
12151:             warnings.len(),
12152:             3,
12153:             "each registered sink still warns: {warnings:?}"
12154:         );
12155:     }
12156: 
12157:     #[test]
12158:     fn callback_replay_batches_past_the_first_batch_without_truncating_later_sinks() {
12159:         use std::fmt::Write as _;
12160: 
12161:         let mut source = String::new();
12162:         for index in 0..=MAX_CALLBACK_TAINT_REPLAYS {
12163:             writeln!(
12164:                 &mut source,
12165:                 "entry .benign{index} -validatecommand {{set value %P}}"
12166:             )
12167:             .expect("write to String");
12168:         }
12169:         source.push_str("entry .malicious -validatecommand {eval %P}");
12170:         let (cu, registry) = loaded_tk_callback_unit(&source);
12171:         let malicious_start = u32::try_from(
12172:             cu.source
12173:                 .rfind("{eval %P}")
12174:                 .expect("malicious callback is present"),
12175:         )
12176:         .expect("test source fits in u32");
12177: 
12178:         reset_callback_replay_build_count();
12179:         let warnings = find_taint_warnings_for_cu(&cu, &registry, None);
12180: 
12181:         assert_eq!(
12182:             callback_replay_build_count(),
12183:             2,
12184:             "callbacks beyond one replay batch must receive a second bounded solve"
12185:         );
12186:         assert!(
12187:             warnings.iter().any(|warning| {
12188:                 warning.code == DiagCode::T100 && warning.span.start() == malicious_start
12189:             }),
12190:             "the callback after 32 benign registrations must still warn: {warnings:?}"
12191:         );
12192:     }
12193: 
12194:     #[test]
12195:     fn unprovided_tk_callbacks_do_not_gain_replay_authority_from_catalogue() {
12196:         let registry = CommandRegistry::build_default().project_for_profile(
12197:             tcl_dialect::DialectProfile::find("tcl8.6").expect("selected native profile"),
12198:         );
12199:         let source = "package require Tk; entry .one -validatecommand {eval %P}";
12200:         let cu = crate::compilation_unit::CompilationUnit::build_for(source, &registry, false)
12201:             .with_interprocedural(&registry, None);
12202:         reset_callback_replay_build_count();
12203:         let _ = find_taint_warnings_for_cu(&cu, &registry, None);
12204:         assert_eq!(callback_replay_build_count(), 0);
12205:     }
12206: 
12207:     #[test]
12208:     fn callback_free_units_skip_replay_name_search_and_solve() {
12209:         use crate::compilation_unit::CompilationUnit;
12210: 
12211:         let registry = CommandRegistry::build_default();
12212:         for source in [
12213:             "set value fixed\nputs $value",
12214:             // This is a callback registration, but its builder is dynamic and
12215:             // therefore deliberately has no statically recoverable replay.
12216:             "entry .entry -validatecommand [format {eval %P}]",
12217:         ] {
12218:             let cu = CompilationUnit::build_for(source, &registry, false)
12219:                 .with_interprocedural(&registry, None);
12220:             reset_callback_replay_build_count();
12221:             reset_callback_replay_name_search_count();
12222:             let _warnings = find_taint_warnings_for_cu(&cu, &registry, None);
12223:             assert_eq!(
12224:                 callback_replay_build_count(),
12225:                 0,
12226:                 "no recoverable callback may compile an empty replay: {source}"
12227:             );
12228:             assert_eq!(
12229:                 callback_replay_name_search_count(),
12230:                 0,
12231:                 "no recoverable callback may scan source for replay names: {source}"
12232:             );
12233:         }
12234:     }
12235: 
12236:     #[test]
12237:     fn callback_replay_name_search_is_single_pass_under_collision_stress() {
12238:         use std::fmt::Write as _;
12239: 
12240:         let mut source = String::new();
12241:         for suffix in 0..(MAX_CALLBACK_TAINT_REPLAYS + 8) {
12242:             let input = if suffix == 0 {
12243:                 CALLBACK_REPLAY_INPUT_VAR_BASE.to_owned()
12244:             } else {
12245:                 format!("{CALLBACK_REPLAY_INPUT_VAR_BASE}_{suffix}")
12246:             };
12247:             let proc = if suffix == 0 {
12248:                 CALLBACK_REPLAY_PROC_BASE.to_owned()
12249:             } else {
12250:                 format!("{CALLBACK_REPLAY_PROC_BASE}_{suffix}")
12251:             };
12252:             writeln!(
12253:                 &mut source,
12254:                 "set {input} safe\nproc ::{proc}_0 {{}} {{ return }}"
12255:             )
12256:             .expect("write to String");
12257:         }
12258:         source.push_str("entry .entry -validatecommand {eval %P}");
12259: 
12260:         let (cu, registry) = loaded_tk_callback_unit(&source);
12261:         reset_callback_replay_build_count();
12262:         reset_callback_replay_name_search_count();
12263:         let warnings = find_taint_warnings_for_cu(&cu, &registry, None);
12264:         assert!(
12265:             warnings
12266:                 .iter()
12267:                 .any(|warning| warning.code == DiagCode::T100),
12268:             "collision avoidance must preserve the callback warning: {warnings:?}"
12269:         );
12270:         assert_eq!(callback_replay_build_count(), 1);
12271:         assert_eq!(
12272:             callback_replay_name_search_count(),
12273:             1,
12274:             "even a collision-rich source gets one linear synthetic-name scan"
12275:         );
12276:     }
12277: 
12278:     /// TP: `interp alias {} myEval {} eval; myEval $x` still raises T100 —
12279:     /// `classify_sink` dispatches on `Statement::canonical_command_or_source()`,
12280:     /// so the alias resolves to `eval` even though the source spells the call
12281:     /// `myEval`, which is not itself a registered command.
12282:     #[test]
12283:     fn t100_fires_through_interp_alias_indirection() {
12284:         use crate::compilation_unit::CompilationUnit;
12285:         let registry = CommandRegistry::build_default();
12286:         let source = "interp alias {} myEval {} eval\n\
12287:                        set x [gets stdin]\n\
12288:                        myEval $x\n";
12289:         let cu = CompilationUnit::build_for(source, &registry, false)
12290:             .with_interprocedural(&registry, None);
12291:         let warnings = find_taint_warnings_for_cu(&cu, &registry, None);
12292:         assert!(
12293:             warnings.iter().any(|w| w.code == DiagCode::T100),
12294:             "expected T100 through the `myEval` alias for `eval`, got {warnings:?}",
12295:         );
12296:     }
12297: 
12298:     /// TP: `rename eval myEval; myEval $x` also raises T100 — the same
12299:     /// `CommandAliasMap` mechanism `interp alias` uses now also recognises
12300:     /// a static `rename oldName newName` (`detect_rename`), so a renamed
12301:     /// built-in resolves through `canonical_command_or_source()` exactly
12302:     /// like an `interp alias`.
12303:     #[test]
12304:     fn t100_fires_through_rename_indirection() {
12305:         use crate::compilation_unit::CompilationUnit;
12306:         let registry = CommandRegistry::build_default();
12307:         let source = "rename eval myEval\n\
12308:                        set x [gets stdin]\n\
12309:                        myEval $x\n";
12310:         let cu = CompilationUnit::build_for(source, &registry, false)
12311:             .with_interprocedural(&registry, None);
12312:         let warnings = find_taint_warnings_for_cu(&cu, &registry, None);
12313:         assert!(
12314:             warnings.iter().any(|w| w.code == DiagCode::T100),
12315:             "expected T100 through the `myEval` rename of `eval`, got {warnings:?}",
12316:         );
12317:     }
12318: 
12319:     /// TN: without the alias, a plain user command named `myEval` is not a
12320:     /// sink at all — proves the alias fix above isn't matching on the bare
12321:     /// name.
12322:     #[test]
12323:     fn t100_silent_for_unaliased_lookalike_command() {
12324:         use crate::compilation_unit::CompilationUnit;
12325:         let registry = CommandRegistry::build_default();
12326:         let source = "proc myEval {x} { return $x }\n\
12327:                        set x [gets stdin]\n\
12328:                        myEval $x\n";
12329:         let cu = CompilationUnit::build_for(source, &registry, false)
12330:             .with_interprocedural(&registry, None);
12331:         let warnings = find_taint_warnings_for_cu(&cu, &registry, None);
12332:         assert!(
12333:             warnings.iter().all(|w| w.code != DiagCode::T100),
12334:             "a user proc named myEval must not be treated as the eval sink, got {warnings:?}",
12335:         );
12336:     }
12337: 
12338:     /// TP: `puts $tainted` still raises T101 (not T100) end-to-end, now via
12339:     /// the registry-driven `taint_output_sink` dispatch in `classify_sink`
12340:     /// rather than a hardcoded `command == "puts"` match.
12341:     #[test]
12342:     fn t101_fires_for_puts_via_registry_driven_dispatch() {
12343:         use crate::compilation_unit::CompilationUnit;
12344:         let registry = CommandRegistry::build_default();
12345:         let source = "set x [gets stdin]\nputs $x\n";
12346:         let cu = CompilationUnit::build_for(source, &registry, false)
12347:             .with_interprocedural(&registry, None);
12348:         let warnings = find_taint_warnings_for_cu(&cu, &registry, None);
12349:         assert!(
12350:             warnings.iter().any(|w| w.code == DiagCode::T101),
12351:             "expected T101 for tainted puts, got {warnings:?}",
12352:         );
12353:         assert!(
12354:             warnings.iter().all(|w| w.code != DiagCode::T100),
12355:             "puts must not also raise T100, got {warnings:?}",
12356:         );
12357:     }
12358: 
12359:     /// TP: `open $tainted` raises T100. A `fileName` argument whose first
12360:     /// character is `|` runs the rest of the word as a command pipeline —
12361:     /// the same command-injection hazard `exec` carries — so tainted data
12362:     /// reaching `open`'s first argument is a code-execution sink exactly
12363:     /// like `exec`, not merely a file-I/O one.
12364:     #[test]
12365:     fn t100_fires_for_open_tainted_filename() {
12366:         use crate::compilation_unit::CompilationUnit;
12367:         let registry = CommandRegistry::build_default();
12368:         assert!(
12369:             registry
12370:                 .get("open")
12371:                 .expect("open in registry")
12372:                 .traits
12373:                 .contains(tcl_registry::Traits::TAINT_SINK),
12374:             "open must carry TAINT_SINK in the registry",
12375:         );
12376:         let source = "set x [gets stdin]\nopen $x r\n";
12377:         let cu = CompilationUnit::build_for(source, &registry, false)
12378:             .with_interprocedural(&registry, None);
12379:         let warnings = find_taint_warnings_for_cu(&cu, &registry, None);
12380:         assert!(
12381:             warnings.iter().any(|w| w.code == DiagCode::T100),
12382:             "expected T100 for tainted open fileName, got {warnings:?}",
12383:         );
12384:     }
12385: 
12386:     /// FP fix / TN: `open /tmp/out $mode` — a *literal* safe fileName with a
12387:     /// tainted access-mode argument must not raise T100. Only arg 0 selects a
12388:     /// `|`-pipeline; a tainted access mode or octal permissions can never
12389:     /// turn a literal path into a command, so `open`'s `taint_code_sink_args
12390:     /// = Some(&[0])` gates the sink to the fileName slot alone.
12391:     #[test]
12392:     fn t100_silent_for_open_tainted_access_mode() {
12393:         use crate::compilation_unit::CompilationUnit;
12394:         let registry = CommandRegistry::build_default();
12395:         let source = "set mode [gets stdin]\nopen /tmp/out $mode\n";
12396:         let cu = CompilationUnit::build_for(source, &registry, false)
12397:             .with_interprocedural(&registry, None);
12398:         let warnings = find_taint_warnings_for_cu(&cu, &registry, None);
12399:         assert!(
12400:             warnings.iter().all(|w| w.code != DiagCode::T100),
12401:             "a tainted open access mode with a literal fileName must not raise T100, got {warnings:?}",
12402:         );
12403:     }
12404: 
12405:     /// TP: `apply $lambda ...` with a tainted lambda (arg 0) raises T100 — the
12406:     /// lambda body is executed verbatim, so tainted code in the `func` slot
12407:     /// is a genuine code-injection sink.
12408:     #[test]
12409:     fn t100_fires_for_apply_tainted_lambda() {
12410:         use crate::compilation_unit::CompilationUnit;
12411:         let registry = CommandRegistry::build_default();
12412:         let source = "set lambda [gets stdin]\napply $lambda 1 2\n";
12413:         let cu = CompilationUnit::build_for(source, &registry, false)
12414:             .with_interprocedural(&registry, None);
12415:         let warnings = find_taint_warnings_for_cu(&cu, &registry, None);
12416:         assert!(
12417:             warnings.iter().any(|w| w.code == DiagCode::T100),
12418:             "expected T100 for a tainted apply lambda (arg 0), got {warnings:?}",
12419:         );
12420:     }
12421: 
12422:     /// FP fix / TN: `apply {{x} {return $x}} $tainted` — a tainted value
12423:     /// passed as an ordinary lambda *argument* (bound to a formal parameter,
12424:     /// never re-evaluated as script) must not raise T100. `apply`'s
12425:     /// `taint_code_sink_args = Some(&[0])` gates the sink to the `func` slot.
12426:     #[test]
12427:     fn t100_silent_for_apply_tainted_argument() {
12428:         use crate::compilation_unit::CompilationUnit;
12429:         let registry = CommandRegistry::build_default();
12430:         let source = "set x [gets stdin]\napply {{a} {return $a}} $x\n";
12431:         let cu = CompilationUnit::build_for(source, &registry, false)
12432:             .with_interprocedural(&registry, None);
12433:         let warnings = find_taint_warnings_for_cu(&cu, &registry, None);
12434:         assert!(
12435:             warnings.iter().all(|w| w.code != DiagCode::T100),
12436:             "a tainted apply argument (not the lambda) must not raise T100, got {warnings:?}",
12437:         );
12438:     }
12439: 
12440:     /// FP fix / TN: `subst -nocommands $tainted` — the exact mitigation
12441:     /// `subst`'s own hover snippet recommends — must not raise T100, since
12442:     /// `-nocommands` disables the only hazard (command substitution) the
12443:     /// code names.
12444:     #[test]
12445:     fn t100_silent_for_subst_nocommands() {
12446:         use crate::compilation_unit::CompilationUnit;
12447:         let registry = CommandRegistry::build_default();
12448:         let source = "set x [gets stdin]\nsubst -nocommands $x\n";
12449:         let cu = CompilationUnit::build_for(source, &registry, false)
12450:             .with_interprocedural(&registry, None);
12451:         let warnings = find_taint_warnings_for_cu(&cu, &registry, None);
12452:         assert!(
12453:             warnings.iter().all(|w| w.code != DiagCode::T100),
12454:             "subst -nocommands must not raise T100, got {warnings:?}",
12455:         );
12456:     }
12457: 
12458:     /// TP regression: plain `subst $tainted` (no flags) keeps raising T100 —
12459:     /// the new sink gate must not suppress the common, genuinely dangerous
12460:     /// default-options call.
12461:     #[test]
12462:     fn t100_fires_for_subst_without_nocommands() {
12463:         use crate::compilation_unit::CompilationUnit;
12464:         let registry = CommandRegistry::build_default();
12465:         let source = "set x [gets stdin]\nsubst $x\n";
12466:         let cu = CompilationUnit::build_for(source, &registry, false)
12467:             .with_interprocedural(&registry, None);
12468:         let warnings = find_taint_warnings_for_cu(&cu, &registry, None);
12469:         assert!(
12470:             warnings.iter().any(|w| w.code == DiagCode::T100),
12471:             "expected T100 for bare `subst $x`, got {warnings:?}",
12472:         );
12473:     }
12474: 
12475:     /// TN: the Tcl 9.1 positive option form without `-commands` is equally
12476:     /// safe — `-variables` alone never runs command substitution.
12477:     #[test]
12478:     fn t100_silent_for_subst_positive_form_without_commands() {
12479:         use crate::compilation_unit::CompilationUnit;
12480:         let registry = CommandRegistry::build_default();
12481:         let source = "set x [gets stdin]\nsubst -variables $x\n";
12482:         let cu = CompilationUnit::build_for(source, &registry, false)
12483:             .with_interprocedural(&registry, None);
12484:         let warnings = find_taint_warnings_for_cu(&cu, &registry, None);
12485:         assert!(
12486:             warnings.iter().all(|w| w.code != DiagCode::T100),
12487:             "subst -variables (Tcl 9.1 positive form) must not raise T100, got {warnings:?}",
12488:         );
12489:     }
12490: 
12491:     /// TP: the Tcl 9.1 positive form *with* `-commands` present stays a sink.
12492:     #[test]
12493:     fn t100_fires_for_subst_positive_form_with_commands() {
12494:         use crate::compilation_unit::CompilationUnit;
12495:         let registry = CommandRegistry::build_default();
12496:         let source = "set x [gets stdin]\nsubst -variables -commands $x\n";
12497:         let cu = CompilationUnit::build_for(source, &registry, false)
12498:             .with_interprocedural(&registry, None);
12499:         let warnings = find_taint_warnings_for_cu(&cu, &registry, None);
12500:         assert!(
12501:             warnings.iter().any(|w| w.code == DiagCode::T100),
12502:             "expected T100 for `subst -variables -commands $x`, got {warnings:?}",
12503:         );
12504:     }
12505: 
12506:     /// FN fix — TP: a tainted variable used directly in an `if` branch
12507:     /// condition is evaluated exactly like any other braced `expr`, but
12508:     /// conditions live on `Terminator::Branch`, not in `ssa_block.statements`,
12509:     /// so the per-statement scan alone never reaches them —
12510:     /// `emit_branch_condition_warnings` is what covers them.
12511:     #[test]
12512:     fn t100_fires_for_tainted_if_condition() {
12513:         use crate::compilation_unit::CompilationUnit;
12514:         let registry = CommandRegistry::build_default();
12515:         let source =
12516:             "proc f {} {\n  set x [gets stdin]\n  if {$x + 1 > 5} {\n    puts big\n  }\n}\n";
12517:         let cu = CompilationUnit::build_for(source, &registry, false)
12518:             .with_interprocedural(&registry, None);
12519:         let warnings = find_taint_warnings_for_cu(&cu, &registry, None);
12520:         let hit = warnings
12521:             .iter()
12522:             .find(|w| w.code == DiagCode::T100)
12523:             .unwrap_or_else(|| panic!("expected T100 for tainted if-condition, got {warnings:?}"));
12524:         // Tight span: just the `{...}` condition text, not the whole
12525:         // `if {...} { puts big }` statement (which also spans the body).
12526:         let text = &source[hit.span.start() as usize..hit.span.end() as usize];
12527:         assert!(
12528:             text == "$x",
12529:             "expected the exact coercing variable reference, got {text:?}",
12530:         );
12531:     }
12532: 
12533:     /// TP: the same hazard through `while` and `for` conditions.
12534:     #[test]
12535:     fn t100_fires_for_tainted_while_and_for_conditions() {
12536:         use crate::compilation_unit::CompilationUnit;
12537:         let registry = CommandRegistry::build_default();
12538:         for source in [
12539:             "proc f {} {\n  set x [gets stdin]\n  while {$x < 10} {\n    incr x\n  }\n}\n",
12540:             "proc f {} {\n  set x [gets stdin]\n  for {set i 0} {$i < $x} {incr i} {\n    puts $i\n  }\n}\n",
12541:         ] {
12542:             let cu = CompilationUnit::build_for(source, &registry, false)
12543:                 .with_interprocedural(&registry, None);
12544:             let warnings = find_taint_warnings_for_cu(&cu, &registry, None);
12545:             assert!(
12546:                 warnings.iter().any(|w| w.code == DiagCode::T100),
12547:                 "expected T100 for tainted loop condition in {source:?}, got {warnings:?}",
12548:             );
12549:         }
12550:     }
12551: 
12552:     /// FP fix / TN: `if {$tainted eq "admin"}` raises nothing — `eq` is a
12553:     /// pure string comparison with no numeric coercion, so neither the
12554:     /// "numeric coercion" message nor any other T100 variant applies. This
12555:     /// also proves the branch-condition pass reuses the same
12556:     /// `collect_coercion_operands` operator-context filter as the
12557:     /// `AssignExpr`/`ExprEval` path, not a re-implementation that flags
12558:     /// every variable indiscriminately.
12559:     #[test]
12560:     fn t100_silent_for_string_only_if_condition() {
12561:         use crate::compilation_unit::CompilationUnit;
12562:         let registry = CommandRegistry::build_default();
12563:         let source =
12564:             "proc f {} {\n  set x [gets stdin]\n  if {$x eq \"admin\"} {\n    puts ok\n  }\n}\n";
12565:         let cu = CompilationUnit::build_for(source, &registry, false)
12566:             .with_interprocedural(&registry, None);
12567:         let warnings = find_taint_warnings_for_cu(&cu, &registry, None);
12568:         assert!(
12569:             warnings.iter().all(|w| w.code != DiagCode::T100),
12570:             "eq is a pure string compare, expected no T100, got {warnings:?}",
12571:         );
12572:     }
12573: 
12574:     /// FP fix / TN: a `switch` on a tainted value raises no T100 in any of
12575:     /// its matching modes.
12576:     ///
12577:     /// An exact `switch` is flattened into a chain of `StrEq` branch
12578:     /// terminators whose subject operand is an `ExprNode::Raw` holding the
12579:     /// normalised variable reference
12580:     /// (`cfg_builder::cfg_lower::switch_subject_operand`), so an arm's
12581:     /// coercion context is the one that `StrEq` gives its operands: none.
12582:     ///
12583:     /// Every string mode is covered because none of them is an exception:
12584:     /// `-exact`, `-glob` and `-regexp` all match text, so there is no arm
12585:     /// spelling the message would fit. Tcl 9.1's `-integer` is the one numeric
12586:     /// mode; see `t100_for_a_tainted_switch_integer_subject`.
12587:     ///
12588:     /// tclsh 8.6.18 and 9.0.4 both print `other` for `set c 0x10; switch -- $c
12589:     /// {16 {puts hex} default {puts other}}` — the subject is compared as the
12590:     /// string `0x10`, never coerced to 16.
12591:     #[test]
12592:     fn t100_silent_for_switch_arms_on_a_tainted_subject() {
12593:         use crate::compilation_unit::CompilationUnit;
12594:         let registry = CommandRegistry::build_default();
12595:         for mode in ["--", "-exact --", "-glob --", "-regexp --"] {
12596:             let source = format!(
12597:                 "proc f {{}} {{\n  set cmd [gets stdin]\n  switch {mode} $cmd {{\n    \
12598:                  status {{ puts ok }}\n    version {{ puts 1 }}\n    \
12599:                  default {{ puts none }}\n  }}\n}}\n"
12600:             );
12601:             let cu = CompilationUnit::build_for(&source, &registry, false)
12602:                 .with_interprocedural(&registry, None);
12603:             let warnings = find_taint_warnings_for_cu(&cu, &registry, None);
12604:             assert!(
12605:                 warnings.iter().all(|w| w.code != DiagCode::T100),
12606:                 "`switch {mode}` matches as a string, expected no T100, got {warnings:?}",
12607:             );
12608:         }
12609:     }
12610: 
12611:     fn switch_integer_t100s(release: &str, body: &str) -> Vec<TaintWarning> {
12612:         use crate::compilation_unit::CompilationUnit;
12613:         let registry = tcl_registry::model::ingress::static_context_for(release).commands();
12614:         let profile = tcl_dialect::DialectProfile::find(release).expect("catalogue profile");
12615:         let source = format!("proc f {{}} {{\n  set cmd [gets stdin]\n  set ok 5\n  {body}\n}}\n");
12616:         let cu = CompilationUnit::build_for_profile(&source, registry, false, profile)
12617:             .with_interprocedural(registry, Some(profile));
12618:         find_taint_warnings_for_cu(&cu, registry, Some(profile))
12619:             .into_iter()
12620:             .filter(|w| w.code == DiagCode::T100)
12621:             .collect()
12622:     }
12623: 
12624:     /// TP: Tcl 9.1's `switch -integer` (TIP 730) reads its subject with
12625:     /// `Tcl_GetWideIntFromObj`, so a tainted subject is the same coercion
12626:     /// hazard as a braced `expr` operand. tclsh 9.1.0 runs the `16` arm for
12627:     /// `switch -integer -- 0x10 {16 {puts hex} default {puts other}}` and
12628:     /// raises `expected integer but got "abc"` for a subject of `abc`.
12629:     #[test]
12630:     fn t100_for_a_tainted_switch_integer_subject() {
12631:         for call in [
12632:             "switch -integer -- $cmd {1 { puts one } default { puts none }}",
12633:             "switch -int $cmd {1 { puts one }}",
12634:             "switch -integer -- $cmd 1 { puts one } default { puts none }",
12635:             "if {$ok} { switch -integer -- $cmd {1 { puts one }} }",
12636:         ] {
12637:             let hits = switch_integer_t100s("tcl9.1", call);
12638:             assert_eq!(hits.len(), 1, "{call}: {hits:?}");
12639:             assert_eq!(hits[0].variable, "cmd", "{call}");
12640:             assert_eq!(hits[0].sink_command, "switch -integer operand", "{call}");
12641:             assert!(
12642:                 hits[0].message.contains("numeric coercion"),
12643:                 "{call}: {}",
12644:                 hits[0].message
12645:             );
12646:         }
12647:         // The squiggle is the coerced word, not the whole `switch`.
12648:         let call = "switch -integer -- $cmd {1 { puts one }}";
12649:         let hits = switch_integer_t100s("tcl9.1", call);
12650:         let source = format!("proc f {{}} {{\n  set cmd [gets stdin]\n  set ok 5\n  {call}\n}}\n");
12651:         let span = hits[0].span;
12652:         assert_eq!(&source[span.start() as usize..span.end() as usize], "$cmd");
12653:         // A tainted inline pattern is read as an integer too.
12654:         let hits = switch_integer_t100s("tcl9.1", "switch -integer -- $ok $cmd { puts one }");
12655:         assert_eq!(hits.len(), 1, "{hits:?}");
12656:         assert_eq!(hits[0].variable, "cmd");
12657:     }
12658: 
12659:     /// TN: no coercion reaches the tainted value — the option does not exist
12660:     /// before 9.1 (tclsh 9.0.4 rejects `-integer` as a bad option), the value
12661:     /// is brace-quoted text, a sanitiser hands over an integer it produced, the
12662:     /// subject is clean, the mode compares text (including when `-integer` is
12663:     /// only another option's value), or C rejects the option combination.
12664:     #[test]
12665:     fn t100_silent_for_switch_integer_without_a_coerced_tainted_word() {
12666:         for (release, call) in [
12667:             ("tcl9.0", "switch -integer -- $cmd {1 { puts one }}"),
12668:             ("tcl8.6", "switch -integer -- $cmd {1 { puts one }}"),
12669:             ("tcl9.1", "switch -integer -- {$cmd} {1 { puts one }}"),
12670:             (
12671:                 "tcl9.1",
12672:                 "switch -integer -- [string length $cmd] {1 { puts one }}",
12673:             ),
12674:             ("tcl9.1", "switch -integer -- $ok {1 { puts one }}"),
12675:             ("tcl9.1", "switch -glob -- $cmd {1* { puts one }}"),
12676:             // `-integer` is `-matchvar`'s value here: a regexp switch.
12677:             (
12678:                 "tcl9.1",
12679:                 "switch -matchvar -integer -regexp -- $cmd {1 { puts one }}",
12680:             ),
12681:             // C rejects the call before reading the subject.
12682:             ("tcl9.1", "switch -integer -nocase -- $cmd {1 { puts one }}"),
12683:             (
12684:                 "tcl9.1",
12685:                 "if {[scan $cmd %d n] == 1} { switch -integer -- $n {1 { puts one }} }",
12686:             ),
12687:         ] {
12688:             let hits = switch_integer_t100s(release, call);
12689:             assert_eq!(hits.len(), 0, "{release} `{call}`: {hits:?}");
12690:         }
12691:     }
12692: 
12693:     /// The same silence for an array element as a `switch` subject.
12694:     ///
12695:     /// `$a(k)` normalises to a `${a(k)}` subject, whose reconstruction has to
12696:     /// match the array name the expr scan reports plus the index it does not.
12697:     /// It is one reference to one element, so the arm's `StrEq` context is the
12698:     /// whole answer here too.
12699:     #[test]
12700:     fn t100_silent_for_a_switch_on_a_tainted_array_element() {
12701:         use crate::compilation_unit::CompilationUnit;
12702:         let registry = CommandRegistry::build_default();
12703:         let source = "proc f {} {\n  array set a [list k [gets stdin]]\n  \
12704:                       switch -- $a(k) {\n    status { puts ok }\n    \
12705:                       default { puts none }\n  }\n}\n";
12706:         let cu = CompilationUnit::build_for(source, &registry, false)
12707:             .with_interprocedural(&registry, None);
12708:         let warnings = find_taint_warnings_for_cu(&cu, &registry, None);
12709:         assert!(
12710:             warnings.iter().all(|w| w.code != DiagCode::T100),
12711:             "an array-element switch subject matches as a string too, got {warnings:?}",
12712:         );
12713:     }
12714: 
12715:     /// TP guard for the test above: the `Raw` arm's whole-variable narrowing
12716:     /// must not reach a `Raw` that really is unparsed expression source with a
12717:     /// coercing operator inside it.
12718:     #[test]
12719:     fn t100_still_fires_for_a_tainted_operand_in_an_unparsed_expr() {
12720:         use crate::compilation_unit::CompilationUnit;
12721:         let registry = CommandRegistry::build_default();
12722:         let source = "proc f {} {\n  set x [gets stdin]\n  expr {$x + 1}\n}\n";
12723:         let cu = CompilationUnit::build_for(source, &registry, false)
12724:             .with_interprocedural(&registry, None);
12725:         let warnings = find_taint_warnings_for_cu(&cu, &registry, None);
12726:         assert!(
12727:             warnings.iter().any(|w| w.code == DiagCode::T100),
12728:             "expected T100 for a numeric-coercing operand, got {warnings:?}",
12729:         );
12730:     }
12731: 
12732:     /// An *escaped* bracket writes a literal `[`, so the quoter never runs and
12733:     /// the raw value lands in the pattern.
12734:     ///
12735:     /// tclsh 8.6.18 and 9.0.4 both leave `"\[regex::quote $p]"` as the text
12736:     /// `[regex::quote <value of p>]` — the command is not invoked — so the
12737:     /// wrapper the mitigation would credit does not exist. Segmentation is the
12738:     /// lexer's for exactly this reason; a bracket count reads a call here.
12739:     #[test]
12740:     fn t103_not_cleared_by_an_escaped_bracket_that_never_calls_the_quoter() {
12741:         use crate::compilation_unit::CompilationUnit;
12742:         let registry = CommandRegistry::build_default();
12743:         let source = "proc f {} {\n  set p [gets stdin]\n  \
12744:                       regexp -- \"\\[regex::quote $p]\" $line\n}\n";
12745:         let cu = CompilationUnit::build_for(source, &registry, false)
12746:             .with_interprocedural(&registry, None);
12747:         let warnings = find_taint_warnings_for_cu(&cu, &registry, None);
12748:         assert!(
12749:             warnings.iter().any(|w| w.code == DiagCode::T103),
12750:             "an escaped bracket is not a call, so T103 must stand: {warnings:?}",
12751:         );
12752:     }
12753: 
12754:     /// T103's `[regex::quote …]` mitigation reads the same whether the quote
12755:     /// wraps the value in place or through a variable.
12756:     ///
12757:     /// The quoting is what makes the pattern trusted, and it happens either
12758:     /// way; only the spelling differs. Since wrapping in place is what T103's
12759:     /// quick fix writes, that spelling is the one an applied fix has to clear.
12760:     ///
12761:     /// The scope is the pattern argument alone: `$p` used as the *subject*
12762:     /// too is not in a pattern position, so it cannot withdraw the proof the
12763:     /// wrapped pattern carries.
12764:     #[test]
12765:     fn t103_cleared_by_an_inline_regex_quote_in_the_pattern_slot() {
12766:         use crate::compilation_unit::CompilationUnit;
12767:         let registry = CommandRegistry::build_default();
12768:         let cases: [(&str, bool); 5] = [
12769:             ("regexp -- $p $line", true),
12770:             ("set q [regex::quote $p]\n  regexp -- $q $line", false),
12771:             ("regexp -- [regex::quote $p] $line", false),
12772:             ("regexp -- [regex::quote $p] $p", false),
12773:             // `string range` carries no transform, so it proves nothing.
12774:             ("regexp -- [string range $p 0 5] $line", true),
12775:         ];
12776:         for (tail, expected) in cases {
12777:             let source = format!("proc f {{}} {{\n  set p [gets stdin]\n  {tail}\n}}\n");
12778:             let cu = CompilationUnit::build_for(&source, &registry, false)
12779:                 .with_interprocedural(&registry, None);
12780:             let warnings = find_taint_warnings_for_cu(&cu, &registry, None);
12781:             let got = warnings.iter().any(|w| w.code == DiagCode::T103);
12782:             assert_eq!(got, expected, "for {tail:?}, got {warnings:?}");
12783:         }
12784:     }
12785: 
12786:     /// The T101 mitigation chain end to end: the CR/LF-stripping `string map`
12787:     /// its KCS page prescribes — and its quick fix writes — clears the
12788:     /// diagnostic, in both the wrap-a-variable and wrap-in-place spellings,
12789:     /// and no other mapping does.
12790:     ///
12791:     /// tclsh 8.6.18 and 9.0.4 both give `string map {"\n" "" "\r" ""}
12792:     /// "a\nb\rc"` a length of 3 (`abc`), so the mapping really does delete
12793:     /// both characters — the element `"\n"` is list-parsed with its backslash
12794:     /// honoured, giving the newline itself as the key rather than a
12795:     /// two-character sequence. Dropping the `"\r"` pair leaves length 4 on
12796:     /// both, which is the half-pair case below.
12797:     #[test]
12798:     fn t101_cleared_only_by_a_mapping_that_deletes_crlf() {
12799:         use crate::compilation_unit::CompilationUnit;
12800:         let registry = CommandRegistry::build_default();
12801:         let crlf = r#"{"\n" "" "\r" ""}"#;
12802:         let cases: &[(&str, bool)] = &[
12803:             ("puts $x", true),
12804:             (&format!("puts [string map {crlf} $x]"), false),
12805:             (&format!("set s [string map {crlf} $x]\n  puts $s"), false),
12806:             ("puts [string map {a b} $x]", true),
12807:             // Only half the pair: an LF is deleted but a CR still survives.
12808:             (r#"puts [string map {"\n" ""} $x]"#, true),
12809:             // The mapping is dynamic and the *subject* is the braced word, so
12810:             // the rewriting is exactly what cannot be seen. tclsh 8.6.18 and
12811:             // 9.0.4: `set m [list X "a\nb"]; string map $m {"\n" "" "\r" ""
12812:             // X}` yields a string containing a newline.
12813:             (&format!("puts [string map $x {crlf}]"), true),
12814:             // A later `string map` puts a newline back, so the earlier proof
12815:             // no longer describes what reaches `puts` — in either spelling.
12816:             (
12817:                 &format!("set s [string map {crlf} $x]\n  puts [string map {{\"|\" \"\\n\"}} $s]"),
12818:                 true,
12819:             ),
12820:             (
12821:                 &format!(
12822:                     "set s [string map {crlf} $x]\n  \
12823:                      set t [string map {{\"|\" \"\\n\"}} $s]\n  puts $t"
12824:                 ),
12825:                 true,
12826:             ),
12827:         ];
12828:         for &(tail, expected) in cases {
12829:             let source = format!("proc f {{}} {{\n  set x [gets stdin]\n  {tail}\n}}\n");
12830:             let cu = CompilationUnit::build_for(&source, &registry, false)
12831:                 .with_interprocedural(&registry, None);
12832:             let warnings = find_taint_warnings_for_cu(&cu, &registry, None);
12833:             let got = warnings.iter().any(|w| w.code == DiagCode::T101);
12834:             assert_eq!(got, expected, "for {tail:?}, got {warnings:?}");
12835:         }
12836:     }
12837: 
12838:     /// FP fix — TN: a tainted variable that only appears inside a nested
12839:     /// `[cmd $x]` command substitution within a braced expr must not be
12840:     /// flagged as an "expr operand: numeric coercion" hit — it flows into
12841:     /// that nested call's own argument, a completely different risk
12842:     /// category (code execution, if `cmd` is itself dangerous) which that
12843:     /// call's own sink classification already covers independently.
12844:     #[test]
12845:     fn t100_expr_operand_message_not_raised_for_var_only_in_nested_command_sub() {
12846:         use crate::compilation_unit::CompilationUnit;
12847:         let registry = CommandRegistry::build_default();
12848:         // `string length` is a sanitiser (fixed numeric return) and not a
12849:         // sink, so the nested call itself raises nothing either — isolating
12850:         // the "expr operand" false positive this test targets.
12851:         let source = "proc f {} {\n  set x [gets stdin]\n  if {[string length $x] > 5} {\n    puts big\n  }\n}\n";
12852:         let cu = CompilationUnit::build_for(source, &registry, false)
12853:             .with_interprocedural(&registry, None);
12854:         let warnings = find_taint_warnings_for_cu(&cu, &registry, None);
12855:         assert!(
12856:             warnings.iter().all(|w| w.code != DiagCode::T100),
12857:             "$x only reaches a nested command-sub argument, not a direct \
12858:              expr operand; expected no T100, got {warnings:?}",
12859:         );
12860:     }
12861: 
12862:     /// TP: a tainted variable nested through a nested command sub still
12863:     /// raises T100 when that nested command is *itself* a sink.
12864:     #[test]
12865:     fn t100_fires_when_nested_command_sub_is_itself_a_sink() {
12866:         use crate::compilation_unit::CompilationUnit;
12867:         let registry = CommandRegistry::build_default();
12868:         let source = "proc f {} {\n  set x [gets stdin]\n  if {[exec $x] eq \"ok\"} {\n    puts ok\n  }\n}\n";
12869:         let cu = CompilationUnit::build_for(source, &registry, false)
12870:             .with_interprocedural(&registry, None);
12871:         let warnings = find_taint_warnings_for_cu(&cu, &registry, None);
12872:         assert!(
12873:             warnings.iter().any(|w| w.code == DiagCode::T100),
12874:             "expected T100 from the nested `exec $x`, got {warnings:?}",
12875:         );
12876:     }
12877: 
12878:     /// TP: `$tainted` inside a ternary branch still flags when the ternary
12879:     /// itself sits in a numeric-coercion position — the branch's value
12880:     /// stands in for the ternary as a whole in the parent operator.
12881:     #[test]
12882:     fn t100_fires_for_tainted_var_through_ternary_branch_in_coercing_context() {
12883:         use crate::compilation_unit::CompilationUnit;
12884:         let registry = CommandRegistry::build_default();
12885:         let source = "proc f {c} {\n  set x [gets stdin]\n  if {($c ? $x : 0) + 1 > 5} {\n    puts big\n  }\n}\n";
12886:         let cu = CompilationUnit::build_for(source, &registry, false)
12887:             .with_interprocedural(&registry, None);
12888:         let warnings = find_taint_warnings_for_cu(&cu, &registry, None);
12889:         assert!(
12890:             warnings.iter().any(|w| w.code == DiagCode::T100),
12891:             "expected T100 for $x flowing through a coerced ternary branch, got {warnings:?}",
12892:         );
12893:     }
12894: 
12895:     /// TP: the ternary *condition* is always boolean-coerced, regardless of
12896:     /// the ternary's own surrounding context.
12897:     #[test]
12898:     fn t100_fires_for_tainted_var_in_ternary_condition() {
12899:         use crate::compilation_unit::CompilationUnit;
12900:         let registry = CommandRegistry::build_default();
12901:         let source =
12902:             "proc f {} {\n  set x [gets stdin]\n  if {$x ? \"a\" : \"b\"} {\n    puts ok\n  }\n}\n";
12903:         let cu = CompilationUnit::build_for(source, &registry, false)
12904:             .with_interprocedural(&registry, None);
12905:         let warnings = find_taint_warnings_for_cu(&cu, &registry, None);
12906:         assert!(
12907:             warnings.iter().any(|w| w.code == DiagCode::T100),
12908:             "expected T100 for tainted ternary condition, got {warnings:?}",
12909:         );
12910:     }
12911: 
12912:     /// Precision: `eval "prefix" $x "suffix"` underlines only the `$x`
12913:     /// argument word (2 characters), not the whole `eval "prefix" $x
12914:     /// "suffix"` statement — `tight_arg_span` narrows the highlight to the
12915:     /// one argument word that actually carries the tainted value, using the
12916:     /// real per-word source spans a compiled `Statement::Call` carries.
12917:     #[test]
12918:     fn t100_span_is_the_tainted_argument_word_not_the_whole_statement() {
12919:         use crate::compilation_unit::CompilationUnit;
12920:         let registry = CommandRegistry::build_default();
12921:         let source = "proc f {} {\n  set x [gets stdin]\n  eval \"prefix\" $x \"suffix\"\n}\n";
12922:         let cu = CompilationUnit::build_for(source, &registry, false)
12923:             .with_interprocedural(&registry, None);
12924:         let warnings = find_taint_warnings_for_cu(&cu, &registry, None);
12925:         let hit = warnings
12926:             .iter()
12927:             .find(|w| w.code == DiagCode::T100)
12928:             .unwrap_or_else(|| panic!("expected T100, got {warnings:?}"));
12929:         let text = &source[hit.span.start() as usize..hit.span.end() as usize];
12930:         assert_eq!(
12931:             text, "$x",
12932:             "expected the tight `$x` argument span, got {text:?} from {hit:?}",
12933:         );
12934:     }
12935: 
12936:     #[test]
12937:     fn native_source_option_warnings_keep_original_schema_and_terminator() {
12938:         let context =
12939:             crate::environment_ingress::resolve_environment("tcl8.6").default_context_registry();
12940:         let registry = context.commands();
12941:         let profile = registry.profile().unwrap();
12942:         let config = tcl_lexer::LexerConfig::for_file_grammar(profile.grammar);
12943:         let input = crate::analyser::ResolvedAnalysisInput::new(
12944:             profile,
12945:             profile,
12946:             std::sync::Arc::clone(&context),
12947:             config,
12948:         );
12949:         for (command, expected) in [
12950:             ("exec $value", true),
12951:             ("exec -- $value", false),
12952:             ("exec {$value}", false),
12953:             ("exec {*}$value", false),
12954:         ] {
12955:             let source = format!("proc run {{value}} {{{command}}}");
12956:             let unit = crate::compilation_unit::CompilationUnit::build_with_analysis_input(
12957:                 &source,
12958:                 crate::compilation_unit::UnitBuildOptions {
12959:                     registry,
12960:                     defer_top_level: false,
12961:                     config,
12962:                     dialect: Some(profile),
12963:                     external_call_sites: None,
12964:                     declared_commands: None,
12965:                 },
12966:                 None,
12967:                 &input,
12968:             )
12969:             .with_interprocedural(registry, Some(profile));
12970:             assert!(unit.ir_module.source_entry.native_entry.is_none());
12971:             assert_eq!(
12972:                 unit.ir_module.original_native_declaration_body_units.len(),
12973:                 1
12974:             );
12975:             let warnings = find_taint_warnings_for_cu(&unit, registry, Some(profile));
12976:             assert_eq!(
12977:                 warnings.iter().any(|warning| warning.code == DiagCode::T102
12978:                     && warning.variable == "value"
12979:                     && warning.sink_command == "exec"),
12980:                 expected,
12981:                 "{command}: {warnings:?}"
12982:             );
12983:             if expected {
12984:                 let mut missing = unit.clone();
12985:                 missing.ir_module.retained_source_bindings = None;
12986:                 assert!(
12987:                     find_taint_warnings_for_cu(&missing, registry, Some(profile))
12988:                         .iter()
12989:                         .all(|warning| warning.code != DiagCode::T102)
12990:                 );
12991:                 let foreign = crate::environment_ingress::resolve_environment("tcl9.0")
12992:                     .default_context_registry();
12993:                 assert!(
12994:                     find_taint_warnings_for_cu(&unit, foreign.commands(), Some(profile))
12995:                         .iter()
12996:                         .all(|warning| warning.code != DiagCode::T102)
12997:                 );
12998:             }
12999:         }
13000:     }
13001: 
13002:     /// The `${…}` closer comes from the shared owner, so the name taint is
13003:     /// keyed on is the one the lexer spanned.
13004:     ///
13005:     /// Taint is name-keyed: a scan that recovers `a{b` where the document's
13006:     /// lexer spanned `a{b}c` looks up a cell nothing ever writes, so the
13007:     /// tainted value's colour is lost and the sink diagnostics that depend on
13008:     /// it (T1xx, W313) go quiet on a flow they should flag:
13009:     /// `set {a{b}c} 7; subst {${a{b}c}}` is `7` on tclsh 9.0.4 and
13010:     /// `can't read "a{b"` on 8.6.16.
13011:     #[test]
13012:     fn original_argument_candidates_use_full_source_config_and_nested_index_inventory() {
13013:         let context = tcl_registry::model::ingress::static_context_for("tcl9.1");
13014:         let registry = context.commands();
13015:         let unit = crate::compilation_unit::CompilationUnit::build_for(
13016:             "puts [list exec $arr($index) ${a{b}c} $tail $tail]",
13017:             registry,
13018:             false,
13019:         );
13020:         let tokens = unit.ir_module.top_level.statements[0].tokens().unwrap();
13021:         let source =
13022:             TaintSourceContext::for_module_function(registry, &unit.ir_module, &unit.top_level);
13023:         assert_eq!(source.config, unit.ir_module.lexer_config);
13024:         let names = arg_var_names_with_config(&tokens.argv_texts[1], source.config);
13025:         assert!(!names.has_unknown_residual());
13026:         assert_eq!(names.names(), ["arr", "index", "a{b}c", "tail", "tail"]);
13027:     }
13028: 
13029:     #[test]
13030:     fn standalone_list_wrapper_uses_original_grouped_head_values_and_exact_extent() {
13031:         let registry = CommandRegistry::build_default();
13032:         let config = tcl_lexer::LexerConfig::for_profile(registry.profile());
13033:         let dialect = registry
13034:             .profile()
13035:             .map(tcl_registry::InvocationDialect::of_profile);
13036:         for original in [
13037:             "[list puts $value]",
13038:             "[list {puts} $value]",
13039:             "[::list \"puts\" $value]",
13040:         ] {
13041:             assert_eq!(
13042:                 standalone_list_wrapper_head(original, &registry, config, dialect).as_deref(),
13043:                 Some("puts")
13044:             );
13045:         }
13046:         for original in [
13047:             "[list $command $value]",
13048:             "[list {$command} $value]",
13049:             "[list {} $value]",
13050:             "[list {*}{puts value}]",
13051:             "[list puts $value; list puts $value]",
13052:             "[list puts $value]suffix",
13053:             "[list puts $value]; missing",
13054:             "[list puts $value",
13055:             "[string cat puts $value]",
13056:         ] {
13057:             assert!(
13058:                 standalone_list_wrapper_head(original, &registry, config, dialect).is_none(),
13059:                 "{original}"
13060:             );
13061:         }
13062:         let args = vec!["[list {puts} $value]".to_owned()];
13063:         let call = SinkCall {
13064:             source: TaintSourceContext::standalone(&registry, registry.profile()),
13065:             command: "eval",
13066:             args: &args,
13067:             registry: &registry,
13068:             tokens: None,
13069:             effective: None,
13070:             source_read: None,
13071:             argument_offset: 0,
13072:         };
13073:         assert!(list_wrapped_arg_command_is_literal(&call, "value"));
13074:         let mut unavailable = call;
13075:         unavailable.source = TaintSourceContext::for_input(&registry, None, config);
13076:         assert!(!list_wrapped_arg_command_is_literal(&unavailable, "value"));
13077:     }
13078: 
13079:     #[test]
13080:     fn unavailable_argument_inventory_keeps_known_reads_and_refuses_mitigations() {
13081:         let context = tcl_registry::model::ingress::static_context_for("tcl8.6");
13082:         let registry = context.commands();
13083:         let unit = crate::compilation_unit::CompilationUnit::build_for(
13084:             "set value SAFE; puts {[missing $value}",
13085:             registry,
13086:             false,
13087:         );
13088:         let source =
13089:             TaintSourceContext::for_module_function(registry, &unit.ir_module, &unit.top_level);
13090:         let tokens = unit
13091:             .ir_module
13092:             .top_level
13093:             .statements
13094:             .last()
13095:             .unwrap()
13096:             .tokens()
13097:             .unwrap();
13098:         let args = tokens.argv_texts[1..].to_vec();
13099:         let call = SinkCall {
13100:             source,
13101:             command: "puts",
13102:             args: &args,
13103:             registry,
13104:             tokens: Some(tokens),
13105:             effective: None,
13106:             source_read: None,
13107:             argument_offset: 0,
13108:         };
13109:         assert!(arg_var_names_with_config(&args[0], source.config).has_unknown_residual());
13110:         assert!(
13111:             all_argument_candidates(&args[0], source.config, &unit.top_level.ssa)
13112:                 .iter()
13113:                 .any(|name| name == "value")
13114:         );
13115:         assert!(!var_consumed_by_sanitiser(&call, "value"));
13116:         assert!(!list_wrapped_arg_command_is_literal(&call, "value"));
13117:         assert!(!sink_var_position_safe(&call, DiagCode::T100, "value"));
13118:         assert!(var_wrapper_colours(registry, source, &args, "value", Some(tokens), 0).is_none());
13119:     }
13120: 
13121:     #[test]
13122:     fn arg_var_names_follows_the_release_close_rule() {
13123:         use tcl_dialect::BracedVarStyle::{FirstClose, Tcl9Nesting};
13124:         assert_eq!(
13125:             arg_var_names("/tmp/${a{b}c}", Tcl9Nesting),
13126:             HashSet::from(["a{b}c".to_owned()])
13127:         );
13128:         assert_eq!(
13129:             arg_var_names("/tmp/${a{b}c}", FirstClose),
13130:             HashSet::from(["a{b".to_owned()])
13131:         );
13132:         // The scan resumes past the reference under either rule, so a second
13133:         // ordinary reference in the same word is still collected.
13134:         assert_eq!(
13135:             arg_var_names("${a{b}c}/$tail", Tcl9Nesting),
13136:             HashSet::from(["a{b}c".to_owned(), "tail".to_owned()])
13137:         );
13138:     }
13139: 
13140:     /// Shared substitution inventories preserve name and lexical boundaries.
13141:     mod arg_var_names_vs_vars_in_word {
13142:         use super::*;
13143: 
13144:         /// TP: a bare `$name` reference — both scanners agree.
13145:         #[test]
13146:         fn agree_on_bare_var() {
13147:             let registry = CommandRegistry::build_default();
13148:             assert_eq!(
13149:                 arg_var_names("$p", tcl_dialect::BracedVarStyle::default()),
13150:                 HashSet::from(["p".to_owned()])
13151:             );
13152:             assert_eq!(
13153:                 crate::var_refs::vars_in_word("$p", &registry)
13154:                     .into_iter()
13155:                     .collect::<HashSet<_>>(),
13156:                 HashSet::from(["p".to_owned()])
13157:             );
13158:         }
13159: 
13160:         /// TP: `${braced}` next to a bare `$var` in the same word — both
13161:         /// scanners agree, including across a non-variable separator (`/`).
13162:         #[test]
13163:         fn agree_on_braced_and_bare_in_one_word() {
13164:             let registry = CommandRegistry::build_default();
13165:             let want = HashSet::from(["dir".to_owned(), "file".to_owned()]);
13166:             assert_eq!(
13167:                 arg_var_names("${dir}/$file", tcl_dialect::BracedVarStyle::default()),
13168:                 want
13169:             );
13170:             assert_eq!(
13171:                 crate::var_refs::vars_in_word("${dir}/$file", &registry)
13172:                     .into_iter()
13173:                     .collect::<HashSet<_>>(),
13174:                 want
13175:             );
13176:         }
13177: 
13178:         /// TP (command substitution): a `$var` nested inside `[cmd …]` —
13179:         /// both scanners recurse into the substitution and agree.
13180:         #[test]
13181:         fn agree_on_var_inside_command_substitution() {
13182:             let registry = CommandRegistry::build_default();
13183:             assert_eq!(
13184:                 arg_var_names("[foo $x]", tcl_dialect::BracedVarStyle::default()),
13185:                 HashSet::from(["x".to_owned()])
13186:             );
13187:             assert_eq!(
13188:                 crate::var_refs::vars_in_word("[foo $x]", &registry)
13189:                     .into_iter()
13190:                     .collect::<HashSet<_>>(),
13191:                 HashSet::from(["x".to_owned()])
13192:             );
13193:         }
13194: 
13195:         /// The array root and its substituted index are separate dependencies.
13196:         #[test]
13197:         fn agree_on_var_nested_in_array_index() {
13198:             let registry = CommandRegistry::build_default();
13199:             assert_eq!(
13200:                 arg_var_names("$arr($cmd)", tcl_dialect::BracedVarStyle::default()),
13201:                 HashSet::from(["arr".to_owned(), "cmd".to_owned()]),
13202:                 "arg_var_names must keep catching the nested index variable"
13203:             );
13204:             assert_eq!(
13205:                 crate::var_refs::vars_in_word("$arr($cmd)", &registry)
13206:                     .into_iter()
13207:                     .collect::<HashSet<_>>(),
13208:                 HashSet::from(["arr".to_owned(), "cmd".to_owned()]),
13209:                 "the shared inventory includes the substituted index dependency"
13210:             );
13211:         }
13212: 
13213:         /// FP guard: a backslash-escaped `\$name` is literal text (Tcl
13214:         /// backslash substitution turns `\$` into a literal `$`, so no
13215:         /// variable is referenced). A byte-scan that does not know about
13216:         /// backslash escaping reads it as a reference to `notavar`;
13217:         /// `arg_var_names` must agree with `vars_in_word`, which goes through
13218:         /// the real lexer.
13219:         #[test]
13220:         fn escaped_dollar_is_not_a_reference() {
13221:             let registry = CommandRegistry::build_default();
13222:             assert_eq!(
13223:                 arg_var_names("\\$notavar", tcl_dialect::BracedVarStyle::default()).len(),
13224:                 0,
13225:                 "an escaped \\$ must not be read as a variable reference"
13226:             );
13227:             assert_eq!(
13228:                 crate::var_refs::vars_in_word("\\$notavar", &registry).len(),
13229:                 0
13230:             );
13231:         }
13232: 
13233:         /// FP fixed, doubled escape: `\\$foo` is an escaped backslash
13234:         /// (literal `\`) followed by a live, unescaped `$foo` — the
13235:         /// variable reference still must be found.
13236:         #[test]
13237:         fn double_backslash_then_live_var_is_still_found() {
13238:             assert_eq!(
13239:                 arg_var_names("\\\\$foo", tcl_dialect::BracedVarStyle::default()),
13240:                 HashSet::from(["foo".to_owned()])
13241:             );
13242:         }
13243: 
13244:         /// TN: plain literal text with no `$` sigil at all.
13245:         #[test]
13246:         fn no_dollar_sigil_is_empty() {
13247:             assert_eq!(
13248:                 arg_var_names("hello world", tcl_dialect::BracedVarStyle::default()).len(),
13249:                 0
13250:             );
13251:         }
13252:     }
13253: 
13254:     /// `interp alias` / `rename` command-name resolution feeding sink
13255:     /// classification. Sink checks key off
13256:     /// `Statement::canonical_command_or_source()`, so a call through a
13257:     /// renamed or aliased name resolves to whatever it now denotes.
13258:     mod rename_and_alias_taint {
13259:         use super::*;
13260:         use crate::compilation_unit::CompilationUnit;
13261: 
13262:         fn taint_warnings_for(source: &str) -> Vec<TaintWarning> {
13263:             let registry = CommandRegistry::build_default();
13264:             let cu = CompilationUnit::build_for(source, &registry, false)
13265:                 .with_interprocedural(&registry, None);
13266:             find_taint_warnings_for_cu(&cu, &registry, None)
13267:         }
13268: 
13269:         /// TP (regression guard): tainted data reaching the real `puts` sink
13270:         /// through an `interp alias` name. This was silently missed before
13271:         /// sink classification started reading `canonical_command` — the
13272:         /// alias table was populated but never consulted here.
13273:         #[test]
13274:         fn tainted_data_through_interp_alias_is_flagged() {
13275:             let w =
13276:                 taint_warnings_for("set u [gets stdin]\ninterp alias {} myputs {} puts\nmyputs $u");
13277:             assert!(
13278:                 w.iter().any(|d| d.code == DiagCode::T101),
13279:                 "expected T101 through the `myputs` alias, got {w:?}"
13280:             );
13281:         }
13282: 
13283:         /// TP: tainted data reaching the real `puts` sink through a renamed
13284:         /// command name (`rename puts myputs`) — the scenario this
13285:         /// investigation was specifically scoped to cover.
13286:         #[test]
13287:         fn tainted_data_through_renamed_sink_is_flagged() {
13288:             let w = taint_warnings_for("set u [gets stdin]\nrename puts myputs\nmyputs $u");
13289:             assert!(
13290:                 w.iter().any(|d| d.code == DiagCode::T101),
13291:                 "expected T101 through the renamed `myputs`, got {w:?}"
13292:             );
13293:         }
13294: 
13295:         /// TN: `rename someSafeProc puts` shadows the builtin — the bare
13296:         /// name `puts` now denotes the user's own proc, not the real
13297:         /// output sink, so a subsequent `puts $tainted` must NOT be flagged.
13298:         /// Guards the false-positive direction of the same fix (a renamed
13299:         /// binding can point *away* from a builtin just as easily as onto
13300:         /// one).
13301:         #[test]
13302:         fn rename_shadowing_a_builtin_suppresses_the_sink() {
13303:             let w = taint_warnings_for(
13304:                 "proc mysafeputs {x} { return }\n\
13305:                  set u [gets stdin]\n\
13306:                  rename mysafeputs puts\n\
13307:                  puts $u",
13308:             );
13309:             assert!(
13310:                 w.iter().all(|d| d.code != DiagCode::T101),
13311:                 "puts is shadowed by a user proc after the rename, got {w:?}"
13312:             );
13313:         }
13314: 
13315:         /// A substituted word whose value is known names the missing command;
13316:         /// its failed rename stops this script before the later sink.
13317:         #[test]
13318:         fn known_missing_rename_stops_before_the_builtin_sink() {
13319:             let w = taint_warnings_for(
13320:                 "set old somecmd\nset u [gets stdin]\nrename $old puts\nputs $u",
13321:             );
13322:             assert!(
13323:                 w.iter().all(|d| d.code != DiagCode::T101),
13324:                 "a failed rename must not invent a reached puts sink, got {w:?}"
13325:             );
13326:         }
13327: 
13328:         /// TN control: an *unrelated* rename must not disturb ordinary
13329:         /// `puts` sink detection.
13330:         #[test]
13331:         fn unrelated_rename_does_not_affect_puts_sink() {
13332:             let w = taint_warnings_for("rename string mystr\nset u [gets stdin]\nputs $u");
13333:             assert!(
13334:                 w.iter().any(|d| d.code == DiagCode::T101),
13335:                 "expected T101 for a plain puts call, got {w:?}"
13336:             );
13337:         }
13338: 
13339:         /// TN: the deletion form `rename puts {}` creates no new binding —
13340:         /// nothing to alias — so it must not be mistaken for a rename that
13341:         /// resolves some other name to `puts`.
13342:         #[test]
13343:         fn rename_deletion_form_creates_no_alias() {
13344:             let w = taint_warnings_for("set u [gets stdin]\nrename puts {}\nputs $u");
13345:             assert!(
13346:                 w.iter().all(|d| d.code != DiagCode::T101),
13347:                 "a deleted command cannot regain stock puts metadata: {w:?}"
13348:             );
13349:         }
13350:     }
13351: 
13352:     /// Unit tests for the pure [`shadowed_builtin_names`] helper, isolated
13353:     /// from the end-to-end taint-warning plumbing tested by
13354:     /// `namespace_shadowed_builtin_taint` below.
13355:     mod shadowed_builtin_names_tests {
13356:         use super::*;
13357: 
13358:         #[test]
13359:         fn retained_body_scope_ignores_display_and_refuses_detached_units() {
13360:             // naming.compiler.original-analysis-metadata-context
13361:             // docs/design/analysis/name-resolution-proofs/original-analysis-metadata-context.md
13362:             let profile = tcl_dialect::DialectProfile::find("tcl8.6").unwrap();
13363:             let registry = CommandRegistry::build_default().project_for_profile(profile);
13364:             let mut unit = crate::compilation_unit::CompilationUnit::build_for_profile(
13365:                 "namespace eval ns {proc puts {args} {}; proc run {value} {puts $value}}",
13366:                 &registry,
13367:                 false,
13368:                 profile,
13369:             );
13370:             let id = crate::interprocedural::test_body_identity::fixture_id(
13371:                 &unit.procedures,
13372:                 "::ns::run",
13373:             );
13374:             let function = unit.procedures.get_mut(&id).unwrap();
13375:             function.name = "::counterfactual::run".to_owned();
13376:             assert_eq!(
13377:                 shadowed_builtin_names_for_module_function(
13378:                     unit.procedures.get(&id).unwrap(),
13379:                     &unit,
13380:                     &registry
13381:                 ),
13382:                 Some(HashSet::from(["puts".to_owned()]))
13383:             );
13384:             let detached_top = unit.top_level.clone();
13385:             assert!(
13386:                 shadowed_builtin_names_for_module_function(&detached_top, &unit, &registry)
13387:                     .is_none()
13388:             );
13389:             let detached_body = unit.procedures.get(&id).unwrap().clone();
13390:             assert!(
13391:                 shadowed_builtin_names_for_module_function(&detached_body, &unit, &registry)
13392:                     .is_none()
13393:             );
13394:             let foreign_unit = crate::compilation_unit::CompilationUnit::build_for_profile(
13395:                 "proc foreign {} {}",
13396:                 &registry,
13397:                 false,
13398:                 profile,
13399:             );
13400:             let foreign = crate::interprocedural::test_body_identity::fixture_id(
13401:                 &foreign_unit.procedures,
13402:                 "::foreign",
13403:             );
13404:             unit.procedures.get_mut(&id).unwrap().body_id = Some(foreign);
13405:             assert!(
13406:                 shadowed_builtin_names_for_module_function(
13407:                     unit.procedures.get(&id).unwrap(),
13408:                     &unit,
13409:                     &registry
13410:                 )
13411:                 .is_none()
13412:             );
13413:         }
13414: 
13415:         #[test]
13416:         fn namespace_scoped_proc_shadows_only_its_own_namespace() {
13417:             let registry = CommandRegistry::build_default();
13418:             let procs = ["::myns::puts", "::myns::helper"];
13419:             let shadowed = shadowed_builtin_names("::myns", procs.iter().copied(), &registry);
13420:             assert_eq!(shadowed, HashSet::from(["puts".to_owned()]));
13421:             // A different namespace sees no shadow at all.
13422:             assert_eq!(
13423:                 shadowed_builtin_names("::other", procs.iter().copied(), &registry).len(),
13424:                 0
13425:             );
13426:         }
13427: 
13428:         #[test]
13429:         fn global_proc_shadows_every_namespace() {
13430:             let registry = CommandRegistry::build_default();
13431:             let procs = ["::puts"];
13432:             for ns in ["::", "::myns", "::a::b"] {
13433:                 assert_eq!(
13434:                     shadowed_builtin_names(ns, procs.iter().copied(), &registry),
13435:                     HashSet::from(["puts".to_owned()]),
13436:                     "namespace {ns} must see the global shadow"
13437:                 );
13438:             }
13439:         }
13440: 
13441:         #[test]
13442:         fn nested_child_proc_does_not_shadow_its_parent() {
13443:             let registry = CommandRegistry::build_default();
13444:             let procs = ["::a::b::puts"];
13445:             assert_eq!(
13446:                 shadowed_builtin_names("::a", procs.iter().copied(), &registry).len(),
13447:                 0
13448:             );
13449:         }
13450: 
13451:         #[test]
13452:         fn non_registry_proc_name_is_not_shadowing() {
13453:             // A proc named after something the registry doesn't know is not a
13454:             // "shadow" in this sense — there's no builtin sink to suppress.
13455:             let registry = CommandRegistry::build_default();
13456:             let procs = ["::myns::totallyMadeUpName"];
13457:             assert_eq!(
13458:                 shadowed_builtin_names("::myns", procs.iter().copied(), &registry).len(),
13459:                 0
13460:             );
13461:         }
13462:     }
13463: 
13464:     /// A user proc shadowing a builtin's bare name: `proc ::myns::puts {args}
13465:     /// {…}` (or a plain top-level `proc puts {…}`) makes a bare `puts` call
13466:     /// from the shadowing scope dispatch to the user's own proc, not the
13467:     /// output-sink builtin.
13468:     mod namespace_shadowed_builtin_taint {
13469:         use super::*;
13470:         use crate::compilation_unit::CompilationUnit;
13471: 
13472:         fn taint_warnings_for(source: &str) -> Vec<TaintWarning> {
13473:             let context = tcl_registry::model::ingress::resolve_environment("tcl8.6")
13474:                 .default_context_registry();
13475:             let profile = tcl_dialect::DialectProfile::plain_tcl();
13476:             let config = tcl_lexer::LexerConfig::for_file_grammar(profile.grammar);
13477:             let input = crate::analyser::ResolvedAnalysisInput::new(
13478:                 profile,
13479:                 profile,
13480:                 std::sync::Arc::clone(&context),
13481:                 config,
13482:             );
13483:             let registry = context.commands();
13484:             let cu = CompilationUnit::build_with_analysis_input(
13485:                 source,
13486:                 crate::compilation_unit::UnitBuildOptions {
13487:                     registry,
13488:                     defer_top_level: false,
13489:                     config,
13490:                     dialect: Some(profile),
13491:                     external_call_sites: None,
13492:                     declared_commands: None,
13493:                 },
13494:                 None,
13495:                 &input,
13496:             )
13497:             .with_interprocedural(registry, Some(profile));
13498:             find_taint_warnings_for_cu(&cu, registry, Some(profile))
13499:         }
13500: 
13501:         /// FP fixed: a namespace-scoped proc of the same name as a builtin
13502:         /// must suppress the builtin sink classification for bare calls made
13503:         /// from that namespace — this was the false positive the
13504:         /// investigation's example (`proc ::myns::puts`) called out.
13505:         #[test]
13506:         fn namespace_scoped_proc_shadowing_builtin_suppresses_sink() {
13507:             let w = taint_warnings_for(
13508:                 "namespace eval ::myns {\n\
13509:                  \x20 proc puts {x} { return }\n\
13510:                  \x20 proc run {} {\n\
13511:                  \x20   set u [gets stdin]\n\
13512:                  \x20   puts $u\n\
13513:                  \x20 }\n\
13514:                  }",
13515:             );
13516:             assert!(
13517:                 w.iter().all(|d| d.code != DiagCode::T101),
13518:                 "puts is shadowed by ::myns::puts, must not be a sink, got {w:?}"
13519:             );
13520:         }
13521: 
13522:         /// FP fixed: the same shadowing effect for a plain top-level proc
13523:         /// redefinition (no namespace involved at all).
13524:         #[test]
13525:         fn top_level_proc_shadowing_builtin_suppresses_sink() {
13526:             let w = taint_warnings_for("proc puts {x} { return }\nset u [gets stdin]\nputs $u");
13527:             assert!(
13528:                 w.iter().all(|d| d.code != DiagCode::T101),
13529:                 "puts is shadowed by a top-level proc, got {w:?}"
13530:             );
13531:         }
13532: 
13533:         /// FP fixed: a *global*-level shadowing proc suppresses the sink for
13534:         /// bare calls made from *any* namespace, not just the global one —
13535:         /// Tcl's unqualified-name lookup always falls back to global.
13536:         #[test]
13537:         fn global_proc_shadows_calls_from_other_namespaces_too() {
13538:             let w = taint_warnings_for(
13539:                 "proc puts {x} { return }\n\
13540:                  namespace eval ::myns {\n\
13541:                  \x20 proc run {} {\n\
13542:                  \x20   set u [gets stdin]\n\
13543:                  \x20   puts $u\n\
13544:                  \x20 }\n\
13545:                  }",
13546:             );
13547:             assert!(
13548:                 w.iter().all(|d| d.code != DiagCode::T101),
13549:                 "the global puts proc must shadow calls from ::myns too, got {w:?}"
13550:             );
13551:         }
13552: 
13553:         /// TN control: an unshadowed bare `puts` inside a namespace is still
13554:         /// the real builtin sink.
13555:         #[test]
13556:         fn unshadowed_namespace_call_is_still_a_sink() {
13557:             let w = taint_warnings_for(
13558:                 "namespace eval ::myns {\n\
13559:                  \x20 proc run {} {\n\
13560:                  \x20   set u [gets stdin]\n\
13561:                  \x20   puts $u\n\
13562:                  \x20 }\n\
13563:                  }",
13564:             );
13565:             assert!(
13566:                 w.iter().any(|d| d.code == DiagCode::T101),
13567:                 "expected T101 for an unshadowed puts call, got {w:?}"
13568:             );
13569:         }
13570: 
13571:         /// TN control: a shadowing proc in an unrelated namespace must not
13572:         /// suppress a sink in a *different* namespace.
13573:         #[test]
13574:         fn shadow_in_unrelated_namespace_does_not_suppress_sink() {
13575:             let w = taint_warnings_for(
13576:                 "namespace eval ::other {\n\
13577:                  \x20 proc puts {x} { return }\n\
13578:                  }\n\
13579:                  namespace eval ::myns {\n\
13580:                  \x20 proc run {} {\n\
13581:                  \x20   set u [gets stdin]\n\
13582:                  \x20   puts $u\n\
13583:                  \x20 }\n\
13584:                  }",
13585:             );
13586:             assert!(
13587:                 w.iter().any(|d| d.code == DiagCode::T101),
13588:                 "::other's shadow must not affect ::myns, got {w:?}"
13589:             );
13590:         }
13591: 
13592:         /// TN control: an explicit fully-qualified `::puts` call bypasses
13593:         /// namespace resolution entirely, so it must still be flagged even
13594:         /// when the bare name is locally shadowed.
13595:         #[test]
13596:         fn fully_qualified_call_bypasses_the_shadow() {
13597:             let w = taint_warnings_for(
13598:                 "namespace eval ::myns {\n\
13599:                  \x20 proc puts {x} { return }\n\
13600:                  \x20 proc run {} {\n\
13601:                  \x20   set u [gets stdin]\n\
13602:                  \x20   ::puts $u\n\
13603:                  \x20 }\n\
13604:                  }",
13605:             );
13606:             assert!(
13607:                 w.iter()
13608:                     .any(|d| matches!(d.code, DiagCode::T100 | DiagCode::T101)),
13609:                 "an explicit ::puts must still be classified as a sink, got {w:?}"
13610:             );
13611:         }
13612:     }
13613: 
13614:     /// `trace add variable` / `trace variable` conservatively forcing a
13615:     /// traced name to fully tainted (`apply_module_variable_traces`).
13616:     mod variable_trace_taint {
13617:         use super::*;
13618:         use crate::compilation_unit::CompilationUnit;
13619: 
13620:         fn taint_warnings_for(source: &str) -> Vec<TaintWarning> {
13621:             let registry = CommandRegistry::build_default();
13622:             let cu = CompilationUnit::build_for(source, &registry, false)
13623:                 .with_interprocedural(&registry, None);
13624:             find_taint_warnings_for_cu(&cu, &registry, None)
13625:         }
13626: 
13627:         /// FN guard: installing a `write` trace on an already-tainted
13628:         /// variable must not clear its taint. The trace-add call's own
13629:         /// literal argument words — `add`, `variable`, `x`, `write`,
13630:         /// `{handler}` — are all clean, so a generic "propagate from
13631:         /// arguments" fallback would treat the trace-add's synthetic write to
13632:         /// `x` as deriving from them.
13633:         #[test]
13634:         fn write_trace_does_not_clear_prior_taint() {
13635:             let w = taint_warnings_for(
13636:                 "set x [gets stdin]\ntrace add variable x write {sanitize}\nputs $x",
13637:             );
13638:             assert!(
13639:                 w.iter().any(|d| d.code == DiagCode::T101),
13640:                 "trace installation must not launder x's existing taint, got {w:?}"
13641:             );
13642:         }
13643: 
13644:         /// FN direction: a variable set to a literal (clean) value is
13645:         /// conservatively treated as tainted once *any* trace (even a
13646:         /// `read` trace) is attached — the handler could inject
13647:         /// attacker-controlled content on every future access.
13648:         #[test]
13649:         fn traced_literal_value_is_conservatively_tainted() {
13650:             let w = taint_warnings_for(
13651:                 "set x \"safe-literal\"\ntrace add variable x read {inject}\nputs $x",
13652:             );
13653:             assert!(
13654:                 w.iter().any(|d| d.code == DiagCode::T101),
13655:                 "a traced variable must be treated as tainted even from a literal set, got {w:?}"
13656:             );
13657:         }
13658: 
13659:         /// Cross-proc: a trace installed by one proc still taints a read of
13660:         /// the same global variable in a different function (the module-wide
13661:         /// `Module::traced_variables` over-approximation, not a per-function
13662:         /// one).
13663:         #[test]
13664:         fn trace_installed_in_another_proc_still_taints_this_read() {
13665:             let w = taint_warnings_for(
13666:                 "proc install_trace {} { trace add variable ::x write {cb} }\n\
13667:                  set x [gets stdin]\n\
13668:                  install_trace\n\
13669:                  puts $x",
13670:             );
13671:             assert!(
13672:                 w.iter().any(|d| d.code == DiagCode::T101),
13673:                 "expected T101 despite the trace living in a different proc, got {w:?}"
13674:             );
13675:         }
13676: 
13677:         /// A dynamic trace target (`trace add variable $name …`) can't be
13678:         /// resolved to a literal name, so — mirroring
13679:         /// `Module::has_dynamic_variable_trace` — every name in the module is
13680:         /// conservatively treated as traced (tainted).
13681:         #[test]
13682:         fn dynamic_trace_target_taints_every_name() {
13683:             let w = taint_warnings_for(
13684:                 "set x \"safe-literal\"\ntrace add variable $somevar write {cb}\nputs $x",
13685:             );
13686:             assert!(
13687:                 w.iter().any(|d| d.code == DiagCode::T101),
13688:                 "a dynamic trace target must conservatively taint every name, got {w:?}"
13689:             );
13690:         }
13691: 
13692:         /// TN control: an untraced variable behaves exactly as before — a
13693:         /// clean literal stays clean.
13694:         #[test]
13695:         fn untraced_literal_value_stays_clean() {
13696:             let w = taint_warnings_for("set x hello\nputs $x");
13697:             assert_eq!(w.len(), 0, "no trace in scope, expected no warnings: {w:?}");
13698:         }
13699: 
13700:         /// TN control: an untraced tainted variable is unaffected by this
13701:         /// fix — still flagged exactly as the pre-existing behaviour.
13702:         #[test]
13703:         fn untraced_tainted_value_still_flagged() {
13704:             let w = taint_warnings_for("set x [gets stdin]\nputs $x");
13705:             assert!(
13706:                 w.iter().any(|d| d.code == DiagCode::T101),
13707:                 "expected T101 for a plain untraced tainted puts call, got {w:?}"
13708:             );
13709:         }
13710:     }
13711: 
13712:     /// Unit tests for the pure [`apply_module_variable_traces`] helper,
13713:     /// isolated from the end-to-end plumbing tested by
13714:     /// `variable_trace_taint` above.
13715:     mod apply_module_variable_traces_tests {
13716:         use super::*;
13717:         use crate::compilation_unit::ModuleTraceFacts;
13718: 
13719:         #[test]
13720:         fn forces_existing_entries_for_a_traced_name() {
13721:             let cu = crate::compilation_unit::CompilationUnit::build_for(
13722:                 "proc p {} { trace add variable t write cb\nset t 1\nputs $t }",
13723:                 &CommandRegistry::build_default(),
13724:                 false,
13725:             );
13726:             assert!(cu.ir_module.traced_variables.contains("t"));
13727:             let traces = ModuleTraceFacts {
13728:                 traced_variables: &cu.ir_module.traced_variables,
13729:                 has_dynamic_variable_trace: cu.ir_module.has_dynamic_variable_trace,
13730:                 deferred_writes: &cu.ir_module.deferred_writes,
13731:             };
13732: 
13733:             let fu = cu.function("::p").unwrap();
13734:             let patched = apply_module_variable_traces((*fu.taints).clone(), &fu.ssa, traces);
13735:             let first_definitions: Vec<_> = patched
13736:                 .iter()
13737:                 .filter(|((symbol, version), _)| *version == 1 && fu.ssa.var_name(*symbol) == "t")
13738:                 .collect();
13739:             assert!(
13740:                 !first_definitions.is_empty(),
13741:                 "the traced variable must have a represented first definition: {patched:?}"
13742:             );
13743:             assert!(
13744:                 first_definitions
13745:                     .iter()
13746:                     .all(|(_, taint)| taint.is_tainted()),
13747:                 "every canonical t#1 definition must be forced tainted: {patched:?}"
13748:             );
13749:         }
13750: 
13751:         #[test]
13752:         fn leaves_untraced_names_unchanged() {
13753:             let registry = CommandRegistry::build_default();
13754:             let cu = crate::compilation_unit::CompilationUnit::build_for(
13755:                 "proc p {} { set t 1\nputs $t }",
13756:                 &registry,
13757:                 false,
13758:             );
13759:             assert!(!cu.ir_module.traced_variables.contains("t"));
13760:             assert!(!cu.ir_module.has_dynamic_variable_trace);
13761:             let traces = ModuleTraceFacts {
13762:                 traced_variables: &cu.ir_module.traced_variables,
13763:                 has_dynamic_variable_trace: cu.ir_module.has_dynamic_variable_trace,
13764:                 deferred_writes: &cu.ir_module.deferred_writes,
13765:             };
13766:             let fu = cu.function("::p").unwrap();
13767:             let patched = apply_module_variable_traces((*fu.taints).clone(), &fu.ssa, traces);
13768:             assert_eq!(
13769:                 patched, *fu.taints,
13770:                 "no trace in scope — map must be unchanged"
13771:             );
13772:         }
13773:     }
13774:     #[test]
13775:     fn hosted_taint_diagnostics_use_current_source_metadata_without_native_handler_claims() {
13776:         // Implementation contract: naming.consumer.hosted-source-taint-descriptor
13777:         // docs/design/analysis/name-resolution-proofs/hosted-source-taint-descriptor.md
13778:         let context = tcl_registry::model::ingress::resolve_environment("f5-irules")
13779:             .default_context_registry();
13780:         let registry = context.commands();
13781:         let config = tcl_lexer::LexerConfig::for_profile(registry.profile());
13782:         let source = "when HTTP_REQUEST {set x [HTTP::query]; HTTP::respond 200 content $x}";
13783:         let options = crate::compilation_unit::UnitBuildOptions {
13784:             registry,
13785:             defer_top_level: false,
13786:             config,
13787:             dialect: Some(tcl_dialect::DialectProfile::irules()),
13788:             external_call_sites: None,
13789:             declared_commands: None,
13790:         };
13791:         let cu = crate::compilation_unit::CompilationUnit::build_with_context_registry(
13792:             source,
13793:             options,
13794:             None,
13795:             std::sync::Arc::clone(&context),
13796:         )
13797:         .with_interprocedural(registry, Some(tcl_dialect::DialectProfile::irules()));
13798:         let diagnostics = crate::compiler_checks::run_all_checks(
13799:             &cu,
13800:             registry,
13801:             Some(tcl_dialect::DialectProfile::irules()),
13802:         );
13803:         let diagnostic = diagnostics
13804:             .iter()
13805:             .find(|diagnostic| diagnostic.code == DiagCode::Irule3001)
13806:             .expect("genuine conditional hosted sink");
13807:         assert_eq!(
13808:             diagnostic.taint_subject.as_ref().unwrap().sink_command(),
13809:             "HTTP::respond"
13810:         );
13811:         assert_eq!(
13812:             diagnostic.source_context.as_ref().unwrap().image().bytes(),
13813:             source.as_bytes()
13814:         );
13815:         for negative in [
13816:             "when HTTP_REQUEST {HTTP::respond 200 content literal}",
13817:             "when HTTP_REQUEST {HTTP::respond 200 content {$x}}",
13818:             "when HTTP_REQUEST {HTTP::respond 200 content \"$x$tail\"}",
13819:             "proc HTTP::respond {args} {}; when HTTP_REQUEST {HTTP::respond 200 content $x}",
13820:         ] {
13821:             let unit = crate::compilation_unit::CompilationUnit::build_with_context_registry(
13822:                 negative,
13823:                 options,
13824:                 None,
13825:                 std::sync::Arc::clone(&context),
13826:             );
13827:             let warnings = find_taint_warnings_for_cu(
13828:                 &unit,
13829:                 registry,
13830:                 Some(tcl_dialect::DialectProfile::irules()),
13831:             );
13832:             assert!(
13833:                 warnings
13834:                     .iter()
13835:                     .all(|warning| warning.code != DiagCode::Irule3001),
13836:                 "{negative}: {warnings:?}"
13837:             );
13838:         }
13839:         // An unavailable TMM transition does not prove that a later event's
13840:         // command is deleted. Its conditional hosted descriptor remains advice.
13841:         let uncertain = "rename HTTP::respond {}; when HTTP_REQUEST {HTTP::respond 200 content $x}";
13842:         let unit = crate::compilation_unit::CompilationUnit::build_with_context_registry(
13843:             uncertain,
13844:             options,
13845:             None,
13846:             std::sync::Arc::clone(&context),
13847:         );
13848:         let warnings = find_taint_warnings_for_cu(
13849:             &unit,
13850:             registry,
13851:             Some(tcl_dialect::DialectProfile::irules()),
13852:         );
13853:         assert!(
13854:             warnings
13855:                 .iter()
13856:                 .any(|warning| warning.code == DiagCode::Irule3001)
13857:         );
13858:     }
13859: 
13860:     /// A name an opaque `switch`'s arm may overwrite keeps the taint it held
13861:     /// when no arm runs: the arm need not run, so `puts $u` still sees data
13862:     /// read from the channel.
13863:     #[test]
13864:     fn a_tainted_name_an_opaque_switch_arm_may_overwrite_stays_tainted() {
13865:         let registry = CommandRegistry::build_default();
13866:         let source = "proc p {s} {\n set u [gets stdin]\n switch -glob -- $s { q* { set u clean } }\n puts $u\n}\n";
13867:         let cu = crate::compilation_unit::CompilationUnit::build_for(source, &registry, false)
13868:             .with_interprocedural(&registry, None);
13869:         let found = find_taint_warnings_for_cu(&cu, &registry, None);
13870:         assert!(
13871:             found.iter().any(|w| w.code == DiagCode::T101),
13872:             "expected T101 for the sink after the switch, got {found:?}"
13873:         );
13874:     }
13875:     #[test]
13876:     fn required_replay_empty_success_differs_from_withdrawn_source_owner() {
13877:         let context =
13878:             tcl_registry::model::ingress::resolve_environment("tcl8.6").default_context_registry();
13879:         let registry = context.commands();
13880:         let (_owner, unit) = retained_warning_unit("set value 1", &context);
13881:         let current = taint_warning_report_for_cu(&unit, registry, None);
13882:         assert!(current.warnings.is_empty());
13883:         assert!(current.replays.is_complete());
13884:         let mut withdrawn = unit.clone();
13885:         withdrawn.ir_module.retained_source_bindings = None;
13886:         let missing = taint_warning_report_for_cu(&withdrawn, registry, None);
13887:         assert!(missing.warnings.is_empty());
13888:         assert!(!missing.replays.is_complete());
13889:         assert!(matches!(
13890:             missing.replays,
13891:             TaintReplayAnalysis::Unavailable { .. }
13892:         ));
13893:     }
13894: 
13895:     #[test]
13896:     fn unavailable_nested_replay_retains_original_site_and_independent_warnings() {
13897:         let context =
13898:             tcl_registry::model::ingress::resolve_environment("tcl8.6").default_context_registry();
13899:         let registry = context.commands();
13900:         let source = "set payload [gets stdin]\nregexp $payload haystack\n[eval $payload]";
13901:         let (_owner, unit) = retained_warning_unit(source, &context);
13902:         let proven = taint_warning_report_for_cu(&unit, registry, None).warnings;
13903:         assert!(proven.iter().any(|warning| warning.code == DiagCode::T103));
13904:         let statement = unit
13905:             .top_level
13906:             .ssa
13907:             .blocks
13908:             .values()
13909:             .flat_map(|block| &block.statements)
13910:             .find(|statement| {
13911:                 statement
13912:                     .statement
13913:                     .tokens()
13914:                     .and_then(|tokens| tokens.word_exprs.first())
13915:                     .is_some_and(|word| {
13916:                         let mut children = Vec::new();
13917:                         command_substitutions_in_word(word, &mut children);
13918:                         !children.is_empty()
13919:                     })
13920:             })
13921:             .expect("genuine original command-head substitution");
13922:         let word = statement
13923:             .statement
13924:             .tokens()
13925:             .unwrap()
13926:             .word_exprs
13927:             .first()
13928:             .unwrap();
13929:         let mut children = Vec::new();
13930:         command_substitutions_in_word(word, &mut children);
13931:         let (spelling, span) = children.first().unwrap();
13932:         let script = spelling
13933:             .strip_prefix('[')
13934:             .unwrap()
13935:             .strip_suffix(']')
13936:             .unwrap();
13937:         let unavailable = std::cell::RefCell::new(Vec::new());
13938:         let shadowed = HashSet::new();
13939:         let sink = SinkWarningContext {
13940:             registry,
13941:             source: TaintSourceContext::for_input(registry, None, unit.ir_module.lexer_config),
13942:             dialect: unit.ir_module.dialect_profile,
13943:             shadowed_builtins: &shadowed,
13944:             original_module: Some(&unit.ir_module),
13945:             unavailable_replays: Some(&unavailable),
13946:         };
13947:         let mut warnings = proven.clone();
13948:         emit_isolated_script_warnings(
13949:             script,
13950:             *span,
13951:             statement,
13952:             &unit.top_level.taints,
13953:             &mut warnings,
13954:             &unit.top_level.ssa,
13955:             &sink,
13956:             None,
13957:         );
13958:         assert_eq!(warnings, proven);
13959:         let unavailable = unavailable.into_inner();
13960:         assert_eq!(unavailable.len(), 1);
13961:         assert_eq!(unavailable[0].span, *span);
13962:         assert_eq!(
13963:             unavailable[0].reason,
13964:             UnavailableTaintReplayReason::SourceMetadata
13965:         );
13966:         let captured = unavailable[0].source.as_ref().unwrap();
13967:         assert!(captured.matches_module(&unit.ir_module, registry));
13968:         let mut changed = unit.ir_module.clone();
13969:         changed.source = tcl_lexer::SourceImage::document("set payload fixed");
13970:         assert!(!captured.matches_module(&changed, registry));
13971:         let mut changed_entry = unit.ir_module.clone();
13972:         changed_entry.source_entry.unknown_entry = !changed_entry.source_entry.unknown_entry;
13973:         assert!(!captured.matches_module(&changed_entry, registry));
13974:         let mut changed_namespace = unit.ir_module.clone();
13975:         changed_namespace.top_level_namespace = "::different_replay_source".to_owned();
13976:         assert!(!captured.matches_module(&changed_namespace, registry));
13977:         let mut foreign = tcl_registry::CommandRegistry::build_default();
13978:         foreign.insert(tcl_registry::CommandSpec {
13979:             name: "__foreign_replay_store",
13980:             ..tcl_registry::CommandSpec::DEFAULT
13981:         });
13982:         assert!(!captured.matches_module(&unit.ir_module, &foreign));
13983:     }
13984: 
13985:     #[test]
13986:     fn scaffold_constructors_require_actual_selected_descriptor_identity() {
13987:         let context =
13988:             tcl_registry::model::ingress::resolve_environment("tcl8.6").default_context_registry();
13989:         let registry = context.commands();
13990:         let actual = ScaffoldConstructors::required(registry, None, true, true, true).unwrap();
13991:         assert_eq!(actual.rebinding_priority(registry, None, "proc"), 2);
13992:         assert_eq!(actual.rebinding_priority(registry, None, "::proc"), 2);
13993:         assert_eq!(actual.rebinding_priority(registry, None, "interp"), 1);
13994:         assert_eq!(actual.rebinding_priority(registry, None, "ordinary"), 0);
13995:         let mut replacement = tcl_registry::CommandRegistry::build_default();
13996:         replacement.insert(registry.get("proc").unwrap().clone());
13997:         assert_eq!(actual.rebinding_priority(&replacement, None, "proc"), 0);
13998:         assert!(matches!(
13999:             ScaffoldConstructors::required(registry, None, false, true, false),
14000:             Err(UnavailableTaintReplayReason::SourceMetadata)
14001:         ));
14002:         assert!(ScaffoldConstructors::required(registry, None, false, false, false).is_ok());
14003:         let mut unavailable = tcl_registry::CommandRegistry::build_default();
14004:         unavailable.insert(tcl_registry::CommandSpec {
14005:             state_transitions: Some(tcl_registry::StateTransitionDescriptor::EMPTY),
14006:             ..registry.get("proc").unwrap().clone()
14007:         });
14008:         assert!(matches!(
14009:             ScaffoldConstructors::required(&unavailable, None, true, true, false),
14010:             Err(UnavailableTaintReplayReason::ProcedureConstructor)
14011:         ));
14012:     }
14013:     #[test]
14014:     fn callback_unavailable_spans_require_bounded_original_correspondence() {
14015:         let context =
14016:             tcl_registry::model::ingress::resolve_environment("tcl8.6").default_context_registry();
14017:         let (_owner, unit) = retained_warning_unit("set value 1", &context);
14018:         let end = u32::try_from(unit.source.len()).unwrap();
14019:         let registration = unit.ir_module.top_level.statements.first().unwrap().span();
14020:         let replay = Span::new(end + 1, end + 21);
14021:         let spans = [(replay, registration, "input".to_owned())];
14022:         let residual = |span| UnavailableTaintReplay {
14023:             span,
14024:             reason: UnavailableTaintReplayReason::SourceMetadata,
14025:             source: None,
14026:         };
14027:         let original = residual(Span::new(0, end));
14028:         assert_eq!(
14029:             original_callback_replay_residuals(&original, &unit, &spans)[0].span,
14030:             original.span
14031:         );
14032:         for span in [
14033:             Span::new(end + 2, end + 3),
14034:             Span::new(end - 1, end + 2),
14035:             Span::new(end + 30, end + 31),
14036:         ] {
14037:             let mapped = original_callback_replay_residuals(&residual(span), &unit, &spans);
14038:             assert_eq!(mapped.len(), 1);
14039:             assert_eq!(mapped[0].span, registration);
14040:             assert!(
14041:                 mapped[0]
14042:                     .source
14043:                     .as_ref()
14044:                     .unwrap()
14045:                     .matches_module(&unit.ir_module, context.commands())
14046:             );
14047:         }
14048:         let out_of_bounds = residual(Span::new(end + 30, end + 31));
14049:         let unmapped = original_callback_replay_residuals(&out_of_bounds, &unit, &[]);
14050:         assert_eq!(unmapped[0].span, out_of_bounds.span);
14051:         assert!(unmapped[0].source.is_none());
14052:     }
14053:     #[test]
14054:     fn public_report_keeps_constructor_refusal_beside_an_independent_warning() {
14055:         let baseline =
14056:             tcl_registry::model::ingress::resolve_environment("tcl8.6").default_context_registry();
14057:         let mut supplied = tcl_registry::CommandRegistry::build_default();
14058:         supplied.insert(tcl_registry::CommandSpec {
14059:             state_transitions: Some(tcl_registry::StateTransitionDescriptor::EMPTY),
14060:             ..baseline.commands().get("proc").unwrap().clone()
14061:         });
14062:         let context =
14063:             std::sync::Arc::new(baseline.with_command_store(std::sync::Arc::new(supplied)));
14064:         let registry = context.commands();
14065:         let source = "set payload [gets stdin]\nregexp $payload haystack\nrename puts replacement\n[puts $payload]";
14066:         let (_owner, unit) = retained_warning_unit(source, &context);
14067:         let report = taint_warning_report_for_cu(&unit, registry, None);
14068:         assert!(
14069:             report
14070:                 .warnings
14071:                 .iter()
14072:                 .any(|warning| warning.code == DiagCode::T103)
14073:         );
14074:         assert!(!report.replays.is_complete());
14075:         let refusal = report
14076:             .replays
14077:             .unavailable_replays()
14078:             .iter()
14079:             .find(|residual| residual.reason == UnavailableTaintReplayReason::ProcedureConstructor)
14080:             .expect("actual required scaffold constructor is unavailable");
14081:         assert!(
14082:             refusal
14083:                 .source
14084:                 .as_ref()
14085:                 .unwrap()
14086:                 .matches_module(&unit.ir_module, registry)
14087:         );
14088:         assert_eq!(
14089:             unit.ir_module
14090:                 .source
14091:                 .bytes()
14092:                 .get(refusal.span.as_range())
14093:                 .unwrap(),
14094:             b"[puts $payload]"
14095:         );
14096:     }
14097: }
/* ORIGINAL_SOURCE_RANGE 14099..14182 */
14099: #[cfg(test)]
14100: mod original_taint_local_parser_purpose_tests {
14101:     use super::*;
14102: 
14103:     #[test]
14104:     fn original_taint_callback_and_bracket_shapes_keep_actual_full_config() {
14105:         // naming.source.retained-positioned-command-realm
14106:         // docs/design/analysis/name-resolution-proofs/retained-positioned-command-realm.md
14107:         // These local source/synthetic replay projections grant no callback execution.
14108:         let mut prepared = crate::analyser::Analyser::new();
14109:         let input = prepared.prepare_analysis_input("tcl9.0").unwrap();
14110:         for bom in [tcl_lexer::LeadingBom::Skip, tcl_lexer::LeadingBom::Content] {
14111:             let config = tcl_lexer::LexerConfig {
14112:                 leading_bom: bom,
14113:                 strict_quoting: true,
14114:                 braced_var: tcl_lexer::BracedVarStyle::FirstClose,
14115:                 ..input.lexer_config()
14116:             };
14117:             let actual_input = crate::analyser::ResolvedAnalysisInput::new(
14118:                 input.analyser_profile(),
14119:                 input.unit_profile(),
14120:                 input.context_registry(),
14121:                 config,
14122:             );
14123:             let registry = actual_input.borrowed_context_registry().commands();
14124:             let unit = crate::compilation_unit::CompilationUnit::build_with_analysis_input(
14125:                 "set value VALUE",
14126:                 crate::compilation_unit::UnitBuildOptions {
14127:                     registry,
14128:                     defer_top_level: false,
14129:                     config,
14130:                     dialect: Some(actual_input.unit_profile()),
14131:                     external_call_sites: None,
14132:                     declared_commands: None,
14133:                 },
14134:                 None,
14135:                 &actual_input,
14136:             );
14137:             let source =
14138:                 TaintSourceContext::for_module_function(registry, &unit.ir_module, &unit.top_level);
14139:             assert_eq!(source.config, config);
14140:             assert!(source.metadata.is_some());
14141:             let callback =
14142:                 callback_replay_script("\u{feff}eval literal", &[], "input", source.config)
14143:                     .unwrap();
14144:             assert!(
14145:                 callback.starts_with('\u{feff}'),
14146:                 "body mark is not the file prologue: {callback:?}"
14147:             );
14148:             let (head, args) =
14149:                 parse_taint_command_substitution("[\u{feff}eval literal]", source.config).unwrap();
14150:             assert_eq!(head, "\u{feff}eval");
14151:             assert_eq!(args, ["literal"]);
14152:             let first_close = "eval ${a{b}; eval literal";
14153:             assert!(callback_replay_script(first_close, &[], "input", source.config).is_some());
14154:             let nesting = tcl_lexer::LexerConfig {
14155:                 braced_var: tcl_lexer::BracedVarStyle::Tcl9Nesting,
14156:                 ..source.config
14157:             };
14158:             assert!(callback_replay_script(first_close, &[], "input", nesting).is_none());
14159:             let mut changed = unit.clone();
14160:             changed.ir_module.lexer_config.strict_quoting = !config.strict_quoting;
14161:             assert!(
14162:                 TaintSourceContext::for_module_function(
14163:                     registry,
14164:                     &changed.ir_module,
14165:                     &changed.top_level
14166:                 )
14167:                 .metadata
14168:                 .is_none()
14169:             );
14170:             changed.ir_module.source_metadata_input = None;
14171:             assert!(
14172:                 TaintSourceContext::for_module_function(
14173:                     registry,
14174:                     &changed.ir_module,
14175:                     &changed.top_level
14176:                 )
14177:                 .metadata
14178:                 .is_none()
14179:             );
14180:         }
14181:     }
14182: }
/* ORIGINAL_SOURCE_RANGE 14184..14227 */
14184: #[cfg(test)]
14185: mod original_taint_word_purpose_tests {
14186:     use super::*;
14187: 
14188:     #[test]
14189:     fn original_interpolation_literals_keep_bom_prefix_and_rendered_line_breaks() {
14190:         // naming.source.original-configured-script-completeness
14191:         // docs/design/analysis/name-resolution-proofs/source-original-configured-script-completeness.md
14192:         // Authored interpolation syntax; no value/effect or Native observer receipt.
14193:         let config = tcl_lexer::LexerConfig {
14194:             leading_bom: tcl_lexer::LeadingBom::Skip,
14195:             braced_var: tcl_lexer::BracedVarStyle::FirstClose,
14196:             strict_quoting: true,
14197:             ..tcl_lexer::LexerConfig::default()
14198:         };
14199:         let text = "\u{feff}#prefix\\n$x";
14200:         assert_eq!(leading_literal_prefix_char(text, config), Some('\u{feff}'));
14201:         assert!(literal_contains_crlf(text, config));
14202:         assert_eq!(
14203:             leading_literal_prefix_char("\u{feff}/$x", config),
14204:             Some('\u{feff}')
14205:         );
14206:         assert!(!literal_contains_crlf("{\u{feff}#prefix\\n$x}", config));
14207:         let joined =
14208:             TaintLattice::tainted().with(TaintColour::CRLF_FREE | TaintColour::PATH_PREFIXED);
14209:         let colour = interpolation_carve_out(text, joined, config);
14210:         assert!(
14211:             colour
14212:                 .colours
14213:                 .contains(TaintColour::TAINTED | TaintColour::NON_DASH_PREFIXED)
14214:         );
14215:         assert!(
14216:             !colour
14217:                 .colours
14218:                 .intersects(TaintColour::CRLF_FREE | TaintColour::PATH_PREFIXED)
14219:         );
14220:         assert_eq!(
14221:             colour,
14222:             interpolation_carve_out(text, joined, config.nested())
14223:         );
14224:         assert_eq!(leading_literal_prefix_char("${a{b}", config), None);
14225:         assert_eq!(config.leading_bom, tcl_lexer::LeadingBom::Skip);
14226:     }
14227: }
