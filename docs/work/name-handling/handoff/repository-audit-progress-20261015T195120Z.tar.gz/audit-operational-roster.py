import json,pathlib,collections,datetime
b=pathlib.Path('/workspace/name-session/full-consumer-audit');c=json.loads((b/'audit-file-coverage.json').read_text());code={'.rs','.py','.sh','.bash','.js','.ts','.tsx','.jsx','.c','.h','.cpp','.tcl','.test','.fish','.ps1','.el','.lua','.rb','.pl','.bat','.cmd','.html','.css','.scss','.svelte','.vue'};groups=collections.defaultdict(list)
for r in c['files']:
 p=r['path'];ext=pathlib.Path(p).suffix;archive=p.startswith(('experiments/','docs/design/analysis/name-resolution-proofs/rust-validation/','scripts/dev/bigip-probes/resolution-2286/evidence/','docs/work/name-handling/handoff/'))
 if p.startswith('rust/') and ('/src/' in p or p.endswith('/build.rs')):g='product_sources_and_assets'
 elif p.startswith(('scripts/','tools/')) and not archive and (ext in code or pathlib.Path(p).name in {'Makefile','justfile'}):g='repository_tooling_source_candidates'
 elif p.startswith(('tests/','samples/')) and ext in code:g='test_and_sample_program_candidates'
 elif archive and ext in code:g='archived_harness_or_provider_source_unresolved'
 elif ext=='.md' and r['review_mode']!='generated_record_projection_owner_trace':g='hand_authored_guidance_or_historical_prose_pending_purpose'
 elif not archive and ext in {'.toml','.json','.yaml','.yml','.grammar','.ebnf','.y','.l','.g4','.xml'}:g='first_party_metadata_grammar_or_build_input_candidates'
 else:g='archive_or_nonprogram_data_inventory'
 groups[g].append({'path':p,'blob':r['blob'],'source_sha256':r['source_sha256'],'review_status':r['review_status'],'review_mode':r['review_mode'],'classification':r['classification']})
out={'baseline':c['baseline'],'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Inventory partition for audit-owned paths to prioritize actual operational review. Candidate grouping is not semantic purpose review or exclusion. Every unexamined candidate remains unfinished; provider origin/archived harness roles require explicit provenance.','groups':dict(groups),'summary':{k:{'files':len(v),'reviewed':sum(r['review_status']=='reviewed' for r in v),'unfinished':sum(r['review_status']!='reviewed' for r in v)} for k,v in groups.items()}};(b/'audit-operational-roster.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out['summary'],indent=2))
