from pathlib import Path
import datetime, hashlib, io, json, shutil, subprocess, tarfile, tempfile

directory = Path(__file__).resolve().parent
handoff = Path('/workspace/tcl-lsp/docs/work/name-handling/handoff')
stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
name = f'repository-audit-progress-{stamp}.tar.gz'
snapshot = Path(tempfile.mkdtemp(prefix='naming-audit-checkpoint-', dir='/tmp'))
for source in sorted(directory.iterdir()):
    if source.is_file() and source.suffix in ('.json', '.md', '.py'):
        data = source.read_bytes()
        if source.suffix == '.json':
            json.loads(data)
        (snapshot / source.name).write_bytes(data)
result = subprocess.run(['python3', str(snapshot / 'consolidate.py'), str(snapshot)],
                        check=True, stdout=subprocess.PIPE)
(snapshot / 'consolidate-latest-summary.json').write_bytes(result.stdout)
consolidated = json.loads((snapshot / 'consolidated-in-progress.json').read_text())
assert not consolidated['binding_errors']
assert not consolidated['duplicate_site_candidates']
members = []
with tarfile.open(handoff / name, 'w:gz') as archive:
    for source in sorted(snapshot.iterdir()):
        data = source.read_bytes()
        info = tarfile.TarInfo(source.name)
        info.size = len(data)
        archive.addfile(info, io.BytesIO(data))
        members.append({'path': source.name, 'sha256': hashlib.sha256(data).hexdigest()})
    data = json.dumps({'status': 'INCOMPLETE; exact frozen inputs reconciled',
                       'members': members}, indent=2).encode()
    info = tarfile.TarInfo('CHECKPOINT-MEMBERS.json')
    info.size = len(data)
    archive.addfile(info, io.BytesIO(data))
with tarfile.open(handoff / name) as archive:
    for member in members:
        assert hashlib.sha256(archive.extractfile(member['path']).read()).hexdigest() == member['sha256']
packet = {'file': name, 'sha256': hashlib.sha256((handoff / name).read_bytes()).hexdigest(),
          'status': f"INCOMPLETE cc24 source audit: {len(consolidated['consumers'])} provisional purpose rows; exact frozen input partitions/source SHA/schema reconcile, no same-key duplicate candidates. Includes shared owners, display, metadata/owner repairs and exclusions. Unexamined scope, work-kind/count-unit and independent semantic reconciliation remain; NOT remaining-consumer total. Peer corrections retained; no blanket execution/generator/gate acceptance."}
index = handoff / 'packets.json'
packets = json.loads(index.read_text())
packets.append(packet)
index.write_text(json.dumps(packets, indent=2) + '\n')
checksums = handoff / 'SHA256SUMS'
checksums.write_text(checksums.read_text() + packet['sha256'] + '  ' + name + '\n')
shutil.rmtree(snapshot)
print(json.dumps({**packet, 'verified_members': len(members)}))
