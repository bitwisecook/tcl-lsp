import json,pathlib,hashlib,subprocess,collections,datetime,runpy,re
B=pathlib.Path('/workspace/name-session/full-consumer-audit');R=pathlib.Path('/workspace/tcl-lsp');x=runpy.run_path(str(B/'audit-review-tools.py'));c,s=x['load']();by={r['path']:r for r in c['files']};errors=[];drift=[];cache={};seen=set()
for z in s['consumers']:
 p=z['path'];r=by.get(p)
 if not r:errors.append(['foreign-path',p]);continue
 if z['id'] in seen:errors.append(['duplicate-id',z['id']])
 seen.add(z['id'])
 if z['source_sha256']!=r['source_sha256'] or z['blob']!=r['blob']:errors.append(['source-reference',z['id']])
 if p not in cache:
  d=x['content'](r);cache[p]=d
  if hashlib.sha256(d).hexdigest()!=r['source_sha256']:errors.append(['baseline-sha',p])
 if not 1<=z['line']<=len(cache[p].decode().splitlines()):errors.append(['line',z['id'],z['line']])
 if z['disposition'] not in {'needs_migration','migrated_validation_pending','migrated_verified','shared_owner','display_only','out_of_scope','pending_audit','pending_validation'}:errors.append(['disposition',z['id']])
for r in c['files']:
 if r['review_mode'].startswith('whole_'):
  d=cache.get(r['path'])
  if d is None:d=x['content'](r);cache[r['path']]=d
  if hashlib.sha256(d).hexdigest()!=r['source_sha256']:errors.append(['baseline-sha',r['path']])
  w=R/r['path']
  if not w.is_file() or hashlib.sha256(w.read_bytes()).hexdigest()!=r['source_sha256']:drift.append(r['path'])
 for cid in r['consumer_ids']:
  if cid not in seen:errors.append(['dangling-file-consumer',r['path'],cid])
q={'baseline':c['baseline'],'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':len(c['files']),'modes':dict(collections.Counter(r['review_mode'] for r in c['files'])),'purpose_rows':len(s['consumers']),'dispositions':dict(collections.Counter(r['disposition'] for r in s['consumers'])),'errors':errors,'whole_review_current_worktree_drift':drift,'scope':'Artifact consistency and exact original baseline-byte source correspondence only; no source compilation/provider/generator execution, semantic uniqueness or runtime acceptance.'};(B/'audit-artifact-qa.json').write_text(json.dumps(q,indent=2)+'\n')
known={
 'rust/tcl-bigip/src/parser/bespoke.rs':('actual_inline_operational_setup_read','All25 test bodies/helpers1926–2387 read; actual shared Registry/config parser and compile-time include samples/bigip/bigip.conf, in-memory model/value/offset assertions; no external fixture/provider execution admitted.'),
 **{p:('independent_inline_operational_peer_read','LSP exact actual whole-source loan receipt includes all inline tests/helpers/process/provider/fs/config/generated template/cleanup branches. Primary exact SHA plus bounded semantic kernel challenge; no execution.') for p in ['rust/xtask/src/owner_resolution.rs','rust/xtask/src/owner_resolution/source_internal.rs','rust/xtask/src/registry_axes.rs','rust/tcl-fuzz/src/generator.rs','rust/tcl-bigip-query/src/builtins/net.rs','rust/tcl-irule-test/src/live.rs','rust/xtask/src/smoke_targets.rs']},
 'rust/xtask/src/kcs_index_links.rs':('independent_inline_operational_peer_read','Root exact whole983 source includes all12 actual inline tests847–983. Fixed actual source fixtures/assertions, no gate/test execution. Bounded primary path/purpose challenge; prefix predicate excluded from identity repair.'),
 'rust/tcl-bigip-query/src/builtins/mod.rs':('independent_inline_operational_peer_read','Root exact1771 whole source includes all20 actual inline bodies/helpers including worker256MiB stack/deep model values; no external fs/process/provider setup. No execution.'),
 'rust/tcl-fuzz/src/findings.rs':('actual_inline_operational_setup_read','All14 tests actually read:3 in-memory generator-rate fixtures and11 actual fs/staged JSON/Tcl/summary/reproducer ownership fixtures. No execution.'),
 'rust/tcl-fuzz/src/main.rs':('actual_inline_operational_setup_read','All31 CLI/config/synthetic outcome and actual filesystem finding/summary/record setup tests whole read1635–2291. No actual backend process invoked by these test bodies; no execution.'),
 'rust/xtask/src/value_transfers.rs':('actual_inline_operational_setup_read','All14 test bodies/helpers whole read1176–1358:13 in-memory Rust/Lint/ledger fixtures; one actual source inventory and repository ledger-reading gate assertion. No execution.'),
 'rust/xtask/src/editor_extensions.rs':('actual_inline_operational_setup_read','All15 tests/helpers whole read: actual compiled environment + bundled SpecTcl model, real target file reads/JSON/Regex operations, mutation/restoration and temp directory create/config write/removal. No execution.'),
 'rust/xtask/src/gen_editor_configs.rs':('actual_inline_operational_setup_read','All11 tests/helpers whole read: actual model/bundled inputs and every target file read; generated-region restores; manual elisp balance scanner only source validation. No execution.'),
 'rust/xtask/src/gen_tmlanguage_keywords.rs':('actual_inline_operational_setup_read','All8 tests/helpers whole read: actual Registry, Rust regex compile + matching, target committed file reads/bounded source splices. No execution.'),
 'rust/xtask/src/gen_zed_queries.rs':('actual_inline_operational_setup_read','All6 tests/helpers whole read: actual Registry/provider union and actual generated target/config source reads; static sets/sentinels/assertions. No external processes/provider; no execution.'),
 'rust/xtask/src/segmentation_drift.rs':('actual_inline_operational_setup_read','All14 tests/helpers whole read; final source differential-presence test reads actual repository file and explicit nonexistent source. Other Rust snippets pure in-memory. No execution.'),
 'rust/xtask/src/retired_api_gate.rs':('actual_inline_setup_read','All10 tests/helpers whole read: original literal Rust snippets/owner strings/comment/waiver/assertion only. Production repository scan not invoked by tests. No execution.'),
 'rust/xtask/src/tcltest_sweep.rs':('actual_inline_operational_setup_read','All4 tests/helper whole read: actual checked-in overlay read and real temp directory/file inventory creation/removal; focused selection and scoreboard tests in-memory. No execution.'),
 'rust/xtask/src/number_drift.rs':('actual_inline_operational_setup_read','All12 tests/helper whole read; expression boundary uniqueness test reads actual repository source tree; other source snippet/waiver checks pure in-memory. No execution.'),
 'rust/xtask/src/fp_sweep.rs':('actual_inline_setup_read','All4 test/helper whole read: only in-memory original source/RST literal extraction/line offset/assertions; no filesystem/process/provider setup. No execution.'),
 'rust/tcl-bigip/src/model/gen/dispatch.rs':('actual_inline_setup_read','Both tests whole read: literal quoted/unquoted original config header through shared tokenizer; no filesystem/process/provider setup. No execution.'),
 'rust/tcl-bigip/src/tls.rs':('actual_inline_operational_setup_read','All8 tests and helpers actually read: real shared config parser/TLS importer; one actual included PEM parsed through certificate owner. External included PEM/provider provenance separate, no execution.'),
 'rust/tcl-bigip/src/redact.rs':('actual_inline_setup_read','All5 tests/helpers whole read: fixed MT19937 vectors and actual in-memory string/map codec/secret replacements; no external process/env/fs/provider setup.'),
 'rust/tcl-bigip/src/pcap_remap.rs':('actual_inline_setup_read','All7 tests/helpers whole read: numeric checksums, Vec packet constructors and in-memory remap/assertions; no fs/env/Command/provider setup.'),
 'rust/tcl-bigip/src/pcap_enrich.rs':('actual_inline_setup_read','All5 tests/helpers whole read: static label/address/index and actual in-memory GTM parser fixtures; no fs/env/Command/provider setup.'),
 'rust/tcl-bigip/src/policy_eval.rs':('actual_inline_setup_read','All12 tests/helpers whole read: in-memory model/value/operator/URL fixtures; no fs/env/Command/provider setup.'),
 'rust/tcl-bigip-query/src/builtins/math.rs':('actual_inline_setup_read','Both tests/helpers whole read: numeric constants/calculations and literal assertions only; no fs/env/Command/provider setup.'),
 **{p:('independent_inline_operational_peer_read','Root exact3773-line whole source peer root-xtask-03-peer.json includes all actual inline operational source/process/IO tests; Audit verifies source+aid+anchors and independently challenges bounded kernels. No execution.') for p in ['rust/xtask/src/audit_option_dialects.rs','rust/xtask/src/bigip_data_schema.rs','rust/xtask/src/callback_inventory.rs','rust/xtask/src/dialect_drift.rs']},
 'rust/tcl-bigip/src/f5_trailer.rs':('actual_inline_setup_read','All3 overlay tests/helpers actually read, in-memory typed schema parse/summary only, no Command/env/fs/provider setup.'),
 'rust/tcl-bigip/src/lint.rs':('actual_inline_operational_setup_read','All6 tests/helpers actually read: shared Bigip parser/Registry/model fixtures and warnings, no external fs/env/Command/provider setup; unexecuted.'),
 'rust/tcl-bigip-io/src/openpgp.rs':('actual_inline_setup_read','All2 tests/helpers actual read: byte packet constructors/nested memory payload, no fs/env/process/provider setup; no execution.'),
 'rust/tcl-fuzz/src/wasm_diff.rs':('actual_inline_operational_setup_read','All8 tests actual read: Wasmtime engine/compiler/software VM and fuel checks; no external process/provider; no execution.'),
 'rust/tcl-irule-test/src/topology.rs':('actual_inline_setup_read','All9 tests/helpers manually read: actual in-memory source/model transformations, Registry/list parser controls; no external process/fs/provider setup, unexecuted.'),
 'rust/tcl-irule-test/src/pure_functions.rs':('actual_inline_operational_setup_read','All5 tests/helpers manually read: actual LiveSession loads framework/VM, optional original tclsh processes, typed host/refcount and byte-origin controls; unexecuted.'),
 **{p:('independent_inline_operational_peer_read','Root exact whole-source peer root-xtask-peer.json includes every actual inline operational test/setup/publication guard. Audit admitted exact blob/SHA/line anchors and bounded kernel challenge; no inferred purity or execution.') for p in ['rust/xtask/src/gen_editor_dialects.rs','rust/xtask/src/gen_vscode_package.rs','rust/xtask/src/gen_jetbrains.rs','rust/xtask/src/util.rs']},
 **{p:('independent_inline_operational_peer_read','Root exact3748-line whole-source peer root-xtask-02-peer.json includes every actual test/helper/fs/provider/network/process/artifact stage. Audit rebound exact source/aid/SHA and challenged targeted source-status kernels; no execution/purity inference.') for p in ['rust/xtask/src/gen_irule_test_data.rs','rust/xtask/src/gen_environment_docs.rs','rust/xtask/src/registry_oracle.rs','rust/xtask/src/sslictcl_data.rs','rust/xtask/src/callback_coverage.rs','rust/xtask/src/command_backing.rs']},
 'rust/tcl-bigip-query/src/probes/tls.rs':('actual_inline_operational_setup_read','All3 tests read: actual native cert provider; actual loopback listener/thread/TLS connection; literal diagnostic classification. Source comment no network involved is inaccurate, tests unexecuted.'),
 'rust/tcl-bigip-query/src/examples.rs':('actual_inline_setup_read','Single header/nonempty/trailing-newline literal formatter test actual read, does not execute Query or process/fs.'),
 'rust/tcl-bigip/src/pcapng.rs':('actual_inline_setup_read','All3 NRB/DSB literal byte-array/data tests and helpers actually read, no external fs/process/provider setup.'),
 'rust/tcl-bigip/src/secrets.rs':('actual_inline_setup_read','All6 source/Regex/rewrite-closure tests and helper CONF actual read, no external process/fs/env/cipher-provider setup invoked.'),
 'rust/tcl-fuzz/src/bpf_diff.rs':('actual_inline_operational_setup_read','All4 tests read: first2 actual codegen/emitter/userspace BPF VM, third Registry source construction, fourth seed data; unexecuted.'),
 'rust/tcl-fuzz/src/wasm.rs':('actual_inline_operational_setup_read','All3 tests read: first typed stub binary; last2 actual temp_dir/fs and external wasmtime process via check, allow Unavailable explicitly; unexecuted.'),
 'rust/tcl-fuzz/src/linked_wasm.rs':('actual_inline_setup_read','All4 seeded source/QUERY/bootstrap string assertions read; actual Cargo/process/fs helpers not invoked.'),
 'rust/tcl-fuzz/src/engine.rs':('actual_inline_setup_read','All5 tests fixed args/labels and explicit nonexistent Path override; actual search not invoked, no external setup.'),
 'rust/tcl-fuzz/src/characterize.rs':('actual_inline_setup_read','Both synthetic Outcome relationship tests and helpers actual read; no process/provider setup.'),
 'rust/tcl-fuzz/src/version.rs':('actual_inline_setup_read','Both literal version parsing/skew tests actual read; probe/fs/process not invoked.'),
 'rust/tcl-fuzz/src/harness.rs':('actual_inline_setup_read','All11 synthetic Outcome policy tests/helpers actual read; operational launch/write helper not invoked by tests.'),
 'rust/xtask/src/catalogue_callers.rs':('actual_inline_setup_read','All4 literal snippets/map/allowlist tests actually read, no external file/provider setup invoked.'),
 'rust/xtask/src/tzdata_bundle.rs':('actual_inline_setup_read','All3 literal byte-vector/format tests actually read; actual zoneinfo build not invoked, no external file/provider setup.'),
 'rust/xtask/src/resolution_drift.rs':('actual_inline_setup_read','All5 actual literal snippet/scanner/waiver tests read, no fs/env/process setup.'),
 'rust/xtask/src/diag_tables.rs':('actual_inline_operational_setup_read','Single actual test reads3 repository generated outputs and complete central-descriptor renders through repo_root; unexecuted.'),
 'rust/xtask/src/runtime_stdlib.rs':('actual_inline_setup_read','Both synthetic manifest/digest/literal FILES tests and helpers read; no external IO invoked.'),
 'rust/xtask/src/diag_emission.rs':('actual_inline_operational_setup_read','All8 tests read; final test calls run(), actually recursively reads repository source roots. Other lexical detector tests in-memory; unexecuted.'),
 'rust/bigip-report-gen/rust/src/model.rs':('actual_inline_operational_setup_read','All10 inline tests and helpers actually read, in-memory parser/Registry/model/validator and generated version metadata; collect_model test reaches actual clock::now_epoch_seconds. No external fs/env/process/provider fixture setup or execution by audit.'),
 'rust/bigip-report-gen/rust/src/forensics.rs':('actual_inline_setup_read','All7 test bodies/helpers fully read: in-memory JSON/file text through actual Regex/record policy; no external Command/env/fs/provider setup, no execution.'),
 'rust/bigip-report-gen/rust/src/apm.rs':('actual_inline_operational_setup_read','All4 inline test bodies/helpers read; actual include_str1137-line fixture only truncated excerpt, whole fixture remains unfinished. Private parser/JSON graph setup, no external process/env/provider execution.'),
 'rust/bigip-report-gen/rust/src/security.rs':('actual_inline_operational_setup_read','All27 tests/helpers fully read; actual in-memory config/JSON plus real shared parser/crypt hashing/secret scan. No external process/env/fs mutation, no execution by audit.'),
 'rust/tcl-bigip-query/src/builtins/time_dt.rs':('actual_inline_operational_setup_read','Both tests fully read: now test reaches actual Utc::now clock; strftime test actual in-memory formatter. No environment/provider mutation or execution by audit.'),
 'rust/tcl-bigip-query/src/builtins/regex_str.rs':('actual_inline_setup_read','All3 tests and helpers fully read: actual in-memory Values/Regex/string only; no Command/env/fs/provider setup.'),
 'rust/bigip-report-gen/rust/src/certs.rs':('actual_inline_setup_read','All3 cn tests actual literal DN strings/assertions only, all bodies read; no fs/env/Command/provider/cryptographic setup.'),
 'rust/tcl-bigip-query/src/architecture.rs':('actual_inline_setup_read','Both tests use actual in-memory JSON and static authored source through shared lexer; all bodies/helpers read, no process/env/fs/provider setup.'),
 'rust/tcl-bigip/src/apl/parser.rs':('actual_inline_setup_read','Both test bodies/helpers and actual include_str20line sample read. Compile-time source fixture only; no process/env/fs/provider setup.'),
 'rust/tcl-bigip/src/apl/tokens.rs':('actual_inline_setup_read','All15 test bodies/helpers and actual include_str112line sample read; in-memory lexing/nonoverlap checks, no external process/env/fs/provider setup.'),
 'rust/tcl-bigip-query/src/builtins/f5profile.rs':('actual_inline_setup_read','All7 tests actual in-memory profile maps/values/static shared registry setup; no Command/env/fs/provider process.'),
 'rust/tcl-bigip-query/src/builtins/value2.rs':('actual_inline_setup_read','Both tests actual typed values and assertions only.'),
 'rust/tcl-bigip/src/flow/sessions.rs':('actual_inline_setup_read','All4 tests actual in-memory Flow/IndexMap construction/pairing assertions.'),
 'rust/tcl-bigip/src/flow/tshark.rs':('actual_inline_setup_read','All6 tests actual JSON/Flow maps only; external production Command worker not reached by test calls.'),
 'rust/tcl-bigip-query/src/special.rs':('actual_inline_operational_setup_read','Two tests/helpers read; deep test actually spawns std::thread Builder256MiB stack and joins worker. Unexecuted; not classified pure.'),
 'rust/bigip-report-gen/rust/src/lifecycle.rs':('actual_inline_setup_read','All3 tests actual static date/assertion data; production current clock not called.'),
 'rust/bigip-report-gen/rust/src/enrich.rs':('actual_inline_setup_read','Both tests actual in-memory JSON/network-annotation calculation.'),
 'rust/bigip-report-gen/rust/src/tls.rs':('actual_inline_operational_setup_read','Both tests read; multi-SNI test invokes actual shared parser/TLS importer/embedded trust dataset. Operational internal provider setup; no fresh execution.')}
rows=[]
for r in c['files']:
 if not r['review_mode'].startswith('whole_') or not r['path'].endswith('.rs'):continue
 d=cache[r['path']].decode();markers=[i for i,t in enumerate(d.splitlines(),1) if '#[test]' in t or '#[tokio::test]' in t or '#[cfg(test)]' in t]
 if not markers:continue
 status,reason=known.get(r['path'],('operational_classification_unresolved','Production source review retained independently. Prior extent/test notes may record body reads, but #[test] or absence of lexical Command matches does not establish purity; actual operational setup/guards require explicit body-evidence classification.'))
 rows.append({'path':r['path'],'blob':r['blob'],'source_sha256':r['source_sha256'],'markers':markers,'marker_mode':'lexical inventory only, not test-body/operational proof','status':status,'reason':reason,'existing_review_extent':r.get('reviewed_production_extent'),'existing_test_notes':r.get('tests'),'validation':'No test executed by audit.'})
out={'baseline':c['baseline'],'created_utc':q['checked_utc'],'scope':'Inline test/harness operational review annex for fully production-read Rust paths. Explicit unresolved statuses remain unfinished; not all test functions are pure, not a count of consumers or tests executed. External test files remain their own unexamined coverage rows.','files':rows,'summary':dict(collections.Counter(z['status'] for z in rows))};(B/'audit-inline-operational-census.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'whole':q['modes'].get('whole_production_read'),'whole_peer':q['modes'].get('whole_production_peer_read'),'rows':q['purpose_rows'],'errors':len(errors),'drift':drift,'inline_operational':out['summary']}))
