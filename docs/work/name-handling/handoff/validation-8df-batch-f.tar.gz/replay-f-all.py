from pathlib import Path
import concurrent.futures,subprocess,json,hashlib
base=Path('/workspace/name-session');build=base/'batch-f-build-ordinary';plans=json.loads((base/'f-replay-plans.json').read_text())
def run(label):
 row=plans[label];artifact=row['artifact'];assert hashlib.sha256(Path(artifact['path']).read_bytes()).hexdigest()==artifact['sha256']
 argv=['python3',str(base/'replay-frozen-a.py'),'--package',row['package'],'--plan',str(base/(label+'-f-plan.json')),'--out',str(base/('replay-f-'+label)),'--binary',artifact['path'],'--expected-source',str(build/'source-before.json.gz'),'--timeout','180','--jobs','1','--label','Frozen8df9a9169 ordinary replay; all selected551f controls/budgets retained plus reviewed actual ELF-listed additions; Native/provider closure independent']
 with (base/(label+'-f-runner.log')).open('wb') as out:code=subprocess.run(argv,cwd='/workspace/name-validation',stdout=out,stderr=subprocess.STDOUT).returncode
 p=base/('replay-f-'+label)/'result.json';r=json.loads(p.read_text()) if p.exists() else {};runs=r.get('runs',[])
 summary={'label':label,'exit':code,'selected':len(r.get('selected_tests',[])),'runs':len(runs),'pass':sum(x['exit_code']==0 for x in runs),'fail':sum(x['exit_code']!=0 and not x['timed_out'] for x in runs),'timeout':sum(x['timed_out'] for x in runs),'source_drift':r.get('changed_sources'),'binary_unchanged':r.get('binary_unchanged'),'missing':r.get('missing_exact'),'empty_filters':r.get('empty_filters')};print(json.dumps(summary),flush=True);return summary
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 futures=[pool.submit(run,label) for label in plans]
 results=[f.result() for f in futures]
(base/'replay-f-summary.json').write_text(json.dumps(results,indent=2)+'\n')
