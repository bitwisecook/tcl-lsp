from pathlib import Path
import json,subprocess,re,hashlib
root=Path('/workspace/name-validation');base=Path('/workspace/name-session')
build=json.loads((base/'batch-f-build-ordinary/result.json').read_text());assert build['exit_code']==0 and not build['changed_sources'] and not build['errors'] and len(build['test_artifacts'])==14
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==build['started']['commit']
diff=subprocess.check_output(['git','diff','--unified=0','551f3b2c1..HEAD','--','rust','runtime'],cwd=root,text=True)
added=set(re.findall(r'^\+\s*(?:async\s+)?fn\s+(\w+)\s*\(',diff,re.M))
packages={'compiler':'tcl-compiler','core':'tcl-lsp-core','db':'tcl-lsp-db','syntax':'tcl-syntax','source':'xtask','studio':'tcl-spec-studio','spectcl':'tcl-spectcl','registry':'tcl-registry','mcp':'tcl-mcp','server':'tcl-lsp-server','lexer':'tcl-lexer','irules':'tcl-irules'}
summary={}
for label,package in packages.items():
 artifacts=[a for a in build['test_artifacts'] if Path(a['path']).name.startswith(package.replace('-','_')+'-')];assert len(artifacts)==1
 artifact=artifacts[0];assert hashlib.sha256(Path(artifact['path']).read_bytes()).hexdigest()==artifact['sha256']
 listing=subprocess.run([artifact['path'],'--list','--format','terse'],capture_output=True,text=True,check=True)
 (base/(label+'-f-list.txt')).write_text(listing.stdout)
 tests=[n.removesuffix(': test') for n in listing.stdout.splitlines() if n.endswith(': test')];assert tests
 plan=json.loads((base/(label+'-a-plan.json')).read_text())
 additions=[n for n in tests if n.rsplit('::',1)[-1] in added and n not in plan['exact']]
 plan['exact']+=additions;plan['scope']='Frozen8df9a9169 ordinary replay; all551f selected controls and unchanged original budgets retained, plus actually listed added tests; Native/provider/full-codebase acceptance separate.'
 assert len(plan['exact'])==len(set(plan['exact']));assert all(n in tests for n in plan['exact'])
 (base/(label+'-f-plan.json')).write_text(json.dumps(plan,indent=2)+'\n')
 summary[label]={'package':package,'artifact':artifact,'selected':len(plan['exact']),'additions':additions}
(base/'f-replay-plans.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:{'selected':v['selected'],'additions':v['additions']} for k,v in summary.items()},indent=2))
