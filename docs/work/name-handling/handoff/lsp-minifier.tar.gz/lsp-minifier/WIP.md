# Continue minifier variable-reference insertion first

The user explicitly prioritises completing **all naming consumer migrations**.
Continue implementation here first, in parallel with the separate Compiler
Logical variable-source producer and DB source-occupancy work. This packet is
portable continuation evidence and design, **not an implementation or adoption
patch**. No new minifier Rust changes or conformance assertions were written.
Main production work stops for the user's checkpoint; Root owns Main/Git/Cargo
and source freezes. Resume scratch work until Root opens the next source window.

## Current code and concrete remaining consumer

`minify.before.rs.txt` is the exact current production snapshot of
`rust/tcl-lsp-core/src/minify.rs` at Root source238. Verify its SHA256 before
using it; if Main changes, rebase the narrow implementation rather than replacing
Main with this snapshot. The live Logical authoring route is:
`original::minify_with_analysis` -> positive Logical/full-input compatibility gate
-> `lexical_aggressive` -> `alias_string_literals` around2098.

`alias_string_literals` still calls private `extends_dollar_ref` around1207 in
both cost selection2148 and emission2178, then formats `$alias` or `${alias}`.
The heuristic examines one ASCII byte plus '(' and ':'. It does not use the
actual complete configured source-reference owner and handles Jim Unicode
suffixes incorrectly. `lexical_aggressive` already holds the actual
`ResolvedAnalysisInput`; pass that same input through, do not reconstruct it
from dialect labels or current/global Registry. Existing
`reconstruct_variable_reference` around3083 demonstrates the separate adopted
shared scalar-construction/full-following-component check; reuse its owner
principle rather than copying a private parser. Its original-reference rewrite
and this fresh alias insertion remain different purposes.

## Implementation next

1. Thread the actual held input/configuration from `lexical_aggressive` into
   `alias_string_literals`, its candidate/quoted-fragment collector and the new
   insertion proposal. Preserve all positive Logical/whole-config/currentness,
   claimed-name, non-overlap, cost and existing alias/movement admission guards.
   Native remains outside this lexical path; do not enable its transforms.
2. Carry the authentic full following quoted source fragment and its actual
   root/nested lexical configuration for each selected occurrence. Confirm raw
   substring offsets against the current source with checked UTF-8 boundaries.
   Do not use one next byte, one Unicode char, or a lone-colon probe to decide
   whether the complete next literal fragment extends a reference. Legacy
   collector `collect_string_literals` around2194 currently also reparses
   brace/command contents and guesses base+1 offsets. If migrating that collector,
   use genuine shared word/content and selected body-source ownership; never
   declare every braced value executable or manufacture Scope/frame authority.
   Its broader source-role/movement debt must remain explicit if kept separate.
3. Propose with shared `naming::scalar_source_reference(alias, actual_config,
   require_braces)`. Scan candidate joined to the **whole actual following
   fragment** using the shared scanner. Require exact candidate consumption,
   same literal alias name, and no index. Try braced spelling when bare extends.
   An unavailable proposal withdraws that complete alias candidate, without
   partial claimed-name/claimed-byte mutation or fallback source guesses.
4. Preserve original escape/substitution data. Prefer a complete quoted-fragment
   proposal/value roundtrip through the shared word owners: original fragment
   must be static; proposed fragment may resolve only the exact newly inserted
   scalar component (correct span/name, no index) to the separately checked
   literal alias value. `original_word_unicode_value_with_variables` can supply
   that syntax-only hypothetical value comparison. This is **not** a real read,
   binding, frame, alias execution or movement certificate. A preceding escape
   must not turn the proposed `$` into literal data; split escapes/UTF-8 or
   newly activated components must refuse.
5. Keep the existing braced preamble presentation for valid old cases, but let
   the shared complete-word/static Unicode owner verify it reproduces the
   intended raw substring bytes under the actual input grammar. Do not use
   `String::from_utf8_lossy` to turn unrepresentable source bytes into an alias
   label/value. The existing `braces_balanced` counter is not a value parser.
   Do not silently expand the alias/movement authority claimed by this pass.
6. Compute savings using the exact checked replacement length at each occurrence;
   retain those exact proposals for emission so scoring and output cannot
   disagree. Preserve the old exact ASCII result in
   `aggressive_aliases_string_substrings` around4505. Once no callers remain,
   delete `extends_dollar_ref`. `is_word_byte` still has other live constant-fold
   uses around444/467; do not delete it or claim those uses migrated.
7. Add fixed controls only now, after the original observations below. Keep all
   old assertions and actually replay old aggressive/minifier controls plus new
   ones using a fresh ordinary artifact after all TEMP restoration. Obtain an
   independent source/API/purpose peer and source-owner documentation before
   Root adoption. The user asks for migration completion, not another audit-only
   pause; keep moving genuine remaining consumers after this packet.

## Original C5 and pinned Jim evidence BEFORE new assertions

Both captures preserve their actual pre-existing file drivers, probe bytes,
process/stdout/stderr records and all original provider/init hashes. Every
process exited zero; twelve empty stderr files across both captures remain.
`oracles/controlled` is the conformance authority. Its manifest binds the
unchanged `oracles/initial-excluded` manifest by hash.

The initial trial shares scalar state between cases, so its array setup honestly
fails after the earlier scalar `a`. It also evaluates binary-format UTF-8 bytes
without C Tcl conversion, producing the retained mojibake result. These setup
artifacts are preserved and **excluded** as the corrected array/Unicode authority.

Controlled cases unset `a` before each script. Actual original `format %c 233`
constructs the Unicode eval-source suffix from ASCII driver bytes, avoiding the
byte-string/source-channel mistake. All six providers report:

- `${a}::tail` -> ALIAS::tail, while `$a::tail` -> QUALIFIED.
- `${a}x` -> ALIASx, while `$ax` -> OTHER.
- `${a}:tail` and `$a:tail` -> ALIAS:tail.
- `${a}(k)` -> ALIAS(k), while separate `$a(k)` -> ELEMENT.
- `${a}é` -> ALIASé. Bare `$aé` -> ALIASé on C5, but UNICODE on pinned Jim.

Thus a fresh ASCII alias followed by Unicode needs the actual grammar, while a
whole double-colon tail must never be decided by probing only one colon. These
are bounded original source-reference/value observations, not whole minifier
or alias/movement equivalence, F5 behavior, Native binding, physical cell/frame,
edit, compiler or Rust acceptance. Preserve provider failures/refusals rather
than adjusting expected values to obtain green results.

`replay.py --repo /absolute/checkout --out /absolute/fresh-directory` reproduces
only controlled cases using original provider/init hashes and a new output
directory. It never rewrites retained originals. Missing/different original
providers must be reported unavailable; do not substitute system Tcl. The
portable replay was AST-checked only, not executed as another observation.

## Actual status and parallel ownership

Root integrated source229 inline0ac,230 formatter181,231 iRules d070,232 MCP unused
import7e497,234 formatter oracle archivec081 before this checkpoint. All have
independent source/API peers; ordinary validation remains outstanding.
Actual265 Core243=161PASS82FAIL, all258206 retained1gain0priorPASSregression;
MCP43=32PASS11FAIL, old41 retained1gain0priorPASSregression; Server15=12PASS3FAIL.
New d60 and Server no-original-symbol controls PASS. New pool control failed
before generated assertion transport at central object-reference extraction;
d070 now migrates its Written static Unicode consumer, but actual rerun remains.
New typed Core source positives failed upstream; Compiler measured/identified a
strict physical name-currentness boundary and is implementing a **distinct**
Logical source witness, leaving Native `is_current` unchanged. Never restore
String/shared-span/report-label identity fallbacks to make these tests pass.

TEMP270 is in flight at checkpoint. Root must restore every declared path and
the whole source closure exactly, then build fresh ordinary271 artifacts before
acceptance. No TEMP output is ordinary acceptance. Preserve all actual265 tests
and old failure observations. Core247 and iRules19 plans plus formatter88 and
integration55/15 annexes are separately sealed; Root/Tracking own their final
current-source peers and parent/text Syntax additions. Existing MCP43, Server15,
Lexer11 and all other actual265 scopes stay required.

Root is producing the complete push/status/continuation prompt. Read the current
coordination snapshot and portable Compiler/DB handoffs alongside this packet;
this minifier task does not close their producer/coverage/census obligations.
