// tcl-lsp — a language server and toolchain for Tcl
// Copyright (C) 2026 James Deucker (bitwisecook) <https://github.com/bitwisecook>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.
//
// SPDX-License-Identifier: AGPL-3.0-or-later

//! Class Hierarchy Analysis (`CHA`) for `TclOO`.
//!
//! Builds a complete class hierarchy from the analyser's class
//! index, computes the MRO (two-pass DFS with late-placement
//! deduplication, see [`super::mro::tcloo_linearise`]) for each
//! class, and answers queries about subtype relationships,
//! method providers, and method resolution.
//!
//! Inspired by the CHA techniques used in LLVM and JVM `HotSpot`
//! for devirtualisation and call graph construction.

/// Original byte-joined relation order for source declaration assistance.
pub mod original_metadata;

use std::collections::{HashMap, HashSet};

use super::mro::{build_mro_map, tcloo_linearise};
use super::types::{ClassDef, MethodDef};

/// The name a `constructor` body carries wherever a member is identified by
/// name — `ClassDef::constructors`' own `MethodDef::name`, the tail of the
/// `Method` scope `walk_method_body` opens for it, and the label C Tcl's
/// `info object call` / `self method` report for that frame (tclsh 9.0.4).
pub const CONSTRUCTOR_MEMBER: &str = "<constructor>";

/// [`CONSTRUCTOR_MEMBER`]'s twin for a `destructor` body.
pub const DESTRUCTOR_MEMBER: &str = "<destructor>";

/// The member of `class_def` named `member`, treating the two nameless
/// slots by their synthetic labels ([`CONSTRUCTOR_MEMBER`] /
/// [`DESTRUCTOR_MEMBER`]) and an ordinary name as an instance method,
/// then a class-side one.
///
/// The lookup every `next`-resolution consumer needs once
/// [`ClassHierarchy::member_next_provider`] has named the providing class:
/// keeping it here means a constructor's `MethodDef` is fetched the same
/// way in go-to-definition, find-references, and the arity check. The
/// *effective* constructor is the last declared one, the
/// same "most recent declaration wins" rule
/// [`ClassHierarchy::constructor_provider`] applies.
#[must_use]
pub fn class_member_def<'a>(class_def: &'a ClassDef, member: &str) -> Option<&'a MethodDef> {
    match member {
        CONSTRUCTOR_MEMBER => class_def.constructors.last(),
        DESTRUCTOR_MEMBER => class_def.destructor.as_ref(),
        _ => class_def
            .methods
            .get(member)
            .or_else(|| class_def.class_methods.get(member)),
    }
}

/// Immutable snapshot of the complete class hierarchy.
///
/// Built once via [`build_class_hierarchy`] and queried via
/// [`Self::is_subtype`] / [`Self::method_target`] /
/// [`Self::all_implementations`].
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct ClassHierarchy {
    /// All known classes, keyed by qualified name.
    pub classes: HashMap<String, ClassDef>,
    /// Class → linearised MRO (including self).
    pub mro_map: HashMap<String, Vec<String>>,
    /// Original relation lookups behind unresolved hierarchy rows.
    /// Conflicting rows retain no lookup; report text never restores one.
    original_unresolved_relations:
        HashMap<String, Option<crate::signature_scan::scope::SignatureSourceLookup>>,
    /// Class → its owner-resolved **direct** `mixin` edges, in declaration
    /// order — the same resolution [`Self::mro_map`] linearises through, kept
    /// so a consumer can tell which *branch* of the call chain a provider was
    /// reached on without re-resolving the names itself.
    ///
    /// C walks each mixin branch with a fresh copy of the dispatch flags, so
    /// the branch a provider sits on is what decides its export state (see
    /// [`Self::spine_map`]).
    pub mixin_map: HashMap<String, Vec<String>>,
    /// Class → its **mixin-free** linearisation (including self) — the
    /// `superclass` spine alone, in the order `TclOO`'s call-chain builder
    /// walks it.
    ///
    /// Separate from [`Self::mro_map`] because C's
    /// `AddSimpleClassChainToCallContext` treats the two paths differently:
    /// each mixin is entered with a *fresh copy* of the dispatch flags, so a
    /// mixin that unexports a name empties only its own branch, whereas the
    /// same word on the spine decides the whole dispatch.  Oracle,
    /// byte-identical on tclsh 8.6.16 and 9.0.4:
    ///
    /// ```tcl
    /// oo::class create A   { method m {} { return A-m } }
    /// oo::class create Mix { method m {} { return Mix-m } }
    /// oo::define Mix { unexport m }
    /// oo::class create D { superclass A ; mixin Mix }
    /// [D new] m          ;# -> A-m  (the mixin's unexport did not suppress A's m)
    /// oo::class create B { superclass A }
    /// oo::define B { unexport m }
    /// [B new] m          ;# -> unknown method "m"  (the spine's unexport did)
    /// ```
    ///
    /// Built by the same linearisation owner as `mro_map`, over the same
    /// resolved superclass edges, so the two orders can never disagree about
    /// which qualified name a bare `superclass Device` meant.
    pub spine_map: HashMap<String, Vec<String>>,
    /// Class → direct subclasses.
    pub subclasses: HashMap<String, HashSet<String>>,
    /// Class → all descendants (transitive closure).
    pub transitive_subtypes: HashMap<String, HashSet<String>>,
    /// `(class, method_name)` → qualified name of the class
    /// that provides the method in the MRO chain.  Used for
    /// ``next`` / ``nextto`` resolution and devirtualisation.
    pub method_providers: HashMap<(String, String), String>,
    /// Hierarchy errors (cycles, inconsistent linearisation).
    pub errors: Vec<String>,
}

impl ClassHierarchy {
    pub(super) fn original_unresolved_relation(
        &self,
        row: &str,
    ) -> Option<&crate::signature_scan::scope::SignatureSourceLookup> {
        self.original_unresolved_relations.get(row)?.as_ref()
    }

    /// Return `true` when `child` is a subtype of `parent`
    /// (transitively, via the linearised MRO).
    #[must_use]
    pub fn is_subtype(&self, child: &str, parent: &str) -> bool {
        self.mro_map
            .get(child)
            .is_some_and(|mro| mro.iter().any(|c| c == parent))
    }

    /// Exact reported declaration on one member side, without inherited
    /// lookup. Lexical compatibility consumers must independently select that
    /// advice mode; this query supplies no original or runtime member identity.
    #[must_use]
    pub fn declared_member(
        &self,
        class: &str,
        name: &str,
        side: super::types::MemberSide,
    ) -> Option<(&ClassDef, &MethodDef)> {
        let class = self.classes.get(class)?;
        let method = match side {
            super::types::MemberSide::Instance => class.methods.get(name),
            super::types::MemberSide::ClassObject => class.class_methods.get(name),
        }?;
        Some((class, method))
    }

    /// Resolve which class provides `method_name` for
    /// `class_name`, walking the MRO chain.  Returns the
    /// qualified name of the providing class, or `None` if no
    /// class on the chain implements the method.
    #[must_use]
    pub fn method_target(&self, class_name: &str, method_name: &str) -> Option<&str> {
        self.method_providers
            .get(&(class_name.to_string(), method_name.to_string()))
            .map(String::as_str)
    }

    /// Resolve which class provides an *explicit* constructor for
    /// `class_name`, walking the MRO chain — mirrors [`Self::method_target`],
    /// but for `TclOO`'s single per-class constructor slot
    /// (`ClassDef::constructors`) rather than a named method.
    ///
    /// Returns `None` when no class on the chain declares an *effective*
    /// one: `TclOO` falls back to a permissive default constructor
    /// (inherited from `oo::object`) that accepts and ignores any number
    /// of arguments both when no `constructor` was ever written
    /// (confirmed against tclsh 9.0.4: `oo::class create Foo {}` then `Foo
    /// new 1 2 3` succeeds) **and** when the effective (most recent)
    /// `constructor` declaration has a literally empty body — `TclOO`
    /// treats `constructor {a b} {}` as if no constructor were declared at
    /// all (confirmed against tclsh 9.0.4: `info class constructor Foo`
    /// returns empty, and `Foo new`/`Foo new 1 2 3` both succeed for that
    /// class; a body with any content at all — even a single space or a
    /// comment — *is* a real, arity-enforcing constructor). `source` is the
    /// full document text `body_span` indexes into (see
    /// [`is_empty_method_body`]) — this hierarchy holds no source text of
    /// its own. Callers must treat `None` as "any argument count is
    /// valid", not "the constructor takes no arguments".
    #[must_use]
    pub fn constructor_provider(&self, class_name: &str, source: &str) -> Option<&str> {
        let mro = self.mro_map.get(class_name)?;
        mro.iter().find_map(|ancestor| {
            self.classes
                .get(ancestor)
                .filter(|cd| {
                    cd.constructors
                        .last()
                        .is_some_and(|c| !is_empty_method_body(source, c.body_span))
                })
                .map(|_| ancestor.as_str())
        })
    }

    /// Resolve `TclOO` `next` / `nextto`: the class *after* the current
    /// provider in `class`'s MRO that provides `method`.
    ///
    /// For plain `next`, pass the class currently servicing the method as
    /// `current` and `start_from = None`; the search begins one past
    /// `current`.  For `nextto SomeClass`, pass `start_from =
    /// Some("::SomeClass")`; the search begins *at* that class.  Returns the
    /// qualified name of the next providing class, or `None` when the chain
    /// is exhausted (a `next` past the last provider — a runtime error in
    /// Tcl — surfaces here as "no next").
    #[must_use]
    pub fn next_provider(
        &self,
        class: &str,
        method: &str,
        current: &str,
        start_from: Option<&str>,
    ) -> Option<&str> {
        let mro = self.mro_map.get(class)?;
        let anchor = start_from.unwrap_or(current);
        let anchor_pos = mro.iter().position(|c| c == anchor)?;
        let scan_from = if start_from.is_some() {
            anchor_pos
        } else {
            anchor_pos + 1
        };
        mro.iter().skip(scan_from).find_map(|c| {
            self.classes
                .get(c)
                .filter(|cd| {
                    cd.methods.contains_key(method) || cd.class_methods.contains_key(method)
                })
                .map(|_| c.as_str())
        })
    }

    /// Resolve `TclOO` `next` / `nextto` from *within* `class`'s own
    /// constructor: the class after `class` in its MRO that provides an
    /// *effective* constructor (mirrors [`Self::next_provider`], but for the
    /// unnamed constructor slot rather than a named method — "effective"
    /// carries the same empty-body caveat as [`Self::constructor_provider`],
    /// whose doc explains it).
    ///
    /// For plain `next`, pass `start_from = None`; the search begins one
    /// past `class` itself. For `nextto SomeClass`, pass `start_from =
    /// Some("::SomeClass")`; the search begins *at* that class. `source` is
    /// the document text `body_span`s index into. Returns `None` when the
    /// chain is exhausted or `class` is unknown.
    #[must_use]
    pub fn constructor_next_provider(
        &self,
        class: &str,
        start_from: Option<&str>,
        source: &str,
    ) -> Option<&str> {
        let mro = self.mro_map.get(class)?;
        let anchor = start_from.unwrap_or(class);
        let anchor_pos = mro.iter().position(|c| c == anchor)?;
        let scan_from = if start_from.is_some() {
            anchor_pos
        } else {
            anchor_pos + 1
        };
        mro.iter().skip(scan_from).find_map(|c| {
            self.classes
                .get(c)
                .filter(|cd| {
                    cd.constructors
                        .last()
                        .is_some_and(|ctor| !is_empty_method_body(source, ctor.body_span))
                })
                .map(|_| c.as_str())
        })
    }

    /// Resolve `TclOO` `next` / `nextto` from *within* `class`'s own
    /// destructor: the class after `class` in its MRO that declares a
    /// destructor.
    ///
    /// Unlike [`Self::constructor_next_provider`], a destructor's
    /// "effective" test is plain existence (`ClassDef::destructor.is_some()`)
    /// — `TclOO`'s empty-body-elides-the-constructor quirk is verified
    /// (against tclsh 9.0.4) for constructors specifically; no equivalent
    /// claim has been checked for destructors, so an explicitly empty
    /// destructor body is conservatively still treated as a real override
    /// here rather than assumed to share the constructor's special case.
    ///
    /// Same `start_from` convention as [`Self::constructor_next_provider`].
    /// Returns `None` when the chain is exhausted or `class` is unknown.
    #[must_use]
    pub fn destructor_next_provider(&self, class: &str, start_from: Option<&str>) -> Option<&str> {
        let mro = self.mro_map.get(class)?;
        let anchor = start_from.unwrap_or(class);
        let anchor_pos = mro.iter().position(|c| c == anchor)?;
        let scan_from = if start_from.is_some() {
            anchor_pos
        } else {
            anchor_pos + 1
        };
        mro.iter().skip(scan_from).find_map(|c| {
            self.classes
                .get(c)
                .filter(|cd| cd.destructor.is_some())
                .map(|_| c.as_str())
        })
    }

    /// Resolve `TclOO` `next` / `nextto` from inside **any** member body,
    /// routing the two nameless slots to their own providers.
    ///
    /// `member` is the enclosing member as the analyser names it — a
    /// method's own name, or the synthetic [`CONSTRUCTOR_MEMBER`] /
    /// [`DESTRUCTOR_MEMBER`] label a nameless body carries (the same
    /// `<constructor>` / `<destructor>` spelling C Tcl's own `info object
    /// call` reports, and the one `walk_method_body` builds a constructor
    /// scope's name from).
    ///
    /// The single entry point for `next` resolution, so go-to-definition,
    /// find-references, and the `next`-arity check cannot disagree about
    /// which slot a `next` chains through. [`Self::next_provider`]'s
    /// per-ancestor filter consults only `methods`/`class_methods`, so going
    /// straight there leaves a `next` inside a `constructor` — the ordinary way
    /// a subclass forwards to its superclass's constructor — resolving to
    /// nothing at all and its arity unchecked, while the identical `next`
    /// inside a plain `method` resolves (a real `next` there does dispatch,
    /// pinned against tclsh 9.0.4).
    ///
    /// `source` is the document text `body_span`s index into, needed only
    /// for the constructor slot's empty-body rule — see
    /// [`Self::constructor_provider`].
    #[must_use]
    pub fn member_next_provider(
        &self,
        class: &str,
        member: &str,
        current: &str,
        start_from: Option<&str>,
        source: &str,
    ) -> Option<&str> {
        match member {
            CONSTRUCTOR_MEMBER => self.constructor_next_provider(class, start_from, source),
            DESTRUCTOR_MEMBER => self.destructor_next_provider(class, start_from),
            _ => self.next_provider(class, member, current, start_from),
        }
    }

    /// Return all `(class, defining_class)` pairs that
    /// implement `method_name`.  Order matches the iteration
    /// order of `method_providers` (`HashMap` — non-deterministic
    /// across runs; sort externally if determinism matters).
    #[must_use]
    pub fn all_implementations(&self, method_name: &str) -> Vec<(String, String)> {
        self.method_providers
            .iter()
            .filter(|((_cls, meth), _provider)| meth == method_name)
            .map(|((cls, _meth), provider)| (cls.clone(), provider.clone()))
            .collect()
    }

    /// The linearised MRO of `class_name` (self first), or a single-element
    /// `[class_name]` when the hierarchy has no entry for it — an external or
    /// otherwise unindexed class is still itself.
    #[must_use]
    pub fn mro_or_self(&self, class_name: &str) -> Vec<String> {
        self.mro_map
            .get(class_name)
            .cloned()
            .unwrap_or_else(|| vec![class_name.to_string()])
    }

    /// Whether any known **strict descendant** of `class_name` resolves
    /// `method` — the template-method abstention for `my` dispatch.
    ///
    /// An abstract base whose method bodies call `my M`, with `M` written
    /// only by concrete subclasses, runs fine: `my` late-binds on the
    /// actual receiver, which is always a subclass instance (the base is
    /// never instantiated), and bypasses export filtering, so even an
    /// unexported (capitalised) subclass method is reachable.  A known
    /// subclass that defines `M` is direct evidence the call is that
    /// pattern and not a typo — with **no** defining subclass anywhere in
    /// the index, W308 still fires, which is what keeps this from
    /// swallowing the check on self-dispatch entirely.
    ///
    /// Descendants are found through [`Self::mro_map`] (any class whose
    /// MRO contains `class_name`), and `method` resolves through
    /// [`Self::method_target`] on the descendant, so a template method the
    /// subclass itself inherits from a mixin still counts.
    #[must_use]
    pub fn subclass_provides_method(&self, class_name: &str, method: &str) -> bool {
        self.mro_map.iter().any(|(cls, mro)| {
            cls != class_name
                && mro.iter().any(|ancestor| ancestor == class_name)
                && self.method_target(cls, method).is_some()
        })
    }

    /// Every instance method some class on `class_name`'s MRO **generates**
    /// from its declared `property` members — `oo::configurable`'s
    /// `configure` (Tcl 9.0+).
    ///
    /// Registry data throughout: the names come from the manufacturing
    /// metaclass's
    /// [`property_accessor_methods`](tcl_registry::definer::DefinitionBodyGrammar::property_accessor_methods),
    /// so no consumer spells `configure` and none can invent a generated
    /// method the class system does not have. `cget` is not one of them:
    /// `configurable.n` documents no `cget` in either 9.0 or 9.1, and
    /// dispatching one really does fail.
    ///
    /// The whole MRO is asked, not just the receiver's own class, because the
    /// generated method is a real method on the configurable ancestor and a
    /// subclass inherits it.  A class that declares `property` members but
    /// whose metaclass resolves to no grammar — a user metaclass derived from
    /// `oo::configurable` — falls back to the dialect-wide
    /// [`CommandRegistry::property_accessor_methods`](tcl_registry::CommandRegistry::property_accessor_methods),
    /// so such a class is not told its accessor is missing.
    ///
    /// Empty when nothing on the MRO is configurable, and for a registry the
    /// caller does not have.
    #[must_use]
    pub fn property_accessor_methods(
        &self,
        registry: Option<&tcl_registry::CommandRegistry>,
        class_name: &str,
    ) -> Vec<&'static str> {
        let Some(registry) = registry else {
            return Vec::new();
        };
        let mut out: Vec<&'static str> = Vec::new();
        let mut declares_properties = false;
        for ancestor in self.mro_or_self(class_name) {
            let Some(cd) = self.classes.get(&ancestor) else {
                continue;
            };
            declares_properties |= !cd.properties.is_empty();
            if let Some(grammar) = registry.get(&cd.metaclass).and_then(|s| s.definition_body) {
                out.extend(grammar.property_accessor_methods.iter().copied());
            }
        }
        if out.is_empty() && declares_properties {
            out = registry.property_accessor_methods();
        }
        out.sort_unstable();
        out.dedup();
        out
    }

    /// Whether `method` is one the class system generates for `class_name`'s
    /// properties — see [`Self::property_accessor_methods`].
    #[must_use]
    pub fn is_property_accessor(
        &self,
        registry: Option<&tcl_registry::CommandRegistry>,
        class_name: &str,
        method: &str,
    ) -> bool {
        self.property_accessor_methods(registry, class_name)
            .contains(&method)
    }

    /// Every method name callable on `class_name` — instance and class
    /// methods declared anywhere on its linearised MRO, plus whatever its
    /// class system generates from declared properties — sorted and
    /// deduplicated.  Feeds the W308 "did you mean…?" suggestion list; empty
    /// for an unknown class.
    ///
    /// The generated-method fold and the W308 *existence* check
    /// (`Analyser::validate_method_on_class`) both go through
    /// [`Self::property_accessor_methods`] precisely so they cannot disagree:
    /// were only this side to fold them in, `$obj configure` on a configurable
    /// class would draw "Unknown method 'configure' … did you mean
    /// 'configure'?".
    #[must_use]
    pub fn known_methods(
        &self,
        registry: Option<&tcl_registry::CommandRegistry>,
        class_name: &str,
    ) -> Vec<String> {
        let mut out: std::collections::BTreeSet<String> = std::collections::BTreeSet::new();
        if let Some(mro) = self.mro_map.get(class_name) {
            for ancestor in mro {
                if let Some(cd) = self.classes.get(ancestor) {
                    out.extend(cd.methods.keys().cloned());
                    out.extend(cd.class_methods.keys().cloned());
                }
            }
        }
        out.extend(
            self.property_accessor_methods(registry, class_name)
                .into_iter()
                .map(str::to_owned),
        );
        out.into_iter().collect()
    }
}

/// Whether a `TclOO` method/constructor body span is *effectively* empty —
/// `{}` / `[]` / `""` with **nothing at all** between the delimiters.
/// `TclOO` treats exactly this shape as "no constructor was written" (see
/// [`ClassHierarchy::constructor_provider`]'s doc comment); any body
/// content at all, even a single space or a comment, keeps it real
/// (confirmed against tclsh 9.0.4).
///
/// `body_span` follows this project's general delimited-word convention
/// (`docs/design/contracts/lexing.md`): for
/// non-empty content the span covers the opening delimiter through the
/// *last inner character*, excluding the closer (e.g. `{ }`'s span slices
/// to `"{ "`, two bytes); for genuinely empty content the span instead
/// extends one further to sit *on* the closer (`{}`'s span slices to the
/// full `"{}"`, also two bytes, but ending on `}` rather than before it).
/// So an empty body is exactly the two-byte slice `"{}"` / `"[]"` /
/// `"\"\""` — no non-empty content is ever pair-shaped like that (a
/// single-inner-character body such as `{x}` slices to `"{x"`, not `"{}"`)
/// — a cheap, unambiguous string-equality test rather than re-parsing.
pub(in crate::analyser) fn is_empty_method_body(source: &str, body_span: tcl_lexer::Span) -> bool {
    let start = body_span.start() as usize;
    let end = body_span.end() as usize;
    matches!(source.get(start..end), Some("{}" | "[]" | "\"\""))
}

/// Resolve a possibly-bare superclass / mixin name written in the body of
/// class `owner` to a qualified name keyed in `classes`.
///
/// A superclass declared bare (`superclass Device`) is resolved the way
/// Tcl would resolve the command: in the **defining class's namespace**,
/// then walking outward to the global namespace, and finally — when the
/// simple name is *globally unique* — to that single class (covering the
/// common `namespace import` idiom without needing per-file import data).
/// An ambiguous simple name (several classes share the tail) stays bare,
/// so no wrong link is ever manufactured.  This is what links cross-file
/// inheritance where a subclass in one file names a base class defined,
/// under a namespace, in another (the `SpiceGenTcl` `superclass Device`
/// shape), which would otherwise stay unlinked, silently dropping the
/// inherited methods.
fn resolve_super_name(
    name: &str,
    owner_qname: &str,
    classes: &HashMap<String, ClassDef>,
    tail_index: &HashMap<String, Vec<String>>,
) -> String {
    // The MRO builder wants a name back even when nothing resolves (it leaves
    // the edge unlinked rather than dropping the class), so fall back to the
    // written name; the resolution logic itself lives in `resolve_class_name`.
    resolve_class_name(name, owner_qname, |q| classes.contains_key(q), tail_index)
        .unwrap_or_else(|| name.to_string())
}

/// Compatibility assistance for explicitly constructed class graph keys.
/// Source declarations require original caller lookup receipts instead. This
/// adapter supplies no native class, provider, import or execution authority.
pub fn resolve_class_name<S: std::hash::BuildHasher>(
    name: &str,
    owner_qname: &str,
    is_known: impl Fn(&str) -> bool,
    tail_index: &HashMap<String, Vec<String>, S>,
) -> Option<String> {
    if is_known(name) {
        return Some(name.to_string());
    }
    // C Tcl resolves a bare `superclass`/`mixin` name relative to the enclosing
    // (`oo::define` call-site) namespace in exactly two scopes — the current
    // namespace, then global — with NO walk through intermediate ancestors.
    // Verified against the VM's `cmd_oo::resolve_class` and C's
    // `GetClassInOuterContext` (`tclOODefineCmds.c`).  An ancestor walk
    // manufactures a wrong inheritance edge (e.g. a bare `superclass Base` in
    // `::a::b::Sub` linked to `::a::Base` even though real Tcl errors — `Base`
    // is reachable from neither `::a::b` nor global).  Uses the shared command
    // -resolution candidate order so class-name resolution can never diverge
    // from it (a class name *is* a command name).
    let (owner_ns, _) = crate::naming::key_holder_and_tail(owner_qname);
    for cand in crate::naming::bareword_resolution_candidates(owner_ns, name) {
        if is_known(&cand) {
            return Some(cand);
        }
    }
    // Constructed graph compatibility has no source import/context receipt.
    let _ = tail_index;
    None
}

/// Positively retained Logical reporting lookup in the actual lexical
/// namespace. This shares command candidate ordering, without joining Native
/// source-name records, guessing a unique tail or issuing a class identity.
#[must_use]
pub fn resolve_retained_logical_class_name(
    analysis: &super::types::AnalysisResult,
    name: &str,
    namespace: &str,
) -> Option<String> {
    analysis
        .allows_retained_logical_declaration_advice()
        .then_some(())?;
    crate::naming::bareword_resolution_candidates(namespace, name)
        .into_iter()
        .find(|candidate| analysis.all_classes.contains_key(candidate))
}

/// Resolve original source naming against retained class publication slots.
/// Missing, colliding or foreign-policy records do not establish class identity.
#[must_use]
pub fn resolve_class_lookup<S: std::hash::BuildHasher>(
    lookup: &crate::signature_scan::scope::SignatureSourceLookup,
    classes: &HashMap<String, ClassDef, S>,
) -> Option<String> {
    for candidate in lookup.candidates()? {
        if classes.values().any(|class| {
            class.source_name_ambiguous.is_observed()
                && class.source_name.as_ref().is_some_and(|source| {
                    source.policy() == lookup.policy() && source.slot() == &candidate
                })
        }) {
            return None;
        }
        let mut matches = classes.iter().filter(|(_, class)| {
            !class.source_name_ambiguous.is_observed()
                && class.source_name.as_ref().is_some_and(|source| {
                    source.policy() == lookup.policy() && source.slot() == &candidate
                })
        });
        if let Some((key, _)) = matches.next() {
            return matches.next().is_none().then(|| key.clone());
        }
    }
    None
}

/// Source lookup in an independently supplied original caller context.
#[must_use]
pub fn resolve_written_class_name_in_context<S: std::hash::BuildHasher>(
    name: &str,
    namespace: &crate::signature_scan::scope::SignatureNamespaceScope,
    policy: tcl_syntax::naming::NamePolicyProtocol,
    classes: &HashMap<String, ClassDef, S>,
) -> Option<String> {
    let lookup = crate::signature_scan::scope::SignatureSourceLookup::new(
        policy,
        namespace.clone(),
        name.to_owned(),
    )?;
    resolve_class_lookup(&lookup, classes)
}

/// Source query in a retained scope, without guessing a missing object frame.
#[must_use]
pub fn resolve_written_class_name_in_scope<S: std::hash::BuildHasher>(
    name: &str,
    namespace: &crate::signature_scan::scope::SignatureNamespaceScope,
    classes: &HashMap<String, ClassDef, S>,
) -> Option<String> {
    let policies: HashSet<_> = classes
        .values()
        .filter_map(|class| {
            class
                .source_name
                .as_ref()
                .map(crate::signature_scan::scope::SignatureSourceCommand::policy)
        })
        .collect();
    let mut selected = None;
    for policy in policies {
        if let Some(key) = resolve_written_class_name_in_context(name, namespace, policy, classes) {
            if selected.as_ref().is_some_and(|previous| previous != &key) {
                return None;
            }
            selected = Some(key);
        }
    }
    selected
}

/// Exact innermost source scope containing a written query position.
#[must_use]
pub fn source_namespace_at(
    scope: &super::types::Scope,
    offset: u32,
) -> Option<&crate::signature_scan::scope::SignatureNamespaceScope> {
    let mut children = scope.children.iter().filter(|child| {
        child
            .body_span
            .is_some_and(|span| span.start() <= offset && offset < span.end())
    });
    if let Some(child) = children.next() {
        if children.next().is_some() {
            return None;
        }
        return source_namespace_at(child, offset);
    }
    scope.naming_scope.as_ref()
}

/// Unpositioned root lookup using retained declaration policies only.
/// A missing original caller context cannot borrow a globally unique tail.
#[must_use]
pub fn resolve_written_class_name<S: std::hash::BuildHasher>(
    name: &str,
    classes: &HashMap<String, ClassDef, S>,
) -> Option<String> {
    let policies: HashSet<_> = classes
        .values()
        .filter_map(|class| {
            class
                .source_name
                .as_ref()
                .map(crate::signature_scan::scope::SignatureSourceCommand::policy)
        })
        .collect();
    let mut selected = None;
    for policy in policies {
        if let Some(key) = resolve_written_class_name_in_context(
            name,
            &crate::signature_scan::scope::SignatureNamespaceScope::root(Some(policy)),
            policy,
            classes,
        ) {
            if selected.as_ref().is_some_and(|previous| previous != &key) {
                return None;
            }
            selected = Some(key);
        }
    }
    selected
}

/// Presentation-only simple-name index; it grants no class lookup authority.
pub fn build_tail_index<'a>(
    qnames: impl Iterator<Item = &'a String>,
) -> HashMap<String, Vec<String>> {
    let mut tail_index: HashMap<String, Vec<String>> = HashMap::new();
    for qname in qnames {
        // `qname` is a constructed key — construction-inverse tail.
        let tail = crate::naming::key_tail(qname);
        tail_index
            .entry(tail.to_string())
            .or_default()
            .push(qname.clone());
    }
    tail_index
}

fn unresolved_class_relation_row(class: &str, written: &str) -> String {
    format!("@unresolvedclass@{class} {written}")
}

/// Build the supers/mixins maps used by the MRO algorithm.
fn build_supers_mixins_maps(
    classes: &HashMap<String, ClassDef>,
) -> (HashMap<String, Vec<String>>, HashMap<String, Vec<String>>) {
    let mut supers_map: HashMap<String, Vec<String>> = HashMap::new();
    let mut mixins_map: HashMap<String, Vec<String>> = HashMap::new();
    for (qname, class) in classes {
        let normalise = |names: &[String]| -> Vec<String> {
            names
                .iter()
                .map(|written| match class.relation_lookups.get(written) {
                    Some(Some(lookup)) => resolve_class_lookup(lookup, classes)
                        .unwrap_or_else(|| unresolved_class_relation_row(qname, written)),
                    None if class.source_name.is_none() => {
                        resolve_super_name(written, qname, classes, &HashMap::new())
                    }
                    Some(None) | None => unresolved_class_relation_row(qname, written),
                })
                .collect()
        };
        supers_map.insert(qname.clone(), normalise(&class.superclasses));
        if !class.mixins.is_empty() {
            mixins_map.insert(qname.clone(), normalise(&class.mixins));
        }
    }
    (supers_map, mixins_map)
}

/// Whether the combined, already-normalised superclass/mixin graph reachable
/// from `start` revisits a node on its active path. The shared MRO primitive
/// deliberately cuts off mixin revisits, but an analysis hierarchy records
/// every relation cycle as an error so downstream proofs never mistake that
/// truncated order for a complete method chain.
fn has_relation_cycle(
    start: &str,
    supers_map: &HashMap<String, Vec<String>>,
    mixins_map: &HashMap<String, Vec<String>>,
) -> bool {
    fn visit(
        class_name: &str,
        supers_map: &HashMap<String, Vec<String>>,
        mixins_map: &HashMap<String, Vec<String>>,
        active: &mut HashSet<String>,
        complete: &mut HashSet<String>,
    ) -> bool {
        if active.contains(class_name) {
            return true;
        }
        if complete.contains(class_name) {
            return false;
        }
        active.insert(class_name.to_owned());
        let relations = supers_map
            .get(class_name)
            .into_iter()
            .flatten()
            .chain(mixins_map.get(class_name).into_iter().flatten());
        for relation in relations {
            if visit(relation, supers_map, mixins_map, active, complete) {
                return true;
            }
        }
        active.remove(class_name);
        complete.insert(class_name.to_owned());
        false
    }

    visit(
        start,
        supers_map,
        mixins_map,
        &mut HashSet::new(),
        &mut HashSet::new(),
    )
}

/// Build the method-provider map: `(class, method) -> first ancestor
/// in MRO order that provides the method`.
fn build_method_providers(
    classes: &HashMap<String, ClassDef>,
    mro_map: &HashMap<String, Vec<String>>,
) -> HashMap<(String, String), String> {
    let mut method_providers: HashMap<(String, String), String> = HashMap::new();
    for (qname, cd) in classes {
        let mro = mro_map
            .get(qname)
            .cloned()
            .unwrap_or_else(|| vec![qname.clone()]);
        let mut all_methods: HashSet<String> = HashSet::new();
        for n in cd.methods.keys() {
            all_methods.insert(n.clone());
        }
        for n in cd.class_methods.keys() {
            all_methods.insert(n.clone());
        }
        for ancestor_name in &mro {
            if let Some(ancestor) = classes.get(ancestor_name) {
                for n in ancestor.methods.keys() {
                    all_methods.insert(n.clone());
                }
                for n in ancestor.class_methods.keys() {
                    all_methods.insert(n.clone());
                }
            }
        }
        for method_name in all_methods {
            for ancestor_name in &mro {
                if let Some(ancestor) = classes.get(ancestor_name)
                    && (ancestor.methods.contains_key(&method_name)
                        || ancestor.class_methods.contains_key(&method_name))
                {
                    method_providers
                        .insert((qname.clone(), method_name.clone()), ancestor_name.clone());
                    break;
                }
            }
        }
    }
    method_providers
}

/// Build the [`ClassHierarchy`] from a flat class-def index.  Runs
/// MRO linearisation, computes direct + transitive subclass sets, and
/// resolves method-provider chains.
#[must_use]
pub fn build_class_hierarchy<S: std::hash::BuildHasher>(
    classes: HashMap<String, ClassDef, S>,
) -> ClassHierarchy {
    // Normalise to the default-hasher map used by `ClassHierarchy::classes`
    // so the rest of the routine (and the public field) stay hasher-agnostic.
    let classes: HashMap<String, ClassDef> = classes.into_iter().collect();
    let (supers_map, mixins_map) = build_supers_mixins_maps(&classes);
    let mut original_unresolved_relations = HashMap::new();
    for (qname, class) in &classes {
        for written in class.superclasses.iter().chain(&class.mixins) {
            let Some(Some(lookup)) = class.relation_lookups.get(written) else {
                continue;
            };
            if resolve_class_lookup(lookup, &classes).is_some() {
                continue;
            }
            let row = unresolved_class_relation_row(qname, written);
            let captured = original_unresolved_relations
                .entry(row)
                .or_insert_with(|| Some(lookup.clone()));
            if captured.as_ref().is_some_and(|previous| previous != lookup) {
                *captured = None;
            }
        }
    }

    // Compute MRO for every class.  ``build_mro_map`` walks
    // ``supers_map.keys()`` only; classes that appear as parents
    // but aren't in the index get a single-element MRO when
    // queried via ``tcloo_linearise`` directly — for our
    // ``classes``-only walk that's fine.
    let (mro_map_raw, errors_pass1) = build_mro_map(&supers_map, &mixins_map);

    // Backfill: classes whose MRO landed in errors get a
    // single-element chain (themselves only) so downstream
    // lookups don't return ``None``.
    let mut mro_map: HashMap<String, Vec<String>> = mro_map_raw;
    let mut errors = errors_pass1;
    for qname in classes.keys() {
        if has_relation_cycle(qname, &supers_map, &mixins_map) {
            let error = format!("cycle detected in class relation hierarchy for {qname}");
            if !errors.contains(&error) {
                errors.push(error);
            }
        }
    }
    for qname in classes.keys() {
        if !mro_map.contains_key(qname) {
            mro_map.insert(qname.clone(), vec![qname.clone()]);
        }
    }
    // Also include single-pass-fail classes: re-run linearise
    // for any class missing a successful MRO entry above; this
    // catches the case where ``build_mro_map`` short-circuited
    // the iteration on a cycle and never visited some classes.
    for qname in classes.keys() {
        if mro_map[qname] == vec![qname.clone()] && !classes[qname].superclasses.is_empty() {
            // Try a fresh linearise; if it still errors, leave
            // the single-element MRO and record the error.
            match tcloo_linearise(qname, &supers_map, &mixins_map) {
                Ok(mro) => {
                    mro_map.insert(qname.clone(), mro);
                }
                Err(e) => {
                    if !errors.iter().any(|s| s == &e.message) {
                        errors.push(e.message);
                    }
                }
            }
        }
    }

    // The mixin-free spine, from the same resolved `supers_map` and the same
    // linearisation owner — only the mixin edges are withheld.  Backfilled
    // identically, so every indexed class has an entry.
    let no_mixins: HashMap<String, Vec<String>> = HashMap::new();
    let (mut spine_map, _spine_errors) = build_mro_map(&supers_map, &no_mixins);
    for qname in classes.keys() {
        if !spine_map.contains_key(qname) {
            spine_map.insert(qname.clone(), vec![qname.clone()]);
        }
    }

    // Build direct-subclass map.  Initialise with empty sets
    // for every class so callers see a non-None entry even when
    // a class has no subclasses.
    //
    // A class is a subtype of both its superclasses **and** its mixins — the
    // MRO (and thus `is_subtype` / `method_target`) already treats a mixin as
    // a supertype, so the subclass map must be built from both edges too, or
    // it disagrees with `is_subtype` (asymmetrically, depending on which file
    // a mixing-in subclass happens to live in).  Union supers + mixins here.
    let mut direct_subs: HashMap<String, HashSet<String>> = HashMap::new();
    for qname in classes.keys() {
        direct_subs.insert(qname.clone(), HashSet::new());
    }
    for qname in classes.keys() {
        let parents = supers_map
            .get(qname)
            .into_iter()
            .flatten()
            .chain(mixins_map.get(qname).into_iter().flatten());
        for parent in parents {
            if let Some(set) = direct_subs.get_mut(parent) {
                set.insert(qname.clone());
            }
        }
    }

    // Build transitive-subtype closure via BFS over direct subs.
    let mut transitive: HashMap<String, HashSet<String>> = HashMap::new();
    for qname in classes.keys() {
        let mut visited: HashSet<String> = HashSet::new();
        let mut stack: Vec<String> = direct_subs
            .get(qname)
            .cloned()
            .unwrap_or_default()
            .into_iter()
            .collect();
        while let Some(child) = stack.pop() {
            if visited.contains(&child) {
                continue;
            }
            visited.insert(child.clone());
            if let Some(grandchildren) = direct_subs.get(&child) {
                for g in grandchildren {
                    stack.push(g.clone());
                }
            }
        }
        transitive.insert(qname.clone(), visited);
    }

    let method_providers = build_method_providers(&classes, &mro_map);

    // `errors` is accumulated while walking `classes.keys()` (HashMap order), so
    // its `Vec` order is otherwise nondeterministic.  Sort it: the order carries
    // no meaning, and a stable order keeps two logically-equal hierarchies
    // `==` — which is what lets salsa backdate `project_class_index` on a
    // body-only edit instead of needlessly recomputing dependent token queries.
    errors.sort_unstable();

    ClassHierarchy {
        classes,
        mro_map,
        original_unresolved_relations,
        mixin_map: mixins_map,
        spine_map,
        subclasses: direct_subs,
        transitive_subtypes: transitive,
        method_providers,
        errors,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::analyser::types::MethodDef;
    use tcl_lexer::Span;

    fn span() -> Span {
        Span::new(0, 0)
    }

    fn cls(qname: &str, supers: &[&str], mixins: &[&str], methods: &[&str]) -> ClassDef {
        let mut cd = ClassDef {
            name: crate::naming::key_tail(qname).to_string(),
            qualified_name: qname.to_string(),
            name_span: span(),
            body_span: span(),
            superclasses: supers.iter().map(|s| (*s).to_string()).collect(),
            mixins: mixins.iter().map(|s| (*s).to_string()).collect(),
            ..Default::default()
        };
        for m in methods {
            cd.methods.insert(
                (*m).to_string(),
                MethodDef {
                    name: (*m).to_string(),
                    params: Vec::new(),
                    params_computed: false,
                    formal_count: crate::signature_scan::formal_count::SourceFormalCount::Authored(
                        tcl_dialect::ParameterGrammar::Tcl,
                    ),
                    name_span: span(),
                    body_span: span(),
                    kind: "method".to_string(),
                    is_self_method: false,
                    visibility: "public".to_string(),
                    doc: String::new(),
                    forward_target: None,
                },
            );
        }
        cd
    }

    fn map(classes: Vec<ClassDef>) -> HashMap<String, ClassDef> {
        classes
            .into_iter()
            .map(|c| (c.qualified_name.clone(), c))
            .collect()
    }

    #[test]
    fn declared_member_keeps_reported_side_and_declaring_class_separate() {
        let mut class = cls("::C", &[], &[], &["same"]);
        let mut class_method = class.methods["same"].clone();
        class_method.name_span = Span::new(20, 24);
        class_method.is_self_method = true;
        class.class_methods.insert("same".to_owned(), class_method);
        let hierarchy = build_class_hierarchy(map(vec![class, cls("::Sub", &["::C"], &[], &[])]));
        let (_, instance) = hierarchy
            .declared_member("::C", "same", super::super::types::MemberSide::Instance)
            .unwrap();
        let (_, class_object) = hierarchy
            .declared_member("::C", "same", super::super::types::MemberSide::ClassObject)
            .unwrap();
        assert_ne!(instance.name_span, class_object.name_span);
        assert_eq!(hierarchy.method_target("::Sub", "same"), Some("::C"));
        assert!(
            hierarchy
                .declared_member("::Sub", "same", super::super::types::MemberSide::Instance)
                .is_none()
        );
    }

    #[test]
    fn empty_input_yields_empty_hierarchy() {
        let h = build_class_hierarchy(HashMap::new());
        assert_eq!(h.classes.len(), 0);
        assert_eq!(h.mro_map.len(), 0);
        assert_eq!(h.subclasses.len(), 0);
        assert_eq!(h.errors, [] as [std::string::String; 0]);
    }

    #[test]
    fn single_class_self_mro() {
        let classes = map(vec![cls("::A", &[], &[], &["m"])]);
        let h = build_class_hierarchy(classes);
        assert_eq!(h.mro_map["::A"], vec!["::A"]);
        assert_eq!(h.method_target("::A", "m"), Some("::A"));
    }

    #[test]
    fn single_inheritance_method_resolution() {
        // B inherits from A; A defines ``m``; B's lookup of
        // ``m`` resolves to A.
        let classes = map(vec![
            cls("::A", &[], &[], &["m"]),
            cls("::B", &["::A"], &[], &[]),
        ]);
        let h = build_class_hierarchy(classes);
        assert_eq!(h.mro_map["::B"], vec!["::B", "::A"]);
        assert_eq!(h.method_target("::B", "m"), Some("::A"));
        assert!(h.is_subtype("::B", "::A"));
        assert!(!h.is_subtype("::A", "::B"));
    }

    #[test]
    fn diamond_method_resolution_with_late_placement() {
        // D → B, C → A.  TclOO late-placement puts A after C.
        // B defines ``m`` so D's ``m`` resolves to B.
        let classes = map(vec![
            cls("::A", &[], &[], &[]),
            cls("::B", &["::A"], &[], &["m"]),
            cls("::C", &["::A"], &[], &[]),
            cls("::D", &["::B", "::C"], &[], &[]),
        ]);
        let h = build_class_hierarchy(classes);
        assert_eq!(h.mro_map["::D"], vec!["::D", "::B", "::C", "::A"]);
        assert_eq!(h.method_target("::D", "m"), Some("::B"));
    }

    #[test]
    fn mixin_provider_takes_precedence() {
        // B mixes M; M defines ``m``; B's ``m`` resolves to M.
        let classes = map(vec![
            cls("::A", &[], &[], &[]),
            cls("::M", &[], &[], &["m"]),
            cls("::B", &["::A"], &["::M"], &[]),
        ]);
        let h = build_class_hierarchy(classes);
        assert_eq!(h.mro_map["::B"], vec!["::M", "::B", "::A"]);
        assert_eq!(h.method_target("::B", "m"), Some("::M"));
    }

    #[test]
    fn direct_subclasses_recorded() {
        let classes = map(vec![
            cls("::A", &[], &[], &[]),
            cls("::B", &["::A"], &[], &[]),
            cls("::C", &["::A"], &[], &[]),
        ]);
        let h = build_class_hierarchy(classes);
        let a_subs = &h.subclasses["::A"];
        assert!(a_subs.contains("::B"));
        assert!(a_subs.contains("::C"));
        assert_eq!(a_subs.len(), 2);
        // Leaves have empty subclass sets, never None.
        assert_eq!(h.subclasses["::B"].len(), 0);
    }

    #[test]
    fn mixin_recorded_as_subclass_edge() {
        // `B` mixes `M`.  `is_subtype(B, M)` is true (the MRO places the
        // mixin as a supertype), so the subclass map must list `B` under
        // `M` too — otherwise the two views disagree.
        let classes = map(vec![
            cls("::M", &[], &[], &[]),
            cls("::A", &[], &[], &[]),
            cls("::B", &["::A"], &["::M"], &[]),
        ]);
        let h = build_class_hierarchy(classes);
        assert!(h.is_subtype("::B", "::M"));
        assert!(
            h.subclasses["::M"].contains("::B"),
            "{:?}",
            h.subclasses["::M"]
        );
        assert!(h.subclasses["::A"].contains("::B"));
        // Transitive closure agrees.
        assert!(h.transitive_subtypes["::M"].contains("::B"));
    }

    #[test]
    fn transitive_subtypes_via_bfs() {
        let classes = map(vec![
            cls("::A", &[], &[], &[]),
            cls("::B", &["::A"], &[], &[]),
            cls("::C", &["::B"], &[], &[]),
        ]);
        let h = build_class_hierarchy(classes);
        let a_descendants = &h.transitive_subtypes["::A"];
        assert!(a_descendants.contains("::B"));
        assert!(a_descendants.contains("::C"));
        assert_eq!(a_descendants.len(), 2);
    }

    #[test]
    fn cycle_collected_as_error_not_panic() {
        let classes = map(vec![
            cls("::A", &["::B"], &[], &[]),
            cls("::B", &["::A"], &[], &[]),
        ]);
        let h = build_class_hierarchy(classes);
        assert_ne!(h.errors, [] as [std::string::String; 0]);
        // Cycle classes get single-element MRO fallback.
        assert_eq!(h.mro_map["::A"], vec!["::A"]);
    }

    #[test]
    fn relation_cycle_errors_distinguish_a_mixin_cycle_from_a_diamond() {
        let cyclic = build_class_hierarchy(map(vec![
            cls("::A", &[], &["::B"], &[]),
            cls("::B", &[], &["::A"], &[]),
            cls("::C", &[], &["::A"], &[]),
        ]));
        assert_ne!(cyclic.errors, [] as [std::string::String; 0]);

        let diamond = build_class_hierarchy(map(vec![
            cls("::Root", &[], &[], &[]),
            cls("::Left", &["::Root"], &[], &[]),
            cls("::Right", &["::Root"], &[], &[]),
            cls("::Leaf", &["::Left", "::Right"], &[], &[]),
        ]));
        assert_eq!(diamond.errors, [] as [std::string::String; 0]);
    }

    #[test]
    fn unqualified_parent_normalised_when_match_exists() {
        // ``::B`` lists ``A`` (no ``::``) as a superclass; the
        // normalisation step adds the leading ``::`` because
        // ``::A`` is in the class map.
        let classes = map(vec![
            cls("::A", &[], &[], &["m"]),
            cls("::B", &["A"], &[], &[]),
        ]);
        let h = build_class_hierarchy(classes);
        assert_eq!(h.mro_map["::B"], vec!["::B", "::A"]);
        assert_eq!(h.method_target("::B", "m"), Some("::A"));
    }

    #[test]
    fn method_target_returns_none_for_unknown_method() {
        let classes = map(vec![cls("::A", &[], &[], &[])]);
        let h = build_class_hierarchy(classes);
        assert_eq!(h.method_target("::A", "nope"), None);
    }

    /// `constructor_provider` mirrors `method_target` but over
    /// `ClassDef::constructors` rather than `methods`.
    ///
    /// Real source text `is_empty_method_body` slices into: byte 0-1 is
    /// `"{}"` (an empty body), byte 2-4 is `"{x"` (`is_empty_method_body`'s
    /// documented non-empty-content slice shape — the span covers the
    /// opener through the last inner byte, excluding the closer).
    const CTOR_SRC: &str = "{}{x}";
    const EMPTY_BODY: Span = Span::new(0, 2);
    const NON_EMPTY_BODY: Span = Span::new(2, 4);

    /// A real (non-empty-bodied) constructor.
    fn cls_with_ctor(qname: &str, supers: &[&str]) -> ClassDef {
        cls_with_ctor_body(qname, supers, NON_EMPTY_BODY)
    }

    fn cls_with_ctor_body(qname: &str, supers: &[&str], body_span: Span) -> ClassDef {
        let mut cd = cls(qname, supers, &[], &[]);
        cd.constructors.push(MethodDef {
            name: "<constructor>".to_string(),
            params: Vec::new(),
            params_computed: false,
            formal_count: crate::signature_scan::formal_count::SourceFormalCount::Authored(
                tcl_dialect::ParameterGrammar::Tcl,
            ),
            name_span: span(),
            body_span,
            kind: "constructor".to_string(),
            is_self_method: false,
            visibility: "public".to_string(),
            doc: String::new(),
            forward_target: None,
        });
        cd
    }

    #[test]
    fn constructor_provider_none_when_no_class_declares_one() {
        let classes = map(vec![cls("::A", &[], &[], &[])]);
        let h = build_class_hierarchy(classes);
        assert_eq!(h.constructor_provider("::A", CTOR_SRC), None);
    }

    #[test]
    fn constructor_provider_own_class() {
        let classes = map(vec![cls_with_ctor("::A", &[])]);
        let h = build_class_hierarchy(classes);
        assert_eq!(h.constructor_provider("::A", CTOR_SRC), Some("::A"));
    }

    #[test]
    fn constructor_provider_inherited_from_superclass() {
        // ::B has no constructor of its own; ::A's is inherited.
        let classes = map(vec![
            cls_with_ctor("::A", &[]),
            cls("::B", &["::A"], &[], &[]),
        ]);
        let h = build_class_hierarchy(classes);
        assert_eq!(h.constructor_provider("::B", CTOR_SRC), Some("::A"));
    }

    #[test]
    fn constructor_provider_own_overrides_inherited() {
        let classes = map(vec![
            cls_with_ctor("::A", &[]),
            cls_with_ctor("::B", &["::A"]),
        ]);
        let h = build_class_hierarchy(classes);
        assert_eq!(h.constructor_provider("::B", CTOR_SRC), Some("::B"));
    }

    #[test]
    fn constructor_provider_none_for_empty_body_constructor() {
        // `constructor {a b} {}` (a literally empty body) is `TclOO`'s way
        // of writing "no constructor" — confirmed against tclsh 9.0.4:
        // `info class constructor` returns empty and `new` accepts any
        // argument count.
        let classes = map(vec![cls_with_ctor_body("::A", &[], EMPTY_BODY)]);
        let h = build_class_hierarchy(classes);
        assert_eq!(h.constructor_provider("::A", CTOR_SRC), None);
    }

    #[test]
    fn constructor_provider_falls_back_to_superclass_when_own_is_empty_bodied() {
        let classes = map(vec![
            cls_with_ctor("::A", &[]),
            cls_with_ctor_body("::B", &["::A"], EMPTY_BODY),
        ]);
        let h = build_class_hierarchy(classes);
        assert_eq!(h.constructor_provider("::B", CTOR_SRC), Some("::A"));
    }

    #[test]
    fn is_empty_method_body_matches_only_the_exact_delimiter_pair() {
        assert!(is_empty_method_body(CTOR_SRC, EMPTY_BODY));
        assert!(!is_empty_method_body(CTOR_SRC, NON_EMPTY_BODY));
        assert!(is_empty_method_body("[]", Span::new(0, 2)));
        assert!(is_empty_method_body("\"\"", Span::new(0, 2)));
        // Out-of-range span — must not panic, must not report empty.
        assert!(!is_empty_method_body("{}", Span::new(0, 5)));
    }

    // `constructor_next_provider` / `destructor_next_provider` — the
    // constructor/destructor next-chain.

    #[test]
    fn constructor_next_provider_none_when_class_unknown() {
        let classes = map(vec![cls_with_ctor("::A", &[])]);
        let h = build_class_hierarchy(classes);
        assert_eq!(h.constructor_next_provider("::Nope", None, CTOR_SRC), None);
    }

    #[test]
    fn constructor_next_provider_direct_superclass() {
        // `Sub`'s own `next` (no explicit target) resolves one past `Sub`
        // itself in `Sub`'s own MRO — its direct superclass `Base`.
        let classes = map(vec![
            cls_with_ctor("::Base", &[]),
            cls_with_ctor("::Sub", &["::Base"]),
        ]);
        let h = build_class_hierarchy(classes);
        assert_eq!(
            h.constructor_next_provider("::Sub", None, CTOR_SRC),
            Some("::Base")
        );
    }

    #[test]
    fn constructor_next_provider_skips_ancestor_with_no_effective_constructor() {
        // `Mid` declares no constructor of its own (a pure pass-through), so
        // `Sub`'s `next` must skip past it and reach `Base`'s — the same
        // "effective provider" skip `constructor_provider` already performs,
        // just starting one class later.
        let classes = map(vec![
            cls_with_ctor("::Base", &[]),
            cls("::Mid", &["::Base"], &[], &[]),
            cls_with_ctor("::Sub", &["::Mid"]),
        ]);
        let h = build_class_hierarchy(classes);
        assert_eq!(
            h.constructor_next_provider("::Sub", None, CTOR_SRC),
            Some("::Base")
        );
    }

    #[test]
    fn constructor_next_provider_skips_ancestor_with_empty_bodied_constructor() {
        // `Mid` declares an explicit but empty-bodied constructor — `TclOO`
        // treats that as "no constructor", so `next` from `Sub` must skip
        // past it too, exactly like `constructor_provider` does.
        let classes = map(vec![
            cls_with_ctor("::Base", &[]),
            cls_with_ctor_body("::Mid", &["::Base"], EMPTY_BODY),
            cls_with_ctor("::Sub", &["::Mid"]),
        ]);
        let h = build_class_hierarchy(classes);
        assert_eq!(
            h.constructor_next_provider("::Sub", None, CTOR_SRC),
            Some("::Base")
        );
    }

    #[test]
    fn constructor_next_provider_none_when_chain_exhausted() {
        let classes = map(vec![cls_with_ctor("::Sub", &[])]);
        let h = build_class_hierarchy(classes);
        assert_eq!(h.constructor_next_provider("::Sub", None, CTOR_SRC), None);
    }

    #[test]
    fn constructor_next_provider_nextto_explicit_target() {
        // `nextto Grandparent` jumps straight to the named class, skipping
        // `Base` even though `Base` also has an effective constructor.
        let classes = map(vec![
            cls_with_ctor("::Grandparent", &[]),
            cls_with_ctor("::Base", &["::Grandparent"]),
            cls_with_ctor("::Sub", &["::Base"]),
        ]);
        let h = build_class_hierarchy(classes);
        assert_eq!(
            h.constructor_next_provider("::Sub", Some("::Grandparent"), CTOR_SRC),
            Some("::Grandparent")
        );
    }

    /// A class with a real (non-empty) destructor.
    fn cls_with_dtor(qname: &str, supers: &[&str]) -> ClassDef {
        let mut cd = cls(qname, supers, &[], &[]);
        cd.destructor = Some(MethodDef {
            name: "<destructor>".to_string(),
            params: Vec::new(),
            params_computed: false,
            formal_count: crate::signature_scan::formal_count::SourceFormalCount::Authored(
                tcl_dialect::ParameterGrammar::Tcl,
            ),
            name_span: span(),
            body_span: NON_EMPTY_BODY,
            kind: "destructor".to_string(),
            visibility: "public".to_string(),
            doc: String::new(),
            forward_target: None,
            is_self_method: false,
        });
        cd
    }

    #[test]
    fn destructor_next_provider_direct_superclass() {
        let classes = map(vec![
            cls_with_dtor("::Base", &[]),
            cls_with_dtor("::Sub", &["::Base"]),
        ]);
        let h = build_class_hierarchy(classes);
        assert_eq!(h.destructor_next_provider("::Sub", None), Some("::Base"));
    }

    #[test]
    fn destructor_next_provider_skips_ancestor_with_no_destructor() {
        let classes = map(vec![
            cls_with_dtor("::Base", &[]),
            cls("::Mid", &["::Base"], &[], &[]),
            cls_with_dtor("::Sub", &["::Mid"]),
        ]);
        let h = build_class_hierarchy(classes);
        assert_eq!(h.destructor_next_provider("::Sub", None), Some("::Base"));
    }

    #[test]
    fn destructor_next_provider_none_when_chain_exhausted() {
        let classes = map(vec![cls_with_dtor("::Sub", &[])]);
        let h = build_class_hierarchy(classes);
        assert_eq!(h.destructor_next_provider("::Sub", None), None);
    }

    #[test]
    fn all_implementations_lists_all_classes_with_method() {
        let classes = map(vec![
            cls("::A", &[], &[], &["m"]),
            cls("::B", &["::A"], &[], &["m"]),
        ]);
        let h = build_class_hierarchy(classes);
        let mut impls = h.all_implementations("m");
        impls.sort();
        assert_eq!(impls.len(), 2);
        // ``::A`` provides its own m.
        assert!(impls.contains(&("::A".to_string(), "::A".to_string())));
        // ``::B`` overrides; B's m provider is ::B.
        assert!(impls.contains(&("::B".to_string(), "::B".to_string())));
    }

    #[test]
    fn bare_superclass_links_via_namespace_ancestry() {
        // A subclass in `::Ns::Sub` names its base bare (`Base`); the base
        // lives at `::Ns::Base`. Ancestry resolution links them so the
        // inherited method resolves.
        let classes = map(vec![
            cls("::Ns::Base", &[], &[], &["inherited"]),
            cls("::Ns::Sub", &["Base"], &[], &[]),
        ]);
        let h = build_class_hierarchy(classes);
        assert_eq!(h.mro_map["::Ns::Sub"], vec!["::Ns::Sub", "::Ns::Base"]);
        assert_eq!(
            h.method_target("::Ns::Sub", "inherited"),
            Some("::Ns::Base")
        );
    }

    #[test]
    fn bare_superclass_links_via_unique_tail_across_namespaces() {
        // The SpiceGenTcl shape: a global class (`::Core`, from an
        // `namespace import`) names a base defined under a namespace
        // (`::SpiceGenTcl::Device`). The simple name is globally unique, so
        // the tail match links them and the inherited method resolves.
        let classes = map(vec![
            cls("::SpiceGenTcl::Device", &[], &[], &["genSPICEString"]),
            cls("::Core", &["Device"], &[], &[]),
        ]);
        let h = build_class_hierarchy(classes);
        assert_eq!(
            h.method_target("::Core", "genSPICEString"),
            Some("::SpiceGenTcl::Device")
        );
    }

    #[test]
    fn next_provider_walks_and_nextto_restarts() {
        // C -> B -> A, all define `m`.
        let classes = map(vec![
            cls("::A", &[], &[], &["m"]),
            cls("::B", &["::A"], &[], &["m"]),
            cls("::C", &["::B"], &[], &["m"]),
        ]);
        let h = build_class_hierarchy(classes);
        // `next` from C's m → B, then A, then exhausted.
        assert_eq!(h.next_provider("::C", "m", "::C", None), Some("::B"));
        assert_eq!(h.next_provider("::C", "m", "::B", None), Some("::A"));
        assert_eq!(h.next_provider("::C", "m", "::A", None), None);
        // `nextto ::A` jumps straight to A.
        assert_eq!(h.next_provider("::C", "m", "::C", Some("::A")), Some("::A"));
    }

    #[test]
    fn next_provider_skips_classes_without_the_method() {
        // C -> B -> A; only C and A define `m`. `next` from C skips B → A.
        let classes = map(vec![
            cls("::A", &[], &[], &["m"]),
            cls("::B", &["::A"], &[], &[]),
            cls("::C", &["::B"], &[], &["m"]),
        ]);
        let h = build_class_hierarchy(classes);
        assert_eq!(h.next_provider("::C", "m", "::C", None), Some("::A"));
    }

    #[test]
    fn ambiguous_bare_superclass_stays_unlinked() {
        // Two classes share the tail `Base`; a bare `superclass Base` from an
        // unrelated namespace must NOT be linked to either (no wrong guess).
        let classes = map(vec![
            cls("::A::Base", &[], &[], &["m"]),
            cls("::B::Base", &[], &[], &["m"]),
            cls("::C::Sub", &["Base"], &[], &[]),
        ]);
        let h = build_class_hierarchy(classes);
        // Sub's MRO contains only itself + the unresolved bare `Base` leaf;
        // the method does not resolve to either candidate.
        assert_eq!(h.method_target("::C::Sub", "m"), None);
    }

    // Class-name resolution follows C Tcl's one-hop rule (current ns, then
    // global), never an ancestor walk.  `resolve_from` mirrors the analyser's
    // real call.
    fn resolve_from(name: &str, owner: &str, keys: &[&str]) -> Option<String> {
        let key_strings: Vec<String> = keys.iter().copied().map(String::from).collect();
        let known: std::collections::HashSet<String> = key_strings.iter().cloned().collect();
        let tail_index = build_tail_index(key_strings.iter());
        resolve_class_name(name, owner, |q| known.contains(q), &tail_index)
    }

    /// FP guard: a bare `superclass Base` in `::a::b::Sub` where `Base` exists
    /// only at `::a::Base` (an *ancestor*, not the current ns or global) and the
    /// tail is ambiguous must NOT link — real Tcl errors there, and an ancestor
    /// walk would wrongly return `::a::Base`.
    #[test]
    fn superclass_resolution_abstains_on_ancestor_only_base() {
        let got = resolve_from(
            "Base",
            "::a::b::Sub",
            &["::a::Base", "::x::Base", "::a::b::Sub"],
        );
        assert_eq!(
            got, None,
            "must abstain, not climb to an ancestor namespace"
        );
    }

    /// TP: a base in the class's *own* namespace resolves one-hop.
    #[test]
    fn superclass_same_namespace_base_resolves() {
        let got = resolve_from("Base", "::a::Sub", &["::a::Base", "::a::Sub"]);
        assert_eq!(got.as_deref(), Some("::a::Base"));
    }

    /// TP: a global base resolves (current-ns miss falls through to global).
    #[test]
    fn superclass_global_base_resolves() {
        let got = resolve_from("Base", "::a::b::Sub", &["::Base", "::a::b::Sub"]);
        assert_eq!(got.as_deref(), Some("::Base"));
    }

    /// A globally unique tail supplies no retained import or caller receipt.
    #[test]
    fn superclass_cross_file_unique_tail_withdraws() {
        let got = resolve_from(
            "Device",
            "::spice::sub::Sub",
            &["::spice::Device", "::spice::sub::Sub"],
        );
        assert_eq!(got, None);
    }

    /// TN: an absolute `::`-qualified name is taken exactly.
    #[test]
    fn superclass_absolute_name_is_exact() {
        let got = resolve_from("::a::Base", "::x::Sub", &["::a::Base", "::x::Sub"]);
        assert_eq!(got.as_deref(), Some("::a::Base"));
    }
}

#[cfg(test)]
mod source_naming_tests {
    use super::*;
    use crate::signature_scan::scope::{
        SignatureNamespaceScope, SignatureSourceCommand, SignatureSourceLookup,
    };
    use tcl_syntax::naming::NamePolicyProtocol;

    fn source_class(
        policy: NamePolicyProtocol,
        scope: &SignatureNamespaceScope,
        written: &str,
    ) -> ClassDef {
        ClassDef {
            source_name: SignatureSourceCommand::object_in_context(policy, scope, written),
            ..ClassDef::default()
        }
    }

    #[test]
    fn class_lookup_requires_original_context_and_does_not_borrow_unique_tail() {
        let policy = NamePolicyProtocol::authored_tcl(tcl_dialect::TclVersion::V8_6);
        let root = SignatureNamespaceScope::root(Some(policy));
        let left = root.child("left", Some(policy)).unwrap();
        let right = root.child("right", Some(policy)).unwrap();
        let classes = HashMap::from([(
            "::left::Base".to_owned(),
            source_class(policy, &left, "Base"),
        )]);
        assert_eq!(
            resolve_written_class_name_in_context("Base", &left, policy, &classes).as_deref(),
            Some("::left::Base")
        );
        assert_eq!(
            resolve_written_class_name_in_context("Base", &right, policy, &classes),
            None
        );
        assert_eq!(resolve_written_class_name("Base", &classes), None);
        let caller = SignatureSourceLookup::new(policy, left, "Base".to_owned()).unwrap();
        assert_eq!(
            resolve_class_lookup(&caller, &classes).as_deref(),
            Some("::left::Base")
        );
        assert!(
            SignatureSourceLookup::new(
                NamePolicyProtocol::authored_jim084(),
                right,
                "Base".to_owned()
            )
            .is_none()
        );
    }

    #[test]
    fn class_report_collisions_withdraw_instead_of_selecting_another_slot() {
        let policy = NamePolicyProtocol::authored_tcl(tcl_dialect::TclVersion::V8_6);
        let root = SignatureNamespaceScope::root(Some(policy));
        let left = root
            .child("a:", Some(policy))
            .unwrap()
            .child("b", Some(policy))
            .unwrap();
        let right = root
            .child("a", Some(policy))
            .unwrap()
            .child(":b", Some(policy))
            .unwrap();
        assert_eq!(left.display(), right.display());
        let mut result = super::super::types::AnalysisResult::default();
        result.retain_class_declaration(
            "::a:::b::Base".to_owned(),
            source_class(policy, &left, "Base"),
        );
        result.retain_class_declaration(
            "::a:::b::Base".to_owned(),
            source_class(policy, &right, "Base"),
        );
        assert!(
            result.all_classes["::a:::b::Base"]
                .source_name_ambiguous
                .is_observed()
        );
        assert_eq!(
            resolve_written_class_name_in_context("Base", &right, policy, &result.all_classes),
            None
        );
    }
}

#[cfg(test)]
mod constructed_projection_tests {
    use super::*;

    #[test]
    fn constructed_class_graph_lookup_preserves_literal_colon_holder() {
        // Implementation contract: naming.analysis.constructed-key-consumer-projections
        // docs/design/analysis/name-resolution-proofs/constructed-key-consumer-projections.md
        // Explicit constructed graph assistance; no retained source lookup exists here.
        let tails: HashMap<String, Vec<String>> = HashMap::new();
        for (owner, expected) in [
            ("Sub", "::Base"),
            ("::Sub", "::Base"),
            ("n::Sub", "::n::Base"),
            ("::a::::Sub", "::a::Base"),
            ("::::::", ":::::Base"),
            ("::é::λ", "::é::Base"),
        ] {
            assert_eq!(
                resolve_class_name("Base", owner, |candidate| candidate == expected, &tails)
                    .as_deref(),
                Some(expected),
            );
            assert_eq!(
                resolve_class_name(
                    "Base",
                    owner,
                    |candidate| candidate == "::foreign::Base",
                    &tails
                ),
                None,
            );
        }
    }
}
