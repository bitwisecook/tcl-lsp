// tcl-lsp — a language server and toolchain for Tcl
// Copyright (C) 2026 James Deucker (bitwisecook) <https://github.com/bitwisecook>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.
//
// SPDX-License-Identifier: AGPL-3.0-or-later

//! Top-level optimiser orchestration.
//!
//! Orchestration is implicit in the layered pipeline:
//! [`CompilationUnit::build_for`] runs the analyses,
//! [`build_interprocedural_analysis`] builds the summaries, and
//! [`super::run_passes`] dispatches each pass. The thin façade
//! below is a single entry point that plumbs these together, runs
//! every pass in default order, and then applies the overlap-aware
//! selection filter from [`super::helpers::select`].
//!
//! Callers that need a single `optimise(source)` one-shot call
//! use [`optimise`] / [`optimise_with_dialect`]. Callers that
//! want full control (custom pass ordering, pre-populated
//! `PassContext` scratch state) stay on
//! [`super::run_passes`] directly.

use tcl_core_types::DiagCode;
use tcl_registry::CommandRegistry;

use crate::compilation_unit::CompilationUnit;

use super::elimination::DeadStore;
use super::helpers::select::select_non_overlapping;
use super::helpers::spans::{full_rewrite_span, line_delete_span};
use super::helpers::var_refs::{bareword_occurrences, count_var_refs};
use super::{Optimisation, PassContext, PassId, run_passes};

/// Build a [`CompilationUnit`] for `source`, run every
/// optimiser pass in canonical order, and return the overlap-
/// free set of [`Optimisation`] suggestions.
///
/// Equivalent to [`optimise_with_dialect`] with `dialect = None`.
#[must_use]
pub fn optimise(source: &str, registry: &CommandRegistry) -> Vec<Optimisation> {
    optimise_with_dialect(source, registry, None)
}

/// Build a [`CompilationUnit`] for `source`, populate
/// interprocedural summaries, and run every pass in
/// [`PassId::all()`] order — then deduplicate via
/// [`select_non_overlapping`].
#[must_use]
pub fn optimise_with_dialect(
    source: &str,
    registry: &CommandRegistry,
    dialect: Option<&'static tcl_dialect::DialectProfile>,
) -> Vec<Optimisation> {
    let profile = match dialect {
        Some(profile) => profile,
        None => tcl_dialect::DialectProfile::plain_tcl(),
    };
    let cu = CompilationUnit::build_for_profile(source, registry, false, profile)
        .with_interprocedural(registry, dialect);
    optimise_unit(&cu, registry, dialect)
}

/// Run every pass over an **already-built** [`CompilationUnit`] (one carrying
/// its interprocedural summary) and return the overlap-resolved optimisations.
///
/// This is the rebuild-free core of [`optimise_with_dialect`]: callers that have
/// already constructed a `CompilationUnit` (e.g. the LSP diagnostics path, which
/// also runs `compiler_checks::run_all_checks` over the same unit) share it
/// instead of lowering the source a second time.
#[must_use]
pub fn optimise_unit(
    cu: &CompilationUnit,
    registry: &CommandRegistry,
    dialect: Option<&'static tcl_dialect::DialectProfile>,
) -> Vec<Optimisation> {
    let raw = optimise_unit_raw(cu, registry, dialect);
    finalise_optimisations(&raw, cu, registry, dialect)
}

/// The total ordering key used to canonicalise the optimisation set before
/// overlap arbitration and group renumbering — the determinism chokepoint that
/// makes the surviving set, its order, and group numbering byte-identical given
/// an equal `CompilationUnit` (the precondition for salsa early-cutoff on
/// `compiler_check_diagnostics`, and for the per-procedure optimiser memo: the
/// rebased per-proc raw set sorts into the same order the whole-module run does).
fn sort_optimisations(opts: &mut [Optimisation]) {
    opts.sort_by(|a, b| {
        (
            a.span.start(),
            a.span.end(),
            &a.code,
            &a.message,
            &a.replacement,
            a.hint_only,
        )
            .cmp(&(
                b.span.start(),
                b.span.end(),
                &b.code,
                &b.message,
                &b.replacement,
                b.hint_only,
            ))
    });
}

/// Build a [`PassContext`] wired the way every production entry point below
/// needs it: `registry` (place-bridge / purity resolution), `ir_module`
/// (the whole-module trace facts — `traced_commands` / `has_dynamic_trace`
/// / `traced_variables` / `has_dynamic_variable_trace` — without this the
/// O127 store-to-load-forwarding trace-purity gate and the O102
/// load-forwarding variable-trace gate silently see an empty/false default
/// and never actually block on a real trace), and `command_mutations` (the
/// whole-module builtin-fold trust gate, O129/O116/O118 — without this a
/// renamed/redefined builtin, e.g. `rename string {}; [string length …]`,
/// still gets const-folded with its original semantics, a silent
/// miscompile). Every production entry point shares this context builder.
fn build_pass_context<'a>(
    cu: &'a CompilationUnit,
    registry: &'a CommandRegistry,
    dialect: Option<&'static tcl_dialect::DialectProfile>,
) -> PassContext<'a> {
    let ia = cu.interproc.clone().unwrap_or_default();
    let mut ctx = PassContext::with_dialect(&cu.source, ia, dialect);
    ctx.registry = Some(registry);
    ctx.ir_module = Some(&cu.ir_module);
    ctx.command_mutations.clone_from(&cu.command_mutations);
    // This is a conservative whole-unit safety fact. Several source-walking
    // passes run before elimination and cannot recover the current handler
    // from a nested script, so protecting the union is sound; handler-local
    // refinement remains elimination's concern.
    ctx.cross_event_vars = cu
        .connection_scope
        .as_ref()
        .map(crate::connection_scope::ConnectionScope::source_names)
        .unwrap_or_default();
    ctx
}

/// The first half of [`optimise_unit`]: run every pass over the built unit and
/// return the **canonicalised raw** optimisation set, before overlap selection
/// / const-dead-store coupling / group renumbering — that whole-module tail is
/// [`finalise_optimisations`].
///
/// Split out so the per-procedure optimiser memo can run this half on a
/// **single-procedure offset-0** unit (one proc in `cu.procedures`, its offset-0
/// body in `cu.ir_module.procedures`, the reconstructed interproc summary +
/// `redefined_procedures` + module `command_mutations` it depends on) and cache
/// the result keyed on the proc's offset-0 `FnLatticeKey`; the whole-module
/// [`finalise_optimisations`] then runs once over the rebased, assembled set.
/// Running it on the whole unit reproduces `optimise_unit` exactly.
#[must_use]
pub fn optimise_unit_raw(
    cu: &CompilationUnit,
    registry: &CommandRegistry,
    dialect: Option<&'static tcl_dialect::DialectProfile>,
) -> Vec<Optimisation> {
    let mut ctx = build_pass_context(cu, registry, dialect);
    run_passes(&mut ctx, cu, &PassId::all());

    // Determinism chokepoint.  Several passes iterate `HashMap`s
    // (`cu.procedures`, def-use chains, SSA blocks), so both the emission order
    // and the monotonic group ids vary run-to-run — and, critically, between the
    // offset-0 per-procedure memo build and the whole-module build.  Canonicalise
    // before overlap arbitration so the surviving set, its order, and group
    // numbering are byte-identical given an equal `CompilationUnit`.
    sort_optimisations(&mut ctx.optimisations);
    ctx.optimisations
}

/// The second half of [`optimise_unit`]: the **whole-module tail** over a
/// canonicalised raw optimisation set — overlap selection, const-propagation/dead-store
/// coupling, the resurrected-reference guard, and group renumbering.  Reads
/// `cu.source` (absolute span slices) and iterates `cu.procedures` / `cu.methods`,
/// so it always runs over the **real whole-module unit** with the assembled,
/// rebased raw set — never a single-procedure unit.
#[must_use]
pub fn finalise_optimisations(
    raw: &[Optimisation],
    cu: &CompilationUnit,
    registry: &CommandRegistry,
    dialect: Option<&'static tcl_dialect::DialectProfile>,
) -> Vec<Optimisation> {
    let mut selected = select_non_overlapping(raw);
    // Couple constant propagation with dead-store removal: a `set x <const>`
    // whose every use was propagated away by a *surviving* O100/O101/O102/O103
    // rewrite is now dead and can be removed. Done after overlap selection so
    // the removal is emitted only when the propagations actually survived —
    // the group mechanism is not application-gating, so a survival check is
    // the safe coupling primitive.
    couple_propagated_const_dead_stores(cu, registry, dialect, &mut selected);
    // **Resurrected-reference guard (FP-OPT-08).** A def-elimination (an empty
    // replacement removing `set b 0`) is computed on the SSA, which may treat a
    // use as dead — e.g. `if {$b}` whose const-false condition makes the body
    // unreachable. But a *surviving* textual rewrite (unwrapping `if {$a}` to its
    // body) can keep that `$b` reference in the emitted output, so the def is not
    // actually dead. Drop any def-elimination whose target variable still appears
    // in another surviving optimisation's replacement text.
    drop_def_elims_resurrected_by_replacements(cu, registry, &mut selected);
    // Re-canonicalise: `couple_propagated_const_dead_stores` appends its O109
    // removals in `cu.procedures` / `cu.methods` HashMap-iteration order, which
    // differs run-to-run and — critically — between the offset-0 per-procedure
    // memo build and the whole-module build. Sort by the same total key as
    // above so the surviving set's order (and therefore `renumber_groups`'
    // group numbering, which walks this order) is byte-identical given an equal
    // `CompilationUnit`. Also keeps `output_is_sorted_by_span_start`.
    sort_optimisations(&mut selected);
    renumber_groups(&mut selected);
    selected
}

/// Exact original definition operands for the command removed by this edit.
/// This is a protective source-rewrite query: names can withdraw a deletion,
/// never establish runtime cells or authorise executing the replacement.
/// Unavailable original geometry/selection stays unavailable.
fn elim_target_vars(
    cu: &CompilationUnit,
    registry: &CommandRegistry,
    deletion: tcl_lexer::Span,
) -> Option<Vec<String>> {
    let module = &cu.ir_module;
    if module.source.try_text().ok()? != cu.source
        || module.registry_snapshot.as_ref()?.semantic_key() != registry.snapshot().semantic_key()
    {
        return None;
    }
    let first = cu
        .all_body_function_units()
        .flat_map(|unit| {
            unit.cfg.blocks.iter().flat_map(move |(&block, data)| {
                data.statements
                    .iter()
                    .enumerate()
                    .filter_map(move |(index, _)| {
                        let span =
                            unit.abs_span(unit.cfg.statement_source_edit_span(block, index)?);
                        (deletion.start() <= span.start() && span.end() <= deletion.end())
                            .then_some((span, unit, block, index))
                    })
            })
        })
        .min_by_key(|(span, _, _, _)| (span.start(), std::cmp::Reverse(span.len())));
    let Some((_, unit, block, index)) = first else {
        // A non-statement deletion (for example a whole declaration) is not a
        // variable definition. Definition-removal codes need their own carrier.
        return Some(Vec::new());
    };
    let tokens = unit.cfg.source_tokens_at(block, index)?;
    let binding = tokens.source_binding.as_ref()?;
    let origin = binding.source_origin()?;
    if !matches!(
        origin.kind(),
        crate::command_binding::SourceOriginKind::Authored(_)
    ) || origin.source_image() != &module.source
        || binding
            .original_lexer_config_for_tokens(tokens)?
            .normalized()
            != module.lexer_config.normalized()
    {
        return None;
    }
    let normal = crate::registry_invocation::normal_transfer_invocation_with_metadata_context(
        registry,
        Some(unit.invocation_metadata_context(registry)?),
        tokens,
    )?;
    normal_definition_reference_names(&normal, &binding.variable_context, registry)
}

/// Combine original operand names and already-bound canonical projections.
/// The common operand/cell owners select CString/counting, array decomposition
/// and aliases; this consumer never parses a reporting command head or argv.
fn normal_definition_reference_names(
    normal: &crate::registry_invocation::NormalTransferInvocation,
    context: &crate::var_resolve::ResolveContext,
    registry: &CommandRegistry,
) -> Option<Vec<String>> {
    let outputs = normal.variable_output_arguments()?;
    let mut names = normal.definition_names();
    // Unknown variable operands cannot turn an absence of printable names
    // into a licence to delete their original definition.
    for index in outputs {
        normal.argument_literal(index)?;
    }
    for place in normal.definition_places(context, registry) {
        let canonical = crate::var_resolve::canonical_binding_value_name(&place)?;
        names.push(canonical);
        names.push(place.name);
    }
    let mut roots = Vec::new();
    for name in names {
        // These are selected values, not substitution syntax. In particular
        // a literal `$name` must keep its leading dollar byte.
        roots.push(
            tcl_syntax::naming::split_element_ref(&name)
                .map_or(name.clone(), |(base, _)| base.to_owned()),
        );
    }
    roots.sort_unstable();
    roots.dedup();
    Some(roots)
}

/// Drop a def-elimination (empty replacement) when its target variable still
/// appears as `$var` / `${var}` in another *surviving* optimisation's
/// replacement — the SSA judged the def dead, but a surviving textual rewrite
/// resurrected a reference to it (FP-OPT-08).
///
/// A **group-mate** never resurrects. One group is a single atomic rewrite, so
/// a code-sinking (O125) insertion carrying the sunk `set x …` *and* the `$x`
/// that consumes it is the very reason its paired deletion exists; reading it
/// as a resurrection would keep the assignment in both places. Group-mates are
/// therefore skipped when scanning for a resurrecting reference, and a
/// deletion that *is* dropped takes the rest of its group with it — the group
/// is applied all-or-nothing, never partially, exactly as
/// [`select_non_overlapping`] guarantees earlier in this tail.
fn drop_def_elims_resurrected_by_replacements(
    cu: &CompilationUnit,
    registry: &CommandRegistry,
    selected: &mut Vec<Optimisation>,
) {
    // naming.optimiser.original-definition-resurrection-guard
    // docs/design/analysis/name-resolution-proofs/optimiser-original-definition-resurrection-guard.md
    let elims: Vec<(usize, Option<Vec<String>>)> = selected
        .iter()
        .enumerate()
        .filter(|(_, o)| o.replacement.trim().is_empty())
        .map(|(i, o)| {
            let names = elim_target_vars(cu, registry, o.span).and_then(|names| {
                (!names.is_empty()
                    || !matches!(o.code, DiagCode::O109 | DiagCode::O125 | DiagCode::O126))
                .then_some(names)
            });
            (i, names)
        })
        .collect();
    if elims.is_empty() {
        return;
    }
    let mut drop: Vec<usize> = elims
        .iter()
        .filter(|(i, names)| {
            let Some(names) = names else {
                return true;
            };
            let group = selected[*i].group;
            selected.iter().enumerate().any(|(j, o)| {
                j != *i
                    && !(group.is_some() && o.group == group)
                    && names
                        .iter()
                        .any(|name| count_var_refs(&o.replacement, name) > 0)
            })
        })
        .map(|(i, _)| *i)
        .collect();
    let dropped_groups: std::collections::HashSet<u32> =
        drop.iter().filter_map(|i| selected[*i].group).collect();
    if !dropped_groups.is_empty() {
        drop.extend(
            selected
                .iter()
                .enumerate()
                .filter(|(_, o)| o.group.is_some_and(|g| dropped_groups.contains(&g)))
                .map(|(i, _)| i),
        );
    }
    drop.sort_unstable();
    drop.dedup();
    for idx in drop.into_iter().rev() {
        selected.remove(idx);
    }
}

/// Whether `code` is a *direct* constant-propagation rewrite — a `$var`
/// substituted by its value (O100) or forwarded from its reaching def (O102).
///
/// Deliberately excludes the expr / proc *folds* (O101 / O103): those consume
/// a `$var` inside a `[expr …]` / `[proc …]` that collapses to a literal,
/// which makes the feeding def merely *unused* rather than *propagated*. At
/// the top level the optimiser keeps such a def (the conservative O126 "maybe a
/// global" case — `set a 3; puts [expr {$a + 1}]` keeps `set a 3`), and inside
/// a proc the ordinary dead-store pass removes it. Counting the fold here
/// would wrongly couple-remove the top-level def.
fn is_propagation_code(code: DiagCode) -> bool {
    matches!(code, DiagCode::O100 | DiagCode::O102)
}

/// How many `$var` / `${var}` references `opt` consumed — present in its
/// original source span but gone from its replacement. Counted (not just
/// detected) so one string rewrite that folds several `$var` occurrences is
/// tallied correctly.
fn consumed_var_count(opt: &Optimisation, source: &str, var: &str) -> usize {
    let (s, e) = (opt.span.start() as usize, opt.span.end() as usize);
    if s >= e || e > source.len() {
        return 0;
    }
    let before = count_var_refs(&source[s..e], var);
    let after = count_var_refs(&opt.replacement, var);
    before.saturating_sub(after)
}

/// Couple constant propagation with dead-store removal — see the call site in
/// [`optimise_unit`]. For each single-def constant scalar variable whose every
/// use was propagated by a surviving rewrite, append an `O109` removal of the
/// defining `set`. Conservative on every axis: a single safe-to-delete
/// constant def, all uses simple `Operand` reads each covered by a surviving
/// propagation that consumed the `$var`, no aliasing / RMW-hidden / global /
/// array involvement, the textual `$var` count equal to the use count (no
/// untracked reference), and the removal span free of overlap with any selected
/// rewrite. iRules dialects are skipped (cross-event variable lifetimes need
/// the connection-scope model, out of scope here).
fn couple_propagated_const_dead_stores(
    cu: &CompilationUnit,
    registry: &CommandRegistry,
    dialect: Option<&'static tcl_dialect::DialectProfile>,
    selected: &mut Vec<Optimisation>,
) {
    if crate::taint::is_irules_dialect(dialect) {
        return;
    }
    // Whole-module variable-trace facts: a dynamic trace
    // target makes every name potentially traced, so no propagated const
    // def is provably dead anywhere in the module.
    if cu.ir_module.has_dynamic_variable_trace {
        return;
    }
    let source = &cu.source;
    let mut functions: Vec<&crate::compilation_unit::FunctionUnit> = vec![&cu.top_level];
    functions.extend(cu.procedures.values());
    functions.extend(cu.methods.values());

    let mut removals: Vec<Optimisation> = Vec::new();
    for fu in functions {
        // Skip a function the complexity guard excluded from deep analysis:
        // its lattices are trivial, so const/dead-store coupling has nothing
        // sound to act on.
        if fu.complexity_guarded || fu.cfg.has_opaque_native_accesses() {
            continue;
        }
        couple_const_dead_stores_in_function(
            fu,
            &cu.ir_module,
            registry,
            source,
            selected,
            &cu.ir_module.traced_variables,
            &mut removals,
        );
    }

    // Append each removal, reconciling it against the already-selected
    // rewrites. The def line is disjoint from the use propagations (those land
    // at the use sites on other lines), but a rewrite *inside* the def line —
    // the O101 expr-fold of `set x [expr {1+1}]`, or an O100/O102 inside the
    // RHS — is fully contained in the line being deleted, so the deletion
    // supersedes it: drop those and emit the removal. A rewrite that only
    // *partially* overlaps the line (a structural O112 spanning past it) is
    // left intact and the removal skipped.
    for rem in removals {
        let contains =
            |o: &Optimisation| rem.span.start() <= o.span.start() && o.span.end() <= rem.span.end();
        let partial_overlap = selected.iter().any(|o| {
            !o.hint_only
                && rem.span.start() < o.span.end()
                && o.span.start() < rem.span.end()
                && !contains(o)
        });
        if partial_overlap {
            continue;
        }
        selected.retain(|o| o.hint_only || !contains(o));
        selected.push(rem);
    }
}

/// Per-function read-only state for the const-dead-store coupling check,
/// borrowed across each def-use chain.
struct CoupleCtx<'a> {
    fu: &'a crate::compilation_unit::FunctionUnit,
    module: &'a crate::ir::Module,
    registry: &'a CommandRegistry,
    source: &'a str,
    selected: &'a [Optimisation],
    def_count: std::collections::HashMap<&'a str, usize>,
    scope_aliases: std::collections::HashSet<String>,
    rmw_hidden: std::collections::HashSet<String>,
    /// [`crate::ir::Module::traced_variables`] — canonical (`::`-stripped)
    /// names under an active variable trace anywhere in the module.
    traced: &'a std::collections::BTreeSet<String>,
}

fn couple_const_dead_stores_in_function(
    fu: &crate::compilation_unit::FunctionUnit,
    module: &crate::ir::Module,
    registry: &CommandRegistry,
    source: &str,
    selected: &[Optimisation],
    traced: &std::collections::BTreeSet<String>,
    removals: &mut Vec<Optimisation>,
) {
    use crate::def_use::DefKind;

    let Some(metadata) = fu.invocation_metadata_context_for_module(registry, module) else {
        return;
    };
    // Per-variable def count — only single-def scalars qualify.
    let mut def_count: std::collections::HashMap<&str, usize> = std::collections::HashMap::new();
    for chain in fu.def_use.chains.values() {
        if chain.definition.kind == DefKind::Statement
            && let Some(symbol) = fu.def_use.symbol(&fu.ssa, chain.key.0)
        {
            *def_count.entry(fu.ssa.var_name(symbol)).or_insert(0) += 1;
        }
    }

    let ctx = CoupleCtx {
        fu,
        module,
        registry,
        source,
        selected,
        def_count,
        scope_aliases: super::elimination::scan_scope_aliases_with_metadata_context(
            &fu.cfg,
            registry,
            Some(metadata),
        ),
        rmw_hidden: super::elimination::collect_rmw_hidden_reads(fu, registry),
        traced,
    };

    for chain in fu.def_use.chains.values() {
        if let Some(removal) = couple_const_dead_store_chain(&ctx, chain) {
            removals.push(removal);
        }
    }
}

/// Decide whether one def-use `chain` is a const dead store fully consumed by
/// propagation, returning the O109 removal to emit when so. Extracted from
/// [`couple_const_dead_stores_in_function`].
fn couple_const_dead_store_chain(
    ctx: &CoupleCtx<'_>,
    chain: &crate::def_use::DefUseChain,
) -> Option<Optimisation> {
    use crate::analyses::LatticeValue;
    use crate::def_use::{DefKind, UseKind};

    let CoupleCtx {
        fu,
        module,
        registry,
        source,
        selected,
        def_count,
        scope_aliases,
        rmw_hidden,
        traced,
    } = ctx;

    if chain.definition.kind != DefKind::Statement {
        return None;
    }
    let symbol = fu.def_use.symbol(&fu.ssa, chain.key.0)?;
    let var = fu.ssa.var_name(symbol);
    // Single constant scalar def, never aliased / global / RMW-hidden /
    // traced. The whole-module trace fact stores the canonical
    // (`::`-stripped) spelling, so an unqualified store still
    // matches a `trace add variable ::var …` installed anywhere.
    if def_count.get(var).copied().unwrap_or(0) != 1 {
        return None;
    }
    if var.starts_with("::")
        || super::elimination::store_is_seen_elsewhere(fu, chain, scope_aliases)
        || rmw_hidden.contains(var)
        || crate::variable_observation_names::variable_name_may_be_observed(
            *traced,
            var,
            false,
            crate::variable_observation_names::VariableProtectionPurpose::ModuleObservation,
        )
    {
        return None;
    }
    // The chain retains cell identity; display names are only used by the
    // textual coupling guards above and below.
    let is_const = fu
        .sccp
        .values
        .get(&(symbol, chain.key.1))
        .is_some_and(|lv| matches!(lv, LatticeValue::Const(_)));
    if !is_const {
        return None;
    }
    // Any def-tracked use must be a simple operand read — a phi/terminator
    // use means the value flows somewhere a textual `$var` scan can't see,
    // so bail conservatively.
    if chain
        .uses
        .iter()
        .any(|u| !matches!(u.kind, UseKind::Operand))
    {
        return None;
    }
    let def_block_id = fu.cfg.block_id(&chain.definition.block)?;
    let def_block = fu.cfg.blocks.get(&def_block_id)?;
    let def_idx = usize::try_from(chain.definition.statement_index).ok()?;
    fu.cfg
        .statement_source_edit_span(fu.cfg.block_id(&chain.definition.block)?, def_idx)?;
    let def_stmt = def_block.statements.get(def_idx)?;
    // A statement the solver proved raises keeps its raise, and a definition
    // a raise preserved holds the value before it, not one the statement
    // computed: neither is a constant store to remove.
    let preserved = fu.sccp.preserved.contains_key(&(symbol, chain.key.1));
    if preserved || fu.sccp.raised.contains(&(def_block_id, def_idx)) {
        return None;
    }
    // The def must be a const-foldable scalar assignment whose inlined
    // value carries no substitution metacharacters. Two shapes qualify:
    //
    //   * `set x <literal>` (`AssignConst`) inlines its literal verbatim.
    //   * `set x [expr {1+1}]` (`AssignExpr` / `AssignValue`) was proven
    //     `Const` by SCCP above, so O100 substituted the *rendered
    //     constant* (`2`), not the original expression text. These are
    //     removed too once the fold and propagation are applied.
    //
    // Either way reject a value bearing `$ [ ] \`: it could re-substitute
    // differently once inlined, so those are left to the conservative path.
    let inlined_value = match def_stmt {
        crate::ir::Statement::AssignConst { value, .. } => value.clone(),
        crate::ir::Statement::AssignExpr { .. } | crate::ir::Statement::AssignValue { .. } => {
            let Some(LatticeValue::Const(c)) = fu.sccp.values.get(&(symbol, chain.key.1)) else {
                return None;
            };
            super::helpers::literals::format_constant_with_policy(
                c,
                crate::tcl_expr_eval::FoldPolicy::from_registry(registry),
            )?
        }
        _ => return None,
    };
    if inlined_value.contains(['$', '[', ']', '\\']) {
        return None;
    }
    // Pure constant assignment — removing it loses no observable effect.
    let purity = super::elimination::PurityCtx {
        registry: Some(registry),
        interproc_pure: &std::collections::HashSet::<crate::ir::ProcedureId>::new(),
        config: fu.source_lexer_config(),
        metadata: fu.invocation_metadata_context_for_module(registry, module),
        module: Some(module),
    };
    let block = fu.cfg.block_id(&chain.definition.block)?;
    let index = usize::try_from(chain.definition.statement_index).ok()?;
    if !super::elimination::assignment_safe_to_delete_at(fu, block, index, purity) {
        return None;
    }

    if !every_reference_propagated(fu, source, selected, var) {
        return None;
    }

    // Approach B: `def_stmt` is from `fu.cfg` (relative to `base_offset`).
    // Widen past the inner-end convention before deleting: a value word that
    // is quoted, braced, or bracketed leaves its closer outside the statement
    // Widen past the inner-end convention before taking the line: a quoted
    // value word leaves its closer outside the statement span, and a deletion
    // that stops short of it strands the closer on a line of its own.
    let written = full_rewrite_span(source, fu.abs_span(def_stmt.source_edit_span()?));
    let del_span = line_delete_span(source, written);
    Some(Optimisation::new(
        DiagCode::O109,
        "Eliminate dead store",
        del_span,
        "",
    ))
}

/// Textual coupling check (robust to def-use gaps such as
/// string-interpolation reads): count `$var` references across the
/// function, then count how many a *surviving* propagation actually
/// consumed. The def is removable only when at least one reference existed
/// and **every** reference was propagated away. A braced literal `{$var}`
/// (no substitution) or an array `$var(i)` read is counted but never
/// consumed, so the counts diverge and the def is kept — conservative and
/// safe. Extracted from [`couple_const_dead_store_chain`].
fn every_reference_propagated(
    fu: &crate::compilation_unit::FunctionUnit,
    source: &str,
    selected: &[Optimisation],
    var: &str,
) -> bool {
    let (fs, fe) = function_source_span(fu);
    if fs >= fe || fe > source.len() {
        return false;
    }
    let func_src = &source[fs..fe];
    let total_refs = count_var_refs(func_src, var);
    if total_refs == 0 {
        // Never read (or read only in a non-substituting form) — the
        // existing unused-variable pass owns this; not a propagation
        // coupling.
        return false;
    }
    // Miscompilation guard: the variable name must appear as a *bareword*
    // exactly once — the def target. Any other bareword occurrence is a
    // by-name read the `$var` scan can't see (`[set x]`, `info exists x`,
    // `upvar … x`, a `"…x…"` literal, …); removing the def would then drop a
    // value still consumed. Conservative: a stray textual `x` keeps the def.
    if bareword_occurrences(func_src, var) != 1 {
        return false;
    }
    // Attribute a propagation to this function by its *start* offset —
    // a rewrite never spans two functions, and a word-token's span may
    // run one past `fe` (the inner-end convention leaves the closing
    // delimiter outside the statement span).
    let consumed: usize = selected
        .iter()
        .filter(|o| {
            !o.hint_only
                && is_propagation_code(o.code)
                && (o.span.start() as usize) >= fs
                && (o.span.start() as usize) <= fe
        })
        .map(|o| consumed_var_count(o, source, var))
        .sum();
    consumed == total_refs
}

/// Source byte range spanning every statement of `fu` (for textual reference
/// counting). Falls back to an empty range when the function has no spans.
fn function_source_span(fu: &crate::compilation_unit::FunctionUnit) -> (usize, usize) {
    let mut lo = u32::MAX;
    let mut hi = 0u32;
    for block in fu.cfg.blocks.values() {
        for stmt in &block.statements {
            let sp = stmt.span();
            if sp.start() < lo {
                lo = sp.start();
            }
            if sp.end() > hi {
                hi = sp.end();
            }
        }
        if let Some(t) = block
            .terminator
            .as_ref()
            .and_then(crate::cfg::Terminator::span)
        {
            if t.start() < lo {
                lo = t.start();
            }
            if t.end() > hi {
                hi = t.end();
            }
        }
    }
    if lo == u32::MAX {
        (0, 0)
    } else {
        // Approach B: `fu`'s CFG spans are relative to its `base_offset`; return
        // absolute positions so the `source[fs..fe]` slice and the comparison
        // against (absolute) emitted optimisation spans are correct on the
        // memoised offset-0 path.
        (fu.abs_pos(lo) as usize, fu.abs_pos(hi) as usize)
    }
}

/// Canonicalise group ids in-place to `0, 1, 2, …` by order of first appearance.
///
/// Group ids are allocated by a monotonic counter during pass execution, so
/// their absolute values depend on the (`HashMap`-iteration) order in which
/// grouped rewrites were emitted.  Only the *partition* they encode is
/// semantically meaningful (members of one group apply all-or-nothing), so
/// remapping each distinct id to a first-appearance index makes the values
/// deterministic while preserving the partition.  `opts` is assumed already in
/// canonical order.
fn renumber_groups(opts: &mut [Optimisation]) {
    use std::collections::HashMap;
    let mut remap: HashMap<u32, u32> = HashMap::new();
    let mut next = 0u32;
    for o in opts.iter_mut() {
        if let Some(g) = o.group {
            let new = *remap.entry(g).or_insert_with(|| {
                let v = next;
                next += 1;
                v
            });
            o.group = Some(new);
        }
    }
}

/// Run every pass over `cu` and return the **O109 dead stores** the
/// elimination pass determined eliminable (each keyed by function / block /
/// statement / SSA value). Mirrors [`optimise_unit`] but exposes the
/// structured dead-store records ([`PassContext::dead_stores`]) instead of
/// the optimisation list — so tools (the compiler explorer's `cfgPostSsa`
/// analysis, dead-store callouts, and `stats`) can show dead stores from
/// where Rust actually computes them, with the optimiser's full suppression
/// applied (purity, scope aliases, place model, cross-event scope).
#[must_use]
pub fn find_dead_stores(
    cu: &CompilationUnit,
    registry: &CommandRegistry,
    dialect: Option<&'static tcl_dialect::DialectProfile>,
) -> Vec<DeadStore> {
    let mut ctx = build_pass_context(cu, registry, dialect);
    run_passes(&mut ctx, cu, &PassId::all());
    ctx.dead_stores
}

/// Run the passes one at a time over a shared context and return, for each
/// [`PassId`] in [`PassId::all`] order, the optimisations *that pass*
/// produced (raw, before overlap arbitration). Powers the explorer's
/// "optimiser pass pipeline" view onto this pass sequence.
///
/// Equivalent to [`optimise_unit`] in effect (each pass sees the prior
/// passes' context), but it attributes every finding to its originating pass.
#[must_use]
pub fn optimise_by_pass(
    cu: &CompilationUnit,
    registry: &CommandRegistry,
    dialect: Option<&'static tcl_dialect::DialectProfile>,
) -> Vec<(PassId, Vec<Optimisation>)> {
    let mut ctx = build_pass_context(cu, registry, dialect);
    let mut by_pass = Vec::new();
    for pass in PassId::all() {
        let before = ctx.optimisations.len();
        run_passes(&mut ctx, cu, &[pass]);
        by_pass.push((pass, ctx.optimisations[before..].to_vec()));
    }
    by_pass
}

/// Compatibility entry point for test and external dialect-name callers.
///
/// Typed callers should use [`optimise_raw_for_profile`].
#[must_use]
pub fn optimise_raw(
    source: &str,
    registry: &CommandRegistry,
    dialect: Option<&str>,
) -> Vec<Optimisation> {
    optimise_raw_for_profile(
        source,
        registry,
        dialect
            .map(|name| crate::environment_ingress::resolve_environment(name).analyser_profile()),
    )
}

/// Build, run every pass, and return the full *unfiltered* optimisation list
/// (no overlap resolution) under an already-resolved profile. Exposed mainly
/// for tests that inspect raw per-pass output before manager arbitration.
#[must_use]
pub fn optimise_raw_for_profile(
    source: &str,
    registry: &CommandRegistry,
    dialect: Option<&'static tcl_dialect::DialectProfile>,
) -> Vec<Optimisation> {
    // Split the raw CU build to avoid `with_interprocedural`'s taint
    // re-run (irrelevant for `optimise_raw`'s test callers) — but `cu.interproc`
    // is still populated (`try_fold_static_proc_call` / `try_o103_proc_fold`
    // in `propagation` read it directly, the same field `optimise_unit_raw`'s
    // production callers populate via `with_interprocedural`), so an O103
    // interprocedural fold behaves identically whether exercised through this
    // helper or the real pipeline.
    let mut cu = dialect.map_or_else(
        || CompilationUnit::build_for(source, registry, false),
        |profile| CompilationUnit::build_for_profile(source, registry, false, profile),
    );
    let object_types = crate::object_types::object_handle_classes(&cu, registry);
    let Some(identities) =
        crate::realm::document_realm_bindings_for_module(&cu.ir_module, registry)
    else {
        return Vec::new();
    };
    let ia = crate::interprocedural::build_interprocedural_analysis_for_unit(
        &cu,
        registry,
        dialect,
        crate::interprocedural::ObjectTypeCandidates::candidates(&object_types),
        &identities,
    );
    cu.interproc = Some(ia);
    let mut ctx = build_pass_context(&cu, registry, dialect);
    run_passes(&mut ctx, &cu, &PassId::all());
    ctx.optimisations
}

/// Apply the non-hint-only optimisation rewrites to `source`, returning the
/// rewritten text.  Edits are applied in reverse-offset order (so earlier
/// offsets stay valid) and deduplicated by `(offset, length)`.  Spans are
/// half-open `[start, end)`, so the byte range is `span.start()..span.end()`.
#[must_use]
pub fn apply_optimisations(source: &str, optimisations: &[Optimisation]) -> String {
    let mut edits: Vec<(usize, usize, &str)> = optimisations
        .iter()
        .filter(|o| !o.hint_only)
        .filter_map(|o| {
            let start = o.span.start() as usize;
            let end = o.span.end() as usize;
            (start <= end && end <= source.len()).then_some((
                start,
                end - start,
                o.replacement.as_str(),
            ))
        })
        .collect();
    if edits.is_empty() {
        return source.to_owned();
    }
    edits.sort_by_key(|e| std::cmp::Reverse(e.0));
    let mut seen: std::collections::HashSet<(usize, usize)> = std::collections::HashSet::new();
    let mut result = source.to_owned();
    for (offset, length, text) in edits {
        if !seen.insert((offset, length)) {
            continue;
        }
        if offset + length <= result.len() {
            result.replace_range(offset..offset + length, text);
        }
    }
    result
}

/// Iteratively optimise `source` until a fixpoint or `max_iterations` is
/// reached, skipping any optimisation whose code is in `disabled` (upper-cased
/// code strings) on **every** pass.
///
/// Returns `(final_source, applied_optimisations, iterations_used)` — the
/// iteration count is one per pass attempted, including the final pass that
/// finds nothing new. A single-pass profile is simply `max_iterations == 1`.
///
/// `tcl pkg discover` uses it; `tcl opt` runs `optimise_under_policy` instead.
#[must_use]
pub fn optimise_source_multipass_filtered<S: std::hash::BuildHasher>(
    source: &str,
    registry: &CommandRegistry,
    dialect: Option<&'static tcl_dialect::DialectProfile>,
    max_iterations: usize,
    disabled: &std::collections::HashSet<String, S>,
) -> (String, Vec<Optimisation>, usize) {
    optimise_source_multipass_admitting(source, registry, dialect, max_iterations, |_, kept| {
        kept.into_iter()
            .filter(|o| !disabled.contains(o.code.as_str()))
            .collect()
    })
}

/// The general form behind [`optimise_source_multipass_filtered`]: `admit`
/// decides, once per pass, which of that pass's candidates are applied.
///
/// It is handed the text the pass actually ran over, not the original source,
/// because a *line-keyed* rule cannot be resolved once up front. Suppression
/// directives (`# noqa`, `# tcl-lsp: disable=`) name a line, and every applied
/// rewrite shifts the lines below it — so a policy resolved against the
/// original numbering would, from the second pass on, silence the wrong
/// rewrites. Re-resolving per pass is what keeps a directive attached to the
/// statement its author wrote it above.
///
/// A code-keyed rule has no such problem, which is why the `disabled`-set
/// wrapper can ignore the text argument entirely.
#[must_use]
pub fn optimise_source_multipass_admitting<F>(
    source: &str,
    registry: &CommandRegistry,
    dialect: Option<&'static tcl_dialect::DialectProfile>,
    max_iterations: usize,
    admit: F,
) -> (String, Vec<Optimisation>, usize)
where
    F: FnMut(&str, Vec<Optimisation>) -> Vec<Optimisation>,
{
    optimise_source_multipass_using(
        source,
        max_iterations,
        |current| optimise_with_dialect(current, registry, dialect),
        admit,
    )
}

/// Rebuild each pass with the complete supplied editing input. Each source
/// image receives a new source-only entry; no Native entry crosses a rewrite.
/// Missing or foreign ownership returns the original text without candidates.
#[must_use]
pub fn optimise_source_multipass_admitting_with_analysis_input<F>(
    source: &str,
    registry: &CommandRegistry,
    input: Option<&crate::analyser::ResolvedAnalysisInput>,
    max_iterations: usize,
    admit: F,
) -> (String, Vec<Optimisation>, usize)
where
    F: FnMut(&str, Vec<Optimisation>) -> Vec<Optimisation>,
{
    let Some(input) = input.filter(|input| {
        crate::registry_invocation::InvocationMetadataContext::for_source_input(
            registry,
            input,
            input.lexer_config(),
            Some(input.unit_profile()),
        )
        .is_some()
    }) else {
        return (source.to_owned(), Vec::new(), 0);
    };
    optimise_source_multipass_using(
        source,
        max_iterations,
        |current| {
            let entry = crate::command_binding::SourceAnalysisEntry::for_supplied_source(
                registry,
                input,
                input.lexer_config(),
                Some(input.unit_profile()),
            );
            let declared = crate::analyser::utils::document_declared_surface(
                current,
                None,
                input.analyser_profile().name,
            );
            let unit = CompilationUnit::build_with_analysis_input(
                current,
                crate::compilation_unit::UnitBuildOptions {
                    registry,
                    defer_top_level: false,
                    config: input.lexer_config(),
                    dialect: Some(input.unit_profile()),
                    external_call_sites: None,
                    declared_commands: Some(&declared),
                },
                Some(&entry),
                input,
            )
            .with_interprocedural(registry, Some(input.unit_profile()));
            optimise_unit(&unit, registry, Some(input.unit_profile()))
        },
        admit,
    )
}

fn optimise_source_multipass_using<C, F>(
    source: &str,
    max_iterations: usize,
    mut candidates_for: C,
    mut admit: F,
) -> (String, Vec<Optimisation>, usize)
where
    C: FnMut(&str) -> Vec<Optimisation>,
    F: FnMut(&str, Vec<Optimisation>) -> Vec<Optimisation>,
{
    let mut current = source.to_owned();
    let mut all: Vec<Optimisation> = Vec::new();
    let mut iterations = 0;
    for _ in 0..max_iterations {
        iterations += 1;
        let candidates = candidates_for(&current);
        let kept = admit(&current, candidates);
        if kept.is_empty() {
            break;
        }
        let next = apply_optimisations(&current, &kept);
        all.extend(kept);
        if next == current {
            break;
        }
        current = next;
    }
    (current, all, iterations)
}

/// Iteratively optimise `source` until a fixpoint or `max_iterations` is
/// reached: each pass recompiles the rewritten source so optimisations
/// exposed by an earlier pass (constant folding enabling further folding /
/// dead-store removal) are discovered.  Returns `(final_source,
/// all_optimisations_applied)`.
#[must_use]
pub fn optimise_source_multipass(
    source: &str,
    registry: &CommandRegistry,
    dialect: Option<&'static tcl_dialect::DialectProfile>,
    max_iterations: usize,
) -> (String, Vec<Optimisation>) {
    let mut current = source.to_owned();
    let mut all: Vec<Optimisation> = Vec::new();
    for _ in 0..max_iterations {
        let opts = optimise_with_dialect(&current, registry, dialect);
        if opts.is_empty() {
            break;
        }
        let next = apply_optimisations(&current, &opts);
        all.extend(opts);
        if next == current {
            break;
        }
        current = next;
    }
    (current, all)
}

#[cfg(test)]
mod tests {
    use super::*;
    use tcl_lexer::Span;

    #[test]
    fn supplied_multipass_refreshes_conditional_candidates_for_each_source_image() {
        // naming.compiler.original-analysis-metadata-context
        // docs/design/analysis/name-resolution-proofs/original-analysis-metadata-context.md
        let context =
            crate::environment_ingress::resolve_environment("tcl8.6").default_context_registry();
        let registry = std::sync::Arc::clone(context.commands());
        let profile = tcl_dialect::DialectProfile::plain_tcl();
        let input = crate::analyser::ResolvedAnalysisInput::new(
            profile,
            profile,
            context,
            tcl_lexer::LexerConfig::for_profile(Some(profile)),
        );
        // O112 removes the whole constant branch; O100 substitutes variable
        // constants within a surviving expression. This test keeps the actual
        // applied rewrite and its newly analysed source image non-vacuous.
        let source = "proc subject {} {if {1} {puts retained} else {puts omitted}}";
        let mut images = Vec::new();
        let mut branch_candidates = Vec::new();
        let (text, applied, iterations) = optimise_source_multipass_admitting_with_analysis_input(
            source,
            &registry,
            Some(&input),
            3,
            |current, candidates| {
                images.push(current.to_owned());
                branch_candidates.push(
                    candidates
                        .iter()
                        .filter(|row| row.code == DiagCode::O112)
                        .count(),
                );
                candidates
                    .into_iter()
                    .filter(|row| row.code == DiagCode::O112)
                    .collect()
            },
        );
        assert!(applied.iter().any(|row| row.code == DiagCode::O112));
        assert!(iterations >= 2);
        assert_ne!(images[0], images[1]);
        assert_eq!(images.last().unwrap(), &text);
        assert!(branch_candidates[0] > 0);
        assert_eq!(
            branch_candidates[1], 0,
            "the rewritten image must not reuse the old branch candidate"
        );
        assert!(text.contains("retained"));
        assert!(!text.contains("omitted"));
        let missing = optimise_source_multipass_admitting_with_analysis_input(
            source,
            &registry,
            None,
            3,
            |_, _| panic!("missing supplied input must not enter the rewrite loop"),
        );
        assert_eq!(missing, (source.to_owned(), Vec::new(), 0));
    }

    fn registry() -> CommandRegistry {
        // `when` is registry-resolved (no
        // string-pattern fallback in `lower_command`), so any
        // test that lowers iRule code through `optimise_*` must
        // carry the iRules dialect.  Loading it here keeps the
        // helper a one-call site; tests that only lower plain
        // Tcl don't notice the extra commands.
        let mut r = CommandRegistry::build_default();
        r.load_irules();
        r
    }

    #[test]
    fn empty_source_yields_empty_result() {
        let opts = optimise("", &registry());
        assert_eq!(opts, [] as [crate::optimiser::Optimisation; 0]);
    }

    #[test]
    fn cross_event_vars_reach_code_sinking_before_elimination() {
        let source = "when HTTP_REQUEST {\n    if {$cond} { set n 1 } else { set n 2 }\n    set flag $n\n    if {$n > 1} { log local0. $flag }\n}\nwhen HTTP_RESPONSE { log local0. $flag }\n";
        let opts = optimise_with_dialect(
            source,
            &registry(),
            Some(tcl_dialect::DialectProfile::irules()),
        );
        assert!(
            opts.iter().all(|opt| {
                opt.code != DiagCode::O125
                    || !source[opt.span.start() as usize..opt.span.end() as usize]
                        .contains("set flag")
            }),
            "cross-event assignment must not be sunk before elimination: {opts:?}"
        );
    }

    /// Every optimiser pass
    /// (`propagation`, `expr_simplify`, `pattern_recognition`,
    /// `structure_elimination`, `code_sinking`) walks `Script`/`Statement`
    /// bodies recursively and is now depth-capped
    /// (`super::MAX_OPTIMISER_WALK_DEPTH`). In this end-to-end pipeline
    /// `lowering`'s own cap (`MAX_LOWER_NEST_DEPTH`, matching value) is the
    /// first line of defence — it truncates source nesting before the
    /// optimiser passes ever see it — so this asserts the *whole pipeline*
    /// survives deep nesting rather than isolating the optimiser-level caps
    /// specifically (those are unit-verified by construction: every
    /// recursive call site threads `depth + 1`, matching the pattern
    /// already proven in `lowering`/`param_traits`).
    ///
    /// `tcl-compiler` is a library — it does not own the stack its callers
    /// run it on. Every real consumer (`tcl-lsp-server`/`tcl-mcp`/the `tcl`
    /// CLI/`f5-cli`/`tcl-debugger`) already wraps calls into it with a
    /// dedicated 64 MiB thread; `cargo test`'s
    /// bare ~2 MiB per-test default is not representative of that and is
    /// not the depth caps' design target — they bound *frame count*, not
    /// the stack cost of each frame (see `docs/design/compiler/
    /// recursive-descent-depth-limits.md`). So this spawns its own
    /// production-sized thread rather than asserting on the test harness's
    /// thread directly.
    #[test]
    fn deeply_nested_if_survives_full_optimiser_pipeline() {
        const DEPTH: usize = 400;
        const STACK_SIZE: usize = 64 * 1024 * 1024;
        let mut src = String::new();
        for _ in 0..DEPTH {
            src.push_str("if {1} {\n");
        }
        src.push_str("set done 1\n");
        for _ in 0..DEPTH {
            src.push_str("}\n");
        }
        // The assertion is that this returns at all, not what it returns.
        std::thread::Builder::new()
            .stack_size(STACK_SIZE)
            .spawn(move || {
                let _ = optimise(&src, &registry());
            })
            .unwrap()
            .join()
            .unwrap();
    }

    fn optimised(src: &str) -> String {
        let opts = optimise(src, &registry());
        apply_optimisations(src, &opts)
    }

    #[test]
    fn constant_loop_condition_fold_keeps_braces() {
        // A constant `while` condition folded through O101 must not drop the
        // opening brace of the braced condition: the CFG loop-condition span
        // omits the closing `}`, so a naive rewrite yields `while 1}`.
        // `while {1}` is already minimal → unchanged; `while {1 < 2}` folds
        // to `while {1}` (braces preserved).
        assert_eq!(optimised("while {1} { break }\n"), "while {1} { break }\n");
        assert_eq!(
            optimised("while {1 < 2} { break }\n"),
            "while {1} { break }\n"
        );
    }

    #[test]
    fn call_by_name_in_namespace_keeps_feeding_set() {
        // A `proc` declared inside a namespaced proc is registered under its
        // qualified name (`::demo::bump`); a same-namespace bare call
        // (`bump x`) must still resolve to it so the call-by-name `upvar`
        // read keeps the feeding `set x 10` alive. Regression for an
        // over-removal that produced a dangling `$x` reference.
        let src = "namespace eval ::demo {\n    \
                   proc upvarDemo {} {\n        set x 10\n        \
                   proc bump {varName} { upvar 1 $varName v; incr v; return $v }\n        \
                   set y [bump x]\n        return $x\n    }\n}\n";
        assert!(
            optimised(src).contains("set x 10"),
            "call-by-name read must keep `set x 10`; got {:?}",
            optimised(src),
        );
    }

    #[test]
    fn couples_constant_propagation_with_dead_store_removal() {
        // The propagated constant leaves `set x 42` dead — it is removed.
        assert_eq!(optimised("set x 42\nputs $x\n"), "puts 42\n");
        // String-interpolation reads are covered too (the textual scan does
        // not rely on def-use tracking the in-string `$x`).
        assert_eq!(
            optimised("proc f {} {\n  set x 42\n  puts \"v $x\"\n}\n"),
            "proc f {} {\n  puts \"v 42\"\n}\n",
        );
    }

    #[test]
    fn couples_sccp_const_expr_dead_store_removal() {
        // `set x [expr {1+1}]` folds to a constant SCCP proves; once its only
        // use is propagated the computed def is dead — removed. The O101
        // expr-fold inside the def line is superseded by the line deletion.
        assert_eq!(optimised("set x [expr {1+1}]\nputs $x\n"), "puts 2\n");
        // The quoted-expr form folds the same way — it is removed too.
        assert_eq!(optimised("set x [expr \"1+1\"]\nputs $x\n"), "puts 2\n");
        // Inside a proc, with a string-interpolation read.
        assert_eq!(
            optimised("proc p {} {\n  set x [expr {1+1}]\n  puts \"v=$x\"\n}\n"),
            "proc p {} {\n  puts \"v=2\"\n}\n",
        );
    }

    #[test]
    fn coupling_keeps_non_const_expr_def() {
        // A computed assignment SCCP cannot prove constant (a runtime command)
        // is never coupled away.
        let kept = optimised("set x [expr {[clock seconds]}]\nputs $x\n");
        assert!(
            kept.contains("set x [expr"),
            "non-const expr def must be kept; got {kept:?}",
        );
    }

    #[test]
    fn coupling_keeps_defs_it_cannot_prove_dead() {
        // Never read at top level → kept (the unused-variable pass owns the
        // proc case; a top-level const may be an externally-consumed global).
        assert_eq!(
            optimised("set x 42\nputs hello\n"),
            "set x 42\nputs hello\n"
        );
        // Read by name, not via `$x` — `[set x]` still needs the value.
        let by_name = optimised("proc f {} {\n  set x 42\n  puts [set x]\n}\n");
        assert!(
            by_name.contains("set x 42"),
            "by-name read must keep the def; got {by_name:?}",
        );
        // A value carrying substitution metacharacters is never coupled.
        let meta = optimised("set e {$y [k]}\ncatch {subst $e}\n");
        assert!(
            meta.contains("set e "),
            "metacharacter-bearing const must keep its def; got {meta:?}",
        );
    }

    #[test]
    fn coupling_sees_through_literal_name_in_strings() {
        // The variable name appearing as literal text inside a string
        // (`"x=$x"`) is not a by-name read — the def is still removable when
        // every real `$x` reference is propagated.
        assert_eq!(
            optimised("set x 1\nset y 2\nputs \"x=$x y=$y\"\n"),
            "puts \"x=1 y=2\"\n",
        );
    }

    #[test]
    fn braced_word_is_never_propagated() {
        // Tcl performs no substitution inside `{…}`, so `$x` in a braced word
        // is a literal — it must not be propagated, and the def stays live.
        assert_eq!(
            optimised("set x 42\nputs {$x}\nputs $x\n"),
            "set x 42\nputs {$x}\nputs 42\n",
        );
    }

    #[test]
    fn read_modify_write_target_keeps_feeding_set() {
        // `lset` / `lpop` read the list before rewriting it, so the feeding
        // `set` is live — not a dead store.
        for src in [
            "set lst {a b c d e}\nlset lst 2 X\nputs $lst\n",
            "set lst {1 2 3}\nlpop lst\nputs $lst\n",
        ] {
            assert!(
                optimised(src).contains("set lst"),
                "RMW target's feeding set must be kept; got {:?}",
                optimised(src),
            );
        }
    }

    #[test]
    fn constant_branch_fires_via_manager() {
        // if {1} { set x 1 } triggers both O101 (branch fold)
        // and O112 (structure elimination). The overlap filter
        // prefers the higher-priority O112 (priority 9) over
        // O101 (priority 1), so the manager's output should
        // contain O112 in this shape.
        let opts = optimise("if {1} { set x 1 } else { set y 2 }", &registry());
        assert!(
            opts.iter()
                .any(|o| o.code == DiagCode::O112 || o.code == DiagCode::O101),
            "expected at least one branch-related rewrite, got {opts:?}",
        );
    }

    fn native_existence_optimisations(source: &str) -> Vec<Optimisation> {
        let profile = tcl_dialect::DialectProfile::find("tcl8.6").unwrap();
        let registry = tcl_registry::model::ingress::static_context_for_profile(profile).commands();
        let capture = crate::environment_ingress::captured_native_entry(profile);
        let entry = crate::command_binding::SourceAnalysisEntry {
            native_entry: Some(std::sync::Arc::new(capture.as_entry().clone())),
            invocation_dialect: Some(tcl_registry::InvocationDialect::of_profile(profile)),
            native_compilation: tcl_registry::native_compilation::NativeCompilationContext {
                mode: tcl_registry::native_compilation::NativeCompilationMode::Direct,
                ..Default::default()
            },
            ..crate::command_binding::SourceAnalysisEntry::default()
        };
        let unit = CompilationUnit::build_with_source_entry(
            source,
            crate::compilation_unit::UnitBuildOptions {
                registry,
                defer_top_level: false,
                config: tcl_lexer::LexerConfig::from_grammar(profile.grammar),
                dialect: Some(profile),
                external_call_sites: None,
                declared_commands: None,
            },
            &entry,
        );
        optimise_unit(&unit, registry, Some(profile))
    }

    #[test]
    fn info_exists_fold_surfaces_o101() {
        // A provably-constant `info exists`
        // guard (never-defined non-param folds false; a parameter folds
        // true) surfaces as an O101 constant-branch fold.
        let never = native_existence_optimisations(
            "proc f {a} { if {[info exists b]} { puts hi } }; f VALUE",
        );
        assert!(
            never
                .iter()
                .any(|o| o.code == DiagCode::O101 && o.replacement == "{0}"),
            "never-defined `info exists` should fold to {{0}}, got {never:?}",
        );
        let param = native_existence_optimisations(
            "proc f {a} { if {[info exists a]} { puts hi } }; f VALUE",
        );
        assert!(
            param
                .iter()
                .any(|o| o.code == DiagCode::O101 && o.replacement == "{1}"),
            "parameter `info exists` should fold to {{1}}, got {param:?}",
        );
    }

    #[test]
    fn info_exists_rewrite_requires_actual_selected_entry() {
        let declaration = "proc f {a} {if {[info exists a]} {puts hi}}";
        let profile = tcl_dialect::DialectProfile::find("tcl8.6").unwrap();
        let registry = tcl_registry::model::ingress::static_context_for_profile(profile).commands();
        let unknown = crate::command_binding::SourceAnalysisEntry {
            unknown_entry: true,
            invocation_dialect: Some(tcl_registry::InvocationDialect::of_profile(profile)),
            ..Default::default()
        };
        let unit = CompilationUnit::build_with_source_entry(
            &format!("{declaration}; f VALUE"),
            crate::compilation_unit::UnitBuildOptions {
                registry,
                defer_top_level: false,
                config: tcl_lexer::LexerConfig::from_grammar(profile.grammar),
                dialect: Some(profile),
                external_call_sites: None,
                declared_commands: None,
            },
            &unknown,
        );
        assert!(
            optimise_unit(&unit, registry, Some(profile))
                .iter()
                .all(|rewrite| rewrite.code != DiagCode::O101)
        );
        for source in [
            declaration.to_owned(),
            format!("rename info {{}}; proc info args {{return UNKNOWN}}; {declaration}; f VALUE"),
            format!("{declaration}; mystery; f VALUE"),
        ] {
            assert!(
                native_existence_optimisations(&source)
                    .iter()
                    .all(|rewrite| rewrite.code != DiagCode::O101),
                "unentered or unselected existence query: {source}"
            );
        }
    }

    #[test]
    fn output_is_sorted_by_span_start() {
        let opts = optimise("set x 5\nif {1} { puts $x } else { puts 0 }", &registry());
        let mut prev = 0u32;
        for o in &opts {
            assert!(
                o.span.start() >= prev,
                "manager output must be sorted by span start: got {} after {}",
                o.span.start(),
                prev,
            );
            prev = o.span.start();
        }
    }

    #[test]
    fn overlap_filter_runs() {
        // The manager applies select_non_overlapping, so duplicate
        // / overlapping rewrites must not appear in the output
        // — exercise by checking that no two rewrites share the
        // exact same span.
        let opts = optimise("if {1} { set x 1 } else { set y 2 }", &registry());
        let spans: Vec<_> = opts.iter().map(|o| o.span).collect();
        let mut unique = spans.clone();
        unique.sort_by_key(|s| (s.start(), s.end()));
        unique.dedup();
        assert_eq!(
            spans.len(),
            unique.len(),
            "manager must deduplicate overlapping rewrites",
        );
    }

    #[test]
    fn optimise_raw_skips_overlap_filter() {
        // Raw output can contain overlapping rewrites that the
        // filtered path would dedupe — the `raw` entry point is
        // the escape hatch that leaves them visible.
        let raw = optimise_raw("if {1} { set x 1 } else { set y 2 }", &registry(), None);
        // Presence alone is the contract.
        let _ = raw;
    }

    #[test]
    fn tcloo_method_bodies_get_zero_o100_family_optimisations() {
        // Coverage gap, not a bug: `branch_folding::run` walks
        // `cu.analysable_functions()` and `propagation::run` walks
        // `cu.top_level` + `cu.procedures` directly — neither visits
        // `cu.methods`. So today the O100/O101/O102/O103
        // constant-propagation and branch-folding family never fires inside
        // a TclOO method body, even for a body this trivially foldable.
        // Contrast with O109 (dead-store elimination, `elimination.rs`),
        // which explicitly iterates `cu.methods` with its own
        // instance-variable escaping rules. This test locks in the
        // *current* behaviour so a future change that starts analysing
        // method bodies is a deliberate, reviewed decision — not an
        // accidental regression noticed only via a diff in generated
        // diagnostics.
        let src = "oo::class create Counter {\n    \
                   method bump {} {\n        set n 5\n        return $n\n    }\n}\n";
        let opts = optimise(src, &registry());
        assert!(
            opts.iter().all(|o| !matches!(
                o.code,
                DiagCode::O100 | DiagCode::O101 | DiagCode::O102 | DiagCode::O103
            )),
            "TclOO method bodies are not yet analysed by the O100 family, got {opts:?}",
        );
    }

    #[test]
    fn interp_eval_barrier_body_never_gets_o100_family_diagnostics() {
        // True negative, by design rather than by soundness gap: a literal
        // `interp eval {} {…}` body lowers its whole argument list to a
        // single opaque `Statement::Barrier` (`command`/`args`/`tokens`
        // only — see `ir.rs::Statement::Barrier`), never a nested `Script`.
        // There is nothing for any pass's recursive statement walk to
        // descend into, so an obviously-foldable expression written
        // *inside* that literal body (`expr {1+1}`) never gets an O101
        // constant-expr-fold diagnostic — `interp eval`'s body text is
        // opaque to every static-analysis pass, exactly like a bare
        // `eval`/`uplevel`/`unknown` body with a non-trivial target. This
        // locks in that "no diagnostic" here is the *expected* shape, not
        // an unnoticed hole.
        let src = "interp eval {} { set x [expr {1+1}] }\n";
        let opts = optimise(src, &registry());
        assert!(
            opts.iter().all(|o| !matches!(
                o.code,
                DiagCode::O100 | DiagCode::O101 | DiagCode::O102 | DiagCode::O103
            )),
            "content inside an `interp eval` barrier body must not be analysed, got {opts:?}",
        );
    }

    #[test]
    fn same_pattern_in_a_plain_proc_does_fold_as_control() {
        // Precision control for the coverage-gap test above: the identical
        // `set n 5; return $n` shape, in a plain (non-TclOO) proc, does
        // fold (SCCP proves `n` constant and O100 rewrites the `return`
        // directly) — proving the gap above is specific to method bodies
        // rather than the pattern being unfoldable everywhere.
        let src = "proc bump {} {\n    set n 5\n    return $n\n}\n";
        let opts = optimise(src, &registry());
        assert!(
            opts.iter()
                .any(|o| o.code == DiagCode::O100 && o.replacement == "return 5"),
            "control: same set/return pattern in a plain proc should fold, got {opts:?}",
        );
    }

    #[test]
    fn dialect_gated_passes_observe_active_dialect() {
        // irules-only O124 should fire when dialect = f5-irules.
        let src = "proc ::dead {} { return 1 }\nwhen HTTP_REQUEST { set x 0 }\n";
        let irules = tcl_registry::model::ingress::static_context_for("f5-irules");
        let opts = optimise_with_dialect(
            src,
            irules.commands(),
            Some(tcl_dialect::DialectProfile::irules()),
        );
        assert!(
            opts.iter().any(|o| o.code == DiagCode::O124),
            "expected O124 in irules dialect, got {opts:?}",
        );
        // And should NOT fire for plain tcl.
        let tcl = tcl_registry::model::ingress::static_context_for("tcl8.6");
        let tcl_opts = optimise_with_dialect(src, tcl.commands(), tcl.commands().profile());
        assert!(
            tcl_opts.iter().all(|o| o.code != DiagCode::O124),
            "O124 should be gated on irules dialect, got {tcl_opts:?}",
        );
    }

    /// The two members of one O125 sink group over `source`: the deletion of
    /// the leading assignment, and the insertion that replays it into the
    /// branch that consumes it.
    fn sink_group(source: &str) -> Vec<Optimisation> {
        let set_end = u32::try_from(source.find('\n').expect("two-line source")).unwrap();
        let body_start =
            u32::try_from(source.rfind("log $msg").expect("target statement")).unwrap();
        let mut del =
            Optimisation::new(DiagCode::O125, "delete original", Span::new(0, set_end), "");
        del.group = Some(0);
        let mut ins = Optimisation::new(
            DiagCode::O125,
            "prepend in target body",
            Span::new(body_start, body_start + 8),
            "set msg \"error\"; log $msg",
        );
        ins.group = Some(0);
        vec![del, ins]
    }

    #[test]
    fn group_mate_replacement_does_not_resurrect_a_paired_deletion() {
        // The insertion's replacement holds both the sunk `set msg …` and the
        // `$msg` consuming it, so it reads as a resurrection unless group-mates
        // are exempt. Both members must survive, or the assignment lands twice.
        let source = "set msg \"error\"\nif {$ok} { return } else { log $msg }";
        let mut selected = sink_group(source);
        let registry = registry();
        let cu = CompilationUnit::build_for(source, &registry, false);
        drop_def_elims_resurrected_by_replacements(&cu, &registry, &mut selected);
        assert_eq!(
            selected.len(),
            2,
            "both grouped members must survive, got {selected:?}",
        );
    }

    #[test]
    fn a_dropped_deletion_takes_its_whole_group_with_it() {
        // Control for the exemption above: a resurrecting reference from
        // *outside* the group still drops the deletion, and a group is
        // all-or-nothing, so its other members go with it.
        let source = "set msg \"error\"\nif {$ok} { return } else { log $msg }";
        let mut selected = sink_group(source);
        selected.push(Optimisation::new(
            DiagCode::O100,
            "unrelated rewrite that keeps $msg alive",
            Span::new(
                u32::try_from(source.len()).unwrap(),
                u32::try_from(source.len()).unwrap(),
            ),
            "puts $msg",
        ));
        let registry = registry();
        let cu = CompilationUnit::build_for(source, &registry, false);
        drop_def_elims_resurrected_by_replacements(&cu, &registry, &mut selected);
        assert_eq!(
            selected.len(),
            1,
            "the whole O125 group must go, leaving only the unrelated rewrite, got {selected:?}",
        );
        assert_eq!(selected[0].code, DiagCode::O100);
    }
    /// Manufactured proposals test only finalisation's safety gate; they do
    /// not assert that an optimiser pass emits these proposals for the source.
    fn guarded_removal(source: &str, command: &str, replacement: &str) -> Vec<Optimisation> {
        let registry = tcl_registry::model::ingress::static_context_for("tcl9.0").commands();
        let cu = CompilationUnit::build_for_profile(
            source,
            registry,
            false,
            registry.profile().unwrap(),
        );
        let start = u32::try_from(source.find(command).unwrap()).unwrap();
        let end = start + u32::try_from(command.len()).unwrap();
        let raw = vec![
            Optimisation::new(
                DiagCode::O109,
                "definition removal",
                Span::new(start, end),
                "",
            ),
            Optimisation::new(
                DiagCode::O100,
                "surviving source",
                Span::new(
                    u32::try_from(source.len()).unwrap(),
                    u32::try_from(source.len()).unwrap(),
                ),
                replacement,
            ),
        ];
        finalise_optimisations(&raw, &cu, registry, registry.profile())
    }

    #[test]
    fn original_definition_guard_keeps_quoted_qualified_and_alias_names() {
        // naming.optimiser.original-definition-resurrection-guard
        // docs/design/analysis/name-resolution-proofs/optimiser-original-definition-resurrection-guard.md
        for (source, command, replacement) in [
            ("set {b c} 0\n", "set {b c} 0", "puts ${b c}"),
            ("set \"b c\" 0\n", "set \"b c\" 0", "puts ${b c}"),
            ("::set b 0\n", "::set b 0", "puts $b"),
            (
                "interp alias {} assign {} set\nassign {b c} 0\n",
                "assign {b c} 0",
                "puts ${b c}",
            ),
            (
                "interp alias {} assign {} set b\nassign 0\n",
                "assign 0",
                "puts $b",
            ),
            ("set {b(c} 0\n", "set {b(c} 0", "puts ${b(c}"),
            ("set {$b} 0\n", "set {$b} 0", "puts ${$b}"),
            ("set $target 0\n", "set $target 0", "puts $b"),
            ("proc set {name value} {}\nset b 0\n", "set b 0", "puts $b"),
        ] {
            let selected = guarded_removal(source, command, replacement);
            assert!(
                selected.iter().all(|opt| opt.code != DiagCode::O109),
                "{source:?}: {selected:?}"
            );
        }
        let selected = guarded_removal("set {b c} 0\n", "set {b c} 0", "puts ${other name}");
        assert!(
            selected.iter().any(|opt| opt.code == DiagCode::O109),
            "unrelated replacement: {selected:?}"
        );
    }

    #[test]
    fn original_definition_guard_declines_foreign_source_registry_and_missing_carrier() {
        // naming.optimiser.original-definition-resurrection-guard
        // docs/design/analysis/name-resolution-proofs/optimiser-original-definition-resurrection-guard.md
        let registry = tcl_registry::model::ingress::static_context_for("tcl9.0").commands();
        let source = "set {b c} 0\n";
        let cu = CompilationUnit::build_for_profile(
            source,
            registry,
            false,
            registry.profile().unwrap(),
        );
        let span = Span::new(0, u32::try_from(source.trim_end().len()).unwrap());
        assert!(
            elim_target_vars(&cu, registry, span)
                .unwrap()
                .contains(&"b c".to_owned())
        );
        let mut stale = cu.clone();
        stale.source.replace_range(..3, "put");
        assert_eq!(elim_target_vars(&stale, registry, span), None);
        let foreign = tcl_registry::model::ingress::static_context_for("tcl8.6").commands();
        assert_eq!(elim_target_vars(&cu, foreign, span), None);
        stale = cu.clone();
        stale.ir_module.lexer_config.strict_quoting ^= true;
        assert_eq!(elim_target_vars(&stale, registry, span), None);
        stale = cu;
        stale.top_level.cfg.command_binding_sites.clear();
        for block in stale.top_level.cfg.blocks.values_mut() {
            for statement in &mut block.statements {
                if let Some(tokens) = statement.tokens_mut() {
                    tokens.source_binding = None;
                }
            }
        }
        assert_eq!(elim_target_vars(&stale, registry, span), None);
    }
}
