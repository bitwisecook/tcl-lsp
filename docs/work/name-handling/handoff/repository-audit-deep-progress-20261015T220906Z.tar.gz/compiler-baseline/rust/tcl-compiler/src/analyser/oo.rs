// tcl-lsp — a language server and toolchain for Tcl
// Copyright (C) 2026 James Deucker (bitwisecook) <https://github.com/bitwisecook>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.
//
// SPDX-License-Identifier: AGPL-3.0-or-later

//! `TclOO` class / method body parsing + unknown-proc detection.
//!
//! Walks the body of an ``oo::class create Name { ... }`` or
//! ``oo::define Name { ... }`` block (and a snit type's or an itcl class's)
//! and populates the [`super::types::ClassDef`] fields: the full field set
//! (``constructors``, ``destructor``, ``variables``,
//! ``properties``, ``filters``, ``exports``, ``unexports``) plus
//! [`Analyser::extract_unknown_proc_info`] — the W123 gating
//! analysis for user-defined ``unknown`` procs.
//!
//! Every member statement is read through its registry row
//! (`DefinitionBodyGrammar::member_row`) and lands by its effect and the side
//! its receiver resolves to, never by its keyword (`member_landing`):
//!
//! - a callable — in the table `MethodKind::from_effect` names: an instance
//!   method in ``ClassDef::methods``, a type-object one in
//!   ``ClassDef::class_methods``, a constructor appended to
//!   ``ClassDef::constructors`` under its synthetic `<keyword>` name, a
//!   destructor in ``ClassDef::destructor``; snit's option handlers and
//!   `typeconstructor` among the methods of their side; snit's namespace
//!   `proc` through the ordinary proc handling;
//! - a forward — ``methods`` with ``kind = "forward"``;
//! - per-instance state — folds into ``ClassDef::variables`` through the
//!   registry slot spec (``-append`` with dedup for `TclOO`'s `variable`);
//! - a relation — the superclass and mixin slots (default ``-set``) and each
//!   side's filter slot (default ``-append``, duplicates kept);
//! - a retraction or visibility word — the members it names, on its side;
//! - flag-keyed accessors (``property NAME ?-get BODY? ?-set BODY? ?-kind
//!   K?``) — a [`super::types::PropertyDef`] per name;
//! - a definition-time script (``initialise`` / ``initialize``) — its body is
//!   walked in a class-keyed scope for variable tracking.

use tcl_dialect::model::SurfaceQuery;
use tcl_dialect::model::surface_admits;
use tcl_lexer::{Span, Token, TokenType};
use tcl_registry::Traits;
use tcl_registry::arg_role::ArgRole;
use tcl_registry::definer::{
    CallableRole, DefinitionBodyGrammar, InitTiming, MemberCurrentNamespace, MemberEffect,
    MemberKind, MemberReceiver, MemberRefKind, MemberRow, MemberSpec, MemberVisibility,
    RelationSlot, StateScope, WrapperShift,
};
use tcl_registry::side_effects::SideEffectTarget;
use tcl_registry::{InvocationArguments, InvocationWord};
use tcl_syntax::word_rules::WordValueRules;

use super::diagnostics::helpers::has_substitution;
use super::scope::scope_at_mut;
use super::state::Analyser;
use super::types::{
    ClassDef, DefinitionAbort, DefinitionAbortKind, MemberSide, MethodDef, PropertyDef,
    RenamedMember, Scope, ScopeKind, UnknownProcInfo,
};
use super::utils::{param_name_spans_for_token, parse_param_list};
use crate::ir::{MethodKind, Statement};
use crate::signature_scan::types::ParamDef;

/// Original-handler chaining follows the retained implementation identity.
/// A saved name chosen by the author is not evidence without a proved rename.
fn chains_original_unknown(facts: &tcl_registry::InvocationFacts) -> bool {
    facts.traits.contains(Traits::UNRESOLVED_COMMAND_HANDLER)
}

/// Effective registry effects, including alias prefixes and subcommand forms.
fn spawns_process(facts: &tcl_registry::InvocationFacts) -> bool {
    facts.traits.contains(Traits::UNSAFE)
        && facts
            .effects
            .legacy()
            .side_effects
            .iter()
            .any(|effect| effect.target == SideEffectTarget::Process)
}

fn loads_external_unit(facts: &tcl_registry::InvocationFacts) -> bool {
    facts.traits.contains(Traits::LOADS_EXTERNAL_UNIT)
}

/// Implicit variable snit injects into `typemethod` / `typeconstructor` bodies.
///
/// The instance-body implicits (`self` / `selfns` / `type` / `options`) come
/// from the definer's registry grammar (`implicit_vars`); this is only the
/// narrower *type*-body subset, which the flat grammar list doesn't
/// distinguish — a `typemethod` body sees `type` but not `self`.
const SNIT_TYPE_IMPLICIT: &[&str] = &["type"];

/// A definer's grammar plus the class being populated and where its members
/// live — bundled so the snit / itcl member dispatch + extraction helpers stay
/// under the argument limit.  Shared by both families (the extraction is
/// grammar-driven; only the per-family dispatch differs).
struct OriginalJimClassLists {
    bases_dynamic: bool,
    superclasses: Vec<String>,
    variable_words: Vec<String>,
    source_bases: Option<Vec<crate::signature_scan::scope::SignatureSourceNameInput>>,
}

struct ClassBodyCtx<'a> {
    grammar: &'static DefinitionBodyGrammar,
    class_def: &'a mut ClassDef,
    class_qualified: &'a str,
    scope_path: &'a [usize],
}

/// A body-bearing member ready to extract: its grammar spec (argument layout),
/// the table its row lands in, and the synthetic name for the nameless forms.
/// Bundled to keep [`Analyser::extract_class_member`] under the argument limit.
struct MemberForm<'a> {
    member: &'a MemberSpec,
    kind: MethodKind,
    label: &'a str,
    /// The member's declared visibility — its row's: the family's name rule
    /// (every snit and itcl member is exported), or the visibility an itcl
    /// access modifier's shift declares.
    visibility: &'a str,
}

/// The snit definer being parsed.  Which implicit variables its member
/// bodies see — including the widget-only `win` / `hull` pair — comes from
/// the grammar's own `implicit_vars` (`snit::widget` / `widgetadaptor` carry
/// `SNIT_WIDGET_GRAMMAR`), so no consumer matches the definer's name suffix.
struct SnitDefiner {
    grammar: &'static DefinitionBodyGrammar,
}

/// Whether `member` declares variables by name: a
/// [`MemberEffect::StateDeclaration`] whose words name them — every argument
/// (`TclOO`'s `variable a b c`) or its [`ArgRole::VarWrite`] word (snit's
/// `variable` / `typevariable` / `component` / `typecomponent`, itcl's
/// `variable` / `common`). snit's `option` declares state but names an option,
/// not a variable, so it is not one. A callable that binds a value variable
/// (snit 1.x `onconfigure`) is a body, not a declaration.
fn declares_variables(member: &MemberSpec) -> bool {
    matches!(member.effect, MemberEffect::StateDeclaration { .. })
        && (member.all_args_var || member.indices_for(ArgRole::VarWrite).next().is_some())
}

/// Map each declared instance-variable name in `known` to the span of its
/// declaration name-token, scanning the class-body `cmds`.  Used to anchor a
/// seeded object variable's `definition_span` at its `variable v` declaration
/// instead of the whole method body — a whole-body span would let a
/// variable rename overwrite the entire method.  Only names already present in
/// `known` (the authoritative `ClassDef::variables` list) are recorded, so a
/// non-name argument of a declaration member can never be mistaken for a
/// variable; the first declaration of a name wins.
fn collect_var_decl_spans(
    grammar: &DefinitionBodyGrammar,
    cmds: &[crate::segmenter::SegmentedCommand],
    known: &[String],
    image: &tcl_lexer::SourceImage,
    config: tcl_lexer::LexerConfig,
    dialect: Option<SurfaceQuery<'_>>,
) -> std::collections::HashMap<String, Span> {
    let mut out: std::collections::HashMap<String, Span> = std::collections::HashMap::new();
    if known.is_empty() {
        return out;
    }
    let known_set: std::collections::HashSet<&str> = known.iter().map(String::as_str).collect();
    for cmd in cmds {
        if cmd.is_partial {
            continue;
        }
        // A statement is a variable declaration when its row declares the
        // instances' state and its member names variables — the same answer
        // the class fold gives it, so the span map and `ClassDef::variables`
        // cannot disagree.  Gating additionally on `known_set` below means a
        // stray non-declaration match cannot leak.
        let Some(statement) = MemberStatement::read(grammar, &cmd.texts, &cmd.argv, dialect) else {
            continue;
        };
        if !declares_variables(statement.member)
            || statement.row.receiver != MemberReceiver::Instance
        {
            continue;
        }
        let groups = tcl_lexer::group_commands_bytes(&cmd.all_tokens, image.bytes(), config);
        let [group] = groups.as_slice() else {
            continue;
        };
        if group.words.len() != cmd.argv.len() || group.words.iter().any(|word| word.expand) {
            continue;
        }
        let args = cmd.args().iter().map(String::as_str).collect::<Vec<_>>();
        for argument in
            grammar.member_arg_indices_for_role_in(cmd.name(), &args, dialect, ArgRole::VarWrite)
        {
            let ordinal = argument + 1;
            let Some((group, tok)) = group.words.get(ordinal).zip(cmd.argv.get(ordinal)) else {
                continue;
            };
            let Ok(word) =
                tcl_lexer::NativeWord::from_group(image.clone(), config, &cmd.all_tokens, group)
            else {
                continue;
            };
            let Some(value) = tcl_syntax::word_rules::original_static_word_unicode_value(&word)
            else {
                continue;
            };
            let Ok(name) = String::from_utf8(value) else {
                continue;
            };
            let base = tcl_syntax::naming::split_element_ref(&name)
                .map_or(name.as_str(), |(root, _)| root);
            if known_set.contains(base) {
                out.entry(base.to_owned()).or_insert(tok.span);
            }
        }
    }
    out
}

/// Strip a leading member wrapper (a registry [`MemberKind::Wrapper`] — itcl's
/// `public` / `protected` / `private` access modifiers, `TclOO`'s `self`) from a
/// member call, returning the effective member keyword and its argument texts
/// and tokens (the words *after* the keyword).  Returns `None` for an empty
/// command or a bare wrapper with no inner member keyword (a wrapper's bare
/// script-block form, `self { … }`, has no inner member).
fn unwrap_wrapper_member<'a>(
    grammar: &DefinitionBodyGrammar,
    texts: &'a [String],
    argv: &'a [Token],
) -> Option<(&'a str, &'a [String], &'a [Token])> {
    let (first, rest_texts) = texts.split_first()?;
    let rest_toks = argv.get(1..).unwrap_or(&[]);
    if grammar
        .member(first)
        .is_some_and(|m| m.kind == MemberKind::Wrapper)
    {
        // `<modifier> <member> args…` — the inner member follows.
        let (inner, inner_texts) = rest_texts.split_first()?;
        let inner_toks = rest_toks.get(1..).unwrap_or(&[]);
        Some((inner.as_str(), inner_texts, inner_toks))
    } else {
        Some((first.as_str(), rest_texts, rest_toks))
    }
}

/// The words of one definition-body member statement as the registry reads
/// them: a braced word, or one with no substitution, is the literal it spells;
/// anything else is a computed word ([`has_substitution`], the boundary this
/// walker's other static-word checks draw).
fn member_statement_words<'t>(texts: &'t [String], argv: &[Token]) -> Vec<InvocationWord<'t>> {
    texts
        .iter()
        .enumerate()
        .map(|(index, text)| match argv.get(index) {
            Some(tok) if tok.kind == TokenType::Str || !has_substitution(text, tok) => {
                InvocationWord::Literal(text)
            }
            Some(_) => InvocationWord::Dynamic,
            None => InvocationWord::Opaque,
        })
        .collect()
}

/// One definition-body member statement read through its registry
/// [`MemberRow`]: the row, the member spec at its keyword (the wrapped
/// member's own for a wrapper's prefix form), and the statement's words.
struct MemberStatement<'a> {
    grammar: &'a DefinitionBodyGrammar,
    row: MemberRow,
    member: &'static MemberSpec,
    texts: &'a [String],
    argv: &'a [Token],
}

impl<'a> MemberStatement<'a> {
    /// The statement `texts` / `argv` spell, read under `dialect`; `None`
    /// when the registry cannot read it — an unknown or computed keyword, a
    /// wrapper around nothing it recognises, a recognised option word the
    /// dialect lacks, or a computed word where an optional one may stand.
    fn read(
        grammar: &'a DefinitionBodyGrammar,
        texts: &'a [String],
        argv: &'a [Token],
        dialect: Option<SurfaceQuery<'_>>,
    ) -> Option<Self> {
        let words = member_statement_words(texts, argv);
        let row = grammar.member_row(0, InvocationArguments::structured(&words), dialect)?;
        let member = grammar.member(texts.get(row.keyword_index)?)?;
        Some(Self {
            grammar,
            row,
            member,
            texts,
            argv,
        })
    }

    /// The member keyword as written.
    fn keyword(&self) -> &'a str {
        &self.texts[self.row.keyword_index]
    }

    /// The member keyword's token.
    fn keyword_token(&self) -> Option<Token> {
        self.argv.get(self.row.keyword_index).copied()
    }

    /// The words after the member keyword.
    fn args(&self) -> &'a [String] {
        self.texts.get(self.row.keyword_index + 1..).unwrap_or(&[])
    }

    /// The tokens of [`Self::args`], word for word.
    fn arg_tokens(&self) -> &'a [Token] {
        self.argv.get(self.row.keyword_index + 1..).unwrap_or(&[])
    }

    /// Where the row lands in the class model.
    fn landing(&self) -> MemberLanding {
        member_landing(self.grammar, self.member, &self.row)
    }

    /// What the wrappers written before the member keyword do to it,
    /// innermost first ([`WrapperShift::within`]) — the shift the row's
    /// receiver and visibility already include.
    fn shift(&self) -> WrapperShift {
        self.texts[..self.row.keyword_index]
            .iter()
            .fold(WrapperShift::NONE, |outer, word| {
                self.grammar
                    .member(word)
                    .and_then(|wrapper| wrapper.wrapper_shift)
                    .map_or(outer, |inner| inner.within(outer))
            })
    }

    /// The visibility a declared member is recorded with.
    ///
    /// A literal name takes the row's answer — its option word, then its
    /// wrapper, then the family's name rule. A computed name is still recorded
    /// under its written spelling (the class outline shows `${m}`), so the
    /// same three steps read that spelling: `${m}` fails `TclOO`'s `[a-z]*`
    /// rule, and is unexported unless its option word or wrapper says
    /// otherwise.
    fn recorded_visibility(&self, written_name: &str, dialect: Option<SurfaceQuery<'_>>) -> String {
        let named = matches!(
            self.row.effect,
            MemberEffect::Callable {
                name_slot: Some(_),
                ..
            } | MemberEffect::Forward { .. }
        );
        if self.row.name.is_some() || !named {
            return self.row.visibility.as_str().to_string();
        }
        let fallback = self.shift().visibility.map_or_else(
            || default_visibility(self.grammar, written_name),
            |visibility| visibility.as_str().to_string(),
        );
        declared_member_visibility(self.member, self.args(), fallback, dialect)
    }
}

/// Where one member row lands in the class model — the one `match` on
/// [`MemberEffect`] the `TclOO` fold and the snit and itcl body walkers share,
/// so no walker routes a member by its keyword.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum MemberLanding {
    /// A body recorded as a [`MethodDef`] in the table this kind names.
    Method(MethodKind),
    /// A procedure in the definition's own namespace (snit's `proc`): an
    /// ordinary proc, not a member.
    Procedure,
    /// A definition-time script no member table models (`TclOO`'s
    /// `initialise`, walked as the class's own init script, and a wrapper's
    /// block form, whose members are read one by one).
    InitScript,
    /// A forwarded method.
    Forward,
    /// Declared state.
    State(StateScope),
    /// A contribution to an ancestry or interposition slot.
    Relation(RelationSlot),
    /// Removes the members it names.
    Retraction,
    /// Changes the visibility of the members it names.
    Visibility,
    /// Flag-keyed accessor declarations (`property … ?-get …? ?-set …?`),
    /// until they are `Callable` rows of their own.
    Accessors,
    /// Configures the definition and records nothing.
    Nothing,
}

/// Where `row` — a statement of `member` under `grammar` — lands.
///
/// A callable lands in the table [`MethodKind::from_effect`] names; an
/// option's read or write handler opens no method frame of its own (the IR
/// lifts none), but the class model keeps its body, under its synthetic
/// `<keyword -option>` label, on the side that holds the option. A script run
/// once at definition is a class-side body when the family runs member bodies
/// in the defined entity's own namespace
/// ([`MemberCurrentNamespace::DefinedEntity`]: snit's `typeconstructor` is the
/// proc `${type}::Snit_typeconstructor`, run with `type` bound); under
/// `TclOO`'s runtime-receiver policy it runs in the class object's own
/// namespace, and the walker reads it as the class's init script.
fn member_landing(
    grammar: &DefinitionBodyGrammar,
    member: &MemberSpec,
    row: &MemberRow,
) -> MemberLanding {
    match row.effect {
        MemberEffect::Callable {
            role: CallableRole::Procedure,
            ..
        } => MemberLanding::Procedure,
        MemberEffect::Callable {
            role: CallableRole::Accessor | CallableRole::Mutator,
            ..
        } => MemberLanding::Method(side_kind(row.receiver)),
        MemberEffect::Callable { role, .. } => MethodKind::from_effect(role, row.receiver)
            .map_or(MemberLanding::Nothing, MemberLanding::Method),
        MemberEffect::InitScript {
            timing: InitTiming::AtDefinition,
            ..
        } if member.kind == MemberKind::Flat
            && grammar.member_current_namespace() == MemberCurrentNamespace::DefinedEntity =>
        {
            MemberLanding::Method(side_kind(row.receiver))
        }
        MemberEffect::InitScript { .. } => MemberLanding::InitScript,
        MemberEffect::Forward { .. } => MemberLanding::Forward,
        MemberEffect::StateDeclaration { scope } => MemberLanding::State(scope),
        MemberEffect::Relation { slot } => MemberLanding::Relation(slot),
        MemberEffect::Retraction => MemberLanding::Retraction,
        MemberEffect::Visibility => MemberLanding::Visibility,
        MemberEffect::Configuration if member.kind == MemberKind::FlagKeyed => {
            MemberLanding::Accessors
        }
        MemberEffect::Configuration => MemberLanding::Nothing,
    }
}

/// The method table a body with no lifecycle role of its own lands in: the
/// class object's for a type-object row, the instances' otherwise.
const fn side_kind(receiver: MemberReceiver) -> MethodKind {
    match receiver {
        MemberReceiver::TypeObject => MethodKind::ClassMethod,
        MemberReceiver::Instance | MemberReceiver::Both => MethodKind::Method,
    }
}

/// The method table a row's resolved receiver names, or `None` for a row on
/// both sides at once, which no member table models.
const fn member_side(receiver: MemberReceiver) -> Option<MemberSide> {
    match receiver {
        MemberReceiver::Instance => Some(MemberSide::Instance),
        MemberReceiver::TypeObject => Some(MemberSide::ClassObject),
        MemberReceiver::Both => None,
    }
}

/// File a recorded member under the table its kind names.
fn record_method(class_def: &mut ClassDef, kind: MethodKind, md: MethodDef) {
    match kind {
        MethodKind::Method => {
            class_def.methods.insert(md.name.clone(), md);
        }
        MethodKind::ClassMethod => {
            class_def.class_methods.insert(md.name.clone(), md);
        }
        MethodKind::Constructor => class_def.constructors.push(md),
        MethodKind::Destructor => class_def.destructor = Some(md),
    }
}

/// The `(var_idx, list_idx, body_idx)` post-head argument positions of a
/// registry-declared "var/list pairs then a trailing body" loop command
/// (`foreach`/`lmap`), when it has **exactly one** var/list pair — the only
/// shape [`Analyser::record_loop_installed_members`] can read a member name
/// off of. `None` for anything else: no [`tcl_registry::Traits::LOOP_LIST_HEADER`]
/// trait, no single matching [`tcl_registry::repeated::RepeatedArgLayout`],
/// or more (or fewer) than one pair — a multi-list `foreach` has no single
/// variable a member's name word could unambiguously mean.
pub(super) fn loop_installer_pair(
    spec: &tcl_registry::CommandSpec,
    post_head: usize,
) -> Option<(usize, usize, usize)> {
    if !spec.traits.contains(tcl_registry::Traits::LOOP_LIST_HEADER) {
        return None;
    }
    let [layout] = spec.repeated_args else {
        return None;
    };
    if layout.role != ArgRole::LoopVarList || layout.stride != 2 || layout.exclude_trailing != 1 {
        return None;
    }
    let var_indices = layout.indices(post_head);
    let &[var_idx] = var_indices.as_slice() else {
        return None;
    };
    Some((var_idx, var_idx + 1, post_head - 1))
}

/// Split a loop's literal list word into `(element, absolute source span)`
/// pairs, or `None` when the word is not literal (a single brace/quote/bare
/// token with no substitutions — same predicate the parameter-list literal
/// check uses) or fails to parse as a Tcl list.
fn literal_loop_elements(
    list_word: &str,
    list_tok: Token,
    list_single_token: bool,
) -> Option<Vec<(String, Span)>> {
    if !crate::signature_scan::params::param_word_is_literal(list_tok.kind, list_single_token) {
        return None;
    }
    let list_content_start = list_tok.span.start() + u32::from(list_tok.content_offset);
    let mut members = Vec::new();
    let mut pos = 0usize;
    loop {
        match tcl_syntax::list::find_element(list_word, pos) {
            Ok(Some(el)) => {
                let raw = &list_word[el.value.clone()];
                let value = if el.literal {
                    raw.to_string()
                } else {
                    tcl_lexer::backslash_subst(raw).into_owned()
                };
                let span = Span::new(
                    list_content_start + u32::try_from(el.value.start).unwrap_or(0),
                    list_content_start + u32::try_from(el.value.end).unwrap_or(0),
                );
                members.push((value, span));
                pos = el.next;
            }
            Ok(None) => break,
            // A malformed list is left exactly as opaque — no partial guess.
            Err(_) => return None,
        }
    }
    if members.is_empty() {
        None
    } else {
        Some(members)
    }
}

/// Whether a loop's body is exactly one member declaration (per `grammar`,
/// under any `self`/`private` wrapper) that names itself with exactly a
/// reference to the loop variable `var_name` — `foreach`'s installer idiom.
/// Returns the member's `(kind, body_span)` on a match; `None` for anything
/// else (more than one statement, a fixed name, a name built from more than
/// the bare variable, a member that is no method on either side) — left
/// exactly as opaque as before, not a partial guess.
fn loop_installed_member_shape(
    grammar: &DefinitionBodyGrammar,
    body_word: &str,
    body_content_start: u32,
    lexer_config: tcl_lexer::LexerConfig,
    dialect: Option<SurfaceQuery<'_>>,
    var_name: &str,
) -> Option<(MethodKind, Span)> {
    let inner_cmds = crate::segmenter::segment_commands_with_offset_and_config(
        body_word,
        body_content_start,
        lexer_config.nested(),
    );
    let mut real_cmds = inner_cmds
        .iter()
        .filter(|c| !c.is_partial && !c.argv.is_empty());
    let inner = real_cmds.next()?;
    if real_cmds.next().is_some() {
        return None; // more than one statement — not the simple installer shape
    }
    let statement = MemberStatement::read(grammar, &inner.texts, &inner.argv, dialect)?;
    let MemberLanding::Method(kind @ (MethodKind::Method | MethodKind::ClassMethod)) =
        statement.landing()
    else {
        return None;
    };
    let (member, inner_texts, inner_argv) =
        (statement.member, statement.args(), statement.arg_tokens());
    let name_idx = member
        .indices_for_call_in(inner_texts, dialect, ArgRole::Name)
        .next()?;
    let original = tcl_lexer::native_script_words_in_with_purpose(
        tcl_lexer::SourceImage::document(body_word),
        Span::new(0, u32::try_from(body_word.len()).ok()?),
        lexer_config,
        tcl_lexer::SourceSegmentationPurpose::NestedScript,
    )
    .ok()?;
    if original.fatal_tail.is_some() || original.commands.len() != 1 {
        return None;
    }
    let words = &original.commands.first()?.words;
    if words.len() != inner.argv.len() {
        return None;
    }
    let ordinal = statement
        .row
        .keyword_index
        .checked_add(1)?
        .checked_add(name_idx)?;
    let name =
        tcl_syntax::word_rules::original_scalar_variable_with_prefix(words.get(ordinal)?, &[b""])?;
    if name != var_name.as_bytes() {
        return None;
    }
    let body_idx = member
        .indices_for_call_in(inner_texts, dialect, ArgRole::Body)
        .next()?;
    let body_span = inner_argv.get(body_idx).map_or(inner.span, |t| t.span);
    Some((kind, body_span))
}

/// The synthetic name for a nameless member (one with no [`ArgRole::Name`]):
/// `<keyword>`, with a leading roleless option word (snit 1.x
/// `onconfigure`/`oncget`'s `-option`) appended when present so the two
/// option handlers for the same keyword stay distinct (`<onconfigure -foo>` vs
/// `<onconfigure -bar>`).  Unused for named members.
fn member_label(member: &MemberSpec, keyword: &str, args: &[String]) -> String {
    let role_at_zero = member.arg_roles.iter().any(|(i, _)| *i == 0);
    if !role_at_zero && let Some(opt) = args.first() {
        return format!("<{keyword} {opt}>");
    }
    format!("<{keyword}>")
}

fn original_two_word_proc_name(
    declaration: &crate::signature_scan::original_name::SourceDeclarationMetadata<
        super::types::ProcDef,
    >,
) -> Option<(
    crate::signature_scan::scope::SignatureSourceNameInput,
    crate::signature_scan::scope::SignatureSourceNameInput,
)> {
    let input = crate::signature_scan::scope::SignatureSourceNameInput::OriginalWord(
        declaration.name_input().clone(),
    );
    let children = input.original_list_elements()?;
    let [class, member] = children.as_slice() else {
        return None;
    };
    Some((class.clone(), member.clone()))
}

fn insert_original_two_word_member(
    class_def: &mut ClassDef,
    member: &str,
    proc: &super::types::ProcDef,
) {
    class_def.methods.insert(
        member.to_string(),
        MethodDef {
            name: member.to_string(),
            params: proc.params.clone(),
            params_computed: proc.params_computed,
            formal_count: proc.formal_count.clone(),
            name_span: proc.name_span,
            body_span: proc.body_span,
            kind: "method".to_string(),
            is_self_method: false,
            visibility: "public".to_string(),
            doc: proc.doc.clone(),
            forward_target: None,
        },
    );
}

impl Analyser {
    pub(super) fn original_provider_class_name(
        &self,
        span: Span,
    ) -> Option<crate::signature_scan::original_name::SourceOriginalNameOccurrence> {
        let policy = self.declaration_name_policy()?;
        self.head_identities
            .original_source_name_at_span(span, self.file_lexer_config(), self.word_rules(), policy)
            .or_else(|| {
                // The actual walk retains this complete original static word
                // independently of invocation entry. It supplies naming syntax
                // only; the caller still selects the definer and naming scope.
                let original = self.original_static_source_name_at_span(span)?;
                let input = original.name_input();
                (input.lexer_config() == self.file_lexer_config()
                    && input.word_value_rules() == self.word_rules()
                    && input.policy() == policy)
                    .then(|| original.clone())
            })
    }

    pub(super) fn retain_original_provider_class(
        &mut self,
        original: Option<&crate::signature_scan::original_name::SourceOriginalNameOccurrence>,
        class: &ClassDef,
    ) {
        if self.selected_logical_declaration_advice()
            && let Some(image) = self
                .result
                .retained_command_realm()
                .filter(|realm| {
                    realm.matches_resolved_analysis_input(&self.resolved_analysis_input())
                })
                .and_then(|realm| realm.original_source_image())
                .filter(|image| image.bytes() == self.source.as_bytes())
                .cloned()
            && let Some(declaration) = super::types::LogicalSourceClassDeclaration::capture(
                image,
                self.resolved_analysis_input(),
                class,
            )
        {
            self.result.logical_class_declarations.push(declaration);
        }
        if let Some(original) = original
            && let Some(name) = class.source_name.clone()
            && let Some(metadata) =
                crate::signature_scan::original_name::SourceDeclarationMetadata::new(
                    original,
                    name,
                    class.clone(),
                )
        {
            self.result.original_class_metadata.push(metadata);
        }
        // The selected definer supplies the class role. Hosted source words
        // retain their own context and unavailable materialisation; no C/Jim
        // command slot is recovered from the reporting class name.
        if let Some(original) = self.result.original_vendor_source_name_in_source(
            &tcl_lexer::SourceImage::document(&self.source),
            self.file_lexer_config(),
            class.name_span,
        ) {
            let record = crate::signature_scan::vendor_name::VendorSourceDeclarationMetadata::new(
                original,
                tcl_syntax::naming::VendorSourceNamePurpose::SourceName,
                class.clone(),
            );
            if !self.result.original_vendor_class_metadata.contains(&record) {
                self.result.original_vendor_class_metadata.push(record);
            }
        }
    }
    /// Walk the body of a ``oo::class create`` / ``oo::define``
    /// block, populating `class_def` from each subcommand.
    ///
    /// The body is re-segmented via
    /// [`crate::segmenter::segment_commands_with_offset`] (no
    /// recovery — recovery is top-level only).  Dynamic bodies
    /// (non-`Str` tokens) skip the walk because they can't be
    /// statically re-segmented.
    /// Whether the command `cmd_name` is *unavailable* in the active dialect —
    /// its registry spec is dialect-gated and the document's dialect falls
    /// outside the gate.  Used to suppress member-level dialect diagnostics
    /// when the enclosing definer (`oo::configurable`, itself 9.0+) is already
    /// flagged: one diagnostic for the version-only construct, not a cascade.
    pub(super) fn command_dialect_disabled(&self, cmd_name: &str) -> bool {
        let generation = self.analysis_context();
        generation
            .commands()
            .get(cmd_name)
            .is_some_and(|spec| !generation.context().spec_available(spec))
    }

    /// Whether the definition-body member `subcmd` is available in the active
    /// dialect.  A member with no dialect restriction (the common case) and an
    /// unknown member (handled elsewhere, not gated here) both count as
    /// available; a version-gated member — `classmethod`, `private`,
    /// `initialise` / `initialize`, `definitionnamespace`, `property`, all
    /// 9.0+ — is available only when the document's dialect intersects its
    /// set.  An unrecognised dialect never restricts.
    fn oo_member_available(&self, grammar: &DefinitionBodyGrammar, subcmd: &str) -> bool {
        let Some(member) = grammar.member(subcmd) else {
            return true;
        };
        match member.surface {
            None => true,
            Some(allowed) => surface_admits(
                allowed,
                Some(&self.analysis_context().context().authoring_query()),
            ),
        }
    }

    /// Emit W002 for a definition-body member the active dialect's grammar
    /// does not have.
    ///
    /// Shared by the three call shapes a member can take — inside a
    /// metaclass's `create` body, inside an `oo::define Cls { … }` block
    /// (both via [`Self::parse_oo_definition_body`]), and the single-command
    /// `oo::define Cls classmethod …` form (via
    /// [`Self::handle_oo_define_command`]) — so all three report the same way
    /// rather than only the bodies being checked.
    ///
    /// Reports **without** dropping the member: the walk still records it,
    /// so go-to-definition, references, rename, document symbols, and code
    /// lenses keep working on the code the user actually wrote.  That
    /// matches the whole-command W002 ([`Self::emit_w002_disabled_command`]),
    /// which likewise reports a dialect-unavailable command while the
    /// analyser goes on modelling the call.  Erasing the member instead
    /// would answer "this needs Tcl 9.0" by silently breaking every editor
    /// feature over it.
    ///
    /// `definer_disabled` bypasses the gate: when the enclosing definer is
    /// itself unavailable (`oo::configurable` under 8.6) its own diagnostic
    /// already covers the construct, and a member word must never cascade
    /// into a second report.
    pub(super) fn emit_w002_oo_member_disabled(
        &mut self,
        grammar: &DefinitionBodyGrammar,
        subcmd: &str,
        tok: Token,
        definer_disabled: bool,
    ) {
        if definer_disabled || self.oo_member_available(grammar, subcmd) {
            return;
        }
        self.result
            .diagnostics
            .push(crate::analyser::types::Diagnostic::new(
                tcl_core_types::DiagCode::W002,
                tok.span,
                format!(
                    "'{subcmd}' is disabled in the active dialect profile ('{}')",
                    self.dialect()
                ),
                super::types::Severity::Warning,
            ));
    }

    /// Emit W002 for a recognised optional member argument that exists in the
    /// grammar but is unavailable in this document's selected dialect.
    ///
    /// Unlike a whole-member gate, this preserves Tcl 8.6's ordinary
    /// `method NAME PARAMS BODY` layout while declining a Tcl 9 visibility
    /// flag in that same member. The option vocabulary and position remain in
    /// [`MemberSpec`]; this is only the generic diagnostic presentation.
    pub(super) fn emit_w002_oo_member_option_disabled(
        &mut self,
        member: &MemberSpec,
        args: &[String],
        arg_tokens: &[Token],
        definer_disabled: bool,
    ) -> bool {
        if definer_disabled {
            return false;
        }
        let Some(option) = member.unavailable_option_for(
            args,
            Some(self.analysis_context().context().authoring_query()),
        ) else {
            return false;
        };
        let Some(position) = member.optional_argument.map(|optional| optional.position) else {
            return false;
        };
        let Some(tok) = arg_tokens.get(usize::from(position)) else {
            return false;
        };
        self.result
            .diagnostics
            .push(crate::analyser::types::Diagnostic::new(
                tcl_core_types::DiagCode::W002,
                tok.span,
                format!(
                    "'{}' is disabled in the active dialect profile ('{}')",
                    option.value,
                    self.dialect()
                ),
                super::types::Severity::Warning,
            ));
        true
    }

    /// Record the command references a definition-body member names as
    /// arguments, driven entirely by the member's registry grammar — never by a
    /// member keyword the walker recognises.  Two grammar facts name a command:
    ///
    /// * `all_args_ref == Some(MemberRefKind::Class)` — every argument names a
    ///   class (`superclass A B`, `mixin ?-append? M …`).  A class is a command
    ///   in `TclOO`, so each is a command reference resolved in the class's
    ///   namespace.
    /// * an [`ArgRole::CommandName`] argument position — one argument names a
    ///   command (`forward NAME TARGET …`: the delegated command's name).
    ///
    /// Both flow through the ordinary invocation machinery, so find-references,
    /// go-to-definition, rename, and call-hierarchy reach the named class /
    /// command across files exactly as a direct call does.  A
    /// `MemberRefKind::Method` member names methods of *this* class rather than
    /// commands, so the method-reference machinery handles it, not this path.  A
    /// dynamic word (`superclass $base`) names no static command and is skipped.
    /// Whether one command of a definition body installs members this walk
    /// cannot read, making the class's recorded member tables a lower bound
    /// ([`super::types::ClassDef::member_set_incomplete`]).
    ///
    /// Two shapes qualify, neither matched by keyword:
    ///
    /// * a **member** word whose declaration is supplied dynamically — a
    ///   `{*}` expansion that survived [`splice_static_member_expansions`]
    ///   (only a braced literal splices statically), or a computed word in
    ///   one of the member's own declaring roles (`method $m …`). Tcl
    ///   resolves both at definition time, so the members are real; the
    ///   analyser simply cannot name them.
    /// * a **non-member** word that either has no registry spec (a helper
    ///   proc, or a class-installer command from another file) or declares
    ///   an [`ArgRole::Body`] argument — a script the member walk does not
    ///   descend into, so any `method` inside it is invisible
    ///   (`foreach m {…} { method $m … }`, `if {…} { method x {} {…} }`).
    ///
    /// Registry data decides both halves: the definer grammar says what a
    /// member word is and which of its arguments declare, and the command
    /// spec says whether a word carries a script. Nothing here names a
    /// command or a keyword.
    ///
    /// A comment line segments to no words at all and is skipped by the
    /// caller, so it never reaches this test.
    fn member_declaration_is_opaque(
        &self,
        grammar: &DefinitionBodyGrammar,
        cmd: &crate::segmenter::SegmentedCommand,
        texts: &[String],
    ) -> bool {
        let Some(keyword) = texts.first() else {
            return false;
        };
        let Some(member) = grammar.member(keyword) else {
            // Not a member word. Unknown to the registry, or script-taking:
            // either way this command can install members out of sight.
            // Roles come from the static table *and* the per-call resolver
            // (`foreach`'s layout depends on how many var/list pairs it was
            // given, so its `Body` index is only knowable from the words).
            let generation = self.analysis_context();
            return generation
                .context()
                .resolve_spec(generation.commands(), keyword)
                .is_none_or(|spec| {
                    // Possible declaration effects use the selected schema's
                    // closed role capabilities, without an execution query.
                    tcl_registry::CommandRegistry::spec_may_have_arg_role(spec, ArgRole::Body)
                });
        };
        // A `{*}` word the splicer would refuse — anything but a single
        // braced literal, whose element list is the only one knowable
        // without running the program.  Tested per word (not "did any
        // splice happen"), so a command mixing a spliceable and an
        // unspliceable expansion is still opaque.
        if let Some(expand) = cmd.expand_word.as_ref()
            && expand.iter().enumerate().any(|(i, &e)| {
                e && !(cmd.argv.get(i).is_some_and(|t| t.kind == TokenType::Str)
                    && cmd.single_token_word.get(i).copied().unwrap_or(false))
            })
        {
            return true;
        }
        // A computed member **name** — `method $m …`, the installer-loop
        // spelling — declares a member the walk cannot name.  `+ 1` because
        // role indices are relative to the member's arguments while `texts`
        // still carries the keyword at 0.
        //
        // Only the name word is tested.  A parameter list or body word is a
        // *script*, and a script routinely contains `$` and `[` without being
        // dynamic in the sense that matters here (`constructor {x} { set a
        // $x }` is entirely readable); the `{*}` test above is what catches
        // the genuinely reflected signature.
        let original =
            self.original_logical_member_words(grammar, cmd)
                .filter(|(statement, _, _)| {
                    cmd.texts.as_slice() == texts && std::ptr::eq(statement.member, member)
                });
        member
            .indices_for_call_in(
                &texts[1..],
                Some(self.analysis_context().context().authoring_query()),
                ArgRole::Name,
            )
            .any(|idx| {
                if let Some((statement, _, words)) = original.as_ref() {
                    return words
                        .get(statement.row.keyword_index + 1 + idx)
                        .is_none_or(|word| {
                            tcl_syntax::word_rules::original_static_word_unicode_value(word)
                                .is_none_or(|value| value.contains(&0))
                        });
                }
                if self.selected_logical_declaration_advice() {
                    return true;
                }
                texts
                    .get(idx + 1)
                    .is_some_and(|w| crate::naming::is_dynamic_word(w))
            })
    }

    /// Record the per-name members a **literal** loop-installer declares,
    /// even though [`Self::member_declaration_is_opaque`] has already (and
    /// correctly) marked the class's member set incomplete because of it.
    ///
    /// `foreach m {alpha beta gamma} { method $m {args} {…} }` computes
    /// each member's *name* from the loop variable, which is why the
    /// ordinary member walk cannot read it — but the loop's own list is
    /// written right there in the source, so the set of names it will bind
    /// `$m` to really is knowable without running the program. This adds
    /// what can honestly be said on top of the existing abstention; it
    /// never narrows `member_set_incomplete` back to "complete", because
    /// knowing three names is not the same as knowing them all (a sibling
    /// `oo::define` elsewhere, or a second, unreadable installer in the
    /// same body, could still add more).
    ///
    /// Deliberately narrow — every condition below is a bail, not a best
    /// effort, and any miss just leaves the loop as opaque as it already
    /// was:
    ///
    /// * the head word must be a registry-declared "var/list pairs then a
    ///   trailing body" loop shape ([`tcl_registry::Traits::LOOP_LIST_HEADER`]
    ///   plus exactly one [`tcl_registry::repeated::RepeatedArgLayout`]
    ///   covering a var/list pair) — `foreach`/`lmap`, decided from registry
    ///   data, never a keyword;
    /// * exactly one var/list pair (a multi-list `foreach` has no single
    ///   variable a member's name word could unambiguously mean);
    /// * the loop variable is one bare name, not a multi-variable group
    ///   (`foreach {a b} $list …`);
    /// * the list word is a **literal** Tcl list (no `$`/`[`) that parses
    ///   cleanly;
    /// * the body is exactly one member declaration (per `grammar`, unwrapped
    ///   of any `self`/`private`) whose `Name` argument is exactly a
    ///   reference to the loop variable — anything else (a fixed name, a
    ///   name built from more than the bare variable, more than one
    ///   statement) is left unread, exactly as before this ran.
    ///
    /// The recorded member's parameter list is always `params_computed`
    /// (never re-derived from the loop body's own written params, even when
    /// they look literal): a reflective installer's signature can itself be
    /// computed per iteration (`method $m {*}[classDef $m]`), so treating
    /// one binding's `{args}` as representative of every other would be a
    /// fabrication for the general shape this exists to cover.
    fn record_loop_installed_members(
        &self,
        grammar: &DefinitionBodyGrammar,
        cmd: &crate::segmenter::SegmentedCommand,
        class_def: &mut ClassDef,
    ) {
        let Some(keyword) = cmd.texts.first().map(String::as_str) else {
            return;
        };
        let generation = self.analysis_context();
        let Some(spec) = generation
            .context()
            .resolve_spec(generation.commands(), keyword)
        else {
            return;
        };
        // Post-head argument count (`texts` still carries the keyword at 0).
        let post_head = cmd.texts.len().saturating_sub(1);
        let Some((var_idx, list_idx, body_idx)) = loop_installer_pair(spec, post_head) else {
            return;
        };
        let (Some(var_word), Some(list_word), Some(body_word)) = (
            cmd.texts.get(var_idx + 1),
            cmd.texts.get(list_idx + 1),
            cmd.texts.get(body_idx + 1),
        ) else {
            return;
        };
        // The loop variable must be one bare name.
        let Ok(var_names) = self.word_rules().split_list(var_word) else {
            return;
        };
        if var_names.len() != 1 {
            return; // a multi-variable group — no single name a `$var` could mean
        }
        let var_name = &var_names[0];
        if !tcl_syntax::naming::is_static_variable_source_word(var_name) {
            return;
        }
        let Some(list_tok) = cmd.argv.get(list_idx + 1) else {
            return;
        };
        let list_single = cmd
            .single_token_word
            .get(list_idx + 1)
            .copied()
            .unwrap_or(false);
        let Some(members) = literal_loop_elements(list_word, *list_tok, list_single) else {
            return;
        };
        let Some(body_tok) = cmd.argv.get(body_idx + 1) else {
            return;
        };
        let body_content_start = body_tok.span.start() + u32::from(body_tok.content_offset);
        let Some((kind, body_span)) = loop_installed_member_shape(
            grammar,
            body_word,
            body_content_start,
            self.file_lexer_config(),
            Some(self.analysis_context().context().authoring_query()),
            var_name,
        ) else {
            return;
        };
        for (name, name_span) in members {
            let md = MethodDef {
                visibility: default_visibility(grammar, &name),
                name,
                params: Vec::new(),
                params_computed: true,
                formal_count: crate::signature_scan::formal_count::SourceFormalCount::Authored(
                    tcl_dialect::ParameterGrammar::Tcl,
                ),
                name_span,
                body_span,
                kind: kind.as_str().to_string(),
                is_self_method: false,
                doc: String::new(),
                forward_target: None,
            };
            // A literal, directly-written declaration elsewhere in the class
            // always outranks a name merely *inferred* from the loop's list —
            // this only ever fills a gap, never overrides real data, however
            // the two are ordered in the source.
            let table = if kind == MethodKind::ClassMethod {
                &mut class_def.class_methods
            } else {
                &mut class_def.methods
            };
            table.entry(md.name.clone()).or_insert(md);
        }
    }

    pub(super) fn record_member_command_references(
        &mut self,
        grammar: &DefinitionBodyGrammar,
        texts: &[String],
        argv: &[Token],
        scope_path: &[usize],
    ) {
        // Unwrap a `self …` (or itcl access-modifier) prefix so a wrapped
        // `self mixin -append …` still contributes its class references.  The
        // returned texts/tokens are the words *after* the effective keyword, so
        // grammar arg-role indices (0-based after the keyword) index them
        // directly.
        let Some((keyword, arg_texts, arg_toks)) = unwrap_wrapper_member(grammar, texts, argv)
        else {
            return;
        };
        let Some(spec) = grammar.member(keyword) else {
            return;
        };
        // `skip_flags` drops `-`-prefixed option words — correct only for the
        // class-list members (`mixin -append …`), where the flags aren't class
        // names.  A `forward` TARGET is a plain command name that may legally
        // begin with `-` (`forward f -foo` delegates to a command named
        // `-foo`), so its `ArgRole::CommandName` recording keeps such words.
        let record = |analyser: &mut Self, name: &str, tok: &Token, skip_flags: bool| {
            if name.is_empty() || crate::naming::is_dynamic_word(name) {
                return;
            }
            if skip_flags && name.starts_with('-') {
                return;
            }
            // A named command reference carries no fixed call arity: a
            // superclass/mixin is not invoked here, and a `forward` target is
            // invoked with a variable number of appended arguments.
            let resolved = analyser.resolve_command_qualified_name(name, scope_path);
            analyser.push_command_reference(name.to_owned(), tok.span, resolved, None);
        };
        if spec.all_args_ref == Some(MemberRefKind::Class) {
            for (name, tok) in arg_texts.iter().zip(arg_toks) {
                record(self, name, tok, true);
            }
        }
        for idx in spec.indices_for_call_in(
            arg_texts,
            Some(self.analysis_context().context().authoring_query()),
            ArgRole::CommandName,
        ) {
            if let (Some(name), Some(tok)) = (arg_texts.get(idx), arg_toks.get(idx)) {
                record(self, name, tok, false);
            }
        }
    }

    pub(super) fn parse_oo_definition_body(
        &mut self,
        body_text: &str,
        body_tok: Token,
        class_def: &mut ClassDef,
        scope_path: &[usize],
        grammar: Option<&'static DefinitionBodyGrammar>,
        definer_disabled: bool,
    ) {
        if body_tok.kind != TokenType::Str {
            return;
        }
        // Member recognition + argument layout come from the definer's registry
        // grammar; without one (only possible when the analyser has no registry,
        // e.g. a direct unit-test call) there is nothing to walk.
        let Some(grammar) = grammar else {
            return;
        };
        if grammar.family == tcl_registry::definer::DefinerFamily::TclOo
            && class_def.source_name.is_some()
            && !class_def.source_name_ambiguous.is_observed()
        {
            class_def.original_relations.begin_declaration();
        }
        // The methods walked below home under the class's qualified name;
        // capture it before the member-collection walk mutates `class_def`.
        let class_qualified = class_def.qualified_name.clone();
        let base_offset = body_tok.span.start() + u32::from(body_tok.content_offset);
        let cmds = crate::segmenter::segment_commands_with_offset_and_config(
            body_text,
            base_offset,
            self.file_lexer_config().nested(),
        );
        let CollectedDefinitionBodies {
            methods: method_bodies,
            accessors: accessor_bodies,
            initialisers: init_bodies,
        } = self.collect_oo_definition_members(
            grammar,
            &cmds,
            class_def,
            scope_path,
            definer_disabled,
        );
        self.original_class_definition_body = None;
        // The display inventory is separate from original source link authority.
        self.collect_oo_links(&method_bodies, class_def);

        // Walk each method / accessor / class-init body in its own
        // `Method` scope with the formal parameters and the class's instance
        // variables pre-bound.
        let class_variables = class_def.variables.clone();
        // Map each declared instance-variable name to its `variable v`
        // declaration name-token span, so the per-method seeding below anchors
        // the object variable's definition at the declaration rather than the
        // whole method body.
        let generation = self.analysis_context();
        let var_decl_spans = self
            .head_identities
            .original_source_image()
            .filter(|image| image.bytes() == self.source.as_bytes())
            .map_or_else(std::collections::HashMap::new, |image| {
                collect_var_decl_spans(
                    grammar,
                    &cmds,
                    &class_variables,
                    image,
                    self.file_lexer_config().nested(),
                    Some(generation.context().authoring_query()),
                )
            });
        // `TclOO` method bodies resolve bare commands globally (object-ns
        // semantics — see `Scope::oo_global_resolution`); snit / itcl
        // members resolve in the type / class namespace.
        let oo_global = matches!(grammar.family, tcl_registry::definer::DefinerFamily::TclOo);
        // The class-level `initialise` body runs first and in a scope of its
        // own, so the class-scoped variables it declares are visible to this
        // class's own method / accessor bodies below — and to no other
        // class's.
        let mut class_variables = class_variables;
        let mut var_decl_spans = var_decl_spans;
        for mb in &init_bodies {
            for (name, span) in
                self.walk_class_init_body(&class_variables, &class_qualified, scope_path, mb)
            {
                if !class_variables.contains(&name) {
                    class_variables.push(name.clone());
                }
                var_decl_spans.entry(name).or_insert(span);
            }
        }
        for mb in method_bodies.iter().chain(accessor_bodies.iter()) {
            self.walk_method_body(
                &class_variables,
                &var_decl_spans,
                MethodBodyClass {
                    display: &class_qualified,
                    declaration: Some(class_def),
                },
                scope_path,
                mb,
                oo_global,
            );
        }
    }

    /// Collect an OO definition body's members: update the class facts and
    /// retain body-bearing members for the later scope walk.
    fn collect_oo_definition_members(
        &mut self,
        grammar: &DefinitionBodyGrammar,
        cmds: &[crate::segmenter::SegmentedCommand],
        class_def: &mut ClassDef,
        scope_path: &[usize],
        definer_disabled: bool,
    ) -> CollectedDefinitionBodies {
        let mut bodies = CollectedDefinitionBodies::default();
        for cmd in cmds {
            if !cmd.is_partial && !cmd.argv.is_empty() {
                self.collect_oo_definition_member(
                    grammar,
                    cmd,
                    class_def,
                    scope_path,
                    definer_disabled,
                    &mut bodies,
                );
            }
        }
        bodies
    }

    fn original_logical_member_words<'a>(
        &self,
        grammar: &'a DefinitionBodyGrammar,
        cmd: &'a crate::segmenter::SegmentedCommand,
    ) -> Option<(
        MemberStatement<'a>,
        super::ResolvedAnalysisInput,
        Vec<tcl_lexer::NativeWord>,
    )> {
        if !self.selected_logical_declaration_advice() || cmd.is_partial {
            return None;
        }
        let input = self.resolved_analysis_input();
        let image = self
            .result
            .retained_command_realm()
            .filter(|realm| realm.matches_resolved_analysis_input(&input))
            .and_then(|realm| realm.original_source_image())
            .filter(|image| image.bytes() == self.source.as_bytes())?;
        let config = self.file_lexer_config().nested();
        if config != input.lexer_config().nested() {
            return None;
        }
        let context = self.analysis_context();
        let statement = MemberStatement::read(
            grammar,
            &cmd.texts,
            &cmd.argv,
            Some(context.context().authoring_query()),
        )?;
        let groups = tcl_lexer::group_commands_bytes(&cmd.all_tokens, image.bytes(), config);
        let [group] = groups.as_slice() else {
            return None;
        };
        if group.words.len() != cmd.argv.len() || group.words.iter().any(|word| word.expand) {
            return None;
        }
        let words = group
            .words
            .iter()
            .map(|group| {
                tcl_lexer::NativeWord::from_group(image.clone(), config, &cmd.all_tokens, group)
            })
            .collect::<Result<Vec<_>, _>>()
            .ok()?;
        if !words.iter().zip(&cmd.argv).all(|(word, token)| {
            word.group().span == token.span
                && word.tokens().first().is_some_and(|original| {
                    original.kind == token.kind
                        && original.content_offset == token.content_offset
                        && original.in_quote == token.in_quote
                })
        }) || words[..=statement.row.keyword_index]
            .iter()
            .zip(&cmd.texts)
            .any(|(word, text)| {
                tcl_syntax::word_rules::original_static_word_ascii_presentation(word).as_deref()
                    != Some(text.as_bytes())
            })
        {
            return None;
        }
        Some((statement, input, words))
    }

    pub(super) fn retain_logical_member_name_operand(
        &self,
        grammar: &DefinitionBodyGrammar,
        cmd: &crate::segmenter::SegmentedCommand,
        class: &mut ClassDef,
    ) {
        let Some((statement, input, words)) = self.original_logical_member_words(grammar, cmd)
        else {
            return;
        };
        let MemberEffect::Callable {
            name_slot: Some(name_slot),
            ..
        } = statement.row.effect
        else {
            return;
        };
        let (Some(name), Some(side), Some(body)) = (
            statement.row.name.as_ref(),
            member_side(statement.row.receiver),
            statement.row.body,
        ) else {
            return;
        };
        let context = self.analysis_context();
        let surface = Some(context.context().authoring_query());
        let mut names =
            statement
                .member
                .indices_for_call_in(statement.args(), surface, ArgRole::Name);
        let mut bodies =
            statement
                .member
                .indices_for_call_in(statement.args(), surface, ArgRole::Body);
        if names.next() != Some(usize::from(name_slot))
            || names.next().is_some()
            || bodies
                .next()
                .map(|index| statement.row.keyword_index + 1 + index)
                != Some(body.0)
            || bodies.next().is_some()
        {
            return;
        }
        let name_ordinal = statement.row.keyword_index + 1 + usize::from(name_slot);
        let Some(word) = words.get(name_ordinal) else {
            return;
        };
        if tcl_syntax::word_rules::original_static_word_ascii_presentation(word).as_deref()
            != Some(name.as_bytes())
        {
            return;
        }
        let (Some(name_token), Some(body_token)) =
            (cmd.argv.get(name_ordinal), cmd.argv.get(body.0))
        else {
            return;
        };
        class.original_members.retain_logical_name_operand(
            input,
            words,
            name_ordinal,
            side,
            (name_token.span, body_token.span),
        );
    }

    pub(super) fn retain_logical_member_visibility_operands(
        &self,
        grammar: &DefinitionBodyGrammar,
        cmd: &crate::segmenter::SegmentedCommand,
        class: &mut ClassDef,
    ) {
        let Some((statement, input, words)) = self.original_logical_member_words(grammar, cmd)
        else {
            return;
        };
        if statement.row.effect != MemberEffect::Visibility
            || statement.member.all_args_ref != Some(MemberRefKind::Method)
        {
            return;
        }
        let (Some(side), Some(effect)) = (
            member_side(statement.row.receiver),
            statement.member.visibility_effect,
        ) else {
            return;
        };
        let first = statement.row.keyword_index + 1;
        if words[first..]
            .iter()
            .zip(statement.args())
            .any(|(word, name)| {
                name.as_bytes().contains(&0)
                    || tcl_syntax::word_rules::original_static_word_ascii_presentation(word)
                        .as_deref()
                        != Some(name.as_bytes())
            })
        {
            return;
        }
        for ordinal in first..words.len() {
            class.original_members.retain_logical_visibility_operand(
                input.clone(),
                words.clone(),
                ordinal,
                side,
                effect,
            );
        }
    }

    /// Selected source-member formal applicability and exact authored ordinals.
    /// The original class ledger supplies any lifecycle body; representative
    /// tokens and reporting strings cannot stand in for that whole word.
    fn member_formal_parameter_indices(
        &self,
        grammar: &DefinitionBodyGrammar,
        member: &MemberSpec,
        args: &[String],
        tokens: &[Token],
        class: &ClassDef,
    ) -> Vec<usize> {
        use tcl_registry::definer::SourceFormalValidationApplicability;
        // naming.tcloo.empty-lifecycle-definition
        // docs/design/analysis/name-resolution-proofs/tcloo-empty-lifecycle-definition.md
        let context = self.analysis_context();
        let surface = Some(context.context().authoring_query());
        let applicability = grammar
            .source_member_formal_validation_applicability(member, None)
            .or_else(|| {
                let kind = grammar.source_special_member_kind(member)?;
                let body_index = member
                    .indices_for_call_in(args, surface, ArgRole::Body)
                    .next()?;
                let body_token = tokens.get(body_index)?;
                let image = tcl_lexer::SourceImage::document(&self.source);
                let config = self.file_lexer_config();
                let mut selected = class
                    .original_special_members
                    .declarations()
                    .filter(|entry| {
                        let word = entry.body_word();
                        entry.kind() == kind
                            && word.image() == &image
                            && word.config() == config
                            && word.group().span.start() == body_token.span.start()
                    });
                let entry = selected.next()?;
                if selected.next().is_some() {
                    return None;
                }
                let values = tcl_registry::native_compiler_words::NativeCompilerWords::capture(
                    std::slice::from_ref(entry.body_word()),
                    self.declaration_name_policy()?.string_protocol(),
                )
                .ok()?;
                grammar
                    .source_member_formal_validation_applicability(member, Some(values.literal(0)?))
            });
        if applicability != Some(SourceFormalValidationApplicability::Required) {
            return Vec::new();
        }
        member
            .indices_for_call_in(args, surface, ArgRole::ParamList)
            .collect()
    }

    /// Process one segmented OO definition member using only its registered
    /// grammar, including wrapper expansion and profile-aware argument roles.
    fn collect_oo_definition_member(
        &mut self,
        grammar: &DefinitionBodyGrammar,
        cmd: &crate::segmenter::SegmentedCommand,
        class_def: &mut ClassDef,
        scope_path: &[usize],
        definer_disabled: bool,
        bodies: &mut CollectedDefinitionBodies,
    ) {
        self.retain_original_member_metadata(grammar, cmd, class_def, scope_path);
        let spliced = splice_static_member_expansions(&self.source, cmd, self.file_lexer_config());
        let (texts, argv) = spliced.as_ref().map_or(
            (cmd.texts.as_slice(), cmd.argv.as_slice()),
            |(texts, argv)| (texts.as_slice(), argv.as_slice()),
        );
        if let (Some(subcmd), Some(token)) = (texts.first(), argv.first()) {
            self.emit_w002_oo_member_disabled(grammar, subcmd, *token, definer_disabled);
        }
        if let Some(member) = texts.first().and_then(|subcmd| grammar.member(subcmd))
            && self.emit_w002_oo_member_option_disabled(
                member,
                &texts[1..],
                &argv[1..],
                definer_disabled,
            )
        {
            return;
        }
        if self.member_declaration_is_opaque(grammar, cmd, texts) {
            class_def.member_set_incomplete = true;
            self.record_loop_installed_members(grammar, cmd, class_def);
        }
        let expanded = expand_wrapper_block_members(
            &self.source,
            grammar,
            texts,
            argv,
            self.file_lexer_config(),
        );
        let member_calls: Vec<(&[String], &[Token])> = expanded.as_ref().map_or_else(
            || vec![(texts, argv)],
            |inner| {
                inner
                    .iter()
                    .map(|(texts, argv)| (texts.as_slice(), argv.as_slice()))
                    .collect()
            },
        );
        for (texts, argv) in member_calls {
            if let Some((keyword, args)) = texts.split_first()
                && let Some(member) = grammar.member(keyword)
            {
                let tokens = argv.get(1..).unwrap_or(&[]);
                let parameter_indices =
                    self.member_formal_parameter_indices(grammar, member, args, tokens, class_def);
                super::diagnostics::emit_invalid_formal_parameter_list_diagnostics(
                    self,
                    args,
                    tokens,
                    &parameter_indices,
                );
            }
            apply_oo_subcommand_in(
                grammar,
                texts,
                argv,
                class_def,
                MemberDialect {
                    surface: Some(self.analysis_context().context().authoring_query()),
                    rules: self.word_rules(),
                },
            );
            self.retain_class_relation_lookups(texts, class_def, scope_path);
            self.record_member_command_references(grammar, texts, argv, scope_path);
            if let Some(method) = collect_method_body(
                grammar,
                texts,
                argv,
                Some(self.analysis_context().context().authoring_query()),
                self.word_rules(),
            ) {
                bodies.methods.push(method);
            }
        }
        collect_class_level_bodies(
            grammar,
            texts,
            argv,
            Some(self.analysis_context().context().authoring_query()),
            &mut bodies.accessors,
            &mut bodies.initialisers,
        );
    }

    pub(super) fn retain_class_relation_lookups(
        &self,
        texts: &[String],
        class: &mut ClassDef,
        scope_path: &[usize],
    ) {
        // These are the same analyser-local field routes as apply_oo_subcommand_in.
        let names = match texts.first().map(String::as_str) {
            Some("superclass" | "inherit") => &class.superclasses,
            Some("mixin") => &class.mixins,
            _ => return,
        };
        for written in names.iter().filter(|name| texts[1..].contains(name)) {
            let lookup = self.declaration_name_policy().and_then(|policy| {
                crate::signature_scan::scope::SignatureSourceLookup::new(
                    policy,
                    self.declaration_namespace_scope(scope_path)?,
                    written.clone(),
                )
            });
            match class.relation_lookups.entry(written.clone()) {
                std::collections::hash_map::Entry::Vacant(entry) => {
                    entry.insert(lookup);
                }
                std::collections::hash_map::Entry::Occupied(mut entry) => {
                    if entry.get() != &lookup {
                        entry.insert(None);
                    }
                }
            }
        }
    }

    /// Walk one class-level `initialise` / `initialize` body in a scope
    /// **keyed on the class**, and report the variables it declared there.
    ///
    /// The body is not a method — calling `self` / `classvariable` / `link`
    /// inside it is a runtime error ("`self` may only be called from inside
    /// a method", tclsh 9.0.4) — but it does run in a *per-class* frame:
    /// `namespace current` there is that class object's own namespace
    /// (`::oo::Obj20` for one class, `::oo::Obj22` for the next), with
    /// `namespace path` = `::oo::Helpers ::oo`. Walking every sibling
    /// class's init body in the one shared enclosing scope collided their
    /// declarations: a `classvariable NAME` read in *any* class's property
    /// setter then resolved to whichever class came first in the file, and
    /// find-references merged both classes' declarations into a single
    /// symbol — a definitive wrong answer on a statically decidable case,
    /// and one a rename would act on. tclsh 9.0.4 keeps
    /// the two independent: two `oo::configurable` classes whose setters
    /// each check their own `initialize`-declared list correctly reject the
    /// other's values.
    ///
    /// Returned names are seeded into this class's method bodies by the
    /// caller, which is what makes a setter's `classvariable NAME` read
    /// reach its own class's declaration. Deliberately unconditional, the
    /// same approximation the instance-`variable` seeding beside it already
    /// makes: the analyser does not track which methods actually issued the
    /// `classvariable` link, so a name declared in the init body is treated
    /// as visible (defined, never unused-warned) throughout the class.
    ///
    /// Walked inline rather than through `deferred_bodies` — a class-level
    /// init script is not one of the per-item-rebuildable method bodies,
    /// and this is the same inline walk it always had.
    fn walk_class_init_body(
        &mut self,
        class_variables: &[String],
        class_qualified: &str,
        scope_path: &[usize],
        mb: &CollectedMethodBody,
    ) -> Vec<(String, Span)> {
        if mb.body_tok.kind != TokenType::Str {
            return Vec::new();
        }
        let init_qn = if class_qualified.is_empty() {
            mb.name.clone()
        } else {
            format!("{class_qualified}::{}", mb.name)
        };
        let Some(init_idx) =
            scope_at_mut(&mut self.result.global_scope, scope_path).map(|parent| {
                let mut child = Scope::new(ScopeKind::Method, init_qn);
                child.body_span = Some(mb.body_tok.span);
                // The object frame resolves bare commands globally, exactly as a
                // method body's does — `namespace path` is `::oo::Helpers ::oo`
                // and the class's *defining* namespace is not searched.
                child.oo_global_resolution = true;
                // ...but it is NOT a method invocation, so `oo_method_frame`
                // stays false. The two facts
                // diverge here and nowhere else: the family *resolves*
                // (`namespace which -command link` → `::oo::Helpers::link`,
                // so W123 must stay silent) yet all but `my` raise `… may
                // only be called from inside a method` when called, so
                // completion and hover must not offer them. `my` is the
                // exception because it is `::oo::ObjN::my` rather than an
                // `::oo::Helpers` member and a class is an object — `my new`
                // in an `initialize` body really does make an instance.
                child.oo_method_frame = false;
                parent.children.push(child);
                parent.children.len() - 1
            })
        else {
            return Vec::new();
        };
        let mut init_path = scope_path.to_vec();
        init_path.push(init_idx);
        let body_start = mb.body_tok.span.start();
        for var in class_variables {
            let base =
                tcl_syntax::naming::split_element_ref(var).map_or(var.as_str(), |(root, _)| root);
            if base.is_empty() {
                continue;
            }
            self.define_var(
                base,
                mb.body_tok,
                &init_path,
                false,
                Some(Span::new(body_start, body_start)),
            );
        }
        let seeded: std::collections::HashSet<String> = class_variables
            .iter()
            .map(|v| {
                tcl_syntax::naming::split_element_ref(v)
                    .map_or(v.as_str(), |(root, _)| root)
                    .to_owned()
            })
            .collect();
        self.analyse_body(&mb.body_text, mb.body_tok, &init_path);
        // Whatever the walk itself recorded in this scope — no second,
        // name-matching parser here; the registry-driven walk already knows
        // which words a `variable` / `const` statement declares.
        super::scope::scope_at(&self.result.global_scope, &init_path).map_or_else(
            Vec::new,
            |scope| {
                scope
                    .variables
                    .iter()
                    .filter(|(name, _)| !seeded.contains(name.as_str()))
                    .map(|(name, def)| (name.clone(), def.definition_span))
                    .collect()
            },
        )
    }

    /// Collect display-only alias/target pairs from the selected catalogue.
    /// Positive source consumers authenticate original invocation receipts.
    fn collect_oo_links(&self, method_bodies: &[CollectedMethodBody], class_def: &mut ClassDef) {
        for mb in method_bodies {
            if mb.body_tok.kind != TokenType::Str {
                continue;
            }
            let base = mb.body_tok.span.start() + u32::from(mb.body_tok.content_offset);
            let cmds = crate::segmenter::segment_commands_with_offset_and_config(
                &mb.body_text,
                base,
                self.file_lexer_config().nested(),
            );
            for cmd in &cmds {
                if cmd.is_partial
                    || !cmd.texts.first().is_some_and(|head| {
                        let generation = self.analysis_context();
                        generation
                            .context()
                            .resolve_spec(generation.commands(), head)
                            .is_some_and(|spec| {
                                spec.traits.contains(Traits::TCLOO_BINDS_METHOD_ALIAS)
                            })
                    })
                {
                    continue;
                }
                for word in cmd.texts.iter().skip(1) {
                    if crate::naming::is_dynamic_word(word) {
                        continue;
                    }
                    match crate::tcl_expr_eval::split_tcl_list(word, self.word_rules()).as_slice() {
                        [name] if !name.is_empty() => {
                            let key = {
                                let written = tcl_syntax::naming::canonical_written_command(name);
                                tcl_syntax::naming::unroot_rooted_key(&written)
                                    .unwrap_or(&written)
                                    .to_owned()
                            };
                            class_def.linked_members.entry(key.clone()).or_insert(key);
                        }
                        [name, target] if !name.is_empty() => {
                            class_def
                                .linked_members
                                .entry({
                                    let written =
                                        tcl_syntax::naming::canonical_written_command(name);
                                    tcl_syntax::naming::unroot_rooted_key(&written)
                                        .unwrap_or(&written)
                                        .to_owned()
                                })
                                .or_insert_with(|| target.clone());
                        }
                        _ => {}
                    }
                }
            }
        }
    }

    /// Walk a single `TclOO` method body in a fresh [`ScopeKind::Method`] scope.
    ///
    /// Pre-binds the method's formal parameters and the class's instance
    /// `variable`s as defined-but-not-warned locals (so reads of them do not
    /// false-fire W210 read-before-set / W214 unused), then re-walks the body
    /// through [`Self::analyse_body`] so its `$obj method` / `[cmd] method`
    /// dispatch sites are recorded (with `in_method = true`) for the W307 /
    /// W308 post-pass.
    fn walk_method_body(
        &mut self,
        class_variables: &[String],
        var_decl_spans: &std::collections::HashMap<String, Span>,
        class: MethodBodyClass<'_>,
        scope_path: &[usize],
        mb: &CollectedMethodBody,
        oo_global_resolution: bool,
    ) {
        if mb.body_tok.kind != TokenType::Str {
            return;
        }
        let class_qualified = class.display;
        let original_context = (oo_global_resolution && !mb.class_side)
            .then(|| {
                super::types::OriginalLexicalMemberContext::from_class_body(
                    class.declaration?,
                    &mb.body_tok,
                    mb.params_tok.as_ref(),
                    self.resolved_analysis_input(),
                    &tcl_lexer::SourceImage::document(&self.source),
                    self.file_lexer_config(),
                )
            })
            .flatten()
            .map(Box::new);
        let original_body_declaration = oo_global_resolution
            .then(|| {
                super::types::OriginalSourceReceiverBodyDeclaration::from_class_body(
                    class.declaration?,
                    &mb.body_tok,
                    mb.params_tok.as_ref(),
                    self.resolved_analysis_input(),
                    &tcl_lexer::SourceImage::document(&self.source),
                )
            })
            .flatten();
        let method_qn = if class_qualified.is_empty() {
            mb.name.clone()
        } else {
            format!("{class_qualified}::{}", mb.name)
        };
        // Instance-side `TclOO` method of a statically-named class:
        // `[self class]` answers the defining class in this frame, so
        // record the fact for the constant command-substitution fold.
        // `oo_global_resolution` is exactly the
        // `TclOO`-family gate (snit / itcl walkers pass `false`);
        // class-side members abstain (`self class` never answers the
        // written class there); a synthetic key (`::@objdefine@…`) is
        // not a class name.
        let oo_defining_class = (oo_global_resolution
            && !mb.class_side
            && !class_qualified.is_empty()
            && !class_qualified.contains('@'))
        .then(|| class_qualified.to_owned());
        let Some(method_idx) = ({
            scope_at_mut(&mut self.result.global_scope, scope_path).map(|parent| {
                let mut child = Scope::new(ScopeKind::Method, method_qn.clone());
                child.body_span = Some(mb.body_tok.span);
                child.original_member_context = original_context;
                child.original_receiver_body_declaration = original_body_declaration;
                child.oo_global_resolution = oo_global_resolution;
                // A real method invocation, unlike the class-level
                // `initialise` frame `walk_class_init_body` opens: the whole
                // `oo::Helpers` family is callable here, not merely
                // resolvable (tclsh 9.0.4 inside a constructor: `link zzz`
                // returns `::oo::ObjN::zzz`).
                child.oo_method_frame = oo_global_resolution;
                child.oo_defining_class.clone_from(&oo_defining_class);
                parent.children.push(child);
                parent.children.len() - 1
            })
        }) else {
            return;
        };
        let mut method_path = scope_path.to_vec();
        method_path.push(method_idx);
        // Formal parameters — defined, never unused-warned.  Anchor each
        // param's definition span at its name in the param-list literal so
        // go-to-definition / references / rename resolve to the
        // parameter, not the whole method body.  Falls back to the body token
        // when the param-list word or a name can't be located.
        let param_spans = mb
            .params_tok
            .map(|pt| param_name_spans_for_token(&self.source, pt));
        for (i, p) in mb.params.iter().enumerate() {
            let def_span = param_spans.as_ref().and_then(|s| s.get(i).copied());
            self.define_var(&p.name, mb.body_tok, &method_path, false, def_span);
        }
        if let Some(pt) = mb.params_tok {
            self.emit_w218_args_not_final(&mb.params, param_spans.as_deref().unwrap_or(&[]), pt);
        }
        // Class instance variables — visible in every method body.  Anchor
        // each one's definition span at its `variable v` declaration token
        // A seeded var must NEVER take the whole method-body span as its
        // `definition_span`, or a rename would rewrite the entire body.  When
        // the declaration span is unknown (e.g. a snit implicit var) fall back
        // to a zero-width span at the body start — harmless, never destructive.
        let body_start = mb.body_tok.span.start();
        for var in class_variables {
            let base =
                tcl_syntax::naming::split_element_ref(var).map_or(var.as_str(), |(root, _)| root);
            if base.is_empty() || mb.params.iter().any(|p| p.name == base) {
                continue;
            }
            let def_span = var_decl_spans
                .get(base)
                .copied()
                .unwrap_or_else(|| Span::new(body_start, body_start));
            self.define_var(base, mb.body_tok, &method_path, false, Some(def_span));
        }
        // Per-item shell pass: defer the method body for an isolated pass like
        // `handle_proc_command`.  Carry the method's qualified name as
        // `scope_name` (so the duplicate detector keys each method distinctly),
        // the class's *defining* namespace (so command/var resolution in the
        // isolated `Method` scope matches the whole-file walk), the formal
        // params, and the class instance variables (pre-bound in every method).
        if self.defer_proc_bodies {
            // Same rule `handle_proc_command` records for a deferred proc body:
            // the command-resolution namespace, so the isolated per-item rebuild
            // and the whole-file walk agree even when the class definer ran
            // inside a qualified-name proc.
            let namespace = self.command_resolution_namespace(scope_path);
            let safe_interp_ctx = self.safe_interp_ctx_snapshot();
            self.deferred_bodies.push(super::per_item::DeferredBody {
                resolved_input: Some(self.resolved_analysis_input()),
                body_text: std::sync::Arc::from(mb.body_text.as_str()),
                body_tok: mb.body_tok,
                scope_path: method_path,
                is_method: true,
                oo_global_resolution,
                namespace,
                scope_name: method_qn,
                params: mb.params.clone(),
                // The shell walk above already seeded these with their real
                // declaration spans; the graft keeps the shell's span, so
                // the deferred body pass only needs the names.
                seeded_variables: class_variables.to_vec(),
                // Attached later by `fill_deferred_bodies` for bodies with a
                // fold candidate.
                command_trust: None,
                ensemble_targets: Vec::new(),
                prefixless_ensembles: Vec::new(),
                oo_defining_class,
                safe_interp_ctx,
            });
        } else {
            self.analyse_body(&mb.body_text, mb.body_tok, &method_path);
        }
    }

    /// Handle a snit (tcllib) type/widget definition —
    /// ``snit::type``/``snit::widget``/``snit::widgetadaptor Name { body }``
    /// (and their `::`-qualified forms).  Snit reinterprets its body as a
    /// class description, exactly like an `oo::class` body, so we model it as
    /// a real [`ClassDef`] with method scopes — object dispatch inside method
    /// bodies (`$self foo`, `$component bar`) is then recognised as in-method
    /// dispatch (no false W307) and snit's implicit instance variables don't
    /// surface as read-before-set / unused.
    pub(super) fn handle_snit_type_command(
        &mut self,
        cmd_name: &str,
        args: &[String],
        arg_tokens: &[Token],
        scope_path: &[usize],
    ) -> bool {
        self.handle_snit_type_source(super::original_definer::ClassDefinerCall {
            cmd_name,
            args,
            arg_tokens,
            scope_path,
            cmd_tok: None,
            original: None,
        })
    }

    pub(super) fn handle_snit_type_source(
        &mut self,
        call: super::original_definer::ClassDefinerCall<'_>,
    ) -> bool {
        let super::original_definer::ClassDefinerCall {
            cmd_name,
            args,
            arg_tokens,
            scope_path,
            original,
            ..
        } = call;
        // Which commands are snit definers, their member sub-keywords + argument
        // layout, and the variables snit injects into member bodies are all
        // registry data (a `Snit`-family definition-body grammar) — not a
        // hardcoded name / member / implicit-var list.  A new snit-like definer
        // is picked up automatically once its spec carries the grammar.  The
        // grammar is `&'static`, so it outlives the immutable registry borrow
        // released here before the `&mut self` work below.
        let Some(grammar) = original
            .map(super::original_definer::OriginalClassDefinerSource::grammar)
            .or_else(|| self.definition_grammar(cmd_name))
            .filter(|g| g.family == tcl_registry::definer::DefinerFamily::Snit)
        else {
            return false;
        };
        if args.len() < 2 || arg_tokens.len() < 2 {
            return false;
        }
        let raw_name = &args[0];
        let body = &args[1];
        // A relative type name homes to the namespace current at the call —
        // the command-resolution namespace, so a `snit::type` created inside
        // `proc ::ns::p {}` becomes `::ns::T`.
        let ns_prefix = self.command_resolution_namespace(scope_path);
        // Constructed key in, construction-inverse tail out: a colon
        // trim or `rsplit("::")` would collapse a lone-colon name.
        let qualified = super::handlers::qualify(&ns_prefix, raw_name);
        let simple = crate::naming::key_tail(&qualified).to_string();
        let name_span = arg_tokens[0].span;
        // **W314** — the class name has no absolute written form.
        self.emit_w314_no_absolute_name(raw_name, name_span);
        let body_tok = arg_tokens[1];
        let doc = std::mem::take(&mut self.last_comment);
        let original_name = original
            .and_then(super::original_definer::OriginalClassDefinerSource::original_name)
            .or_else(|| self.original_provider_class_name(name_span));
        let source_name = original_name.as_ref().and_then(|original| {
            crate::signature_scan::scope::SignatureSourceCommand::provider_advice_from_key(
                &self.declaration_namespace_scope(scope_path)?,
                original.name_input(),
            )
        });
        let mut class = ClassDef {
            source_name,
            name: simple.clone(),
            qualified_name: qualified.clone(),
            name_span,
            body_span: body_tok.span,
            metaclass: cmd_name.to_string(),
            metaclass_provenance: super::types::MetaclassProvenance::Observed,
            doc,
            ..Default::default()
        };
        if !body.is_empty() {
            let definer = SnitDefiner { grammar };
            self.parse_snit_definition_body(
                body, body_tok, &mut class, &qualified, scope_path, &definer,
            );
        }
        // For `my`-dispatch resolution — see
        // `class_body_spans`'s doc.
        self.result
            .class_body_spans
            .push((qualified.clone(), class.body_span));
        self.retain_original_provider_class(original_name.as_ref(), &class);
        self.result
            .retain_class_declaration(qualified, class.clone());
        let path = scope_path.to_vec();
        if let Some(scope) = scope_at_mut(&mut self.result.global_scope, &path) {
            scope.classes.insert(simple, class);
        }
        true
    }

    /// Parse a snit type/widget body into methods + variable declarations, in
    /// two passes (so a method can reference any instance/type variable
    /// regardless of declaration order).
    fn parse_snit_definition_body(
        &mut self,
        body: &str,
        body_tok: Token,
        class_def: &mut ClassDef,
        class_qualified: &str,
        scope_path: &[usize],
        definer: &SnitDefiner,
    ) {
        if body_tok.kind != TokenType::Str {
            return;
        }
        let grammar = definer.grammar;
        let base_offset = body_tok.span.start() + u32::from(body_tok.content_offset);
        let cmds = crate::segmenter::segment_commands_with_offset_and_config(
            body,
            base_offset,
            self.file_lexer_config().nested(),
        );

        // The variables snit injects into every member body come from the
        // definer's registry grammar (`implicit_vars`); the widget grammar's
        // list already includes the widget-only `win` / `hull` pair.
        let implicit_vars = grammar.implicit_vars;
        let mut instance_vars: Vec<String> =
            implicit_vars.iter().map(|s| (*s).to_string()).collect();
        let mut type_vars: Vec<String> = SNIT_TYPE_IMPLICIT
            .iter()
            .map(|s| (*s).to_string())
            .collect();

        // First pass: collect declared instance / type variable + component
        // names.  Which members declare state, and whose, is each statement's
        // row (`StateDeclaration`'s scope: per-type state is the type
        // variables', per-instance the instance variables'); which argument
        // holds the name is the member's registry layout.
        let context = self.analysis_context();
        let dialect = Some(context.context().authoring_query());
        for cmd in &cmds {
            if cmd.is_partial {
                continue;
            }
            let Some(statement) = MemberStatement::read(grammar, &cmd.texts, &cmd.argv, dialect)
            else {
                continue;
            };
            let MemberLanding::State(scope) = statement.landing() else {
                continue;
            };
            let args = statement.args();
            let Some(name) = statement
                .member
                .indices_for_call_in(args, dialect, ArgRole::VarWrite)
                .next()
                .and_then(|i| args.get(i))
            else {
                continue;
            };
            match scope {
                StateScope::PerType => type_vars.push(name.clone()),
                StateScope::PerInstance => instance_vars.push(name.clone()),
                // An option is configured through the instance, not read as
                // a variable of its own.
                StateScope::Option => {}
            }
        }

        // Record the *explicit* instance + type variables on the class —
        // method-scope seeding and the W307 dispatch-source suppression both
        // read `ClassDef::variables`.  The base grammar's implicit scalars
        // (`self`/`selfns`/`type`/`options` — `SNIT_GRAMMAR.implicit_vars`,
        // shared by every snit definer) and the type-implicit `type` are
        // filtered; a widget's injected `win`/`hull` (the extra names its
        // own grammar adds on top of the base set) are kept — they are real
        // per-instance variables worth surfacing on the class record.
        let base_implicits = tcl_registry::definer::SNIT_GRAMMAR.implicit_vars;
        class_def.variables = instance_vars
            .iter()
            .filter(|v| !base_implicits.contains(&v.as_str()))
            .chain(
                type_vars
                    .iter()
                    .filter(|v| !SNIT_TYPE_IMPLICIT.contains(&v.as_str())),
            )
            .cloned()
            .collect();

        // Second pass: analyse method-bearing declarations in method scopes.
        for cmd in &cmds {
            if cmd.is_partial || cmd.texts.is_empty() {
                continue;
            }
            self.retain_original_member_metadata(grammar, cmd, class_def, scope_path);
            let mut ctx = ClassBodyCtx {
                grammar,
                class_def,
                class_qualified,
                scope_path,
            };
            self.dispatch_snit_member(cmd, &mut ctx, &instance_vars, &type_vars);
        }
    }

    /// Dispatch one snit body statement by its row: a callable or a
    /// definition-time script to the method extractor, a namespace procedure
    /// to the ordinary proc handler.  Split out of
    /// [`Self::parse_snit_definition_body`] so the two-pass walk stays small.
    ///
    /// Recognition, argument layout (which words are the name / parameter list
    /// / value var / body) and what the statement declares all come from its
    /// registry row ([`member_landing`], the routing the `TclOO` fold shares):
    /// a type-object row's body sees the type variables and lands among the
    /// class methods, an instance row's sees the instance variables.  Only the
    /// synthetic name of the nameless forms is decided here.
    fn dispatch_snit_member(
        &mut self,
        cmd: &crate::segmenter::SegmentedCommand,
        ctx: &mut ClassBodyCtx<'_>,
        instance_vars: &[String],
        type_vars: &[String],
    ) {
        let context = self.analysis_context();
        let dialect = Some(context.context().authoring_query());
        let (sub_args, sub_tokens) = (&cmd.texts[1..], cmd.argv.get(1..).unwrap_or(&[]));
        if let Some(member) = ctx.grammar.member(&cmd.texts[0]) {
            let parameter_indices = self.member_formal_parameter_indices(
                ctx.grammar,
                member,
                sub_args,
                sub_tokens,
                ctx.class_def,
            );
            super::diagnostics::emit_invalid_formal_parameter_list_diagnostics(
                self,
                sub_args,
                sub_tokens,
                &parameter_indices,
            );
        }
        let Some(statement) = MemberStatement::read(ctx.grammar, &cmd.texts, &cmd.argv, dialect)
        else {
            return;
        };
        match statement.landing() {
            // A type-private `proc name args body` is a procedure in the
            // type's namespace — analyse it as an ordinary proc in the
            // enclosing scope, not a method.
            MemberLanding::Procedure => {
                // No per-argument single-token info is threaded this deep into
                // the snit member dispatcher; `&[]` is the same safe default
                // `resolve_dynamic_word` already falls back to elsewhere (a
                // dynamic type-private proc name still gets a chance to resolve
                // via `fold_interpolation_single`, just not the single-`$var`
                // fast path).
                self.handle_proc_command(
                    statement.keyword(),
                    statement.args(),
                    statement.arg_tokens(),
                    &[],
                    ctx.scope_path,
                );
            }
            MemberLanding::Method(kind) => {
                let seed_vars = if statement.row.receiver == MemberReceiver::TypeObject {
                    type_vars
                } else {
                    instance_vars
                };
                let label = member_label(statement.member, statement.keyword(), statement.args());
                let form = MemberForm {
                    member: statement.member,
                    kind,
                    label: &label,
                    visibility: statement.row.visibility.as_str(),
                };
                self.extract_class_member(
                    statement.args(),
                    statement.arg_tokens(),
                    ctx,
                    seed_vars,
                    &form,
                );
            }
            _ => {}
        }
    }

    /// Analyse one snit method / constructor / etc. body in a method scope
    /// seeded with `seed_vars` (snit's implicit names + declared instance or
    /// type variables) and the method's formal parameters.  The name /
    /// parameter-list / value-var / body word positions all come from
    /// `member`'s registry arg-roles — a body-less member is a no-op.
    fn extract_class_member(
        &mut self,
        args: &[String],
        arg_tokens: &[Token],
        ctx: &mut ClassBodyCtx<'_>,
        seed_vars: &[String],
        form: &MemberForm<'_>,
    ) {
        let MemberForm {
            member,
            kind,
            label,
            visibility,
        } = *form;
        let context = self.analysis_context();
        let mask = Some(context.context().authoring_query());
        let Some(body_idx) = member.indices_for_call_in(args, mask, ArgRole::Body).next() else {
            return;
        };
        let Some(body_text) = args.get(body_idx).cloned() else {
            return;
        };
        let body_tok = arg_tokens.get(body_idx).copied();
        let name_idx = member.indices_for_call_in(args, mask, ArgRole::Name).next();
        let params_idx = member
            .indices_for_call_in(args, mask, ArgRole::ParamList)
            .next();

        // A named member (`method NAME …`) uses its name word; the nameless
        // forms fall back to the caller's synthetic label (`<constructor>`,
        // `<oncget -opt>`, …), or `<body>` when even that is empty.
        let name = name_idx
            .and_then(|i| args.get(i))
            .cloned()
            .unwrap_or_else(|| {
                if label.is_empty() {
                    "<body>".to_string()
                } else {
                    label.to_string()
                }
            });
        // Formal parameters: the parameter-list word, plus any `VarWrite` word
        // (snit 1.x `onconfigure`'s value variable) modelled as a bound local.
        let mut params: Vec<ParamDef> = params_idx
            .and_then(|i| args.get(i))
            .map_or_else(Vec::new, |p| parse_param_list(p, self.word_rules()));
        for i in member.indices_for_call_in(
            args,
            Some(self.analysis_context().context().authoring_query()),
            ArgRole::VarWrite,
        ) {
            if let Some(v) = args.get(i) {
                params.push(ParamDef {
                    name: v.clone(),
                    has_default: false,
                    default_value: None,
                });
            }
        }
        let params_tok = params_idx.and_then(|i| arg_tokens.get(i).copied());

        let zero = Span::new(0, 0);
        let name_span = name_idx
            .and_then(|i| arg_tokens.get(i))
            .or_else(|| arg_tokens.first())
            .map_or(zero, |t| t.span);
        let body_span = body_tok.map_or(name_span, |t| t.span);
        let method_def = MethodDef {
            name: name.clone(),
            params: params.clone(),
            params_computed: false,
            formal_count: crate::signature_scan::formal_count::SourceFormalCount::Authored(
                tcl_dialect::ParameterGrammar::Tcl,
            ),
            name_span,
            body_span,
            kind: kind.as_str().to_string(),
            is_self_method: false,
            visibility: visibility.to_string(),
            doc: String::new(),
            forward_target: None,
        };
        record_method(ctx.class_def, kind, method_def);

        // Walk the body in a method scope seeded with the params + seed vars,
        // reusing the TclOO method-body walker (it pre-binds the params and the
        // supplied vars as never-warn locals, then analyses the body). snit /
        // itcl members resolve in the type / class namespace, so
        // `oo_global_resolution` stays false here.
        if let Some(bt) = body_tok {
            let mb = CollectedMethodBody {
                name,
                params,
                body_text,
                body_tok: bt,
                params_tok,
                // snit / itcl members are not `TclOO` frames — no
                // `[self class]` fact may be derived from them.
                class_side: true,
            };
            // snit / itcl seed vars are mostly grammar-injected implicits with no
            // source declaration token; an empty span map makes `walk_method_body`
            // fall back to a safe zero-width span (never the body span), so a
            // rename can't overwrite the body.  Precise snit declaration spans
            // are not modelled.
            let no_var_spans = std::collections::HashMap::new();
            self.walk_method_body(
                seed_vars,
                &no_var_spans,
                MethodBodyClass {
                    display: ctx.class_qualified,
                    declaration: None,
                },
                ctx.scope_path,
                &mb,
                false,
            );
        }
    }

    /// Handle an [incr Tcl] `itcl::class Name { body }` (family `Itcl`),
    /// modelling it as a [`ClassDef`] with method scopes exactly like
    /// `oo::class` / `snit::type`, so `$this method` dispatch and reads of the
    /// instance / `common` variables inside method bodies don't false-fire.
    /// The access modifiers `public` / `protected` / `private` are prefix
    /// wrappers (registry `MemberKind::Wrapper`) and are unwrapped here.
    pub(super) fn handle_itcl_class_command(
        &mut self,
        cmd_name: &str,
        args: &[String],
        arg_tokens: &[Token],
        scope_path: &[usize],
    ) -> bool {
        self.handle_itcl_class_source(super::original_definer::ClassDefinerCall {
            cmd_name,
            args,
            arg_tokens,
            scope_path,
            cmd_tok: None,
            original: None,
        })
    }

    pub(super) fn handle_itcl_class_source(
        &mut self,
        call: super::original_definer::ClassDefinerCall<'_>,
    ) -> bool {
        let super::original_definer::ClassDefinerCall {
            cmd_name,
            args,
            arg_tokens,
            scope_path,
            original,
            ..
        } = call;
        let Some(grammar) = original
            .map(super::original_definer::OriginalClassDefinerSource::grammar)
            .or_else(|| self.definition_grammar(cmd_name))
            .filter(|g| g.family == tcl_registry::definer::DefinerFamily::Itcl)
        else {
            return false;
        };
        if args.len() < 2 || arg_tokens.len() < 2 {
            return false;
        }
        let raw_name = &args[0];
        let body = &args[1];
        // As for snit: a relative itcl class name homes to the namespace
        // current at the call, not the lexical one.
        let ns_prefix = self.command_resolution_namespace(scope_path);
        // Constructed key in, construction-inverse tail out: a colon
        // trim or `rsplit("::")` would collapse a lone-colon name.
        let qualified = super::handlers::qualify(&ns_prefix, raw_name);
        let simple = crate::naming::key_tail(&qualified).to_string();
        let name_span = arg_tokens[0].span;
        // **W314** — the class name has no absolute written form.
        self.emit_w314_no_absolute_name(raw_name, name_span);
        let body_tok = arg_tokens[1];
        let doc = std::mem::take(&mut self.last_comment);
        let original_name = original
            .and_then(super::original_definer::OriginalClassDefinerSource::original_name)
            .or_else(|| self.original_provider_class_name(name_span));
        let source_name = original_name.as_ref().and_then(|original| {
            crate::signature_scan::scope::SignatureSourceCommand::provider_advice_from_key(
                &self.declaration_namespace_scope(scope_path)?,
                original.name_input(),
            )
        });
        let mut class = ClassDef {
            source_name,
            name: simple.clone(),
            qualified_name: qualified.clone(),
            name_span,
            body_span: body_tok.span,
            metaclass: cmd_name.to_string(),
            metaclass_provenance: super::types::MetaclassProvenance::Observed,
            doc,
            ..Default::default()
        };
        if !body.is_empty() {
            self.parse_itcl_definition_body(
                body, body_tok, &mut class, &qualified, scope_path, grammar,
            );
        }
        // For `my`-dispatch resolution — see
        // `class_body_spans`'s doc.
        self.result
            .class_body_spans
            .push((qualified.clone(), class.body_span));
        self.retain_original_provider_class(original_name.as_ref(), &class);
        self.result
            .retain_class_declaration(qualified, class.clone());
        let path = scope_path.to_vec();
        if let Some(scope) = scope_at_mut(&mut self.result.global_scope, &path) {
            scope.classes.insert(simple, class);
        }
        true
    }

    /// Handle a `JimClass` definer — `class NAME ?BASES? VARS` — recording the
    /// class as a [`ClassDef`] with its base classes and the instance
    /// variables `VARS` names.
    ///
    /// `VARS` is a dictionary of every instance variable and its initial
    /// value, not a script, so it is read for its keys and never walked as a
    /// body. The class defines no member itself: methods arrive later, through
    /// [`Self::handle_jim_class_member_call`] or a two-word `proc`
    /// ([`Self::record_two_word_proc_member`]).
    pub(super) fn handle_jim_class_command(
        &mut self,
        cmd_name: &str,
        args: &[String],
        arg_tokens: &[Token],
        scope_path: &[usize],
    ) -> bool {
        self.handle_jim_class_source(super::original_definer::ClassDefinerCall {
            cmd_name,
            args,
            arg_tokens,
            scope_path,
            cmd_tok: None,
            original: None,
        })
    }

    pub(super) fn handle_jim_class_source(
        &mut self,
        call: super::original_definer::ClassDefinerCall<'_>,
    ) -> bool {
        let super::original_definer::ClassDefinerCall {
            cmd_name,
            args,
            arg_tokens,
            scope_path,
            original,
            ..
        } = call;
        if !original
            .map(super::original_definer::OriginalClassDefinerSource::grammar)
            .or_else(|| self.definition_grammar(cmd_name))
            .is_some_and(|grammar| grammar.family == tcl_registry::definer::DefinerFamily::JimClass)
        {
            return false;
        }
        // The definer's own arity is 2 or 3; any other shape is left to the
        // arity check.
        if !(2..=3).contains(&args.len()) || arg_tokens.len() != args.len() {
            return false;
        }
        let ns_prefix = self.command_resolution_namespace(scope_path);
        let qualified = super::handlers::qualify(&ns_prefix, &args[0]);
        let simple = crate::naming::key_tail(&qualified).to_string();
        let name_span = arg_tokens[0].span;
        // **W314** — the class name has no absolute written form.
        self.emit_w314_no_absolute_name(&args[0], name_span);

        let vars_at = args.len() - 1;
        let OriginalJimClassLists {
            bases_dynamic,
            superclasses,
            variable_words,
            source_bases,
        } = self.original_jim_class_lists(original, args);
        self.report_original_jim_dictionary_shape(cmd_name, &variable_words, arg_tokens[vars_at]);
        let own_variables: Vec<String> = variable_words.into_iter().step_by(2).collect();
        // A derived class's variable dictionary is its bases' merged with its
        // own, so a method body sees every inherited instance variable too.
        let mut variables = self.inherited_jim_class_variables(
            &superclasses,
            source_bases.as_deref(),
            original,
            scope_path,
        );
        for variable in own_variables {
            if !variables.contains(&variable) {
                variables.push(variable);
            }
        }

        let doc = std::mem::take(&mut self.last_comment);
        let original_name = original
            .and_then(super::original_definer::OriginalClassDefinerSource::original_name)
            .or_else(|| self.original_provider_class_name(name_span));
        let source_name = original_name.as_ref().and_then(|original| {
            crate::signature_scan::scope::SignatureSourceCommand::provider_advice_from_key(
                &self.declaration_namespace_scope(scope_path)?,
                original.name_input(),
            )
        });
        let mut class = ClassDef {
            source_name,
            name: simple,
            qualified_name: qualified.clone(),
            name_span,
            body_span: arg_tokens[vars_at].span,
            metaclass: cmd_name.to_string(),
            metaclass_provenance: super::types::MetaclassProvenance::Observed,
            superclasses,
            variables,
            inheritance_unknown: bases_dynamic,
            doc,
            ..Default::default()
        };
        self.retain_original_jim_relation_lookups(&mut class, source_bases, scope_path);
        self.retain_original_provider_class(original_name.as_ref(), &class);
        self.register_defined_class(qualified.clone(), class, scope_path);
        self.adopt_recorded_two_word_procs(&qualified, scope_path, original);
        true
    }

    pub(super) fn retained_source_advice_purpose(
        &self,
    ) -> Option<crate::command_binding::OriginalInvocationSourcePurpose> {
        let input = self
            .resolved_input
            .as_ref()
            .or(self.result.resolved_input.as_ref())?;
        let config = self.file_lexer_config();
        if input.lexer_config() != config {
            return None;
        }
        let context = self.analysis_context();
        let registry = context.commands();
        let metadata = crate::registry_invocation::InvocationMetadataContext::for_analysis_input(
            registry, input,
        )?;
        self.head_identities
            .source_bindings()
            .original_source_entry_purpose(
                &tcl_lexer::SourceImage::document(&self.source),
                config,
                metadata,
                registry,
            )
    }

    fn original_jim_class_lists(
        &self,
        original: Option<&super::original_definer::OriginalClassDefinerSource>,
        args: &[String],
    ) -> OriginalJimClassLists {
        let vars_at = args.len() - 1;
        let rules = self.word_rules();
        let words_of = |text: &str| -> Vec<String> {
            if crate::naming::is_dynamic_word(text) {
                return Vec::new();
            }
            rules
                .split_list(text)
                .map(|elements| elements.iter().map(ToString::to_string).collect())
                .unwrap_or_default()
        };
        let base_at = original
            .and_then(|source| source.grammar().source_base_class_list_argument(args.len()));
        let source_bases = base_at
            .and_then(|ordinal| original?.native_argument_input(ordinal))
            .and_then(
                crate::signature_scan::scope::SignatureSourceNameInput::original_list_elements,
            );
        let Some(purpose) = self.retained_source_advice_purpose() else {
            return OriginalJimClassLists {
                bases_dynamic: true,
                superclasses: Vec::new(),
                variable_words: Vec::new(),
                source_bases: None,
            };
        };
        let native = purpose != crate::command_binding::OriginalInvocationSourcePurpose::Logical;
        let bases_dynamic = if native {
            base_at.is_some() && source_bases.is_none()
        } else {
            args.len() == 3 && crate::naming::is_dynamic_word(&args[1])
        };
        let superclasses = if native {
            source_bases.as_ref().map_or_else(Vec::new, |inputs| {
                inputs
                    .iter()
                    .filter_map(|input| std::str::from_utf8(input.bytes()).ok().map(str::to_owned))
                    .collect()
            })
        } else if args.len() == 3 {
            words_of(&args[1])
        } else {
            Vec::new()
        };
        let variable_words = if native {
            original
                .and_then(|source| source.native_argument_input(vars_at))
                .and_then(
                    crate::signature_scan::scope::SignatureSourceNameInput::original_list_elements,
                )
                .map_or_else(Vec::new, |inputs| {
                    inputs
                        .iter()
                        .filter_map(|input| {
                            std::str::from_utf8(input.bytes()).ok().map(str::to_owned)
                        })
                        .collect()
                })
        } else {
            words_of(&args[vars_at])
        };
        OriginalJimClassLists {
            bases_dynamic,
            superclasses,
            variable_words,
            source_bases,
        }
    }

    fn retain_original_jim_relation_lookups(
        &self,
        class: &mut ClassDef,
        source_bases: Option<Vec<crate::signature_scan::scope::SignatureSourceNameInput>>,
        scope_path: &[usize],
    ) {
        let Some(purpose) = self.retained_source_advice_purpose() else {
            return;
        };
        let native = purpose != crate::command_binding::OriginalInvocationSourcePurpose::Logical;
        if native {
            for input in source_bases.into_iter().flatten() {
                let Ok(written) = std::str::from_utf8(input.bytes()) else {
                    continue;
                };
                class.relation_lookups.insert(
                    written.to_owned(),
                    self.declaration_namespace_scope(scope_path)
                        .and_then(|namespace| {
                            crate::signature_scan::scope::SignatureSourceLookup::from_input(
                                namespace, &input,
                            )
                        }),
                );
            }
        } else {
            for written in &class.superclasses {
                class.relation_lookups.insert(
                    written.clone(),
                    self.declaration_name_policy().and_then(|policy| {
                        crate::signature_scan::scope::SignatureSourceLookup::new(
                            policy,
                            self.declaration_namespace_scope(scope_path)?,
                            written.clone(),
                        )
                    }),
                );
            }
        }
    }

    fn report_original_jim_dictionary_shape(
        &mut self,
        command: &str,
        words: &[String],
        token: Token,
    ) {
        if words.len().is_multiple_of(2) {
            return;
        }
        let span = super::utils::full_word_span(token, &self.source);
        self.result.diagnostics.push(super::types::Diagnostic::new(
            tcl_core_types::DiagCode::E005,
            span,
            format!("Wrong argument-count shape for '{command}': the variable dictionary has an odd number of elements, so '{}' has no value", words[words.len() - 1]),
            super::types::Severity::Error,
        ));
    }

    fn inherited_jim_class_variables(
        &self,
        superclasses: &[String],
        inputs: Option<&[crate::signature_scan::scope::SignatureSourceNameInput]>,
        original: Option<&super::original_definer::OriginalClassDefinerSource>,
        scope_path: &[usize],
    ) -> Vec<String> {
        let classes: Vec<_> = if let Some(original) = original {
            inputs
                .into_iter()
                .flatten()
                .filter_map(|input| {
                    let reference =
                        crate::registry_invocation::source_structure::source_class_reference_at(
                            &self.source,
                            &self.result,
                            original.declaration().factory().site().offset,
                            input,
                        )?;
                    Some(
                        reference
                            .class_declaration()
                            .source_class(&self.result)?
                            .metadata()
                            .clone(),
                    )
                })
                .collect()
        } else {
            superclasses
                .iter()
                .filter_map(|base| {
                    self.resolve_user_class_in(base, scope_path)
                        .and_then(|qualified| self.result.all_classes.get(&qualified).cloned())
                })
                .collect()
        };
        let mut variables = Vec::new();
        for class in classes {
            for variable in class.variables {
                if !variables.contains(&variable) {
                    variables.push(variable);
                }
            }
        }
        variables
    }

    /// Attach genuine two-word procedure declarations to this source class.
    /// Native list children retain their own producer and naming scope; only
    /// explicit Logical compatibility may read reporting procedure names.
    fn adopt_recorded_two_word_procs(
        &mut self,
        class_q: &str,
        scope_path: &[usize],
        original: Option<&super::original_definer::OriginalClassDefinerSource>,
    ) {
        if let Some(original) = original {
            let calls: Vec<_> = self
                .result
                .original_procedure_declarations()
                .filter_map(|procedure| {
                    let (input, member) = original_two_word_proc_name(procedure)?;
                    let reference =
                        crate::registry_invocation::source_structure::source_class_reference_at(
                            &self.source,
                            &self.result,
                            original.declaration().factory().site().offset,
                            &input,
                        )?;
                    (reference.class_declaration().factory().site()
                        == original.declaration().factory().site())
                    .then(|| (reference, member, procedure.clone()))
                })
                .collect();
            for (reference, member, procedure) in calls {
                self.add_original_two_word_member(&reference, &member, &procedure, scope_path);
            }
            return;
        }
        if self.retained_source_advice_purpose()
            != Some(crate::command_binding::OriginalInvocationSourcePurpose::Logical)
        {
            return;
        }
        let rules = self.word_rules();
        let calls: Vec<_> = self
            .result
            .all_procs
            .values()
            .filter_map(|procedure| {
                let words = rules.split_list(&procedure.name).ok()?;
                let [class, member] = words.as_slice() else {
                    return None;
                };
                (self.resolve_user_class_in(class, scope_path).as_deref() == Some(class_q))
                    .then(|| (member.to_string(), procedure.clone()))
            })
            .collect();
        for (member, procedure) in calls {
            self.add_two_word_member(class_q, &member, &procedure, scope_path);
        }
    }

    /// Handle `CLASS member …` where `CLASS` is a `JimClass` class and `member`
    /// is one of its definer's own members (`CLASS method NAME ARGS BODY`),
    /// recording the member on the class and walking its body with the class
    /// variables and the grammar's implicit variables (`self`) bound.
    pub(super) fn handle_jim_class_member_call(
        &mut self,
        cmd_name: &str,
        args: &[String],
        arg_tokens: &[Token],
        scope_path: &[usize],
        command_token: Token,
    ) -> bool {
        let original = super::original_definer::OriginalClassCallSource::capture(
            &self.source,
            &self.result,
            command_token.span.start(),
        );
        let (args, arg_tokens, mut class_def, grammar) = if let Some(original) = &original {
            let Some(class) = original.call.class_declaration().source_class(&self.result) else {
                return false;
            };
            (
                original.arguments.as_slice(),
                original.tokens.as_slice(),
                class.metadata().clone(),
                original.grammar,
            )
        } else {
            let Some(class_q) = self.resolve_user_class_in(cmd_name, scope_path) else {
                return false;
            };
            let Some(class) = self.result.all_classes.get(&class_q).cloned() else {
                return false;
            };
            let Some(grammar) = self.class_definer_grammar(&class_q) else {
                return false;
            };
            (args, arg_tokens, class, grammar)
        };
        if grammar.family != tcl_registry::definer::DefinerFamily::JimClass {
            return false;
        }
        if !self.analyse_jim_inline_member(grammar, args, arg_tokens, &mut class_def, scope_path) {
            return false;
        }
        let class_q = class_def.qualified_name.clone();
        if let Some(original) = &original {
            self.retain_original_source_class_update(original.call.class_declaration(), &class_def);
        }
        self.register_defined_class(class_q, class_def, scope_path);
        true
    }

    fn analyse_jim_inline_member(
        &mut self,
        grammar: &'static DefinitionBodyGrammar,
        args: &[String],
        arg_tokens: &[Token],
        class_def: &mut ClassDef,
        scope_path: &[usize],
    ) -> bool {
        let Some(keyword) = args.first() else {
            return false;
        };
        if arg_tokens.len() != args.len() {
            return false;
        }
        let Some(member) = grammar.member(keyword) else {
            return false;
        };
        self.retain_original_inline_member_metadata(
            grammar, args, arg_tokens, class_def, scope_path,
        );
        let class_q = class_def.qualified_name.clone();
        let member_args = &args[1..];
        let member_tokens = &arg_tokens[1..];
        let parameter_indices = self.member_formal_parameter_indices(
            grammar,
            member,
            member_args,
            member_tokens,
            class_def,
        );
        super::diagnostics::emit_invalid_formal_parameter_list_diagnostics(
            self,
            member_args,
            member_tokens,
            &parameter_indices,
        );
        let mut seed_vars = class_def.variables.clone();
        seed_vars.extend(grammar.implicit_vars.iter().map(ToString::to_string));
        let mut ctx = ClassBodyCtx {
            grammar,
            class_def,
            class_qualified: &class_q,
            scope_path,
        };
        let form = MemberForm {
            member,
            kind: MethodKind::Method,
            label: "",
            visibility: "public",
        };
        self.extract_class_member(member_args, member_tokens, &mut ctx, &seed_vars, &form);
        true
    }

    /// Record a `proc` whose name is the two-element list `{CLASS member}` as a
    /// method of `CLASS` when `CLASS` is a class of a family that stores its
    /// members as two-word commands
    /// ([`tcl_registry::definer::DefinerFamily::members_are_two_word_commands`]).
    ///
    /// The procedure is itself the two-word command `{CLASS member}` — every
    /// dialect defines that — so this only adds the class-side fact. The
    /// method has no class variables and no `self` in its body: a raw
    /// definition is not wrapped by the class command's `method`. A class
    /// written after the `proc` adopts it when the class is defined
    /// ([`Self::adopt_recorded_two_word_procs`]).
    pub(super) fn record_two_word_proc_member(
        &mut self,
        proc_name: &str,
        proc: &super::types::ProcDef,
        scope_path: &[usize],
    ) {
        let Some(purpose) = self.retained_source_advice_purpose() else {
            return;
        };
        if purpose != crate::command_binding::OriginalInvocationSourcePurpose::Logical {
            let selected = self
                .result
                .original_procedure_declarations()
                .find_map(|original| {
                    (original.metadata().name_span == proc.name_span
                        && original.metadata().body_span == proc.body_span
                        && original.metadata().source_name == proc.source_name)
                        .then_some(())?;
                    let (input, member) = original_two_word_proc_name(original)?;
                    let reference =
                        crate::registry_invocation::source_structure::source_class_reference_at(
                            &self.source,
                            &self.result,
                            original.declaration_site().offset,
                            &input,
                        )?;
                    Some((reference, member, original.clone()))
                });
            if let Some((reference, member, procedure)) = selected {
                self.add_original_two_word_member(&reference, &member, &procedure, scope_path);
            }
            return;
        }
        let Ok(words) = self.word_rules().split_list(proc_name) else {
            return;
        };
        let [class_word, member_word] = words.as_slice() else {
            return;
        };
        let Some(class_q) = self.resolve_user_class_in(class_word, scope_path) else {
            return;
        };
        self.add_two_word_member(&class_q, member_word, proc, scope_path);
    }

    fn add_original_two_word_member(
        &mut self,
        reference: &crate::command_binding::OriginalSourceClassReference,
        member: &crate::signature_scan::scope::SignatureSourceNameInput,
        procedure: &crate::signature_scan::original_name::SourceDeclarationMetadata<
            super::types::ProcDef,
        >,
        scope_path: &[usize],
    ) {
        let declaration = reference.class_declaration();
        let context = self.analysis_context();
        if !declaration
            .grammar(&context)
            .is_some_and(|grammar| grammar.family.members_are_two_word_commands())
        {
            return;
        }
        let Some(original) = declaration.source_class(&self.result) else {
            return;
        };
        let mut class = original.metadata().clone();
        let Ok(label) = std::str::from_utf8(member.bytes()) else {
            return;
        };
        insert_original_two_word_member(&mut class, label, procedure.metadata());
        if !self.retain_original_two_word_source_member(reference, procedure, member, &mut class) {
            return;
        }
        self.retain_original_source_class_update(declaration, &class);
        self.register_defined_class(class.qualified_name.clone(), class, scope_path);
    }

    /// Add `proc` to `class_q` as its method `member` when the class's family
    /// stores its members as two-word commands.
    fn add_two_word_member(
        &mut self,
        class_q: &str,
        member: &str,
        proc: &super::types::ProcDef,
        scope_path: &[usize],
    ) {
        if !self
            .class_definer_grammar(class_q)
            .is_some_and(|grammar| grammar.family.members_are_two_word_commands())
        {
            return;
        }
        let Some(mut class_def) = self.result.all_classes.get(class_q).cloned() else {
            return;
        };
        insert_original_two_word_member(&mut class_def, member, proc);
        self.register_defined_class(class_q.to_string(), class_def, scope_path);
    }

    /// Parse an itcl class body through each statement's registry row: a
    /// superclass relation (`inherit`) → superclasses, declared state
    /// (`variable` / `common`) → the variables in scope, a callable (`method` /
    /// `proc` / `constructor` / `destructor`) → a method scope in the table its
    /// row lands in.  Two passes (so a method can reference any variable
    /// regardless of declaration order); an access modifier is a wrapper whose
    /// shift the row already carries — its member's visibility.
    fn parse_itcl_definition_body(
        &mut self,
        body: &str,
        body_tok: Token,
        class_def: &mut ClassDef,
        class_qualified: &str,
        scope_path: &[usize],
        grammar: &'static DefinitionBodyGrammar,
    ) {
        if body_tok.kind != TokenType::Str {
            return;
        }
        let base_offset = body_tok.span.start() + u32::from(body_tok.content_offset);
        let cmds = crate::segmenter::segment_commands_with_offset_and_config(
            body,
            base_offset,
            self.file_lexer_config().nested(),
        );

        // itcl injects `this` (the object's own command) into every method body.
        let implicit_vars = grammar.implicit_vars;
        let mut instance_vars: Vec<String> =
            implicit_vars.iter().map(|s| (*s).to_string()).collect();

        // Pass 1: declared state names (`variable` / `common`, under any
        // access modifier) + the ancestry an `inherit` names — each read off
        // the statement's row.
        let context = self.analysis_context();
        let dialect = Some(context.context().authoring_query());
        for cmd in &cmds {
            if cmd.is_partial || cmd.texts.is_empty() {
                continue;
            }
            // A base class an `inherit` names is a command reference (the same
            // registry-driven path TclOO's `superclass`/`mixin` use), so
            // find-references / go-to-definition / rename reach it across files.
            self.record_member_command_references(grammar, &cmd.texts, &cmd.argv, scope_path);
            let Some(statement) = MemberStatement::read(grammar, &cmd.texts, &cmd.argv, dialect)
            else {
                continue;
            };
            let args = statement.args();
            match statement.landing() {
                // Per-instance and per-type (`common`) state are both in scope
                // in an itcl method body.
                MemberLanding::State(_) => {
                    if let Some(name) = statement
                        .member
                        .indices_for_call_in(args, dialect, ArgRole::VarWrite)
                        .next()
                        .and_then(|i| args.get(i))
                    {
                        instance_vars.push(name.clone());
                    }
                }
                MemberLanding::Relation(RelationSlot::Superclass) => {
                    apply_slot_member(Some(statement.member), args, &mut class_def.superclasses);
                }
                _ => {}
            }
        }
        class_def.variables = instance_vars
            .iter()
            .filter(|v| !implicit_vars.contains(&v.as_str()))
            .cloned()
            .collect();

        // Pass 2: method-bearing members in their own method scopes.
        for cmd in &cmds {
            if cmd.is_partial {
                continue;
            }
            self.retain_original_member_metadata(grammar, cmd, class_def, scope_path);
            if let Some((keyword, kw_args, kw_toks)) =
                unwrap_wrapper_member(grammar, &cmd.texts, &cmd.argv)
                && let Some(member) = grammar.member(keyword)
            {
                let parameter_indices: Vec<usize> = member
                    .indices_for_call_in(kw_args, dialect, ArgRole::ParamList)
                    .collect();
                super::diagnostics::emit_invalid_formal_parameter_list_diagnostics(
                    self,
                    kw_args,
                    kw_toks,
                    &parameter_indices,
                );
            }
            // Only a body the row lands in a method table is a method scope:
            // `variable` / `common` are declarations (handled in pass 1) even
            // though `variable`'s optional config body carries an
            // `ArgRole::Body` (that body is highlighted by the token walker,
            // not recorded as a method here), and `inherit` carries no body.
            let Some(statement) = MemberStatement::read(grammar, &cmd.texts, &cmd.argv, dialect)
            else {
                continue;
            };
            let MemberLanding::Method(kind) = statement.landing() else {
                continue;
            };
            let label = member_label(statement.member, statement.keyword(), statement.args());
            let mut ctx = ClassBodyCtx {
                grammar,
                class_def,
                class_qualified,
                scope_path,
            };
            let form = MemberForm {
                member: statement.member,
                kind,
                label: &label,
                visibility: statement.row.visibility.as_str(),
            };
            self.extract_class_member(
                statement.args(),
                statement.arg_tokens(),
                &mut ctx,
                &instance_vars,
                &form,
            );
        }
    }

    /// Detect dispatch shape of a user-defined ``unknown`` proc.
    ///
    /// Lowers the proc body to IR, then walks the resulting
    /// top-level [`Statement`]s looking for:
    ///
    /// - Selected original case syntax referencing the first parameter —
    ///   exact labels become possible dispatch targets; glob/regexp modes
    ///   mark pattern dispatch. Canonical body-selection residuals remain
    ///   explicit. Selected case-folding child descriptors retain their own
    ///   original operand before setting ``case_insensitive``.
    /// - `Statement::Call` / `Statement::Barrier` that chains the original
    ///   handler ([`chains_original_unknown`]) — sets ``chains_original``.
    /// - a call that shells out ([`spawns_process`]) — sets ``has_exec``.
    /// - a call that loads more script ([`loads_external_unit`]) — sets
    ///   ``has_auto_load``.
    ///
    /// Empty bodies set ``empty_stub = true`` and skip the IR
    /// walk.  Lowering failures fall back to the conservative
    /// "fully dynamic" shape (every flag set, no targets) so
    /// downstream W123 emission stays suppressed.
    pub fn extract_unknown_proc_info(
        &mut self,
        body: &str,
        params: &[ParamDef],
    ) -> UnknownProcInfo {
        self.extract_unknown_proc_info_at(body, params, None)
    }

    /// Secondary body analysis uses the actual document source execution
    /// points when called by the procedure handler.
    pub(crate) fn extract_unknown_proc_info_at(
        &mut self,
        body: &str,
        params: &[ParamDef],
        base: Option<u32>,
    ) -> UnknownProcInfo {
        if body.trim().is_empty() {
            return UnknownProcInfo {
                empty_stub: true,
                ..Default::default()
            };
        }

        let first_param = params
            .first()
            .map_or_else(|| "cmd".to_string(), |p| p.name.clone());

        // Lower to IR.  On panic, be conservative — assume fully
        // dynamic — by returning an ``UnknownProcInfo`` with
        // every dynamic flag set so the W123 emitter suppresses
        // unresolved-command warnings file-wide (the safe
        // direction when we couldn't analyse the handler body).
        // naming.compiler.original-unknown-handler-source-context
        // docs/design/analysis/name-resolution-proofs/compiler-original-unknown-handler-source-context.md
        let context = self.analysis_context();
        let retained = self
            .resolved_input
            .as_ref()
            .or(self.result.resolved_input.as_ref());
        let config = retained.map_or_else(
            || self.lexer_config(),
            super::ResolvedAnalysisInput::lexer_config,
        );
        let profile = retained.map_or(self.profile, super::ResolvedAnalysisInput::unit_profile);
        let metadata = retained.and_then(|input| {
            crate::registry_invocation::InvocationMetadataContext::for_source_input(
                context.commands(),
                input,
                config,
                Some(profile),
            )
        });
        let Ok(script) = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
            let mut lowerer = crate::lowering::Lowerer::with_config(context.commands(), config)
                .with_dialect(Some(profile))
                .with_context_registry(std::sync::Arc::clone(&context));
            if let Some(input) = retained {
                lowerer = lowerer.with_resolved_analysis_input(input.clone());
            }
            if let Some(entry) = &self.source_analysis_entry {
                lowerer.set_source_analysis_options(entry.options());
            } else if let Some(input) =
                retained.filter(|input| input.has_logical_source_name_context())
            {
                // The standalone source helper requires positive retained
                // Logical input; no reconstructed profile grants that axis.
                if let Some(options) =
                    crate::command_binding::SourceAnalysisOptions::for_logical_source(input)
                {
                    lowerer.set_source_analysis_options(options);
                }
            }
            if let Some(base) = base {
                lowerer.lower_into_script_with_bindings(
                    body,
                    base,
                    "::",
                    self.head_identities.source_bindings(),
                )
            } else {
                lowerer.lower(body).top_level.clone()
            }
        })) else {
            return UnknownProcInfo {
                chains_original: true,
                case_insensitive: true,
                has_pattern_dispatch: true,
                has_exec: true,
                has_auto_load: true,
                ..Default::default()
            };
        };

        let mut info = UnknownProcInfo::default();
        for stmt in &script.statements {
            walk_unknown_stmt(
                stmt,
                &script,
                &context,
                metadata,
                &first_param,
                &mut info,
                0,
            );
        }

        info
    }
}

/// Walk an inline `oo::define Class subcmd ...` form using the selected
/// dialect's member layout. A recognised member option from another dialect
/// is not reinterpreted using the older positional layout.
/// The two dialect facts extracting a member definition needs, carried
/// together because they are read from the same document: the availability
/// point that resolves the member's argument roles, and the word-value rules
/// that split its parameter list.
#[derive(Clone, Copy)]
pub(super) struct MemberDialect<'a> {
    pub(super) surface: Option<SurfaceQuery<'a>>,
    pub(super) rules: WordValueRules,
}

pub(super) fn parse_oo_define_inline_in(
    analyser: &mut Analyser,
    grammar: &DefinitionBodyGrammar,
    args: &[String],
    arg_tokens: &[Token],
    class_def: &mut ClassDef,
    dialect: Option<SurfaceQuery<'_>>,
    scope_path: &[usize],
) {
    if args.is_empty() {
        return;
    }
    if args
        .first()
        .and_then(|subcmd| grammar.member(subcmd))
        .is_some_and(|member| member.unavailable_option_for(&args[1..], dialect).is_some())
    {
        return;
    }
    analyser
        .retain_original_inline_member_metadata(grammar, args, arg_tokens, class_def, scope_path);
    if let Some(member) = args.first().and_then(|subcmd| grammar.member(subcmd)) {
        let parameter_indices = analyser.member_formal_parameter_indices(
            grammar,
            member,
            &args[1..],
            arg_tokens.get(1..).unwrap_or(&[]),
            class_def,
        );
        super::diagnostics::emit_invalid_formal_parameter_list_diagnostics(
            analyser,
            &args[1..],
            arg_tokens.get(1..).unwrap_or(&[]),
            &parameter_indices,
        );
    }
    // Synthesise a single fake "command" matching what the
    // body walker would have produced.
    apply_oo_subcommand_in(
        grammar,
        args,
        arg_tokens,
        class_def,
        MemberDialect {
            surface: dialect,
            rules: analyser.word_rules(),
        },
    );
    analyser.retain_class_relation_lookups(args, class_def, scope_path);
}

/// Depth cap for [`walk_unknown_stmt`]'s recursion over nested `if`/`for`/
/// `while`/`foreach`/`catch`/`try`/`switch`/`Block`/`UpFrame` bodies —
/// Transitively bounded today via `MAX_LOWER_NEST_DEPTH`
/// (every `Script` this walk sees was built by `crate::lowering`, which
/// already caps its own construction at 256), capped here independently
/// for defence-in-depth and consistency with every other full-tree walker
/// in this crate.
const MAX_UNKNOWN_STMT_WALK_DEPTH: tcl_core_types::RecursionLimit =
    tcl_core_types::RecursionLimit(256);

/// Inspect a single IR statement for unknown-proc dispatch
/// markers.
///
/// Recurses through control-flow bodies (`if` clauses, `for` /
/// `while` / `foreach` bodies, `try` / `catch` bodies) so a
/// ``switch`` arm or ``exec`` call buried inside a guard or
/// loop is still detected. `depth` is `stmt`'s own nesting level — see
/// [`MAX_UNKNOWN_STMT_WALK_DEPTH`].
fn walk_unknown_stmt(
    stmt: &Statement,
    script: &crate::ir::Script,
    context: &tcl_registry::model::ContextRegistry,
    metadata: Option<crate::registry_invocation::InvocationMetadataContext<'_>>,
    first_param: &str,
    info: &mut UnknownProcInfo,
    depth: u32,
) {
    if MAX_UNKNOWN_STMT_WALK_DEPTH.exceeded(depth) {
        return;
    }
    // Select the purpose only after this original carrier agrees with the
    // complete supplied source owner. Availability-only metadata cannot turn
    // an original Logical carrier into the Native route.
    let source_metadata = metadata.and_then(|metadata| {
        let tokens = script.retained_source_tokens_for_statement(stmt)?;
        tokens
            .source_binding
            .as_ref()?
            .original_invocation_metadata_for_input(
                tokens,
                metadata.source_analysis_input()?,
                context.commands(),
            )
    });
    let case = source_metadata.and_then(|metadata| {
        if script
            .retained_source_tokens_for_statement(stmt)?
            .source_binding
            .as_ref()?
            .original_invocation_source_purpose(
                script.retained_source_tokens_for_statement(stmt)?,
                metadata,
                context.commands(),
            )?
            == crate::command_binding::OriginalInvocationSourcePurpose::Logical
        {
            crate::registry_invocation::source_structure::original_logical_source_case_for_tokens(
                script.retained_source_tokens_for_statement(stmt)?,
                context.commands(),
                metadata,
            )
        } else {
            crate::registry_invocation::source_structure::original_native_source_case_for_statement(
                script,
                stmt,
                context.commands(),
                metadata,
            )
        }
    });
    if let Some(case) = case
        && case.references_parameter(first_param)
    {
        info.case_insensitive |= case.folds_case();
        if case.mode() == tcl_registry::spec::CaseMatchMode::Exact {
            info.dispatch_targets
                .extend(case.patterns().iter().cloned());
        } else {
            info.has_pattern_dispatch = true;
        }
        info.case_body_residuals.push(case.body_operands().clone());
    }
    match stmt {
        Statement::Switch { arms, .. } => {
            // Recurse into arm bodies (a switch arm may contain
            // an exec or auto_load that should still register).
            for arm in arms {
                if let Some(body) = &arm.body {
                    for inner in &body.statements {
                        walk_unknown_stmt(
                            inner,
                            body,
                            context,
                            metadata,
                            first_param,
                            info,
                            depth + 1,
                        );
                    }
                }
            }
        }
        Statement::Call { .. } | Statement::Barrier { .. } | Statement::NativeCall { .. } => {
            // naming.compiler.original-unknown-handler-source-context
            // docs/design/analysis/name-resolution-proofs/compiler-original-unknown-handler-source-context.md
            // Logical source advice describes the exact selected operation;
            // Native execution still needs its independent proved target.
            let invocation = source_metadata.and_then(|metadata| {
                if script.retained_source_tokens_for_statement(stmt)?
            .source_binding.as_ref()?.original_invocation_source_purpose(
                script.retained_source_tokens_for_statement(stmt)?, metadata, context.commands(),
            )? == crate::command_binding::OriginalInvocationSourcePurpose::Logical {
                    crate::registry_invocation::original_logical_operation_invocation_with_metadata_context(
                        context.commands(), metadata, stmt.tokens()?,
                    )
                } else {
                    crate::registry_invocation::resolved_statement_invocation_with_metadata_context(
                        context.commands(), Some(metadata), stmt,
                    )
                }
            });
            if let Some(invocation) = invocation {
                info.chains_original |= chains_original_unknown(&invocation.facts);
                info.has_exec |= spawns_process(&invocation.facts);
                info.has_auto_load |= loads_external_unit(&invocation.facts);
            }
        }
        Statement::If {
            clauses, else_body, ..
        } => {
            for clause in clauses {
                for inner in &clause.body.statements {
                    walk_unknown_stmt(
                        inner,
                        &clause.body,
                        context,
                        metadata,
                        first_param,
                        info,
                        depth + 1,
                    );
                }
            }
            if let Some(body) = else_body {
                for inner in &body.statements {
                    walk_unknown_stmt(inner, body, context, metadata, first_param, info, depth + 1);
                }
            }
        }
        Statement::For { body, .. }
        | Statement::While { body, .. }
        | Statement::Foreach { body, .. }
        | Statement::Catch { body, .. }
        | Statement::Block { body, .. }
        | Statement::UpFrame { body, .. } => {
            for inner in &body.statements {
                walk_unknown_stmt(inner, body, context, metadata, first_param, info, depth + 1);
            }
        }
        Statement::Try {
            body,
            handlers,
            finally_body,
            ..
        } => {
            for inner in &body.statements {
                walk_unknown_stmt(inner, body, context, metadata, first_param, info, depth + 1);
            }
            for handler in handlers {
                for inner in &handler.body.statements {
                    walk_unknown_stmt(
                        inner,
                        &handler.body,
                        context,
                        metadata,
                        first_param,
                        info,
                        depth + 1,
                    );
                }
            }
            if let Some(body) = finally_body {
                for inner in &body.statements {
                    walk_unknown_stmt(inner, body, context, metadata, first_param, info, depth + 1);
                }
            }
        }
        Statement::AssignConst { .. }
        | Statement::AssignExpr { .. }
        | Statement::AssignValue { .. }
        | Statement::Incr { .. }
        | Statement::ExprEval { .. }
        | Statement::Return { .. } => {}
    }
}

/// Collect the two class-level (non-method) body kinds a definition body
/// can carry: a `property`'s `-get`/`-set` accessor scripts, and an
/// `initialise`/`initialize` block.
///
/// Neither is a method frame, so [`collect_method_body`] — restricted to the
/// four real method-bearing members — does not see them, yet each needs its
/// own scope in the per-body walk. Split out of `parse_oo_definition_body`
/// purely to
/// keep that walker within its line budget.
fn collect_class_level_bodies(
    grammar: &DefinitionBodyGrammar,
    texts: &[String],
    argv: &[Token],
    dialect: Option<SurfaceQuery<'_>>,
    accessor_bodies: &mut Vec<CollectedMethodBody>,
    init_bodies: &mut Vec<CollectedMethodBody>,
) {
    // Written directly in the class body — a wrapped spelling is no
    // class-level script of the class's own.
    let Some(statement) = MemberStatement::read(grammar, texts, argv, dialect)
        .filter(|statement| statement.row.keyword_index == 0)
    else {
        return;
    };
    match statement.landing() {
        MemberLanding::Accessors => collect_property_accessor_bodies(texts, argv, accessor_bodies),
        // A wrapper's block form is an init script too, but its members are
        // read one by one ([`expand_wrapper_block_members`]); only a member
        // of its own runs as the class's init script.
        MemberLanding::InitScript if statement.member.kind == MemberKind::Flat => {
            if let Some(body_idx) = statement.row.body.map(|body| body.0)
                && let (Some(body), Some(tok)) = (texts.get(body_idx), argv.get(body_idx).copied())
                && tok.kind == TokenType::Str
            {
                init_bodies.push(CollectedMethodBody {
                    name: format!("<{}>", statement.keyword()),
                    params: Vec::new(),
                    body_text: body.clone(),
                    body_tok: tok,
                    params_tok: None,
                    // A class-level init script is not a method frame at
                    // all — `self` raises there.
                    class_side: true,
                });
            }
        }
        _ => {}
    }
}

/// One definition-body member command's words with every **statically
/// determined** `{*}` expansion already spliced, or `None` when the command
/// has no expansion the analyser can resolve (the overwhelmingly common
/// case, kept allocation-free).
///
/// Tcl expands `{*}` during parsing, so a `{*}`-marked word whose text is a
/// literal is *not* one word — it is the elements of the list it holds, and
/// the member grammar's fixed argument layout applies to those.  Without
/// this normalisation `constructor {*}{args {…}}` / `method
/// {*}{foo {} {…}}` look one word short of their grammar and the member is
/// dropped entirely, with no diagnostic.  Verified
/// against tclsh 9.0.4 and 8.6.16: both forms define a real, callable
/// member, in the `oo::class create` body *and* the `oo::define` body.
///
/// Only a single **braced** (`Str`) word splices: braces suppress
/// substitution, so its element list is exactly what the runtime sees.  A
/// `{*}` over a variable or command substitution (`{*}[info class
/// definition …]`, the ticklecharts `chart3D` reflection idiom) has no
/// statically-knowable element list and is left verbatim — the member then
/// abstains exactly as before rather than being recorded with invented
/// parameters or a body span pointing at the wrong text.
///
/// Element spans come from the segmenter
/// ([`crate::segmenter::flatten_clause_list_elements_with_config`]), so each spliced
/// word carries its own true source range and downstream consumers
/// (document symbols, `my`-dispatch, hover) get real positions rather than
/// the whole-list span.
/// Expand a wrapper member's bare **script-block** form into the equivalent
/// prefix forms, so one walker handles both spellings of the same declaration.
///
/// `TclOO`'s `self` and `private` are the two members the registry marks
/// [`MemberKind::Wrapper`] *with* `wrapper_block_body`: each takes both
/// `self method NAME ARGS BODY` (prefix) and `self { method NAME ARGS BODY; … }`
/// (block, a definition script evaluated against the class object / with
/// private visibility).  Only the prefix form was ever walked, so every member
/// declared in a block was invisible to the whole analysis — no `ClassDef`
/// entry, hence no document-symbol node, no dispatch arity, and no body walk.
///
/// Returns `Some(calls)` — each `(texts, argv)` being the block's inner command
/// with the wrapper keyword (and its token) spliced back on at index 0 — for a
/// block form, and `None` for everything else, including the prefix form, which
/// the caller already handles as written.
///
/// Oracle, identical on tclsh 9.0.4 and 8.6.16 — the block form declares
/// exactly the same class-side methods the prefix form does:
///
/// ```tcl
/// oo::class create ::C {
///     self { method make {n} {return "made-$n"} ; method other {} {return other} }
///     method inst {} {return inst}
/// }
/// ::C make 7                  ;# -> made-7
/// info class methods ::C      ;# -> inst          (instance side untouched)
/// info object methods ::C     ;# -> other make    (class-object side)
/// oo::class create ::F { superclass ::C }
/// ::F make 1                  ;# -> error: unknown method "make"  (not inherited)
/// ```
///
/// and `export`/`unexport` inside the block act on the class-object side:
/// `oo::class create ::E { self { method hidden {} {…} ; unexport hidden } }`
/// leaves `info object methods ::E` empty while `-all -private` still lists
/// `hidden`.
///
/// Abstains — returning `None`, so the command is walked exactly as it is
/// today — on a dynamic (non-`Str`) block word, which cannot be re-segmented
/// statically, and on any shape carrying words after the block.
fn expand_wrapper_block_members(
    source: &str,
    grammar: &DefinitionBodyGrammar,
    texts: &[String],
    argv: &[Token],
    config: tcl_lexer::LexerConfig,
) -> Option<Vec<(Vec<String>, Vec<Token>)>> {
    use tcl_registry::definer::MemberKind;
    let keyword = texts.first()?;
    let keyword_tok = *argv.first()?;
    let member = grammar.member(keyword)?;
    if member.kind != MemberKind::Wrapper || !member.wrapper_block_body {
        return None;
    }
    // The prefix form — the word after the wrapper is itself a member keyword —
    // is already the spelling the walker consumes; leave it alone.
    let inner_first = texts.get(1)?;
    if grammar.member(inner_first).is_some() {
        return None;
    }
    // This is the wrapper's own fixed one-body layout, not an inner member
    // layout. The recursively spliced member goes back through the
    // profile-aware caller, so a Tcl 9 option cannot be accepted here under
    // Tcl 8.6.
    // `+ 1` because a member's registry arg-role indices are relative to its
    // *arguments*, while `texts`/`argv` still carry the keyword at 0.
    let body_idx = member.indices_for(ArgRole::Body).next()? + 1;
    if texts.len() != body_idx + 1 {
        return None;
    }
    let body_text = texts.get(body_idx)?;
    let body_tok = *argv.get(body_idx)?;
    if body_tok.kind != TokenType::Str {
        return None;
    }
    let base_offset = body_tok.span.start() + u32::from(body_tok.content_offset);
    let cmds = crate::segmenter::segment_commands_with_offset_and_config(
        body_text,
        base_offset,
        config.nested(),
    );
    let mut out: Vec<(Vec<String>, Vec<Token>)> = Vec::new();
    for cmd in &cmds {
        if cmd.is_partial || cmd.argv.is_empty() {
            continue;
        }
        let spliced = splice_static_member_expansions(source, cmd, config);
        let (inner_texts, inner_argv) = spliced
            .as_ref()
            .map_or((cmd.texts.as_slice(), cmd.argv.as_slice()), |(t, a)| {
                (t.as_slice(), a.as_slice())
            });
        let mut wrapped_texts = Vec::with_capacity(inner_texts.len() + 1);
        wrapped_texts.push(keyword.clone());
        wrapped_texts.extend(inner_texts.iter().cloned());
        let mut wrapped_argv = Vec::with_capacity(inner_argv.len() + 1);
        wrapped_argv.push(keyword_tok);
        wrapped_argv.extend(inner_argv.iter().copied());
        out.push((wrapped_texts, wrapped_argv));
    }
    Some(out)
}

fn splice_static_member_expansions(
    source: &str,
    cmd: &crate::segmenter::SegmentedCommand,
    config: tcl_lexer::LexerConfig,
) -> Option<(Vec<String>, Vec<Token>)> {
    let expand = cmd.expand_word.as_ref()?;
    if !expand.iter().any(|&e| e) {
        return None;
    }
    let mut texts: Vec<String> = Vec::with_capacity(cmd.texts.len());
    let mut argv: Vec<Token> = Vec::with_capacity(cmd.argv.len());
    let mut spliced = false;
    for (i, (text, tok)) in cmd.texts.iter().zip(cmd.argv.iter()).enumerate() {
        let is_static_expansion = expand.get(i).copied().unwrap_or(false)
            && tok.kind == TokenType::Str
            && cmd.single_token_word.get(i).copied().unwrap_or(false);
        if is_static_expansion {
            spliced = true;
            for (element, element_tok) in crate::segmenter::flatten_clause_list_elements_with_config(
                source, text, *tok, config,
            ) {
                texts.push(element);
                argv.push(element_tok);
            }
            continue;
        }
        texts.push(text.clone());
        argv.push(*tok);
    }
    spliced.then_some((texts, argv))
}

/// Per-subcommand dispatcher shared by the body-form and
/// inline-form walkers.
///
/// `texts` and `argv` are parallel: `texts[0]` / `argv[0]` is
/// the subcommand name (``superclass`` / ``method`` / etc.).
/// `oo::define Cls private <subcmd> ...` — wraps a method-defining
/// subcommand with `visibility = "private"`.  Extracted from
/// [`apply_oo_subcommand`] to keep the dispatch under threshold.
/// Display text stays separate from the actual source class declaration.
#[derive(Clone, Copy)]
struct MethodBodyClass<'a> {
    display: &'a str,
    declaration: Option<&'a ClassDef>,
}

/// A `TclOO` method body collected during the definition walk, with its actual
/// argument tokens. The source declaration stays separate from display text.
struct CollectedMethodBody {
    /// Method name (`<constructor>` / `<destructor>` for those forms).
    name: String,
    /// Formal parameters (empty for `destructor`).
    params: Vec<ParamDef>,
    /// Inner body text (braces stripped), as `analyse_body` expects.
    body_text: String,
    /// The body word token (carries the absolute span + `content_offset`).
    body_tok: Token,
    /// The raw param-list word token (`{a b}`), used to anchor each formal
    /// parameter's definition span at its name. `None` for
    /// `destructor` (no parameter list).
    params_tok: Option<Token>,
    /// True for a **class-side** member (`classmethod`, `self method`) —
    /// and for any collected body that is not a real instance-side method
    /// invocation frame (class `initialise` scripts, `property` accessor
    /// bodies). Gates [`super::types::Scope::oo_defining_class`]: `[self
    /// class]` *raises* in a class-side frame, so no defining-class fact may
    /// be recorded for one.
    class_side: bool,
}

/// Bodies collected from a definition grammar before their scopes can be
/// walked with the complete class variable set.
#[derive(Default)]
struct CollectedDefinitionBodies {
    methods: Vec<CollectedMethodBody>,
    accessors: Vec<CollectedMethodBody>,
    initialisers: Vec<CollectedMethodBody>,
}

/// Recognise a method-defining statement in a class body and return its body
/// to walk in a fresh [`ScopeKind::Method`] scope.
///
/// Whether the statement opens a method frame is its registry row's answer (a
/// callable landing in a method table), and the member's argument layout —
/// which word is the name, the parameter list, and the recursable body — comes
/// entirely from its registry [`MemberSpec`] arg-roles (never hardcoded
/// indices), so a definer that adds or reshapes a method-bearing member is
/// picked up from the grammar alone.
///
/// A class-level init script (`initialise` / `initialize`, walked in a scope
/// of its own by the caller) and a wrapper's block form are not method frames,
/// even though the grammar marks each as carrying a body. A forward has no
/// body; dynamic (non-braced) bodies are filtered downstream by
/// [`Analyser::walk_method_body`].
fn collect_method_body(
    grammar: &DefinitionBodyGrammar,
    texts: &[String],
    argv: &[Token],
    dialect: Option<SurfaceQuery<'_>>,
    rules: WordValueRules,
) -> Option<CollectedMethodBody> {
    // A wrapped member (`self method …`, `private method …`) is read through
    // its wrapper: its body would otherwise never be walked at all (no internal
    // diagnostics inside a `self method`/`private method` body — confirmed
    // empirically, a deliberately-wrong-arity call inside one drew nothing,
    // while the identical call in a plain `method` body correctly fired). The
    // row's keyword is the wrapped member's own, so the slices below start
    // right after the *effective* keyword either way.
    let statement = MemberStatement::read(grammar, texts, argv, dialect)?;
    if !matches!(statement.landing(), MemberLanding::Method(_)) {
        return None;
    }
    // A member on the class object (`classmethod`, `self method`) runs in a
    // class-side frame, where `[self class]` never answers the written class
    // (tclsh 9.0.4: it raises "method not defined by a class" in a
    // `self method`, and answers the internal `::oo::ObjN:: oo ::delegate`
    // class in a `classmethod`).
    let class_side = statement.row.receiver != MemberReceiver::Instance;
    let (member, keyword, texts, argv) = (
        statement.member,
        statement.keyword(),
        statement.args(),
        statement.arg_tokens(),
    );
    let body_idx = member
        .indices_for_call_in(texts, dialect, ArgRole::Body)
        .next()?;
    let params_idx = member
        .indices_for_call_in(texts, dialect, ArgRole::ParamList)
        .next();
    let name_idx = member
        .indices_for_call_in(texts, dialect, ArgRole::Name)
        .next();

    let body_text = texts.get(body_idx)?.clone();
    let body_tok = *argv.get(body_idx)?;
    // A named member (`method NAME …`) uses its name word; the nameless forms
    // (`constructor` / `destructor`) get a synthetic `<keyword>` name.
    let name = name_idx
        .and_then(|i| texts.get(i))
        .map_or_else(|| format!("<{keyword}>"), String::clone);
    let params = params_idx
        .and_then(|i| texts.get(i))
        .map_or_else(Vec::new, |p| parse_param_list(p, rules));
    let params_tok = params_idx.and_then(|i| argv.get(i).copied());
    Some(CollectedMethodBody {
        name,
        params,
        body_text,
        body_tok,
        params_tok,
        class_side,
    })
}

/// Apply a *retracting* member word (`deletemethod m`, `self renamemethod old
/// new`, `private deletemethod m`) to `side`'s method table: remove every name
/// it retracts, and — for a renaming word — re-record the removed member under
/// the name it **arrives** at.
///
/// Which member words retract, and *which of their arguments* they retract or
/// re-key, is registry data ([`MemberSpec::retraction`] /
/// [`tcl_registry::definer::MemberRetraction::split`]), never a keyword matched
/// here — the sibling
/// [`MemberRefKind::Method`] members (`export` / `unexport` / `filter`) name a
/// method without removing it and must not retract.
///
/// `arg_tokens` is the *same slice* as `names`, word for word: the arrival
/// name's own token is the synthetic declaration site the moved member gets
/// (see below), so it has to be reachable from the index the registry hands
/// back.
///
/// # The rename really moves the member
///
/// `renamemethod old new` is not a deletion — it is a move, and the destination
/// is a fully dispatchable member carrying the *source's* body, parameters and
/// visibility. Oracle, byte-identical on tclsh 9.0.4 and 8.6.14:
///
/// ```tcl
/// oo::class create ::R1 { method old {} { return OLDBODY } ; renamemethod old new }
/// info class methods ::R1              ;# -> new
/// [::R1 new] new                       ;# -> OLDBODY            (the old body runs)
/// info class definition ::R1 new       ;# -> {} { return OLDBODY }
/// oo::class create ::R4 { method Priv {} {…} ; renamemethod Priv pub }
/// info class methods ::R4              ;# -> (empty)   `pub` is still UNexported…
/// info class methods ::R4 -private     ;# -> pub       …because `Priv` was
/// oo::class create ::R5 { method low {} {…} ; renamemethod low Up }
/// info class methods ::R5              ;# -> Up        …and `Up` is still exported
/// ```
///
/// so the moved [`MethodDef`] keeps its `visibility` verbatim — the family's
/// name-based default (`[a-z]*` is exported for `TclOO`) is applied when a
/// member is *(re)declared*, never when one is renamed. Its `body_span` also
/// stays pointing at the original body, which is the only real body there is;
/// only `name` and `name_span` move, the latter onto the `renamemethod` call's
/// own destination word — the natural go-to-definition target for a member
/// whose sole textual mention of the new name is right there.
///
/// # Definition-aborting shapes
///
/// Real Tcl aborts the *whole* definition — no class is created at all — when a
/// retracting word names a member that does not exist on its own side, or
/// renames onto a name that side already holds. Each is recorded as a
/// [`DefinitionAbort`] for the class handlers to turn into a `W315`; the
/// partial class is still built, so navigation degrades rather than vanishing.
/// This is the one site that can detect them, because it is the only place that
/// knows the side's table state *at the point the word runs* — which is exactly
/// the granularity real Tcl uses (`method a ; method b ; deletemethod b ;
/// renamemethod a b` is legal, and leaves `b`).
///
/// # Tombstones for what this record cannot see
///
/// A name this record does **not** declare leaves a *tombstone* in
/// [`ClassDef::retracted_members`] instead: that is the cross-document shape —
/// `oo::class create ::C { method m … }` in one file, `oo::define ::C {
/// deletemethod m }` in another — where the second file's `via_define` stub has
/// nothing local to remove, and dropping the retraction on the floor leaves the
/// workspace advertising a method that sourcing the extension deletes.
/// A retraction of a member the same document declares needs no
/// tombstone: it removed the entry outright, the order within one body is known,
/// and exporting it would wrongly cancel a *different* document's redeclaration
/// of the name, which no ordering evidence supports.
///
/// Tombstone and abort are the same fact read under different knowledge, so
/// they are mutually exclusive by construction: whether this record is a
/// cross-file stub is not knowable here, so *both* are recorded and the class
/// handler — which does know ([`ClassDef::via_define`]) — keeps exactly one.
fn retract_named_members(
    member: &MemberSpec,
    names: &[String],
    arg_tokens: &[Token],
    class_def: &mut ClassDef,
    side: MemberSide,
) {
    let Some(retraction) = member.retraction else {
        return;
    };
    let words = retraction.split(names);
    // The name the retracted member re-appears under, with the word whose span
    // becomes its synthetic declaration site. A dynamic destination
    // (`renamemethod old $new`) names nothing statically, so the move abstains
    // and the source is simply retracted — a false negative, the direction this
    // campaign abstains toward.
    let arrival = words
        .arrives_at
        .and_then(|i| Some((names.get(i)?, *arg_tokens.get(i)?)))
        .filter(|(name, tok)| !has_substitution(name, tok));
    for (i, name) in words.retracted.iter().enumerate() {
        let tok = arg_tokens.get(i).copied();
        // A dynamic source name (`deletemethod $m`) resolves to nothing
        // statically: it may or may not name a live member, so neither the
        // removal, the tombstone, nor the abort has evidence behind it.
        if tok.is_some_and(|t| has_substitution(name, &t)) {
            continue;
        }
        let Some(removed) = side.table(class_def).remove(name) else {
            // Nothing local to remove: the cross-file stub shape.  The
            // tombstone carries the *arrival* too when the retracting word was
            // a move — the stub has no `MethodDef` to re-key, so
            // recording where the member goes is the only way the workspace
            // join can put it there.  Its own arrival word is the synthetic
            // declaration site, exactly as it is for a same-file move.
            class_def
                .retracted_members
                .push(crate::analyser::types::MemberRetractionRecord {
                    member: name.clone(),
                    side,
                    arrival: arrival.map(|(new_name, _)| new_name.clone()),
                    arrival_span: arrival.map(|(_, tok)| tok.span),
                });
            if let Some(tok) = tok {
                class_def.definition_aborts.push(DefinitionAbort {
                    kind: DefinitionAbortKind::MissingMember,
                    member: name.clone(),
                    span: tok.span,
                });
            }
            // Nothing was removed, so there is nothing to move and no
            // destination question to ask: real Tcl fails on the source word
            // first (`renamemethod ghost b` reports `method ghost does not
            // exist`, never `method called b already exists`), and one word
            // earns one report.
            continue;
        };
        let Some((new_name, new_tok)) = arrival else {
            continue;
        };
        // The member state this move runs against, captured with the source
        // already removed and the destination not yet inserted — exactly the
        // table the interpreter reads at this point in the body.
        let moved = RenamedMember {
            source: name.clone(),
            destination: new_name.clone(),
            side,
            destination_span: new_tok.span,
            blocked: side.table(class_def).keys().cloned().collect(),
        };
        // One fold decides both readings of that state: whether the destination
        // actually written aborts the definition (`W315`, below) and whether
        // some *other* name would (the rename gate, which asks the recorded
        // `RenamedMember` the same question). Deciding them in one place is what
        // stops the diagnostic and the gate from drifting apart.
        //
        // A rename real Tcl rejects moves nothing — and rather than let the
        // wreckage take a declaration with it, the source stays under its own
        // name and an existing destination keeps its own body. Both members the
        // author wrote are then still navigable, which is the whole point of
        // recording a class that cannot run.
        if let Some(kind) = moved.abort_if_renamed_to(new_name) {
            class_def.definition_aborts.push(DefinitionAbort {
                kind,
                member: new_name.clone(),
                span: new_tok.span,
            });
            side.table(class_def).insert(name.clone(), removed);
            continue;
        }
        let mut md = removed;
        // Only the identity moves: the body span still points at the one real
        // body, and the visibility is the source's (oracle above), not the
        // destination name's family default.
        md.name.clone_from(new_name);
        md.name_span = new_tok.span;
        side.table(class_def).insert(new_name.clone(), md);
        class_def.renamed_members.push(moved);
    }
}

/// Apply a member word's **visibility effect** — `export` / `unexport` — to the
/// members it names, scoped to `side`.
///
/// A no-op for a member carrying no effect: which words set visibility is
/// registry data ([`MemberSpec::visibility_effect`]), never a keyword matched
/// here, exactly as [`MemberSpec::retraction`] decides which words
/// retract. The sibling [`MemberRefKind::Method`] member `filter` names a method
/// and does neither, so it falls through untouched, and a definition grammar for
/// another class system gets the same handling by declaring the effect on its
/// own member word.
///
/// The names also update the class-level visibility sets **of that side** —
/// `exports`/`unexports` for the instance side, `class_exports`/
/// `class_unexports` for the class-object side ([`MemberSide::visibility_sets`]).
/// The pair is what carries the flip across documents: a `via_define` stub
/// declares no member to flip, so without a recorded set a `self unexport m` in
/// one file never reaches another file's class-command dispatch.
/// The two pairs stay strictly apart — `exports`/`unexports` are the
/// *instance*-side record by contract (`workspace_index`'s effective-export
/// union over `instance_method`, `rename_safety`'s "the class declares this
/// name" test), so a class-object-side flip landing there would silently
/// re-state an unrelated instance method's export bit.
///
/// Within a pair the two sets are maintained **mutually exclusive**, because
/// each is a record of the *last* writer for the name and the union consumer
/// reads any `exports` entry as decisive: `method m {} {…} ; export m ;
/// unexport m` must leave `m` in `unexports` alone, or cross-file dispatch would
/// keep advertising a method that `[C new] m` rejects with `unknown method "m"`
/// (tclsh 9.0.4 / 8.6.14).
fn apply_visibility_member(
    member: &MemberSpec,
    names: &[String],
    class_def: &mut ClassDef,
    side: MemberSide,
) {
    let Some(effect) = member.visibility_effect else {
        return;
    };
    let visibility = match effect {
        MemberVisibility::Exported => "public",
        MemberVisibility::Unexported => "unexported",
    };
    let (exports, unexports) = side.visibility_sets(class_def);
    let (set, cleared) = match effect {
        MemberVisibility::Exported => (exports, unexports),
        MemberVisibility::Unexported => (unexports, exports),
    };
    for name in names {
        set.insert(name.clone());
        cleared.remove(name);
    }
    set_member_visibility(class_def, names, visibility, side);
}

/// Fold a relation row into the graph its slot feeds, on the side the row
/// resolved to.
///
/// `superclasses` / `mixins` feed the class-hierarchy graph (inherited
/// methods, MRO).  The navigable *references* to those base classes are
/// recorded separately as `command_invocations` by
/// `record_member_command_references`, so no per-name span is kept here.
/// A class object's own ancestry is not the class's (`self mixin M` mixes
/// into the class object, which no instance inherits), so a class-side
/// superclass or mixin row records nothing.
///
/// The two filter slots are separate slots that intercept different
/// dispatches (see [`ClassDef::filters`] and [`ClassDef::class_filters`] for
/// the oracle), so a `filter` call lands in the slot of the side its wrapper
/// put it on, never in one flat list: `self filter f` fills the class
/// object's own filter slot, which intercepts dispatches on the *class
/// command* (`::B cls`, and even `::B new`) while leaving instances unfiltered
/// — `info object filters ::B` -> `f`, `info class filters ::B` -> empty, on
/// tclsh 9.0.4 and 8.6.14 alike — and `private filter s` fills the
/// *instance* slot (`info class filters`, tclsh 9.0.4; `private` does not
/// exist on 8.6).
///
/// What the word does to the slot is registry data ([`MemberSpec::slot`]):
/// `filter a; filter b` leaves both live (`-append` default — tclsh 9.0.4 /
/// 8.6.16: `info class filters` → `a b`), `superclass` / `mixin` replace
/// (`-set` default — tclsh 9.0.4: `superclass A` then `superclass -append B`
/// → `::A ::B`), and the explicit operations fold through
/// [`tcl_registry::definer::SlotSpec::apply`] — the same fold every slot
/// consumer uses, so they cannot diverge.
fn apply_relation_member(
    member: &MemberSpec,
    slot: RelationSlot,
    args: &[String],
    class_def: &mut ClassDef,
    side: MemberSide,
) {
    let list = match (slot, side) {
        (RelationSlot::Superclass, MemberSide::Instance) => &mut class_def.superclasses,
        (RelationSlot::Mixin, MemberSide::Instance) => &mut class_def.mixins,
        (RelationSlot::Filter, side) => side.filter_list(class_def),
        (RelationSlot::Superclass | RelationSlot::Mixin, MemberSide::ClassObject) => return,
    };
    apply_slot_member(Some(member), args, list);
}

/// Fold one slot-member call (`filter` / `superclass` / `mixin` /
/// `variable`) into `list` through the member's registry [`SlotSpec`]
/// — the one place the analyser applies slot semantics, so
/// the instance / class-object filter slots, the superclass list, the mixin
/// list, and the declared-variable slot all take the identical fold.
///
/// A member with no slot spec — a relation that is a plain list of class
/// references, like itcl's `inherit`, which takes no operation words — adds
/// the names it lists.
fn apply_slot_member(member: Option<&MemberSpec>, args: &[String], list: &mut Vec<String>) {
    match member.and_then(|m| m.slot) {
        Some(slot) => slot.apply(list, args),
        None => list.extend(args.iter().cloned()),
    }
}

/// The effective default visibility string for a freshly-(re)defined
/// member under `grammar`'s family rule (`"public"` / `"unexported"`).
fn default_visibility(grammar: &DefinitionBodyGrammar, name: &str) -> String {
    if grammar.member_default_exported(name) {
        "public".to_string()
    } else {
        "unexported".to_string()
    }
}

/// The visibility of a newly-declared member, selected by its grammar's
/// optional declaration argument when present and otherwise by the caller's
/// family/wrapper default. No caller needs to parse a member-specific flag.
fn declared_member_visibility(
    member: &MemberSpec,
    args: &[String],
    fallback: String,
    dialect: Option<SurfaceQuery<'_>>,
) -> String {
    member
        .declared_visibility_for_in(args, dialect)
        .map_or(fallback, |visibility| visibility.as_str().to_string())
}

/// Set the recorded visibility of each named member on `side` only to
/// `visibility` — the `export` / `unexport` member effect.
///
/// A name with no recorded member **on that side** is skipped: a later `method`
/// definition re-applies the name default anyway (tclsh 9.0.4-pinned), an
/// export-only stub has no declaration to navigate to, and — pinned on 9.0.4 and
/// 8.6.14 alike — naming a method that exists only on the *other* side really is
/// a no-op in Tcl, so skipping it is the faithful answer, not an abstention.
fn set_member_visibility(
    class_def: &mut ClassDef,
    names: &[String],
    visibility: &str,
    side: MemberSide,
) {
    let table = side.table(class_def);
    for name in names {
        if let Some(md) = table.get_mut(name) {
            md.visibility = visibility.to_string();
        }
    }
}

/// `oo::define Cls forward name target ...` — records a forward
/// alias as a method, keeping the target command and any prepended
/// arguments (`forward`'s own version of `interp alias` partial
/// application) so a call through the forward can be arity-checked
/// against `target`'s own signature, shifted by the prepended count —
/// see `Analyser::resolve_indirect_call_target`.  Which words are the name and
/// the target is the row's [`MemberEffect::Forward`] slots.
fn apply_oo_forward(
    statement: &MemberStatement<'_>,
    class_def: &mut ClassDef,
    dialect: Option<SurfaceQuery<'_>>,
) {
    let MemberEffect::Forward {
        name_slot,
        prefix_slot,
    } = statement.row.effect
    else {
        return;
    };
    let (args, tokens) = (statement.args(), statement.arg_tokens());
    let (name_slot, prefix_slot) = (usize::from(name_slot), usize::from(prefix_slot));
    if let Some(name) = args.get(name_slot) {
        let span = tokens
            .get(name_slot)
            .map_or(tcl_lexer::Span::new(0, 0), |token| token.span);
        let forward_target = args.get(prefix_slot).map(|target| {
            (
                target.clone(),
                args.get(prefix_slot + 1..).unwrap_or(&[]).to_vec(),
            )
        });
        let md = MethodDef {
            name: name.clone(),
            params: Vec::new(),
            params_computed: false,
            formal_count: crate::signature_scan::formal_count::SourceFormalCount::Authored(
                tcl_dialect::ParameterGrammar::Tcl,
            ),
            name_span: span,
            body_span: span,
            kind: "forward".to_string(),
            is_self_method: false,
            // A forward is dispatched by the same name rule as a method
            // (C computes `isPublic` identically for both).
            visibility: statement.recorded_visibility(name, dialect),
            doc: String::new(),
            forward_target,
        };
        class_def.methods.insert(md.name.clone(), md);
    }
}

#[cfg(test)]
pub(super) fn apply_oo_subcommand(
    grammar: &DefinitionBodyGrammar,
    texts: &[String],
    argv: &[Token],
    class_def: &mut ClassDef,
) {
    apply_oo_subcommand_in(
        grammar,
        texts,
        argv,
        class_def,
        MemberDialect {
            surface: None,
            rules: WordValueRules::TCL,
        },
    );
}

/// Apply one registry member using the selected dialect's concrete layout.
///
/// The statement's [`MemberRow`] decides everything: its effect says what the
/// member declares ([`member_landing`], the routing the snit and itcl walkers
/// share) and its resolved receiver says which side it lands on. A wrapper's
/// shift is already in that receiver, so `self` and `private` have no arm of
/// their own: `self method` lands among the class methods because its row's
/// receiver is the type object, `private method` among the instance methods
/// with the visibility its shift declares, and the block forms reach here
/// member by member, prefixed with their wrapper by
/// [`expand_wrapper_block_members`]. A statement the registry cannot read
/// records nothing.
///
/// A member word that *removes* the members it names — `deletemethod m`,
/// `renamemethod old new` — and one that flips their visibility — `export`
/// / `unexport` — act on their row's side and nowhere else: written with no
/// wrapper, the **instance** side; under `self`, the class-object side;
/// under `private`, `private`'s own (instance) side, including a member the
/// same block just recorded. Oracle, byte-identical on tclsh 9.0.4 and
/// 8.6.14:
///
/// ```tcl
/// oo::class create ::I1 { method gone {} {…}; method kept {} {…}
///                         deletemethod gone }
/// info class methods ::I1   ;# -> kept
/// oo::class create ::I3 { method old {} {…}; renamemethod old new }
/// info class methods ::I3   ;# -> new          (`old` really is gone)
/// oo::class create ::I4 { method gone {} {…} }
/// oo::define ::I4 { deletemethod gone }
/// info class methods ::I4   ;# -> (empty)
/// oo::class create C { method m {} {…}
///                      self { method m {} {…}; unexport m } }
/// info object methods ::C   ;# -> (empty)     class-side `m` unexported
/// info class methods ::C    ;# -> m           instance side untouched
/// ```
///
/// and `oo::class create E2 { self { method onlyclass {} {…} } }` then
/// `oo::define E2 { unexport onlyclass }` leaves the class-object side's
/// `onlyclass` exported and dispatchable, while `oo::define E { self
/// unexport onlyinst }` naming a method only the *other* side has is a
/// silent no-op, not the hard error `deletemethod` raises.
pub(super) fn apply_oo_subcommand_in(
    grammar: &DefinitionBodyGrammar,
    texts: &[String],
    argv: &[Token],
    class_def: &mut ClassDef,
    dialect: MemberDialect<'_>,
) {
    let Some(statement) = MemberStatement::read(grammar, texts, argv, dialect.surface) else {
        return;
    };
    let Some(side) = member_side(statement.row.receiver) else {
        return;
    };
    let (member, words, tokens) = (statement.member, statement.args(), statement.arg_tokens());
    match statement.landing() {
        MemberLanding::Method(kind) => record_declared_method(&statement, kind, class_def, dialect),
        // `class_methods` holds the `classmethod`-kind entries the
        // class-command dispatch reads, so a class-object forward
        // (`self forward`) stays unrecorded.
        MemberLanding::Forward if side == MemberSide::Instance => {
            apply_oo_forward(&statement, class_def, dialect.surface);
        }
        // Additive, not a reset (tclsh9.0-verified: `oo::define Cls
        // variable a b; oo::define Cls variable c` leaves all of `a`, `b`, `c`
        // live simultaneously), because the class `variable` word is a slot
        // whose default operation is `-append` (with dedup — tclsh 9.0.4:
        // `variable a; variable a b` → `a b`); the explicit `-set` / `-clear`
        // / `-remove` operations fold through the same registry fold as every
        // other slot. A class-object variable (`self variable`) is no instance
        // variable of the class.
        MemberLanding::State(_) if side == MemberSide::Instance => {
            apply_slot_member(Some(member), words, &mut class_def.variables);
        }
        MemberLanding::Relation(slot) => {
            apply_relation_member(member, slot, words, class_def, side);
        }
        MemberLanding::Retraction => retract_named_members(member, words, tokens, class_def, side),
        MemberLanding::Visibility => apply_visibility_member(member, words, class_def, side),
        MemberLanding::Accessors if side == MemberSide::Instance => {
            extract_property_defs(words, tokens, class_def);
        }
        // A class-level init script's body is collected and walked on its
        // own ([`collect_class_level_bodies`]); a procedure, a configuration
        // word and the wrapped spellings of the sided arms above record
        // nothing here.
        _ => {}
    }
}

/// Record a callable member row as the [`MethodDef`] its kind names.
///
/// The name, parameter list and body words come from the member's registry
/// layout ([`extract_method_def_in`]); a nameless member (a constructor or
/// destructor) is recorded under its synthetic `<keyword>` name and anchored on
/// its keyword, where an editor lands for go-to-definition and hover. A method
/// (re)definition takes the visibility its row names — the family's name-based
/// default unless its option word or wrapper says otherwise — discarding any
/// earlier explicit `export`/`unexport` of the name (tclsh 9.0.4-pinned; the
/// rule itself is registry data — `[a-z]*` for `TclOO`).
///
/// A member a receiver-moving wrapper put on the class object (`self method
/// NAME ARGS BODY`, `TclOO`'s own spelling of a class-level method) is tagged
/// `is_self_method`, so the class-command MRO walk in `tcl-lsp-core` knows not
/// to treat it as inherited the way a `classmethod` is (real tclsh: a subclass
/// with no override does not gain a `self method` at all).
fn record_declared_method(
    statement: &MemberStatement<'_>,
    kind: MethodKind,
    class_def: &mut ClassDef,
    dialect: MemberDialect<'_>,
) {
    let synthetic = format!("<{}>", statement.keyword());
    let Some(mut md) = extract_method_def_in(
        statement.member,
        statement.args(),
        statement.arg_tokens(),
        kind.as_str(),
        "public",
        &synthetic,
        dialect,
    ) else {
        return;
    };
    if matches!(
        statement.row.effect,
        MemberEffect::Callable {
            name_slot: None,
            ..
        }
    ) && let Some(keyword) = statement.keyword_token()
    {
        md.name_span = keyword.span;
    }
    md.visibility = statement.recorded_visibility(&md.name, dialect.surface);
    md.is_self_method = kind == MethodKind::ClassMethod && statement.shift().receiver.is_some();
    record_method(class_def, kind, md);
}

/// Extract property definitions from a ``property`` subcommand.
///
/// Walks the args, splitting names from option values
/// (``-get BODY``, ``-set BODY``, ``-kind readable|writable|readwrite``).
/// Each property gets a [`PropertyDef`] entry in
/// ``class_def.properties``.
///
/// All property options take a value (``-get``, ``-set``,
/// ``-kind``); there are no flag-only options.  When ``-kind``
/// is omitted the property defaults to ``"readwrite"``.
///
/// This records only the class-level `PropertyDef` entries; the
/// accessor (`-get` / `-set`) bodies are collected and walked
/// separately by [`collect_property_accessor_bodies`].
fn extract_property_defs(args: &[String], arg_tokens: &[Token], class_def: &mut ClassDef) {
    let zero = Span::new(0, 0);

    // Collect property names + their per-arg index, then the
    // trailing options, in a two-pass shape.
    let mut names: Vec<(String, usize)> = Vec::new();
    let mut kind = "readwrite".to_string();
    let mut getter_defined = false;
    let mut setter_defined = false;

    let mut i = 0;
    while i < args.len() {
        let arg = &args[i];
        if let Some(stripped) = arg.strip_prefix('-') {
            // All property options take a value.
            if i + 1 >= args.len() {
                i += 1;
                continue;
            }
            let value = &args[i + 1];
            match stripped {
                "kind" => kind.clone_from(value),
                "get" => getter_defined = true,
                "set" => setter_defined = true,
                _ => {}
            }
            i += 2;
            continue;
        }
        names.push((arg.clone(), i));
        i += 1;
    }

    for (name, idx) in names {
        let span = arg_tokens.get(idx).map_or(zero, |t| t.span);
        class_def.properties.insert(
            name.clone(),
            PropertyDef {
                name,
                name_span: span,
                kind: kind.clone(),
                has_getter: getter_defined,
                has_setter: setter_defined,
            },
        );
    }
}

/// Collect the `-get` / `-set` accessor bodies of a `property` subcommand as
/// walkable method bodies (named `<get>` / `<set>`).  Only braced (`Str`)
/// bodies are walkable.
fn collect_property_accessor_bodies(
    texts: &[String],
    argv: &[Token],
    out: &mut Vec<CollectedMethodBody>,
) {
    let mut i = 0;
    while i < texts.len() {
        if let Some(opt) = texts[i].strip_prefix('-') {
            // Every property option takes a value; only `-get`/`-set` carry a
            // body to analyse.
            if i + 1 < texts.len() {
                if matches!(opt, "get" | "set")
                    && let Some(tok) = argv.get(i + 1).copied()
                    && tok.kind == TokenType::Str
                {
                    out.push(CollectedMethodBody {
                        name: format!("<{opt}>"),
                        params: Vec::new(),
                        body_text: texts[i + 1].clone(),
                        body_tok: tok,
                        params_tok: None,
                        // Conservative: a `property` accessor body is a
                        // 9.0+ `oo::configurable` surface this analysis has
                        // not pinned `[self class]` behaviour for — abstain
                        // from the defining-class fact rather than guess.
                        class_side: true,
                    });
                }
                i += 2;
                continue;
            }
        }
        i += 1;
    }
}

/// Extract a [`MethodDef`] from a method-shaped member's args.
///
/// The name / parameter-list / body word positions come from `member`'s
/// registry arg-roles (`method NAME PARAMS BODY`, `constructor PARAMS BODY`,
/// `destructor BODY`), never hardcoded indices.  A member with no
/// [`ArgRole::Name`] (constructor / destructor) takes `synthetic_name` as its
/// placeholder.  `args` / `arg_tokens` are the words *after* the member
/// keyword.
///
/// Returns `None` when the argument count is too short (no body word) to match
/// the member's shape.
#[cfg(test)]
fn extract_method_def(
    member: &MemberSpec,
    args: &[String],
    arg_tokens: &[Token],
    kind: &str,
    visibility: &str,
    synthetic_name: &str,
) -> Option<MethodDef> {
    extract_method_def_in(
        member,
        args,
        arg_tokens,
        kind,
        visibility,
        synthetic_name,
        MemberDialect {
            surface: None,
            rules: WordValueRules::TCL,
        },
    )
}

pub(super) fn extract_method_def_in(
    member: &MemberSpec,
    args: &[String],
    arg_tokens: &[Token],
    kind: &str,
    visibility: &str,
    synthetic_name: &str,
    dialect: MemberDialect<'_>,
) -> Option<MethodDef> {
    let zero = tcl_lexer::Span::new(0, 0);
    let body_idx = member
        .indices_for_call_in(args, dialect.surface, ArgRole::Body)
        .next()?;
    // A body word must be present for the member to be well-formed.
    args.get(body_idx)?;
    let name_idx = member
        .indices_for_call_in(args, dialect.surface, ArgRole::Name)
        .next();
    let params_idx = member
        .indices_for_call_in(args, dialect.surface, ArgRole::ParamList)
        .next();

    let name = name_idx
        .and_then(|i| args.get(i))
        .map_or_else(|| synthetic_name.to_string(), String::clone);
    let params = params_idx
        .and_then(|i| args.get(i))
        .map_or_else(Vec::new, |p| parse_param_list(p, dialect.rules));
    let name_span = name_idx
        .and_then(|i| arg_tokens.get(i))
        .map_or(zero, |t| t.span);
    let body_span = arg_tokens.get(body_idx).map_or(zero, |t| t.span);
    Some(MethodDef {
        name,
        params,
        params_computed: false,
        formal_count: crate::signature_scan::formal_count::SourceFormalCount::Authored(
            tcl_dialect::ParameterGrammar::Tcl,
        ),
        name_span,
        body_span,
        kind: kind.to_string(),
        // Flipped by the one caller that needs it (`record_declared_method`,
        // for a member a receiver-moving wrapper put on the class object) —
        // every other caller means it literally, so `false` is the
        // correct default here, not just a placeholder.
        is_self_method: false,
        visibility: visibility.to_string(),
        doc: String::new(),
        forward_target: None,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::analyser::types::MemberRetractionRecord;

    #[test]
    fn original_receiver_declaration_keeps_its_whole_parent_bom_configuration() {
        // naming.tcloo.original-source-receiver-body-declaration
        // docs/design/analysis/name-resolution-proofs/tcloo-original-source-receiver-body-declaration.md
        // Source declaration body only; no allocated class or entered method.
        fn bodies(
            scope: &Scope,
        ) -> Vec<&super::super::types::OriginalSourceReceiverBodyDeclaration> {
            scope
                .original_receiver_body_declaration
                .iter()
                .map(AsRef::as_ref)
                .chain(scope.children.iter().flat_map(bodies))
                .collect()
        }
        let body = "interp create -safe s; interp eval s {oo::class create C {method m {} {source a.tcl}}}";
        let mut prepared = Analyser::new();
        let input = prepared.prepare_analysis_input("tcl9.1").unwrap();
        let source = format!("\u{feff}{body}");
        let result = Analyser::new().analyse(&source, "tcl9.1");
        let declarations = bodies(&result.global_scope);
        assert_eq!(declarations.len(), 1, "{:?}", result.diagnostics);
        assert!(declarations[0].matches_source(&tcl_lexer::SourceImage::document(&source), &input));
        for bom in [tcl_lexer::LeadingBom::Skip, tcl_lexer::LeadingBom::Content] {
            let mut supplied = input.clone();
            supplied.config.leading_bom = bom;
            let result = Analyser::new()
                .with_resolved_input(supplied.clone())
                .analyse(body, "display-only");
            let declarations = bodies(&result.global_scope);
            assert_eq!(declarations.len(), 1, "{bom:?}: {:?}", result.diagnostics);
            let original = declarations[0];
            let image = tcl_lexer::SourceImage::document(body);
            assert!(original.matches_source(&image, &supplied));
            assert_eq!(original.body_word().config(), supplied.lexer_config());
            assert_eq!(original.parameters_word().config(), supplied.lexer_config());
            let commands = tcl_lexer::native_script_words_in(
                image.clone(),
                original.body_word().content_span().unwrap(),
                supplied.lexer_config(),
            )
            .unwrap();
            assert!(original.owns_invocation(&commands.commands[0].words, &supplied));
            assert!(!original.matches_source(
                &tcl_lexer::SourceImage::document(&(body.to_owned() + "\n")),
                &supplied
            ));
            let mut stale = supplied.clone();
            stale.config.strict_quoting = !stale.config.strict_quoting;
            assert!(!original.matches_source(&image, &stale));
            let mut foreign = supplied.clone();
            foreign.context = std::sync::Arc::new(
                supplied
                    .context
                    .with_command_store(std::sync::Arc::clone(supplied.context.commands())),
            );
            assert!(!original.matches_source(&image, &foreign));
        }
    }

    #[test]
    fn logical_method_name_operands_require_selected_original_named_members() {
        let source = "oo::class create C {method {$literal} {} {}; self method {with space} {} {}; method known $formals {}; constructor {} {}; foreach n {generated} {method $n {} {}}; method {*}{expanded} {} {}}";
        let analysis = Analyser::new().analyse(source, "tcl");
        let class = &analysis.all_classes["::C"];
        let input = analysis.resolved_input.as_ref().unwrap();
        let image = analysis
            .retained_command_realm()
            .unwrap()
            .original_source_image()
            .unwrap();
        for (side, method) in [
            (MemberSide::Instance, &class.methods["$literal"]),
            (MemberSide::Instance, &class.methods["known"]),
            (MemberSide::ClassObject, &class.class_methods["with space"]),
        ] {
            let word = class
                .original_members
                .logical_name_operand(side, method, input, image)
                .unwrap();
            assert_eq!(
                tcl_syntax::word_rules::original_static_word_ascii_presentation(word).unwrap(),
                method.name.as_bytes(),
            );
            assert!(
                class
                    .original_members
                    .logical_name_operand(
                        match side {
                            MemberSide::Instance => MemberSide::ClassObject,
                            MemberSide::ClassObject => MemberSide::Instance,
                        },
                        method,
                        input,
                        image,
                    )
                    .is_none()
            );
            let mut changed = method.clone();
            changed.name_span = tcl_lexer::Span::new(0, 1);
            assert!(
                class
                    .original_members
                    .logical_name_operand(side, &changed, input, image)
                    .is_none()
            );
            let foreign = tcl_lexer::SourceImage::document("different source");
            assert!(
                class
                    .original_members
                    .logical_name_operand(side, method, input, &foreign)
                    .is_none()
            );
            let mut changed_input = input.clone();
            changed_input.unit_profile = Analyser::new()
                .analyse(source, "tcl8.6")
                .resolved_input
                .unwrap()
                .unit_profile;
            assert!(
                class
                    .original_members
                    .logical_name_operand(side, method, &changed_input, image)
                    .is_none()
            );
        }
        assert!(
            class
                .original_members
                .logical_name_operand(MemberSide::Instance, &class.constructors[0], input, image)
                .is_none()
        );
        for name in ["generated", "expanded"] {
            let method = &class.methods[name];
            assert!(
                class
                    .original_members
                    .logical_name_operand(MemberSide::Instance, method, input, image)
                    .is_none()
            );
        }
    }

    #[test]
    fn logical_method_name_roles_follow_the_selected_family_grammar() {
        for source in [
            "snit::type C {method {two words} {} {}}",
            "itcl::class C {method {two words} {} {}}",
        ] {
            let analysis = Analyser::new().analyse(source, "tcl");
            let class = &analysis.all_classes["::C"];
            let method = &class.methods["two words"];
            let input = analysis.resolved_input.as_ref().unwrap();
            let image = analysis
                .retained_command_realm()
                .unwrap()
                .original_source_image()
                .unwrap();
            let word = class
                .original_members
                .logical_name_operand(MemberSide::Instance, method, input, image)
                .unwrap();
            assert_eq!(
                tcl_syntax::word_rules::original_static_word_ascii_presentation(word).unwrap(),
                b"two words"
            );
        }
    }

    #[test]
    fn logical_member_opacity_uses_selected_name_words_instead_of_literal_sigils() {
        let source = "oo::class create C {method {$literal} {} {}; method {${literal}} {} {}}";
        let analysis = Analyser::new().analyse(source, "tcl");
        let class = &analysis.all_classes["::C"];
        assert!(class.methods.contains_key("$literal"));
        assert!(class.methods.contains_key("${literal}"));
        assert!(!class.member_set_incomplete);
        let unsupported =
            Analyser::new().analyse("oo::class create C {method {nul\0name} {} {}}", "tcl");
        let class = &unsupported.all_classes["::C"];
        assert!(class.methods.contains_key("nul\0name"));
        assert!(class.member_set_incomplete);
        for body in [
            "method $computed {} {}",
            "method {*}$parts",
            "method {*}{expanded} {} {}",
        ] {
            let source = format!("oo::class create C {{{body}}}");
            let analysis = Analyser::new().analyse(&source, "tcl");
            let class = &analysis.all_classes["::C"];
            assert!(class.member_set_incomplete);
            assert!(class.methods.values().all(|method| {
                class
                    .original_members
                    .logical_name_operand(
                        MemberSide::Instance,
                        method,
                        analysis.resolved_input.as_ref().unwrap(),
                        analysis
                            .retained_command_realm()
                            .unwrap()
                            .original_source_image()
                            .unwrap(),
                    )
                    .is_none()
            }));
        }
    }

    #[test]
    fn logical_member_name_ingress_refuses_reconstructed_wrapper_vectors() {
        let source = "oo::class create C {self {method m {} {}}}";
        let analysis = Analyser::new().analyse(source, "tcl");
        let class = &analysis.all_classes["::C"];
        let input = analysis.resolved_input.as_ref().unwrap();
        let image = analysis
            .retained_command_realm()
            .unwrap()
            .original_source_image()
            .unwrap();
        assert!(
            class
                .original_members
                .logical_name_operand(
                    MemberSide::ClassObject,
                    &class.class_methods["m"],
                    input,
                    image
                )
                .is_none()
        );

        let direct_source = "oo::class create C {method m {} {}}";
        let mut analyser = Analyser::new();
        let analysis = analyser
            .analyse_and_retain_result_for_test(direct_source, "tcl")
            .clone();
        let mut class = analysis.all_classes["::C"].clone();
        class.original_members = Default::default();
        let current = &analysis.all_classes["::C"];
        let actual_input = analysis.resolved_input.as_ref().unwrap();
        let actual_image = analysis
            .retained_command_realm()
            .unwrap()
            .original_source_image()
            .unwrap();
        let outer = crate::segmenter::segment_commands_with_offset_and_config(
            direct_source,
            0,
            actual_input.lexer_config(),
        );
        let [outer] = outer.as_slice() else {
            panic!("one authentic original class command")
        };
        let groups = tcl_lexer::group_commands_bytes(
            &outer.all_tokens,
            actual_image.bytes(),
            actual_input.lexer_config(),
        );
        let body_group = &groups[0].words[3];
        assert_eq!(body_group.span, current.body_span);
        let body = tcl_lexer::NativeWord::from_group(
            actual_image.clone(),
            actual_input.lexer_config(),
            &outer.all_tokens,
            body_group,
        )
        .unwrap();
        let content = crate::registry_invocation::original_written_script_body_span(&body).unwrap();
        let commands = crate::segmenter::segment_commands_with_offset_and_config(
            &direct_source[content.as_range()],
            content.start(),
            actual_input.lexer_config().nested(),
        );
        let mut command = commands
            .into_iter()
            .find(|command| command.name() == "method")
            .unwrap();
        analyser.retain_logical_member_name_operand(
            &tcl_registry::definer::TCLOO_GRAMMAR,
            &command,
            &mut class,
        );
        let actual_input = analysis.resolved_input.as_ref().unwrap();
        let actual_image = analysis
            .retained_command_realm()
            .unwrap()
            .original_source_image()
            .unwrap();
        assert!(
            class
                .original_members
                .logical_name_operand(
                    MemberSide::Instance,
                    &class.methods["m"],
                    actual_input,
                    actual_image
                )
                .is_some()
        );
        class.original_members = Default::default();
        command.argv[2] = command.argv[1];
        assert!(analyser.member_declaration_is_opaque(
            &tcl_registry::definer::TCLOO_GRAMMAR,
            &command,
            &command.texts,
        ));
        analyser.retain_logical_member_name_operand(
            &tcl_registry::definer::TCLOO_GRAMMAR,
            &command,
            &mut class,
        );
        let actual_input = analysis.resolved_input.as_ref().unwrap();
        let actual_image = analysis
            .retained_command_realm()
            .unwrap()
            .original_source_image()
            .unwrap();
        assert!(
            class
                .original_members
                .logical_name_operand(
                    MemberSide::Instance,
                    &class.methods["m"],
                    actual_input,
                    actual_image
                )
                .is_none()
        );
    }

    #[test]
    fn loop_installed_members_require_the_original_variable_word() {
        let config = tcl_lexer::LexerConfig::for_dialect("tcl9.1");
        let dialect = tcl_registry::model::ingress::static_context_for("tcl9.1")
            .context()
            .authoring_query();
        let shape =
            |body, name| loop_installed_member_shape(tcloo(), body, 7, config, Some(dialect), name);
        for body in [
            "method $name {} {}",
            r#"method "$name" {} {}"#,
            "method ${name} {} {}",
            "private method $name {} {}",
            "self method $name {} {}",
        ] {
            assert!(shape(body, "name").is_some(), "{body}");
        }
        for body in [
            "method {$name} {} {}",
            r"method \$name {} {}",
            "method {${name}} {} {}",
            "method prefix$name {} {}",
            "method $name$suffix {} {}",
            "method $name(key) {} {}",
            "method ${name(key)} {} {}",
            "method {*}{$name} {} {}",
            r#"method " $name" {} {}"#,
        ] {
            assert!(shape(body, "name").is_none(), "{body}");
        }
        assert!(shape("method ${literal:::name} {} {}", "literal:::name").is_some());
        assert!(shape("method ${literal:::name} {} {}", "literal::name").is_none());
        let flat = tcl_lexer::LexerConfig {
            braced_var: tcl_dialect::BracedVarStyle::FirstClose,
            ..config
        };
        assert!(
            loop_installed_member_shape(
                tcloo(),
                "method ${a{b} {} {}",
                7,
                flat,
                Some(dialect),
                "a{b"
            )
            .is_some()
        );
        assert!(shape("method ${a{b} {} {}", "a{b").is_none());
    }

    #[test]
    fn original_member_script_projection_keeps_body_bom_as_keyword_content() {
        // naming.source.original-configured-script-completeness
        // docs/design/analysis/name-resolution-proofs/source-original-configured-script-completeness.md
        // Exact member grammar syntax; no installed method or Native worker.
        let config = tcl_lexer::LexerConfig::for_file_grammar(
            crate::environment_ingress::resolve_environment("tcl9.1").grammar(),
        );
        let dialect = tcl_registry::model::ingress::static_context_for("tcl9.1")
            .context()
            .authoring_query();
        let positive = "method $name {} {}";
        assert!(
            loop_installed_member_shape(tcloo(), positive, 7, config, Some(dialect), "name")
                .is_some()
        );
        assert!(
            loop_installed_member_shape(
                tcloo(),
                "\u{feff}method $name {} {}",
                7,
                config,
                Some(dialect),
                "name"
            )
            .is_none()
        );
        let source = "private {\u{feff}method ghost {} {}}";
        let command = crate::segmenter::segment_commands_with_offset_and_config(source, 0, config)
            .pop()
            .unwrap();
        let expanded =
            expand_wrapper_block_members(source, tcloo(), &command.texts, &command.argv, config)
                .unwrap();
        assert_eq!(expanded.len(), 1);
        assert_eq!(expanded[0].0[1], "\u{feff}method");
        assert!(tcloo().member(&expanded[0].0[1]).is_none());
    }

    #[test]
    fn original_vendor_class_declarations_keep_selected_source_role_and_unavailable_units() {
        // Implementation contract: naming.vendor.original-source-context-input
        // docs/design/analysis/name-resolution-proofs/vendor-original-source-context-input.md
        let source = r"snit::type {Plain} {}
snit::type {C\uD800} {}";
        for profile in ["f5-irules", "f5-iapps", "f5-tmsh"] {
            let result = Analyser::new().analyse(source, profile);
            let classes = result
                .original_vendor_class_declarations()
                .collect::<Vec<_>>();
            assert_eq!(classes.len(), 2, "{profile}");
            for class in &classes {
                assert_eq!(
                    class.purpose(),
                    tcl_syntax::naming::VendorSourceNamePurpose::SourceName
                );
                assert_eq!(
                    class.name_input().source_image(),
                    &tcl_lexer::SourceImage::document(source)
                );
                assert!(
                    class.metadata().source_name.is_none(),
                    "hosted source cards have no C/Jim slot"
                );
                assert_eq!(
                    result.original_vendor_source_name_in_source(
                        class.name_input().source_image(),
                        class.name_input().lexer_config(),
                        class.metadata().name_span,
                    ),
                    Some(class.original_occurrence())
                );
            }
            assert_eq!(
                classes[0].name_input().literal_units(classes[0].purpose()),
                Some(b"Plain".as_slice())
            );
            assert!(
                classes[1]
                    .name_input()
                    .literal_units(classes[1].purpose())
                    .is_none()
            );
            assert_eq!(result.original_class_declarations().count(), 0);
        }
        let result = Analyser::new().analyse("snit::type Plain {}", "tcl8.6");
        assert_eq!(result.original_vendor_class_declarations().count(), 0);
    }

    /// The `TclOO` definition-body grammar the `apply_oo_subcommand` /
    /// `extract_method_def` helpers read their member argument layout from —
    /// the same `&'static` the analyser fetches from the registry at runtime.
    fn tcloo() -> &'static DefinitionBodyGrammar {
        &tcl_registry::definer::TCLOO_GRAMMAR
    }

    fn class() -> ClassDef {
        ClassDef {
            name: "C".to_string(),
            qualified_name: "::C".to_string(),
            name_span: tcl_lexer::Span::new(0, 0),
            body_span: tcl_lexer::Span::new(0, 0),
            ..Default::default()
        }
    }

    /// The `W315` messages an analysis produced, in emission order — the
    /// "this class definition cannot run" reports.
    fn w315_messages(r: &super::super::types::AnalysisResult) -> Vec<String> {
        r.diagnostics
            .iter()
            .filter(|d| d.code == tcl_core_types::DiagCode::W315)
            .map(|d| d.message.clone())
            .collect()
    }

    fn has_w315(r: &super::super::types::AnalysisResult) -> bool {
        !w315_messages(r).is_empty()
    }

    fn tok(span: (u32, u32)) -> Token {
        Token::new(TokenType::Esc, tcl_lexer::Span::new(span.0, span.1))
    }

    fn str_tok(span: (u32, u32)) -> Token {
        Token {
            kind: TokenType::Str,
            span: tcl_lexer::Span::new(span.0, span.1),
            content_offset: 1,
            in_quote: false,
        }
    }

    #[test]
    fn superclass_subcommand_assigns_supers() {
        let mut cd = class();
        let texts: Vec<String> = ["superclass", "::A", "::B"]
            .iter()
            .map(|s| (*s).to_string())
            .collect();
        let argv = [tok((0, 10)), tok((11, 14)), tok((15, 18))];
        apply_oo_subcommand(tcloo(), &texts, &argv, &mut cd);
        assert_eq!(cd.superclasses, vec!["::A", "::B"]);
    }

    #[test]
    fn mixin_subcommand_strips_dash_flags() {
        let mut cd = class();
        let texts: Vec<String> = ["mixin", "-append", "::M1", "::M2"]
            .iter()
            .map(|s| (*s).to_string())
            .collect();
        let argv = [tok((0, 5)), tok((6, 13)), tok((14, 18)), tok((19, 23))];
        apply_oo_subcommand(tcloo(), &texts, &argv, &mut cd);
        assert_eq!(cd.mixins, vec!["::M1", "::M2"]);
    }

    /// Apply a sequence of definition-body words to one class — the shape
    /// slot folding is about: later words must fold into,
    /// not overwrite, earlier slot state.
    fn apply_words(cd: &mut super::ClassDef, calls: &[&[&str]]) {
        for words in calls {
            let texts: Vec<String> = words.iter().map(|s| (*s).to_string()).collect();
            let argv: Vec<tcl_lexer::Token> = words.iter().map(|_| tok((0, 1))).collect();
            apply_oo_subcommand(tcloo(), &texts, &argv, cd);
        }
    }

    // Slot semantics for filter / superclass / mixin / variable (defaults
    // pinned against tclOODefineCmds.c 9.0.4 and confirmed live on
    // tclsh 9.0.4).

    // TP: `filter a ; filter b` appends — `info class filters` → `a b`,
    // NOT `b` (which is what a last-writer-wins reading would give).
    #[test]
    fn filter_slot_appends_across_calls() {
        let mut cd = class();
        apply_words(&mut cd, &[&["filter", "a"], &["filter", "b"]]);
        assert_eq!(cd.filters, vec!["a", "b"]);
    }

    // TP: the explicit operations fold — `-set` replaces, `-clear` empties,
    // `-prepend` front-inserts (tclsh 9.0.4: `filter a; filter -prepend b`
    // → `b a`), `-remove` deletes.
    #[test]
    fn filter_slot_explicit_operations_fold() {
        let mut cd = class();
        apply_words(&mut cd, &[&["filter", "a", "b"], &["filter", "-set", "x"]]);
        assert_eq!(cd.filters, vec!["x"]);
        apply_words(&mut cd, &[&["filter", "-clear"]]);
        assert_eq!(cd.filters, [] as [std::string::String; 0]);
        apply_words(&mut cd, &[&["filter", "a"], &["filter", "-prepend", "b"]]);
        assert_eq!(cd.filters, vec!["b", "a"]);
        apply_words(&mut cd, &[&["filter", "-remove", "b"]]);
        assert_eq!(cd.filters, vec!["a"]);
    }

    // FP guard: an operation word is recognised at argument 0 only —
    // `filter a -set b` appends three literal items (tclsh 9.0.4), it does
    // not replace the slot with `b`.
    #[test]
    fn filter_slot_op_word_only_recognised_first() {
        let mut cd = class();
        apply_words(&mut cd, &[&["filter", "a", "-set", "b"]]);
        assert_eq!(cd.filters, vec!["a", "-set", "b"]);
    }

    // TP: `superclass` defaults to `-set` (replace) — the common single
    // declaration keeps its meaning — and `-append` extends (tclsh 9.0.4:
    // `superclass A` after `superclass B` → `::B`; `superclass -append A`
    // → `::B ::A`).
    #[test]
    fn superclass_slot_replaces_by_default_and_appends_explicitly() {
        let mut cd = class();
        apply_words(&mut cd, &[&["superclass", "::A"], &["superclass", "::B"]]);
        assert_eq!(cd.superclasses, vec!["::B"]);
        apply_words(&mut cd, &[&["superclass", "-append", "::A"]]);
        assert_eq!(cd.superclasses, vec!["::B", "::A"]);
    }

    // TP: `mixin` defaults to `-set` in 8.6 and 9.0 alike (both C sources
    // forward `--default-operation` to `-set`; tclsh 9.0.4:
    // `mixin M1; mixin M2` → `::M2`).
    #[test]
    fn mixin_slot_replaces_by_default() {
        let mut cd = class();
        apply_words(&mut cd, &[&["mixin", "::M1"], &["mixin", "::M2"]]);
        assert_eq!(cd.mixins, vec!["::M2"]);
    }

    // TP: the class `variable` slot appends with dedup (tclsh 9.0.4:
    // `variable a; variable a b` → `a b`) and folds `-set` / `-remove`.
    #[test]
    fn variable_slot_appends_dedups_and_folds_ops() {
        let mut cd = class();
        apply_words(&mut cd, &[&["variable", "a"], &["variable", "a", "b"]]);
        assert_eq!(cd.variables, vec!["a", "b"]);
        apply_words(&mut cd, &[&["variable", "-remove", "a"]]);
        assert_eq!(cd.variables, vec!["b"]);
        apply_words(&mut cd, &[&["variable", "-set", "c"]]);
        assert_eq!(cd.variables, vec!["c"]);
    }

    // TN: an unknown leading `-op` aborts the whole definition in real Tcl
    // (`unknown method "-bogus"`), so the fold must leave the slot state
    // unchanged rather than record `-bogus`/`x` as filters.
    #[test]
    fn unknown_slot_op_leaves_slot_untouched() {
        let mut cd = class();
        apply_words(&mut cd, &[&["filter", "a"], &["filter", "-bogus", "x"]]);
        assert_eq!(cd.filters, vec!["a"]);
    }

    // TP, full pipeline: the fold carries across definition blocks — the
    // oracle transcript verbatim (tclsh 9.0.4 and 8.6.16, byte-identical):
    //   oo::class create C { filter a; filter b } → info class filters → a b
    //   oo::define C { filter -set x }            →                    → x
    //   oo::define C { filter -clear }            →                    → (empty)
    #[test]
    fn filter_slot_folds_across_oo_define_blocks() {
        let mut a = Analyser::new();
        let r = a.analyse(
            "oo::class create ::C { filter a\nfilter b }\n\
             oo::define ::C { filter -set x }\n",
            "tcl9.0",
        );
        let c = r.all_classes.get("::C").expect("::C recorded");
        assert_eq!(c.filters, vec!["x"]);

        let mut a2 = Analyser::new();
        let r2 = a2.analyse(
            "oo::class create ::C { filter a\nfilter b }\n\
             oo::define ::C { filter -append c }\n",
            "tcl9.0",
        );
        let c2 = r2.all_classes.get("::C").expect("::C recorded");
        assert_eq!(c2.filters, vec!["a", "b", "c"]);
    }

    // The class-object side folds through the same slot spec: `self filter`
    // appends across calls, and never leaks into the instance slot.
    #[test]
    fn class_side_filter_slot_folds_and_stays_sided() {
        let mut a = Analyser::new();
        let r = a.analyse(
            "oo::class create ::C { self { filter a }\nself { filter b } }\n",
            "tcl9.0",
        );
        let c = r.all_classes.get("::C").expect("::C recorded");
        assert_eq!(c.class_filters, vec!["a", "b"]);
        assert_eq!(c.filters, [] as [std::string::String; 0]);
    }

    #[test]
    fn method_subcommand_records_method_def() {
        let mut cd = class();
        let texts: Vec<String> = ["method", "greet", "name", "puts $name"]
            .iter()
            .map(|s| (*s).to_string())
            .collect();
        let argv = [tok((0, 6)), tok((7, 12)), tok((13, 17)), str_tok((18, 32))];
        apply_oo_subcommand(tcloo(), &texts, &argv, &mut cd);
        assert!(cd.methods.contains_key("greet"));
        let md = &cd.methods["greet"];
        assert_eq!(md.kind, "method");
        assert_eq!(md.visibility, "public");
    }

    /// Tcl 9's declaration flag sits between a method name and parameter list.
    /// The analyser receives only the generic registry layout and its selected
    /// visibility—not a command-specific option parser.
    #[test]
    fn method_visibility_option_shifts_params_and_sets_visibility() {
        let mut cd = class();
        let texts: Vec<String> = ["method", "internal", "-private", "arg", "puts $arg"]
            .iter()
            .map(|s| (*s).to_string())
            .collect();
        let argv = [
            tok((0, 6)),
            tok((7, 15)),
            tok((16, 24)),
            tok((25, 28)),
            str_tok((29, 38)),
        ];
        apply_oo_subcommand(tcloo(), &texts, &argv, &mut cd);
        let method = cd.methods.get("internal").expect("method recorded");
        assert_eq!(method.visibility, "private");
        assert_eq!(method.params[0].name, "arg");
        assert_eq!(method.body_span, tcl_lexer::Span::new(29, 38));
    }

    #[test]
    fn method_visibility_option_is_profile_gated_without_old_layout_reinterpretation() {
        let src = "oo::class create C { method internal -private {} { return ok } }";
        let mut analyser = Analyser::new();
        let tcl86 = analyser.analyse(src, "tcl8.6").clone();
        assert!(
            tcl86
                .diagnostics
                .iter()
                .any(|diagnostic| diagnostic.code.as_str() == "W002"),
            "Tcl 8.6 must diagnose the Tcl 9 method option: {:?}",
            tcl86.diagnostics
        );
        assert!(
            tcl86
                .all_classes
                .get("::C")
                .is_none_or(|class| !class.methods.contains_key("internal")),
            "the invalid Tcl 8.6 member must not be reinterpreted using a shifted layout"
        );

        let mut analyser = Analyser::new();
        let tcl90 = analyser.analyse(src, "tcl9.0").clone();
        assert_eq!(
            tcl90.all_classes["::C"].methods["internal"].visibility,
            "private"
        );
    }

    #[test]
    fn classmethod_subcommand_records_class_method() {
        let mut cd = class();
        let texts: Vec<String> = ["classmethod", "build", "args", "return $args"]
            .iter()
            .map(|s| (*s).to_string())
            .collect();
        let argv = [
            tok((0, 11)),
            tok((12, 17)),
            tok((18, 22)),
            str_tok((23, 38)),
        ];
        apply_oo_subcommand(tcloo(), &texts, &argv, &mut cd);
        assert!(cd.class_methods.contains_key("build"));
        assert!(!cd.methods.contains_key("build"));
    }

    #[test]
    fn constructor_appends_to_constructors_list() {
        let mut cd = class();
        let texts: Vec<String> = ["constructor", "args", "puts ctor"]
            .iter()
            .map(|s| (*s).to_string())
            .collect();
        let argv = [tok((0, 11)), tok((12, 16)), str_tok((17, 28))];
        apply_oo_subcommand(tcloo(), &texts, &argv, &mut cd);
        assert_eq!(cd.constructors.len(), 1);
        assert_eq!(cd.constructors[0].kind, "constructor");
        assert_eq!(cd.constructors[0].name, "<constructor>");
        // Name span anchors on the `constructor` keyword token
        // (argv[0] = 0..11), not the default (0, 0).
        assert_eq!(cd.constructors[0].name_span, tcl_lexer::Span::new(0, 11));
        // Constructors are not mirrored into the methods map.
        assert!(!cd.methods.contains_key("<constructor>"));
    }

    #[test]
    fn destructor_sets_destructor_field() {
        let mut cd = class();
        let texts: Vec<String> = ["destructor", "puts dtor"]
            .iter()
            .map(|s| (*s).to_string())
            .collect();
        let argv = [tok((0, 10)), str_tok((11, 22))];
        apply_oo_subcommand(tcloo(), &texts, &argv, &mut cd);
        let dtor = cd.destructor.as_ref().expect("destructor recorded");
        assert_eq!(dtor.kind, "destructor");
        assert_eq!(dtor.name, "<destructor>");
        // Name span anchors on the `destructor` keyword token
        // (argv[0] = 0..10).
        assert_eq!(dtor.name_span, tcl_lexer::Span::new(0, 10));
        assert!(!cd.methods.contains_key("<destructor>"));
    }

    #[test]
    fn forward_records_method_with_forward_kind() {
        let mut cd = class();
        let texts: Vec<String> = ["forward", "delegate", "::other::cmd"]
            .iter()
            .map(|s| (*s).to_string())
            .collect();
        let argv = [tok((0, 7)), tok((8, 16)), tok((17, 29))];
        apply_oo_subcommand(tcloo(), &texts, &argv, &mut cd);
        assert!(cd.methods.contains_key("delegate"));
        assert_eq!(cd.methods["delegate"].kind, "forward");
    }

    #[test]
    fn private_method_records_with_private_visibility() {
        let mut cd = class();
        let texts: Vec<String> = ["private", "method", "internal", "args", "puts hi"]
            .iter()
            .map(|s| (*s).to_string())
            .collect();
        let argv = [
            tok((0, 7)),
            tok((8, 14)),
            tok((15, 23)),
            tok((24, 28)),
            str_tok((29, 37)),
        ];
        apply_oo_subcommand(tcloo(), &texts, &argv, &mut cd);
        assert!(cd.methods.contains_key("internal"));
        assert_eq!(cd.methods["internal"].visibility, "private");
    }

    #[test]
    fn self_method_subcommand_records_class_method_tagged_is_self_method() {
        // TP: `self method NAME ARGS BODY` (TclOO's own spelling of a
        // class-level method, the stock counterpart to ooutil's `classmethod`
        // keyword) must land by its row's type-object receiver, or
        // `class_methods` gains no entry for it. Recorded with
        // `kind: "classmethod"` (both
        // spellings mean "dispatched via the class's own bound command")
        // but tagged `is_self_method` so the class-command MRO walk knows
        // NOT to treat it as inherited the way ooutil's `classmethod` is.
        let mut cd = class();
        let texts: Vec<String> = ["self", "method", "make", "n", "return made"]
            .iter()
            .map(|s| (*s).to_string())
            .collect();
        let argv = [
            tok((0, 4)),
            tok((5, 11)),
            tok((12, 16)),
            tok((17, 18)),
            str_tok((19, 30)),
        ];
        apply_oo_subcommand(tcloo(), &texts, &argv, &mut cd);
        assert!(!cd.methods.contains_key("make"));
        let md = cd
            .class_methods
            .get("make")
            .expect("recorded as a classmethod");
        assert_eq!(md.kind, "classmethod");
        assert!(md.is_self_method);
        assert_eq!(md.visibility, "public");
    }

    #[test]
    fn self_classmethod_subcommand_also_records_into_class_methods() {
        // TP — the `self classmethod` inner spelling (rarer, but valid:
        // `self` always retargets to the class object regardless of which
        // inner member follows) must resolve identically to `self method`.
        let mut cd = class();
        let texts: Vec<String> = ["self", "classmethod", "build", "args", "return $args"]
            .iter()
            .map(|s| (*s).to_string())
            .collect();
        let argv = [
            tok((0, 4)),
            tok((5, 16)),
            tok((17, 22)),
            tok((23, 27)),
            str_tok((28, 43)),
        ];
        apply_oo_subcommand(tcloo(), &texts, &argv, &mut cd);
        let md = cd
            .class_methods
            .get("build")
            .expect("recorded as a classmethod");
        assert!(md.is_self_method);
    }

    #[test]
    fn self_block_form_is_a_silent_noop_not_a_crash() {
        // FN guard — this helper does not read the `self { method NAME ARGS
        // BODY }` *block* form (nor the symmetric `private` one). It must
        // decline cleanly, never panic on the whole braced blob standing in
        // for an inner keyword.
        let mut cd = class();
        let texts: Vec<String> = ["self", "{ method make {n} { return made } }"]
            .iter()
            .map(|s| (*s).to_string())
            .collect();
        let argv = [tok((0, 4)), str_tok((5, 42))];
        apply_oo_subcommand(tcloo(), &texts, &argv, &mut cd);
        assert_eq!(cd.class_methods.len(), 0);
        assert_eq!(cd.methods.len(), 0);
    }

    #[test]
    fn unrecognised_subcommand_is_silent_noop() {
        let mut cd = class();
        let texts: Vec<String> = ["whatever", "x"].iter().map(|s| (*s).to_string()).collect();
        let argv = [tok((0, 8)), tok((9, 10))];
        apply_oo_subcommand(tcloo(), &texts, &argv, &mut cd);
        // No fields populated; no panic.
        assert_eq!(cd.methods.len(), 0);
        assert_eq!(cd.superclasses, [] as [std::string::String; 0]);
        assert_eq!(cd.mixins, [] as [std::string::String; 0]);
    }

    #[test]
    fn variable_declaration_spans_use_selected_original_literal_name_operands() {
        let source =
            "variable {$literal} {${braced}} {}; variable $computed; variable {*}{shifted}";
        let profile = tcl_dialect::DialectProfile::find("tcl9.1").unwrap();
        let config = tcl_lexer::LexerConfig::for_profile(Some(profile));
        let image = tcl_lexer::SourceImage::document(source);
        let commands = crate::segmenter::segment_commands_with_offset_and_config(source, 0, config);
        let known = [
            "$literal",
            "${braced}",
            "",
            "computed",
            "$computed",
            "shifted",
        ]
        .map(str::to_owned);
        let spans = collect_var_decl_spans(tcloo(), &commands, &known, &image, config, None);
        for name in ["$literal", "${braced}", ""] {
            assert!(spans.contains_key(name), "{name:?}: {spans:?}");
        }
        assert!(!spans.contains_key("literal") && !spans.contains_key("braced"));
        assert!(
            !spans.contains_key("computed")
                && !spans.contains_key("$computed")
                && !spans.contains_key("shifted")
        );
    }

    #[test]
    fn variable_subcommand_records_class_variables() {
        let mut cd = class();
        let texts: Vec<String> = ["variable", "x", "y"]
            .iter()
            .map(|s| (*s).to_string())
            .collect();
        let argv = [tok((0, 8)), tok((9, 10)), tok((11, 12))];
        apply_oo_subcommand(tcloo(), &texts, &argv, &mut cd);
        assert_eq!(cd.variables, vec!["x", "y"]);
    }

    #[test]
    fn a_second_variable_subcommand_accumulates_rather_than_replacing() {
        // TP — the real corpus shape
        // (georgtree_tclopt's ::tclopt::Mpfit) has TWO separate `variable`
        // statements in the same class body (`variable funct m ftol ...`
        // then, separately, `variable Pars`). tclsh9.0-verified: both
        // statements' names are live, simultaneous instance variables —
        // `variable` inside a class body is additive, never a reset (the
        // same "always present in every method" declaration a `variable`
        // command inside a method body itself would make, just issued
        // once for the whole class). A second statement must not silently
        // discard the first's names.
        let mut cd = class();
        apply_oo_subcommand(
            tcloo(),
            &["variable".to_string(), "funct".to_string(), "m".to_string()],
            &[tok((0, 8)), tok((9, 14)), tok((15, 16))],
            &mut cd,
        );
        apply_oo_subcommand(
            tcloo(),
            &["variable".to_string(), "Pars".to_string()],
            &[tok((20, 28)), tok((29, 33))],
            &mut cd,
        );
        assert_eq!(cd.variables, vec!["funct", "m", "Pars"]);
    }

    #[test]
    fn filter_subcommand_records_filters() {
        let mut cd = class();
        let texts: Vec<String> = ["filter", "log", "trace"]
            .iter()
            .map(|s| (*s).to_string())
            .collect();
        let argv = [tok((0, 6)), tok((7, 10)), tok((11, 16))];
        apply_oo_subcommand(tcloo(), &texts, &argv, &mut cd);
        assert_eq!(cd.filters, vec!["log", "trace"]);
        // …and only the instance slot: the class object stays unfiltered.
        assert_eq!(cd.class_filters.len(), 0, "{:?}", cd.class_filters);
    }

    #[test]
    fn export_and_unexport_record_sets() {
        let mut cd = class();
        let texts1: Vec<String> = ["export", "foo", "bar"]
            .iter()
            .map(|s| (*s).to_string())
            .collect();
        let argv1 = [tok((0, 6)), tok((7, 10)), tok((11, 14))];
        apply_oo_subcommand(tcloo(), &texts1, &argv1, &mut cd);
        assert!(cd.exports.contains("foo"));
        assert!(cd.exports.contains("bar"));

        let texts2: Vec<String> = ["unexport", "baz"]
            .iter()
            .map(|s| (*s).to_string())
            .collect();
        let argv2 = [tok((0, 8)), tok((9, 12))];
        apply_oo_subcommand(tcloo(), &texts2, &argv2, &mut cd);
        assert!(cd.unexports.contains("baz"));
    }

    #[test]
    fn property_subcommand_records_property_def() {
        let mut cd = class();
        let texts: Vec<String> = [
            "property",
            "colour",
            "-kind",
            "readable",
            "-get",
            "return red",
        ]
        .iter()
        .map(|s| (*s).to_string())
        .collect();
        let argv = [
            tok((0, 8)),
            tok((9, 15)),
            tok((16, 21)),
            tok((22, 30)),
            tok((31, 35)),
            str_tok((36, 47)),
        ];
        apply_oo_subcommand(tcloo(), &texts, &argv, &mut cd);
        let pd = cd.properties.get("colour").expect("colour recorded");
        assert_eq!(pd.kind, "readable");
        assert!(pd.has_getter);
        assert!(!pd.has_setter);
    }

    /// `property` is a 9.0 `TclOO` member: under 8.6 it is flagged
    /// disabled-in-dialect (W002), but from 9.0 on it is accepted silently.
    ///
    /// Either way the member is **recorded** — reporting "this needs Tcl
    /// 9.0" must not also break go-to-definition, references, rename, and
    /// document symbols over the code the user wrote, and the whole-command
    /// W002 behaves the same way (it reports a dialect-unavailable command
    /// while the analyser goes on modelling the call).
    #[test]
    fn property_member_is_gated_to_9_0() {
        let src = "oo::class create C {\n    property color\n}\n";
        let mut a86 = Analyser::new();
        let r86 = a86.analyse(src, "tcl8.6");
        assert!(
            r86.diagnostics
                .iter()
                .any(|d| d.code == tcl_core_types::DiagCode::W002),
            "property should be W002 under 8.6",
        );
        assert!(
            r86.all_classes
                .get("::C")
                .is_some_and(|c| c.properties.contains_key("color")),
            "the member is still recorded, so editor features keep working",
        );

        let mut a90 = Analyser::new();
        let r90 = a90.analyse(src, "tcl9.0");
        assert!(
            !r90.diagnostics
                .iter()
                .any(|d| d.code == tcl_core_types::DiagCode::W002),
            "property is available in 9.0",
        );
        assert!(
            r90.all_classes
                .get("::C")
                .is_some_and(|c| c.properties.contains_key("color")),
            "9.0 records the property",
        );
    }

    /// A configurable class answers `configure` for its properties, so that
    /// generated accessor is folded into its known methods even though no
    /// `method` body defines it.  `cget` is **not** generated
    /// (`configurable.n` documents none in 9.0 or 9.1), so it must not be.
    #[test]
    fn configurable_class_knows_configure_but_not_cget() {
        let mut a = Analyser::new();
        let r = a
            .analyse(
                "oo::configurable create C {\n    property color\n}\n",
                "tcl9.0",
            )
            .clone();
        let known = r.class_hierarchy().known_methods(
            Some(tcl_registry::model::ingress::static_context_for("tcl9.0").commands()),
            "::C",
        );
        assert!(known.contains(&"configure".to_owned()), "{known:?}");
        assert!(!known.contains(&"cget".to_owned()), "{known:?}");
    }

    /// A command reference the analyser records for a class-body member
    /// argument (`superclass`/`mixin`/`inherit`/`forward` target).  `written`
    /// is the token text; `resolved` the qualified command it denotes.
    fn has_cmd_ref(
        r: &crate::analyser::types::AnalysisResult,
        written: &str,
        resolved: &str,
    ) -> bool {
        r.command_invocations.iter().any(|inv| {
            inv.name == written && inv.resolved_qualified_name.as_deref() == Some(resolved)
        })
    }

    // TP: a `superclass ::ns::Base` names the base class — recorded as a
    // command reference so references / go-to-definition / rename reach it.
    #[test]
    fn superclass_records_a_command_reference_to_the_base_class() {
        let mut a = Analyser::new();
        let r = a
            .analyse(
                "namespace eval ::ns {\n  oo::class create Base {}\n  \
                 oo::class create Sub { superclass ::ns::Base }\n}\n",
                "tcl9.0",
            )
            .clone();
        assert!(
            has_cmd_ref(&r, "::ns::Base", "::ns::Base"),
            "superclass must record a command reference: {:?}",
            r.command_invocations
                .iter()
                .map(|i| &i.name)
                .collect::<Vec<_>>()
        );
    }

    // TP: `mixin ::ns::Role` — the mixed-in class is a command reference.
    #[test]
    fn mixin_records_a_command_reference_to_the_class() {
        let mut a = Analyser::new();
        let r = a
            .analyse(
                "namespace eval ::ns {\n  oo::class create Role {}\n  \
                 oo::class create C { mixin ::ns::Role }\n}\n",
                "tcl9.0",
            )
            .clone();
        assert!(has_cmd_ref(&r, "::ns::Role", "::ns::Role"));
    }

    // The `forward` target resolves through the member grammar's
    // `ArgRole::CommandName` and records the delegated command.
    #[test]
    fn forward_target_still_records_a_command_reference() {
        let mut a = Analyser::new();
        let r = a
            .analyse(
                "namespace eval ::ns {\n  proc helper {} {}\n  \
                 oo::class create C { forward f ::ns::helper }\n}\n",
                "tcl9.0",
            )
            .clone();
        assert!(has_cmd_ref(&r, "::ns::helper", "::ns::helper"));
    }

    // TP: a bare `superclass Base` (same namespace) resolves to the enclosing
    // namespace's class — the one-hop call-site resolution, not an ancestor.
    #[test]
    fn bare_superclass_resolves_in_the_class_namespace() {
        let mut a = Analyser::new();
        let r = a
            .analyse(
                "namespace eval ::ns {\n  oo::class create Base {}\n  \
                 oo::class create Sub { superclass Base }\n}\n",
                "tcl9.0",
            )
            .clone();
        assert!(has_cmd_ref(&r, "Base", "::ns::Base"));
    }

    // TP (itcl): `inherit ::ns::Base` names a base class the same way.
    #[test]
    fn itcl_inherit_records_a_command_reference_to_the_base_class() {
        let mut a = Analyser::new();
        let r = a
            .analyse(
                "itcl::class ::ns::Base {}\n\
                 itcl::class ::ns::Sub { inherit ::ns::Base }\n",
                "tcl8.6",
            )
            .clone();
        assert!(
            has_cmd_ref(&r, "::ns::Base", "::ns::Base"),
            "itcl inherit must record a command reference: {:?}",
            r.command_invocations
                .iter()
                .map(|i| &i.name)
                .collect::<Vec<_>>()
        );
    }

    // TN: a dynamic base name (`superclass $base`) names no static command —
    // no reference is recorded (nothing to navigate or rename).
    #[test]
    fn dynamic_superclass_records_no_command_reference() {
        let mut a = Analyser::new();
        let r = a
            .analyse(
                "namespace eval ::ns {\n  \
                 oo::class create Sub { superclass $base }\n}\n",
                "tcl9.0",
            )
            .clone();
        assert!(
            !r.command_invocations
                .iter()
                .any(|inv| inv.name.contains('$')),
            "a dynamic superclass name must not be recorded as a reference"
        );
    }

    // FP guard: `mixin -append ::ns::M` — the `-append` flag is not a class,
    // only `::ns::M` is a reference.
    #[test]
    fn mixin_append_flag_is_not_a_command_reference() {
        let mut a = Analyser::new();
        let r = a
            .analyse(
                "namespace eval ::ns {\n  oo::class create M {}\n  \
                 oo::class create C { mixin -append ::ns::M }\n}\n",
                "tcl9.0",
            )
            .clone();
        assert!(
            has_cmd_ref(&r, "::ns::M", "::ns::M"),
            "the class is a reference"
        );
        assert!(
            !r.command_invocations
                .iter()
                .any(|inv| inv.name == "-append"),
            "the -append flag must not be recorded as a command reference"
        );
    }

    // TP: the inline `oo::define Sub superclass Base` form (no `{body}` block)
    // records the base-class reference too — the same as the braced body form.
    // (The inline path is separate from the body walk.)
    #[test]
    fn inline_oo_define_superclass_records_a_command_reference() {
        let mut a = Analyser::new();
        let r = a
            .analyse(
                "namespace eval ::ns {\n  oo::class create Base {}\n  \
                 oo::class create Sub {}\n  oo::define Sub superclass ::ns::Base\n}\n",
                "tcl9.0",
            )
            .clone();
        assert!(
            has_cmd_ref(&r, "::ns::Base", "::ns::Base"),
            "inline `oo::define … superclass` must record a command reference: {:?}",
            r.command_invocations
                .iter()
                .map(|i| &i.name)
                .collect::<Vec<_>>()
        );
    }

    // TP: a `forward` target may legally begin with `-` (a command named
    // `-foo`).  The `-`-flag filter applies only to class-list members
    // (`mixin -append`), never to the forward command name.
    #[test]
    fn forward_target_beginning_with_dash_is_recorded() {
        let mut a = Analyser::new();
        let r = a
            .analyse(
                "namespace eval ::ns {\n  oo::class create C { forward f -foo }\n}\n",
                "tcl9.0",
            )
            .clone();
        assert!(
            r.command_invocations.iter().any(|inv| inv.name == "-foo"),
            "a hyphen-prefixed forward target must be recorded: {:?}",
            r.command_invocations
                .iter()
                .map(|i| &i.name)
                .collect::<Vec<_>>()
        );
    }

    #[test]
    fn property_subcommand_with_no_kind_defaults_to_readwrite() {
        let mut cd = class();
        let texts: Vec<String> = ["property", "x"].iter().map(|s| (*s).to_string()).collect();
        let argv = [tok((0, 8)), tok((9, 10))];
        apply_oo_subcommand(tcloo(), &texts, &argv, &mut cd);
        let pd = cd.properties.get("x").expect("x recorded");
        assert_eq!(pd.kind, "readwrite");
        assert!(!pd.has_getter);
        assert!(!pd.has_setter);
    }

    #[test]
    fn property_subcommand_records_multiple_names() {
        let mut cd = class();
        let texts: Vec<String> = ["property", "x", "y", "-kind", "writable"]
            .iter()
            .map(|s| (*s).to_string())
            .collect();
        let argv = [
            tok((0, 8)),
            tok((9, 10)),
            tok((11, 12)),
            tok((13, 18)),
            tok((19, 27)),
        ];
        apply_oo_subcommand(tcloo(), &texts, &argv, &mut cd);
        assert_eq!(cd.properties.len(), 2);
        assert_eq!(cd.properties["x"].kind, "writable");
        assert_eq!(cd.properties["y"].kind, "writable");
    }

    #[test]
    fn extract_method_def_too_few_args_returns_none() {
        // ``method`` with only 1 arg (just the name) — needs 3 (name, params,
        // body), so the grammar's `Body` word at index 2 is absent.
        let member = tcloo().member("method").expect("method is a member");
        let args: Vec<String> = vec!["foo".to_string()];
        let arg_tokens: Vec<Token> = vec![tok((0, 3))];
        let md = extract_method_def(member, &args, &arg_tokens, "method", "public", "");
        assert!(md.is_none());
    }

    fn param(name: &str) -> ParamDef {
        ParamDef {
            name: name.to_string(),
            has_default: false,
            default_value: None,
        }
    }

    /// Depth coverage: `walk_unknown_stmt` recurses once per nested
    /// `if`/`for`/`while`/`foreach`/`catch`/`try`/`switch`/`Block`/`UpFrame`
    /// body, with no depth cap of its own. Transitively bounded to
    /// `MAX_LOWER_NEST_DEPTH`
    /// (256) by the lowering pass today, so this is defence-in-depth /
    /// consistency with every other full-tree walker in this crate, not a
    /// currently-reproducible crash. 1000 levels of *source* nesting is
    /// comfortably past this new cap; the assertion is that
    /// `extract_unknown_proc_info` returns at all, not what it returns.
    /// Spawns its own big-stack thread since the lexer/CST/segmenter
    /// stages upstream of `walk_unknown_stmt`'s own new cap still walk the
    /// full un-truncated source nesting before lowering's cap trims it —
    /// same rationale as `structured::tests::deeply_nested_if_survives_structured_walk`.
    #[test]
    fn extract_unknown_proc_info_survives_deep_nesting() {
        const DEPTH: usize = 1000;
        const STACK_SIZE: usize = 64 * 1024 * 1024;
        let mut body = String::new();
        for _ in 0..DEPTH {
            body.push_str("if {1} {\n");
        }
        body.push_str("exec ls\n");
        for _ in 0..DEPTH {
            body.push_str("}\n");
        }
        std::thread::Builder::new()
            .stack_size(STACK_SIZE)
            .spawn(move || {
                let mut a = Analyser::new();
                let _ = a.extract_unknown_proc_info(&body, &[param("cmd"), param("args")]);
            })
            .unwrap()
            .join()
            .unwrap();
    }

    #[test]
    fn extract_unknown_proc_info_empty_body_marks_empty_stub() {
        let mut a = Analyser::new();
        let info = a.extract_unknown_proc_info("", &[param("cmd"), param("args")]);
        assert!(info.empty_stub);
        assert_eq!(info.dispatch_targets.len(), 0);
    }

    #[test]
    fn extract_unknown_proc_info_whitespace_body_marks_empty_stub() {
        let mut a = Analyser::new();
        let info = a.extract_unknown_proc_info("   \n  \t ", &[param("cmd"), param("args")]);
        assert!(info.empty_stub);
    }

    fn logical_unknown_input(
        context: std::sync::Arc<tcl_registry::model::ContextRegistry>,
    ) -> super::super::ResolvedAnalysisInput {
        let profile = tcl_dialect::DialectProfile::plain_tcl();
        super::super::ResolvedAnalysisInput::new(
            profile,
            profile,
            context,
            tcl_lexer::LexerConfig::for_profile(Some(profile)),
        )
    }

    fn logical_unknown_analyser() -> Analyser {
        let input = logical_unknown_input(tcl_registry::model::ingress::context_for_profile(
            tcl_dialect::DialectProfile::plain_tcl(),
        ));
        assert!(input.has_logical_source_name_context());
        Analyser::new().with_resolved_input(input)
    }

    #[test]
    fn original_unknown_source_context_requires_retained_logical_input_and_current_registry() {
        // naming.compiler.original-unknown-handler-source-context
        // docs/design/analysis/name-resolution-proofs/compiler-original-unknown-handler-source-context.md
        let body = "switch -exact $cmd {foo {return 1}}";
        let mut missing = Analyser::new();
        assert!(
            missing
                .extract_unknown_proc_info(body, &[param("cmd")])
                .dispatch_targets
                .is_empty()
        );
        let input = logical_unknown_analyser().resolved_input.unwrap();
        let options =
            crate::command_binding::SourceAnalysisOptions::for_logical_source(&input).unwrap();
        let context = input.context_registry();
        let mut lowerer =
            crate::lowering::Lowerer::with_config(context.commands(), input.lexer_config());
        lowerer.set_source_analysis_options(options);
        let lowered = lowerer.lower(body);
        let statement = lowered.top_level.statements.first().unwrap();
        let binding = lowered
            .top_level
            .retained_source_tokens_for_statement(statement)
            .unwrap()
            .source_binding
            .as_ref()
            .unwrap();
        assert_eq!(binding.logical_source_name_advice_input(), Some(&input));
        assert!(matches!(
            statement,
            Statement::Call { .. } | Statement::Barrier { .. }
        ));
        // The possible source bodies do not settle the unknown option branch.
        let metadata = crate::registry_invocation::InvocationMetadataContext::for_analysis_input(
            context.commands(),
            &input,
        )
        .unwrap();
        let case =
            crate::registry_invocation::source_structure::original_logical_source_case_for_tokens(
                lowered
                    .top_level
                    .retained_source_tokens_for_statement(statement)
                    .unwrap(),
                context.commands(),
                metadata,
            )
            .unwrap();
        assert!(case.body_operands().selection_unknown);
        let mut logical = logical_unknown_analyser();
        assert!(
            logical
                .extract_unknown_proc_info(body, &[param("cmd")])
                .dispatch_targets
                .contains("foo")
        );
        let mut logical = logical_unknown_analyser();
        // Retired analyser registry labels cannot replace the retained input.
        logical.registry = Some(
            tcl_registry::model::ingress::static_context_for("f5-irules")
                .commands()
                .snapshot()
                .shared_registry(),
        );
        assert!(
            logical
                .extract_unknown_proc_info(body, &[param("cmd")])
                .dispatch_targets
                .contains("foo")
        );
        for dialect in [
            "tcl8.4",
            "tcl8.5",
            "tcl8.6",
            "tcl9.0",
            "tcl9.1",
            "jimtcl",
            "f5-irules",
            "f5-iapps",
            "f5-tmsh",
        ] {
            let environment = tcl_registry::model::ingress::resolve_environment(dialect);
            let profile = environment.unit_profile();
            let input = super::super::ResolvedAnalysisInput::new(
                environment.analyser_profile(),
                profile,
                environment.default_context_registry(),
                tcl_lexer::LexerConfig::for_profile(Some(profile)),
            );
            assert!(!input.has_logical_source_name_context(), "{dialect}");
            let mut native = Analyser::new().with_resolved_input(input);
            assert!(
                native
                    .extract_unknown_proc_info(body, &[param("cmd")])
                    .dispatch_targets
                    .is_empty(),
                "{dialect}"
            );
        }
    }

    #[test]
    fn original_unknown_case_advice_retains_residuals_in_final_info() {
        // naming.compiler.original-unknown-handler-source-context
        // docs/design/analysis/name-resolution-proofs/compiler-original-unknown-handler-source-context.md
        // Possible source dispatch keeps its selection/error and no-match
        // paths; it supplies no Native occupancy, chosen effect or body entry.
        let mut analyser = logical_unknown_analyser();
        let result = analyser.analyse(
            "proc unknown {cmd args} {switch -exact $cmd {café {return 1} default {return 0}}}",
            "tcl",
        );
        let info = result
            .unknown_proc_info
            .expect("original unknown declaration");
        assert!(info.dispatch_targets.contains("café"));
        assert!(!info.dispatch_targets.contains("default"));
        assert!(!info.has_pattern_dispatch);
        let [residual] = info.case_body_residuals.as_slice() else {
            panic!("the final AnalysisResult must retain its canonical case residual")
        };
        assert!(residual.selection_unknown);
        assert!(!residual.no_match_possible);
        assert_eq!(residual.bodies.len(), 2);
        assert_eq!(residual.patterns.len(), 2);

        let input = logical_unknown_analyser().resolved_input.unwrap();
        let context = input.context_registry();
        let closed = "switch -exact -- $cmd {foo {return 1} default {return 0}}";
        let mut lowerer =
            crate::lowering::Lowerer::with_config(context.commands(), input.lexer_config())
                .with_resolved_analysis_input(input.clone());
        let script = lowerer.lower(closed).top_level.clone();
        assert!(matches!(
            script.statements.first(),
            Some(Statement::Switch { .. })
        ));
        let mut analyser = Analyser::new().with_resolved_input(input);
        let info = analyser.extract_unknown_proc_info(closed, &[param("cmd")]);
        assert!(info.dispatch_targets.contains("foo"));
        assert_eq!(info.case_body_residuals.len(), 1);
        assert!(!info.case_body_residuals[0].selection_unknown);
        assert!(!info.case_body_residuals[0].no_match_possible);
    }

    #[test]
    fn original_unknown_case_advice_keeps_captured_ordinals_and_literal_parameter_names() {
        // naming.compiler.original-unknown-handler-source-context
        // docs/design/analysis/name-resolution-proofs/compiler-original-unknown-handler-source-context.md
        let source = "interp alias {} ::choisiré {} switch -exact; ::choisiré $cmd {é {return 1} default {return 0}}";
        let mut analyser = logical_unknown_analyser();
        let info = analyser.extract_unknown_proc_info(source, &[param("cmd")]);
        assert!(info.dispatch_targets.contains("é"));
        let [residual] = info.case_body_residuals.as_slice() else {
            panic!("the captured selector retains a case residual")
        };
        assert!(residual.selection_unknown);
        assert_eq!(residual.bodies[0].argument, 2);
        assert_eq!(residual.bodies[0].list_element, Some(1));
        assert_eq!(residual.patterns[0].argument, 2);
        assert_eq!(residual.patterns[0].list_element, Some(0));

        for source in [
            "switch -exact $cmdSuffix {foo {return 1}}",
            "switch -exact {$cmd} {foo {return 1}}",
            "switch -exact $cmd(index) {foo {return 1}}",
        ] {
            let info = analyser.extract_unknown_proc_info(source, &[param("cmd")]);
            assert!(info.dispatch_targets.is_empty(), "{source}");
            assert!(info.case_body_residuals.is_empty(), "{source}");
        }
        let info = analyser.extract_unknown_proc_info(
            "switch -exact ${$cmd} {literal {return 1}}",
            &[param("$cmd")],
        );
        assert!(info.dispatch_targets.contains("literal"));
    }

    fn original_case_availability_contexts() -> (
        std::sync::Arc<tcl_registry::model::ContextRegistry>,
        std::sync::Arc<tcl_registry::model::ContextRegistry>,
    ) {
        use std::sync::Arc;
        let baseline = tcl_registry::model::ingress::static_context_for("tcl8.6");
        let mut registry = baseline
            .commands()
            .project_for_profile(tcl_dialect::DialectProfile::find("tcl8.6").unwrap());
        let mut spec = registry.get("switch").unwrap().clone();
        spec.name = "current_case";
        spec.surface = Some(tcl_dialect::model::SpecSurface::TCL86_PLUS);
        registry.insert(spec);
        let current = Arc::new(baseline.with_command_store(Arc::new(registry)));
        let older = Arc::new(
            tcl_registry::model::ingress::static_context_for("tcl8.4")
                .with_command_store(Arc::clone(current.commands())),
        );
        assert!(Arc::ptr_eq(current.commands(), older.commands()));
        (current, older)
    }

    #[test]
    fn original_unknown_case_advice_refuses_missing_foreign_changed_and_shadowed_owners() {
        // naming.compiler.original-unknown-handler-source-context
        // docs/design/analysis/name-resolution-proofs/compiler-original-unknown-handler-source-context.md
        use crate::registry_invocation::{
            InvocationMetadataContext, source_structure::original_logical_source_case_for_tokens,
        };
        use std::sync::Arc;
        let (current, older) = original_case_availability_contexts();
        let input = logical_unknown_input(Arc::clone(&current));
        let profile = input.unit_profile();
        let config = input.lexer_config();
        let source =
            "interp alias {} selecté {} current_case -exact; selecté $cmd {foo {return 1}}";
        let mut analyser = Analyser::new().with_resolved_input(input.clone());
        let positive = analyser.extract_unknown_proc_info(source, &[param("cmd")]);
        assert!(positive.dispatch_targets.contains("foo"));
        assert!(positive.case_body_residuals[0].no_match_possible);
        let mut lowerer = crate::lowering::Lowerer::with_config(current.commands(), config)
            .with_resolved_analysis_input(input.clone());
        let script = lowerer.lower(source).top_level.clone();
        let tokens = script
            .retained_source_tokens_for_statement(script.statements.last().unwrap())
            .unwrap();
        let metadata =
            InvocationMetadataContext::for_analysis_input(current.commands(), &input).unwrap();
        assert!(
            original_logical_source_case_for_tokens(tokens, current.commands(), metadata).is_some()
        );
        assert!(
            original_logical_source_case_for_tokens(
                tokens,
                current.commands(),
                current.as_ref().into()
            )
            .is_none()
        );
        let foreign = logical_unknown_input(
            tcl_registry::model::ingress::resolve_environment("tcl9.1").default_context_registry(),
        );
        let mut changed_config = config;
        changed_config.strict_quoting = !changed_config.strict_quoting;
        let changed = super::super::ResolvedAnalysisInput::new(
            profile,
            profile,
            Arc::clone(&current),
            changed_config,
        );
        for input in [&foreign, &changed] {
            let metadata = InvocationMetadataContext::for_analysis_input(
                input.borrowed_context_registry().commands(),
                input,
            )
            .unwrap();
            assert!(
                original_logical_source_case_for_tokens(tokens, current.commands(), metadata)
                    .is_none()
            );
        }
        let mut missing = tokens.clone();
        missing.source_binding = None;
        assert!(
            original_logical_source_case_for_tokens(&missing, current.commands(), metadata)
                .is_none()
        );
        let mut altered = tokens.clone();
        let crate::ir::WordExpr::Variable { spelling, .. } = &mut altered.word_exprs[1] else {
            panic!("original written subject")
        };
        *spelling = "$other".into();
        assert!(
            original_logical_source_case_for_tokens(&altered, current.commands(), metadata)
                .is_none()
        );
        let mut absent = Analyser::new();
        assert!(
            absent
                .extract_unknown_proc_info(source, &[param("cmd")])
                .dispatch_targets
                .is_empty()
        );
        let mut unavailable = Analyser::new().with_resolved_input(logical_unknown_input(older));
        assert!(
            unavailable
                .extract_unknown_proc_info(source, &[param("cmd")])
                .dispatch_targets
                .is_empty()
        );
        for source in [
            "proc current_case args {}; interp alias {} selecté {} current_case -exact; selecté $cmd {foo {return 1}}",
            "interp alias {} selecté {} current_case -exact; proc current_case args {}; selecté $cmd {foo {return 1}}",
            "current_case $option $cmd {foo {return 1}}",
        ] {
            assert!(
                analyser
                    .extract_unknown_proc_info(source, &[param("cmd")])
                    .dispatch_targets
                    .is_empty(),
                "{source}"
            );
        }
    }

    #[test]
    fn original_unknown_case_advice_selects_the_original_case_fold_child() {
        // naming.compiler.original-unknown-handler-source-context
        // docs/design/analysis/name-resolution-proofs/compiler-original-unknown-handler-source-context.md
        let mut analyser = logical_unknown_analyser();
        let source =
            "interp alias {} foldé {} string tolower; switch -exact [foldé $cmd] {foo {return 1}}";
        let info = analyser.extract_unknown_proc_info(source, &[param("cmd")]);
        assert!(info.dispatch_targets.contains("foo"));
        assert!(info.case_insensitive);
        for source in [
            "proc string args {}; switch -exact [string tolower $cmd] {foo {return 1}}",
            "switch -exact [list {string tolower $cmd}] {foo {return 1}}",
            "switch -exact [string tolower $other] {foo {return 1}}",
        ] {
            let info = analyser.extract_unknown_proc_info(source, &[param("cmd")]);
            assert!(info.dispatch_targets.is_empty(), "{source}");
            assert!(!info.case_insensitive, "{source}");
        }
        let input = logical_unknown_analyser().resolved_input.unwrap();
        let context = input.context_registry();
        let mut lowerer =
            crate::lowering::Lowerer::with_config(context.commands(), input.lexer_config())
                .with_resolved_analysis_input(input.clone());
        let script = lowerer.lower(source).top_level.clone();
        let mut tokens = script
            .retained_source_tokens_for_statement(script.statements.last().unwrap())
            .unwrap()
            .clone();
        assert!(!tokens.nested_bindings.is_empty());
        tokens.nested_bindings.clear();
        let metadata = crate::registry_invocation::InvocationMetadataContext::for_analysis_input(
            context.commands(),
            &input,
        )
        .unwrap();
        let case =
            crate::registry_invocation::source_structure::original_logical_source_case_for_tokens(
                &tokens,
                context.commands(),
                metadata,
            )
            .unwrap();
        assert!(!case.references_parameter("cmd"));
        assert!(!case.folds_case());
    }

    #[test]
    fn original_unknown_native_case_advice_requires_typed_switch_and_original_input() {
        // naming.compiler.original-unknown-handler-source-context
        // docs/design/analysis/name-resolution-proofs/compiler-original-unknown-handler-source-context.md
        // This fixture retains actual registration and compiler entry. The
        // readonly case query grants no successful variable read or body entry.
        use crate::registry_invocation::{
            InvocationMetadataContext, InvocationMetadataInput,
            source_structure::original_native_source_case_for_statement,
        };
        let environment = tcl_registry::model::ingress::resolve_environment("tcl8.6");
        let profile = environment.unit_profile();
        let context = environment.default_context_registry();
        let config = tcl_lexer::LexerConfig::for_profile(Some(profile));
        let input = super::super::ResolvedAnalysisInput::new(
            environment.analyser_profile(),
            profile,
            context.clone(),
            config,
        );
        let (_owner, captured) =
            crate::environment_ingress::captured_native_entry_with_owner(profile);
        let options = crate::command_binding::SourceAnalysisOptions {
            metadata_context: InvocationMetadataInput::SuppliedSource(Some(&input)),
            native_entry: Some(&captured),
            invocation_dialect: Some(tcl_registry::InvocationDialect::of_profile(profile)),
            native_compilation: crate::environment_ingress::authoring_native_compilation(),
            ..Default::default()
        };
        let mut lowerer = crate::lowering::Lowerer::with_config(context.commands(), config)
            .with_dialect(Some(profile))
            .with_resolved_analysis_input(input.clone());
        lowerer.set_source_analysis_options(options);
        let script = lowerer
            .lower("switch -exact -- $cmd {foo {return 1} default {return 0}}")
            .top_level
            .clone();
        let statement = script.statements.first().unwrap();
        assert!(matches!(statement, Statement::Switch { .. }));
        let metadata =
            InvocationMetadataContext::for_analysis_input(context.commands(), &input).unwrap();
        let case = original_native_source_case_for_statement(
            &script,
            statement,
            context.commands(),
            metadata,
        )
        .expect("typed original Native case source");
        assert!(case.references_parameter("cmd"));
        assert_eq!(case.patterns(), &["foo"]);
        assert!(!case.body_operands().selection_unknown);
        assert!(!case.body_operands().no_match_possible);
        let mut info = UnknownProcInfo::default();
        walk_unknown_stmt(
            statement,
            &script,
            &context,
            Some(metadata),
            "cmd",
            &mut info,
            0,
        );
        assert!(info.dispatch_targets.contains("foo"));
        assert_eq!(info.case_body_residuals.len(), 1);
        assert!(
            original_native_source_case_for_statement(
                &script,
                statement,
                context.commands(),
                context.as_ref().into(),
            )
            .is_none()
        );
        let mut missing = script.clone();
        missing.command_binding_sites = Default::default();
        assert!(
            original_native_source_case_for_statement(
                &missing,
                &missing.statements[0],
                context.commands(),
                metadata,
            )
            .is_none()
        );
        let mut generic_lowerer = crate::lowering::Lowerer::with_config(context.commands(), config)
            .with_resolved_analysis_input(input.clone());
        let generic = generic_lowerer
            .lower("switch -exact -- $cmd {foo {return 1} default {return 0}}")
            .top_level
            .clone();
        let generic_statement = generic.statements.first().unwrap();
        assert!(!matches!(generic_statement, Statement::Switch { .. }));
        assert!(
            original_native_source_case_for_statement(
                &generic,
                generic_statement,
                context.commands(),
                metadata,
            )
            .is_none()
        );
    }

    #[test]
    fn extract_unknown_proc_info_exact_switch_collects_dispatch_targets() {
        let mut a = logical_unknown_analyser();
        let body = r"switch -exact $cmd {
            foo { return 1 }
            bar { return 2 }
            default { return 0 }
        }";
        let info = a.extract_unknown_proc_info(body, &[param("cmd"), param("args")]);
        assert!(!info.empty_stub);
        assert!(info.dispatch_targets.contains("foo"));
        assert!(info.dispatch_targets.contains("bar"));
        assert!(!info.dispatch_targets.contains("default"));
        assert!(!info.has_pattern_dispatch);
    }

    #[test]
    fn extract_unknown_proc_info_glob_switch_marks_pattern_dispatch() {
        let mut a = logical_unknown_analyser();
        let body = r"switch -glob $cmd {
            foo* { return 1 }
            *bar { return 2 }
        }";
        let info = a.extract_unknown_proc_info(body, &[param("cmd"), param("args")]);
        assert!(info.has_pattern_dispatch);
        assert_eq!(info.dispatch_targets.len(), 0);
    }

    #[test]
    fn extract_unknown_proc_info_chains_original_via_known_target() {
        let mut a = logical_unknown_analyser();
        let body = r"rename unknown _original_unknown
_original_unknown $cmd $args";
        let info = a.extract_unknown_proc_info(body, &[param("cmd"), param("args")]);
        assert!(info.chains_original);
    }

    #[test]
    fn unknown_handler_effects_require_the_live_implementation() {
        for (body, flag) in [
            ("proc exec args {}; exec $cmd", "exec"),
            ("proc auto_load args {}; auto_load $cmd", "load"),
            ("_original_unknown $cmd", "chain"),
            ("if {$condition} {rename exec {}}; exec $cmd", "exec"),
        ] {
            let mut analyser = logical_unknown_analyser();
            let info = analyser.extract_unknown_proc_info(body, &[param("cmd")]);
            let claimed = match flag {
                "exec" => info.has_exec,
                "load" => info.has_auto_load,
                _ => info.chains_original,
            };
            assert!(
                !claimed,
                "unproved implementation acquired builtin effects: {body}"
            );
        }
        let mut analyser = Analyser::new();
        let result = analyser.analyse(
            "proc exec args {}; proc unknown {cmd args} {exec $cmd}",
            "tcl8.6",
        );
        assert!(!result.unknown_proc_info.as_ref().unwrap().has_exec);
    }

    #[test]
    fn unknown_handler_effects_follow_resolved_alias_arguments() {
        let mut analyser = logical_unknown_analyser();
        let info = analyser.extract_unknown_proc_info(
            "interp alias {} ensure {} package require; ensure Tcl",
            &[param("cmd")],
        );
        assert!(info.has_auto_load);
    }

    #[test]
    fn original_unknown_operation_advice_keeps_actual_availability_and_captured_sources() {
        // naming.compiler.original-unknown-handler-source-context
        // docs/design/analysis/name-resolution-proofs/compiler-original-unknown-handler-source-context.md
        // Operation descriptions are conditional source advice, without an
        // executed load, Native handler, cell, frame or Normal certificate.
        use std::sync::Arc;
        let baseline = tcl_registry::model::ingress::static_context_for("tcl8.6");
        let mut registry = baseline
            .commands()
            .project_for_profile(tcl_dialect::DialectProfile::find("tcl8.6").unwrap());
        let mut loader = registry.get("package").unwrap().clone();
        loader.name = "context_package";
        loader.surface = Some(tcl_dialect::model::SpecSurface::TCL86_PLUS);
        let mut subcommands = loader.subcommands.to_vec();
        subcommands
            .iter_mut()
            .find(|subcommand| subcommand.name == "require")
            .unwrap()
            .surface = Some(tcl_dialect::model::SpecSurface::TCL86_PLUS);
        loader.subcommands = Box::leak(subcommands.into_boxed_slice());
        registry.insert(loader);
        let current = Arc::new(baseline.with_command_store(Arc::new(registry)));
        let older = Arc::new(
            tcl_registry::model::ingress::static_context_for("tcl8.4")
                .with_command_store(Arc::clone(current.commands())),
        );
        assert!(Arc::ptr_eq(current.commands(), older.commands()));
        let profile = tcl_dialect::DialectProfile::plain_tcl();
        let config = tcl_lexer::LexerConfig::for_file_grammar(profile.grammar);
        let input =
            |context| super::super::ResolvedAnalysisInput::new(profile, profile, context, config);
        let source = "interp alias {} ::chargeré {} context_package require; ::chargeré Tcl";
        let mut analyser = Analyser::new().with_resolved_input(input(Arc::clone(&current)));
        assert!(
            analyser
                .extract_unknown_proc_info(source, &[param("cmd")])
                .has_auto_load
        );
        analyser.registry = Some(
            tcl_registry::model::ingress::static_context_for("f5-irules")
                .commands()
                .snapshot()
                .shared_registry(),
        );
        assert!(
            analyser
                .extract_unknown_proc_info(source, &[param("cmd")])
                .has_auto_load
        );
        let mut unavailable = Analyser::new().with_resolved_input(input(older));
        assert!(
            !unavailable
                .extract_unknown_proc_info(source, &[param("cmd")])
                .has_auto_load
        );
        let replaced = "proc context_package args {}; interp alias {} ensure {} context_package require; ensure Tcl";
        assert!(
            !analyser
                .extract_unknown_proc_info(replaced, &[param("cmd")])
                .has_auto_load
        );
    }

    fn assert_captured_logical_source_target(
        tokens: &crate::ir::CommandTokens,
        context: &tcl_registry::model::ContextRegistry,
        metadata: crate::registry_invocation::InvocationMetadataContext<'_>,
    ) {
        let input = metadata.source_analysis_input().unwrap();
        let original = tokens.source_binding.as_ref().unwrap();
        let target = original
            .proved_execution_target()
            .expect("closed Logical source target");
        assert!(target.registry_backed);
        let dialect = original
            .original_source_word_dialect_for_tokens(tokens)
            .expect("actual Logical source dialect");
        assert!(dialect.native_name_protocol().is_none());
        assert!(
            crate::command_binding::SourceAnalysisOptions::for_logical_source(input)
                .unwrap()
                .native_entry
                .is_none()
        );
        let selected = crate::registry_invocation::original_logical_operation_invocation_with_metadata_context(
            context.commands(), metadata, tokens,
        ).unwrap();
        assert!(
            selected
                .with_metadata_schema(
                    context.commands(),
                    metadata,
                    original.invocation_realm().unwrap(),
                    |schema| {
                        let target_spec = context.context().resolve_spec_in_realm(
                            context.commands(),
                            &target.command,
                            original.invocation_realm().unwrap(),
                        )?;
                        Some(std::ptr::eq(
                            target_spec,
                            schema.authored_source_descriptors().command,
                        ))
                    },
                )
                .unwrap()
        );
        assert_eq!(
            selected.evaluated_words[0].literal_bytes(),
            Some(b"require".as_slice())
        );
        assert_eq!(
            selected.effective.origins[1],
            crate::registry_invocation::InvocationWordOrigin::BindingPrefix(0)
        );
        assert_eq!(selected.effective.written_argument(1), Some(0));
    }

    #[test]
    fn original_unknown_operation_advice_refuses_missing_foreign_changed_and_dynamic_source() {
        // naming.compiler.original-unknown-handler-source-context
        // docs/design/analysis/name-resolution-proofs/compiler-original-unknown-handler-source-context.md
        use crate::registry_invocation::InvocationMetadataContext;
        let input = logical_unknown_analyser().resolved_input.unwrap();
        let context = input.context_registry();
        let source = "interp alias {} ensure {} package require; ensure Tcl";
        let mut lowerer =
            crate::lowering::Lowerer::with_config(context.commands(), input.lexer_config())
                .with_resolved_analysis_input(input.clone());
        let script = lowerer.lower(source).top_level.clone();
        let statement = script.statements.last().unwrap();
        let original = statement.tokens().unwrap().source_binding.as_ref().unwrap();
        assert!(original.original_recorded_head_name_input().is_none());
        let metadata = InvocationMetadataContext::for_source_input(
            context.commands(),
            &input,
            input.lexer_config(),
            Some(input.unit_profile()),
        )
        .unwrap();
        assert_captured_logical_source_target(statement.tokens().unwrap(), &context, metadata);
        let inspect = |statement: &Statement, metadata| {
            let mut info = UnknownProcInfo::default();
            walk_unknown_stmt(statement, &script, &context, metadata, "cmd", &mut info, 0);
            info
        };
        assert!(inspect(statement, Some(metadata)).has_auto_load);
        let foreign = super::super::ResolvedAnalysisInput::new(
            input.analyser_profile(),
            input.unit_profile(),
            tcl_registry::model::ingress::resolve_environment("tcl9.1").default_context_registry(),
            input.lexer_config(),
        );
        let mut config = input.lexer_config();
        config.strict_quoting = !config.strict_quoting;
        let changed = super::super::ResolvedAnalysisInput::new(
            input.analyser_profile(),
            input.unit_profile(),
            input.context_registry(),
            config,
        );
        for metadata in [
            None,
            Some(context.as_ref().into()),
            InvocationMetadataContext::for_analysis_input(
                foreign.borrowed_context_registry().commands(),
                &foreign,
            ),
            InvocationMetadataContext::for_analysis_input(context.commands(), &changed),
        ] {
            assert!(!inspect(statement, metadata).has_auto_load);
        }
        let mut missing = statement.clone();
        missing.tokens_mut().unwrap().source_binding = None;
        assert!(!inspect(&missing, Some(metadata)).has_auto_load);
        let mut analyser = logical_unknown_analyser();
        for source in [
            "interp alias {} ensure {} package $selector; ensure Tcl",
            "interp alias {} ensure {} package require; $unknown Tcl",
            "interp alias {} ensure {} package require; proc package args {}; ensure Tcl",
        ] {
            assert!(
                !analyser
                    .extract_unknown_proc_info(source, &[param("cmd")])
                    .has_auto_load,
                "{source}"
            );
        }
        assert!(
            !Analyser::new()
                .extract_unknown_proc_info(source, &[param("cmd")])
                .has_auto_load
        );
    }

    #[test]
    fn original_unknown_operation_purpose_requires_the_complete_original_source_input() {
        // naming.compiler.original-unknown-handler-source-context
        // docs/design/analysis/name-resolution-proofs/compiler-original-unknown-handler-source-context.md
        let input = logical_unknown_analyser().resolved_input.unwrap();
        let context = input.context_registry();
        let source = "interp alias {} ensure {} package require; ensure Tcl";
        let mut lowerer =
            crate::lowering::Lowerer::with_config(context.commands(), input.lexer_config())
                .with_resolved_analysis_input(input.clone());
        let script = lowerer.lower(source).top_level.clone();
        let statement = script.statements.last().unwrap();
        let metadata = crate::registry_invocation::InvocationMetadataContext::for_analysis_input(
            context.commands(),
            &input,
        )
        .unwrap();
        let mut selected = UnknownProcInfo::default();
        walk_unknown_stmt(
            statement,
            &script,
            &context,
            Some(metadata),
            "cmd",
            &mut selected,
            0,
        );
        assert!(selected.has_auto_load);
        let native_profile =
            tcl_registry::model::ingress::resolve_environment("tcl8.6").analyser_profile();
        let native_input = super::super::ResolvedAnalysisInput::new(
            native_profile,
            native_profile,
            std::sync::Arc::clone(&context),
            input.lexer_config(),
        );
        assert!(!native_input.has_logical_source_name_context());
        for metadata in [
            None,
            Some(context.as_ref().into()),
            crate::registry_invocation::InvocationMetadataContext::for_analysis_input(
                context.commands(),
                &native_input,
            ),
        ] {
            let mut refused = UnknownProcInfo::default();
            walk_unknown_stmt(
                statement,
                &script,
                &context,
                metadata,
                "cmd",
                &mut refused,
                0,
            );
            assert!(!refused.has_auto_load);
            assert!(!refused.has_exec);
            assert!(!refused.chains_original);
            assert!(refused.dispatch_targets.is_empty());
        }
    }

    #[test]
    fn extract_unknown_proc_info_detects_exec_call() {
        let mut a = logical_unknown_analyser();
        let body = r"exec $cmd {*}$args";
        let info = a.extract_unknown_proc_info(body, &[param("cmd"), param("args")]);
        assert!(info.has_exec);
    }

    #[test]
    fn extract_unknown_proc_info_detects_auto_load_call() {
        let mut a = logical_unknown_analyser();
        let body = r"auto_load $cmd";
        let info = a.extract_unknown_proc_info(body, &[param("cmd"), param("args")]);
        assert!(info.has_auto_load);
    }

    #[test]
    fn extract_unknown_proc_info_case_insensitive_via_string_tolower() {
        let mut a = logical_unknown_analyser();
        let body = r"switch -exact [string tolower $cmd] {
            foo { return 1 }
        }";
        let info = a.extract_unknown_proc_info(body, &[param("cmd"), param("args")]);
        assert!(info.case_insensitive);
        assert!(info.dispatch_targets.contains("foo"));
    }

    #[test]
    fn extract_unknown_proc_info_no_first_param_defaults_to_cmd() {
        // Empty params list — the helper should fall back to
        // ``"cmd"`` as the dispatch-subject variable name.
        let mut a = logical_unknown_analyser();
        let body = r"switch -exact $cmd { foo { return 1 } }";
        let info = a.extract_unknown_proc_info(body, &[]);
        assert!(info.dispatch_targets.contains("foo"));
    }

    // The `self { … }` / `private { … }` block forms.

    #[test]
    fn self_block_form_records_every_member_as_a_class_method() {
        // TP. Oracle (tclsh 9.0.4 / 8.6.16, identical):
        //   oo::class create ::C {
        //       self { method make {n} {…} ; method other {} {…} }
        //       method inst {} {…}
        //   }
        //   ::C make 7               -> made-7
        //   info object methods ::C  -> other make   (class-object side)
        //   info class methods ::C   -> inst         (instance side)
        //   oo::class create ::F {superclass ::C} ; ::F make 1
        //                            -> error: unknown method "make"
        // i.e. exactly what the `self method …` prefix form declares — which
        // is why both spellings land on the same recording path.
        let src = "oo::class create ::C {\n\
                   self {\n\
                   method make {n} { return $n }\n\
                   method other {} { return other }\n\
                   }\n\
                   method inst {} { return inst }\n\
                   }";
        let mut a = Analyser::new();
        let r = a.analyse(src, "tcl9.0");
        let c = r.all_classes.get("::C").expect("::C recorded");
        for name in ["make", "other"] {
            let md = c
                .class_methods
                .get(name)
                .unwrap_or_else(|| panic!("`{name}` must record as a class method"));
            assert_eq!(md.kind, "classmethod");
            assert!(
                md.is_self_method,
                "`self`-scoped members are not inherited by subclasses",
            );
            assert_eq!(md.visibility, "public");
        }
        // The instance side is untouched — `inst` stays an instance method and
        // the block's members never leak into it.
        assert!(c.methods.contains_key("inst"));
        assert!(!c.methods.contains_key("make"));
        assert!(!c.methods.contains_key("other"));
    }

    #[test]
    fn self_block_form_records_through_oo_define_too() {
        // TP. Same block, reached through `oo::define` rather than the class
        // creation body (oracle: `oo::define ::D { self { method mk {} {…} } }`
        // → `info object methods ::D` is `mk`).
        let src = "oo::class create ::D {}\n\
                   oo::define ::D {\n\
                   self {\n\
                   method mk {} { return dmk }\n\
                   }\n\
                   }";
        let mut a = Analyser::new();
        let r = a.analyse(src, "tcl9.0");
        let c = r.all_classes.get("::D").expect("::D recorded");
        assert!(c.class_methods.contains_key("mk"));
    }

    #[test]
    fn self_block_scoped_unexport_flips_the_class_side() {
        // TP. Oracle: `oo::class create ::E { self { method
        // hidden {} {…} ; unexport hidden } }` leaves `info object methods
        // ::E` empty while `-all -private` still lists `hidden`, and
        // `::E hidden` errors "unknown method" — so the block's `unexport`
        // really does apply to the class-object side. The member is recorded
        // *and* now carries the visibility the block gave it.
        let src = "oo::class create ::E {\n\
                   self {\n\
                   method hidden {} { return h }\n\
                   unexport hidden\n\
                   }\n\
                   }";
        let mut a = Analyser::new();
        let r = a.analyse(src, "tcl9.0");
        let c = r.all_classes.get("::E").expect("::E recorded");
        assert!(c.class_methods.contains_key("hidden"));
        assert_eq!(c.class_methods["hidden"].visibility, "unexported");
    }

    #[test]
    fn self_scoped_unexport_leaves_a_same_named_instance_method_alone() {
        // TN — block and prefix spellings both.
        // Oracle, byte-identical on tclsh 9.0.4 and 8.6.14:
        //   oo::class create C { method m {} {return inst-m}
        //                        self { method m {} {return class-m}
        //                               unexport m } }
        //   info object methods ::C  ->            (class side unexported)
        //   info class methods ::C   -> m          (instance side untouched)
        //   ::C m                    -> unknown method "m"
        //   [::C new] m              -> inst-m
        for src in [
            "oo::class create ::C {\n\
             method m {} { return inst }\n\
             self {\n\
             method m {} { return class }\n\
             unexport m\n\
             }\n\
             }",
            "oo::class create ::C {\n\
             method m {} { return inst }\n\
             self method m {} { return class }\n\
             self unexport m\n\
             }",
        ] {
            let mut a = Analyser::new();
            let r = a.analyse(src, "tcl9.0");
            let c = r.all_classes.get("::C").expect("::C recorded");
            assert_eq!(
                c.class_methods["m"].visibility, "unexported",
                "class side must be flipped",
            );
            assert_eq!(
                c.methods["m"].visibility, "public",
                "instance side must NOT be flipped by a `self`-scoped unexport",
            );
            assert!(
                !c.unexports.contains("m"),
                "the class-level `unexports` set is the instance-side record; a \
                 class-object-side unexport must not enter it",
            );
        }
    }

    #[test]
    fn unwrapped_unexport_leaves_the_class_side_alone() {
        // TN, the mirror direction. Oracle:
        //   oo::class create E2 { self { method onlyclass {} {…} } }
        //   oo::define E2 { unexport onlyclass }
        //   info object methods ::E2 -> onlyclass   (still exported)
        //   ::E2 onlyclass           -> oc          (still dispatches)
        // The unwrapped word acts on the instance side, where the name does
        // not exist — a silent no-op in real Tcl.
        let src = "oo::class create ::E2 {\n\
                   self { method onlyclass {} { return oc } }\n\
                   }\n\
                   oo::define ::E2 { unexport onlyclass }";
        let mut a = Analyser::new();
        let r = a.analyse(src, "tcl9.0");
        let c = r.all_classes.get("::E2").expect("::E2 recorded");
        assert_eq!(c.class_methods["onlyclass"].visibility, "public");
    }

    #[test]
    fn cross_side_unexport_is_a_silent_no_op_not_an_error() {
        // TN / oracle-shape pin. Unlike `deletemethod` (a hard error that
        // aborts the definition), naming the *other* side's method in an
        // `export`/`unexport` is accepted and does nothing:
        //   oo::class create E { method onlyinst {} {…} }
        //   oo::define E { self unexport onlyinst }   ;# no error
        //   info class methods ::E  -> onlyinst       (still exported)
        //   [::E new] onlyinst      -> oi
        // so we record no visibility change and — crucially — no member stub.
        let src = "oo::class create ::E3 { method onlyinst {} { return oi } }\n\
                   oo::define ::E3 { self unexport onlyinst }";
        let mut a = Analyser::new();
        let r = a.analyse(src, "tcl9.0");
        let c = r.all_classes.get("::E3").expect("::E3 recorded");
        assert_eq!(c.methods["onlyinst"].visibility, "public");
        assert!(!c.class_methods.contains_key("onlyinst"));
    }

    #[test]
    fn self_block_export_reexports_a_class_side_member() {
        // TP, the export half — last explicit state wins.
        // Oracle: `oo::class create H1 { self { method lower {} {…} ;
        // unexport lower ; export lower } }` -> `info object methods ::H1`
        // is `lower` on 9.0.4 and 8.6.14 alike.
        let src = "oo::class create ::H1 {\n\
                   self {\n\
                   method lower {} { return l }\n\
                   unexport lower\n\
                   export lower\n\
                   }\n\
                   }";
        let mut a = Analyser::new();
        let r = a.analyse(src, "tcl9.0");
        let c = r.all_classes.get("::H1").expect("::H1 recorded");
        assert_eq!(c.class_methods["lower"].visibility, "public");
    }

    #[test]
    fn private_scoped_visibility_members_flip_the_instance_side() {
        // TP, the third routing. `private` is 9.0-only (`invalid command
        // name "private"` on 8.6), and under it a visibility word acts on the
        // instance side exactly as the unwrapped spelling does. Oracle:
        //   oo::class create G1 { method m {} {…}; private { unexport m } }
        //   info class methods ::G1              ->            (unexported)
        //   info class methods ::G1 -all -private -> … m …
        //   oo::class create G3 { method m {} {…}; private export m }
        //   info class methods ::G3              -> m          (exported)
        for (src, want) in [
            (
                "oo::class create ::G1 {\n\
                 method m {} { return m }\n\
                 private { unexport m }\n\
                 }",
                "unexported",
            ),
            (
                "oo::class create ::G2 {\n\
                 method m {} { return m }\n\
                 private unexport m\n\
                 }",
                "unexported",
            ),
            (
                "oo::class create ::G3 {\n\
                 method m {} { return m }\n\
                 private export m\n\
                 }",
                "public",
            ),
        ] {
            let mut a = Analyser::new();
            let r = a.analyse(src, "tcl9.0");
            let c = r
                .all_classes
                .values()
                .find(|c| c.methods.contains_key("m"))
                .expect("class recorded");
            assert_eq!(c.methods["m"].visibility, want, "{src}");
        }
    }

    #[test]
    fn private_block_form_records_instance_methods() {
        // TP, symmetric half — `private` is the other registry member marked
        // wrapper-with-block-body.
        let src = "oo::class create ::P {\n\
                   private {\n\
                   method secret {k} { return $k }\n\
                   }\n\
                   }";
        let mut a = Analyser::new();
        let r = a.analyse(src, "tcl9.0");
        let c = r.all_classes.get("::P").expect("::P recorded");
        assert_eq!(c.methods["secret"].visibility, "private");
        assert!(!c.class_methods.contains_key("secret"));
    }

    #[test]
    fn self_block_does_not_declare_instance_variables() {
        // TN / abstention boundary. `self { variable x }` declares a variable
        // on the *class object*, not an instance variable of the class — the
        // prefix form (`self variable x`) is not recorded either, and the
        // block form must not start recording it as one.
        let src = "oo::class create ::V {\n\
                   self {\n\
                   variable classlevel\n\
                   }\n\
                   variable instancelevel\n\
                   }";
        let mut a = Analyser::new();
        let r = a.analyse(src, "tcl9.0");
        let c = r.all_classes.get("::V").expect("::V recorded");
        assert_eq!(c.variables, vec!["instancelevel".to_string()]);
    }

    #[test]
    fn self_introspection_prefix_is_not_a_block_member() {
        // TN. Inside a *method body*, `self class` is an introspection call,
        // not a definer member. The body is walked as a script (never as a
        // definition body), so nothing here may reach `class_methods`.
        let src = "oo::class create ::W {\n\
                   method whoami {} { return [self class] }\n\
                   }";
        let mut a = Analyser::new();
        let r = a.analyse(src, "tcl9.0");
        let c = r.all_classes.get("::W").expect("::W recorded");
        assert!(c.methods.contains_key("whoami"));
        assert_eq!(c.class_methods.len(), 0, "{:?}", c.class_methods);
    }

    #[test]
    fn dynamic_self_block_abstains() {
        // Abstention boundary: a non-literal block word cannot be re-segmented
        // statically, so the expansion declines and the class records nothing
        // rather than guessing.
        let src = "set b {method make {n} { return $n }}\n\
                   oo::class create ::Dyn {\n\
                   self $b\n\
                   }";
        let mut a = Analyser::new();
        let r = a.analyse(src, "tcl9.0");
        let c = r.all_classes.get("::Dyn").expect("::Dyn recorded");
        assert_eq!(c.class_methods.len(), 0, "{:?}", c.class_methods);
        assert_eq!(c.methods.len(), 0, "{:?}", c.methods);
    }

    #[test]
    fn self_block_destructive_member_drops_the_member_it_deletes() {
        // TP. Oracle (tclsh 9.0.4 / 8.6.16, identical):
        //   oo::class create ::C1 {
        //       self { method gone {} {…} ; method kept {} {…} ; deletemethod gone }
        //   }
        //   info object methods ::C1  ->  kept
        //   ::C1 gone                 ->  unknown method "gone"
        // Retaining `gone` would show a stale document symbol and let
        // navigation resolve a name the interpreter does not have.
        let src = "oo::class create ::C {\n                   self {\n                   method gone {} { return g }\n                   method kept {} { return k }\n                   deletemethod gone\n                   }\n                   }";
        let mut a = Analyser::new();
        let r = a.analyse(src, "tcl9.0");
        let c = r.all_classes.get("::C").expect("::C recorded");
        assert!(
            !c.class_methods.contains_key("gone"),
            "{:?}",
            c.class_methods
        );
        assert!(c.class_methods.contains_key("kept"));
    }

    #[test]
    fn self_block_renamemethod_moves_the_member_on_the_class_side() {
        // TP, the class-side half. Oracle, byte-identical on tclsh
        // 9.0.4 and 8.6.14:
        //   oo::class create ::R2 { self { method old {} {return CLSOLD}
        //                                  renamemethod old new } }
        //   info object methods ::R2  -> new
        //   ::R2 new                  -> CLSOLD   (shadowing the stock `new`!)
        //   ::R2 old                  -> unknown method
        // The move stays on the wrapper's own side: the instance table is not
        // touched in either direction.
        let src = "oo::class create ::C {\n                   self {\n                   method old {} { return o }\n                   renamemethod old new\n                   }\n                   }";
        let mut a = Analyser::new();
        let r = a.analyse(src, "tcl9.0");
        let c = r.all_classes.get("::C").expect("::C recorded");
        assert!(
            !c.class_methods.contains_key("old"),
            "{:?}",
            c.class_methods
        );
        let md = c.class_methods.get("new").expect("`new` is a class member");
        assert_eq!(md.name, "new");
        assert!(
            src[md.body_span.start() as usize..md.body_span.end() as usize].contains("return o"),
        );
        assert_eq!(
            c.methods.len(),
            0,
            "instance side untouched: {:?}",
            c.methods
        );
        assert!(!has_w315(&r), "{:?}", w315_messages(&r));
    }

    #[test]
    fn private_block_destructive_member_drops_the_instance_side_member() {
        // TP, symmetric half. Oracle (9.0 — `private` is a 9.0 member):
        //   oo::class create ::C5 {
        //       private { method secret {} {…} ; method other {} {…} ;
        //                 deletemethod secret }
        //   }
        //   info class methods ::C5 -all -private   ->  no `secret`
        let src = "oo::class create ::C {\n                   private {\n                   method secret {} { return s }\n                   method other {} { return o }\n                   deletemethod secret\n                   }\n                   }";
        let mut a = Analyser::new();
        let r = a.analyse(src, "tcl9.0");
        let c = r.all_classes.get("::C").expect("::C recorded");
        assert!(!c.methods.contains_key("secret"), "{:?}", c.methods);
        assert!(c.methods.contains_key("other"));
    }

    #[test]
    fn wrapper_block_and_prefix_forms_retract_identically() {
        // The block form is normalised into the prefix form, so both spellings
        // must land on the same result. Oracle for the prefix side:
        //   oo::define ::C7 { self method sgone {} {…} }
        //   info object methods ::C7                  ->  sgone
        //   oo::define ::C7 { self deletemethod sgone }
        //   info object methods ::C7                  ->  (empty)
        let src = "oo::class create ::C {}\n                   oo::define ::C { self method gone {} { return g } }\n                   oo::define ::C { self deletemethod gone }";
        let mut a = Analyser::new();
        let r = a.analyse(src, "tcl9.0");
        let c = r.all_classes.get("::C").expect("::C recorded");
        assert_eq!(c.class_methods.len(), 0, "{:?}", c.class_methods);
    }

    #[test]
    fn a_retraction_does_not_cross_to_the_other_side() {
        // TN. `self deletemethod` touches only the class-object side. Oracle:
        //   oo::class create ::D { method m {} {return inst}
        //                          self { method m {} {return cls} } }
        //   oo::define ::D { self deletemethod m }
        //   info class methods ::D   ->  m        (instance side survives)
        //   info object methods ::D  ->  (empty)
        //   [::D new] m              ->  inst
        let src = "oo::class create ::D {\n                   method m {} { return inst }\n                   self { method m {} { return cls } }\n                   }\n                   oo::define ::D { self deletemethod m }";
        let mut a = Analyser::new();
        let r = a.analyse(src, "tcl9.0");
        let c = r.all_classes.get("::D").expect("::D recorded");
        assert!(c.methods.contains_key("m"), "instance side must survive");
        assert!(!c.class_methods.contains_key("m"), "class side must go");
    }

    #[test]
    fn non_retracting_method_reference_members_keep_their_member() {
        // TN, the discrimination the registry flag exists for: `export`,
        // `unexport`, and `filter` are the sibling `MemberRefKind::Method`
        // members — they *name* a method without removing it, so they must not
        // retract. Oracle:
        //   oo::class create ::A { self { method a {} {…} ; unexport a ; export a } }
        //   info object methods ::A  ->  a   ;  ::A a  ->  1
        //   oo::class create ::B { self { method f {} {…} ; filter f } }
        //   info object methods ::B  ->  f
        let mut a = Analyser::new();
        let r = a.analyse(
            "oo::class create ::A {\n self {\n method a {} { return 1 }\n unexport a\n export a\n }\n}",
            "tcl9.0",
        );
        assert!(
            r.all_classes["::A"].class_methods.contains_key("a"),
            "export/unexport must not retract",
        );
        let mut a = Analyser::new();
        let r = a.analyse(
            "oo::class create ::B {\n self {\n method f {} { return 1 }\n filter f\n }\n}",
            "tcl9.0",
        );
        assert!(
            r.all_classes["::B"].class_methods.contains_key("f"),
            "filter must not retract",
        );
    }

    #[test]
    fn a_retracted_member_can_be_redeclared_by_a_later_body() {
        // Source-order guard. Oracle:
        //   oo::class create ::C { method m {} {return 1} }
        //   oo::define ::C { self method m {} {return 2} }
        //   oo::define ::C { self deletemethod m }
        //   oo::define ::C { self method m {} {return 3} }
        //   ::C m        ->  3     (class side, redeclared after the delete)
        //   [::C new] m  ->  1     (instance side, never touched)
        // Retraction happens where the body is walked, so a later declaration
        // wins — it is not a whole-document erasure of the name.
        let src = "oo::class create ::C { method m {} { return 1 } }\n                   oo::define ::C { self method m {} { return 2 } }\n                   oo::define ::C { self deletemethod m }\n                   oo::define ::C { self method m {} { return 3 } }";
        let mut a = Analyser::new();
        let r = a.analyse(src, "tcl9.0");
        let c = r.all_classes.get("::C").expect("::C recorded");
        assert!(c.class_methods.contains_key("m"), "redeclaration must win");
        assert!(c.methods.contains_key("m"), "instance side untouched");
    }

    #[test]
    fn unwrapped_deletemethod_drops_the_instance_side_member() {
        // TP. An *unwrapped* `deletemethod` — in a class-creation
        // body or an `oo::define` body, with no `self` / `private` wrapper —
        // deletes on the instance side. Oracle, byte-identical on tclsh 9.0.4
        // and 8.6.14:
        //   oo::class create ::I1 { method gone {} {…}; method kept {} {…}
        //                           deletemethod gone }
        //   info class methods ::I1  ->  kept
        //   oo::class create ::I4 { method gone {} {…} }
        //   oo::define ::I4 { deletemethod gone }
        //   info class methods ::I4  ->            (empty)
        for src in [
            "oo::class create ::C {\n\
             method gone {} { return g }\n\
             method kept {} { return k }\n\
             deletemethod gone\n\
             }",
            "oo::class create ::C {\n\
             method gone {} { return g }\n\
             method kept {} { return k }\n\
             }\n\
             oo::define ::C { deletemethod gone }",
        ] {
            let mut a = Analyser::new();
            let r = a.analyse(src, "tcl9.0");
            let c = r.all_classes.get("::C").expect("::C recorded");
            assert!(!c.methods.contains_key("gone"), "deleted member retained");
            assert!(c.methods.contains_key("kept"), "sibling member dropped");
        }
    }

    #[test]
    fn unwrapped_renamemethod_moves_the_member_to_the_new_name() {
        // TP. Oracle,
        // byte-identical on tclsh 9.0.4 and 8.6.14:
        //   oo::class create ::I3 { method old {} {return o}; renamemethod old new }
        //   info class methods ::I3        ->  new
        //   [::I3 new] new                 ->  o        (the old body runs)
        //   info class definition ::I3 new ->  {} { return o }
        //   ::I3 old                       ->  unknown method
        // so `new` is a fully navigable member carrying `old`'s body: `old` goes,
        // `new` arrives with the *same* `MethodDef`, its name span moved onto
        // the `renamemethod` call's destination word (the only place the new
        // name is written) and its body span left on the one real body.
        let mut a = Analyser::new();
        let src = "oo::class create ::C { method old {} { return o }\n\
             renamemethod old new }";
        let r = a.analyse(src, "tcl9.0");
        let c = r.all_classes.get("::C").expect("::C recorded");
        assert!(!c.methods.contains_key("old"));
        let md = c.methods.get("new").expect("`new` is a member");
        assert_eq!(md.name, "new");
        // The name span is the `renamemethod`'s destination word …
        assert_eq!(
            &src[md.name_span.start() as usize..md.name_span.end() as usize],
            "new"
        );
        // … and it is the *second* `new` in the source (the one in the
        // `renamemethod` call), not any earlier text.
        assert!(md.name_span.start() as usize > src.find("renamemethod").expect("call"));
        // … while the body span still points at the original body.
        assert!(
            src[md.body_span.start() as usize..md.body_span.end() as usize].contains("return o"),
            "body span must stay on the original body",
        );
        // A rename is not a (re)declaration, so the family's name-based export
        // default is not re-applied — the source's visibility travels with it.
        assert_eq!(md.visibility, "public");
        // TN: a rename onto a fresh name is a legal order.
        assert!(!has_w315(&r), "{:?}", w315_messages(&r));
        // …and the *destination* name leaves no cross-document tombstone: the
        // rename creates `new`, it does not delete it, so another document's
        // `method new` must survive. Registry data decides which arguments a
        // retracting word removes (`MemberRetraction::FirstArgument`).
        assert!(
            !c.retracted_members
                .iter()
                .any(|r| r.member == "new" || r.member == "old"),
            "a locally-declared retraction needs no tombstone: {:?}",
            c.retracted_members,
        );
    }

    // The class-side visibility + filter channels.

    #[test]
    fn self_scoped_visibility_words_fill_the_class_side_sets() {
        // TP. A `self export` / `self unexport` has to leave a
        // record of its own or the flip never travels to another file's
        // class-command dispatch. Oracle, byte-identical on tclsh 9.0.4/8.6.14:
        //   oo::class create ::X { self { method cm {} { return cm } } }
        //   ::X cm                    ;# -> cm
        //   oo::define X { self unexport cm }
        //   ::X cm                    ;# -> unknown method "cm": must be create,
        //                             ;#    destroy or new
        //   info object methods ::X   ;# -> (empty)
        //   info object methods ::X -all -private ;# -> … cm …  (still defined)
        let mut a = Analyser::new();
        let r = a.analyse(
            "oo::class create ::C { self { method cm {} { return c } } }\n\
             oo::define ::C { self unexport cm }",
            "tcl9.0",
        );
        let c = r.all_classes.get("::C").expect("::C recorded");
        assert!(c.class_unexports.contains("cm"), "{:?}", c.class_unexports);
        assert_eq!(c.class_exports.len(), 0, "{:?}", c.class_exports);
        assert_eq!(c.class_methods["cm"].visibility, "unexported");
        // …and the instance-side pair — the one every existing consumer reads
        // as the instance record — stays untouched in both directions.
        assert_eq!(c.exports.len(), 0, "{:?}", c.exports);
        assert_eq!(c.unexports.len(), 0, "{:?}", c.unexports);
    }

    #[test]
    fn a_rename_carries_the_sources_visibility_not_the_new_names_default() {
        // CRITICAL pin. A rename is not a (re)declaration, so the
        // family's name-based export default (`[a-z]*` is exported for `TclOO`)
        // is NOT re-applied to the destination — the source's own visibility
        // travels with the body. Both directions, byte-identical on tclsh 9.0.4
        // and 8.6.14:
        //   oo::class create ::R4 { method Priv {} {…} ; renamemethod Priv pub }
        //   info class methods ::R4           ;# -> (empty)   `pub` is UNexported
        //   info class methods ::R4 -private  ;# -> pub       despite the name
        //   [::R4 new] pub                    ;# -> unknown method "pub"
        //   oo::class create ::R5 { method low {} {…} ; renamemethod low Up }
        //   info class methods ::R5           ;# -> Up        still EXPORTED
        //   info class methods ::R5 -private  ;# -> Up        despite the name
        //
        // Applying the destination's default instead would flip both of these
        // the wrong way — offering a `pub` no `$obj pub` can call, and hiding an
        // `Up` that dispatches fine.
        for (src_name, dst_name, want) in [("Priv", "pub", "unexported"), ("low", "Up", "public")] {
            let src = format!(
                "oo::class create ::C {{ method {src_name} {{}} {{ return 1 }}\n\
                 renamemethod {src_name} {dst_name} }}"
            );
            let mut a = Analyser::new();
            let r = a.analyse(&src, "tcl9.0");
            let c = r.all_classes.get("::C").expect("::C recorded");
            assert_eq!(
                c.methods[dst_name].visibility, want,
                "{src_name} -> {dst_name}",
            );
        }
    }

    #[test]
    fn the_class_side_visibility_sets_keep_only_the_last_writer() {
        // The class-side pair takes the identical last-writer-exclusive rule as
        // the instance pair, because the workspace consumer reads any `exports`
        // entry as decisive. Oracle: `oo::class create ::H1 { self { method
        // lower {} {…} ; unexport lower ; export lower } }` leaves
        // `info object methods ::H1` -> lower on 9.0.4 and 8.6.14 alike.
        for (body, exported) in [
            ("unexport m\nexport m", true),
            ("export m\nunexport m", false),
        ] {
            let src = format!(
                "oo::class create ::C {{ self {{ method m {{}} {{ return 1 }}\n{body} }} }}"
            );
            let mut a = Analyser::new();
            let r = a.analyse(&src, "tcl9.0");
            let c = r.all_classes.get("::C").expect("::C recorded");
            let (winner, loser) = if exported {
                (&c.class_exports, &c.class_unexports)
            } else {
                (&c.class_unexports, &c.class_exports)
            };
            assert!(winner.contains("m"), "{body}");
            assert!(
                !loser.contains("m"),
                "{body}: superseded set still holds `m`"
            );
        }
    }

    #[test]
    fn an_unwrapped_visibility_word_never_touches_the_class_side_sets() {
        // TN, the mirror of `a_self_scoped_visibility_word_never_touches_the_
        // instance_sets`. The unwrapped spelling is instance-scoped, so an
        // identically-named class-side member keeps its own state — oracle:
        // `oo::class create E2 { self { method onlyclass {} {…} } }` then
        // `oo::define E2 { unexport onlyclass }` leaves `onlyclass` exported and
        // dispatchable via `::E2 onlyclass` on 9.0.4 and 8.6.14.
        let mut a = Analyser::new();
        let r = a.analyse(
            "oo::class create ::C { self { method m {} { return c } } }\n\
             oo::define ::C { unexport m }",
            "tcl9.0",
        );
        let c = r.all_classes.get("::C").expect("::C recorded");
        assert_eq!(c.class_exports.len(), 0, "{:?}", c.class_exports);
        assert_eq!(c.class_unexports.len(), 0, "{:?}", c.class_unexports);
        assert_eq!(c.class_methods["m"].visibility, "public");
        // The unwrapped word still records its own (instance-side) intent.
        assert!(c.unexports.contains("m"));
    }

    #[test]
    fn filters_are_sided_by_the_wrapper_they_are_written_under() {
        // TP + TN — `filters` is sided like every other member table. The two
        // slots are genuinely independent in `TclOO` and
        // intercept different dispatches. Oracle, byte-identical on tclsh 9.0.4
        // and 8.6.14:
        //   oo::class create ::A { method real {} {…} ; method logit {args} {…}
        //                          filter logit }
        //   info class filters ::A   ;# -> logit      info object filters ::A -> {}
        //   [::A new] real           ;# logit fires, `self target` -> `::A real`
        //   oo::class create ::B { method inst {} {…}
        //       self { method cls {} {…} ; method logit {args} {…} ; filter logit } }
        //   info object filters ::B  ;# -> logit      info class filters ::B  -> {}
        //   ::B cls                  ;# logit fires, `self target` -> `::B cls`
        //   ::B new                  ;# logit fires too — the constructor path
        //   [::B new] inst           ;# logit does NOT fire
        let mut a = Analyser::new();
        let r = a.analyse(
            "oo::class create ::A { method real {} { return r }\n\
             method logit {args} { next }\n\
             filter logit }\n\
             oo::class create ::B { method inst {} { return i }\n\
             self { method cls {} { return c }\n\
             method logit {args} { next }\n\
             filter logit } }",
            "tcl9.0",
        );
        let a_cls = r.all_classes.get("::A").expect("::A recorded");
        assert_eq!(a_cls.filters, vec!["logit"]);
        assert_eq!(a_cls.class_filters.len(), 0, "{:?}", a_cls.class_filters);
        let b_cls = r.all_classes.get("::B").expect("::B recorded");
        assert_eq!(b_cls.class_filters, vec!["logit"]);
        assert_eq!(b_cls.filters.len(), 0, "{:?}", b_cls.filters);
    }

    #[test]
    fn a_private_scoped_filter_is_instance_side() {
        // TN for the third spelling: `private` is a *visibility* wrapper over
        // the instance side, not a third side, so its `filter` lands in the
        // instance slot. Oracle (9.0 only — `private` does not exist on 8.6,
        // where the same body fails with `invalid command name "private"`):
        //   oo::class create ::P { private { method s {} {} ; filter s } }
        //   info class filters ::P   ;# -> s
        //   info object filters ::P  ;# -> (empty)
        let mut a = Analyser::new();
        let r = a.analyse(
            "oo::class create ::C { private { method s {} { return s }\n\
             filter s } }",
            "tcl9.0",
        );
        let c = r.all_classes.get("::C").expect("::C recorded");
        assert_eq!(c.filters, vec!["s"]);
        assert_eq!(c.class_filters.len(), 0, "{:?}", c.class_filters);
    }

    #[test]
    fn per_object_visibility_lands_in_object_member_state() {
        // `oo::objdefine $o { unexport m }` really works — oracle, 9.0.4 and
        // 8.6.14 alike:
        //   oo::class create ::C { method m {} {…} } ; set o [::C new]
        //   oo::objdefine $o { unexport m } ; $o m
        //   ;# -> unknown method "m": must be destroy or n
        // The flip lands in the receiver binding's `ObjectMemberState`
        // — the durable per-object home — while the class itself stays
        // untouched, and the throwaway holder never reaches `all_classes`.
        let mut a = Analyser::new();
        let r = a.analyse(
            "oo::class create ::C { method m {} { return m } }\n\
             set o [::C new]\n\
             oo::objdefine $o { unexport m }",
            "tcl9.0",
        );
        let c = r.all_classes.get("::C").expect("::C recorded");
        assert_eq!(c.methods["m"].visibility, "public");
        assert_eq!(c.unexports.len(), 0, "{:?}", c.unexports);
        assert!(!r.all_classes.contains_key("::@objdefine@::o"));
        let states = r
            .object_member_state
            .get("o")
            .expect("the receiver binding has member state");
        assert_eq!(states.len(), 1, "{states:?}");
        assert!(states[0].unexports.contains("m"), "{states:?}");
        assert_eq!(states[0].exports.len(), 0, "{states:?}");
    }

    #[test]
    fn per_object_export_and_unexport_are_last_writer_exclusive() {
        // The per-object pair keeps the same last-writer-exclusive contract
        // as the class-side pairs: a later `export m` cancels the earlier
        // flip, across blocks of the same binding.
        let mut a = Analyser::new();
        let r = a.analyse(
            "oo::class create ::C { method m {} { return m } }\n\
             set o [::C new]\n\
             oo::objdefine $o { unexport m }\n\
             oo::objdefine $o { export m }",
            "tcl9.0",
        );
        let states = r.object_member_state.get("o").expect("state recorded");
        assert_eq!(states.len(), 1, "one binding: {states:?}");
        assert!(states[0].exports.contains("m"), "{states:?}");
        assert!(!states[0].unexports.contains("m"), "{states:?}");
    }

    #[test]
    fn per_object_cross_block_retraction_folds_and_stays_silent() {
        // The cross-block hazard that kept W315 out of `oo::objdefine`:
        // a second block retracting what the first declared
        // is legal (tclsh 9.0.4 / 8.6.14 both accept it), so the seeded walk
        // must remove the member silently — no W315 — and the folded state
        // must drop it.
        let mut a = Analyser::new();
        let r = a.analyse(
            "oo::class create ::C {}\n\
             set o [::C new]\n\
             oo::objdefine $o { method im {} { return i } }\n\
             oo::objdefine $o { deletemethod im }",
            "tcl9.0",
        );
        assert_eq!(w315_messages(&r).len(), 0, "{:?}", r.diagnostics);
        let states = r.object_member_state.get("o").expect("state recorded");
        assert_eq!(states.len(), 1, "{states:?}");
        assert_eq!(
            states[0].methods.len(),
            0,
            "the retraction must fold: {states:?}"
        );
    }

    #[test]
    fn a_retraction_of_a_locally_declared_member_leaves_no_tombstone() {
        // TN for the cross-document channel. Within one document the member is
        // removed outright and the order is known, so exporting a tombstone
        // would wrongly cancel a *different* document's redeclaration of the
        // name — no ordering evidence supports that.
        let mut a = Analyser::new();
        let r = a.analyse(
            "oo::class create ::C { method gone {} { return g } }\n\
             oo::define ::C { deletemethod gone }",
            "tcl9.0",
        );
        let c = r.all_classes.get("::C").expect("::C recorded");
        assert!(!c.methods.contains_key("gone"));
        assert_eq!(c.retracted_members.len(), 0, "{:?}", c.retracted_members);
    }

    // W315, "this class definition cannot run".

    #[test]
    fn w315_fires_for_every_definition_aborting_retraction() {
        // naming.diagnostics.original-definition-abort-admission
        // docs/design/analysis/name-resolution-proofs/diagnostic-original-definition-abort-admission.md
        // Explicit Logical source-table compatibility; no Native worker/table claim.
        for (body, want) in [
            (
                "deletemethod ghost\nmethod ghost {} { return g }",
                "this class definition cannot run: method \"ghost\" does not exist",
            ),
            (
                "self { method cm {} { return c } }\ndeletemethod cm",
                "this class definition cannot run: method \"cm\" does not exist",
            ),
            (
                "method a {} { return a }\nmethod b {} { return b }\nrenamemethod a b",
                "this class definition cannot run: method called \"b\" already exists",
            ),
            (
                "method a {} { return a }\nrenamemethod a a",
                "this class definition cannot run: cannot rename method to itself",
            ),
            (
                "method b {} { return b }\nrenamemethod ghost b",
                "this class definition cannot run: method \"ghost\" does not exist",
            ),
        ] {
            let mut a = logical_object_abort_analyser();
            let r = a.analyse(
                &format!("oo::class create ::C {{ {body} }}"),
                "explicit-object-abort-advice",
            );
            assert_eq!(w315_messages(&r), vec![want.to_string()], "body: {body}");
            assert!(r.all_classes.contains_key("::C"), "body: {body}");
        }
    }

    #[test]
    fn w315_fires_on_the_class_side_too() {
        // naming.diagnostics.original-definition-abort-admission
        // docs/design/analysis/name-resolution-proofs/diagnostic-original-definition-abort-admission.md
        // Explicit Logical source-table compatibility; no Native worker/table claim.
        for body in [
            "method im {} { return i }\nself { deletemethod im }",
            "method im {} { return i }\nself { renamemethod im other }",
        ] {
            let mut a = logical_object_abort_analyser();
            let r = a.analyse(
                &format!("oo::class create ::C {{ {body} }}"),
                "explicit-object-abort-advice",
            );
            assert_eq!(
                w315_messages(&r),
                vec!["this class definition cannot run: method \"im\" does not exist".to_string()],
                "body: {body}",
            );
            assert!(r.all_classes["::C"].methods.contains_key("im"), "{body}");
        }
    }

    fn logical_object_abort_analyser() -> Analyser {
        let profile = tcl_dialect::DialectProfile::projected_from_point(
            "explicit-object-abort-advice",
            &[],
            "Logical object definition advice",
            tcl_dialect::model::DialectPoint::canonical(tcl_dialect::model::Release::JIM_0_79),
        )
        .intern();
        let input = super::super::ResolvedAnalysisInput::new(
            profile,
            profile,
            tcl_registry::model::ingress::resolve_environment("tcl9.0").default_context_registry(),
            tcl_lexer::LexerConfig::for_profile(Some(profile)),
        );
        assert!(input.has_logical_source_name_context());
        Analyser::new().with_resolved_input(input)
    }

    fn injected_class_abort_candidates() -> ClassDef {
        ClassDef {
            definition_aborts: [
                DefinitionAbortKind::MissingMember,
                DefinitionAbortKind::DestinationExists,
                DefinitionAbortKind::RenameToItself,
            ]
            .into_iter()
            .map(|kind| DefinitionAbort {
                kind,
                member: "missing".to_owned(),
                span: Span::new(0, 1),
            })
            .collect(),
            retracted_members: vec![MemberRetractionRecord::deletion(
                "missing".to_owned(),
                MemberSide::Instance,
            )],
            ..Default::default()
        }
    }

    #[test]
    fn original_class_abort_refuses_native_and_hosted_reporting_tables() {
        // naming.diagnostics.original-definition-abort-admission
        // docs/design/analysis/name-resolution-proofs/diagnostic-original-definition-abort-admission.md
        // Positive injected candidates check admission, not runtime retractions.
        let source = "oo::class create C {deletemethod ghost; method ghost {} {}}";
        for dialect in [
            "tcl8.4",
            "tcl8.5",
            "tcl8.6",
            "tcl9.0",
            "tcl9.1",
            "jimtcl",
            "f5-irules",
            "f5-tmsh",
            "f5-iapps",
        ] {
            let mut analyser = Analyser::new();
            analyser.result = analyser.analyse(source, dialect);
            assert!(!has_w315(&analyser.result), "{dialect}");
            analyser.result.lexical_declaration_advice = true;
            analyser.result.dialect = "explicit-object-abort-advice".to_owned();
            analyser.result.original_vendor_source_names.clear();
            analyser.result.all_classes.clear();
            let mut class = injected_class_abort_candidates();
            assert_eq!(class.definition_aborts.len(), 3);
            assert!(!class.via_define);
            analyser.emit_w315_definition_cannot_run(&mut class);
            assert!(
                !has_w315(&analyser.result),
                "{dialect}: reports grant no Native closure"
            );
            assert!(class.definition_aborts.is_empty());
            assert_eq!(class.retracted_members.len(), 1);
        }
    }

    #[test]
    fn original_class_abort_refuses_missing_retained_input() {
        // naming.diagnostics.original-definition-abort-admission
        // docs/design/analysis/name-resolution-proofs/diagnostic-original-definition-abort-admission.md
        let mut analyser = Analyser::new();
        analyser.result.lexical_declaration_advice = true;
        analyser.result.dialect = "explicit-object-abort-advice".to_owned();
        assert!(analyser.result.resolved_input.is_none());
        let mut class = injected_class_abort_candidates();
        analyser.emit_w315_definition_cannot_run(&mut class);
        assert!(!has_w315(&analyser.result));
        assert!(class.definition_aborts.is_empty());
        assert_eq!(class.retracted_members.len(), 1);
    }

    #[test]
    fn original_class_abort_keeps_retained_logical_advice_despite_report_mutations() {
        // naming.diagnostics.original-definition-abort-admission
        // docs/design/analysis/name-resolution-proofs/diagnostic-original-definition-abort-admission.md
        let mut analyser = logical_object_abort_analyser();
        analyser.result = analyser.analyse("", "explicit-object-abort-advice");
        assert!(analyser.result.allows_retained_logical_declaration_advice());
        analyser.result.dialect = "tcl9.0".to_owned();
        analyser.result.all_classes.clear();
        analyser.result.command_invocations.clear();
        analyser.result.all_procs.clear();
        let mut class = injected_class_abort_candidates();
        analyser.emit_w315_definition_cannot_run(&mut class);
        assert_eq!(w315_messages(&analyser.result).len(), 3);
        assert!(class.definition_aborts.is_empty());
        assert!(class.retracted_members.is_empty());
        analyser.result.lexical_declaration_advice = false;
        let mut withdrawn = injected_class_abort_candidates();
        analyser.emit_w315_definition_cannot_run(&mut withdrawn);
        assert_eq!(w315_messages(&analyser.result).len(), 3);
        assert!(withdrawn.definition_aborts.is_empty());
        assert_eq!(withdrawn.retracted_members.len(), 1);
    }

    fn inject_object_abort_candidates(analyser: &mut Analyser) {
        analyser
            .result
            .instance_classes
            .insert("owned".to_owned(), "::C".to_owned());
        analyser
            .result
            .created_instance_commands
            .insert("owned".to_owned());
        analyser.result.object_methods.clear();
        analyser.objdefine_unresolved_receiver = false;
        for kind in [
            DefinitionAbortKind::MissingMember,
            DefinitionAbortKind::DestinationExists,
            DefinitionAbortKind::RenameToItself,
        ] {
            analyser.objdefine_abort_candidates.push(
                super::super::state::ObjdefineAbortCandidate {
                    abort: DefinitionAbort {
                        kind,
                        member: "missing".to_owned(),
                        span: Span::new(0, 1),
                    },
                    receiver: "owned".to_owned(),
                    prior_state_conditional: false,
                },
            );
        }
    }

    #[test]
    fn original_object_abort_refuses_native_and_hosted_reporting_tables() {
        // naming.diagnostics.original-object-abort-admission
        // docs/design/analysis/name-resolution-proofs/diagnostic-original-object-abort-admission.md
        // Injected report candidates test admission, without asserting execution.
        let source = "oo::class create C {}\nset o [C new]\noo::objdefine $o {method a {} {}; renamemethod a a}";
        for dialect in [
            "tcl8.4",
            "tcl8.5",
            "tcl8.6",
            "tcl9.0",
            "tcl9.1",
            "jimtcl",
            "f5-irules",
            "f5-tmsh",
            "f5-iapps",
        ] {
            let mut analyser = Analyser::new();
            analyser.result = analyser.analyse(source, dialect);
            assert!(!has_w315(&analyser.result), "{dialect}");
            analyser.result.lexical_declaration_advice = true;
            analyser.result.dialect = "explicit-object-abort-advice".to_owned();
            inject_object_abort_candidates(&mut analyser);
            assert_eq!(analyser.objdefine_abort_candidates.len(), 3);
            analyser.flush_objdefine_abort_diagnostics();
            assert!(
                !has_w315(&analyser.result),
                "{dialect}: report maps grant no Native table"
            );
            assert!(analyser.objdefine_abort_candidates.is_empty());
        }
    }

    #[test]
    fn original_object_abort_refuses_missing_retained_input() {
        // naming.diagnostics.original-object-abort-admission
        // docs/design/analysis/name-resolution-proofs/diagnostic-original-object-abort-admission.md
        let mut analyser = Analyser::new();
        analyser.result.lexical_declaration_advice = true;
        assert!(analyser.result.resolved_input.is_none());
        inject_object_abort_candidates(&mut analyser);
        analyser.flush_objdefine_abort_diagnostics();
        assert!(!has_w315(&analyser.result));
        assert!(analyser.objdefine_abort_candidates.is_empty());
    }

    #[test]
    fn original_object_abort_keeps_explicit_logical_advice_despite_report_label() {
        // naming.diagnostics.original-object-abort-admission
        // docs/design/analysis/name-resolution-proofs/diagnostic-original-object-abort-admission.md
        let mut analyser = logical_object_abort_analyser();
        analyser.result = analyser.analyse("", "explicit-object-abort-advice");
        assert!(analyser.result.allows_lexical_declaration_advice());
        assert!(
            analyser
                .result
                .resolved_input
                .as_ref()
                .unwrap()
                .has_logical_source_name_context()
        );
        analyser.result.dialect = "tcl9.0".to_owned();
        inject_object_abort_candidates(&mut analyser);
        analyser.flush_objdefine_abort_diagnostics();
        assert_eq!(w315_messages(&analyser.result).len(), 3);
    }

    // Per-object abort reports use explicitly selected Logical source advice.
    // The String table supplies no Native own-method presence or completeness.

    #[test]
    fn w315_fires_for_a_per_object_retraction_of_a_never_declared_member() {
        // Explicit Logical compatibility uses the authored object's own table,
        // independently of inherited class metadata. No Native absence is proved.
        let mut a = logical_object_abort_analyser();
        let r = a.analyse(
            "oo::class create ::C { method ghost {} { return g } }\n\
             set o [::C new]\n\
             oo::objdefine $o { deletemethod ghost }",
            "explicit-object-abort-advice",
        );
        assert_eq!(
            w315_messages(&r),
            vec!["this object definition cannot run: method \"ghost\" does not exist".to_string()],
        );
    }

    #[test]
    fn w315_fires_for_a_per_object_rename_onto_an_existing_member() {
        // Explicit Logical source order retains a destination declared by an
        // earlier block of the same authored binding. It grants no Native table.
        let mut a = logical_object_abort_analyser();
        let r = a.analyse(
            "oo::class create ::C {}\n\
             set o [::C new]\n\
             oo::objdefine $o { method a {} { return a }\n method b {} { return b } }\n\
             oo::objdefine $o { renamemethod a b }",
            "explicit-object-abort-advice",
        );
        assert_eq!(
            w315_messages(&r),
            vec![
                "this object definition cannot run: method called \"b\" already exists".to_string()
            ],
        );
    }

    #[test]
    fn w315_fires_for_a_per_object_rename_to_itself() {
        // The Logical model selects the same source and destination name;
        // the compatibility assertion does not grant a Native worker receipt.
        let mut a = logical_object_abort_analyser();
        let r = a.analyse(
            "oo::objdefine $o { method x {} { return x }\n renamemethod x x }",
            "explicit-object-abort-advice",
        );
        assert_eq!(
            w315_messages(&r),
            vec!["this object definition cannot run: cannot rename method to itself".to_string()],
        );
    }

    #[test]
    fn per_object_w315_abstains_without_the_receivers_construction_in_view() {
        // Logical metadata for an extension lacks a closed authored receiver
        // table; a declaration in another file remains possible.
        let mut a = logical_object_abort_analyser();
        let r = a.analyse(
            "oo::objdefine $o { deletemethod ghost }",
            "explicit-object-abort-advice",
        );
        assert!(!has_w315(&r), "{:?}", w315_messages(&r));
    }

    #[test]
    fn per_object_w315_abstains_when_any_key_declares_the_member() {
        // An authored alias can refer to a member declared under another key.
        // Logical metadata with that possibility cannot assert its absence.
        let mut a = logical_object_abort_analyser();
        let r = a.analyse(
            "oo::class create ::C {}\n\
             set p [::C new]\n\
             oo::objdefine $p { method ghost {} { return g } }\n\
             set o [::C new]\n\
             set o $p\n\
             oo::objdefine $o { deletemethod ghost }",
            "explicit-object-abort-advice",
        );
        assert!(!has_w315(&r), "{:?}", w315_messages(&r));
    }

    #[test]
    fn per_object_w315_abstains_when_any_receiver_is_unresolved() {
        // An unknown authored receiver can affect any object's source table.
        let mut a = logical_object_abort_analyser();
        let r = a.analyse(
            "oo::class create ::C {}\n\
             set o [::C new]\n\
             oo::objdefine [pick] { method ghost {} { return g } }\n\
             oo::objdefine $o { deletemethod ghost }",
            "explicit-object-abort-advice",
        );
        assert!(!has_w315(&r), "{:?}", w315_messages(&r));
    }

    #[test]
    fn w315_stays_silent_for_every_legal_order() {
        // naming.diagnostics.original-definition-abort-admission
        // docs/design/analysis/name-resolution-proofs/diagnostic-original-definition-abort-admission.md
        // Explicit Logical source-table compatibility; no Native worker/table claim.
        for body in [
            "method a {} {}\nmethod b {} {}\ndeletemethod a",
            "self { method a {} {}\nmethod b {} {}\ndeletemethod a }",
            "method a {} {}\nrenamemethod a fresh",
            "method a {} {}\nself { method b {} {} }\nrenamemethod a b",
            "method a {} {}\ndeletemethod a\nmethod a {} {}",
            "method a {} {}\nmethod b {} {}\ndeletemethod b\nrenamemethod a b",
            "method a {} {}\nrenamemethod a b\nrenamemethod b c",
        ] {
            let mut a = logical_object_abort_analyser();
            let r = a.analyse(
                &format!("oo::class create ::C {{ {body} }}"),
                "explicit-object-abort-advice",
            );
            assert!(!has_w315(&r), "body: {body} -> {:?}", w315_messages(&r));
        }
    }

    #[test]
    fn a_cross_side_visibility_word_is_not_a_w315() {
        // naming.diagnostics.original-definition-abort-admission
        // docs/design/analysis/name-resolution-proofs/diagnostic-original-definition-abort-admission.md
        // Explicit Logical source-table compatibility; no Native worker/table claim.
        for body in [
            "method onlyinst {} {}\nself unexport onlyinst",
            "self { method onlyclass {} {} }\nunexport onlyclass",
            "export ghost",
            "self export ghost",
            "filter ghost",
            "self filter ghost",
        ] {
            let mut a = logical_object_abort_analyser();
            let r = a.analyse(
                &format!("oo::class create ::C {{ {body} }}"),
                "explicit-object-abort-advice",
            );
            assert!(!has_w315(&r), "body: {body} -> {:?}", w315_messages(&r));
        }
    }

    #[test]
    fn w315_abstains_on_a_dynamic_source_name() {
        // naming.diagnostics.original-definition-abort-admission
        // docs/design/analysis/name-resolution-proofs/diagnostic-original-definition-abort-admission.md
        // Explicit Logical source-table compatibility; no Native worker/table claim.
        for body in [
            "method m {} {}\ndeletemethod $gone",
            "method m {} {}\nrenamemethod $old new",
            "method m {} {}\ndeletemethod [pick]",
        ] {
            let mut a = logical_object_abort_analyser();
            let r = a.analyse(
                &format!("oo::class create ::C {{ {body} }}"),
                "explicit-object-abort-advice",
            );
            assert!(!has_w315(&r), "body: {body} -> {:?}", w315_messages(&r));
            assert!(
                r.all_classes["::C"].methods.contains_key("m"),
                "body: {body}: a dynamic retraction must not remove a member",
            );
            assert_eq!(
                r.all_classes["::C"].retracted_members.len(),
                0,
                "body: {body}: {:?}",
                r.all_classes["::C"].retracted_members,
            );
        }
    }

    #[test]
    fn a_dynamic_rename_destination_still_retracts_the_source() {
        // TN for the *destination* half, which is not symmetric with the source.
        // Whatever `$n` turns out to be, `renamemethod m $n` definitely takes
        // `m` away — `::C m` is an unknown method afterwards on 9.0.4 and
        // 8.6.14 alike — so retracting the source is the faithful answer even
        // though the arrival name is unknowable. Only the arrival abstains, and
        // with no static destination there is nothing to check for a collision.
        let mut a = Analyser::new();
        let r = a.analyse(
            "oo::class create ::C { method m {} { return m }\n\
             method n {} { return n }\n\
             renamemethod m $n }",
            "tcl9.0",
        );
        let c = r.all_classes.get("::C").expect("::C recorded");
        assert!(!c.methods.contains_key("m"), "{:?}", c.methods);
        assert!(
            c.methods.contains_key("n"),
            "the collision guess is not made"
        );
        assert!(!has_w315(&r), "{:?}", w315_messages(&r));
    }

    #[test]
    fn a_cross_file_stub_retraction_is_a_tombstone_not_a_w315() {
        // naming.diagnostics.original-definition-abort-admission
        // docs/design/analysis/name-resolution-proofs/diagnostic-original-definition-abort-admission.md
        // Explicit Logical source-table compatibility; no Native worker/table claim.
        let mut a = logical_object_abort_analyser();
        let r = a.analyse(
            "oo::define ::C { deletemethod m }\n\
             oo::define ::D { self deletemethod cm }\n\
             oo::define ::E { renamemethod old new }",
            "explicit-object-abort-advice",
        );
        assert!(!has_w315(&r), "{:?}", w315_messages(&r));
        assert_eq!(
            r.all_classes["::C"].retracted_members,
            vec![MemberRetractionRecord::deletion(
                "m".to_string(),
                MemberSide::Instance
            )],
        );
        assert!(r.all_classes["::C"].via_define);
    }

    #[test]
    fn a_same_file_define_extending_a_local_class_is_not_a_stub() {
        // naming.diagnostics.original-definition-abort-admission
        // docs/design/analysis/name-resolution-proofs/diagnostic-original-definition-abort-admission.md
        // Explicit Logical source-table compatibility; no Native worker/table claim.
        let mut a = logical_object_abort_analyser();
        let r = a.analyse(
            "oo::class create ::C { method kept {} { return k } }\n\
             oo::define ::C { deletemethod ghost }",
            "explicit-object-abort-advice",
        );
        assert_eq!(
            w315_messages(&r),
            vec!["this class definition cannot run: method \"ghost\" does not exist".to_string()],
        );
        assert!(!r.all_classes["::C"].via_define);
        assert_eq!(
            r.all_classes["::C"].retracted_members.len(),
            0,
            "{:?}",
            r.all_classes["::C"].retracted_members,
        );
    }

    #[test]
    fn a_move_records_the_member_state_it_ran_against() {
        // The moved member's declaration site is the
        // `renamemethod`'s destination word, so a *rename* of it rewrites that
        // word — and the gate that decides whether the result still runs needs
        // the table as it stood at the move. Captured with the source already
        // removed and the destination not yet inserted, which is exactly what
        // the interpreter reads at that point.
        let src = "oo::class create ::C { method old {} { return 1 }\n\
                   method sib {} { return 2 }\n\
                   renamemethod old new }";
        let mut a = Analyser::new();
        let r = a.analyse(src, "tcl9.0");
        let c = r.all_classes.get("::C").expect("::C recorded");
        assert_eq!(c.renamed_members.len(), 1, "{:?}", c.renamed_members);
        let moved = &c.renamed_members[0];
        assert_eq!(moved.source, "old");
        assert_eq!(moved.destination, "new");
        assert_eq!(moved.side, MemberSide::Instance);
        assert_eq!(
            &src[moved.destination_span.start() as usize..moved.destination_span.end() as usize],
            "new",
        );
        // `sib` is live at the move; `old` is not (it was just retracted) and
        // `new` is not (it has not arrived yet).
        assert_eq!(moved.blocked, vec!["sib".to_string()]);
    }

    #[test]
    fn the_move_record_answers_which_new_names_would_abort() {
        // The shared fold both consumers use: the walker asks it about the
        // destination actually written (that is how W315 is decided) and the
        // rename gate asks it about the name the user typed. Oracle, identical
        // on tclsh 9.0.4 and 8.6.14 — no class is created in either case:
        //   { method old {} {…} ; renamemethod old old }
        //        -> cannot rename method to itself
        //   { method old {} {…} ; method sib {} {…} ; renamemethod old sib }
        //        -> method called sib already exists
        let mut a = Analyser::new();
        let r = a.analyse(
            "oo::class create ::C { method old {} { return 1 }\n\
             method sib {} { return 2 }\n\
             renamemethod old new }",
            "tcl9.0",
        );
        let moved = &r.all_classes["::C"].renamed_members[0];
        assert_eq!(
            moved.abort_if_renamed_to("old"),
            Some(DefinitionAbortKind::RenameToItself),
        );
        assert_eq!(
            moved.abort_if_renamed_to("sib"),
            Some(DefinitionAbortKind::DestinationExists),
        );
        // TN: a fresh name is fine, and so is the destination it already has.
        assert_eq!(moved.abort_if_renamed_to("fresh"), None);
        // The mirror direction, from the same record.
        assert!(moved.collides_with_renaming("sib", "new"));
        assert!(!moved.collides_with_renaming("sib", "other"));
    }

    #[test]
    fn a_cross_side_name_is_not_in_the_move_snapshot() {
        // TN (CRITICAL). Collisions are side-local: `method old {} {…}` +
        // `self { method sib {} {…} }` + `renamemethod old sib` runs fine and
        // leaves `info class methods ::C1` -> sib (9.0.4 / 8.6.14). So a
        // class-side `sib` must not appear in an instance-side move's snapshot.
        let mut a = Analyser::new();
        let r = a.analyse(
            "oo::class create ::C { method old {} { return 1 }\n\
             self { method sib {} { return 2 } }\n\
             renamemethod old new }",
            "tcl9.0",
        );
        let moved = &r.all_classes["::C"].renamed_members[0];
        assert_eq!(moved.blocked.len(), 0, "{:?}", moved.blocked);
        assert_eq!(moved.abort_if_renamed_to("sib"), None);
    }

    #[test]
    fn the_move_snapshot_honours_body_order_in_both_directions() {
        // TN ×2, both oracle-pinned legal on 9.0.4 and 8.6.14:
        //   { method old {} {} ; method sib {} {} ; deletemethod sib
        //     renamemethod old sib }                 -> info class methods -> sib
        //   { method old {} {} ; renamemethod old sib ; method sib {} {} }
        //                                            -> info class methods -> sib
        // so a name deleted *before* the move is free, and one declared
        // *after* it never collides with it.
        let mut a = Analyser::new();
        let r = a.analyse(
            "oo::class create ::C { method old {} { return 1 }\n\
             method sib {} { return 2 }\n\
             deletemethod sib\n\
             renamemethod old new }",
            "tcl9.0",
        );
        assert_eq!(
            r.all_classes["::C"].renamed_members[0].abort_if_renamed_to("sib"),
            None,
            "a name deleted before the move is free",
        );
        let mut a = Analyser::new();
        let r = a.analyse(
            "oo::class create ::D { method old {} { return 1 }\n\
             renamemethod old new\n\
             method sib {} { return 2 } }",
            "tcl9.0",
        );
        assert_eq!(
            r.all_classes["::D"].renamed_members[0].abort_if_renamed_to("sib"),
            None,
            "a name declared after the move never collides with it",
        );
    }

    #[test]
    fn a_rejected_rename_records_no_move() {
        // naming.diagnostics.original-definition-abort-admission
        // docs/design/analysis/name-resolution-proofs/diagnostic-original-definition-abort-admission.md
        // Explicit Logical source-table compatibility; no Native worker/table claim.
        for body in [
            "method a {} {}\nrenamemethod a a",
            "method a {} {}\nmethod b {} {}\nrenamemethod a b",
        ] {
            let mut a = logical_object_abort_analyser();
            let r = a.analyse(
                &format!("oo::class create ::C {{ {body} }}"),
                "explicit-object-abort-advice",
            );
            assert_eq!(
                r.all_classes["::C"].renamed_members.len(),
                0,
                "body: {body}: {:?}",
                r.all_classes["::C"].renamed_members,
            );
            assert!(has_w315(&r), "body: {body}");
        }
    }

    #[test]
    fn a_blocked_rename_keeps_both_members_navigable() {
        // Navigation-resilience pin for the aborting shapes. Real Tcl creates no
        // class at all, so there is no "right" answer to mirror — the useful one
        // keeps every declaration the author wrote reachable rather than letting
        // the wreckage take one with it.
        let src = "oo::class create ::C { method a {} { return a }\n\
                   method b {} { return b }\n\
                   renamemethod a b }";
        let mut a = Analyser::new();
        let r = a.analyse(src, "tcl9.0");
        let c = r.all_classes.get("::C").expect("::C recorded");
        assert!(c.methods.contains_key("a"), "source kept: {:?}", c.methods);
        let b = c.methods.get("b").expect("destination kept");
        assert!(
            src[b.body_span.start() as usize..b.body_span.end() as usize].contains("return b"),
            "the destination keeps its OWN body",
        );
    }

    #[test]
    fn w315_is_reported_once_per_offending_word() {
        // naming.diagnostics.original-definition-abort-admission
        // docs/design/analysis/name-resolution-proofs/diagnostic-original-definition-abort-admission.md
        // Explicit Logical source-table compatibility; no Native worker/table claim.
        let mut a = logical_object_abort_analyser();
        let r = a.analyse(
            "oo::class create ::C { method kept {} { return k } }\n\
             oo::define ::C { deletemethod ghost }\n\
             oo::define ::C { method extra {} { return e } }\n\
             oo::define ::C { deletemethod other }",
            "explicit-object-abort-advice",
        );
        assert_eq!(
            w315_messages(&r),
            vec![
                "this class definition cannot run: method \"ghost\" does not exist".to_string(),
                "this class definition cannot run: method \"other\" does not exist".to_string(),
            ],
        );
    }

    #[test]
    fn w315_points_at_the_offending_word() {
        // naming.diagnostics.original-definition-abort-admission
        // docs/design/analysis/name-resolution-proofs/diagnostic-original-definition-abort-admission.md
        // Explicit Logical source-table compatibility; no Native worker/table claim.
        let src = "oo::class create ::C { deletemethod ghost }";
        let mut a = logical_object_abort_analyser();
        let r = a.analyse(src, "explicit-object-abort-advice");
        let d = r
            .diagnostics
            .iter()
            .find(|d| d.code == tcl_core_types::DiagCode::W315)
            .expect("W315");
        assert_eq!(
            &src[d.span.start() as usize..d.span.end() as usize],
            "ghost"
        );
    }

    #[test]
    fn a_stub_retraction_of_an_undeclared_member_leaves_a_tombstone() {
        // naming.source.original-class-reference
        // docs/design/analysis/name-resolution-proofs/source-original-class-reference.md
        // Explicit Logical cross-document advisory channel; no Native class or retraction.
        // TP for the cross-document channel. This document
        // is the `oo::define ::C { deletemethod m }` half of a two-file program:
        // it has no local `m` to remove, so the removal has to travel as a
        // tombstone or the workspace keeps advertising a method that sourcing
        // this file deletes. The side travels with it — a `self`-scoped
        // retraction tombstones the class-object side.
        let mut a = logical_object_abort_analyser();
        let r = a.analyse(
            "oo::define ::C { deletemethod m }\n\
             oo::define ::D { self deletemethod cm }",
            "explicit-object-abort-advice",
        );
        assert_eq!(
            r.all_classes["::C"].retracted_members,
            vec![MemberRetractionRecord::deletion(
                "m".to_string(),
                MemberSide::Instance
            )],
        );
        assert_eq!(
            r.all_classes["::D"].retracted_members,
            vec![MemberRetractionRecord::deletion(
                "cm".to_string(),
                MemberSide::ClassObject
            )],
        );
    }

    #[test]
    fn a_stub_renamemethod_tombstones_only_the_source_name() {
        // naming.source.original-class-reference
        // docs/design/analysis/name-resolution-proofs/source-original-class-reference.md
        // Explicit Logical cross-document advisory channel; no Native move.
        // TN for the tombstone's shape: `renamemethod old new` removes `old` and
        // *creates* `new` (oracle: `info class methods ::I3` -> new, and
        // `[::I3 new] new` answers), so tombstoning `new` would suppress a live
        // member another document legitimately declares. Which arguments a
        // retracting word removes is registry data
        // ([`tcl_registry::definer::MemberRetraction::FirstArgument`]), not a
        // keyword match here.
        let mut a = logical_object_abort_analyser();
        let r = a.analyse(
            "oo::define ::C { renamemethod old new }",
            "explicit-object-abort-advice",
        );
        assert_eq!(
            r.all_classes["::C"]
                .retracted_members
                .iter()
                .map(|r| (r.member.clone(), r.side))
                .collect::<Vec<_>>(),
            vec![("old".to_string(), MemberSide::Instance)],
        );
        // …and the arrival travels with it: the stub has no
        // `MethodDef` to move, so the destination name is what lets the
        // workspace join re-key the defining file's record.
        assert_eq!(
            r.all_classes["::C"].retracted_members[0].arrival.as_deref(),
            Some("new"),
        );
    }

    #[test]
    fn missing_class_source_cannot_publish_native_definition_stubs() {
        // naming.source.original-class-reference
        // docs/design/analysis/name-resolution-proofs/source-original-class-reference.md
        let source = "oo::define ::C {deletemethod m}; oo::define ::D {renamemethod old new}";
        for profile in ["tcl8.6", "tcl9.0", "tcl9.1", "f5-irules"] {
            let result = Analyser::new().analyse(source, profile);
            assert!(!result.all_classes.contains_key("::C"), "{profile}");
            assert!(!result.all_classes.contains_key("::D"), "{profile}");
        }
        let mut missing = logical_object_abort_analyser();
        let mut baseline = logical_object_abort_analyser();
        missing.result = baseline.analyse(source, "explicit-object-abort-advice");
        assert!(missing.result.all_classes.contains_key("::C"));
        missing.result.resolved_input = None;
        missing.result.all_classes.clear();
        missing.source = source.to_owned();
        let command = crate::segmenter::segment_commands_with_offset_and_config(
            source,
            0,
            missing.lexer_config(),
        )
        .remove(0);
        assert!(missing.handle_oo_define_command(
            command.name(),
            command.args(),
            command.arg_tokens(),
            command.arg_single_token(),
            &[],
        ));
        assert!(missing.result.all_classes.is_empty());
    }

    #[test]
    fn visibility_sets_keep_only_the_last_writer() {
        // `exports` / `unexports` each record the
        // *last* explicit writer for a name, and the cross-file consumer
        // (`workspace_index::method_dispatch_chain`) reads any `exports` entry
        // as decisive — so a name must never sit in both. Oracle, identical on
        // tclsh 9.0.4 and 8.6.14:
        //   oo::class create L1 { method m {} {…}; export m; unexport m }
        //   info class methods ::L1  ->            ;  [L1 new] m -> unknown method
        //   oo::class create L2 { method m {} {…}; unexport m; export m }
        //   info class methods ::L2  -> m          ;  [L2 new] m -> 1
        // Both unwrapped and `private`-scoped writers must leave each name
        // in exactly the set selected by its last explicit visibility operation.
        for (body, last, want_vis) in [
            ("export m\nunexport m", "unexports", "unexported"),
            ("unexport m\nexport m", "exports", "public"),
            (
                "private export m\nprivate unexport m",
                "unexports",
                "unexported",
            ),
            ("private unexport m\nprivate export m", "exports", "public"),
            (
                "private { export m }\nprivate { unexport m }",
                "unexports",
                "unexported",
            ),
        ] {
            let src = format!("oo::class create ::C {{ method m {{}} {{ return 1 }}\n{body} }}");
            let mut a = Analyser::new();
            let r = a.analyse(&src, "tcl9.0");
            let c = r.all_classes.get("::C").expect("::C recorded");
            let (winner, loser) = if last == "exports" {
                (&c.exports, &c.unexports)
            } else {
                (&c.unexports, &c.exports)
            };
            assert!(winner.contains("m"), "{body}: {last} must hold `m`");
            assert!(
                !loser.contains("m"),
                "{body}: the superseded set still holds `m` — cross-file dispatch \
                 reads any `exports` entry as decisive",
            );
            assert_eq!(c.methods["m"].visibility, want_vis, "{body}");
        }
    }

    #[test]
    fn a_self_scoped_visibility_word_never_touches_the_instance_sets() {
        // TN for the same sets: they are the *instance*-side record, so a
        // class-object-side flip must stay out of them entirely (in either
        // direction) — otherwise it would re-state an unrelated instance
        // method's export bit cross-file.
        let src = "oo::class create ::C {\n\
                   method m {} { return 1 }\n\
                   self { method m {} { return 2 }\n\
                   unexport m\n\
                   export m\n\
                   }\n\
                   }";
        let mut a = Analyser::new();
        let r = a.analyse(src, "tcl9.0");
        let c = r.all_classes.get("::C").expect("::C recorded");
        assert_eq!(c.exports.len(), 0, "{:?}", c.exports);
        assert_eq!(c.unexports.len(), 0, "{:?}", c.unexports);
        assert_eq!(c.methods["m"].visibility, "public");
        assert_eq!(c.class_methods["m"].visibility, "public");
    }

    #[test]
    fn unwrapped_deletemethod_does_not_touch_the_class_side() {
        // TN. The unwrapped word is instance-scoped; a class-object-side member
        // of the same name survives it. (Real Tcl goes further and makes the
        // cross-side form a hard definition-aborting error — `oo::define ::I5
        // { deletemethod cm }` over a `self`-only `cm` raises `method cm does
        // not exist` and leaves `info object methods ::I5` -> cm — so a
        // document that reaches this shape never ran; keeping the class-side
        // entry is the abstaining answer either way.)
        let src = "oo::class create ::C {\n\
                   self { method cm {} { return c } }\n\
                   }\n\
                   oo::define ::C { deletemethod cm }";
        let mut a = Analyser::new();
        let r = a.analyse(src, "tcl9.0");
        let c = r.all_classes.get("::C").expect("::C recorded");
        assert!(c.class_methods.contains_key("cm"));
    }

    #[test]
    fn unwrapped_non_destructive_members_do_not_retract() {
        // TN for the registry flag: `export` / `unexport` / `filter` name a
        // method without removing it, so the unwrapped arm must leave them be.
        for member in ["export", "unexport", "filter"] {
            let src =
                format!("oo::class create ::C {{ method m {{}} {{ return 1 }}\n{member} m }}");
            let mut a = Analyser::new();
            let r = a.analyse(&src, "tcl9.0");
            assert!(
                r.all_classes["::C"].methods.contains_key("m"),
                "`{member}` must not retract",
            );
        }
    }

    #[test]
    fn source_configuration_accumulates_redeclared_members_under_original_class_owner() {
        // naming.source.original-class-reference
        // docs/design/analysis/name-resolution-proofs/source-original-class-reference.md
        // Conditional source chronology and canonical metadata, without an
        // executed configuration worker or a live Native method table.
        for source in [
            "oo::class create C {method m {} {return FIRST}}; oo::define C {deletemethod m}; oo::define C {method m {} {return LAST}}",
            "oo::class create C {method m {} {return FIRST}}; rename C Held; interp alias {} configure {} oo::define Held; configure {deletemethod m}; configure {method m {} {return LAST}}",
        ] {
            let mut result = Analyser::new().analyse(source, "tcl9.0");
            let declaration = result.original_class_declarations().next().unwrap();
            assert!(declaration.metadata().methods.contains_key("m"));
            let last = source.find("return LAST").unwrap();
            assert!(
                declaration.metadata().methods["m"]
                    .body_span
                    .as_range()
                    .contains(&last)
            );
            let methods = declaration
                .metadata()
                .original_members
                .methods(MemberSide::Instance)
                .unwrap();
            let method = methods
                .iter()
                .find(|method| method.original_name_input().bytes() == b"m")
                .unwrap();
            assert!(method.metadata().body_span.as_range().contains(&last));
            let canonical = declaration.clone();
            result.all_classes.clear();
            assert_eq!(
                result.original_class_declarations().next(),
                Some(&canonical)
            );
        }
        let source = "oo::class create C {}; rename C {}; oo::define C {method ghost {} {}}";
        let result = Analyser::new().analyse(source, "tcl9.0");
        assert_eq!(result.original_class_declarations().count(), 1);
        assert!(result.original_class_declarations().all(|declaration| {
            !declaration.metadata().methods.contains_key("ghost")
                && declaration
                    .metadata()
                    .original_members
                    .declarations()
                    .all(|method| method.original_name_input().bytes() != b"ghost")
        }));
    }

    #[test]
    fn an_unwrapped_retracted_member_can_be_redeclared_by_a_later_body() {
        // Source-order guard, unwrapped half. Retraction happens where the body
        // is walked, so a later `oo::define` redeclaration wins rather than the
        // name being erased document-wide.
        let src = "oo::class create ::C { method m {} { return 1 } }\n\
                   oo::define ::C { deletemethod m }\n\
                   oo::define ::C { method m {} { return 2 } }";
        let mut a = Analyser::new();
        let r = a.analyse(src, "tcl9.0");
        assert!(r.all_classes["::C"].methods.contains_key("m"));
    }

    #[test]
    fn objdefine_deletemethod_drops_the_per_object_member() {
        // The per-object table is the same instance-side routing. Oracle:
        //   oo::objdefine $o { method im {} {…}; deletemethod im }
        //   info object methods $o  ->            (empty)
        // `oo::objdefine` records into a throwaway `ClassDef` that never
        // reaches `all_classes`, so this asserts the walk simply does not
        // panic or resurrect the name anywhere.
        let src = "oo::class create ::C { method m {} { return m } }\n\
                   set o [::C new]\n\
                   oo::objdefine $o { method im {} { return i }\n\
                   deletemethod im }";
        let mut a = Analyser::new();
        let r = a.analyse(src, "tcl9.0");
        assert!(!r.all_classes.contains_key("::@objdefine@::o"));
        assert!(r.all_classes["::C"].methods.contains_key("m"));
    }

    // snit (tcllib) type / widget support.  Verified against real
    // `tclsh8.6` + tcllib.

    #[test]
    fn snit_type_recorded_as_class_with_members() {
        let src = "snit::type ::foo::Bar {\n\
                   variable v1\n\
                   typevariable tv1\n\
                   method m1 {a b} { return [expr {$a+$b+$v1}] }\n\
                   typemethod tm1 {} { return $tv1 }\n\
                   constructor {args} { set v1 0 }\n\
                   destructor { unset v1 }\n\
                   typeconstructor { set tv1 0 }\n\
                   }";
        let mut a = Analyser::new();
        let r = a.analyse(src, "tcl8.6");
        let c = r.all_classes.get("::foo::Bar").expect("Bar class recorded");
        assert_eq!(c.metaclass, "snit::type");
        assert!(c.methods.contains_key("m1"));
        assert!(c.class_methods.contains_key("tm1"));
        assert!(c.class_methods.contains_key("<typeconstructor>"));
        assert_eq!(c.constructors.len(), 1);
        assert!(c.destructor.is_some());
        assert_eq!(c.variables, vec!["v1".to_string(), "tv1".to_string()]);
    }

    #[test]
    fn snit_widget_keeps_win_and_hull_vars() {
        // A snit::widget injects `win` and `hull` instance variables — both
        // are recorded (only the four implicit scalars are filtered).
        let src = "snit::widget Dial {\n\
                   variable state\n\
                   method draw {} { return $win }\n\
                   }";
        let mut a = Analyser::new();
        let r = a.analyse(src, "tcl8.6");
        let c = r.all_classes.get("::Dial").expect("Dial recorded");
        assert_eq!(c.metaclass, "snit::widget");
        assert_eq!(
            c.variables,
            vec!["win".to_string(), "hull".to_string(), "state".to_string()]
        );
    }

    #[test]
    fn snit_method_body_suppresses_self_dispatch_and_implicit_vars() {
        // Inside a snit method, `$self`/`$component` dispatch and reads of
        // instance variables must not false-fire W307 (non-literal command),
        // W210 (read-before-set), or W211/W214 (unused).
        let src = "snit::widget mywidget {\n\
                   variable helper\n\
                   component inner\n\
                   method draw {} {\n\
                       $self configure -bg white\n\
                       $inner render\n\
                       $helper compute\n\
                       return $win\n\
                   }\n\
                   }";
        let r = crate::provider_fixtures::analyse(
            &format!("package require snit\n{src}"),
            "tcl8.6",
            &[crate::provider_fixtures::Provider::Snit],
        );
        for code in ["W210", "W211", "W214", "W307", "W308"] {
            assert!(
                !r.diagnostics.iter().any(|d| d.code.as_str() == code),
                "{code} must not fire in a snit method body: {:?}",
                r.diagnostics
            );
        }
    }

    #[test]
    fn snit_widgetadaptor_and_qualified_definer() {
        let mut a = Analyser::new();
        let r = a.analyse("::snit::widgetadaptor Foo { method m {} {} }", "tcl8.6");
        let c = r.all_classes.get("::Foo").expect("Foo recorded");
        assert_eq!(c.metaclass, "::snit::widgetadaptor");
        assert!(c.methods.contains_key("m"));
    }

    #[test]
    fn non_snit_command_is_not_a_class() {
        // A plain command that merely starts with `snit` is not a definer.
        let mut a = Analyser::new();
        let r = a.analyse("snitch foo { bar }", "tcl8.6");
        assert_eq!(r.all_classes.len(), 0);
    }

    // [incr Tcl] `itcl::class` — recorded as a `ClassDef` with method scopes,
    // access modifiers unwrapped, `inherit` → superclasses, `this` implicit.

    #[test]
    fn itcl_class_recorded_with_members() {
        let src = "itcl::class ::widgets::Dial {\n\
                   inherit Base\n\
                   variable value 0\n\
                   common count 0\n\
                   constructor {args} { set value 0 }\n\
                   destructor { unset value }\n\
                   method spin {delta} { incr value $delta }\n\
                   proc reset {} { set count 0 }\n\
                   }";
        let mut a = Analyser::new();
        let r = a.analyse(src, "tcl8.6");
        let c = r
            .all_classes
            .get("::widgets::Dial")
            .expect("Dial class recorded");
        assert_eq!(c.metaclass, "itcl::class");
        assert_eq!(c.superclasses, vec!["Base".to_string()]);
        assert!(c.methods.contains_key("spin"));
        assert!(
            c.class_methods.contains_key("reset"),
            "proc is a class method"
        );
        assert_eq!(c.constructors.len(), 1);
        assert!(c.destructor.is_some());
        // `variable` + `common` declarations are recorded (implicit `this` is
        // filtered).
        assert_eq!(c.variables, vec!["value".to_string(), "count".to_string()]);
    }

    #[test]
    fn itcl_access_modifiers_unwrap_with_visibility() {
        let src = "itcl::class C {\n\
                   public method api {} {}\n\
                   private method helper {} {}\n\
                   protected variable state 0\n\
                   }";
        let mut a = Analyser::new();
        let r = a.analyse(src, "tcl8.6");
        let c = r.all_classes.get("::C").expect("C recorded");
        assert_eq!(c.methods["api"].visibility, "public");
        assert_eq!(c.methods["helper"].visibility, "private");
        // The wrapped `protected variable state` is still a declared variable.
        assert!(c.variables.contains(&"state".to_string()));
    }

    #[test]
    fn itcl_method_body_suppresses_this_and_instance_vars() {
        // Inside an itcl method, `$this` dispatch and reads of instance /
        // `common` variables must not false-fire W210/W211/W307.
        let src = "itcl::class C {\n\
                   variable handler\n\
                   common registry\n\
                   method run {} {\n\
                       $this configure\n\
                       $handler process\n\
                       return $registry\n\
                   }\n\
                   }";
        let mut a = Analyser::new();
        let r = a.analyse(src, "tcl8.6");
        for code in ["W210", "W211", "W214", "W307", "W308"] {
            assert!(
                !r.diagnostics.iter().any(|d| d.code.as_str() == code),
                "{code} must not fire in an itcl method body: {:?}",
                r.diagnostics
            );
        }
    }

    #[test]
    fn non_itcl_command_is_not_a_class() {
        // A command that merely starts with `itcl` is not a definer.
        let mut a = Analyser::new();
        let r = a.analyse("itclish foo { bar }", "tcl8.6");
        assert_eq!(r.all_classes.len(), 0);
    }

    // OO body-walks: `initialise` body, `property -get/-set` accessor bodies,
    // and the `new` / `createWithNamespace` class-command variants.

    #[test]
    fn oo_initialise_body_is_walked() {
        // A `variable` read inside `initialise { … }` must not false-fire
        // W210 read-before-set — the class-level init body is walked with the
        // class's instance variables visible.
        let src = "oo::class create Foo {\n\
                   variable cache\n\
                   initialise { set cache [dict create] }\n\
                   method get {k} { return [dict get $cache $k] }\n\
                   }";
        let mut a = Analyser::new();
        let r = a.analyse(src, "tcl8.6");
        assert!(
            !r.diagnostics
                .iter()
                .any(|d| matches!(d.code.as_str(), "W210" | "W211")),
            "initialise body should be walked cleanly: {:?}",
            r.diagnostics
        );
    }

    /// A class-shared variable set up by the class-level `initialize` script
    /// and reached from a method through `classvariable` must not draw a
    /// read-before-set.
    ///
    /// Oracled on tclsh 9.0.4: this exact class answers `5e-6`. The
    /// `initialize` body runs in the class's own object namespace, so the
    /// write and the read live in different frames — which is precisely why
    /// `classvariable` has to be modelled as a declaration rather than as a
    /// plain local.
    #[test]
    fn classvariable_reaches_a_variable_initialise_declared() {
        let src = "oo::class create Foo {\n\
                   initialize {\n\
                   variable Pitch\n\
                   const Pitch 5e-6\n\
                   }\n\
                   method m {} { classvariable Pitch; return $Pitch }\n\
                   }";
        let mut a = Analyser::new();
        let r = a.analyse(src, "tcl9.0");
        assert!(
            !r.diagnostics.iter().any(|d| d.code.as_str() == "W210"),
            "classvariable reaches the initialise-declared cell: {:?}",
            r.diagnostics
        );
    }

    /// Near variants of the same shape, each **run** on tclsh
    /// 9.0.4: a plain `set` instead of `const`, a value-bearing
    /// `variable`, the British `initialise` spelling, the `oo::define`
    /// form, two names in one `classvariable` call (both must bind — a
    /// `VarWrite` role on index 0 alone leaves the second unbound), and a
    /// write/read split across two methods.
    ///
    /// The `variable Pitch` before the `const` is load-bearing,
    /// not noise: an `initialize` script runs in a call frame, so a bare
    /// `const Pitch 5e-6` there makes a *frame-local* constant that no
    /// method can reach (tclsh 9.0.4: `can't read "Pitch": no such
    /// variable`). Only the `variable` declaration aims the write at the
    /// class-shared cell — which is why that shape is absent from this
    /// clean-list.
    #[test]
    fn classvariable_variants_stay_clean() {
        for (label, src) in [
            (
                "set instead of const",
                "oo::class create Foo {\n\
                 initialize { variable Pitch; set Pitch 5e-6 }\n\
                 method m {} { classvariable Pitch; return $Pitch }\n\
                 }",
            ),
            (
                "value-bearing variable",
                "oo::class create Foo {\n\
                 initialize { variable Pitch 5e-6 }\n\
                 method m {} { classvariable Pitch; return $Pitch }\n\
                 }",
            ),
            (
                "initialise spelling",
                "oo::class create Foo {\n\
                 initialise { variable Pitch; const Pitch 5e-6 }\n\
                 method m {} { classvariable Pitch; return $Pitch }\n\
                 }",
            ),
            (
                "oo::define form",
                "oo::class create Foo {}\n\
                 oo::define Foo {\n\
                 initialize { variable Pitch; const Pitch 5e-6 }\n\
                 method m {} { classvariable Pitch; return $Pitch }\n\
                 }",
            ),
            (
                "two names in one call",
                "oo::class create Foo {\n\
                 initialize { variable a 1; variable b 2 }\n\
                 method m {} { classvariable a b; return [list $a $b] }\n\
                 }",
            ),
            (
                "written in one method, read in another",
                "oo::class create Foo {\n\
                 method w {} { classvariable Count; set Count 1 }\n\
                 method r {} { classvariable Count; return $Count }\n\
                 }",
            ),
            (
                // The `classvariable(n)` manual page's own example.
                "manual-page Counted example",
                "oo::class create Counted {\n\
                 initialise { variable count 0 }\n\
                 variable number\n\
                 constructor {} { classvariable count; set number [incr count] }\n\
                 method report {} { classvariable count; puts \"$number of $count\" }\n\
                 }",
            ),
        ] {
            let mut a = Analyser::new();
            let r = a.analyse(src, "tcl9.0");
            assert!(
                !r.diagnostics
                    .iter()
                    .any(|d| matches!(d.code.as_str(), "W210" | "W211")),
                "{label}: {:?}",
                r.diagnostics
            );
        }
    }

    /// The other half: the classvariable handling must not silence a genuine
    /// unbound read. Without `classvariable`, a method's `$Pitch` is an
    /// *instance* variable that the class-level `initialize` never wrote —
    /// tclsh 9.0.4 raises `can't read "Pitch": no such variable` — so W210
    /// is correct and has to stay.
    #[test]
    fn a_method_read_without_classvariable_still_warns() {
        let src = "oo::class create Foo {\n\
                   initialize { variable Pitch; const Pitch 5e-6 }\n\
                   method m {} { ::return $Pitch }\n\
                   }";
        let mut a = Analyser::new();
        let r = a.analyse(src, "tcl9.0");
        assert!(
            r.diagnostics.iter().any(|d| d.code.as_str() == "W210"),
            "an instance-side read of a class-scoped cell is a real bug: {:?}",
            r.diagnostics
        );
    }

    /// The same snippet under 8.6 reports what 8.6 actually lacks —
    /// `initialize` and `const` are both 9.0 members — and never W210.
    /// `classvariable` itself is reachable there only through Tcllib's
    /// `ooutil`, which the document requires.
    #[test]
    fn the_reporter_snippet_under_86_reports_the_missing_commands() {
        let src = "package require ooutil\n\
                   oo::class create Foo {\n\
                   initialize { variable Pitch; const Pitch 5e-6 }\n\
                   method m {} { classvariable Pitch; return $Pitch }\n\
                   }";
        let mut a = Analyser::new();
        let r = a.analyse(src, "tcl8.6");
        let codes: Vec<&str> = r.diagnostics.iter().map(|d| d.code.as_str()).collect();
        assert!(
            !codes.contains(&"W210"),
            "8.6 must not add a read-before-set: {:?}",
            r.diagnostics
        );
        assert!(
            r.diagnostics
                .iter()
                .any(|d| d.code.as_str() == "W002" && d.message.contains("'const'")),
            "8.6 has no `const` (TIP 677 is 9.0): {:?}",
            r.diagnostics
        );
    }

    /// `classvariable` binds only literal, unqualified names: a
    /// substitution names no cell the analyser can see, so it stays the
    /// W212 it already was rather than silently declaring `$dyn`.
    #[test]
    fn a_dynamic_classvariable_name_is_not_a_declaration() {
        let src = "oo::class create Foo { method m {} { classvariable $dyn; return $Pitch } }";
        let mut a = Analyser::new();
        let r = a.analyse(src, "tcl9.0");
        assert!(
            r.diagnostics.iter().any(|d| d.code.as_str() == "W212"),
            "a substituted name is still reported: {:?}",
            r.diagnostics
        );
    }

    #[test]
    fn oo_property_accessor_bodies_are_walked() {
        // `-get`/`-set` accessor bodies are walked with the instance variable
        // `val` and the implicit `value` visible — no false W210 / W307.
        // `property` is a 9.0 member, so the vector runs under a 9.0 dialect.
        let src = "oo::configurable create Bar {\n\
                   variable val\n\
                   property color -get { return $val } -set { set val $value }\n\
                   }";
        let mut a = Analyser::new();
        let r = a.analyse(src, "tcl9.0");
        assert!(r.all_classes.contains_key("::Bar"));
        assert!(
            !r.diagnostics
                .iter()
                .any(|d| matches!(d.code.as_str(), "W210" | "W307")),
            "property accessor bodies should be walked cleanly: {:?}",
            r.diagnostics
        );
    }

    #[test]
    fn oo_class_create_with_namespace_is_not_exported() {
        // C Tcl 9.0.4 and 8.6 both reject this ordinary command dispatch:
        // createWithNamespace exists internally but is not exported on
        // oo::class. A rejected call cannot introduce a class.
        let mut a = Analyser::new();
        let r = a.analyse("oo::class createWithNamespace MyCls ::ns { }", "tcl8.6");
        assert!(
            !r.all_classes.keys().any(|k| k.contains("MyCls")),
            "an unexported manufacturer must not record a class: {:?}",
            r.all_classes.keys().collect::<Vec<_>>()
        );
    }
}

#[cfg(test)]
mod lifecycle_formal_tests {
    use crate::analyser::Analyser;
    use tcl_core_types::DiagCode;

    #[test]
    fn original_tcloo_formals_follow_counted_lifecycle_body_applicability() {
        // naming.tcloo.empty-lifecycle-definition
        // docs/design/analysis/name-resolution-proofs/tcloo-empty-lifecycle-definition.md
        // Original ASCII source-script contract; no entered frame is asserted.
        for dialect in ["tcl8.6", "tcl9.0", "tcl9.1"] {
            for (source, expected) in [
                ("oo::class create C {constructor {{a b c}} {}}", 0),
                ("oo::class create C {constructor {{a b c}} { }}", 1),
                ("oo::class create C {constructor {{a b c}} {# body}}", 1),
                ("oo::class create C {constructor {\"a} {}}", 0),
                ("oo::class create C {constructor {\"a} { }}", 1),
                (
                    "oo::class create C {}; oo::define C constructor {{a b c}} {}",
                    0,
                ),
                (
                    "oo::class create C {}; oo::define C constructor {{a b c}} { }",
                    1,
                ),
                (
                    "oo::class create P {constructor {a b} { }}; oo::class create C {superclass P; constructor {{a b c}} {}}",
                    0,
                ),
                ("oo::class create C {method m {{a b c}} {}}", 1),
            ] {
                let analysis = Analyser::new().analyse(source, dialect);
                let diagnostics = analysis
                    .diagnostics
                    .iter()
                    .filter(|diagnostic| diagnostic.code == DiagCode::E006)
                    .collect::<Vec<_>>();
                assert_eq!(
                    diagnostics.len(),
                    expected,
                    "{dialect}: {source}: {diagnostics:?}"
                );
            }
        }
    }

    #[test]
    fn original_tcloo_formal_applicability_preserves_dynamic_body_uncertainty() {
        // naming.tcloo.empty-lifecycle-definition
        // docs/design/analysis/name-resolution-proofs/tcloo-empty-lifecycle-definition.md
        // Dynamic source bodies are not evaluated or promoted to empty values.
        for source in [
            "oo::class create C {constructor {{a b c}} $body}",
            "oo::class create C {constructor {{a b c}} [body]}",
            "oo::class create C {}; oo::define C constructor {{a b c}} $body",
        ] {
            let analysis = Analyser::new().analyse(source, "tcl9.0");
            assert!(
                !analysis
                    .diagnostics
                    .iter()
                    .any(|diagnostic| diagnostic.code == DiagCode::E006),
                "{source}"
            );
        }
    }
}
