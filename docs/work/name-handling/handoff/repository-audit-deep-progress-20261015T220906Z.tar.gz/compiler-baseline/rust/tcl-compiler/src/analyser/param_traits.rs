// tcl-lsp — a language server and toolchain for Tcl
// Copyright (C) 2026 James Deucker (bitwisecook) <https://github.com/bitwisecook>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.
//
// SPDX-License-Identifier: AGPL-3.0-or-later

//! Proc argument trait inference.
//!
//! Walks a proc body to determine how each parameter is used:
//!
//! - `Eval` — run as a script: a `Body` word of a call the registry says
//!   evaluates code or defers its script (``eval``, ``uplevel``, ``after``),
//!   or any word of one that substitutes its operand (``subst``)
//! - `Body` — used as a loop / control body
//! - `VarWrite` — names a variable the proc writes through an alias
//!   (``upvar`` and then any registry `VarWrite` of the alias)
//! - `VarRead` — names a variable the proc reads via ``upvar``
//! - `Expr` — evaluated as an expression
//! - `LoopList` — the list a list loop iterates (``foreach`` / ``lmap``)
//! - `DynamicNameLocal` — the param's *value* names a
//!   **callee-local** variable (``set $p 1`` / ``scan … $p`` /
//!   ``lassign … $p`` / ``regsub … $p``, or a registry
//!   ``VarWrite`` / ``VarRead`` role on a bare ``$param``).  Emitted
//!   with `VarRead`; refines it so caller-side dead-store / unused
//!   suppression does **not** treat a literal-name call arg as
//!   consumed (the callee uses the string to name its *own* local,
//!   not a caller-frame alias).
//!
//! Two passes are exposed:
//!
//! * [`infer_param_traits`] — shallow command scan.  Fast enough
//!   for synchronous use during analysis; detects direct patterns
//!   like ``eval $param``, ``upvar 1 $param local``, ``foreach x
//!   $list body``.  It **does** descend into ``[...]`` command
//!   substitutions (`return [set $v]` is a first-order use), and
//!   recognises variable names built from parameters — a bare
//!   ``$p``, a compound array element (``set ${v}($k)`` marks both
//!   ``v`` and ``k``), and ``namespace upvar ns $token arr``.  It
//!   does **not** recurse into braced *body* arguments (that is the
//!   deep pass's job).
//! * [`infer_param_traits_deep`] — recursive descent into
//!   braced body args, catching traits hidden one or more
//!   levels deep (`foreach item $items { uplevel 1 $body }`
//!   surfaces the `$body` Eval trait via the recursion).  More
//!   expensive than the shallow pass; intended for asynchronous
//!   analysis (call-graph / symbol-graph / dataflow-graph /
//!   semantic-graph builders).  Bounded by [`MAX_DEPTH`]
//!   (8 levels) to prevent runaway recursion on pathological
//!   input.
//!
//! [`merge_traits`] unions the two passes' results when
//! callers want both.

use std::collections::{HashMap, HashSet};

use tcl_registry::model::DocumentCommandSurface;
use tcl_registry::{CommandRegistry, arg_role::ArgRole};

use super::types::ProcArgTrait;
use crate::segmenter::segment_commands_with_offset_and_config;
use tcl_lexer::{LexerConfig, TokenType};

/// Top-level shallow trait inference.  Returns a map from
/// parameter name to a set of inferred traits.  Empty entries
/// (parameters with no detected trait) are dropped from the
/// returned map.
///
/// `env` carries the document's one command surface (the dialect-aware
/// registry generation plus whatever the document declares for itself with
/// `# tcl-lsp: stub`), the dialect lexer configuration, and the document's
/// proven command-identity facts — see [`TraitScanEnv`].
#[must_use]
pub fn infer_param_traits(
    params: &[&str],
    body_source: &str,
    env: TraitScanEnv<'_>,
) -> HashMap<String, HashSet<ProcArgTrait>> {
    if params.is_empty() || body_source.trim().is_empty() || !env.matches_source(body_source) {
        return HashMap::new();
    }
    let param_set: HashSet<&str> = params.iter().copied().collect();
    let mut traits: HashMap<&str, HashSet<ProcArgTrait>> =
        params.iter().map(|p| (*p, HashSet::new())).collect();
    let mut aliases = Aliases::default();

    let ctx = ScanCtx {
        param_set: &param_set,
        parameters: params,
        surface: env.surface,
        config: env.config,
        identities: env.identities,
        executed_source: env.executed_source,
        source_base: env
            .executed_source
            .map(crate::command_binding::ExecutedScriptSource::base),
    };
    scan_commands(body_source, &ctx, &mut traits, &mut aliases);

    finalise_traits(traits)
}

/// Maximum recursion depth for [`infer_param_traits_deep`]
/// (8 levels).  Pathological input (deeply-nested braced bodies)
/// stops descending past this bound rather than blowing the
/// stack.
pub const MAX_DEPTH: u8 = 8;

/// Recursive deep trait inference.  Same return shape as
/// [`infer_param_traits`] but additionally descends into braced
/// body arguments to surface traits hidden one or more levels
/// in.  More expensive than the shallow pass — intended for
/// asynchronous use behind the call-graph / symbol-graph /
/// dataflow-graph / semantic-graph builders.
///
/// Recursion is bounded by [`MAX_DEPTH`] and only enters braced
/// body args — `$var` or `[cmd]` references at the head of a
/// body arg are treated as opaque (their `Eval` trait is already
/// captured at the top level by the same call-site's role
/// scan).
#[must_use]
pub fn infer_param_traits_deep(
    params: &[&str],
    body_source: &str,
    env: TraitScanEnv<'_>,
) -> HashMap<String, HashSet<ProcArgTrait>> {
    infer_param_traits_deep_at_depth(params, body_source, env, 0)
}

/// [`infer_param_traits_deep`] with an explicit starting depth.
///
/// The public entry points always start at `0`; `scan_deep`'s own `apply`
/// (`ArgRole::LambdaLiteral`) handling calls this with `depth + 1` instead
/// of re-entering at `0`. A lambda body is inferred in its own frame (see
/// the doc comment at that call site for why), but it is still lexically
/// nested inside the enclosing scan — starting it back at depth `0` would
/// let alternating `if {…} { apply {x {…}} … }` nesting reset the logical
/// counter on every `apply`, defeating [`MAX_DEPTH`] while the *native*
/// call stack keeps growing one `scan_deep` ↔
/// `infer_param_traits_deep_at_depth` frame group per level regardless —
/// the same "guard exists but doesn't cover every recursive edge" bug class.
fn infer_param_traits_deep_at_depth(
    params: &[&str],
    body_source: &str,
    env: TraitScanEnv<'_>,
    depth: u8,
) -> HashMap<String, HashSet<ProcArgTrait>> {
    if params.is_empty()
        || body_source.trim().is_empty()
        || depth > MAX_DEPTH
        || !env.matches_source(body_source)
    {
        return HashMap::new();
    }
    let param_set: HashSet<&str> = params.iter().copied().collect();
    let mut traits: HashMap<&str, HashSet<ProcArgTrait>> =
        params.iter().map(|p| (*p, HashSet::new())).collect();
    let mut aliases = Aliases::default();

    let ctx = ScanCtx {
        param_set: &param_set,
        parameters: params,
        surface: env.surface,
        config: env.config,
        identities: env.identities,
        executed_source: env.executed_source,
        source_base: env
            .executed_source
            .map(crate::command_binding::ExecutedScriptSource::base),
    };
    scan_deep(body_source, &ctx, &mut traits, &mut aliases, depth);

    finalise_traits(traits)
}

/// Union shallow + deep trait results per parameter.  Useful
/// when callers want to run the shallow pass synchronously for
/// an initial result and then upgrade with the deep pass once it
/// completes.
///
/// Generic over the hasher so it composes with whatever
/// [`infer_param_traits`] / [`infer_param_traits_deep`] return.
#[must_use]
pub fn merge_traits<S, H>(
    shallow: HashMap<String, HashSet<ProcArgTrait, H>, S>,
    deep: HashMap<String, HashSet<ProcArgTrait, H>, S>,
) -> HashMap<String, HashSet<ProcArgTrait, H>, S>
where
    S: std::hash::BuildHasher,
    H: std::hash::BuildHasher + Default,
{
    let mut merged = shallow;
    for (param, deep_traits) in deep {
        merged.entry(param).or_default().extend(deep_traits);
    }
    merged
}

/// Drop parameters with no detected trait and convert the
/// borrowed keys back to owned `String`s.  Shared between
/// `infer_param_traits` and `infer_param_traits_deep` so both
/// pass shapes return the same kind of map.
fn finalise_traits(
    traits: HashMap<&str, HashSet<ProcArgTrait>>,
) -> HashMap<String, HashSet<ProcArgTrait>> {
    traits
        .into_iter()
        .filter(|(_, set)| !set.is_empty())
        .map(|(k, v)| (k.to_string(), v))
        .collect()
}

/// Read-only inference state threaded unchanged through the
/// shallow and deep scan family (`scan_commands` / `scan_command`
/// / `scan_deep`).  Bundling these into one borrowing context
/// keeps each scan helper at or under the 7-argument limit.
///
/// `'p` is the params' lifetime (the param-name slices borrowed
/// from the caller's `params` argument); `'r` borrows the
/// command surface / param-set for the duration of a scan.
#[derive(Clone, Copy)]
struct ScanCtx<'p, 'r> {
    param_set: &'r HashSet<&'p str>,
    parameters: &'r [&'p str],
    surface: DocumentCommandSurface<'r>,
    config: LexerConfig,
    /// The **document's** proven command-identity facts, so a
    /// role, frame-effect, or structural handler is chosen by the command a
    /// head *is* rather than the one it is spelled as.
    ///
    /// Positioned scans retain the actual evaluated body origin and its map;
    /// standalone scans require conservative unpositioned identity consensus.
    identities: &'r crate::realm::CommandBindingRealm,
    executed_source: Option<&'r crate::command_binding::ExecutedScriptSource>,
    source_base: Option<u32>,
}

impl<'p> ScanCtx<'p, '_> {
    fn body_assistance(
        &self,
        source: &str,
        command: &crate::segmenter::SegmentedCommand,
    ) -> Option<Box<crate::registry_invocation::InvocationBodyAssistance>> {
        let bindings = self.identities.source_bindings_ref();
        if self.executed_source.is_none() {
            return crate::registry_invocation::unpositioned_body_assistance(
                &self.surface,
                bindings,
                source,
                self.config,
                command,
                self.identities.source_metadata_context().as_deref(),
            );
        }
        let selected = self
            .executed_source
            .filter(|source| bindings.source_origin() != Some(&source.origin))
            .and_then(|source| bindings.selected_source(source));
        crate::registry_invocation::segmented_body_assistance(
            &self.surface,
            selected.as_ref().unwrap_or(bindings),
            source,
            self.config,
            command,
            self.source_base.unwrap_or(0),
            self.identities.source_metadata_context().as_deref(),
        )
    }

    fn argument_values(
        &self,
        source: &str,
        command: &crate::segmenter::SegmentedCommand,
        aliases: &Aliases<'p>,
    ) -> ArgumentValues<'p> {
        let Some(executed) = self.executed_source else {
            return ArgumentValues::lexical(
                source,
                command,
                self.param_set,
                aliases,
                self.config.nested(),
                self.surface.commands(),
            );
        };
        let bindings = self.identities.source_bindings_ref();
        let selected = (bindings.source_origin() != Some(&executed.origin))
            .then(|| bindings.selected_source(executed))
            .flatten();
        let bindings = selected.as_ref().unwrap_or(bindings);
        let mut tokens = crate::ir::CommandTokens::from_segmented(
            &tcl_lexer::SourceMap::new(source),
            self.config,
            command,
        );
        crate::lattice_rebase::rebase_command_tokens(
            &mut tokens,
            i64::from(self.source_base.unwrap_or(0)),
        );
        let parameters = self.parameters;
        let registry = self.surface.commands();
        // Parameter traits describe the original declaration's inputs. A
        // caller's entered values cannot erase or donate that symbolic input.
        let full = tokens
            .words()
            .iter()
            .map(|word| {
                let (spelling, site) = word.sole_variable_substitution()?;
                let name = bindings.symbolic_declaration_formal_value_at(
                    &executed.origin,
                    site,
                    spelling,
                    parameters,
                    (
                        registry,
                        self.identities
                            .source_bindings_ref()
                            .source_metadata_owner(),
                    ),
                )?;
                self.param_set.get(name.as_str()).copied()
            })
            .collect();
        let offset = command
            .span
            .start()
            .checked_add(self.source_base.unwrap_or(0));
        let components = tokens
            .words()
            .iter()
            .map(|word| {
                offset.map_or_else(Vec::new, |offset| {
                    bindings
                        .symbolic_declaration_formal_components_in_word(
                            &executed.origin,
                            offset,
                            word,
                            parameters,
                            (
                                registry,
                                self.identities
                                    .source_bindings_ref()
                                    .source_metadata_owner(),
                            ),
                        )
                        .into_iter()
                        .filter_map(|name| self.param_set.get(name.as_str()).copied())
                        .collect()
                })
            })
            .collect();
        ArgumentValues { full, components }
    }

    fn nested(&self, token: &tcl_lexer::Token, text: &str) -> Self {
        self.nested_at(
            token
                .span
                .start()
                .checked_add(u32::from(token.content_offset)),
            text,
        )
    }

    fn nested_at(&self, offset: Option<u32>, text: &str) -> Self {
        let source_base = self.source_base.and_then(|base| base.checked_add(offset?));
        let source_base = self.executed_source.map_or(source_base, |source| {
            let base = source_base?;
            crate::command_binding::ExecutedScriptSource::contiguous(
                std::sync::Arc::clone(&source.origin),
                text,
                base,
            )
            .map(|_| base)
        });
        Self {
            source_base,
            ..*self
        }
    }

    fn source_slice(
        &self,
        text: &str,
        offset: u32,
    ) -> Option<crate::command_binding::ExecutedScriptSource> {
        let source = self.executed_source?;
        let base = self.source_base?.checked_add(offset)?;
        crate::command_binding::ExecutedScriptSource::contiguous(
            std::sync::Arc::clone(&source.origin),
            text,
            base,
        )
    }
}

/// Everything a param-trait scan needs about the document it is scanning
/// inside: the command surface it resolves against, the dialect lexer
/// configuration the body re-segments under, and the document's proven
/// command-identity facts.
///
/// Bundled so the four public entry points share one parameter rather than
/// four, and so adding a document-level fact does not re-open every signature.
#[derive(Clone, Copy)]
pub struct TraitScanEnv<'a> {
    /// The one command surface this document analyses against
    /// ([`DocumentCommandSurface`]): the caller's already-built,
    /// dialect-aware registry generation plus whatever the document
    /// declares for itself with `# tcl-lsp: stub`. Building
    /// a fresh `CommandRegistry::build_default()` per proc would both be
    /// expensive and miss the dialect-specific `arg_role_resolver` /
    /// `arg_roles` the caller's generation has loaded; a stub like
    /// `# tcl-lsp: stub my_eval {script:body}` makes a `my_eval $param`
    /// invocation mark the parameter `ProcArgTrait::Body`.
    pub surface: DocumentCommandSurface<'a>,
    /// Complete parent configuration retained by the original body/metadata
    /// owner. Body parsers select `config.nested()` locally, including a body
    /// at offset zero; `{*}`, quoting and all other grammar axes remain intact.
    /// The parent configuration remains available for original word joins.
    pub config: LexerConfig,
    /// The document's proven command-identity facts — see
    /// [`crate::realm`].  Pass
    /// [`CommandBindingRealm::none()`](crate::realm::CommandBindingRealm::none)
    /// when there is no document to scan.
    pub identities: &'a crate::realm::CommandBindingRealm,
    /// Exact evaluated body bytes and origin. Missing carriers use only
    /// conservative unpositioned identity consensus.
    pub executed_source: Option<&'a crate::command_binding::ExecutedScriptSource>,
}

impl TraitScanEnv<'_> {
    fn matches_source(self, text: &str) -> bool {
        self.executed_source
            .is_none_or(|source| source.text.bytes() == text.as_bytes())
    }

    #[cfg(test)]
    fn has_actual_procedure_entry(self) -> bool {
        self.executed_source.is_some_and(|source| {
            self.identities
                .source_bindings_ref()
                .has_actual_procedure_entry(source)
        })
    }
}

/// Frozen input origins for each original word, including the command head.
/// Equal spellings in different positions can read different stored values.
struct ArgumentValues<'p> {
    full: Vec<Option<&'p str>>,
    components: Vec<Vec<&'p str>>,
}

impl<'p> ArgumentValues<'p> {
    fn lexical(
        source: &str,
        command: &crate::segmenter::SegmentedCommand,
        parameters: &HashSet<&'p str>,
        aliases: &Aliases<'p>,
        config: LexerConfig,
        registry: &CommandRegistry,
    ) -> Self {
        let tokens = crate::ir::CommandTokens::from_segmented(
            &tcl_lexer::SourceMap::new(source),
            config,
            command,
        );
        let original = tokens
            .original_words_match_argv_text()
            .then(|| {
                crate::registry_invocation::original_native_compiler_words(
                    &tcl_lexer::SourceImage::document(source),
                    tokens.words(),
                    command.span.start(),
                    config,
                )
            })
            .flatten();
        let Some(original) = original else {
            return Self {
                full: vec![None; command.argv.len()],
                components: vec![Vec::new(); command.argv.len()],
            };
        };
        let mut scanner = crate::var_refs::VarReferenceScanner::with_config(
            crate::var_refs::VarScanOptions::default(),
            config,
        );
        Self {
            full: original
                .iter()
                .map(|word| {
                    lookup_param(original_scalar_reference_name(word)?, parameters, aliases)
                })
                .collect(),
            components: original
                .iter()
                .map(|word| {
                    original_reference_components(word, registry, &mut scanner)
                        .iter()
                        .filter_map(|name| lookup_param(name, parameters, aliases))
                        .collect()
                })
                .collect(),
        }
    }

    fn argument(&self, index: usize) -> Option<&'p str> {
        self.full.get(index + 1).copied().flatten()
    }

    fn argument_components(&self, index: usize) -> &[&'p str] {
        self.components.get(index + 1).map_or(&[], Vec::as_slice)
    }
}

/// Mutable alias / value-copy state accumulated while scanning a proc body.
/// Bundling the two maps keeps the scan helpers at or under the argument limit.
#[derive(Clone)]
struct Aliases<'p> {
    /// `myVar` (an `upvar` / `namespace upvar` alias name) → the param it
    /// aliases, so a later `set myVar …` writes the caller's variable
    /// (`VarWrite`).
    upvar: HashMap<String, &'p str>,
    retired_inputs: HashSet<String>,
    direct_inputs_known: bool,
    /// A local name → the param whose *value* it currently holds (`set n $p`),
    /// so a later `$n` in a name / command position resolves to that param.
    /// Invalidated when the local is written to anything else.
    value_copies: HashMap<String, &'p str>,
}

impl Default for Aliases<'_> {
    fn default() -> Self {
        Self {
            upvar: HashMap::new(),
            value_copies: HashMap::new(),
            retired_inputs: HashSet::new(),
            direct_inputs_known: true,
        }
    }
}

impl Aliases<'_> {
    fn clear(&mut self) {
        self.upvar.clear();
        self.value_copies.clear();
        self.direct_inputs_known = false;
    }
}

/// Local scalar geometry under this invocation's retained lookup policy.
/// Unknown policy requires agreement across source policies, not a default.
fn is_local_scalar_name(
    name: &str,
    selected: &crate::registry_invocation::ResolvedStatementInvocation,
) -> bool {
    tcl_syntax::naming::split_element_ref(name).is_none()
        && selected
            .dialect
            .and_then(|dialect| dialect.variable_lookup_policy)
            .map_or_else(
                || {
                    tcl_syntax::naming::source_variable_name_is_frame_local_for_all_policies(
                        name.as_bytes(),
                    )
                },
                |policy| {
                    tcl_syntax::naming::source_variable_name_is_frame_local(name.as_bytes(), policy)
                },
            )
}

fn written_template_literal(
    view: &crate::registry_invocation::InvocationBodyAssistance,
    selected: &crate::registry_invocation::ResolvedStatementInvocation,
    written: usize,
) -> Option<String> {
    let mut matching = (0..selected.arguments.len())
        .filter(|index| selected.effective.written_argument(*index) == Some(written));
    let argument = matching.next()?;
    matching.next().is_none().then_some(())?;
    view.caller_template_literal_data(selected, argument)
}

/// Single-level command scan shared by both passes.  Extracts
/// segmented commands from `source` and dispatches each through
/// [`scan_command`].
///
/// `source` has a lifetime independent of `'p` so callers can
/// re-enter with body-arg slices that don't outlive the
/// enclosing source.
fn scan_commands<'p>(
    source: &str,
    ctx: &ScanCtx<'p, '_>,
    traits: &mut HashMap<&'p str, HashSet<ProcArgTrait>>,
    aliases: &mut Aliases<'p>,
) {
    scan_commands_bounded(source, ctx, traits, aliases, 0);
}

/// [`scan_commands`] plus descent into `[...]` command substitutions, bounded
/// by [`MAX_DEPTH`].  A param used inside a substitution (`return [set $v]`,
/// `set x [foo $v]`, `set ${v}($k)` wrapped in `[...]`) is a first-order use of
/// that param, not a "deep" one, so both the shallow and deep passes see it —
/// the substitution is where much ordinary Tcl computation happens.  Nested
/// substitutions are reached by the recursion.
fn scan_commands_bounded<'p>(
    source: &str,
    ctx: &ScanCtx<'p, '_>,
    traits: &mut HashMap<&'p str, HashSet<ProcArgTrait>>,
    aliases: &mut Aliases<'p>,
    depth: u8,
) {
    let segments = segment_commands_with_offset_and_config(source, 0, ctx.config.nested());
    for seg in &segments {
        if seg.texts.is_empty() {
            continue;
        }
        scan_segment(source, seg, ctx, traits, aliases, depth);
    }
}

fn scan_segment<'p>(
    source: &str,
    seg: &crate::segmenter::SegmentedCommand,
    ctx: &ScanCtx<'p, '_>,
    traits: &mut HashMap<&'p str, HashSet<ProcArgTrait>>,
    aliases: &mut Aliases<'p>,
    depth: u8,
) -> (
    Option<Box<crate::registry_invocation::InvocationBodyAssistance>>,
    Aliases<'p>,
    ArgumentValues<'p>,
) {
    let cmd_args: Vec<String> = seg.texts[1..].to_vec();
    // Per-arg "braced literal" flags: a single `Str` word (`{…}`) suppresses
    // substitution, so a `$k` inside it is literal text, not a param ref.
    let braced: Vec<bool> = (1..seg.texts.len())
        .map(|i| {
            seg.argv.get(i).is_some_and(|t| t.kind == TokenType::Str)
                && seg.single_token_word.get(i).copied().unwrap_or(false)
        })
        .collect();
    let values = ctx.argument_values(source, seg, aliases);
    if depth < MAX_DEPTH {
        let config = ctx.config.nested();
        let tokens = crate::ir::CommandTokens::from_segmented(
            &tcl_lexer::SourceMap::new(source),
            config,
            seg,
        );
        if let Some(words) = tokens
            .original_words_match_argv_text()
            .then(|| {
                crate::registry_invocation::original_native_compiler_words(
                    &tcl_lexer::SourceImage::document(source),
                    tokens.words(),
                    seg.span.start(),
                    config,
                )
            })
            .flatten()
        {
            for word in words.iter() {
                let arena = word.executable_parts();
                let mut bodies: Vec<_> = arena
                    .all_parts()
                    .filter_map(|part| match part.part {
                        tcl_lexer::ExecutablePart::Command { body } => Some(body),
                        _ => None,
                    })
                    .collect();
                bodies.sort_by_key(|body| body.start());
                for body in bodies {
                    let Some(inner) = arena
                        .bytes(body)
                        .and_then(|bytes| std::str::from_utf8(bytes).ok())
                    else {
                        continue;
                    };
                    if !inner.trim().is_empty() {
                        let nested = ctx.nested_at(Some(body.start()), inner);
                        scan_commands_bounded(inner, &nested, traits, aliases, depth + 1);
                    }
                }
            }
        }
    }
    let body_aliases = aliases.clone();
    let view = ctx.body_assistance(source, seg);
    #[cfg(debug_assertions)]
    if std::env::var_os("TCL_LSP_TRACE_ORIGINAL_PARAM_ROLES").is_some() {
        eprintln!(
            "ORIGINAL_PARAM_ROLES command local_offset={} base={:?} executed_source={} parameters={} full_values={} components={} assistance={} roles={}",
            seg.span.start(),
            ctx.source_base,
            ctx.executed_source.is_some(),
            ctx.parameters.len(),
            values.full.iter().filter(|value| value.is_some()).count(),
            values.components.iter().map(Vec::len).sum::<usize>(),
            view.is_some(),
            view.as_ref()
                .map_or(0, |view| view.parameter_role_advice().written_roles().len())
        );
    }
    scan_command(
        view.as_deref(),
        &cmd_args,
        &braced,
        &values,
        ctx,
        traits,
        aliases,
    );
    (view, body_aliases, values)
}

/// Recursive scan with depth tracking.  Walks every command at
/// the current level, then descends into the braced body
/// arguments each command declares via the registry's
/// ``ArgRole::Body`` role assignments.
///
/// `$var` / `[cmd]` body args are skipped — they aren't
/// braced bodies, and any `Eval` trait they carry is recorded
/// at the top level by the same call-site's role scan.
//
fn scan_deep<'p>(
    source: &str,
    ctx: &ScanCtx<'p, '_>,
    traits: &mut HashMap<&'p str, HashSet<ProcArgTrait>>,
    aliases: &mut Aliases<'p>,
    depth: u8,
) {
    if depth > MAX_DEPTH {
        return;
    }

    // Each nested body receives its original pre-dispatch copy state. A
    // conditional body cannot publish its assignments into a sibling path.
    let segments = segment_commands_with_offset_and_config(source, 0, ctx.config.nested());
    for seg in segments {
        if seg.texts.is_empty() {
            continue;
        }
        let (view, body_aliases, values) = scan_segment(source, &seg, ctx, traits, aliases, depth);
        let cmd_args: Vec<&str> = seg.texts[1..].iter().map(String::as_str).collect();
        // One surface answers for both a catalogue command and a
        // document-declared `# tcl-lsp: stub` one, so a stub-defined body
        // arg recurses just like a shipped one.
        let roles = view.as_ref().map_or_else(Vec::new, |view| {
            let mut roles = view.parameter_role_advice().written_roles();
            roles.extend(view.declared_roles.iter().copied());
            roles
        });
        let body_indices: HashSet<usize> = roles
            .iter()
            .filter_map(|&(index, role)| (role == ArgRole::Body).then_some(index))
            .collect();
        for idx in body_indices {
            let Some(body_text) = cmd_args.get(idx) else {
                continue;
            };
            if let Some(token) = seg.argv.get(idx + 1) {
                scan_deep_body(body_text, token, ctx, traits, &body_aliases, depth);
            }
        }

        // `apply {argList body ?ns?} …` — an apply body runs in a *fresh*
        // call frame with its own parameters; recursing into it with the
        // enclosing proc's own `ctx`/`traits` (as a plain `Body` arg would)
        // conflates the two frames. A lambda-local variable that happens to
        // share a name with an enclosing param (`proc f {body} { apply {x
        // {eval $body}} 1 }`) would wrongly mark `f`'s `body` param as
        // evaluated, while the real forwarding case (`apply {x {eval $x}}
        // $body`) would be missed entirely. Instead: infer the lambda's own
        // traits in complete isolation — as if it were its own tiny proc —
        // then propagate a
        // lambda param's trait back onto an enclosing param only when the
        // corresponding actual argument is a bare, unadorned reference to
        // that enclosing param, i.e. only when the value genuinely flows
        // from the caller's frame into the lambda's.
        for idx in roles
            .iter()
            .filter_map(|&(index, role)| (role == ArgRole::LambdaLiteral).then_some(index))
        {
            let Some(&tok) = seg.argv.get(idx + 1) else {
                continue;
            };
            if tok.kind != tcl_lexer::TokenType::Str {
                continue;
            }
            let Some(elems) = crate::lambda_literal::split_lambda_literal(source, tok) else {
                continue;
            };
            let Some(body_span) = elems.body else {
                continue;
            };
            let Some(body_text) = source.get(body_span.start() as usize..body_span.end() as usize)
            else {
                continue;
            };
            if body_text.trim().is_empty() {
                continue;
            }
            let Some(params_text) =
                source.get(elems.params.start() as usize..elems.params.end() as usize)
            else {
                continue;
            };
            let lambda_param_defs = crate::signature_scan::params::parse_param_list(
                params_text,
                tcl_syntax::word_rules::WordValueRules::from_config(&ctx.config),
            );
            let lambda_param_names: Vec<&str> =
                lambda_param_defs.iter().map(|p| p.name.as_str()).collect();
            if lambda_param_names.is_empty() {
                continue;
            }
            let lambda_source = ctx.source_slice(body_text, body_span.start());
            if ctx.executed_source.is_some() && lambda_source.is_none() {
                continue;
            }
            let lambda_traits = infer_param_traits_deep_at_depth(
                &lambda_param_names,
                body_text,
                TraitScanEnv {
                    surface: ctx.surface,
                    config: ctx.config,
                    identities: ctx.identities,
                    executed_source: lambda_source.as_ref(),
                },
                depth + 1,
            );
            if lambda_traits.is_empty() {
                continue;
            }
            for (param_name, outer_param) in
                lambda_input_bindings(view.as_deref(), idx, &lambda_param_defs, &values)
            {
                if let Some(lambda_param_traits) = lambda_traits.get(&param_name) {
                    traits
                        .entry(outer_param)
                        .or_default()
                        .extend(lambda_param_traits.iter().copied());
                }
            }
        }
    }
}

/// Only an ordinary value binding forwards the original outer input. Defaults,
/// variadic list construction and Jim caller links have different value owners.
fn lambda_input_bindings<'p>(
    view: Option<&crate::registry_invocation::InvocationBodyAssistance>,
    lambda: usize,
    parameters: &[crate::signature_scan::types::ParamDef],
    values: &ArgumentValues<'p>,
) -> Vec<(String, &'p str)> {
    use tcl_syntax::formal_params::{
        FormalArgumentBinding, FormalParameter, bind_formal_arguments,
    };
    let Some(selected) = view.and_then(|view| view.caller_name_template_invocation()) else {
        return Vec::new();
    };
    let Some(grammar) = selected
        .dialect
        .and_then(tcl_registry::InvocationDialect::parameter_grammar)
    else {
        return Vec::new();
    };
    let Some(lambda) = (0..selected.arguments.len())
        .find(|index| selected.effective.written_argument(*index) == Some(lambda))
    else {
        return Vec::new();
    };
    let formals: Vec<_> = parameters
        .iter()
        .map(|parameter| FormalParameter {
            name: parameter.name.clone(),
            default: parameter.default_value.clone(),
        })
        .collect();
    let Ok(plan) = bind_formal_arguments(
        &formals,
        selected.arguments.len().saturating_sub(lambda + 1),
        grammar,
    ) else {
        return Vec::new();
    };
    plan.into_iter()
        .filter_map(|binding| {
            let FormalArgumentBinding::Value {
                parameter,
                argument,
            } = binding
            else {
                return None;
            };
            let original = selected.effective.written_argument(lambda + 1 + argument)?;
            Some((formals[parameter].name.clone(), values.argument(original)?))
        })
        .collect()
}

fn scan_deep_body<'p>(
    body_text: &str,
    token: &tcl_lexer::Token,
    ctx: &ScanCtx<'p, '_>,
    traits: &mut HashMap<&'p str, HashSet<ProcArgTrait>>,
    aliases: &Aliases<'p>,
    depth: u8,
) {
    if body_text.trim().is_empty() {
        return;
    }
    let head = body_text.as_bytes();
    if head
        .first()
        .is_some_and(|&byte| byte == b'$' || byte == b'[')
        || head
            .get(1)
            .is_some_and(|&byte| byte == b'$' || byte == b'[')
    {
        return;
    }
    let nested = ctx.nested(token, body_text);
    scan_deep(body_text, &nested, traits, &mut aliases.clone(), depth + 1);
}

/// A whole original scalar substitution, including one inside quotes.
fn original_scalar_reference_name(word: &tcl_lexer::NativeWord) -> Option<&str> {
    if word.group().expand {
        return None;
    }
    let arena = word.executable_parts();
    let [component] = arena.list(arena.root()) else {
        return None;
    };
    let tcl_lexer::ExecutablePart::Variable { index: None, .. } = component.part else {
        return None;
    };
    let spelling = std::str::from_utf8(arena.bytes(component.span)?).ok()?;
    tcl_syntax::naming::whole_scalar_variable_reference_name(spelling, word.config())
}

fn original_reference_components(
    word: &tcl_lexer::NativeWord,
    registry: &CommandRegistry,
    scanner: &mut crate::var_refs::VarReferenceScanner,
) -> Vec<String> {
    use tcl_lexer::ExecutablePart;
    let arena = word.executable_parts();
    let mut names = Vec::new();
    for component in arena.all_parts() {
        match component.part {
            ExecutablePart::Variable { name, .. } => {
                if let Some(name) = arena
                    .bytes(name)
                    .and_then(|name| std::str::from_utf8(name).ok())
                {
                    names.push(
                        tcl_syntax::naming::split_element_ref(name)
                            .map_or(name, |(root, _)| root)
                            .to_owned(),
                    );
                }
            }
            ExecutablePart::Command { body } | ExecutablePart::Expression { expression: body } => {
                if let Some(script) = arena
                    .bytes(body)
                    .and_then(|script| std::str::from_utf8(script).ok())
                {
                    names.extend(scanner.scan_lexical_script(script, registry));
                }
            }
            ExecutablePart::Text(_) | ExecutablePart::ParseError(_) => {}
        }
    }
    names
}

/// Trait navigation is a May projection; alias and value-copy state require
/// the separate accepted, definite invocation and original written operands.
fn scan_command<'p>(
    view: Option<&crate::registry_invocation::InvocationBodyAssistance>,
    cmd_args: &[String],
    braced: &[bool],
    values: &ArgumentValues<'p>,
    ctx: &ScanCtx<'p, '_>,
    traits: &mut HashMap<&'p str, HashSet<ProcArgTrait>>,
    aliases: &mut Aliases<'p>,
) {
    if let Some(p) = values.full.first().copied().flatten()
        && let Some(set) = traits.get_mut(p)
    {
        set.insert(ProcArgTrait::Command);
    }
    let Some(view) = view else {
        aliases.clear();
        return;
    };
    if !view.parameter_role_advice().is_closed() {
        aliases.clear();
        apply_arg_role_traits(&view.declared_roles, cmd_args, braced, values, traits);
        return;
    }
    // An unresolved replacement may have no parameter-evaluation grammar.
    // Preserve declaration navigation independently of that execution residual.
    let advice = view.parameter_role_advice();
    apply_arg_role_traits(&advice.written_roles(), cmd_args, braced, values, traits);
    apply_arg_role_traits(&view.declared_roles, cmd_args, braced, values, traits);
    apply_possible_evaluation_traits(advice, cmd_args, braced, values, traits);
    if let Some(selected) = view.parameter_invocation(ctx.parameters) {
        record_selected_aliases(view, selected, values, traits, aliases);
        apply_definite_writes(view, selected, values, traits, aliases);
        if advice.may_execute_body() {
            aliases.clear();
        }
    } else {
        aliases.clear();
    }
}

fn apply_possible_evaluation_traits<'p>(
    advice: &crate::registry_invocation::ParameterRoleAdvice,
    args: &[String],
    braced: &[bool],
    values: &ArgumentValues<'p>,
    traits: &mut HashMap<&'p str, HashSet<ProcArgTrait>>,
) {
    use tcl_registry::Traits;
    for candidate in advice.candidates() {
        for (index, role) in candidate.written_argument_roles() {
            if role == ArgRole::Body
                && !braced.get(index).copied().unwrap_or(false)
                && candidate.possible_traits.intersects(
                    Traits::EVALUATES_CODE | Traits::DYNAMIC_EVAL_BODY | Traits::DEFERS_BODY,
                )
                && let Some(param) = values.argument(index)
                && let Some(set) = traits.get_mut(param)
            {
                set.insert(ProcArgTrait::Eval);
            }
        }
        if candidate
            .possible_traits
            .contains(Traits::SCRIPT_CONCATENATES_ARGS)
            && candidate
                .possible_traits
                .intersects(Traits::EVALUATES_CODE | Traits::DEFERS_BODY)
            && let Some(first) = candidate
                .roles
                .iter()
                .filter_map(|&(index, role)| {
                    (role == ArgRole::Body)
                        .then_some(candidate.argument_offset + usize::from(index))
                })
                .min()
        {
            for effective in first..candidate.effective.words.len() {
                if let Some(index) = candidate.effective.written_argument(effective)
                    && !braced.get(index).copied().unwrap_or(false)
                    && let Some(param) = values.argument(index)
                    && let Some(set) = traits.get_mut(param)
                {
                    set.insert(ProcArgTrait::Eval);
                }
            }
        }
        if candidate
            .possible_traits
            .contains(Traits::PERFORMS_SUBSTITUTION)
        {
            for index in 0..args.len() {
                if braced.get(index).copied().unwrap_or(false) {
                    continue;
                }
                if let Some(param) = values.argument(index)
                    && let Some(set) = traits.get_mut(param)
                {
                    set.insert(ProcArgTrait::Eval);
                }
            }
        }
        if !candidate.possible_traits.contains(Traits::LOOP_LIST_HEADER) {
            continue;
        }
        for &(index, role) in &candidate.roles {
            if role != ArgRole::LoopVarList {
                continue;
            }
            let effective = candidate.argument_offset + usize::from(index) + 1;
            if let Some(param) = candidate
                .effective
                .written_argument(effective)
                .and_then(|original| values.argument(original))
                && let Some(set) = traits.get_mut(param)
            {
                set.insert(ProcArgTrait::LoopList);
            }
        }
    }
}

fn record_selected_aliases<'p>(
    view: &crate::registry_invocation::InvocationBodyAssistance,
    selected: &crate::registry_invocation::ResolvedStatementInvocation,
    values: &ArgumentValues<'p>,
    traits: &mut HashMap<&'p str, HashSet<ProcArgTrait>>,
    aliases: &mut Aliases<'p>,
) {
    let Some((_, first)) = selected_alias_layout(selected) else {
        return;
    };
    for source in (first..selected.arguments.len()).step_by(2) {
        let destination = source + 1;
        let input = selected
            .effective
            .written_argument(source)
            .and_then(|original| values.argument(original));
        if let Some(param) = input
            && let Some(set) = traits.get_mut(param)
        {
            set.insert(ProcArgTrait::VarRead);
        }
        if let Some(param) = selected
            .effective
            .written_argument(destination)
            .and_then(|original| values.argument(original))
            && let Some(set) = traits.get_mut(param)
        {
            mark_dynamic_name_local(set);
        }
        let Some(local) = view.caller_template_literal_data(selected, destination) else {
            aliases.clear();
            continue;
        };
        aliases.value_copies.remove(&local);
        aliases.upvar.remove(&local);
        aliases.retired_inputs.insert(local.clone());
        if let Some(param) = input
            && is_local_scalar_name(&local, selected)
        {
            aliases.upvar.insert(local, param);
        }
    }
}

fn selected_alias_layout(
    selected: &crate::registry_invocation::ResolvedStatementInvocation,
) -> Option<(tcl_registry::frame_effect::FrameLevel, usize)> {
    use tcl_registry::frame_effect::{FrameArgLayout, FrameArgumentResolution, FrameLevel};
    let namespace_alias = selected
        .facts
        .state_transitions
        .declared()
        .into_iter()
        .flat_map(tcl_registry::StateTransitions::facts)
        .filter_map(|fact| match &fact.transition {
            tcl_registry::StateTransition::VariableCellAlias(alias)
                if matches!(
                    alias.target,
                    tcl_registry::VariableAliasTarget::Namespace { .. }
                ) =>
            {
                Some(alias.words.target)
            }
            _ => None,
        })
        .min();
    if let Some(first) = namespace_alias {
        return Some((FrameLevel::Dynamic, first));
    }
    let effect = selected.facts.frame_effect?;
    if effect.layout != FrameArgLayout::AliasPairs {
        return None;
    }
    let words: Vec<_> = selected
        .evaluated_words
        .iter()
        .map(crate::registry_invocation::EffectiveInvocationWord::as_registry_word)
        .collect();
    let arguments =
        tcl_registry::InvocationArguments::structured(&words).with_dialect(selected.dialect?);
    match effect.successful_layout(arguments).layout {
        FrameArgumentResolution::Valid {
            level,
            level_word_len,
        } => Some((level, level_word_len)),
        FrameArgumentResolution::Invalid | FrameArgumentResolution::Unknown => None,
    }
}

fn apply_definite_writes<'p>(
    view: &crate::registry_invocation::InvocationBodyAssistance,
    selected: &crate::registry_invocation::ResolvedStatementInvocation,
    values: &ArgumentValues<'p>,
    traits: &mut HashMap<&'p str, HashSet<ProcArgTrait>>,
    aliases: &mut Aliases<'p>,
) {
    if selected_alias_layout(selected).is_some() {
        return;
    }
    // Freeze the read-side copy before applying this command's writes.
    let copy = (selected.facts.operation
        == tcl_registry::SemanticOperationId::StructuredLowering(
            tcl_registry::hooks::LoweringHookId::Set,
        )
        && selected.arguments.len() == 2)
        .then(|| {
            let target = view.caller_template_literal_data(selected, 0)?;
            if !is_local_scalar_name(&target, selected) {
                return None;
            }
            let param = selected
                .effective
                .written_argument(1)
                .and_then(|index| values.argument(index))?;
            Some((target, param))
        })
        .flatten();
    for (index, role) in selected.written_argument_roles() {
        if role != ArgRole::VarWrite {
            continue;
        }
        let Some(name) = written_template_literal(view, selected, index) else {
            aliases.clear();
            continue;
        };
        if let Some(param) = aliases.upvar.get(name.as_str())
            && let Some(set) = traits.get_mut(param)
        {
            set.insert(ProcArgTrait::VarWrite);
        }
        aliases.value_copies.remove(name.as_str());
        aliases.retired_inputs.insert(name.clone());
    }
    if let Some((target, param)) = copy {
        aliases.value_copies.insert(target, param);
    }
}

/// Per-arg role-driven trait recording — apply
/// ``ArgRole::Body`` / ``Expr`` / ``VarWrite`` / ``VarRead`` to
/// the matching parameter trait set when an arg is a simple
/// ``$param`` reference (or aliases an upvar'd one).
///
/// `braced[i]` is `true` when argument `i` was a braced (`{…}`) literal word,
/// in which case **no substitution occurs**: `set {arr($k)} 1` names the literal
/// variable `arr($k)`, so the `$k` inside must not be read as a substitution.
/// The braced guard applies only to the variable-name
/// roles; a braced `Body` / `Expr` word still substitutes internally when Tcl
/// evaluates it, and the deep pass recurses into it.
fn apply_arg_role_traits<'p>(
    roles: &[(usize, ArgRole)],
    cmd_args: &[String],
    braced: &[bool],
    values: &ArgumentValues<'p>,
    traits: &mut HashMap<&'p str, HashSet<ProcArgTrait>>,
) {
    for idx in 0..cmd_args.len() {
        for role in roles
            .iter()
            .filter_map(|&(index, role)| (index == idx).then_some(role))
        {
            match role {
                // Body / Expr apply only to a bare `$param` (or upvar-aliased) word:
                // the whole argument *is* the param's value, evaluated as a script /
                // expression.
                ArgRole::Body => {
                    if let Some(p) = values.argument(idx)
                        && let Some(set) = traits.get_mut(p)
                    {
                        set.insert(ProcArgTrait::Body);
                    }
                }
                ArgRole::Expr => {
                    if let Some(p) = values.argument(idx)
                        && let Some(set) = traits.get_mut(p)
                    {
                        set.insert(ProcArgTrait::Expr);
                    }
                }
                // A registry / stub `VarWrite` / `VarRead` role names a variable.
                // Every param whose value flows into that name — the whole `$p`, or
                // a `$p` component of a compound dynamic name (`${p}($k)`,
                // `$p($k)`) — names a CALLEE-LOCAL variable (`set $p 1`,
                // `set ${v}($k)`, `incr $p`), NOT a caller-frame alias.  Record the
                // callee-local refinement (never `VarWrite`; only an `upvar`-aliased
                // write-back is a genuine caller write).  A braced word is a literal
                // name — no substitution — so no param flows into it.
                ArgRole::VarWrite | ArgRole::VarRead
                    if !braced.get(idx).copied().unwrap_or(false) =>
                {
                    for p in values.argument_components(idx) {
                        if let Some(set) = traits.get_mut(p) {
                            mark_dynamic_name_local(set);
                        }
                    }
                }
                // A registry / stub `CommandPrefix` role names a command — a callback
                // command prefix (`tcltest::customMatch`, `selection handle`, a stub
                // `:command_prefix` arg).  A `$param` (or component of a dynamic
                // name) flowing there means the param's value is a command name.
                // Braced words are literal — no substitution.
                ArgRole::CommandPrefix if !braced.get(idx).copied().unwrap_or(false) => {
                    for p in values.argument_components(idx) {
                        if let Some(set) = traits.get_mut(p) {
                            set.insert(ProcArgTrait::Command);
                        }
                    }
                }
                _ => {}
            }
        }
    }
}

/// Map a substituted name to a parameter value, directly or through an
/// accepted value copy. An upvar's contents belong to the referenced cell;
/// they are not the parameter string that named that cell.
fn lookup_param<'p>(
    var_name: &str,
    param_set: &HashSet<&'p str>,
    aliases: &Aliases<'p>,
) -> Option<&'p str> {
    aliases.value_copies.get(var_name).copied().or_else(|| {
        (aliases.direct_inputs_known && !aliases.retired_inputs.contains(var_name))
            .then(|| param_set.get(var_name).copied())
            .flatten()
    })
}

/// Record the callee-local dynamic-name use of a param — its **value**
/// is used as a variable *name* in the proc's own scope (``set $p 1``,
/// ``scan $s %d $p``, ``lassign $l $p``, ``regsub … $p``).  Emits
/// [`ProcArgTrait::DynamicNameLocal`] (the refinement that stops
/// caller-side dead-store / unused-variable suppression from treating
/// the call site as consuming the caller's variable) plus
/// [`ProcArgTrait::VarRead`] (the param's string *is* read).  Never
/// `VarWrite` — only an ``upvar``-aliased write-back is a genuine
/// caller-frame write.
fn mark_dynamic_name_local(set: &mut HashSet<ProcArgTrait>) {
    set.insert(ProcArgTrait::DynamicNameLocal);
    set.insert(ProcArgTrait::VarRead);
}

/// The parameters whose **value names a variable in the immediate caller's
/// frame** — `upvar 1 $param local` and its default-level spelling `upvar
/// $param local`, and nothing else.
///
/// This symbolic layout is conditional on entry to the retained declaration.
/// It names no caller cell and grants no read, store or successful activation.
/// Call-site navigation selects the actual callee and argument independently.
/// It is strictly narrower
/// than [`ProcArgTrait::VarWrite`] / [`ProcArgTrait::VarRead`], which record
/// only *that* a parameter's value is used as a variable name through an
/// `upvar`, never *which frame* the alias lands in.  Every other level names a
/// different frame, pinned identical on tclsh 9.0.4 and 8.6.14:
///
/// | callee body | `p x` from a proc writes … |
/// |---|---|
/// | `upvar 1 $n a; set a 1` | the caller's `x` |
/// | `upvar 0 $n a; set a 1` | the **callee's own** `x` — caller's `x` never exists |
/// | `upvar #0 $n a; set a 1` | the **global** `::x` |
/// | `upvar 2 $n a; set a 1` | the caller's **caller** — the immediate caller is skipped |
///
/// `namespace upvar ns $token local` is deliberately absent too: it aliases a
/// *namespace* variable, so a call site passing `token` creates nothing in the
/// calling frame either.
///
/// Only the top-level command scan is walked, matching the shallow trait pass
/// exactly — a consumer that requires both facts is then never widened by a
/// disagreement between them, only narrowed.
#[must_use]
pub fn caller_frame_upvar_params(
    params: &[&str],
    body_source: &str,
    env: TraitScanEnv<'_>,
) -> HashSet<String> {
    let mut out = HashSet::new();
    if params.is_empty() || body_source.trim().is_empty() || !env.matches_source(body_source) {
        return out;
    }
    let param_set: HashSet<&str> = params.iter().copied().collect();
    let ctx = ScanCtx {
        param_set: &param_set,
        parameters: params,
        surface: env.surface,
        config: env.config,
        identities: env.identities,
        executed_source: env.executed_source,
        source_base: env
            .executed_source
            .map(crate::command_binding::ExecutedScriptSource::base),
    };
    for seg in &segment_commands_with_offset_and_config(body_source, 0, env.config.nested()) {
        let Some(view) = ctx.body_assistance(body_source, seg) else {
            continue;
        };
        let Some(selected) = view.parameter_invocation(params) else {
            continue;
        };
        let Some((level, first)) = selected_alias_layout(selected) else {
            continue;
        };
        if !level.is_caller_frame() {
            continue;
        }
        let values = ctx.argument_values(body_source, seg, &Aliases::default());
        for source in (first..selected.arguments.len()).step_by(2) {
            if let Some(param) = selected
                .effective
                .written_argument(source)
                .and_then(|original| values.argument(original))
            {
                out.insert(param.to_owned());
            }
        }
    }
    out
}

/// The **literal caller-frame targets** a proc body binds through `upvar` —
/// caller-frame names the callee spells in its *own* text, with no call-site
/// argument word to key on (`upvar 1 name name`).  Returns
/// `caller_name → written-through-alias`.
///
/// Strictly the complement of [`caller_frame_upvar_params`]: that fact keys
/// on a `$param` **source** (the name arrives from the call site); this one
/// keys on a *literal* source (the name is fixed by the callee).  tclsh
/// 9.0.4 / 8.6.14, identical: with `proc np {} {upvar name name; set name
/// W1}`, a caller running `np; puts $name` prints `W1` — `name` exists in
/// the caller's frame although the caller never assigns it and no call-site
/// word spells it.
///
/// This is an owned callee template, conditional on its entry and normal alias
/// operations. It identifies no actual caller cell and proves no completed
/// write. Navigation instantiates it only with a separate original
/// call/allocation/frame receipt; execution and value consumers use actual
/// source access and continuation proofs instead.
///
/// Exclusions, each the abstaining direction:
///
/// * a non-caller frame level (`upvar 0` / `#0` / `2` / `$lvl`) — a
///   different frame entirely, see [`caller_frame_upvar_params`]'s table;
/// * a `::`-qualified source (`upvar 1 ::ns::x local`) — a fixed global/
///   namespace cell, level-independent, already linked by the analyser's
///   alias consumer (`apply_state_transitions`) `otherVar` link;
/// * an array element or any substituted/computed source — not a plain
///   caller-frame scalar name this scan can claim;
/// * a dynamic **local** side — with no alias name, the write-through scan
///   below has nothing to match, so the pair contributes nothing here (the
///   compiler-side summary still widens the call site).
///
/// The write-through upgrade mirrors [`record_upvar_pairs`]'s rule for
/// params: a later registry-declared `VarWrite` on the alias local (`set
/// name …`, `lassign … name`) marks the caller name as *created* by a call;
/// an alias only ever read leaves it `false` (a referencing call site, not a
/// creating one).  Only the top-level command scan is walked, matching the
/// shallow trait pass exactly.
#[must_use]
pub fn caller_frame_literal_targets(
    body_source: &str,
    env: TraitScanEnv<'_>,
) -> HashMap<String, bool> {
    if !env.matches_source(body_source) {
        return HashMap::new();
    }
    let params = HashSet::new();
    let ctx = ScanCtx {
        param_set: &params,
        parameters: &[],
        surface: env.surface,
        config: env.config,
        identities: env.identities,
        executed_source: env.executed_source,
        source_base: env
            .executed_source
            .map(crate::command_binding::ExecutedScriptSource::base),
    };
    let mut targets = HashMap::new();
    if body_source.trim().is_empty() || !env.matches_source(body_source) {
        return targets;
    }
    let mut alias_to_target = HashMap::new();
    for seg in &segment_commands_with_offset_and_config(body_source, 0, env.config.nested()) {
        let Some(view) = ctx.body_assistance(body_source, seg) else {
            continue;
        };
        let Some(selected) = view.caller_name_template_invocation() else {
            continue;
        };
        if let Some((level, first)) = selected_alias_layout(selected) {
            if !level.is_caller_frame() {
                continue;
            }
            for source in (first..selected.arguments.len()).step_by(2) {
                let (Some(name), Some(local)) = (
                    view.caller_template_literal_data(selected, source),
                    view.caller_template_literal_data(selected, source + 1),
                ) else {
                    continue;
                };
                if is_local_scalar_name(&name, selected) && is_local_scalar_name(&local, selected) {
                    targets.entry(name.clone()).or_insert(false);
                    alias_to_target.insert(local, name);
                }
            }
            continue;
        }
        for (index, role) in selected.written_argument_roles() {
            if role != ArgRole::VarWrite {
                continue;
            }
            if let Some(name) = written_template_literal(&view, selected, index)
                && let Some(caller_name) = alias_to_target.get(&name)
            {
                targets.insert(caller_name.clone(), true);
            }
        }
    }
    targets
}

#[cfg(test)]
mod tests {
    use super::*;
    use tcl_registry::CommandRegistry;

    fn assert_trait(
        traits: &HashMap<String, HashSet<ProcArgTrait>>,
        param: &str,
        expected: ProcArgTrait,
    ) {
        let set = traits
            .get(param)
            .unwrap_or_else(|| panic!("no traits for {param}"));
        assert!(
            set.contains(&expected),
            "{param}: expected {expected:?}, got {set:?}",
        );
    }

    /// Retain an uncalled declaration with its exact formals and body source.
    /// Successful own-body advice requires this receipt; no caller is invented.
    fn infer(params: &[&str], body: &str) -> HashMap<String, HashSet<ProcArgTrait>> {
        infer_owned(params, body, false)
    }

    fn infer_owned(
        params: &[&str],
        body: &str,
        deep: bool,
    ) -> HashMap<String, HashSet<ProcArgTrait>> {
        let registry = CommandRegistry::build_default();
        let formals = tcl_syntax::list::join_list(params);
        let source = tcl_syntax::list::join_list(["proc", "__trait_probe", &formals, body]);
        let identities = crate::realm::document_realm_bindings(
            &source,
            tcl_dialect::DialectProfile::find("tcl9.0").unwrap(),
            &registry,
        );
        let command = segment_commands_with_offset_and_config(&source, 0, LexerConfig::default())
            .pop()
            .unwrap();
        let script = identities
            .executed_script_for_word(command.argv.last().unwrap().span)
            .unwrap();
        assert_eq!(script.text.try_text().unwrap(), body);
        let env = TraitScanEnv {
            surface: DocumentCommandSurface::new(&registry, None),
            config: LexerConfig::default(),
            identities: &identities,
            executed_source: Some(script),
        };
        if deep {
            infer_param_traits_deep(params, body, env)
        } else {
            infer_param_traits(params, body, env)
        }
    }

    #[test]
    fn original_parameter_scans_keep_parent_input_and_nested_body_bom() {
        // naming.source.original-configured-script-completeness
        // docs/design/analysis/name-resolution-proofs/source-original-configured-script-completeness.md
        // Conditional own-body/caller-name advice only; no entered caller or alias link.
        let mut prepared = crate::analyser::Analyser::new();
        let input = prepared.prepare_analysis_input("tcl9.1").unwrap();
        for bom in [tcl_lexer::LeadingBom::Skip, tcl_lexer::LeadingBom::Content] {
            let mut supplied = input.clone();
            supplied.config.leading_bom = bom;
            supplied.config.braced_var = tcl_lexer::BracedVarStyle::FirstClose;
            for per_item in [false, true] {
                let mut analyser =
                    crate::analyser::Analyser::new().with_resolved_input(supplied.clone());
                let source =
                    "proc p {body name} {upvar 1 $name local; set local VALUE; eval $body}";
                let result = if per_item {
                    analyser.analyse_per_item(source, "display-only")
                } else {
                    analyser.analyse(source, "display-only")
                };
                assert_eq!(result.resolved_input.as_ref(), Some(&supplied));
                let procedure = result
                    .all_procs
                    .get("::p")
                    .expect("genuine original procedure");
                assert_trait(&procedure.param_traits, "body", ProcArgTrait::Eval);
                assert!(procedure.caller_frame_params.contains("name"));

                // The original order first evaluates an unknown script. Its
                // later upvar cannot acquire the preceding positive's selection.
                let mut analyser =
                    crate::analyser::Analyser::new().with_resolved_input(supplied.clone());
                let source =
                    "proc p {body name} {eval $body; upvar 1 $name local; set local VALUE}";
                let result = if per_item {
                    analyser.analyse_per_item(source, "display-only")
                } else {
                    analyser.analyse(source, "display-only")
                };
                assert_eq!(result.resolved_input.as_ref(), Some(&supplied));
                let procedure = result
                    .all_procs
                    .get("::p")
                    .expect("original unknown-eval procedure");
                assert_trait(&procedure.param_traits, "body", ProcArgTrait::Eval);
                assert!(procedure.caller_frame_params.is_empty());

                let mut analyser =
                    crate::analyser::Analyser::new().with_resolved_input(supplied.clone());
                let source = "proc p {body name} {\u{feff}eval $body; \u{feff}upvar 1 $name local; set local VALUE}";
                let result = if per_item {
                    analyser.analyse_per_item(source, "display-only")
                } else {
                    analyser.analyse(source, "display-only")
                };
                let procedure = result
                    .all_procs
                    .get("::p")
                    .expect("genuine original procedure");
                assert!(
                    !procedure
                        .param_traits
                        .get("body")
                        .is_some_and(|traits| traits.contains(&ProcArgTrait::Eval))
                );
                assert!(procedure.caller_frame_params.is_empty());
            }
        }
    }

    #[test]
    fn replaced_formal_does_not_represent_its_incoming_value() {
        let replaced = infer(&["body"], "set body {}; eval $body");
        assert!(
            !replaced
                .get("body")
                .is_some_and(|traits| traits.contains(&ProcArgTrait::Eval))
        );
        let copied = infer(&["body"], "set local $body; set body {}; eval $local");
        assert!(
            copied
                .get("body")
                .is_some_and(|traits| traits.contains(&ProcArgTrait::Eval))
        );
    }

    #[test]
    fn callback_mutations_follow_the_actual_selected_cell() {
        let helper = "proc replace {name} {upvar 1 $name local; set local {}};";
        let replaced = infer(
            &["body"],
            &format!("{helper} set local $body; replace local; eval $local"),
        );
        assert!(
            !replaced
                .get("body")
                .is_some_and(|traits| traits.contains(&ProcArgTrait::Eval))
        );
        let untouched = infer(
            &["body"],
            &format!("{helper} set local $body; replace body; eval $local"),
        );
        assert!(
            untouched
                .get("body")
                .is_some_and(|traits| traits.contains(&ProcArgTrait::Eval))
        );
    }

    #[test]
    fn iteration_binding_retires_the_original_formal_input() {
        let replaced = infer_owned(&["body"], "foreach body {{}} {eval $body}", true);
        assert!(
            !replaced
                .get("body")
                .is_some_and(|traits| traits.contains(&ProcArgTrait::Eval))
        );
        let untouched = infer_owned(&["body"], "foreach other {{}} {eval $body}", true);
        assert!(
            untouched
                .get("body")
                .is_some_and(|traits| traits.contains(&ProcArgTrait::Eval))
        );
    }

    #[test]
    fn original_formal_reads_preserve_literal_variable_names() {
        for (name, reference) in [("a$b", "${a$b}"), ("1", "$1"), ("é", "${é}")] {
            let body = format!("eval {reference}");
            let result = infer(&[name], &body);
            assert!(
                result
                    .get(name)
                    .is_some_and(|traits| traits.contains(&ProcArgTrait::Eval)),
                "{name:?}: {result:?}"
            );
        }
    }

    #[test]
    fn nested_command_reads_do_not_name_the_outer_argument() {
        let result = infer(&["body"], "set [string length $body] 1");
        assert!(
            !result
                .get("body")
                .is_some_and(|traits| traits.contains(&ProcArgTrait::DynamicNameLocal))
        );
    }

    /// A scan environment over `registry` with no document declarations and
    /// no document binding facts — what a bare-body unit test scans under.
    fn env_for(registry: &CommandRegistry, config: LexerConfig) -> TraitScanEnv<'_> {
        TraitScanEnv {
            surface: DocumentCommandSurface::new(registry, None),
            config,
            executed_source: None,
            identities: if registry.profile().is_some() {
                crate::realm::CommandBindingRealm::none()
            } else {
                static ENTRY: std::sync::OnceLock<crate::realm::CommandBindingRealm> =
                    std::sync::OnceLock::new();
                ENTRY.get_or_init(|| {
                    crate::realm::document_realm_bindings(
                        "",
                        tcl_dialect::DialectProfile::find("tcl9.0").expect("test native core"),
                        tcl_registry::default_registry(),
                    )
                })
            },
        }
    }

    /// [`env_for`] with the document's own declarations attached.
    fn env_with_declarations<'a>(
        registry: &'a CommandRegistry,
        declared: &'a tcl_registry::model::DeclaredSurface,
    ) -> TraitScanEnv<'a> {
        TraitScanEnv {
            surface: DocumentCommandSurface::new(registry, Some(declared)),
            ..env_for(registry, LexerConfig::default())
        }
    }

    fn lexical_reference_values<'p>(
        source_word: &str,
        parameters: &[&'p str],
        config: LexerConfig,
    ) -> ArgumentValues<'p> {
        let registry = CommandRegistry::build_default();
        let source = format!("command {source_word}");
        let commands = segment_commands_with_offset_and_config(&source, 0, config);
        assert_eq!(commands.len(), 1);
        let parameters = parameters.iter().copied().collect();
        ArgumentValues::lexical(
            &source,
            &commands[0],
            &parameters,
            &Aliases::default(),
            config,
            &registry,
        )
    }

    #[test]
    fn extract_var_name_simple() {
        let parameters = ["foo", "1abc"];
        let whole = |source| {
            lexical_reference_values(source, &parameters, LexerConfig::default()).argument(0)
        };
        assert_eq!(whole("$foo"), Some("foo"));
        assert_eq!(whole("${foo}"), Some("foo"));
        assert_eq!(whole("foo"), None);
        assert_eq!(whole("$"), None);
        assert_eq!(whole("$1abc"), Some("1abc"));
    }

    #[test]
    fn eval_param_records_eval_trait() {
        let traits = infer(&["body"], "eval $body");
        assert_trait(&traits, "body", ProcArgTrait::Eval);
    }

    /// The *deep* pass
    /// (`infer_param_traits_deep`, which alone recurses into braced body
    /// arguments) must reach real commands *inside* an `apply` lambda body,
    /// not misread the whole `{argList} {body}` blob as one script (which
    /// would treat the parameter word as a command name and never find the
    /// `eval` at all) — mirrors `declarations_deep_recurse_through_declared_body_args`,
    /// swapping the registry-known `apply`/`LambdaLiteral` shape in for a
    /// stub-declared `Body` shape. The lambda's own param is `x`, bound to
    /// the literal `1` — an enclosing `body` param is neither the lambda's
    /// param nor forwarded into the call, so it must record nothing: a lambda
    /// body runs in a fresh frame, and a same-named enclosing param is not
    /// implicitly in scope there.
    #[test]
    fn eval_inside_apply_lambda_body_does_not_leak_to_unrelated_enclosing_param() {
        let registry = CommandRegistry::build_default();
        let traits = infer_param_traits_deep(
            &["body"],
            "apply {x {eval $body}} 1",
            env_for(&registry, LexerConfig::default()),
        );
        assert!(
            !traits
                .get("body")
                .is_some_and(|s| s.contains(&ProcArgTrait::Eval)),
            "an apply lambda's fresh frame must not leak a same-named \
             enclosing param's trait when that param is never forwarded \
             into the call; got {traits:?}"
        );
    }

    /// The real forwarding case: the lambda's own param `x` is `eval`'d
    /// inside its body, and the enclosing `body` param is passed as the
    /// actual argument that binds to `x` — so `body`'s value genuinely does
    /// flow into an `eval`, and the trait must propagate back to it.
    #[test]
    fn eval_param_forwarded_into_apply_lambda_records_eval_trait() {
        let registry = CommandRegistry::build_default();
        let traits = infer_param_traits_deep(
            &["body"],
            "apply {x {eval $x}} $body",
            env_for(&registry, LexerConfig::default()),
        );
        assert_trait(&traits, "body", ProcArgTrait::Eval);
    }

    #[test]
    fn trait_inference_is_dialect_aware_via_expand_syntax() {
        // `extract_commands` / `scan_deep` re-segment under the document
        // dialect, so the body's `{*}` is the expansion operator on 8.5+
        // but a literal brace word on 8.4.  `eval {*}$p` is therefore
        // `eval $p` (→ `p` is Eval) on 9.0 but `eval` of the single
        // composite word `{*}$p` (no clean `$p`, no trait) on 8.4.
        let registry = CommandRegistry::build_default();
        let on = infer_param_traits(
            &["p"],
            "eval {*}$p",
            env_for(&registry, LexerConfig::default()),
        );
        assert!(
            on.get("p").is_some_and(|s| s.contains(&ProcArgTrait::Eval)),
            "9.0 expands `{{*}}` → eval $p → Eval: {on:?}",
        );
        let off = infer_param_traits(
            &["p"],
            "eval {*}$p",
            env_for(&registry, LexerConfig::for_dialect("tcl8.4")),
        );
        assert!(
            off.get("p")
                .is_none_or(|s| !s.contains(&ProcArgTrait::Eval)),
            "8.4 treats `{{*}}` as literal → no clean $p → no Eval: {off:?}",
        );
    }

    #[test]
    fn uplevel_records_eval_on_last_arg_only() {
        let traits = infer(&["lvl", "script"], "uplevel $lvl $script");
        assert_trait(&traits, "script", ProcArgTrait::Eval);
        assert!(
            !traits
                .get("lvl")
                .is_some_and(|s| s.contains(&ProcArgTrait::Eval))
        );
    }

    /// Eval follows the registry's evaluation traits: every word of a script
    /// that concatenates its arguments (`uplevel 1 $a $b` runs `$a $b`), a
    /// script word of any evaluating command, and a `::`-rooted spelling.
    #[test]
    fn eval_reads_the_registry_evaluation_traits() {
        let traits = infer(&["a", "b"], "uplevel 1 $a $b");
        assert_trait(&traits, "a", ProcArgTrait::Eval);
        assert_trait(&traits, "b", ProcArgTrait::Eval);
        assert_trait(
            &infer(&["s"], "namespace eval ::ns $s"),
            "s",
            ProcArgTrait::Eval,
        );
        assert_trait(&infer(&["s"], "::eval $s"), "s", ProcArgTrait::Eval);
    }

    /// Both trackers read the `VarWrite` role: any write of an `upvar` alias
    /// writes the caller's variable, a read through it does not, and any write
    /// of a local ends the parameter value it carried.
    #[test]
    fn the_copy_trackers_read_the_var_write_role() {
        assert_trait(
            &infer(&["v"], "upvar 1 $v arr\narray set arr {k 1}"),
            "v",
            ProcArgTrait::VarWrite,
        );
        let traits = infer(&["v"], "upvar 1 $v local\nreturn [set local]");
        assert!(!traits["v"].contains(&ProcArgTrait::VarWrite), "{traits:?}");
        assert!(!infer(&["v"], "set n $v\nlassign {x} n\nset $n 1").contains_key("v"));
    }

    #[test]
    fn foreach_records_loop_list_and_body() {
        let traits = infer(&["items", "body"], "foreach x $items $body");
        assert_trait(&traits, "items", ProcArgTrait::LoopList);
        assert_trait(&traits, "body", ProcArgTrait::Body);
    }

    #[test]
    fn while_records_expr_and_body() {
        let traits = infer(&["cond", "body"], "while $cond $body");
        assert_trait(&traits, "cond", ProcArgTrait::Expr);
        assert_trait(&traits, "body", ProcArgTrait::Body);
    }

    #[test]
    fn for_records_init_cond_next_body() {
        let traits = infer(&["i", "c", "n", "b"], "for $i $c $n $b");
        assert_trait(&traits, "i", ProcArgTrait::Body);
        assert_trait(&traits, "c", ProcArgTrait::Expr);
        assert_trait(&traits, "n", ProcArgTrait::Body);
        assert_trait(&traits, "b", ProcArgTrait::Body);
    }

    #[test]
    fn upvar_records_var_read_and_aliases_writes() {
        let traits = infer(&["var"], "upvar 1 $var local\nset local 1");
        assert_trait(&traits, "var", ProcArgTrait::VarRead);
        // Write through the alias upgrades to VarWrite.
        assert_trait(&traits, "var", ProcArgTrait::VarWrite);
    }

    /// The frame level the trait map cannot record.  Pinned against tclsh
    /// 9.0.4 and 8.6.14 (byte-identical): with `proc q {n} {upvar L $n a; set
    /// a 1}` called as `q y` from a proc, the caller's `y` exists afterwards
    /// only for `L` = `1` (or an omitted level).  `0` aliases the callee's
    /// own frame, `#0` the global one, `2` the caller's caller.
    #[test]
    fn caller_frame_upvar_params_accepts_only_the_caller_frame_level() {
        let registry = CommandRegistry::build_default();
        let params = ["n"];
        for (body, expected) in [
            ("upvar 1 $n a; set a 1", true),
            ("upvar $n a; set a 1", true),
            ("upvar +1 $n a", true),
            ("upvar 0x1 $n a", true),
            ("upvar 0 $n a; set a 1", false),
            ("upvar #0 $n a; set a 1", false),
            ("upvar 2 $n a; set a 1", false),
            ("upvar -1 $n a", false),
            ("upvar $lvl $n a", false),
            ("upvar bogus $n a", false),
            // `namespace upvar` aliases a namespace variable, never the
            // calling frame.
            ("namespace upvar ::cfg $n a", false),
            // The `myVar` slot names a callee-local alias, not a caller
            // variable.
            ("upvar 1 caller $n", false),
        ] {
            let got = caller_frame_upvar_params(
                &params,
                body,
                env_for(&registry, LexerConfig::default()),
            );
            assert_eq!(
                got.contains("n"),
                expected,
                "{body:?} -> {got:?} (expected caller-frame param: {expected})"
            );
        }
    }

    /// The literal-target fact — `upvar 1 name name` binds the
    /// caller's `name`, written through the alias when the body assigns it.
    /// tclsh 9.0.4: `proc np {} {upvar name name; set name W1}` then
    /// `np; puts $name` prints `W1` in the caller.
    #[test]
    fn caller_frame_literal_targets_records_written_and_read_only() {
        let registry = CommandRegistry::build_default();
        let got = caller_frame_literal_targets(
            "upvar name name\nset name W1",
            env_for(&registry, LexerConfig::default()),
        );
        assert_eq!(got.get("name"), Some(&true), "written through the alias");
        // A body that only reads through the alias creates nothing.
        let got = caller_frame_literal_targets(
            "upvar name name\nreturn [string length $name]",
            env_for(&registry, LexerConfig::default()),
        );
        assert_eq!(got.get("name"), Some(&false), "read-only alias");
        // Distinct local alias spelling still records the CALLER name.
        let got = caller_frame_literal_targets(
            "upvar 1 other mine\nset mine 1",
            env_for(&registry, LexerConfig::default()),
        );
        assert_eq!(got.get("other"), Some(&true));
        assert!(!got.contains_key("mine"));
    }

    /// The exclusions: non-caller levels, `::`-qualified cells, array
    /// elements, substituted sources, dynamic locals, `namespace upvar`.
    #[test]
    fn caller_frame_literal_targets_excludes_other_frames_and_cells() {
        let registry = CommandRegistry::build_default();
        for body in [
            "upvar 0 name name; set name 1",
            "upvar #0 name name; set name 1",
            "upvar 2 name name; set name 1",
            "upvar $lvl name name; set name 1",
            "upvar 1 ::tk::FocusGrab($i) data; set data 1",
            "upvar 1 ::ns::cell local; set local 1",
            "upvar 1 arr(k) local; set local 1",
            "upvar 1 $src local; set local 1",
            "upvar 1 name $dst",
            "namespace upvar ::cfg name local; set local 1",
        ] {
            let got =
                caller_frame_literal_targets(body, env_for(&registry, LexerConfig::default()));
            assert!(got.is_empty(), "{body:?} must record nothing, got {got:?}");
        }
    }

    /// The fact is strictly narrower than the trait: `upvar 0 $n a; set a 1`
    /// still records `VarWrite` (the parameter's value *is* used as a
    /// variable name through an `upvar`) while contributing no caller-frame
    /// parameter — which is exactly why a call-site consumer must intersect
    /// the two.
    #[test]
    fn caller_frame_params_is_narrower_than_the_var_traits() {
        let registry = CommandRegistry::build_default();
        let body = "upvar 0 $n a; set a 1";
        let traits = infer(&["n"], body);
        assert_trait(&traits, "n", ProcArgTrait::VarWrite);
        assert!(
            caller_frame_upvar_params(&["n"], body, env_for(&registry, LexerConfig::default()))
                .is_empty(),
            "the level fact must reject what the trait alone accepts"
        );
    }

    /// `upvar $lvl a b` has three words, so parity puts `$lvl` in the level
    /// slot and `(a, b)` in the pair slot — the level is unplaceable, so no
    /// caller-frame parameter is claimed, while the *pair* handling (and hence
    /// the trait map) still applies.
    #[test]
    fn dynamic_level_word_keeps_parity_pairing_but_claims_no_frame() {
        let registry = CommandRegistry::build_default();
        let traits = infer(&["lvl", "v"], "upvar $lvl $v local\nset local 1");
        assert_trait(&traits, "v", ProcArgTrait::VarWrite);
        assert!(
            caller_frame_upvar_params(
                &["lvl", "v"],
                "upvar $lvl $v local\nset local 1",
                env_for(&registry, LexerConfig::default())
            )
            .is_empty(),
            "a computed level names no statically-known frame"
        );
    }

    #[test]
    fn upvar_my_var_slot_param_is_callee_local_not_var_write() {
        // `upvar 1 caller $local` — the param in the `myVar` slot names the
        // *callee-local* alias, not a caller variable, so it is a
        // `DynamicNameLocal` use, never a caller-frame `VarWrite`.
        let traits = infer(&["local"], "upvar 1 caller $local");
        assert_trait(&traits, "local", ProcArgTrait::DynamicNameLocal);
        assert!(
            !traits
                .get("local")
                .unwrap()
                .contains(&ProcArgTrait::VarWrite),
            "myVar-slot param must not be a caller VarWrite; got {:?}",
            traits.get("local"),
        );
    }

    #[test]
    fn lassign_records_dynamic_name_local() {
        // `lassign {1 2} $a $b` names CALLEE-LOCAL output vars via the
        // params' values — DynamicNameLocal (+ VarRead), NOT VarWrite
        // (which would imply a caller-frame alias).
        let traits = infer(&["a", "b"], "lassign {1 2} $a $b");
        for p in ["a", "b"] {
            assert_trait(&traits, p, ProcArgTrait::DynamicNameLocal);
            assert_trait(&traits, p, ProcArgTrait::VarRead);
            assert!(
                !traits.get(p).unwrap().contains(&ProcArgTrait::VarWrite),
                "{p}: callee-local lassign target must not be VarWrite, got {:?}",
                traits.get(p),
            );
        }
    }

    #[test]
    fn command_substitution_is_scanned() {
        // A param used inside a `[...]` substitution is a first-order use — the
        // shallow scan must descend into it.  `return [set $v 1]` names a
        // callee-local variable via `$v` → DynamicNameLocal (+ VarRead).
        let traits = infer(&["v"], "return [set $v 1]");
        assert_trait(&traits, "v", ProcArgTrait::DynamicNameLocal);
        assert_trait(&traits, "v", ProcArgTrait::VarRead);
        // The read form (single-arg `set`) is scanned identically.
        let traits = infer(&["v"], "return [set $v]");
        assert_trait(&traits, "v", ProcArgTrait::DynamicNameLocal);
    }

    #[test]
    fn command_substitution_plain_value_is_not_a_var_name() {
        // `[string length $x]` reads `$x` as a value, not a variable name, so
        // no role is recorded — the descent must not over-mark ordinary reads.
        let traits = infer(&["x"], "return [string length $x]");
        assert!(
            traits.get("x").is_none_or(HashSet::is_empty),
            "plain value read must record no trait, got {:?}",
            traits.get("x"),
        );
    }

    #[test]
    fn command_substitution_geometry_keeps_quoted_compound_and_index_bodies() {
        for body in [
            "return \"[set $v]\"",
            "return before[set $v]after",
            "return $array([set $v])",
            "return [list [set $v]]",
        ] {
            let traits = infer(&["v"], body);
            assert_trait(&traits, "v", ProcArgTrait::DynamicNameLocal);
            assert_trait(&traits, "v", ProcArgTrait::VarRead);
        }
        for body in ["return {[set $v]}", "return \\[set\\ $v\\]"] {
            let traits = infer(&["v"], body);
            assert!(traits.get("v").is_none_or(HashSet::is_empty), "{body}");
        }
    }

    #[test]
    fn command_substitution_geometry_preserves_index_and_root_alias_order() {
        let traits = infer(&["v"], "return \"$array([set alias $v])[set $alias]\"");
        assert_trait(&traits, "v", ProcArgTrait::DynamicNameLocal);
        assert_trait(&traits, "v", ProcArgTrait::VarRead);
        let reversed = infer(&["v"], "return \"[set $alias]$array([set alias $v])\"");
        assert!(reversed.get("v").is_none_or(HashSet::is_empty));
    }

    #[test]
    fn braced_var_name_has_no_substitution() {
        // `set {arr($k)} 1` — the braces make `arr($k)` a *literal* variable
        // name, so `$k` is not a substitution and must not mark `k` (the
        // segmenter drops the braces, so the guard is by token kind).
        assert!(!infer(&["k"], "set {arr($k)} 1").contains_key("k"));
        assert!(!infer(&["p"], "set {$p} 1").contains_key("p"));
        // The unbraced form *does* substitute, so it still marks the component.
        assert_trait(
            &infer(&["k"], "set arr($k) 1"),
            "k",
            ProcArgTrait::DynamicNameLocal,
        );
    }

    #[test]
    fn compound_dynamic_array_name_marks_components() {
        // `set ${v}($k) 1` — both the array-name param `v` and the key param
        // `k` flow into a dynamic variable name, so both are DynamicNameLocal
        // (+ VarRead).  This is the shape behind `return [set ${v}($k)]`.
        for body in ["set ${v}($k) 1", "set $v($k) 1", "return [set ${v}($k)]"] {
            let traits = infer(&["v", "k"], body);
            for p in ["v", "k"] {
                assert_trait(&traits, p, ProcArgTrait::DynamicNameLocal);
                assert_trait(&traits, p, ProcArgTrait::VarRead);
            }
        }
        // A literal array name with a `$k` key marks only the key.
        let traits = infer(&["k"], "set arr($k) 1");
        assert_trait(&traits, "k", ProcArgTrait::DynamicNameLocal);
    }

    #[test]
    fn var_substitutions_finds_compound_components() {
        let parameters = ["v", "k", "escaped", "1backref"];
        let components = |source| {
            lexical_reference_values(source, &parameters, LexerConfig::default())
                .components
                .remove(1)
        };
        assert_eq!(components("$v"), vec!["v"]);
        assert_eq!(components("${v}($k)"), vec!["v", "k"]);
        assert_eq!(components("$v($k)"), vec!["v", "k"]);
        assert_eq!(components("arr($k)"), vec!["k"]);
        assert_eq!(components("literal"), Vec::<&str>::new());
        assert_eq!(components("\\$escaped"), Vec::<&str>::new());
        assert_eq!(components("$1backref"), vec!["1backref"]);
    }

    #[test]
    fn original_parameter_reference_parts_keep_configured_names_and_literal_indices() {
        let parameters = [
            "1abc", "", "odd name", "caf", "café", "a{b", "a{b}c", "v", "k", "arr",
        ];
        for (dialect, unicode, nested) in [
            ("tcl8.6", false, false),
            ("tcl9.1", false, true),
            ("jim", true, false),
        ] {
            let profile = tcl_registry::model::ingress::resolve_known_environment(dialect)
                .expect("selected original reference grammar environment")
                .unit_profile();
            let config = LexerConfig::for_file_grammar(profile.grammar);
            let values = |word| lexical_reference_values(word, &parameters, config);
            for (word, expected) in [
                ("$1abc", Some("1abc")),
                ("${}", Some("")),
                ("${odd name}", Some("odd name")),
                ("\"$1abc\"", Some("1abc")),
                ("{$1abc}", None),
                ("\\$1abc", None),
            ] {
                assert_eq!(values(word).argument(0), expected, "{dialect}/{word}");
            }
            assert_eq!(values("$café").argument(0), unicode.then_some("café"));
            assert_eq!(
                values("$café").argument_components(0),
                if unicode {
                    &["café"][..]
                } else {
                    &["caf"][..]
                }
            );
            assert_eq!(values("${a{b}c}").argument(0), nested.then_some("a{b}c"));
            assert_eq!(
                values("${a{b}c}").argument_components(0),
                if nested { &["a{b}c"][..] } else { &["a{b"][..] }
            );
            assert_eq!(values("$arr($k)").argument_components(0), &["arr", "k"]);
            assert_eq!(values("${arr($k)}").argument_components(0), &["arr"]);
            assert!(values("${arr($k)}").argument(0).is_none());
            assert!(values("{$arr($k)}").argument_components(0).is_empty());
        }
    }

    #[test]
    fn original_parameter_reference_parts_refuse_changed_segment_presentations() {
        let config = LexerConfig::default();
        let registry = CommandRegistry::build_default();
        let original = "command $old";
        let commands = segment_commands_with_offset_and_config(original, 0, config);
        let parameters = HashSet::from(["old", "new"]);
        let aliases = Aliases::default();
        let valid = ArgumentValues::lexical(
            original,
            &commands[0],
            &parameters,
            &aliases,
            config,
            &registry,
        );
        assert_eq!(valid.argument(0), Some("old"));
        let changed = ArgumentValues::lexical(
            "command $new",
            &commands[0],
            &parameters,
            &aliases,
            config,
            &registry,
        );
        assert!(changed.argument(0).is_none());
        assert!(changed.argument_components(0).is_empty());
        let literal = lexical_reference_values("{$old}", &["old"], config);
        assert!(literal.argument(0).is_none());
        assert!(literal.argument_components(0).is_empty());
    }

    #[test]
    fn value_copy_carries_param_into_name_and_command_positions() {
        // `set n $p` copies the param's value into local `n`; a later `$n` in a
        // name / command position then resolves back to the param.
        assert_trait(
            &infer(&["v"], "set n $v\nset $n 1"),
            "v",
            ProcArgTrait::DynamicNameLocal,
        );
        assert_trait(
            &infer(&["cmd"], "set c $cmd\n$c arg"),
            "cmd",
            ProcArgTrait::Command,
        );
        // In a command substitution too.
        assert_trait(
            &infer(&["v"], "set n $v\nreturn [set $n]"),
            "v",
            ProcArgTrait::DynamicNameLocal,
        );
        // Transitive copies chain.
        assert_trait(
            &infer(&["cmd"], "set c $cmd\nset d $c\n$d arg"),
            "cmd",
            ProcArgTrait::Command,
        );
    }

    #[test]
    fn value_copy_is_invalidated_and_not_over_eager() {
        // Reassigning the local to a non-param drops the copy, so a later `$n`
        // no longer resolves to the original param.
        assert!(!infer(&["v"], "set n $v\nset n other\nset $n 1").contains_key("v"));
        // Merely passing the value through (never used as a name) is not a role.
        assert!(!infer(&["v"], "set n $v\nreturn $n").contains_key("v"));
    }

    #[test]
    fn accepted_copies_feed_eval_without_surviving_unknown_or_mutated_values() {
        assert_trait(
            &infer(&["body"], "set local $body; eval $local"),
            "body",
            ProcArgTrait::Eval,
        );
        for body in [
            "set local $body; set local ordinary; eval $local",
            "set local $body; unknown_callback; eval $local",
            "set local $body; eval {$local}",
        ] {
            assert!(
                !infer(&["body"], body)
                    .get("body")
                    .is_some_and(|traits| traits.contains(&ProcArgTrait::Eval)),
                "{body}"
            );
        }
    }

    #[test]
    fn referenced_upvar_contents_are_not_the_parameter_value_that_named_them() {
        let traits = infer(
            &["name"],
            "upvar 1 $name contents; set contents SCRIPT; set copy $contents; eval $copy",
        );
        assert_trait(&traits, "name", ProcArgTrait::VarWrite);
        assert!(
            !traits["name"].contains(&ProcArgTrait::Eval),
            "the caller cell's contents are distinct from its parameter-supplied name"
        );
    }

    #[test]
    fn param_used_as_command_head_is_command() {
        // `$cmd arg1 arg2` — the param's value is the command word, so it names
        // a command.  Works at the top level and inside a `[...]` substitution.
        assert_trait(&infer(&["cmd"], "$cmd a b"), "cmd", ProcArgTrait::Command);
        assert_trait(
            &infer(&["cmd"], "return [$cmd x]"),
            "cmd",
            ProcArgTrait::Command,
        );
        // A braced `{$cmd}` head is a *literal* command name — no substitution.
        assert!(!infer(&["cmd"], "{$cmd} arg").contains_key("cmd"));
        // A param merely read as a value is not a command.
        assert!(!infer(&["x"], "puts $x").contains_key("x"));
    }

    #[test]
    fn stub_command_prefix_role_is_command() {
        // A stub-declared `command_prefix` argument names a command, so a
        // `$param` there is inferred `Command`.
        let declared = make_declarations(vec![stub_sig(
            "on_event",
            &[
                ("event", ArgRole::Value),
                ("handler", ArgRole::CommandPrefix),
            ],
        )]);
        let registry = CommandRegistry::build_default();
        let traits = infer_param_traits(
            &["h"],
            "on_event click $h",
            TraitScanEnv {
                surface: DocumentCommandSurface::new(&registry, Some(&declared)),
                config: LexerConfig::default(),
                identities: crate::realm::CommandBindingRealm::none(),
                executed_source: None,
            },
        );
        assert_trait(&traits, "h", ProcArgTrait::Command);
    }

    #[test]
    fn namespace_upvar_dynamic_name_reads_other_var() {
        // `namespace upvar ns $token arr` — the token/state-array idiom, with a
        // dynamic `$token` naming the namespace variable aliased into `arr`.
        // The pairs start after the `namespace` word (index 2 of the
        // sub-command args), so `$token` is the *other* var → VarRead, and a
        // later write through the `arr` alias upgrades it to VarWrite.
        let traits = infer(&["token"], "namespace upvar ns $token arr");
        assert_trait(&traits, "token", ProcArgTrait::VarRead);
        let traits = infer(&["token"], "namespace upvar ns $token arr\nset arr 1");
        assert_trait(&traits, "token", ProcArgTrait::VarWrite);
    }

    #[test]
    fn real_world_by_reference_patterns_are_inferred() {
        // The dominant variable-name-by-reference shapes mined from the tcllib /
        // Tcl-library corpus (`http`, `smtp`, `ftp`, … token idiom).  Each names
        // a variable via a parameter, so each must record a read/write trait.
        let has_var = |body: &str, p: &str| {
            let t = infer(&[p], body);
            t.get(p).is_some_and(|s| {
                s.contains(&ProcArgTrait::VarRead) || s.contains(&ProcArgTrait::VarWrite)
            })
        };
        for (body, p) in [
            ("upvar 1 $varname data", "varname"),
            ("upvar 0 $token state", "token"),
            ("upvar #0 $token state", "token"),
            ("upvar $v local", "v"),
            ("variable $name", "name"),
            ("array set $a {x 1}", "a"),
            ("array get $a", "a"),
            ("array names $a", "a"),
            ("unset $v", "v"),
            ("dict set $d k 1", "d"),
            ("incr $counter", "counter"),
            ("append $resultVar x", "resultVar"),
            ("lappend $pages_var p", "pages_var"),
            ("set ${tok}(state) connected", "tok"),
            ("set $gas(idx) 1", "gas"),
            ("namespace upvar ns $v local", "v"),
            ("foreach k [array names $a] { puts $k }", "a"),
            ("return [set ${token}($field)]", "token"),
        ] {
            assert!(
                has_var(body, p),
                "expected a by-reference var trait for `{p}` in `{body}`; got {:?}",
                infer(&[p], body).get(p),
            );
        }
    }

    #[test]
    fn after_records_eval_skipping_cancel_info() {
        let traits = infer(&["body"], "after 100 $body");
        assert_trait(&traits, "body", ProcArgTrait::Eval);
        let traits = infer(&["x"], "after cancel $x");
        // ``after cancel`` doesn't take a script, so $x is not eval.
        assert!(
            traits
                .get("x")
                .is_none_or(|s| !s.contains(&ProcArgTrait::Eval))
        );
    }

    #[test]
    fn regsub_records_dynamic_name_local() {
        // `regsub`'s output var is CALLEE-LOCAL — DynamicNameLocal
        // (+ VarRead), not VarWrite.
        let traits = infer(&["out"], "regsub -all foo $line bar $out");
        assert_trait(&traits, "out", ProcArgTrait::DynamicNameLocal);
        assert_trait(&traits, "out", ProcArgTrait::VarRead);
        assert!(
            !traits.get("out").unwrap().contains(&ProcArgTrait::VarWrite),
            "callee-local regsub target must not be VarWrite, got {:?}",
            traits.get("out"),
        );
    }

    #[test]
    fn regexp_capture_vars_after_switches_record_dynamic_name_local() {
        // `regexp -nocase -- $pat $s $m` — the registry `regexp` spec's
        // arg-role resolver performs the switch skip (`--` terminator
        // included), so the capture var `$m` names a callee-local output
        // variable.  The pattern / subject args are plain value reads and
        // must record no trait.
        let traits = infer(&["pat", "s", "m"], "regexp -nocase -- $pat $s $m");
        assert_trait(&traits, "m", ProcArgTrait::DynamicNameLocal);
        assert_trait(&traits, "m", ProcArgTrait::VarRead);
        assert!(!traits.contains_key("pat"), "{traits:?}");
        assert!(!traits.contains_key("s"), "{traits:?}");
    }

    #[test]
    fn regexp_start_switch_value_is_skipped() {
        // `-start` consumes its value word (spec-declared), so the capture
        // var still resolves after the pattern + string positionals.
        let traits = infer(&["m"], "regexp -start 2 {x+} $s $m");
        assert_trait(&traits, "m", ProcArgTrait::DynamicNameLocal);
    }

    #[test]
    fn regsub_command_switch_is_skipped_to_output_var() {
        // Tcl 9 `regsub -command exp string cmdPrefix varName` — `-command`
        // is a spec-declared flag (one a hardcoded switch list misses), so
        // the output var must still resolve at exp + 3.
        let traits = infer(&["out"], "regsub -command {x+} $s myCb $out");
        assert_trait(&traits, "out", ProcArgTrait::DynamicNameLocal);
        assert_trait(&traits, "out", ProcArgTrait::VarRead);
    }

    #[test]
    fn set_dynamic_name_records_dynamic_name_local_not_var_write() {
        // `set $p 1` — the param's VALUE names a callee-local variable
        // (registry `VarWrite` role on the `$p` substitution).  The
        // refined trait is DynamicNameLocal (+ VarRead), NOT VarWrite:
        // a caller passing a literal name (`f x`) does not have its `x`
        // consumed by this callee.
        let traits = infer(&["p"], "set $p 1");
        assert_trait(&traits, "p", ProcArgTrait::DynamicNameLocal);
        assert_trait(&traits, "p", ProcArgTrait::VarRead);
        assert!(
            !traits.get("p").unwrap().contains(&ProcArgTrait::VarWrite),
            "callee-local `set $p` must not be VarWrite, got {:?}",
            traits.get("p"),
        );
    }

    #[test]
    fn genuine_upvar_write_stays_var_write_not_dynamic_name_local() {
        // A real caller-frame write-back through an `upvar` alias is a
        // genuine `VarWrite` — the DynamicNameLocal refinement must NOT
        // leak onto it (otherwise caller-side suppression of a genuine
        // call-by-name write would regress).
        let traits = infer(&["var"], "upvar 1 $var local\nset local 1");
        assert_trait(&traits, "var", ProcArgTrait::VarWrite);
        assert!(
            !traits
                .get("var")
                .unwrap()
                .contains(&ProcArgTrait::DynamicNameLocal),
            "upvar write-back must not be DynamicNameLocal, got {:?}",
            traits.get("var"),
        );
    }

    #[test]
    fn empty_body_returns_empty_map() {
        let traits = infer(&["a"], "");
        assert!(traits.is_empty());
    }

    /// Deep-pass helper that mirrors [`infer`] for ergonomics.
    fn infer_deep(params: &[&str], body: &str) -> HashMap<String, HashSet<ProcArgTrait>> {
        let registry = CommandRegistry::build_default();
        infer_param_traits_deep(params, body, env_for(&registry, LexerConfig::default()))
    }

    #[test]
    fn deep_pass_surfaces_eval_trait_inside_braced_body() {
        // `$body` is used inside a nested `foreach` body — the
        // shallow pass walks only top-level commands, so it
        // misses the trait.  The deep pass descends into the
        // braced `foreach` body and surfaces `Eval`.
        let body = "foreach item $items {\n  uplevel 1 $body\n}";
        let shallow = infer(&["items", "body"], body);
        let deep = infer_deep(&["items", "body"], body);
        // Shallow catches `items` (LoopList) but misses `body`.
        assert_trait(&shallow, "items", ProcArgTrait::LoopList);
        assert!(
            !shallow
                .get("body")
                .is_some_and(|s| s.contains(&ProcArgTrait::Eval)),
            "shallow pass should not surface nested Eval, got {shallow:?}",
        );
        // Deep catches both.
        assert_trait(&deep, "items", ProcArgTrait::LoopList);
        assert_trait(&deep, "body", ProcArgTrait::Eval);
    }

    #[test]
    fn deep_pass_descends_through_multiple_levels() {
        // `$inner` is buried two levels deep: `if` → `while` →
        // `eval $inner`.  Shallow misses it; deep finds it.
        let body = "if {1} {\n  while {1} {\n    eval $inner\n  }\n}";
        let deep = infer_deep(&["inner"], body);
        assert_trait(&deep, "inner", ProcArgTrait::Eval);
    }

    #[test]
    fn deep_pass_respects_max_depth() {
        // Build a body nested past `MAX_DEPTH` (8 levels of
        // `if {1} { ... }`) with `eval $deep_var` at the
        // innermost level.  The recursion should stop before
        // reaching the innermost level and the trait should not
        // be surfaced.  Using `MAX_DEPTH + 2` (10) levels of
        // nesting puts the eval below the recursion bound.
        let depth_to_nest = usize::from(MAX_DEPTH) + 2;
        let mut body = String::from("eval $deep_var");
        for _ in 0..depth_to_nest {
            body = format!("if {{1}} {{ {body} }}");
        }
        let deep = infer_deep(&["deep_var"], &body);
        assert!(
            !deep
                .get("deep_var")
                .is_some_and(|s| s.contains(&ProcArgTrait::Eval)),
            "MAX_DEPTH bound should keep deeply-nested eval from being surfaced, got {deep:?}",
        );
    }

    /// Depth coverage for the `apply` seam: `scan_deep`'s `apply`
    /// (`ArgRole::LambdaLiteral`) handling must thread its own `depth + 1`
    /// rather than re-enter `infer_param_traits_deep_with_config` — the
    /// *public*, depth-0 entry point. Re-entering resets the *logical*
    /// [`MAX_DEPTH`] counter to 0 on every `apply` boundary while the
    /// *native* Rust call stack (`scan_deep` ↔
    /// `infer_param_traits_deep_at_depth`) keeps growing one frame group per
    /// level regardless — unboundedly, for however deep the input
    /// alternates, so `MAX_DEPTH` (8) never bites.
    ///
    /// 2000 alternating pairs (4000 real nesting levels) is far beyond
    /// anything such a bypass would survive on a small-stack
    /// thread; this must terminate cleanly, not hang or overflow the
    /// stack — the same rationale as the big-stack helpers in
    /// `analyser::commands::tests` / `lowering::tests` (`cargo test`'s
    /// per-test thread has the same undersized default stack production hits).
    #[test]
    fn deep_pass_bounds_alternating_if_apply_nesting() {
        const PAIRS: usize = 2000;
        let mut body = String::from("puts leaf");
        for _ in 0..PAIRS {
            body = format!("if {{1}} {{ apply {{x {{ {body} }}}} 1 }}");
        }
        // With `depth` correctly threaded, an `if`/`apply` pair costs 2
        // logical levels, so real recursion stops at MAX_DEPTH (8) — a
        // handful of native frames regardless of PAIRS. This deliberately
        // runs on the *default* test-thread stack (no big-stack wrapper,
        // unlike the sibling tests in this file and in
        // `commands::tests`/`lowering::tests`): if the reset bug ever comes
        // back, real recursion runs all the way down through every one of
        // PAIRS × 2 levels again — verified locally, reverting just the
        // `depth + 1` fix below to `0` reliably overflows the stack and
        // aborts the test process outright on this same (small,
        // default-sized) thread, before the wall-clock assertion even gets
        // a chance to run. The elapsed-time check below is a second,
        // softer signal for the rare platform/build where the crash
        // threshold happens to sit a little higher.
        let registry = CommandRegistry::build_default();
        let start = std::time::Instant::now();
        let _ = infer_param_traits_deep(&["p"], &body, env_for(&registry, LexerConfig::default()));
        let elapsed = start.elapsed();
        assert!(
            elapsed < std::time::Duration::from_secs(2),
            "took {elapsed:?} — alternating if/apply nesting is no longer bounded by \
             MAX_DEPTH (reset-to-0 bypass regression?)"
        );
    }

    #[test]
    fn deep_pass_skips_dynamic_body_args() {
        // `if {1} $body` — the body is a `$var` reference,
        // not a braced literal.  The deep pass shouldn't try
        // to descend into it (we have no body text to scan);
        // the shallow pass already surfaces the `Body` trait
        // via the registry's role scan.  This pins that
        // contract: dynamic body args don't double-count.
        let body = "if {1} $body";
        let deep = infer_deep(&["body"], body);
        assert_trait(&deep, "body", ProcArgTrait::Body);
    }

    #[test]
    fn merge_traits_unions_shallow_and_deep() {
        let mut shallow: HashMap<String, HashSet<ProcArgTrait>> = HashMap::new();
        shallow
            .entry("p1".into())
            .or_default()
            .insert(ProcArgTrait::VarRead);
        let mut deep: HashMap<String, HashSet<ProcArgTrait>> = HashMap::new();
        deep.entry("p1".into())
            .or_default()
            .insert(ProcArgTrait::Eval);
        deep.entry("p2".into())
            .or_default()
            .insert(ProcArgTrait::Body);

        let merged = merge_traits(shallow, deep);
        // p1 gains Eval from deep without losing VarRead from shallow.
        assert!(merged.get("p1").unwrap().contains(&ProcArgTrait::VarRead));
        assert!(merged.get("p1").unwrap().contains(&ProcArgTrait::Eval));
        // p2 (deep-only) lands in the merged map.
        assert!(merged.get("p2").unwrap().contains(&ProcArgTrait::Body));
    }

    #[test]
    fn merge_traits_with_empty_deep_returns_shallow_unchanged() {
        let mut shallow: HashMap<String, HashSet<ProcArgTrait>> = HashMap::new();
        shallow
            .entry("p1".into())
            .or_default()
            .insert(ProcArgTrait::VarWrite);
        let merged = merge_traits(shallow.clone(), HashMap::new());
        assert_eq!(merged.get("p1"), shallow.get("p1"));
    }

    #[test]
    fn deep_pass_matches_shallow_for_top_level_only_bodies() {
        // When there are no nested bodies, the deep pass
        // should return exactly what the shallow pass does.
        let body = "set $x 1\nupvar 1 $var local";
        let shallow = infer(&["x", "var"], body);
        let deep = infer_deep(&["x", "var"], body);
        assert_eq!(shallow, deep);
    }

    #[test]
    fn deep_pass_empty_params_returns_empty_map() {
        let deep = infer_deep(&[], "foreach item $items { uplevel 1 $body }");
        assert!(deep.is_empty());
    }

    // document-declaration integration
    //
    // These tests pin the contract that a non-empty
    // [`tcl_registry::model::DeclaredSurface`] threaded through
    // `infer_param_traits` / `infer_param_traits_deep` lets user-declared
    // `# tcl-lsp: stub` commands participate in role-driven trait
    // inference alongside the catalogue.

    use tcl_dialect::model::Provenance;
    use tcl_registry::model::{DeclaredArgument, DeclaredCommand, DeclaredSurface};

    fn make_declarations(commands: Vec<DeclaredCommand>) -> DeclaredSurface {
        let mut surface = DeclaredSurface::new();
        for command in commands {
            surface.declare(command);
        }
        surface
    }

    fn stub_sig(name: &str, args: &[(&str, ArgRole)]) -> DeclaredCommand {
        DeclaredCommand::new(
            name.to_string(),
            args.iter()
                .map(|(n, r)| DeclaredArgument {
                    name: (*n).to_string(),
                    role: *r,
                    optional: false,
                })
                .collect(),
            Provenance::Document,
        )
    }

    #[test]
    fn declarations_shallow_surface_the_declared_body_role() {
        // `my_eval` isn't in the catalogue, but the document
        // declares its arg-0 as `body`.  An invocation
        // `my_eval $script` should therefore surface `Body` on
        // the `script` param.
        let declared = make_declarations(vec![stub_sig("my_eval", &[("script", ArgRole::Body)])]);
        let registry = CommandRegistry::build_default();
        let traits = infer_param_traits(
            &["script"],
            "my_eval $script",
            TraitScanEnv {
                surface: DocumentCommandSurface::new(&registry, Some(&declared)),
                config: LexerConfig::default(),
                identities: crate::realm::CommandBindingRealm::none(),
                executed_source: None,
            },
        );
        assert_trait(&traits, "script", ProcArgTrait::Body);
    }

    #[test]
    fn declarations_shallow_surface_the_declared_var_write_role() {
        // A declared `VarWrite` on a bare `$param` substitution
        // surfaces the callee-local DynamicNameLocal refinement.
        let declared = make_declarations(vec![stub_sig(
            "with_var",
            &[("varName", ArgRole::VarWrite), ("value", ArgRole::Value)],
        )]);
        let registry = CommandRegistry::build_default();
        let traits = infer_param_traits(
            &["v"],
            "with_var $v 42",
            TraitScanEnv {
                surface: DocumentCommandSurface::new(&registry, Some(&declared)),
                config: LexerConfig::default(),
                identities: crate::realm::CommandBindingRealm::none(),
                executed_source: None,
            },
        );
        // A declared `VarWrite` role on a bare `$v` substitution is the same
        // callee-local dynamic-name shape as `set $v …` — refined to
        // DynamicNameLocal (+ VarRead), not a caller-frame VarWrite.
        assert_trait(&traits, "v", ProcArgTrait::DynamicNameLocal);
        assert_trait(&traits, "v", ProcArgTrait::VarRead);
    }

    #[test]
    fn declarations_deep_recurse_through_declared_body_args() {
        // The document declares `my_loop`'s arg-1 as a body.
        // Without the declaration the deep pass can't see that
        // `my_loop { uplevel 1 $body }` carries an Eval inside.
        // With it the pass descends into the brace and surfaces
        // the Eval.
        let declared = make_declarations(vec![stub_sig(
            "my_loop",
            &[("count", ArgRole::Value), ("body", ArgRole::Body)],
        )]);
        let registry = CommandRegistry::build_default();
        let body = "my_loop 5 { uplevel 1 $script }";
        // Sanity: without the declaration, the deep pass misses
        // the nested Eval because `my_loop` isn't recognised.
        let undeclared = infer_param_traits_deep(
            &["script"],
            body,
            env_for(&registry, LexerConfig::default()),
        );
        assert!(
            !undeclared
                .get("script")
                .is_some_and(|s| s.contains(&ProcArgTrait::Eval)),
            "undeclared, my_loop's body shouldn't be recognised, got {undeclared:?}",
        );
        // With the declaration, the recursion fires.
        let with_declaration = infer_param_traits_deep(
            &["script"],
            body,
            TraitScanEnv {
                surface: DocumentCommandSurface::new(&registry, Some(&declared)),
                config: LexerConfig::default(),
                identities: crate::realm::CommandBindingRealm::none(),
                executed_source: None,
            },
        );
        assert_trait(&with_declaration, "script", ProcArgTrait::Eval);
    }

    #[test]
    fn declarations_do_not_disturb_catalogue_resolution() {
        // A declaration covering `my_thing` mustn't shadow any
        // catalogue command.  A shipped `foreach` invocation
        // still records its `LoopList` / `Body` traits through the
        // catalogue path even when an unrelated document
        // declaration is active.
        let declared = make_declarations(vec![stub_sig("my_thing", &[("a", ArgRole::Body)])]);
        let registry = CommandRegistry::build_default();
        let traits = infer_param_traits(
            &["items", "body"],
            "foreach x $items $body",
            env_with_declarations(&registry, &declared),
        );
        assert_trait(&traits, "items", ProcArgTrait::LoopList);
        assert_trait(&traits, "body", ProcArgTrait::Body);
    }

    #[test]
    fn no_declarations_matches_an_empty_declaration_set() {
        // An empty declaration set should produce the same result as
        // `None` — a document that declares nothing is exactly the
        // catalogue.
        let registry = CommandRegistry::build_default();
        let body = "foreach x {1 2 3} $body";
        let none = infer_param_traits(&["body"], body, env_for(&registry, LexerConfig::default()));
        let declared = DeclaredSurface::new();
        let empty =
            infer_param_traits(&["body"], body, env_with_declarations(&registry, &declared));
        assert_eq!(none, empty);
    }

    /// Trait inference must resolve a command head's *effective identity*, not
    /// its written spelling.
    ///
    /// tclsh oracle (8.6.16 and 9.0.4, byte-identical): `interp alias {} run
    /// {} eval` makes `run $body` evaluate `$body`; `rename eval run` moves it
    /// and leaves `eval` gone; a top-level `proc eval …` takes the name over,
    /// so `eval $body` no longer evaluates anything.
    ///
    /// The environment carries the *document's* facts while the scan reads a
    /// *proc body*, which is exactly the shape the analyser threads.
    fn realm_for_body(
        prelude: &str,
        body: &str,
    ) -> (crate::realm::CommandBindingRealm, tcl_lexer::Span) {
        let source = format!("{prelude}proc __trait_probe {{body v}} {{{body}}}");
        let registry = CommandRegistry::build_default();
        let identities = crate::realm::document_realm_bindings(
            &source,
            tcl_registry::model::ingress::resolve_environment("tcl8.6").analyser_profile(),
            &registry,
        );
        let segments = segment_commands_with_offset_and_config(&source, 0, LexerConfig::default());
        let body_span = segments.last().unwrap().argv.last().unwrap().span;
        (identities, body_span)
    }

    fn traits_under(prelude: &str, body: &str) -> HashMap<String, HashSet<ProcArgTrait>> {
        let registry = CommandRegistry::build_default();
        let (identities, body_span) = realm_for_body(prelude, body);
        infer_param_traits(
            &["body"],
            body,
            TraitScanEnv {
                surface: DocumentCommandSurface::new(&registry, None),
                config: LexerConfig::default(),
                identities: &identities,
                executed_source: identities.executed_script_for_word(body_span),
            },
        )
    }

    fn is_eval(traits: &HashMap<String, HashSet<ProcArgTrait>>) -> bool {
        traits
            .get("body")
            .is_some_and(|s| s.contains(&ProcArgTrait::Eval))
    }

    #[test]
    fn param_traits_follow_an_aliased_head() {
        assert!(is_eval(&traits_under(
            "interp alias {} run {} eval\n",
            "run $body"
        )));
        // The `::`-qualified spelling of the alias classifies alike.
        assert!(is_eval(&traits_under(
            "interp alias {} run {} eval\n",
            "::run $body"
        )));
        // Guard: an unbound `run` evaluates nothing.
        assert!(!is_eval(&traits_under("set y 1\n", "run $body")));
    }

    #[test]
    fn param_traits_follow_a_renamed_head() {
        assert!(is_eval(&traits_under("rename eval run\n", "run $body")));
        assert!(
            !is_eval(&traits_under("rename eval run\n", "eval $body")),
            "a renamed-away `eval` must not keep the built-in's grammar"
        );
    }

    #[test]
    fn param_traits_abstain_for_a_builtin_shadowed_by_a_user_proc() {
        assert!(
            !is_eval(&traits_under("proc eval {s} { return $s }\n", "eval $body")),
            "a user `proc eval` takes the name over; its argument is not a script"
        );
        // Guard: the unshadowed built-in still records the trait.
        assert!(is_eval(&traits_under("set y 1\n", "eval $body")));
    }

    #[test]
    fn param_traits_abstain_for_a_dynamic_binding() {
        assert!(
            !is_eval(&traits_under("rename $old run\n", "run $body")),
            "a dynamic rename must not make `run` an evaluator"
        );
        assert!(
            !is_eval(&traits_under("rename $old run\n", "eval $body")),
            "the unknown source may be eval, so its later evaluator identity is unresolved"
        );
        assert!(
            is_eval(&traits_under("rename puts output\n", "eval $body")),
            "a proved unrelated rename preserves the evaluator binding"
        );
    }

    /// The caller-frame scans read the resolved head too: `upvar`'s
    /// `FrameArgLayout::AliasPairs` grammar belongs to the command a head is.
    #[test]
    fn caller_frame_scans_follow_the_resolved_head() {
        let registry = CommandRegistry::build_default();
        let params_under = |prelude: &str, body: &str| {
            let (identities, span) = realm_for_body(prelude, body);
            caller_frame_upvar_params(
                &["v"],
                body,
                TraitScanEnv {
                    surface: DocumentCommandSurface::new(&registry, None),
                    config: LexerConfig::default(),
                    executed_source: identities.executed_script_for_word(span),
                    identities: &identities,
                },
            )
        };
        let literals_under = |prelude: &str, body: &str| {
            let (identities, span) = realm_for_body(prelude, body);
            caller_frame_literal_targets(
                body,
                TraitScanEnv {
                    surface: DocumentCommandSurface::new(&registry, None),
                    config: LexerConfig::default(),
                    executed_source: identities.executed_script_for_word(span),
                    identities: &identities,
                },
            )
        };
        let alias = "interp alias {} peek {} upvar\n";
        assert!(
            params_under(alias, "peek 1 $v alias").contains("v"),
            "an alias of upvar must select the caller frame"
        );
        assert!(literals_under(alias, "peek 1 name name\nset name W1").contains_key("name"));
        let shadow = "proc upvar {a b c} { return 1 }\n";
        assert!(params_under(shadow, "upvar 1 $v alias").is_empty());
        assert!(literals_under(shadow, "upvar 1 name name\nset name W1").is_empty());
        assert!(params_under("", "upvar 1 $v alias").contains("v"));
        assert!(literals_under("", "upvar 1 name name\nset name W1").contains_key("name"));
    }

    #[test]
    fn positioned_own_body_tracks_local_symbolic_copy_without_a_caller() {
        let source = "proc p {body} {set local $body; eval $local}";
        let registry = tcl_registry::model::ingress::static_context_for("tcl8.6").commands();
        let identities = crate::realm::document_realm_bindings(
            source,
            tcl_dialect::DialectProfile::find("tcl8.6").unwrap(),
            registry,
        );
        let command = segment_commands_with_offset_and_config(source, 0, LexerConfig::default())
            .pop()
            .unwrap();
        let script = identities
            .executed_script_for_word(command.argv.last().unwrap().span)
            .unwrap();
        let env = TraitScanEnv {
            surface: DocumentCommandSurface::new(registry, None),
            config: LexerConfig::default(),
            identities: &identities,
            executed_source: Some(script),
        };
        let traits = infer_param_traits(&["body"], script.try_text().unwrap(), env);
        assert_trait(&traits, "body", ProcArgTrait::Eval);
        assert!(caller_frame_upvar_params(&["body"], script.try_text().unwrap(), env).is_empty());
        assert!(caller_frame_literal_targets(script.try_text().unwrap(), env).is_empty());
        let bare = infer_param_traits(
            &["body"],
            script.try_text().unwrap(),
            env_for(registry, LexerConfig::default()),
        );
        assert!(
            !bare
                .get("body")
                .is_some_and(|traits| traits.contains(&ProcArgTrait::Eval))
        );
    }

    #[test]
    fn declaration_retains_symbolic_caller_name_without_caller_identity() {
        let registry = tcl_registry::model::ingress::static_context_for("tcl8.6").commands();
        let declaration = "proc p {v} {upvar 1 $v alias; set alias 1}";
        for (called, source) in [
            (false, declaration.to_owned()),
            (true, format!("{declaration}; p target")),
        ] {
            let identities = crate::realm::document_realm_bindings(
                &source,
                tcl_dialect::DialectProfile::find("tcl8.6").unwrap(),
                registry,
            );
            let commands =
                segment_commands_with_offset_and_config(&source, 0, LexerConfig::default());
            let script = identities
                .executed_script_for_word(commands[0].argv.last().unwrap().span)
                .unwrap();
            let env = TraitScanEnv {
                surface: DocumentCommandSurface::new(registry, None),
                config: LexerConfig::default(),
                identities: &identities,
                executed_source: Some(script),
            };
            assert!(
                caller_frame_upvar_params(&["v"], script.try_text().unwrap(), env).contains("v")
            );
            assert_eq!(env.has_actual_procedure_entry(), called);
            assert!(caller_frame_literal_targets(script.try_text().unwrap(), env).is_empty());
        }
    }

    #[test]
    fn conditional_own_body_traits_reach_whole_and_per_item_proc_consumers() {
        let source = "proc p {body} {set local $body; eval $local}";
        let mut analyser = crate::analyser::Analyser::new();
        let whole = analyser.analyse(source, "tcl8.6");
        let mut analyser = crate::analyser::Analyser::new();
        let per_item = analyser.analyse_per_item(source, "tcl8.6");
        for result in [whole, per_item] {
            let procedure = result.all_procs.get("::p").expect("original declaration");
            assert_trait(&procedure.param_traits, "body", ProcArgTrait::Eval);
            assert!(procedure.caller_frame_params.is_empty());
            assert!(procedure.caller_frame_literals.is_empty());
        }
    }

    #[test]
    fn caller_frame_parameter_templates_reach_navigation_without_entered_caller() {
        for dialect in ["tcl8.4", "tcl8.5", "tcl8.6", "tcl9.0", "tcl9.1", "jimtcl"] {
            let source = "proc setter {d} {upvar 1 $d local; set local VALUE}\nproc caller {} {setter target; puts $target}";
            let mut whole = crate::analyser::Analyser::new();
            let mut per_item = crate::analyser::Analyser::new();
            for analysis in [
                whole.analyse(source, dialect),
                per_item.analyse_per_item(source, dialect),
            ] {
                let setter = analysis.all_procs.get("::setter").expect("original setter");
                assert!(setter.caller_frame_params.contains("d"), "{dialect}");
                assert_trait(&setter.param_traits, "d", ProcArgTrait::VarWrite);
            }
            let replaced = "proc setter {d} {set d OTHER; upvar 1 $d local; set local VALUE}\nproc caller {} {setter target; puts $target}";
            let mut analyser = crate::analyser::Analyser::new();
            let analysis = analyser.analyse(replaced, dialect);
            let setter = analysis.all_procs.get("::setter").expect("original setter");
            assert!(!setter.caller_frame_params.contains("d"), "{dialect}");
            assert!(
                !setter
                    .param_traits
                    .get("d")
                    .is_some_and(|traits| traits.contains(&ProcArgTrait::VarWrite)),
                "{dialect}"
            );
        }
    }

    #[test]
    fn declared_roles_cannot_restore_a_replaced_or_opaque_slot() {
        let declared = make_declarations(vec![stub_sig("my_eval", &[("script", ArgRole::Body)])]);
        let registry = CommandRegistry::build_default();
        for prelude in [
            "proc my_eval args {return ordinary};",
            "rename $old output;",
        ] {
            let body = "my_eval $body";
            let (identities, span) = realm_for_body(prelude, body);
            let traits = infer_param_traits(
                &["body"],
                body,
                TraitScanEnv {
                    surface: DocumentCommandSurface::new(&registry, Some(&declared)),
                    config: LexerConfig::default(),
                    identities: &identities,
                    executed_source: identities.executed_script_for_word(span),
                },
            );
            assert!(
                !traits
                    .get("body")
                    .is_some_and(|traits| traits.contains(&ProcArgTrait::Body)),
                "{prelude}"
            );
        }
    }
}

#[cfg(test)]
mod original_name_data_tests {
    use super::*;

    fn assistance(
        source: &str,
        dialect: &str,
    ) -> (
        crate::provider_fixtures::OriginalNativeModuleFixture,
        Box<crate::registry_invocation::InvocationBodyAssistance>,
    ) {
        let fixture = crate::provider_fixtures::original_native_module(source, dialect);
        let (context, module) = &*fixture;
        let tokens = module
            .top_level
            .statements
            .iter()
            .find_map(|statement| {
                module
                    .top_level
                    .retained_source_tokens_for_statement(statement)
            })
            .expect("actual original source statement");
        let view = crate::registry_invocation::invocation_body_assistance(
            context.commands(),
            context.as_ref(),
            &DocumentCommandSurface::new(context.commands(), None),
            tokens,
        );
        (fixture, view)
    }

    #[test]
    fn caller_template_literal_data_keeps_name_bytes_and_held_variable_policy() {
        for (dialect, qualified_local) in [("tcl8.4", false), ("tcl9.1", false), ("jimtcl", true)] {
            let (_fixture, view) = assistance("set {$literal} VALUE", dialect);
            let selected = view
                .caller_name_template_invocation()
                .expect("actual original selected set invocation");
            assert_eq!(
                view.caller_template_literal_data(selected, 0).as_deref(),
                Some("$literal")
            );
            for name in [
                "",
                " with space ",
                "$literal",
                "[literal]",
                "literal(open",
                "1abc",
                "café",
            ] {
                assert!(is_local_scalar_name(name, selected), "{dialect}/{name}");
            }
            assert_eq!(
                is_local_scalar_name("N::qualified", selected),
                qualified_local,
                "{dialect}"
            );
            assert!(!is_local_scalar_name("::rooted", selected));
            assert!(!is_local_scalar_name("array(key)", selected));
        }
    }

    #[test]
    fn caller_template_literal_data_refuses_foreign_changed_and_dynamic_carriers() {
        let (_fixture, mut view) = assistance("set {$literal} VALUE", "tcl9.1");
        let selected = view
            .caller_name_template_invocation()
            .expect("original selected set");
        assert_eq!(
            view.caller_template_literal_data(selected, 0).as_deref(),
            Some("$literal")
        );
        let detached = selected.clone();
        assert!(view.caller_template_literal_data(&detached, 0).is_none());
        view.definite_invocation.as_mut().unwrap().arguments[0] = Some("changed".into());
        assert!(
            view.caller_template_literal_data(view.caller_name_template_invocation().unwrap(), 0)
                .is_none()
        );
        let (_fixture, view) = assistance("set $computed VALUE", "tcl9.1");
        assert!(
            view.caller_name_template_invocation()
                .and_then(|selected| view.caller_template_literal_data(selected, 0))
                .is_none()
        );
    }
}
