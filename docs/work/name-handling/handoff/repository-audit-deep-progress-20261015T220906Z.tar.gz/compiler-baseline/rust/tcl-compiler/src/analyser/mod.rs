// tcl-lsp — a language server and toolchain for Tcl
// Copyright (C) 2026 James Deucker (bitwisecook) <https://github.com/bitwisecook>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.
//
// SPDX-License-Identifier: AGPL-3.0-or-later

//! Single-pass Tcl analyser.
//!
//! Walks segmented Tcl commands, populates an [`AnalysisResult`]
//! (procs, classes, variables, diagnostics, package requires, …),
//! and emits W-coded warnings via the diagnostic emitters.
//!
//! The analyser is a single struct with methods grouped by concern:
//!
//! - [`state`] — the [`Analyser`] struct + per-walk state fields.
//! - [`types`] — [`AnalysisResult`] + the per-record types
//!   ([`ProcDef`], [`ClassDef`], [`VarDef`], [`Diagnostic`], …).
//! - [`snapshot`] — [`AnalyserSnapshot`] for chunked re-analysis.
//! - [`utils`] — pure helpers.
//!
//! Per-concern modules cover command dispatch (`commands.rs`), the
//! per-command handlers (`handlers.rs`), diagnostics (`diagnostics/`),
//! `TclOO` and recovery (`oo.rs` + `recovery.rs`), plus the public entry
//! point.
//!
//! This pure analyser is consumed directly by the native
//! `tcl-lsp-server`.

pub mod bounds_checks;
pub mod class_hierarchy;
/// Object→class binding lattice and dispatch resolver. Experimental: not
/// wired into shipping diagnostics; measured by the `mro_eval` harness.
/// See `docs/design/analysis/name-resolution.md` §5.6.
pub mod class_lattice;
pub mod commands;
pub mod confusables_table;
mod diagnostic_registry;
mod diagnostic_subject;
pub mod diagnostics;
pub mod dispatch;
pub mod handlers;
pub mod indirection;
mod input;
mod interp_visibility;
pub mod irules_event_checks;
pub mod item_tree;
#[cfg(test)]
mod name_producer_tests;
pub mod oo;
mod original_definer;
mod original_members;
pub mod param_traits;
pub mod per_item;
pub mod recovery;
pub mod scope;
pub mod snapshot;
pub mod source_integrity;
pub mod state;
pub mod syntax_checks;
pub mod tk_checks;
pub mod types;
pub mod utils;
mod variable_alias_templates;
mod variable_source_declarations;

pub use variable_source_declarations::OriginalVariableSourceDeclaration;

pub use class_hierarchy::{ClassHierarchy, build_class_hierarchy};
pub use class_lattice::{
    AblationConfig, ClassValue, DispatchStats, DispatchVerdict, NsContext, SiteReport, TopReason,
    analyse_dispatch, class_values, next_provider,
};
pub use item_tree::{
    FileDecls, Item, ItemId, ItemKind, ItemSig, ItemTree, SourceDeclarationSignature,
};
// The MRO linearisation lives in `tcl-syntax` so the bytecode VM (which must
// not depend on the compiler — the `CompileService` injection keeps the wasm
// core light) can share it. Re-exported here so callers can reach it as
// `tcl_compiler::analyser::…`.
pub use diagnostic_registry::{
    DeclaredSourceDiagnosticKind, DeclaredSourceDiagnosticSubject, RegistrySourceDiagnosticKind,
    RegistrySourceDiagnosticSubject,
};
pub use diagnostic_subject::{
    DiagnosticSubject, ObjectSourceAritySubject, RegisteredInstanceSourceDiagnosticKind,
    RegisteredInstanceSourceDiagnosticSubject, SourceCallbackArgumentCounts,
    SourceCallbackArityIssue, SourceCallbackAritySubject, SourceCallbackSignatureLookup,
    SourceUnresolvedCommandSubject, SourceUnresolvedMathFunctionSubject,
};
pub use input::ResolvedAnalysisInput;
pub use interp_visibility::{
    ConditionalInterpreterVisibilitySubject, InterpreterVisibilityObligation,
    OriginalInterpreterSourceDomain, OriginalInterpreterSourceLoad,
    SourceInterpreterVisibilitySnapshot,
};
pub use scope::{
    VariableAliasLink, command_resolution_namespace_at, implicit_command_namespace_path_at,
    innermost_scope_is_oo_method_frame, innermost_scope_reaches_oo_helpers,
    lookup_var_by_qualified_name, lookup_var_in_namespace, namespace_variables,
    qualified_name_for_var_decl, variable_alias_links,
};
pub use snapshot::AnalyserSnapshot;
pub use source_integrity::bidi_control_diagnostics;
pub use state::{Analyser, NonAsciiMode};
pub use tcl_syntax::mro::{self, MroError, build_mro_map, tcloo_linearise};
pub use types::{
    AnalysisResult, ClassDef, ClassFactory, ClassFactoryIndex, CodeFix, DefinedSymbol,
    DefinitionAbortKind, Diagnostic, FactoryMember, FactoryWord, FixSafety,
    LogicalSourceObjectMembers, ManufacturerSpec, MemberRetractionRecord, MemberSide,
    MetaclassProvenance, MethodDef, ObjectMemberState, ObjectMethodDef, ProcArgTrait, ProcDef,
    PropertyDef, QualifiedVarRef, RenamedMember, Scope, ScopeKind, Severity, StubFlags,
    SubclassProvidedMethods, UnknownProcInfo, VarDef, class_constructor_key, class_destructor_key,
    class_member_key, class_property_key,
};
// The one `# noqa` / `# tcl-lsp: disable=…` suppression contract, beside the
// pre-scan that builds the map it reads. Every diagnostic surface — the
// language server's publish path, the `diag` / `lint` / `validate` CLI verbs,
// the source-style and SslicTcl projections — asks through it, so a directive
// means the same thing everywhere.
pub use utils::{FILE_SUPPRESS_KEY, line_suppressed};
