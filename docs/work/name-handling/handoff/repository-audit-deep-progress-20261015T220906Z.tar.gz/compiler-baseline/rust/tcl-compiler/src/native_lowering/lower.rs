// tcl-lsp — a language server and toolchain for Tcl
// Copyright (C) 2026 James Deucker (bitwisecook) <https://github.com/bitwisecook>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.
//
// SPDX-License-Identifier: AGPL-3.0-or-later

//! Lowering from the executable semantic IR to NLIR.
//!
//! Every executable block becomes one NLIR block and every instruction one
//! statement. Statements are selected by registry descriptor — the
//! [`LoweringHookId`] an already-lowered operation carries, or the
//! [`NativeLowering`] shape of a resolved invocation — never by command name.
//! A dispatch-stability proof at the site decides whether an intrinsic or a
//! fixed completion may be taken directly; otherwise the generic argv
//! invocation is kept. Anything the lowering cannot express structurally
//! becomes the source-text rung with a typed reason.

use std::collections::{BTreeMap, HashMap, HashSet};

use tcl_core_types::Code as CompletionCode;
use tcl_dialect::DialectProfile;
use tcl_registry::hooks::LoweringHookId;
use tcl_registry::model::semantic::SemanticContext;
use tcl_registry::native_boolean_truth::{
    NativeBooleanExpressionResultProduction, NativeBooleanTruthPurpose,
};
use tcl_registry::{CellUpdate, CommandRegistry, IntrinsicId, NativeLowering};
use tcl_syntax::expr::ast::render_expr;
use tcl_syntax::expr::{BinOp, ExprNode, UnaryOp};
use tcl_syntax::number::{Number, Numbers};

use super::cells::{
    CellPlace, ShadowState, VariableWordDecline, cell_place, has_substitution, name_data_place,
    variable_reference_place, variable_word_place, whole_reference,
};
use super::elide::{BarrierDecision, CellDemotion, TraceLedger};
use super::ir::{
    CmpOp, CompareKind, EntryProtocol, IfElseResult, IntOp, NativeBlock, NativeBlockId,
    NativeFunction, NativeOp, NativeStatement, NativeTerminator, NativeType, NativeValue,
    NativeValueId, StatementSite,
};
use super::representation::{
    Representation, cmp_op, double_op, double_result_defined, exactly_representable_as_double,
    int_op, numeric_hint, proven_int_result, proven_neg_result,
};
use super::{
    CellAccessKind, CellAccessRecord, FunctionDecline, FunctionReport, FunctionStatus,
    NativeBinding, NativeLoweringDecline, StatementOutcome, StatementRecord,
};
use crate::codegen::structured::command_text;
use crate::command_binding::ModuleCommandMutations;
use crate::dispatch_proof::{
    DispatchEntryAssumption, DispatchProofAnalysis, analyse_original_dispatch_stability,
};
use crate::executable_ir::{
    ExecutableArgvId, ExecutableBlock, ExecutableExpr, ExecutableFunction, ExecutableInstruction,
    ExecutableTerminator, ExecutableValueId, GenericInvoke, InvocationResolution, LoweredOperation,
};
use crate::intervals::Interval;
use crate::ir::{CommandTokens, Module, NodeId, SourceSite, Statement, WordExpr, WordPart};
use crate::registry_invocation::{
    InvocationMetadataContext, RegistryInvocationResolution, resolve_word_exprs,
    resolved_tokens_invocation_with_metadata_context,
};
use crate::semantic_optimisation::{SemanticOptimisationConfig, SemanticOptimisationPassId};
use crate::types::TypeShape;
use crate::var_escape::types::ProcEscapeSummary;

/// Recursion cap for nested command substitution and compound-word parts.
const MAX_WORD_DEPTH: u32 = 32;

/// Everything the lowering of one function needs.
pub struct LoweringInput<'a> {
    /// The command registry.
    pub registry: &'a CommandRegistry,
    /// The semantic context invocations were resolved under.
    pub context: Option<SemanticContext>,
    /// The executable function to lower.
    pub function: &'a ExecutableFunction,
    /// The unit's source text (for the source-text rung only).
    pub source: &'a str,
    /// The lowered module: trace targets and procedures.
    pub module: &'a Module,
    /// The compilation unit's prepared whole-module command-mutation summary.
    pub mutations: &'a ModuleCommandMutations,
    /// The enabled semantic optimisation passes.
    pub config: SemanticOptimisationConfig,
    /// The escape summary of a procedure body, when lowering one.
    pub escape: Option<&'a ProcEscapeSummary>,
    /// Whether this is the top-level script.
    pub top_level: bool,
    /// The offset in `source` the enclosing body opens at: `0` for the
    /// top-level script, the procedure body's first content byte for a
    /// procedure. A statement's absolute span less this offset is its
    /// body-relative position, which is the line `errorInfo` reports.
    pub line_origin: u32,
    /// The dispatch entry contract the world proofs are made under.
    pub entry_assumption: DispatchEntryAssumption,
    /// Front-end type shapes per variable name, joined over every SSA
    /// version, used only as fast-path hints.
    pub type_hints: &'a BTreeMap<String, TypeShape>,
}

/// Why an expression could not be lowered natively; the whole expression
/// then goes to the runtime expression intrinsic.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum ExprDecline {
    CommandSubstitution,
    SubstitutedString,
    DynamicVariable,
    UnsupportedOperator,
    Raw,
    OriginalBooleanObjectUnavailable,
}

/// Lower one executable function to NLIR.
pub fn lower_function(
    input: &LoweringInput<'_>,
) -> Result<(NativeFunction, FunctionReport), FunctionDecline> {
    if !input
        .config
        .is_enabled(SemanticOptimisationPassId::NativeLowering)
    {
        return Err(FunctionDecline::PassDisabled);
    }
    if input
        .function
        .native_compilation_admission
        .as_ref()
        .is_some_and(|admission| admission.requires_native_provider())
    {
        return Err(FunctionDecline::NativeCompilationAdmissionRequired);
    }
    if input.function.validate().is_err() {
        return Err(FunctionDecline::InvalidExecutableIr);
    }
    if let Some(kind) = unlowered_instruction(input.function) {
        return Err(FunctionDecline::UnloweredInstruction(kind));
    }
    let mut lowerer = Lowerer::new(input);
    let function = lowerer.lower();
    if lowerer.boolean_admission_missing {
        return Err(FunctionDecline::NativeCompilationAdmissionRequired);
    }
    let report = FunctionReport {
        status: FunctionStatus::Lowered,
        // The emitter decides binding, once it knows whether the module
        // installed an entry for the body.
        binding: NativeBinding::NotApplicable,
        statements: lowerer.records,
    };
    Ok((function, report))
}

/// The first executable instruction kind this lowering does not project.
fn unlowered_instruction(function: &ExecutableFunction) -> Option<&'static str> {
    // No partial lowering: the original wrapper would replay phases already
    // represented by executable edges. Reject before constructing the lowerer.
    if function.blocks.iter().any(|block| {
        matches!(
            block.terminator,
            Some(ExecutableTerminator::RegionChoice { .. })
        )
    }) {
        return Some("evaluated-body-region");
    }
    function
        .blocks
        .iter()
        .flat_map(|block| &block.instructions)
        .find_map(|instruction| match instruction {
            ExecutableInstruction::CompleteEvaluatedRegion(_) => Some("evaluated-body-region"),
            ExecutableInstruction::IterateLists { .. } => Some("iterate-lists"),
            ExecutableInstruction::MatchPattern { .. } => Some("match-pattern"),
            ExecutableInstruction::JoinCompletion { .. } => Some("join-completion"),
            ExecutableInstruction::WriteCompletionCell { .. } => Some("write-completion-cell"),
            ExecutableInstruction::EvaluateExpr {
                expr: ExecutableExpr::Operand { .. },
                ..
            } => Some("operand-expression"),
            ExecutableInstruction::EvaluateExpr {
                expr: ExecutableExpr::TrapPrefix { .. },
                ..
            } => Some("trap-prefix"),
            _ => None,
        })
}

/// Native truth stages require a current complete source input and its
/// independently retained interpreter entry. Availability does not select a
/// physical point, and stale entry metadata cannot donate its point.
fn native_boolean_dialect(input: &LoweringInput<'_>) -> Option<tcl_registry::InvocationDialect> {
    let metadata = InvocationMetadataContext::for_module(input.registry, input.module)?;
    if input
        .module
        .source_entry
        .metadata_context
        .source_analysis_input()
        != metadata.source_analysis_input()
    {
        return None;
    }
    let entry = input.module.source_entry.native_entry.as_deref()?;
    entry
        .execution_point
        .map(tcl_registry::InvocationDialect::of_point)
}

struct Lowerer<'a> {
    input: &'a LoweringInput<'a>,
    original_invocations: Option<super::original_invocations::OriginalInvocations>,
    values: Vec<NativeValue>,
    exec_values: HashMap<ExecutableValueId, NativeValueId>,
    argvs: HashMap<ExecutableArgvId, Vec<NativeValueId>>,
    ledger: TraceLedger<'a>,
    demotion: CellDemotion<'a>,
    mutations: &'a ModuleCommandMutations,
    proofs: DispatchProofAnalysis,
    numbers: Numbers,
    dialect: Option<&'static DialectProfile>,
    /// A current source owner and independently retained physical entry select
    /// the truth recipe; an authored profile alone supplies no opcode protocol.
    boolean_dialect: Option<tcl_registry::InvocationDialect>,
    boolean_admission_missing: bool,
    /// The document's lexer grammar, resolved once with `dialect` and
    /// threaded into every re-read of source text this pass makes
    /// (`docs/design/registry/dialect-profile-model.md` §2.5).
    lexer_config: tcl_lexer::LexerConfig,
    representation: bool,
    mathfunc_native: bool,
    declined_nodes: BTreeMap<NodeId, NativeLoweringDecline>,
    /// The enclosing command's source site per node, so a statement that
    /// evaluates one word of a command still names the whole command in an
    /// `errorInfo` frame — which is what the eval loop logs.
    command_sites: BTreeMap<NodeId, SourceSite>,
    /// Nodes whose operand words dispatched a runtime command (a nested
    /// invocation, a math function through the command table, a runtime
    /// expression) or read a cell whose trace barrier was kept, so the
    /// site's own operand-admissibility verdict must stand.
    observing_nodes: HashSet<NodeId>,
    current_node: Option<NodeId>,
    current_site: Option<StatementSite>,
    shadows: ShadowState,
    exit_shadows: Vec<Option<ShadowState>>,
    records: Vec<StatementRecord>,
    current: Option<StatementRecord>,
    ops: Vec<Vec<NativeOp>>,
    max_argc: usize,
}

impl<'a> Lowerer<'a> {
    fn new(input: &'a LoweringInput<'a>) -> Self {
        let module = input.module;
        let ledger = TraceLedger::new(
            &module.traced_variables,
            // A source trace ledger cannot enumerate observers already installed
            // in an independently entered native frame. Retain the runtime bit.
            module.has_dynamic_variable_trace || module.source_entry.native_entry.is_some(),
            input.config,
        );
        let demotion = if input.top_level {
            CellDemotion::top_level(input.config)
        } else {
            // Named escape summaries are advisory. An actual native entry
            // requires a separately retained byte/ordinal/layout projection;
            // this lowering does not yet consume that capability.
            CellDemotion::procedure(
                input
                    .escape
                    .filter(|_| input.module.source_entry.native_entry.is_none()),
                input.config,
            )
        };
        let environment = input.context.map(SemanticContext::environment_id);
        // The document's profile, taken from the ingress rather than found
        // on a catalogue row by name. `DialectProfile::find` answers `None`
        // for an environment with a Tcl ladder and no row — `jim` — so a
        // name lookup here would hand this pass the permissive fallback and
        // lower a Jim unit as Tcl 9.0. The
        // context's id is already the ingress's canonical one, so this is a
        // keyed lookup, not a second resolution of a user string, and
        // `unit_profile` is the same door `CompilationUnit::build_for_dialect`
        // uses (so `tk` keeps its typed profile).
        let profile = environment
            .map(|id| crate::environment_ingress::resolve_environment(id).unit_profile());
        // `expr` resolves `abs(…)` through the command table, so a native
        // math function is only sound while nothing in the module can have
        // replaced one: no dynamic trace, no proc declaring one, and no
        // `rename` / `interp alias` touching the namespace (a dynamic
        // mutation could touch anything).
        let mutations = input.mutations;
        let mathfunc_native = !module.has_dynamic_trace
            && !mutations.has_dynamic_mutation()
            && !mutations.changes_command_resolution()
            && !mutations.rebinds_under("::tcl::mathfunc::")
            && !module.procedures.values().any(|procedure| {
                procedure.publication.as_ref().is_none_or(|publication| {
                    publication.slot().namespace.as_segments()
                        == [
                            tcl_core_types::NameBytes::from("tcl"),
                            tcl_core_types::NameBytes::from("mathfunc"),
                        ]
                })
            });
        Self {
            input,
            original_invocations: super::original_invocations::OriginalInvocations::for_module(
                module,
                input.registry,
                input.source,
            ),
            values: Vec::new(),
            exec_values: HashMap::new(),
            argvs: HashMap::new(),
            ledger,
            demotion,
            mutations,
            proofs: analyse_original_dispatch_stability(
                input.function,
                input.entry_assumption,
                input.registry,
                crate::registry_invocation::InvocationMetadataContext::for_module(
                    input.registry,
                    module,
                ),
            ),
            numbers: Numbers::Target(module.number_syntax()),
            dialect: profile,
            boolean_dialect: native_boolean_dialect(input),
            boolean_admission_missing: false,
            lexer_config: module.native_lexer_config(),
            representation: input
                .config
                .is_enabled(SemanticOptimisationPassId::RepresentationInference),
            mathfunc_native,
            declined_nodes: BTreeMap::new(),
            command_sites: BTreeMap::new(),
            observing_nodes: HashSet::new(),
            current_node: None,
            current_site: None,
            shadows: ShadowState::default(),
            exit_shadows: vec![None; input.function.blocks.len()],
            records: Vec::new(),
            current: None,
            ops: Vec::new(),
            max_argc: 0,
        }
    }

    // Values and operations.

    fn new_value(&mut self, ty: NativeType, rep: Representation) -> NativeValueId {
        let id = NativeValueId(u32::try_from(self.values.len()).expect("value count fits u32"));
        self.values.push(NativeValue { ty, rep });
        if let Some(record) = &mut self.current {
            record
                .representations
                .push(self.values[id.0 as usize].rep.kind_str());
        }
        id
    }

    fn ty(&self, id: NativeValueId) -> NativeType {
        self.values[id.0 as usize].ty
    }

    fn rep(&self, id: NativeValueId) -> &Representation {
        &self.values[id.0 as usize].rep
    }

    fn emit(&mut self, op: NativeOp) {
        self.ops
            .last_mut()
            .expect("an open operation buffer")
            .push(op);
    }

    fn push_buffer(&mut self) {
        self.ops.push(Vec::new());
    }

    fn pop_buffer(&mut self) -> Vec<NativeOp> {
        self.ops.pop().expect("a buffer to pop")
    }

    /// Run `f` in a fresh buffer; keep its operations only when it succeeds.
    fn attempt<T, E>(&mut self, f: impl FnOnce(&mut Self) -> Result<T, E>) -> Result<T, E> {
        self.push_buffer();
        let outcome = f(self);
        let ops = self.pop_buffer();
        if outcome.is_ok() {
            self.ops
                .last_mut()
                .expect("an enclosing buffer")
                .extend(ops);
        }
        outcome
    }

    fn const_int(&mut self, value: i64) -> NativeValueId {
        let dst = self.new_value(NativeType::I64, Representation::exact_int(value));
        self.emit(NativeOp::ConstInt { dst, value });
        dst
    }

    fn const_str(&mut self, text: &str) -> NativeValueId {
        let dst = self.new_value(NativeType::Obj, Representation::Boxed(None));
        self.emit(NativeOp::ConstStr {
            dst,
            text: text.to_owned(),
        });
        dst
    }

    /// The boxed form of `value`.
    fn boxed(&mut self, value: NativeValueId) -> NativeValueId {
        if self.ty(value) == NativeType::Obj {
            return value;
        }
        let shape = match self.rep(value) {
            Representation::NativeInt(_) => Some(TypeShape::Int),
            Representation::NativeDouble { .. } => Some(TypeShape::Double),
            Representation::NativeBool => Some(TypeShape::Boolean),
            _ => None,
        };
        let dst = self.new_value(NativeType::Obj, Representation::Boxed(shape));
        self.emit(NativeOp::Box { dst, src: value });
        dst
    }

    /// Convert the original operand at its actual reached instruction.
    /// Canonical Boolean values need no object conversion; all other values
    /// remain boxed so the selected getter observes their original cache.
    fn truth(&mut self, value: NativeValueId, purpose: NativeBooleanTruthPurpose) -> NativeValueId {
        if self.ty(value) == NativeType::Bool {
            return value;
        }
        if self
            .boolean_dialect
            .and_then(|dialect| dialect.native_boolean_truth_protocol(purpose))
            .is_none()
        {
            self.boolean_admission_missing = true;
        }
        debug_assert_eq!(self.ty(value), NativeType::Obj);
        let src = value;
        let dst = self.new_value(NativeType::Bool, Representation::NativeBool);
        self.emit(NativeOp::UnboxBool { dst, src, purpose });
        dst
    }

    fn expression_result_truth(
        &mut self,
        value: NativeValueId,
        production: NativeBooleanExpressionResultProduction,
    ) -> NativeValueId {
        if self
            .boolean_dialect
            .and_then(|dialect| dialect.native_boolean_expression_result_protocol(production))
            .is_none()
        {
            self.boolean_admission_missing = true;
        }
        let src = self.boxed(value);
        let dst = self.new_value(NativeType::Bool, Representation::NativeBool);
        self.emit(NativeOp::BooleanExpressionResult {
            dst,
            src,
            production,
        });
        dst
    }

    fn int_to_double(&mut self, value: NativeValueId) -> NativeValueId {
        let dst = self.new_value(
            NativeType::F64,
            Representation::NativeDouble { finite: true },
        );
        self.emit(NativeOp::IntToDouble { dst, src: value });
        dst
    }

    fn bool_to_int(&mut self, value: NativeValueId) -> NativeValueId {
        let dst = self.new_value(
            NativeType::I64,
            Representation::NativeInt(Interval {
                lo: Some(0),
                hi: Some(1),
            }),
        );
        self.emit(NativeOp::BoolToInt { dst, src: value });
        dst
    }

    // Cells.

    fn record_cell(
        &mut self,
        place: &CellPlace,
        access: CellAccessKind,
        barrier: BarrierDecision,
        shadowed: bool,
    ) {
        let storage = self.demotion.decide(place.base());
        if let Some(record) = &mut self.current {
            record.cells.push(CellAccessRecord {
                place: place.spelling(),
                access,
                storage,
                barrier,
                shadowed,
            });
        }
    }

    /// Read `place`, reusing its native shadow when one is live.
    fn read_cell(&mut self, place: &CellPlace) -> NativeValueId {
        if let Some(value) = self.shadows.read(place) {
            let barrier = self.ledger.decide(place);
            self.record_cell(place, CellAccessKind::Read, barrier, true);
            return value;
        }
        self.read_original_cell(place)
    }

    /// A reached Boolean operand retains the actual cell's object and cache,
    /// independently of an equal numeric value in the shadow lattice.
    fn read_original_cell(&mut self, place: &CellPlace) -> NativeValueId {
        let hint = self.input.type_hints.get(place.base()).cloned();
        let dst = self.new_value(NativeType::Obj, Representation::Boxed(hint));
        let barrier = self.ledger.decide(place);
        self.emit(NativeOp::CellRead {
            dst,
            place: place.clone(),
            barrier,
        });
        if barrier.is_elided() {
            self.shadows.write(place.clone(), dst);
        } else {
            self.note_observation();
        }
        self.record_cell(place, CellAccessKind::Read, barrier, false);
        dst
    }

    /// Write `boxed` into `place`; `shadow` is the value later reads may
    /// reuse (the native form of `boxed`, when there is one).
    fn write_cell(&mut self, place: &CellPlace, boxed: NativeValueId, shadow: NativeValueId) {
        let barrier = self.ledger.decide(place);
        self.emit(NativeOp::CellWrite {
            place: place.clone(),
            src: boxed,
            barrier,
        });
        if barrier.is_elided() {
            self.shadows.write(place.clone(), shadow);
        } else {
            self.shadows.forget_base(place.base());
        }
        self.record_cell(place, CellAccessKind::Write, barrier, false);
    }

    fn clobber_shadows(&mut self) {
        self.shadows.clobber();
    }

    /// Record that the statement's operand words observed the world through
    /// a runtime dispatch or an unproven cell read.
    fn note_observation(&mut self) {
        if let Some(node) = &self.current_node {
            self.observing_nodes.insert(node.clone());
        }
    }

    // Driver.

    fn lower(&mut self) -> NativeFunction {
        let function = self.input.function;
        self.prescan();
        let (order, headers, predecessors) = block_order(function);
        let mut blocks: Vec<Option<NativeBlock>> = vec![None; function.blocks.len()];
        for index in order {
            let block = &function.blocks[index];
            self.shadows = match predecessors[index].as_slice() {
                [only] if !headers.contains(&index) => {
                    self.exit_shadows[*only].clone().unwrap_or_default()
                }
                _ => ShadowState::default(),
            };
            let mut statements = Vec::with_capacity(block.instructions.len());
            for (position, instruction) in block.instructions.iter().enumerate() {
                statements.push(self.lower_instruction(block, index, position, instruction));
            }
            let terminator = self.lower_terminator(block);
            self.exit_shadows[index] = Some(std::mem::take(&mut self.shadows));
            blocks[index] = Some(NativeBlock {
                id: NativeBlockId(u32::try_from(index).unwrap_or(u32::MAX)),
                statements,
                terminator,
            });
        }
        let blocks = blocks
            .into_iter()
            .enumerate()
            .map(|(index, block)| {
                block.unwrap_or_else(|| NativeBlock {
                    id: NativeBlockId(u32::try_from(index).unwrap_or(u32::MAX)),
                    statements: Vec::new(),
                    terminator: NativeTerminator::Return(unreachable_completion(function)),
                })
            })
            .collect();
        NativeFunction {
            native_compilation_admission: function.native_compilation_admission.clone(),
            values: std::mem::take(&mut self.values),
            blocks,
            entry: NativeBlockId(u32::try_from(function.entry.index()).unwrap_or(u32::MAX)),
            completion_count: completion_count(function),
            max_argc: self.max_argc,
            protocol: if self.input.top_level {
                EntryProtocol::Script
            } else {
                EntryProtocol::ProcEntry
            },
        }
    }

    /// Decide, before any operation is emitted, which invocation nodes must
    /// keep the source-text rung because one of their words cannot be
    /// evaluated structurally.
    fn prescan(&mut self) {
        for block in &self.input.function.blocks {
            for instruction in &block.instructions {
                // The command site every statement of this command reports.
                // A word evaluation carries only its *word's* site, but the
                // eval loop logs the whole command, so the command-carrying
                // instructions publish theirs for the whole node.
                match instruction {
                    ExecutableInstruction::Invoke(invoke) => {
                        self.command_sites
                            .insert(invoke.node.clone(), invoke.source.clone());
                    }
                    ExecutableInstruction::ExecuteLowered(operation) => {
                        self.command_sites
                            .insert(operation.node.clone(), operation.source.clone());
                    }
                    ExecutableInstruction::ExecuteOpaqueRegion(region) => {
                        self.command_sites
                            .insert(region.node.clone(), region.source.clone());
                    }
                    ExecutableInstruction::CompleteStructuredRegion(region) => {
                        self.command_sites
                            .insert(region.node.clone(), region.source.clone());
                    }
                    _ => {}
                }
                match instruction {
                    ExecutableInstruction::Invoke(invoke) => {
                        if let Err(reason) = self.words_lowerable(&invoke.original_words, 0) {
                            self.declined_nodes.insert(invoke.node.clone(), reason);
                        }
                    }
                    ExecutableInstruction::ExpandWord { node, .. } => {
                        self.declined_nodes
                            .insert(node.clone(), NativeLoweringDecline::ArgumentExpansion);
                    }
                    _ => {}
                }
            }
        }
    }

    fn lower_terminator(&mut self, block: &ExecutableBlock) -> NativeTerminator {
        let target = |id: crate::executable_ir::ExecutableBlockId| {
            NativeBlockId(u32::try_from(id.index()).unwrap_or(u32::MAX))
        };
        match block
            .terminator
            .as_ref()
            .expect("a validated executable block is terminated")
        {
            ExecutableTerminator::RegionChoice { .. } => {
                unreachable!("the function-level pre-check declines evaluated regions")
            }
            ExecutableTerminator::Goto(next) => NativeTerminator::Goto(target(*next)),
            ExecutableTerminator::Branch {
                condition,
                then_target,
                else_target,
            } => {
                let condition = self.exec_values[condition];
                debug_assert_eq!(self.ty(condition), NativeType::Bool);
                NativeTerminator::Branch {
                    condition,
                    then_target: target(*then_target),
                    else_target: target(*else_target),
                }
            }
            ExecutableTerminator::CompletionSwitch {
                completion,
                cases,
                default,
            } => NativeTerminator::CompletionSwitch {
                completion: *completion,
                cases: cases
                    .iter()
                    .map(|case| {
                        (
                            i32::try_from(case.code.as_int()).unwrap_or(i32::MAX),
                            target(case.target),
                        )
                    })
                    .collect(),
                default: target(*default),
            },
            ExecutableTerminator::ReturnCompletion(completion) => {
                NativeTerminator::Return(*completion)
            }
        }
    }

    fn begin(&mut self, node: Option<&NodeId>, instruction: &'static str) {
        self.current_node = node.cloned();
        self.current_site = node.and_then(|node| self.statement_site(node));
        self.current = Some(StatementRecord {
            node: node.cloned(),
            instruction,
            outcome: StatementOutcome::Empty,
            cells: Vec::new(),
            representations: Vec::new(),
        });
        self.push_buffer();
    }

    /// The command site an `errorInfo` frame for `node` names: its exact
    /// source text and its 1-based line within the body being compiled.
    fn statement_site(&self, node: &NodeId) -> Option<StatementSite> {
        let source = self.command_sites.get(node)?;
        let text = command_text(
            self.input.source,
            source.span,
            &self.input.module.source,
            self.input.module.lexer_config,
        )
        .to_owned();
        Some(StatementSite {
            line: body_line(
                self.input.source,
                self.input.line_origin,
                source.span.start(),
            ),
            text,
        })
    }

    fn finish(
        &mut self,
        completion: crate::executable_ir::CompletionId,
        node: Option<&NodeId>,
        outcome: StatementOutcome,
    ) -> NativeStatement {
        let ops = self.pop_buffer();
        let mut record = self.current.take().expect("an open statement record");
        record.outcome = outcome;
        self.records.push(record);
        NativeStatement {
            completion,
            node: node.cloned(),
            site: self.current_site.take(),
            ops,
        }
    }

    fn eval_source(&mut self, source: &SourceSite, reason: NativeLoweringDecline) {
        let text = command_text(
            self.input.source,
            source.span,
            &self.input.module.source,
            self.input.module.lexer_config,
        )
        .to_owned();
        self.emit(NativeOp::EvalSource { text, reason });
        self.clobber_shadows();
    }

    #[allow(clippy::too_many_lines)]
    fn lower_instruction(
        &mut self,
        block: &ExecutableBlock,
        block_index: usize,
        position: usize,
        instruction: &ExecutableInstruction,
    ) -> NativeStatement {
        match instruction {
            ExecutableInstruction::EvaluateWord {
                value,
                completion,
                word,
                node,
                ..
            } => {
                self.begin(Some(node), "evaluate-word");
                if self.declined_nodes.contains_key(node) {
                    return self.finish(*completion, Some(node), StatementOutcome::Empty);
                }
                match self.attempt(|this| this.lower_word(word, 0)) {
                    Ok(id) => {
                        self.exec_values.insert(*value, id);
                        self.finish(*completion, Some(node), StatementOutcome::Native)
                    }
                    Err(reason) => {
                        // The pre-scan admitted this word, so this cannot
                        // happen; fail closed onto the source rung anyway.
                        self.declined_nodes.insert(node.clone(), reason);
                        self.finish(*completion, Some(node), StatementOutcome::Empty)
                    }
                }
            }
            ExecutableInstruction::ExpandWord {
                completion, node, ..
            } => {
                self.begin(Some(node), "expand-word");
                self.finish(*completion, Some(node), StatementOutcome::Empty)
            }
            ExecutableInstruction::BuildArgv {
                argv,
                completion,
                entries,
            } => {
                self.begin(None, "build-argv");
                let words: Option<Vec<NativeValueId>> = entries
                    .iter()
                    .map(|entry| match entry {
                        crate::executable_ir::ArgvEntry::Value(value) => {
                            self.exec_values.get(value).copied()
                        }
                        crate::executable_ir::ArgvEntry::Expanded(_) => None,
                    })
                    .collect();
                if let Some(words) = words {
                    self.argvs.insert(*argv, words);
                }
                self.finish(*completion, None, StatementOutcome::Empty)
            }
            ExecutableInstruction::Invoke(invoke) => {
                self.begin(Some(&invoke.node), "invoke");
                let outcome = self.lower_invoke(invoke, block_index, position);
                self.finish(invoke.completion, Some(&invoke.node), outcome)
            }
            ExecutableInstruction::ExecuteLowered(operation) => {
                self.begin(Some(&operation.node), "execute-lowered");
                let outcome = self.lower_lowered(operation);
                self.finish(operation.completion, Some(&operation.node), outcome)
            }
            ExecutableInstruction::ExecuteOpaqueRegion(region) => {
                self.begin(Some(&region.node), "execute-opaque-region");
                let reason = NativeLoweringDecline::OpaqueRegion(region.descriptor);
                self.eval_source(&region.source, reason);
                self.finish(
                    region.completion,
                    Some(&region.node),
                    StatementOutcome::EvalSource(reason),
                )
            }
            ExecutableInstruction::EvaluateExpr {
                value,
                completion,
                expr,
                node,
                ..
            } => {
                self.begin(Some(node), "evaluate-expr");
                let outcome = match expr {
                    ExecutableExpr::Condition { expr, .. } => {
                        let text = render_expr(expr);
                        let truth = self.lower_condition_expression(expr, &text);
                        self.exec_values.insert(*value, truth);
                        StatementOutcome::Native
                    }
                    ExecutableExpr::Operand { .. } | ExecutableExpr::TrapPrefix { .. } => {
                        unreachable!("the function-level pre-check declines structured operands")
                    }
                };
                self.finish(*completion, Some(node), outcome)
            }
            ExecutableInstruction::CompleteStructuredRegion(region) => {
                self.begin(Some(&region.node), "complete-structured-region");
                self.finish(
                    region.completion,
                    Some(&region.node),
                    StatementOutcome::Empty,
                )
            }
            ExecutableInstruction::CompleteEvaluatedRegion(_)
            | ExecutableInstruction::MatchPattern { .. }
            | ExecutableInstruction::IterateLists { .. }
            | ExecutableInstruction::JoinCompletion { .. }
            | ExecutableInstruction::WriteCompletionCell { .. } => {
                unreachable!("the function-level pre-check declines these instructions")
            }
        }
        .with_block(block)
    }

    // Invocations.

    fn lower_invoke(
        &mut self,
        invoke: &GenericInvoke,
        block_index: usize,
        position: usize,
    ) -> StatementOutcome {
        if let Some(reason) = self.declined_nodes.get(&invoke.node).copied() {
            self.eval_source(&invoke.source, reason);
            return StatementOutcome::EvalSource(reason);
        }
        let Some(argv) = self.argvs.get(&invoke.argv).cloned() else {
            let reason = NativeLoweringDecline::MissingCommandTokens;
            self.eval_source(&invoke.source, reason);
            return StatementOutcome::EvalSource(reason);
        };
        if invoke.registry_specialisation_arguments_exact()
            && let InvocationResolution::Resolved(facts) = &invoke.resolution
            && let Some(lowering) = self.invocation_native_lowering(invoke, facts)
        {
            // The site proof's operand-admissibility verdict is conservative
            // about command substitutions and variable reads in the operand
            // words; the lowering knows exactly which of those words
            // dispatched a command or read an unproven cell, so a node whose
            // words did neither may take the proof on its domain coverage.
            let words_observed = self.observing_nodes.contains(&invoke.node);
            let proven = self
                .proofs
                .site(
                    u32::try_from(block_index).unwrap_or(u32::MAX),
                    u32::try_from(position).unwrap_or(u32::MAX),
                )
                .is_some_and(|site| {
                    (site.operand_words_admissible || !words_observed)
                        && facts
                            .dispatch_dependencies
                            .iter()
                            .all(|domain| site.covers.contains(domain))
                });
            match lowering {
                NativeLowering::Intrinsic {
                    id: IntrinsicId::ChannelWrite,
                    arity,
                } if proven && argv.len() == 2 && arity.accepts(1) => {
                    self.emit(NativeOp::Puts { src: argv[1] });
                    if !cells_unobserved(&facts.effects) {
                        self.clobber_shadows();
                    }
                    return StatementOutcome::NativeIntrinsic;
                }
                NativeLowering::Completion(code) if proven && argv.len() == 1 => {
                    self.emit(NativeOp::Complete { code, result: None });
                    return StatementOutcome::NativeCompletion;
                }
                NativeLowering::CellReadModifyWrite(update) if proven && argv.len() >= 2 => {
                    if let Some(outcome) = self.lower_cell_update(update, invoke, &argv) {
                        return outcome;
                    }
                }
                NativeLowering::Definition if proven => {
                    if let Some(outcome) = self.lower_definition(invoke, &argv) {
                        return outcome;
                    }
                }
                _ => {}
            }
        }
        self.max_argc = self.max_argc.max(argv.len());
        self.emit(NativeOp::Invoke { argv });
        self.clobber_shadows();
        StatementOutcome::GenericInvoke
    }

    fn invocation_native_lowering(
        &self,
        invoke: &GenericInvoke,
        facts: &tcl_registry::InvocationFacts,
    ) -> Option<NativeLowering> {
        if self.source_absent_model() {
            return self.input.registry.native_lowering_for_descriptor(
                facts.descriptor_key(),
                self.input.registry.own_surface_query().as_ref(),
            );
        }
        let tokens = self.original_invocations.as_ref()?.command(invoke)?;
        let metadata = self.original_invocation_metadata(tokens)?;
        let selected = resolved_tokens_invocation_with_metadata_context(
            self.input.registry,
            Some(metadata),
            tokens,
        )?;
        (selected.facts.as_ref() == facts).then_some(())?;
        self.input.registry.native_lowering_for_descriptor(
            selected.facts.descriptor_key(),
            Some(&metadata.context().authoring_query()),
        )
    }

    fn original_invocation_metadata<'b>(
        &self,
        tokens: &'b crate::ir::CommandTokens,
    ) -> Option<InvocationMetadataContext<'b>> {
        let input = self.input.module.source_metadata_input.as_ref()?;
        tokens
            .source_binding
            .as_ref()?
            .original_invocation_metadata_for_input(tokens, input, self.input.registry)
    }

    /// A definition-time command (`proc`) whose body this module also
    /// compiled: the runtime binds the written source body exactly as `proc`
    /// does, and additionally binds the compiled entry the emitter installed
    /// for that body.
    ///
    /// The exact original allocating instruction selects the retained body.
    /// Missing or ambiguous body provenance keeps the generic invocation.
    fn lower_definition(
        &mut self,
        invoke: &GenericInvoke,
        argv: &[NativeValueId],
    ) -> Option<StatementOutcome> {
        let site = invoke.source_binding.as_ref()?.invocation_site()?;
        let mut matching = self
            .input
            .module
            .procedures
            .at_declaration(site)
            .filter(|(_, procedure)| procedure.span == invoke.source.span);
        let (id, procedure) = matching.next()?;
        if matching.next().is_some() {
            return None;
        }

        // A body the front end never captured (a synthetic or dynamic one)
        // has nothing for the runtime to bind; keep the generic invocation.
        let body_source = procedure.body_source.clone()?;
        // Every word this hands the runtime has to be the word the statement
        // actually writes; a substituted one keeps the generic invocation, and
        // the runtime's own `proc` — which evaluates the word at the call site,
        // as Tcl does — defines the procedure.
        if !definition_words_are_written_out(
            &invoke.original_words,
            &procedure.params_raw,
            &body_source,
        ) {
            return None;
        }
        if argv.len() != 4 {
            return None;
        }
        self.max_argc = self.max_argc.max(argv.len());
        self.emit(NativeOp::DefineProc {
            entry_key: *id,
            argv: argv.to_vec(),
        });
        self.clobber_shadows();
        Some(StatementOutcome::NativeDefinition)
    }

    /// `incr`/`append`/`lappend` reached as an invocation: the place is the
    /// first argument word, which must be a literal name.
    fn lower_cell_update(
        &mut self,
        update: CellUpdate,
        invoke: &GenericInvoke,
        argv: &[NativeValueId],
    ) -> Option<StatementOutcome> {
        let place = if let Some(binding) = &invoke.source_binding {
            let (_, mut tokens) = binding.original_recorded_command()?;
            (tokens.words() == invoke.original_words).then_some(())?;
            tokens.source_binding = Some(binding.clone());
            let value = crate::registry_invocation::original_literal_argument_data_for_module(
                self.input.registry,
                self.input.module,
                &tokens,
                0,
            )?;
            name_data_place(&value)?
        } else {
            self.source_absent_model().then_some(())?;
            let word = invoke.original_words.get(1)?;
            let crate::registry_invocation::EffectiveInvocationWord::Literal(value) =
                crate::registry_invocation::effective_invocation_word(
                    word,
                    self.lexer_config.escapes,
                    tcl_syntax::word_rules::WordValueRules::from_config(&self.lexer_config),
                )
            else {
                return None;
            };
            name_data_place(&value)?
        };
        match update {
            CellUpdate::Increment => {
                if argv.len() > 3 {
                    return None;
                }
                let delta = match argv.get(2) {
                    Some(value) => *value,
                    None => self.const_int(1),
                };
                self.lower_incr(&place, delta);
                Some(StatementOutcome::Native)
            }
            CellUpdate::Append | CellUpdate::ListAppend => {
                let barrier = self.ledger.decide(&place);
                self.emit(NativeOp::CellAppend {
                    place: place.clone(),
                    values: argv[2..].to_vec(),
                    list: update == CellUpdate::ListAppend,
                    barrier,
                });
                self.shadows.forget_base(place.base());
                self.record_cell(&place, CellAccessKind::Update, barrier, false);
                Some(StatementOutcome::Native)
            }
        }
    }

    /// `incr place delta`: native when the cell's shadow and the delta are
    /// proven-in-range integers, else the guarded runtime read-modify-write.
    fn lower_incr(&mut self, place: &CellPlace, delta: NativeValueId) {
        let shadow = self.shadows.read(place);
        if let (Some(current), NativeType::I64) = (shadow, self.ty(delta))
            && self.ty(current) == NativeType::I64
            && let (Some(lhs), Some(rhs)) =
                (self.rep(current).interval(), self.rep(delta).interval())
            && let Some(result) = proven_int_result(IntOp::Add, lhs, rhs)
        {
            let dst = self.new_value(NativeType::I64, Representation::NativeInt(result));
            self.emit(NativeOp::IntBinary {
                dst,
                op: IntOp::Add,
                lhs: current,
                rhs: delta,
            });
            let boxed = self.boxed(dst);
            self.write_cell(place, boxed, dst);
            return;
        }
        let barrier = self.ledger.decide(place);
        let guard = self.ledger.incr_guard(place);
        let dst = self.new_value(NativeType::Obj, Representation::Boxed(Some(TypeShape::Int)));
        self.emit(NativeOp::CellIncr {
            dst,
            place: place.clone(),
            delta,
            guard,
            barrier,
        });
        if barrier.is_elided() {
            self.shadows.write(place.clone(), dst);
        } else {
            self.shadows.forget_base(place.base());
        }
        self.record_cell(place, CellAccessKind::Update, barrier, shadow.is_some());
    }

    fn source_absent_model(&self) -> bool {
        self.input.module.source.is_empty()
            && self.input.module.retained_source_bindings.is_none()
            && self.input.module.source_metadata_input.is_none()
            && self.input.module.source_entry.native_entry.is_none()
            && self
                .input
                .module
                .source_entry
                .metadata_context
                .is_standalone()
            && !self.input.module.source_entry.unknown_entry
    }

    fn lowered_name_place(
        &self,
        operation: &LoweredOperation,
        name: &str,
        braced: bool,
    ) -> Option<CellPlace> {
        if let Some(tokens) = operation.original_tokens.as_deref() {
            (operation.source.provenance == crate::ir::Provenance::Source).then_some(())?;
            let (command, _) = tokens
                .source_binding
                .as_ref()?
                .original_recorded_command()?;
            (command.span == operation.source.span).then_some(())?;
            (tokens.argv_texts.get(1).map(String::as_str) == Some(name)).then_some(())?;
            let value = crate::registry_invocation::original_literal_argument_data_for_module(
                self.input.registry,
                self.input.module,
                tokens,
                0,
            )?;
            return name_data_place(&value);
        }
        self.source_absent_model().then_some(())?;
        cell_place(name, braced)
    }

    fn original_lowered_argument<'b>(
        &self,
        operation: &'b LoweredOperation,
        argument: usize,
        expected: &str,
    ) -> Option<crate::registry_invocation::OriginalSourceArgument<'b>> {
        let tokens = operation.original_tokens.as_deref()?;
        (operation.source.provenance == crate::ir::Provenance::Source).then_some(())?;
        let (command, _) = tokens
            .source_binding
            .as_ref()?
            .original_recorded_command()?;
        (command.span == operation.source.span).then_some(())?;
        (tokens
            .argv_texts
            .get(argument.checked_add(1)?)
            .map(String::as_str)
            == Some(expected))
        .then_some(())?;
        crate::registry_invocation::original_source_argument_for_module(
            self.input.registry,
            self.input.module,
            tokens,
            argument,
        )
    }

    fn lower_original_operand(
        &mut self,
        operation: &LoweredOperation,
        text: &str,
    ) -> Option<NativeValueId> {
        if self.source_absent_model() {
            return self.lower_operand_word(text);
        }
        let argument = self.original_lowered_argument(operation, 1, text)?;
        if let Some(text) = argument.literal_data() {
            if self.representation
                && let Some(Number::Int(value)) = self.numbers.parse_whole(&text)
                && value.to_string() == text
            {
                return Some(self.const_int(value));
            }
            return Some(self.const_str(&text));
        }
        let (spelling, source) = argument.word().sole_variable_substitution()?;
        tcl_syntax::naming::whole_scalar_variable_reference_name(spelling, self.lexer_config)?;
        let place = variable_place(spelling, source, self.lexer_config).ok()?;
        let value = self.read_cell(&place);
        Some(self.as_int_operand(value))
    }

    // Already-lowered operations.

    #[allow(clippy::too_many_lines)]
    fn lower_lowered(&mut self, operation: &LoweredOperation) -> StatementOutcome {
        match &operation.statement {
            Statement::AssignConst {
                name,
                name_braced,
                value,
                ..
            } => {
                let Some(place) = self.lowered_name_place(operation, name, *name_braced) else {
                    return self
                        .decline(&operation.source, NativeLoweringDecline::ComputedCellName);
                };
                let original;
                let value = if self.source_absent_model() {
                    value.as_str()
                } else {
                    let Some(argument) = self.original_lowered_argument(operation, 1, value) else {
                        return self.decline(
                            &operation.source,
                            NativeLoweringDecline::MissingCommandTokens,
                        );
                    };
                    let Some(value) = argument.literal_data() else {
                        return self
                            .decline(&operation.source, NativeLoweringDecline::SubstitutedOperand);
                    };
                    original = value;
                    &original
                };
                let boxed = self.const_str(value);
                let shadow = self.native_constant(value).unwrap_or(boxed);
                self.write_cell(&place, boxed, shadow);
                StatementOutcome::Native
            }
            Statement::AssignValue {
                name,
                name_braced,
                value,
                tokens,
                ..
            } => {
                let Some(place) = self.lowered_name_place(operation, name, *name_braced) else {
                    return self
                        .decline(&operation.source, NativeLoweringDecline::ComputedCellName);
                };
                let word = if self.source_absent_model() {
                    value_word(tokens.as_ref()).cloned()
                } else {
                    let Some(argument) = self.original_lowered_argument(operation, 1, value) else {
                        return self.decline(
                            &operation.source,
                            NativeLoweringDecline::MissingCommandTokens,
                        );
                    };
                    if let Some(value) = argument.literal_data() {
                        let boxed = self.const_str(&value);
                        let shadow = self.native_constant(&value).unwrap_or(boxed);
                        self.write_cell(&place, boxed, shadow);
                        return StatementOutcome::Native;
                    }
                    if matches!(
                        argument.word(),
                        WordExpr::Literal { .. } | WordExpr::BracedLiteral { .. }
                    ) {
                        return self
                            .decline(&operation.source, NativeLoweringDecline::SubstitutedOperand);
                    }
                    Some(argument.word().clone())
                };
                let Some(word) = word else {
                    return self.decline(
                        &operation.source,
                        NativeLoweringDecline::MissingCommandTokens,
                    );
                };
                if let WordExpr::Literal { text, .. } | WordExpr::BracedLiteral { text, .. } = &word
                    && !text.contains('\\')
                {
                    let boxed = self.const_str(text);
                    let shadow = self.native_constant(text).unwrap_or(boxed);
                    self.write_cell(&place, boxed, shadow);
                    return StatementOutcome::Native;
                }
                match self.attempt(|this| this.lower_word(&word, 0)) {
                    Ok(value) => {
                        self.write_cell(&place, value, value);
                        StatementOutcome::Native
                    }
                    Err(reason) => self.decline(&operation.source, reason),
                }
            }
            Statement::AssignExpr {
                name,
                name_braced,
                expr,
                ..
            } => {
                let Some(place) = self.lowered_name_place(operation, name, *name_braced) else {
                    return self
                        .decline(&operation.source, NativeLoweringDecline::ComputedCellName);
                };
                let value = self.lower_expression(expr);
                let boxed = self.boxed(value);
                self.write_cell(&place, boxed, value);
                StatementOutcome::Native
            }
            Statement::Incr {
                name,
                name_braced,
                amount,
                ..
            } => {
                let Some(place) = self.lowered_name_place(operation, name, *name_braced) else {
                    return self
                        .decline(&operation.source, NativeLoweringDecline::ComputedCellName);
                };
                let delta = match amount.as_deref() {
                    None => self.const_int(1),
                    Some(text) => match self.lower_original_operand(operation, text) {
                        Some(value) => value,
                        None => {
                            return self.decline(
                                &operation.source,
                                NativeLoweringDecline::SubstitutedOperand,
                            );
                        }
                    },
                };
                self.lower_incr(&place, delta);
                StatementOutcome::Native
            }
            Statement::ExprEval { expr, .. } => {
                let value = self.lower_expression(expr);
                let boxed = self.boxed(value);
                self.emit(NativeOp::Complete {
                    code: CompletionCode::Ok,
                    result: Some(boxed),
                });
                StatementOutcome::Native
            }
            Statement::Return {
                value,
                expr,
                braced,
                ..
            } => {
                let result = match (expr, value) {
                    (Some(expr), _) => {
                        let value = self.lower_expression(expr);
                        Some(self.boxed(value))
                    }
                    (None, Some(text)) if *braced || !has_substitution(text) => {
                        Some(self.const_str(text))
                    }
                    (None, Some(_)) => {
                        return self
                            .decline(&operation.source, NativeLoweringDecline::SubstitutedOperand);
                    }
                    (None, None) => None,
                };
                self.emit(NativeOp::Complete {
                    code: CompletionCode::Return,
                    result,
                });
                StatementOutcome::Native
            }
            _ => self.decline(
                &operation.source,
                NativeLoweringDecline::OpaqueRegion(Some(operation.descriptor)),
            ),
        }
    }

    fn decline(&mut self, source: &SourceSite, reason: NativeLoweringDecline) -> StatementOutcome {
        // Drop anything the statement emitted before declining.
        if let Some(buffer) = self.ops.last_mut() {
            buffer.clear();
        }
        self.eval_source(source, reason);
        StatementOutcome::EvalSource(reason)
    }

    /// The native constant a literal value text denotes, when boxing that
    /// native value would print exactly the text again.
    fn native_constant(&mut self, text: &str) -> Option<NativeValueId> {
        if !self.representation {
            return None;
        }
        match self.numbers.parse_whole(text)? {
            Number::Int(value) if value.to_string() == text => Some(self.const_int(value)),
            Number::Double(value)
                if value.is_finite() && tcl_syntax::number::format_double(value) == text =>
            {
                let dst = self.new_value(
                    NativeType::F64,
                    Representation::NativeDouble { finite: true },
                );
                self.emit(NativeOp::ConstDouble { dst, value });
                Some(dst)
            }
            _ => None,
        }
    }

    /// A single retained operand word (an `incr` amount): a literal, or one
    /// bare scalar variable reference.
    fn lower_operand_word(&mut self, text: &str) -> Option<NativeValueId> {
        if text.starts_with('$') {
            // A retained `$name` word carries no lexical extent here, so the
            // owner's name reading decides it: an element access is not one
            // scalar operand.
            let place = name_data_place(whole_reference(text, self.lexer_config)?)?;
            if matches!(place, CellPlace::Element { .. }) {
                return None;
            }
            let value = self.read_cell(&place);
            return Some(self.as_int_operand(value));
        }
        if has_substitution(text) {
            return None;
        }
        if let Some(Number::Int(value)) = self.numbers.parse_whole(text)
            && self.representation
        {
            return Some(self.const_int(value));
        }
        Some(self.const_str(text))
    }

    /// The `i64` form of an integer operand when it is native, else its
    /// boxed form (the runtime then owns the conversion and its error).
    fn as_int_operand(&mut self, value: NativeValueId) -> NativeValueId {
        match self.ty(value) {
            NativeType::I64 | NativeType::Obj => value,
            NativeType::Bool => self.bool_to_int(value),
            NativeType::F64 => self.boxed(value),
        }
    }

    // Words.

    fn words_lowerable(&self, words: &[WordExpr], depth: u32) -> Result<(), NativeLoweringDecline> {
        if depth > MAX_WORD_DEPTH {
            return Err(NativeLoweringDecline::WordNestingTooDeep);
        }
        if words.is_empty() {
            return Err(NativeLoweringDecline::MissingCommandTokens);
        }
        for word in words {
            self.word_lowerable(word, depth)?;
        }
        Ok(())
    }

    fn word_lowerable(&self, word: &WordExpr, depth: u32) -> Result<(), NativeLoweringDecline> {
        match word {
            WordExpr::Literal { .. } => Ok(()),
            WordExpr::BracedLiteral { text, .. } => {
                if text.contains('\\') {
                    Err(NativeLoweringDecline::BackslashSubstitution)
                } else {
                    Ok(())
                }
            }
            WordExpr::Variable { spelling, source } => {
                variable_place(spelling, source, self.lexer_config).map(|_| ())
            }
            WordExpr::CommandSubstitution { spelling, source } => {
                let inner = nested_words(spelling, source, self.lexer_config)?;
                self.words_lowerable(&inner, depth + 1)
            }
            WordExpr::Template { parts, .. } => {
                if parts.is_empty() {
                    return Err(NativeLoweringDecline::OpaqueWord);
                }
                for part in parts {
                    match part {
                        WordPart::Text { text, .. } => {
                            if text.contains('\\') {
                                return Err(NativeLoweringDecline::BackslashSubstitution);
                            }
                        }
                        WordPart::Variable { spelling, source } => {
                            variable_place(spelling, source, self.lexer_config)?;
                        }
                        WordPart::CommandSubstitution { spelling, source } => {
                            let inner = nested_words(spelling, source, self.lexer_config)?;
                            self.words_lowerable(&inner, depth + 1)?;
                        }
                        WordPart::Opaque { .. } => return Err(NativeLoweringDecline::OpaqueWord),
                    }
                }
                Ok(())
            }
            WordExpr::Expand { .. } => Err(NativeLoweringDecline::ArgumentExpansion),
            WordExpr::Opaque { .. } => Err(NativeLoweringDecline::OpaqueWord),
        }
    }

    /// Lower one word to a boxed value.
    fn lower_word(
        &mut self,
        word: &WordExpr,
        depth: u32,
    ) -> Result<NativeValueId, NativeLoweringDecline> {
        if depth > MAX_WORD_DEPTH {
            return Err(NativeLoweringDecline::WordNestingTooDeep);
        }
        match word {
            WordExpr::Literal { text, .. } => Ok(self.const_str(text)),
            WordExpr::BracedLiteral { text, .. } => {
                if text.contains('\\') {
                    return Err(NativeLoweringDecline::BackslashSubstitution);
                }
                Ok(self.const_str(text))
            }
            WordExpr::Variable { spelling, source } => {
                let place = variable_place(spelling, source, self.lexer_config)?;
                let value = self.read_cell(&place);
                Ok(self.boxed(value))
            }
            WordExpr::CommandSubstitution { spelling, source } => {
                self.lower_command_substitution(spelling, source, depth)
            }
            WordExpr::Template { parts, .. } => {
                if parts.is_empty() {
                    return Err(NativeLoweringDecline::OpaqueWord);
                }
                let mut values = Vec::with_capacity(parts.len());
                for part in parts {
                    values.push(match part {
                        WordPart::Text { text, .. } => {
                            if text.contains('\\') {
                                return Err(NativeLoweringDecline::BackslashSubstitution);
                            }
                            self.const_str(text)
                        }
                        WordPart::Variable { spelling, source } => {
                            let place = variable_place(spelling, source, self.lexer_config)?;
                            let value = self.read_cell(&place);
                            self.boxed(value)
                        }
                        WordPart::CommandSubstitution { spelling, source } => {
                            self.lower_command_substitution(spelling, source, depth)?
                        }
                        WordPart::Opaque { .. } => return Err(NativeLoweringDecline::OpaqueWord),
                    });
                }
                if let [only] = values.as_slice() {
                    return Ok(*only);
                }
                let dst = self.new_value(
                    NativeType::Obj,
                    Representation::Boxed(Some(TypeShape::String)),
                );
                self.emit(NativeOp::Concat { dst, parts: values });
                Ok(dst)
            }
            WordExpr::Expand { .. } => Err(NativeLoweringDecline::ArgumentExpansion),
            WordExpr::Opaque { .. } => Err(NativeLoweringDecline::OpaqueWord),
        }
    }

    /// A `[…]` word: a native expression when the registry resolves it to the
    /// expression hook over one braced literal and the module keeps `expr`
    /// bound to its builtin, else a nested generic invocation.
    fn lower_command_substitution(
        &mut self,
        spelling: &str,
        source: &SourceSite,
        depth: u32,
    ) -> Result<NativeValueId, NativeLoweringDecline> {
        let inner = nested_words(spelling, source, self.lexer_config)?;
        if self.substitution_is_native_expression(&inner)
            && inner.len() == 2
            && let WordExpr::BracedLiteral { text, .. } = &inner[1]
        {
            let expr = tcl_syntax::expr::parser::parse_expr_for_profile(text, self.dialect);
            let value = self.lower_expression_text(&expr, text);
            return Ok(self.boxed(value));
        }
        let mut argv = Vec::with_capacity(inner.len());
        for word in &inner {
            argv.push(self.lower_word(word, depth + 1)?);
        }
        self.max_argc = self.max_argc.max(argv.len());
        let dst = self.new_value(NativeType::Obj, Representation::Boxed(None));
        self.emit(NativeOp::NestedInvoke { dst, argv });
        self.clobber_shadows();
        self.note_observation();
        Ok(dst)
    }

    fn substitution_is_native_expression(&self, inner: &[WordExpr]) -> bool {
        if self.source_absent_model() {
            let Ok(RegistryInvocationResolution::Resolved(facts)) =
                resolve_word_exprs(self.input.registry, self.input.context, inner)
            else {
                return false;
            };
            return self.input.registry.native_lowering_for_descriptor(
                facts.descriptor_key(),
                self.input.registry.own_surface_query().as_ref(),
            ) == Some(NativeLowering::Structured(LoweringHookId::Expr))
                && self.command_trusted(facts.descriptor_key());
        }
        let Some(tokens) = self
            .original_invocations
            .as_ref()
            .and_then(|inventory| inventory.substitution(inner))
        else {
            return false;
        };
        let Some(metadata) = self.original_invocation_metadata(tokens) else {
            return false;
        };
        let Some(selected) = resolved_tokens_invocation_with_metadata_context(
            self.input.registry,
            Some(metadata),
            tokens,
        ) else {
            return false;
        };
        self.input.registry.native_lowering_for_descriptor(
            selected.facts.descriptor_key(),
            Some(&metadata.context().authoring_query()),
        ) == Some(NativeLowering::Structured(LoweringHookId::Expr))
            && self.command_trusted(selected.facts.descriptor_key())
    }

    /// Whether the module keeps `name` bound to its registry builtin at every
    /// point, so a nested command word may take the builtin's native shape.
    fn command_trusted(&self, descriptor: tcl_registry::CanonicalCommandDescriptorKey<'_>) -> bool {
        self.mutations.trusts_unobserved_descriptor(
            descriptor,
            self.input.module.has_dynamic_trace,
            &self.input.module.traced_commands,
        )
    }

    // Expressions.

    /// Lower an expression, falling back to the runtime expression intrinsic
    /// over the rendered expression when it has no native shape.
    fn lower_expression(&mut self, expr: &ExprNode) -> NativeValueId {
        let text = render_expr(expr);
        self.lower_expression_text(expr, &text)
    }

    fn lower_expression_text(&mut self, expr: &ExprNode, text: &str) -> NativeValueId {
        if let Ok(value) = self.attempt(|this| this.lower_expr(expr)) {
            return value;
        }
        let dst = self.new_value(NativeType::Obj, Representation::Boxed(None));
        self.emit(NativeOp::ExprEval {
            dst,
            text: text.to_owned(),
        });
        self.clobber_shadows();
        self.note_observation();
        dst
    }

    /// A fallback owns raw expression evaluation, its result producer and truth
    /// in one runtime operation. `ExprEval` already produces a public result,
    /// so its object must not enter another public result producer here.
    fn lower_condition_expression(&mut self, expr: &ExprNode, text: &str) -> NativeValueId {
        if let Ok(value) = self.attempt(|this| this.lower_boolean_operand(expr)) {
            return self.expression_result_truth(
                value,
                NativeBooleanExpressionResultProduction::InlineExpression,
            );
        }
        if self
            .boolean_dialect
            .and_then(|dialect| {
                dialect.native_boolean_expression_result_protocol(
                    NativeBooleanExpressionResultProduction::PublicExpressionApi,
                )
            })
            .is_none()
        {
            self.boolean_admission_missing = true;
        }
        let dst = self.new_value(NativeType::Bool, Representation::NativeBool);
        self.emit(NativeOp::ExprBoolEval {
            dst,
            text: text.to_owned(),
        });
        self.clobber_shadows();
        self.note_observation();
        dst
    }

    /// Retain the object consumed by the reached truth stage. Mathematical
    /// numeric shadows and intermediate machine numbers carry no observable
    /// cache/conversion receipt; those expressions keep the runtime seam.
    fn lower_boolean_operand(&mut self, node: &ExprNode) -> Result<NativeValueId, ExprDecline> {
        match node {
            ExprNode::Var { text, .. } => {
                let place = variable_reference_place(text, self.lexer_config)
                    .map_err(|_| ExprDecline::DynamicVariable)?;
                Ok(self.read_original_cell(&place))
            }
            ExprNode::Literal { .. } | ExprNode::CompiledWord { .. } | ExprNode::String { .. } => {
                // Source bytes are not an original compiled literal pool/cache
                // receipt. Preserve the public expression runtime seam.
                Err(ExprDecline::OriginalBooleanObjectUnavailable)
            }
            _ => {
                let value = self.lower_expr(node)?;
                match self.ty(value) {
                    NativeType::Bool | NativeType::Obj => Ok(value),
                    NativeType::I64 | NativeType::F64 => {
                        Err(ExprDecline::OriginalBooleanObjectUnavailable)
                    }
                }
            }
        }
    }

    #[allow(clippy::too_many_lines)]
    fn lower_expr(&mut self, node: &ExprNode) -> Result<NativeValueId, ExprDecline> {
        match node {
            ExprNode::Literal { text, .. } => Ok(self.lower_literal(text)),
            // A word already reduced to its value: no delimiters to strip, and
            // a live substitution means the value is not known here.
            ExprNode::CompiledWord { text, braced } => {
                if *braced || !(text.contains("${") || text.contains('[')) {
                    Ok(self.lower_literal(text))
                } else {
                    // The same decline a substituted string operand takes.
                    Err(ExprDecline::SubstitutedString)
                }
            }
            ExprNode::String { text, .. } => {
                // A `"…"` operand is its text only when nothing in it
                // substitutes. A `{…}` one is literal but for its
                // backslash-newlines, which fold in Tcl and stay in Jim, so one
                // carrying them is declined rather than pushed raw (#2227).
                match tcl_syntax::expr::fixed_string_operand(text) {
                    Some(inner) => Ok(self.const_str(inner)),
                    None => Err(ExprDecline::SubstitutedString),
                }
            }
            ExprNode::Var { text, .. } => {
                let place = variable_reference_place(text, self.lexer_config)
                    .map_err(|_| ExprDecline::DynamicVariable)?;
                Ok(self.read_cell(&place))
            }
            ExprNode::Command { .. } => Err(ExprDecline::CommandSubstitution),
            ExprNode::Raw { .. } => Err(ExprDecline::Raw),
            ExprNode::Binary { op, left, right } => self.lower_binary(*op, left, right),
            ExprNode::Unary { op, operand } => self.lower_unary(*op, operand),
            ExprNode::Ternary {
                condition,
                true_branch,
                false_branch,
            } => {
                let condition = self.lower_boolean_operand(condition)?;
                let condition = self.truth(condition, NativeBooleanTruthPurpose::ConditionalJump);
                // Exactly one arm runs: each lowers from the state the
                // condition left, and only what both agree on survives.
                let entry_shadows = self.shadows.clone();
                self.push_buffer();
                let then_value = self.lower_expr(true_branch);
                let mut then_ops = self.pop_buffer();
                let then_shadows = std::mem::replace(&mut self.shadows, entry_shadows);
                let then_value = then_value?;
                self.push_buffer();
                let else_value = self.lower_expr(false_branch);
                let mut else_ops = self.pop_buffer();
                self.shadows.intersect(&then_shadows);
                let else_value = else_value?;
                let result = self.merge_arms(&mut then_ops, then_value, &mut else_ops, else_value);
                self.emit(NativeOp::IfElse {
                    condition,
                    then_ops,
                    else_ops,
                    result: Some(result.clone()),
                });
                Ok(result.dst)
            }
            ExprNode::Call { function, args, .. } => self.lower_call(function, args),
        }
    }

    fn lower_literal(&mut self, text: &str) -> NativeValueId {
        if self.representation {
            match self.numbers.parse_whole(text) {
                Some(Number::Int(value)) => return self.const_int(value),
                Some(Number::Double(value)) if value.is_finite() => {
                    let dst = self.new_value(
                        NativeType::F64,
                        Representation::NativeDouble { finite: true },
                    );
                    self.emit(NativeOp::ConstDouble { dst, value });
                    return dst;
                }
                _ => {}
            }
        }
        self.const_str(text)
    }

    fn lower_binary(
        &mut self,
        op: BinOp,
        left: &ExprNode,
        right: &ExprNode,
    ) -> Result<NativeValueId, ExprDecline> {
        match op {
            BinOp::And | BinOp::Or => {
                let original_lhs = self.lower_boolean_operand(left)?;
                let conjunction = op == BinOp::And;
                let purpose = if conjunction {
                    NativeBooleanTruthPurpose::LogicalAnd
                } else {
                    NativeBooleanTruthPurpose::LogicalOr
                };
                let lhs = self.truth(original_lhs, purpose);
                // The right operand is only evaluated when the left does not
                // short-circuit, so its shadows hold on one path only.
                let entry_shadows = self.shadows.clone();
                self.push_buffer();
                let rhs = self.lower_logical_right(original_lhs, right, conjunction);
                let rhs_ops = self.pop_buffer();
                self.shadows.intersect(&entry_shadows);
                let rhs = rhs?;
                let dst = self.new_value(NativeType::Bool, Representation::NativeBool);
                let short = self.new_value(NativeType::Bool, Representation::NativeBool);
                let short_op = NativeOp::ConstBool {
                    dst: short,
                    value: op == BinOp::Or,
                };
                let (then_ops, else_ops, then_src, else_src) = if op == BinOp::And {
                    (rhs_ops, vec![short_op], rhs, short)
                } else {
                    (vec![short_op], rhs_ops, short, rhs)
                };
                self.emit(NativeOp::IfElse {
                    condition: lhs,
                    then_ops,
                    else_ops,
                    result: Some(IfElseResult {
                        dst,
                        then_src,
                        else_src,
                    }),
                });
                Ok(dst)
            }
            _ => {
                let lhs = self.lower_expr(left)?;
                let rhs = self.lower_expr(right)?;
                self.lower_binary_values(op, lhs, rhs)
            }
        }
    }

    #[allow(clippy::too_many_lines)]
    fn lower_binary_values(
        &mut self,
        op: BinOp,
        lhs: NativeValueId,
        rhs: NativeValueId,
    ) -> Result<NativeValueId, ExprDecline> {
        let lhs = self.numeric_operand(lhs);
        let rhs = self.numeric_operand(rhs);
        let lrep = self.rep(lhs).clone();
        let rrep = self.rep(rhs).clone();
        if let Some(cmp) = cmp_op(op) {
            match (&lrep, &rrep) {
                (Representation::NativeInt(_), Representation::NativeInt(_)) => {
                    let dst = self.new_value(NativeType::Bool, Representation::NativeBool);
                    self.emit(NativeOp::Compare {
                        dst,
                        op: cmp,
                        kind: CompareKind::I64,
                        lhs,
                        rhs,
                    });
                    return Ok(dst);
                }
                // A mixed int/double comparison is only exact while the
                // integer side converts to `f64` without rounding; outside
                // that range the dynamic edge's exact comparator is the only
                // right answer.
                (l, r)
                    if l.is_native_numeric()
                        && r.is_native_numeric()
                        && mixed_compare_is_exact(l, r) =>
                {
                    let lhs = self.promote_double(lhs);
                    let rhs = self.promote_double(rhs);
                    let dst = self.new_value(NativeType::Bool, Representation::NativeBool);
                    self.emit(NativeOp::Compare {
                        dst,
                        op: cmp,
                        kind: CompareKind::F64,
                        lhs,
                        rhs,
                    });
                    return Ok(dst);
                }
                _ => {
                    let dst = self.new_value(NativeType::Bool, Representation::NativeBool);
                    let hint = numeric_hint(&lrep, &rrep);
                    self.emit(NativeOp::DynamicCompare {
                        dst,
                        op,
                        lhs,
                        rhs,
                        hint,
                    });
                    return Ok(dst);
                }
            }
        }
        if let Some(iop) = int_op(op) {
            if let (Representation::NativeInt(l), Representation::NativeInt(r)) = (&lrep, &rrep)
                && let Some(result) = proven_int_result(iop, *l, *r)
            {
                let dst = self.new_value(NativeType::I64, Representation::NativeInt(result));
                self.emit(NativeOp::IntBinary {
                    dst,
                    op: iop,
                    lhs,
                    rhs,
                });
                return Ok(dst);
            }
            if let Some(dop) = double_op(op)
                && double_result_defined(dop)
                && lrep.is_native_numeric()
                && rrep.is_native_numeric()
                && (matches!(lrep, Representation::NativeDouble { .. })
                    || matches!(rrep, Representation::NativeDouble { .. }))
                && self.finite(lhs)
                && self.finite(rhs)
            {
                let lhs = self.promote_double(lhs);
                let rhs = self.promote_double(rhs);
                let dst = self.new_value(
                    NativeType::F64,
                    Representation::NativeDouble { finite: false },
                );
                self.emit(NativeOp::DoubleBinary {
                    dst,
                    op: dop,
                    lhs,
                    rhs,
                });
                return Ok(dst);
            }
            let hint = numeric_hint(&lrep, &rrep);
            let dst = self.new_value(
                NativeType::Obj,
                Representation::Boxed(Some(TypeShape::Numeric)),
            );
            self.emit(NativeOp::DynamicBinary {
                dst,
                op,
                lhs,
                rhs,
                hint,
            });
            return Ok(dst);
        }
        if op.spec().mathop_shape.is_none() {
            return Err(ExprDecline::UnsupportedOperator);
        }
        let lhs = self.boxed(lhs);
        let rhs = self.boxed(rhs);
        let dst = self.new_value(NativeType::Obj, Representation::Boxed(None));
        self.emit(NativeOp::MathOp {
            dst,
            op: op.spec().spelling,
            args: vec![lhs, rhs],
        });
        Ok(dst)
    }

    /// Keep the original left operand until the selected final instruction.
    /// C8.4 reconverts left then right after evaluating the right expression;
    /// the later C and Jim short-circuit paths convert only the right operand.
    fn lower_logical_right(
        &mut self,
        original_lhs: NativeValueId,
        right: &ExprNode,
        conjunction: bool,
    ) -> Result<NativeValueId, ExprDecline> {
        let rhs = self.lower_boolean_operand(right)?;
        let Some(purpose) = self
            .boolean_dialect
            .and_then(|dialect| dialect.native_logical_final_operand_purpose(conjunction))
        else {
            self.boolean_admission_missing = true;
            return Err(ExprDecline::UnsupportedOperator);
        };
        if !matches!(
            purpose,
            NativeBooleanTruthPurpose::LogicalAndInstruction
                | NativeBooleanTruthPurpose::LogicalOrInstruction
        ) {
            return Ok(self.truth(rhs, purpose));
        }
        let lhs = self.truth(original_lhs, purpose);
        let rhs = self.truth(rhs, purpose);
        let dst = self.new_value(NativeType::Bool, Representation::NativeBool);
        let fixed = self.new_value(NativeType::Bool, Representation::NativeBool);
        let constant = NativeOp::ConstBool {
            dst: fixed,
            value: !conjunction,
        };
        let (then_ops, else_ops, then_src, else_src) = if conjunction {
            (Vec::new(), vec![constant], rhs, fixed)
        } else {
            (vec![constant], Vec::new(), fixed, rhs)
        };
        self.emit(NativeOp::IfElse {
            condition: lhs,
            then_ops,
            else_ops,
            result: Some(IfElseResult {
                dst,
                then_src,
                else_src,
            }),
        });
        Ok(dst)
    }

    fn lower_unary(
        &mut self,
        op: UnaryOp,
        operand: &ExprNode,
    ) -> Result<NativeValueId, ExprDecline> {
        let value = if op == UnaryOp::Not {
            self.lower_boolean_operand(operand)?
        } else {
            self.lower_expr(operand)?
        };
        match op {
            UnaryOp::Not => {
                let truth = self.truth(value, NativeBooleanTruthPurpose::LogicalNot);
                let dst = self.new_value(NativeType::Bool, Representation::NativeBool);
                self.emit(NativeOp::NotBool { dst, src: truth });
                Ok(dst)
            }
            UnaryOp::WordNot => Err(ExprDecline::UnsupportedOperator),
            UnaryOp::Neg | UnaryOp::Pos | UnaryOp::BitNot => {
                let value = self.numeric_operand(value);
                let rep = self.rep(value).clone();
                match (op, &rep) {
                    (
                        UnaryOp::Pos,
                        Representation::NativeInt(_) | Representation::NativeDouble { .. },
                    ) => Ok(value),
                    (UnaryOp::Neg, Representation::NativeInt(interval)) => {
                        if let Some(result) = proven_neg_result(*interval) {
                            let dst =
                                self.new_value(NativeType::I64, Representation::NativeInt(result));
                            self.emit(NativeOp::IntNeg { dst, src: value });
                            return Ok(dst);
                        }
                        Ok(self.dynamic_unary(op, value))
                    }
                    (UnaryOp::Neg, Representation::NativeDouble { finite }) => {
                        let dst = self.new_value(
                            NativeType::F64,
                            Representation::NativeDouble { finite: *finite },
                        );
                        self.emit(NativeOp::DoubleNeg { dst, src: value });
                        Ok(dst)
                    }
                    (UnaryOp::BitNot, Representation::NativeInt(_)) => {
                        let dst = self.new_value(NativeType::I64, Representation::any_int());
                        self.emit(NativeOp::IntBitNot { dst, src: value });
                        Ok(dst)
                    }
                    _ => Ok(self.dynamic_unary(op, value)),
                }
            }
        }
    }

    fn dynamic_unary(&mut self, op: UnaryOp, value: NativeValueId) -> NativeValueId {
        let dst = self.new_value(
            NativeType::Obj,
            Representation::Boxed(Some(TypeShape::Numeric)),
        );
        self.emit(NativeOp::DynamicUnary {
            dst,
            op,
            src: value,
        });
        dst
    }

    #[allow(clippy::too_many_lines)]
    fn lower_call(
        &mut self,
        function: &str,
        args: &[ExprNode],
    ) -> Result<NativeValueId, ExprDecline> {
        let mut values = Vec::with_capacity(args.len());
        for arg in args {
            let value = self.lower_expr(arg)?;
            values.push(self.numeric_operand(value));
        }
        if self.mathfunc_native {
            match (function, values.as_slice()) {
                ("double", [value]) => match self.rep(*value) {
                    Representation::NativeInt(_) => return Ok(self.int_to_double(*value)),
                    Representation::NativeDouble { .. } => return Ok(*value),
                    _ => {}
                },
                ("int" | "wide", [value]) => {
                    if matches!(self.rep(*value), Representation::NativeInt(_)) {
                        return Ok(*value);
                    }
                }
                ("abs", [value]) => {
                    if let Representation::NativeInt(interval) = self.rep(*value).clone()
                        && let Some(negated) = proven_neg_result(interval)
                    {
                        let zero = self.const_int(0);
                        let negative = self.new_value(NativeType::Bool, Representation::NativeBool);
                        self.emit(NativeOp::Compare {
                            dst: negative,
                            op: CmpOp::Lt,
                            kind: CompareKind::I64,
                            lhs: *value,
                            rhs: zero,
                        });
                        let neg =
                            self.new_value(NativeType::I64, Representation::NativeInt(negated));
                        let hull = hull(interval, negated);
                        let dst = self.new_value(NativeType::I64, Representation::NativeInt(hull));
                        self.emit(NativeOp::IfElse {
                            condition: negative,
                            then_ops: vec![NativeOp::IntNeg {
                                dst: neg,
                                src: *value,
                            }],
                            else_ops: Vec::new(),
                            result: Some(IfElseResult {
                                dst,
                                then_src: neg,
                                else_src: *value,
                            }),
                        });
                        return Ok(dst);
                    }
                }
                ("max" | "min", [first, second]) => {
                    let both_int = matches!(
                        (self.rep(*first), self.rep(*second)),
                        (Representation::NativeInt(_), Representation::NativeInt(_))
                    );
                    if both_int {
                        let (l, r) = (
                            self.rep(*first)
                                .interval()
                                .unwrap_or(Interval { lo: None, hi: None }),
                            self.rep(*second)
                                .interval()
                                .unwrap_or(Interval { lo: None, hi: None }),
                        );
                        let pick_first =
                            self.new_value(NativeType::Bool, Representation::NativeBool);
                        self.emit(NativeOp::Compare {
                            dst: pick_first,
                            op: if function == "max" {
                                CmpOp::Ge
                            } else {
                                CmpOp::Le
                            },
                            kind: CompareKind::I64,
                            lhs: *first,
                            rhs: *second,
                        });
                        let dst =
                            self.new_value(NativeType::I64, Representation::NativeInt(hull(l, r)));
                        self.emit(NativeOp::IfElse {
                            condition: pick_first,
                            then_ops: Vec::new(),
                            else_ops: Vec::new(),
                            result: Some(IfElseResult {
                                dst,
                                then_src: *first,
                                else_src: *second,
                            }),
                        });
                        return Ok(dst);
                    }
                }
                _ => {}
            }
        }
        let args = values
            .into_iter()
            .map(|value| self.boxed(value))
            .collect::<Vec<_>>();
        let dst = self.new_value(NativeType::Obj, Representation::Boxed(None));
        self.emit(NativeOp::MathFunc {
            dst,
            name: function.to_owned(),
            args,
        });
        // The math function resolves through the command table, so it may be
        // user code that observes or writes any cell.
        self.clobber_shadows();
        self.note_observation();
        Ok(dst)
    }

    /// A boolean operand of arithmetic reads as the integer `0`/`1`.
    fn numeric_operand(&mut self, value: NativeValueId) -> NativeValueId {
        if self.ty(value) == NativeType::Bool {
            self.bool_to_int(value)
        } else {
            value
        }
    }

    fn promote_double(&mut self, value: NativeValueId) -> NativeValueId {
        if self.ty(value) == NativeType::I64 {
            self.int_to_double(value)
        } else {
            value
        }
    }

    fn finite(&self, value: NativeValueId) -> bool {
        match self.rep(value) {
            Representation::NativeInt(_) => true,
            Representation::NativeDouble { finite } => *finite,
            _ => false,
        }
    }

    /// Merge the values two arms produce into one, boxing both when their
    /// native types differ.
    fn merge_arms(
        &mut self,
        then_ops: &mut Vec<NativeOp>,
        then_value: NativeValueId,
        else_ops: &mut Vec<NativeOp>,
        else_value: NativeValueId,
    ) -> IfElseResult {
        let then_ty = self.ty(then_value);
        let else_ty = self.ty(else_value);
        if then_ty == else_ty {
            let rep = match (self.rep(then_value).clone(), self.rep(else_value).clone()) {
                (Representation::NativeInt(l), Representation::NativeInt(r)) => {
                    Representation::NativeInt(hull(l, r))
                }
                (
                    Representation::NativeDouble { finite: l },
                    Representation::NativeDouble { finite: r },
                ) => Representation::NativeDouble { finite: l && r },
                (Representation::NativeBool, Representation::NativeBool) => {
                    Representation::NativeBool
                }
                (Representation::Boxed(l), Representation::Boxed(r)) if l == r => {
                    Representation::Boxed(l)
                }
                _ => Representation::Boxed(None),
            };
            let dst = self.new_value(then_ty, rep);
            return IfElseResult {
                dst,
                then_src: then_value,
                else_src: else_value,
            };
        }
        let then_boxed = self.box_into(then_ops, then_value);
        let else_boxed = self.box_into(else_ops, else_value);
        let dst = self.new_value(NativeType::Obj, Representation::Boxed(None));
        IfElseResult {
            dst,
            then_src: then_boxed,
            else_src: else_boxed,
        }
    }

    fn box_into(&mut self, ops: &mut Vec<NativeOp>, value: NativeValueId) -> NativeValueId {
        if self.ty(value) == NativeType::Obj {
            return value;
        }
        let dst = self.new_value(NativeType::Obj, Representation::Boxed(None));
        ops.push(NativeOp::Box { dst, src: value });
        dst
    }
}

/// A statement carries no block reference; the helper exists so the block
/// parameter of `lower_instruction` stays available to future per-block
/// decisions without a warning today.
trait WithBlock {
    fn with_block(self, block: &ExecutableBlock) -> Self;
}

impl WithBlock for NativeStatement {
    fn with_block(self, _block: &ExecutableBlock) -> Self {
        self
    }
}

/// Whether an invocation's registry effect footprint proves it neither
/// writes a variable cell nor runs a callback that could.
fn cells_unobserved(effects: &tcl_registry::world_effect::EffectFootprint) -> bool {
    use tcl_registry::world_effect::{EffectAccessMode, WorldStateDomain};
    !effects.requires_world_barrier()
        && effects.accesses().iter().all(|access| {
            !matches!(
                access.domain,
                WorldStateDomain::VariableStore | WorldStateDomain::VariableTraces
            ) || access.mode == EffectAccessMode::Read
        })
}

fn hull(a: Interval, b: Interval) -> Interval {
    let lo = match (a.lo, b.lo) {
        (Some(x), Some(y)) => Some(x.min(y)),
        _ => None,
    };
    let hi = match (a.hi, b.hi) {
        (Some(x), Some(y)) => Some(x.max(y)),
        _ => None,
    };
    Interval { lo, hi }
}

/// The value word of a `set name value` statement's retained tokens.
fn value_word(tokens: Option<&CommandTokens>) -> Option<&WordExpr> {
    let tokens = tokens?;
    if !tokens.words_align_with_argv_text() || tokens.words().len() != 3 {
        return None;
    }
    tokens.words().get(2)
}

/// The cell a variable word reads, in this tier's decline vocabulary.
///
/// [`variable_word_place`] is the one owner of the reading; this only names
/// the refusal.
/// Whether the word is written out literally, so what the front end recorded
/// for it is the text the statement itself carries.
fn is_written_literal(word: &WordExpr) -> bool {
    matches!(
        word,
        WordExpr::Literal { .. } | WordExpr::BracedLiteral { .. }
    )
}

/// Whether the word is a literal whose content is exactly `recorded`.
fn word_is_literally(word: &WordExpr, recorded: &str) -> bool {
    match word {
        WordExpr::Literal { text, .. } | WordExpr::BracedLiteral { text, .. } => text == recorded,
        _ => false,
    }
}

/// Whether a `proc name params body` statement wrote every word out, and wrote
/// the parameter list and body the surviving [`crate::ir::Procedure`] recorded.
///
/// The condition under which a tier may register a definition itself rather
/// than leave it to the runtime's own `proc`. `Procedure` records the
/// *written* name, parameter list and body text, but a lowering may have
/// compiled the body from a value it materialised instead — a const-mapped
/// `$body`, or a `[subst -nocommands …]` template — recording the original
/// word beside that compiled body rather than the text it compiled.
/// Registering that word would report the wrong `info body`, and any later run
/// of the source body (a step trace, or a declined native entry) would
/// evaluate the substitution *in the procedure's own frame*, where its
/// operands do not exist.
///
/// Shared by the native tier and the general wasm tier because it is one rule:
/// a second copy is a second thing to go out of step.
pub(crate) fn definition_words_are_written_out(
    words: &[WordExpr],
    params_raw: &str,
    body_source: &str,
) -> bool {
    // The runtime's `proc` owns every error the other shapes can raise, so
    // only the exact four-word form is taken.
    let [_head, name, params, body] = words else {
        return false;
    };
    is_written_literal(name)
        && word_is_literally(params, params_raw)
        && word_is_literally(body, body_source)
}

/// The 1-based line of `offset` within the body that opens at `origin`.
///
/// `errorInfo` counts a procedure's lines from the first byte of its body
/// text, not from the start of the file, which is exactly what
/// `Interp::log_command_bytes` expects from a compiled statement.
fn body_line(source: &str, origin: u32, offset: u32) -> u32 {
    let Some(preceding) = source.get(origin as usize..offset as usize) else {
        return 1;
    };
    u32::try_from(preceding.matches('\n').count())
        .unwrap_or(u32::MAX)
        .saturating_add(1)
}

fn variable_place(
    spelling: &str,
    source: &SourceSite,
    config: tcl_lexer::LexerConfig,
) -> Result<CellPlace, NativeLoweringDecline> {
    variable_word_place(spelling, source, config).map_err(|decline| match decline {
        VariableWordDecline::Dynamic => NativeLoweringDecline::DynamicVariableName,
        VariableWordDecline::Ambiguous => NativeLoweringDecline::AmbiguousVariableSpelling,
    })
}

/// The structured words of a `[…]` command substitution, recovered by the
/// canonical segmenter over the recorded lexical extent
/// ([`crate::word_subst::nested_command_words`] owns that recovery, so this
/// tier plans the same words the analysis tier lifts).
fn nested_words(
    spelling: &str,
    source: &SourceSite,
    config: tcl_lexer::LexerConfig,
) -> Result<Vec<WordExpr>, NativeLoweringDecline> {
    crate::word_subst::nested_command_words(spelling, source, config)
        .map(|tokens| tokens.word_exprs)
        .map_err(|decline| match decline {
            crate::word_subst::NestedWordsDecline::Unmodelled => {
                NativeLoweringDecline::UnmodelledCommandSubstitution
            }
            crate::word_subst::NestedWordsDecline::NoWords => {
                NativeLoweringDecline::MissingCommandTokens
            }
        })
}

/// Reverse post-order over the executable CFG, the loop headers (targets of
/// back edges), and every block's predecessor list.
fn block_order(function: &ExecutableFunction) -> (Vec<usize>, HashSet<usize>, Vec<Vec<usize>>) {
    let count = function.blocks.len();
    let successors: Vec<Vec<usize>> = function
        .blocks
        .iter()
        .map(|block| match &block.terminator {
            Some(ExecutableTerminator::RegionChoice { enter, skip }) => {
                vec![enter.index(), skip.index()]
            }
            Some(ExecutableTerminator::Goto(target)) => vec![target.index()],
            Some(ExecutableTerminator::Branch {
                then_target,
                else_target,
                ..
            }) => vec![then_target.index(), else_target.index()],
            Some(ExecutableTerminator::CompletionSwitch { cases, default, .. }) => {
                let mut targets: Vec<usize> =
                    cases.iter().map(|case| case.target.index()).collect();
                targets.push(default.index());
                targets
            }
            Some(ExecutableTerminator::ReturnCompletion(_)) | None => Vec::new(),
        })
        .collect();
    let mut predecessors: Vec<Vec<usize>> = vec![Vec::new(); count];
    for (from, targets) in successors.iter().enumerate() {
        let mut seen = HashSet::new();
        for target in targets {
            if *target < count && seen.insert(*target) {
                predecessors[*target].push(from);
            }
        }
    }
    // Iterative DFS for post-order and back-edge detection.
    let mut state = vec![0u8; count]; // 0 unvisited, 1 on stack, 2 done
    let mut post = Vec::with_capacity(count);
    let mut headers = HashSet::new();
    let mut stack: Vec<(usize, usize)> = Vec::new();
    let entry = function.entry.index();
    if entry < count {
        state[entry] = 1;
        stack.push((entry, 0));
    }
    while let Some((block, next)) = stack.last_mut() {
        let block = *block;
        if *next < successors[block].len() {
            let target = successors[block][*next];
            *next += 1;
            if target >= count {
                continue;
            }
            match state[target] {
                0 => {
                    state[target] = 1;
                    stack.push((target, 0));
                }
                1 => {
                    headers.insert(target);
                }
                _ => {}
            }
        } else {
            state[block] = 2;
            post.push(block);
            stack.pop();
        }
    }
    post.reverse();
    (post, headers, predecessors)
}

fn completion_count(function: &ExecutableFunction) -> usize {
    let mut count = 0;
    for block in &function.blocks {
        for instruction in &block.instructions {
            count = count.max(instruction_completion(instruction).index() + 1);
        }
        if let Some(
            ExecutableTerminator::CompletionSwitch { completion, .. }
            | ExecutableTerminator::ReturnCompletion(completion),
        ) = &block.terminator
        {
            count = count.max(completion.index() + 1);
        }
    }
    count
}

fn instruction_completion(
    instruction: &ExecutableInstruction,
) -> crate::executable_ir::CompletionId {
    match instruction {
        ExecutableInstruction::EvaluateWord { completion, .. }
        | ExecutableInstruction::ExpandWord { completion, .. }
        | ExecutableInstruction::BuildArgv { completion, .. }
        | ExecutableInstruction::EvaluateExpr { completion, .. }
        | ExecutableInstruction::MatchPattern { completion, .. }
        | ExecutableInstruction::JoinCompletion { completion, .. }
        | ExecutableInstruction::WriteCompletionCell { completion, .. }
        | ExecutableInstruction::IterateLists { completion, .. } => *completion,
        ExecutableInstruction::Invoke(invoke) => invoke.completion,
        ExecutableInstruction::ExecuteLowered(operation) => operation.completion,
        ExecutableInstruction::ExecuteOpaqueRegion(region) => region.completion,
        ExecutableInstruction::CompleteStructuredRegion(region) => region.completion,
        ExecutableInstruction::CompleteEvaluatedRegion(region) => region.invocation.completion,
    }
}

/// A completion for a block the executable CFG never reaches.
fn unreachable_completion(function: &ExecutableFunction) -> crate::executable_ir::CompletionId {
    function
        .blocks
        .iter()
        .flat_map(|block| &block.instructions)
        .map(instruction_completion)
        .next()
        .unwrap_or_else(|| crate::executable_ir::CompletionId::new(function.id, 0))
}

/// Whether comparing these two native numeric representations through `f64`
/// gives Tcl's answer. Two doubles always do; a mixed pair only while the
/// integer side is exactly representable (see
/// [`exactly_representable_as_double`]). Two integers never reach here.
fn mixed_compare_is_exact(l: &Representation, r: &Representation) -> bool {
    match (l, r) {
        (Representation::NativeInt(i), Representation::NativeDouble { .. })
        | (Representation::NativeDouble { .. }, Representation::NativeInt(i)) => {
            exactly_representable_as_double(*i)
        }
        _ => true,
    }
}

#[cfg(test)]
mod evaluated_region_tests {
    #[test]
    fn evaluated_wrapper_is_rejected_before_native_operations_are_emitted() {
        let function = crate::execution_region::evaluated_region_test_fixture();
        function.validate().unwrap();
        assert_eq!(
            super::unlowered_instruction(&function),
            Some("evaluated-body-region")
        );
    }
}

#[cfg(test)]
mod original_entry_storage_tests {
    #[test]
    // Implementation contract: naming.variable.aot-original-slot-purpose
    // docs/design/analysis/name-resolution-proofs/aot-original-slot-purpose.md
    fn original_native_entry_keeps_cells_and_runtime_trace_guards_despite_escape_labels() {
        use super::*;
        let registry = CommandRegistry::build_default();
        let function = crate::execution_region::evaluated_region_test_fixture();
        let mutations = ModuleCommandMutations::default();
        let hints = BTreeMap::new();
        let mut summary = ProcEscapeSummary::default();
        summary.local_slots.insert("x".into(), 11);
        let config = SemanticOptimisationConfig::new()
            .with_enabled(SemanticOptimisationPassId::CellDemotion)
            .with_enabled(SemanticOptimisationPassId::TraceBarrierElision);
        let authored = Module::default();
        let input = LoweringInput {
            registry: &registry,
            context: None,
            function: &function,
            source: "",
            module: &authored,
            mutations: &mutations,
            config,
            escape: Some(&summary),
            top_level: false,
            line_origin: 0,
            entry_assumption: DispatchEntryAssumption::UnknownWorld,
            type_hints: &hints,
        };
        let lowerer = Lowerer::new(&input);
        let place = super::super::cells::CellPlace::Named { name: "x".into() };
        assert_eq!(
            lowerer.demotion.decide("x").storage,
            super::super::cells::CellStorage::Slot(11)
        );
        assert_eq!(
            lowerer.ledger.incr_guard(&place),
            super::super::elide::IncrGuard::Unguarded
        );
        let profile = tcl_dialect::DialectProfile::find("tcl9.0").unwrap();
        let mut entry: crate::environment_ingress::CapturedNativeEntry =
            crate::environment_ingress::captured_native_entry(profile);
        entry.frame = tcl_runtime_api::native_compilation::NativeCompilationFrame::Procedure;
        let mut native = authored.clone();
        native.source_entry.native_entry = Some(std::sync::Arc::new(entry.clone()));
        let native_input = LoweringInput {
            module: &native,
            ..input
        };
        let lowerer = Lowerer::new(&native_input);
        assert_eq!(
            lowerer.demotion.decide("x").storage,
            super::super::cells::CellStorage::Cell
        );
        assert_eq!(
            lowerer.ledger.incr_guard(&place),
            super::super::elide::IncrGuard::RuntimeTraceBit
        );
        let mut traced = native.clone();
        traced.traced_variables.insert("x".into());
        let traced_input = LoweringInput {
            module: &traced,
            ..native_input
        };
        let lowerer = Lowerer::new(&traced_input);
        assert_eq!(
            lowerer.ledger.incr_guard(&place),
            super::super::elide::IncrGuard::RuntimeTraceBit
        );
    }
}
