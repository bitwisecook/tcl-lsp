// tcl-lsp — a language server and toolchain for Tcl
// Copyright (C) 2026 James Deucker (bitwisecook) <https://github.com/bitwisecook>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.
//
// SPDX-License-Identifier: AGPL-3.0-or-later

//! Branch-folding optimiser pass.
//!
//! Two entry points, both folded into [`run`]:
//!
//! - `optimise_constant_branches`: for every
//!   [`ConstantBranch`] SCCP produced, emits an `O101`
//!   suggestion rewriting the condition to the literal boolean
//!   it folded to.
//! - `optimise_branch_proc_calls`: for every branch
//!   condition SCCP could *not* fold, tries propagation via
//!   [`substitute_expr_constants_for_execution`] (from the
//!   [`super::helpers::expr_simplify`] toolkit).
//!   `propagate_into_branches` runs `substitute_expr_constants_for_execution`
//!   first to build a working text, then probes the four AST
//!   rewriters in priority order — `strength_reduce` (`O113`)
//!   → `strlen` (`O117`) → `streq` (`O120`) → `instcombine`
//!   (`O110`).  The first rewriter that changes text wins its
//!   diagnostic code; **`O100`** ("Propagate constants into
//!   branch expression") only fires when substitution changed
//!   the text *and* none of the AST rewriters did.
//!
//! Switch-dispatch branches (the ones `cfg_builder` synthesises
//! inside `switch` blocks: a chain of `StrEq` probes against
//! `switch_next_*` fall-through blocks) are skipped — folding
//! them would produce misleading rewrites of user-visible source
//! text.

use std::collections::HashSet;
use tcl_core_types::DiagCode;

use crate::cfg::Terminator;
use crate::compilation_unit::{CompilationUnit, FunctionUnit};
use crate::expr_ast::{BinOp, ExprNode};
use crate::sccp::{BranchFactKind, ConstantBranch};

use super::helpers::expr_simplify::{
    OperandTypes, instcombine_expr_typed, operand_types, substitute_expr_constants_for_execution,
    try_eq_ne_string_compare_simplify_expr, try_fold_expr, try_strength_reduce_expr_typed,
    try_strlen_simplify_expr, try_unwrap_expr_in_expr,
};
use super::propagation::sccp_constants_for;
use super::{Optimisation, PassContext};

/// Run the branch-folding pass — both
/// `optimise_constant_branches` and
/// `optimise_branch_proc_calls`.
///
/// Constant-branch pass (`optimise_constant_branches`):
///
/// - Code: `O101` ("Fold constant expression").
/// - Replacement: `"1"` or `"0"` depending on the folded value,
///   wrapped in braces when the source condition was braced.
/// - Span: the branch terminator's condition span.
/// - Switch-dispatch branches (`StrEq` condition + block or
///   targets whose names mention `switch_next`) are skipped.
///
/// Branch-proc-call propagation (`optimise_branch_proc_calls`):
///
/// - Code: `O100` ("Propagate constants into branch
///   expression") when SCCP could not fold the branch but the
///   constant-substitution pass produced a text change.
/// - Uses per-function SCCP lattice to build the constants map;
///   variables whose every tracked version agrees on a single
///   `Const` value participate.
pub fn run(ctx: &mut PassContext<'_>, cu: &CompilationUnit) {
    for fu in cu.analysable_functions() {
        fold_constant_branches(ctx, fu);
        propagate_into_branches(ctx, fu);
    }
}

/// For every branch the SCCP pass *did not* fold, project the
/// per-function lattice into a constants map and try to rewrite
/// the condition text via [`substitute_expr_constants_for_execution`]. Emits
/// `O100` on any text change.
fn propagate_into_branches(ctx: &mut PassContext<'_>, fu: &FunctionUnit) {
    // Note: `constants` may be empty — the cascade (strength-reduce, streq,
    // instcombine) and the O115 redundant-`expr` unwrap still apply to a
    // branch condition with no propagable constants; this does not gate on a
    // non-empty constant map. Substitution is simply a no-op in that case.
    // No trace/alias filtering needed: `constants` is a pure projection of
    // `fu.sccp.values`, and `sccp()` itself already forces a traced or
    // frame-aliased variable's own lattice entry to `Overdefined` —
    // `run_load_forwarding` (O102) is the one pass that still needs its own
    // check, since it runs an independent def-use-chain scan that never
    // consults `fu.sccp` at all.
    let constants = sccp_constants_for(fu, ctx.fold_policy());
    // Numeric-type context so identity rewrites (`$x + 0` → `$x`, etc.) on a
    // branch condition fire only when the dropped operand is provably numeric.
    let numeric = operand_types(fu);
    // A `Selected` fact is no branch: its block holds a statement, and the
    // terminator it ends in is some other condition's to fold.
    let folded: HashSet<String> = fu
        .sccp
        .constant_branches
        .iter()
        .filter(|cb| cb.kind != BranchFactKind::Selected)
        .map(|cb| cb.block.clone())
        .collect();

    for (bn, block) in &fu.cfg.blocks {
        // `folded` holds block *names* (from each `ConstantBranch.block`);
        // resolve the iterated `BlockId` to its name to test membership.
        if folded.contains(fu.cfg.block_name(*bn)) {
            continue;
        }
        let Some(Terminator::Branch {
            condition,
            span: Some(span),
            ..
        }) = &block.terminator
        else {
            continue;
        };
        if is_switch_dispatch_cond(condition) {
            continue;
        }
        let Some(BranchConditionSource {
            binding_span,
            span,
            inner,
            braced,
        }) = branch_condition_source(ctx.source, fu, *bn, *span)
        else {
            continue;
        };
        let rewrap = |text: &str| {
            if braced {
                format!("{{{text}}}")
            } else {
                text.to_owned()
            }
        };

        // O115: a branch condition that is itself a redundant `[expr {…}]`
        // wrapper (`if {[expr {$x}]} …`) unwraps to its inner expression.
        // Checked before the constant cascade. Unlike the rest of this
        // cascade — which folds the condition text using Tcl's own
        // internal expr evaluation (never a command dispatch, so
        // `rename`/`interp alias`-ing `expr` cannot affect it) — this
        // specific rewrite assumes the embedded `[expr {…}]` substring is
        // a genuine command substitution dispatching to builtin `expr`,
        // so it alone needs the trust gate.
        if let Some(unwrapped) = try_unwrap_expr_in_expr(inner)
            && unwrapped != inner
            && ctx.command_mutations.trusts("expr")
            && branch_execution_equivalent(ctx, inner, &unwrapped, &constants, binding_span)
        {
            ctx.report(Optimisation::new(
                DiagCode::O115,
                "Remove redundant nested expr",
                span,
                rewrap(&unwrapped),
            ));
            continue;
        }

        // Cascade: substitute → strength-reduce → strlen → streq →
        // instcombine, with an O101 fold short-circuit.
        let sub = substitute_expr_constants_for_execution(
            inner,
            &constants,
            ctx.dialect,
            &crate::tcl_expr_eval::NativeOperandProofs::new(),
        );
        let working = if sub.changed {
            sub.text.clone()
        } else {
            inner.to_owned()
        };

        // O101: if constant propagation makes the whole condition fold to a
        // literal (`if {$flag > 0}` with `flag == 1` → `1`), emit the fold in
        // preference to the partial-canonicalisation codes.
        if sub.changed
            && let Some(folded) = try_fold_expr(&working, ctx.rewrite_folds())
            && folded != inner
            && branch_execution_equivalent(ctx, inner, &folded, &constants, binding_span)
        {
            ctx.report(Optimisation::new(
                DiagCode::O101,
                "Fold constant expression",
                span,
                rewrap(&folded),
            ));
            continue;
        }

        let Some((code, message, final_text)) =
            branch_cascade(&working, sub.changed, &sub.text, &numeric, ctx.dialect)
        else {
            continue;
        };
        if !branch_execution_equivalent(ctx, inner, &final_text, &constants, binding_span) {
            if code == DiagCode::O120 {
                ctx.report_prepared_expression_candidate(
                    code,
                    "String comparison may use eq/ne after preserving shared-operand conversions",
                    binding_span,
                );
            }
            continue;
        }
        ctx.report(Optimisation::new(code, message, span, rewrap(&final_text)));
    }
}

/// Exact written condition and its native expression binding extent.
struct BranchConditionSource<'a> {
    binding_span: tcl_lexer::Span,
    span: tcl_lexer::Span,
    inner: &'a str,
    braced: bool,
}

fn branch_condition_source<'a>(
    source: &'a str,
    fu: &FunctionUnit,
    block: crate::cfg::BlockId,
    expected: tcl_lexer::Span,
) -> Option<BranchConditionSource<'a>> {
    let edit_span = fu.cfg.terminator_source_edit_span(block)?;
    debug_assert_eq!(edit_span, expected);
    let binding_span = fu.abs_span(edit_span);
    // The lexer owns widening a braced word through its original closer.
    // An inner closing brace does not establish the outer word's extent.
    let span = tcl_lexer::word_span_at(source, binding_span);
    let condition = source.get(span.as_range())?;
    if condition.is_empty() {
        return None;
    }
    let (inner, braced) = condition
        .strip_prefix('{')
        .and_then(|body| body.strip_suffix('}'))
        .map_or((condition, false), |body| (body, true));
    Some(BranchConditionSource {
        binding_span,
        span,
        inner,
        braced,
    })
}

fn branch_execution_equivalent(
    ctx: &PassContext<'_>,
    original: &str,
    proposed: &str,
    constants: &std::collections::HashMap<String, String>,
    span: tcl_lexer::Span,
) -> bool {
    let original = branch_original_expression(ctx, original);
    let environment = constants
        .iter()
        .map(|(name, value)| {
            (
                name.clone(),
                crate::tcl_expr_eval::EnvValue::Str(value.clone()),
            )
        })
        .collect();
    ctx.expression_rewrite_equivalence_at(&original, proposed, &environment, span)
        .is_ok()
}

/// Parse source topology under the retained lexical policy. This tree does
/// not supply native preparation, operand objects or rewrite permission.
fn branch_original_expression(ctx: &PassContext<'_>, source: &str) -> ExprNode {
    let profile = ctx
        .dialect
        .unwrap_or_else(tcl_dialect::DialectProfile::plain_tcl);
    let mut parser = tcl_syntax::expr::parser::ExprParseContext::for_profile(profile);
    if ctx.dialect.is_none() {
        // The explicit standalone boundary keeps its selected runtime numeral
        // grammar; source lexer overrides do not choose a numeric policy.
        parser.lexer_grammar.numbers = tcl_syntax::number::runtime_syntax();
    }
    parser.lexer_grammar = ctx.lexer_config().grammar_over(parser.lexer_grammar);
    crate::expr_parser::parse_expr_with_syntax_context(source, &parser)
}

/// The branch-condition simplification cascade: the first transform that
/// changes `working` wins its diagnostic code. Returns `None` when nothing
/// applies. `sub_changed`/`sub_text` carry the constant-substitution result
/// so a pure substitution (no further simplification) still emits O100.
fn branch_cascade(
    working: &str,
    sub_changed: bool,
    sub_text: &str,
    numeric: &OperandTypes,
    dialect: Option<&'static tcl_dialect::DialectProfile>,
) -> Option<(DiagCode, &'static str, String)> {
    let (sred, sred_changed) = try_strength_reduce_expr_typed(working, Some(numeric), dialect);
    if sred_changed {
        return Some((DiagCode::O113, "Strength-reduce expression", sred));
    }
    let (slen, slen_changed) = try_strlen_simplify_expr(working, dialect);
    if slen_changed {
        return Some((DiagCode::O117, "Simplify string length zero-check", slen));
    }
    let (streq, streq_changed) = try_eq_ne_string_compare_simplify_expr(working, dialect);
    if streq_changed {
        return Some((DiagCode::O120, "Use eq/ne for string comparison", streq));
    }
    let (combined, combined_changed) =
        instcombine_expr_typed(working, true, Some(numeric), dialect);
    if combined_changed {
        return Some((
            DiagCode::O110,
            "Canonicalise expression (InstCombine)",
            combined,
        ));
    }
    if sub_changed {
        return Some((
            DiagCode::O100,
            "Propagate constants into branch expression",
            sub_text.to_owned(),
        ));
    }
    None
}

fn is_switch_dispatch_cond(cond: &ExprNode) -> bool {
    matches!(
        cond,
        ExprNode::Binary {
            op: BinOp::StrEq,
            ..
        }
    )
}

fn fold_constant_branches(ctx: &mut PassContext<'_>, fu: &FunctionUnit) {
    // No trace/alias filtering needed: `fu.sccp.constant_branches` is
    // derived entirely from `sccp()`'s own lattice `values`, and `sccp()`
    // itself already forces a traced or frame-aliased variable's lattice
    // entry to `Overdefined` — a branch reading one never resolves to a
    // constant decision in the first place, so it never lands in
    // `constant_branches` to begin with. O102 `run_load_forwarding` is the
    // one pass that still needs its own check, since it runs an independent
    // def-use-chain scan that never consults `fu.sccp` at all.
    for cb in fu
        .sccp
        .constant_branches
        .iter()
        .filter(|cb| cb.kind != BranchFactKind::Selected)
    {
        let Some(block) = fu.cfg.block_by_name(&cb.block) else {
            continue;
        };
        let Some(Terminator::Branch {
            condition,
            span: Some(span),
            ..
        }) = &block.terminator
        else {
            continue;
        };

        if is_switch_dispatch(condition, cb) {
            continue;
        }

        // `span` is carried by `fu.cfg`'s terminator, so it is relative to the
        // unit's `base_offset` (0 for a real-position build, the body offset for
        // a memoised offset-0 unit); recover the absolute span before slicing
        // `ctx.source` or emitting.
        let Some(block_id) = fu.cfg.block_id(&cb.block) else {
            continue;
        };
        let Some(edit_span) = fu.cfg.terminator_source_edit_span(block_id) else {
            continue;
        };
        debug_assert_eq!(edit_span, *span);
        let span = fu.abs_span(edit_span);
        // The condition span is the lexer's own word span, so a braced
        // condition stops one byte short of its closing `}` (`while {1 < 2}`
        // slices as `{1 < 2`), and the brace unwrap below would then strip an
        // opener with no matching closer. `word_span_at` owns that widening:
        // deciding it here from the slice's last byte reads `{$x eq {}}` —
        // which already ends in the *inner* pair's `}` — as already whole, and
        // drops the outer brace from the rewrite target.
        let span = tcl_lexer::word_span_at(ctx.source, span);
        let source = ctx.source;
        let range = span.as_range();
        if range.end > source.len() {
            continue;
        }
        let cond_text = &source[range];
        if cond_text.is_empty() {
            continue;
        }

        let (prefix, suffix) = if cond_text.starts_with('{') && cond_text.ends_with('}') {
            ("{", "}")
        } else {
            ("", "")
        };

        let folded = if cb.value { "1" } else { "0" };
        let replacement = format!("{prefix}{folded}{suffix}");

        ctx.report(Optimisation::new(
            DiagCode::O101,
            "Fold constant expression",
            span,
            replacement,
        ));
    }
}

/// Return `true` when a constant-branch is the synthetic
/// `switch` dispatch chain `cfg_builder` emits. The dispatch is
/// always a `StrEq` test between the switch subject and a pattern
/// word, with a fall-through target block named `switch_next_*`.
fn is_switch_dispatch(cond: &ExprNode, cb: &ConstantBranch) -> bool {
    if !matches!(
        cond,
        ExprNode::Binary {
            op: BinOp::StrEq,
            ..
        }
    ) {
        return false;
    }
    if cb.block.contains("switch_next") {
        return true;
    }
    cb.taken_target.starts_with("switch_next") || cb.not_taken_target.starts_with("switch_next")
}

#[cfg(test)]
mod tests {
    use std::collections::{HashMap, HashSet};
    use tcl_core_types::DiagCode;

    use tcl_lexer::Span;
    use tcl_registry::CommandRegistry;

    use crate::analyses::{ConstValue, LatticeValue};
    use crate::cfg::{Block, BlockId, Function as CfgFunction, Terminator};
    use crate::compilation_unit::{CompilationUnit, FunctionUnit};
    use crate::expr_ast::{BinOp, ExprNode};
    use crate::interprocedural::InterproceduralAnalysis;
    use crate::sccp::{ConstantBranch, SccpResult};
    use crate::ssa::{SsaBlock, SsaFunction, Symbol};

    use super::super::{PassContext, PassId};
    use super::run;

    #[test]
    fn original_branch_source_parser_keeps_retained_grammar_and_numeric_axes() {
        // naming.optimiser.original-branch-expression-source-grammar
        // docs/design/analysis/name-resolution-proofs/original-branch-expression-source-grammar.md
        // Source AST topology only, independent of native preparation/admission.
        let old = tcl_dialect::DialectProfile::find("tcl8.6").unwrap();
        let new = tcl_dialect::DialectProfile::find("tcl9.0").unwrap();
        let mut ctx = PassContext {
            dialect: Some(old),
            source_lexer_config: Some(tcl_lexer::LexerConfig::for_profile(Some(new))),
            ..PassContext::default()
        };
        assert!(matches!(
            super::branch_original_expression(&ctx, "${a{b}c}"),
            ExprNode::Var { name, .. } if name == "a{b}c"
        ));
        assert!(matches!(
            super::branch_original_expression(&ctx, "${a{b}"),
            ExprNode::Raw { .. }
        ));
        ctx.dialect = Some(new);
        ctx.source_lexer_config = Some(tcl_lexer::LexerConfig::for_profile(Some(old)));
        assert!(matches!(
            super::branch_original_expression(&ctx, "${a{b}"),
            ExprNode::Var { name, .. } if name == "a{b"
        ));
        assert!(matches!(
            super::branch_original_expression(&ctx, "${a{b}c}"),
            ExprNode::Raw { .. }
        ));
        assert!(matches!(
            super::branch_original_expression(&ctx, "${café}"),
            ExprNode::Var { name, .. } if name == "café"
        ));
        assert!(matches!(
            super::branch_original_expression(&ctx, "${scalar(open}"),
            ExprNode::Var { name, .. } if name == "scalar(open"
        ));
        // The lexer overlay cannot add Tcl 9 numeral forms to Tcl 8.4.
        ctx.dialect = tcl_dialect::DialectProfile::find("tcl8.4");
        ctx.source_lexer_config = Some(tcl_lexer::LexerConfig::for_profile(Some(new)));
        assert!(matches!(
            super::branch_original_expression(&ctx, "0d10"),
            ExprNode::Raw { .. }
        ));
        ctx.dialect = Some(new);
        ctx.source_lexer_config = Some(tcl_lexer::LexerConfig::for_profile(Some(old)));
        assert!(matches!(
            super::branch_original_expression(&ctx, "0d10"),
            ExprNode::Literal { text, .. } if text == "0d10"
        ));
    }

    #[test]
    fn original_branch_source_topology_keeps_equivalence_permission_separate() {
        // naming.optimiser.original-branch-expression-source-grammar
        // docs/design/analysis/name-resolution-proofs/original-branch-expression-source-grammar.md
        // Closed literal policy and missing original variable-object proof are
        // separate obligations; this is no native execution observation.
        let mut ctx = PassContext {
            dialect: tcl_dialect::DialectProfile::find("tcl9.0"),
            source_lexer_config: Some(tcl_lexer::LexerConfig::for_dialect("tcl8.6")),
            ..PassContext::default()
        };
        assert!(super::branch_execution_equivalent(
            &ctx,
            "1 + 2",
            "1 + 2",
            &HashMap::new(),
            Span::new(0, 5)
        ));
        let constants = HashMap::from([("scalar(open".to_owned(), "3".to_owned())]);
        assert!(matches!(
            super::branch_original_expression(&ctx, "${scalar(open}"),
            ExprNode::Var { name, .. } if name == "scalar(open"
        ));
        assert!(!super::branch_execution_equivalent(
            &ctx,
            "${scalar(open}",
            "3",
            &constants,
            Span::new(0, 14)
        ));
        ctx.dialect = None;
        assert!(!super::branch_execution_equivalent(
            &ctx,
            "1 + 2",
            "1 + 2",
            &HashMap::new(),
            Span::new(0, 5)
        ));
    }

    fn registry() -> CommandRegistry {
        CommandRegistry::build_default()
    }

    fn literal(text: &str) -> ExprNode {
        ExprNode::Literal {
            text: text.into(),
            start: 0,
            end: u32::try_from(text.len()).unwrap_or(0),
        }
    }

    fn str_eq_cond(var: &str, lit: &str) -> ExprNode {
        ExprNode::Binary {
            op: BinOp::StrEq,
            left: Box::new(ExprNode::Var {
                text: format!("${var}"),
                name: var.into(),
                start: 0,
                end: 0,
            }),
            right: Box::new(ExprNode::Literal {
                text: lit.into(),
                start: 0,
                end: 0,
            }),
        }
    }

    fn empty_ssa_block(name: &str) -> SsaBlock {
        SsaBlock {
            name: name.into(),
            phis: Vec::new(),
            statements: Vec::new(),
            entry_versions: HashMap::new(),
            exit_versions: HashMap::new(),
        }
    }

    /// Resolve an already-interned block name to its [`BlockId`].
    fn id_of(cfg: &CfgFunction, name: &str) -> BlockId {
        cfg.block_id(name).expect("block name interned")
    }

    /// Build an `SsaFunction` sharing `cfg`'s block-id numbering, with an
    /// empty `SsaBlock` inserted for every block in `cfg`.
    fn make_ssa(cfg: &CfgFunction) -> SsaFunction {
        let mut ssa = SsaFunction::trivial("::top", cfg.entry, cfg.block_names().to_vec());
        for (id, b) in &cfg.blocks {
            ssa.blocks.insert(*id, empty_ssa_block(&b.name));
        }
        ssa
    }

    /// The set of [`BlockId`]s for `names`, resolved against `cfg`.
    fn id_set(cfg: &CfgFunction, names: &[&str]) -> HashSet<BlockId> {
        names.iter().map(|n| id_of(cfg, n)).collect()
    }

    /// Build a synthetic [`FunctionUnit`] wrapping `cfg`, `ssa`,
    /// and a hand-rolled `SccpResult`. We skip the full pipeline
    /// so tests can feed the pass lattice values the SCCP driver
    /// would struggle to reach in isolation (mixed lattices,
    /// Overdefined, …).
    fn function_unit(
        name: &str,
        cfg: CfgFunction,
        ssa: SsaFunction,
        sccp: SccpResult,
    ) -> FunctionUnit {
        let mut unit = FunctionUnit::trivial_guarded(name, cfg);
        unit.ssa = ssa;
        unit.sccp = sccp;
        unit.complexity_guarded = false;
        unit.tier = tcl_registry::value_transfer::AnalysisTier::Deep;
        unit
    }

    /// Wrap a single [`FunctionUnit`] as a [`CompilationUnit`].
    fn compilation_unit(source: &str, mut fu: FunctionUnit) -> CompilationUnit {
        // These hand-built branches explicitly refer to this authored input.
        // Production obtains the same ownership from the script/CFG builders.
        let origin = std::sync::Arc::new(crate::command_binding::SourceOriginId::authored(
            &std::sync::Arc::from(source),
        ));
        let authored = std::sync::Arc::new(
            crate::command_binding::ExecutedScriptSource::contiguous(origin, source, 0)
                .expect("whole authored fixture"),
        );
        fu.cfg.executed_source = Some(std::sync::Arc::clone(&authored));
        for (&id, block) in &fu.cfg.blocks {
            if block
                .terminator
                .as_ref()
                .and_then(Terminator::span)
                .is_some()
            {
                fu.cfg
                    .terminator_sources
                    .insert(id, Some(std::sync::Arc::clone(&authored)));
            }
        }
        CompilationUnit::from_branch_folding_fixture(source, fu)
    }

    fn branch_block(
        name: &str,
        cond: ExprNode,
        span: Span,
        true_t: BlockId,
        false_t: BlockId,
    ) -> Block {
        let mut b = Block::new(name);
        b.terminator = Some(Terminator::Branch {
            condition: cond,
            true_target: true_t,
            false_target: false_t,
            span: Some(span),
            condition_base: None,
        });
        b
    }

    fn ret_block(name: &str) -> Block {
        let mut b = Block::new(name);
        b.terminator = Some(Terminator::Return {
            expr_base: None,
            tokens: None,
            value: None,
            value_word: None,
            span: None,
            expr: None,
            braced: false,
        });
        b
    }

    fn build_ctx(source: &str) -> PassContext<'_> {
        PassContext::new(source, InterproceduralAnalysis::default())
    }

    // Tests

    #[test]
    fn constant_true_condition_emits_o101_with_one() {
        let source = "if {1} { set x 1 } else { set y 2 }";
        let cond_span = Span::new(3, 6); // covers "{1}"
        let mut cfg = CfgFunction::new("::top", "entry");
        let entry = cfg.entry;
        let t = cfg.intern_block("t");
        let e = cfg.intern_block("e");
        cfg.blocks.get_mut(&entry).unwrap().terminator = Some(Terminator::Branch {
            condition: literal("1"),
            true_target: t,
            false_target: e,
            span: Some(cond_span),
            condition_base: None,
        });
        cfg.blocks.insert(t, ret_block("t"));
        cfg.blocks.insert(e, ret_block("e"));

        let ssa = make_ssa(&cfg);
        let sccp = SccpResult {
            required_math_invocations: Vec::new(),
            required_expression_preparations: Vec::new(),
            explanations: Vec::new(),
            route_tally: crate::value_transfer::RouteTally::default(),
            folded_types: HashMap::new(),
            preserved: HashMap::new(),
            raised: HashSet::default(),
            template_plans: Vec::new(),
            selections: Vec::new(),
            existence: HashMap::new(),
            existence_reads: HashMap::new(),
            existence_exits: HashMap::new(),
            existence_entries: HashMap::new(),
            refinements: Vec::new(),
            refinements_at: HashMap::new(),
            value_entries: HashMap::new(),
            query_places: Vec::new(),
            existence_guards: Vec::new(),
            loop_enumerations: Vec::new(),
            reads_module: false,
            completion: crate::sccp::RunCompletion::default(),
            values: HashMap::new(),
            executable_blocks: id_set(&cfg, &["entry", "t"]),
            executable_edges: HashSet::default(),
            constant_branches: vec![ConstantBranch {
                block: "entry".into(),
                span: Some(cond_span),
                condition: "1".into(),
                value: true,
                taken_target: "t".into(),
                not_taken_target: "e".into(),
                kind: crate::sccp::BranchFactKind::Applied,
            }],
        };
        let cu = compilation_unit(source, function_unit("::top", cfg, ssa, sccp));

        let mut ctx = build_ctx(&cu.source);
        run(&mut ctx, &cu);

        assert_eq!(ctx.optimisations.len(), 1);
        let opt = &ctx.optimisations[0];
        assert_eq!(opt.code, DiagCode::O101);
        assert_eq!(opt.message, "Fold constant expression");
        assert_eq!(opt.replacement, "{1}");
        assert_eq!(opt.span, cond_span);
        assert!(opt.group.is_none());
        assert!(!opt.hint_only);
    }

    #[test]
    fn constant_condition_ending_in_a_nested_empty_pair_keeps_its_own_closer() {
        // The condition span is the lexer's word span, so it stops one byte
        // short of the outer `}`. Deciding the widening from the slice's last
        // byte reads `{$x eq {}` as already whole — it does end in a `}`, the
        // *inner* empty pair's — and rewrites a span missing the outer brace,
        // leaving `while {0}} { … }`.
        let source = "while {$x eq {}} { set x done }";
        // `{$x eq {}` — the lexer's own inner-end span for the condition.
        let cond_span = Span::new(6, 15);
        assert_eq!(&source[cond_span.as_range()], "{$x eq {}");
        let whole_word = Span::new(6, 16);
        assert_eq!(&source[whole_word.as_range()], "{$x eq {}}");

        let mut cfg = CfgFunction::new("::top", "entry");
        let entry = cfg.entry;
        let t = cfg.intern_block("t");
        let e = cfg.intern_block("e");
        cfg.blocks.get_mut(&entry).unwrap().terminator = Some(Terminator::Branch {
            condition: literal("0"),
            true_target: t,
            false_target: e,
            span: Some(cond_span),
            condition_base: None,
        });
        cfg.blocks.insert(t, ret_block("t"));
        cfg.blocks.insert(e, ret_block("e"));

        let ssa = make_ssa(&cfg);
        let sccp = SccpResult {
            required_math_invocations: Vec::new(),
            required_expression_preparations: Vec::new(),
            explanations: Vec::new(),
            route_tally: crate::value_transfer::RouteTally::default(),
            folded_types: HashMap::new(),
            preserved: HashMap::new(),
            raised: HashSet::default(),
            template_plans: Vec::new(),
            selections: Vec::new(),
            existence: HashMap::new(),
            existence_reads: HashMap::new(),
            existence_exits: HashMap::new(),
            existence_entries: HashMap::new(),
            refinements: Vec::new(),
            refinements_at: HashMap::new(),
            value_entries: HashMap::new(),
            query_places: Vec::new(),
            existence_guards: Vec::new(),
            loop_enumerations: Vec::new(),
            reads_module: false,
            completion: crate::sccp::RunCompletion::default(),
            values: HashMap::new(),
            executable_blocks: id_set(&cfg, &["entry", "e"]),
            executable_edges: HashSet::default(),
            constant_branches: vec![ConstantBranch {
                block: "entry".into(),
                span: Some(cond_span),
                condition: "0".into(),
                value: false,
                taken_target: "e".into(),
                not_taken_target: "t".into(),
                kind: crate::sccp::BranchFactKind::Applied,
            }],
        };
        let cu = compilation_unit(source, function_unit("::top", cfg, ssa, sccp));

        let mut ctx = build_ctx(&cu.source);
        run(&mut ctx, &cu);

        assert_eq!(ctx.optimisations.len(), 1);
        let opt = &ctx.optimisations[0];
        assert_eq!(opt.code, DiagCode::O101);
        assert_eq!(
            opt.span, whole_word,
            "rewrite target must be the whole word"
        );
        assert_eq!(opt.replacement, "{0}");
        // Applying it must leave a balanced script, not `while {0}} { … }`.
        let mut rewritten = source.to_owned();
        rewritten.replace_range(opt.span.as_range(), &opt.replacement);
        assert_eq!(rewritten, "while {0} { set x done }");
    }

    #[test]
    fn constant_false_condition_emits_o101_with_zero() {
        let source = "if {0} {a} else {b}";
        let cond_span = Span::new(3, 6);
        let mut cfg = CfgFunction::new("::top", "entry");
        let entry = cfg.entry;
        let t = cfg.intern_block("t");
        let e = cfg.intern_block("e");
        cfg.blocks.get_mut(&entry).unwrap().terminator = Some(Terminator::Branch {
            condition: literal("0"),
            true_target: t,
            false_target: e,
            span: Some(cond_span),
            condition_base: None,
        });
        cfg.blocks.insert(t, ret_block("t"));
        cfg.blocks.insert(e, ret_block("e"));

        let ssa = make_ssa(&cfg);
        let sccp = SccpResult {
            required_math_invocations: Vec::new(),
            required_expression_preparations: Vec::new(),
            explanations: Vec::new(),
            route_tally: crate::value_transfer::RouteTally::default(),
            folded_types: HashMap::new(),
            preserved: HashMap::new(),
            raised: HashSet::default(),
            template_plans: Vec::new(),
            selections: Vec::new(),
            existence: HashMap::new(),
            existence_reads: HashMap::new(),
            existence_exits: HashMap::new(),
            existence_entries: HashMap::new(),
            refinements: Vec::new(),
            refinements_at: HashMap::new(),
            value_entries: HashMap::new(),
            query_places: Vec::new(),
            existence_guards: Vec::new(),
            loop_enumerations: Vec::new(),
            reads_module: false,
            completion: crate::sccp::RunCompletion::default(),
            values: HashMap::new(),
            executable_blocks: id_set(&cfg, &["entry", "e"]),
            executable_edges: HashSet::default(),
            constant_branches: vec![ConstantBranch {
                block: "entry".into(),
                span: Some(cond_span),
                condition: "0".into(),
                value: false,
                taken_target: "e".into(),
                not_taken_target: "t".into(),
                kind: crate::sccp::BranchFactKind::Applied,
            }],
        };
        let cu = compilation_unit(source, function_unit("::top", cfg, ssa, sccp));

        let mut ctx = build_ctx(&cu.source);
        run(&mut ctx, &cu);

        assert_eq!(ctx.optimisations.len(), 1);
        assert_eq!(ctx.optimisations[0].replacement, "{0}");
    }

    #[test]
    fn nested_constant_branches_fold_independently() {
        // entry branches on 1 → "mid"; mid branches on 0 → "inner_else".
        let source = "if {1} { if {0} {a} else {b} }";
        let outer_span = Span::new(3, 6); // "{1}"
        let inner_span = Span::new(12, 15); // "{0}"

        let mut cfg = CfgFunction::new("::top", "entry");
        let entry = cfg.entry;
        let mid = cfg.intern_block("mid");
        let after = cfg.intern_block("after");
        let inner_then = cfg.intern_block("inner_then");
        let inner_else = cfg.intern_block("inner_else");
        cfg.blocks.insert(
            entry,
            branch_block("entry", literal("1"), outer_span, mid, after),
        );
        cfg.blocks.insert(
            mid,
            branch_block("mid", literal("0"), inner_span, inner_then, inner_else),
        );
        cfg.blocks.insert(inner_then, ret_block("inner_then"));
        cfg.blocks.insert(inner_else, ret_block("inner_else"));
        cfg.blocks.insert(after, ret_block("after"));

        let ssa = make_ssa(&cfg);
        let sccp = SccpResult {
            required_math_invocations: Vec::new(),
            required_expression_preparations: Vec::new(),
            explanations: Vec::new(),
            route_tally: crate::value_transfer::RouteTally::default(),
            folded_types: HashMap::new(),
            preserved: HashMap::new(),
            raised: HashSet::default(),
            template_plans: Vec::new(),
            selections: Vec::new(),
            existence: HashMap::new(),
            existence_reads: HashMap::new(),
            existence_exits: HashMap::new(),
            existence_entries: HashMap::new(),
            refinements: Vec::new(),
            refinements_at: HashMap::new(),
            value_entries: HashMap::new(),
            query_places: Vec::new(),
            existence_guards: Vec::new(),
            loop_enumerations: Vec::new(),
            reads_module: false,
            completion: crate::sccp::RunCompletion::default(),
            values: HashMap::new(),
            executable_blocks: id_set(&cfg, &["entry", "mid", "inner_else"]),
            executable_edges: HashSet::default(),
            constant_branches: vec![
                ConstantBranch {
                    block: "entry".into(),
                    span: Some(outer_span),
                    condition: "1".into(),
                    value: true,
                    taken_target: "mid".into(),
                    not_taken_target: "after".into(),
                    kind: crate::sccp::BranchFactKind::Applied,
                },
                ConstantBranch {
                    block: "mid".into(),
                    span: Some(inner_span),
                    condition: "0".into(),
                    value: false,
                    taken_target: "inner_else".into(),
                    not_taken_target: "inner_then".into(),
                    kind: crate::sccp::BranchFactKind::Applied,
                },
            ],
        };
        let cu = compilation_unit(source, function_unit("::top", cfg, ssa, sccp));

        let mut ctx = build_ctx(&cu.source);
        run(&mut ctx, &cu);

        assert_eq!(ctx.optimisations.len(), 2);
        let replacements: Vec<&str> = ctx
            .optimisations
            .iter()
            .map(|o| o.replacement.as_str())
            .collect();
        assert!(replacements.contains(&"{1}"));
        assert!(replacements.contains(&"{0}"));
    }

    #[test]
    fn mixed_lattice_with_one_branch_const_folds_only_that_branch() {
        // entry branches on Unknown → SCCP leaves it out of
        // constant_branches. A second block's branch folds. Only
        // the folded branch should yield an O101.
        let source = "if {$x} { if {1} {a} else {b} }";
        let folded_span = Span::new(13, 16); // "{1}"

        let mut cfg = CfgFunction::new("::top", "entry");
        let entry = cfg.entry;
        let mid = cfg.intern_block("mid");
        let after = cfg.intern_block("after");
        let t = cfg.intern_block("t");
        let e = cfg.intern_block("e");
        cfg.blocks.get_mut(&entry).unwrap().terminator = Some(Terminator::Branch {
            condition: ExprNode::Var {
                text: "$x".into(),
                name: "x".into(),
                start: 0,
                end: 2,
            },
            true_target: mid,
            false_target: after,
            span: Some(Span::new(3, 7)), // "{$x}"
            condition_base: None,
        });
        cfg.blocks
            .insert(mid, branch_block("mid", literal("1"), folded_span, t, e));
        cfg.blocks.insert(t, ret_block("t"));
        cfg.blocks.insert(e, ret_block("e"));
        cfg.blocks.insert(after, ret_block("after"));

        let mut ssa = make_ssa(&cfg);
        let x = ssa.intern_var("x");
        let mut values: HashMap<(Symbol, u32), LatticeValue> = HashMap::new();
        // Simulate a mixed / Overdefined lattice for x.
        values.insert(
            (x, 1),
            LatticeValue::ConstSet(vec![ConstValue::Int(0), ConstValue::Int(1)]),
        );
        let sccp = SccpResult {
            required_math_invocations: Vec::new(),
            required_expression_preparations: Vec::new(),
            explanations: Vec::new(),
            route_tally: crate::value_transfer::RouteTally::default(),
            folded_types: HashMap::new(),
            preserved: HashMap::new(),
            raised: HashSet::default(),
            template_plans: Vec::new(),
            selections: Vec::new(),
            existence: HashMap::new(),
            existence_reads: HashMap::new(),
            existence_exits: HashMap::new(),
            existence_entries: HashMap::new(),
            refinements: Vec::new(),
            refinements_at: HashMap::new(),
            value_entries: HashMap::new(),
            query_places: Vec::new(),
            existence_guards: Vec::new(),
            loop_enumerations: Vec::new(),
            reads_module: false,
            completion: crate::sccp::RunCompletion::default(),
            values,
            executable_blocks: id_set(&cfg, &["entry", "mid", "t", "e"]),
            executable_edges: HashSet::default(),
            // Only the SCCP-proved constant branch appears here —
            // the ConstSet lattice does not produce one.
            constant_branches: vec![ConstantBranch {
                block: "mid".into(),
                span: Some(folded_span),
                condition: "1".into(),
                value: true,
                taken_target: "t".into(),
                not_taken_target: "e".into(),
                kind: crate::sccp::BranchFactKind::Applied,
            }],
        };
        let cu = compilation_unit(source, function_unit("::top", cfg, ssa, sccp));

        let mut ctx = build_ctx(&cu.source);
        run(&mut ctx, &cu);

        assert_eq!(ctx.optimisations.len(), 1);
        assert_eq!(ctx.optimisations[0].replacement, "{1}");
        // The folded one is in block "mid", span at offset 13.
        assert_eq!(ctx.optimisations[0].span, folded_span);
    }

    #[test]
    fn overdefined_lattice_produces_no_fold() {
        // Overdefined conditions never appear in
        // `constant_branches`, so the pass emits nothing.
        let source = "if {$x} { ok }";
        let mut cfg = CfgFunction::new("::top", "entry");
        let entry = cfg.entry;
        let t = cfg.intern_block("t");
        let e = cfg.intern_block("e");
        cfg.blocks.get_mut(&entry).unwrap().terminator = Some(Terminator::Branch {
            condition: ExprNode::Var {
                text: "$x".into(),
                name: "x".into(),
                start: 0,
                end: 2,
            },
            true_target: t,
            false_target: e,
            span: Some(Span::new(3, 7)),
            condition_base: None,
        });
        cfg.blocks.insert(t, ret_block("t"));
        cfg.blocks.insert(e, ret_block("e"));

        let mut ssa = make_ssa(&cfg);
        let x = ssa.intern_var("x");
        let mut values: HashMap<(Symbol, u32), LatticeValue> = HashMap::new();
        values.insert((x, 1), LatticeValue::Overdefined);
        let sccp = SccpResult {
            required_math_invocations: Vec::new(),
            required_expression_preparations: Vec::new(),
            explanations: Vec::new(),
            route_tally: crate::value_transfer::RouteTally::default(),
            folded_types: HashMap::new(),
            preserved: HashMap::new(),
            raised: HashSet::default(),
            template_plans: Vec::new(),
            selections: Vec::new(),
            existence: HashMap::new(),
            existence_reads: HashMap::new(),
            existence_exits: HashMap::new(),
            existence_entries: HashMap::new(),
            refinements: Vec::new(),
            refinements_at: HashMap::new(),
            value_entries: HashMap::new(),
            query_places: Vec::new(),
            existence_guards: Vec::new(),
            loop_enumerations: Vec::new(),
            reads_module: false,
            completion: crate::sccp::RunCompletion::default(),
            values,
            executable_blocks: id_set(&cfg, &["entry", "t", "e"]),
            executable_edges: HashSet::default(),
            constant_branches: Vec::new(),
        };
        let cu = compilation_unit(source, function_unit("::top", cfg, ssa, sccp));

        let mut ctx = build_ctx(&cu.source);
        run(&mut ctx, &cu);

        assert_eq!(ctx.optimisations, [] as [crate::optimiser::Optimisation; 0]);
    }

    #[test]
    fn bare_condition_without_braces_yields_unwrapped_replacement() {
        // `if 1 { ... }` — the cond span covers the bare `1`.
        let source = "if 1 { a } else { b }";
        let cond_span = Span::new(3, 4);
        let mut cfg = CfgFunction::new("::top", "entry");
        let entry = cfg.entry;
        let t = cfg.intern_block("t");
        let e = cfg.intern_block("e");
        cfg.blocks.get_mut(&entry).unwrap().terminator = Some(Terminator::Branch {
            condition: literal("1"),
            true_target: t,
            false_target: e,
            span: Some(cond_span),
            condition_base: None,
        });
        cfg.blocks.insert(t, ret_block("t"));
        cfg.blocks.insert(e, ret_block("e"));

        let ssa = make_ssa(&cfg);
        let sccp = SccpResult {
            required_math_invocations: Vec::new(),
            required_expression_preparations: Vec::new(),
            explanations: Vec::new(),
            route_tally: crate::value_transfer::RouteTally::default(),
            folded_types: HashMap::new(),
            preserved: HashMap::new(),
            raised: HashSet::default(),
            template_plans: Vec::new(),
            selections: Vec::new(),
            existence: HashMap::new(),
            existence_reads: HashMap::new(),
            existence_exits: HashMap::new(),
            existence_entries: HashMap::new(),
            refinements: Vec::new(),
            refinements_at: HashMap::new(),
            value_entries: HashMap::new(),
            query_places: Vec::new(),
            existence_guards: Vec::new(),
            loop_enumerations: Vec::new(),
            reads_module: false,
            completion: crate::sccp::RunCompletion::default(),
            values: HashMap::new(),
            executable_blocks: id_set(&cfg, &["entry", "t"]),
            executable_edges: HashSet::default(),
            constant_branches: vec![ConstantBranch {
                block: "entry".into(),
                span: Some(cond_span),
                condition: "1".into(),
                value: true,
                taken_target: "t".into(),
                not_taken_target: "e".into(),
                kind: crate::sccp::BranchFactKind::Applied,
            }],
        };
        let cu = compilation_unit(source, function_unit("::top", cfg, ssa, sccp));

        let mut ctx = build_ctx(&cu.source);
        run(&mut ctx, &cu);

        assert_eq!(ctx.optimisations.len(), 1);
        assert_eq!(ctx.optimisations[0].replacement, "1");
    }

    #[test]
    fn switch_dispatch_branches_are_skipped() {
        // A `StrEq` condition where either the block name or a
        // target name mentions `switch_next` — the synthetic
        // dispatch chain — must not be folded.
        let source = "switch -- $s { a { one } b { two } }";
        let cond_span = Span::new(14, 17);
        let mut cfg = CfgFunction::new("::top", "switch_probe_0");
        let probe = cfg.entry;
        let arm_a = cfg.intern_block("arm_a");
        let switch_next_1 = cfg.intern_block("switch_next_1");
        cfg.blocks.insert(
            probe,
            branch_block(
                "switch_probe_0",
                str_eq_cond("s", "a"),
                cond_span,
                arm_a,
                switch_next_1,
            ),
        );
        cfg.blocks.insert(arm_a, ret_block("arm_a"));
        cfg.blocks.insert(switch_next_1, ret_block("switch_next_1"));

        let ssa = make_ssa(&cfg);
        let sccp = SccpResult {
            required_math_invocations: Vec::new(),
            required_expression_preparations: Vec::new(),
            explanations: Vec::new(),
            route_tally: crate::value_transfer::RouteTally::default(),
            folded_types: HashMap::new(),
            preserved: HashMap::new(),
            raised: HashSet::default(),
            template_plans: Vec::new(),
            selections: Vec::new(),
            existence: HashMap::new(),
            existence_reads: HashMap::new(),
            existence_exits: HashMap::new(),
            existence_entries: HashMap::new(),
            refinements: Vec::new(),
            refinements_at: HashMap::new(),
            value_entries: HashMap::new(),
            query_places: Vec::new(),
            existence_guards: Vec::new(),
            loop_enumerations: Vec::new(),
            reads_module: false,
            completion: crate::sccp::RunCompletion::default(),
            values: HashMap::new(),
            executable_blocks: id_set(&cfg, &["switch_probe_0", "arm_a"]),
            executable_edges: HashSet::default(),
            constant_branches: vec![ConstantBranch {
                block: "switch_probe_0".into(),
                span: Some(cond_span),
                condition: "$s eq a".into(),
                value: true,
                taken_target: "arm_a".into(),
                not_taken_target: "switch_next_1".into(),
                kind: crate::sccp::BranchFactKind::Applied,
            }],
        };
        let cu = compilation_unit(source, function_unit("::top", cfg, ssa, sccp));

        let mut ctx = build_ctx(&cu.source);
        run(&mut ctx, &cu);

        assert_eq!(
            ctx.optimisations.len(),
            0,
            "switch dispatch branches must not be folded: got {:?}",
            ctx.optimisations,
        );
    }

    #[test]
    fn branch_proc_calls_propagates_constant_into_non_folded_branch() {
        // `$cond` is Overdefined (written two different values
        // in branches of an outer if); the inner `if {$cond}` is
        // therefore not a SCCP constant branch. The branch-
        // proc-calls pass should attempt substitution and — since
        // $cond is Overdefined — emit nothing. This test exercises
        // the "no constant available" code path.
        let cu = CompilationUnit::build_for(
            "set cond 1\nif {$flag} { set cond 2 }\nif {$cond} { set x 1 }",
            &registry(),
            false,
        );
        let mut ctx = PassContext::new(&cu.source, InterproceduralAnalysis::default());
        run(&mut ctx, &cu);
        // No O100 because $cond is not a single constant across
        // all tracked versions.
        assert!(
            !ctx.optimisations.iter().any(|o| o.code == DiagCode::O100),
            "unexpected O100 for Overdefined variable: {:?}",
            ctx.optimisations,
        );
    }

    #[test]
    fn branch_proc_calls_emits_o100_when_const_propagates() {
        // `set x 5` makes $x constant; `if {$x < $y}` has one
        // tracked version of $x, which SCCP collapses. The
        // branch condition `$x < $y` is not a SCCP constant
        // branch (because $y is Unknown), so substituting $x → 5
        // is the only rewrite. Expect an O100.
        let cu =
            CompilationUnit::build_for("set x 5\nif {$x < $y} { set z 1 }", &registry(), false);
        let mut ctx = PassContext::new(&cu.source, InterproceduralAnalysis::default());
        run(&mut ctx, &cu);
        let got = ctx
            .optimisations
            .iter()
            .find(|o| o.code == DiagCode::O100 && o.message.contains("branch"));
        assert!(
            got.is_some(),
            "expected O100 propagating x=5 into branch, got {:?}",
            ctx.optimisations,
        );
        let opt = got.unwrap();
        assert!(
            opt.replacement.contains('5'),
            "replacement should contain the propagated value, got {:?}",
            opt.replacement,
        );
    }

    #[test]
    fn branch_folding_runs_via_run_passes_dispatch() {
        // Smoke-test the PassId::BranchFolding wiring end-to-end
        // from a real source string using the full pipeline.
        let cu =
            CompilationUnit::build_for("if {1} { set x 1 } else { set y 2 }", &registry(), false);
        let mut ctx = build_ctx(&cu.source);
        super::super::run_passes(&mut ctx, &cu, &[PassId::BranchFolding]);
        assert!(
            ctx.optimisations
                .iter()
                .any(|o| o.code == DiagCode::O101 && o.replacement.contains('1')),
            "expected an O101 fold via run_passes, got {:?}",
            ctx.optimisations,
        );
    }

    #[test]
    fn branch_condition_redundant_expr_emits_o115() {
        // `if {[expr {$x}]} …` — the condition is a redundant `[expr {…}]`
        // wrapper; it unwraps to `$x`. Exercised at top level (proc bodies
        // with a returning branch collapse to a straight CFG).
        let cu = CompilationUnit::build_for(
            "if {[expr {$x}]} { puts a } else { puts b }",
            &registry(),
            false,
        );
        let mut ctx = build_ctx(&cu.source);
        super::super::run_passes(&mut ctx, &cu, &[PassId::BranchFolding]);
        let o115 = ctx
            .optimisations
            .iter()
            .find(|o| o.code == DiagCode::O115)
            .expect("expected an O115 unwrap on the branch condition");
        assert_eq!(o115.replacement, "{$x}");
    }

    #[test]
    fn renamed_expr_blocks_branch_condition_unwrap() {
        // FP guard: `if {[expr {$x}]} …` embeds a genuine command
        // substitution — once `expr` is renamed anywhere in the module,
        // `[expr {$x}]` no longer means "evaluate $x as an expression", so
        // the O115 unwrap must not fire.
        let source = "rename expr real_expr\nif {[expr {$x}]} { puts a } else { puts b }";
        let reg = registry();
        let cu = CompilationUnit::build_for(source, &reg, false);
        let mut ctx = build_ctx(&cu.source);
        ctx.command_mutations =
            crate::command_binding::scan_module_command_mutations(&cu.ir_module, &reg);
        super::super::run_passes(&mut ctx, &cu, &[PassId::BranchFolding]);
        assert!(
            ctx.optimisations.iter().all(|o| o.code != DiagCode::O115),
            "must not unwrap through a renamed expr: {:?}",
            ctx.optimisations,
        );
    }

    #[test]
    fn plain_branch_condition_fold_unaffected_by_expr_rename() {
        // TN/control: `if`/`while` conditions are evaluated by Tcl's own
        // internal expr engine, never by dispatching a command literally
        // named "expr" — so renaming `expr` elsewhere in the module must
        // NOT block a plain (no explicit `[expr {…}]` substring) constant
        // branch fold.
        let source = "rename expr real_expr\nif {2 + 2 == 4} { puts a } else { puts b }";
        let reg = registry();
        let cu = CompilationUnit::build_for(source, &reg, false);
        let mut ctx = build_ctx(&cu.source);
        ctx.command_mutations =
            crate::command_binding::scan_module_command_mutations(&cu.ir_module, &reg);
        super::super::run_passes(&mut ctx, &cu, &PassId::all());
        assert!(
            ctx.optimisations
                .iter()
                .any(|o| o.code == DiagCode::O101 || o.code == DiagCode::O112),
            "plain condition fold must be unaffected by an unrelated expr rename: {:?}",
            ctx.optimisations,
        );
    }

    #[test]
    fn missing_terminator_source_owner_declines_source_rewrite() {
        let source = "if {2 + 2 == 4} { puts a } else { puts b }";
        let mut cu = CompilationUnit::build_for(source, &registry(), false);
        cu.top_level.cfg.terminator_sources.clear();
        let mut ctx = build_ctx(source);
        run(&mut ctx, &cu);
        assert!(
            ctx.optimisations.is_empty(),
            "unknown source ownership must decline: {:?}",
            ctx.optimisations
        );
    }
}
