// tcl-lsp — a language server and toolchain for Tcl
// Copyright (C) 2026 James Deucker (bitwisecook) <https://github.com/bitwisecook>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.
//
// SPDX-License-Identifier: AGPL-3.0-or-later

//! Intrep shimmer analysis — detect places where a variable's
//! Tcl-value intrep (list/dict/int/…) is converted at a use site.
//!
//! Decomposed into
//! independently-testable sub-modules:
//!
//! | Sub-module    | Responsibility                                  |
//! |---------------|-------------------------------------------------|
//! | [`graph`]     | Loop detection, CFG reachability                |
//! | [`hints`]     | Registry arg-type hints, numeric compatibility  |
//! | [`span`]      | SSA definition → source span mapping            |
//! | [`use_site`]  | S100/S101 use-site shimmer detection            |
//! | [`phi`]       | S101 phi-node shimmer detection                 |
//! | [`expr`]      | S100 expression-level shimmer detection         |
//! | [`thunking`]  | S102 loop-oscillation detection                 |
//! | [`sharing`]   | S103 shared-value copy-on-write detection       |
//! | [`byte_array`]| S110 byte-array-corruption detection            |

pub mod byte_array;
pub mod commit;
pub mod expr;
pub mod graph;
pub mod hints;
pub mod phi;
pub mod sharing;
mod source_context;
pub mod span;
pub mod thunking;
pub mod use_site;
pub use source_context::ShimmerContext;

use std::collections::{HashMap, HashSet};
use tcl_core_types::DiagCode;

use tcl_lexer::Span;
use tcl_registry::{BytePayloadSpec, CommandRegistry, TclType};

use crate::cfg::{BlockId, Function as CfgFunction};
use crate::ssa::{SsaFunction, ValueKey};
use crate::types::TypeLattice;

/// A use-site where a variable's intrep is converted.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct ShimmerWarning {
    /// Source span of the use.
    pub span: Span,
    /// Variable name.
    pub variable: String,
    /// Source intrep (the type the variable held).
    pub from_type: TclType,
    /// Target intrep (the type the command expected).
    pub to_type: TclType,
    /// Command that triggered the conversion.
    pub command: String,
    /// Whether the use is inside a loop body.
    pub in_loop: bool,
    /// Diagnostic code (`"S100"` / `"S101"`).
    pub code: DiagCode,
    /// Formatted message.
    pub message: String,
    /// Related spans + labels for diagnostic context.
    pub related: Vec<(Span, String)>,
}

/// A variable that oscillates between two types across loop iterations.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct ThunkingWarning {
    /// Source span.
    pub span: Span,
    /// Variable name.
    pub variable: String,
    /// First observed type.
    pub type_a: TclType,
    /// Second observed type.
    pub type_b: TclType,
    /// Diagnostic code (`"S102"`).
    pub code: DiagCode,
    /// Formatted message.
    pub message: String,
    /// Related spans.
    pub related: Vec<(Span, String)>,
}

/// A mutation of a provably shared value — C Tcl duplicates the whole value
/// before writing (`Tcl_IsShared` → `Tcl_DuplicateObj`), so the mutation
/// pays an O(n) copy. See [`sharing`].
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct SharingWarning {
    /// Source span of the mutating command.
    pub span: Span,
    /// The mutated variable.
    pub variable: String,
    /// The other live holder of the same value.
    pub shared_with: String,
    /// The mutating command (`lappend` / `lset` / `dict`).
    pub command: String,
    /// Diagnostic code (`"S103"`).
    pub code: DiagCode,
    /// Formatted message.
    pub message: String,
    /// Related spans: the copy that created the share, and the partner's
    /// still-live read.
    pub related: Vec<(Span, String)>,
}

/// Human-readable lowercase name for a Tcl intrep type.
///
/// ```
/// use tcl_compiler::shimmer::type_name;
/// use tcl_registry::TclType;
/// assert_eq!(type_name(TclType::Int), "int");
/// ```
#[must_use]
pub fn type_name(t: TclType) -> String {
    format!("{t:?}").to_ascii_lowercase()
}

/// Resolve the `from` side of a warning against the committed-intrep state:
/// the single committed rep when every path agrees, a *path-dependent* label
/// naming the possibilities when different paths committed different reps,
/// the steady-state may-rep of a loop-carried value, or the lattice fallback.
/// Returns the struct-level `from_type` plus the message label (they differ
/// only in the path-dependent case, where no single `TclType` is truthful).
///
/// A candidate equal to `expected` never names the from side — a loop header
/// re-joins its own conversion via the back edge (`dict for`'s list argument
/// is already a dict on iterations 2+), and that same-type path is exactly
/// the one *not* paying; the reported conversion is from the other state.
#[must_use]
pub(crate) fn committed_from_label(
    state: &commit::CommitState,
    fallback: TclType,
    expected: TclType,
) -> (TclType, String) {
    if let Some(t) = state.single_committed()
        && t != expected
    {
        return (t, type_name(t));
    }
    let may: Vec<TclType> = state
        .may_types()
        .iter()
        .copied()
        .filter(|&t| t != expected)
        .collect();
    if may.len() >= 2 {
        let names: Vec<String> = may.iter().map(|&t| type_name(t)).collect();
        return (fallback, format!("path-dependent ({})", names.join(" or ")));
    }
    if let [t] = may[..] {
        return (t, type_name(t));
    }
    (fallback, type_name(fallback))
}

/// Find intrep-shimmer warnings for a single function.
///
/// Runs three sub-passes in order:
/// 1. **Use-site** ([`use_site`]): a command argument expects a different
///    type than the variable currently holds (S100 outside loops, S101
///    inside loops).
/// 2. **Phi-node** ([`phi`]): control-flow merges two differently-typed
///    versions of a variable (S101).
/// 3. **Expression** ([`expr`]): arithmetic/comparison operators used with
///    the wrong operand type (S100).
///
/// `sccp` is the function's own lattice: its reachability, its constants,
/// and the folded types its evaluations state — a computed value's
/// representation decides whether a use of it converts
/// ([`hints::is_free_first_conversion`]).
#[must_use]
#[cfg(test)]
pub(crate) fn find_shimmer_warnings(
    cfg: &CfgFunction,
    ssa: &SsaFunction,
    types: &HashMap<ValueKey, TypeLattice>,
    sccp: &crate::sccp::SccpResult,
    registry: &CommandRegistry,
) -> Vec<ShimmerWarning> {
    find_shimmer_warnings_with_context(cfg, ssa, types, sccp, ShimmerContext::standalone(registry))
}

pub(crate) fn find_shimmer_warnings_with_context(
    cfg: &CfgFunction,
    ssa: &SsaFunction,
    types: &HashMap<ValueKey, TypeLattice>,
    sccp: &crate::sccp::SccpResult,
    context: ShimmerContext<'_>,
) -> Vec<ShimmerWarning> {
    let registry = context.registry();
    let executable_blocks = &sccp.executable_blocks;
    // The committed-intrep dataflow (first-use commit) is shared by the
    // use-site and expr detectors: it tells each use whether the value has
    // already committed a different intrep on every path (a genuine second
    // conversion) or is still pure (a free first conversion).
    let commit_ctx = commit::CommitCtx {
        registry,
        context,
        ssa,
        source: crate::ssa::SsaSourceView::unpositioned(ssa),
        types,
        values: &sccp.values,
        folded: &sccp.folded_types,
    };
    let facts = ShimmerFacts {
        commit: commit::compute_commit_facts(
            cfg,
            &commit_ctx,
            executable_blocks,
            &sccp.executable_edges,
        ),
        loop_blocks: graph::loop_body_blocks(cfg),
    };
    // A use reads the type a refinement in force at its block proves.
    let in_force = crate::type_infer::types_in_force(types, sccp);
    let mut out = Vec::new();
    out.extend(use_site::find_use_site_shimmers_with_context(
        cfg,
        &commit_ctx,
        (executable_blocks, &in_force),
        &facts,
    ));
    out.extend(phi::find_phi_shimmers(
        cfg,
        ssa,
        types,
        sccp,
        &facts.loop_blocks,
    ));
    out.extend(expr::find_expr_shimmers_with_context(
        cfg,
        &commit_ctx,
        (executable_blocks, &in_force),
        &facts,
    ));
    out
}

/// The type lattice as one block's statements and terminator read it: the
/// type a refinement in force at the block proves of a version
/// ([`crate::type_infer::types_in_force`]) — the arm of `[string is integer
/// -strict $x]` reads `x` as an integer — and otherwise the version's own.
#[derive(Clone, Copy)]
pub(crate) struct BlockTypes<'a> {
    own: &'a HashMap<ValueKey, TypeLattice>,
    in_force: Option<&'a HashMap<(BlockId, ValueKey), TypeLattice>>,
    block: BlockId,
}

impl<'a> BlockTypes<'a> {
    /// `own` as `block` reads it under the refinements `in_force`.
    pub(crate) fn at(
        own: &'a HashMap<ValueKey, TypeLattice>,
        in_force: &'a HashMap<(BlockId, ValueKey), TypeLattice>,
        block: BlockId,
    ) -> Self {
        Self {
            own,
            in_force: Some(in_force),
            block,
        }
    }

    /// `own` read with no refinement in force.
    #[cfg(test)]
    pub(crate) fn unrefined(own: &'a HashMap<ValueKey, TypeLattice>, block: BlockId) -> Self {
        Self {
            own,
            in_force: None,
            block,
        }
    }

    /// The type `key` holds in the block.
    pub(crate) fn get(&self, key: ValueKey) -> Option<&'a TypeLattice> {
        self.in_force
            .and_then(|in_force| in_force.get(&(self.block, key)))
            .or_else(|| self.own.get(&key))
    }
}

/// Per-function facts the three shimmer sub-passes share, each computed once
/// per CFG rather than once per pass.
///
/// The committed-intrep dataflow is consumed by the use-site and expr
/// detectors; the cycle-block set by all three (it decides the S100 / S101
/// in-loop split).  Recomputing the latter per pass costs ~69 s on a
/// 2000-branch flat proc; the graph walk is a single Tarjan pass instead.
pub(crate) struct ShimmerFacts {
    /// Committed-intrep facts — see [`commit::compute_commit_facts`].
    pub commit: commit::CommitFacts,
    /// Every block that lies on a cycle — see [`graph::loop_body_blocks`].
    pub loop_blocks: HashSet<String>,
}

/// Find every shimmer warning across a whole compilation unit.
///
/// Public `*_for_cu` entry point (mirroring
/// [`crate::gvn::find_redundancies_for_cu`]) so downstream tooling — the
/// compiler explorer, the MCP server — can run the analysis without
/// re-deriving per-function inputs. Walks each function's SSA / type /
/// SCCP results in `cu.functions()` order.
#[must_use]
pub fn find_shimmer_warnings_for_cu(
    cu: &crate::compilation_unit::CompilationUnit,
    registry: &CommandRegistry,
) -> Vec<ShimmerWarning> {
    let mut out = Vec::new();
    for fu in cu.analysable_functions() {
        let Some(context) = ShimmerContext::for_function(fu, registry) else {
            continue;
        };
        out.extend(find_shimmer_warnings_with_context(
            &fu.cfg, &fu.ssa, &fu.types, &fu.sccp, context,
        ));
    }
    out
}

/// The "first used as" intrep pushback for every function unit: variables
/// whose def is **pure** (a literal / interpolation / string-command result)
/// and whose every executable typed read committed the **same** intrep map to
/// that intrep, keyed by function name then variable name (all versions must
/// agree). This test projection checks consensus across all versions.
#[cfg(test)]
#[must_use]
pub fn first_use_commitments_for_cu(
    cu: &crate::compilation_unit::CompilationUnit,
    registry: &CommandRegistry,
) -> HashMap<String, HashMap<String, TclType>> {
    let mut out: HashMap<String, HashMap<String, TclType>> = HashMap::new();
    for fu in cu.analysable_functions() {
        let commitments = first_use_value_commitments_for_function(fu, registry);
        // Collapse (sym, ver) → name: every version with a pushback must agree
        // on the same intrep, else the name is dropped (conflicting uses).
        let mut per_name: HashMap<String, Option<TclType>> = HashMap::new();
        for ((sym, _ver), t) in commitments {
            per_name
                .entry(fu.ssa.var_name(sym).to_owned())
                .and_modify(|slot| {
                    if *slot != Some(t) {
                        *slot = None;
                    }
                })
                .or_insert(Some(t));
        }
        let agreed: HashMap<String, TclType> = per_name
            .into_iter()
            .filter_map(|(name, t)| t.map(|t| (name, t)))
            .collect();
        if !agreed.is_empty() {
            out.insert(fu.name.clone(), agreed);
        }
    }
    out
}

/// First-use commitments for actual SSA symbols in one retained function.
/// Displayed function and variable labels do not select this result.
#[cfg(test)]
#[must_use]
pub fn first_use_commitments_for_function(
    function: &crate::compilation_unit::FunctionUnit,
    registry: &CommandRegistry,
) -> HashMap<crate::ssa::Symbol, TclType> {
    let mut symbols: HashMap<crate::ssa::Symbol, Option<TclType>> = HashMap::new();
    for ((symbol, _version), value) in first_use_value_commitments_for_function(function, registry)
    {
        symbols
            .entry(symbol)
            .and_modify(|previous| {
                if *previous != Some(value) {
                    *previous = None;
                }
            })
            .or_insert(Some(value));
    }
    symbols
        .into_iter()
        .filter_map(|(symbol, value)| value.map(|value| (symbol, value)))
        .collect()
}

/// First-use advice for each represented contents version in one retained function.
/// Source read ownership and available versions must be selected independently.
#[must_use]
pub fn first_use_value_commitments_for_function(
    function: &crate::compilation_unit::FunctionUnit,
    registry: &CommandRegistry,
) -> HashMap<crate::ssa::ValueKey, TclType> {
    let Some(context) = ShimmerContext::for_function(function, registry) else {
        return HashMap::new();
    };
    let ctx = commit::CommitCtx {
        registry,
        context,
        ssa: &function.ssa,
        source: crate::ssa::SsaSourceView::unpositioned(&function.ssa),
        types: &function.types,
        values: &function.sccp.values,
        folded: &function.sccp.folded_types,
    };
    commit::compute_commit_facts(
        &function.cfg,
        &ctx,
        &function.sccp.executable_blocks,
        &function.sccp.executable_edges,
    )
    .single_commitments(&ctx)
}

/// Find every thunking warning across a whole compilation unit. See
/// [`find_shimmer_warnings_for_cu`].
#[must_use]
pub fn find_thunking_warnings_for_cu(
    cu: &crate::compilation_unit::CompilationUnit,
    registry: &CommandRegistry,
) -> Vec<ThunkingWarning> {
    let mut out = Vec::new();
    for fu in cu.analysable_functions() {
        let Some(context) = ShimmerContext::for_function(fu, registry) else {
            continue;
        };
        out.extend(find_thunking_warnings_with_context(
            &fu.cfg,
            &fu.ssa,
            &fu.types,
            &fu.sccp.executable_blocks,
            context,
            cu.method_instance_vars(fu.body_id),
        ));
    }
    out
}

/// Find thunking warnings for a single function.
///
/// Identifies variables that oscillate between two intrep types across
/// loop iterations, causing a type conversion on every pass (S102).
#[must_use]
#[cfg(test)]
pub(crate) fn find_thunking_warnings<S: std::hash::BuildHasher>(
    cfg: &CfgFunction,
    ssa: &SsaFunction,
    types: &HashMap<ValueKey, TypeLattice>,
    executable_blocks: &HashSet<BlockId>,
    registry: &CommandRegistry,
    extra_scope_aliases: Option<&HashSet<String, S>>,
) -> Vec<ThunkingWarning> {
    find_thunking_warnings_with_context(
        cfg,
        ssa,
        types,
        executable_blocks,
        ShimmerContext::standalone(registry),
        extra_scope_aliases,
    )
}

pub(crate) fn find_thunking_warnings_with_context<S: std::hash::BuildHasher>(
    cfg: &CfgFunction,
    ssa: &SsaFunction,
    types: &HashMap<ValueKey, TypeLattice>,
    executable_blocks: &HashSet<BlockId>,
    context: ShimmerContext<'_>,
    extra_scope_aliases: Option<&HashSet<String, S>>,
) -> Vec<ThunkingWarning> {
    thunking::find_thunking_warnings_with_context(
        cfg,
        ssa,
        types,
        executable_blocks,
        context,
        extra_scope_aliases,
    )
}

/// Find shared-value copy-on-write warnings (S103) for a single function.
///
/// Fires on the tight `set b $a` … `lappend/lset/dict-mutator` pattern
/// where both holders are provably alive — C Tcl duplicates the shared
/// value before every such mutation. See [`sharing`] for the pattern and
/// its deliberate exclusions.
pub(crate) fn find_sharing_warnings_with_context<S: std::hash::BuildHasher>(
    cfg: &CfgFunction,
    ssa: &SsaFunction,
    def_use: &crate::def_use::DefUseFacts,
    executable_blocks: &HashSet<BlockId>,
    context: ShimmerContext<'_>,
    extra_scope_aliases: Option<&HashSet<String, S>>,
) -> Vec<SharingWarning> {
    sharing::find_sharing_warnings_with_context(
        cfg,
        ssa,
        def_use,
        executable_blocks,
        context,
        extra_scope_aliases,
    )
}

/// Find every shared-value copy-on-write warning (S103) across a whole
/// compilation unit. See [`find_shimmer_warnings_for_cu`].
#[must_use]
pub fn find_sharing_warnings_for_cu(
    cu: &crate::compilation_unit::CompilationUnit,
    registry: &CommandRegistry,
) -> Vec<SharingWarning> {
    let mut out = Vec::new();
    for fu in cu.analysable_functions() {
        let Some(context) = ShimmerContext::for_function(fu, registry) else {
            continue;
        };
        out.extend(find_sharing_warnings_with_context(
            &fu.cfg,
            &fu.ssa,
            &fu.def_use,
            &fu.sccp.executable_blocks,
            context,
            cu.method_instance_vars(fu.body_id),
        ));
    }
    out
}

/// Find byte-array-corruption warnings (S110) for a single function.
///
/// A forward byte-provenance dataflow flags binary data (a `*::payload`
/// getter, `binary format` / `binary decode` / `encoding convertto`) that is
/// coerced to a character string and then written back through a byte sink
/// (`*::payload replace`), or case-folded / re-encoded directly. See
/// [`byte_array`]. `payload_layouts` is the dialect-gated `*::payload` byte
/// command set (empty under non-iRules dialects).
pub(crate) fn find_byte_array_warnings_with_context(
    cfg: &CfgFunction,
    ssa: &SsaFunction,
    sccp: &crate::sccp::SccpResult,
    context: ShimmerContext<'_>,
    payload_layouts: &HashMap<&'static str, BytePayloadSpec>,
) -> Vec<ShimmerWarning> {
    byte_array::find_byte_array_warnings_with_context(cfg, ssa, sccp, context, payload_layouts)
}

/// Find every byte-array-corruption warning (S110) across a whole compilation
/// unit. The `*::payload` byte-command set is taken from the registry (already
/// scoped to the loaded dialect). See [`find_shimmer_warnings_for_cu`].
#[must_use]
pub fn find_byte_array_warnings_for_cu(
    cu: &crate::compilation_unit::CompilationUnit,
    registry: &CommandRegistry,
) -> Vec<ShimmerWarning> {
    let payload_layouts = registry.byte_array_payload_layouts();
    let mut out = Vec::new();
    for fu in cu.analysable_functions() {
        let Some(context) = ShimmerContext::for_function(fu, registry) else {
            continue;
        };
        out.extend(find_byte_array_warnings_with_context(
            &fu.cfg,
            &fu.ssa,
            &fu.sccp,
            context,
            &payload_layouts,
        ));
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::cfg::Function;
    use tcl_registry::CommandRegistry;

    fn registry() -> CommandRegistry {
        CommandRegistry::build_default()
    }

    #[test]
    fn first_use_symbols_keep_the_actual_function_and_refuse_missing_input() {
        let context =
            tcl_registry::model::ingress::resolve_environment("tcl9.0").default_context_registry();
        let registry = context.commands();
        let unit = byte_array::retained_representation_unit(
            "set value {1 2 3}; llength $value",
            std::sync::Arc::clone(&context),
        );
        let original = first_use_commitments_for_function(&unit.top_level, registry);
        assert!(original.values().any(|value| *value == TclType::List));
        let mut renamed = unit.top_level.clone();
        renamed.name = "unrelated reporting label".to_owned();
        assert_eq!(
            first_use_commitments_for_function(&renamed, registry),
            original
        );
        renamed.source_metadata_input = None;
        assert!(first_use_commitments_for_function(&renamed, registry).is_empty());
        let mut foreign = CommandRegistry::build_default();
        let mut changed = foreign.get("set").unwrap().clone();
        changed.name = "unrelated";
        foreign.insert(changed);
        assert!(first_use_commitments_for_function(&unit.top_level, &foreign).is_empty());
    }

    #[test]
    fn type_name_is_lowercase() {
        assert_eq!(type_name(TclType::Int), "int");
        assert_eq!(type_name(TclType::String), "string");
        assert_eq!(type_name(TclType::List), "list");
    }

    /// API smoke-test: both entry points accept an empty function.
    #[test]
    fn find_shimmer_warnings_empty_function() {
        let f = Function::new("::top", "entry");
        let ssa = crate::ssa::build_ssa(&f, &registry());
        let sccp = crate::sccp::sccp(
            &f,
            &ssa,
            None,
            crate::tcl_expr_eval::FoldPolicy::default(),
            crate::sccp::TraceInputs {
                source_metadata_input: None,
                registry: &registry(),
                traced_variables: &std::collections::BTreeSet::new(),
                has_dynamic_variable_trace: false,
                deferred_writes: &crate::ir::NO_DEFERRED_WRITES,
                analysis_context: None,
                existence: None,
            },
        );
        let types: HashMap<ValueKey, TypeLattice> = HashMap::new();
        assert!(find_shimmer_warnings(&f, &ssa, &types, &sccp, &registry()).is_empty());
        assert_eq!(
            find_thunking_warnings(
                &f,
                &ssa,
                &types,
                &sccp.executable_blocks,
                &registry(),
                None::<&HashSet<String>>
            )
            .len(),
            0
        );
    }
}
