// tcl-lsp — a language server and toolchain for Tcl
// Copyright (C) 2026 James Deucker (bitwisecook) <https://github.com/bitwisecook>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.
//
// SPDX-License-Identifier: AGPL-3.0-or-later

//! Side-effect classification for compiler analysis passes.
//!
//! Rich, structured model of what a Tcl/iRules command does to its
//! environment — what it reads, what it writes, where the data lives,
//! what shape it has, and which dialect/connection context applies.
//!
//! The model is layered:
//!
//! 1. **Enums** describe the vocabulary: [`StorageType`] (data shape),
//!    [`StorageScope`] (where data lives), [`ConnectionSide`] (F5 proxy
//!    context), [`SideEffectTarget`] (external resource affected), and
//!    [`EffectRegion`] (coarse bitflags for GVN / interprocedural kill
//!    checks).
//! 2. **Dataclasses** ([`SideEffect`], [`CommandSideEffects`]) compose
//!    those into per-invocation facts.
//! 3. **Classification functions** resolve registry metadata +
//!    runtime arguments into a [`CommandSideEffects`].
//!
//! Consumers include the optimiser (kill safety, CSE), the iRules
//! flow checker (response-commit tracking), the taint engine, and
//! later data-flow analyses that need to know *what* a command
//! touches rather than just *whether* it is pure.
//!
//! The registry's lightweight `tcl_registry::SideEffect` /
//! `SideEffectTarget` / `StorageType` / `ConnectionSide` types stay
//! unchanged — they are what the command metadata carries; this
//! module holds the richer inferred-by-analysis types.

use bitflags::bitflags;

use tcl_registry::prelude::StorageType as RegistryStorageType;
use tcl_registry::side_effects::{
    ConnectionSide as RegistryConnectionSide, SideEffect as RegistrySideEffect,
    SideEffectTarget as RegistryTarget,
};
use tcl_registry::{CommandRegistry, Traits};

// StorageType — data shape of a target

/// Data shape of the target being read or written.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum StorageType {
    /// Simple string/integer value (Tcl default representation).
    Scalar,
    /// Tcl list value.
    List,
    /// Tcl dict value (key-value pairs).
    Dict,
    /// Tcl array (associative array of variables, not a value type).
    Array,
    /// Shape cannot be determined statically.
    Unknown,
}

// StorageScope — where data resides

/// Where the data resides at runtime.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum StorageScope {
    // Tcl-universal scopes
    /// Local variable inside the current procedure.
    ProcLocal,
    /// Variable in a named Tcl namespace (`namespace eval`).
    Namespace,
    /// Global namespace variable (`::var` or via `global`).
    Global,
    /// Aliased from a caller's frame via `upvar` / `uplevel`.
    Upvar,

    // F5 iRules-specific scopes
    /// iRules event-scoped state (stable within one `when` handler).
    Event,
    /// iRules connection-scoped state (lives for the connection lifetime).
    Connection,
    /// iRules root static namespace cell, persistent within one TMM worker.
    Static,
    /// F5 session table (`table` command). Keyed, with lifetime/timeout.
    SessionTable,
    /// F5 persistence table (`session` / `persist` commands).
    Persistence,
    /// F5 data group / class (read-only at runtime, `class` command).
    DataGroup,

    // External I/O scopes
    /// File on disk (`open` / `puts` / `read` / `close`).
    FileSystem,
    /// Network socket or connection (`socket` / `connect` / `send`).
    NetworkSocket,
    /// Logging destination (`log` / `puts stderr`).
    LogOutput,

    /// Scope cannot be determined statically.
    Unknown,
}

// ConnectionSide — F5 proxy context

/// F5 proxy connection context in which a side effect occurs.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum ConnectionSide {
    /// Client-side of the proxy (between client and BIG-IP).
    Client,
    /// Server-side of the proxy (between BIG-IP and pool member).
    Server,
    /// Both sides / the proxy itself (e.g. `table`, connection-wide).
    Both,
    /// No connection context (e.g. `RULE_INIT`, `static::` variables).
    Global,
    /// Not applicable (pure Tcl command, no F5 proxy context).
    None,
}

// SideEffectTarget — what category of external resource is touched

/// The category of external resource that a command touches.
///
/// This is the *what*, not the *where* — combine with [`StorageScope`]
/// and [`ConnectionSide`] for the full picture.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum SideEffectTarget {
    // Variable mutation
    /// Tcl variable read or write (`set`, `incr`, `append`, …).
    Variable,

    // F5 iRules data stores
    /// Session table entry (`table set/add/lookup/delete`).
    SessionTable,
    /// Persistence record (`session add/lookup`, `persist`).
    PersistenceTable,
    /// Data group / class lookup (`class match/search/lookup`).
    DataGroup,

    // HTTP state
    /// HTTP header read/write (`HTTP::header`).
    HttpHeader,
    /// HTTP payload/body (`HTTP::payload`, `HTTP::collect`).
    HttpBody,
    /// HTTP status code (`HTTP::status`).
    HttpStatus,
    /// HTTP URI components (`HTTP::uri`, `HTTP::path`, `HTTP::query`).
    HttpUri,
    /// HTTP cookie (`HTTP::cookie`).
    HttpCookie,
    /// HTTP method (`HTTP::method`).
    HttpMethod,
    /// HTTP/2 protocol state.
    Http2State,

    // Response lifecycle
    /// Commits or sends an HTTP response (`HTTP::respond`, `redirect`).
    ResponseCommit,
    /// Connection-level action: drop, reject, discard, forward.
    ConnectionControl,

    // Transport / TLS
    /// TCP connection state (`TCP::close`, `TCP::collect`, …).
    TcpState,
    /// SSL/TLS state (`SSL::disable`, `SSL::cert`, …).
    SslState,
    /// UDP datagram state.
    UdpState,

    // Load balancing
    /// Pool or pool member selection (`pool`, `LB::select`).
    PoolSelection,
    /// Direct node selection (`node`).
    NodeSelection,
    /// SNAT address selection (`snat`, `snatpool`).
    SnatSelection,

    // External I/O
    /// File system read/write (`open`, `puts`, `read`, `close`).
    FileIo,
    /// Network socket I/O (`socket`, `connect`, `send`).
    NetworkIo,
    /// Logging output (`log local0.`, `puts stderr`).
    LogIo,

    /// Content rewriting via stream profile (`STREAM::`, `REWRITE::`).
    StreamProfile,

    // DNS
    /// DNS message state (`DNS::header`, `DNS::answer`, …).
    DnsState,

    // Classification / DoS
    /// Traffic classification state (`CLASSIFY::`, `CLASSIFICATION::`).
    ClassificationState,
    /// Layer-7 denial-of-service protection state (`DOSL7::`).
    Dosl7State,

    // Flow / connection management
    /// Flow object state (`FLOW::create_related`, `FLOW::idle_timeout`, …).
    FlowState,
    /// Large Scale NAT state (`LSN::address`, `LSN::persistence`, …).
    LsnState,
    /// Event-handler flow control: abandons the remaining script in the
    /// current event invocation, without touching the connection, other
    /// events, or other rules (iRules `return` inside a `when` body).
    /// Distinct from [`Self::ConnectionControl`], which terminates the
    /// connection rather than just the current handler.
    EventControl,

    // Application protocols
    /// FTP protocol state (`FTP::enable`, `FTP::port`, …).
    FtpState,
    /// ICAP protocol state (`ICAP::header`, `ICAP::method`, …).
    IcapState,
    /// Message routing state (`MESSAGE::field`, `MR::message`, …).
    MessageState,

    // Statistics
    /// Internal statistics counters (`ISTATS::set`, `ISTATS::incr`, …).
    IStats,

    // F5 security / policy
    /// Access Policy Manager state (`ACCESS::session`, `ACCESS::policy`, …).
    ApmState,
    /// Application Security Manager state (`ASM::enable`, `ASM::disable`, …).
    AsmState,

    // F5 configuration (iApps)
    /// BIG-IP configuration change (iApps, `tmsh::` commands).
    BigipConfig,

    // Interpreter state
    /// Defines or removes a procedure (`proc`, `rename`).
    ProcDefinition,
    /// Namespace creation / deletion (`namespace eval`, `namespace delete`).
    NamespaceState,
    /// Interpreter-level state (`interp`, `package`, `load`).
    InterpState,

    /// Target cannot be determined statically.
    Unknown,
}

// EffectRegion — coarse bitflags for GVN / interprocedural kill checks

bitflags! {
    /// Abstract mutable regions used for effect invalidation.
    ///
    /// Coarse view consumed by GVN and interprocedural analysis. The
    /// structured [`SideEffectTarget`] model is authoritative; this
    /// enum exists purely for fast bitwise kill checks.
    #[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
    pub struct EffectRegion: u32 {
        /// No region.
        const NONE               = 0;
        /// Any HTTP state (header, body, status, URI, cookie, method, HTTP/2).
        const HTTP_STATE         = 1 << 0;
        /// Response lifecycle (commit / redirect / respond).
        const RESPONSE_LIFECYCLE = 1 << 1;
        /// Global or namespace-scoped variable state.
        const GLOBAL_STATE       = 1 << 2;
        /// Catch-all for unknown effects.
        const UNKNOWN_STATE      = 1 << 3;
    }
}

/// Map a structured target to a coarse [`EffectRegion`].
#[must_use]
pub fn target_to_region(target: SideEffectTarget, scope: StorageScope) -> EffectRegion {
    match target {
        SideEffectTarget::HttpHeader
        | SideEffectTarget::HttpBody
        | SideEffectTarget::HttpStatus
        | SideEffectTarget::HttpUri
        | SideEffectTarget::HttpCookie
        | SideEffectTarget::HttpMethod
        | SideEffectTarget::Http2State => EffectRegion::HTTP_STATE,
        SideEffectTarget::ResponseCommit => {
            EffectRegion::RESPONSE_LIFECYCLE | EffectRegion::HTTP_STATE
        }
        SideEffectTarget::Variable => match scope {
            StorageScope::Global | StorageScope::Namespace | StorageScope::Static => {
                EffectRegion::GLOBAL_STATE
            }
            StorageScope::ProcLocal | StorageScope::Event | StorageScope::Connection => {
                EffectRegion::NONE
            }
            _ => EffectRegion::UNKNOWN_STATE,
        },
        // External I/O does not mutate compiler-tracked in-memory state.
        SideEffectTarget::FileIo | SideEffectTarget::NetworkIo | SideEffectTarget::LogIo => {
            EffectRegion::NONE
        }
        _ => EffectRegion::UNKNOWN_STATE,
    }
}

// Scope / storage-type inference helpers

/// A compatibility query for Tcl names in a root procedure context.
///
/// Host storage policy is applied only by the contextual classifier. A name
/// `static::x` is an ordinary Tcl namespace reference in this query.
#[must_use]
pub fn scope_from_varname(name: &str) -> (StorageScope, Option<String>) {
    if crate::naming::is_qualified(name.as_bytes()) {
        let rooted = crate::naming::qualify("::", name);
        let (namespace, _) = crate::naming::key_holder_and_tail(&rooted);
        let scope = if namespace == "::" {
            StorageScope::Global
        } else {
            StorageScope::Namespace
        };
        (scope, Some(namespace.to_owned()))
    } else {
        (StorageScope::ProcLocal, None)
    }
}

fn variable_effect_context<'a>(
    context: &'a crate::var_resolve::ResolveContext,
    dialect: Option<&'static tcl_dialect::DialectProfile>,
) -> std::borrow::Cow<'a, crate::var_resolve::ResolveContext> {
    // An explicit metadata profile supplies lookup policy only when the
    // retained point has not already selected its execution dialect.
    if context.invocation_dialect.is_none()
        && let Some(profile) = dialect
    {
        let mut supplied = context.clone();
        supplied.invocation_dialect = Some(tcl_registry::InvocationDialect::of_profile(profile));
        std::borrow::Cow::Owned(supplied)
    } else {
        std::borrow::Cow::Borrowed(context)
    }
}

fn resolved_variable_scope(
    name: &str,
    registry: &CommandRegistry,
    dialect: Option<&'static tcl_dialect::DialectProfile>,
    context: &crate::var_resolve::ResolveContext,
) -> (StorageScope, Option<String>, String) {
    let context = variable_effect_context(context, dialect);
    let context = context.as_ref();
    let Some((place, canonical)) = crate::var_resolve::canonical_namespace_variable_place(
        name, context, registry,
    )
    .and_then(|place| crate::var_resolve::canonical_place_key(&place).map(|key| (place, key))) else {
        let place = crate::var_resolve::resolve_place(name, context, false, registry);
        let scope = if place.dynamic {
            StorageScope::Unknown
        } else if place.ns == crate::place::LOCAL_NS {
            StorageScope::ProcLocal
        } else {
            StorageScope::Unknown
        };
        return (scope, None, name.to_owned());
    };
    let (scope, namespace) = canonical_namespace_storage_scope(&place, &canonical, dialect);
    (scope, namespace, canonical.compatibility_name())
}

/// Classify a resolved namespace place; display supplies neither cell nor worker ownership.
#[must_use]
pub(crate) fn namespace_storage_scope_for_place(
    place: &crate::place::Place,
    dialect: Option<&'static tcl_dialect::DialectProfile>,
) -> StorageScope {
    let Some(canonical) = crate::var_resolve::canonical_place_key(place) else {
        return StorageScope::Unknown;
    };
    canonical_namespace_storage_scope(place, &canonical, dialect).0
}

fn canonical_namespace_storage_scope(
    place: &crate::place::Place,
    canonical: &crate::var_resolve::VariableCellKey,
    dialect: Option<&'static tcl_dialect::DialectProfile>,
) -> (StorageScope, Option<String>) {
    let namespace = if let Some(identity) = canonical.namespace_identity() {
        let root = identity
            .exact_native_path()
            .is_some_and(tcl_core_types::ByteNamespacePath::is_root);
        let worker = place.cell.as_ref().is_some_and(|cell| {
            cell.storage_domain == Some(tcl_registry::f5::VariableStorageDomain::WorkerNamespace)
        });
        Some((root, identity.display(), worker))
    } else {
        match canonical.root() {
            crate::var_resolve::VariableCellKey::Authored(_) => {
                match place.cell.as_ref().map(|cell| &cell.owner) {
                    Some(crate::place::CellOwner::Namespace(namespace)) => {
                        // This authored classification supplies no native TMM owner.
                        let worker = crate::taint::is_irules_dialect(dialect)
                            && tcl_registry::f5::namespace_storage_domain(
                                tcl_registry::f5::BigIpExecutionContext::TmmIRule,
                                namespace,
                            ) == tcl_registry::f5::VariableStorageDomain::WorkerNamespace;
                        Some((namespace == "::", Some(namespace.clone()), worker))
                    }
                    None => {
                        // A resolved legacy symbolic place has no native cell.
                        let namespace = &place.ns;
                        let worker = crate::taint::is_irules_dialect(dialect)
                            && tcl_registry::f5::namespace_storage_domain(
                                tcl_registry::f5::BigIpExecutionContext::TmmIRule,
                                namespace,
                            ) == tcl_registry::f5::VariableStorageDomain::WorkerNamespace;
                        Some((namespace == "::", Some(namespace.clone()), worker))
                    }
                    _ => None,
                }
            }
            _ => None,
        }
    };
    let Some((root, namespace, worker)) = namespace else {
        return (StorageScope::Unknown, None);
    };
    let scope = if worker {
        StorageScope::Static
    } else if root {
        StorageScope::Global
    } else {
        StorageScope::Namespace
    };
    (scope, namespace)
}

/// Lift a registry `StorageType` value into the richer
/// compiler-side [`StorageType`].
fn lift_registry_storage_type(rt: RegistryStorageType) -> StorageType {
    match rt {
        RegistryStorageType::Dict => StorageType::Dict,
        RegistryStorageType::List => StorageType::List,
        RegistryStorageType::Array => StorageType::Array,
    }
}

/// Infer the storage type for a command invocation by querying the
/// registry's `inferred_storage_type` metadata. Falls back to
/// [`StorageType::Scalar`] for commands without a declared shape, so
/// `set`, `incr`, `append`, and similar scalar commands default to
/// the scalar shape.
///
/// `args` is accepted for API symmetry but currently ignored;
/// argument-dependent shape inference is not implemented.
#[must_use]
pub fn storage_type_for_command(
    registry: &CommandRegistry,
    command: &str,
    _args: &[String],
) -> StorageType {
    if let Some(spec) = registry.get(command)
        && let Some(rt) = spec.inferred_storage_type
    {
        return lift_registry_storage_type(rt);
    }
    StorageType::Scalar
}

// SideEffect, CommandSideEffects

/// One discrete read or write produced by a command invocation.
///
/// A single command may produce multiple [`SideEffect`] instances.
/// For example, `HTTP::header replace Host "example.com"` produces
/// both a read (current header state) and a write (new header
/// value).
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct SideEffect {
    /// What category of resource is touched.
    pub target: SideEffectTarget,
    /// Whether this effect includes a read from the target.
    pub reads: bool,
    /// Whether this effect includes a write to the target.
    pub writes: bool,
    /// Data shape of the target (scalar, list, dict, array).
    pub storage_type: StorageType,
    /// Where the data resides (proc-local, global, F5 table, …).
    pub scope: StorageScope,
    /// F5 proxy context for this effect.
    pub connection_side: ConnectionSide,
    /// Tcl namespace or F5 protocol namespace (e.g. `"HTTP"`).
    ///
    /// For Tcl variables this is optional presentation of the retained
    /// namespace path (`"::foo::bar"`), never a namespace identity.
    /// For F5 commands this is the protocol prefix (`"HTTP"`,
    /// `"SSL"`). `None` when not applicable or not determinable.
    pub namespace: Option<String>,
    /// Dialect this effect applies to (`"irules"`, `"tcl"`, …).
    ///
    /// `None` means the effect is dialect-independent.
    pub dialect: Option<String>,
    /// Optional key identifying the specific target.
    ///
    /// For variables: a compatibility label, not a cell-equality proof.
    /// For `table` / `session`:
    /// the key expression (if literal). For HTTP headers: the
    /// header name (if literal). `None` when dynamic or not
    /// applicable.
    pub key: Option<String>,
    /// F5 session-table subtable name, if applicable.
    pub subtable: Option<String>,
}

impl SideEffect {
    /// Build a minimal effect with `target`, `reads`, `writes` set
    /// and all other fields at their defaults. Convenient for
    /// classifier impls to chain with struct-update syntax.
    #[must_use]
    pub fn new(target: SideEffectTarget, reads: bool, writes: bool) -> Self {
        Self {
            target,
            reads,
            writes,
            storage_type: StorageType::Unknown,
            scope: StorageScope::Unknown,
            connection_side: ConnectionSide::None,
            namespace: None,
            dialect: None,
            key: None,
            subtable: None,
        }
    }
}

/// Complete side-effect profile for one command invocation.
///
/// Wraps zero or more individual [`SideEffect`] instances plus
/// summary flags for quick consumer queries. Produced by
/// [`classify_side_effects`].
#[derive(Debug, Clone, PartialEq, Eq, Default)]
pub struct CommandSideEffects {
    /// Individual side effects produced by this invocation.
    pub effects: Vec<SideEffect>,
    /// No observable side effects (reads from immutable state OK).
    pub pure: bool,
    /// Same inputs always produce the same outputs.
    pub deterministic: bool,
    /// Contains `eval`/`uplevel`/`call` — effects are unknowable.
    pub dynamic_barrier: bool,
    /// Dialect context in which this classification was made.
    pub dialect: Option<String>,
}

impl CommandSideEffects {
    /// The canonical pure/deterministic result.
    #[must_use]
    pub fn pure() -> Self {
        Self {
            effects: Vec::new(),
            pure: true,
            deterministic: true,
            dynamic_barrier: false,
            dialect: None,
        }
    }

    /// A conservative "writes something unknown" result. Used when
    /// the classifier cannot determine a precise target.
    #[must_use]
    pub fn unknown_write() -> Self {
        Self {
            effects: vec![SideEffect::new(SideEffectTarget::Unknown, false, true)],
            pure: false,
            deterministic: false,
            dynamic_barrier: false,
            dialect: None,
        }
    }

    /// A dynamic-dispatch barrier (`eval` / `uplevel` / `call`).
    #[must_use]
    pub fn dynamic_barrier() -> Self {
        Self {
            effects: Vec::new(),
            pure: false,
            deterministic: false,
            dynamic_barrier: true,
            dialect: None,
        }
    }

    /// Whether any effect includes a read.
    #[must_use]
    pub fn reads_any(&self) -> bool {
        self.effects.iter().any(|e| e.reads)
    }

    /// Whether any effect includes a write.
    #[must_use]
    pub fn writes_any(&self) -> bool {
        self.effects.iter().any(|e| e.writes)
    }

    /// Whether this invocation touches `target` (read or write).
    #[must_use]
    pub fn affects_target(&self, target: SideEffectTarget) -> bool {
        self.effects.iter().any(|e| e.target == target)
    }

    /// Whether this invocation writes to `target`.
    #[must_use]
    pub fn writes_target(&self, target: SideEffectTarget) -> bool {
        self.effects.iter().any(|e| e.target == target && e.writes)
    }

    /// Whether this invocation reads from `target`.
    #[must_use]
    pub fn reads_target(&self, target: SideEffectTarget) -> bool {
        self.effects.iter().any(|e| e.target == target && e.reads)
    }

    /// Effects restricted to a specific storage scope.
    #[must_use]
    pub fn effects_in_scope(&self, scope: StorageScope) -> Vec<&SideEffect> {
        self.effects.iter().filter(|e| e.scope == scope).collect()
    }

    /// Effects restricted to a specific connection side.
    #[must_use]
    pub fn effects_on_side(&self, side: ConnectionSide) -> Vec<&SideEffect> {
        self.effects
            .iter()
            .filter(|e| e.connection_side == side)
            .collect()
    }

    /// Map structured effects to coarse `(reads, writes)`
    /// [`EffectRegion`] bitflags. Suitable for GVN /
    /// interprocedural kill checks.
    #[must_use]
    pub fn to_effect_regions(&self) -> (EffectRegion, EffectRegion) {
        let mut reads = EffectRegion::NONE;
        let mut writes = EffectRegion::NONE;
        for e in &self.effects {
            let region = target_to_region(e.target, e.scope);
            if e.reads {
                reads |= region;
            }
            if e.writes {
                writes |= region;
            }
        }
        if self.dynamic_barrier {
            writes |= EffectRegion::UNKNOWN_STATE;
        }
        (reads, writes)
    }
}

// Classification

/// Optional summary of a procedure's side effects, provided by
/// interprocedural analysis. When supplied to
/// [`classify_side_effects`], it bypasses registry-based classification
/// and the summary's effect regions are translated directly into
/// [`CommandSideEffects`].
#[derive(Debug, Clone, Copy)]
pub struct CalleeSummary {
    /// Coarse regions read by the callee.
    pub effect_reads: EffectRegion,
    /// Coarse regions written by the callee.
    pub effect_writes: EffectRegion,
    /// Whether the callee is pure overall.
    pub pure: bool,
}

impl Default for CalleeSummary {
    fn default() -> Self {
        Self {
            effect_reads: EffectRegion::NONE,
            effect_writes: EffectRegion::NONE,
            pure: false,
        }
    }
}

/// Classify the side effects of a command invocation.
///
/// Combines registry metadata with argument inspection to produce a
/// structured [`CommandSideEffects`] describing what the command
/// reads and writes, in what scope, and on which connection side.
///
/// When `callee_summary` is `Some`, registry-based classification is
/// skipped and the summary's effect regions are translated directly
/// into effects — see [`classify_from_callee_summary`].
///
/// The registry
/// traits consulted today are `PURE`, `PURE_EVALUATION`,
/// `EVALUATES_CODE`, `CREATES_BARRIER`, `DEFINES_PROCEDURE`, and
/// `DESTROYS_VARIABLE`, plus the spec-level `assigns_variable_at`
/// field, and the spec's structured `side_effects`. A `PURE` command
/// with a mutator subcommand
/// (`HTTP::header insert …`) is downgraded to impure and a still-pure
/// command surfaces its hint read-only. Full arity-based form
/// resolution and the per-subcommand protocol-namespace write modelling
/// are not implemented.
#[must_use]
pub fn classify_side_effects(
    registry: &CommandRegistry,
    command: &str,
    args: &[String],
    dialect: Option<&'static tcl_dialect::DialectProfile>,
    callee_summary: Option<&CalleeSummary>,
) -> CommandSideEffects {
    let mut context = crate::var_resolve::ResolveContext::default();
    if crate::taint::is_irules_dialect(dialect) {
        context.known_namespaces.extend(
            tcl_registry::f5::runtime_namespaces(tcl_registry::f5::BigIpExecutionContext::TmmIRule)
                .iter()
                .map(|namespace| (*namespace).to_owned()),
        );
    }
    classify_side_effects_with_context(registry, command, args, dialect, callee_summary, &context)
}

/// Classify effects using the variable bindings in force at this invocation.
#[must_use]
#[allow(
    clippy::too_many_lines,
    reason = "sequential registry-trait dispatch; splitting hurts readability"
)]
pub fn classify_side_effects_with_context(
    registry: &CommandRegistry,
    command: &str,
    args: &[String],
    dialect: Option<&'static tcl_dialect::DialectProfile>,
    callee_summary: Option<&CalleeSummary>,
    context: &crate::var_resolve::ResolveContext,
) -> CommandSideEffects {
    if let Some(summary) = callee_summary {
        return classify_from_callee_summary(summary, dialect);
    }

    let Some(spec) = registry.get(command) else {
        return fallback_unknown_write(dialect);
    };

    // Dynamic-dispatch commands are barriers.
    if spec
        .traits
        .intersects(Traits::EVALUATES_CODE | Traits::CREATES_BARRIER)
    {
        return CommandSideEffects {
            effects: vec![SideEffect::new(SideEffectTarget::Unknown, true, true)],
            dynamic_barrier: true,
            dialect: dialect.map(|profile| profile.name.to_owned()),
            ..CommandSideEffects::default()
        };
    }

    // Pure evaluation (`expr` when braced) is always pure — checked first
    // and unconditionally, mirroring `is_pure_evaluation` short-
    // circuit (no subcommand / hint handling applies).
    if spec.traits.contains(Traits::PURE_EVALUATION) {
        return CommandSideEffects {
            pure: true,
            deterministic: true,
            dialect: dialect.map(|profile| profile.name.to_owned()),
            ..CommandSideEffects::default()
        };
    }

    // Command-level `PURE` commands. Two refinements on the pure
    // branch:
    //   1. A *mutator* subcommand downgrades purity — e.g. `HTTP::header`
    //      is `PURE` but `HTTP::header insert …` mutates header state, so
    //      it must fall through to the structured-hints classification
    //      below (which yields the read+write effect). Without this a
    //      header mutation reads as pure with no effects.
    //   2. A still-pure command may carry a *read-only* hint — `HTTP::header`
    //      (getter) reads header state. Return the structured hint
    //      with `reads=true, writes=false` by forcing the
    //      spec's hints read-only.
    if spec.traits.contains(Traits::PURE) {
        let effective_sub = args.first().map(String::as_str);
        let sub_is_mutator = effective_sub
            .and_then(|s| spec.resolve_subcommand(s))
            .is_some_and(|sc| sc.mutator);
        if !sub_is_mutator {
            let effects = dialect_side_effect_hints(registry, command, effective_sub, dialect)
                .map(|hints| {
                    hints
                        .into_iter()
                        .map(|mut e| {
                            e.reads = true;
                            e.writes = false;
                            e
                        })
                        .collect::<Vec<_>>()
                })
                .unwrap_or_default();
            return CommandSideEffects {
                effects,
                pure: true,
                deterministic: true,
                dialect: dialect.map(|profile| profile.name.to_owned()),
                ..CommandSideEffects::default()
            };
        }
        // Mutator subcommand → not pure; fall through to the hints block.
    }

    // Subcommand-level purity: ensemble commands (`string`, `dict`, `array`,
    // …) are not pure at the command level but most of their subcommands are
    // (`string length`, `dict get`, `array names`). A command that is not
    // pure inherits purity from a pure subcommand spec, with a `mutator`
    // subcommand overriding back to impure.
    // Without this the side-effect classifier treats every ensemble call as a
    // conservative unknown-write, which (e.g.) hides redundant `string length`
    // computations from GVN.
    if let Some(sub) = args.first().and_then(|a| spec.resolve_subcommand(a))
        && sub.pure
        && !sub.mutator
    {
        return CommandSideEffects {
            pure: true,
            deterministic: true,
            dialect: dialect.map(|profile| profile.name.to_owned()),
            ..CommandSideEffects::default()
        };
    }

    // Variable-assigning commands (`set`, `incr`, `append`, `lappend`, …).
    if let Some(idx) = spec.assigns_variable_at {
        let idx = usize::from(idx);
        if idx < args.len() {
            return classify_variable_assignment(
                registry,
                command,
                args,
                idx,
                spec.traits,
                dialect,
                context,
            );
        }
        return CommandSideEffects {
            effects: vec![SideEffect::new(SideEffectTarget::Variable, true, true)],
            dialect: dialect.map(|profile| profile.name.to_owned()),
            ..CommandSideEffects::default()
        };
    }

    // Procedure definition (`proc`).
    if spec.traits.contains(Traits::DEFINES_PROCEDURE) {
        let mut e = SideEffect::new(SideEffectTarget::ProcDefinition, false, true);
        e.scope = StorageScope::Namespace;
        e.dialect = dialect.map(|profile| profile.name.to_owned());
        return CommandSideEffects {
            effects: vec![e],
            dialect: dialect.map(|profile| profile.name.to_owned()),
            ..CommandSideEffects::default()
        };
    }

    // Destroys a variable (`unset`).
    if spec.traits.contains(Traits::DESTROYS_VARIABLE) {
        // The destroyed variables are exactly the `VarWrite`-role args, resolved
        // through the registry's arg-role resolver — which skips the leading
        // options (`-nocomplain`, `--`) and yields *every* trailing name, not
        // just the first. So `unset -nocomplain x` keys `x` (not `-nocomplain`),
        // and `unset a b` keys both `a` and `b`.
        let arg_refs: Vec<&str> = args.iter().map(String::as_str).collect();
        let targets =
            registry.arg_indices_for_role(command, &arg_refs, tcl_registry::ArgRole::VarWrite);
        let make_effect = |name: Option<&str>| {
            let mut e = SideEffect::new(SideEffectTarget::Variable, false, true);
            if let Some(name) = name {
                let (scope, namespace, key) =
                    resolved_variable_scope(name, registry, dialect, context);
                e.scope = scope;
                e.namespace = namespace;
                e.key = Some(key);
            }
            e.dialect = dialect.map(|profile| profile.name.to_owned());
            e
        };
        // No named target (`unset`, `unset -nocomplain`, `unset --`) is a
        // valid no-op destroy; still emit one untargeted Variable effect so the
        // command stays classified impure rather than pure.
        let effects: Vec<SideEffect> = if targets.is_empty() {
            vec![make_effect(None)]
        } else {
            targets
                .iter()
                .map(|&idx| make_effect(args.get(idx).map(String::as_str)))
                .collect()
        };
        return CommandSideEffects {
            effects,
            dialect: dialect.map(|profile| profile.name.to_owned()),
            ..CommandSideEffects::default()
        };
    }

    // Hints-first: consult the spec's structured `side_effects`
    // (`side_effect_hints`). Dialect-gated, subcommand hints
    // first. e.g. `puts`/`read` declare a `FileIo` write whose coarse
    // region is `NONE` — so a proc that only calls `puts` is impure
    // (`writes_any`) yet has no tracked effect region.
    let effective_sub = args.first().map(String::as_str);
    if let Some(effects) = dialect_side_effect_hints(registry, command, effective_sub, dialect) {
        return CommandSideEffects {
            effects,
            dialect: dialect.map(|profile| profile.name.to_owned()),
            ..CommandSideEffects::default()
        };
    }

    // Fallback: conservative unknown read+write.
    fallback_unknown_write(dialect)
}

/// Classify the side effects of a command invocation against one
/// document's command surface — the catalogue plus the document's own
/// `# tcl-lsp: stub` declarations.
///
/// A name the document declares answers from its declaration (nearest
/// wins): the facts a stub's flags state, read in the order
/// [`classify_side_effects`] reads a catalogue spec's — see
/// [`classify_declared`]. Every other name, and every call with a
/// `callee_summary`, is [`classify_side_effects`] over the catalogue.
#[must_use]
pub fn classify_side_effects_in(
    surface: &tcl_registry::model::DocumentCommandSurface<'_>,
    command: &str,
    args: &[String],
    dialect: Option<&'static tcl_dialect::DialectProfile>,
    callee_summary: Option<&CalleeSummary>,
) -> CommandSideEffects {
    if callee_summary.is_none() && surface.declares(command) {
        return classify_declared(surface, command, dialect);
    }
    classify_side_effects(surface.commands(), command, args, dialect, callee_summary)
}

/// The side effects of a command the document declares, read off the facts
/// its declaration states in the order [`classify_side_effects`] reads a
/// catalogue spec's: an eval-like barrier trait first, then `PURE` (its
/// stated effects surfaced read-only, as a pure catalogue command's hints
/// are), then the stated effects, and the conservative unknown write for a
/// declaration that states none — so a stub with no flags classifies exactly
/// as an undeclared command does.
///
/// The traits and effects come from
/// [`DocumentCommandSurface`](tcl_registry::model::DocumentCommandSurface),
/// so a declaration that redeclares a shipped command keeps that command's
/// security traits and side effects beneath its own (invariant I6).
fn classify_declared(
    surface: &tcl_registry::model::DocumentCommandSurface<'_>,
    command: &str,
    dialect: Option<&'static tcl_dialect::DialectProfile>,
) -> CommandSideEffects {
    let traits = surface.traits(command).unwrap_or_default();
    if traits.intersects(Traits::EVALUATES_CODE | Traits::CREATES_BARRIER) {
        return CommandSideEffects {
            effects: vec![SideEffect::new(SideEffectTarget::Unknown, true, true)],
            dynamic_barrier: true,
            dialect: dialect.map(|profile| profile.name.to_owned()),
            ..CommandSideEffects::default()
        };
    }
    let stated = surface.side_effects(command).unwrap_or_default();
    if traits.contains(Traits::PURE) {
        return CommandSideEffects {
            effects: stated
                .iter()
                .map(|effect| {
                    let mut effect = lift_registry_effect(*effect, dialect);
                    effect.reads = true;
                    effect.writes = false;
                    effect
                })
                .collect(),
            pure: true,
            deterministic: true,
            dialect: dialect.map(|profile| profile.name.to_owned()),
            ..CommandSideEffects::default()
        };
    }
    if stated.is_empty() {
        return fallback_unknown_write(dialect);
    }
    CommandSideEffects {
        effects: stated
            .iter()
            .map(|effect| lift_registry_effect(*effect, dialect))
            .collect(),
        dialect: dialect.map(|profile| profile.name.to_owned()),
        ..CommandSideEffects::default()
    }
}

/// Translate an interprocedural [`CalleeSummary`] into a
/// [`CommandSideEffects`].
fn classify_from_callee_summary(
    summary: &CalleeSummary,
    dialect: Option<&'static tcl_dialect::DialectProfile>,
) -> CommandSideEffects {
    let reads = summary.effect_reads;
    let writes = summary.effect_writes;
    let commits = writes.contains(EffectRegion::RESPONSE_LIFECYCLE);
    let mut effects = Vec::new();

    if reads.contains(EffectRegion::HTTP_STATE) || writes.contains(EffectRegion::HTTP_STATE) {
        effects.push(SideEffect::new(
            SideEffectTarget::HttpHeader,
            reads.contains(EffectRegion::HTTP_STATE),
            writes.contains(EffectRegion::HTTP_STATE),
        ));
    }
    if commits {
        effects.push(SideEffect::new(
            SideEffectTarget::ResponseCommit,
            false,
            true,
        ));
    }
    if writes.contains(EffectRegion::GLOBAL_STATE) {
        let mut e = SideEffect::new(SideEffectTarget::Variable, false, true);
        e.scope = StorageScope::Global;
        effects.push(e);
    }
    if writes.contains(EffectRegion::UNKNOWN_STATE) {
        effects.push(SideEffect::new(SideEffectTarget::Unknown, true, true));
    }
    if effects.is_empty() && !summary.pure {
        effects.push(SideEffect::new(SideEffectTarget::Unknown, true, true));
    }

    CommandSideEffects {
        effects,
        pure: summary.pure,
        deterministic: summary.pure,
        dynamic_barrier: false,
        dialect: dialect.map(|profile| profile.name.to_owned()),
    }
}

/// Build a `SideEffect` for a command that assigns a variable at
/// position `idx`. Applies these heuristics:
///
/// - Read-before-write commands (`incr`, `append`, `lappend`) always
///   read and write.
/// - `set x` (single var, no value) is a read; `set x v` is a write.
/// - iRules context: `static::` targets use `ConnectionSide::Global`;
///   proc-local targets use `ConnectionSide::Both`.
fn classify_variable_assignment(
    registry: &CommandRegistry,
    command: &str,
    args: &[String],
    idx: usize,
    traits: Traits,
    dialect: Option<&'static tcl_dialect::DialectProfile>,
    context: &crate::var_resolve::ResolveContext,
) -> CommandSideEffects {
    let context = variable_effect_context(context, dialect);
    let context = context.as_ref();
    let varname = &args[idx];
    let (scope, ns, key) = resolved_variable_scope(varname, registry, dialect, context);
    let st = storage_type_for_command(registry, command, args);
    let rmw = traits.contains(Traits::READS_BEFORE_WRITE);

    // When there is only the variable name and no value, it's a read
    // (`set x`); otherwise it's a write. Read-modify-write commands
    // always write even with one arg.
    let is_write = args.len() > idx + 1 || rmw;
    let is_read = rmw || args.len() == idx + 1;

    let is_irules = crate::taint::is_irules_dialect(dialect);
    let side = if is_irules {
        match scope {
            StorageScope::Static => ConnectionSide::Global,
            StorageScope::ProcLocal => ConnectionSide::Both,
            _ => ConnectionSide::None,
        }
    } else {
        ConnectionSide::None
    };

    let mut effect = SideEffect::new(SideEffectTarget::Variable, is_read, is_write);
    effect.storage_type = st;
    effect.scope = scope;
    effect.connection_side = side;
    effect.namespace = ns;
    effect.dialect = dialect.map(|profile| profile.name.to_owned());
    effect.key = Some(key);

    let mut effects = vec![effect];

    // Only the resolved root namespace cell can carry the registry's extra
    // interpreter effect. A source alias retains that owner; a same-named
    // procedure local or named namespace cell does not.
    if is_write {
        let place = crate::var_resolve::resolve_place(varname, context, false, registry);
        if let Some(target) = crate::var_resolve::root_namespace_variable_simple_name(&place)
            .and_then(|simple| {
                tcl_registry::special_vars::special_var_write_effect(
                    simple,
                    Some(tcl_registry::special_vars::surface_query_for_profile(
                        dialect,
                    )),
                )
            })
        {
            let mut extra = SideEffect::new(lift_registry_target(target), false, true);
            extra.dialect = dialect.map(|profile| profile.name.to_owned());
            effects.push(extra);
        }
    }

    CommandSideEffects {
        effects,
        dialect: dialect.map(|profile| profile.name.to_owned()),
        ..CommandSideEffects::default()
    }
}

/// Translate a registry [`RegistryTarget`] into the richer
/// compiler-side [`SideEffectTarget`]. The two enums share variant
/// names 1:1 except for the registry-only `Process` / `ChannelIo`
/// targets: `Process` collapses to
/// [`SideEffectTarget::Unknown`] (its coarse region is
/// `UNKNOWN_STATE`, matching `exec` fallback) and `ChannelIo`
/// maps to [`SideEffectTarget::FileIo`] (channel I/O is file-shaped,
/// region `NONE`).
// Each variant is mapped explicitly (1:1 by name, plus the two
// registry-only fall-throughs) so the correspondence is auditable and
// new registry targets fail to compile until mapped. Arms that share a
// body are grouped with `|`.
fn lift_registry_target(t: RegistryTarget) -> SideEffectTarget {
    use RegistryTarget as R;
    match t {
        R::Variable => SideEffectTarget::Variable,
        R::SessionTable => SideEffectTarget::SessionTable,
        R::PersistenceTable => SideEffectTarget::PersistenceTable,
        R::DataGroup => SideEffectTarget::DataGroup,
        R::HttpHeader => SideEffectTarget::HttpHeader,
        R::HttpBody => SideEffectTarget::HttpBody,
        R::HttpStatus => SideEffectTarget::HttpStatus,
        R::HttpUri => SideEffectTarget::HttpUri,
        R::HttpCookie => SideEffectTarget::HttpCookie,
        R::HttpMethod => SideEffectTarget::HttpMethod,
        R::Http2State => SideEffectTarget::Http2State,
        R::ResponseCommit => SideEffectTarget::ResponseCommit,
        R::ConnectionControl => SideEffectTarget::ConnectionControl,
        R::TcpState => SideEffectTarget::TcpState,
        R::SslState => SideEffectTarget::SslState,
        R::UdpState => SideEffectTarget::UdpState,
        R::PoolSelection => SideEffectTarget::PoolSelection,
        R::NodeSelection => SideEffectTarget::NodeSelection,
        R::SnatSelection => SideEffectTarget::SnatSelection,
        // `ChannelIo` is file-shaped, so it lifts to `FileIo` like `FileIo`.
        R::FileIo | R::ChannelIo => SideEffectTarget::FileIo,
        R::NetworkIo => SideEffectTarget::NetworkIo,
        R::LogIo => SideEffectTarget::LogIo,
        R::StreamProfile => SideEffectTarget::StreamProfile,
        R::DnsState => SideEffectTarget::DnsState,
        R::ClassificationState => SideEffectTarget::ClassificationState,
        R::Dosl7State => SideEffectTarget::Dosl7State,
        R::FlowState => SideEffectTarget::FlowState,
        R::LsnState => SideEffectTarget::LsnState,
        R::FtpState => SideEffectTarget::FtpState,
        R::IcapState => SideEffectTarget::IcapState,
        R::MessageState => SideEffectTarget::MessageState,
        R::IStats => SideEffectTarget::IStats,
        R::ApmState => SideEffectTarget::ApmState,
        R::AsmState => SideEffectTarget::AsmState,
        R::BigipConfig => SideEffectTarget::BigipConfig,
        R::ProcDefinition => SideEffectTarget::ProcDefinition,
        R::NamespaceState => SideEffectTarget::NamespaceState,
        R::InterpState => SideEffectTarget::InterpState,
        R::EventControl => SideEffectTarget::EventControl,
        // Registry-only targets with no compiler counterpart.
        R::Process | R::Unknown => SideEffectTarget::Unknown,
    }
}

/// Translate a registry [`RegistryConnectionSide`] into the compiler's
/// [`ConnectionSide`] (1:1).
fn lift_registry_side(s: RegistryConnectionSide) -> ConnectionSide {
    match s {
        RegistryConnectionSide::None => ConnectionSide::None,
        RegistryConnectionSide::Client => ConnectionSide::Client,
        RegistryConnectionSide::Server => ConnectionSide::Server,
        RegistryConnectionSide::Both => ConnectionSide::Both,
        RegistryConnectionSide::Global => ConnectionSide::Global,
    }
}

/// Lift one registry [`RegistrySideEffect`] hint into a compiler
/// [`SideEffect`], stamping the active `dialect` onto it when a dialect
/// is supplied. The registry hint carries only
/// `target`/`reads`/`writes`/`connection_side`; the remaining fields
/// stay at their defaults.
fn lift_registry_effect(
    e: RegistrySideEffect,
    dialect: Option<&'static tcl_dialect::DialectProfile>,
) -> SideEffect {
    let mut effect = SideEffect::new(lift_registry_target(e.target), e.reads, e.writes);
    effect.connection_side = lift_registry_side(e.connection_side);
    effect.dialect = dialect.map(|profile| profile.name.to_owned());
    effect
}

/// Coarse regions of already selected normal-handler effects. This May
/// projection establishes neither successful entry nor purity and does not
/// replace the invocation's unknown or callback obligations.
pub(crate) fn normal_handler_effect_regions(
    footprint: &tcl_registry::world_effect::EffectFootprint,
) -> (EffectRegion, EffectRegion) {
    let mut reads = EffectRegion::NONE;
    let mut writes = EffectRegion::NONE;
    for effect in &footprint.legacy().side_effects {
        let region = target_to_region(lift_registry_target(effect.target), StorageScope::Unknown);
        if effect.reads {
            reads |= region;
        }
        if effect.writes {
            writes |= region;
        }
    }
    (reads, writes)
}

/// Resolve the dialect-gated structured side-effect hints for a
/// command invocation, through the registry model's one hint-selection
/// primitive (centralisation C7 —
/// [`tcl_registry::model::side_effect_hints_in_context`]): specs
/// newest-first, filtered by the resolved context's availability,
/// subcommand-level hints before command-level ones. `None` when no
/// qualifying spec declares any hint (so the caller falls back to the
/// conservative UNKNOWN write). A `None` dialect selects with no
/// availability filter, as before.
fn dialect_side_effect_hints(
    registry: &CommandRegistry,
    command: &str,
    subcommand: Option<&str>,
    dialect: Option<&'static tcl_dialect::DialectProfile>,
) -> Option<Vec<SideEffect>> {
    let generation = dialect.map(crate::environment_ingress::context_for_profile);
    let hints = tcl_registry::model::side_effect_hints_in_context(
        registry,
        generation
            .as_deref()
            .map(tcl_registry::model::ContextRegistry::context),
        command,
        subcommand,
    )?;
    Some(
        hints
            .iter()
            .map(|e| lift_registry_effect(*e, dialect))
            .collect(),
    )
}

fn fallback_unknown_write(
    dialect: Option<&'static tcl_dialect::DialectProfile>,
) -> CommandSideEffects {
    CommandSideEffects {
        effects: vec![SideEffect::new(SideEffectTarget::Unknown, true, true)],
        dialect: dialect.map(|profile| profile.name.to_owned()),
        ..CommandSideEffects::default()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use tcl_dialect::model::{Family, SurfaceLayer};

    #[test]
    fn http_targets_map_to_http_state_region() {
        for target in [
            SideEffectTarget::HttpHeader,
            SideEffectTarget::HttpBody,
            SideEffectTarget::HttpStatus,
            SideEffectTarget::HttpUri,
            SideEffectTarget::HttpCookie,
            SideEffectTarget::HttpMethod,
            SideEffectTarget::Http2State,
        ] {
            assert_eq!(
                target_to_region(target, StorageScope::Unknown),
                EffectRegion::HTTP_STATE,
                "{target:?}"
            );
        }
    }

    #[test]
    fn response_commit_is_both_response_and_http_state() {
        let r = target_to_region(SideEffectTarget::ResponseCommit, StorageScope::Unknown);
        assert!(r.contains(EffectRegion::RESPONSE_LIFECYCLE));
        assert!(r.contains(EffectRegion::HTTP_STATE));
    }

    #[test]
    fn variable_scope_distinguishes_global_vs_local() {
        assert_eq!(
            target_to_region(SideEffectTarget::Variable, StorageScope::Global),
            EffectRegion::GLOBAL_STATE
        );
        assert_eq!(
            target_to_region(SideEffectTarget::Variable, StorageScope::Namespace),
            EffectRegion::GLOBAL_STATE
        );
        assert_eq!(
            target_to_region(SideEffectTarget::Variable, StorageScope::ProcLocal),
            EffectRegion::NONE
        );
    }

    #[test]
    fn external_io_is_not_compiler_tracked() {
        assert_eq!(
            target_to_region(SideEffectTarget::FileIo, StorageScope::FileSystem),
            EffectRegion::NONE
        );
        assert_eq!(
            target_to_region(SideEffectTarget::NetworkIo, StorageScope::NetworkSocket),
            EffectRegion::NONE
        );
        assert_eq!(
            target_to_region(SideEffectTarget::LogIo, StorageScope::LogOutput),
            EffectRegion::NONE
        );
    }

    #[test]
    fn unknown_targets_fall_through() {
        assert_eq!(
            target_to_region(SideEffectTarget::Unknown, StorageScope::Unknown),
            EffectRegion::UNKNOWN_STATE
        );
        assert_eq!(
            target_to_region(SideEffectTarget::SessionTable, StorageScope::Unknown),
            EffectRegion::UNKNOWN_STATE
        );
    }

    #[test]
    fn effect_region_supports_bitwise_combine() {
        let combined = EffectRegion::HTTP_STATE | EffectRegion::GLOBAL_STATE;
        assert!(combined.contains(EffectRegion::HTTP_STATE));
        assert!(combined.contains(EffectRegion::GLOBAL_STATE));
        assert!(!combined.contains(EffectRegion::UNKNOWN_STATE));
    }

    #[test]
    fn http_uri_family_reads_http_state_region() {
        // `HTTP::uri` / `HTTP::path` / `HTTP::query` getters carry a
        // read-only `HttpUri` side effect, so they classify into the
        // `HTTP_STATE` *read* region. Without `side_effects` on their specs,
        // callgraph/dataflow reports `NONE` instead of
        // `HTTP_STATE`.
        let mut reg = tcl_registry::CommandRegistry::build_default();
        reg.load_surface(SurfaceLayer::Core(Family::F5Irules, ""));
        for cmd in ["HTTP::uri", "HTTP::path", "HTTP::query"] {
            let ci = classify_side_effects(&reg, cmd, &[], None, None);
            let (reads, writes) = ci.to_effect_regions();
            assert!(
                reads.contains(EffectRegion::HTTP_STATE),
                "{cmd}: reads should include HTTP_STATE, got {reads:?}"
            );
            assert!(
                !writes.contains(EffectRegion::HTTP_STATE),
                "{cmd}: getter form must not write HTTP_STATE, got {writes:?}"
            );
        }
    }

    // SideEffect / CommandSideEffects.

    #[test]
    fn side_effect_new_defaults() {
        let e = SideEffect::new(SideEffectTarget::Variable, true, false);
        assert_eq!(e.target, SideEffectTarget::Variable);
        assert!(e.reads);
        assert!(!e.writes);
        assert_eq!(e.storage_type, StorageType::Unknown);
        assert_eq!(e.scope, StorageScope::Unknown);
        assert_eq!(e.connection_side, ConnectionSide::None);
        assert!(e.namespace.is_none());
        assert!(e.dialect.is_none());
        assert!(e.key.is_none());
        assert!(e.subtable.is_none());
    }

    #[test]
    fn command_side_effects_pure_constant() {
        let cse = CommandSideEffects::pure();
        assert!(cse.pure);
        assert!(cse.deterministic);
        assert_eq!(cse.effects, [] as [crate::side_effects::SideEffect; 0]);
        assert!(!cse.dynamic_barrier);
        assert!(!cse.reads_any());
        assert!(!cse.writes_any());
    }

    #[test]
    fn command_side_effects_unknown_write_constant() {
        let cse = CommandSideEffects::unknown_write();
        assert!(!cse.pure);
        assert_eq!(cse.effects.len(), 1);
        assert_eq!(cse.effects[0].target, SideEffectTarget::Unknown);
        assert!(cse.effects[0].writes);
        assert!(cse.writes_any());
    }

    #[test]
    fn command_side_effects_dynamic_barrier_flag() {
        let cse = CommandSideEffects::dynamic_barrier();
        assert!(cse.dynamic_barrier);
        let (_, w) = cse.to_effect_regions();
        assert!(w.contains(EffectRegion::UNKNOWN_STATE));
    }

    #[test]
    fn affects_reads_writes_target_helpers() {
        let cse = CommandSideEffects {
            effects: vec![
                SideEffect::new(SideEffectTarget::HttpHeader, true, false),
                SideEffect::new(SideEffectTarget::Variable, false, true),
            ],
            ..CommandSideEffects::default()
        };
        assert!(cse.affects_target(SideEffectTarget::HttpHeader));
        assert!(cse.affects_target(SideEffectTarget::Variable));
        assert!(!cse.affects_target(SideEffectTarget::FileIo));
        assert!(cse.reads_target(SideEffectTarget::HttpHeader));
        assert!(!cse.reads_target(SideEffectTarget::Variable));
        assert!(cse.writes_target(SideEffectTarget::Variable));
    }

    #[test]
    fn to_effect_regions_unions_reads_and_writes() {
        let mut global_var = SideEffect::new(SideEffectTarget::Variable, false, true);
        global_var.scope = StorageScope::Global;
        let cse = CommandSideEffects {
            effects: vec![
                SideEffect::new(SideEffectTarget::HttpHeader, true, false),
                global_var,
            ],
            ..CommandSideEffects::default()
        };
        let (r, w) = cse.to_effect_regions();
        assert!(r.contains(EffectRegion::HTTP_STATE));
        assert!(w.contains(EffectRegion::GLOBAL_STATE));
        assert!(!w.contains(EffectRegion::HTTP_STATE));
    }

    // Scope + storage-type inference.

    #[test]
    fn scope_proc_local_for_bare_names() {
        let (s, ns) = scope_from_varname("x");
        assert_eq!(s, StorageScope::ProcLocal);
        assert!(ns.is_none());
    }

    #[test]
    fn static_spelling_is_an_ordinary_tcl_namespace() {
        let (s, ns) = scope_from_varname("static::counter");
        assert_eq!(s, StorageScope::Namespace);
        assert_eq!(ns.as_deref(), Some("::static"));
    }

    #[test]
    fn scope_global_for_root_qualified() {
        let (s, ns) = scope_from_varname("::var");
        assert_eq!(s, StorageScope::Global);
        assert_eq!(ns.as_deref(), Some("::"));
    }

    #[test]
    fn scope_namespace_for_qualified_with_segments() {
        let (s, ns) = scope_from_varname("::foo::bar::var");
        assert_eq!(s, StorageScope::Namespace);
        assert_eq!(ns.as_deref(), Some("::foo::bar"));
    }

    #[test]
    fn scope_namespace_single_segment() {
        let (s, ns) = scope_from_varname("::foo::var");
        assert_eq!(s, StorageScope::Namespace);
        assert_eq!(ns.as_deref(), Some("::foo"));
    }

    #[test]
    fn storage_type_default_scalar_for_unknown_command() {
        let registry = CommandRegistry::build_default();
        let args = vec![];
        assert_eq!(
            storage_type_for_command(&registry, "nonexistentcmd", &args),
            StorageType::Scalar
        );
    }

    #[test]
    fn storage_type_registry_backed_list_dict_array() {
        let registry = CommandRegistry::build_default();
        let args = vec![];
        // lappend / dict / array are declared with inferred storage
        // types in the registry and should be mapped through.
        assert_eq!(
            storage_type_for_command(&registry, "lappend", &args),
            StorageType::List
        );
        assert_eq!(
            storage_type_for_command(&registry, "dict", &args),
            StorageType::Dict
        );
        assert_eq!(
            storage_type_for_command(&registry, "array", &args),
            StorageType::Array
        );
    }

    // classify_side_effects.

    #[test]
    fn classify_pure_expr() {
        let registry = CommandRegistry::build_default();
        let cse = classify_side_effects(&registry, "expr", &["{1 + 2}".into()], None, None);
        assert!(cse.pure);
        assert!(cse.deterministic);
        assert_eq!(cse.effects, [] as [crate::side_effects::SideEffect; 0]);
    }

    #[test]
    fn classify_set_write() {
        let registry = CommandRegistry::build_default();
        let cse = classify_side_effects(&registry, "set", &["x".into(), "42".into()], None, None);
        assert!(!cse.pure);
        assert!(cse.writes_any());
        assert!(!cse.reads_any());
        let eff = &cse.effects[0];
        assert_eq!(eff.target, SideEffectTarget::Variable);
        assert_eq!(eff.scope, StorageScope::ProcLocal);
        assert_eq!(eff.key.as_deref(), Some("x"));
    }

    #[test]
    fn classify_set_read_when_no_value() {
        let registry = CommandRegistry::build_default();
        let cse = classify_side_effects(&registry, "set", &["x".into()], None, None);
        assert!(cse.reads_any());
        assert!(!cse.writes_any());
    }

    #[test]
    fn classify_incr_is_read_modify_write() {
        let registry = CommandRegistry::build_default();
        let cse = classify_side_effects(&registry, "incr", &["i".into()], None, None);
        // incr always reads AND writes (READS_BEFORE_WRITE trait).
        assert!(cse.reads_any());
        assert!(cse.writes_any());
    }

    #[test]
    fn classify_unset_keys_the_variable_not_the_option() {
        // `unset x` destroys `x` — it is a WRITE (destroy) of
        // `x`, never a read, and its key is `x` (not modelled as an assignment).
        let registry = CommandRegistry::build_default();
        let cse = classify_side_effects(&registry, "unset", &["x".into()], None, None);
        assert!(cse.writes_any());
        assert!(!cse.reads_any(), "unset does not read its target");
        assert_eq!(cse.effects.len(), 1);
        assert_eq!(cse.effects[0].target, SideEffectTarget::Variable);
        assert_eq!(cse.effects[0].key.as_deref(), Some("x"));
    }

    #[test]
    fn classify_unset_skips_leading_options() {
        // `unset -nocomplain x` keys `x`, NOT `-nocomplain`.
        let registry = CommandRegistry::build_default();
        let cse = classify_side_effects(
            &registry,
            "unset",
            &["-nocomplain".into(), "x".into()],
            None,
            None,
        );
        let keys: Vec<&str> = cse
            .effects
            .iter()
            .filter_map(|e| e.key.as_deref())
            .collect();
        assert_eq!(keys, vec!["x"], "must key the variable, not the option");
    }

    #[test]
    fn classify_unset_keys_every_name() {
        // `unset a b c` destroys all three — not just the first.
        let registry = CommandRegistry::build_default();
        let cse = classify_side_effects(
            &registry,
            "unset",
            &["a".into(), "b".into(), "c".into()],
            None,
            None,
        );
        let mut keys: Vec<&str> = cse
            .effects
            .iter()
            .filter_map(|e| e.key.as_deref())
            .collect();
        keys.sort_unstable();
        assert_eq!(keys, vec!["a", "b", "c"]);
        assert!(cse.writes_any());
    }

    #[test]
    fn classify_global_scope_variable() {
        let registry = CommandRegistry::build_default();
        let cse = classify_side_effects(
            &registry,
            "set",
            &["::foo::bar".into(), "v".into()],
            None,
            None,
        );
        let eff = &cse.effects[0];
        assert_eq!(eff.scope, StorageScope::Namespace);
        assert_eq!(eff.namespace.as_deref(), Some("::foo"));
    }

    #[test]
    fn classify_irules_static_uses_global_connection_side() {
        let registry = CommandRegistry::build_default();
        let cse = classify_side_effects(
            &registry,
            "set",
            &["static::counter".into(), "0".into()],
            Some(tcl_dialect::DialectProfile::irules()),
            None,
        );
        let eff = &cse.effects[0];
        assert_eq!(eff.scope, StorageScope::Static);
        assert_eq!(eff.connection_side, ConnectionSide::Global);
    }

    #[test]
    fn classify_irules_proc_local_uses_both_side() {
        let registry = CommandRegistry::build_default();
        let cse = classify_side_effects(
            &registry,
            "set",
            &["local".into(), "0".into()],
            Some(tcl_dialect::DialectProfile::irules()),
            None,
        );
        let eff = &cse.effects[0];
        assert_eq!(eff.connection_side, ConnectionSide::Both);
    }

    #[test]
    fn classify_eval_is_dynamic_barrier() {
        let registry = CommandRegistry::build_default();
        let cse = classify_side_effects(&registry, "eval", &["script".into()], None, None);
        assert!(cse.dynamic_barrier);
        let (_, w) = cse.to_effect_regions();
        assert!(w.contains(EffectRegion::UNKNOWN_STATE));
    }

    #[test]
    fn classify_proc_is_procedure_definition() {
        let registry = CommandRegistry::build_default();
        let cse = classify_side_effects(
            &registry,
            "proc",
            &["foo".into(), "{}".into(), "{}".into()],
            None,
            None,
        );
        let eff = &cse.effects[0];
        assert_eq!(eff.target, SideEffectTarget::ProcDefinition);
        assert!(eff.writes);
        assert_eq!(eff.scope, StorageScope::Namespace);
    }

    #[test]
    fn classify_unknown_command_is_conservative() {
        let registry = CommandRegistry::build_default();
        let cse = classify_side_effects(&registry, "__nonexistent", &[], None, None);
        assert!(cse.reads_any());
        assert!(cse.writes_any());
        assert_eq!(cse.effects[0].target, SideEffectTarget::Unknown);
    }

    #[test]
    fn classify_puts_consults_structured_side_effects() {
        // `puts` carries no purity/assign/proc-def trait, so a trait-only
        // classifier falls through to the conservative UNKNOWN write. It resolves
        // via the spec's structured `side_effects` (a `FileIo` write) —
        // impure (`writes_any`) but region-free: `classify_side_effects`
        // for `puts` yields pure=False, regions=(NONE, NONE).
        let registry = CommandRegistry::build_default();
        let cse = classify_side_effects(&registry, "puts", &["hi".into()], None, None);
        assert!(!cse.pure);
        assert!(cse.writes_any());
        assert!(!cse.reads_any());
        assert_eq!(cse.effects[0].target, SideEffectTarget::FileIo);
        // The whole point: no tracked effect region (NONE, not UNKNOWN_STATE).
        let (r, w) = cse.to_effect_regions();
        assert_eq!(r, EffectRegion::NONE);
        assert_eq!(w, EffectRegion::NONE);
    }

    #[test]
    fn external_tk_selection_reads_are_neither_pure_nor_deterministic() {
        let registry = tcl_registry::model::ingress::static_context_for("tk").commands();
        let profile = tcl_registry::model::ingress::resolve_environment("tk").analyser_profile();
        for command in ["clipboard", "selection"] {
            let effect =
                classify_side_effects(registry, command, &["get".to_owned()], Some(profile), None);
            assert!(!effect.pure, "{command} get reads mutable external state");
            assert!(
                !effect.deterministic,
                "{command} get can change without any Tcl-side write"
            );
            assert!(
                effect.reads_any(),
                "{command} get must retain its read effect"
            );
            assert!(!effect.writes_any(), "{command} get is not itself a writer");
        }
    }

    #[test]
    fn pure_command_mutator_subcommand_downgrades_purity() {
        // `HTTP::header` carries `Traits::PURE` + a structured `HttpHeader`
        // read+write hint + `mutator` subcommands. The getter stays pure with
        // a read-only effect; a mutator subcommand (`insert`) downgrades to
        // impure with a read+write effect. On the pure branch,
        // `HTTP::header` → (HTTP_STATE, NONE) pure; `insert` → (HTTP_STATE,
        // HTTP_STATE) impure.
        let mut registry = CommandRegistry::build_default();
        registry.load_surface(SurfaceLayer::Core(Family::F5Irules, ""));

        let getter = classify_side_effects(
            &registry,
            "HTTP::header",
            &["value".into(), "Host".into()],
            Some(tcl_dialect::DialectProfile::irules()),
            None,
        );
        assert!(getter.pure, "HTTP::header getter should stay pure");
        assert_eq!(
            getter.to_effect_regions(),
            (EffectRegion::HTTP_STATE, EffectRegion::NONE),
            "pure getter reads header state, no write",
        );

        let insert = classify_side_effects(
            &registry,
            "HTTP::header",
            &["insert".into(), "X-Foo".into(), "y".into()],
            Some(tcl_dialect::DialectProfile::irules()),
            None,
        );
        assert!(
            !insert.pure,
            "HTTP::header insert (mutator subcommand) must not be pure",
        );
        assert_eq!(
            insert.to_effect_regions(),
            (EffectRegion::HTTP_STATE, EffectRegion::HTTP_STATE),
            "header mutation reads + writes header state",
        );
    }

    #[test]
    fn classify_hints_are_dialect_gated() {
        // `log` is irules-only. Under a Tcl dialect its irules `LogIo`
        // hint must NOT apply — the spec doesn't support `tcl8.6`, so the
        // classifier falls back to the conservative UNKNOWN write
        // (dialect-mismatched specs are skipped). With no dialect requested
        // the hint applies.
        let mut registry = CommandRegistry::build_default();
        registry.load_surface(SurfaceLayer::Core(Family::F5Irules, ""));
        // Dialect-agnostic (interproc path): LogIo, region-free, impure.
        let agnostic = classify_side_effects(&registry, "log", &["hi".into()], None, None);
        assert!(!agnostic.pure);
        assert_eq!(agnostic.effects[0].target, SideEffectTarget::LogIo);
        assert_eq!(
            agnostic.to_effect_regions(),
            (EffectRegion::NONE, EffectRegion::NONE)
        );
        // Under a Tcl dialect the irules spec is gated out → UNKNOWN write.
        let tcl = classify_side_effects(
            &registry,
            "log",
            &["hi".into()],
            Some(tcl_registry::model::ingress::resolve_environment("tcl8.6").analyser_profile()),
            None,
        );
        assert!(!tcl.pure);
        assert_eq!(tcl.effects[0].target, SideEffectTarget::Unknown);
        assert_eq!(
            tcl.to_effect_regions(),
            (EffectRegion::UNKNOWN_STATE, EffectRegion::UNKNOWN_STATE)
        );
    }

    #[test]
    fn callee_summary_http_read_emits_http_header_effect() {
        let registry = CommandRegistry::build_default();
        let summary = CalleeSummary {
            effect_reads: EffectRegion::HTTP_STATE,
            effect_writes: EffectRegion::NONE,
            pure: false,
        };
        let cse = classify_side_effects(&registry, "doesnt_matter", &[], None, Some(&summary));
        assert!(cse.affects_target(SideEffectTarget::HttpHeader));
        assert!(cse.reads_target(SideEffectTarget::HttpHeader));
        assert!(!cse.writes_target(SideEffectTarget::HttpHeader));
    }

    #[test]
    fn callee_summary_response_commit_sets_write() {
        let registry = CommandRegistry::build_default();
        let summary = CalleeSummary {
            effect_reads: EffectRegion::NONE,
            effect_writes: EffectRegion::RESPONSE_LIFECYCLE | EffectRegion::HTTP_STATE,
            pure: false,
        };
        let cse = classify_side_effects(&registry, "doesnt_matter", &[], None, Some(&summary));
        assert!(cse.writes_target(SideEffectTarget::ResponseCommit));
    }

    #[test]
    fn callee_summary_pure_bypass_registry() {
        let registry = CommandRegistry::build_default();
        let summary = CalleeSummary {
            effect_reads: EffectRegion::NONE,
            effect_writes: EffectRegion::NONE,
            pure: true,
        };
        let cse = classify_side_effects(&registry, "doesnt_matter", &[], None, Some(&summary));
        assert!(cse.pure);
        assert!(cse.deterministic);
        assert_eq!(cse.effects, [] as [crate::side_effects::SideEffect; 0]);
    }

    #[test]
    fn effects_filtered_by_scope_and_side() {
        let mut client_hdr = SideEffect::new(SideEffectTarget::HttpHeader, true, false);
        client_hdr.connection_side = ConnectionSide::Client;
        let mut server_hdr = SideEffect::new(SideEffectTarget::HttpHeader, true, false);
        server_hdr.connection_side = ConnectionSide::Server;
        let cse = CommandSideEffects {
            effects: vec![client_hdr, server_hdr],
            ..CommandSideEffects::default()
        };
        assert_eq!(cse.effects_on_side(ConnectionSide::Client).len(), 1);
        assert_eq!(cse.effects_on_side(ConnectionSide::Server).len(), 1);
        assert_eq!(cse.effects_in_scope(StorageScope::Global).len(), 0);
    }
    #[test]
    fn static_namespace_effects_share_regions_across_spellings_and_aliases() {
        let registry = CommandRegistry::build_default();
        let dialect = Some(tcl_dialect::DialectProfile::irules());
        let mut context = crate::var_resolve::ResolveContext::default();
        context.known_namespaces.insert("::static".to_owned());
        let target =
            crate::var_resolve::resolve_place("::static::counter", &context, false, &registry);
        context.alias_bindings.insert("linked".to_owned(), target);
        for name in ["static::counter", "::static::counter", "linked"] {
            let effects = classify_side_effects_with_context(
                &registry,
                "set",
                &[name.to_owned(), "1".to_owned()],
                dialect,
                None,
                &context,
            );
            assert_eq!(effects.effects[0].scope, StorageScope::Static);
            assert_eq!(effects.effects[0].key.as_deref(), Some("::static::counter"));
            assert!(
                effects
                    .to_effect_regions()
                    .1
                    .contains(EffectRegion::GLOBAL_STATE)
            );
        }
        let plain = classify_side_effects(
            &registry,
            "set",
            &["::static::counter".to_owned(), "1".to_owned()],
            Some(tcl_dialect::DialectProfile::find("tcl8.6").expect("profile")),
            None,
        );
        assert_eq!(plain.effects[0].scope, StorageScope::Namespace);
    }

    fn native_effect_namespace(
        token: u64,
        segments: &[&str],
    ) -> crate::command_binding::SourceNamespaceKey {
        use tcl_runtime_api::native_compilation::{
            NativeInterpreterIdentity, NativeNamespaceContext,
        };
        crate::command_binding::SourceNamespaceKey::Native(NativeNamespaceContext {
            interpreter: NativeInterpreterIdentity {
                owner: 31,
                interpreter: 7,
            },
            token,
            path: tcl_core_types::ByteNamespacePath::from_segments(segments.iter().copied()),
        })
    }

    #[test]
    fn namespace_place_storage_scope_requires_the_selected_domain_before_static_reporting() {
        // naming.analysis.resolved-static-variable-patterns
        // docs/design/analysis/name-resolution-proofs/resolved-static-variable-patterns.md
        // Actual resolver/domain software inputs; no physical BIG-IP worker is observed.
        let registry = tcl_registry::model::ingress::static_context_for("f5-irules").commands();
        let root = native_effect_namespace(1, &[]);
        let static_namespace = native_effect_namespace(2, &["static"]);
        let mut context = crate::var_resolve::ResolveContext::for_namespace("::static");
        context.retain_namespace_world(
            static_namespace.clone(),
            [root, static_namespace],
            Some(tcl_syntax::naming::NativeNameProtocol::C(
                tcl_dialect::TclVersion::V8_4,
            )),
        );
        context.invocation_dialect = Some(tcl_registry::InvocationDialect::of_profile(
            registry.profile().unwrap(),
        ));
        let ordinary =
            crate::var_resolve::resolve_literal_place("debug", &context, false, registry);
        assert_eq!(
            namespace_storage_scope_for_place(&ordinary, registry.profile()),
            StorageScope::Namespace
        );
        context.hosted_execution_context = Some(tcl_registry::f5::BigIpExecutionContext::TmmIRule);
        let selected =
            crate::var_resolve::resolve_literal_place("debug", &context, false, registry);
        assert_eq!(
            namespace_storage_scope_for_place(&selected, registry.profile()),
            StorageScope::Static
        );
        let mut displayed = ordinary;
        displayed.ns = "::static".into();
        displayed.name = "static::debug".into();
        assert_eq!(
            namespace_storage_scope_for_place(&displayed, registry.profile()),
            StorageScope::Namespace
        );
        let unknown = crate::place::unknown_top();
        assert_eq!(
            namespace_storage_scope_for_place(&unknown, registry.profile()),
            StorageScope::Unknown
        );
    }

    #[test]
    fn native_variable_scope_uses_geometry_and_actual_storage_domain() {
        let registry = CommandRegistry::build_default();
        let root = native_effect_namespace(1, &[]);
        let literal_colons = native_effect_namespace(2, &["::"]);
        let static_namespace = native_effect_namespace(3, &["static"]);
        for (namespace, expected) in [
            (root.clone(), StorageScope::Global),
            (literal_colons.clone(), StorageScope::Namespace),
            (static_namespace.clone(), StorageScope::Namespace),
        ] {
            let mut context = crate::var_resolve::ResolveContext::for_namespace(
                namespace.display().expect("Unicode presentation"),
            );
            context.retain_namespace_world(
                namespace.clone(),
                [
                    root.clone(),
                    literal_colons.clone(),
                    static_namespace.clone(),
                ],
                Some(tcl_syntax::naming::NativeNameProtocol::C(
                    tcl_dialect::TclVersion::V8_6,
                )),
            );
            context.invocation_dialect = Some(tcl_registry::InvocationDialect::of_profile(
                tcl_dialect::DialectProfile::find("tcl8.6").expect("actual lookup protocol"),
            ));
            if namespace != root {
                assert_eq!(
                    resolved_variable_scope(
                        "counter",
                        &registry,
                        Some(tcl_dialect::DialectProfile::irules()),
                        &context,
                    )
                    .0,
                    StorageScope::Unknown,
                    "unknown current/global cell presence must remain ambiguous",
                );
            }
            context.namespace_cells.present.insert(
                crate::var_resolve::VariableCellKey::Namespace {
                    identity: namespace.clone(),
                    simple: "counter".into(),
                },
            );
            let (scope, displayed_namespace, _) = resolved_variable_scope(
                "counter",
                &registry,
                Some(tcl_dialect::DialectProfile::irules()),
                &context,
            );
            assert_eq!(scope, expected);
            assert_eq!(displayed_namespace, namespace.display());
            context.namespace_cells.present.insert(
                crate::var_resolve::VariableCellKey::Namespace {
                    identity: namespace.clone(),
                    simple: "auto_path".into(),
                },
            );
            let special = classify_side_effects_with_context(
                &registry,
                "set",
                &["auto_path".to_owned(), "value".to_owned()],
                Some(tcl_dialect::DialectProfile::find("tcl8.6").expect("profile")),
                None,
                &context,
            );
            assert_eq!(
                special.writes_target(SideEffectTarget::InterpState),
                expected == StorageScope::Global,
            );
            if namespace == static_namespace {
                context.authored_tmm_static = Some(
                    tcl_runtime_api::authored_tmm::AuthoredTmmStaticCompilationContext {
                        policy: tcl_runtime_api::authored_tmm::AuthoredTmmStaticPolicy::RuleInitPublication,
                        context: None,
                        namespace: namespace.native_context().expect("actual namespace").clone(),
                        recipients: Vec::new(),
                        outward_observers: tcl_runtime_api::native_compilation::NativeVariableObserverPresence::Unknown,
                    },
                );
                assert_eq!(
                    resolved_variable_scope("counter", &registry, None, &context).0,
                    StorageScope::Static,
                );
                context
                    .authored_tmm_static
                    .as_mut()
                    .expect("selected policy")
                    .namespace
                    .token += 1;
                assert_eq!(
                    resolved_variable_scope("counter", &registry, None, &context).0,
                    StorageScope::Namespace,
                );
            }
        }
    }

    #[test]
    fn native_namespace_scope_distinguishes_current_global_and_original_alias_cells() {
        use crate::var_resolve::VariableCellKey;

        for (dialect, version, fallback) in [
            ("tcl8.4", tcl_dialect::TclVersion::V8_4, true),
            ("tcl8.5", tcl_dialect::TclVersion::V8_5, true),
            ("tcl8.6", tcl_dialect::TclVersion::V8_6, true),
            ("tcl9.0", tcl_dialect::TclVersion::V9_0, false),
            ("tcl9.1", tcl_dialect::TclVersion::V9_1, false),
        ] {
            let selected = tcl_registry::model::ingress::static_context_for(dialect);
            let registry = selected.commands();
            let root = native_effect_namespace(1, &[]);
            let named = native_effect_namespace(2, &["named"]);
            let mut context = crate::var_resolve::ResolveContext::for_namespace("::named");
            context.retain_namespace_world(
                named.clone(),
                [root.clone(), named.clone()],
                Some(tcl_syntax::naming::NativeNameProtocol::C(version)),
            );
            let profile = Some(tcl_dialect::DialectProfile::find(dialect).expect("native profile"));
            assert_eq!(
                resolved_variable_scope("counter", registry, profile, &context).0,
                if fallback {
                    StorageScope::Unknown
                } else {
                    StorageScope::Namespace
                },
                "{dialect}: open original cell inventory",
            );
            let root_cell = VariableCellKey::Namespace {
                identity: root.clone(),
                simple: "counter".into(),
            };
            let current_cell = VariableCellKey::Namespace {
                identity: named,
                simple: "counter".into(),
            };
            context.namespace_cells.closed = true;
            context.namespace_cells.present.insert(root_cell);
            assert_eq!(
                resolved_variable_scope("counter", registry, profile, &context).0,
                if fallback {
                    StorageScope::Global
                } else {
                    StorageScope::Namespace
                },
                "{dialect}: missing current cell and present global cell",
            );
            context.namespace_cells.present.insert(current_cell);
            assert_eq!(
                resolved_variable_scope("counter", registry, profile, &context).0,
                StorageScope::Namespace,
                "{dialect}: present current cell precedes global fallback",
            );
            let original = context.namespace_place_in_identity("counter", &root, false);
            context.alias_bindings.insert("linked", original);
            assert_eq!(
                resolved_variable_scope("linked", registry, profile, &context).0,
                StorageScope::Global,
                "{dialect}: original alias retains its root receiver",
            );
            context.namespace_cells.present.clear();
            assert_eq!(
                resolved_variable_scope("counter", registry, profile, &context).0,
                StorageScope::Namespace,
                "{dialect}: both original cells absent selects current creation table",
            );
        }
    }

    #[test]
    fn jim_namespace_scope_keeps_activation_locals_and_original_variable_links_separate() {
        let selected = tcl_registry::model::ingress::static_context_for("jim");
        let registry = selected.commands();
        let profile = registry.profile();
        let root = native_effect_namespace(1, &[]);
        let named = native_effect_namespace(2, &["named"]);
        let mut context = crate::var_resolve::ResolveContext::for_namespace("::named");
        context.retain_namespace_world(
            named.clone(),
            [root.clone(), named.clone()],
            Some(tcl_syntax::naming::NativeNameProtocol::Jim084),
        );
        context.namespace_objects.insert(root.clone(), "".into());
        context
            .namespace_objects
            .insert(named.clone(), "named".into());
        assert_eq!(
            resolved_variable_scope("counter", registry, profile, &context).0,
            StorageScope::ProcLocal,
            "an unlinked namespace-eval local does not select global fallback",
        );
        let original = context.namespace_place_in_identity("counter", &named, false);
        assert_eq!(
            original
                .cell
                .as_ref()
                .expect("original flat namespace cell")
                .name,
            "named::counter",
        );
        assert_eq!(
            original.cell.as_ref().unwrap().owner,
            crate::place::CellOwner::NamespaceIdentity(Box::new(root.clone())),
            "Jim's stored key is root-flat; the namespace owner is independent",
        );
        context.alias_bindings.insert("counter", original);
        assert_eq!(
            resolved_variable_scope("counter", registry, profile, &context).0,
            StorageScope::Global,
            "variable links retain Jim's actual flat global storage owner",
        );
        let root_original = context.namespace_place_in_identity("counter", &root, false);
        context.alias_bindings.insert("linked", root_original);
        assert_eq!(
            resolved_variable_scope("linked", registry, profile, &context).0,
            StorageScope::Global,
        );
        assert_eq!(
            resolved_variable_scope("::counter", registry, profile, &context).0,
            StorageScope::Global,
            "an original root qualifier selects the real flat global cell",
        );
    }

    #[test]
    fn special_variable_effects_follow_root_cells_and_aliases() {
        let registry = CommandRegistry::build_default();
        let profile = Some(tcl_dialect::DialectProfile::find("tcl8.6").expect("profile"));
        let mut context = crate::var_resolve::ResolveContext::default();
        context.known_namespaces.insert("::named".to_owned());
        for (name, alias) in [("::auto_path", "search_path"), ("::env", "environment")] {
            let target = crate::var_resolve::resolve_place(name, &context, false, &registry);
            context.alias_bindings.insert(alias, target);
        }
        for (name, expected) in [
            ("::auto_path", true),
            ("search_path", true),
            ("::env(KEY)", true),
            ("environment(KEY)", true),
            ("auto_path", false),
            ("env(KEY)", false),
            ("::named::auto_path", false),
            ("::named::env(KEY)", false),
        ] {
            let effects = classify_side_effects_with_context(
                &registry,
                "set",
                &[name.to_owned(), "value".to_owned()],
                profile,
                None,
                &context,
            );
            assert_eq!(
                effects.writes_target(SideEffectTarget::InterpState),
                expected,
                "{name}"
            );
        }
        let read = classify_side_effects_with_context(
            &registry,
            "set",
            &["search_path".to_owned()],
            profile,
            None,
            &context,
        );
        assert!(!read.writes_target(SideEffectTarget::InterpState));
    }

    /// A command the document declares classifies from the facts its
    /// declaration states — nearest wins — and a declaration stating none
    /// classifies exactly as an undeclared command does; every other name is
    /// the catalogue's.
    ///
    /// The declarations arrive the way a document states them, through the
    /// analyser's one ingestion path (`document_declared_surface`), so the
    /// facts classified here are the flags' own: `-pure` is `PURE`, and
    /// `-mutator` is `READS_BEFORE_WRITE` beside a variable read and write.
    #[test]
    fn a_declared_command_classifies_from_its_declaration() {
        use tcl_registry::model::DocumentCommandSurface;
        let registry = CommandRegistry::build_default();
        let declared = crate::analyser::utils::document_declared_surface(
            "# tcl-lsp: stubs-begin\n\
             # tcl-lsp: stub my_pure {} -pure\n\
             # tcl-lsp: stub my_mut {v:var} -mutator\n\
             # tcl-lsp: stub my_plain {}\n\
             # tcl-lsp: stubs-end\n",
            None,
            "tcl8.6",
        );
        let surface = DocumentCommandSurface::new(&registry, Some(&declared));
        let classify = |name: &str, args: &[String]| {
            classify_side_effects_in(&surface, name, args, None, None)
        };

        let pure = classify("my_pure", &[]);
        assert!(pure.pure && pure.deterministic && pure.effects.is_empty());

        let mutator = classify("my_mut", &[]);
        assert!(!mutator.pure);
        assert!(mutator.reads_target(SideEffectTarget::Variable));
        assert!(mutator.writes_target(SideEffectTarget::Variable));
        assert!(
            !mutator.affects_target(SideEffectTarget::Unknown),
            "the stated effect, not the conservative unknown write"
        );

        assert_eq!(
            classify("my_plain", &[]),
            classify_side_effects(&registry, "no_such_command", &[], None, None),
            "a declaration stating no behaviour is as conservative as no declaration"
        );

        let set_args = ["x".to_owned(), "1".to_owned()];
        assert_eq!(
            classify("set", &set_args),
            classify_side_effects(&registry, "set", &set_args, None, None),
            "an undeclared name is the catalogue's"
        );
    }

    /// A declaration flagged `-extension` starts from the conservative default
    /// for native code: a dynamic barrier with an unknown read and write. A
    /// stated purity or effect replaces those, because the declaration said
    /// what the command does; a stated barrier survives.
    #[test]
    fn an_extension_declaration_is_a_barrier_until_it_states_its_effects() {
        use tcl_registry::model::DocumentCommandSurface;
        let registry = CommandRegistry::build_default();
        let declared = crate::analyser::utils::document_declared_surface(
            "# tcl-lsp: stubs-begin\n\
             # tcl-lsp: stub ext_any {} -extension\n\
             # tcl-lsp: stub ext_pure {} -extension -pure\n\
             # tcl-lsp: stub ext_mut {} -extension -mutator\n\
             # tcl-lsp: stub ext_both {} -extension -mutator -barrier\n\
             # tcl-lsp: stub plain {}\n\
             # tcl-lsp: stubs-end\n",
            None,
            "tcl8.6",
        );
        let surface = DocumentCommandSurface::new(&registry, Some(&declared));
        let classify = |name: &str| classify_side_effects_in(&surface, name, &[], None, None);

        let any = classify("ext_any");
        assert!(any.dynamic_barrier && !any.pure);
        assert!(any.reads_target(SideEffectTarget::Unknown));
        assert!(any.writes_target(SideEffectTarget::Unknown));

        let pure = classify("ext_pure");
        assert!(pure.pure && pure.deterministic && pure.effects.is_empty());
        assert!(!pure.dynamic_barrier);

        let mutator = classify("ext_mut");
        assert!(!mutator.dynamic_barrier && !mutator.pure);
        assert!(mutator.writes_target(SideEffectTarget::Variable));
        assert!(!mutator.affects_target(SideEffectTarget::Unknown));

        // `-barrier` is the trait the minifier fences scopes by, not the
        // classifier's `dynamic_barrier`, so it is read off the surface.
        let barrier_trait = |name: &str| {
            surface
                .traits(name)
                .is_some_and(|traits| traits.contains(Traits::CREATES_DYNAMIC_BARRIER))
        };
        assert!(
            barrier_trait("ext_both"),
            "a stated barrier survives a stated effect"
        );
        assert!(
            !barrier_trait("ext_mut"),
            "a stated effect replaces the default's barrier"
        );
        assert!(barrier_trait("ext_any"), "the default is a barrier");

        assert!(
            !classify("plain").dynamic_barrier,
            "without `-extension` a stub that states nothing is no barrier"
        );
    }
}
