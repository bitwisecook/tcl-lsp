// tcl-lsp — a language server and toolchain for Tcl
// Copyright (C) 2026 James Deucker (bitwisecook) <https://github.com/bitwisecook>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.
//
// SPDX-License-Identifier: AGPL-3.0-or-later

//! Top-level diagnostic aggregator.
//!
//! Runs every per-pass diagnostic source (SCCP constant-branch,
//! GVN redundancies, shimmer warnings, taint warnings, optimiser
//! suggestions) against a [`CompilationUnit`] and returns a
//! single flat list of diagnostics ready for the LSP.
//!
//! Hosts the [`Diagnostic`] supertype and the [`run_all_checks`] entry
//! point that calls every analysis pass — SCCP, GVN, shimmer (S100–S103),
//! and taint (T100–T101) — and collects results into a flat list.

use tcl_lexer::Span;

use crate::compilation_unit::{CompilationUnit, FunctionUnit};
use crate::gvn::{
    find_loop_invariants_for_function, find_partial_redundancies_for_function,
    find_redundancies_for_function,
};
#[cfg(test)]
use crate::irules_checks::find_conditional_irule_source_flow_advice;
use crate::irules_checks::{
    CodeFix, IrulesCheckWarning, find_conditional_collection_source_pairing_advice,
    find_generic_static_name_warnings, find_hoistable_set_warnings,
};
use crate::path_concat::PathConcatWarning;
use crate::sccp::{BranchFactKind, ConstantBranch};
use crate::shimmer::{
    SharingWarning, ShimmerWarning, ThunkingWarning, find_byte_array_warnings_with_context,
    find_sharing_warnings_with_context, find_shimmer_warnings_with_context,
    find_thunking_warnings_with_context,
};
use crate::taint::{
    TaintWarning, find_destructive_file_warnings_for_module_function,
    find_path_concat_warnings_for_module_function,
    find_setter_constraint_warnings_for_module_function, is_irules_dialect,
};
use crate::uri_split::find_uri_split_suggestions;
use tcl_registry::CommandRegistry;

// Unified diagnostic envelope

pub use tcl_core_types::DiagCode;
/// Severity of a compiler diagnostic — the shared [`tcl_core_types::Severity`].
pub use tcl_core_types::Severity;

/// Exact source and command-store inputs retained by a diagnostic issuer.
/// This is source currency, not a reached command, cell or edit permission.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct DiagnosticSourceContext {
    image: tcl_lexer::SourceImage,
    config: tcl_lexer::LexerConfig,
    registry: tcl_registry::RegistrySnapshot,
    input: crate::analyser::ResolvedAnalysisInput,
    authoring_purpose: DiagnosticSourceAuthoringPurpose,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
enum DiagnosticSourceAuthoringPurpose {
    OrdinarySourceSubject,
    ConditionalSourceNoAction,
}

impl DiagnosticSourceContext {
    /// Eligibility for a retained authoring subject, independently of every
    /// action's further source/intent checks. Conditional source advice grants none.
    #[must_use]
    pub fn allows_context_action_subject(&self) -> bool {
        self.authoring_purpose == DiagnosticSourceAuthoringPurpose::OrdinarySourceSubject
    }

    fn for_unit(cu: &CompilationUnit, registry: &CommandRegistry) -> Option<Self> {
        if cu.ir_module.registry_snapshot.as_ref()?.semantic_key()
            != registry.snapshot().semantic_key()
        {
            return None;
        }
        let input = crate::registry_invocation::InvocationMetadataContext::for_module(
            registry,
            &cu.ir_module,
        )?
        .source_analysis_input()?;
        Some(Self {
            image: cu.ir_module.source.clone(),
            config: cu.ir_module.lexer_config,
            registry: registry.snapshot(),
            input: input.clone(),
            authoring_purpose: DiagnosticSourceAuthoringPurpose::OrdinarySourceSubject,
        })
    }

    /// Whole original image, including the source channel.
    #[must_use]
    pub const fn image(&self) -> &tcl_lexer::SourceImage {
        &self.image
    }
    /// Every actual lexer configuration axis.
    #[must_use]
    pub const fn lexer_config(&self) -> tcl_lexer::LexerConfig {
        self.config
    }
    /// Complete actual availability and source policies used by the issuer.
    /// This retained input supplies currency only, not an execution grant.
    #[must_use]
    pub const fn analysis_input(&self) -> &crate::analyser::ResolvedAnalysisInput {
        &self.input
    }
    /// Immutable command store used by the diagnostic producer.
    #[must_use]
    pub const fn registry(&self) -> &tcl_registry::RegistrySnapshot {
        &self.registry
    }
}

/// Structured taint producer fields, independent of the rendered message.
/// The variable is a taint-analysis subject, not a native lookup key. Consumers
/// select a source read independently before proposing a replacement.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct TaintDiagnosticSubject {
    variable: String,
    sink_command: String,
}

impl TaintDiagnosticSubject {
    /// Taint-analysis subject used for source advice and presentation.
    #[must_use]
    pub fn variable(&self) -> &str {
        &self.variable
    }
    /// Sink selected by the producer; never extracted from diagnostic prose.
    #[must_use]
    pub fn sink_command(&self) -> &str {
        &self.sink_command
    }
}

/// A unified diagnostic emitted by the compiler-checks pipeline.
///
/// Downstream consumers (LSP, CLI) lower this into their native
/// diagnostic types.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct Diagnostic {
    /// Source span.
    pub span: Span,
    /// Diagnostic code (e.g. `"O105"`, `"S100"`, `"T100"`).
    pub code: DiagCode,
    /// Short category name (`"gvn"`, `"shimmer"`, `"taint"`, …).
    pub category: String,
    /// Severity.
    pub severity: Severity,
    /// Formatted message.
    pub message: String,
    /// Optional replacement text for a code-action fix that rewrites
    /// the diagnostic's span. `None` when the check has no suggested
    /// fix or could not build one. Consumers that surface code actions
    /// (LSP `CodeAction`, CLI auto-fix) should plumb this through.
    pub replacement: Option<String>,
    /// Suggested fixes whose range is independent of `span` — insertions or
    /// out-of-span replacements that `replacement` (a same-span rewrite) cannot
    /// express (e.g. the IRULE5002/5004 "insert `return`" fixes). Empty when the
    /// check has no such fix. Consumers emit one `TextEdit` per fix at its own
    /// `span`.
    pub fixes: Vec<CodeFix>,
    /// Exact issuer inputs for a context-driven source action, when retained.
    pub source_context: Option<DiagnosticSourceContext>,
    /// Original taint fields, independent of any message or reporting label.
    pub taint_subject: Option<TaintDiagnosticSubject>,
}

impl Diagnostic {
    fn from_constant_branch(cb: &ConstantBranch) -> Self {
        Self {
            // Use the branch terminator's span when available so
            // editors / CLIs can highlight the condition that was
            // folded, rather than the start of the file.
            span: cb.span.unwrap_or_else(|| Span::new(0, 0)),
            code: DiagCode::O100,
            category: "sccp".into(),
            severity: Severity::Hint,
            message: format!(
                "condition in block {} is {} on normal completion — target `{}`",
                cb.block, cb.value, cb.taken_target
            ),
            replacement: None,
            fixes: Vec::new(),
            source_context: None,
            taint_subject: None,
        }
    }

    fn from_shimmer(w: &ShimmerWarning) -> Self {
        Self {
            span: w.span,
            code: w.code,
            category: "shimmer".into(),
            // S100 (single shimmer outside a loop) is informational; S101
            // (per-iteration loop shimmer) is a warning.
            severity: if w.code == DiagCode::S100 {
                Severity::Info
            } else {
                Severity::Warning
            },
            message: w.message.clone(),
            replacement: None,
            fixes: Vec::new(),
            source_context: None,
            taint_subject: None,
        }
    }

    fn from_thunking(w: &ThunkingWarning) -> Self {
        Self {
            span: w.span,
            code: w.code,
            category: "shimmer".into(),
            severity: Severity::Warning,
            message: w.message.clone(),
            replacement: None,
            fixes: Vec::new(),
            source_context: None,
            taint_subject: None,
        }
    }

    fn from_sharing(w: &SharingWarning) -> Self {
        Self {
            span: w.span,
            code: w.code,
            category: "shimmer".into(),
            // S103 (mutation of a potentially shared value copies it) is a
            // hint: the duplicate is correct behaviour with a real but
            // situational cost, one notch below the S100 representation
            // conversions.
            severity: Severity::Hint,
            message: w.message.clone(),
            replacement: None,
            fixes: Vec::new(),
            source_context: None,
            taint_subject: None,
        }
    }

    fn from_taint(w: &TaintWarning) -> Self {
        Self {
            span: w.span,
            code: w.code,
            category: "taint".into(),
            // The taint family is a Warning by default (not an Error); T106
            // and IRULE3103 are informational.
            severity: match w.code.as_str() {
                "T106" | "IRULE3103" => Severity::Info,
                _ => Severity::Warning,
            },
            message: w.message.clone(),
            replacement: w.replacement.clone(),
            fixes: w.fixes.clone(),
            source_context: None,
            taint_subject: Some(TaintDiagnosticSubject {
                variable: w.variable.clone(),
                sink_command: w.sink_command.clone(),
            }),
        }
    }

    fn from_conditional_collection_source_pairing(
        advice: &crate::irules_checks::ConditionalCollectionSourcePairingAdvice<'_>,
        pairing: &crate::irules_checks::ConditionalCollectionSourcePairing,
    ) -> Option<Self> {
        let (unit, registry) = advice.diagnostic_source_owner_for(pairing)?;
        Self::from_conditional_irule_source(
            unit,
            registry,
            pairing.span(),
            pairing.code(),
            pairing.message(),
        )
    }

    fn from_conditional_irule_source_flow(
        advice: &crate::irules_checks::ConditionalIruleSourceFlowAdvice<'_>,
        finding: &crate::irules_checks::ConditionalIruleSourceFlowFinding,
    ) -> Option<Self> {
        let (unit, registry) = advice.diagnostic_source_owner_for(finding)?;
        Self::from_conditional_irule_source(
            unit,
            registry,
            finding.span(),
            finding.code(),
            finding.message(),
        )
    }

    fn from_conditional_irule_source(
        unit: &CompilationUnit,
        registry: &CommandRegistry,
        span: Span,
        code: DiagCode,
        message: &str,
    ) -> Option<Self> {
        let mut context = DiagnosticSourceContext::for_unit(unit, registry)?;
        context.authoring_purpose = DiagnosticSourceAuthoringPurpose::ConditionalSourceNoAction;
        Some(Self {
            span,
            code,
            category: "irules".to_owned(),
            severity: Severity::Warning,
            message: message.to_owned(),
            replacement: None,
            fixes: Vec::new(),
            source_context: Some(context),
            taint_subject: None,
        })
    }

    fn from_irules_check(w: &IrulesCheckWarning) -> Self {
        Self {
            span: w.span,
            code: w.code,
            category: "irules".into(),
            // IRULE1007/1008 (collect-without-release / release-without-
            // collect) are hard connection-state errors; IRULE4004 is
            // informational. Everything else is a Warning.
            severity: match w.code.as_str() {
                "IRULE1007" | "IRULE1008" => Severity::Error,
                "IRULE4004" => Severity::Info,
                _ => Severity::Warning,
            },
            message: w.message.clone(),
            replacement: w.replacement.clone(),
            fixes: w.fixes.clone(),
            source_context: None,
            taint_subject: None,
        }
    }

    fn from_redundant(r: &crate::gvn::RedundantComputation) -> Self {
        Self {
            span: r.span,
            code: r.code,
            category: "gvn".into(),
            severity: Severity::Suggestion,
            message: r.message.clone(),
            replacement: None,
            fixes: Vec::new(),
            source_context: None,
            taint_subject: None,
        }
    }

    fn from_path_concat(w: &PathConcatWarning) -> Self {
        // The `[file join …]` replacement is only built when `w.span` is
        // the value word's own token range (see
        // `find_path_concat_warnings`), so lifting it into a same-span
        // fix replaces exactly the concatenated value.
        let fixes = w.replacement.as_ref().map_or_else(Vec::new, |r| {
            vec![CodeFix {
                span: w.span,
                new_text: r.clone(),
                description: "Rewrite with `file join`".to_string(),
                // W201: `file join` normalises separators and absolute-path
                // segments, so the joined result is not always the concatenated
                // string it replaces.
                safety: crate::irules_checks::FixSafety::RequiresReview,
            }]
        });
        Self {
            span: w.span,
            code: w.code,
            category: "taint".into(),
            // W201 (path concatenation) is a Hint, not a Warning.
            severity: match w.code.as_str() {
                "W201" => Severity::Hint,
                _ => Severity::Warning,
            },
            message: w.message.clone(),
            replacement: w.replacement.clone(),
            fixes,
            source_context: None,
            taint_subject: None,
        }
    }
}

// Entry point

/// Absolutise a per-function diagnostic's span — and its fixes' spans,
/// which live in the same coordinate space — by adding the unit's
/// `base_offset`.  The per-function checks read spans from `fu.cfg`/`fu.ssa`/
/// `fu.sccp`, which are relative to that offset (0 for a real-position build,
/// the body offset for a memoised offset-0 unit, Approach B).
fn shift(fu: &FunctionUnit, mut d: Diagnostic) -> Diagnostic {
    d.span = fu.abs_span(d.span);
    for fix in &mut d.fixes {
        fix.span = fu.abs_span(fix.span);
    }
    d
}

/// Compiler diagnostics and availability of required taint replays.
#[derive(Debug, Clone)]
pub struct CompilerCheckReport {
    /// Diagnostics produced by the requested checks.
    pub diagnostics: Vec<Diagnostic>,
    /// Command-head replay status for the checked functions; stored callbacks are a separate whole-unit query.
    pub taint_replays: crate::taint::TaintReplayAnalysis,
}

/// Run every check against a compilation unit and return a
/// flat list of diagnostics.
///
/// Order of the returned diagnostics is stable but not guaranteed
/// across releases — consumers that care about ordering sort on
/// `(span.start(), code)` themselves.
#[must_use]
pub fn run_all_checks(
    cu: &CompilationUnit,
    registry: &CommandRegistry,
    dialect: Option<&'static tcl_dialect::DialectProfile>,
) -> Vec<Diagnostic> {
    run_all_checks_with_generic_patterns(cu, registry, dialect, None)
}

/// Like [`run_all_checks`] but with explicit IRULE4002 generic-name patterns
/// (`None` → default set, `Some(&[])` → disabled, `Some(custom)` → replace).
/// Used by the no-salsa-input fallback so user `genericVariablePatterns`
/// configuration is honoured even off the memoised path.
#[must_use]
pub fn run_all_checks_with_generic_patterns(
    cu: &CompilationUnit,
    registry: &CommandRegistry,
    dialect: Option<&'static tcl_dialect::DialectProfile>,
    generic_patterns: Option<&[String]>,
) -> Vec<Diagnostic> {
    let solved = crate::taint_interproc::solve_interprocedural_taints(cu, registry, dialect);
    run_all_checks_with_solved_and_patterns(cu, registry, dialect, &solved, generic_patterns)
}

/// Preserve diagnostics and required replay availability independently.
#[must_use]
pub fn compiler_check_report_with_generic_patterns(
    cu: &CompilationUnit,
    registry: &CommandRegistry,
    dialect: Option<&'static tcl_dialect::DialectProfile>,
    generic_patterns: Option<&[String]>,
) -> CompilerCheckReport {
    let solved = crate::taint_interproc::solve_interprocedural_taints(cu, registry, dialect);
    compiler_check_report_with_solved_and_patterns(cu, registry, dialect, &solved, generic_patterns)
}

/// Like [`run_all_checks`] but consumes a pre-computed interprocedural taint
/// solve, so a caller can supply a memoised one instead of
/// re-solving the whole module on every edit — that solve is ~95% of this pass.
#[must_use]
pub fn run_all_checks_with_solved(
    cu: &CompilationUnit,
    registry: &CommandRegistry,
    dialect: Option<&'static tcl_dialect::DialectProfile>,
    solved: &crate::taint_interproc::InterprocTaintResult,
) -> Vec<Diagnostic> {
    run_all_checks_with_solved_and_patterns(cu, registry, dialect, solved, None)
}

/// Like [`run_all_checks_with_solved`] but with explicit IRULE4002 generic-name
/// patterns (see [`run_all_checks_with_generic_patterns`]).
#[must_use]
pub fn run_all_checks_with_solved_and_patterns(
    cu: &CompilationUnit,
    registry: &CommandRegistry,
    dialect: Option<&'static tcl_dialect::DialectProfile>,
    solved: &crate::taint_interproc::InterprocTaintResult,
    generic_patterns: Option<&[String]>,
) -> Vec<Diagnostic> {
    compiler_check_report_with_solved_and_patterns(cu, registry, dialect, solved, generic_patterns)
        .diagnostics
}

/// Preserve diagnostics and required replay availability independently.
#[must_use]
pub fn compiler_check_report_with_solved_and_patterns(
    cu: &CompilationUnit,
    registry: &CommandRegistry,
    dialect: Option<&'static tcl_dialect::DialectProfile>,
    solved: &crate::taint_interproc::InterprocTaintResult,
    generic_patterns: Option<&[String]>,
) -> CompilerCheckReport {
    let mut out: Vec<Diagnostic> = Vec::new();

    // Per-function non-taint checks (SCCP constant branches, GVN redundancies,
    // shimmer / thunking / byte-array), computed on each procedure — **and**,
    // via `analysable_body_function_units`, every `TclOO` method body and
    // synthetic body unit (`apply` lambda, `namespace eval` body) too, so the
    // whole family this folds in (SCCP constant branches, GVN redundancies and
    // the shimmer half alike) reaches those places as well (no separate
    // widening loop needed here: unlike `tcl-lsp-db::proc_taint_solve`'s
    // memoised path, which still iterates the proc-only `analysable_functions`
    // and so keeps its own explicit `function_nontaint_checks` top-up pass over
    // methods/body units) — rebased to its offset. Factored into
    // [`function_nontaint_checks`] so
    // the LSP db can memoise it per procedure on the offset-0 `FnLatticeKey`
    // An unedited procedure's checks are a cache hit
    // instead of recomputed over the whole unit every edit.
    for fu in cu.analysable_body_function_units() {
        for d in
            function_nontaint_checks(fu, registry, dialect, cu.method_instance_vars(fu.body_id))
        {
            out.push(shift(fu, d));
        }
    }

    // Taint (per-function, reading the interprocedural `solved`) + iRules
    // module-level checks — the half that is not per-function-pure.
    let taint_replays =
        push_taint_and_module_checks(cu, registry, dialect, solved, generic_patterns, &mut out);

    retain_diagnostic_source_context(cu, registry, &mut out);
    // Deterministic ordering (producers emit in `HashMap`-iteration order);
    // see [`sort_diagnostics`].
    sort_diagnostics(&mut out);

    CompilerCheckReport {
        diagnostics: out,
        taint_replays,
    }
}

/// Every per-function **non-taint** check for one procedure, returned at the
/// procedure's **offset-0** spans (the caller rebases — `shift` for a built
/// unit, or `+ body_offset` for the LSP db's offset-0 memo): SCCP constant
/// branches, GVN full / partial / loop redundancies, and the intrep-shimmer
/// family (shimmer S100/S101, thunking S102, shared-value copy S103,
/// byte-array S110).
///
/// These read only the `FunctionUnit`, so the LSP db wraps this in a salsa query
/// keyed on the offset-0 `FnLatticeKey` — an unedited
/// procedure's checks are a cache hit.  The S110 `*::payload` byte-command set is
/// dialect-gated (empty outside iRules).
#[must_use]
pub fn function_nontaint_checks<S: std::hash::BuildHasher>(
    fu: &FunctionUnit,
    registry: &CommandRegistry,
    dialect: Option<&'static tcl_dialect::DialectProfile>,
    instance_vars: Option<&std::collections::HashSet<String, S>>,
) -> Vec<Diagnostic> {
    let mut out: Vec<Diagnostic> = Vec::new();
    for cb in fu
        .diagnostic_value_facts()
        .constant_branches()
        .iter()
        .filter(|cb| cb.kind != BranchFactKind::Selected)
    {
        out.push(Diagnostic::from_constant_branch(cb));
    }
    for r in find_redundancies_for_function(registry, fu, dialect) {
        out.push(Diagnostic::from_redundant(&r));
    }
    for r in find_partial_redundancies_for_function(registry, fu, dialect) {
        out.push(Diagnostic::from_redundant(&r));
    }
    for r in find_loop_invariants_for_function(registry, fu, dialect) {
        out.push(Diagnostic::from_redundant(&r));
    }
    out.extend(shimmer_family_checks(fu, registry, dialect, instance_vars));
    out
}

/// The intrep-shimmer diagnostic family alone for one function body: use-site
/// / expression / phi shimmer (S100/S101), loop-oscillation thunking (S102),
/// shared-value copy-on-write (S103), and byte-array corruption (S110).
///
/// Uses the function's actual retained availability and lexical configuration.
/// Missing, foreign or mismatched metadata declines the entire family.
/// Callers can supply procedures, `TclOO` methods and synthetic body units;
/// [`CompilationUnit::analysable_functions`] visits top level and procedures.
/// Byte payload layouts follow the retained source profile, independently of
/// the compatibility dialect argument. Availability supplies no Native handler.
#[must_use]
pub fn shimmer_family_checks<S: std::hash::BuildHasher>(
    fu: &FunctionUnit,
    registry: &CommandRegistry,
    _dialect: Option<&'static tcl_dialect::DialectProfile>,
    instance_vars: Option<&std::collections::HashSet<String, S>>,
) -> Vec<Diagnostic> {
    let Some(context) = crate::shimmer::ShimmerContext::for_function(fu, registry) else {
        return Vec::new();
    };
    let mut out: Vec<Diagnostic> = Vec::new();
    for w in find_shimmer_warnings_with_context(&fu.cfg, &fu.ssa, &fu.types, &fu.sccp, context) {
        out.push(Diagnostic::from_shimmer(&w));
    }
    for w in find_thunking_warnings_with_context(
        &fu.cfg,
        &fu.ssa,
        &fu.types,
        &fu.sccp.executable_blocks,
        context,
        instance_vars,
    ) {
        out.push(Diagnostic::from_thunking(&w));
    }
    for w in find_sharing_warnings_with_context(
        &fu.cfg,
        &fu.ssa,
        &fu.def_use,
        &fu.sccp.executable_blocks,
        context,
        instance_vars,
    ) {
        out.push(Diagnostic::from_sharing(&w));
    }
    let payload_layouts =
        if is_irules_dialect(fu.source_metadata_input().map(|input| input.unit_profile())) {
            registry.byte_array_payload_layouts()
        } else {
            std::collections::HashMap::new()
        };
    for w in
        find_byte_array_warnings_with_context(&fu.cfg, &fu.ssa, &fu.sccp, context, &payload_layouts)
    {
        out.push(Diagnostic::from_shimmer(&w));
    }
    out
}

/// Append the taint-family warnings (per function, reading the interprocedural
/// `solved` taints) and the iRules module-level flow checks — the half of
/// [`run_all_checks_with_solved`] that is *not* per-function-pure (taint already
/// arrives pre-solved), so the per-procedure cache does not memoise it.
pub fn push_taint_and_module_checks(
    cu: &CompilationUnit,
    registry: &CommandRegistry,
    dialect: Option<&'static tcl_dialect::DialectProfile>,
    solved: &crate::taint_interproc::InterprocTaintResult,
    generic_patterns: Option<&[String]>,
    out: &mut Vec<Diagnostic>,
) -> crate::taint::TaintReplayAnalysis {
    let first = out.len();
    let mut taint_replays = crate::taint::TaintReplayAnalysis::Analysed {
        unavailable: Vec::new(),
    };
    // The interprocedural solve produces colour-aware return summaries and
    // parameter entry taints; its `top_taints` / `proc_taints` supersede the bare
    // per-function `fu.taints` for the warning families so a tainted argument
    // flowing into a callee parameter and then a sink is reported (cross-proc
    // entry-taint).
    // `trace add variable` / `trace variable` lets a runtime callback rewrite
    // a variable's value in ways static analysis can't see; a name traced
    // anywhere in the module is conservatively treated as tainted everywhere
    // — see `taint::apply_module_variable_traces`.
    let module_traces = crate::compilation_unit::ModuleTraceFacts {
        traced_variables: &cu.ir_module.traced_variables,
        has_dynamic_variable_trace: cu.ir_module.has_dynamic_variable_trace,
        deferred_writes: &cu.ir_module.deferred_writes,
    };
    // `analysable_body_function_units` (not `analysable_functions`) so a sink
    // inside a TclOO method body — or an `apply` lambda / `namespace eval`
    // body — is still checked; see its doc comment.
    for fu in cu.analysable_body_function_units() {
        let taints = crate::taint::apply_module_variable_traces(
            solved.taints_for_function(cu, fu).clone(),
            &fu.ssa,
            module_traces,
        );
        if let Some(shadowed) =
            crate::taint::shadowed_builtin_names_for_module_function(fu, cu, registry)
        {
            let report = crate::taint::taint_warning_report_for_module_function(
                fu,
                &taints,
                &fu.sccp.executable_blocks,
                registry,
                &cu.ir_module,
                &shadowed,
                module_traces,
            );
            taint_replays.merge(report.replays);
            for warning in report.warnings {
                out.push(shift(fu, Diagnostic::from_taint(&warning)));
            }
        } else {
            taint_replays.merge(crate::taint::TaintReplayAnalysis::unavailable());
        }
        // Conditional setter metadata follows the actual source owner.
        for w in find_setter_constraint_warnings_for_module_function(
            fu,
            &cu.ir_module,
            registry,
            &taints,
        ) {
            out.push(shift(fu, Diagnostic::from_taint(&w)));
        }
        if is_irules_dialect(dialect) {
            // IRULE3103 — `*::uri` getter + manual decomposition.
            for w in find_uri_split_suggestions(
                &fu.cfg,
                &fu.ssa,
                Some(&fu.sccp.values),
                &fu.sccp.executable_blocks,
                registry,
                dialect,
            ) {
                out.push(shift(fu, Diagnostic::from_taint(&w)));
            }
        }
        for w in find_path_concat_warnings_for_module_function(fu, &cu.ir_module, registry, &taints)
        {
            out.push(shift(fu, Diagnostic::from_path_concat(&w)));
        }
        // W313: destructive `file` ops on a variable/tainted path.
        for w in
            find_destructive_file_warnings_for_module_function(fu, &cu.ir_module, registry, &taints)
        {
            out.push(shift(fu, Diagnostic::from_taint(&w)));
        }
    }

    // iRules-dialect non-taint (module-level / control-flow) checks.
    push_irules_flow_checks(cu, registry, dialect, generic_patterns, out);
    retain_diagnostic_source_context(cu, registry, &mut out[first..]);
    taint_replays
}

/// Attach complete original issuer inputs after diagnostics have their final
/// whole-document spans. A foreign command store supplies no source currency.
/// This retains provenance, independently of every diagnostic's fix permission.
pub fn retain_diagnostic_source_context(
    cu: &CompilationUnit,
    registry: &CommandRegistry,
    diagnostics: &mut [Diagnostic],
) {
    // Implementation contract: naming.editor.original-diagnostic-edit-currency
    // docs/design/analysis/name-resolution-proofs/original-diagnostic-edit-currency.md
    let context = DiagnosticSourceContext::for_unit(cu, registry);
    for diagnostic in diagnostics {
        let purpose = diagnostic.source_context.as_ref().map_or(
            DiagnosticSourceAuthoringPurpose::OrdinarySourceSubject,
            |current| current.authoring_purpose,
        );
        let previous = diagnostic.source_context.take();
        diagnostic.source_context = context
            .clone()
            .map(|mut current| {
                current.authoring_purpose = purpose;
                current
            })
            .or_else(|| {
                // Preserve a withheld authoring purpose with its original issuer;
                // an unavailable currency refresh must never reset it to Ordinary.
                previous.filter(|previous| {
                    previous.authoring_purpose
                        == DiagnosticSourceAuthoringPurpose::ConditionalSourceNoAction
                })
            });
    }
}

/// Append the iRules-dialect module-level checks (IRULE5002/5004 +
/// IRULE1005-1008/1201/1202/4004).
///
/// Each helper is dialect-gated internally (returns empty for non-iRules
/// dialects), so calling them unconditionally is correct.  Split out of
/// [`run_all_checks`] to keep that aggregator within the line budget.
///
/// The unnormalised-getter warning (IRULE3102) is deliberately *not*
/// aggregated here: the analyser's per-command emitter
/// (`analyser::irules_event_checks`) owns it for the LSP/CLI stream — it
/// anchors on the getter word itself and reaches nested `[…]`
/// substitutions through the nested-segment dispatch.  Emitting the
/// CFG-side scan (`find_unnormalised_getter_warnings`, still used by the
/// compiler explorer's own view) here as well double-reported every site
/// with a second, wider span.
fn push_irules_flow_checks(
    cu: &CompilationUnit,
    registry: &CommandRegistry,
    dialect: Option<&'static tcl_dialect::DialectProfile>,
    generic_patterns: Option<&[String]>,
    out: &mut Vec<Diagnostic>,
) {
    // Every iRules security/flow check receives the resolved availability
    // fact, so an aliased spelling cannot be treated differently by a later
    // pass.
    let dialect = dialect.map(tcl_dialect::DialectProfile::surface_query);
    if let Some(advice) = find_conditional_collection_source_pairing_advice(cu, registry, dialect) {
        if let Some(flow) = advice.conditional_source_flow() {
            for finding in flow.findings() {
                if let Some(diagnostic) =
                    Diagnostic::from_conditional_irule_source_flow(&flow, finding)
                {
                    out.push(diagnostic);
                }
            }
        }
        for pairing in advice.pairings() {
            if let Some(diagnostic) =
                Diagnostic::from_conditional_collection_source_pairing(&advice, pairing)
            {
                out.push(diagnostic);
            }
        }
    }
    for w in find_hoistable_set_warnings(cu, dialect) {
        out.push(Diagnostic::from_irules_check(&w));
    }
    for w in find_generic_static_name_warnings(cu, dialect, generic_patterns) {
        out.push(Diagnostic::from_irules_check(&w));
    }
}

/// Impose a deterministic total order on diagnostics.
///
/// See [`run_all_checks`] — the per-pass producers emit in `HashMap`-iteration
/// order, so a stable sort on `(span, code, category, severity, message,
/// replacement)` is what makes the output byte-identical between the memoised
/// per-procedure build and the whole-module build.
pub fn sort_diagnostics(out: &mut [Diagnostic]) {
    out.sort_by(|a, b| {
        (
            a.span.start(),
            a.span.end(),
            &a.code,
            &a.category,
            a.severity.as_str(),
            &a.message,
            &a.replacement,
        )
            .cmp(&(
                b.span.start(),
                b.span.end(),
                &b.code,
                &b.category,
                b.severity.as_str(),
                &b.message,
                &b.replacement,
            ))
    });
}

#[cfg(test)]
mod tests {
    #[test]
    fn conditional_source_flow_has_no_authoring_subject_or_foreign_entry_membership() {
        let environment = tcl_registry::model::resolve_known_environment("f5-irules").unwrap();
        let context = environment.default_context_registry();
        let config = tcl_lexer::LexerConfig::from_grammar(environment.grammar());
        let input = crate::analyser::ResolvedAnalysisInput::new(
            environment.analyser_profile(),
            environment.unit_profile(),
            context.clone(),
            config,
        );
        let unit = crate::compilation_unit::CompilationUnit::build_with_analysis_input(
            "when HTTP_REQUEST {HTTP::respond 200; HTTP::header insert X yes}",
            crate::compilation_unit::UnitBuildOptions {
                registry: context.commands(),
                defer_top_level: false,
                config,
                dialect: Some(environment.unit_profile()),
                external_call_sites: None,
                declared_commands: None,
            },
            None,
            &input,
        );
        let surface = Some(environment.unit_profile().surface_query());
        let advice =
            super::find_conditional_irule_source_flow_advice(&unit, context.commands(), surface)
                .unwrap();
        let finding = advice
            .findings()
            .iter()
            .find(|finding| finding.code() == super::DiagCode::Irule1201)
            .unwrap();
        let mut diagnostic =
            super::Diagnostic::from_conditional_irule_source_flow(&advice, finding).unwrap();
        assert!(diagnostic.fixes.is_empty() && diagnostic.replacement.is_none());
        let foreign = tcl_registry::model::resolve_known_environment("tcl8.6")
            .unwrap()
            .default_context_registry();
        for registry in [context.commands(), foreign.commands(), context.commands()] {
            super::retain_diagnostic_source_context(
                &unit,
                registry,
                std::slice::from_mut(&mut diagnostic),
            );
            assert!(
                !diagnostic
                    .source_context
                    .as_ref()
                    .unwrap()
                    .allows_context_action_subject()
            );
        }
        let other =
            super::find_conditional_irule_source_flow_advice(&unit, context.commands(), surface)
                .unwrap();
        assert!(super::Diagnostic::from_conditional_irule_source_flow(&other, finding).is_none());
    }

    #[test]
    fn conditional_pairing_authoring_withdrawal_survives_currency_refresh() {
        let environment = tcl_registry::model::resolve_known_environment("f5-irules").unwrap();
        let context = environment.default_context_registry();
        let config = tcl_lexer::LexerConfig::from_grammar(environment.grammar());
        let input = crate::analyser::ResolvedAnalysisInput::new(
            environment.analyser_profile(),
            environment.unit_profile(),
            context.clone(),
            config,
        );
        let unit = crate::compilation_unit::CompilationUnit::build_with_analysis_input(
            "when HTTP_REQUEST {HTTP::payload}",
            crate::compilation_unit::UnitBuildOptions {
                registry: context.commands(),
                defer_top_level: false,
                config,
                dialect: Some(environment.unit_profile()),
                external_call_sites: None,
                declared_commands: None,
            },
            None,
            &input,
        );
        let advice = super::find_conditional_collection_source_pairing_advice(
            &unit,
            context.commands(),
            Some(environment.unit_profile().surface_query()),
        )
        .unwrap();
        let pairing = advice
            .pairings()
            .iter()
            .find(|pairing| pairing.code() == super::DiagCode::Irule1006)
            .unwrap();
        let mut diagnostic =
            super::Diagnostic::from_conditional_collection_source_pairing(&advice, pairing)
                .unwrap();
        assert!(diagnostic.replacement.is_none() && diagnostic.fixes.is_empty());
        assert!(
            !diagnostic
                .source_context
                .as_ref()
                .unwrap()
                .allows_context_action_subject()
        );
        let foreign = tcl_registry::model::resolve_known_environment("tcl8.6")
            .unwrap()
            .default_context_registry();
        for registry in [context.commands(), foreign.commands(), context.commands()] {
            super::retain_diagnostic_source_context(
                &unit,
                registry,
                std::slice::from_mut(&mut diagnostic),
            );
            assert!(
                !diagnostic
                    .source_context
                    .as_ref()
                    .unwrap()
                    .allows_context_action_subject()
            );
        }
        assert!(
            super::DiagnosticSourceContext::for_unit(&unit, context.commands())
                .unwrap()
                .allows_context_action_subject()
        );
        let other_advice = super::find_conditional_collection_source_pairing_advice(
            &unit,
            context.commands(),
            Some(environment.unit_profile().surface_query()),
        )
        .unwrap();
        assert!(
            super::Diagnostic::from_conditional_collection_source_pairing(&other_advice, pairing)
                .is_none()
        );
    }

    use super::*;

    fn registry() -> CommandRegistry {
        let mut r = CommandRegistry::build_default();
        r.load_irules();
        r
    }

    /// A proof-gated O105 is advisory only: hint severity with no
    /// auto-apply payload.  The dispatch-stability site proof licenses the
    /// diagnostic under its declared entry contract; an editor code action
    /// would advertise a stronger observational-safety guarantee than that
    /// proof establishes, so none may be attached until an action-tier proof
    /// exists.
    #[test]
    fn proof_gated_o105_is_a_hint_with_no_auto_fix() {
        let cu = CompilationUnit::build_for_profile(
            "llength {a b}\nllength {a b}",
            &registry(),
            false,
            tcl_registry::model::ingress::resolve_environment("tcl9.0").analyser_profile(),
        );
        let diags = run_all_checks(
            &cu,
            &registry(),
            Some(tcl_registry::model::ingress::resolve_environment("tcl9.0").analyser_profile()),
        );
        let o105: Vec<_> = diags
            .iter()
            .filter(|diagnostic| diagnostic.code.as_str() == "O105")
            .collect();
        assert!(!o105.is_empty(), "the proven replay must be reported");
        for diagnostic in o105 {
            assert_eq!(diagnostic.severity, Severity::Suggestion);
            assert!(diagnostic.replacement.is_none());
            assert_eq!(diagnostic.fixes, [] as [crate::irules_checks::CodeFix; 0]);
        }
    }

    #[test]
    fn shimmer_not_double_counted_in_tcloo_method_body() {
        let src = "oo::class create C {\n    method m {} {\n        ::set x hello\n        ::incr x\n    }\n}\n";
        let cu = CompilationUnit::build_for(src, &registry(), false);
        let diags = run_all_checks(&cu, &registry(), None);
        let s100: Vec<_> = diags.iter().filter(|d| d.code.as_str() == "S100").collect();
        assert_eq!(s100.len(), 1, "expected exactly one S100, got {s100:?}");
    }

    /// Same double-count guard for a `namespace eval` body (the other
    /// synthetic body-unit kind `analysable_body_function_units` reaches).
    #[test]
    fn shimmer_not_double_counted_in_namespace_eval_body() {
        let src = "namespace eval ns {\n    set x hello\n    incr x\n}\n";
        let cu = CompilationUnit::build_for(src, &registry(), false);
        let diags = run_all_checks(&cu, &registry(), None);
        let s100: Vec<_> = diags.iter().filter(|d| d.code.as_str() == "S100").collect();
        assert_eq!(s100.len(), 1, "expected exactly one S100, got {s100:?}");
    }

    #[test]
    fn run_all_checks_on_empty_source_is_empty() {
        let cu = CompilationUnit::build_for("", &registry(), false);
        assert_eq!(
            run_all_checks(&cu, &registry(), None),
            [] as [crate::compiler_checks::Diagnostic; 0]
        );
    }

    /// (FP guard) `my variable count` links an object-instance variable whose
    /// true intrep depends on another method's last write, not the nominal
    /// return type of `my`. Before the registry fix (`oo_my.rs`'s `variable`
    /// subcommand), this spuriously claimed a String->Int shimmer on `incr`.
    #[test]
    fn no_shimmer_for_tcloo_instance_variable_linked_via_my_variable() {
        let src = "oo::class create Counter {\n    method bump {} {\n        my variable count\n        incr count\n    }\n}\n";
        let cu = CompilationUnit::build_for(src, &registry(), false);
        let diags = run_all_checks(&cu, &registry(), None);
        let shimmer: Vec<_> = diags
            .iter()
            .filter(|d| matches!(d.code.as_str(), "S100" | "S101"))
            .collect();
        assert_eq!(
            shimmer.len(),
            0,
            "'my variable'-linked instance var must not spuriously shimmer: {shimmer:?}"
        );
    }

    /// (TN control) The same method body, minus `my variable`, still fires
    /// S100/S101 — proves the guard above is keyed on the scope-alias link,
    /// not a blanket regression of `incr`-on-String detection inside methods.
    #[test]
    fn shimmer_still_fires_in_tcloo_method_without_my_variable() {
        let src = "oo::class create Counter {\n    method bump {} {\n        ::set count hello\n        ::incr count\n    }\n}\n";
        let cu = CompilationUnit::build_for(src, &registry(), false);
        let diags = run_all_checks(&cu, &registry(), None);
        let shimmer: Vec<_> = diags
            .iter()
            .filter(|d| matches!(d.code.as_str(), "S100" | "S101"))
            .collect();
        assert!(
            !shimmer.is_empty(),
            "expected a shimmer for the untraced-and-unlinked case: {diags:?}"
        );
    }

    #[test]
    fn run_all_checks_reports_sccp_constant_branch() {
        let cu =
            CompilationUnit::build_for("if {1} { set x 1 } else { set y 2 }", &registry(), false);
        let diagnostics = run_all_checks(&cu, &registry(), None);
        // SCCP should have flagged the constant-true branch.
        let has_sccp = diagnostics.iter().any(|d| d.category == "sccp");
        assert!(has_sccp, "expected an SCCP diagnostic, got {diagnostics:?}");
    }

    #[test]
    fn shimmer_s100_is_info_s101_is_warning() {
        // S100 — a single shimmer outside any loop is informational.
        let cu = CompilationUnit::build_for("set x \"hello\"\nincr x", &registry(), false);
        let diags = run_all_checks(&cu, &registry(), None);
        let s100 = diags
            .iter()
            .find(|d| d.code == DiagCode::S100)
            .expect("expected an S100 shimmer");
        assert_eq!(s100.severity, Severity::Info, "S100 must be Info: {s100:?}");
        assert_eq!(s100.severity.as_str(), "info");

        // An unknown iterable does not establish its elements' object class.
        // Preserve the original source as a representation-withdrawal control.
        let cu = CompilationUnit::build_for(
            "proc f {l} {\n  foreach x $l {\n    set y [expr {$x + 1}]\n  }\n}\n",
            &registry(),
            false,
        );
        let diags = run_all_checks(&cu, &registry(), None);
        assert!(diags.iter().all(|diag| diag.code != DiagCode::S101));

        // Each reached iteration constructs a List before numeric conversion.
        // All five C releases and current Jim observe List -> Int on this path.
        let environment = tcl_registry::model::ingress::resolve_environment("tcl8.6");
        let native_registry = tcl_registry::model::ingress::static_context_for("tcl8.6").commands();
        let profile = environment.analyser_profile();
        let cu = CompilationUnit::build_for_profile(
            "proc f {item} {foreach i [list $item $item] {set x [list $i]; set y [expr {$x+1}]}}; f 7",
            native_registry,
            false,
            profile,
        );
        let diags = run_all_checks(&cu, native_registry, Some(profile));
        let s101 = diags
            .iter()
            .find(|d| d.code == DiagCode::S101)
            .expect("expected an S101 shimmer");
        assert_eq!(
            s101.severity,
            Severity::Warning,
            "S101 must be Warning: {s101:?}"
        );
    }

    #[test]
    fn diagnostic_from_redundant_preserves_code() {
        let r = crate::gvn::RedundantComputation::new(
            Span::new(0, 5),
            Span::new(10, 15),
            "llength $x",
            DiagCode::O105,
            "msg",
        );
        let d = Diagnostic::from_redundant(&r);
        assert_eq!(d.code, DiagCode::O105);
        assert_eq!(d.category, "gvn");
    }

    #[test]
    fn run_all_checks_reports_irule3001_end_to_end() {
        let profile = tcl_dialect::DialectProfile::irules();
        let registry = registry().project_for_profile(profile);
        let cu = CompilationUnit::build_for_profile(
            "set u [HTTP::uri]\nHTTP::respond 200 content $u",
            &registry,
            false,
            profile,
        )
        .with_interprocedural(&registry, Some(profile));
        let diagnostics = run_all_checks(&cu, &registry, Some(profile));
        assert!(
            diagnostics
                .iter()
                .any(|d| d.code == DiagCode::Irule3001 && d.category == "taint"),
            "expected IRULE3001, got {diagnostics:?}",
        );
    }

    #[test]
    fn run_all_checks_reports_irule3101_end_to_end() {
        let cu = CompilationUnit::build_for("HTTP::uri foo", &registry(), false)
            .with_interprocedural(&registry(), Some(tcl_dialect::DialectProfile::irules()));
        let diagnostics = run_all_checks(
            &cu,
            &registry(),
            Some(tcl_dialect::DialectProfile::irules()),
        );
        assert!(
            diagnostics
                .iter()
                .any(|d| d.code == DiagCode::Irule3101 && d.category == "taint"),
            "expected IRULE3101, got {diagnostics:?}",
        );
    }

    #[test]
    fn run_all_checks_reports_s110_payload_roundtrip_end_to_end() {
        let profile = tcl_dialect::DialectProfile::irules();
        let registry = registry().project_for_profile(profile);
        let cu = CompilationUnit::build_for_profile(
            "when CLIENT_DATA {\n  set p [TCP::payload]\n  set q [string map {a b} $p]\n  \
             TCP::payload replace 0 100 $q\n}",
            &registry,
            false,
            profile,
        )
        .with_interprocedural(&registry, Some(profile));
        let diagnostics = run_all_checks(&cu, &registry, Some(profile));
        let hit = diagnostics
            .iter()
            .find(|d| d.code == DiagCode::S110)
            .unwrap_or_else(|| panic!("expected S110, got {diagnostics:?}"));
        assert_eq!(hit.category, "shimmer");
        assert_eq!(hit.severity, Severity::Warning, "S110 must be a Warning");
    }

    /// Under a non-iRules dialect the `*::payload` layout set is empty, so a
    /// plain-Tcl document that merely names a `*::payload` command is silent.
    #[test]
    fn run_all_checks_s110_silent_outside_irules_dialect() {
        let src = "proc f {} {\n  set p [TCP::payload]\n  set q [string map {a b} $p]\n  \
                   TCP::payload replace 0 100 $q\n}";
        let cu = CompilationUnit::build_for(src, &registry(), false);
        let diagnostics = run_all_checks(&cu, &registry(), None);
        assert!(
            diagnostics.iter().all(|d| d.code != DiagCode::S110),
            "S110 must not fire under plain Tcl: {diagnostics:?}"
        );
    }

    #[test]
    fn run_all_checks_does_not_double_report_irule3102() {
        // IRULE3102 ownership: the analyser's per-command emitter
        // (`analyser::irules_event_checks`) reports it for the LSP/CLI
        // stream with a tight getter-word anchor; aggregating the CFG-side
        // scan here as well double-reported every site with a second,
        // wider span. `run_all_checks` must therefore stay silent — the
        // analyser end-to-end assertion lives alongside.
        let cu = CompilationUnit::build_for("set u [HTTP::uri]", &registry(), false)
            .with_interprocedural(&registry(), Some(tcl_dialect::DialectProfile::irules()));
        let diagnostics = run_all_checks(
            &cu,
            &registry(),
            Some(tcl_dialect::DialectProfile::irules()),
        );
        assert!(
            diagnostics.iter().all(|d| d.code != DiagCode::Irule3102),
            "run_all_checks must not double-report IRULE3102: {diagnostics:?}"
        );

        // The analyser stream owns the code (single, tight instance).
        let mut analyser = crate::analyser::Analyser::new();
        let result = analyser.analyse(
            "when HTTP_REQUEST {\n    set u [HTTP::uri]\n}\n",
            "f5-irules",
        );
        let hits: Vec<_> = result
            .diagnostics
            .iter()
            .filter(|d| d.code == DiagCode::Irule3102)
            .collect();
        assert_eq!(
            hits.len(),
            1,
            "the analyser stream reports IRULE3102 exactly once: {:?}",
            result.diagnostics
        );
    }

    #[test]
    fn run_all_checks_irule3101_gated_by_dialect() {
        // Regression: `HTTP::uri foo` is a non-slash-prefixed literal.
        // Under `f5-irules` it should warn with IRULE3101; under plain
        // Tcl it must stay silent (user-defined proc named "HTTP::uri"
        // must not trigger a high-severity error).
        let src = "HTTP::uri foo";

        let irules_cu = CompilationUnit::build_for(src, &registry(), false)
            .with_interprocedural(&registry(), Some(tcl_dialect::DialectProfile::irules()));
        let irules_diags = run_all_checks(
            &irules_cu,
            &registry(),
            Some(tcl_dialect::DialectProfile::irules()),
        );
        assert!(
            irules_diags.iter().any(|d| d.code == DiagCode::Irule3101),
            "expected IRULE3101 under f5-irules dialect, got {irules_diags:?}",
        );

        let plain_cu = CompilationUnit::build_for(src, &registry(), false);
        let plain_diags = run_all_checks(&plain_cu, &registry(), None);
        assert!(
            plain_diags.iter().all(|d| d.code != DiagCode::Irule3101),
            "no IRULE3101 without dialect, got {plain_diags:?}",
        );
    }

    #[test]
    fn run_all_checks_irule_codes_gated_by_dialect() {
        let cu = CompilationUnit::build_for(
            "set u [HTTP::uri]\nHTTP::respond 200 content $u",
            &registry(),
            false,
        );
        let diagnostics = run_all_checks(&cu, &registry(), None);
        assert!(
            diagnostics
                .iter()
                .all(|d| !d.code.as_str().starts_with("IRULE")),
            "no IRULE diagnostics without dialect, got {diagnostics:?}",
        );
    }

    #[test]
    fn run_all_checks_reports_w201_path_concat() {
        let src = "set x 42\nset p \"/tmp/$x\"";
        let cu = CompilationUnit::build_for(src, &registry(), false);
        let diagnostics = run_all_checks(&cu, &registry(), None);
        let w201 = diagnostics
            .iter()
            .find(|d| d.code == DiagCode::W201 && d.category == "taint")
            .unwrap_or_else(|| panic!("expected W201 path-concat diagnostic, got {diagnostics:?}"));
        // The `[file join …]` suggestion must survive the lowering
        // from `PathConcatWarning` to `Diagnostic`.
        let replacement = w201
            .replacement
            .as_deref()
            .expect("W201 diagnostic should carry a [file join] replacement");
        assert!(
            replacement.starts_with("[file join /tmp ") && replacement.ends_with(']'),
            "unexpected replacement text: {replacement:?}",
        );
        // The replacement is also lifted into a same-span quick fix that
        // replaces exactly the quoted value word.
        assert_eq!(w201.fixes.len(), 1, "expected one fix: {:?}", w201.fixes);
        let fix = &w201.fixes[0];
        assert_eq!(fix.description, "Rewrite with `file join`");
        assert_eq!(fix.new_text, replacement);
        assert_eq!(fix.span, w201.span);
        assert_eq!(
            &src[fix.span.start() as usize..fix.span.end() as usize],
            "\"/tmp/$x\"",
            "the fix span must cover exactly the value word",
        );
    }
}
