// tcl-lsp — a language server and toolchain for Tcl
// Copyright (C) 2026 James Deucker (bitwisecook) <https://github.com/bitwisecook>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.
//
// SPDX-License-Identifier: AGPL-3.0-or-later

//! Expression-level shimmer detection (S100).
//!
//! `[expr]` arithmetic operators require numeric operands; string
//! comparison operators (`eq`, `ne`, `lt`, `le`, `gt`, `ge`) require
//! string values.  Using a value of the wrong type in an expression
//! forces a silent intrep conversion:
//!
//! - A `String` variable in an arithmetic binary op (`+`, `-`, `*`, …)
//!   → `String → Int/Double` shimmer.
//! - An `Int` or `Double` variable in a string comparison op (`eq`, `ne`,
//!   `lt`, `le`, `gt`, `ge`) → `Int/Double → String` shimmer.
//!
//! This pass walks every [`Statement::AssignExpr`] and
//! [`Statement::ExprEval`] in every SCCP-executable block and recurses
//! into the expression AST looking for such mismatches.

use std::collections::{HashMap, HashSet};
use tcl_core_types::DiagCode;

use tcl_lexer::Span;
use tcl_registry::TclType;

use crate::analyses::LatticeValue;
use crate::cfg::{BlockId, Function as CfgFunction, Terminator};
use crate::depth_guard::MAX_EXPR_NODE_DEPTH;
use crate::expr_ast::{BinOp, ExprNode};
use crate::ir::Statement;
use crate::sccp::cfg_order;
use crate::ssa::{SsaFunction, Symbol, ValueKey};
use crate::types::{TypeKind, TypeLattice};

use super::ShimmerWarning;
use super::hints::is_free_first_conversion;

/// Find expression-level shimmer warnings for a function.
///
/// Covers two expression sites:
/// 1. **`AssignExpr` / `ExprEval` statements** — `set x [expr {…}]` and
///    standalone `expr {…}`.
/// 2. **`Terminator::Branch` conditions** — the predicate of every
///    `if`/`while`/`for` construct.  Variable versions are resolved from
///    the retained actual source reference, including changes performed by
///    an earlier substitution in the same expression.
#[must_use]
pub(crate) fn find_expr_shimmers_with_context(
    cfg: &CfgFunction,
    commit_ctx: &super::commit::CommitCtx<'_>,
    (executable_blocks, in_force): (
        &HashSet<BlockId>,
        &HashMap<(BlockId, ValueKey), TypeLattice>,
    ),
    facts: &super::ShimmerFacts,
) -> Vec<ShimmerWarning> {
    let super::commit::CommitCtx {
        registry: _,
        context,
        ssa,
        source: _,
        types,
        values,
        folded,
    } = *commit_ctx;
    let mut out = Vec::new();
    let loop_blocks = &facts.loop_blocks;

    for block_id in cfg_order(cfg) {
        if !executable_blocks.contains(&block_id) {
            continue;
        }
        let Some(ssa_block) = ssa.blocks.get(&block_id) else {
            continue;
        };
        // An expr-operator shimmer inside a loop body re-converts the operand
        // every iteration (S101); outside a loop it is one-time (S100).
        let in_loop = loop_blocks.contains(cfg.block_name(block_id));
        // Per-block de-duplication keyed on (statement span, variable): several
        // operands of the same statement that name the same variable emit one
        // warning, not one per operand.
        let mut seen: HashSet<(Span, String)> = HashSet::new();
        // The committed-intrep walker replays the commit transfer in step with
        // this walk, so each expr's operands see the state just before it.
        let mut commit_walker = facts.commit.walker(commit_ctx, block_id);
        let block_types = super::BlockTypes::at(types, in_force, block_id);

        // 1. SSA statements: AssignExpr and ExprEval.
        for (index, ss) in ssa_block.statements.iter().enumerate() {
            match &ss.statement {
                Statement::AssignExpr {
                    expr,
                    span,
                    expr_base,
                    ..
                }
                | Statement::ExprEval {
                    expr,
                    span,
                    expr_base,
                    ..
                } => {
                    let mut ctx = ExprShimmerCtx {
                        types: block_types,
                        values,
                        source: crate::ssa::SsaSourceView::at_statement(ssa, block_id, index),
                        folded,
                        commit: &commit_walker,
                        stmt_span: *span,
                        expr_base: *expr_base,
                        executed_source: None,
                        in_loop,
                        seen: &mut seen,
                        out: &mut out,
                    };
                    collect_expr_shimmers(&mut ctx, expr, 0);
                }
                // An `[expr …]` written inside another command's word, such as
                // `puts [expr {$d % 2}]`. The lowerer turns a *statement* `expr`
                // into the node above but leaves a nested one as opaque
                // argument text,
                // so it is lifted and parsed here (see [`crate::word_subst`]).
                // Operands retain the nested expression's original source base
                // and each read's actual place/version snapshot.
                //
                // Both statement kinds that carry substitutable words are
                // lifted, for the reason the arm exists at all: the outer
                // command decides nothing about what Tcl evaluates inside a
                // word, so `set r [list [expr {0 in $x}]]` runs the same
                // expression as `puts [list [expr {0 in $x}]]`. Only the
                // Lifting only the `Call` half would leave the assignment
                // spelling reporting nothing. A `set x [expr {…}]` whose
                // value word *is* the substitution never reaches here — the
                // lowerer already made it the `AssignExpr` above — so the two
                // arms cannot both report the same expression.
                Statement::Call { tokens, .. } | Statement::AssignValue { tokens, .. } => {
                    let mut expressions = context.lifted_expressions(tokens.as_ref());
                    if matches!(ss.statement, Statement::Call { .. })
                        && let Some(tokens) = tokens
                        && let Some(expression) = context.expression(tokens, ss.statement.span())
                    {
                        expressions.push(expression);
                    }
                    for lifted in expressions {
                        let mut ctx = ExprShimmerCtx {
                            types: block_types,
                            values,
                            source: crate::ssa::SsaSourceView::at_statement(ssa, block_id, index),
                            folded,
                            commit: &commit_walker,
                            // The substitution's own extent, so the report
                            // points at `[expr …]` rather than the whole
                            // enclosing command.
                            stmt_span: lifted.span,
                            expr_base: lifted.expression_base,
                            executed_source: lifted.executed_source.as_ref(),
                            in_loop,
                            seen: &mut seen,
                            out: &mut out,
                        };
                        collect_expr_shimmers(&mut ctx, &lifted.expression, 0);
                    }
                }
                _ => {}
            }
            commit_walker.step(&ss.statement, &ss.uses);
        }

        // 2. Terminator expressions: an `if`/`while`/`for` predicate, and a
        //    `return [expr {…}]` value.
        collect_terminator_shimmers(
            &mut TerminatorWalk {
                cfg,
                ssa,
                types: block_types,
                values,
                folded,
                block_id,
                commit: &commit_walker,
                in_loop,
            },
            &mut seen,
            &mut out,
        );
    }

    out
}

/// Everything one block's terminator walk needs that is constant across it.
struct TerminatorWalk<'a> {
    cfg: &'a CfgFunction,
    ssa: &'a SsaFunction,
    /// The type lattice as the block reads it.
    types: super::BlockTypes<'a>,
    values: &'a HashMap<ValueKey, LatticeValue>,
    folded: &'a HashMap<ValueKey, crate::value_transfer::FoldedType>,
    block_id: BlockId,
    /// The versions in scope when a terminator is evaluated — after every
    /// statement of its block has run.
    commit: &'a super::commit::CommitWalker<'a>,
    in_loop: bool,
}

/// Walk the expression a block's terminator evaluates, if it has one.
///
/// Both arms are expressions Tcl evaluates in this frame, so both are walked
/// on the same terms as a statement `expr`. Without the `return` arm,
/// `expr {$u0 * $dx}` as a statement is
/// walked while `return [expr {$u0 * $dx}]` is not, so the same expression
/// reported differently depending only on its position. The lowerer already
/// parses it onto `Terminator::Return::expr`, and leaves that `None` for the
/// braced `return {[expr …]}` that Tcl never evaluates, so reading it is both
/// free and exact.
fn collect_terminator_shimmers(
    walk: &mut TerminatorWalk<'_>,
    seen: &mut HashSet<(Span, String)>,
    out: &mut Vec<ShimmerWarning>,
) {
    let Some(terminator) = walk
        .cfg
        .blocks
        .get(&walk.block_id)
        .and_then(|b| b.terminator.as_ref())
    else {
        return;
    };
    // Both branches and returned expressions retain the parser's original
    // expression base, so positioned reads use their actual source extent.
    let (expr, span, expr_base) = match terminator {
        Terminator::Branch {
            condition,
            span,
            condition_base,
            ..
        } => (condition, *span, *condition_base),
        Terminator::Return {
            expr: Some(expr),
            span,
            expr_base,
            ..
        } => (expr, *span, *expr_base),
        _ => return,
    };
    let mut ctx = ExprShimmerCtx {
        types: walk.types,
        values: walk.values,
        source: crate::ssa::SsaSourceView::at_terminator(walk.ssa, walk.block_id),
        folded: walk.folded,
        commit: walk.commit,
        stmt_span: span.unwrap_or_else(|| Span::new(0, 0)),
        expr_base,
        executed_source: None,
        in_loop: walk.in_loop,
        seen,
        out,
    };
    collect_expr_shimmers(&mut ctx, expr, 0);
}

/// Read-only context + warning sinks threaded through one expr walk.
///
/// `source` / `stmt_span` / `in_loop` are constant for a single
/// `collect_expr_shimmers` recursion (they describe the statement whose expr
/// is being walked); `seen` / `out` accumulate de-duplicated warnings.
struct ExprShimmerCtx<'a> {
    /// The type lattice as the block reads it.
    types: super::BlockTypes<'a>,
    /// SCCP constant values, for the uncommitted-value ("pure string") check —
    /// a pure operand that is a valid instance of the required type converts for
    /// free, so it must not be flagged (see [`is_free_first_conversion`]).
    values: &'a HashMap<ValueKey, LatticeValue>,
    source: crate::ssa::SsaSourceView<'a>,
    folded: &'a HashMap<ValueKey, crate::value_transfer::FoldedType>,
    /// Committed-intrep state just before this statement ([`super::commit`]) —
    /// an operand whose value already committed a different intrep on every
    /// path genuinely re-represents here even when the lattice sees no
    /// mismatch.
    commit: &'a super::commit::CommitWalker<'a>,
    stmt_span: Span,
    /// Absolute source offset of the expression text's first byte, when it
    /// is a verbatim source slice (see [`crate::ir::IfClause::condition_base`]).
    /// Maps AST leaf offsets to absolute operand spans; `None` falls back to
    /// anchoring at `stmt_span`.
    expr_base: Option<u32>,
    executed_source: Option<&'a crate::command_binding::ExecutedExpressionSource>,
    in_loop: bool,
    seen: &'a mut HashSet<(Span, String)>,
    out: &'a mut Vec<ShimmerWarning>,
}

impl ExprShimmerCtx<'_> {
    fn representation_cost(
        &self,
        node: &ExprNode,
        semantic: TclType,
        expected: TclType,
    ) -> Option<super::commit::RepresentationCost> {
        self.commit.cost_for_expression(
            self.source,
            node,
            super::commit::ExpressionCostOrigin {
                base: self.expr_base,
                executed: self.executed_source,
            },
            self.read_variable(node)?,
            semantic,
            expected,
        )
    }

    fn read_variable(&self, node: &ExprNode) -> Option<crate::ssa::SsaReadReference> {
        if let Some(source) = self.executed_source {
            self.source.read_executed_expression_variable(node, source)
        } else {
            self.source.read_expression_variable(node, self.expr_base)
        }
    }

    /// The representation the evaluation that produced `(sym, ver)` states
    /// it constructed, when it says.
    fn representation(
        &self,
        sym: Symbol,
        ver: u32,
    ) -> tcl_registry::value_transfer::RepresentationEvidence {
        self.folded.get(&(sym, ver)).map_or(
            tcl_registry::value_transfer::RepresentationEvidence::Unknown,
            |folded| folded.representation,
        )
    }

    /// The span a shimmer on `node` anchors to: the operand's own source
    /// range when the expression text is verbatim-anchored (the leaf's
    /// mapped by the native variable extent owner), else the whole statement.
    fn operand_span(&self, node: &ExprNode) -> Span {
        if let Some(source) = self.executed_source {
            return source
                .variable_source(node)
                .map_or(self.stmt_span, |(_, source)| source.span);
        }
        if let Some(base) = self.expr_base
            && let Some(span) = node.variable_source_span(base, self.commit.config())
        {
            return span;
        }
        self.stmt_span
    }
}

fn collect_expr_shimmers(ctx: &mut ExprShimmerCtx<'_>, node: &ExprNode, depth: u32) {
    // Native-stack safety net: walks the `ExprNode` tree, one
    // native frame per level. Past the cap, stop descending — a collector
    // that returns the shimmer warnings gathered so far is the safe fallback
    // (operands buried deeper than the cap go unflagged; never a crash).
    if MAX_EXPR_NODE_DEPTH.exceeded(depth) {
        return;
    }
    match node {
        ExprNode::Binary {
            op, left, right, ..
        } => {
            // Recurse into children first.
            collect_expr_shimmers(ctx, left, depth + 1);
            collect_expr_shimmers(ctx, right, depth + 1);

            match op {
                // Arithmetic, bitwise, and shift operators are an unconditional
                // numeric context with NO string fallback: Tcl reads each
                // operand with `Tcl_GetNumberFromObj`, which on success installs
                // the numeric intrep in place (clobbering String/List/Dict/
                // ByteArray) and on failure raises — so on any path that
                // executes without error, the shimmer really happened.
                BinOp::Add | BinOp::Sub | BinOp::Mul | BinOp::Div | BinOp::Pow => {
                    check_numeric_operand(ctx, left, *op, NumericContext::Arithmetic);
                    check_numeric_operand(ctx, right, *op, NumericContext::Arithmetic);
                }

                // The integer-only half of that set. `%`, the shifts and the
                // bitwise operators read their operands the same way but then
                // reject a `TCL_NUMBER_DOUBLE` outright, so their expectation
                // is `Int`, not the `Numeric` join — tclsh 8.6.16 / 9.0.4
                // verified for all six: `set d [expr {1.0 + 1.5}]` then
                // `expr {$d % 2}` raises `can't use floating-point value as
                // operand of "%"`, and likewise for `<<`, `>>`, `&`, `|`, `^`.
                // Lumping them in with the arithmetic operators made a
                // double operand look compatible once `Double` joined the
                // numeric class.
                BinOp::Mod
                | BinOp::LShift
                | BinOp::RShift
                | BinOp::BitAnd
                | BinOp::BitOr
                | BinOp::BitXor => {
                    check_numeric_operand(ctx, left, *op, NumericContext::Integer);
                    check_numeric_operand(ctx, right, *op, NumericContext::Integer);
                }

                // `&&`/`||` are a boolean context, not arithmetic
                // (`tclExecute.c` INST_LOR/INST_LAND use `TclGetBooleanFromObj`)
                // — but like arithmetic it has no string fallback: the operand's
                // intrep is replaced by a boolean/numeric one on success and the
                // command errors otherwise, so flagging a non-numeric intrep is
                // still sound. Only the wording and target type differ.
                BinOp::And | BinOp::Or => {
                    check_numeric_operand(ctx, left, *op, NumericContext::Boolean);
                    check_numeric_operand(ctx, right, *op, NumericContext::Boolean);
                }

                // `in`/`ni` convert the RIGHT operand to a list
                // (`TclListObjGetElements`) — a genuine intrep replacement for
                // a String/Dict/ByteArray value (tclsh-verified:
                // `expr {"b" in $L}` with a string-typed `$L` installs the
                // list intrep). The needle is read as a string (intrep kept).
                BinOp::In | BinOp::Ni => {
                    check_list_operand(ctx, right, *op);
                }

                // String comparison operators: operands should be String.
                // No rewrite to the numeric equivalent (eq→==, ne→!=, lt→<,
                // le→<=, gt→>, ge→>=) is ever offered — `eq`/`ne`/`lt`/…
                // always compare the operands' *string* representations,
                // never their numeric value, so the two families disagree
                // whenever the string forms don't sort/compare the same way
                // as the numbers they denote (`"10" lt "2"` is true
                // lexicographically but `10 < 2` is false; `"1.0" eq "1"` is
                // false but `1.0 == 1` is true). "Both operands are numeric"
                // does not make the rewrite safe, so only the informational
                // warning fires.
                BinOp::StrEq
                | BinOp::StrNe
                | BinOp::StrLt
                | BinOp::StrLe
                | BinOp::StrGt
                | BinOp::StrGe => {
                    check_string_operand(ctx, left, *op);
                    check_string_operand(ctx, right, *op);
                }

                // Everything else — notably the comparisons, both ordering
                // (`<`/`<=`/`>`/`>=`) and equality (`==`/`!=`) — is NOT
                // flagged. C Tcl probes each comparison operand with
                // `GetNumberFromObj` *without* generating a string rep and
                // falls back to a string comparison (both intreps kept) when
                // either operand is non-numeric; an operand's intrep is
                // replaced only when its OWN string happens to parse as a
                // number, which a static type cannot prove (verified on tclsh
                // 8.6: `expr {5 == $L}` with `$L` a list keeps the list
                // intrep; `expr {$s <= 5}` with `$s` = "hello" keeps
                // `string`). Flagging on "the sibling operand looks numeric"
                // was a verified false-positive class; the S102 flip-flop
                // detection still catches genuinely alternating intreps.
                _ => {}
            }
        }

        ExprNode::Unary { operand, .. } => {
            collect_expr_shimmers(ctx, operand, depth + 1);
        }

        ExprNode::Ternary {
            condition,
            true_branch,
            false_branch,
            ..
        } => {
            collect_expr_shimmers(ctx, condition, depth + 1);
            collect_expr_shimmers(ctx, true_branch, depth + 1);
            collect_expr_shimmers(ctx, false_branch, depth + 1);
        }

        _ => {}
    }
}

/// Which no-string-fallback expr context a flagged operand sits in — decides
/// the diagnostic's wording and target type, not whether it fires.
#[derive(Clone, Copy)]
enum NumericContext {
    /// `+`/`-`/`*`/`/`/`**` — `Tcl_GetNumberFromObj`, intrep becomes
    /// Int/Double.
    Arithmetic,
    /// `%`/`<<`/`>>`/`&`/`|`/`^` — read the same way, but a double is then
    /// rejected rather than accepted, so the expectation is `Int`.
    Integer,
    /// `&&`/`||` — `TclGetBooleanFromObj`, intrep becomes Boolean (or numeric).
    Boolean,
}

/// Emit a shimmer if `node` is a variable reference with a non-numeric
/// type used in a numeric/boolean coercion context.  The code is S101 inside
/// a loop body (per-iteration conversion) and S100 outside one.
fn check_numeric_operand(
    ctx: &mut ExprShimmerCtx<'_>,
    node: &ExprNode,
    op: BinOp,
    context: NumericContext,
) {
    let ExprNode::Var { text, .. } = node else {
        return;
    };
    let base = crate::naming::element_var_name(text);
    let Some(read) = ctx.read_variable(node) else {
        return;
    };
    let sym = read.symbol;
    let Some(ver) = read.version else {
        return;
    };
    if ver == 0 {
        return;
    }
    let lattice = ctx
        .types
        .get((sym, ver))
        .cloned()
        .unwrap_or_else(TypeLattice::unknown);
    if lattice.kind() != TypeKind::Known {
        return;
    }
    let Some(current) = lattice.tcl_type() else {
        return;
    };
    let (to_type, context_name) = match context {
        NumericContext::Arithmetic => (TclType::Numeric, "arithmetic expression"),
        NumericContext::Integer => (TclType::Int, "integer-only expression"),
        NumericContext::Boolean => (TclType::Boolean, "boolean context"),
    };
    let Some(cost) = ctx.representation_cost(node, current, to_type) else {
        return;
    };
    let current = cost.current;
    // A prior use that committed a non-numeric intrep on every path makes this
    // operand a genuine second conversion (`set v 5; llength $v; expr {$v+1}`
    // re-represents List → Numeric) — even where the lattice type is numeric.
    let commit_state = cost.commitment;
    // Otherwise only flag clearly non-numeric types (String, List, Dict,
    // ByteArray). A byte array in an arithmetic context is a textbook C Tcl
    // shimmer: Tcl has no numeric intrep of its own, so `Tcl_GetNumberFromObj`
    // falls back to parsing the byte array's *string* rep (each byte
    // relabelled as a Latin-1 code point) as a number and, on success,
    // replaces the cached byte-array intrep with Int/Double — exactly the same
    // in-place intrep clobber as the String/List/Dict cases, just via the
    // byte-array route.
    let lattice_flags = matches!(
        current,
        TclType::String | TclType::List | TclType::Dict | TclType::ByteArray
    );
    if !commit_state.must_pay(to_type) {
        if !lattice_flags {
            return;
        }
        // A pure (uncommitted) operand whose value is a valid number / boolean
        // converts for free: `set s [string trim true]; expr {$s && 1}` and a
        // numeric-valued string in arithmetic are not shimmers. A committed
        // List/Dict/ByteArray, or a pure string that is not a valid instance
        // (`set s hello; expr {$s + 1}`), still fires.
        if is_free_first_conversion(
            current,
            to_type,
            ctx.values.get(&(sym, ver)),
            ctx.representation(sym, ver),
            ctx.commit.numbers(),
            ctx.commit.word_rules(),
        ) {
            return;
        }
    }
    let (from, from_label) = super::committed_from_label(&commit_state, current, to_type);
    // De-duplicate per (statement span, variable) within the block.
    if !ctx.seen.insert((ctx.stmt_span, base.to_owned())) {
        return;
    }
    let code = if ctx.in_loop {
        DiagCode::S101
    } else {
        DiagCode::S100
    };
    ctx.out.push(ShimmerWarning {
        span: ctx.operand_span(node),
        variable: base.to_owned(),
        from_type: from,
        to_type,
        command: format!("expr:{op:?}"),
        in_loop: ctx.in_loop,
        code,
        message: format!(
            "variable '{base}' has {from_label} intrep used in {context_name} \
             (operand of '{op}')",
        ),
        related: Vec::new(),
    });
}

/// Emit a shimmer for the RIGHT operand of `in`/`ni` when its type shows an
/// intrep that list conversion replaces (String/Dict/ByteArray → List). A
/// List-typed operand is already there; numeric intreps regenerate a string
/// then parse, which is the same replacement, but a single number is a
/// one-element list conversion so cheap it is not worth a warning.
fn check_list_operand(ctx: &mut ExprShimmerCtx<'_>, node: &ExprNode, op: BinOp) {
    let ExprNode::Var { text, .. } = node else {
        return;
    };
    let base = crate::naming::element_var_name(text);
    let Some(read) = ctx.read_variable(node) else {
        return;
    };
    let sym = read.symbol;
    let Some(ver) = read.version else {
        return;
    };
    if ver == 0 {
        return;
    }
    let lattice = ctx
        .types
        .get((sym, ver))
        .cloned()
        .unwrap_or_else(TypeLattice::unknown);
    if lattice.kind() != TypeKind::Known {
        return;
    }
    let Some(current) = lattice.tcl_type() else {
        return;
    };
    let Some(cost) = ctx.representation_cost(node, current, TclType::List) else {
        return;
    };
    let current = cost.current;
    // A prior use that committed a non-list intrep on every path makes this
    // membership test a genuine second conversion (`expr {$v+1}` then
    // `expr {"b" in $v}` re-represents Numeric → List).
    let commit_state = cost.commitment;
    let lattice_flags = matches!(
        current,
        TclType::String | TclType::Dict | TclType::ByteArray
    );
    if !commit_state.must_pay(TclType::List) {
        if !lattice_flags {
            return;
        }
        // A pure string is a free first conversion to a list — `set hay [string
        // trim "a b c"]; expr {"b" in $hay}` parses it once, losslessly (oracle:
        // the value goes pure → list). Only a committed Dict/ByteArray genuinely
        // re-represents on the `in` list conversion.
        if is_free_first_conversion(
            current,
            TclType::List,
            ctx.values.get(&(sym, ver)),
            ctx.representation(sym, ver),
            ctx.commit.numbers(),
            ctx.commit.word_rules(),
        ) {
            return;
        }
    }
    let (from, from_label) = super::committed_from_label(&commit_state, current, TclType::List);
    if !ctx.seen.insert((ctx.stmt_span, base.to_owned())) {
        return;
    }
    let code = if ctx.in_loop {
        DiagCode::S101
    } else {
        DiagCode::S100
    };
    ctx.out.push(ShimmerWarning {
        span: ctx.stmt_span,
        variable: base.to_owned(),
        from_type: from,
        to_type: TclType::List,
        command: format!("expr:{op:?}"),
        in_loop: ctx.in_loop,
        code,
        message: format!(
            "variable '{var}' has {from_label} intrep converted to a list by \
             '{op_word}' membership",
            var = base,
            op_word = if matches!(op, BinOp::In) { "in" } else { "ni" },
        ),
        related: Vec::new(),
    });
}

/// Emit a shimmer if `node` is a numeric variable used in a string
/// comparison.  S101 inside a loop body, S100 outside one.
///
/// No `CodeFix` is ever attached: `eq`/`ne`/`lt`/`le`/`gt`/`ge` compare the
/// operands' string representations, never their numeric value, so no
/// rewrite to the numeric-equivalent operator is generally safe — see the
/// `BinOp::StrEq | …` match arm's doc comment in [`collect_expr_shimmers`].
fn check_string_operand(ctx: &mut ExprShimmerCtx<'_>, node: &ExprNode, op: BinOp) {
    let ExprNode::Var { text, .. } = node else {
        return;
    };
    let base = crate::naming::element_var_name(text);
    let Some(read) = ctx.read_variable(node) else {
        return;
    };
    let sym = read.symbol;
    let Some(ver) = read.version else {
        return;
    };
    if ver == 0 {
        return;
    }
    let lattice = ctx
        .types
        .get((sym, ver))
        .cloned()
        .unwrap_or_else(TypeLattice::unknown);
    if lattice.kind() != TypeKind::Known {
        return;
    }
    let Some(current) = lattice.tcl_type() else {
        return;
    };
    let Some(cost) = ctx.representation_cost(node, current, TclType::String) else {
        return;
    };
    let current = cost.current;
    // A numeric variable in a string comparison does NOT lose its intrep —
    // `TclStringCmp` reads the string reps, which are generated once and
    // cached *alongside* the numeric intrep (dual-porting; tclsh-verified:
    // `set x 42; expr {$x eq "42"}` leaves `x` an int). So this is a
    // likely-intent hint (`eq` on numbers is usually a typo for `==`), not a
    // conversion cost: it stays S100 even inside a loop — the S101
    // "per-iteration cost" escalation would claim a cost that is paid at
    // most once — and the wording claims no representation change.
    if matches!(
        current,
        TclType::Int | TclType::Double | TclType::Numeric | TclType::Boolean
    ) {
        // De-duplicate per (statement span, variable) within the block.
        if !ctx.seen.insert((ctx.stmt_span, base.to_owned())) {
            return;
        }
        let numeric_op = numeric_equivalent(op);
        ctx.out.push(ShimmerWarning {
            span: ctx.operand_span(node),
            variable: base.to_owned(),
            from_type: current,
            to_type: TclType::String,
            command: format!("expr:{op:?}"),
            in_loop: ctx.in_loop,
            code: DiagCode::S100,
            message: format!(
                "numeric variable '{base}' compared as a string ('{op}') — the \
                 numeric intrep is kept (a string rep is cached alongside); if \
                 a numeric comparison was intended, use '{numeric_op}' instead"
            ),
            related: Vec::new(),
        });
    }
}

/// The numeric-comparison equivalent of a string-comparison `BinOp`, used
/// only for the diagnostic's hint text — not a suggestion that the rewrite
/// is behaviourally equivalent. Panics on any other variant — only ever
/// called with `BinOp::Str{Eq,Ne,Lt,Le,Gt,Ge}` from
/// [`check_string_operand`]'s single call site.
fn numeric_equivalent(op: BinOp) -> &'static str {
    match op {
        BinOp::StrEq => "==",
        BinOp::StrNe => "!=",
        BinOp::StrLt => "<",
        BinOp::StrLe => "<=",
        BinOp::StrGt => ">",
        BinOp::StrGe => ">=",
        _ => unreachable!("numeric_equivalent called with a non-string-comparison BinOp"),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::compilation_unit::CompilationUnit;
    use tcl_registry::CommandRegistry;

    fn registry() -> CommandRegistry {
        CommandRegistry::build_default()
    }

    /// Compute commit facts + run the expr detector for one function unit —
    /// the production wiring `find_shimmer_warnings` performs.
    fn expr_shimmers(
        fu: &crate::compilation_unit::FunctionUnit,
        registry: &CommandRegistry,
    ) -> Vec<ShimmerWarning> {
        let ctx = super::super::commit::CommitCtx {
            registry,
            context: crate::shimmer::ShimmerContext::standalone(registry),
            ssa: &fu.ssa,
            source: crate::ssa::SsaSourceView::unpositioned(&fu.ssa),
            types: &fu.types,
            values: &fu.sccp.values,
            folded: &fu.sccp.folded_types,
        };
        let facts = super::super::ShimmerFacts {
            commit: super::super::commit::compute_commit_facts(
                &fu.cfg,
                &ctx,
                &fu.sccp.executable_blocks,
                &fu.sccp.executable_edges,
            ),
            loop_blocks: super::super::graph::loop_body_blocks(&fu.cfg),
        };
        let in_force = crate::type_infer::types_in_force(&fu.types, &fu.sccp);
        find_expr_shimmers(
            &fu.cfg,
            &ctx,
            (&fu.sccp.executable_blocks, &in_force),
            &facts,
        )
    }

    /// `collect_expr_shimmers` recurses
    /// once per `ExprNode` level, so it needs a depth cap. A tree
    /// built directly is unbounded (the Pratt parser caps its own output at
    /// 256) and empirically overflowed the native stack (SIGABRT) in the low
    /// thousands of levels on a 2 MiB thread. 3000 is past that crash range
    /// and past `MAX_EXPR_NODE_DEPTH` (256); the assertion is that it returns
    /// at all.
    #[test]
    fn deeply_nested_collect_expr_shimmers_survives() {
        use crate::expr_ast::ExprNode;
        use std::collections::HashSet;
        use tcl_lexer::Span;

        let r = registry();
        let cu = CompilationUnit::build_for("set v 5", &r, false);
        let fu = cu.function("::top").unwrap();
        let cctx = super::super::commit::CommitCtx {
            registry: &r,
            context: crate::shimmer::ShimmerContext::standalone(&r),
            ssa: &fu.ssa,
            source: crate::ssa::SsaSourceView::unpositioned(&fu.ssa),
            types: &fu.types,
            values: &fu.sccp.values,
            folded: &fu.sccp.folded_types,
        };
        let facts = super::super::commit::compute_commit_facts(
            &fu.cfg,
            &cctx,
            &fu.sccp.executable_blocks,
            &fu.sccp.executable_edges,
        );
        let walker = facts.walker(&cctx, fu.cfg.entry);

        let mut seen: HashSet<(Span, String)> = HashSet::new();
        let mut out: Vec<ShimmerWarning> = Vec::new();
        let mut sctx = ExprShimmerCtx {
            types: super::super::BlockTypes::unrefined(&fu.types, fu.cfg.entry),
            values: &fu.sccp.values,
            source: crate::ssa::SsaSourceView::unpositioned(&fu.ssa),
            folded: &fu.sccp.folded_types,
            commit: &walker,
            stmt_span: Span::new(0, 1),
            expr_base: None,
            executed_source: None,
            in_loop: false,
            seen: &mut seen,
            out: &mut out,
        };

        let mut node = ExprNode::Var {
            text: "$v".into(),
            name: "v".into(),
            start: 0,
            end: 2,
        };
        for _ in 0..3000 {
            node = ExprNode::Binary {
                op: crate::expr_ast::BinOp::Add,
                left: Box::new(node),
                right: Box::new(ExprNode::Literal {
                    text: "1".into(),
                    start: 0,
                    end: 1,
                }),
            };
        }
        collect_expr_shimmers(&mut sctx, &node, 0);
    }

    /// An Int variable in arithmetic — no shimmer.
    #[test]
    fn no_expr_shimmer_int_in_arithmetic() {
        let cu = CompilationUnit::build_for("set x 5\nset y [expr {$x + 1}]", &registry(), false);
        let fu = cu.function("::top").unwrap();
        let w = expr_shimmers(fu, &registry());
        assert_eq!(w.len(), 0, "unexpected expr shimmers: {w:?}");
    }

    /// Arithmetic preserves a loop accumulator's double representation in both
    /// bare `expr` statements and expressions assigned through `set`.
    #[test]
    fn no_expr_shimmer_double_accumulator_in_arithmetic() {
        for tail in ["expr {$u0 * $dx}", "set z [expr {$u0 * $dx}]"] {
            let src = format!(
                "proc clip {{q dx}} {{\n\
                 set u0 0.0\n\
                 foreach qi $q {{\n\
                 set r [expr {{$qi / 2.0}}]\n\
                 if {{$r > $u0}} {{ set u0 $r }}\n\
                 }}\n\
                 {tail}\n\
                 }}"
            );
            let cu = CompilationUnit::build_for(&src, &registry(), false);
            let fu = cu.function("::clip").unwrap();
            let w = expr_shimmers(fu, &registry());
            assert!(
                !w.iter().any(|sw| sw.variable == "u0"),
                "double operand of '*' must not shimmer ({tail}): {w:?}"
            );
        }
    }

    /// A double read in a boolean context is the same free numeric read.
    #[test]
    fn no_expr_shimmer_double_in_boolean_context() {
        let cu = CompilationUnit::build_for(
            "set x [expr {1.0 + 1.5}]\nset y [expr {$x && 1}]",
            &registry(),
            false,
        );
        let fu = cu.function("::top").unwrap();
        let w = expr_shimmers(fu, &registry());
        assert_eq!(w.len(), 0, "unexpected expr shimmers: {w:?}");
    }

    /// The same expression must not report differently depending only on
    /// where it sits — as a statement, or inside a `return`. The return value
    /// is an `ExprNode` the lowerer already parsed onto the terminator, so the
    /// walker reads it there.
    #[test]
    fn expr_shimmer_fires_in_a_return_expression() {
        let src = "proc f {x} {\n set d [expr {sqrt($x)}]\n return [expr {$d % 2}]\n}";
        let cu = CompilationUnit::build_for(src, &registry(), false);
        let fu = cu.function("::f").unwrap();
        let w = expr_shimmers(fu, &registry());
        assert!(
            w.iter()
                .any(|sw| sw.variable == "d" && sw.to_type == TclType::Int),
            "a double in a returned integer-only expression is still a mismatch: {w:?}"
        );
    }

    /// `return {[expr {…}]}` is a literal string — Tcl never evaluates it, so
    /// the lowerer leaves the terminator's `expr` `None` and nothing fires.
    #[test]
    fn no_expr_shimmer_in_a_braced_return_value() {
        let src = "proc f {x} {\n set d [expr {sqrt($x)}]\n return {[expr {$d % 2}]}\n}";
        let cu = CompilationUnit::build_for(src, &registry(), false);
        let fu = cu.function("::f").unwrap();
        assert_eq!(
            expr_shimmers(fu, &registry()),
            [] as [crate::shimmer::ShimmerWarning; 0]
        );
    }

    /// The other half of the same asymmetry: an `[expr …]` in a call
    /// argument. Its operands never reach `SsaStatement::uses` (the body is a
    /// braced word the *command* parser does not substitute), so the walk
    /// resolves them against the versions live at the statement.
    #[test]
    fn expr_shimmer_fires_in_a_nested_call_argument() {
        let src = "proc f {x} {\n set d [expr {sqrt($x)}]\n puts [expr {$d % 2}]\n}";
        let cu = CompilationUnit::build_for(src, &registry(), false);
        let fu = cu.function("::f").unwrap();
        let w = expr_shimmers(fu, &registry());
        assert!(
            w.iter()
                .any(|sw| sw.variable == "d" && sw.to_type == TclType::Int),
            "nested `[expr …]` is evaluated just like a statement one: {w:?}"
        );
    }

    /// …and the braced spelling of that same word is not.
    #[test]
    fn no_expr_shimmer_in_a_braced_call_argument() {
        let src = "proc f {x} {\n set d [expr {sqrt($x)}]\n puts {[expr {$d % 2}]}\n}";
        let cu = CompilationUnit::build_for(src, &registry(), false);
        let fu = cu.function("::f").unwrap();
        assert_eq!(
            expr_shimmers(fu, &registry()),
            [] as [crate::shimmer::ShimmerWarning; 0]
        );
    }

    /// A nested `[expr …]` must be lifted out of an
    /// assignment value exactly as it is out of a call argument. The outer
    /// command decides nothing about what Tcl evaluates inside the word, so
    /// `set r <word>` and `puts <word>` run the same expression — but only the
    /// `Call` arm was lifted here, so the assignment spelling reported nothing
    /// even while `commit` recorded the conversion for later reads.
    ///
    /// Paired against the call spelling rather than asserted on its own: it is
    /// the symmetry that is the contract, and only a comparison catches the
    /// two arms drifting apart again. The braced row is the control — Tcl
    /// never substitutes it, at either spelling.
    #[test]
    fn assign_value_lifts_the_same_nested_expr_a_call_does() {
        for (word, runs) in [
            ("[expr {0 in $x}]", true),
            ("[list [expr {0 in $x}]]", true),
            ("[list \"[expr {0 in $x}]\"]", true),
            ("[list {[expr {0 in $x}]}]", false),
        ] {
            let mut verdicts = Vec::new();
            for stmt in [format!("puts {word}"), format!("set r {word}")] {
                let src = format!("proc f {{lst}} {{\n set x [llength $lst]\n {stmt}\n}}");
                let cu = CompilationUnit::build_for(&src, &registry(), false);
                let fu = cu.function("::f").unwrap();
                let w = expr_shimmers(fu, &registry());
                let hit = w.iter().find(|sw| sw.variable == "x").cloned();
                if let Some(hit) = hit.as_ref() {
                    assert_eq!(hit.to_type, TclType::List, "in {stmt:?}");
                }
                verdicts.push((stmt, hit.is_some()));
            }
            let [(call, call_fired), (assign, assign_fired)] = verdicts.as_slice() else {
                unreachable!("one verdict per spelling")
            };
            assert_eq!(
                call_fired, assign_fired,
                "{call:?} and {assign:?} evaluate the same expression and must report alike"
            );
            assert_eq!(*call_fired, runs, "wrong verdict for {call:?}");
        }
    }

    /// A `set x [expr {…}]` whose value word *is* the substitution is lowered
    /// to `AssignExpr`, so widening the lift to `AssignValue` must not make
    /// the two arms report the same expression twice.
    #[test]
    fn a_bare_expr_assignment_is_reported_once() {
        let src = "proc f {lst} {\n set x [llength $lst]\n set r [expr {0 in $x}]\n}";
        let cu = CompilationUnit::build_for(src, &registry(), false);
        let fu = cu.function("::f").unwrap();
        let w = expr_shimmers(fu, &registry());
        assert_eq!(
            w.iter().filter(|sw| sw.variable == "x").count(),
            1,
            "one expression, one report: {w:?}"
        );
    }

    /// `%`, the shifts and the bitwise operators
    /// are integer-only, so a committed double is still a mismatch there even
    /// though `Double` is now numeric-compatible. tclsh 8.6.16 / 9.0.4:
    /// `expr {$d % 2}` on a double raises `can't use floating-point value as
    /// operand of "%"`, and the same for `<<`, `>>`, `&`, `|`, `^`.
    #[test]
    fn expr_shimmer_double_still_fires_for_integer_only_operators() {
        for op in ["%", "<<", ">>", "&", "|", "^"] {
            let src =
                format!("proc f {{x}} {{\n set d [expr {{sqrt($x)}}]\n expr {{$d {op} 2}}\n}}");
            let cu = CompilationUnit::build_for(&src, &registry(), false);
            let fu = cu.function("::f").unwrap();
            let w = expr_shimmers(fu, &registry());
            assert!(
                w.iter()
                    .any(|sw| sw.variable == "d" && sw.to_type == TclType::Int),
                "a double operand of '{op}' must still be reported: {w:?}"
            );
        }
    }

    /// The arithmetic operators keep accepting it.
    #[test]
    fn no_expr_shimmer_double_for_true_arithmetic_operators() {
        for op in ["+", "-", "*", "/", "**"] {
            let src =
                format!("proc f {{x}} {{\n set d [expr {{sqrt($x)}}]\n expr {{$d {op} 2}}\n}}");
            let cu = CompilationUnit::build_for(&src, &registry(), false);
            let fu = cu.function("::f").unwrap();
            let w = expr_shimmers(fu, &registry());
            assert!(
                !w.iter().any(|sw| sw.variable == "d"),
                "a double operand of '{op}' is a free numeric read: {w:?}"
            );
        }
    }

    /// A String variable used in arithmetic should produce S100.
    #[test]
    fn expr_shimmer_string_in_arithmetic() {
        let cu = CompilationUnit::build_for(
            "set x \"hello\"\nset y [expr {$x + 1}]",
            &registry(),
            false,
        );
        let fu = cu.function("::top").unwrap();
        let w = expr_shimmers(fu, &registry());
        let has_shimmer = w
            .iter()
            .any(|sw| sw.variable == "x" && sw.from_type == TclType::String);
        assert!(
            has_shimmer,
            "expected string-in-arithmetic shimmer, got: {w:?}"
        );
    }

    /// Comparison operators never flag: C Tcl probes each operand without
    /// generating a string rep and falls back to a string comparison — an
    /// operand's intrep is replaced only when its OWN string parses as a
    /// number, which the value (not the type) decides. tclsh-verified:
    /// `set s [string trim hello]; expr {$s == "5"}` and `expr {$s <= 5}`
    /// both leave `s` a `string`; `expr {5 == $L}` keeps `$L` a `list`.
    /// The old behaviour ("flag when the sibling operand looks numeric") was
    /// a verified false-positive class.
    #[test]
    fn expr_shimmer_comparisons_never_flag() {
        for src in [
            // String operand vs numeric literal — value "hello" cannot parse,
            // no shimmer happens at runtime (the old code flagged this).
            "set s [string trim hello]\nset y [expr {$s == \"5\"}]",
            "set s [string trim hello]\nset y [expr {$s <= 5}]",
            // Both string — string compare.
            "set s [string trim hello]\nset y [expr {$s == \"hello\"}]",
            "set s [string trim hello]\nset y [expr {$s < \"banana\"}]",
            // List operand — list intrep kept, string compare.
            "set lst [list a b c]\nset s [string trim hi]\nset y [expr {$lst > $s}]",
            "set lst [list a b c]\nset y [expr {5 == $lst}]",
        ] {
            let cu = CompilationUnit::build_for(src, &registry(), false);
            let fu = cu.function("::top").unwrap();
            let w = expr_shimmers(fu, &registry());
            assert!(
                !w.iter()
                    .any(|sw| sw.variable == "s" || sw.variable == "lst"),
                "comparison operands must not be flagged for {src:?}: {w:?}"
            );
        }
    }

    /// `&&`/`||` are a boolean coercion context with no string fallback: a
    /// String-typed operand genuinely loses its intrep (tclsh:
    /// `set s "true"; expr {$s && 1}` installs a boolean intrep). The wording
    /// says boolean, not arithmetic.
    #[test]
    fn expr_shimmer_boolean_context_flags_string_operand() {
        let cu = CompilationUnit::build_for(
            "set s [string trim true]\nset y [expr {$s && 1}]",
            &registry(),
            false,
        );
        let fu = cu.function("::top").unwrap();
        let w = expr_shimmers(fu, &registry());
        let warning = w.iter().find(|sw| sw.variable == "s");
        let warning = warning.expect("string operand of && must be flagged");
        assert_eq!(warning.to_type, TclType::Boolean);
        assert!(
            warning.message.contains("boolean context"),
            "wording must say boolean context: {}",
            warning.message
        );
    }

    fn missing_committed_haystack(
        fu: &crate::compilation_unit::FunctionUnit,
        native_registry: &CommandRegistry,
        w: &[ShimmerWarning],
    ) -> ! {
        let reads: Vec<_> = fu
            .ssa
            .blocks
            .iter()
            .flat_map(|(&block, body)| {
                body.statements
                    .iter()
                    .enumerate()
                    .filter_map(move |(index, statement)| {
                        let view = crate::ssa::SsaSourceView::at_statement(&fu.ssa, block, index);
                        let tokens = view.source_tokens()?;
                        Some((
                            statement.statement.span(),
                            tokens
                                .variable_accesses
                                .iter()
                                .map(|access| {
                                    let read = view
                                        .read_reference(&access.source, &access.original_spelling);
                                    let types = read
                                        .and_then(|read| {
                                            read.version.map(|version| (read.symbol, version))
                                        })
                                        .and_then(|key| fu.types.get(&key));
                                    let representations: Vec<_> = access
                                        .context_alternatives()
                                        .iter()
                                        .map(|context| {
                                            let place =
                                                crate::var_resolve::resolve_substitution_access(
                                                    &access.original_spelling,
                                                    context,
                                                    native_registry,
                                                    tcl_registry::TraceOperation::Read,
                                                );
                                            (
                                                context
                                                    .read_produces_value(&place, native_registry),
                                                context.contents_representation_at(&place),
                                            )
                                        })
                                        .collect();
                                    (
                                        &access.original_spelling,
                                        access.source.span,
                                        read,
                                        types,
                                        access.context_residual(),
                                        representations,
                                    )
                                })
                                .collect::<Vec<_>>(),
                        ))
                    })
            })
            .collect();
        panic!("committed Dict haystack of `in` must be flagged; warnings={w:?}; reads={reads:?}")
    }

    /// `in`/`ni` convert the RIGHT operand to a list. A *committed* Dict
    /// haystack genuinely re-represents (Dict → List); a *pure* string haystack
    /// does not — `[string trim "a b c"]` is a pure string (oracle: it goes pure
    /// → list on first read), so its list conversion is free. A List-typed
    /// haystack is already a list, and the needle is read as a string — both
    /// silent.
    #[test]
    fn expr_shimmer_in_membership_flags_committed_not_pure_haystack() {
        let profile = tcl_dialect::DialectProfile::find("tcl8.6").unwrap();
        let native_registry =
            tcl_registry::model::ingress::static_context_for_profile(profile).commands();
        // TP: a committed Dict haystack re-represents to a list.
        let cu = CompilationUnit::build_for_profile(
            "set hay [dict create a 1 b 2]\nset y [expr {\"a\" in $hay}]",
            native_registry,
            false,
            profile,
        );
        let fu = cu.function("::top").unwrap();
        let w = expr_shimmers(fu, native_registry);
        let warning = w
            .iter()
            .find(|sw| sw.variable == "hay")
            .unwrap_or_else(|| missing_committed_haystack(fu, native_registry, &w));
        assert_eq!(warning.from_type, TclType::Dict);
        assert_eq!(warning.to_type, TclType::List);

        let unspecified = registry();
        let generic = CompilationUnit::build_for(
            "set hay [dict create a 1 b 2]\nset y [expr {\"a\" in $hay}]",
            &unspecified,
            false,
        );
        assert!(
            expr_shimmers(generic.function("::top").unwrap(), &unspecified)
                .iter()
                .any(|warning| warning.variable == "hay" && warning.from_type == TclType::Dict),
            "the selected generic native creator independently produces a Dict"
        );
        let replaced = CompilationUnit::build_for_profile(
            "rename dict {}; proc dict args {return {a 1 b 2}}; set maker dict;\n\
             set hay [$maker create a 1 b 2]\nset y [expr {\"a\" in $hay}]",
            native_registry,
            false,
            profile,
        );
        assert!(
            !expr_shimmers(replaced.function("::top").unwrap(), native_registry)
                .iter()
                .any(|warning| warning.variable == "hay"),
            "a replacement reached through generic dispatch cannot borrow the native creator's Dict"
        );

        // TN: a pure string haystack is a free first conversion.
        let cu_pure = CompilationUnit::build_for_profile(
            "set hay [string trim \"a b c\"]\nset y [expr {\"b\" in $hay}]",
            native_registry,
            false,
            profile,
        );
        let fu_pure = cu_pure.function("::top").unwrap();
        let w_pure = expr_shimmers(fu_pure, native_registry);
        assert!(
            !w_pure.iter().any(|sw| sw.variable == "hay"),
            "pure string haystack must not be flagged: {w_pure:?}"
        );

        // A List-typed haystack is already a list — silent.
        let cu2 = CompilationUnit::build_for_profile(
            "set hay [list a b c]\nset y [expr {\"b\" in $hay}]",
            native_registry,
            false,
            profile,
        );
        let fu2 = cu2.function("::top").unwrap();
        let w2 = expr_shimmers(fu2, native_registry);
        assert!(
            !w2.iter().any(|sw| sw.variable == "hay"),
            "list haystack must not be flagged: {w2:?}"
        );

        // The needle is read as a string — a String-typed needle is silent.
        let cu3 = CompilationUnit::build_for_profile(
            "set needle [string trim b]\nset hay [dict create a 1]\nset y [expr {$needle in $hay}]",
            native_registry,
            false,
            profile,
        );
        let fu3 = cu3.function("::top").unwrap();
        let w3 = expr_shimmers(fu3, native_registry);
        assert!(
            !w3.iter().any(|sw| sw.variable == "needle"),
            "the needle of `in` must not be flagged: {w3:?}"
        );
    }

    /// An Int variable used in a string comparison inside an `AssignExpr` produces S100.
    #[test]
    fn expr_shimmer_int_in_string_comparison_assign_expr() {
        let cu =
            CompilationUnit::build_for("set x 42\nset z [expr {$x eq \"42\"}]", &registry(), false);
        let fu = cu.function("::top").unwrap();
        let w = expr_shimmers(fu, &registry());
        let has_shimmer = w
            .iter()
            .any(|sw| sw.variable == "x" && sw.from_type == TclType::Int);
        assert!(
            has_shimmer,
            "expected Int-in-string-cmp shimmer, got: {w:?}"
        );
    }

    /// An Int variable used in a string comparison inside an `if` condition
    /// (`Terminator::Branch`) produces S100 via the branch-condition path.
    #[test]
    fn expr_shimmer_int_in_if_branch_condition() {
        let cu = CompilationUnit::build_for(
            "set x 42\nif {$x eq \"42\"} { set y 1 }",
            &registry(),
            false,
        );
        let fu = cu.function("::top").unwrap();
        let w = expr_shimmers(fu, &registry());
        let has_shimmer = w
            .iter()
            .any(|sw| sw.variable == "x" && sw.from_type == TclType::Int);
        assert!(
            has_shimmer,
            "expected Int-in-string-cmp shimmer in if-condition, got: {w:?}"
        );
    }

    /// The same variable used in several operands of one expression emits a
    /// single shimmer, not one per operand (per-block `(span, var)` dedup).
    #[test]
    fn expr_shimmer_dedups_repeated_operand() {
        let cu = CompilationUnit::build_for(
            "set x \"hi\"\nset y [expr {$x + $x + $x}]",
            &registry(),
            false,
        );
        let fu = cu.function("::top").unwrap();
        let w = expr_shimmers(fu, &registry());
        let xs: Vec<_> = w.iter().filter(|sw| sw.variable == "x").collect();
        assert_eq!(
            xs.len(),
            1,
            "repeated operand must emit one shimmer, got: {xs:?}"
        );
    }

    /// An arithmetic shimmer inside a loop body is a per-iteration cost
    /// (S101); the same shimmer outside a loop is one-time (S100).
    #[test]
    fn expr_shimmer_in_loop_is_s101() {
        let cu = CompilationUnit::build_for(
            "proc f {l} {\n  foreach x $l {\n    set y [expr {$x + 1}]\n  }\n}\n",
            &registry(),
            false,
        );
        let fu = cu.function("::f").unwrap();
        let w = expr_shimmers(fu, &registry());
        let s = w.iter().find(|sw| sw.variable == "x");
        assert!(s.is_some(), "expected expr shimmer for x in loop: {w:?}");
        let s = s.unwrap();
        assert_eq!(
            s.code,
            DiagCode::S101,
            "in-loop arithmetic shimmer must be S101"
        );
        assert!(s.in_loop);
    }

    /// A String literal compared with `eq` — no shimmer (String is correct type).
    #[test]
    fn no_expr_shimmer_string_in_string_comparison() {
        let cu = CompilationUnit::build_for(
            "set x \"hello\"\nif {$x eq \"world\"} { set y 1 }",
            &registry(),
            false,
        );
        let fu = cu.function("::top").unwrap();
        let w = expr_shimmers(fu, &registry());
        // x is String; used with eq (string comparison) — no shimmer.
        let str_cmp_shimmers: Vec<_> = w
            .iter()
            .filter(|sw| sw.variable == "x" && sw.to_type == TclType::String)
            .collect();
        assert_eq!(
            str_cmp_shimmers.len(),
            0,
            "unexpected String-in-string-cmp shimmer: {str_cmp_shimmers:?}"
        );
    }

    /// A byte-array-typed variable used in arithmetic shimmers to Numeric —
    /// the same in-place intrep clobber as String/List/Dict, reached via
    /// `Tcl_GetNumberFromObj` falling back to the byte array's string rep.
    #[test]
    fn expr_shimmer_bytearray_in_arithmetic() {
        let cu = CompilationUnit::build_for(
            "set b [binary format c* {49 50}]\nset y [expr {$b + 1}]",
            &registry(),
            false,
        );
        let fu = cu.function("::top").unwrap();
        let w = expr_shimmers(fu, &registry());
        let has_shimmer = w
            .iter()
            .any(|sw| sw.variable == "b" && sw.from_type == TclType::ByteArray);
        assert!(
            has_shimmer,
            "expected bytearray-in-arithmetic shimmer, got: {w:?}"
        );
    }

    /// TP (range precision): the warning span is the offending operand
    /// itself (`$x` inside the braced expr), not the whole statement.
    #[test]
    fn expr_shimmer_span_narrows_to_operand_assign_expr() {
        let src = "set x \"hello\"\nset y [expr {$x + 1}]";
        let cu = CompilationUnit::build_for(src, &registry(), false);
        let fu = cu.function("::top").unwrap();
        let w = expr_shimmers(fu, &registry());
        let s = w
            .iter()
            .find(|sw| sw.variable == "x")
            .unwrap_or_else(|| panic!("expected shimmer for x, got: {w:?}"));
        let expected = src.rfind("$x").unwrap();
        assert_eq!(
            (s.span.start() as usize, s.span.end() as usize),
            (expected, expected + 2),
            "span must cover exactly the `$x` operand, got {:?} in {src:?}",
            s.span
        );
    }

    /// TP (range precision): a branch-condition shimmer anchors at the
    /// operand inside the braced `if` condition.
    #[test]
    fn expr_shimmer_span_narrows_to_operand_in_branch_condition() {
        let src = "set x 42\nif {$x eq \"42\"} { set y 1 }";
        let cu = CompilationUnit::build_for(src, &registry(), false);
        let fu = cu.function("::top").unwrap();
        let w = expr_shimmers(fu, &registry());
        let s = w
            .iter()
            .find(|sw| sw.variable == "x")
            .unwrap_or_else(|| panic!("expected shimmer for x, got: {w:?}"));
        let expected = src.rfind("$x").unwrap();
        assert_eq!(
            (s.span.start() as usize, s.span.end() as usize),
            (expected, expected + 2),
            "span must cover exactly the `$x` operand, got {:?} in {src:?}",
            s.span
        );
    }

    /// TP (range precision): the narrowed span works inside a proc body too
    /// (offset-0 memo + rebase must not lose the expression anchor).
    #[test]
    fn expr_shimmer_span_narrows_to_operand_inside_proc() {
        let src = "proc f {} {\n  set x \"hello\"\n  set y [expr {$x * 2}]\n}\n";
        let cu = CompilationUnit::build_for(src, &registry(), false);
        let fu = cu.function("::f").unwrap();
        let w = expr_shimmers(fu, &registry());
        let s = w
            .iter()
            .find(|sw| sw.variable == "x")
            .unwrap_or_else(|| panic!("expected shimmer for x, got: {w:?}"));
        // The unit's spans are unit-relative; recover absolutes via abs_span.
        let abs = fu.abs_span(s.span);
        let expected = src.rfind("$x").unwrap();
        assert_eq!(
            (abs.start() as usize, abs.end() as usize),
            (expected, expected + 2),
            "span must cover exactly the `$x` operand, got {abs:?} in {src:?}"
        );
    }

    /// Fallback (no verbatim anchor): a *quoted* condition is reconstructed
    /// from multiple tokens, so no `condition_base` exists — the warning
    /// still fires, anchored at the condition span (which contains the
    /// operand), never a bogus narrowed range.
    #[test]
    fn expr_shimmer_span_falls_back_without_verbatim_anchor() {
        let src = "set x 42\nif \"$x eq 42\" { set y 1 }";
        let cu = CompilationUnit::build_for(src, &registry(), false);
        let fu = cu.function("::top").unwrap();
        let w = expr_shimmers(fu, &registry());
        // The quoted form substitutes before parsing, so the shimmer may or
        // may not fire; when it does, the span must contain the whole
        // fallback range and be non-degenerate.
        for s in w.iter().filter(|sw| sw.variable == "x") {
            assert!(
                s.span.end() > s.span.start(),
                "fallback span must be non-degenerate: {s:?}"
            );
            let slice = &src[s.span.start() as usize..s.span.end() as usize];
            assert!(
                slice.contains("$x"),
                "fallback span must still contain the operand, got {slice:?}"
            );
        }
    }

    /// TN (dedup + narrowing): with the span narrowed to the operand, the
    /// per-statement dedup still emits one warning for `$x + $x`, anchored
    /// at the *first* occurrence.
    #[test]
    fn expr_shimmer_narrowed_span_dedups_to_first_operand() {
        let src = "set x \"hi\"\nset y [expr {$x + $x}]";
        let cu = CompilationUnit::build_for(src, &registry(), false);
        let fu = cu.function("::top").unwrap();
        let w = expr_shimmers(fu, &registry());
        let xs: Vec<_> = w.iter().filter(|sw| sw.variable == "x").collect();
        assert_eq!(xs.len(), 1, "one warning per statement+var: {xs:?}");
        let first = src.find("{$x").unwrap() + 1;
        assert_eq!(
            (xs[0].span.start() as usize, xs[0].span.end() as usize),
            (first, first + 2),
            "dedup keeps the first operand's span"
        );
    }

    /// (Regression guard) `eq`/`ne`/`lt`/`le`/`gt`/`ge` never get an
    /// auto-fix, even when both operands are provably numeric — a prior
    /// version of this check offered a rewrite to the numeric-equivalent
    /// operator whenever both sides looked numeric, but Tcl's string
    /// comparison operators compare string *representations*, not numeric
    /// value: `"10" lt "2"` is true (lexicographic) while `10 < 2` is false,
    /// so the rewrite silently changes program behaviour. `ShimmerWarning`
    /// carries no `fixes` field: the warning is informational only.
    #[test]
    fn expr_shimmer_lt_both_numeric_still_fires_with_no_fix_offered() {
        let src = "set x 10\nset y 2\nset z [expr {$x lt $y}]";
        let cu = CompilationUnit::build_for(src, &registry(), false);
        let fu = cu.function("::top").unwrap();
        let w = expr_shimmers(fu, &registry());
        let s = w
            .iter()
            .find(|sw| sw.variable == "x" || sw.variable == "y")
            .unwrap_or_else(|| panic!("expected an Int-in-string-cmp shimmer, got: {w:?}"));
        assert!(
            s.message.contains("if a numeric comparison was intended"),
            "expected the informational hint, got: {s:?}"
        );
    }
}

#[cfg(test)]
pub(crate) fn find_expr_shimmers(
    cfg: &CfgFunction,
    commit_ctx: &super::commit::CommitCtx<'_>,
    (executable_blocks, in_force): (
        &HashSet<BlockId>,
        &HashMap<(BlockId, ValueKey), TypeLattice>,
    ),
    facts: &super::ShimmerFacts,
) -> Vec<ShimmerWarning> {
    find_expr_shimmers_with_context(cfg, commit_ctx, (executable_blocks, in_force), facts)
}
