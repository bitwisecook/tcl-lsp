# Unadopted VM Parent current-holder draft

Exact draft449f2da4979ac51a7fef4a1c46cc3b72f5333ca7757029ef66371382639c2209. Main was never modified. Scratch rustfmt parsing only; no Cargo/tests. Runtime and Compiler source/API peer requests remain pending.

VM Jim namespace parent's no-argument path currently obtains namespace_object_bytes(current_ns_id()), which requires an already materialized token and substitutes a report/token path for the original current namespace holder. The draft uses the existing actual OriginalJimNamespaceContext::materialize at the reached operation, checks the original Name scope, and reads the exact held current namespace object through that scope. The explicit-operand path is unchanged. No name-to-NsId inverse, new lookup or missing namespace materialization is used.

One controlled real for_lambda context/entered frame test distinguishes no-argument and explicit absent-name forms. Existing original SDK258 CURRENT_REUSE int42 becomes resident, whereas the explicit operand leaves caller int42 nonresident; both return `::`. This tests actual getter purpose and current-context materialization. It does not claim complete Parent result primary/publication parity: the draft intentionally leaves the existing shared parent-byte/result producer unchanged. The independent adopted Runtime Parent6435 result recipe is more precise.

Beforeimage is the source221 VM cmd_namespace.rs. Rebase onto current238 preserving the adopted SharedEmpty arm/test. If combining with selected-retirement, compose their disjoint same-file hunks and seal one exact current afterimage. Obtain independent API/lifetime review and Root-run the new control plus the existing actual lambda namespace/getter controls.
