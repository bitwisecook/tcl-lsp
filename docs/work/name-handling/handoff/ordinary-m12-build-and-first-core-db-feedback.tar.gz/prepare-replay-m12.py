from pathlib import Path
import json,subprocess,re,hashlib
root=Path('/workspace/name-validation');base=Path('/workspace/name-session')
build=json.loads((base/'batch-m12-build-ordinary/result.json').read_text());assert build['exit_code']==0 and not build['changed_sources'] and not build['errors'] and len(build['test_artifacts'])==23
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==build['started']['commit']
diff=subprocess.check_output(['git','diff','--unified=0','4faff1a8db8ee365b90e5c0609d038b98334dfa3..HEAD','--','rust','runtime'],cwd=root,text=True)
added=set(re.findall(r'^\+\s*(?:async\s+)?fn\s+(\w+)\s*\(',diff,re.M))
packages={'compiler':'tcl-compiler','core':'tcl-lsp-core','db':'tcl-lsp-db','syntax':'tcl-syntax','source':'xtask','studio':'tcl-spec-studio','spectcl':'tcl-spectcl','registry':'tcl-registry','mcp':'tcl-mcp','server':'tcl-lsp-server','lexer':'tcl-lexer','irules':'tcl-irules','vm':'tcl-vm','bpf':'bpf-tcl-ir','coretypes':'tcl-core-types','bpfcodegen':'bpf-tcl-codegen','host':'tcl-host-native','debugger':'tcl-debugger','debugcli':'tcl-debugger','sandbox':'tcl-sandbox','pkg':'tcl-pkg','runtimeapi':'tcl-runtime-api','query':'tcl-bigip-query'}
summary={}
for label,package in packages.items():
 artifacts=[a for a in build['test_artifacts'] if Path(a['path']).name.startswith(('tcl_debug' if label=='debugcli' else package.replace('-','_'))+'-')];assert len(artifacts)==1
 artifact=artifacts[0];assert hashlib.sha256(Path(artifact['path']).read_bytes()).hexdigest()==artifact['sha256']
 listing=subprocess.run([artifact['path'],'--list','--format','terse'],capture_output=True,text=True,check=True)
 (base/(label+'-m12-list.txt')).write_text(listing.stdout)
 tests=[n.removesuffix(': test') for n in listing.stdout.splitlines() if n.endswith(': test')];assert tests
 plan=json.loads((base/(label+'-l15-plan.json')).read_text()) if (base/(label+'-l15-plan.json')).exists() else {'exact': [], 'filters': [], 'test_timeouts': {}}
 additions=[n for n in tests if (n.rsplit('::',1)[-1] in added or label in {'coretypes','bpfcodegen','host','debugger','debugcli','sandbox','pkg','runtimeapi','query'}) and n not in plan['exact']]
 
 if not plan['exact'] and not additions: continue
 plan['exact']+=additions;plan['scope']='Frozen c9e826a23 ordinary replay; all1491 L15 selected controls and unchanged original budgets retained, plus actually listed new migration tests; Native/provider/full-codebase acceptance separate.'
 assert len(plan['exact'])==len(set(plan['exact']));assert all(n in tests for n in plan['exact'])
 (base/(label+'-m12-plan.json')).write_text(json.dumps(plan,indent=2)+'\n')
 summary[label]={'package':package,'artifact':artifact,'selected':len(plan['exact']),'additions':additions}
(base/'m12-replay-plans.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:{'selected':v['selected'],'additions':v['additions']} for k,v in summary.items()},indent=2))
