from pathlib import Path
import concurrent.futures,subprocess,json,hashlib
base=Path('/workspace/name-session');build=base/'batch-m12-build-ordinary';plans=json.loads((base/'m12-replay-plans.json').read_text())
def run(label):
 row=plans[label];artifact=row['artifact'];assert hashlib.sha256(Path(artifact['path']).read_bytes()).hexdigest()==artifact['sha256']
 argv=['python3',str(base/'replay-frozen-a.py'),'--package',row['package'],'--plan',str(base/(label+('-m12-rest-plan.json' if label=='compiler' else '-m12-plan.json'))),'--out',str(base/('replay-m12-'+label)),'--binary',artifact['path'],'--expected-source',str(build/'source-before.json.gz'),'--timeout','180','--jobs','1','--label','Frozen c9e826a23 ordinary remainder; original2286 first PASS71.841791191s/180; all1491 L15 controls retained with55 actuallylisted additions; original budgets and strict source/provider/binary/run guards preserved; Native/full closure independent']
 with (base/(label+'-m12-runner.log')).open('wb') as out:code=subprocess.run(argv,cwd='/workspace/name-validation',stdout=out,stderr=subprocess.STDOUT).returncode
 p=base/('replay-m12-'+label)/'result.json';r=json.loads(p.read_text()) if p.exists() else {};runs=r.get('runs',[])
 summary={'label':label,'exit':code,'selected':len(r.get('selected_tests',[])),'runs':len(runs),'pass':sum(x['exit_code']==0 for x in runs),'fail':sum(x['exit_code']!=0 and not x['timed_out'] for x in runs),'timeout':sum(x['timed_out'] for x in runs),'source_drift':r.get('changed_sources'),'binary_unchanged':r.get('binary_unchanged'),'missing':r.get('missing_exact'),'empty_filters':r.get('empty_filters')};print(json.dumps(summary),flush=True);return summary
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 futures=[pool.submit(run,label) for label in plans]
 results=[f.result() for f in futures]
first=json.loads((base/'replay-m12-first/result.json').read_text());assert len(first['runs'])==1 and first['runs'][0]['exit_code']==0 and first['binary_unchanged'] and not first['changed_sources']
results.insert(0,{'label':'compiler-first','exit':0,'selected':1,'runs':1,'pass':1,'fail':0,'timeout':0,'source_drift':{},'binary_unchanged':True,'missing':[],'empty_filters':[]})
(base/'replay-m12-summary.json').write_text(json.dumps(results,indent=2)+'\n')
