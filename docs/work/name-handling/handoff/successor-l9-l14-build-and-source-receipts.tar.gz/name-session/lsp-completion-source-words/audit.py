from pathlib import Path
import hashlib,json,re,subprocess,collections
root=Path('/workspace/tcl-lsp')
out=Path('/workspace/name-session/lsp-completion-source-words')
base='542394a42'
paths=['rust/tcl-lexer/src/word_parts/cursor.rs','rust/tcl-syntax/src/word_rules.rs','rust/tcl-lsp-core/src/completion.rs','rust/tcl-lsp-core/src/completion/original_context.rs']
def tests(raw):
    s=raw.decode(); m=list(s); i=0
    def hide(a,b): m[a:b]=' '*(b-a)
    while i<len(s):
        if s.startswith('//',i):
            j=s.find('\n',i); j=len(s) if j<0 else j; hide(i,j); i=j; continue
        if s.startswith('/*',i):
            j=i+2; depth=1
            while j<len(s) and depth:
                if s.startswith('/*',j): depth+=1;j+=2
                elif s.startswith('*/',j): depth-=1;j+=2
                else:j+=1
            hide(i,j);i=j;continue
        raw_start=re.compile(r'r(#{0,255})"').match(s,i)
        if raw_start:
            end='"'+raw_start.group(1);j=s.find(end,i+len(raw_start.group(0)))
            assert j>=0
            j+=len(end);hide(i,j);i=j;continue
        if s[i]=='"':
            j=i+1
            while j<len(s):
                if s[j]=='\\':j+=2
                elif s[j]=='"':j+=1;break
                else:j+=1
            hide(i,j);i=j;continue
        if s[i]=="'":
            if i+2<len(s) and s[i+2]=="'":j=i+3
            elif i+1<len(s) and s[i+1]=='\\':
                end=s.find("'",i+2,min(i+20,len(s)));j=end+1 if end>=0 else i
            else:j=i
            if j>i:hide(i,j);i=j;continue
        i+=1
    masked=''.join(m); result={}; counts=collections.Counter()
    for match in re.finditer(r'#\s*\[\s*test\s*\]',masked):
        fn=re.search(r'\bfn\s+(\w+)\s*\(',masked[match.end():]);assert fn
        name=fn.group(1);start=match.end()+fn.start();brace=masked.find('{',start);assert brace>=0
        j=brace+1;depth=1
        while depth:
            assert j<len(masked),name
            if masked[j]=='{':depth+=1
            elif masked[j]=='}':depth-=1
            j+=1
        key=f'{name}#{counts[name]}';counts[name]+=1
        result[key]=s[start:j].encode()
    return result
receipt={'base_commit':base,'kind':'configured-unicode-source-construction-consumer-migration','cargo_or_test_execution':False,'files':[]}
for name in paths:
    before=subprocess.check_output(['git','show',f'{base}:{name}'],cwd=root)
    after=(root/name).read_bytes()
    dest=out/'checkpoint-before'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(before)
    dest=out/'after'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(after)
    old=tests(before);new=tests(after)
    missing=sorted(old.keys()-new.keys());changed=sorted(k for k in old.keys()&new.keys() if old[k]!=new[k])
    receipt['files'].append({'path':name,'before_sha256':hashlib.sha256(before).hexdigest(),'after_sha256':hashlib.sha256(after).hexdigest(),'retained_test_functions':len(old),'missing_tests':missing,'changed_original_test_bodies':changed,'new_test_functions':sorted(new.keys()-old.keys())})
    assert not missing,(name,missing)
    assert not changed,(name,changed)
receipt['ingress_changes']=['No existing test body or Tcl fixture/assertion/position changed.', 'The existing cfg(test) catalogue wrapper now passes the grammar of its already-supplied explicit profile to the shared syntax constructor; it does not fabricate AnalysisResult or source ownership.']
receipt['limitations']=['Static test-body equality and formatting are not compilation or execution acceptance.', 'Expression-function/snippet domains, multiline completion edit transport, OO receiver advice and ParamList display policy remain separately unfinished.', 'Unicode source authoring supplies no Native name, existing identity, dispatch, frame, cell, absence, Normal or edit authority.']
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
