"""Read-only structural classification of exact retained generated parser initializers.
This checks literal/descriptive table grammar, not generated-table semantics or upstream parity.
"""
import json,re,pathlib,hashlib,subprocess
ROOT=pathlib.Path('/workspace/name-session/full-consumer-audit');BASE='cc24c394004fc187378ba0eefb6c2c5b2615fb00';REPO='/workspace/tcl-lsp'
b=subprocess.check_output(['git','-C',REPO,'show',BASE+':rust/zed-query-check/vendor/parser.c']);assert hashlib.sha256(b).hexdigest()=='44a5e5478943cdd5a775b91a4972ba9d76a58e7333114abe105a9046572c2a70';lines=b.decode().split('\n')
# Only scalar literals, named enum/constants, designators and previously actual-read
# parse table constructor macros are admitted. No expressions, callbacks or calls.
TOKEN=re.compile(r'\s+|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|0[xX][0-9a-fA-F]+|[0-9]+|[A-Za-z_][A-Za-z_0-9]*|[{}\[\]().,=]')
MACROS={'STATE':1,'SMALL_STATE':1,'ACTIONS':1,'SHIFT':1,'SHIFT_REPEAT':1,'SHIFT_EXTRA':0,'REDUCE':4,'RECOVER':0,'ACCEPT_INPUT':0}
known={'true','false','NULL','ts_builtin_sym_end'};known.update(re.findall(r'^#define ([A-Z_]+) \d+$',b.decode(),re.M));fields={'visible','named','supertype','index','length','inherited','lex_state','external_lex_state','entry','count','reusable'}
records=[]
for a,e in [(22,1737),(3390,17464)]:
 text='\n'.join(lines[a-1:e]);cursor=0
 pattern=re.compile(r'\s*(enum [A-Za-z_][A-Za-z_0-9]*\s*\{|static const [^;{}=]+?\s*=\s*\{)')
 while cursor<len(text):
  if not text[cursor:].strip():break
  m=pattern.match(text,cursor);assert m,repr(text[cursor:cursor+150]);start=cursor;startline=a+text[:m.start()].count('\n');enum=m.group(1).lstrip().startswith('enum ');pos=m.end();tokens=[];depth=1
  while depth:
   t=TOKEN.match(text,pos);assert t,repr(text[pos:pos+100]);value=t.group();pos=t.end()
   if value.isspace():continue
   if value=='{':depth+=1
   elif value=='}':depth-=1
   if depth:tokens.append(value)
  assert text[pos:pos+1]==';';pos+=1
  if enum:
   k=0
   while k<len(tokens):
    name=tokens[k];assert re.fullmatch('[A-Za-z_][A-Za-z_0-9]*',name);k+=1
    if k<len(tokens) and tokens[k]=='=':assert re.fullmatch('[0-9]+',tokens[k+1]);k+=2
    known.add(name)
    if k<len(tokens):assert tokens[k]==',';k+=1
  else:
   k=0
   def scalar():
    global k
    t=tokens[k];k+=1
    if re.fullmatch(r'0[xX][0-9a-fA-F]+|[0-9]+|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'',t):return
    assert t in known or t in MACROS,('unknown scalar',t)
    if t in MACROS:
     assert tokens[k]=='(';k+=1
     for arg in range(MACROS[t]):
      if arg:assert tokens[k]==',';k+=1
      scalar()
     assert tokens[k]==')';k+=1
   def value():
    global k
    if tokens[k]=='{':
     k+=1;entries('}');assert tokens[k]=='}';k+=1
    else:scalar()
   def entries(end=None):
    global k
    while k<len(tokens) and (end is None or tokens[k]!=end):
     designated=False
     while tokens[k] in ['[','.']:
      designated=True
      if tokens[k]=='[':k+=1;scalar();assert tokens[k]==']';k+=1
      else:k+=1;assert tokens[k] in fields; k+=1
     if designated:assert tokens[k]=='=';k+=1
     value()
     if k<len(tokens) and tokens[k]==',':k+=1
     elif k<len(tokens) and (end is None or tokens[k]!=end):raise AssertionError(('separator',tokens[k:k+5]))
   entries();assert k==len(tokens)
  records.append(dict(declaration=m.group(1).strip(),physical_LF_segments=[startline,a+text[:pos].count('\n')],sha256=hashlib.sha256(text[m.start():pos].encode()).hexdigest(),tokens=len(tokens),classification='strict_fixed_descriptive_initializer_not_semantic_acceptance'))
  cursor=pos
result=dict(baseline=BASE,sourceSHA=hashlib.sha256(b).hexdigest(),status='strict_table_grammar_classification_complete',sections=[[22,1737],[3390,17464]],declarations=records,admitted_parse_macros=MACROS,unmatched_nonliteral_content=[],limitation='No lexer execution/table semantics/upstream regeneration/parity or naming binding authority inferred. Constructor macros actual-read in parser.h; all nonliteral executable parser regions direct-read separately.')
p=ROOT/'db-runtime-audit-tree-sitter-table-classification.json';out=(json.dumps(result,indent=2)+'\n').encode();p.write_bytes(out);print(len(records),hashlib.sha256(out).hexdigest())
