"""Integrate Root-admitted missing public embedding purposes into sealed325."""
from pathlib import Path
import json,hashlib,os,collections,datetime,copy
R=Path('/workspace/name-session/full-consumer-audit');W=R/'vm-embedding-facet-successor';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def write(p,d):
 t=p.with_suffix('.tmp');t.write_text(json.dumps(d,indent=2)+'\n');os.replace(t,p)
def pin(p,role=None):
 d={'path':str(p.relative_to(R)),'sha256':sha(p),'bytes':p.stat().st_size}
 if role:d['role']=role
 return d
names=['vm-consumers.json','vm-migration-units.json','vm-work-kind-summary.json','vm-final-audit-receipt.json','vm-semantic-correction-manifest.json']
for n in names:
 p=W/('before-'+n)
 if not p.exists():p.write_bytes((R/n).read_bytes())
oldman=read(W/'before-vm-semantic-correction-manifest.json');assert sha(W/'before-vm-semantic-correction-manifest.json')=='cb442e68dc80347575da391043c3f17561c85ffc3514ad7e8ed6e3986e6025d0'
for x in oldman['files']:
 p=W/('before-'+x['path']) if x['path'] in names else R/x['path'];assert sha(p)==x['sha256'],x['path']
annex=read(R/'vm-embedding-owner-facet-annex.json');assert sha(R/'vm-embedding-owner-facet-annex.json')=='f39c11c22c8c33d81621ef71b6ad8f657d2a31a402ffd230b6f25930dfd599a1'
u=read(W/'before-vm-migration-units.json');c=read(W/'before-vm-consumers.json');f=read(W/'before-vm-final-audit-receipt.json');summary=read(W/'before-vm-work-kind-summary.json');assert len(u['units'])==325 and len(c['consumers'])==958
blob={x['path']:x['blob'] for x in c['consumers']};now=datetime.datetime.now(datetime.timezone.utc).isoformat();newrows=[];newunits=[]
for i,orig in enumerate(annex['new_proposed_owner_units'],959):
 rid=f'vm-{i:04d}';unit=copy.deepcopy(orig);first=unit['code_change_sites'][0]
 #New public facets are absent: existing methods are bounded location/context
 #anchors, not claims that Unicode convenience/private handlers must change.
 seam=dict(first,blob=blob[first['path']],original_row_id=rid,site_kind='existing public embedding owner extension seam; add the missing purpose-specific API, existing method unchanged',proposed_api_absent=True)
 unit['code_change_sites']=[seam]
 unit['affected_unchanged_callers']=copy.deepcopy(unit.pop('existing_owners'))
 unit['required_change']=[unit['required_change']];unit.update(source_owner='vm',original_row_ids=[rid],representation_and_context=['Actual checked public embedding boundary for exact selected input form; original bytes/header/script purpose remain distinct.',unit['unchanged_affected_callers']],existing_shared_api=['Existing private owner/context APIs are listed in affected_unchanged_callers. None is an externally callable embedding door; extend the same public owner, no competing resolver.'],source_evidence=[{'row':rid,'path':first['path'],'source_sha256':first['source_sha256'],'blob':blob[first['path']],'review_site':unit['purpose']}],control_obligations=[unit.pop('tests_and_evidence'),'Keep genuine input form/provider/interpreter/frame/currentness and full Host/Guest error distinctions.'],canonical_basis='Root admitted explicit missing public purpose after actual Runtime Engine adapter trace and bounded VM public/private source proof; one VM owner unit per variable/package/script family, existing convenience/private workers unchanged.',limitations=['New API does not exist at baseline; code_change_sites identifies its actual existing owner extension seam, not an invented current method.','Runtime Engine API/adapter changes are separate same-family units; no shared owner counted twice.','No source/build/test/provider/Git execution or implementation acceptance.'])
 unit['cross_owner_dependencies']=unit.pop('cross_owner_dependencies')
 row={'id':rid,'path':first['path'],'symbol':first['symbol'],'site':unit['purpose'],'line':first['line'],'source_sha256':first['source_sha256'],'blob':blob[first['path']],'context':'Actual external Engine/Cshim use requires a missing public checked embedding purpose. Existing Unicode/source-byte facades and pub(crate) workers retain distinct contracts; Runtime owns external API/adapters.','shared_api':'; '.join(unit['existing_shared_api']),'missing_integration':unit['required_change'][0],'disposition':'needs_migration','tests':unit['control_obligations'],'evidence':['vm-embedding-owner-facet-annex.json','Root explicit admission of3VM owner facets; stable Runtime family linkage'],'validation':'Source-only API gap proof; no implementation, provider, runtime reference/count or test acceptance.','work_kind':'shared_owner_extension','work_kind_reason':'Genuine externally required purpose is missing from existing public owner; private original worker/API name is not ready public adoption.','work_kind_basis':'Root/Runtime matched actual external Engine consumer input to exact VM public/private source forms at the pinned baseline.','status_review':'Explicit source-proof successor annex after historical325 seal; not silent reclassification.','semantic_review':{'new_source_purpose':True,'annex':'vm-embedding-owner-facet-annex.json','canonical_destinations':[{'kind':'remaining_code_unit','unit_id':unit['id']}],'purpose_states':['needs_migration'],'work_components':['shared_owner_extension']}}
 c['consumers'].append(row);u['units'].append(unit);u['original_row_mapping'][rid]=[{'kind':'remaining_code_unit','unit_id':unit['id']}];newrows.append(row);newunits.append(unit)
assert len(c['consumers'])==961 and len(u['units'])==328
c['status']='Complete assigned source closure and corrected original357 QA retained; three explicit newly proved public embedding purposes added by Root-admitted successor. Not migration completion.'
write(W/'vm-consumers.json',c)
u.update(utc=now,status='Canonical successor:325 semantically corrected confirmed purposes plus3 genuinely missing public embedding owner facets;109 questions/345 integrated validation obligations retained. No implementation/execution acceptance.',source_rows_sha256=sha(W/'vm-consumers.json'),remaining_total=328)
ct=u['counts'];ct.update(original_purpose_rows=961,predecessor_purpose_rows=958,new_admitted_embedding_purpose_rows=3,confirmed_remaining_code_units=328,remaining_code_units=328,distinct_physical_source_anchors=len({(s['path'],s['line']) for z in u['units'] for s in z['code_change_sites']}),families=len({z['family_id'] for z in u['units']}),work_kind=dict(collections.Counter(z['work_kind'] for z in u['units'])),relative_effort=dict(collections.Counter(z['relative_effort'] for z in u['units'])),consumer_row_dispositions=dict(collections.Counter(z['disposition'] for z in c['consumers'])))
for z in newunits:u['families'].append({'id':z['family_id'],'unit_ids':[z['id']],'count_purpose':'VM public owner extension once; separate actual Engine API/adapters are Runtime-owned same-family changes.'})
u['embedding_successor']={'historical325_manifest':'vm-embedding-facet-successor/before-vm-semantic-correction-manifest.json','source_proof_annex':'vm-embedding-owner-facet-annex.json','new_rows':[z['id'] for z in newrows],'new_units':[z['id'] for z in newunits],'admission':'Root explicitly authorized after bounded public/private VM API trace matched actual Runtime consumer forms. Existing private workers and public Unicode convenience APIs are affected context only, not extra migrations.'}
u['generator']='vm-embedding-facet-successor/integrate.py (successor of corrected historical325 projection)';write(W/'vm-migration-units.json',u)
summary.update(utc=now,rows=961,work_kind=dict(collections.Counter(z['work_kind'] for z in c['consumers'])),dispositions=ct['consumer_row_dispositions'],confirmed_canonical_work_kind=ct['work_kind'],confirmed_units=328);write(W/'vm-work-kind-summary.json',summary)
#All preceding958 rows and325 unit bodies remain unchanged; only explicit new
 #rows/units/families/count inputs are added.
assert c['consumers'][:958]==read(W/'before-vm-consumers.json')['consumers']
assert u['units'][:325]==read(W/'before-vm-migration-units.json')['units']
for z in newunits:
 for s in z['code_change_sites']:
  p=R/'vm-source'/s['path'];assert sha(p)==s['source_sha256'];assert p.read_text().splitlines()[s['line']-1]==s['source_line']
assert set(u['original_row_mapping'])=={z['id'] for z in c['consumers']};assert all(u['original_row_mapping'].values());assert ct['distinct_physical_source_anchors']==943
receipt={'baseline':u['baseline'],'utc':now,'status':'Root-admitted source/count successor adds3 missing public embedding purposes to frozen325; no existing325 unit or958 source row body changed. No execution acceptance.','before':[pin(W/('before-'+n)) for n in names],'admission_source':pin(R/'vm-embedding-owner-facet-annex.json'),'generator':pin(W/'integrate.py'),'new_row_ids':[z['id'] for z in newrows],'new_unit_ids':[z['id'] for z in newunits],'counts':ct,'integrity_errors':[],'guards_and_scope':['Actual variable input forms/flags/original header vs CString distinctions; no shared storage facade grants guest mutation semantics.','Package exact selected embedding bytes are not an original Obj header/cache/source receipt.','Script original Value/purpose/currentness is separate from source-byte/framework-host entry.','Existing begin_embedding_call/finish_embedding_result and original operation/interpreter/frame/header guards stay strict.','Only new public API owner extension seams counted; existing private kernels/Unicode facades are unchanged context, not additional code-change sites.'],'limits':['Runtime API and concrete Engine bridge changes are separate units in same stable families; Root global dedup independent.','VM coverage remains exact byte-identical; new observed API purpose, not new source/provider execution coverage.']};write(W/'admission-receipt.json',receipt)
f.update(utc=now,status='Complete source closure and corrected357 semantic QA retained; explicit three-public-embedding-facet successor adds3 confirmed purposes, no execution acceptance.',canonical_counts={'purpose_rows':961,'remaining_code_units':328,'physical_site_anchors':943,'unresolved_questions':109,'integrated_validation_obligations':345,'additional_pending_validation_units':2,'no_additional_change_records':184},unit_counts=ct,embedding_successor_receipt='vm-embedding-facet-successor/admission-receipt.json')
for z in f['inputs']:
 p=W/z['path'] if (W/z['path']).exists() else R/z['path'];z['sha256']=sha(p);z['bytes']=p.stat().st_size
f['inputs'] += [pin(W/'admission-receipt.json'),pin(R/'vm-embedding-owner-facet-annex.json'),pin(W/'integrate.py')];write(W/'vm-final-audit-receipt.json',f)
for n in names[:4]:
 p=R/n;t=p.with_suffix('.embedding-successor.tmp');t.write_bytes((W/n).read_bytes());os.replace(t,p)
man={'baseline':u['baseline'],'utc':now,'status':'Frozen328 successor; original corrected325 and all958 old rows retained byte-structurally unchanged. Three Root-admitted missing public embedding purposes added explicitly. No execution acceptance.','files':[pin(R/n) for n in names[:4]]+[pin(R/'vm-file-coverage.json'),pin(W/'admission-receipt.json'),pin(R/'vm-embedding-owner-facet-annex.json')],'counts':ct,'integrity_errors':[]};write(R/'vm-semantic-correction-manifest.json',man)
print(json.dumps({'manifest_sha256':sha(R/'vm-semantic-correction-manifest.json'),'units_sha256':sha(R/'vm-migration-units.json'),'consumers_sha256':sha(R/'vm-consumers.json'),'admission_sha256':sha(W/'admission-receipt.json'),'counts':ct},indent=2))
