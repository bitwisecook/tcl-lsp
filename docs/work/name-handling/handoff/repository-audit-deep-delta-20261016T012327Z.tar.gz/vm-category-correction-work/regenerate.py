"""Project the completed individual semantic decisions; no source or provider execution."""
import collections, copy, datetime, hashlib, json, os
from pathlib import Path
R=Path('/workspace/name-session/full-consumer-audit'); W=R/'vm-category-correction-work'; G=W/'generated';G.mkdir(exist_ok=True)
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def uniq(xs):
 out=[]
 for x in xs:
  if x not in out:out.append(x)
 return out
def save(p,x):
 t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(x,indent=2)+'\n');os.replace(t,p)
old=read(W/'before-vm-migration-units.json');rows=read(W/'before-vm-consumers.json'); coverage=read(W/'before-vm-file-coverage.json'); final=read(W/'before-vm-final-audit-receipt.json')
reviews=read(W/'review-state.json')['reviews']+read(W/'remaining357-review-state.json')['reviews'];rv={x['id']:x for x in reviews};ou={x['id']:x for x in old['units']}; byrow={x['id']:x for x in rows['consumers']}
assert len(rv)==len(ou)==357 and set(rv)==set(ou)
# Explicit source-purpose partitions authored from the completed decisions. Each list
# projects the reviewed expression ordinals, rather than duplicating every old site.
# (category, state, exact anchor indices, optional existing canonical target)
splits={
 '0361':[('consumer_integration','needs_migration',[0],None),('consumer_integration','needs_migration',[1,2],None)],
 '0430':[('shared_owner_extension','needs_migration',[1],None),('unclassified_pending_owner_trace','pending_audit',[0],None)],
 '0645':[('consumer_integration','needs_migration',[0,1],None),('shared_owner_extension','needs_migration',[2,3],None)],
 '0684':[('consumer_integration','needs_migration',[0,1],None),('shared_owner_extension','needs_migration',[2,3],None)],
 '0753':[('shared_owner_repair','needs_migration',[0],None),('shared_owner_extension','needs_migration',[3,4],None),('consumer_integration','needs_migration',[1,2],None)],
 '0773':[('shared_owner_extension','needs_migration',[0],None),('consumer_integration','needs_migration',[1],None),('consumer_integration','needs_migration',[2,3],'vm-unit-0840-b')],
 '0778':[('consumer_integration','needs_migration',[0,1],None),('consumer_integration','needs_migration',[2,3],None)],
 '0803':[('shared_owner_extension','needs_migration',[2],'vm-unit-0776'),('shared_owner_extension','needs_migration',[0],'vm-unit-0840-a'),('shared_owner_extension','needs_migration',[1],'vm-unit-0840-b')],
 '0840':[('shared_owner_extension','needs_migration',[0],None),('consumer_integration','needs_migration',[1,2,3,4,5],None)],
 '0904':[('consumer_integration','needs_migration',[0],None),('shared_owner_extension','needs_migration',[1,2],None)],
 '0127':[('consumer_integration','needs_migration',[2,3,4,5],None),('shared_owner_extension','needs_migration',[],'vm-unit-0866')],
 '0205':[('consumer_integration','needs_migration',[0],None),('host_abi_transport','needs_migration',[1,2],None)],
 '0207':[('host_abi_transport','needs_migration',[0,1,2],None),('unclassified_pending_owner_trace','pending_audit',[3],None)],
 '0210':[('consumer_integration','needs_migration',[0],None),('shared_owner_extension','needs_migration',[1],None)],
 '0359':[('consumer_integration','needs_migration',[0,1],None),('host_abi_transport','needs_migration',[2],None)],
 '0428':[('consumer_integration','needs_migration',[0,1,2],None),('shared_owner_extension','needs_migration',[3],None)],
 '0457':[('consumer_integration','needs_migration',[0,1],None),('unclassified_pending_owner_trace','pending_audit',[2],None)],
 '0532':[('consumer_integration','needs_migration',[0,1],None),('consumer_integration','needs_migration',[2,3],None),('unclassified_pending_owner_trace','pending_audit',[4,5],None)],
 '0590':[('consumer_integration','needs_migration',[0],None),('unclassified_pending_owner_trace','pending_audit',[1],None)],
 '0592':[('consumer_integration','needs_migration',[1,2],None),('consumer_integration','needs_migration',[3],None),('unclassified_pending_owner_trace','pending_audit',[0],None),('unclassified_pending_owner_trace','pending_audit',[4],None)],
 '0604':[('consumer_integration','needs_migration',[1],None),('unclassified_pending_owner_trace','pending_audit',[0],None)],
 '0714':[('consumer_integration','needs_migration',[0],None),('host_abi_transport','needs_migration',[1,2],None),('shared_owner_extension','needs_migration',[3],None)],
 '0763':[('consumer_integration','needs_migration',[1],'vm-unit-0757'),('unclassified_pending_owner_trace','pending_audit',[0,2,3],None)],
 '0768':[('consumer_integration','needs_migration',[1,2],None),('consumer_integration','needs_migration',[0,3],None)],
 '0808':[('consumer_integration','needs_migration',[0,1,2],None),('unclassified_pending_owner_trace','pending_audit',[3],None)],
 '0837':[('consumer_integration','needs_migration',[0],None),('consumer_integration','needs_migration',[1,2],None)],
 '0862':[('consumer_integration','needs_migration',[2],'vm-unit-0757'),('unclassified_pending_owner_trace','pending_audit',[0,1,4],'vm-unit-0735')],
 '0889':[('consumer_integration','needs_migration',[2],None),('consumer_integration','needs_migration',[0],None),('unclassified_pending_owner_trace','pending_audit',[1],None)],
 '0890':[('consumer_integration','needs_migration',[0],None),('unclassified_pending_owner_trace','pending_audit',[1,2],None)],
 '0902':[('consumer_integration','needs_migration',[0,1],None),('unclassified_pending_owner_trace','pending_audit',[2,3],None)],
 '0926':[('consumer_integration','needs_migration',[0,1,3,4],None),('unclassified_pending_owner_trace','pending_audit',[1,2,3],None)],
 '0933':[('unclassified_pending_owner_trace','pending_audit',[0,1,2],None),('unclassified_pending_owner_trace','pending_audit',[3],None)]
}
# Additional no-evidence bgerror question in0840 has no demonstrated code site. It
# is retained as a question, not padded into a confirmed implementation unit.
extra_questions=[{'id':'vm-question-0840-bgerror','original_row_ids':['vm-0840'],'state':'pending_audit','work_kind':'unclassified_pending_owner_trace','question':'Does actual bgerror List conversion require an additional caller/host-refusal transport beyond the already retained operation? No additional naming repair established.','source_review':'vm-unit-0840','code_change_sites':[]}]
# Explicit unchanged semantic anchors among retained evidence: actual operations
# already exist and cannot be counted again as proposed code changes.
unchanged={
 'vm-unit-host-invoked-object-vector':[],
 'vm-unit-0862':[3],
 'vm-unit-0902':[3],
 'vm-unit-0926':[2],
}
blob={x['path']:x['blob'] for x in rows['consumers']}
textcache={}
def anchor(a,origin,change=True):
 p=a['path'];ls=textcache.setdefault(p,(R/'vm-source'/p).read_text().splitlines());assert ls[a['line']-1]==a['source_line'],(origin,p,a['line'])
 assert sha(R/'vm-source'/p)==a['source_sha256'],p
 return dict(a,blob=blob.get(p),site_kind='reviewed actual semantic expression requiring proposed change' if change else 'reviewed existing guard/context; unchanged',original_unit_id=origin)
projected=[]; retirement=[]; aliases={}; decisions=[]
for oid,u in ou.items():
 r=rv[oid]; cat=r.get('category',r.get('proposed_category'));state=r.get('state','needs_migration')
 if r.get('recommended_unit_retirement'):
  retirement.append({'original_unit_id':oid,'original_row_ids':u['original_row_ids'],'disposition':'shared_owner','reason':r['decision'],'semantic_review':r,'source_sites':[anchor(a,oid,False) for a in r['actual_semantic_anchors']]});continue
 key=oid.removeprefix('vm-unit-'); sp=splits.get(key)
 if r.get('recommended_unit_split'):assert sp,(oid,'missing purpose partition')
 if sp:
  purposes=r['recommended_unit_split']
  #0803 separates two independently selected declaration purposes from its one
  #original freeform second recommendation.0840 leaves unproven bgerror external.
  if key=='0803':purposes=[purposes[0],'Actual Debug static declaration facet','Actual Limit static declaration facet']
  if key=='0840':purposes=purposes[:2]
  if key=='0592':purposes=purposes[:2]+['Legacy STR_REPLACE selected operation/provider admission and original operand requirements','Legacy REGEXP selected operation/provider admission and original operand requirements']
  assert len(sp)==len(purposes),oid
 else:sp=[(cat,state,list(range(len(r['actual_semantic_anchors']))),r.get('recommended_merge_into'))];purposes=[u['purpose']]
 for i,((kind,st,indices,target),purpose) in enumerate(zip(sp,purposes)):
  if isinstance(purpose,dict):purpose=purpose['purpose']
  ident=oid+('-'+chr(97+i) if len(sp)>1 else '')
  v=copy.deepcopy(u);v.update(id=ident,work_kind=kind,state=st,purpose=purpose,required_change=[r['decision'],r['anchor_decision']],canonical_basis='Individual actual semantic review of all357 predecessor units; explicit purpose partition and exact semantic anchors supersede prior coarse category/declaration inference.',semantic_review_ids=[oid],semantic_reviews=[r],predecessor_unit_ids=[oid])
  if len(sp)>1:v['required_change']=[purpose, 'The complete semantic review below retains existing guards and bounds this specific purpose; sibling purposes are separately mapped.']
  idxunch=unchanged.get(oid,[])
  v['code_change_sites']=[anchor(r['actual_semantic_anchors'][j],oid) for j in indices if j not in idxunch]
  v['affected_unchanged_callers']=uniq(v['affected_unchanged_callers']+[anchor(r['actual_semantic_anchors'][j],oid,False) for j in idxunch])
  v['affected_unchanged_callers']=uniq(v['affected_unchanged_callers']+[anchor(a,oid,False) for a in r.get('existing_unchanged_semantic_context',[])])
  if st!='needs_migration':
   v['observed_source_sites']=[dict(a,site_kind='actual candidate semantic site; no required change established') for a in v.pop('code_change_sites')];v['code_change_sites']=[]
  v['existing_api_status']='The semantic review states which facet already exists, which genuinely missing purpose needs owner extension, and which actual provider/caller question remains. Historical API names are context, never a readiness or Native authority grant.'
  v['relative_effort']='XL' if u['relative_effort']=='XL' else 'L' if kind in ['shared_owner_extension','shared_owner_repair'] else u['relative_effort']
  if st!='needs_migration':v['relative_effort']=None
  if target:aliases[ident]=target
  projected.append(v)
# Merge only explicit same-purpose decisions, keeping independently reviewed source
#expressions and row mappings. Aliases may target split children.
by={x['id']:x for x in projected}
def dest(k):
 seen=set()
 while k in aliases:
  assert k not in seen,k;seen.add(k);k=aliases[k]
 assert k in by,k
 return k
if 'vm-unit-0627' in aliases:aliases['vm-unit-0627']='vm-unit-0592-d'
for k,target in list(aliases.items()):
 d=dest(k);a=by[k];b=by[d]
 #Merging0627 legacy-only question into0592's third purpose is explicit.
 if k=='vm-unit-0627':d='vm-unit-0592-d';b=by[d];aliases[k]=d
 if a['state']!=b['state']:
  #The shared purpose destination determines implementation status, preserving
  #both individual review decisions and no claim of implementation acceptance.
  assert k in ['vm-unit-0736','vm-unit-0127-b','vm-unit-0803-b','vm-unit-0803-c'],(k,a['state'],b['state'])
 for f in ['original_row_ids','source_evidence','representation_and_context','existing_shared_api','required_change','control_obligations','affected_unchanged_callers','semantic_review_ids','semantic_reviews','predecessor_unit_ids']:
  b[f]=uniq(b.get(f,[])+a.get(f,[]))
 b['code_change_sites']=uniq(b['code_change_sites']+a.get('code_change_sites',[]))
 b['observed_source_sites']=uniq(b.get('observed_source_sites',[])+a.get('observed_source_sites',[]))
 decisions.append({'source':k,'destination':d,'reason':'Explicit individual same-purpose review; distinct actual changed expressions retained, no similarity merge.'})
kept=[x for x in projected if x['id'] not in aliases]
#Correct host-family linkage: central missing facet is Runtime359, not a second
#VM owner extension or an inference that the ordinary tail ABI loses the head.
host=next(x for x in kept if x['id']=='vm-unit-host-invoked-object-vector')
host.update(family_id='embedding.actual-original-command-vector',cross_owner_dependencies=[{'owner':'runtime','unit_id':'runtime:embedding.actual-original-command-vector:359','api':'tcl-engine-api/src/lib.rs703 HostCommand::invoke_original_completion_with_registrar','purpose':'Genuine original headed invocation facet supplied only by actual dispatcher; ordinary669 tail-only contract unchanged.','counted_in_vm':False,'affected_adapters':['runtime348','Cshim354','EngineTclvm363']}])
#All source-purpose questions are outside the confirmed implementation subtotal.
units=[x for x in kept if x['state']=='needs_migration'];questions=copy.deepcopy(old['unresolved_questions']);valid=copy.deepcopy(old['validation_obligations']);no=copy.deepcopy(old['no_additional_change'])
for x in kept:
 if x['state']=='pending_audit':questions.append(dict(x,question=x['required_change'],id=x['id'].replace('vm-unit-','vm-question-reviewed-')))
 elif x['state']=='pending_validation':valid.append(dict(x,remaining_validation=x['required_change'],reviewed_unit_id=x['id']))
 elif x['state']!='needs_migration':raise AssertionError(x['state'])
questions+=extra_questions
for x in retirement:no.append(x)
#Resolve all row destinations anew. Existing mappings for previously integrated /
#excluded / unresolved rows are retained unless a completed semantic unit reviewed
#that row. Mixed rows deliberately map to each distinct purpose.
mapping=copy.deepcopy(old['original_row_mapping']);revised_rows={r for u in old['units'] for r in u['original_row_ids']}
for r in revised_rows:mapping[r]=[]
for x in units:
 for r in x['original_row_ids']:mapping[r].append({'kind':'remaining_code_unit','unit_id':x['id']})
for i,x in enumerate(questions):
 if x.get('semantic_review_ids') or x['id']=='vm-question-0840-bgerror':
  for r in x['original_row_ids']:mapping[r].append({'kind':'unresolved_question','question_id':x['id']})
for i,x in enumerate(valid):
 if x.get('reviewed_unit_id'):
  for r in x['original_row_ids']:mapping[r].append({'kind':'validation_obligation','index':i,'reviewed_unit_id':x['reviewed_unit_id']})
for i,x in enumerate(no):
 if x.get('original_unit_id'):
  for r in x['original_row_ids']:mapping[r].append({'kind':'no_additional_code_change_for_reviewed_purpose','index':i})
assert set(mapping)==set(byrow) and all(mapping.values())
#Update only the actually reviewed predecessor unit rows. Retain separate purposes
#on mixed rows instead of pretending a single old disposition captures them all.
rowchanges=[]
for row in rows['consumers']:
 if row['id'] not in revised_rows:continue
 rr=[r for r in reviews if row['id'] in ou[r['id']]['original_row_ids']]
 targets=mapping[row['id']]; kinds=uniq([x['work_kind'] for x in kept if row['id'] in x['original_row_ids']])
 states=uniq([x['state'] for x in kept if row['id'] in x['original_row_ids']])
 newdisp='needs_migration' if 'needs_migration' in states else 'pending_audit' if 'pending_audit' in states else 'pending_validation' if 'pending_validation' in states else 'shared_owner'
 oldfields={k:copy.deepcopy(row.get(k)) for k in ['disposition','work_kind','work_kind_reason','missing_integration']}
 row.update(disposition=newdisp,work_kind=kinds[0] if len(kinds)==1 else 'mixed_purpose' if kinds else 'display_exclusion',work_kind_reason='; '.join(uniq([r['decision'] for r in rr])),missing_integration='; '.join(uniq([r['decision'] for r in rr])),semantic_review={'status':'all predecessor canonical purpose and actual semantic associations individually reviewed','review_ids':[r['id'] for r in rr],'canonical_destinations':targets,'purpose_states':states,'work_components':kinds,'historical_fields':oldfields})
 row['work_kind_basis']='Individual completed actual semantic review and explicit canonical purposes; supersedes historical inferred work-kind labels. No execution acceptance.'
 rowchanges.append({'row':row['id'],'before':oldfields,'after':{k:row[k] for k in oldfields},'review_ids':[r['id'] for r in rr]})
#Physical changed sites are expression associations, not estimated patch hunks.
for u in units:
 u['code_change_sites']=uniq(u['code_change_sites'])
 assert u['code_change_sites'],('confirmed unit without actual proposed site',u['id'])
sites={(s['path'],s['line']) for u in units for s in u['code_change_sites']}
families=collections.defaultdict(list)
for u in units:families[u['family_id']].append(u['id'])
counts={'original_purpose_rows':len(byrow),'predecessor_canonical_units_semantically_reviewed':357,'confirmed_remaining_code_units':len(units),'remaining_code_units':len(units),'distinct_physical_source_anchors':len(sites),'families':len(families),'work_kind':dict(collections.Counter(x['work_kind'] for x in units)),'relative_effort':dict(collections.Counter(x['relative_effort'] for x in units)),'unresolved_questions':len(questions),'integrated_validation_obligations':sum(not x.get('reviewed_unit_id') for x in valid),'additional_validation_only_questions':sum(bool(x.get('reviewed_unit_id')) for x in valid),'no_additional_change_records':len(no),'consumer_row_dispositions':dict(collections.Counter(x['disposition'] for x in rows['consumers'])),'explicit_purpose_split_predecessors':len(splits),'explicit_same_purpose_merges':len(aliases),'retired_duplicate_owner_units':len(retirement)}
rows['status']='Complete assigned source closure; all357 predecessor canonical purposes individually semantically corrected. Confirmed implementation requirements, unresolved actual-purpose questions and validation obligations remain separate; no execution acceptance.'
rows['status_review']='vm-category-correction-work:111category+246semantic association reviews, explicit purpose partitions/merges and preserved beforeimages.'
save(G/'vm-consumers.json',rows)
out=copy.deepcopy(old);out.update(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='Corrected source/count proposal after all357 actual semantic association reviews. Confirmed changes only in units; unresolved source/provider/target requirements are questions, not migrated integrations. No execution acceptance.',source_rows_sha256=sha(G/'vm-consumers.json'),coverage_sha256=sha(W/'before-vm-file-coverage.json'),remaining_total=len(units),counts=counts,units=units,families=[{'id':k,'unit_ids':v,'count_purpose':'Purpose family is a coordination/dedup key, not an additional migration unit or an automatic one-owner-per-family assertion.'} for k,v in sorted(families.items())],original_row_mapping=mapping,unresolved_questions=questions,validation_obligations=valid,no_additional_change=no,semantic_review={'predecessor_units':357,'individual_reviews':357,'unchanged_historical_beforeimages':'vm-category-correction-work/before-*','category_and_association_ledger':'vm-category-correction-work/review-state.json','remaining_association_ledger':'vm-category-correction-work/remaining357-review-state.json','explicit_merge_decisions':decisions,'retirements':retirement,'row_changes':'vm-category-correction-work/row-changes.json','limits':'Full source closure and actual semantic review do not establish implementation/oracle execution acceptance. Exact owner-side changed API sites outside assigned files require cross-owner admission; recorded dependencies are not silently counted as VM owner implementations.'})
out['corrections']=uniq(old['corrections']+['vm-category-correction-work/review-state.json','vm-category-correction-work/remaining357-review-state.json','vm-category-correction-work/row-changes.json'])
out['limits']=uniq(old['limits']+['Prior declaration/hash validation is superseded by individual semantic expression association review. Strong existing guards are retained in each semantic decision; unknown or unproven provider purposes are outside confirmed code totals.','Mixed source rows map to multiple genuine purposes. Shared exact-purpose merges retain all actual distinct expression sites and historical row IDs.','Shared owner extension category means a demonstrated missing owner facet plus required consumer transport; owner-side APIs outside this lane remain explicit coordination dependencies. It does not mean every API cited historically is ready, or that all generic family members share one facet.'])
save(G/'vm-migration-units.json',out);save(W/'row-changes.json',{'baseline':old['baseline'],'rows':rowchanges,'limits':'Only previously proposed canonical integration rows changed; unrelated integrated/exclusion rows retained.'})
#Keep full source coverage artifact byte-identical; recomputing it cannot donate
#new semantic/provider/execution coverage.
(G/'vm-file-coverage.json').write_bytes((W/'before-vm-file-coverage.json').read_bytes())
save(W/'projection-boundaries.json',{'baseline':old['baseline'],'split_anchor_ordinals':splits,'merges':decisions,'retired':retirement,'limits':'All splits refer to individually reviewed original semantic expressions. Some expressions are shared by multiple actual purposes; distinct physical site count deduplicates these.'})
print(json.dumps(counts,indent=2))
