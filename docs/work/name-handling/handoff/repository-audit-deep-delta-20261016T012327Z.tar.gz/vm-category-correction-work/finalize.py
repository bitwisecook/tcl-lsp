"""Artifact-only consistency checks and atomic primary publication, no Git/builds."""
import collections,datetime,hashlib,json,os
from pathlib import Path
R=Path('/workspace/name-session/full-consumer-audit');W=R/'vm-category-correction-work';G=W/'generated'
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def pin(p,role=None):
 d={'path':str(p.relative_to(R)),'sha256':sha(p),'bytes':p.stat().st_size}
 if role:d['role']=role
 return d
def write(p,d):
 t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(d,indent=2)+'\n');os.replace(t,p)
u=load(G/'vm-migration-units.json');c=load(G/'vm-consumers.json');old=load(W/'before-vm-migration-units.json');f=load(W/'before-vm-final-audit-receipt.json');reviews=load(W/'review-state.json')['reviews']+load(W/'remaining357-review-state.json')['reviews'];bounds=load(W/'projection-boundaries.json');errors=[]
assert len(reviews)==len({x['id'] for x in reviews})==357
assert {x['id'] for x in reviews}=={x['id'] for x in old['units']}
assert len(c['consumers'])==958 and len({x['id'] for x in c['consumers']})==958
assert sha(G/'vm-consumers.json')==u['source_rows_sha256']
assert sha(G/'vm-file-coverage.json')==u['coverage_sha256']==sha(W/'before-vm-file-coverage.json')==sha(R/'vm-file-coverage.json')
assert len(u['units'])==u['counts']['remaining_code_units']==u['remaining_total']
assert all(x['state']=='needs_migration' for x in u['units'])
ids={x['id'] for x in u['units']};qs={x['id'] for x in u['unresolved_questions']};assert len(ids)==len(u['units']);assert len(qs)==len(u['unresolved_questions'])
for r,m in u['original_row_mapping'].items():
 assert m,r
 for x in m:
  if x['kind']=='remaining_code_unit':assert x['unit_id'] in ids,(r,x)
  elif x['kind']=='unresolved_question':assert x['question_id'] in qs,(r,x)
  elif 'index' in x:
   seq=u['validation_obligations'] if x['kind'] in ['validation_obligation','integrated_validation_obligation'] else u['no_additional_change'];assert 0<=x['index']<len(seq),(r,x)
   assert r in seq[x['index']]['original_row_ids'],(r,x)
  else:raise AssertionError((r,x))
assert set(u['original_row_mapping'])=={x['id'] for x in c['consumers']}
#Both source SHA and actual selected semantic expression membership are checked.
#These are integrity checks of authored reviews, not their semantic justification.
cache={};checked=set();sitekeys=set()
for x in reviews:
 for a in x['actual_semantic_anchors']+x.get('existing_unchanged_semantic_context',[]):
  p=a['path']
  if p not in cache:
   path=R/'vm-source'/p;cache[p]=(sha(path),path.read_text().splitlines())
  h,lines=cache[p];assert h==a['source_sha256'],p;assert lines[a['line']-1]==a['source_line'],(p,a['line']);checked.add((p,a['line']))
for x in u['units']:
 assert x['code_change_sites'],x['id']
 for a in x['code_change_sites']:
  assert (a['path'],a['line']) in checked,(x['id'],a)
  sitekeys.add((a['path'],a['line']))
assert len(sitekeys)==u['counts']['distinct_physical_source_anchors']
assert sum(u['counts']['work_kind'].values())==len(u['units'])
assert sum(u['counts']['relative_effort'].values())==len(u['units'])
assert {x['id'] for x in reviews}=={r for x in u['units']+u['unresolved_questions']+u['validation_obligations'] for r in x.get('semantic_review_ids',[])}|{x['original_unit_id'] for x in bounds['retired']}
#Only individually reviewed predecessor integration rows change in this correction.
origrows={x['id']:x for x in load(W/'before-vm-consumers.json')['consumers']};changed={r for x in old['units'] for r in x['original_row_ids']}
assert all(x==origrows[x['id']] for x in c['consumers'] if x['id'] not in changed)
#Source/report identities are not execution acceptance. No new migrated_verified.
assert not any(x['disposition']=='migrated_verified' for x in c['consumers'])
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
summary={'baseline':u['baseline'],'utc':now,'rows':len(c['consumers']),'work_kind':dict(collections.Counter(x['work_kind'] for x in c['consumers'])),'dispositions':dict(collections.Counter(x['disposition'] for x in c['consumers'])),'confirmed_canonical_work_kind':u['counts']['work_kind'],'confirmed_units':u['remaining_total'],'limits':'Source-row categories are not migration counts. All357 predecessor canonical purposes individually semantically reviewed; mixed rows map to multiple canonical purposes. Questions remain unresolved, not integrated/verified. See corrected catalogue and beforeimages.'}
write(G/'vm-work-kind-summary.json',summary)
peer=R/'root-vm-canonical-boundary-peer.json';assert sha(peer)=='ac1d6ceefa553425b974997ec6d28a9203cd6558088b1009178378f051da9198'
receipt={'baseline':u['baseline'],'utc':now,'status':'Completed individual source-semantic QA and corrected canonical projection, artifact-only. Confirmed implementation requirements and unknown requirements remain distinct. This is not migration completion or provider/test acceptance.','review_coverage':{'all_predecessor_units':357,'former_metadata_units':111,'other_actual_associations':246,'unreviewed_predecessor_units':0,'source_coverage_unchanged':f['coverage']},'counts':u['counts'],'count_reconciliation':{'predecessor_units':357,'explicit_additional_purpose_leaves':sum(len(v)-1 for v in bounds['split_anchor_ordinals'].values()),'explicit_same_purpose_merges':len(bounds['merges']),'retired_duplicate_owner_units':len(bounds['retired']),'confirmed_code_units':len(u['units']),'reviewed_pending_purpose_questions':sum(bool(x.get('semantic_review_ids')) for x in u['unresolved_questions']),'extra_unproven_bgerror_question':1,'reviewed_pending_validation_units':sum(bool(x.get('reviewed_unit_id')) for x in u['validation_obligations']),'note':'The count of remaining implementation purposes excludes unresolved questions; questions are not asserted resolved or waived.'},'integrity':{'errors':[],'unique_original_rows':958,'row_destinations_complete':True,'reviewed_source_semantic_expression_memberships':len(checked),'confirmed_distinct_changed_expression_anchors':len(sitekeys),'untouched_noncanonical_rows_byte_structures_equal':True,'coverage_file_byte_identical':True},'correction_purposes':['Replace coarse111metadata categories with actual required work; keep true target/schema obligations distinct.','All357 actual claimed code-site associations individually reviewed; false declaration/neighbor anchors corrected, existing guards narrow or retract unsupported repairs.','Split actual distinct purposes before explicit same-purpose merges; original rows retain all destination mappings and exact review history.','No unknown implementation/domain/provider question is labeled migrated_validation_pending. Existing345integrated obligations remain execution-pending.','One actual Runtime359 original-headed API owner linked to VM adapter; ordinary tail contract and existing genuine head retention preserved.','Independent original provider/probe APIs and adversarial source inputs stay independent; our validation invocation/path/guard changes remain validation_only.'],'inputs':[pin(W/n) for n in ['before-vm-migration-units.json','before-vm-consumers.json','before-vm-file-coverage.json','before-vm-final-audit-receipt.json','review-state.json','remaining357-review-state.json','projection-boundaries.json','row-changes.json','regenerate.py','finalize.py','pending-sitekind-correction.json']]+[pin(peer,'Independent bounded four-boundary challenge; no whole357 semantic donation.')],'outputs':[pin(G/n) for n in ['vm-consumers.json','vm-migration-units.json','vm-file-coverage.json','vm-work-kind-summary.json']],'limits':u['limits']+['Actual API-side changed-source locations outside this assigned lane are coordination dependencies. Do not treat every cited historical API as an already-ready facet or count generic families as owner repairs.','No source/test/build/provider/network/Git actions in this artifact correction.']}
write(W/'final-semantic-correction-receipt.json',receipt)
#Retain additional old summary before publishing; immutable original4 already held.
bs=W/'before-vm-work-kind-summary.json'
if not bs.exists():bs.write_bytes((R/'vm-work-kind-summary.json').read_bytes())
f.update(utc=now,status='Assigned production/operational source closure retained. Corrected catalogue after all357 individual actual semantic reviews. Artifact-only; implementation requirements and unknown questions remain unfinished, no execution acceptance.',canonical_counts={'purpose_rows':958,'remaining_code_units':len(u['units']),'physical_site_anchors':len(sitekeys),'unresolved_questions':len(u['unresolved_questions']),'integrated_validation_obligations':345,'additional_pending_validation_units':2,'no_additional_change_records':len(u['no_additional_change'])},unit_counts=u['counts'],integrity_errors=[],semantic_correction_receipt='vm-category-correction-work/final-semantic-correction-receipt.json')
inputs=[]
for x in f['inputs']:
 p=G/x['path'] if (G/x['path']).exists() else R/x['path'];d=pin(p);d['path']=x['path']
 if x['path']=='vm-build-migration-units.py':d['role']='Historical coarse generator retained for beforeimage provenance; corrected catalogue uses vm-category-correction-work/regenerate.py.'
 inputs.append(d)
inputs+=[pin(W/'final-semantic-correction-receipt.json'),pin(W/'regenerate.py'),pin(W/'finalize.py')]
f['inputs']=inputs;f['limits']=u['limits'];write(G/'vm-final-audit-receipt.json',f)
#Publish five primary files with atomic replacement and a final manifest marker.
#Root can verify the marker before consuming a coherent snapshot.
for name in ['vm-consumers.json','vm-migration-units.json','vm-work-kind-summary.json','vm-final-audit-receipt.json']:
 p=R/name;t=p.with_suffix('.semantic-correction.tmp');t.write_bytes((G/name).read_bytes());os.replace(t,p)
manifest={'baseline':u['baseline'],'utc':now,'status':'Frozen corrected VM catalogue source/count proposal; all357 predecessor purpose associations reviewed. Root consolidation/global dedup remains independent. No execution acceptance.','files':[pin(R/n) for n in ['vm-consumers.json','vm-migration-units.json','vm-file-coverage.json','vm-work-kind-summary.json','vm-final-audit-receipt.json']]+[pin(W/'final-semantic-correction-receipt.json')],'counts':u['counts'],'integrity_errors':[]}
write(R/'vm-semantic-correction-manifest.json',manifest)
print(json.dumps({'manifest_sha256':sha(R/'vm-semantic-correction-manifest.json'),'receipt_sha256':sha(W/'final-semantic-correction-receipt.json'),'files':manifest['files'],'counts':u['counts']},indent=2))
