#!/usr/bin/env python3
"""Read-only Git/source audit for the original VM133 packet; never invokes its runner."""
import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess

HERE = Path(__file__).resolve().parent
REPO = Path('/workspace/tcl-lsp')
BASE = '2d456966b'
TARGET = '8df9a9169'


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)


def digest(value):
    return hashlib.sha256(value).hexdigest()


def function(source, name):
    matches = list(re.finditer(r'(?m)^\s*fn ' + re.escape(name) + r'\s*\(', source))
    assert len(matches) == 1, name
    start = matches[0].start()
    index = source.index('{', matches[0].end())
    depth = 0
    while index < len(source):
        if source.startswith('//', index):
            end = source.find('\n', index + 2)
            index = len(source) if end < 0 else end
            continue
        if source.startswith('/*', index):
            comment = 1
            index += 2
            while comment:
                if source.startswith('/*', index): comment += 1; index += 2
                elif source.startswith('*/', index): comment -= 1; index += 2
                else: index += 1
                assert index <= len(source)
            continue
        raw = re.match(r'(?:br|r)(#{0,255})"', source[index:])
        if raw:
            end = '"' + raw.group(1)
            index = source.index(end, index + raw.end()) + len(end)
            continue
        if source[index] == '"':
            index += 1
            while source[index] != '"':
                index += 2 if source[index] == '\\' else 1
            index += 1
            continue
        char = re.match(r"'(?:\\(?:u\{[0-9a-fA-F_]+\}|x[0-9a-fA-F]{2}|.)|[^'\\\r\n])'", source[index:])
        if char:
            index += char.end()
            continue
        if source[index] == '{': depth += 1
        if source[index] == '}':
            depth -= 1
            if depth == 0: return source[start:index + 1].encode()
        index += 1
    raise AssertionError('Unclosed original function: ' + name)


def main():
    bindings = json.loads((HERE / 'actual-current-source-binding.json').read_text())['bindings']
    changes = []
    for path, historical in bindings.items():
        old = git('show', BASE + ':' + path)
        new = git('show', TARGET + ':' + path)
        assert digest(old) == historical, path
        if old == new: continue
        before = HERE / 'source-before' / path
        after = HERE / 'source-after' / path
        before.parent.mkdir(parents=True, exist_ok=True); after.parent.mkdir(parents=True, exist_ok=True)
        before.write_bytes(old); after.write_bytes(new)
        changes.append({'path': path, 'before_sha256': digest(old), 'after_sha256': digest(new),
            'before_git_blob': git('rev-parse', BASE + ':' + path).decode().strip(),
            'after_git_blob': git('rev-parse', TARGET + ':' + path).decode().strip(),
            'before_blob': str(before.relative_to(HERE)), 'after_blob': str(after.relative_to(HERE))})
    source_diff = git('diff', '--binary', BASE, TARGET, '--', *(row['path'] for row in changes))
    (HERE / 'source-transition.patch').write_bytes(source_diff)
    root_diff = git('diff', '--binary', BASE, TARGET)
    (HERE / 'root-commit-transition.patch').write_bytes(root_diff)
    audit = json.loads((HERE / 'current-source-selector-audit.json').read_text())
    selected = []
    for row in audit['tests']:
        old = git('show', BASE + ':' + row['path']).decode()
        new = git('show', TARGET + ':' + row['path']).decode()
        before = function(old, row['function']); after = function(new, row['function'])
        selected.append({'build': row['build'], 'selector': row['selector'], 'path': row['path'],
            'function': row['function'], 'before_function_sha256': digest(before),
            'after_function_sha256': digest(after), 'function_byte_identical': before == after})
    (HERE / 'selected-function-preservation.json').write_text(json.dumps({'count': len(selected), 'tests': selected}, indent=2) + '\n')
    manifest = {'prepared_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'historical_commit': git('rev-parse', BASE).decode().strip(),
        'target_commit': git('rev-parse', TARGET).decode().strip(),
        'historical_binding_sha256': digest((HERE / 'actual-current-source-binding.json').read_bytes()),
        'source_transition_patch_sha256': digest(source_diff), 'root_commit_transition_patch_sha256': digest(root_diff),
        'selected_function_audit_sha256': digest((HERE / 'selected-function-preservation.json').read_bytes()),
        'historical_binding_count': len(bindings), 'changed_live_source_count': len(changes), 'changes': changes,
        'root_commit_chain': git('log', '--reverse', '--format=%H %s', BASE + '..' + TARGET).decode().splitlines(),
        'review_scope': 'Extend only exact original live-source hash checks from the retained 2d456966b images to reviewed frozen 8df9a9169; all original source chains remain immutable. Root source/API peer receipts are separate from execution acceptance.',
        'cargo_executed': False, 'binary_list_executed': False, 'test_executed': False}
    (HERE / 'source-successor-2d-to-8df.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({'changed_paths': len(changes), 'selected_controls': len(selected), 'changed_functions': [r['selector'] for r in selected if not r['function_byte_identical']]}))


if __name__ == '__main__': main()
