# Proposed VM133 source rebind — frozen 8df9a9169

This is a read-only preparation packet. Root alone may build, list binaries or
execute the replay. No Cargo, ELF list or selected test has been run here.

The immutable original packet is
`/workspace/name-session/validation-plans/name-vm-current238-full133-plan-20261015`.
Its 71 file checksums are retained in `original-packet-checksums.json`; all 70
entries in its original `packet-manifest.json` verified. That manifest remains
historical. Its original runner bytes are preserved separately in
`original-run-main-vm.py`; the proposed runner and its exact patch are separate
current artifacts. No historical source or provider record was rewritten.

All 58 historical current238 bindings match actual Git source at
`2d456966b4619af28250e73e8585e4dac49be454`. Exactly eight files changed through
`8df9a91699c0907ae3e0aefa1b10396feb967e8f`. The source successor record retains
their exact before/after bytes, Git blob identities, scoped patch and complete
root commit diff. All 133 selected Rust function bodies are byte-identical
between these commits. Their selectors, assertions and budgets remain intact.

The proposed runner adds a strict target-HEAD and source-successor guard. Four
existing live source hash checks pass their original expected digest through
that guard. A changed file accepts only its exact matching historical digest
and exact reviewed afterimage; unchanged files retain the original digest.
All historical chain arithmetic and required-image inventories remain intact.
The selected control union/order, 180-second individual budgets, original
automatic error programs, original provider checks, actual compiled dependency
closure, artifact selection, nonempty binary lists, exact one-test execution
checks and before/after drift checks remain unchanged.

The fresh provider receipt is separate from historical `provider-check.json`.
GitHub HEAD was rechecked at 2026-10-15 11:27:38 UTC and still resolves to
`5bac7c99ad65864c87da513e22e2f01703fa4e03`. The actual supplied original Jim
binary, source revision and metadata remain equal to the historical provider:
binary SHA256 `c5b2b0c37c3bad8e97760350460310bde65e74cf9833979fe1c088e4dd2a4891`,
patchlevel `0.84-9-g5bac7c9`. The proposed runner preserves the old binary,
revision and version checks and additionally binds the 13 freshly hashed Jim
inputs. This metadata query was read-only and is not a test result.

Source/API peer context for the retained root commits:

- `551f3b2c1`: original selected namespace retirement and Parent-holder source
  reviewed by Compiler and Runtime peers; exact ancestor relation, birth and
  generic-currentness boundaries preserved.
- `a3e3d7949`: canonical object construction and original nested caller checks
  reviewed by LSP and Runtime peers, including original argument header liveness.
- `a9fca77c1`: typed Parent result and authentic subcommand cache/arity producer
  reviewed by LSP and Runtime peers; execution remained pending.
- `7100086d2`, `5e3aa3278`, `8df9a9169`: Root integration/validation corrections
  retained in the complete root diff. Selected VM133 functions remain unchanged.

These are bounded source reviews, not Native execution, source-purpose
admission, compilation or replay acceptance. Root must review and approve the
proposed runner/afterimage extension and retain ordinary compiled closure and
artifact snapshots at execution.

Current blockers: the frozen worktree has none of the runner's canonical
`tmp/tcl8.4.20`, `tmp/tcl8.5.19`, `tmp/tcl8.6.18`, `tmp/tcl9.0.4`,
`tmp/tcl9.1.0` or `tmp/jimtcl-oracle` provider paths provisioned. Root may
symlink these to the original trees after checking exact original
binary/library/harness pairing. This preparer created no provider symlink.
The replay also requires Root's exclusive heavy lease and an ordinary build
with diagnostic traces disabled. The source/hash preflight passes independently
of those execution prerequisites.

Proposed command, only after Root resolves those blockers:

```sh
python3 /workspace/name-session/vm-f-rebind/run-main-vm.py \
  --root /workspace/name-validation \
  --out <fresh-root-owned-output-directory> \
  --target <root-owned-isolated-Cargo-target>
```
