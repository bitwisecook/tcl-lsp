"""Exact reviewed live-source successor guard; no resolver or execution admission."""
import hashlib
import json
from pathlib import Path
import subprocess


TRANSITION_SHA256 = '21b1c963b83dd8b1bc6eccef4c528937b7a9ddcef3833139a7bdcbe03599f0fc'
ORIGINAL_CHECKSUMS_SHA256 = '9f3bd1a717b3c461cb5bbcef41a7e8d95b08b0ccd63588fdaf38ea26e244c812'
FRESH_PROVIDER_SHA256 = 'a9ffb36b2f143ff8102b078f98b364cc5e561877170f31420ab7ab3680b29c33'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def validate(packet, root):
    transition_path = packet / 'source-successor-2d-to-8df.json'
    original_path = packet / 'original-packet-checksums.json'
    if digest(transition_path) != TRANSITION_SHA256 or digest(original_path) != ORIGINAL_CHECKSUMS_SHA256:
        raise ValueError('Reviewed frozen source transition or original packet checksum receipt changed')
    original = json.loads(original_path.read_text())
    for name, expected in original['files'].items():
        current = packet / ('original-run-main-vm.py' if name == 'run-main-vm.py' else name)
        if digest(current) != expected:
            raise ValueError('Immutable original VM133 packet input changed: ' + name)
    transition = json.loads(transition_path.read_text())
    current_head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
    if current_head != transition['target_commit']:
        raise ValueError('VM133 rebind requires the exact frozen 8df9a9169 root; current HEAD is ' + current_head)
    if transition['historical_commit'] != '2d456966b4619af28250e73e8585e4dac49be454':
        raise ValueError('Historical source commit changed')
    binding = packet / 'actual-current-source-binding.json'
    if digest(binding) != transition['historical_binding_sha256']:
        raise ValueError('Historical current238 binding record changed')
    historical = json.loads(binding.read_text())['bindings']
    changes = transition['changes']
    if len(historical) != 58 or len(changes) != 8 or len({row['path'] for row in changes}) != 8:
        raise ValueError('Frozen source successor inventory changed')
    for row in changes:
        path = row['path']
        if historical[path] != row['before_sha256']:
            raise ValueError('Source transition does not continue the historical binding: ' + path)
        for stage, commit in [('before', transition['historical_commit']), ('after', transition['target_commit'])]:
            retained = packet / row[stage + '_blob']
            actual = subprocess.check_output(['git', 'show', commit + ':' + path], cwd=root)
            blob = subprocess.check_output(['git', 'rev-parse', commit + ':' + path], cwd=root, text=True).strip()
            if digest(retained) != row[stage + '_sha256'] or hashlib.sha256(actual).hexdigest() != row[stage + '_sha256'] or blob != row[stage + '_git_blob']:
                raise ValueError('Exact historical/frozen source blob differs: ' + path)
        if digest(root / path) != row['after_sha256']:
            raise ValueError('Frozen live source afterimage differs: ' + path)
    for name, expected in [('source-transition.patch', transition['source_transition_patch_sha256']), ('root-commit-transition.patch', transition['root_commit_transition_patch_sha256']), ('selected-function-preservation.json', transition['selected_function_audit_sha256'])]:
        if digest(packet / name) != expected:
            raise ValueError('Retained source transition evidence differs: ' + name)
    audit = json.loads((packet / 'selected-function-preservation.json').read_text())
    if audit['count'] != 133 or len(audit['tests']) != 133 or any(not row['function_byte_identical'] or row['before_function_sha256'] != row['after_function_sha256'] for row in audit['tests']):
        raise ValueError('Original VM133 selected function preservation receipt changed')
    if digest(packet / 'fresh-provider-check.json') != FRESH_PROVIDER_SHA256:
        raise ValueError('Reviewed fresh provider record changed')
    fresh = json.loads((packet / 'fresh-provider-check.json').read_text())
    upstream = packet / fresh['fresh_upstream_receipt']
    if digest(upstream) != fresh['fresh_upstream_receipt_sha256'] or json.loads(upstream.read_text())['commit']['sha'] != fresh['local_revision'] or not fresh['matches_current_upstream_head']:
        raise ValueError('Fresh provider source/head equality receipt changed')
    old_provider = json.loads((packet / 'provider-check.json').read_text())
    if digest(packet / 'provider-check.json') != fresh['historical_provider_check_sha256'] or any(fresh[key] != old_provider[key] for key in ['local_revision', 'interpreter_sha256', 'reported_version', 'original_jim_c_sha256']):
        raise ValueError('Fresh provider no longer preserves the exact historical original')
    return {row['path']: row for row in changes}


def live_hash(changes, path, historical):
    successor = changes.get(path)
    if successor is None:
        return historical
    if successor['before_sha256'] != historical:
        raise ValueError('Frozen live-source guard does not continue its exact original purpose/hash: ' + path)
    return successor['after_sha256']
