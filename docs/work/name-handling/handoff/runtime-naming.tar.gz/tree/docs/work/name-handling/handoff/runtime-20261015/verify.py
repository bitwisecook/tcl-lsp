from pathlib import Path
import argparse,hashlib,json
p=argparse.ArgumentParser();p.add_argument('--repository-root',type=Path);p.add_argument('--current-provider',action='store_true');a=p.parse_args();base=Path(__file__).resolve().parent;root=a.repository_root or base.parents[4];m=json.loads((base/'transport-manifest.json').read_text());h=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
for row in m['files']:assert h(base/row['path'])==row['sha256'],row['path']
refs=json.loads((base/'provider-references.json').read_text())['references']
for row in refs:assert h(root/row['repository_path'])==row['sha256'],row['repository_path']
if a.current_provider:
 for label in ['helper-prefix-sdk200','import-sdk297']:
  old=json.loads((base/label/'manifest.json').read_text());assert old['provider_before_sha256']==old['provider_after_sha256']
  for path,digest in old['provider_before_sha256'].items():assert h(root/'tmp/jimtcl-oracle'/Path(path).name)==digest,path
print(json.dumps({'transport_files':len(m['files']),'exact_original_copies':len(m['original_files']),'canonical_provider_references':len(refs),'current_provider_checked':a.current_provider,'provider_executed':False}))
