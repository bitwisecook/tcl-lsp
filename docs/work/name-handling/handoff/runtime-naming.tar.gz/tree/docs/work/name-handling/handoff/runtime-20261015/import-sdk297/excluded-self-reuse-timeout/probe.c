// tcl-lsp — a language server and toolchain for Tcl
// Copyright (C) 2026 James Deucker (bitwisecook) <https://github.com/bitwisecook>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.
//
// SPDX-License-Identifier: AGPL-3.0-or-later



#include <stdio.h>
#include <string.h>
#include "jim.h"
static const char *label;
static Jim_Obj *caller;
static void sample(const char *kind, Jim_Obj *object) {
    printf("%s|%s|%d|%s\n",kind,label,object->bytes!=NULL,object->typePtr?object->typePtr->name:"none");
}
static void update_pattern(Jim_Obj *object) {
    const char *payload=object->internalRep.ptr;
    sample("CALLER_AT_PATTERN_GETTER",caller);
    object->length=(int)strlen(payload);object->bytes=Jim_Alloc(object->length+1);
    memcpy(object->bytes,payload,object->length+1);
}
static const Jim_ObjType pattern_type={"import-pattern-probe",NULL,NULL,update_pattern,JIM_TYPE_NONE};
static Jim_Obj *pattern(Jim_Interp *i,const char *payload) {
    Jim_Obj *o=Jim_NewStringObj(i,"",0);Jim_InvalidateStringRep(o);
    o->typePtr=&pattern_type;o->internalRep.ptr=(void *)payload;Jim_IncrRefCount(o);return o;
}
static Jim_Interp *fresh(void) {
    Jim_Interp *i=Jim_CreateInterp();Jim_RegisterCoreCommands(i);
    return Jim_InitStaticExtensions(i)==JIM_OK ? i:NULL;
}
static void bytes(const char *kind,int code,Jim_Obj *object) {
    int length;const char *data=Jim_GetString(object,&length);printf("%s|%s|%d|",kind,label,code);
    for(int n=0;n<length;n++)printf("%02x",(unsigned char)data[n]);puts("");
}
int main(void) {
    setvbuf(stdout,NULL,_IONBF,0);
    Jim_Interp *v=fresh();if(!v)return 2;label="VERSION";
    Jim_Eval(v,"info patchlevel");bytes("RESULT",0,Jim_GetResult(v));Jim_FreeInterp(v);
    const struct {const char *name;int direct,count,change,setup;const char *payload;} cases[]={
      {"PUBLIC_ZERO",0,0,0,0,"84::*"},{"DIRECT_ZERO",1,0,0,0,"84::*"},
      {"PUBLIC_RELATIVE",0,1,0,0,"84::*"},{"DIRECT_RELATIVE",1,1,0,0,"84::*"},
      {"PUBLIC_ABSOLUTE",0,1,0,0,"::42::84::*"},{"DIRECT_ABSOLUTE",1,1,0,0,"::42::84::*"},
      {"PUBLIC_MISSING",0,1,0,0,"absent::*"},{"DIRECT_MISSING",1,1,0,0,"absent::*"},
      {"PUBLIC_MULTI",0,2,0,0,"84::*"},{"DIRECT_MULTI",1,2,0,0,"84::*"},
      {"PUBLIC_SELF",0,1,0,1,"::42::target"},{"DIRECT_SELF",1,1,0,1,"::42::target"},
      {"PUBLIC_CONFLICT",0,1,0,1,"84::*"},{"DIRECT_CONFLICT",1,1,0,1,"84::*"},
      {"PUBLIC_REPLACED",0,1,1,0,"84::*"},{"DIRECT_REPLACED",1,1,1,0,"84::*"},
      {"PUBLIC_DELETED",0,1,2,0,"84::*"},{"DIRECT_DELETED",1,1,2,0,"84::*"}
    };
    for(unsigned n=0;n<sizeof(cases)/sizeof(cases[0]);n++) {
      Jim_Interp *i=fresh();if(!i)return 3;
      if(Jim_Eval(i,"proc ::42::84::target args {return TARGET}; proc ::42::85::other args {return OTHER}; alias ::42::84::aliased ::42::85::other")!=JIM_OK)return 4;
      if(cases[n].setup && Jim_Eval(i,"proc ::42::target args {return PRIOR}")!=JIM_OK)return 5;
      if(cases[n].change && Jim_Eval(i,cases[n].change==1?
          "rename {namespace import} saved; proc {namespace import} {args} {return $args}":
          "rename {namespace import} {}")!=JIM_OK)return 6;
      Jim_Obj *head=Jim_NewStringObj(i,cases[n].direct?"namespace import":"namespace",-1);Jim_IncrRefCount(head);
      Jim_Obj *member=Jim_NewStringObj(i,"import",-1);Jim_IncrRefCount(member);
      caller=Jim_NewIntObj(i,42);Jim_IncrRefCount(caller);
      for(int reuse=0;reuse<2;reuse++) {
        char phase[128];snprintf(phase,sizeof(phase),"%s_%s",cases[n].name,reuse?"REUSE":"COLD");label=phase;
        if(reuse)Jim_InvalidateStringRep(caller);
        Jim_Obj *first=pattern(i,cases[n].payload),*second=pattern(i,"85::*");
        Jim_Obj *argv[4];int argc=0;argv[argc++]=head;if(!cases[n].direct)argv[argc++]=member;
        if(cases[n].count>0)argv[argc++]=first;if(cases[n].count>1)argv[argc++]=second;
        Jim_Obj *vector=Jim_NewListObj(i,argv,argc);Jim_IncrRefCount(vector);
        sample("CALLER_BEFORE",caller);sample("FIRST_BEFORE",first);sample("SECOND_BEFORE",second);
        int code=Jim_EvalNamespace(i,vector,caller);
        sample("CALLER_AFTER",caller);sample("FIRST_AFTER",first);sample("SECOND_AFTER",second);
        if(cases[n].change==1)printf("REPLACEMENT_ARG_IS_ORIGINAL|%s|%d\n",label,
          Jim_ListLength(i,Jim_GetResult(i))==1 && Jim_ListGetIndex(i,Jim_GetResult(i),0)==first);
        bytes("RESULT",code,Jim_GetResult(i));
        code=Jim_Eval(i,"info alias ::42::target");bytes("IMPORTED_TARGET_PREFIX",code,Jim_GetResult(i));
        code=Jim_Eval(i,"info alias ::42::aliased");bytes("IMPORTED_CHAIN_PREFIX",code,Jim_GetResult(i));
        Jim_DecrRefCount(i,vector);Jim_DecrRefCount(i,first);Jim_DecrRefCount(i,second);
      }
      Jim_DecrRefCount(i,head);Jim_DecrRefCount(i,member);Jim_DecrRefCount(i,caller);Jim_FreeInterp(i);
    }
    return 0;
}
