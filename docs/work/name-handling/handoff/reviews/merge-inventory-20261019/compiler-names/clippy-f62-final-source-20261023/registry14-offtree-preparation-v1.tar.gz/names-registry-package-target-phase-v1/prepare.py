from pathlib import Path
import json,hashlib,subprocess,difflib,re
b=Path(__file__).parent;root=Path('/workspace/naming-migration-publish/tcl-lsp');files={};fmt='/workspace/.rustup/toolchains/1.99.1-x86_64-unknown-linux-gnu/bin/rustfmt'
def load(rel):s=(root/rel).read_text();files[rel]=[s,s];return s
def save(rel,s):files[rel][1]=s
rel='rust/tcl-compiler/src/registry_invocation/source_structure/package_target_survey.rs';s=load(rel)
a=s.index('        let (outer_query, release_arity) =',s.index('    pub fn target_guard('));z=s.index('        if outer_query.query',a);old=s[a:z]
body=old[old.index('                let decided ='):old.index('            })??;')]
release='''type PackageQueryReleaseArity = (
    tcl_registry::source_navigation::SourcePackageQueryInvocation,
    Vec<(tcl_dialect::TclVersion, bool)>,
);

fn package_query_release_arity(
    schema: &tcl_registry::ResolvedInvocation<'_, '_>,
) -> Option<PackageQueryReleaseArity> {
'''+ '\n'.join(x[12:] if x.startswith('            ') else x for x in body.rstrip().splitlines())+'\n}\n\n'
s=s[:a]+'''        let (outer_query, release_arity) =
            outer_words.with_source_schema(&registry_context, package_query_release_arity)??;
'''+s[z:]
a=s.index('        if ![\n',s.index('    pub fn target_guard('));z=s.index('        Some(OriginalPackageIndexTargetGuard {',a);old=s[a:z]
# All original subject/requirements/model/ancestor queries remain inside one phase.
phase='''    fn target_guard_components(
        &self,
        parent: &tcl_lexer::NativeScriptCommandWords,
        outer: &tcl_lexer::NativeScriptCommandWords,
        inner: &super::OriginalSingleSourceCommandSubstitution,
        subject: &str,
        outer_words: &OriginalRegistryWords,
        outer_query: &tcl_registry::source_navigation::SourcePackageQueryInvocation,
    ) -> Option<TargetGuardComponents> {
'''+old.replace('row.name == subject', 'row.name == subject').replace('self.model(parent, &subject)', 'self.model(parent, subject)').replace('self.model(outer, &subject)', 'self.model(outer, subject)').replace('self.model(inner.command(), &subject)', 'self.model(inner.command(), subject)').replace('ancestor.model(command, &subject)', 'ancestor.model(command, subject)')+'''        Some(TargetGuardComponents { requirements, models })
    }

'''
s=s[:a]+'''        let TargetGuardComponents { requirements, models } =
            self.target_guard_components(parent, outer, &inner, &subject, &outer_words, &outer_query)?;
'''+s[z:]
a=s.index('        let mut syntax =',s.index('    pub fn target_guard('));z=s.index('        let scripts =',a);old=s[a:z]
phase+='    fn target_guard_expression(&self, text: &str) -> Option<TargetGuardExpression> {\n'+old+'        Some(TargetGuardExpression { syntax, tree, negated, extent })\n    }\n\n'
s=s[:a]+'        let TargetGuardExpression { syntax: _syntax, tree: _tree, negated, extent } =\n            self.target_guard_expression(text)?;\n'+s[z:]
a=s.index('    /// Whole original braced Expr');s=s[:a]+phase+s[a:]
a=s.index('impl OriginalPackageIndexSourceSurvey');s=s[:a]+'''struct TargetGuardExpression {
    syntax: tcl_syntax::expr::parser::ExprParseContext,
    tree: ExprNode,
    negated: bool,
    extent: tcl_lexer::Span,
}

struct TargetGuardComponents {
    requirements: Vec<String>,
    models: Vec<crate::command_binding::OriginalPackageIndexSourceModel>,
}

'''+release+s[a:];save(rel,s)
names=['target_guard','target_guard_components','package_query_release_arity','target_guard_expression']
manifest=[];patch=[];counts={}
for rel,(old,new) in files.items():
 for sub,data in [('before',old),('proposed',new)]:p=b/sub/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(data)
 p=b/'proposed'/rel;subprocess.run([fmt,'--edition','2024','--config','skip_children=true',str(p)],check=True);new=p.read_text()
 for name in names:
  match=re.search(r'fn '+name+r'(?:<[^>]*>)?\(',new)
  if not match:continue
  a=new.index('{',match.start());i=a+1;d=1
  while d:d+=(new[i]=='{')-(new[i]=='}');i+=1
  counts[name]=len([line for line in new[a+1:i-1].splitlines() if line.strip() and not line.strip().startswith('//')])
 pat=r'\b(?:assert|assert_eq|assert_ne|debug_assert|debug_assert_eq|debug_assert_ne)!';assert [x for x in old.splitlines() if re.search(pat,x)]==[x for x in new.splitlines() if re.search(pat,x)]
 h=lambda v:hashlib.sha256(v.encode()).hexdigest();manifest.append({'path':rel,'before_sha256':h(old),'after_sha256':h(new)});patch.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
assert max(counts.values())<=100,counts
p=b/'proposal.patch';p.write_text(''.join(patch));m={'files':manifest,'patch_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'fresh_f62_indices':[84],'body_counts_after':counts,'scope':'Package target source survey length site: exact original schema release arity/query phase and subject/requirements/same-context models/ancestor model phase. All parent owners retained; no visibility/public API, source/owner/policy/three-state refusal, query/evaluation order or assertion changes.','limits':'Off-tree preparation/fmt/assertions only; no Cargo/typecheck/Clippy/runtime; independent type/owner/query/drop review required.'};(b/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(m['patch_sha256'],counts)
