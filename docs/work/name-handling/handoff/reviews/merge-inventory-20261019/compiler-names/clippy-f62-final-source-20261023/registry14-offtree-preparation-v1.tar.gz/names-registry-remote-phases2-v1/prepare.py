from pathlib import Path
import json,hashlib,subprocess,difflib,re
b=Path(__file__).parent;root=Path('/workspace/naming-migration-publish/tcl-lsp');files={};fmt='/workspace/.rustup/toolchains/1.99.1-x86_64-unknown-linux-gnu/bin/rustfmt'
def load(rel):s=(root/rel).read_text();files[rel]=[s,s];return s
def save(rel,s):files[rel][1]=s
rel='rust/tcl-compiler/src/registry_invocation/source_remote_first_operand.rs';s=load(rel)
a=s.index('                let handle_at =',s.index('    fn scan_commands('));z=s.index('                remote_source_trace!(',a);old=s[a:z]
body=old.replace('                    calls.push(OriginalSourceRemoteFirstOperandAssociation {','                    return Some(OriginalSourceRemoteFirstOperandAssociation {').replace('                    });','                    });')
helper='''    fn first_remote_operand(
        &self,
        words: &OriginalRegistryWords,
        layout: RemoteCallSpec,
        bindings: &[(String, Arc<OriginalSourceRemoteResultAssociation>)],
        body_path: &[OriginalRegistryWords],
    ) -> Option<OriginalSourceRemoteFirstOperandAssociation> {
'''+ '\n'.join(x[8:] if x.startswith('        ') else x for x in body.rstrip().splitlines())+'\n        None\n    }\n\n'
s=s[:a]+'''                if let Some(call) = self.first_remote_operand(&words, layout, bindings, body_path) {
                    calls.push(call);
                }
'''+s[z:]
a=s.index('        if let Some(keyword) = layout.keyword',s.index('    fn binding('));z=s.index('        let variable_word =',a);old=s[a:z]
helper+='''    fn setter_keyword_matches(
        setter: &OriginalRegistryWords,
        layout: &HandleBindingSpec,
    ) -> Option<()> {
'''+old+'        Some(())\n    }\n\n'
s=s[:a]+'        Self::setter_keyword_matches(setter, &layout)?;\n'+s[z:]
a=s.index('        if original.len().checked_sub(1)?',s.index('    fn binding('));z=s.index('        Some((\n',a);old=s[a:z]
helper+='''    fn constructor_operands_match(
        &self,
        original: &[NativeWord],
        constructor: &OriginalRegistryWords,
        constructor_layout: RemoteHandleSpec,
    ) -> Option<()> {
'''+old+'        Some(())\n    }\n\n'
s=s[:a]+'        self.constructor_operands_match(original, &constructor, constructor_layout)?;\n'+s[z:]
a=s.index('                if !summary.admits_source_setter',s.index('    fn scan_commands('));z=s.index('                {\n',a);condition=s[a:z];assert condition.startswith('                if ')
helper+='    fn setter_operands_are_eligible(\n        &self,\n        summary: &SourceSummary,\n        key: &str,\n        pending: &OriginalSourceRemoteResultAssociation,\n        original: &[NativeWord],\n    ) -> bool {\n'+condition[len('                if '):].replace('command.words.iter()', 'original.iter()').replace('Some(&key)', 'Some(key)').replace('.as_ref()', '.as_deref()')+'\n    }\n\n'
s=s[:a]+'                if !self.setter_operands_are_eligible(&summary, &key, &pending, &command.words)\n'+s[z:]
# The extracted expression above is the original refusal condition, so its name
# reports refusal directly rather than negating a changed conjunction.
s=s.replace('setter_operands_are_eligible', 'setter_operands_refuse').replace('if !self.setter_operands_refuse(', 'if self.setter_operands_refuse(')
helper=helper.replace('setter_operands_are_eligible','setter_operands_refuse')
a=s.index('        let plan = tcl_lexer::native_script_words_in_with_purpose(',s.index('    fn binding('));z=s.index('        let original =',a);old=s[a:z]
helper+='    fn single_constructor_plan(&self, body: tcl_lexer::Span) -> Option<tcl_lexer::NativeScriptWordsPlan> {\n'+old+'        Some(plan)\n    }\n\n'
s=s[:a]+'        let plan = self.single_constructor_plan(body)?;\n'+s[z:]
a=s.index('    fn selected_setter_rhs_script(');s=s[:a]+helper+s[a:];save(rel,s)
names=['scan_commands','binding','first_remote_operand','setter_keyword_matches','constructor_operands_match','single_constructor_plan','setter_operands_refuse']
manifest=[];patch=[];counts={}
for rel,(old,new) in files.items():
 for sub,data in [('before',old),('proposed',new)]:p=b/sub/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(data)
 p=b/'proposed'/rel;subprocess.run([fmt,'--edition','2024','--config','skip_children=true',str(p)],check=True);new=p.read_text()
 for name in names:
  match=re.search(r'fn '+name+r'(?:<[^>]*>)?\(',new)
  if not match:continue
  a=new.index('{',match.start());i=a+1;d=1
  while d:d+=(new[i]=='{')-(new[i]=='}');i+=1
  counts[name]=len([line for line in new[a+1:i-1].splitlines() if line.strip() and not line.strip().startswith('//')])
 pat=r'\b(?:assert|assert_eq|assert_ne|debug_assert|debug_assert_eq|debug_assert_ne)!';assert [x for x in old.splitlines() if re.search(pat,x)]==[x for x in new.splitlines() if re.search(pat,x)]
 h=lambda v:hashlib.sha256(v.encode()).hexdigest();manifest.append({'path':rel,'before_sha256':h(old),'after_sha256':h(new)});patch.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
assert max(counts.values())<=100,counts
p=b/'proposal.patch';p.write_text(''.join(patch));m={'files':manifest,'patch_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'fresh_f62_indices':[90,91],'body_counts_after':counts,'scope':'Two remote source association length sites: identical first-operand eligibility and result construction, setter keyword check and constructor literal/arity eligibility. Unconditional post-call association clear/barrier and all source debts retained. All parent owners retained; no visibility/public API, source/owner/policy/three-state refusal, query/evaluation order or assertion changes.','limits':'Off-tree preparation/fmt/assertions only; no Cargo/typecheck/Clippy/runtime; independent type/owner/query/drop review required.'};(b/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(m['patch_sha256'],counts)
