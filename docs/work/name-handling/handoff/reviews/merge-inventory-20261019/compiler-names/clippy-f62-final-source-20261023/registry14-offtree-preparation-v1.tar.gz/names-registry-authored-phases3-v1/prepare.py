from pathlib import Path
import json,hashlib,subprocess,difflib,re
b=Path(__file__).parent;root=Path('/workspace/naming-migration-publish/tcl-lsp');files={};fmt='/workspace/.rustup/toolchains/1.99.1-x86_64-unknown-linux-gnu/bin/rustfmt'
def load(rel):s=(root/rel).read_text();files[rel]=[s,s];return s
def save(rel,s):files[rel][1]=s
rel='rust/tcl-compiler/src/registry_invocation/authored_controls.rs';s=load(rel);a=s.index('    if variables.frame_kind !=',s.index('pub(crate) fn original_authored_scalar_invocation('));z=s.index('    let frame_local =',a);old=s[a:z];assert old.endswith('    {\n        return None;\n    }\n')
helper='''fn authored_scalar_context_is_local(
    variables: &crate::var_resolve::ResolveContext,
    scope: &OriginalAuthoredSourceBodyScope,
) -> bool {
    variables.frame_kind == crate::var_resolve::VariableFrameKind::Local
        && variables
            .execution_name_policy
            .is_none_or(|policy| scope.retains_authored_source_name_policy(policy))
        && variables.interpreter.is_none()
        && variables.execution.is_none()
        && variables.hosted_execution_context.is_none()
        && !variables.dynamic_bindings
        && !variables.dynamic_traces
        && variables.globals.is_empty()
        && variables.ns_vars.is_empty()
        && variables.upvar_aliases.is_empty()
        && variables.instance_vars.is_empty()
        && variables.alias_bindings.is_empty()
        && variables.namespace_alias_bindings.is_empty()
        && variables.name_alias_bindings.is_empty()
        && variables.namespace_name_alias_bindings.is_empty()
        && variables.traced.is_empty()
        && variables.trace_registrations.is_empty()
        && variables.untracked_traces.is_empty()
        && variables.possible_trace_registrations.is_empty()
}

'''
s=s[:a]+'    if !authored_scalar_context_is_local(variables, scope) {\n        return None;\n    }\n'+s[z:];a=s.index('/// Scalar syntax from the exact Standalone');s=s[:a]+helper+s[a:];save(rel,s)
rel='rust/tcl-compiler/src/registry_invocation/authored_body_scope.rs';s=load(rel);start=s.index('pub(crate) fn original_authored_parameter_source_command_for_module(');a=s.index('    let (roles, aliases, continues) = scope.with_source_schema',start);z=s.index('    Some(OriginalAuthoredParameterSourceCommand {',a);old=s[a:z];prefix='    let (roles, aliases, continues) = scope.with_source_schema(tokens, registry, |schema| {\n';assert old.startswith(prefix) and old.endswith('    })?;\n')
body=old[len(prefix):-len('    })?;\n')]
body=body.replace('        Some((roles, aliases, continues))','        Some(AuthoredParameterSourceEffects { roles, aliases, continues })')
helper='''struct AuthoredParameterSourceEffects {
    roles: Vec<(usize, tcl_registry::ArgRole)>,
    aliases: Vec<tcl_registry::VariableCellAliasTransition>,
    continues: bool,
}

fn authored_parameter_source_effects(
    schema: &tcl_registry::ResolvedInvocation<'_, '_>,
    selected: &super::ResolvedStatementInvocation,
    dialect: tcl_registry::InvocationDialect,
) -> Option<AuthoredParameterSourceEffects> {
'''+ '\n'.join(x[4:] if x.startswith('    ') else x for x in body.rstrip().splitlines())+'\n}\n\n'
call='''    let AuthoredParameterSourceEffects { roles, aliases, continues } =
        scope.with_source_schema(tokens, registry, |schema| {
            authored_parameter_source_effects(schema, &selected, dialect)
        })?;
''';s=s[:a]+call+s[z:];a=s.index('/// Reborrow genuine original declaration/source syntax');s=s[:a]+helper+s[a:];save(rel,s)
rel='rust/tcl-compiler/src/registry_invocation/declaration_assistance.rs';s=load(rel);a=s.index('        let logical_name_obligations = match words.source() {');z=s.index('        // Source frame applicability',a);old=s[a:z];expr=old[len('        let logical_name_obligations = '):].rstrip();assert expr.endswith(';');expr=expr[:-1];expr=expr.replace('written_alias_operand(&words,','written_alias_operand(words,')
helper='''type LogicalAliasNameObligation = (
    tcl_lexer::Span,
    Option<tcl_registry::VariableAliasDestination>,
);

fn original_logical_alias_name_obligations(
    words: &super::source_structure::OriginalRegistryWords,
    context: &tcl_registry::model::ContextRegistry,
) -> Option<Vec<LogicalAliasNameObligation>> {
    Some('''+'\n'.join(x[8:] if x.startswith('        ') else x for x in expr.splitlines())+''')
}

'''
s=s[:a]+'        let logical_name_obligations = original_logical_alias_name_obligations(&words, context)?;\n'+s[z:];a=s.index('/// Original source operands of alias grammar');s=s[:a]+helper+s[a:];save(rel,s)
manifest=[];patch=[];counts={};names=['original_authored_scalar_invocation','authored_scalar_context_is_local','original_authored_parameter_source_command_for_module','authored_parameter_source_effects','capture','original_logical_alias_name_obligations']
for rel,(old,new) in files.items():
 for sub,data in [('before',old),('proposed',new)]:p=b/sub/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(data)
 p=b/'proposed'/rel;subprocess.run([fmt,'--edition','2024','--config','skip_children=true',str(p)],check=True);new=p.read_text()
 for name in names:
  match=re.search(r'fn '+name+r'(?:<[^>]*>)?\(',new)
  if not match:continue
  a=new.index('{',match.start());i=a+1;d=1
  while d:d+=(new[i]=='{')-(new[i]=='}');i+=1
  counts[name]=len([line for line in new[a+1:i-1].splitlines() if line.strip() and not line.strip().startswith('//')])
 pat=r'\b(?:assert|assert_eq|assert_ne|debug_assert|debug_assert_eq|debug_assert_ne)!';assert [x for x in old.splitlines() if re.search(pat,x)]==[x for x in new.splitlines() if re.search(pat,x)]
 h=lambda v:hashlib.sha256(v.encode()).hexdigest();manifest.append({'path':rel,'before_sha256':h(old),'after_sha256':h(new)});patch.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
assert max(counts.values())<=100,counts
p=b/'proposal.patch';p.write_text(''.join(patch));m={'files':manifest,'patch_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'fresh_f62_indices':[83,92,95],'body_counts_after':counts,'scope':'Three authored source length sites: exact ordered closed Local variable-context predicate, exact existing authored parameter schema roles/aliases/continuation phase, exact original Logical unresolved-name obligation collection. All parent owners retained; no visibility/public API, source/owner/policy/three-state refusal, query/evaluation order or assertion changes.','limits':'Off-tree preparation/fmt/assertions only; no Cargo/typecheck/Clippy/runtime; independent type/owner/query/drop review required.'};(b/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(m['patch_sha256'],counts)
