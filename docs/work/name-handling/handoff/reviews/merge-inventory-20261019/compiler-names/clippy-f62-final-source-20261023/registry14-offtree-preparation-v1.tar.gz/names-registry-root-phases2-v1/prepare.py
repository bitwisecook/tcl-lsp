from pathlib import Path
import json,hashlib,subprocess,difflib,re
b=Path(__file__).parent;root=Path('/workspace/naming-migration-publish/tcl-lsp');files={};fmt='/workspace/.rustup/toolchains/1.99.1-x86_64-unknown-linux-gnu/bin/rustfmt'
def load(rel):s=(root/rel).read_text();files[rel]=[s,s];return s
def save(rel,s):files[rel][1]=s
rel='rust/tcl-compiler/src/registry_invocation.rs';s=load(rel);start=s.index('pub(crate) fn logical_structured_invocation_with_metadata_context(')
a=s.index('    let selected =\n',start);z=s.index('    let source_roles =',a);old=s[a:z]
helper='''fn original_structured_source_selection(
    registry: &CommandRegistry,
    context: InvocationMetadataContext<'_>,
    tokens: &CommandTokens,
    bindings: Option<&crate::command_binding::SourceCommandBindings>,
) -> Option<ResolvedStatementInvocation> {
'''+old+'    Some(selected)\n}\n\n'
s=s[:a]+'    let selected = original_structured_source_selection(registry, context, tokens, bindings)?;\n'+s[z:]
a=s.index('        let advice =',s.index('    if source_purpose ==',start));z=s.index('    // A possible case body',a);old=s[a:z];assert old.endswith('    }\n');body=old[:-len('    }\n')]
helper+='''fn authored_simulation_structure_is_supported(
    registry: &CommandRegistry,
    context: InvocationMetadataContext<'_>,
    tokens: &CommandTokens,
    selected: &ResolvedStatementInvocation,
    source_roles: Option<&StructuredSourceRoles>,
) -> Option<()> {
'''+ '\n'.join(x[4:] if x.startswith('    ') else x for x in body.rstrip().splitlines()).replace('source_roles.as_ref().map_or_else(', 'source_roles.map_or_else(')+'\n    Some(())\n}\n\n'
s=s[:a]+'''        authored_simulation_structure_is_supported(registry, context, tokens, &selected, source_roles.as_ref())?;
    }
'''+s[z:]
a=s.index('    // A possible case body',start);z=s.index('    Some(LogicalStructuredInvocation {',a);body=s[a:z]
body=body.replace('source_roles\n        .as_ref()\n        .is_some_and(', 'source_roles\n        .is_some_and(')
helper+='''fn original_structured_operands_are_supported(
    registry: &CommandRegistry,
    selected: &ResolvedStatementInvocation,
    source_roles: Option<&StructuredSourceRoles>,
    tokens: &CommandTokens,
) -> Option<()> {
'''+body+'    Some(())\n}\n\n'
s=s[:a]+'    original_structured_operands_are_supported(registry, &selected, source_roles.as_ref(), tokens)?;\n'+s[z:]
a=s.index('/// Select source structure using the caller');s=s[:a]+helper+s[a:]
start=s.index('pub(crate) fn logical_parameter_body_assistance(');a=s.index('    let (facts, source_roles) =',start);z=s.index('    let mut tokens =',a);old=s[a:z]
helper='''struct LogicalParameterSourceFacts {
    facts: InvocationFacts,
    source_roles: Option<(Vec<(u8, tcl_registry::ArgRole)>, bool)>,
    named_only_roles: bool,
}

fn logical_parameter_source_facts(
    words: &source_structure::OriginalRegistryWords,
    context: &tcl_registry::model::ContextRegistry,
    conditional_source: bool,
    named_only: bool,
) -> Option<LogicalParameterSourceFacts> {
'''+old+'    Some(LogicalParameterSourceFacts { facts, source_roles, named_only_roles })\n}\n\n'
s=s[:a]+'''    let LogicalParameterSourceFacts { facts, source_roles, named_only_roles } =
        logical_parameter_source_facts(&words, context, conditional_source, named_only)?;
'''+s[z:]
a=s.index('    if words\n        .origins()',s.index('pub(crate) fn logical_parameter_body_assistance('));z=s.index('    let effective =',a);old=s[a:z];expr=old[len('    if '):old.index('\n    {')]
helper+='fn logical_parameter_origins_are_unwritten(words: &source_structure::OriginalRegistryWords) -> bool {\n    '+expr+'\n}\n\n'
s=s[:a]+'    if logical_parameter_origins_are_unwritten(&words) {\n        return None;\n    }\n'+s[z:]
a=s.index('/// Offset-free syntax assistance joins');s=s[:a]+helper+s[a:];save(rel,s)
names=['logical_structured_invocation_with_metadata_context','original_structured_source_selection','authored_simulation_structure_is_supported','original_structured_operands_are_supported','logical_parameter_body_assistance','logical_parameter_source_facts','logical_parameter_origins_are_unwritten']
manifest=[];patch=[];counts={}
for rel,(old,new) in files.items():
 for sub,data in [('before',old),('proposed',new)]:p=b/sub/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(data)
 p=b/'proposed'/rel;subprocess.run([fmt,'--edition','2024','--config','skip_children=true',str(p)],check=True);new=p.read_text()
 for name in names:
  match=re.search(r'fn '+name+r'(?:<[^>]*>)?\(',new)
  if not match:continue
  a=new.index('{',match.start());i=a+1;d=1
  while d:d+=(new[i]=='{')-(new[i]=='}');i+=1
  counts[name]=len([line for line in new[a+1:i-1].splitlines() if line.strip() and not line.strip().startswith('//')])
 pat=r'\b(?:assert|assert_eq|assert_ne|debug_assert|debug_assert_eq|debug_assert_ne)!';assert [x for x in old.splitlines() if re.search(pat,x)]==[x for x in new.splitlines() if re.search(pat,x)]
 h=lambda v:hashlib.sha256(v.encode()).hexdigest();manifest.append({'path':rel,'before_sha256':h(old),'after_sha256':h(new)});patch.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
assert max(counts.values())<=100,counts
p=b/'proposal.patch';p.write_text(''.join(patch));m={'files':manifest,'patch_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'fresh_f62_indices':[93,94],'body_counts_after':counts,'scope':'Two root source structure length sites: exact lazy retained source selection, authored simulation eligibility, original operand validation, and logical parameter facts/roles phase. All parent owners retained; no visibility/public API, source/owner/policy/three-state refusal, query/evaluation order or assertion changes.','limits':'Off-tree preparation/fmt/assertions only; no Cargo/typecheck/Clippy/runtime; independent type/owner/query/drop review required.'};(b/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(m['patch_sha256'],counts)
