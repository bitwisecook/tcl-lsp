from pathlib import Path
import json,hashlib,re,shutil,subprocess
b=Path(__file__).parent;r=Path('/workspace/naming-migration-publish/tcl-lsp');m=json.loads((b/'manifest.json').read_text());h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();checks={}
shadow=b/'independent-owner-shadow'
for f in m['files']:
 rel=Path(f['path']);before=b/'before'/rel;after=b/'proposed'/rel
 assert h(r/rel)==h(before)==f['before_sha256']; assert h(after)==f['after_sha256'];target=shadow/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(before,target)
run=subprocess.run(['patch','--batch','--fuzz=0','-p1','-i',str(b/'proposal.patch')],cwd=shadow,capture_output=True,text=True);assert run.returncode==0 and 'offset' not in run.stdout and 'fuzz' not in run.stdout,run.stdout+run.stderr
fmt='/workspace/.rustup/toolchains/1.99.1-x86_64-unknown-linux-gnu/bin/rustfmt'
for f in m['files']:
 rel=Path(f['path']);assert h(shadow/rel)==f['after_sha256'];subprocess.run([fmt,'--check','--edition','2024','--config','skip_children=true',str(shadow/rel)],check=True)
 before=(b/'before'/rel).read_text();after=(b/'proposed'/rel).read_text()
 assertion=lambda s:[x for x in s.splitlines() if re.search(r'\b(?:assert|assert_eq|assert_ne|debug_assert|debug_assert_eq|debug_assert_ne)!',x)]
 assert assertion(before)==assertion(after)
 checks['assertion_lines_exact']=True
 names=['original_source_operand_layout_for_declaration','prepare_original_operand_source','original_operand_body_snapshot','original_operand_command_layouts','retain_original_argument_layouts','original_argument_layout_parents_are_current']
 counts={}
 for name in names:
  x=after.index('fn '+name+'(');a=after.index('{',x);depth=1;i=a+1
  while depth:
   if after[i]=='{':depth+=1
   if after[i]=='}':depth-=1
   i+=1
  counts[name]=len([z for z in after[a+1:i-1].splitlines() if z.strip() and not z.lstrip().startswith('//')])
 assert max(counts.values())<=100,counts
 checks['nonblank_noncomment_body_counts']=counts
checks.update({'current_publisher_before_pins':True,'zero_fuzz_no_offset_apply':True,'all_after_pins':True,'pinned_rustfmt':'PASS','typecheck':'UNRUN','Clippy':'UNRUN','runtime':'UNRUN','production_review':'All original queries remain ordered, header before body producer/correspondence, state clone/seeding before native plan, plan before original segment/lexical-vector rejoin; retained unanimous layouts and predecessor continuation logic unchanged. Caller holds header/content/image/native-header-value/read/snapshot/plan/source_operations in original owning binding order through consensus. Only borrowed Copy context crosses walker helper. Original argument-parent OR short-circuit expression exact except reference-level adjustment.'})
(b/'owner-validation.json').write_text(json.dumps(checks,indent=2)+'\n');print(json.dumps(checks))
