from pathlib import Path
import hashlib,json,subprocess,shutil,difflib,datetime
b=Path(__file__).parent;r=Path('/workspace/naming-migration-publish/tcl-lsp');h=lambda data:hashlib.sha256(data).hexdigest();hp=lambda p:h(p.read_bytes());m=json.loads((b/'manifest.json').read_text());assert hp(b/'proposal.patch')=='c7abfc6176ebdfdda2223ab61b4efd53e7275e25dcf085c38c564b82d9eaed62';assert hp(b/'manifest.json')=='95a1281e708fde39531af3257f6377f6dfade1d50cefb4e73540a7ba4880cd3b'
assert len(m['files'])==15 and len({x['path'] for x in m['files']})==15
peer=b/'names-independent-verification';peer.mkdir(exist_ok=True);current={};base={};cluster_paths=[];results=[];projection=[]
for f in m['files']:
 p=f['path'];assert hp(r/p)==f['before_sha256'],('current before changed',p);assert hp(b/p)==f['after_sha256'];base[p]=(r/p).read_bytes();current[p]=base[p].decode();dest=peer/'whole'/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(base[p])
for x in m['original_cluster_verification']:
 if 'cluster' in x and x['cluster'] not in cluster_paths:cluster_paths.append(x['cluster'])
assert len(cluster_paths)==9
for ix,cp in enumerate(cluster_paths):
 c=Path(cp);cm=json.loads((c/'manifest.json').read_text());files=cm if isinstance(cm,list) else cm['files'];scratch=peer/('original-'+str(ix));scratch.mkdir(exist_ok=True)
 for f in files:
  p=f['path'];sources=[c/p,c/'after'/p,c/'proposed'/p];source=next(q for q in sources if q.is_file());assert hp(source)==f['after_sha256'];dest=scratch/p;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,dest)
 rev=subprocess.run(['patch','--batch','-R','--fuzz=0','-p1','-i',str(c/'proposal.patch')],cwd=scratch,capture_output=True,text=True);assert rev.returncode==0 and 'offset' not in rev.stdout and 'fuzz' not in rev.stdout,rev.stdout+rev.stderr
 for f in files:
  p=f['path'];assert hp(scratch/p)==f['before_sha256'];old=(scratch/p).read_text();source=next(q for q in [c/p,c/'after'/p,c/'proposed'/p] if q.is_file());new=source.read_text();left=old.splitlines(True);right=new.splitlines(True);now=current[p].splitlines(True);maps=difflib.SequenceMatcher(a=left,b=now,autojunk=False).get_opcodes();edits=[]
  for tag,i,j,u,v in difflib.SequenceMatcher(a=left,b=right,autojunk=False).get_opcodes():
   if tag=='equal':continue
   slots={(x+i-a,x+j-a) for t,a,z,x,y in maps if t=='equal' and a<=i<=j<=z}
   if slots:
    assert len(slots)==1;aa,zz=slots.pop();assert now[aa:zz]==left[i:j];edits.append((aa,zz,right[u:v]));continue
   assert c.name=='fresh123-irules-packet-actions-v1' and p=='rust/tcl-compiler/src/irules_checks.rs'
   assert left[i:j]==['        drops_connection,\n','        returns_dns_packet,\n']
   needle=['            drops_connection,\n','            returns_dns_packet,\n'];locations=[n for n in range(len(now)-1) if now[n:n+2]==needle];assert len(locations)==1;aa=locations[0]
   assert now[aa-1]=='            span: Span::new(tokens.argv.first()?.start(), tokens.argv.last()?.end()),\n' and now[aa+2]=='            disables_all_events,\n'
   replacement=['    '+line for line in right[u:v]];assert replacement==['            packet_actions: OriginalIrulesPacketActions {\n','                drops_connection,\n','                returns_dns_packet,\n','            },\n']
   edits.append((aa,aa+2,replacement));projection.append({'file':p,'scope':'exact original adjacent packet booleans grouped under retained Relevant constructor; only four-space indentation adaptation','original_lines':left[i:j],'current_lines':needle,'replacement':replacement})
  for aa,zz,replacement in sorted(edits,reverse=True):now[aa:zz]=replacement
  current[p]=''.join(now);results.append({'cluster':str(c),'path':p,'original_before_sha256':f['before_sha256'],'original_after_sha256':f['after_sha256'],'edits':len(edits)})
 # Independent original forward replay after reverse must recover all original finals.
 fw=subprocess.run(['patch','--batch','--fuzz=0','-p1','-i',str(c/'proposal.patch')],cwd=scratch,capture_output=True,text=True);assert fw.returncode==0 and 'offset' not in fw.stdout and 'fuzz' not in fw.stdout,fw.stdout+fw.stderr
 for f in files:assert hp(scratch/f['path'])==f['after_sha256']
assert len(projection)==1
for f in m['files']:assert h(current[f['path']].encode())==f['after_sha256'],('component replay mismatch',f['path'])
whole=subprocess.run(['patch','--batch','--fuzz=0','-p1','-i',str(b/'proposal.patch')],cwd=peer/'whole',capture_output=True,text=True);assert whole.returncode==0 and 'offset' not in whole.stdout and 'fuzz' not in whole.stdout,whole.stdout+whole.stderr
for f in m['files']:
 p=f['path'];assert hp(peer/'whole'/p)==f['after_sha256'];subprocess.run(['/workspace/.rustup/toolchains/1.99.1-x86_64-unknown-linux-gnu/bin/rustfmt','--check','--edition','2024','--config','skip_children=true',str(peer/'whole'/p)],check=True)
rootpeers=Path('/workspace/naming-proof-storage/root-peer-fresh123-presence-and-image-v1');rp=[]
for c in ['fresh123-executable-effect-presence-v1','fresh123-source-image-consumption-v1']:
 p=rootpeers/(c+'-review.json');rr=json.loads(p.read_text());assert 'CLEAR' in rr['verdict'];assert rr['patch_sha256']==hp(Path('/workspace/naming-proof-storage/compiler-clippy')/c/'proposal.patch');rp.append({'path':str(p),'sha256':hp(p)})
for c in ['fresh123-source-line-index-v1','fresh123-irules-packet-actions-v1']:
 p=Path('/workspace/naming-proof-storage')/('ccg-peer-'+c)/'receipt.json';rr=json.loads(p.read_text());assert 'CLEAR' in str(rr).upper();rp.append({'path':str(p),'sha256':hp(p)})
receipt={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'verdict':'STATIC COMPOSITION CLEAR bounded exact nine-component union','base_commit':m['base_commit'],'patch_sha256':hp(b/'proposal.patch'),'manifest_sha256':hp(b/'manifest.json'),'file_count':15,'component_count':9,'checks':['All15 actual publisher before hashes and frozen composed final hashes exact','All9 component original after pins independently reversed0/nooffset to original before pins and forwarded0/nooffset back to final pins','Independently replayed every original changed fragment into unchanged actual source spans; exact composed final hashes match all15','One explicitly bounded packet-action constructor indentation projection checked exact two adjacent old fields/currentcontext and exact replacement; preexisting Relevant wrapper and all conservative/3state branches retained','Independent whole combined patch0/nooffset and all15 afterpins, owner-edition pinned rustfmt PASS','All original component semantic reviews received; four external root/CCG peer receipt pins independently bound; no new semantic rewrite introduced by composition'],'original_component_replays':results,'explicit_projection':projection,'bound_external_semantic_peers':rp,'limits':'No source/worktree writes, Git mutations, Cargo, typecheck, Clippy, runtime, perf or acceptance claims. Integration must recheck actual current before pins.'}
p=b/'names-independent-composition-peer.json';p.write_text(json.dumps(receipt,indent=2)+'\n');print(hp(p))
