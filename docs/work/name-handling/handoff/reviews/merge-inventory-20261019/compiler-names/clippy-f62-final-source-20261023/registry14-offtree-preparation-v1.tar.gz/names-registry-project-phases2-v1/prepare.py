from pathlib import Path
import json,hashlib,subprocess,difflib,re
b=Path(__file__).parent;root=Path('/workspace/naming-migration-publish/tcl-lsp');files={};fmt='/workspace/.rustup/toolchains/1.99.1-x86_64-unknown-linux-gnu/bin/rustfmt'
def load(rel):s=(root/rel).read_text();files[rel]=[s,s];return s
def save(rel,s):files[rel][1]=s
rel='rust/tcl-compiler/src/registry_invocation/source_structure/project_procedure_roles.rs';s=load(rel)
a=s.index('    if actual.span != segment.span',s.index('pub fn original_project_procedure_arguments'));z=s.index('    if projection.native_words()',a)
s=s[:a]+'    if !project_procedure_geometry_matches(actual, segment) {\n        return None;\n    }\n'+s[z:]
a=s.index('    let arguments = projection\n',s.index('pub fn original_project_procedure_arguments'));z=s.index('    let bindings =',a);old=s[a:z]
expr=old[len('    let arguments = projection\n        .native_words()'):].rstrip();assert expr.endswith(';');expr=expr[:-1]
expr=expr.replace('.original_written_name_input(&tokens, ordinal)', '.original_written_name_input(tokens, ordinal)')
helpers='''fn project_procedure_geometry_matches(
    actual: &crate::segmenter::SegmentedCommand,
    segment: &crate::segmenter::SegmentedCommand,
) -> bool {
    actual.span == segment.span
        && actual.argv == segment.argv
        && actual.texts == segment.texts
        && actual.word_fragments == segment.word_fragments
        && actual.single_token_word == segment.single_token_word
        && actual.expand_word == segment.expand_word
        && actual.is_partial == segment.is_partial
        && actual.partial_delimiter == segment.partial_delimiter
}

fn project_procedure_argument_values(
    input: &ResolvedAnalysisInput,
    binding: &crate::command_binding::SourceInvocationBinding,
    tokens: &crate::ir::CommandTokens,
    native: &[tcl_lexer::NativeWord],
) -> Vec<EffectiveInvocationWord> {
    native'''+expr+'''
}

'''
s=s[:a]+'    let arguments = project_procedure_argument_values(input, binding, &tokens, projection.native_words());\n'+s[z:]
a=s.index('        if formals\n',s.index('pub fn original_project_procedure_arguments'));z=s.index('        formals.bindings',a);old=s[a:z]
expr=old[len('        if '):old.index('\n        {')]
helpers += "fn project_procedure_has_duplicate_formals(formals: &SignatureSourceFormalParameters) -> bool {\n    "+expr+"\n}\n\n"
s=s[:a]+'        if project_procedure_has_duplicate_formals(formals) {\n            return None;\n        }\n'+s[z:]
a=s.index('/// Select a foreign source header');s=s[:a]+helpers+s[a:];save(rel,s)
rel='rust/tcl-compiler/src/registry_invocation/source_structure/project_class_cards.rs';s=load(rel)
a=s.index('    if actual.span != segment.span',s.index('pub fn original_project_receiver_class_with_sources'));z=s.index('    if let Some(receipt)',a);old=s[a:z]
helper='''fn project_receiver_invocation_is_static(
    actual: &crate::segmenter::SegmentedCommand,
    segment: &crate::segmenter::SegmentedCommand,
    words: &[NativeWord],
) -> bool {
'''+old.replace('        return None;', '        return false;')+'    true\n}\n\n'
s=s[:a]+'    if !project_receiver_invocation_is_static(&actual, segment, &words) {\n        return None;\n    }\n'+s[z:]
a=s.index('/// The same source display over');s=s[:a]+helper+s[a:];save(rel,s)
names=['original_project_procedure_arguments','project_procedure_geometry_matches','project_procedure_argument_values','project_procedure_has_duplicate_formals','original_project_receiver_class_with_sources','project_receiver_invocation_is_static']
manifest=[];patch=[];counts={}
for rel,(old,new) in files.items():
 for sub,data in [('before',old),('proposed',new)]:p=b/sub/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(data)
 p=b/'proposed'/rel;subprocess.run([fmt,'--edition','2024','--config','skip_children=true',str(p)],check=True);new=p.read_text()
 for name in names:
  match=re.search(r'fn '+name+r'(?:<[^>]*>)?\(',new)
  if not match:continue
  a=new.index('{',match.start());i=a+1;d=1
  while d:d+=(new[i]=='{')-(new[i]=='}');i+=1
  counts[name]=len([line for line in new[a+1:i-1].splitlines() if line.strip() and not line.strip().startswith('//')])
 pat=r'\b(?:assert|assert_eq|assert_ne|debug_assert|debug_assert_eq|debug_assert_ne)!';assert [x for x in old.splitlines() if re.search(pat,x)]==[x for x in new.splitlines() if re.search(pat,x)]
 h=lambda v:hashlib.sha256(v.encode()).hexdigest();manifest.append({'path':rel,'before_sha256':h(old),'after_sha256':h(new)});patch.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
assert max(counts.values())<=100,counts
p=b/'proposal.patch';p.write_text(''.join(patch));m={'files':manifest,'patch_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'fresh_f62_indices':[85,86],'body_counts_after':counts,'scope':'Two foreign project source-role length sites: identical complete invocation geometry, exact ordered static operand eligibility, and original per-operand argument-value projection. All parent owners retained; no visibility/public API, source/owner/policy/three-state refusal, query/evaluation order or assertion changes.','limits':'Off-tree preparation/fmt/assertions only; no Cargo/typecheck/Clippy/runtime; independent type/owner/query/drop review required.'};(b/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(m['patch_sha256'],counts)
