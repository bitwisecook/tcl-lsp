from pathlib import Path
import hashlib,json,difflib,subprocess
root=Path('/workspace/naming-migration-publish/tcl-lsp')
base=Path('/workspace/naming-proof-storage/names-cb-declaration-preview-phases-v1')
rel=Path('rust/tcl-compiler/src/command_binding/declaration_preview.rs')
s=(root/rel).read_text(); original=s
start=s.index('fn original_source_operand_layout_for_declaration(')
end=s.index('\nfn original_source_operation_continuation(',start)
fn=s[start:end]
prep_start=fn.index('        let crate::signature_scan::scope::SignatureSourceNameInput::OriginalWord(producer) =')
prep_end=fn.index('        let mut state = row.snapshot.state.clone();',prep_start)
prep=fn[prep_start:prep_end]
# All owning locals introduced at this stage retain the original caller binding order.
prep_call='''        let PreparedOriginalOperandSource {
            content,
            image,
            native_header_value,
            read,
        } = prepare_original_operand_source(site, &tokens, row, target, &effective, shape, &header)?;
'''
fn=fn[:prep_start]+prep_call+fn[prep_end:]
loop_start=fn.index('        let segments = crate::segmenter::segment_commands_image_with_offset_and_config(')
loop_end=fn.index('        if selected\n',loop_start)
loop=fn[loop_start:loop_end]
loop_call='''        let OriginalOperandCommandLayouts {
            retained,
            source_operations: _source_operations,
        } = original_operand_command_layouts(OriginalOperandCommandContext {
            site,
            row,
            parents,
            registry,
            dialect,
            read: &read,
            header: &header,
            snapshot: &snapshot,
            native_header_value: &native_header_value,
            image: &image,
            content,
            plan: &plan,
        })?;
'''
fn=fn[:loop_start]+loop_call+fn[loop_end:]
fn=fn.replace('        if plan.fatal_tail.is_some() {\n            return None;\n        }\n','',1)
snapshot_start=fn.index('        let mut state = row.snapshot.state.clone();')
snapshot_end=fn.index('        let plan = tcl_lexer::native_script_words_in_with_purpose(',snapshot_start)
snapshot=fn[snapshot_start:snapshot_end]
fn=fn[:snapshot_start]+'        let snapshot = original_operand_body_snapshot(site, row, &header, registry)?;\n'+fn[snapshot_end:]
snapshot_helper='''fn original_operand_body_snapshot(
    site: &CommandAllocationSite,
    row: &DeclarationLayoutObservation,
    header: &DeclaredProcedureHeader,
    registry: &tcl_registry::CommandRegistry,
) -> Option<Arc<SourceLookupSnapshot>> {
'''+ '\n'.join(line[4:] if line.startswith('    ') else line for line in snapshot.rstrip().splitlines())+'\n    Some(snapshot)\n}\n\n'
helper='''struct PreparedOriginalOperandSource {
    content: tcl_lexer::Span,
    image: tcl_lexer::SourceImage,
    native_header_value: Arc<[u8]>,
    read: OriginalProcedureReadDeclaration,
}

fn prepare_original_operand_source(
    site: &CommandAllocationSite,
    tokens: &crate::ir::CommandTokens,
    row: &DeclarationLayoutObservation,
    target: &super::SourceCommandTarget,
    effective: &crate::registry_invocation::EffectiveCommandWords,
    shape: tcl_registry::native_procedure::NativeProcedureDefinition,
    header: &DeclaredProcedureHeader,
) -> Option<PreparedOriginalOperandSource> {
'''
# Avoid added reference levels in the moved code.
prep=prep.replace('                &tokens,','                tokens,').replace('                &effective,','                effective,')
helper+='\n'.join(line[4:] if line.startswith('    ') else line for line in prep.rstrip().splitlines())+'\n'
helper+='''    Some(PreparedOriginalOperandSource {
        content,
        image,
        native_header_value,
        read,
    })
}

#[derive(Clone, Copy)]
struct OriginalOperandCommandContext<'a> {
    site: &'a CommandAllocationSite,
    row: &'a DeclarationLayoutObservation,
    parents: &'a Arc<[DeclarationLayoutObservation]>,
    registry: &'a tcl_registry::CommandRegistry,
    dialect: tcl_registry::InvocationDialect,
    read: &'a OriginalProcedureReadDeclaration,
    header: &'a DeclaredProcedureHeader,
    snapshot: &'a Arc<SourceLookupSnapshot>,
    native_header_value: &'a Arc<[u8]>,
    image: &'a tcl_lexer::SourceImage,
    content: tcl_lexer::Span,
    plan: &'a tcl_lexer::NativeScriptWordsPlan,
}

struct OriginalOperandCommandLayouts {
    retained: Vec<OriginalDeclarationSourceOperandLayout>,
    source_operations: Vec<OriginalDeclarationSourceOperation>,
}

fn original_operand_command_layouts(
    context: OriginalOperandCommandContext<'_>,
) -> Option<OriginalOperandCommandLayouts> {
    let OriginalOperandCommandContext {
        site, row, parents, registry, dialect, read, header, snapshot,
        native_header_value, image, content, plan,
    } = context;
    if plan.fatal_tail.is_some() {
        return None;
    }
'''
loop=loop.replace('            &image,','            image,').replace('(&image, content.start()', '(image, content.start()').replace('Arc::clone(&snapshot)','Arc::clone(snapshot)').replace('Arc::clone(&native_header_value)','Arc::clone(native_header_value)').replace('                    &snapshot,','                    snapshot,')
# Explicit underlying clones preserve the original owning values, not references.
loop=loop.replace('read: read.clone(),','read: (*read).clone(),').replace('header: header.clone(),','header: (*header).clone(),')
helper+='\n'.join(line[4:] if line.startswith('    ') else line for line in loop.rstrip().splitlines())+'\n'
helper+='''    Some(OriginalOperandCommandLayouts { retained, source_operations })
}

'''
s=s[:start]+helper+snapshot_helper+fn+s[end:]
# Extract only the original unchanged ordered eligibility condition; all caller owners remain.
a=s.index('    fn retain_original_argument_layouts(')
b=s.index('\n    fn retain_declared_body_layouts(',a)
fn=s[a:b]
cond_start=fn.index('        if input\n')
cond_end=fn.index('        let Some(calls)',cond_start)
condition=fn[cond_start:cond_end]
assert condition.endswith('        {\n            return;\n        }\n')
expr=condition[len('        if '):-len('        {\n            return;\n        }\n')].rstrip()
call='''        if !self.original_argument_layout_parents_are_current(
            site, tokens, parents, registry, &input, config,
        ) {
            return;
        }
'''
fn=fn[:cond_start]+call+fn[cond_end:]
method='''    fn original_argument_layout_parents_are_current(
        &self,
        site: &CommandAllocationSite,
        tokens: &crate::ir::CommandTokens,
        parents: &[DeclarationLayoutObservation],
        registry: &tcl_registry::CommandRegistry,
        input: &crate::analyser::ResolvedAnalysisInput,
        config: tcl_lexer::LexerConfig,
    ) -> bool {
        !('''+expr.replace('Some(&input)','Some(input)')+''')
    }

'''
doc_start=s.rfind('    /// Original argv children',0,a)
assert doc_start!=-1
doc=s[doc_start:a]
s=s[:doc_start]+method+doc+fn+s[b:]
for folder,data in [('before',original),('proposed',s)]:
 p=base/folder/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(data)
fmt='/workspace/.rustup/toolchains/1.99.1-x86_64-unknown-linux-gnu/bin/rustfmt'
subprocess.run([fmt,'--edition','2024','--config','skip_children=true',str(base/'proposed'/rel)],check=True)
new=(base/'proposed'/rel).read_text()
patch=''.join(difflib.unified_diff(original.splitlines(True),new.splitlines(True),fromfile='a/'+str(rel),tofile='b/'+str(rel)))
(base/'proposal.patch').write_text(patch)
h=lambda data:hashlib.sha256(data).hexdigest()
(base/'manifest.json').write_text(json.dumps({'files':[{'path':str(rel),'before_sha256':h(original.encode()),'after_sha256':h(new.encode())}],'patch_sha256':h(patch.encode()),'scope':'Two declaration-preview length sites, exact ordered source-body preparation and retained-command walk plus original argument-parent eligibility. All actual source/body/registry/input/currentness/unanimity guards and original owner binding/drop endpoints retained.','limits':'Off-tree preparation only, no Cargo/typecheck/Clippy/runtime. Independent peer required.'},indent=2)+'\n')
print(h(patch.encode()))
