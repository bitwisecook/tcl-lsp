from pathlib import Path
import hashlib,json,difflib,subprocess,re
b=Path(__file__).parent;root=Path('/workspace/naming-migration-publish/tcl-lsp');files={};fmt='/workspace/.rustup/toolchains/1.99.1-x86_64-unknown-linux-gnu/bin/rustfmt'
def load(rel):
 s=(root/rel).read_text();files[rel]=[s,s];return s
def save(rel,s):files[rel][1]=s
rel='rust/tcl-compiler/src/registry_invocation/original_procedure_call.rs';s=load(rel)
a=s.index('            let authentic_purpose = match procedure.body_kind {');z=s.index('            if !authentic_purpose',a);old=s[a:z];assert old.endswith('            };\n')
body=old[len('            let authentic_purpose = '):].rstrip();body=body[:-1]
helper='''fn original_logical_summary_body_purpose_matches(
    module: &Module,
    id: &crate::ir::ProcedureId,
    procedure: &Procedure,
) -> bool {
'''+ '\n'.join(line[12:] if line.startswith('            ') else line for line in body.splitlines())+'\n}\n\n'
s=s[:a]+'            let authentic_purpose = original_logical_summary_body_purpose_matches(module, id, procedure);\n'+s[z:]
a=s.index('/// Possible Logical body dependencies');s=s[:a]+helper+s[a:];save(rel,s)
rel='rust/tcl-compiler/src/registry_invocation/source_structure/procedure.rs';s=load(rel);a=s.index('    if actual.span != segment.span',s.index('pub fn original_logical_procedure_arguments'));z=s.index('    let native =',a);guard=s[a:z];expr=guard[len('    if '):-len('    {\n        return None;\n    }\n')];assert expr.rstrip().endswith('segment.partial_delimiter')
helper='''fn original_procedure_segment_geometry_matches(
    actual: &crate::segmenter::SegmentedCommand,
    segment: &crate::segmenter::SegmentedCommand,
) -> bool {
    '''+expr.rstrip().replace(' != ', ' == ').replace('|| ', '&& ')+'''
}

'''
s=s[:a]+'    if !original_procedure_segment_geometry_matches(actual, segment) {\n        return None;\n    }\n'+s[z:];a=s.index('/// Join an authentic Logical occurrence');s=s[:a]+helper+s[a:];save(rel,s)
rel='rust/tcl-compiler/src/registry_invocation/source_structure.rs';s=load(rel)
a=s.index('fn conditional_native_case_source_words(');z=s.index('\n/// Original lexical values',a);fn=s[a:z];head='''    let head = Some(OriginalOperandSource {
        span: native.first()?.span(),
        input: binding.original_written_name_input(&tokens, 0),
        word: native.first().cloned(),
    });
''';assert fn.count(head)==1
fn=fn.replace(head,'    let head = Some(conditional_native_case_head(&native, binding, &tokens)?);\n')
s=s[:a]+fn+s[z:]
helper='''fn conditional_native_case_head(
    native: &[tcl_lexer::NativeWord],
    binding: &crate::command_binding::SourceInvocationBinding,
    tokens: &crate::ir::CommandTokens,
) -> Option<OriginalOperandSource> {
    Some(OriginalOperandSource {
        span: native.first()?.span(),
        input: binding.original_written_name_input(tokens, 0),
        word: native.first().cloned(),
    })
}

''';a=s.index('/// Conditional original Native argv');s=s[:a]+helper+s[a:]
a=s.index('fn generic_definition_child_source_words(');z=s.index('\nfn source_registry_words_with_definition_parent(',a);fn=s[a:z]
pa=fn.index('    let mut arguments = Vec::with_capacity(');pz=fn.index('    let head = OriginalOperandSource',pa);build=fn[pa:pz]
fn=fn[:pa]+'''    let DefinitionChildOperands {
        arguments,
        operands,
        origins,
    } = original_definition_child_operands(original);
'''+fn[pz:]
fn=fn.replace('    use crate::registry_invocation::{EffectiveInvocationWord, InvocationWordOrigin};\n','',1)
head='''    let head = OriginalOperandSource {
        span: original.first()?.span(),
        input: None,
        word: Some(original.first()?.clone()),
    };
''';assert fn.count(head)==1
fn=fn.replace(head,'    let head = original_definition_child_head(original)?;\n')
s=s[:a]+fn+s[z:]
helper='''struct DefinitionChildOperands {
    arguments: Vec<crate::registry_invocation::EffectiveInvocationWord>,
    operands: Vec<Option<OriginalOperandSource>>,
    origins: Vec<crate::registry_invocation::InvocationWordOrigin>,
}

fn original_definition_child_operands(original: &[tcl_lexer::NativeWord]) -> DefinitionChildOperands {
    use crate::registry_invocation::{EffectiveInvocationWord, InvocationWordOrigin};
'''+build+'''    DefinitionChildOperands { arguments, operands, origins }
}

fn original_definition_child_head(
    original: &[tcl_lexer::NativeWord],
) -> Option<OriginalOperandSource> {
    Some(OriginalOperandSource {
        span: original.first()?.span(),
        input: None,
        word: Some(original.first()?.clone()),
    })
}

''';a=s.index('// naming.source.original-generic-definition-child-registry-roles');s=s[:a]+helper+s[a:];save(rel,s)
manifest=[];patch=[];counts={}
names=['original_logical_procedure_may_dependencies_for_module','original_logical_summary_body_purpose_matches','original_logical_procedure_arguments','original_procedure_segment_geometry_matches','conditional_native_case_source_words','conditional_native_case_head','generic_definition_child_source_words','original_definition_child_operands','original_definition_child_head']
for rel,(old,new) in files.items():
 for sub,data in [('before',old),('proposed',new)]:p=b/sub/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(data)
 p=b/'proposed'/rel;subprocess.run([fmt,'--edition','2024','--config','skip_children=true',str(p)],check=True);new=p.read_text()
 for name in names:
  match=re.search(r'fn '+name+r'(?:<[^>]*>)?\(',new)
  if match is None:continue
  a=new.index('{',match.start());i=a+1;d=1
  while d:d+=(new[i]=='{')-(new[i]=='}');i+=1
  counts[name]=len([line for line in new[a+1:i-1].splitlines() if line.strip() and not line.strip().startswith('//')])
 pat=r'\b(?:assert|assert_eq|assert_ne|debug_assert|debug_assert_eq|debug_assert_ne)!';assert [x for x in old.splitlines() if re.search(pat,x)]==[x for x in new.splitlines() if re.search(pat,x)]
 h=lambda v:hashlib.sha256(v.encode()).hexdigest();manifest.append({'path':rel,'before_sha256':h(old),'after_sha256':h(new)});patch.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
assert max(counts.values())<=100,counts
p=b/'proposal.patch';p.write_text(''.join(patch));m={'files':manifest,'patch_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'fresh_f62_indices':[82,87,88,89],'body_counts_after':counts,'scope':'Four registry source length sites only: exact Logical purpose predicate; exact original segment agreement predicate; exact conditional Native head projection; original generic child operand-vector construction. Original owners remain in caller; exact ordered guards, provenance, inputs/config, all-alternative/3state refusals unchanged. No public API/visibility changes, assertions byte-preserved.','limits':'Off-tree fmt/assertion preparation only; no Cargo/typecheck/Clippy/runtime, independent type/order/drop peer required.'};(b/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(m['patch_sha256'],counts)
