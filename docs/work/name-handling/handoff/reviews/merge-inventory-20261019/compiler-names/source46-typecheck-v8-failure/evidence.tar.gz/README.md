# Eight-package all-target typecheck v8, candidate source46

Off-tree successor to preserved seven-package source30 v4. No root GO or approved integrated HEAD/tree exists here and no Cargo/build/lock has started. This prepares compilation evidence only; tests, runtime and release acceptance remain separate.

The package list adds only bpf-tcl-ir to the prior seven with the same pinned Cargo check --locked --keep-going --all-targets --message-format=json invocation. Exact46 before/after candidate source hashes derive from the prior source30 map plus the frozen coordinator next-batch v3 composition; root must verify final integration against every row and baseline before sealing GO.

The old reviewed executor is byte-identical. The same nonblocking single build lock, source/provider snapshots, exact approved HEAD ancestry and product map, docs-only descendants, GO/input checks, pre-spawn/post-build checks, lifecycle/empty-group/absolute deadline/disk/log caps and zero-warning Cargo JSON/stderr criteria remain.

Environment fix: launch sets the exact recorded successful source30 attempt2 build environment plus absolute pinned RUSTC and tool PATH prefix; suite verifies these values and both Cargo/rustc hashes before lock and pre-spawn. The runner-input manifest now includes suite.py itself, closing the prior v4 omission from root-GO input pins. No old v4 file is changed.

Before launch, root must supply root-go.json with source_commit, plan_sha256, runner_input_manifest_sha256, source46_manifest_sha256 and actual approved_integrated_head/tree after current integration verification. Never substitute the off-tree composition base HEAD for that final integration. The absent-GO launch self-check refuses without runner/lock/Cargo.

V6 refuses inherited compiler flag/wrapper/build-target overrides in both launcher and direct suite before lock. It also authenticates approved_integrated_head to the exact approved_integrated_tree and every source46 after hash, requires the worktree product to match that approved commit, and allows actual HEAD to advance only through docs/work/name-handling commits. Before/pre-spawn/after HEAD samples must advance monotonically and are recorded; exact HEAD equality is informational, not an acceptance requirement. Full source/provider snapshots, approved product identity and GO remain immutable.

V7 adds a final authenticated source_view after complete source/provider snapshots, requires the post-Cargo HEAD to be its ancestor, and records both post-Cargo and final-after-seals HEADs. The final head_after field denotes that last validated sample. No environment/process/executor change.

V8 changes only version/path/count and the source46 manifest bound to frozen coordinator next-batch v4 (28 new-path edits over source30, cumulative46 against3b1). All v7 environment/process/approved-product/docs-descendant/final-sampling guards remain identical. No root GO or final HEAD/tree exists in this preparation.
