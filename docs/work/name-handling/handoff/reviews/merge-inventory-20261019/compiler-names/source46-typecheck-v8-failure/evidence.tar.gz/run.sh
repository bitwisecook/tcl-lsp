#!/bin/sh
exec python3 /tmp/name-handling-eight-package-check-v8-source46/launch.py "$@"
