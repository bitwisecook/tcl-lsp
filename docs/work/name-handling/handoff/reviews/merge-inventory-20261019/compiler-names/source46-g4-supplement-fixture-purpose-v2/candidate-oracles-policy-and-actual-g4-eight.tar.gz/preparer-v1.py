from pathlib import Path
import hashlib,json,subprocess,difflib,datetime
root=Path('/workspace/naming-migration-active/tcl-lsp');b=Path('/tmp/compiler-names-g4-supplement-fixture-purpose-v1');b.mkdir(exist_ok=False);rels=['rust/tcl-compiler/src/command_binding/lifecycle_advice.rs','rust/tcl-compiler/src/command_binding/original_body_namespace.rs'];olds={r:(root/r).read_text() for r in rels};news=dict(olds)
r=rels[0];s=news[r];a='''        let advice = SourceCommandBindings::scoped_lifecycle_advice(&tokens, &registry)
            .expect("original scoped provider");''';assert s.count(a)==1;s=s.replace(a,'''        assert!(SourceCommandBindings::scoped_lifecycle_advice(&tokens, &registry).is_none());

        // An abrupt root keeps this independent declaration survey Conditional.
        // Its genuine source carrier must satisfy the scoped provider contract.
        let (bindings, tokens, registry) = inventory("; return ROOT");
        crate::command_binding::trace_original_g4_owner(
            "scoped-lifecycle-conditional",
            &bindings,
            &tokens,
        );
        let binding = tokens.source_binding.as_ref().unwrap();
        assert_eq!(
            binding.runtime_reachability(),
            super::super::SourceRuntimeReachability::Conditional
        );
        assert!(binding.lookup_state.is_some());
        assert!(bindings.final_state.baseline.native_entry.is_none());
'''+a);news[r]=s
r=rels[1];s=news[r];anchor='''    fn body_at(
''';helper='''    fn original_conditional_body_fixture(source: &str, environment: &str) -> OriginalBodyFixture {
        let wrapped = format!("proc conditional_body {{condition}} {{{source}}}; return ROOT");
        let mut fixture = original_fixture(&wrapped, environment);
        let start = wrapped.find(source).unwrap();
        fixture.tokens = source
            .match_indices("if ")
            .map(|(relative, _)| {
                let offset = u32::try_from(start + relative).unwrap();
                let binding = fixture.bindings.invocation_at_source("", offset);
                let (_, mut tokens) = binding
                    .original_recorded_command()
                    .expect("genuine original conditional body command");
                tokens.source_binding = Some(binding);
                tokens
            })
            .collect();
        fixture
    }

''';assert s.count(anchor)==1;s=s.replace(anchor,helper+anchor)
start=s.index('    fn original_immediate_body_namespace_keeps_actual_native_conditional_and_error_prefix()');a=s.index('                // The readonly namespace query',start);z=s.index('                assert!(\n                    fixture\n                        .bindings\n                        .executed_script_entry_namespace_context_at',a)
oldpositive=s[a:z];expected='''                // The readonly namespace query also retains conditional body
                // syntax; it does not assert that the body entered. Pin that
                // distinction against the exact actual-entry query.
                assert_eq!(
                    fixture.bindings.executed_script_namespace_context(&body),
                    Some(expected.clone())
                );
                let site = binding.invocation_site().unwrap();
                // Entered-script keys use post-head argument ordinals, while
                // body_at above consumes the whole written word ordinal.
                assert_eq!(fixture.bindings.executed_script_at(site, 1), Some(&body));
''';assert oldpositive==expected
s=s[:a]+'''                // A missing condition errors before selecting or entering this
                // body; the original namespace syntax above remains independent.
                assert!(fixture.bindings.executed_script_namespace_context(&body).is_none());
                let site = binding.invocation_site().unwrap();
                assert!(fixture.bindings.executed_script_at(site, 1).is_none());
'''+s[z:]
a=s.index('            let mut lowerer =',start)
newloop='''            // Unknown but bound formal input reaches genuine conditional body
            // observations. It does not infer entry from the lexical body word.
            let fixture = original_conditional_body_fixture(source, environment);
            let config = fixture.input.lexer_config();
            let expected = SourceNamespaceKey::from_native_entry(
                fixture.entry.native_entry.as_deref().unwrap(),
            ).unwrap();
            assert_eq!(fixture.tokens.len(), 2);
            for parent in &fixture.tokens {
                let binding = parent.source_binding.as_ref().unwrap();
                assert_eq!(binding.runtime_reachability(), super::super::SourceRuntimeReachability::Conditional);
                let body = body_at(parent, 2, config);
'''+oldpositive+'''                assert!(fixture.bindings.entered_scripts.values()
                    .flat_map(|arguments| arguments.values().flatten())
                    .any(|observation| observation.source == body
                        && observation.frame.is_none()
                        && observation.namespace.is_none()
                        && observation.conditional_namespace.as_ref() == Some(&expected)));
            }
'''
s=s[:a]+newloop+s[a:];news[r]=s
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();pins={};patch=''
for r,new in news.items():
 p=b/'shadow'/r;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(new);f=subprocess.run(['/workspace/.rustup/toolchains/1.99.1-x86_64-unknown-linux-gnu/bin/rustfmt','--edition','2024','--config','skip_children=true',str(p)],text=True,capture_output=True);assert f.returncode==0,f.stderr;patch+=''.join(difflib.unified_diff(olds[r].splitlines(True),p.read_text().splitlines(True),fromfile='a/'+r,tofile='b/'+r));pins[r]={'before':hashlib.sha256(olds[r].encode()).hexdigest(),'final':sha(p)}
(b/'proposal.patch').write_text(patch);m={'utc':datetime.datetime.now(datetime.UTC).isoformat(),'status':'OFFTREE test-purpose fixture split; genuine Conditional positive premises UNRUN, no source/production change','patch_sha256':sha(b/'proposal.patch'),'files':pins,'actual_basis':'Source46 actual row33 explicitly Reached/noNative but scoped API firstrequiresConditional. Row34 original_body_namespace_context SomeNative passes; independent executed_script_namespace_context None at454, condition error breaks source walker before body operand/conditional observation.','lifecycle':'Retains original Reached target/noNative assertions and scopedNone refusal, then original full phase/body/frame/source positive/refusal tail on independent real inventory ;returnROOT requiring actualConditional+lookupSome. No reachability mutation/provider/Native donation.','immediate':'Retains original full errorprefix source, independent namespace-syntax Some and noNativepreparation/entry/compiled refusals. Original executed_script namespace/argument positive assertions moved unchanged to actual original formal-bound unknown Conditional body fixture (ownNativeentry/source owner); requires exact recorded original child command/currentConditional+actual conditional namespace observation. All lowerer positive assertions retained; no fake body/namespace entry.','counts':'Same original2 test selectors, no added/ignored tests. Conditional source fixtures are meaningful positive obligations; exact Rust issuer availability unmeasured, may refuse.','limits':'Do not call existing original8 green or tests fixed until actualfresh run. No assertion-only None substitution without retaining independent genuine positive coverage. Compiler32/35 import separate, not repaired.','checks':'Pinnedfmt2024 parse2PASS, exactcurrentbefore, no Cargo/canonical/Git/GO.'};(b/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps(m))
