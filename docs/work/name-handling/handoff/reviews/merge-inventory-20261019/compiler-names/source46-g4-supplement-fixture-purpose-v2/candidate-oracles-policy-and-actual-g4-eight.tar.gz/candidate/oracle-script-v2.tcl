puts [list version [info patchlevel]]
unset -nocomplain condition result
set code [catch {if {$condition} {set result A}; if {[set condition]} {set result B}} value]
puts [list error_prefix $code [info exists result] $value]
proc observe_result {name1 name2 operation} {
    upvar 1 $name1 value
    lappend ::effects $value
}
proc conditional_body {condition observe} {
    if {$observe} {trace add variable result write observe_result}
    if {$condition} {set result A}; if {[set condition]} {set result B}
    if {[info exists result]} {return [list 1 $result]}
    return [list 0 NONE]
}
foreach observe {0 1} {
    foreach condition {0 1} {
        set ::effects {}
        set code [catch {conditional_body $condition $observe} value]
        puts [list formal $observe $condition $code $::effects $value]
    }
}
