from pathlib import Path
import hashlib,json,subprocess,difflib,datetime
r=Path('/workspace/naming-migration-active/tcl-lsp');b=Path('/tmp/compiler-names-import-child-outcome-trace-v1');b.mkdir(exist_ok=False);rels=['rust/tcl-compiler/src/command_binding.rs','rust/tcl-compiler/src/command_binding/compiled_preflight.rs','rust/tcl-compiler/src/command_binding/compiled_preflight/original_preparation.rs'];olds={n:(r/n).read_text() for n in rels};news=dict(olds)
n=rels[0];s=news[n];a='impl SourceOutcomes {\n';assert s.count(a)==1;s=s.replace(a,a+'''    #[cfg(debug_assertions)]
    fn trace_original_namespace_child(&self, stage: &str, offset: u32) {
        if std::env::var_os("TCL_LSP_TRACE_ORIGINAL_COMMAND_TABLE").is_some() {
            eprintln!(
                "ORIGINAL_NAMESPACE_CHILD stage={stage} site={offset} normal={} complete={} native_complete={} conditional_complete={} unclosed={:?} routes={:?}",
                self.normal.is_some(),
                self.normal_completion.is_some(),
                self.native_normal_completion.is_some(),
                self.conditional_normal_completion.is_some(),
                self.normal.as_ref().map(|normal| normal.unclosed_command_world),
                self.abrupt.iter().map(|(route, _)| route).collect::<Vec<_>>(),
            );
        }
    }

''',1)
a='''        if let Some(abrupt) = entry_error {
            outcomes.add_abrupt(''';z='''        #[cfg(debug_assertions)]
        if std::env::var_os("TCL_LSP_TRACE_ORIGINAL_COMMAND_TABLE").is_some() {
            eprintln!("ORIGINAL_NAMESPACE_CHILD_ENTRY base={base} entry_error={} segments={}", entry_error.is_some(), segments.len());
        }
        if let Some(abrupt) = entry_error {
            outcomes.add_abrupt(''';assert s.count(a)==1;s=s.replace(a,z,1)
a='''        for (index, segment) in segments.iter().enumerate() {
            let Some(mut continuing) = outcomes.normal.take() else {''';z='''        #[cfg(debug_assertions)]
        outcomes.trace_original_namespace_child("script_entry", base);
        for (index, segment) in segments.iter().enumerate() {
            let Some(mut continuing) = outcomes.normal.take() else {''';assert s.count(a)==1;s=s.replace(a,z,1)
a='''            outcomes.join(&command);
            outcomes.normal_completion = outcomes
                .normal_completion
                .filter(|_| prefix_complete.is_some());''';z='''            #[cfg(debug_assertions)]
            command.trace_original_namespace_child("command_return", segment.span.start());
            outcomes.join(&command);
            outcomes.normal_completion = outcomes
                .normal_completion
                .filter(|_| prefix_complete.is_some());''';assert s.count(a)==1;s=s.replace(a,z,1)
a='''            let Some(continuing) = &outcomes.normal else {
                continue;
            };
            self.record_continuation_source_point(segment, continuing, context);''';z='''            #[cfg(debug_assertions)]
            outcomes.trace_original_namespace_child("script_join", segment.span.start());
            let Some(continuing) = &outcomes.normal else {
                continue;
            };
            self.record_continuation_source_point(segment, continuing, context);''';assert s.count(a)==1;s=s.replace(a,z,1)
a='''        let assessment = compiled_preflight::preflight_image(image, base, state, context, snapshot);
''';z=a+'''        #[cfg(debug_assertions)]
        if std::env::var_os("TCL_LSP_TRACE_ORIGINAL_COMMAND_TABLE").is_some() {
            eprintln!(
                "ORIGINAL_NAMESPACE_CHILD_PREFLIGHT base={base} bytes={} failure={} possible_error={} native_entry_unavailable={} compiler_sites={} child_regions={} preview_depth={}",
                image.len(),
                assessment.failure.is_some(),
                assessment.possible_error,
                assessment.native_entry_unavailable,
                assessment.compiler_invocations.len(),
                assessment.compiled_children.len(),
                self.declaration_preview_depth,
            );
        }
''';assert s.count(a)==1;s=s.replace(a,z,1);news[n]=s
n=rels[1];s=news[n];a='''    fn require_provider(&mut self) {
        self.possible_error = true;''';z='''    #[cfg_attr(debug_assertions, track_caller)]
    fn require_provider(&mut self) {
        #[cfg(debug_assertions)]
        if std::env::var_os("TCL_LSP_TRACE_ORIGINAL_COMMAND_TABLE").is_some() {
            eprintln!(
                "ORIGINAL_NAMESPACE_CHILD_PROVIDER base={} previous_possible_error={} caller={}",
                self.chunk.offset, self.possible_error, std::panic::Location::caller(),
            );
        }
        self.possible_error = true;''';assert s.count(a)==1;s=s.replace(a,z,1)
a='''            scanner.possible_error = true;''';z='''            #[cfg(debug_assertions)]
            if std::env::var_os("TCL_LSP_TRACE_ORIGINAL_COMMAND_TABLE").is_some() {
                eprintln!("ORIGINAL_NAMESPACE_CHILD_PROVIDER base={base} reason=math_table_prerequisite_mismatch");
            }
            scanner.possible_error = true;''';assert s.count(a)==1;s=s.replace(a,z,1);news[n]=s
n=rels[2];s=news[n];a='''                | tcl_lexer::ExecutablePart::ParseError(_) => self.possible_error = true,''';z='''                | tcl_lexer::ExecutablePart::ParseError(_) => {
                    #[cfg(debug_assertions)]
                    if std::env::var_os("TCL_LSP_TRACE_ORIGINAL_COMMAND_TABLE").is_some() {
                        eprintln!("ORIGINAL_NAMESPACE_CHILD_PROVIDER base={} reason=expression_or_parse_error_part span={:?}", self.chunk.offset, component.span);
                    }
                    self.possible_error = true;
                }''';assert s.count(a)==1;s=s.replace(a,z,1);news[n]=s
patch='';pins={};sha=lambda d:hashlib.sha256(d).hexdigest()
for n,s in news.items():
 p=b/'shadow'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s);f=subprocess.run(['/workspace/.rustup/toolchains/1.99.1-x86_64-unknown-linux-gnu/bin/rustfmt','--edition','2024','--config','skip_children=true',str(p)],text=True,capture_output=True);assert f.returncode==0,f.stderr;patch+=''.join(difflib.unified_diff(olds[n].splitlines(True),p.read_text().splitlines(True),fromfile='a/'+n,tofile='b/'+n));pins[n]={'before':sha(olds[n].encode()),'final':sha(p.read_bytes())}
(b/'proposal.patch').write_text(patch);m={'utc':datetime.datetime.now(datetime.UTC).isoformat(),'status':'OFFTREE pure actual child Error/completion origin trace; no fix','patch_sha256':sha((b/'proposal.patch').read_bytes()),'files':pins,'actual_basis':'row35 C8.4 namespace eval33/86 BODY_FINISH normaltrue/child_completefalse/abrupt1. Original child commands proc/export/import return no abrupt, so rootstatefalse. Need distinguish preflight entryError from command/join completion withdrawal; current exactorigin unmeasured.','scope':'Read existing prepared preflight assessment once; trace source-script entryError and original outcome fields before/after unchanged joins. Debug trackcaller on existing require_provider setter + logs at both other possible_error assignments. No extra semantic query/condition/state change, all original ?/OR/join/result semantics and error alternatives preserved.','gate':'cfgdebug_assertions+existing TCL_LSP_TRACE_ORIGINAL_COMMAND_TABLE; trackcaller cfgdebug only','limits':'No new token/proof/Normal/Native/body/completion authority, no R1/force-import guard/test/Eq changes. Pinnedfmt3PASS; actualdiagnostic/Rusttyping/sourceapply/Cargo/Git/GO absent. Capturetail2f8d heldofftarget because prior tracefilter omitted actualFINISH lines.'};(b/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps(m))
