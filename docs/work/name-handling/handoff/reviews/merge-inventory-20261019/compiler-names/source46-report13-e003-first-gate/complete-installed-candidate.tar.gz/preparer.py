from pathlib import Path
import json,hashlib,subprocess,difflib,datetime
root=Path('/workspace/naming-migration-active/tcl-lsp');base=Path('/tmp/compiler-names-report-empty-installed-v1');base.mkdir(exist_ok=False);rel='rust/tcl-compiler/src/analyser/authenticated_report/body_correspondence.rs';old=(root/rel).read_text();s=old.replace('                module,\n                *id,','                module,\n                registry,\n                *id,');s=s.replace('        module: &crate::ir::Module,\n        id: ProcedureId,\n        body: ReportBodyOwner,','        module: &crate::ir::Module,\n        registry: &CommandRegistry,\n        id: ProcedureId,\n        body: ReportBodyOwner,')
assert s.count('.is_none_or(|source| source.is_empty())')==1
s=s.replace('.is_none_or(|source| source.is_empty())','.is_none_or(|source| {\n                    source.is_empty()\n                        && Self::empty_installed_body(module, registry, id, &body).is_none()\n                })')
helper='''    // An installed body retains its evaluated value extent. Admit an empty
    // extent only through the same current source card used by the Lowerer.
    fn empty_installed_body(
        module: &crate::ir::Module,
        registry: &CommandRegistry,
        id: ProcedureId,
        body: &ReportBodyOwner,
    ) -> Option<()> {
        (matches!(body.role, ReportBodyRole::Unit(ProcedureBodyKind::Installed))
            && body.id == id
            && body.declaration_purpose.is_none()
            && body.declaration.is_empty())
        .then_some(())?;
        let positioned = module
            .retained_source_bindings
            .as_ref()?
            .positioned_for_module(module, registry)?;
        let root = positioned.source_origin()?;
        let allocation = module.installed_procedure_body_units.get(&id)?;
        let held = module.body_units.get(&id)?;
        let source = body.source.as_ref()?;
        let namespace = body.namespace.as_deref()?;
        (module.procedure_ids.owns(id)
            && held.body_kind == ProcedureBodyKind::Installed
            && held.span == body.declaration
            && held.declaration_site == body.site
            && Some(held.body_offset) == body.body_offset
            && held.body_offset == body.declaration.start()
            && held.body.executed_source.as_ref().is_some_and(|actual| Arc::ptr_eq(actual, source))
            && held.body.namespace_context.as_deref() == Some(namespace)
            && body.site.as_ref() == Some(&allocation.site)
            && allocation.matches_source_declaration_image(&module.source, allocation.site.offset)
            && Arc::ptr_eq(&allocation.site.source, root)
            && Arc::ptr_eq(&source.origin, root)
            && source.text.bytes().is_empty()
            && matches!(
                &source.mapping,
                crate::command_binding::ExecutedScriptMapping::Contiguous { base }
                    if *base == body.declaration.start()
            ))
        .then_some(())?;
        positioned.installed_procedure_body_units().into_iter().any(|card| {
            card.allocation == *allocation
                && card.source == **source
                && Arc::ptr_eq(&card.source.origin, root)
                && card.namespace_key == *namespace
        }).then_some(())
    }

'''
anchor='    #[cfg(test)]\n    pub(super) fn hosted_domain_for_test';assert anchor in s;s=s.replace(anchor,helper+anchor)
test='''    #[test]
    fn empty_installed_body_requires_the_current_complete_source_card() {
        let source = "proc retained {} {}\\nretained EXTRA";
        let left = Analyser::new().analyse_for_report(source, "tcl8.6");
        let right = Analyser::new().analyse_for_report(source, "tcl8.6");
        let capture = left.current_capture().expect("genuine empty installed body");
        assert_eq!(left.compare(&right), super::super::AnalysisReportComparison::Equal);
        let module = &capture.bodies.prepared.unit().ir_module;
        let registry = left.analysis.resolved_registry().unwrap();
        let (&id, _) = module.installed_procedure_body_units.iter().next().unwrap();
        let make = |module: &crate::ir::Module| {
            ReportBodyInventory::procedure(module, id, module.body_units.get(&id).unwrap(), ReportBodyRole::Unit(ProcedureBodyKind::Installed)).unwrap()
        };
        let body = make(module);
        assert_eq!(body.declaration, Span::empty(18));
        assert!(body.declaration_purpose.is_none());
        assert!(ReportBodyInventory::empty_installed_body(module, registry, id, &body).is_some());
        let mut missing = module.clone();
        missing.installed_procedure_body_units.remove(&id);
        assert!(ReportBodyInventory::empty_installed_body(&missing, registry, id, &body).is_none());
        let mut changed = module.clone();
        changed.body_units.get_mut(&id).unwrap().body_offset += 1;
        assert!(ReportBodyInventory::empty_installed_body(&changed, registry, id, &make(&changed)).is_none());
        let mut no_owner = module.clone();
        no_owner.retained_source_bindings = None;
        assert!(ReportBodyInventory::empty_installed_body(&no_owner, registry, id, &body).is_none());
        let foreign = &right.current_capture().unwrap().bodies.prepared.unit().ir_module;
        assert!(ReportBodyInventory::empty_installed_body(foreign, registry, id, &body).is_none());
        let mut wrong_role = make(module);
        wrong_role.role = ReportBodyRole::Unit(ProcedureBodyKind::OriginalDeclaration);
        assert!(ReportBodyInventory::empty_installed_body(module, registry, id, &wrong_role).is_none());
        let mut wrong_purpose = make(module);
        wrong_purpose.declaration_purpose = Some(ReportDeclarationPurpose::AllocatedSource);
        assert!(ReportBodyInventory::empty_installed_body(module, registry, id, &wrong_purpose).is_none());
        let mut wrong_span = make(module);
        wrong_span.declaration = Span::empty(0);
        assert!(ReportBodyInventory::empty_installed_body(module, registry, id, &wrong_span).is_none());
        let mut out_of_range = make(module);
        out_of_range.declaration = Span::empty(u32::try_from(source.len() + 1).unwrap());
        assert!(ReportBodyInventory::push(&mut Vec::new(), module, registry, id, out_of_range).is_none());
        let mut bodies = Vec::new();
        assert!(ReportBodyInventory::push(&mut bodies, module, registry, id, make(module)).is_some());
        assert!(ReportBodyInventory::push(&mut bodies, module, registry, id, make(module)).is_none());
        assert_eq!(bodies.len(), 1);
    }

'''
anchor='    #[test]\n    fn actual_complete_body_inventory_is_total_and_role_sensitive()';assert anchor in s;s=s.replace(anchor,test+anchor)
p=base/'shadow'/rel;p.parent.mkdir(parents=True);p.write_text(s);fmt=subprocess.run(['/workspace/.rustup/toolchains/1.99.1-x86_64-unknown-linux-gnu/bin/rustfmt','--edition','2024',str(p)],text=True,capture_output=True);assert fmt.returncode==0,fmt.stderr
patch=''.join(difflib.unified_diff(old.splitlines(True),p.read_text().splitlines(True),fromfile='a/'+rel,tofile='b/'+rel));(base/'proposal.patch').write_text(patch);sha=lambda x:hashlib.sha256(x.read_bytes()).hexdigest();r={'utc':datetime.datetime.now(datetime.UTC).isoformat(),'status':'OFFTREE exact actual Installed empty extent producer repair candidate; untyped/unrun','path':rel,'before_sha256':hashlib.sha256(old.encode()).hexdigest(),'final_sha256':sha(p),'patch_sha256':sha(base/'proposal.patch'),'actual_first_refusal':'source46 compiler58 report13 stderr525-527/543-545 and711-749 Unit Installed empty18..18; owns true, duplicate false, all original purpose flags false; capture.bodies unavailable','scope':'Only UnitInstalled/no declarationpurpose/current installed allocation and independently issued installed card, exact positioned Module/registry/input/root Arc/held source Arc/span/site/bodyoffset/namespace/contiguous emptyvalue. No role relabel. Existing OriginalDeclaration-only a9c4 stays separate/not applied. Existing tests unchanged; one genuine positive/fullcompare and missingcard/changedactualoffset/missingowner/foreign/unsupportedrole/purpose/span/outofrange/duplicate controls unrun.','uniqueness':'Owner installed_procedure_body_units sorts+dedup_by exact allocation; matcher requires allocation plus source/namespace/root identity, hence at most one emitted match.','checks':'Pinnedfmt2024 PASS; no canonical source/Cargo/Git/GO. Peer and fresh Rust type/runtime required.'};(base/'manifest.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
