from pathlib import Path
import json,hashlib,difflib,subprocess,datetime
r=Path('/workspace/naming-migration-active/tcl-lsp');prev=Path('/tmp/compiler-names-normal-source-analysis-owner-v2');b=Path('/tmp/compiler-names-normal-source-analysis-owner-v3');b.mkdir(exist_ok=True);rels=['rust/tcl-compiler/src/command_binding/source_transition_advice.rs','rust/tcl-compiler/src/command_binding/source_point_entry.rs','rust/tcl-compiler/src/command_binding/source_transition_advice/source_point.rs'];sha=lambda d:hashlib.sha256(d).hexdigest();patch='';pins={}
append='''        let second_seed = other.original_source_transition_seed().unwrap();
        let second_input = foreign.resolved_input.as_ref().unwrap();
        assert!(
            second_seed
                .normal_source_outcome_graph(second_input.borrowed_context_registry(), other)
                .is_some()
        );
'''
for rel in rels:
 old=(r/rel).read_text();s=(prev/'shadow'/rel).read_text();v2=s
 if rel.endswith('/source_point.rs'):
  start=s.index('    fn normal_source_outcome_refuses_foreign_equal_source_and_changed_config()');end=s.index('\n}\n\n#[cfg(test)]\nmod conditional_region_purpose_controls',start);part=s[start:end];a='''        assert!(
            changed
                .normal_source_outcome_graph(input.borrowed_context_registry(), bindings)
                .is_none()
        );
    }
''';a=a.rstrip('\n');assert part.count(a)==1;part=part.replace(a,a[:-5]+append+'    }',1);s=s[:start]+part+s[end:]
 p=b/'shadow'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s);x=subprocess.run(['/workspace/.rustup/toolchains/1.99.1-x86_64-unknown-linux-gnu/bin/rustfmt','--edition','2024','--config','skip_children=true',str(p)],capture_output=True,text=True);assert x.returncode==0,x.stderr;final=p.read_text()
 if rel.endswith('/source_point.rs'):assert final.replace(append,'',1)==v2
 else:assert final==v2
 patch+=''.join(difflib.unified_diff(old.splitlines(True),final.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel));pins[rel]={'before':sha(old.encode()),'v2_final':sha(v2.encode()),'final':sha(final.encode())}
(b/'proposal.patch').write_text(patch);m={'utc':datetime.datetime.now(datetime.UTC).isoformat(),'status':'OFFTREE test-only successor to peer-CLEAR Normalownerv2; Rusttyping/runtime UNRUN','patch_sha256':sha((b/'proposal.patch').read_bytes()),'predecessor_patch_sha256':'6ae79e80c768429d8e0694ee232fab4fc39e04c40fa819d0179007ba405e2bc1','files':pins,'delta':'Only appends genuine second equal-source analysis ownseed→ownbindings Some at end of existing refusaltest AFTERallcurrentassertions. Uses original foreign AnalysisResult/other bindings and its genuine issuer; no source mutation/reconstructed owner/foreign donation. Removing append restores entirev2file byte-for-byte; other2files byteidenticalv2. Same exactselector/count.','production':'All production/ownerptr/old4fieldEq and every oldpositive/negative/Eq assertion inoriginalorder unchanged byte-for-byte fromv2. V2/core17 immutable.','checks':'Pinnedfmtedition2024 parse3PASS; v2 exactbyte-restoration proofPASS; no Cargo/source/Git/GO/fixturepolicy change.'};(b/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');(b/'added-assertion.txt').write_text(append);print(json.dumps(m))
