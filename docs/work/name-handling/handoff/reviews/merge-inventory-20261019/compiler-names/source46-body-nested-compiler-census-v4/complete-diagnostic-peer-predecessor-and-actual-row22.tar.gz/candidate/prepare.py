from pathlib import Path
import json,hashlib,difflib,subprocess,datetime
r=Path('/workspace/naming-migration-active/tcl-lsp');prev=Path('/tmp/compiler-names-body-nested-compiler-census-v3');b=Path('/tmp/compiler-names-body-nested-compiler-census-v4');b.mkdir(exist_ok=False);m=json.loads((prev/'manifest.json').read_text());sha=lambda d:hashlib.sha256(d).hexdigest();patch=''
for rel,pins in m['files'].items():
 old=(r/rel).read_text();assert sha(old.encode())==pins['before'];s=(prev/'shadow'/rel).read_text()
 if rel.endswith('compiler_inventory.rs'):
  a='''/// Runtime entry knowledge for one exact original command allocation.
''';helper='''fn trace_compiler_syntax_option<T>(stage: &str, offset: Option<u32>, value: Option<T>) -> Option<T> {
    #[cfg(debug_assertions)]
    if std::env::var_os("TCL_LSP_TRACE_BODY_SYNTAX").is_some() {
        eprintln!("ORIGINAL_COMPILER_SYNTAX_GATE stage={stage} offset={offset:?} present={}", value.is_some());
    }
    #[cfg(not(debug_assertions))]
    let _ = (stage, offset);
    value
}

fn trace_compiler_syntax_flag(stage: &str, offset: Option<u32>, value: bool) -> bool {
    #[cfg(debug_assertions)]
    if std::env::var_os("TCL_LSP_TRACE_BODY_SYNTAX").is_some() {
        eprintln!("ORIGINAL_COMPILER_SYNTAX_GATE stage={stage} offset={offset:?} value={value}");
    }
    #[cfg(not(debug_assertions))]
    let _ = (stage, offset);
    value
}

''';assert s.count(a)==1;s=s.replace(a,helper+a,1)
  start=s.index('    pub(crate) fn original_compiler_syntax_alternatives');end=s.index('\nfn original_compiler_syntax_alternative',start);part=s[start:end]
  a='''        let owner = self.original_analysis_owner.as_ref()?;
        let binding = tokens.source_binding.as_ref()?;
        if tokens.synthetic.is_some()
            || !tokens.original_words_match_argv_text()
            || input.has_logical_source_name_context()
            || input.has_hosted_source_name_context()
            || !binding
                .original_analysis_owner
                .as_ref()
                .is_some_and(|actual| Arc::ptr_eq(actual, owner))
            || owner.metadata.source_analysis_input() != Some(input)
            || !self
                .matches_original_source_image(owner.source.source_image(), input.lexer_config())
''';z='''        let offset = tokens.words().first().map(|word| word.source().span.start());
        #[cfg(debug_assertions)]
        if std::env::var_os("TCL_LSP_TRACE_BODY_SYNTAX").is_some() {
            eprintln!("ORIGINAL_COMPILER_SYNTAX_QUERY offset={offset:?} words={:?} argv_texts={:?} input_config={:?}", tokens.words(), tokens.argv_texts, input.lexer_config());
        }
        let owner = trace_compiler_syntax_option("analysis_owner", offset, self.original_analysis_owner.as_ref())?;
        let binding = trace_compiler_syntax_option("source_binding", offset, tokens.source_binding.as_ref())?;
        if trace_compiler_syntax_flag("synthetic", offset, tokens.synthetic.is_some())
            || trace_compiler_syntax_flag("word_text_mismatch", offset, !tokens.original_words_match_argv_text())
            || trace_compiler_syntax_flag("logical_context", offset, input.has_logical_source_name_context())
            || trace_compiler_syntax_flag("hosted_context", offset, input.has_hosted_source_name_context())
            || trace_compiler_syntax_flag("binding_owner_mismatch", offset, !binding
                .original_analysis_owner
                .as_ref()
                .is_some_and(|actual| Arc::ptr_eq(actual, owner)))
            || trace_compiler_syntax_flag("owner_input_mismatch", offset, owner.metadata.source_analysis_input() != Some(input))
            || trace_compiler_syntax_flag("source_image_mismatch", offset, !self
                .matches_original_source_image(owner.source.source_image(), input.lexer_config()))
''';assert a in part;part=part.replace(a,z,1)
  part=part.replace('''offset: tokens.words().first()?.source().span.start(),''','''offset: trace_compiler_syntax_option("head_word", offset, tokens.words().first())?.source().span.start(),''',1)
  a='''        if let Some(children) = self.original_child_compiler_visits(&site) {
            visits.extend(children);
        }
        if visits.is_empty() {''';z='''        #[cfg(debug_assertions)]
        if std::env::var_os("TCL_LSP_TRACE_BODY_SYNTAX").is_some() {
            eprintln!("ORIGINAL_COMPILER_SYNTAX_DIRECT offset={offset:?} visits={}", visits.len());
        }
        if let Some(children) = trace_compiler_syntax_option("child_visits", offset, self.original_child_compiler_visits(&site)) {
            visits.extend(children);
        }
        if trace_compiler_syntax_flag("visits_empty", offset, visits.is_empty()) {''';assert a in part;part=part.replace(a,z,1)
  a='''            .map(|visit| {
                original_compiler_syntax_alternative(visit, owner, tokens, input, registry)
            })''';z='''            .enumerate()
            .map(|(ordinal, visit)| {
                #[cfg(debug_assertions)]
                if std::env::var_os("TCL_LSP_TRACE_BODY_SYNTAX").is_some() {
                    eprintln!("ORIGINAL_COMPILER_SYNTAX_VISIT offset={offset:?} ordinal={ordinal} words={:?}", visit.original_words.as_ref().map(|words| &words.words));
                }
                #[cfg(not(debug_assertions))]
                let _ = ordinal;
                trace_compiler_syntax_option("alternative", offset, original_compiler_syntax_alternative(visit, owner, tokens, input, registry))
            })''';assert a in part;part=part.replace(a,z,1);s=s[:start]+part+s[end:]
  start=s.index('fn original_compiler_syntax_alternative<');end=s.index('\n#[cfg(test)]\nmod source_syntax_alternative_tests',start);part=s[start:end]
  a='''    let original = visit.original_words.as_ref()?;
    let policy = visit.policy.as_ref()?;
    policy.compiler?;
    policy.source_protocol?;
    let dialect = policy.words?;''';z='''    let offset = tokens.words().first().map(|word| word.source().span.start());
    let original = trace_compiler_syntax_option("visit.original_words", offset, visit.original_words.as_ref())?;
    let policy = trace_compiler_syntax_option("visit.policy", offset, visit.policy.as_ref())?;
    trace_compiler_syntax_option("visit.compiler", offset, policy.compiler)?;
    trace_compiler_syntax_option("visit.source_protocol", offset, policy.source_protocol)?;
    let dialect = trace_compiler_syntax_option("visit.word_dialect", offset, policy.words)?;''';assert a in part;part=part.replace(a,z,1)
  a='''    if original.words.as_ref() != tokens.words()
        || original.config != input.lexer_config()
        || owner.config != original.config
        || !Arc::ptr_eq(&owner.source, &original.site.source)
        || snapshot.state.current_source_origin.as_ref() != Some(&original.site.source)
        || snapshot.state.baseline.registry_snapshot != Some(registry.snapshot().semantic_key())
        || policy.realm != snapshot.realm
''';z='''    if trace_compiler_syntax_flag("visit.word_vector_mismatch", offset, original.words.as_ref() != tokens.words())
        || trace_compiler_syntax_flag("visit.input_config_mismatch", offset, original.config != input.lexer_config())
        || trace_compiler_syntax_flag("visit.owner_config_mismatch", offset, owner.config != original.config)
        || trace_compiler_syntax_flag("visit.origin_mismatch", offset, !Arc::ptr_eq(&owner.source, &original.site.source))
        || trace_compiler_syntax_flag("visit.snapshot_origin_mismatch", offset, snapshot.state.current_source_origin.as_ref() != Some(&original.site.source))
        || trace_compiler_syntax_flag("visit.registry_mismatch", offset, snapshot.state.baseline.registry_snapshot != Some(registry.snapshot().semantic_key()))
        || trace_compiler_syntax_flag("visit.realm_mismatch", offset, policy.realm != snapshot.realm)
''';assert a in part;part=part.replace(a,z,1)
  a='''    original.site.source.original_lexical_command(
        &original.words,
        original.site.offset,
        original.config,
    )?;''';z='''    trace_compiler_syntax_option("visit.original_lexical_command", offset, original.site.source.original_lexical_command(
        &original.words,
        original.site.offset,
        original.config,
    ))?;''';assert a in part;part=part.replace(a,z,1)
  a='''    let point = snapshot
        .state
        .baseline
        .metadata_context
        .source_analysis_input()?;
    if point != input && point != &input.for_nested_source() {''';z='''    let point = trace_compiler_syntax_option("visit.point_input", offset, snapshot
        .state
        .baseline
        .metadata_context
        .source_analysis_input())?;
    if trace_compiler_syntax_flag("visit.point_input_mismatch", offset, point != input && point != &input.for_nested_source()) {''';assert a in part;part=part.replace(a,z,1)
  a='''    let metadata = crate::registry_invocation::InvocationMetadataContext::for_source_input(
        registry,
        point,
        original.config,
        Some(point.unit_profile()),
    )?;''';z='''    let metadata = trace_compiler_syntax_option("visit.metadata", offset, crate::registry_invocation::InvocationMetadataContext::for_source_input(
        registry,
        point,
        original.config,
        Some(point.unit_profile()),
    ))?;''';assert a in part;part=part.replace(a,z,1);s=s[:start]+part+s[end:]
 p=b/'shadow'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s);x=subprocess.run(['/workspace/.rustup/toolchains/1.99.1-x86_64-unknown-linux-gnu/bin/rustfmt','--edition','2024','--config','skip_children=true',str(p)],capture_output=True,text=True);assert x.returncode==0,x.stderr;patch+=''.join(difflib.unified_diff(old.splitlines(True),p.read_text().splitlines(True),fromfile='a/'+rel,tofile='b/'+rel));pins['final']=sha(p.read_bytes())
(b/'proposal.patch').write_text(patch);m.update(utc=datetime.datetime.now(datetime.UTC).isoformat(),status='OFFTREE pure nested census v3 plus central compiler alternatives firstgate trace; row22 initialpositive unmeasured',patch_sha256=sha((b/'proposal.patch').read_bytes()),predecessor_patch_sha256='03e603db557c11905df2cb15cfaa2bc50a63434ddae44861adaee64fb899fc28',delta='Only compiler_inventory adds generic Option/bool identity helpers and traces existing central all-actual-alternatives query guards. Logs actual parsed vector+original visit vectors, direct/child visit presence and ordered per-visit refusal; preserves all v3 census/nestedfields/querycode. No new semanticquery/token/lookup, firstonly/filter/missing reduction, assertion or policy change. Source image/input/owner/registry/config/realm guards and collect<Option> failclosed preserved.',actual_row22='Initial alternatives unwrapNone before all later negatives. Fixture uses suffix from innerif through outerprocclose; exact-vector hypothesis unproved. No fixture trim/relex or assertion correction; future authentic retained carrier only if measured.');(b/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps(m))
