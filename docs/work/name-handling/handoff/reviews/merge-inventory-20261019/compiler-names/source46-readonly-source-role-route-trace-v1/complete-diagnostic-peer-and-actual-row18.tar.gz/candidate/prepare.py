from pathlib import Path
import json,hashlib,difflib,subprocess,datetime
r=Path('/workspace/naming-migration-active/tcl-lsp');b=Path('/tmp/compiler-names-readonly-source-role-route-trace-v1');b.mkdir(exist_ok=False);rel='rust/tcl-compiler/src/registry_invocation/source_structure.rs';old=(r/rel).read_text();s=old
anchor='''/// Original document/workspace assistance at the unchanged complete call.
''';assert s.count(anchor)==1
helper='''fn trace_original_source_role_option<T>(stage: &str, offset: Option<u32>, value: Option<T>) -> Option<T> {
    #[cfg(debug_assertions)]
    if std::env::var_os("TCL_LSP_TRACE_BODY_SYNTAX").is_some() {
        eprintln!("ORIGINAL_SOURCE_ROLE_ROUTE stage={stage} offset={offset:?} present={}", value.is_some());
    }
    #[cfg(not(debug_assertions))]
    let _ = (stage, offset);
    value
}

fn trace_original_source_role_words(stage: &str, offset: Option<u32>, value: Option<OriginalRegistryWords>) -> Option<OriginalRegistryWords> {
    #[cfg(debug_assertions)]
    if std::env::var_os("TCL_LSP_TRACE_BODY_SYNTAX").is_some() {
        if let Some(words) = value.as_ref() {
            let source = match &words.source {
                OriginalRegistrySource::Selected => "Selected",
                OriginalRegistrySource::Scoped(_) => "Scoped",
                OriginalRegistrySource::DefinitionMember(_) => "DefinitionMember",
                OriginalRegistrySource::SourceTransitions(_) => "SourceTransitions",
                OriginalRegistrySource::ProducedPrefix(_) => "ProducedPrefix",
                OriginalRegistrySource::Conditional(_) => "Conditional",
                OriginalRegistrySource::ConditionalNativeSource(_) => "ConditionalNativeSource",
                OriginalRegistrySource::Vendor(_) => "Vendor",
            };
            eprintln!("ORIGINAL_SOURCE_ROLE_ROUTE stage={stage} offset={offset:?} present=true source={source} command={:?} roles={:?} operands_preserve_lookup={}", words.command, words.roles, words.operands_preserve_source_lookup);
        } else {
            eprintln!("ORIGINAL_SOURCE_ROLE_ROUTE stage={stage} offset={offset:?} present=false");
        }
    }
    #[cfg(not(debug_assertions))]
    let _ = (stage, offset);
    value
}

#[cfg(debug_assertions)]
fn trace_original_source_role_binding(stage: &str, offset: Option<u32>, binding: Option<&crate::command_binding::SourceInvocationBinding>) {
    if std::env::var_os("TCL_LSP_TRACE_BODY_SYNTAX").is_some() {
        if let Some(binding) = binding {
            eprintln!("ORIGINAL_SOURCE_ROLE_BINDING stage={stage} offset={offset:?} targets={:?} unknown={} absent={} runtime_state={} compiler_state={} compiler_admission={:?}", binding.targets.iter().map(|target| (&target.command, target.registry_backed, &target.kind)).collect::<Vec<_>>(), binding.unknown, binding.may_be_absent, binding.lookup_state.is_some(), binding.compiler_lookup_state.is_some(), binding.native_compilation_admission);
        } else {
            eprintln!("ORIGINAL_SOURCE_ROLE_BINDING stage={stage} offset={offset:?} present=false");
        }
    }
}

''';s=s.replace(anchor,helper+anchor,1)
start=s.index('pub fn source_declared_command_words(');end=s.index('/// Fresh readonly source grammar',start);part=s[start:end];a='''    realm.stamp_original_tokens(&mut tokens);
''';z=a+'''    #[cfg(debug_assertions)]
    trace_original_source_role_binding("declared", segment.argv.first().map(|word| word.span.start()), tokens.source_binding.as_ref());
''';assert part.count(a)==1;part=part.replace(a,z,1)
a='''    let selected = binding
        .original_declared_source_selection(&tokens, input, &original)
        .or_else(|| realm.original_authored_declared_source_selection(input, &tokens, &original))?;
    crate::command_binding::OriginalDeclaredCommandWords::from_selected(selected, input)''';z='''    let selected = trace_original_source_role_option("declared.point", Some(offset), binding.original_declared_source_selection(&tokens, input, &original))
        .or_else(|| trace_original_source_role_option("declared.authored", Some(offset), realm.original_authored_declared_source_selection(input, &tokens, &original)))?;
    trace_original_source_role_option("declared.words", Some(offset), crate::command_binding::OriginalDeclaredCommandWords::from_selected(selected, input))''';assert a in part;part=part.replace(a,z,1);s=s[:start]+part+s[end:]
start=s.index('fn source_registry_words_with_definition_parent(');end=s.index('\nfn source_definition_body_grammar(',start);part=s[start:end];a='''    realm.stamp_original_tokens(&mut tokens);
    let blocked = realm.original_source_registry_barrier(&input.context_registry(), &tokens);''';z='''    realm.stamp_original_tokens(&mut tokens);
    #[cfg(debug_assertions)]
    trace_original_source_role_binding("registry", segment.argv.first().map(|word| word.span.start()), tokens.source_binding.as_ref());
    let blocked = realm.original_source_registry_barrier(&input.context_registry(), &tokens);
    #[cfg(debug_assertions)]
    if std::env::var_os("TCL_LSP_TRACE_BODY_SYNTAX").is_some() {
        eprintln!("ORIGINAL_SOURCE_ROLE_ROUTE stage=registry.barrier offset={:?} blocked={blocked}", segment.argv.first().map(|word| word.span.start()));
    }''';assert a in part;part=part.replace(a,z,1)
part=part.replace('''if let Some(scoped) = original_scoped_registry_words(source, analysis, segment) {''','''if let Some(scoped) = trace_original_source_role_words("registry.scoped", segment.argv.first().map(|word| word.span.start()), original_scoped_registry_words(source, analysis, segment)) {''',1)
part=part.replace('''&& let Some(selected) = selected_registry_words(source, analysis, segment, registry)''','''&& let Some(selected) = trace_original_source_role_words("registry.selected", segment.argv.first().map(|word| word.span.start()), selected_registry_words(source, analysis, segment, registry))''',1)
a='''    native_source_registry_words(
        source,
        config,
        analysis.retained_command_realm()?,
        &context,
        segment,
        metadata,
    )''';z='''    trace_original_source_role_words("registry.native", Some(offset), native_source_registry_words(
        source,
        config,
        analysis.retained_command_realm()?,
        &context,
        segment,
        metadata,
    ))''';assert a in part;part=part.replace(a,z,1)
a='''        let advice = realm.original_source_prefix_catalogue_advice(input, &tokens)?;
        source_transition_words_with_segment(source, config, &context, segment, advice)''';z='''        let advice = trace_original_source_role_option("registry.prefix_advice", Some(offset), realm.original_source_prefix_catalogue_advice(input, &tokens))?;
        trace_original_source_role_words("registry.prefix_words", Some(offset), source_transition_words_with_segment(source, config, &context, segment, advice))''';assert a in part;part=part.replace(a,z,1)
a='''        let advice = realm.original_member_source_catalogue_advice(input, &tokens)?;
        source_transition_words_with_segment(source, config, &context, segment, advice)''';z='''        let advice = trace_original_source_role_option("registry.member_advice", Some(offset), realm.original_member_source_catalogue_advice(input, &tokens))?;
        trace_original_source_role_words("registry.member_words", Some(offset), source_transition_words_with_segment(source, config, &context, segment, advice))''';assert a in part;part=part.replace(a,z,1);s=s[:start]+part+s[end:]
start=s.index('fn native_source_registry_words(');end=s.index('\nfn conditional_source_values(',start);part=s[start:end]
a='''        native_source_metadata(source, config, realm, context, segment, retained_metadata)''';z='''        trace_original_source_role_option("native.metadata", segment.argv.first().map(|word| word.span.start()), native_source_metadata(source, config, realm, context, segment, retained_metadata))''';assert a in part;part=part.replace(a,z,1)
a='''        return source_transition_registry_words(source, config, realm, context, segment);''';z='''        return trace_original_source_role_words("native.transition_fallback", segment.argv.first().map(|word| word.span.start()), source_transition_registry_words(source, config, realm, context, segment));''';assert a in part;part=part.replace(a,z,1)
a='''    let metadata = if let Some(metadata) = retained_metadata {
        metadata''';z='''    let metadata = if let Some(metadata) = trace_original_source_role_option("metadata.retained", segment.argv.first().map(|word| word.span.start()), retained_metadata) {
        metadata''';assert a in part;part=part.replace(a,z,1)
a='''                binding.original_catalogue_source_candidate_from_tokens(&tokens, registry)''';z='''                trace_original_source_role_option("metadata.point_candidate", segment.argv.first().map(|word| word.span.start()), binding.original_catalogue_source_candidate_from_tokens(&tokens, registry))''';assert a in part;part=part.replace(a,z,1)
a='''                realm
                    .source_bindings_ref()
                    .original_future_source_catalogue_candidate(&image, config, &tokens, registry)''';z='''                trace_original_source_role_option("metadata.future_candidate", segment.argv.first().map(|word| word.span.start()), realm
                    .source_bindings_ref()
                    .original_future_source_catalogue_candidate(&image, config, &tokens, registry))''';assert a in part;part=part.replace(a,z,1);s=s[:start]+part+s[end:]
p=b/'shadow'/rel;p.parent.mkdir(parents=True);p.write_text(s);x=subprocess.run(['/workspace/.rustup/toolchains/1.99.1-x86_64-unknown-linux-gnu/bin/rustfmt','--edition','2024','--config','skip_children=true',str(p)],text=True,capture_output=True);assert x.returncode==0,x.stderr;patch=''.join(difflib.unified_diff(old.splitlines(True),p.read_text().splitlines(True),fromfile='a/'+rel,tofile='b/'+rel));(b/'proposal.patch').write_text(patch);sha=lambda d:hashlib.sha256(d).hexdigest();m={'utc':datetime.datetime.now(datetime.UTC).isoformat(),'patch_sha256':sha((b/'proposal.patch').read_bytes()),'files':{rel:{'before':sha(old.encode()),'final':sha(p.read_bytes())}},'status':'OFFTREE pure Readonly source-role route diagnostic; no cause/fix claim','scope':'Original declared primary/authored and registry scoped/selected/native/prefix/member and metadata retained/point/future fallback paths wrapped in identity helpers; same old queries once/or_else lazy order/returns. Read stamped binding existing target/state/admission fields and returned carrier sourcekind/roles/preserve flag only. Logical/vendor/definition routes unchanged (fixed fixture plainNative).','gate':'cfgdebug_assertions+existing TCL_LSP_TRACE_BODY_SYNTAX; linked core library included','actual':'row18 Readonly firstassert body data incorrectly Script; source-only newSyntaxCompaction branch excluded bypurpose. Actual returned issuer route unmeasured; authored declaredfallback refuses nonempty actualtargets. No inferred repair.','limits':'No assertion/fixture/proof/Eq/cache/Normal/Native/body authority or barrier/fallback logic change. No semantic extraquery. PinnedfmtparsePASS, Rusttyping/runtime/sourceapply/Cargo/Git/GO absent.'};(b/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps(m))
