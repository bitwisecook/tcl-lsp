from pathlib import Path
import json,hashlib,difflib,subprocess
B=Path(__file__).parent
for label,R in [('work',Path('/workspace/naming-migration-publish/tcl-lsp')),('candidate',Path('/workspace/naming-lsp-release/tcl-lsp'))]:
 out={};p='rust/tcl-vm/src/value.rs';s=(R/p).read_text();start=s.index('    fn native_scalar_probe_using<');a=s.index('        let protocol = dialect',start);b=s.index('        let jim_abi =',a);body=s[a:b];s=s[:a]+'''        let (protocol, string_protocol) = self.native_scalar_probe_protocols(dialect)?;
'''+s[b:];body=body.replace('return Err(ValueError::ScalarNumericInputUnavailable.into());','return Err(ValueError::ScalarNumericInputUnavailable);');helper='''    fn native_scalar_probe_protocols(
        &self,
        dialect: tcl_registry::InvocationDialect,
    ) -> Result<(NativeScalarGetterProtocol, NativeStringProtocol), ValueError> {
'''+body+'''        Ok((protocol, string_protocol))
    }

''';i=s.index('    fn fresh_native_scalar_conversion_using<',start);s=s[:i]+helper+s[i:];out[p]=s
 p='rust/tcl-vm/src/cmd_oo.rs';s=(R/p).read_text();old='''        let usage = match vm.native_argument_usage_header(&words) {
            Ok(usage) => usage,
            Err(completion) => return Err(completion),
        };''';assert s.count(old)==1;s=s.replace(old,'        let usage = vm.native_argument_usage_header(&words)?;',1);out[p]=s
 p='rust/tcl-vm/src/interp/variable_cleanup.rs';s=(R/p).read_text();old='pub(super) struct ElementRetirementPolicy {';assert s.count(old)==1;s=s.replace(old,'#[derive(Clone, Copy)]\n'+old,1);out[p]=s
 p='rust/tcl-vm/src/vars/retirement.rs';s=(R/p).read_text();assert s.count('    Cell(VarCell),')==1;s=s.replace('    Cell(VarCell),','    Cell(Box<VarCell>),',1);assert s.count('self.pending.push(Step::Cell(cell));')==1;s=s.replace('self.pending.push(Step::Cell(cell));','self.pending.push(Step::Cell(Box::new(cell)));',1);assert s.count('fn decompose_retiring_cell(&mut self, mut cell: VarCell)')==1;s=s.replace('fn decompose_retiring_cell(&mut self, mut cell: VarCell)','fn decompose_retiring_cell(&mut self, mut cell: Box<VarCell>)',1);s=s.replace('return Some(VariableRelease(Release::Cell(Box::new(cell))));','return Some(VariableRelease(Release::Cell(cell)));',1);old='''        self.pending
            .push(Step::Release(VariableRelease(Release::Cell(Box::new(
                cell,
            )))));''';assert s.count(old)==1;s=s.replace(old,'        self.pending\n            .push(Step::Release(VariableRelease(Release::Cell(cell))));',1);out[p]=s
 files=[];patch='';D=B/label
 for p,s in out.items():
  before=(R/p).read_bytes();bp=D/'before'/p;ap=D/'proposed'/p;bp.parent.mkdir(parents=True,exist_ok=True);ap.parent.mkdir(parents=True,exist_ok=True);bp.write_bytes(before);ap.write_text(s);subprocess.run(['/workspace/.rustup/toolchains/1.99.1-x86_64-unknown-linux-gnu/bin/rustfmt','--edition','2024','--config','skip_children=true',str(ap)],check=True);after=ap.read_bytes();patch+=''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='a/'+p,tofile='b/'+p));files.append({'path':p,'before_sha256':hashlib.sha256(before).hexdigest(),'after_sha256':hashlib.sha256(after).hexdigest()})
 (D/'proposal.patch').write_text(patch);(D/'manifest.json').write_text(json.dumps({'files':files,'patch_sha256':hashlib.sha256(patch.encode()).hexdigest(),'source_root':str(R),'actual_original_sites':['native_scalar_probe_using101','declared_variable_arguments question_mark','ElementRetirementPolicy needlesspassvalue','Step.Cell largeenum'],'scope':'Protocol selection phase retains exact error conversion/refusal/query order; OO exact match→?; private3bool carrier derivesCopy only/noEq; Step.Cell reuses the existing Release.Cell Box allocation (moves it from immediate decompose to preceding collect step) preserving LIFO/cell field/drop/release order, no new allocation count. All ownership/identity/authority/currentness guards and assertions unchanged.','limits':'Fmt/static only. Independent peer and actual Cargo/typecheck/Clippy/runtime/performance remain required.'},indent=2)+'\n');print(label,hashlib.sha256(patch.encode()).hexdigest())
