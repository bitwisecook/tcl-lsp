from pathlib import Path
import hashlib,json,difflib,subprocess
B=Path(__file__).parent
roots={'work':Path('/workspace/naming-migration-publish/tcl-lsp'),'candidate':Path('/workspace/naming-lsp-release/tcl-lsp')}
def replace(s,old,new):
 assert s.count(old)==1,(old,s.count(old));return s.replace(old,new,1)
for label,R in roots.items():
 out=B/label;out.mkdir(exist_ok=True);files=[];patch=''
 for f in ['cmd_try.rs','cmd_coro.rs','command.rs','embed.rs']:
  p='rust/tcl-vm/src/'+f;before=(R/p).read_bytes();s=before.decode()
  if f=='cmd_try.rs':s=replace(s,'plan: &Rc<TryPlan>, error: TclError)', 'plan: &Rc<TryPlan>, error: crate::TclError)')
  elif f=='cmd_coro.rs':
   s=replace(s,'    stale_message: Option<String>,','    stale_message: Option<&\'static str>,')
   s=replace(s,'fn finish_resume_exit(\n    vm: &mut Vm,\n    key: &CommandSidecarKey,','fn finish_resume_exit(\n    vm: &mut Vm,\n    _key: &CommandSidecarKey,')
  elif f=='command.rs':s=replace(s,'struct PreparedLambdaDeclaration {\n    parts: Vec<Value>,','struct PreparedLambdaDeclaration {\n    parts: crate::NativeListItems,')
  else:
   a=s.index('    pub fn retain_original_operand_failure(');b=s.index('\n    ///',a);part=s[a:b];assert 'original.' not in part and '&original' not in part,part
   s=s[:a]+part.replace('        original: &OriginalOperandProjection,','        _original: &OriginalOperandProjection,')+s[b:]
  bp=out/'before'/p;ap=out/'proposed'/p;bp.parent.mkdir(parents=True,exist_ok=True);ap.parent.mkdir(parents=True,exist_ok=True);bp.write_bytes(before);ap.write_text(s)
  subprocess.run(['/workspace/.rustup/toolchains/1.99.1-x86_64-unknown-linux-gnu/bin/rustfmt','--edition','2024','--config','skip_children=true',str(ap)],check=True)
  after=ap.read_bytes();patch+=''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='a/'+p,tofile='b/'+p));files.append({'path':p,'before_sha256':hashlib.sha256(before).hexdigest(),'after_sha256':hashlib.sha256(after).hexdigest()})
 (out/'proposal.patch').write_text(patch);(out/'manifest.json').write_text(json.dumps({'files':files,'patch_sha256':hashlib.sha256(patch.encode()).hexdigest(),'source_root':str(R),'limits':'Minimal actual CI347 typing/name repairs only; no Cargo/typing/runtime validation. NativeListItems retained without conversion/allocation; original static message lifetime retained; unused parameters remain passed/evaluated at all original callsites.'},indent=2)+'\n');print(label,hashlib.sha256(patch.encode()).hexdigest())
