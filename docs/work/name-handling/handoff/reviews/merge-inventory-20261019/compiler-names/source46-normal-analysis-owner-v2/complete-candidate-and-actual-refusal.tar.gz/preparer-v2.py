from pathlib import Path
import hashlib,json,subprocess,difflib,datetime
root=Path('/workspace/naming-migration-active/tcl-lsp');prev=Path('/tmp/compiler-names-normal-source-analysis-owner-v1');base=Path('/tmp/compiler-names-normal-source-analysis-owner-v2');base.mkdir(exist_ok=False);m=json.loads((prev/'manifest.json').read_text());news={r:(prev/'shadow'/r).read_text() for r in m['files']};r='rust/tcl-compiler/src/command_binding/source_transition_advice.rs';s=news[r];a='''#[derive(Debug, Clone, PartialEq, Eq)]
pub(super) struct OriginalSourceTransitionSeed {
    pub(super) analysis_owner:''';assert s.count(a)==1;s=s.replace(a,'''#[derive(Debug, Clone)]
pub(super) struct OriginalSourceTransitionSeed {
    // Only the Normal-source query uses this attachment. Source syntax reuse
    // keeps its existing four-field seed equality below.
    pub(super) analysis_owner:''');anchor='''#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum OriginalSourceCataloguePurpose''';assert s.count(anchor)==1;s=s.replace(anchor,'''impl PartialEq for OriginalSourceTransitionSeed {
    fn eq(&self, other: &Self) -> bool {
        self.origin == other.origin
            && self.config == other.config
            && self.baseline == other.baseline
            && self.logical_input == other.logical_input
    }
}
impl Eq for OriginalSourceTransitionSeed {}

'''+anchor);news[r]=s
r='rust/tcl-compiler/src/command_binding/source_transition_advice/source_point.rs';s=news[r];a='''        assert!(!Arc::ptr_eq(
            bindings.original_analysis_owner().unwrap(),
            other.original_analysis_owner().unwrap(),
        ));''';assert s.count(a)==1;s=s.replace(a,a+'''
        assert_eq!(seed, other.original_source_transition_seed().unwrap());''');news[r]=s
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();patch='';pins={}
for r,new in news.items():
 p=base/'shadow'/r;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(new);f=subprocess.run(['/workspace/.rustup/toolchains/1.99.1-x86_64-unknown-linux-gnu/bin/rustfmt','--edition','2024','--config','skip_children=true',str(p)],text=True,capture_output=True);assert f.returncode==0,f.stderr;old=(root/r).read_text();patch+=''.join(difflib.unified_diff(old.splitlines(True),p.read_text().splitlines(True),fromfile='a/'+r,tofile='b/'+r));pins[r]={'before':hashlib.sha256(old.encode()).hexdigest(),'final':sha(p)}
(base/'proposal.patch').write_text(patch);m.update({'utc':datetime.datetime.now(datetime.UTC).isoformat(),'status':'OFFTREE v2 exact old seed Eq preserved, Normal-only strict actual attachment; untyped/unrun','patch_sha256':sha(base/'proposal.patch'),'files':pins,'predecessor':'v1 31d44ad9 HELD: derived Eq unintentionally included new owner and changed nonNormal cache identity','successor_delta':'Explicit seed PartialEq/Eq compares exactly previous four fields in previous order, value semantics unchanged: origin/config/baseline/logical_input. Normal-only analysis owner checked separately by pointer. No report/global/runtime Eq changed. Add exact equal-source seedEq positive alongside distinct actual owner and graph foreign refusal assertions.','checks':'Pinnedfmt parse PASS3; exact current before pins; no Cargo/canonical source/Git/GO.'});(base/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps({'patch':m['patch_sha256'],'files':pins}))
