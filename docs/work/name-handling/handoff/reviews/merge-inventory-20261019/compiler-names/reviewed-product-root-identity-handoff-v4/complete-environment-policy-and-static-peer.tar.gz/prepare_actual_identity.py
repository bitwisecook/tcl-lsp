#!/usr/bin/env python3
"""Root-only post-commit adapter; no Git mutation, build, GO or launcher."""
from pathlib import Path
import argparse, importlib.util, json, types

BUILDER = Path('/tmp/name-handling-eight-package-check-v10-builder-v5/builder.py')
BUILDER_SHA = '5cfeb693bb140623b61da85ff0533f81e14df7d80967269f86893a446c082cd3'
PREPARATION_SHA = 'b387fcc3b4eb18f77cc6545ecc5bf42aced205e19744a2a538cfa7ea0a16d3b0'

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--approved-commit', required=True, help='Root actual committed integration SHA; never a candidate label')
    parser.add_argument('--output-dir', required=True, type=Path)
    parser.add_argument('--candidate-manifest', required=True, type=Path)
    parser.add_argument('--candidate-manifest-sha256', required=True)
    options = parser.parse_args()
    import hashlib
    if hashlib.sha256(BUILDER.read_bytes()).hexdigest() != BUILDER_SHA:
        raise SystemExit('STOP: pinned reviewed builder changed')
    spec = importlib.util.spec_from_file_location('reviewed_typing_builder', BUILDER)
    b = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(b)
    args = types.SimpleNamespace(candidate_manifest=options.candidate_manifest, candidate_manifest_sha256=options.candidate_manifest_sha256,
        builder_manifest_sha256=PREPARATION_SHA, identity=None)
    policy = b.verify_preparation(args)
    candidate, variant, files, expected = b.reviewed_candidate(args, policy)
    head = options.approved_commit
    b.require(b.re.fullmatch('[0-9a-f]{40}', head) is not None, 'actual SHA40 required')
    b.require(head != policy['predecessor_product_head'], 'new actual integrated commit absent')
    b.require(b.git_text(policy, 'rev-parse', '--verify', head + '^{commit}') == head, 'actual committed SHA unavailable')
    tree = b.git_text(policy, 'rev-parse', head + '^{tree}')
    b.descendant(policy, policy['predecessor_product_head'], head)
    root = Path(policy['root'])
    for path, row in expected.items():
        b.require(b.data_hash(b.blob(policy, policy['source_commit'], path)) == row['before_sha256'], 'baseline mismatch: ' + path)
        b.require(b.data_hash(b.blob(policy, head, path)) == row['after_sha256'], 'committed final mismatch: ' + path)
        b.require((root/path).is_file() and not (root/path).is_symlink() and b.digest(root/path) == row['after_sha256'], 'worktree final mismatch: ' + path)
    output = options.output_dir
    b.require(output.is_absolute() and output.parent == Path('/tmp'), 'fresh direct /tmp output required')
    output.mkdir(exist_ok=False)
    source_map = output/f'actual-source{len(expected)}-manifest.json'
    value = {'schema':'actual-integrated-reviewed-source-map-v1','source_commit':policy['source_commit'],
        'approved_product_head':head,'approved_product_tree':tree,'exact_path_count':len(expected),
        'candidate_manifest_sha256':options.candidate_manifest_sha256,'candidate_patch_sha256':variant['combined_patch_sha256'],
        'paths':[expected[p] for p in sorted(expected)]}
    with source_map.open('x') as stream:json.dump(value,stream,indent=2);stream.write('\n')
    args.identity = output/'actual-identity.json'
    identity = {'schema':'actual-integrated-product-identity-v1','approved_integrated_head':head,
        'approved_integrated_tree':tree,'source_manifest_path':str(source_map),'source_manifest_sha256':b.digest(source_map),
        'candidate_manifest_sha256':options.candidate_manifest_sha256,'candidate_patch_sha256':variant['combined_patch_sha256'],
        'path_count':len(expected),'typing':False,'runtime_tested':False}
    with args.identity.open('x') as stream:json.dump(identity,stream,indent=2);stream.write('\n')
    # Existing reviewed full verifier supplies authority; the adapter's drafts
    # are unusable for admission if this fails. Actual verification repeats in
    # builder CLI before any protocol materialization.
    first=b.verify_actual(args,policy,variant,files,expected)
    second=b.verify_actual(args,policy,variant,files,expected)
    b.descendant(policy,first['actual_head_sample'],second['actual_head_sample'])
    b.require({k:v for k,v in first.items() if k!='actual_head_sample'} ==
        {k:v for k,v in second.items() if k!='actual_head_sample'}, 'identity moved between samples')
    with (output/'actual-verification.json').open('x') as stream:json.dump(second,stream,indent=2);stream.write('\n')
    print(json.dumps({'status':'ACTUAL committed product verified; typing/runtime UNRUN; no GO or protocol generated',
        'identity':str(args.identity),'identity_sha256':b.digest(args.identity),'source_manifest':str(source_map),
        'source_manifest_sha256':b.digest(source_map),'approved_product_head':head,'approved_product_tree':tree},indent=2))

if __name__=='__main__':main()
