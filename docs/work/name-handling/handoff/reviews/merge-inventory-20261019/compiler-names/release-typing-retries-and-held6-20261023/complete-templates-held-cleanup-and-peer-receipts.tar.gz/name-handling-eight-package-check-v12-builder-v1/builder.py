#!/usr/bin/env python3
"""Bind the reviewed eight-package template only to a verified actual commit."""
from pathlib import Path, PurePosixPath
import argparse
import datetime
import difflib
import hashlib
import json
import os
import re
import subprocess

BASE = Path(__file__).resolve().parent


def stop(message):
    raise SystemExit('STOP: ' + message)


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def unique_json_object(pairs):
    value = {}
    for key, child in pairs:
        require(key not in value, 'duplicate JSON object key: ' + key)
        value[key] = child
    return value


def read_json(path):
    path = Path(path)
    if not path.is_file():
        stop('required actual input is absent: ' + str(path))
    return json.loads(path.read_text(), object_pairs_hook=unique_json_object)


def require(value, message):
    if not value:
        stop(message)


def source_path(value):
    require(isinstance(value, str), 'source path is not text')
    path = PurePosixPath(value)
    require(not path.is_absolute() and path.parts and '..' not in path.parts
            and str(path) == value and not value.startswith('docs/'),
            'unsafe or documentary product path: ' + value)
    return value


def rows_by_path(rows, count):
    require(isinstance(rows, list) and len(rows) == count, 'source path count mismatch')
    out = {}
    for row in rows:
        path = source_path(row['path'])
        require(path not in out, 'duplicate source path: ' + path)
        require(re.fullmatch('[0-9a-f]{64}', row['after_sha256']) is not None,
                'invalid final SHA: ' + path)
        require(row['before_sha256'] is None or
                re.fullmatch('[0-9a-f]{64}', row['before_sha256']) is not None,
                'invalid baseline SHA: ' + path)
        out[path] = {'path': path, 'before_sha256': row['before_sha256'],
                     'after_sha256': row['after_sha256']}
    return out


def git(policy, *args, missing=False):
    allowed = {'rev-parse', 'show', 'merge-base', 'diff', 'rev-list', 'diff-tree',
               'ls-files', 'ls-tree'}
    require(args and args[0] in allowed, 'non-read-only Git command forbidden')
    environment = {k: v for k, v in os.environ.items() if not k.startswith('GIT_')}
    result = subprocess.run(
        [policy['git_path'], '--no-pager', '--no-optional-locks',
         '--no-replace-objects', *args], cwd=policy['root'], env=environment,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    if result.returncode and not missing:
        stop('read-only Git verification failed: ' + ' '.join(args[:2]))
    return result


def git_text(policy, *args):
    return git(policy, *args).stdout.decode().strip()


def blob(policy, commit, path):
    result = git(policy, 'show', commit + ':' + path, missing=True)
    return result.stdout if result.returncode == 0 else None


def data_hash(data):
    return hashlib.sha256(data).hexdigest() if data is not None else None


def descendant(policy, before, after):
    require(git(policy, 'merge-base', '--is-ancestor', before, after,
                missing=True).returncode == 0, 'HEAD is not an approved descendant')


def documentary(path):
    return path.startswith('docs/work/name-handling/')


def source_collector_path(value):
    path = PurePosixPath(value)
    return (path.parts[0] in {'rust', 'runtime', 'tests', 'experiments', 'spec',
                             'specs', 'data', 'resources', '.cargo'}
            or path.suffix in {'.rs', '.c', '.h', '.tcl', '.tclspec'}
            or path.name in {'Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml',
                            'rustfmt.toml', 'clippy.toml'})


def verify_preparation(args):
    manifest_path = BASE / 'preparation-manifest.json'
    require(digest(manifest_path) == args.builder_manifest_sha256,
            'root-reviewed builder manifest SHA mismatch')
    manifest = read_json(manifest_path)
    for name, expected in manifest['files'].items():
        require(Path(name).name == name, 'unsafe builder input path')
        require(digest(BASE / name) == expected, 'reviewed builder input changed: ' + name)
    policy = read_json(BASE / 'policy.json')
    require(digest(policy['git_path']) == policy['git_sha256'], 'Git binary changed')
    predecessor = Path(policy['predecessor_protocol'])
    require(digest(predecessor / 'plan.json') == policy['predecessor_plan_sha256'],
            'immutable v9 plan changed')
    require(digest(predecessor / 'runner-input-manifest.json') ==
            policy['predecessor_input_manifest_sha256'], 'immutable v9 inputs changed')
    for path, expected in read_json(predecessor / 'runner-input-manifest.json')['inputs'].items():
        require(digest(path) == expected, 'immutable v9 input changed: ' + path)
    for name, expected in policy['templates'].items():
        require(digest(BASE / name) == expected, 'template changed: ' + name)
    require(digest(BASE / 'guarded-exec.py.template.txt') ==
            policy['guard_executor_sha256'], 'guarded88125 executor changed')
    return policy


def reviewed_candidate(args, policy):
    require(digest(args.candidate_manifest) == args.candidate_manifest_sha256,
            'explicit root-reviewed candidate SHA mismatch')
    candidate = read_json(args.candidate_manifest)
    require(candidate['approved_current_product_head'] == policy['predecessor_product_head']
            and candidate['approved_current_product_tree'] == policy['predecessor_product_tree']
            and candidate['source46_manifest_sha256'] == policy['predecessor_source_map_sha256'],
            'candidate predecessor identity mismatch')
    require(len(candidate['variants']) == 1, 'explicit candidate must select exactly one variant')
    variant = candidate['variants'][0]
    require(not any('alias-supported' in c['id'] for c in candidate['components']),
            'held alias fixture is outside this reviewed scope')
    require(type(variant['path_count']) is int and variant['path_count'] > 0, 'invalid reviewed candidate path count')
    files = rows_by_path(variant['files'], variant['path_count'])
    require(variant['path_count'] == len(files), 'candidate count metadata mismatch')
    require(digest(variant['combined_patch']) == variant['combined_patch_sha256'],
            'reviewed combined patch changed')
    for component in candidate['components']:
        require(digest(component['patch_path']) == component['patch_sha256'],
                'reviewed component patch changed: ' + component['id'])
    require(digest(policy['predecessor_source_map']) ==
            policy['predecessor_source_map_sha256'], 'actual predecessor map changed')
    previous = read_json(policy['predecessor_source_map'])
    expected = rows_by_path(previous['paths'], 46)
    for path, row in files.items():
        if path in expected:
            require(row['before_sha256'] == expected[path]['after_sha256'],
                    'candidate does not start at actual source46: ' + path)
            expected[path] = {**expected[path], 'after_sha256': row['after_sha256']}
        else:
            expected[path] = row.copy()
    require(len(expected) >= 46, 'reviewed cumulative map lost predecessor paths')
    return candidate, variant, files, expected


def verify_actual(args, policy, variant, files, expected):
    identity = read_json(args.identity)
    require(identity.get('schema') == 'actual-integrated-product-identity-v1',
            'candidate map is not an actual committed product identity')
    require(identity.get('typing') is False and identity.get('runtime_tested') is False,
            'identity must not assert future typing or runtime evidence')
    head = identity.get('approved_integrated_head', '')
    tree = identity.get('approved_integrated_tree', '')
    require(re.fullmatch('[0-9a-f]{40}', head) and re.fullmatch('[0-9a-f]{40}', tree),
            'actual committed HEAD/tree absent or malformed')
    require(head != policy['predecessor_product_head'], 'new integrated commit is absent')
    require(identity.get('candidate_manifest_sha256') == args.candidate_manifest_sha256
            and identity.get('candidate_patch_sha256') == variant['combined_patch_sha256']
            and identity.get('path_count') == len(expected), 'actual identity/candidate join mismatch')
    require(git_text(policy, 'rev-parse', '--verify', head + '^{commit}') == head,
            'actual commit does not exist')
    require(git_text(policy, 'rev-parse', head + '^{tree}') == tree,
            'actual committed tree mismatch')
    require(git_text(policy, 'rev-parse', policy['predecessor_product_head'] + '^{tree}') ==
            policy['predecessor_product_tree'], 'predecessor committed tree mismatch')
    actual_map_path = Path(identity['source_manifest_path'])
    require(actual_map_path.is_absolute() and digest(actual_map_path) ==
            identity['source_manifest_sha256'], 'actual integrated source manifest absent or changed')
    actual_map = read_json(actual_map_path)
    require(actual_map.get('approved_product_head') == head
            and actual_map.get('approved_product_tree') == tree
            and actual_map.get('source_commit') == policy['source_commit'],
            'integrated source manifest is not bound to actual new commit/tree/baseline')
    require(rows_by_path(actual_map['paths'], len(expected)) == expected,
            'actual integrated source differs from the reviewed candidate')
    require(Path(git_text(policy, 'rev-parse', '--show-toplevel')).resolve() ==
            Path(policy['root']).resolve(), 'Git repository root differs from reviewed worktree')
    current = git_text(policy, 'rev-parse', 'HEAD')
    descendant(policy, policy['source_commit'], head)
    descendant(policy, policy['predecessor_product_head'], head)
    descendant(policy, head, current)
    root = Path(policy['root'])
    for path, row in expected.items():
        require(data_hash(blob(policy, policy['source_commit'], path)) == row['before_sha256'],
                'actual baseline blob mismatch: ' + path)
        require(data_hash(blob(policy, head, path)) == row['after_sha256'],
                'actual committed final blob mismatch: ' + path)
        full = root / path
        require(full.is_file() and not full.is_symlink() and digest(full) == row['after_sha256'],
                'worktree final differs from committed candidate: ' + path)
    patch = ''
    for path, row in sorted(files.items()):
        before = blob(policy, policy['predecessor_product_head'], path)
        after = blob(policy, head, path)
        require(data_hash(before) == row['before_sha256'], 'candidate before scope mismatch: ' + path)
        patch += ''.join(difflib.unified_diff(
            (before or b'').decode().splitlines(True), after.decode().splitlines(True),
            fromfile='a/' + path if before is not None else '/dev/null', tofile='b/' + path))
    require(patch.encode() == Path(variant['combined_patch']).read_bytes(),
            'reviewed combined patch does not equal actual committed scope/content')
    changed = set(git_text(policy, 'diff', '--name-only', policy['predecessor_product_head'],
                           head, '--', '.').splitlines())
    require({p for p in changed if not documentary(p)} == set(files),
            'actual new product changes paths outside exact reviewed patch scope')
    exclusions = [':(exclude)docs/work/name-handling'] + [':(exclude)' + p for p in sorted(expected)]
    require(git(policy, 'diff', '--quiet', policy['source_commit'], head, '--', '.',
                *exclusions, missing=True).returncode == 0, 'other committed product differs from baseline')
    for extra in [(), ('--cached',)]:
        require(git(policy, 'diff', *extra, '--quiet', head, '--', '.',
                    ':(exclude)docs/work/name-handling', missing=True).returncode == 0,
                'uncommitted product/index differs from actual approved commit')
    for anchor, allowed in [(policy['predecessor_product_head'], set(files)), (head, set())]:
        for commit in git_text(policy, 'rev-list', anchor + '..' + current).splitlines():
            touched = git_text(policy, 'diff-tree', '--no-commit-id', '--name-only', '-r', '-m', commit).splitlines()
            require(all(p in allowed or documentary(p) for p in touched),
                    'unapproved intermediate source/docs-descendant history')
    for raw in git(policy, 'ls-files', '--others', '--exclude-standard', '-z').stdout.split(b'\0'):
        if raw:
            path = os.fsdecode(raw)
            require(documentary(path) and not source_collector_path(path),
                    'unreviewed untracked product/source-collector path: ' + path)
    tracked = {}
    for commit in [policy['predecessor_product_head'], head]:
        tracked[commit] = {os.fsdecode(p) for p in git(policy, 'ls-tree', '-r', '--name-only', '-z', commit).stdout.split(b'\0')
                           if p and source_collector_path(os.fsdecode(p))}
    added = tracked[head] - tracked[policy['predecessor_product_head']]
    removed = tracked[policy['predecessor_product_head']] - tracked[head]
    expected_added = {p for p, row in files.items() if row['before_sha256'] is None and source_collector_path(p)}
    require(added == expected_added and not removed, 'unreviewed source collector membership change')
    return {'actual_head_sample': current, 'approved_product_head': head,
            'approved_product_tree': tree, 'identity_sha256': digest(args.identity),
            'source_manifest_sha256': digest(actual_map_path), 'verified_source_paths': len(expected),
            'reviewed_candidate_manifest_sha256': args.candidate_manifest_sha256,
            'reviewed_candidate_patch_sha256': variant['combined_patch_sha256'],
            'source_collector_added_paths': sorted(added),
            'tracked_source_count_before': len(tracked[policy['predecessor_product_head']]),
            'tracked_source_count_after': len(tracked[head])}


def materialize(args, policy, candidate, variant, verification):
    output = Path(args.output)
    require(str(output) == policy['output_template'].format(path_count=verification['verified_source_paths']) and not output.exists(),
            'new immutable output must be the unused exact-count v12 directory')
    plan = read_json(BASE / 'plan.template.json')
    count = verification['verified_source_paths']
    plan.update(version=policy['version_template'].format(path_count=count),
                required_integrated_paths=count,
                approved_product_head=verification['approved_product_head'],
                approved_product_tree=verification['approved_product_tree'],
                integrated_manifest_path=str(output / f'source{count}-manifest.json'),
                integrated_manifest_sha256=verification['source_manifest_sha256'],
                actual_identity_path=str(output / 'actual-identity.json'),
                actual_identity_sha256=verification['identity_sha256'],
                candidate_manifest_path=str(output / 'reviewed-candidate-manifest.json'),
                candidate_manifest_sha256=args.candidate_manifest_sha256,
                candidate_patch_sha256=variant['combined_patch_sha256'],
                status='Actual committed reviewed product verified; typing/runtime UNRUN; root GO absent')
    payload = {}
    for name in ['suite.py', 'launch.py', 'run.sh']:
        payload[name] = (BASE / (name + '.template.txt')).read_text().replace('@OUTPUT@', str(output)).replace('@PATH_COUNT@', str(count)).replace('len(paths) != 64', f'len(paths) != {count}').encode()
    payload['guarded-exec.py'] = (BASE / 'guarded-exec.py.template.txt').read_bytes()
    payload['plan.json'] = (json.dumps(plan, sort_keys=True, indent=2) + '\n').encode()
    payload['actual-identity.json'] = Path(args.identity).read_bytes()
    identity = read_json(args.identity)
    payload[f'source{count}-manifest.json'] = Path(identity['source_manifest_path']).read_bytes()
    payload['reviewed-candidate-manifest.json'] = Path(args.candidate_manifest).read_bytes()
    payload['reviewed-candidate.patch.txt'] = Path(variant['combined_patch']).read_bytes()
    payload['predecessor-source46-manifest.json'] = Path(policy['predecessor_source_map']).read_bytes()
    payload['builder-policy.json'] = (BASE / 'policy.json').read_bytes()
    payload['builder-validation.json'] = (json.dumps(verification, sort_keys=True, indent=2) + '\n').encode()
    payload['README.md'] = b'One actual committed reviewed-source eight-package all-target compile check. Root GO is required. No tests/runtime are run. All v9 environment, process, source/provider, zero-warning and documentation-descendant guards remain. Source collector membership may add the reviewed Jim test; full before/after source seals remain exact.\n'
    require(hashlib.sha256(payload['actual-identity.json']).hexdigest() == verification['identity_sha256'],
            'actual identity changed before materialization')
    require(hashlib.sha256(payload[f'source{count}-manifest.json']).hexdigest() == verification['source_manifest_sha256'],
            'actual integrated source map changed before materialization')
    require(hashlib.sha256(payload['reviewed-candidate-manifest.json']).hexdigest() == args.candidate_manifest_sha256,
            'reviewed candidate changed before materialization')
    require(hashlib.sha256(payload['reviewed-candidate.patch.txt']).hexdigest() == variant['combined_patch_sha256'],
            'reviewed patch changed before materialization')
    require(verify_preparation(args) == policy, 'builder/predecessor inputs changed before materialization')
    for component in candidate['components']:
        require(digest(component['patch_path']) == component['patch_sha256'],
                'reviewed component changed before materialization')
    output.mkdir(exist_ok=False)
    for name, data in payload.items():
        with (output / name).open('xb') as stream:
            stream.write(data)
    inputs = {str(output / name): hashlib.sha256(data).hexdigest() for name, data in payload.items()}
    inputs.update(policy['external_inputs'])
    for component in candidate['components']:
        inputs[component['patch_path']] = component['patch_sha256']
    manifest = {'version': plan['version'], 'inputs': inputs}
    manifest_bytes = (json.dumps(manifest, sort_keys=True, indent=2) + '\n').encode()
    with (output / 'runner-input-manifest.json').open('xb') as stream:
        stream.write(manifest_bytes)
    schema = read_json(Path(policy['predecessor_protocol']) / 'root-go-schema.json')
    schema['required_fields'] = {'approved_integrated_head': verification['approved_product_head'],
        'approved_integrated_tree': verification['approved_product_tree'],
        'source_commit': policy['source_commit'], 'plan_sha256': inputs[str(output / 'plan.json')],
        f'source{count}_manifest_sha256': verification['source_manifest_sha256'],
        'runner_input_manifest_sha256': hashlib.sha256(manifest_bytes).hexdigest()}
    contract = schema['runtime_prerequisite_contract']
    contract.update(approved_product_head=verification['approved_product_head'],
                    approved_product_tree=verification['approved_product_tree'],
                    plan_sha256=inputs[str(output / 'plan.json')])
    with (output / 'root-go-schema.json').open('x') as stream:
        stream.write(json.dumps(schema, sort_keys=True, indent=2) + '\n')
    require(not (output / 'root-go.json').exists(), 'builder must never mint a GO')
    return {'status': 'MATERIALIZED verified actual product; typing/runtime UNRUN; root GO absent',
            'output': str(output), 'plan_sha256': inputs[str(output / 'plan.json')],
            'runner_input_manifest_sha256': hashlib.sha256(manifest_bytes).hexdigest(),
            'launcher_sha256': inputs[str(output / 'launch.py')]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--identity', required=True, type=Path)
    parser.add_argument('--candidate-manifest', required=True, type=Path)
    parser.add_argument('--candidate-manifest-sha256', required=True)
    parser.add_argument('--builder-manifest-sha256', required=True)
    parser.add_argument('--output', help='Optional exact-count v12 path; must match verified reviewed scope')
    parser.add_argument('--materialize', action='store_true', help='Write immutable protocol only after actual verification; never GO or launch')
    args = parser.parse_args()
    policy = verify_preparation(args)
    candidate, variant, files, expected = reviewed_candidate(args, policy)
    expected_output = policy['output_template'].format(path_count=len(expected))
    require(args.output in (None, expected_output) and not Path(expected_output).exists(),
            'immutable future protocol already exists or output differs')
    args.output = expected_output
    before = verify_actual(args, policy, variant, files, expected)
    # Recheck after complete read-only proof and before any protocol materialization.
    after = verify_actual(args, policy, variant, files, expected)
    descendant(policy, before['actual_head_sample'], after['actual_head_sample'])
    require({k: v for k, v in before.items() if k != 'actual_head_sample'} ==
            {k: v for k, v in after.items() if k != 'actual_head_sample'},
            'actual product/input/source-collector proof changed during verification')
    result = {'status': 'VERIFIED actual committed product; validate-only, no files/GO/lock/Cargo',
              'verification': after}
    if args.materialize:
        result = materialize(args, policy, candidate, variant, after)
    print(json.dumps(result, sort_keys=True, indent=2))


if __name__ == '__main__':
    main()
