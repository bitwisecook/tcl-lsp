from pathlib import Path
import hashlib,json,subprocess,difflib,datetime
root=Path('/workspace/naming-migration-active/tcl-lsp');old=Path('/tmp/compiler-names-body-nested-compiler-census-v2');b=Path('/tmp/compiler-names-body-nested-compiler-census-v3');b.mkdir(exist_ok=False);m=json.loads((old/'manifest.json').read_text());sha=lambda d:hashlib.sha256(d).hexdigest();patch=''
for rel,pins in m['files'].items():
 before=(root/rel).read_bytes();assert sha(before)==pins['before'];s=(old/'shadow'/rel).read_text()
 if rel.endswith('original_body_syntax.rs'):
  a='''            let native = binding
                .original_compiler_argument_syntax(tokens, &self.input, registry)''';z='''            #[cfg(debug_assertions)]
            if std::env::var_os("TCL_LSP_TRACE_BODY_SYNTAX").is_some() {
                eprintln!(
                    "ORIGINAL_BODY_SYNTAX_NESTED_CARRIERS parent_offset={:?} nested_offsets={:?}",
                    tokens.words().first().map(|word| word.source().span.start()),
                    tokens.nested_bindings.iter().map(|(offset, _)| *offset).collect::<Vec<_>>(),
                );
            }
            let native = binding
                .original_compiler_argument_syntax(tokens, &self.input, registry)''';assert a in s;s=s.replace(a,z,1)
 p=b/'shadow'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s);f=subprocess.run(['/workspace/.rustup/toolchains/1.99.1-x86_64-unknown-linux-gnu/bin/rustfmt','--edition','2024','--config','skip_children=true',str(p)],capture_output=True,text=True);assert f.returncode==0,f.stderr;patch+=''.join(difflib.unified_diff(before.decode().splitlines(True),p.read_text().splitlines(True),fromfile='a/'+rel,tofile='b/'+rel));pins['final']=sha(p.read_bytes())
(b/'proposal.patch').write_text(patch);m.update(utc=datetime.datetime.now(datetime.UTC).isoformat(),status='OFFTREE pure ALL rawcompiler census+parent retained nested-offset fields+existingquery trace',patch_sha256=sha((b/'proposal.patch').read_bytes()),predecessor_patch_sha256='9374cdaefa7202f5d9291cab14eb919227d2d9e51358bf51dd75ef0a0b37f347',delta='Only adds cfgdebug+existingenv log of every existing parent tokens.nested_bindings offset, in order; no new original_recorded_command query or authority. V2 rawcensus/querytrace unchanged. V1 numeric-filter diagnostic HELD.');(b/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps(m))
