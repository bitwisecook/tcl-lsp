from pathlib import Path
import json,hashlib,difflib,subprocess,datetime
root=Path('/workspace/naming-migration-active/tcl-lsp');b=Path('/tmp/compiler-names-body-nested-compiler-census-v1');b.mkdir(exist_ok=False);rels=['rust/tcl-compiler/src/command_binding/compiler_inventory.rs','rust/tcl-compiler/src/command_binding/retained_source.rs','rust/tcl-compiler/src/registry_invocation/source_structure/original_body_syntax.rs'];olds={r:(root/r).read_text() for r in rels};news=dict(olds)
r=rels[0];s=news[r];anchor='''    /// Every actual compiler observation retains its own immutable table and
''';assert s.count(anchor)==1
helper='''    /// Read every retained compiler row in one actual body without selecting it.
    #[cfg(debug_assertions)]
    pub(super) fn trace_original_body_compiler_census(
        &self,
        body: crate::ir::ProcedureId,
        span: tcl_lexer::Span,
        input: &crate::analyser::ResolvedAnalysisInput,
        registry: &tcl_registry::CommandRegistry,
    ) {
        if std::env::var_os("TCL_LSP_TRACE_BODY_SYNTAX").is_none() {
            return;
        }
        let in_span = |site: &CommandAllocationSite| {
            span.start() <= site.offset && site.offset < span.end()
        };
        let trace_visit = |kind: &str,
                           site: &CommandAllocationSite,
                           ordinal: usize,
                           visit: &SourceCompilerInvocation| {
            let original = visit.original_words.as_ref();
            let policy = visit.policy.as_ref();
            let point = visit.table.state.baseline.metadata_context.source_analysis_input();
            eprintln!(
                "ORIGINAL_BODY_COMPILER_ROW body={body:?} kind={kind} offset={} ordinal={ordinal} head={:?} root={} selection={:?} admitted={} structured={} words={} word_count={:?} word_offset={:?} config={:?} config_matches={} source_site={} table_source={} registry={} metadata_matches={} compiler={} dialect={} protocol={} realm={}",
                site.offset,
                visit.head,
                self.root_origin.as_ref().is_some_and(|root| Arc::ptr_eq(root, &site.source)),
                visit.selection,
                visit.admitted.is_some(),
                visit.structured.is_some(),
                original.is_some(),
                original.map(|words| words.words.len()),
                original.and_then(|words| words.words.first().map(|word| word.source().span.start())),
                original.map(|words| words.config),
                original.is_some_and(|words| words.config == input.lexer_config()),
                original.is_some_and(|words| words.site == *site),
                visit.table.state.current_source_origin.as_ref() == Some(&site.source),
                visit.table.state.baseline.registry_snapshot == Some(registry.snapshot().semantic_key()),
                point == Some(input),
                policy.is_some_and(|policy| policy.compiler.is_some()),
                policy.is_some_and(|policy| policy.words.is_some()),
                policy.is_some_and(|policy| policy.source_protocol.is_some()),
                policy.is_some_and(|policy| policy.realm == visit.table.realm),
            );
        };
        eprintln!(
            "ORIGINAL_BODY_COMPILER_CENSUS body={body:?} span={span:?} direct_sites={} child_regions={} analysis_owner={}",
            self.compiler_invocations.len(),
            self.compiled_children.len(),
            self.original_analysis_owner.is_some(),
        );
        for (site, visits) in &self.compiler_invocations {
            if in_span(site) {
                for (ordinal, visit) in visits.iter().enumerate() {
                    trace_visit("direct", site, ordinal, visit);
                }
            }
        }
        for (site, children) in &self.compiled_children {
            for (ordinal, child) in children.iter().enumerate() {
                let has_body_command = child.compiler_visits.keys().any(in_span);
                if !has_body_command {
                    continue;
                }
                let parent_current = match child.parent.as_ref() {
                    super::compiled_invocation::SourceNativeCompilerAdmission::Inline(parent) => self
                        .compiler_invocations
                        .get(&parent.compilation_site)
                        .is_some_and(|parents| !parents.is_empty() && parents.iter().all(|visit| {
                            visit.admitted.as_deref() == Some(child.parent.as_ref())
                                && visit.namespace_key == child.parent_namespace_key
                                && visit.table == child.table
                        })),
                    super::compiled_invocation::SourceNativeCompilerAdmission::Named(_) => false,
                };
                eprintln!(
                    "ORIGINAL_BODY_COMPILER_CHILD body={body:?} offset={} ordinal={ordinal} base={} bytes={} origin={} provider_required={} parent_current={parent_current} sites={}",
                    site.offset,
                    child.script.base(),
                    child.script.text.len(),
                    child.script.origin == site.source,
                    self.compilation_provider_required.contains(&child.enclosing),
                    child.compiler_visits.len(),
                );
                for (command, visits) in child.compiler_visits.iter() {
                    if in_span(command) {
                        for (ordinal, visit) in visits.iter().enumerate() {
                            trace_visit("raw-child", command, ordinal, visit);
                        }
                    }
                }
            }
        }
    }

''';s=s.replace(anchor,helper+anchor);news[r]=s
r=rels[1];s=news[r];anchor='''    /// Independent source-syntax observations from the original compiler.
''';assert s.count(anchor)==1;s=s.replace(anchor,'''    #[cfg(debug_assertions)]
    pub(crate) fn trace_original_body_compiler_census(
        &self,
        body: crate::ir::ProcedureId,
        span: tcl_lexer::Span,
        input: &crate::analyser::ResolvedAnalysisInput,
        registry: &CommandRegistry,
    ) {
        self.positioned.trace_original_body_compiler_census(body, span, input, registry);
    }

'''+anchor);news[r]=s
r=rels[2];s=news[r];anchor='''impl OriginalBodySyntaxInventory {
''';assert s.count(anchor)==1;s=s.replace(anchor,'''fn trace_body_syntax_option<T>(
    stage: &str,
    offset: Option<u32>,
    alternative: Option<usize>,
    value: Option<T>,
) -> Option<T> {
    #[cfg(debug_assertions)]
    if std::env::var_os("TCL_LSP_TRACE_BODY_SYNTAX").is_some() {
        eprintln!("ORIGINAL_BODY_SYNTAX_QUERY stage={stage} offset={offset:?} alternative={alternative:?} present={}", value.is_some());
    }
    #[cfg(not(debug_assertions))]
    let _ = (stage, offset, alternative);
    value
}

fn trace_body_syntax_flag(
    stage: &str,
    offset: Option<u32>,
    alternative: Option<usize>,
    value: bool,
) -> bool {
    #[cfg(debug_assertions)]
    if std::env::var_os("TCL_LSP_TRACE_BODY_SYNTAX").is_some() {
        eprintln!("ORIGINAL_BODY_SYNTAX_QUERY stage={stage} offset={offset:?} alternative={alternative:?} value={value}");
    }
    #[cfg(not(debug_assertions))]
    let _ = (stage, offset, alternative);
    value
}

'''+anchor)
a='''            let mut scripts = vec![&procedure.body];''';assert s.count(a)==1;s=s.replace(a,'''            #[cfg(debug_assertions)]
            retained.trace_original_body_compiler_census(*id, procedure.span, input, registry);
'''+a)
a='''        self.matches_analysis(source, analysis).then_some(())?;
        let parsed =''';assert s.count(a)==1;s=s.replace(a,'''        let offset = segment.argv.first().map(|word| word.span.start());
        trace_body_syntax_flag("tokens.current_analysis", offset, None, self.matches_analysis(source, analysis)).then_some(())?;
        let parsed =''')
a='''        let first = matching.next()?;
        matching.all(|other| other == first).then_some(first)''';assert s.count(a)==1;s=s.replace(a,'''        let first = trace_body_syntax_option("tokens.match", offset, None, matching.next())?;
        trace_body_syntax_flag("tokens.unanimous_match", offset, None, matching.all(|other| other == first)).then_some(first)''')
start=s.index('    fn source_syntax_words(');end=s.index('\n    /// Same configured token-gap proof',start);oldfn=s[start:end]
newfn='''    fn source_syntax_words(
        &self,
        source: &str,
        analysis: &AnalysisResult,
        segment: &crate::segmenter::SegmentedCommand,
    ) -> Option<OriginalRegistryWords> {
        let offset = segment.argv.first().map(|word| word.span.start());
        let tokens = trace_body_syntax_option("source_syntax.tokens", offset, None, self.tokens(source, analysis, segment))?;
        let context = self.input.borrowed_context_registry();
        let registry = context.commands();
        let alternatives = trace_body_syntax_option("source_syntax.alternatives", offset, None,
            self.retained.original_compiler_syntax_alternatives(tokens, &self.input, registry))?;
        let mut unanimous = None;
        for (ordinal, syntax) in alternatives.into_iter().enumerate() {
            let metadata = syntax.metadata();
            let advice = trace_body_syntax_option("source_syntax.advice", offset, Some(ordinal), syntax.source_lookup_advice(tokens))?;
            if !trace_body_syntax_flag("source_syntax.closed", offset, Some(ordinal), advice.closed_authored_simulation_source_lookup(tokens, metadata, registry)) {
                return None;
            }
            let selected = trace_body_syntax_option("source_syntax.layout", offset, Some(ordinal), super::super::resolve_original_declared_layout(
                registry, metadata, tokens, &advice,
            ))?;
            let candidate = trace_body_syntax_option("source_syntax.words", offset, Some(ordinal), compiler_source_words(
                &self.image,
                &self.input,
                tokens,
                segment,
                &syntax,
                &selected,
            ))?;
            if let Some(prior) = &unanimous {
                if trace_body_syntax_flag("source_syntax.disagreement", offset, Some(ordinal), prior != &candidate || !same_source_descriptor(prior, &candidate, context)) {
                    return None;
                }
            } else {
                unanimous = Some(candidate);
            }
        }
        trace_body_syntax_option("source_syntax.unanimous", offset, None, unanimous)
    }
''';s=s[:start]+newfn+s[end:];news[r]=s
patch='';pins={};sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for r,new in news.items():
 p=b/'shadow'/r;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(new);f=subprocess.run(['/workspace/.rustup/toolchains/1.99.1-x86_64-unknown-linux-gnu/bin/rustfmt','--edition','2024','--config','skip_children=true',str(p)],text=True,capture_output=True);assert f.returncode==0,f.stderr;patch+=''.join(difflib.unified_diff(olds[r].splitlines(True),p.read_text().splitlines(True),fromfile='a/'+r,tofile='b/'+r));pins[r]={'before':hashlib.sha256(olds[r].encode()).hexdigest(),'final':sha(p)}
(b/'proposal.patch').write_text(patch);m={'utc':datetime.datetime.now(datetime.UTC).isoformat(),'status':'OFFTREE pure rawcompiler census+existingquery trace only; missing nested issuer facts unmeasured','patch_sha256':sha(b/'proposal.patch'),'files':pins,'gate':'cfgdebug_assertions+existing TCL_LSP_TRACE_BODY_SYNTAX=1, integration compiler library included','actual_basis':'LSP23 actualfactorial output compacts if28, leaves expr62/80 gaps. Existing body inventory trace emits only if28/return54; root-level nested expr path compacts in separatedefault fixture. Consumer source syntax route confirmed wired.','scope':'Read every raw direct and child compiler visit in each current authenticated body span, print originalword/config/source/table/policy/realm/currentparent field facts without selecting/filtering alternatives or granting anything. Capture still retains exactly old command tokens. Identity wrappers expose existing tokens/currentness/alternatives/advice/sourceclosure/layout/words/consensus queries once and in original order; enumerate preserves allactual order.','limits':'No new token candidates, lexical parse→compiler authorization, first-only/dedup/missing reduction, Native/runtime/frame/completion/body grant, assertion/Eq/guard/policy change. No repair or cause closed until actual raw census+queryfirstrefusal observed.','checks':'Pinnedfmt2024 parse3PASS; exactcurrentbefore; no canonical source/Cargo/Git/GO/runner edits.'};(b/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps(m))
