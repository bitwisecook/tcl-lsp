from pathlib import Path
import hashlib,json,subprocess,difflib,datetime
root=Path('/workspace/naming-migration-active/tcl-lsp');old=Path('/tmp/compiler-names-body-nested-compiler-census-v1');b=Path('/tmp/compiler-names-body-nested-compiler-census-v2');b.mkdir(exist_ok=False);m=json.loads((old/'manifest.json').read_text());sha=lambda d:hashlib.sha256(d).hexdigest();patch=''
for rel,pins in m['files'].items():
 before=(root/rel).read_bytes();assert sha(before)==pins['before'];s=(old/'shadow'/rel).read_text()
 if rel.endswith('compiler_inventory.rs'):
  s=s.replace('/// Read every retained compiler row in one actual body without selecting it.','/// Read every retained compiler row without assigning a body or selecting it.')
  s=s.replace('head={:?} root={} selection=', 'head={:?} root={} numeric_in_body={} selection=')
  a='''                    .is_some_and(|root| Arc::ptr_eq(root, &site.source)),
                visit.selection,''';z='''                    .is_some_and(|root| Arc::ptr_eq(root, &site.source)),
                in_span(site),
                visit.selection,''';assert a in s;s=s.replace(a,z,1)
  a='''        for (site, visits) in &self.compiler_invocations {
            if in_span(site) {
                for (ordinal, visit) in visits.iter().enumerate() {
                    trace_visit("direct", site, ordinal, visit);
                }
            }
        }''';z='''        for (site, visits) in &self.compiler_invocations {
            for (ordinal, visit) in visits.iter().enumerate() {
                trace_visit("direct", site, ordinal, visit);
            }
        }''';assert a in s;s=s.replace(a,z,1)
  a='''                let has_body_command = child.compiler_visits.keys().any(in_span);
                if !has_body_command {
                    continue;
                }
''';assert a in s;s=s.replace(a,'',1)
  a='''offset={} ordinal={ordinal} base={} bytes={} origin={} provider_required={} parent_current={parent_current} sites={}''';z='''offset={} ordinal={ordinal} source_root={} enclosing_offset={} enclosing_root={} parent_offset={:?} parent_root={} base={} bytes={} mapping={:?} script_root={} origin_matches_site={} provider_required={} parent_current={parent_current} sites={}''';assert a in s;s=s.replace(a,z,1)
  a='''                    site.offset,
                    child.script.base(),
                    child.script.text.len(),
                    child.script.origin == site.source,''';z='''                    site.offset,
                    self.root_origin.as_ref().is_some_and(|root| Arc::ptr_eq(root, &site.source)),
                    child.enclosing.offset,
                    self.root_origin.as_ref().is_some_and(|root| Arc::ptr_eq(root, &child.enclosing.source)),
                    match child.parent.as_ref() {
                        super::compiled_invocation::SourceNativeCompilerAdmission::Inline(parent) => Some(parent.compilation_site.offset),
                        super::compiled_invocation::SourceNativeCompilerAdmission::Named(_) => None,
                    },
                    match child.parent.as_ref() {
                        super::compiled_invocation::SourceNativeCompilerAdmission::Inline(parent) => self.root_origin.as_ref().is_some_and(|root| Arc::ptr_eq(root, &parent.compilation_site.source)),
                        super::compiled_invocation::SourceNativeCompilerAdmission::Named(_) => false,
                    },
                    child.script.base(),
                    child.script.text.len(),
                    child.script.mapping,
                    self.root_origin.as_ref().is_some_and(|root| Arc::ptr_eq(root, &child.script.origin)),
                    child.script.origin == site.source,''';assert a in s;s=s.replace(a,z,1)
  a='''                for (command, visits) in child.compiler_visits.iter() {
                    if in_span(command) {
                        for (ordinal, visit) in visits.iter().enumerate() {
                            trace_visit("raw-child", command, ordinal, visit);
                        }
                    }
                }''';z='''                for (command, visits) in child.compiler_visits.iter() {
                    for (ordinal, visit) in visits.iter().enumerate() {
                        trace_visit("raw-child", command, ordinal, visit);
                    }
                }''';assert a in s;s=s.replace(a,z,1)
 p=b/'shadow'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s);f=subprocess.run(['/workspace/.rustup/toolchains/1.99.1-x86_64-unknown-linux-gnu/bin/rustfmt','--edition','2024','--config','skip_children=true',str(p)],capture_output=True,text=True);assert f.returncode==0,f.stderr;patch+=''.join(difflib.unified_diff(before.decode().splitlines(True),p.read_text().splitlines(True),fromfile='a/'+rel,tofile='b/'+rel));pins['final']=sha(p.read_bytes())
(b/'proposal.patch').write_text(patch);m.update(utc=datetime.datetime.now(datetime.UTC).isoformat(),status='OFFTREE pure ALL retained rawcompiler census+existingquery trace; v1 HELD for numeric childfilter',patch_sha256=sha((b/'proposal.patch').read_bytes()),predecessor_patch_sha256='f00c80da9b5f66e9ed993100ae5cc95e81307b71553ae4db23760b0f4de0fc3a',scope='Enumerate ALL retained raw direct sites/visits and ALL child regions/visits in positioned inventory for each authenticated body context; no numeric span filtering or inferred materialised ancestry. Log exact root-Arc membership, numeric-in-body separately, child mapping/origin/enclosing/parent/currentness. Context body ID/span does not assert row ownership. Existing query identity traces unchanged; no proof changes.');(b/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps(m))
