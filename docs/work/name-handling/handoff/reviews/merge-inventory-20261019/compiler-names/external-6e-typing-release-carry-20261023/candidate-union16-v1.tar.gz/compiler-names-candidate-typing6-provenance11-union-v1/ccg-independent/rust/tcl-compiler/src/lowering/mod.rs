// tcl-lsp — a language server and toolchain for Tcl
// Copyright (C) 2026 James Deucker (bitwisecook) <https://github.com/bitwisecook>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.
//
// SPDX-License-Identifier: AGPL-3.0-or-later

//! Lower Tcl source to structured analysis IR.
//!
//! Translates a flat token stream (via the segmenter) into the tree of
//! IR nodes defined in [`crate::ir`]. Each Tcl command is pattern-matched by
//! name and converted to a typed IR statement.

use std::collections::{HashMap, HashSet};

use tcl_lexer::TokenType;
use tcl_registry::definer::{
    DefinitionBodyGrammar, InitTiming, MemberCurrentNamespace, MemberEffect, MemberReceiver,
    MemberRow,
};
use tcl_registry::events::{IrulesCommandPlacement, IrulesExecutionContext};
use tcl_registry::hooks::LoweringHookId;
use tcl_registry::{ArgRole, CommandRegistry, InvocationArguments, InvocationWord};

use crate::alias::CommandAliasMap;
use crate::command_binding::{
    RetainedSourceBodyInventory, SourceAnalysisOptions, SourceCommandBindings, TrustedPackageLoader,
};
use crate::expr_parser::parse_expr_for_profile_with_lexer_config;
use crate::ir::{
    CommandBindingSite, CommandTokens, ForeachIterator, MethodDef, MethodKind, Module, Procedure,
    Script, Statement,
};
use crate::lowering_hooks::{
    ArgTokenKind, LoweringCommand, ResolvedLowering, extract_proved_expr_arg,
};
use crate::segmenter::SegmentedCommand;
use tcl_dialect::model::surface_admits;
use tcl_syntax::word_rules::WordValueRules;

mod authored_source_bodies;
mod execution_regions;
pub(crate) mod hooks;
mod hosted_source_bodies;
mod installed_bodies;
mod source_body_syntax;
pub use source_body_syntax::{
    SourceBodySyntaxCache, SourceBodySyntaxRequest, SourceBodySyntaxTemplate,
};
#[cfg(test)]
mod native_body_context_tests;
#[cfg(test)]
mod native_control_carrier_tests;
#[cfg(test)]
mod original_body_word_geometry_tests;
#[cfg(test)]
mod passive_metadata_tests;
pub use execution_regions::stock_body_provider_loader;
// `pub(crate)` for one item: `structured::parse_switch_options`, which the
// dispatch chain's lowering asks where a `switch`'s options end, and whether
// `--` closed them, rather than carrying a second copy of that rule.
pub(crate) mod structured;

#[derive(Clone, Copy, PartialEq, Eq)]
enum LoweringMetadataOrigin {
    Standalone,
    Supplied,
}

/// Stand-in `Script` for a body past [`MAX_LOWER_NEST_DEPTH`]: a single
/// [`Statement::Barrier`] spanning `[base_offset, base_offset + len)`, so
/// downstream passes treat the unanalysed region as having unknown effects
/// (matching how a dynamic `eval`/`uplevel` body is already modelled)
/// rather than as empty/dead code.
fn over_depth_script(base_offset: u32, len: usize) -> Script {
    let end = base_offset.saturating_add(u32::try_from(len).unwrap_or(u32::MAX));
    Script::from_statements(vec![Statement::Barrier {
        span: tcl_lexer::Span::new(base_offset, end),
        reason: "nesting depth exceeds analysis limit".to_owned(),
        command: String::new(),
        canonical_command: None,
        args: Vec::new(),
        tokens: None,
    }])
}

fn unavailable_original_body_script(base_offset: u32, len: usize, reason: &str) -> Script {
    let end = base_offset.saturating_add(u32::try_from(len).unwrap_or(u32::MAX));
    Script::from_statements(vec![Statement::Barrier {
        span: tcl_lexer::Span::new(base_offset, end),
        reason: reason.to_owned(),
        command: String::new(),
        canonical_command: None,
        args: Vec::new(),
        tokens: None,
    }])
}

/// Map token kind to the simplified `ArgTokenKind` used by lowering hooks.
fn arg_token_kind(kind: TokenType) -> ArgTokenKind {
    match kind {
        TokenType::Str => ArgTokenKind::Str,
        TokenType::Esc => ArgTokenKind::Esc,
        TokenType::Cmd => ArgTokenKind::Cmd,
        TokenType::ExprSugar => ArgTokenKind::ExprSugar,
        TokenType::Var => ArgTokenKind::Var,
        _ => ArgTokenKind::Other,
    }
}

/// Join a parent namespace with a child name.
fn join_namespace(parent: &str, child: &str) -> String {
    tcl_syntax::naming::qualify(parent, child)
}

/// Recursive dispatch retains only the selected contract, never the registry's
/// full materialization frame while lowering another body.
struct StructuredHookSelection<'a> {
    hook: LoweringHookId,
    requirement: crate::registry_invocation::SelectedLoweringBindingIdentity<'a>,
    error_context: Option<tcl_registry::InlineBodyErrorContext>,
}

#[inline(never)]
fn resolved_top_level_priority(
    registry: &CommandRegistry,
    command: &str,
    args: &[Option<String>],
) -> Option<u16> {
    let references = args
        .iter()
        .map(|argument| argument.as_deref())
        .collect::<Option<Vec<_>>>()?;
    match registry.irules_top_level_effect(command, &references)? {
        tcl_registry::events::IrulesTopLevelDeclaration::Priority { value } => Some(value),
        _ => None,
    }
}

/// One statically-extractable definer invocation, classified from the
/// command's **registry spec** — never a spelling match: the
/// definer's member grammar plus which argv words carry the definition
/// target and the static braced body.
///
/// Covers every command whose spec hangs a
/// [`tcl_registry::definer::DefinitionBodyGrammar`] off
/// `CommandSpec::definition_body`: the `TclOO` metaclasses (`oo::class`,
/// `oo::configurable`, `oo::abstract`, `oo::singleton`), the
/// `oo::define` / `oo::objdefine` script forms, snit's `type` / `widget` /
/// `widgetadaptor`, and itcl's `itcl::class`.  A new definer added to the
/// registry is picked up here with no lowering change.
#[derive(Clone, Copy)]
struct DefinerCall {
    definition_scope: Option<crate::ir::ProcedureId>,
    descriptor: tcl_registry::CanonicalCommandDescriptorKey<'static>,
    /// The definer's member grammar (registry data).
    grammar: &'static tcl_registry::definer::DefinitionBodyGrammar,
    /// Full-argv index of the class / type / object-handle word.
    name_idx: usize,
    /// Full-argv index of the static braced definition body.
    body_idx: usize,
    /// `oo::objdefine`: the target is an *object handle*, so members and
    /// `variable` declarations are **per-object** state: after
    /// `oo::objdefine $k { variable z }`, `my variable z; info exists z`
    /// yields `0` — per-object, not per-class.
    /// They home under a synthetic `::@objdefine@::…` class name and never
    /// join the real class's cross-block `class_instance_vars` union.
    per_object: bool,
}

impl Lowerer<'_> {
    /// Whether this concrete invocation is declared to initialise an unset
    /// target under the lowerer's active dialect profile.
    ///
    /// This is registry-driven: command form and Tcl release decide the
    /// result, not a consumer-side command-name or read-modify-write rule.
    fn safe_on_uninit(&self, command: &str, args: &[String]) -> bool {
        let Some(context) = self
            .invocation_metadata_context()
            .filter(|context| context.matches_registry(self.registry))
        else {
            return false;
        };
        let arg_refs: Vec<&str> = args.iter().map(String::as_str).collect();
        let dialect = Some(context.context().authoring_query());
        self.registry
            .resolve_invocation(command, &arg_refs, dialect)
            .is_some_and(|resolved| {
                resolved
                    .semantics
                    .safe_on_uninit
                    .is_none_or(|allowed| surface_admits(allowed, dialect.as_ref()))
            })
    }

    /// Read an exact definition layout from the selected original invocation.
    /// These source units do not establish class presence or entered execution.
    fn classify_definer_call(&self, tokens: &CommandTokens) -> Option<DefinerCall> {
        // naming.compiler.original-analysis-metadata-context

        let context = self.invocation_metadata_context()?;
        if let Some(binding) = tokens.source_binding.as_ref()
            && binding.has_original_logical_source_name_role_owner()
            && !binding.has_original_source_layout_owner()
        {
            let selected = crate::registry_invocation::original_logical_source_definition_layout(
                self.registry,
                context.source_analysis_input()?,
                tokens,
            )?;
            return Some(DefinerCall {
                definition_scope: None,
                descriptor: selected.descriptor,
                grammar: selected.grammar,
                name_idx: selected.name_word,
                body_idx: selected.body_word,
                per_object: selected.per_object,
            });
        }
        let invocation = self.logical_structured_invocation(tokens)?;
        let mut bodies = invocation
            .written_roles()
            .into_iter()
            .filter_map(|(index, role)| (role == ArgRole::Body).then_some(index + 1));
        let body_idx = bodies.next()?;
        if bodies.next().is_some()
            || !word_is_static_braced(&tokens.argv_kinds, &tokens.single_token_word, body_idx)
        {
            return None;
        }
        let realm = tokens
            .source_binding
            .as_ref()
            .and_then(crate::command_binding::SourceInvocationBinding::invocation_realm)
            .unwrap_or(self.invocation_realm);
        invocation.with_metadata_schema(self.registry, context, realm, |selected| {
            let grammar = selected.authored_source_definition_body_grammar()?;
            if !grammar.family.manufactures_runtime_commands()
                || !selected
                    .authored_source_script_arguments()?
                    .contains(&(body_idx - 1))
            {
                return None;
            }
            let name_arg = selected
                .state_transitions()
                .facts()
                .iter()
                .find_map(|fact| match &fact.transition {
                    tcl_registry::StateTransition::ObjectDispatch(
                        tcl_registry::ObjectDispatchTransition::Configure { target, .. },
                    ) => target.argument_index(),
                    _ => None,
                })
                .or_else(|| {
                    selected
                        .authored_source_command_publication()
                        .map(|name| name.argument)
                })?;
            let name_idx = invocation.written_argument(name_arg)?.checked_add(1)?;
            (name_idx < tokens.argv.len()).then_some(DefinerCall {
                definition_scope: None,
                descriptor: selected.descriptor_key(),
                grammar,
                name_idx,
                body_idx,
                per_object: selected.authored_source_descriptors().command.analyser_hook
                    == Some(tcl_registry::hooks::AnalyserHookId::OoObjdefine),
            })
        })
    }

    /// Retain possible definition roots from original candidate identities.
    /// Unknown availability or lookup withdraws completeness, never supplies
    /// a nominal grammar or a class declaration from the written command name.
    fn definer_invocation_may_supply_body(&self, tokens: &CommandTokens) -> bool {
        let Some(context) = self
            .invocation_metadata_context()
            .filter(|context| context.matches_registry(self.registry))
        else {
            return true;
        };
        let Some(advice) = crate::registry_invocation::original_registry_invocation_assistance_with_metadata_context(
            self.registry, Some(context), tokens,
        ) else { return true; };
        if advice.unknown_residual || advice.candidates.is_empty() {
            return true;
        }
        let realm = tokens
            .source_binding
            .as_ref()
            .and_then(crate::command_binding::SourceInvocationBinding::invocation_realm)
            .unwrap_or(self.invocation_realm);
        advice.candidates.iter().any(|candidate| {
            let Some(spec) =
                context
                    .context()
                    .resolve_spec_in_realm(self.registry, &candidate.command, realm)
            else {
                return true;
            };
            spec.definition_body.is_some_and(|grammar| {
                grammar.family.manufactures_runtime_commands()
                    && (!candidate.roles_complete
                        || candidate
                            .roles
                            .iter()
                            .any(|&(_, role)| role == ArgRole::Body))
            })
        })
    }

    /// A selected namespace wrapper with unchanged original source operands.
    fn is_namespace_eval_shape(&self, tokens: &CommandTokens) -> bool {
        tokens.argv.len() >= 4
            && word_is_static_braced(&tokens.argv_kinds, &tokens.single_token_word, 3)
            && self
                .logical_structured_invocation(tokens)
                .is_some_and(|invocation| {
                    invocation.lowering_hook() == Some(LoweringHookId::NamespaceEval)
                        && invocation.written_roles().contains(&(2, ArgRole::Body))
                })
    }

    fn source_definition_member(
        &self,
        grammar: &tcl_registry::definer::DefinitionBodyGrammar,
        keyword: &str,
    ) -> Option<&'static tcl_registry::definer::MemberSpec> {
        let context = self
            .invocation_metadata_context()
            .filter(|context| context.matches_registry(self.registry))?;
        grammar.source_member_in(
            keyword.as_bytes(),
            Some(context.context().authoring_query()),
        )
    }

    /// Shared vocabulary and layout over original semantic source words.
    /// Dynamic control words cannot become literal optional member selectors.
    fn source_member_body_indices(
        &self,
        grammar: &tcl_registry::definer::DefinitionBodyGrammar,
        keyword: &str,
        segment: &SegmentedCommand,
        base: usize,
    ) -> Option<Vec<usize>> {
        let context = self
            .invocation_metadata_context()
            .filter(|context| context.matches_registry(self.registry))?;
        let dialect = self.invocation_dialect?;
        let tokens = self.cmd_tokens(segment);
        let source = tokens.words().get(base..)?;
        let values: Vec<_> = source
            .iter()
            .map(|word| {
                crate::registry_invocation::effective_invocation_word(
                    word,
                    self.config.escapes,
                    dialect.word_values,
                )
            })
            .collect();
        let words: Vec<_> = source
            .iter()
            .zip(&values)
            .map(|(source, value)| {
                crate::registry_invocation::invocation_word_with_source(
                    source,
                    value,
                    self.config.escapes,
                )
            })
            .collect();
        grammar.source_member_body_indices_in(
            keyword.as_bytes(),
            tcl_registry::InvocationArguments::structured(&words).with_dialect(dialect),
            Some(context.context().authoring_query()),
        )
    }

    fn member_invocation_supplies_body(
        &self,
        grammar: &tcl_registry::definer::DefinitionBodyGrammar,
        segment: &SegmentedCommand,
    ) -> bool {
        self.source_member_body_indices(grammar, &segment.texts[0], segment, 1)
            .is_none_or(|indices| !indices.is_empty())
    }

    /// A definition created only when this method runs is not part of the
    /// post-pass's source-root walk. Detect it recursively and retain explicit
    /// module evidence rather than pretending its callable bodies do not exist.
    fn method_body_may_install_definition(&self, script: &Script) -> bool {
        fn walk(lowerer: &Lowerer<'_>, script: &Script, depth: u32) -> bool {
            if MAX_LOWER_NEST_DEPTH.exceeded(depth) {
                return true;
            }
            script.statements.iter().any(|stmt| {
                let installs = matches!(stmt, Statement::Call { .. } | Statement::Barrier { .. })
                    && stmt
                        .tokens()
                        .is_none_or(|tokens| lowerer.definer_invocation_may_supply_body(tokens));
                installs
                    || crate::ir_helpers::nested_bodies(stmt)
                        .into_iter()
                        .any(|body| walk(lowerer, body, depth + 1))
            })
        }

        walk(self, script, 0)
    }
}

/// True iff word `idx` (full argv index) is a single braced-literal
/// (`Str`) token.
fn word_is_static_braced(kinds: &[TokenType], single: &[bool], idx: usize) -> bool {
    idx < kinds.len() && idx < single.len() && single[idx] && kinds[idx] == TokenType::Str
}

/// `SegmentedCommand` variant of [`word_is_static_braced`]: word
/// `idx` is a single braced-literal (`Str`) token.
fn seg_word_is_static_braced(seg: &SegmentedCommand, idx: usize) -> bool {
    seg.single_token_word.get(idx).copied().unwrap_or(false)
        && seg.argv.get(idx).is_some_and(|t| t.kind == TokenType::Str)
}

/// Word `idx` is a single substitution-free literal: a `{braced}` (`Str`) word
/// or a plain bareword (`Esc`) — exactly the body words C's `TclCompileIfCmd`
/// inlines. A word carrying `$var` / `[cmd]` substitution, or a multi-token
/// concatenation like `$x1$x2`, is not (it must be substituted then evaluated
/// as a script by the runtime `if` command).
fn seg_word_is_static_literal(seg: &SegmentedCommand, idx: usize) -> bool {
    seg.single_token_word.get(idx).copied().unwrap_or(false)
        && seg
            .argv
            .get(idx)
            .is_some_and(|t| matches!(t.kind, TokenType::Str | TokenType::Esc))
}

/// Word `idx` is C's `TCL_TOKEN_SIMPLE_WORD`: a [`seg_word_is_static_literal`]
/// word whose value is its text, so a bareword or quoted word with a
/// backslash is not (`\"a\"` is `"a"`). A condition or body that is not
/// simple is substituted and then evaluated by the runtime command.
fn seg_word_is_simple(seg: &SegmentedCommand, idx: usize) -> bool {
    seg_word_is_static_literal(seg, idx)
        && (seg.argv.get(idx).is_some_and(|t| t.kind == TokenType::Str)
            || seg.texts.get(idx).is_some_and(|text| !text.contains('\\')))
}

/// Whether word `idx` runs a `$var` / `[cmd]` substitution when it is
/// evaluated — so its value is run-time data rather than the text as written.
///
/// Weaker than the negation of [`seg_word_is_static_literal`], and
/// deliberately so: a **compound** literal word (`{body}x`, two literal tokens
/// welded together) is still spelled out in the source, so a body walk that
/// clamps it with [`crate::segmenter::body_text_in_region`] rebases honest
/// spans. `{*}$n` under an expansionless grammar looks the same
/// from the representative token alone — braced, multi-token — yet its second
/// fragment substitutes, so its value appears nowhere in the document.
///
/// Falls back to the representative token kind when the per-word fragments are
/// unavailable, matching the coarse view the other word gates here take.
fn seg_word_substitutes(seg: &SegmentedCommand, idx: usize) -> bool {
    match seg.word_fragments.get(idx) {
        Some(fragments) if !fragments.is_empty() => fragments
            .iter()
            .any(|fragment| matches!(fragment.token.kind, TokenType::Var | TokenType::Cmd)),
        _ => seg
            .argv
            .get(idx)
            .is_some_and(|tok| matches!(tok.kind, TokenType::Var | TokenType::Cmd)),
    }
}

/// Qualify a procedure name relative to a namespace.
fn qualify_proc_name(namespace: &str, proc_name: &str) -> String {
    tcl_syntax::naming::qualify(namespace, proc_name)
}

/// The namespace a `proc`'s **body** resolves names against: the namespace the
/// proc is *defined in* (the qualifier prefix of its own qualified name), not
/// the lexical namespace the `proc` command was written in.
///
/// The two agree for every proc whose name word carries no qualifier — the
/// overwhelmingly common case, including `proc outer {} { proc inner … }` at
/// top level — and diverge exactly when the name word is itself qualified, so
/// the definition site and the defining namespace are different namespaces.
///
/// Observed identically on tclsh 9.0.4 and 8.6.16 (`self class`-style
/// introspection is not involved; this is plain `info commands` after
/// running the outer proc):
///
/// ```tcl
/// namespace eval ::a {}
/// proc a::outer {} { proc helper {x} { return $x } ; return [namespace current] }
/// a::outer                        ;# -> ::a           (the body's frame namespace)
/// info commands ::helper          ;# -> {}            (NOT the lexical ::)
/// info commands ::a::helper       ;# -> ::a::helper
///
/// namespace eval ::b::c {}
/// proc b::c::o2 {} { proc h2 {y} { return $y } }
/// b::c::o2 ; info commands ::b::c::h2   ;# -> ::b::c::h2, and ::h2 is empty
///
/// # The *lexical* enclosing `namespace eval` loses to the name's own qualifier:
/// namespace eval ::e {}
/// namespace eval ::d { proc ::e::o3 {} { proc h3 {z} { return $z } } }
/// ::e::o3 ; info commands ::e::h3       ;# -> ::e::h3, ::d::h3 and ::h3 empty
///
/// # Nesting composes — each level re-homes to its own defining namespace:
/// namespace eval ::g {}
/// proc g::o7 {} { proc o7b {} { proc h7 {u} { return $u } } }
/// g::o7 ; ::g::o7b ; info commands ::g::h7   ;# -> ::g::h7, ::h7 empty
/// ```
///
/// An absolutely-written nested name (`proc ::abs {q} {…}`) is unaffected —
/// [`qualify_proc_name`] already short-circuits on the leading `::`.
///
/// `qualified` is always rooted (it comes from [`qualify_proc_name`], which
/// routes every result through `normalise_qualified_name`), so the holder is
/// never the empty "relative" marker [`tcl_syntax::naming::key_holder_and_tail`]
/// returns for a bare simple name; `lexical_fallback` covers that
/// impossible-by-construction case rather than silently producing `""`.
#[cfg(test)]
fn proc_body_namespace(qualified: &str, lexical_fallback: &str) -> String {
    let (holder, _) = tcl_syntax::naming::key_holder_and_tail(qualified);
    if holder.is_empty() {
        lexical_fallback.to_string()
    } else {
        holder.to_string()
    }
}

/// Configured list names from a brace-collapsed compatibility word.
#[cfg(test)]
fn parse_var_list_names(list_text: &str, rules: WordValueRules) -> Option<Vec<String>> {
    rules.split_word_names(list_text)
}

/// Split a Tcl *formal parameter* list word into its parameter names.
///
/// This is the `proc` / `apply`-lambda / TclOO-method parameter word, a
/// different grammar from a loop variable list: it has two list levels, the
/// outer one holding a specifier per parameter and each specifier itself a
/// `name ?default?` list. So `{x {y 2} args}` is the three parameters `x`, `y`
/// (defaulting to `2`), and `args`; and `proc p {a\ b} {}` is the *single*
/// parameter `a` defaulting to `b` (tclsh 9.0: `info args p` → `a`), not the
/// two names a whitespace split would produce.
/// [`tcl_syntax::formal_params::parse_formal_parameters_in`] owns the selected
/// engine grammar and
/// is what the VM, the WASM runtime, and `signature_scan` all decode with.
///
/// Only the names reach the IR — [`Procedure::params`] is name-only, and
/// `params_raw` keeps the source text for consumers that need the defaults.
///
/// An unavailable grammar or a parameter list refused by that engine declines.
/// Jim keeps its own lenient list and name grammar; original link spelling
/// in a name-only header supplies no caller-link or ordinary-cell activation.
fn parse_formal_param_names(
    param_text: &str,
    rules: WordValueRules,
    grammar: Option<tcl_dialect::ParameterGrammar>,
) -> Option<Vec<String>> {
    let collapsed = rules.collapse_braced_word(param_text);
    let parameters =
        tcl_syntax::formal_params::parse_formal_parameters_in(&collapsed, grammar?).ok()?;
    Some(
        parameters
            .into_iter()
            .map(|parameter| parameter.name)
            .collect(),
    )
}

/// Retain original creation/publication geometry without borrowing compiler policy.
fn original_procedure_publication(
    tokens: &CommandTokens,
) -> Option<crate::signature_scan::scope::SignatureSourceCommand> {
    use crate::signature_scan::scope::{SignatureSourceCommand, SignatureSourceNameInput};
    let binding = tokens.source_binding.as_ref()?;
    let input = binding.original_written_name_input(tokens, 1)?;
    let SignatureSourceNameInput::OriginalWord(key) = &input else {
        return None;
    };
    let scope = binding.original_operand_naming_scope(&input)?;
    SignatureSourceCommand::procedure_from_key(&scope, key)
}

/// Return `Some(true)` / `Some(false)` if *`expr_text`* is a
/// literal Tcl boolean, or `None` when the condition is not a
/// simple literal. Tolerates surrounding whitespace and is
/// case-insensitive (matches `Tcl_GetBoolean`).
pub(crate) fn static_bool(expr_text: &str) -> Option<bool> {
    let stripped = expr_text.trim();
    match stripped {
        "0" => Some(false),
        "1" => Some(true),
        // Boolean words, incl. unique-prefix spellings (`tr`, `ye`, `of`).
        _ => tcl_syntax::boolean::parse_boolean_word(stripped),
    }
}

/// An `uplevel` level argument, parsed.
///
/// The two forms address different frames and must not be conflated:
/// `#N` counts *down* from the global frame, `N` counts *up* from the
/// current one. They coincide only when the current frame is the
/// global frame, which static analysis cannot assume.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct UplevelLevel {
    /// The level number as written, without the `#`.
    shift: i32,
    /// `true` for the `#N` absolute form, `false` for the relative form.
    absolute: bool,
}

/// Parse the level argument of an `uplevel` call. Accepts the
/// canonical relative form (`uplevel 1 body`, `uplevel 3 body`) and
/// the absolute form (`#0` / `#N`), returning `None` when the argument
/// is dynamic (`$lvl`, `[expr {...}]`) or otherwise unparseable.
///
/// `#0` and `0` both yield a `shift` of `0` and are told apart by
/// `absolute` — `uplevel #0 {…}` runs the body in the global frame
/// while `uplevel 0 {…}` runs it in the current one
/// (tclsh8.6/9.0-confirmed).
fn parse_uplevel_level(text: &str) -> Option<UplevelLevel> {
    if let Some(rest) = text.strip_prefix('#') {
        return rest.parse::<i32>().ok().map(|shift| UplevelLevel {
            shift,
            absolute: true,
        });
    }
    text.parse::<i32>().ok().map(|shift| UplevelLevel {
        shift,
        absolute: false,
    })
}

/// Return `(name, literal)` when *seg* is `set name {literal}`.
///
/// The LHS must be a plain bareword `Esc` token (no substitutions,
/// array index, or namespace qualifier) so we only ever track
/// proc-local scalars. The RHS must be a single brace-string `Str`
/// token.
fn assigned_local_body_literal(
    seg: &SegmentedCommand,
    stmt: &Statement,
    config: tcl_lexer::LexerConfig,
) -> Option<(String, String)> {
    let Statement::AssignConst { name, value, .. } = stmt else {
        return None;
    };
    if seg.args().len() != 2
        || seg.single_token_word.get(..3)? != [true, true, true]
        || name != &seg.args()[0]
        || value != &seg.args()[1]
    {
        return None;
    }
    let arg_tokens = seg.arg_tokens();
    let name_tok = *arg_tokens.first()?;
    let value_tok = *arg_tokens.get(1)?;
    if name_tok.kind != TokenType::Esc || value_tok.kind != TokenType::Str {
        return None;
    }
    let name = crate::value_transfer::literal_token_value(name, name_tok.kind, &config)?;
    if name.is_empty()
        || name.contains('$')
        || name.contains('[')
        || name.contains('(')
        || name.contains("::")
    {
        return None;
    }
    let value = crate::value_transfer::literal_token_value(value, value_tok.kind, &config)?;
    Some((name.into_owned(), value.into_owned()))
}

/// If *`cmd_text`* is `list lit1 lit2 ...` with all-literal
/// arguments, return the body text the list would evaluate to —
/// otherwise `None`.
///
/// Literal means `Esc` / `Str` token only: no `$var` substitution,
/// no nested command substitution. `Str` (`{...}`) tokens are
/// re-braced in the synthesised body so list-canonicalisation
/// stays correct (we trust the segmenter's `single_token_word`
/// flag plus the absence of `$` / `[` in `Esc` text).
fn eval_list_literal_body(cmd_text: &str, config: tcl_lexer::LexerConfig) -> Option<String> {
    let image = tcl_lexer::SourceImage::native(cmd_text.as_bytes());
    let inner = crate::segmenter::segment_commands_image_with_offset_and_config(
        &image,
        0,
        config.nested(),
    )?;
    if inner.len() != 1 {
        return None;
    }
    let inner_cmd = &inner[0];
    if inner_cmd.texts.is_empty() || inner_cmd.texts[0] != "list" {
        return None;
    }
    let argv = inner_cmd.arg_tokens();
    let texts = inner_cmd.args();
    let single = &inner_cmd.single_token_word;
    // Each element after ``list`` must be a single-token literal.
    for (i, tok) in argv.iter().enumerate() {
        // ``single`` is per-word over the full argv (including
        // the command word at index 0) — argv here starts at
        // index 1 of the original argv, so the matching single-
        // token-word index is ``i + 1``.
        if !single.get(i + 1).copied().unwrap_or(false) {
            return None;
        }
        if !matches!(tok.kind, TokenType::Esc | TokenType::Str) {
            return None;
        }
        if tok.kind == TokenType::Esc {
            let text = &texts[i];
            if text.contains('$') || text.contains('[') {
                return None;
            }
        }
    }
    let mut parts: Vec<String> = Vec::with_capacity(argv.len());
    for (i, tok) in argv.iter().enumerate() {
        let text = &texts[i];
        if tok.kind == TokenType::Str {
            parts.push(format!("{{{text}}}"));
        } else {
            parts.push(text.clone());
        }
    }
    Some(parts.join(" "))
}

/// Drop const-map entries that *stmt* may have overwritten.
/// Straight-line assignments pop just the named variable;
/// structured IR and barriers conservatively clear the whole map
/// because their child scopes (or runtime side effects) could
/// touch any tracked name.
/// Token-level check that a relaxed-eval /
/// relaxed-uplevel body is free of nested dynamic-shape barriers.
///
/// When the eval/uplevel hooks consider relaxing a braced-literal
/// body to inline IR, they first walk the body's command words and
/// reject any nested `eval`/`uplevel` whose own body argument is
/// substitution-bearing (`$var` / `[cmd]` / multi-token).  Without
/// this gate, a static braced `eval {uplevel 1 $x}` would relax to
/// IR that runs a compiled `uplevel` with a still-dynamic body.
///
/// The walk is deliberately shallow and token-based:
///
/// 1. Segment the body into commands.
/// 2. For each command the registry marks as evaluating code, ask the
///    registry which words its script is made of and poison unless
///    every one of them is a braced literal (`Str`) word.
/// 3. Recurse into nested braced bodies and into braced-arg shapes
///    of non-barrier commands so a nested
///    `if { … } { eval $x }` still trips the gate.
///
/// Which word is the script is **never** re-derived here:
/// [`CommandRegistry::arg_indices_for_role`] answers it, so `uplevel`'s
/// optional-level shape is resolved by the one contract-tested
/// `uplevel_arg_roles` resolver instead of a second, subtly different
/// level-word sniff.  The barrier test likewise composes subcommand
/// traits ([`CommandRegistry::invocation_traits`]), so the compound
/// eval-family members — `namespace eval`, `namespace inscope`,
/// `interp eval`, all of which carry the eval-family bits on the
/// *subcommand* — flow through the same path a bare `eval` does.
///
/// Returns `true` when the body contains a nested dynamic-shape
/// barrier (the caller should fall back to [`Statement::Barrier`]); `false`
/// when the body is safe to relax.
fn body_has_dynamic_barrier(
    body_text: &str,
    registry: &CommandRegistry,
    config: tcl_lexer::LexerConfig,
) -> bool {
    use tcl_lexer::TokenType;
    use tcl_registry::prelude::Traits;
    let image = tcl_lexer::SourceImage::native(body_text.as_bytes());
    let Some(commands) =
        crate::segmenter::segment_commands_image_with_offset_and_config(&image, 0, config.nested())
    else {
        return true;
    };
    for sc in &commands {
        if sc.argv.is_empty() || sc.texts.is_empty() {
            continue;
        }
        let raw_name = sc.texts[0].as_str();
        let selected = registry
            .get(raw_name)
            .map(tcl_registry::CommandSpec::descriptor_key);
        let name = selected.map_or(raw_name, tcl_registry::CanonicalCommandDescriptorKey::label);
        let args: Vec<&str> = sc.texts[1..].iter().map(String::as_str).collect();
        // A "dynamic barrier" command evaluates a script (`eval`,
        // `uplevel`, `namespace eval`, `interp eval`, …).  Sourced from
        // the registry's `EVALUATES_CODE` trait rather than a hardcoded
        // name list.  `None` because the question is the
        // command's *shape*, not its availability: a barrier is a barrier
        // whichever dialect the file is analysed as.  Deliberate under
        // invariant I4 — a barrier answer *widens* (falls back to
        // `Statement::Barrier`), never specialises on an unproved
        // binding.
        let traits = registry.invocation_traits(name, &args, None);
        if !traits.contains(Traits::EVALUATES_CODE) {
            // Recurse into braced args of non-barrier commands so
            // nested barriers still trip the gate.
            for (i, tok) in sc.argv.iter().enumerate() {
                if i == 0 {
                    continue;
                }
                if tok.kind != TokenType::Str {
                    continue;
                }
                let arg_text = sc.texts.get(i).map_or("", String::as_str);
                if body_has_dynamic_barrier(arg_text, registry, config) {
                    return true;
                }
            }
            continue;
        }
        // Name is a barrier — inspect the words its script is made of.
        let body_indices = registry.arg_indices_for_role(name, &args, ArgRole::Body);
        let Some(&first_body) = body_indices.first() else {
            // The registry can point at no script word: a malformed call
            // (`uplevel 1` — a wrong-#args error) or an evaluator whose
            // code argument is a command *prefix* rather than a script
            // (`coroprobe` / `coroinject`).  Poison so the outer hook
            // falls back to Statement::Barrier and the runtime decides.
            return true;
        };
        // `SCRIPT_CONCATENATES_ARGS`: the trailing words concatenate into
        // the one script Tcl evaluates, so `uplevel 1 {set x 1} $tail`
        // is dynamic even though the marked body word is a literal.  Check
        // the whole tail from the first script word, not just the marked
        // ones.
        let script_words: Vec<usize> = if traits.contains(Traits::SCRIPT_CONCATENATES_ARGS) {
            (first_body..args.len()).collect()
        } else {
            body_indices
        };
        for idx in script_words {
            // `sc.argv` / `sc.texts` include the command name at 0, so the
            // arg-relative index shifts by one.
            let (Some(tok), Some(text)) = (sc.argv.get(idx + 1), sc.texts.get(idx + 1)) else {
                return true;
            };
            if tok.kind != TokenType::Str {
                return true;
            }
            // Recurse into the literal nested script word.
            if body_has_dynamic_barrier(text, registry, config) {
                return true;
            }
        }
    }
    false
}

fn invalidate_const_map_for(
    stmt: &Statement,
    scope: &mut HashMap<String, String>,
    config: tcl_lexer::LexerConfig,
) {
    match stmt {
        Statement::AssignConst {
            name, name_braced, ..
        } => {
            if let Some(literal) =
                crate::value_transfer::recorded_word_value(name, *name_braced, &config)
            {
                let root = tcl_syntax::naming::split_element_ref(&literal)
                    .map_or(literal.as_ref(), |(root, _)| root);
                scope.remove(root);
            } else {
                scope.clear();
            }
        }
        // Calls, substitutions and read traces can write outside their reported target.
        Statement::Call { .. }
        | Statement::AssignExpr { .. }
        | Statement::AssignValue { .. }
        | Statement::Incr { .. }
        | Statement::ExprEval { .. }
        | Statement::Barrier { .. }
        | Statement::NativeCall { .. }
        | Statement::Block { .. }
        | Statement::UpFrame { .. }
        | Statement::If { .. }
        | Statement::For { .. }
        | Statement::While { .. }
        | Statement::Foreach { .. }
        | Statement::Catch { .. }
        | Statement::Try { .. }
        | Statement::Switch { .. } => scope.clear(),
        Statement::Return { .. } => {}
    }
}

/// A memoised per-procedure body-lowering callback: `(offset-0 body text,
/// namespace) → offset-0 body [`Script`]`.  See [`Lowerer::with_body_cache`].
type BodyCacheFn<'a> = dyn Fn(&str, &str) -> Script + 'a;

/// Actual isolated-body worker output and complete lowering recipe. The body is
/// private; independently supplied script values cannot create this template.
#[derive(Debug, Clone, PartialEq)]
pub struct OriginalBodyLoweringTemplate {
    text: String,
    namespace: String,
    registry: tcl_registry::RegistrySnapshot,
    config: tcl_lexer::LexerConfig,
    dialect: Option<&'static tcl_dialect::DialectProfile>,
    body: Script,
}
impl OriginalBodyLoweringTemplate {
    /// Run the existing isolated lowerer once with the exact requested inputs.
    #[must_use]
    pub fn lower(
        text: &str,
        namespace: &str,
        registry: &CommandRegistry,
        config: tcl_lexer::LexerConfig,
        dialect: Option<&'static tcl_dialect::DialectProfile>,
    ) -> Self {
        let body = lower_proc_body_isolated(text, namespace, registry, config, dialect);
        Self {
            text: text.to_owned(),
            namespace: namespace.to_owned(),
            registry: registry.snapshot(),
            config,
            dialect,
            body,
        }
    }
    /// Reporting projection, without source-build or execution admission.
    #[must_use]
    pub fn body(&self) -> &Script {
        &self.body
    }
    fn matches(
        &self,
        text: &str,
        namespace: &str,
        registry: &CommandRegistry,
        config: tcl_lexer::LexerConfig,
        dialect: Option<&'static tcl_dialect::DialectProfile>,
    ) -> bool {
        self.text == text
            && self.namespace == namespace
            && self.registry == registry.snapshot()
            && self.config == config
            && self.dialect == dialect
    }
}
/// Memo callback returning an actual immutable isolated-body worker artifact.
pub type OriginalBodyLoweringCache<'a> = dyn Fn(&str, &str) -> OriginalBodyLoweringTemplate + 'a;

/// Which lowering pass a [`Lowerer`] performs.
#[derive(Clone, Copy, PartialEq, Eq, Default)]
pub(crate) enum CompileTarget {
    /// The analysis IR: structured control flow kept everywhere, every
    /// registry-driven hook active. What LSP consumers (diagnostics,
    /// navigation) lower against.
    #[default]
    Analysis,
    /// The VM-faithful bytecode pass ([`lower_to_ir_for_bytecode`]):
    /// constructs the bytecode backend can't compile correctly (a bare
    /// `try`, a directly-nested `foreach`/`lmap`) barrier to a runtime
    /// dispatch instead of their structured IR; every other hook active.
    Bytecode,
    /// The bytecode pass with every registry-driven inline/structured
    /// lowering hook ALSO suppressed ([`lower_to_ir_traced`]): every command
    /// falls straight to [`Lowerer::lower_default`] — a plain runtime
    /// dispatch (`Statement::Call`/`Statement::Barrier` with a non-empty
    /// `command`, both of which [`crate::codegen`] emits as `push words;
    /// INVOKE`), never a typed statement (`AssignConst`/`Incr`/`Return`/…)
    /// or a structured control-flow block (`If`/`While`/`Foreach`/`Switch`/
    /// `Catch`/`Try`/…). Used to recompile a proc/script body so execution
    /// traces (`enterstep`/`leavestep`) observe every command in it; see
    /// [`tcl_runtime_api::CompileService::compile_traced`]. Never set for
    /// the primary module compile — only for a standalone "compile this body
    /// text as a script" call, so a proc's own `proc name args body`
    /// DEFINITION always module-compiles normally; only its *body* is
    /// affected when recompiled under this target.
    BytecodeTraced,
}

impl CompileTarget {
    /// Whether this pass targets the bytecode backend (barriers
    /// backend-incompatible structured forms) — [`Self::Bytecode`] or
    /// [`Self::BytecodeTraced`].
    pub(crate) fn is_bytecode(self) -> bool {
        matches!(self, Self::Bytecode | Self::BytecodeTraced)
    }

    /// Whether this pass suppresses every inline/structured hook —
    /// [`Self::BytecodeTraced`] only.
    pub(crate) fn is_trace_visible(self) -> bool {
        self == Self::BytecodeTraced
    }
}

/// Origin of the execution entry contract used to initialise source resolution.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum SourceEntryOrigin {
    Authoring,
    Driver,
}

/// Complete source metadata retained independently of an explicitly selected
/// Standalone authoring driver. It supplies no runtime or Native entry.
#[derive(Clone, Copy)]
pub(crate) struct StandaloneSourceInput<'a> {
    registry: &'a CommandRegistry,
    input: &'a crate::analyser::ResolvedAnalysisInput,
}

impl<'a> StandaloneSourceInput<'a> {
    pub(crate) fn retain(
        registry: &'a CommandRegistry,
        input: &'a crate::analyser::ResolvedAnalysisInput,
        config: tcl_lexer::LexerConfig,
        profile: Option<&tcl_dialect::DialectProfile>,
    ) -> Option<Self> {
        if config != input.lexer_config() {
            return None;
        }
        crate::registry_invocation::InvocationMetadataContext::for_source_input(
            registry, input, config, profile,
        )?;
        Some(Self { registry, input })
    }
}

use tcl_lexer::SourceSegmentationPurpose;

/// The lowering engine — accumulates procedures and IR statements.
pub struct Lowerer<'r> {
    /// Output module being built.
    pub module: Module,
    /// Compatibility hook argument; semantic aliases are owned by source bindings.
    aliases: CommandAliasMap,
    /// Point-specific command state in the current source span space.
    source_bindings: Option<RetainedSourceBodyInventory>,
    /// Written geometry only while lowering an authentic body with its
    /// independently selected namespace; never an execution or lookup owner.
    original_body_word_source: Option<crate::command_binding::OriginalBodyWrittenWordOwner>,
    /// Exact entry inventory retained for deferred method extraction.
    module_source_bindings: Option<Box<RetainedSourceBodyInventory>>,
    compilation_scope: tcl_runtime_api::SourceCompilationScope,
    /// Explicit driver-supplied standard-distribution loader contracts.
    trusted_package_loaders: Vec<TrustedPackageLoader>,
    trusted_source_modules: Vec<crate::command_binding::TrustedSourceModuleLoader>,
    /// Whether prior interpreter history prevents a fresh entry proof.
    unknown_entry: bool,
    /// An explicit entry contract replaces the default authoring assumption.
    source_entry_origin: SourceEntryOrigin,
    /// Availability phase supplied by the source entry owner.
    invocation_realm: tcl_dialect::model::InvocationRealm,
    /// Invocation policy snapshot supplied by the driver.
    invocation_dialect: Option<tcl_registry::InvocationDialect>,
    hosted_execution_context: Option<tcl_registry::f5::BigIpExecutionContext>,
    execution_name_policy: Option<tcl_syntax::naming::ExecutionNamePolicy>,
    metadata_input: Option<crate::analyser::ResolvedAnalysisInput>,
    logical_source_input: Option<crate::analyser::ResolvedAnalysisInput>,
    vendor_source_input: Option<crate::analyser::ResolvedAnalysisInput>,
    compiled_variable_provider:
        Option<tcl_registry::native_compiled_variables::LogicalCompiledVariableProvider>,
    /// Evaluation protocol, independent of the runtime variable frame.
    native_compilation: tcl_registry::native_compilation::NativeCompilationContext,
    native_entry: Option<std::sync::Arc<tcl_runtime_api::NativeCompilationEntry>>,
    source_point_entry: Option<crate::command_binding::OriginalSourcePointEntry>,
    source_channel: tcl_lexer::SourceChannel,
    incoming_formals: Vec<String>,
    /// `class qualified name -> every instance variable declared for it`,
    /// accumulated across **all** of that class's definition blocks.
    ///
    /// A class's state is not confined to the block that created it: `oo::class
    /// create C { method m … }` followed by `oo::define C { variable x }`
    /// makes `x` instance state for `m`, which was extracted before the
    /// declaration was seen.  Each block's [`Self::extract_oo_methods`] run
    /// computes only its *own* block's declarations, so the union is
    /// accumulated here and merged into every method of the class by
    /// [`Self::extract_oo_methods_pass`] once all blocks have been walked.
    /// Declaring `variable x` anywhere makes it instance state for every
    /// method of that class, so the union is order-free.
    class_instance_vars: HashMap<String, HashSet<String>>,
    /// Event handler occurrence counts (for `when` numbering).
    when_counts: HashMap<String, u32>,
    /// The registry-owned iRules execution placement of the script currently
    /// being lowered.  This is deliberately distinct from `proc_depth`:
    /// control-flow bodies inherit an event/procedure context, whereas a body
    /// opened by a top-level executable statement is invalid declaration
    /// territory and must not manufacture `when` / `proc` procedures.
    irules_execution_context: IrulesExecutionContext,
    /// Priority inherited by subsequent top-level iRules event declarations.
    irules_priority: u16,
    /// Monotonic counter for synthetic *body unit* names (`apply` lambdas and
    /// `namespace eval` bodies), so each registers under a unique qualified
    /// name in [`Module::body_units`]. Deterministic in source order, so the
    /// fresh and incremental lowerings produce identical names.
    body_unit_count: u32,
    /// Whether we're inside a `namespace eval` body.
    in_namespace_eval: bool,
    /// Command registry for arg-role queries.
    registry: &'r CommandRegistry,
    /// The document's own command declarations (`# tcl-lsp: stub` blocks and
    /// `<dialect>.tcl.stubs` sidecars), unioned with the catalogue's answer
    /// through [`Self::command_surface`]. `None` for a document that
    /// declares nothing, and for every non-document caller (tests, the
    /// bytecode path).
    declared_commands: Option<&'r tcl_registry::model::DeclaredSurface>,
    source_declared_commands: Option<tcl_registry::model::DeclaredSurface>,
    /// Per-script const-map stack. Each scope tracks
    /// proc-local variables assigned a brace-string literal so
    /// later `eval $var` / `uplevel 1 $var` calls can fold the
    /// body in at lowering time. Active only when
    /// `proc_depth > 0` — top-level / `namespace eval` scopes
    /// write globals or namespace vars whose values can be
    /// observed and mutated by other code, so const-propagating
    /// them is unsound.
    const_map_stack: Vec<HashMap<String, String>>,
    /// Per-recursive-script structured command dependencies. Each body owns
    /// its sites, so CFG construction receives the exact bindings for the
    /// script it flattens rather than a module-global approximation.
    command_binding_site_stack: Vec<Vec<CommandBindingSite>>,
    /// Exact original parent across structured body descent; no entry is inferred.
    structured_source_parent: Option<Box<CommandTokens>>,
    /// Depth of `proc` / `when` body lowerings currently in
    /// flight. A positive value enables the const-map.
    proc_depth: u32,
    /// `namespace import` directives observed at lowering time.
    /// Literal `(context_namespace, pattern)` dependency pairs preserve source
    /// order independently of the typed import resolver.
    namespace_imports: Vec<(String, String)>,
    /// `namespace export` directives observed at lowering time.
    /// Recorded as `(context_namespace, pattern)` pairs
    /// and copied into `Module::namespace_exports` at the end of
    /// lowering. Order is preserved.
    namespace_exports: Vec<(String, String)>,
    /// A retained body may be lowered into both a unit and a generic region.
    /// Record each original directive once per actual namespace.
    namespace_directive_sites: HashSet<(crate::command_binding::CommandAllocationSite, String)>,
    /// Depth of statically-dead branches currently being lowered.
    /// `if {0} {…}` / `if {1} {…} else {…}` bump this
    /// around the dead body so any `namespace import` /
    /// `namespace export` directives found inside don't register
    /// with the module-level tables. The IR for the dead code is
    /// still produced so consumers that walk the tree by syntactic
    /// offset see the original structure.
    pub(crate) dead_code_depth: u32,
    /// `true` while lowering a `TclOO` method body. A `proc`
    /// (or `namespace eval`-lifted proc) defined inside a method
    /// body is created at method-call time in the runtime receiver namespace,
    /// NOT at class-definition time — so it must not be lifted into
    /// `module.procedures` (codegen would otherwise emit it
    /// unconditionally at script load). The method body is still
    /// lowered for analysis; only the premature static registration is
    /// suppressed.
    suppress_proc_register: bool,
    /// Genuine readonly Logical body preparation cannot issue executed-source metadata.
    readonly_logical_body: bool,
    readonly_native_declaration_body: bool,
    native_source_children:
        Option<std::sync::Arc<crate::command_binding::OriginalNativeSourceBodyChildren>>,
    /// Hosted source cards keep their independent declaration owner.
    readonly_hosted_body: bool,
    readonly_authored_body: bool,
    authored_source_scope:
        Option<std::sync::Arc<crate::registry_invocation::OriginalAuthoredSourceBodyScope>>,
    /// Lexer config for the document's dialect, threaded into every
    /// body re-segmentation so `{*}` expansion (off for Tcl 8.4 /
    /// iRules) and the iRules `}{` ghost SEP are honoured rather than
    /// always assuming the Tcl-8.5+ default.  Defaults to
    /// `LexerConfig::default()`; production callers thread the active
    /// dialect via [`Lowerer::with_config`] / [`lower_to_ir_with_config`].
    config: tcl_lexer::LexerConfig,
    /// The document's analysis dialect (`None` for plain Tcl), threaded into
    /// every `expr` / condition parse so a dialect-only operator — an iRules
    /// word operator such as `contains` or `starts_with` — is parsed as that
    /// operator instead of degrading to
    /// [`crate::expr_ast::ExprNode::Raw`], which no downstream fold can
    /// evaluate.  Separate from `config`: the lexer config carries the
    /// dialect's *word* tokenisation, this carries its *expression* grammar.
    /// Set by [`Lowerer::with_dialect`] / [`lower_to_ir_with_dialect`].
    dialect: Option<&'static tcl_dialect::DialectProfile>,
    /// The dialect's resolved registry generation, derived beside
    /// [`Self::dialect`] — the context [`try_lower_hook`]'s selection
    /// primitive reads for the I4 binding proof (P1a): a head the
    /// environment does not provide selects no lowering hook and falls to
    /// the default `Statement::Call` path.
    dialect_context: Option<std::sync::Arc<tcl_registry::model::ContextRegistry>>,
    /// Explicit source context survives a driver transition; static authoring
    /// compatibility cannot fill an absent driver's input.
    metadata_origin: LoweringMetadataOrigin,
    /// Which lowering pass this instance performs — folds what would
    /// otherwise be two related bool fields (`for_bytecode`, `trace_visible`)
    /// into one three-state enum (`clippy::struct_excessive_bools`); see
    /// [`CompileTarget`].
    pub(crate) target: CompileTarget,
    /// Optional memoised per-procedure body lowering.
    /// When set, a **top-level** `proc`'s static literal body is lowered through
    /// this callback `(offset-0 body text, namespace) -> offset-0 body Script`
    /// (the caller rebases by the body offset) instead of `lower_body`, so an
    /// unchanged proc's body IR is reused across edits.  Set only for
    /// **context-free** files (no `namespace eval`/`import`/`export`, alias,
    /// `oo::`, `when`, or nested `proc`) where isolated lowering is byte-identical;
    /// `None` ⇒ the normal whole-file lowering.  See [`lower_to_ir_with_body_cache`].
    body_cache: Option<&'r BodyCacheFn<'r>>,
    source_body_syntax_cache: Option<&'r SourceBodySyntaxCache<'r>>,
    original_body_cache: Option<&'r OriginalBodyLoweringCache<'r>>,
    optimiser_lowering_integrity: Option<&'r std::cell::Cell<bool>>,
    #[cfg(test)]
    verify_source_body_syntax_cache: bool,
    /// Current `lower_script` / `lower_body` recursion depth, bounded by
    /// [`MAX_LOWER_NEST_DEPTH`] so deeply-nested bodies cannot overflow the
    /// stack. Mirrors [`crate::cfg_builder::CfgBuilder`]'s `depth` field —
    /// lowering runs *before* CFG construction, so an unguarded recursion
    /// here reaches the same crash first and makes the CFG builder's own
    /// cap moot.
    nest_depth: u32,
    /// The buffer every span this lowering emits indexes into — the document
    /// text for an ordinary lowering, and the *materialised literal* while a
    /// synthesised script is lowered at offset `0` inside one (the `eval
    /// $const` / factory-body paths that re-enter [`Self::lower_script`]).
    /// [`Self::lower_script`] swaps it for the duration of each such
    /// re-entry, because that is exactly where a new span space begins;
    /// [`Self::lower_body`] does not, since a body's spans are rebased into
    /// the space it inherits.
    ///
    /// Held so the lowerer can *check* a body word's rebase against the text
    /// it claims to slice ([`crate::segmenter::body_text_in_region`] in
    /// [`Self::lower_body_from_tok`]) rather than trusting the arithmetic —
    /// the same guard the analyser applies.  Empty until a
    /// script is lowered, which the guard reads as "nothing to compare
    /// against" and leaves every body text alone.
    source: String,
    /// The buffer each word model is read from — see [`WordSpace`].
    word_space: WordSpace,
}

/// The text a [`crate::ir::WordExpr`] is decomposed from, and the offset its
/// first byte sits at in the span space the segmentation used.
///
/// Deliberately *not* [`Lowerer::source`]: a word is read from the very text
/// that was segmented into it, which is not always a slice of the enclosing
/// buffer.  A `{body}x` word's body is clamped to the part that does map;
/// an `eval $const` / `eval [list …]` body is a literal
/// materialised at lowering time and lives in a span space of its own; and
/// the `TclOO` method extraction runs as a post-pass, after the document's
/// span space has been restored to the (empty) enclosing one.  Reading the
/// segmented text itself makes the word model right in all three, and the
/// base keeps every span it reports in the space the statements' spans are
/// in.
struct WordSpace {
    text: String,
    base: u32,
    /// `text`'s line index, held so the per-command [`tcl_lexer::SourceMap`]
    /// is a refcount bump (`LineIndex` is `Arc`-backed) rather than a rescan.
    lines: tcl_lexer::LineIndex,
    channel: tcl_lexer::SourceChannel,
}

impl WordSpace {
    fn new(text: &str, base: u32, channel: tcl_lexer::SourceChannel) -> Self {
        Self {
            text: text.to_owned(),
            base,
            lines: tcl_lexer::LineIndex::new(text),
            channel,
        }
    }

    /// A [`tcl_lexer::SourceMap`] over this text, carrying its base so a word
    /// built from it reports spans in the enclosing span space.
    fn map(&self) -> tcl_lexer::SourceMap<'_> {
        tcl_lexer::SourceMap::from_bytes_with_line_index(
            self.text.as_bytes(),
            self.channel,
            self.lines.clone(),
        )
        .with_base(self.base, 0, 0)
    }
}

/// Maximum nesting depth for the recursive `lower_script` / `lower_body`
/// descent (`lower_script` ↔ `lower_body` ↔ `lower_segmented` ↔
/// `lower_command` are mutually recursive with one Rust frame group per
/// braced-body nesting level). Matches
/// [`crate::cfg_builder::MAX_LOWER_DEPTH`] and
/// `tcl_compiler::analyser::commands::MAX_BODY_DEPTH` — all three
/// independently-recursive walkers over the same source cap at the same
/// depth, so no consumer of this crate depends on one pass reaching a
/// deeper nesting level than another. All three read that depth from
/// [`crate::depth_guard::MAX_SOURCE_NEST_DEPTH`], so it is a shared
/// *budget* rather than a shared *convention*.
///
/// This walk is the one the budget is sized by: at eight Rust frames per
/// nesting level it costs about 18.4 KiB a level, more than twice either
/// sibling, and it is the walk whose recursion the ~400-nested-`foreach`
/// reproducer aborted on.
const MAX_LOWER_NEST_DEPTH: tcl_core_types::RecursionLimit =
    crate::depth_guard::MAX_SOURCE_NEST_DEPTH;

/// Shared construction bound for consumers deriving nested source bodies.
/// A subset frontend must decline further descent when this limit is exceeded.
#[must_use]
pub const fn source_nesting_limit() -> tcl_core_types::RecursionLimit {
    MAX_LOWER_NEST_DEPTH
}

/// The substitutions [`crate::subst_nocommands`] performs: `[cmd]` off,
/// `$var` and backslashes on.
///
/// A `subst` call the registry answers with exactly this set is one that
/// evaluator reproduces, however the call spells it —
/// `subst -nocommands {…}` and Tcl 9.1's `subst -variables -backslashes {…}`
/// both land here (tclsh 9.1b0: `subst -variables -backslashes {hello
/// $name\n[format X]}` with `name` set to `world` yields "hello world",
/// a newline, then the untouched `[format X]`). The registry answers a call
/// it cannot read with every kind, which is not this set, so a computed
/// switch word folds nothing.
pub(crate) const SUBST_NOCOMMANDS_KINDS: tcl_registry::substitution::SubstitutionKinds =
    tcl_registry::substitution::SubstitutionKinds {
        backslashes: true,
        commands: false,
        variables: true,
    };

impl<'r> Lowerer<'r> {
    /// Create a new lowerer with the default (Tcl-8.5+) lexer config.
    #[must_use]
    pub fn new(registry: &'r CommandRegistry) -> Self {
        // dialect-drift-ok: the test-only constructor — every production
        // construction now goes through `Lowerer::with_config` with the
        // unit's own config; the crate's (and downstream crates') test
        // fixtures still spell the plain-Tcl default this way.
        Self::with_config(registry, tcl_lexer::LexerConfig::default())
    }

    /// Create a lowerer with an explicit dialect [`tcl_lexer::LexerConfig`]
    /// (see the `config` field).
    #[must_use]
    pub fn with_config(registry: &'r CommandRegistry, config: tcl_lexer::LexerConfig) -> Self {
        Self {
            module: Module::default(),
            aliases: CommandAliasMap::new(),
            source_bindings: None,
            original_body_word_source: None,
            module_source_bindings: None,
            compilation_scope: tcl_runtime_api::SourceCompilationScope::WholeModule,
            trusted_package_loaders: Vec::new(),
            trusted_source_modules: Vec::new(),
            unknown_entry: false,
            source_entry_origin: SourceEntryOrigin::Authoring,
            invocation_realm: tcl_dialect::model::InvocationRealm::RuleLoader,
            invocation_dialect: Some(crate::environment_ingress::authoring_invocation_dialect(
                registry, None, config,
            )),
            native_compilation: crate::environment_ingress::authoring_native_compilation(),
            compiled_variable_provider: None,
            hosted_execution_context: None,
            execution_name_policy: None,
            metadata_input: None,
            logical_source_input: None,
            vendor_source_input: None,
            native_entry: None,
            source_point_entry: None,
            source_channel: tcl_lexer::SourceChannel::Document,
            incoming_formals: Vec::new(),
            class_instance_vars: HashMap::new(),
            when_counts: HashMap::new(),
            irules_execution_context: IrulesExecutionContext::TopLevel,
            irules_priority: 500,
            body_unit_count: 0,
            in_namespace_eval: false,
            registry,
            declared_commands: None,
            source_declared_commands: None,
            const_map_stack: Vec::new(),
            command_binding_site_stack: Vec::new(),
            structured_source_parent: None,
            proc_depth: 0,
            namespace_imports: Vec::new(),
            namespace_exports: Vec::new(),
            namespace_directive_sites: HashSet::new(),
            dead_code_depth: 0,
            suppress_proc_register: false,
            readonly_logical_body: false,
            readonly_native_declaration_body: false,
            native_source_children: None,
            readonly_hosted_body: false,
            readonly_authored_body: false,
            authored_source_scope: None,
            config,
            dialect: None,
            dialect_context: None,
            metadata_origin: LoweringMetadataOrigin::Standalone,
            target: CompileTarget::Analysis,
            body_cache: None,
            original_body_cache: None,
            optimiser_lowering_integrity: None,
            source_body_syntax_cache: None,
            #[cfg(test)]
            verify_source_body_syntax_cache: false,
            nest_depth: 0,
            source: String::new(),
            word_space: WordSpace::new("", 0, tcl_lexer::SourceChannel::Document),
        }
    }

    pub(crate) fn with_original_optimiser_lowering(
        mut self,
        cache: Option<&'r OriginalBodyLoweringCache<'r>>,
        integrity: &'r std::cell::Cell<bool>,
    ) -> Self {
        self.original_body_cache = cache;
        self.optimiser_lowering_integrity = Some(integrity);
        self
    }

    /// Install the document's own command declarations (see
    /// [`declared_commands`](Self::declared_commands)).
    ///
    /// A stub declares the same kind of fact a `CommandSpec` states, so it
    /// reaches lowering through the same argument-role query the catalogue
    /// does — [`Self::command_surface`] — rather than a parallel table.
    #[must_use]
    pub fn with_declared_commands(
        mut self,
        declared: Option<&'r tcl_registry::model::DeclaredSurface>,
    ) -> Self {
        self.declared_commands = declared;
        self
    }

    /// Set the document's analysis dialect (see [`Lowerer::dialect`]).
    ///
    /// `None` means the caller named *no* dialect — deliberately distinct
    /// from `Some(plain_tcl)`, which is an explicit plain-Tcl document. The
    /// two select different numeral sources downstream (`None` defers to the
    /// thread-ambient target; `Some` pins the profile's grammar), so a caller
    /// holding an optional ingress spelling must map the unstated case to
    /// `None` rather than defaulting to the plain profile. Matches
    /// [`crate::compilation_unit::UnitBuildOptions::dialect`].
    #[must_use]
    pub fn with_dialect(mut self, dialect: Option<&'static tcl_dialect::DialectProfile>) -> Self {
        self.retain_authoring_dialect(dialect);
        if self.source_entry_origin == SourceEntryOrigin::Authoring
            && self.metadata_origin == LoweringMetadataOrigin::Standalone
        {
            self.dialect_context = dialect.map(|profile| {
                let context = crate::environment_ingress::context_for_profile(profile);
                if context.commands().snapshot().semantic_key()
                    == self.registry.snapshot().semantic_key()
                {
                    context
                } else {
                    std::sync::Arc::new(
                        context.with_command_store(self.registry.snapshot().shared_registry()),
                    )
                }
            });
        }
        self
    }

    fn retain_authoring_dialect(&mut self, dialect: Option<&'static tcl_dialect::DialectProfile>) {
        self.dialect = dialect;
        if self.source_entry_origin == SourceEntryOrigin::Authoring {
            self.invocation_dialect =
                Some(crate::environment_ingress::authoring_invocation_dialect(
                    self.registry,
                    dialect,
                    self.config,
                ));
        }
    }

    /// Explicit authoring ingress: a profile supplies grammar and metadata
    /// recipes, independently of any supplied availability or runtime entry.
    pub(crate) fn for_standalone_source(
        registry: &'r CommandRegistry,
        config: tcl_lexer::LexerConfig,
        dialect: Option<&'static tcl_dialect::DialectProfile>,
    ) -> Self {
        let mut lowerer = Self::with_config(registry, config);
        lowerer.retain_authoring_dialect(dialect);
        lowerer
    }

    /// Explicit Standalone driver with complete, independently retained metadata.
    /// Supplied-document ingress never calls this constructor or obtains its model.
    pub(crate) fn for_standalone_source_with_input(owner: StandaloneSourceInput<'r>) -> Self {
        let input = owner.input.clone();
        let mut lowerer = Self::for_standalone_source(
            owner.registry,
            input.lexer_config(),
            Some(input.unit_profile()),
        );
        lowerer.dialect_context = Some(input.context_registry());
        lowerer.retain_standalone_source_metadata(input);
        lowerer
    }

    fn retain_standalone_source_metadata(&mut self, input: crate::analyser::ResolvedAnalysisInput) {
        if input.has_logical_source_name_context() || input.has_hosted_source_name_context() {
            self.retain_resolved_analysis_input(input);
        } else {
            // The explicit driver already selected authoring independently. Metadata
            // retains its exact store/configuration without replacing that purpose.
            self.metadata_input = Some(input);
            self.metadata_origin = LoweringMetadataOrigin::Supplied;
        }
    }

    /// Use the caller's complete availability context for conditional source
    /// metadata. A foreign command generation declines instead of resolving
    /// a replacement from the profile label.
    #[must_use]
    pub fn with_context_registry(
        mut self,
        context: std::sync::Arc<tcl_registry::model::ContextRegistry>,
    ) -> Self {
        // Preserve supplied ownership even when it is foreign. Shared metadata
        // consumers then refuse it instead of rebuilding a profile fallback.
        self.dialect_context = Some(context);
        self.metadata_origin = LoweringMetadataOrigin::Supplied;
        self
    }

    /// Replace the default fresh entry of the retained input with an explicit
    /// unknown prior history.
    #[cfg(test)]
    #[must_use]
    pub(crate) fn with_explicit_unknown_entry(mut self) -> Self {
        let input = self
            .metadata_input
            .clone()
            .expect("retained analysis input");
        let entry = crate::command_binding::SourceAnalysisEntry::unknown_history_for_test(&input);
        self.set_source_analysis_options(entry.options());
        self
    }

    /// Retain the complete caller input independently of execution entry.
    /// Missing or foreign source metadata cannot acquire a profile fallback.
    #[must_use]
    pub fn with_resolved_analysis_input(
        mut self,
        input: crate::analyser::ResolvedAnalysisInput,
    ) -> Self {
        self.retain_resolved_analysis_input(input);
        self
    }

    fn retain_resolved_analysis_input(&mut self, input: crate::analyser::ResolvedAnalysisInput) {
        self.dialect = self.dialect.or(Some(input.unit_profile()));
        let source_entry = (self.source_entry_origin == SourceEntryOrigin::Authoring).then(|| {
            crate::command_binding::SourceAnalysisEntry::for_supplied_source(
                self.registry,
                &input,
                self.config,
                self.dialect,
            )
        });
        self.dialect_context = Some(input.context_registry());
        self.metadata_input = Some(input);
        self.metadata_origin = LoweringMetadataOrigin::Supplied;
        if let Some(entry) = source_entry {
            self.set_source_analysis_options(entry.options());
        }
    }

    /// Install a memoised per-procedure body-lowering callback (see
    /// [`body_cache`](Self::body_cache) and [`lower_to_ir_with_body_cache`]).
    #[must_use]
    pub fn with_body_cache(mut self, cache: &'r BodyCacheFn<'r>) -> Self {
        self.body_cache = Some(cache);
        self
    }

    /// Cache certified conditional source syntax without borrowing executed-body proofs.
    #[must_use]
    pub fn with_source_body_syntax_cache(mut self, cache: &'r SourceBodySyntaxCache<'r>) -> Self {
        self.source_body_syntax_cache = Some(cache);
        self
    }

    /// Mark this as the bytecode/VM compile path, barriering constructs the
    /// backend can't compile (see [`CompileTarget::Bytecode`]). A no-op if
    /// [`Self::trace_visible`] already upgraded this to
    /// [`CompileTarget::BytecodeTraced`] (still bytecode-backend, just also
    /// trace-visible) — order-independent whichever builder call comes first.
    #[must_use]
    pub fn for_bytecode_backend(mut self) -> Self {
        if self.target == CompileTarget::Analysis {
            self.target = CompileTarget::Bytecode;
            self.select_bytecode_entry();
        }
        self
    }

    /// Suppress every inline/structured lowering hook so the whole lowering
    /// pass produces plain runtime dispatches (see
    /// [`CompileTarget::BytecodeTraced`]). Implies the bytecode backend.
    #[must_use]
    pub fn trace_visible(mut self) -> Self {
        self.target = CompileTarget::BytecodeTraced;
        self.select_bytecode_entry();
        self
    }

    fn select_bytecode_entry(&mut self) {
        if self.source_entry_origin == SourceEntryOrigin::Authoring {
            self.native_compilation.mode =
                tcl_registry::native_compilation::NativeCompilationMode::BytecodeObject;
        }
    }

    /// Lower a complete source string to an IR module.
    pub fn lower(&mut self, source: &str) -> &Module {
        self.start_module();
        self.module.source =
            tcl_lexer::SourceImage::from_bytes(source.as_bytes(), self.source_channel);
        if self.source_point_entry.as_ref().is_some_and(|point| {
            self.target.is_bytecode()
                || self.module.source_entry.unknown_entry
                || self
                    .module
                    .source_entry
                    .metadata_context
                    .source_analysis_input()
                    != Some(point.input())
        }) && self.refuse_inherited_runtime_target(source)
        {
            return &self.module;
        }
        let namespace = self.runtime_target_namespace("");
        self.module.top_level_namespace.clone_from(&namespace);
        self.module.top_level =
            self.lower_script(source, &namespace, SourceSegmentationPurpose::WholeInput);
        self.retain_module_source_bindings();
        &self.module
    }

    /// Lower a runtime procedure body as this module's top-level script.
    ///
    /// This is the procedure-target counterpart of [`Self::lower`].  It uses
    /// the same fresh frame as a static `proc` body, while retaining all
    /// module-wide side effects (nested procedures, aliases, namespaces, OO
    /// definitions, and traces) for the bytecode backend.
    pub fn lower_procedure_target(&mut self, source: &str, namespace: &str) -> &Module {
        self.start_module();
        self.module.source =
            tcl_lexer::SourceImage::from_bytes(source.as_bytes(), self.source_channel);
        // The runtime ABI carries an unrooted constructed namespace key while
        // compiler IR records rooted constructed keys.  Convert at the shared
        // naming owner without re-parsing the key as a written Tcl word: a
        // leading `::` here may belong to a literal-colon namespace segment.
        if self.refuse_inherited_runtime_target(source) {
            return &self.module;
        }
        let namespace = self.runtime_target_namespace(namespace);
        self.module.top_level_namespace.clone_from(&namespace);
        // This module's top level *is* a procedure body, which the `::top`
        // name cannot convey to anything downstream (#2207).
        self.module.top_level_kind = crate::ir::TopLevelKind::ProcedureBody;
        self.module.source_entry.native_compilation.frame =
            tcl_registry::native_compilation::NativeCompilationFrame::ProcedureCode;
        self.module.top_level =
            self.in_procedure_frame(Some(IrulesExecutionContext::ProcedureBody), |lowerer| {
                lowerer.lower_script(source, &namespace, SourceSegmentationPurpose::NestedScript)
            });
        self.retain_module_source_bindings();
        &self.module
    }

    /// Lower a runtime script in an explicit constructed namespace.
    ///
    /// Unlike [`Self::lower_procedure_target`], this keeps script-frame
    /// variable and return semantics. Both target forms share the exact same
    /// namespace conversion and module provenance field.
    pub fn lower_script_target(&mut self, source: &str, namespace: &str) -> &Module {
        self.start_module();
        self.module.source =
            tcl_lexer::SourceImage::from_bytes(source.as_bytes(), self.source_channel);
        if self.refuse_inherited_runtime_target(source) {
            return &self.module;
        }
        let namespace = self.runtime_target_namespace(namespace);
        self.module.top_level_namespace.clone_from(&namespace);
        self.module.top_level =
            self.lower_script(source, &namespace, SourceSegmentationPurpose::WholeInput);
        self.retain_module_source_bindings();
        &self.module
    }

    fn retain_module_source_bindings(&mut self) {
        self.module.retained_source_bindings =
            self.module_source_bindings.as_deref().and_then(|bindings| {
                crate::command_binding::RetainedSourceModuleBindings::retain(
                    bindings,
                    &self.module,
                    self.registry,
                )
            });
    }

    fn refuse_inherited_runtime_target(&mut self, source: &str) -> bool {
        if self.source_point_entry.is_none() {
            return false;
        }
        self.module.top_level = unavailable_original_body_script(
            0,
            source.len(),
            "inherited source view has no runtime target",
        );
        true
    }

    fn runtime_target_namespace(&mut self, namespace: &str) -> String {
        if let Some(entry) = &self.source_point_entry {
            self.module.top_level_namespace_context = Some(entry.namespace().clone());
            return entry.namespace().display().unwrap_or_default();
        }
        let key = self.native_entry.as_ref().map_or_else(
            || {
                Some(crate::command_binding::SourceNamespaceKey::authored(
                    tcl_syntax::naming::root_unrooted_key(namespace),
                ))
            },
            |entry| crate::command_binding::SourceNamespaceKey::from_native_entry(entry).ok(),
        );
        let display = key
            .as_ref()
            .and_then(crate::command_binding::SourceNamespaceKey::display)
            .unwrap_or_else(|| tcl_syntax::naming::root_unrooted_key(namespace));
        self.module.top_level_namespace_context = key;
        display
    }

    fn source_entry_frame(&self, namespace: &str) -> crate::var_resolve::VariableExecutionFrame {
        if self.nest_depth == 1
            && let Some(entry) = &self.source_point_entry
        {
            return entry.frame().clone();
        }
        crate::command_binding::source_analysis_frame(
            self.native_entry
                .as_deref()
                .filter(|_| self.nest_depth == 1),
            namespace,
            self.module.top_level_kind,
        )
    }

    fn start_module(&mut self) {
        if self.source_entry_origin == SourceEntryOrigin::Authoring
            && self.metadata_origin == LoweringMetadataOrigin::Standalone
            && self.metadata_input.is_none()
            && self.logical_source_input.is_none()
            && self.vendor_source_input.is_none()
            && self.native_entry.is_none()
            && let Some(profile) = self.dialect.or_else(|| self.registry.profile())
            && let Some(context) = self.dialect_context.clone()
        {
            let input =
                crate::analyser::ResolvedAnalysisInput::new(profile, profile, context, self.config);
            self.retain_standalone_source_metadata(input);
        }
        self.module.top_level_namespace_context = None;
        self.module_source_bindings = None;
        self.module.lexer_config = self.config;
        self.module.dialect_profile = self.dialect.or_else(|| self.registry.profile());
        self.module.registry_snapshot = Some(self.registry.snapshot());
        self.module.source_metadata_input = self
            .metadata_input
            .clone()
            .or_else(|| self.logical_source_input.clone())
            .or_else(|| self.vendor_source_input.clone());
        self.module.dialect = self
            .module
            .dialect_profile
            .map(|profile| profile.name.to_owned());
        // Static authoring uses a fresh standard-distribution entry. Runtime
        // compilation has no authority to assert an installed package loader.
        if self.source_entry_origin == SourceEntryOrigin::Authoring && !self.target.is_bytecode() {
            let profile = self.dialect.or_else(|| self.registry.profile());
            if profile.is_some_and(|profile| {
                !profile.is_irules()
                    && profile.package_protocol() == Some(tcl_dialect::PackageProtocol::Tcl)
            }) {
                let mut providers = std::collections::BTreeMap::new();
                for name in self.registry.command_names() {
                    if let Some(tcl_registry::body_execution::BodyExecutionSpec::CapturedLifecycle(
                        contract,
                    )) = self.registry.get(name).and_then(|spec| spec.body_execution)
                        && let Some(loader) = stock_body_provider_loader(contract.provider, None)
                    {
                        providers.insert(loader.package.clone(), loader);
                    }
                }
                self.trusted_package_loaders = providers.into_values().collect();
            }
        }
        self.module.plain_command_dispatch = self.target.is_trace_visible();
        self.module.source_entry = crate::command_binding::SourceAnalysisEntry {
            source_point_entry: self.source_point_entry.clone(),
            metadata_context: self.source_metadata_input().retain(),
            hosted_execution_context: self.hosted_execution_context,
            execution_name_policy: self.execution_name_policy,
            logical_source_input: self.logical_source_input.clone(),
            vendor_source_input: self.vendor_source_input.clone(),
            compilation_scope: self.compilation_scope,
            invocation_realm: self.invocation_realm,
            declared_commands: self
                .source_declared_commands
                .as_ref()
                .or(self.declared_commands)
                .cloned(),
            trusted_package_loaders: self.trusted_package_loaders.clone(),
            trusted_source_modules: self.trusted_source_modules.clone(),
            unknown_entry: self.unknown_entry,
            invocation_dialect: self.invocation_dialect,
            compiled_variable_provider: self.compiled_variable_provider,
            native_compilation: self.native_compilation,
            native_entry: self.native_entry.clone(),
            incoming_formals: self.incoming_formals.clone(),
        };
    }

    /// Enter a fresh procedure-like runtime frame for one body lowering.
    ///
    /// A procedure frame must not inherit literal bindings from its caller;
    /// `proc_depth` also enables the body-only const-map paths.  Callers that
    /// have an explicit iRules placement supply it here, so all three pieces
    /// of procedure-frame setup are balanced together.
    fn in_procedure_frame<T>(
        &mut self,
        context: Option<IrulesExecutionContext>,
        lower: impl FnOnce(&mut Self) -> T,
    ) -> T {
        self.proc_depth += 1;
        self.const_map_stack.push(HashMap::new());
        let previous_context =
            context.map(|context| std::mem::replace(&mut self.irules_execution_context, context));
        let result = lower(self);
        if let Some(previous) = previous_context {
            self.irules_execution_context = previous;
        }
        self.const_map_stack.pop();
        self.proc_depth -= 1;
        result
    }

    /// Lower a source-text literal into a [`Script`] without
    /// installing it as the module top-level. Used by passes that
    /// need to lower a sub-script (e.g. the
    /// [`crate::inline_uplevel`] rewriter materialising a
    /// brace-literal callsite body).
    pub fn lower_into_script(&mut self, source: &str, namespace: &str) -> Script {
        self.lower_script(source, namespace, SourceSegmentationPurpose::NestedScript)
    }

    /// Lower materialised text under an invocation-time binding proof, retaining
    /// its original document offsets and actual caller activation.
    pub(crate) fn lower_into_script_with_bindings(
        &mut self,
        source: &str,
        base: u32,
        namespace: &str,
        bindings: SourceCommandBindings,
    ) -> Script {
        self.lower_into_script_with_boxed_bindings(
            source,
            base,
            namespace,
            Box::new(bindings.into()),
        )
    }

    fn lower_into_script_with_boxed_bindings(
        &mut self,
        source: &str,
        base: u32,
        namespace: &str,
        bindings: Box<RetainedSourceBodyInventory>,
    ) -> Script {
        let mut positioned_source = " ".repeat(base as usize);
        positioned_source.push_str(source);
        let enclosing_source = std::mem::replace(&mut self.source, positioned_source);
        let enclosing_bindings = self.exchange_boxed_source_bindings(Some(bindings));
        let result = self.lower_body(source, base, namespace);
        drop(self.exchange_boxed_source_bindings(enclosing_bindings));
        self.source = enclosing_source;
        result
    }

    // Whole inventories are constructed and restored outside recursive frames.
    #[inline(never)]
    fn exchange_boxed_source_bindings(
        &mut self,
        bindings: Option<Box<RetainedSourceBodyInventory>>,
    ) -> Option<Box<RetainedSourceBodyInventory>> {
        std::mem::replace(
            &mut self.source_bindings,
            bindings.map(|bindings| *bindings),
        )
        .map(Box::new)
    }

    #[inline(never)]
    fn selected_source_bindings_boxed_in_context(
        &self,
        source: &crate::command_binding::ExecutedScriptSource,
        namespace: &crate::command_binding::SourceNamespaceKey,
    ) -> Option<Box<RetainedSourceBodyInventory>> {
        self.source_bindings
            .as_ref()?
            .selected_source_in_context(source, namespace)
            .map(Box::new)
    }

    /// Lower an original body in its retained namespace incarnation. The
    /// presentation label is independent of command lookup and replay context.
    fn lower_executed_script_in_context(
        &mut self,
        source: crate::command_binding::ExecutedScriptSource,
        namespace: &crate::command_binding::SourceNamespaceKey,
    ) -> Script {
        let (Ok(text), Some(bindings)) = (
            source.try_text(),
            self.selected_source_bindings_boxed_in_context(&source, namespace),
        ) else {
            let mut script = unavailable_original_body_script(
                source.base(),
                source.text.len(),
                "original body source admission is unavailable",
            );
            script.executed_source = Some(std::sync::Arc::new(source));
            script.namespace_context = Some(Box::new(namespace.clone()));
            return script;
        };
        let implicit_math_invocations =
            bindings.math_invocations_for_script(self.registry, &source);
        let expression_preparations = bindings.expression_preparations_for_script(&source);
        let label = namespace.display().unwrap_or_default();
        let enclosing_channel = std::mem::replace(&mut self.source_channel, source.text.channel());
        // Keep the authentic pre-selection owner. A namespace projection memo
        // can filter observations but cannot issue written source geometry.
        let word_source = self.source_bindings.as_ref().and_then(|owner| {
            let input = self
                .invocation_metadata_context()?
                .source_analysis_input()?;
            match self.structured_source_parent.as_deref() {
                Some(parent) => owner.original_body_written_word_owner_at_parent(
                    &source,
                    self.config,
                    self.registry,
                    input,
                    parent,
                ),
                None => owner.original_body_written_word_owner(
                    &source,
                    self.config,
                    self.registry,
                    input,
                ),
            }
        });
        let enclosing_word_source =
            std::mem::replace(&mut self.original_body_word_source, word_source);
        let mut script =
            self.lower_into_script_with_boxed_bindings(text, source.base(), &label, bindings);
        self.original_body_word_source = enclosing_word_source;
        self.source_channel = enclosing_channel;
        script.implicit_math_invocations = implicit_math_invocations;
        script.expression_preparations = expression_preparations;
        script.executed_source = Some(std::sync::Arc::new(source));
        script.namespace_context = Some(Box::new(namespace.clone()));
        script
    }

    /// Project an original body from the same actual Module and parent vector.
    /// Only its retained child source and entry namespace select lowering.
    /// This readonly Script provides no new native compiler, frame or Normal
    /// receipt; absent child/origin/stage correspondence is terminal.
    pub(crate) fn original_body_for_module(
        module: &Module,
        registry: &'r CommandRegistry,
        parent: &CommandTokens,
        argument: usize,
    ) -> Option<Script> {
        // naming.source.original-collection-body-owner

        let metadata =
            crate::registry_invocation::InvocationMetadataContext::for_module(registry, module);
        metadata?;
        let input = module.source_metadata_input.as_ref()?;
        let retained = module.retained_source_bindings.as_deref()?;
        let bindings = retained.positioned_for_module(module, registry);
        let bindings = bindings?;
        if !retained.owns_original_tokens(parent) {
            return None;
        }
        let body_word = parent.argv.get(argument.checked_add(1)?)?;
        let source = bindings.executed_script_for_word(*body_word);
        let source = source?.clone();
        source.try_text().ok()?;
        let mut lowerer = Self::with_config(registry, module.lexer_config)
            .with_resolved_analysis_input(input.clone());
        lowerer.set_source_analysis_options(module.source_entry.options());
        lowerer.source_bindings = Some(bindings.clone().into());
        let namespace = lowerer.original_body_namespace_context(parent, argument, &source);
        let namespace = namespace?;
        // Preserve the independently selected child stage and namespace issuer
        // before delegating the same original-body semantic owner.
        let selected = lowerer
            .source_bindings
            .as_ref()?
            .selected_source_in_context(&source, &namespace);
        selected?;
        Some(lowerer.lower_original_body(source, Some(&namespace)))
    }

    /// Readonly Logical child lowering under the actual complete Module owner.
    /// Original body geometry and selected current/root source namespace stay
    /// independent of reached body-entry and Native compilation receipts.
    pub(crate) fn original_logical_body_for_module(
        module: &Module,
        registry: &'r CommandRegistry,
        parent: &CommandTokens,
        argument: usize,
    ) -> Option<Script> {
        let input = module.source_metadata_input.as_ref()?;
        if !input.has_logical_source_name_context() {
            return None;
        }
        let retained = module.retained_source_bindings.as_deref()?;
        let positioned = retained.positioned_for_module(module, registry)?;
        let body = crate::registry_invocation::original_logical_body_geometry_for_module(
            module, registry, parent, argument,
        )?;
        let namespace = crate::command_binding::original_logical_frame_body_namespace_for_module(
            module, registry, parent, &body,
        )?;
        let source = module.source.try_text().ok()?;
        let text = source.get(body.content_span().as_range())?;
        let mut lowerer = Self::with_config(registry, module.lexer_config)
            .with_resolved_analysis_input(input.clone());
        lowerer.set_source_analysis_options(module.source_entry.options());
        source.clone_into(&mut lowerer.source);
        lowerer.source_channel = module.source.channel();
        lowerer.source_bindings = Some(positioned.clone().into());
        lowerer.structured_source_parent = Some(Box::new(parent.clone()));
        lowerer.suppress_proc_register = true;
        lowerer.readonly_logical_body = true;
        let mut script = lowerer.lower_body(
            text,
            body.content_span().start(),
            &namespace.advisory_key()?,
        );
        script.namespace_context = Some(Box::new(namespace));
        Some(script)
    }

    /// Retain an original body without inventing a namespace when its entry
    /// context is unknown. Known contexts survive unsupported text/admission.
    fn lower_original_body(
        &mut self,
        source: crate::command_binding::ExecutedScriptSource,
        namespace: Option<&crate::command_binding::SourceNamespaceKey>,
    ) -> Script {
        if let Some(namespace) = namespace {
            return self.lower_executed_script_in_context(source, namespace);
        }
        let mut script = unavailable_original_body_script(
            source.base(),
            source.text.len(),
            "original body namespace context is unavailable",
        );
        script.executed_source = Some(std::sync::Arc::new(source));
        script
    }

    fn original_body_namespace_context(
        &self,
        tokens: &CommandTokens,
        argument: usize,
        source: &crate::command_binding::ExecutedScriptSource,
    ) -> Option<crate::command_binding::SourceNamespaceKey> {
        let bindings = self.source_bindings.as_ref()?;
        bindings.executed_script_entry_namespace_key_at(
            tokens.source_binding.as_ref()?.invocation_site()?,
            argument,
            source,
        )
    }

    /// Original retained contexts alone select a body inventory when its
    /// caller has no separate invocation/argument context receipt.
    fn lower_retained_script(
        &mut self,
        source: crate::command_binding::ExecutedScriptSource,
    ) -> Script {
        let namespace = self.source_bindings.as_ref().and_then(|bindings| {
            bindings
                .executed_script_namespace_context(&source)
                .or_else(|| bindings.compiled_script_namespace_context(&source))
                .or_else(|| bindings.declared_script_namespace_context(&source))
                .or_else(|| {
                    let parent = self.structured_source_parent.as_deref()?;
                    parent
                        .source_binding
                        .as_ref()?
                        .original_body_namespace_context(
                            self.registry,
                            self.invocation_metadata_context()?,
                            parent,
                            &source,
                        )
                })
        });
        self.lower_original_body(source, namespace.as_ref())
    }

    /// Retain an unchanged body slice independently of compiler admission.
    fn retain_script_source(&self, mut script: Script, text: &str, base: u32) -> Script {
        if self.readonly_logical_body
            || self.readonly_hosted_body
            || self.readonly_authored_body
            || self.readonly_native_declaration_body
        {
            return script;
        }
        script.executed_source = self
            .source_bindings
            .as_ref()
            .and_then(|bindings| bindings.source_origin())
            .cloned()
            .and_then(|origin| {
                crate::command_binding::ExecutedScriptSource::contiguous(origin, text, base)
            })
            .map(std::sync::Arc::new);
        if let Some(source) = &script.executed_source {
            script.implicit_math_invocations = self
                .source_bindings
                .as_ref()
                .map_or_else(Vec::new, |bindings| {
                    bindings.math_invocations_for_script(self.registry, source)
                });
            script.expression_preparations = self
                .source_bindings
                .as_ref()
                .map_or_else(Vec::new, |bindings| {
                    bindings.expression_preparations_for_script(source)
                });
        }
        script
    }

    /// Supply the execution entry contract before lowering. A previously used
    /// interpreter must pass `unknown_entry`; package advertisements alone do
    /// not establish loader implementation identity.
    pub fn set_source_analysis_options(&mut self, options: SourceAnalysisOptions<'_>) {
        let options = if options.source_point_entry.is_some_and(|point| {
            point
                .child_state(
                    self.registry,
                    options,
                    Some(options.native_lexer_config(self.config)),
                )
                .is_none()
        }) {
            SourceAnalysisOptions {
                source_point_entry: options.source_point_entry,
                metadata_context:
                    crate::registry_invocation::InvocationMetadataInput::SuppliedSource(None),
                unknown_entry: true,
                ..SourceAnalysisOptions::default()
            }
        } else {
            options
        };
        self.source_point_entry = options.source_point_entry.cloned();
        self.compilation_scope = options.compilation_scope;
        self.invocation_realm = options.invocation_realm;
        self.incoming_formals = options.incoming_formals.to_vec();
        self.source_declared_commands = options.declared_commands.cloned();
        self.trusted_package_loaders = options.trusted_package_loaders.to_vec();
        self.trusted_source_modules = options.trusted_source_modules.to_vec();
        self.unknown_entry = options.unknown_entry;
        self.source_entry_origin = SourceEntryOrigin::Driver;
        self.config = options.native_lexer_config(self.config);
        self.invocation_dialect = options.source_invocation_dialect(self.config);
        self.native_compilation = options.native_compilation;
        self.compiled_variable_provider = options.compiled_variable_provider;
        self.hosted_execution_context = options.hosted_execution_context;
        self.execution_name_policy = options.execution_name_policy();
        self.logical_source_input = options.logical_source_input.cloned();
        self.vendor_source_input = options.vendor_source_input.cloned();
        if let Some(input) = self
            .logical_source_input
            .as_ref()
            .or(self.vendor_source_input.as_ref())
        {
            self.dialect = self.dialect.or(Some(input.unit_profile()));
            self.dialect_context = Some(input.context_registry());
            self.metadata_origin = LoweringMetadataOrigin::Supplied;
        } else if self.metadata_origin == LoweringMetadataOrigin::Standalone {
            self.dialect_context = None;
        }
        self.native_entry = options
            .native_entry
            .map(|entry| std::sync::Arc::new(entry.clone()));
    }

    /// Retain the original entry channel for checked structural lowering.
    /// The module and source-origin owners retain the image bytes separately;
    /// this policy never grants native compiler admission.
    pub fn set_source_image_channel(&mut self, image: &tcl_lexer::SourceImage) {
        self.source_channel = image.channel();
    }

    fn current_source_channel(&self) -> tcl_lexer::SourceChannel {
        self.source_channel
    }

    fn segment_source(
        &self,
        text: &str,
        base: u32,
        purpose: SourceSegmentationPurpose,
    ) -> Option<Vec<SegmentedCommand>> {
        let image =
            tcl_lexer::SourceImage::from_bytes(text.as_bytes(), self.current_source_channel());
        crate::segmenter::segment_commands_image_with_offset_and_config(
            &image,
            base,
            purpose.config(self.config),
        )
    }

    /// Lower a source string to an IR script.
    ///
    /// Depth-guarded entry to the recursive lowering, alongside
    /// [`Self::lower_body`] — every nested body re-enters through one of
    /// these two, so bounding both here caps the whole `lower_script` ↔
    /// `lower_body` ↔ `lower_segmented` ↔ `lower_command` recursion. At the
    /// cap we stop descending and lower the remaining text as a single
    /// opaque [`Statement::Barrier`] rather than silently dropping it —
    /// downstream passes (SCCP, dead-code elimination, …) must treat
    /// unanalysed content as having unknown effects, not as empty/dead.
    fn lower_script(
        &mut self,
        source: &str,
        namespace: &str,
        purpose: SourceSegmentationPurpose,
    ) -> Script {
        self.nest_depth += 1;
        if MAX_LOWER_NEST_DEPTH.exceeded(self.nest_depth) {
            self.nest_depth -= 1;
            return over_depth_script(0, source.len());
        }
        // `source` starts a span space: its statements' offsets are relative
        // to it, whether it is the document or a literal materialised inside
        // one.  Swap it in for the descent and restore the enclosing one after
        // (see [`Self::source`]).
        let enclosing_source = std::mem::replace(&mut self.source, source.to_owned());
        // The selected local parser purpose is shared by binding analysis and
        // segmentation. Parent inputs/config remain unchanged for original
        // word and metadata joins; a missing body receipt cannot borrow them.
        let frame = self.source_entry_frame(namespace);
        let image = tcl_lexer::SourceImage::from_bytes(source.as_bytes(), self.source_channel);
        let Some(bindings) = SourceCommandBindings::analyse_image_in_frame_with_purpose(
            &image,
            &frame,
            self.config,
            self.registry,
            SourceAnalysisOptions {
                source_point_entry: self
                    .source_point_entry
                    .as_ref()
                    .filter(|_| self.nest_depth == 1),
                metadata_context: self.source_metadata_input(),
                hosted_execution_context: self.hosted_execution_context,
                execution_name_policy: self.execution_name_policy,
                logical_source_input: self.logical_source_input.as_ref(),
                vendor_source_input: self.vendor_source_input.as_ref(),
                compilation_scope: self.compilation_scope,
                invocation_realm: self.invocation_realm,
                declared_commands: self
                    .source_declared_commands
                    .as_ref()
                    .or(self.declared_commands),
                trusted_package_loaders: &self.trusted_package_loaders,
                trusted_source_modules: &self.trusted_source_modules,
                unknown_entry: self.unknown_entry || self.nest_depth > 1,
                invocation_dialect: self.invocation_dialect,
                compiled_variable_provider: self.compiled_variable_provider,
                native_entry: self.native_entry.as_deref(),
                incoming_formals: if self.nest_depth == 1 {
                    &self.incoming_formals
                } else {
                    &[]
                },
                native_compilation: tcl_registry::native_compilation::NativeCompilationContext {
                    frame: if self.module.top_level_kind == crate::ir::TopLevelKind::ProcedureBody {
                        tcl_registry::native_compilation::NativeCompilationFrame::ProcedureCode
                    } else {
                        self.native_compilation.frame
                    },
                    ..self.native_compilation
                },
            },
            purpose,
        ) else {
            self.source = enclosing_source;
            self.nest_depth -= 1;
            return over_depth_script(0, source.len());
        };
        let enclosing_bindings = self.source_bindings.replace(bindings.into());
        let result = self.lower_script_inner(source, namespace, purpose);
        self.restore_script_bindings(enclosing_bindings);
        self.source = enclosing_source;
        self.nest_depth -= 1;
        result
    }

    #[inline(never)]
    fn restore_script_bindings(&mut self, enclosing: Option<RetainedSourceBodyInventory>) {
        let completed = std::mem::replace(&mut self.source_bindings, enclosing);
        if self.nest_depth == 1 {
            self.module.procedure_implementation_bodies = completed.as_ref().map_or_else(
                || std::sync::Arc::from([]),
                |bindings| {
                    bindings
                        .procedure_implementation_bodies()
                        .map(
                            |body| crate::command_binding::SourceInstalledProcedureBody {
                                allocation: body.allocation.clone(),
                                command: body.allocation.command.clone(),
                                namespace: body.namespace.to_owned(),
                                namespace_key: body.namespace_key.clone(),
                                parameters: body.parameters.to_vec(),
                                original_parameters: body.original_parameters.cloned(),
                                source: body.source.clone(),
                            },
                        )
                        .collect()
                },
            );
            self.module.future_call_sites = completed.as_ref().map_or_else(Vec::new, |bindings| {
                bindings
                    .future_body_inventories()
                    .iter()
                    .flat_map(crate::command_binding::SourceFutureBodyInventory::call_sites)
                    .collect()
            });
            self.module_source_bindings = completed.map(Box::new);
        }
    }

    /// Run `body` with the words of the commands it lowers read from `text`,
    /// segmented at `base` — see [`WordSpace`]. Restores the enclosing space
    /// after, so a nested body does not outlive its own descent.
    fn in_word_space<T>(&mut self, text: &str, base: u32, body: impl FnOnce(&mut Self) -> T) -> T {
        let channel = self.current_source_channel();
        let enclosing =
            std::mem::replace(&mut self.word_space, WordSpace::new(text, base, channel));
        let result = body(self);
        self.word_space = enclosing;
        result
    }

    fn lower_script_inner(
        &mut self,
        source: &str,
        namespace: &str,
        purpose: SourceSegmentationPurpose,
    ) -> Script {
        let Some(commands) = self.segment_source(source, 0, purpose) else {
            return over_depth_script(0, source.len());
        };
        self.const_map_stack.push(HashMap::new());
        self.command_binding_site_stack.push(Vec::new());
        let stmts =
            self.in_word_space(source, 0, |this| this.lower_segmented(&commands, namespace));
        let command_binding_sites = self
            .command_binding_site_stack
            .pop()
            .expect("the script command-binding site scope is balanced");
        self.const_map_stack.pop();
        let script = self.attach_native_compilation_failure(
            Script::from_lowered_parts(stmts, command_binding_sites),
            0,
        );
        let script = self.retain_script_source(script, source, 0);
        script
    }

    /// Lower a body argument (inside braces/brackets) to an IR script.
    ///
    /// Inherits the parent scope's const-map so a child body can
    /// still relax its
    /// `eval` / `uplevel` against literals bound in the enclosing
    /// scope (`set body {literal}; catch {uplevel 1 $body}` is the
    /// canonical example).
    ///
    /// Depth-guarded the same way as [`Self::lower_script`] — see its doc
    /// comment.
    fn lower_body(&mut self, text: &str, base_offset: u32, namespace: &str) -> Script {
        let context = self.nested_irules_execution_context();
        self.lower_body_in_irules_context(text, base_offset, namespace, context)
    }

    /// Lower a body while explicitly preserving the registry-owned iRules
    /// execution context.  `when` / `proc` declarations use this to install
    /// their event/procedure frame; ordinary script-bearing commands use
    /// [`Self::lower_body`], which derives the nested context instead.
    fn lower_body_in_irules_context(
        &mut self,
        text: &str,
        base_offset: u32,
        namespace: &str,
        context: IrulesExecutionContext,
    ) -> Script {
        let previous = std::mem::replace(&mut self.irules_execution_context, context);
        self.nest_depth += 1;
        let result = if MAX_LOWER_NEST_DEPTH.exceeded(self.nest_depth) {
            self.nest_depth -= 1;
            over_depth_script(base_offset, text.len())
        } else {
            let result = self.lower_body_inner(text, base_offset, namespace);
            self.nest_depth -= 1;
            result
        };
        self.irules_execution_context = previous;
        result
    }

    /// Which iRules placement a nested script inherits.  A control-flow or
    /// callback body within an event/procedure keeps that live frame; a body
    /// reached from a top-level executable command remains invalid rather
    /// than gaining the power to declare a handler or procedure.
    const fn nested_irules_execution_context(&self) -> IrulesExecutionContext {
        match self.irules_execution_context {
            IrulesExecutionContext::TopLevel | IrulesExecutionContext::InvalidNestedBody => {
                IrulesExecutionContext::InvalidNestedBody
            }
            IrulesExecutionContext::EventBody => IrulesExecutionContext::EventBody,
            IrulesExecutionContext::ProcedureBody => IrulesExecutionContext::ProcedureBody,
        }
    }

    /// Run one synthesised script in a known iRules execution context.  A
    /// materialised proc body has no source token to route through
    /// [`Self::lower_body_in_irules_context`], but it still must not treat a
    /// nested declaration as a file-level one.
    fn lower_script_in_irules_context(
        &mut self,
        source: &str,
        namespace: &str,
        context: IrulesExecutionContext,
    ) -> Script {
        let previous = std::mem::replace(&mut self.irules_execution_context, context);
        let result = self.lower_script(source, namespace, SourceSegmentationPurpose::NestedScript);
        self.irules_execution_context = previous;
        result
    }

    /// The part of a body word's `text` whose spans may honestly be rebased
    /// by that word's content offset, given the word occupies `tok`'s span in
    /// [`Self::source`].
    ///
    /// Every body lowering below adds one base offset to the spans the
    /// segmenter cuts from a word *value*, which is truthful only while that
    /// value is the source region verbatim.  A compound `{body}x` word breaks
    /// it: the value is the brace content welded to the tail with the closing
    /// `}` dropped, so every token past the drop slides one byte left — an
    /// off-by-one span on ASCII, an offset inside a UTF-8 sequence on
    /// anything else.  [`crate::segmenter::body_text_in_region`]
    /// clamps such a value to the contiguous braced part and passes an
    /// ordinary body through untouched; the analyser's `analyse_body`
    /// applies it too, and this is the lowering side of the same guard.
    ///
    /// A substituting word (`$body`, `[gen]`) is left alone: its value is
    /// run-time data that no source region can be compared against, so there
    /// is nothing here to prove and clamping it would only delete text.  Such
    /// words are the literal gates' business — they barrier rather than
    /// lower.
    ///
    /// A translating Document channel folds CRLF in a braced word's cooked
    /// value while its spans stay original offsets, so a braced body maps
    /// back to its source region first
    /// ([`crate::segmenter::braced_body_source_region`]).
    fn guarded_body_text(&self, tok: tcl_lexer::Token, text: &str) -> String {
        if matches!(tok.kind, TokenType::Var | TokenType::Cmd) {
            return text.to_owned();
        }
        let base = (tok.span.start() + u32::from(tok.content_offset)) as usize;
        let text = crate::segmenter::braced_body_source_region(
            &self.source,
            base,
            tok.span.end().saturating_sub(1) as usize,
            text,
        );
        crate::segmenter::body_text_in_region(&self.source, base, tok.span.end() as usize, text)
            .to_owned()
    }

    fn lower_body_inner(&mut self, text: &str, base_offset: u32, namespace: &str) -> Script {
        let Some(commands) =
            self.segment_source(text, base_offset, SourceSegmentationPurpose::NestedScript)
        else {
            return over_depth_script(base_offset, text.len());
        };
        let inherited = self.const_map_stack.last().cloned().unwrap_or_default();
        self.const_map_stack.push(inherited);
        self.command_binding_site_stack.push(Vec::new());
        let stmts = self.in_word_space(text, base_offset, |this| {
            this.lower_segmented(&commands, namespace)
        });
        let command_binding_sites = self
            .command_binding_site_stack
            .pop()
            .expect("the body command-binding site scope is balanced");
        self.const_map_stack.pop();
        let script = self.attach_native_compilation_failure(
            Script::from_lowered_parts(stmts, command_binding_sites),
            base_offset,
        );
        let script = self.retain_script_source(script, text, base_offset);
        script
    }

    /// Retain only a failure agreed by every reached compilation entry.
    fn attach_native_compilation_failure(&self, mut script: Script, chunk: u32) -> Script {
        if self.readonly_logical_body
            || self.readonly_hosted_body
            || self.readonly_authored_body
            || self.readonly_native_declaration_body
        {
            return script;
        }
        script.native_compilation_failure = self
            .source_bindings
            .as_ref()
            .and_then(|bindings| bindings.native_compilation_failure_at(chunk))
            .cloned()
            .map(Box::new);
        if let Some(bindings) = &self.source_bindings
            && (bindings.native_compilation_provider_required_at(chunk)
                || script.native_compilation_failure.is_some())
        {
            script.native_compilation_admission = Some(std::sync::Arc::new(
                crate::native_compilation_admission::NativeCompilationAdmission {
                    source: bindings.native_compilation_source_at(chunk).cloned(),
                    failure: script
                        .native_compilation_failure
                        .as_deref()
                        .cloned()
                        .map(std::sync::Arc::new),
                    provider_required: true,
                },
            ));
        }
        script
    }

    /// Lower a list of segmented commands to IR statements.
    fn lower_segmented(
        &mut self,
        segments: &[SegmentedCommand],
        namespace: &str,
    ) -> Vec<Statement> {
        let mut stmts = Vec::new();
        for seg in segments {
            if seg.is_partial {
                Self::push_partial_command(&mut stmts, seg.span);
                continue;
            }
            if let Some(stmt) = self.lower_command(seg, namespace) {
                self.update_const_map(seg, &stmt);
                Self::push_boxed_statement(&mut stmts, stmt);
            }
        }
        self.debug_assert_spans_in_source(&stmts);
        stmts
    }

    // Materialisation is deliberately outside the recursive descent frame.
    #[inline(never)]
    fn push_partial_command(statements: &mut Vec<Statement>, span: tcl_lexer::Span) {
        statements.push(Statement::Barrier {
            span,
            reason: "incomplete command".into(),
            command: String::new(),
            canonical_command: None,
            args: vec![],
            tokens: None,
        });
    }

    #[inline(never)]
    fn push_boxed_statement(statements: &mut Vec<Statement>, statement: Box<Statement>) {
        statements.push(*statement);
    }

    /// Every statement leaving [`Self::lower_segmented`] must carry a span
    /// that is a real range of the buffer it was lowered from — the contract
    /// downstream consumers rely on when they slice the source with an IR
    /// span (AGENTS.md: "trust it rather than re-deriving").
    ///
    /// This is the producer-side chokepoint: every statement the lowering
    /// emits passes through here, at the nesting level whose segments were
    /// cut from [`Self::source`], so a body rebase that overshoots its
    /// document (a compound `{body}x` word, a non-literal body word)
    /// fails the build's own tests instead of
    /// reaching a consumer.  Debug-only: the guards in
    /// [`Self::lower_body_from_tok`] and codegen's slice clamp are what keep
    /// a release build safe.
    fn debug_assert_spans_in_source(&self, stmts: &[Statement]) {
        debug_assert!(
            self.source.is_empty()
                || stmts
                    .iter()
                    .all(|stmt| self.source.get(stmt.span().as_range()).is_some()),
            "lowering emitted a span outside its {} byte source: {:?}",
            self.source.len(),
            stmts
                .iter()
                .map(Statement::span)
                .filter(|span| self.source.get(span.as_range()).is_none())
                .collect::<Vec<_>>(),
        );
    }

    /// Maintain the per-scope const-map after a command lowers.
    ///
    /// Retain a quiet Logical scalar assignment's original literal value
    /// under its decoded local name; unclosed writes withdraw retained entries.
    /// Gated on `proc_depth > 0` — globals / namespace vars at
    /// top-level or inside `namespace eval` cannot be safely
    /// const-propagated.
    ///
    /// Kept out of [`Self::lower_segmented`]'s frame: its carrier locals are
    /// several KiB, and that frame recurs once per nested body level.
    #[inline(never)]
    fn update_const_map(&mut self, seg: &SegmentedCommand, stmt: &Statement) {
        if self.proc_depth == 0 {
            return;
        }
        let quiet_store = if matches!(stmt, Statement::AssignConst { .. }) {
            let tokens = self.cmd_tokens(seg);
            tokens.source_binding.as_ref().and_then(|binding| {
                binding.original_conditional_logical_scalar_store(
                    &tokens,
                    self.invocation_metadata_context()?,
                    self.registry,
                )
            })
        } else {
            None
        };
        let literal = assigned_local_body_literal(seg, stmt, self.config).filter(|(_, value)| {
            quiet_store
                .as_ref()
                .is_some_and(|store| store.value() == value)
        });
        let Some(scope) = self.const_map_stack.last_mut() else {
            return;
        };
        if let Some((name, value)) = literal {
            scope.insert(name, value);
        } else if matches!(stmt, Statement::AssignConst { .. }) && quiet_store.is_none() {
            scope.clear();
        } else {
            invalidate_const_map_for(stmt, scope, self.config);
        }
    }

    fn original_native_written_argument_value(
        &self,
        seg: &SegmentedCommand,
        argument: usize,
    ) -> Option<String> {
        self.native_entry.as_ref()?;
        let tokens = self.cmd_tokens(seg);
        let binding = tokens.source_binding.as_ref()?;
        (binding.original_invocation_source_purpose(
            &tokens,
            self.invocation_metadata_context()?,
            self.registry,
        )? == crate::command_binding::OriginalInvocationSourcePurpose::Execution)
            .then_some(())?;
        binding
            .evaluated_written_argument_value(argument)
            .map(str::to_owned)
    }

    fn original_authored_written_argument_value(
        &self,
        seg: &SegmentedCommand,
        argument: usize,
    ) -> Option<String> {
        let tokens = self.cmd_tokens(seg);
        tokens
            .source_binding
            .as_ref()?
            .original_authored_written_argument_value(
                &tokens,
                argument,
                self.invocation_metadata_context()?,
                self.registry,
            )
            .map(str::to_owned)
    }

    /// Read a simple body reference from the quiet Logical local-value map.
    /// Unknown, array and compound references retain runtime dispatch.
    fn const_map_lookup(&self, word: &str) -> Option<String> {
        if self.proc_depth == 0 {
            return None;
        }
        let name = tcl_syntax::naming::whole_scalar_variable_reference_name(word, self.config)?;
        self.const_map_stack.last()?.get(name).cloned()
    }

    fn logical_structured_invocation(
        &self,
        tokens: &CommandTokens,
    ) -> Option<crate::registry_invocation::SourceStructuredInvocation> {
        if self.allows_standalone_registry_metadata() {
            return crate::registry_invocation::original_authored_control_invocation(
                tokens,
                self.registry,
            )
            .or_else(|| {
                crate::registry_invocation::original_authored_scalar_invocation(
                    tokens,
                    self.registry,
                )
                .map(|selected| {
                    crate::registry_invocation::SourceStructuredInvocation::Authored(Box::new(
                        selected,
                    ))
                })
            });
        }
        let metadata = self.invocation_metadata_context()?;
        if self.readonly_native_declaration_body {
            return crate::registry_invocation::original_native_source_structured_invocation(
                self.registry,
                metadata,
                tokens,
            );
        }
        if metadata
            .source_analysis_input()
            .is_some_and(crate::analyser::ResolvedAnalysisInput::has_hosted_source_name_context)
        {
            return crate::registry_invocation::original_hosted_structured_invocation(
                self.registry,
                metadata,
                tokens,
            );
        }
        crate::registry_invocation::logical_structured_invocation_with_metadata_context(
            self.registry,
            self.invocation_metadata_context()?,
            tokens,
            self.source_bindings.as_deref(),
        )
        .map(|selected| {
            crate::registry_invocation::SourceStructuredInvocation::Logical(Box::new(selected))
        })
        .or_else(|| {
            crate::registry_invocation::original_logical_source_structured_invocation(
                self.registry,
                metadata,
                tokens,
            )
        })
        .or_else(|| {
            if self.target.is_bytecode() {
                return None;
            }
            crate::registry_invocation::original_native_source_structured_invocation(
                self.registry,
                metadata,
                tokens,
            )
        })
    }

    /// Build a `CommandTokens` snapshot from a segmented command, decomposing
    /// each word under the document's own grammar (`self.config`) from the
    /// text that was segmented into it (see [`WordSpace`]).
    fn cmd_tokens(&self, seg: &SegmentedCommand) -> CommandTokens {
        let mut tokens = CommandTokens::from_segmented(&self.word_space.map(), self.config, seg);
        if self.readonly_authored_body {
            if let Some(scope) = &self.authored_source_scope {
                let mut scalar = None;
                if let Some(bindings) = &self.source_bindings
                    && let Some(mut declared) = bindings
                        .original_authored_declaration_source_tokens(&tokens, scope, self.registry)
                {
                    let original = declared.clone();
                    let retained = declared.source_binding.as_mut().and_then(|binding| {
                        binding.retain_original_authored_scalar_body_scope(
                            std::sync::Arc::clone(scope),
                            &original,
                        )
                    });
                    if retained.is_some()
                        && crate::registry_invocation::original_authored_scalar_invocation(
                            &declared,
                            self.registry,
                        )
                        .is_some()
                    {
                        scalar = Some(declared);
                    }
                }
                let original = tokens.clone();
                let _ = tokens
                    .source_binding
                    .get_or_insert_with(Default::default)
                    .retain_original_authored_source_body_scope(
                        std::sync::Arc::clone(scope),
                        &original,
                    );
                if let Some(declared) = scalar {
                    tokens = declared;
                }
            }
        } else if let Some(bindings) = &self.source_bindings {
            bindings.stamp_original_tokens(&mut tokens);
            if let (Some(body), Some(metadata)) = (
                self.original_body_word_source.as_ref(),
                self.invocation_metadata_context(),
            ) && let Some(input) = metadata.source_analysis_input()
            {
                let _ = body.stamp_original_tokens(self.registry, input, &mut tokens);
            }
        }
        if let Some(owner) = &self.native_source_children {
            let _ = owner.stamp_tokens(&mut tokens);
        }
        // Implementation contract: naming.consumer.hosted-source-taint-descriptor

        // The invocation owns the original whole image. A retained body's
        // positioned lowering buffer can contain padding before this command;
        // those bytes are not the source owner of conditional hosted metadata.
        tokens.hosted_taint_context = tokens
            .source_binding
            .as_ref()
            .and_then(|binding| binding.invocation_site())
            .zip(self.dialect_context.as_ref())
            .and_then(|(site, context)| {
                crate::registry_invocation::HostedSourceTaintContext::from_lowering(
                    site.source.source_image().clone(),
                    self.config,
                    std::sync::Arc::clone(context),
                )
                .map(|owner| {
                    owner.retain_source_structure_input(
                        self.invocation_metadata_context()
                            .and_then(crate::registry_invocation::InvocationMetadataContext::source_analysis_input),
                    )
                })
            })
            .map(std::sync::Arc::new);
        tokens
    }

    /// Construct the full source carrier outside recursive lowering frames.
    #[inline(never)]
    fn cmd_tokens_boxed(&self, seg: &SegmentedCommand) -> Box<CommandTokens> {
        Box::new(self.cmd_tokens(seg))
    }

    /// Extract arg token kinds for the lowering hooks.
    fn arg_kinds(seg: &SegmentedCommand) -> Vec<ArgTokenKind> {
        seg.argv
            .iter()
            .skip(1)
            .map(|t| arg_token_kind(t.kind))
            .collect()
    }

    /// Collect proved handler directives as metadata, independently of opcode
    /// eligibility. Dead branches and unknown operands supply no literal row.
    fn record_namespace_directives(&mut self, tokens: &CommandTokens, namespace: &str) {
        use tcl_registry::{NamespaceTransition, NamespaceTransitionTarget, TransitionSubject};
        if self.dead_code_depth != 0 {
            return;
        }
        let footprint = match self.invocation_metadata_context() {
            Some(context) => {
                crate::registry_invocation::namespace_directive_footprint_with_metadata_context(
                    self.registry,
                    Some(context),
                    tokens,
                )
            }
            None if self.allows_standalone_registry_metadata() => {
                crate::registry_invocation::namespace_directive_footprint(
                    self.registry,
                    None,
                    tokens,
                )
            }
            None => None,
        };
        let Some(footprint) = footprint else { return };
        let namespace = tokens
            .source_binding
            .as_ref()
            .map_or(namespace, |binding| binding.lookup_namespace.as_str());
        if let Some(site) = tokens
            .source_binding
            .as_ref()
            .and_then(crate::command_binding::SourceInvocationBinding::invocation_site)
            && !self
                .namespace_directive_sites
                .insert((site.clone(), namespace.to_owned()))
        {
            return;
        }
        for directive in footprint.transitions() {
            match directive {
                NamespaceTransition::Import {
                    namespace: NamespaceTransitionTarget::Current,
                    patterns,
                    ..
                } => {
                    for pattern in patterns.iter().filter_map(TransitionSubject::literal) {
                        self.namespace_imports
                            .push((namespace.to_owned(), pattern.to_owned()));
                    }
                }
                NamespaceTransition::Export {
                    namespace: NamespaceTransitionTarget::Current,
                    patterns,
                } => {
                    let Some((_, patterns)) =
                        NamespaceTransition::export_pattern_operands(patterns)
                    else {
                        continue;
                    };
                    self.namespace_exports.extend(
                        patterns
                            .iter()
                            .filter_map(TransitionSubject::literal)
                            .map(|pattern| (namespace.to_owned(), pattern.to_owned())),
                    );
                }
                _ => {}
            }
        }
    }

    /// Whether a resolved lowering hook commits to a **positional argv
    /// shape** — its lowerer reads "the body is word N", "the loop variables
    /// are word 0", "the result variable is word 1" — so a `{*}` expansion
    /// among the words makes the shape unknowable and the call must barrier
    /// instead.
    ///
    /// Registry-derived by construction: the answer is keyed on the typed
    /// [`LoweringHookId`] that [`Self::try_dispatch_structured_hook`] already
    /// dispatches on, not on a command-name list: a name list drifts against
    /// the structured hook IDs, letting a form such as `lmap`, `dict for`,
    /// `array for`, `foreachLine`, `catch`, `try`, `eval`, `uplevel` or
    /// `apply` commit to its un-expanded argv.  The match is exhaustive with
    /// no wildcard arm, so a new hook ID cannot be added without classifying
    /// it here.
    ///
    /// The `false` arm is the non-structured group: those hooks run in
    /// [`try_lower_hook`] before this dispatcher is reached, and each already
    /// declines an expanded call itself via `has_expansion`.
    fn hook_commits_to_argv_shape(hook: LoweringHookId) -> bool {
        match hook {
            LoweringHookId::Proc
            | LoweringHookId::When
            | LoweringHookId::NamespaceEval
            | LoweringHookId::If
            | LoweringHookId::Switch
            | LoweringHookId::For
            | LoweringHookId::While
            | LoweringHookId::Foreach
            | LoweringHookId::Lmap
            | LoweringHookId::ForeachLine
            | LoweringHookId::Catch
            | LoweringHookId::Try
            | LoweringHookId::Dict
            | LoweringHookId::Eval
            | LoweringHookId::Uplevel
            | LoweringHookId::Apply
            | LoweringHookId::ArrayFor => true,
            LoweringHookId::Expr
            | LoweringHookId::Return
            | LoweringHookId::Set
            | LoweringHookId::Incr
            | LoweringHookId::AppendOrLappend
            | LoweringHookId::Unset
            | LoweringHookId::Global
            | LoweringHookId::Variable
            | LoweringHookId::Upvar => false,
        }
    }

    /// `{*}` expansion on a structured command lowers to a barrier so
    /// downstream analyses can't reason about the expanded form.
    fn structured_expand_barrier(
        &self,
        cmd_name: &str,
        args: &[String],
        seg: &SegmentedCommand,
    ) -> Statement {
        Statement::Barrier {
            span: seg.span,
            reason: format!("{cmd_name} with argument expansion"),
            command: cmd_name.into(),
            canonical_command: None,
            args: args.to_vec(),
            tokens: Some(self.cmd_tokens(seg)),
        }
    }

    /// Try to dispatch *`cmd_name`* through the registry's typed
    /// [`LoweringHookId`] for structured commands dispatched from
    /// [`lower_command`](Self::lower_command).  Returns
    /// `Some(stmt)` when the hook ID matches a structured form;
    /// returns `None` otherwise so `lower_command` falls back to
    /// [`lower_default`](Self::lower_default).
    ///
    /// Every structured form routes through
    /// `resolve_call().lowering_hook`, and unmatched commands flow
    /// straight to `lower_default`.  Forms with shape preconditions
    /// (`proc`, `namespace eval`, `foreach`, `lmap`, `dict`,
    /// `when`, `foreachLine`) return `None` on a failed
    /// precondition so `lower_default` catches them.
    ///
    /// Dispatching through the hook ID picks up two benefits over a
    /// bare name match:
    ///
    /// 1. Canonical resolution via [`CommandRegistry::resolve_call`]
    ///    instead of bare name comparison, so any future spec
    ///    that aliases an existing form (e.g. an iRules-specific
    ///    `eval` variant) automatically dispatches correctly
    ///    when its `lowering_hook` is stamped.
    /// 2. The hook ID is the canonical key consumed by downstream
    ///    audit / LSP / compiler-explorer surfaces.
    // Registry-hook dispatcher keeps uniform fallback policy in one place.
    #[allow(clippy::too_many_lines)]
    fn try_dispatch_structured_hook(
        &mut self,
        cmd_name: &str,
        seg: &SegmentedCommand,
        namespace: &str,
    ) -> Option<Box<Statement>> {
        let args = seg.args();
        // Release availability is selected before recursive body lowering.
        let tokens = self.cmd_tokens_boxed(seg);
        if self.target.is_bytecode()
            && tokens
                .source_binding
                .as_ref()
                .and_then(|binding| binding.original_structured_compilation(&tokens))
                .is_some_and(|preparation| {
                    matches!(
                        preparation.recipe(),
                        tcl_registry::native_instruction_plan::NativeInstructionPlan::Control(_)
                    )
                })
        {
            // The selected compiler owns expression preparation and body visits.
            // Retain its original vector until the native emission work list.
            return Some(self.lower_default_boxed(seg, namespace));
        }
        let admitted = self.target.is_bytecode().then(|| {
            crate::registry_invocation::admitted_native_compiler_invocation(
                self.registry,
                None,
                &tokens,
            )
        });
        let logical =
            (!self.target.is_bytecode()).then(|| self.logical_structured_invocation(&tokens));
        let resolved = if let Some(admitted) = &admitted {
            let admitted = admitted.as_ref()?;
            StructuredHookSelection {
                hook: admitted.lowering_hook()?,
                requirement: crate::registry_invocation::SelectedLoweringBindingIdentity::Native(
                    admitted,
                ),
                error_context: admitted.compiler_operand_error_context(),
            }
        } else {
            let logical = logical.as_ref()?.as_ref()?;
            StructuredHookSelection {
                hook: logical.lowering_hook()?,
                requirement: logical.lowering_identity(),
                error_context: logical.error_context(),
            }
        };
        let hook = resolved.hook;
        // The expansion gate lives here, keyed on the same typed hook the
        // dispatch below uses, so it can never name a different set of
        // commands than the lowerers it protects.
        if Self::hook_commits_to_argv_shape(hook)
            && seg
                .expand_word
                .as_ref()
                .is_some_and(|ew| ew.iter().any(|&e| e))
        {
            return Some(self.box_lowered_statement(|this| {
                this.structured_expand_barrier(cmd_name, args, seg)
            }));
        }
        self.with_original_body_parent(tokens, |this| {
            let inline_body_error_context = resolved.error_context;
            let statement = match hook {
                // Static-body uplevel.  Match `uplevel 1 {body}`,
                // `uplevel #0 {body}`, and the canonical no-level form
                // `uplevel {body}` (level defaults to 1) when the body
                // arg is a brace-string literal token.  Dynamic forms
                // (`uplevel 1 $body` / `uplevel $lvl {body}`) fall
                // through to the default lowering so a runtime
                // `Call` / `Barrier` carries the unresolved arguments.
                LoweringHookId::Uplevel => this.box_lowered_statement(|this| {
                    this.try_lower_uplevel_static(seg, namespace)
                        .unwrap_or_else(|| this.lower_default(seg, namespace))
                }),

                // `eval $body` / `eval {body}` with a literal /
                // const-folded body relaxes to a `Statement::Block` so
                // downstream analyses see the inlined script.  Dynamic
                // bodies (`eval $dyn` with no const-map binding,
                // `eval [cmd]`) fall through to the default barrier
                // dispatch.
                LoweringHookId::Eval => this.box_lowered_statement(|this| {
                    this.lower_eval_structured(
                        seg,
                        namespace,
                        inline_body_error_context,
                        resolved.requirement,
                    )
                }),

                // `apply {{params} body ?ns?} …` — walk the braced body so nested
                // definitions register (like `namespace eval`), keeping the call a
                // runtime barrier because the body runs in a separate frame.
                LoweringHookId::Apply => this.box_lowered_statement(|this| this.lower_apply(seg)),

                // `array for {k v} arr body` (Tcl 9.0) — iterate array entries.
                // Like `apply`, the call stays a runtime barrier (C Tcl invokes
                // `::tcl::array::for` with the body as an unparsed literal), but a
                // braced literal body is walked in a fresh frame bound to the two
                // loop variables so it is analysable.
                LoweringHookId::ArrayFor => {
                    this.record_consumed_command_binding(seg, namespace, resolved.requirement);
                    this.box_lowered_statement(|this| this.lower_array_for(seg, namespace))
                }

                // Straightforward control-flow forms.  Each is a
                // single-method dispatch with no arity / shared-method /
                // subcommand complications.
                LoweringHookId::If => {
                    this.record_consumed_command_binding(seg, namespace, resolved.requirement);
                    this.box_lowered_statement(|this| this.lower_if(seg, namespace))
                }
                LoweringHookId::Switch => {
                    this.record_consumed_command_binding(seg, namespace, resolved.requirement);
                    this.box_lowered_statement(|this| this.lower_switch(seg, namespace))
                }
                LoweringHookId::For => {
                    this.record_consumed_command_binding(seg, namespace, resolved.requirement);
                    this.box_lowered_statement(|this| this.lower_for(seg, namespace))
                }
                LoweringHookId::While => {
                    this.record_consumed_command_binding(seg, namespace, resolved.requirement);
                    this.box_lowered_statement(|this| this.lower_while(seg, namespace))
                }
                // A count the release's `catch` refuses is its `wrong # args`, which
                // the command raises before it runs the body.
                LoweringHookId::Catch => {
                    if !this
                        .release_admits_arity(resolved.requirement.binding_identity(), args.len())
                    {
                        return None;
                    }
                    this.box_lowered_statement(|this| {
                        this.lower_catch_with_binding(seg, namespace, resolved.requirement)
                    })
                }
                LoweringHookId::Try => {
                    this.record_consumed_command_binding(seg, namespace, resolved.requirement);
                    this.box_lowered_statement(|this| this.lower_try(seg, namespace))
                }

                // Forms with shape preconditions.  Calls with the wrong
                // arity / shape must fall through to `lower_default`
                // instead of crashing the dedicated lowerer, so each arm
                // returns `None` on precondition failure and
                // `lower_command` then falls through to `lower_default`.
                //
                // `proc name params body` — exactly three args and
                // at least three token slices (the body needs to
                // be a real token, not synthesised whitespace).
                LoweringHookId::Proc => {
                    return this.box_optional_lowered_statement(|this| {
                        this.try_lower_proc_declaration(
                            seg,
                            namespace,
                            resolved.requirement.descriptor_key().label(),
                        )
                    });
                }
                // `namespace eval ns body` — the subcommand match
                // is already handled by `resolve_call`, so the
                // hook only fires for the `eval` subcommand.  Keep
                // the arity / token-count guards (a tokenless body
                // would derail body lowering).
                LoweringHookId::NamespaceEval => {
                    if args.len() >= 3 && seg.arg_tokens().len() >= 3 {
                        this.box_lowered_statement(|this| this.lower_namespace_eval(seg, namespace))
                    } else {
                        return None;
                    }
                }
                // `foreach vars list body` / `lmap vars list body`
                // — share `lower_foreach(... is_lmap)`.  The
                // dedicated lowerer handles its own shape errors,
                // so no precondition here.
                LoweringHookId::Foreach => {
                    this.record_consumed_command_binding(seg, namespace, resolved.requirement);
                    this.box_lowered_statement(|this| this.lower_foreach(seg, namespace, false))
                }
                LoweringHookId::Lmap => {
                    this.record_consumed_command_binding(seg, namespace, resolved.requirement);
                    this.box_lowered_statement(|this| this.lower_foreach(seg, namespace, true))
                }
                // `dict <subcommand> ...` — must have at least one
                // arg so the subcommand can be picked.  Bare `dict`
                // falls through to `lower_default`.
                LoweringHookId::Dict => {
                    if args.is_empty() {
                        return None;
                    }
                    this.record_consumed_command_binding(seg, namespace, resolved.requirement);
                    this.box_lowered_statement(|this| this.lower_dict(seg, namespace))
                }

                // `when EVENT ?priority N? body` — iRules event
                // handler.  The hook stamp lives on the `when` spec
                // in `tcl-registry/src/commands/irules/when.rs`,
                // which `load_dialect(SpecSurface::IRULES)` brings
                // into the registry.  Production callers (the LSP
                // server) load the active dialect
                // before lowering; tests that lower iRule code call
                // `registry.load_irules()` explicitly (see
                // `irules_checks::tests::registry`).  Callers that
                // lower iRule code against a vanilla `build_default()`
                // registry now silently flow through to
                // `lower_default` — that path was always a
                // misconfiguration; the dialect needs to match the
                // source.
                LoweringHookId::When => {
                    return this.box_optional_lowered_statement(|this| {
                        this.try_lower_when_declaration(
                            seg,
                            namespace,
                            resolved.requirement.descriptor_key().label(),
                        )
                    });
                }
                // `foreachLine varName filename body` — Tcl 9.0
                // (TIP 670).  Always registered in `build_default()`
                // via `tcl::foreachline::spec`, so no dialect-load
                // dance is needed.  The `lower_foreach_line`
                // emitter handles its own shape errors and
                // dynamic-body fallback, but the `args.len() == 3`
                // guard keeps an under- or over-argued `foreachLine`
                // flowing to `lower_default` instead of triggering a
                // barrier inside the dedicated emitter.
                LoweringHookId::ForeachLine => {
                    return this.box_optional_lowered_statement(|this| {
                        this.try_lower_foreach_line_structured(seg, namespace, resolved.requirement)
                    });
                }

                // Non-structured hooks (`Expr` / `Return` / `Set` /
                // `Incr` / `AppendOrLappend` / `Unset` / `Global` /
                // `Variable` / `Upvar`) are handled by
                // [`try_lower_hook`] before [`lower_command`] reaches
                // this dispatcher.  They can still reach here when
                // their static dispatcher returned `None` for the
                // input shape (e.g. `try_lower_expr` rejects
                // multi-arg `expr`); fall through to `lower_default`.
                LoweringHookId::Expr
                | LoweringHookId::Return
                | LoweringHookId::Set
                | LoweringHookId::Incr
                | LoweringHookId::AppendOrLappend
                | LoweringHookId::Unset
                | LoweringHookId::Global
                | LoweringHookId::Variable
                | LoweringHookId::Upvar => return None,
            };
            Some(statement)
        })
    }

    /// Keep the genuine parent vector through all structured body callbacks,
    /// restoring it even when a hook declines before producing a statement.
    fn with_original_body_parent<T>(
        &mut self,
        parent: Box<CommandTokens>,
        lower: impl FnOnce(&mut Self) -> T,
    ) -> T {
        let enclosing = self.structured_source_parent.replace(parent);
        let result = lower(self);
        self.structured_source_parent = enclosing;
        result
    }

    /// Materialise statement return storage outside the recursive dispatcher.
    /// Retaining one inline return slot per hook arm otherwise grows every
    /// nested structured lowering frame as the IR's statement variants grow.
    fn box_lowered_statement(
        &mut self,
        lower: impl FnOnce(&mut Self) -> Statement,
    ) -> Box<Statement> {
        Box::new(lower(self))
    }

    fn box_optional_lowered_statement(
        &mut self,
        lower: impl FnOnce(&mut Self) -> Option<Statement>,
    ) -> Option<Box<Statement>> {
        lower(self).map(Box::new)
    }

    /// Retain the resolved head of a command whose typed lowering consumes its
    /// live command semantics. This is recorded before lowering nested bodies,
    /// while the enclosing script's site scope is current.
    fn record_consumed_command_binding(
        &mut self,
        seg: &SegmentedCommand,
        resolution_namespace: &str,
        requirement: crate::registry_invocation::SelectedLoweringBindingIdentity<'_>,
    ) {
        let source_tokens = Some(Box::new(self.cmd_tokens(seg)));
        let name = crate::registry_invocation::static_command_word(
            source_tokens.as_deref().expect("retained invocation"),
            self.config.escapes,
            tcl_syntax::word_rules::WordValueRules::from_config(&self.config),
        )
        .unwrap_or_else(|| seg.name().to_owned());
        let guard = crate::registry_invocation::command_binding_guard(
            source_tokens.as_deref().expect("retained invocation"),
        );
        let namespace_context = crate::registry_invocation::compiled_namespace_context(
            source_tokens.as_deref().expect("retained invocation"),
        );
        let shape = self.invocation_shape(seg);
        let Some(sites) = self.command_binding_site_stack.last_mut() else {
            return;
        };
        sites.push(CommandBindingSite {
            span: seg.span,
            source_tokens,
            known_namespaces: self
                .source_bindings
                .as_ref()
                .map(|bindings| bindings.known_namespaces_at(seg.span.start())),
            variable_frame: self.source_bindings.as_ref().map(|bindings| {
                bindings
                    .invocation_at_source(seg.name(), seg.span.start())
                    .variable_frame
            }),
            variable_context: self.source_bindings.as_ref().map(|bindings| {
                bindings
                    .invocation_at_source(seg.name(), seg.span.start())
                    .variable_context
            }),
            existing_namespace_cells: self.source_bindings.as_ref().map(|bindings| {
                bindings
                    .invocation_at_source(seg.name(), seg.span.start())
                    .existing_namespace_cells
            }),
            binding: tcl_runtime_api::CommandBindingIdentity::in_rooted_namespace(
                resolution_namespace,
                name,
                requirement.binding_identity(),
            )
            .with_namespace_context(namespace_context)
            .with_guard(guard),
            shape,
        });
    }

    /// Whether the release's signature of `command` admits `count` arguments.
    fn release_admits_arity(&self, command: &str, count: usize) -> bool {
        self.registry.get(command).is_none_or(|spec| {
            self.registry
                .release_arity(spec)
                .accepts(u16::try_from(count).unwrap_or(u16::MAX))
        })
    }

    /// The words after `seg`'s command, as a release's compile reads them.
    fn invocation_shape(
        &self,
        seg: &SegmentedCommand,
    ) -> tcl_registry::release_compilation::InvocationShape {
        let release = self
            .dialect
            .map_or(tcl_dialect::TclVersion::V9_0, |profile| {
                profile.vm_runtime_version
            });
        let args = seg.texts.get(1..).unwrap_or_default();
        tcl_registry::release_compilation::InvocationShape::of(release, args, |index| {
            seg_word_is_static_literal(seg, index + 1)
        })
    }

    fn lower_catch_with_binding(
        &mut self,
        seg: &SegmentedCommand,
        namespace: &str,
        requirement: crate::registry_invocation::SelectedLoweringBindingIdentity<'_>,
    ) -> Statement {
        let lowered = self.lower_catch(seg, namespace);
        if matches!(lowered, Statement::Catch { .. }) {
            self.record_consumed_command_binding(seg, namespace, requirement);
        }
        lowered
    }

    fn lower_eval_structured(
        &mut self,
        seg: &SegmentedCommand,
        namespace: &str,
        inline_body_error_context: Option<tcl_registry::InlineBodyErrorContext>,
        requirement: crate::registry_invocation::SelectedLoweringBindingIdentity<'_>,
    ) -> Statement {
        let lowered = self.try_lower_eval_static(seg, namespace, inline_body_error_context);
        if lowered.is_some() {
            self.record_consumed_command_binding(seg, namespace, requirement);
        }
        lowered.unwrap_or_else(|| self.lower_default(seg, namespace))
    }

    fn try_lower_foreach_line_structured(
        &mut self,
        seg: &SegmentedCommand,
        namespace: &str,
        requirement: crate::registry_invocation::SelectedLoweringBindingIdentity<'_>,
    ) -> Option<Statement> {
        if seg.args().len() != 3 {
            return None;
        }

        let lowered = self.lower_foreach_line(seg, namespace);
        if matches!(lowered, Statement::Foreach { .. }) {
            self.record_consumed_command_binding(seg, namespace, requirement);
        }
        Some(lowered)
    }

    /// Retain a conditional Logical procedure directly from its sealed source
    /// recipe. Native parameter/publication/entry receipts remain unavailable.
    fn try_lower_logical_procedure_declaration(
        &mut self,
        seg: &SegmentedCommand,
        namespace: &str,
        tokens: &CommandTokens,
    ) -> Option<Statement> {
        if self.compilation_scope == tcl_runtime_api::SourceCompilationScope::EnteredSource {
            return None;
        }
        let input = self
            .invocation_metadata_context()?
            .source_analysis_input()?;
        let declaration = self
            .source_bindings
            .as_ref()?
            .original_logical_procedure_declaration(tokens, self.registry, input)?;
        let qualified = declaration.qualified_name()?.to_owned();
        let name = declaration.name()?.to_owned();
        let params_raw = declaration.parameters_text()?.to_owned();
        let params = declaration
            .parameters()
            .iter()
            .map(|parameter| parameter.name.clone())
            .collect();
        let source = declaration.source().clone();
        let body_offset = source.base();
        let body_source = source.try_text().ok()?.to_owned();
        let body = self
            .in_procedure_frame(Some(IrulesExecutionContext::ProcedureBody), |lowerer| {
                lowerer.lower_original_body(source, Some(declaration.namespace()))
            });
        if !self.suppress_proc_register {
            let publication = original_procedure_publication(tokens);
            if publication.as_ref().is_some_and(|publication| {
                self.module
                    .procedures
                    .values()
                    .any(|previous| previous.publication.as_ref() == Some(publication))
            }) {
                self.module.redefined_procedures.insert(qualified.clone());
            }
            self.module.retain_procedure(Procedure {
                name,
                qualified_name: qualified,
                publication,
                declaration_site: tokens
                    .source_binding
                    .as_ref()
                    .and_then(|binding| binding.invocation_site())
                    .cloned(),
                body_kind: crate::ir::ProcedureBodyKind::Named,
                params,
                span: seg.span,
                body,
                params_raw,
                body_source: Some(body_source),
                body_offset,
                namespace_scoped: self.in_namespace_eval,
                base_priority: 500,
            });
        }
        Some(self.lower_default(seg, namespace))
    }

    fn try_lower_proc_declaration(
        &mut self,
        seg: &SegmentedCommand,
        namespace: &str,
        canonical_command: &str,
    ) -> Option<Statement> {
        if seg.args().len() != 3 || seg.arg_tokens().len() < 3 {
            return None;
        }
        if self
            .registry
            .profile()
            .is_some_and(tcl_dialect::DialectProfile::is_irules)
        {
            if self
                .registry
                .irules_command_placement(canonical_command, self.irules_execution_context)
                != IrulesCommandPlacement::Allowed
            {
                return None;
            }
            let arg_refs: Vec<&str> = seg.args().iter().map(String::as_str).collect();
            let closed = tcl_registry::events::closed_braced_argument_words(
                &self.source,
                seg.arg_tokens(),
                seg.arg_single_token(),
            )?;
            let declaration = tcl_registry::events::IrulesDeclarationArguments::new(
                &arg_refs,
                seg.arg_tokens(),
                seg.arg_single_token(),
                &closed,
            )
            .and_then(|arguments| {
                self.registry
                    .irules_top_level_declaration_shape(canonical_command, arguments)
            });
            if !matches!(
                declaration,
                Some(tcl_registry::events::IrulesTopLevelDeclaration::Procedure { .. })
            ) {
                return None;
            }
        }
        Some(self.lower_proc(seg, namespace))
    }

    fn try_lower_when_declaration(
        &mut self,
        seg: &SegmentedCommand,
        namespace: &str,
        canonical_command: &str,
    ) -> Option<Statement> {
        if self
            .registry
            .irules_command_placement(canonical_command, self.irules_execution_context)
            != IrulesCommandPlacement::Allowed
        {
            return None;
        }
        let arg_refs: Vec<&str> = seg.args().iter().map(String::as_str).collect();
        let closed = tcl_registry::events::closed_braced_argument_words(
            &self.source,
            seg.arg_tokens(),
            seg.arg_single_token(),
        )?;
        let arguments = tcl_registry::events::IrulesDeclarationArguments::new(
            &arg_refs,
            seg.arg_tokens(),
            seg.arg_single_token(),
            &closed,
        )?;
        let tcl_registry::events::IrulesTopLevelDeclaration::Event {
            event,
            body_index,
            priority,
        } = self
            .registry
            .irules_top_level_declaration_shape(canonical_command, arguments)?
        else {
            return None;
        };
        Some(self.lower_when(seg, namespace, &event, body_index, priority))
    }

    /// Store a non-structured hook's exact dependency only when it replaced
    /// ordinary command dispatch with specialised IR.
    fn finish_resolved_lowering(
        &mut self,
        seg: &SegmentedCommand,
        lowered: ResolvedLowering,
    ) -> Statement {
        let source_tokens = lowered
            .binding
            .as_ref()
            .map(|_| Box::new(self.cmd_tokens(seg)));
        let shape = if lowered.binding.is_some() {
            self.invocation_shape(seg)
        } else {
            tcl_registry::release_compilation::InvocationShape::default()
        };
        if let Some(binding) = lowered.binding
            && let Some(sites) = self.command_binding_site_stack.last_mut()
        {
            sites.push(CommandBindingSite {
                span: seg.span,
                source_tokens,
                known_namespaces: self
                    .source_bindings
                    .as_ref()
                    .map(|bindings| bindings.known_namespaces_at(seg.span.start())),
                variable_frame: self.source_bindings.as_ref().map(|bindings| {
                    bindings
                        .invocation_at_source(seg.name(), seg.span.start())
                        .variable_frame
                }),
                variable_context: self.source_bindings.as_ref().map(|bindings| {
                    bindings
                        .invocation_at_source(seg.name(), seg.span.start())
                        .variable_context
                }),
                existing_namespace_cells: self.source_bindings.as_ref().map(|bindings| {
                    bindings
                        .invocation_at_source(seg.name(), seg.span.start())
                        .existing_namespace_cells
                }),
                binding,
                shape,
            });
        }
        lowered.statement
    }

    /// Retain vendor rule declarations independently of native compiler protocol.
    /// The host declaration grammar supplies a deferred inventory, not an opcode
    /// or proof that runtime command installation necessarily completes.
    fn try_lower_rule_loader_declaration(
        &mut self,
        seg: &SegmentedCommand,
        namespace: &str,
        tokens: &CommandTokens,
    ) -> Option<Box<Statement>> {
        use tcl_dialect::model::InvocationRealm;
        use tcl_registry::events::IrulesTopLevelDeclaration;
        if !self
            .registry
            .profile()
            .is_some_and(tcl_dialect::DialectProfile::is_irules)
            || self.irules_execution_context != IrulesExecutionContext::TopLevel
        {
            return None;
        }
        let binding = tokens.source_binding.as_ref()?;
        if binding.invocation_realm() != Some(InvocationRealm::RuleLoader) {
            return None;
        }
        match self.retained_rule_loader_declaration(seg.span.start()) {
            Some(IrulesTopLevelDeclaration::Priority { value }) => {
                self.irules_priority = value;
                return Some(self.lower_default_boxed(seg, namespace));
            }
            Some(IrulesTopLevelDeclaration::Event {
                event,
                body_index,
                priority,
            }) => {
                return Some(Box::new(
                    self.lower_when(seg, namespace, &event, body_index, priority),
                ));
            }
            Some(IrulesTopLevelDeclaration::Procedure { .. }) => {
                // A validated alternative retains a deferred declaration only.
                // The original Call and its runtime/compilation residual remain.
                return Some(Box::new(self.lower_proc(seg, namespace)));
            }
            _ => {}
        }
        let target = binding.proved_handler_target()?;
        if !target.registry_backed || !target.prepended.is_empty() {
            return None;
        }
        let name = target.command.as_str();
        if let Some(value) =
            resolved_top_level_priority(self.registry, name, &binding.evaluated_argument_values)
        {
            self.irules_priority = value;
            return Some(self.lower_default_boxed(seg, namespace));
        }
        match self.registry.get(name)?.lowering_hook? {
            LoweringHookId::When => self
                .try_lower_when_declaration(seg, namespace, name)
                .map(Box::new),
            LoweringHookId::Proc => self
                .try_lower_proc_declaration(seg, namespace, name)
                .map(Box::new),
            _ => None,
        }
    }

    /// Body-bearing alternatives supply deferred inventory; file policy requires a
    /// closed declaration candidate. Neither projection licenses an opcode.
    fn retained_rule_loader_declaration(
        &self,
        offset: u32,
    ) -> Option<tcl_registry::events::IrulesTopLevelDeclaration> {
        use tcl_registry::events::IrulesTopLevelDeclaration;
        self.source_bindings
            .as_ref()?
            .deferred_rule_declaration_candidates(offset)?
            .iter()
            .find_map(|candidate| match &candidate.declaration {
                declaration @ IrulesTopLevelDeclaration::Event { .. } => Some(declaration.clone()),
                declaration @ IrulesTopLevelDeclaration::Procedure { .. }
                    if candidate.body.is_some() =>
                {
                    Some(declaration.clone())
                }
                declaration @ IrulesTopLevelDeclaration::Priority { .. } if !candidate.unknown => {
                    Some(declaration.clone())
                }
                _ => None,
            })
    }

    /// Lower a single command.
    fn lower_command(&mut self, seg: &SegmentedCommand, namespace: &str) -> Option<Box<Statement>> {
        if seg.texts.is_empty() {
            return None;
        }
        // Only the structured dispatch below recurses into nested bodies, so
        // every other selection runs in its own out-of-line frame: this frame
        // recurs once per nested body level under the depth guard's budget.
        match self.lower_command_selection(seg, namespace) {
            CommandLoweringSelection::Lowered(statement) => Some(statement),
            CommandLoweringSelection::Structured(resolved_name) => {
                if let Some(stmt) =
                    self.try_dispatch_structured_hook(&resolved_name, seg, namespace)
                {
                    return Some(stmt);
                }
                Some(self.lower_default_boxed(seg, namespace))
            }
        }
    }

    /// Every non-recursive selection of [`Self::lower_command`]: a finished
    /// statement, or the resolved label of a possible structured form.
    #[inline(never)]
    fn lower_command_selection(
        &mut self,
        seg: &SegmentedCommand,
        namespace: &str,
    ) -> CommandLoweringSelection {
        use CommandLoweringSelection::Lowered;
        // Analysis uses the selected logical handler in its owned source scope.
        // Bytecode separately requires original native compiler admission.
        let tokens = self.cmd_tokens_boxed(seg);
        self.record_namespace_directives(&tokens, namespace);
        if let Some(declaration) = self.try_lower_rule_loader_declaration(seg, namespace, &tokens) {
            return Lowered(declaration);
        }
        if self.target.is_bytecode()
            && crate::registry_invocation::proved_native_admitted_inline_operation(&tokens)
                .is_none()
        {
            self.retain_entered_namespace_body(seg, namespace, &tokens);
        }
        if !self.target.is_bytecode()
            && !self.target.is_trace_visible()
            && let Some(statement) = self
                .try_lower_authored_procedure_declaration(seg, namespace, &tokens)
                .or_else(|| self.try_lower_logical_procedure_declaration(seg, namespace, &tokens))
        {
            return Lowered(Box::new(statement));
        }
        if !self.target.is_bytecode()
            && !self.target.is_trace_visible()
            && let Some(statement) =
                self.try_lower_original_operand_evaluation_update(seg, namespace, &tokens)
        {
            return Lowered(statement);
        }
        let resolved_name = if self.target.is_bytecode() {
            let target = tokens
                .source_binding
                .as_ref()
                .and_then(|binding| {
                    binding
                        .admitted_inline_invocation()
                        .map(|proof| &proof.target)
                        .or_else(|| binding.proved_execution_target())
                })
                .filter(|target| target.registry_backed);
            if target
                .as_ref()
                .is_none_or(|target| !target.prepended.is_empty())
            {
                return Lowered(self.lower_default_boxed(seg, namespace));
            }
            if let Some(admitted) = crate::registry_invocation::admitted_native_compiler_invocation(
                self.registry,
                None,
                &tokens,
            ) {
                admitted.descriptor_key().label().to_owned()
            } else if let Some(label) = self.retained_metadata_descriptor_label(&tokens) {
                label
            } else {
                return Lowered(self.lower_default_boxed(seg, namespace));
            }
        } else {
            let Some(logical) = self.logical_structured_invocation(&tokens) else {
                return Lowered(self.lower_default_boxed(seg, namespace));
            };
            logical.descriptor_key().label().to_owned()
        };
        let resolved_name = resolved_name.as_str();

        if self.irules_execution_context == IrulesExecutionContext::TopLevel
            && let Some(value) = tokens.source_binding.as_ref().and_then(|binding| {
                resolved_top_level_priority(
                    self.registry,
                    resolved_name,
                    &binding.evaluated_argument_values,
                )
            })
        {
            self.irules_priority = value;
        }

        // Trace-visible compilation retains runtime dispatch at every site.
        if self.target.is_trace_visible() {
            return Lowered(self.lower_default_boxed(seg, namespace));
        }

        if self.target.is_bytecode()
            && crate::registry_invocation::proved_native_admitted_inline_operation(&tokens)
                .is_none()
        {
            // A declaration still supplies a deferred body inventory. Its
            // returned Call retains ordinary dispatch; no native opcode or
            // before-arguments command requirement is minted from that inventory.
            if self
                .registry
                .get(resolved_name)
                .is_some_and(|spec| spec.lowering_hook == Some(LoweringHookId::Proc))
                && let Some(statement) =
                    self.try_lower_proc_declaration_boxed(seg, namespace, resolved_name)
            {
                return Lowered(statement);
            }
            return Lowered(self.lower_default_boxed(seg, namespace));
        }

        if let Some(statement) = self.try_registered_lowering_hook(resolved_name, seg, namespace) {
            return Lowered(statement);
        }

        // Registry-driven hook-ID dispatch covers all 17
        // structured command forms — every typed
        // `LoweringHookId` (Proc, When, NamespaceEval, If,
        // Switch, For, While, Foreach, Lmap, ForeachLine, Catch,
        // Try, Dict, Eval, Uplevel, Apply, ArrayFor) flows through
        // [`try_dispatch_structured_hook`], which also raises the
        // `{*}`-expansion barrier for them.  Commands that
        // aren't in the registry, or whose hook is `None`, fall
        // through to [`lower_default`] in [`Self::lower_command`].
        CommandLoweringSelection::Structured(resolved_name.to_owned())
    }

    /// Retain an attempted update's original read plan without admitting its
    /// failed argv, handler or any body. Ordinary handler lowering stays gated.
    fn try_lower_original_operand_evaluation_update(
        &mut self,
        seg: &SegmentedCommand,
        namespace: &str,
        tokens: &CommandTokens,
    ) -> Option<Box<Statement>> {
        let selected = crate::registry_invocation::original_operand_evaluation_update(
            self.registry,
            self.invocation_metadata_context()?,
            tokens,
            self.source_bindings.as_deref()?,
        )?;
        let command = LoweringCommand {
            span: seg.span,
            name: selected.descriptor_key().label(),
            resolution_namespace: namespace,
            args: seg.args(),
            single_token_word: &seg.single_token_word,
            expand_word: seg.expand_word.as_deref(),
            tokens: Some(tokens.clone()),
            arg_kinds: &Self::arg_kinds(seg),
            dialect: self.dialect,
            lexer_config: self.config,
        };
        let lowered = crate::lowering_hooks::try_lower_operand_evaluation_update_with_binding(
            &command,
            &selected,
            &self.aliases,
            self.registry,
            self.dialect_context
                .as_deref()
                .map(tcl_registry::model::ContextRegistry::context),
            self.safe_on_uninit(command.name, command.args),
        )?;
        Some(Box::new(self.finish_resolved_lowering(seg, lowered)))
    }

    /// Keep declaration construction out of ordinary command descent frames.
    #[inline(never)]
    fn try_lower_proc_declaration_boxed(
        &mut self,
        seg: &SegmentedCommand,
        namespace: &str,
        resolved_name: &str,
    ) -> Option<Box<Statement>> {
        self.try_lower_proc_declaration(seg, namespace, resolved_name)
            .map(Box::new)
    }

    #[inline(never)]
    fn try_registered_lowering_hook(
        &mut self,
        resolved_name: &str,
        seg: &SegmentedCommand,
        namespace: &str,
    ) -> Option<Box<Statement>> {
        let args = seg.args();
        let hook_cmd = LoweringCommand {
            span: seg.span,
            name: resolved_name,
            resolution_namespace: namespace,
            args,
            single_token_word: &seg.single_token_word,
            expand_word: seg.expand_word.as_deref(),
            tokens: Some(self.cmd_tokens(seg)),
            arg_kinds: &Self::arg_kinds(seg),
            dialect: self.dialect,
            lexer_config: self.config,
        };
        let context = self
            .dialect_context
            .as_deref()
            .map(tcl_registry::model::ContextRegistry::context);
        let admitted = self.target.is_bytecode().then(|| {
            crate::registry_invocation::admitted_native_compiler_invocation(
                self.registry,
                None,
                hook_cmd.tokens.as_ref()?,
            )
        });
        let logical = (!self.target.is_bytecode())
            .then(|| self.logical_structured_invocation(hook_cmd.tokens.as_ref()?));
        let requirement = if let Some(admitted) = &admitted {
            crate::registry_invocation::SelectedLoweringBindingIdentity::Native(admitted.as_ref()?)
        } else {
            logical.as_ref()?.as_ref()?.lowering_identity()
        };
        let mut lowered = if self.target.is_bytecode() {
            crate::lowering_hooks::try_lower_admitted_hook_with_binding(
                &hook_cmd,
                &self.aliases,
                self.registry,
                context,
                self.safe_on_uninit(resolved_name, args),
            )?
        } else {
            let logical = logical.as_ref()?.as_ref()?;
            crate::lowering_hooks::try_lower_logical_hook_with_binding(
                &hook_cmd,
                logical,
                &self.aliases,
                self.registry,
                context,
                self.safe_on_uninit(resolved_name, args),
            )?
        };
        let tokens = self.cmd_tokens(seg);
        let name = crate::registry_invocation::static_command_word(
            &tokens,
            self.config.escapes,
            tcl_syntax::word_rules::WordValueRules::from_config(&self.config),
        )
        .unwrap_or_else(|| seg.name().to_owned());
        let binding = tcl_runtime_api::CommandBindingIdentity::in_rooted_namespace(
            namespace,
            name,
            requirement.binding_identity(),
        )
        .with_namespace_context(crate::registry_invocation::compiled_namespace_context(
            &tokens,
        ))
        .with_guard(crate::registry_invocation::command_binding_guard(&tokens));
        if let Statement::ExprEval {
            command_binding, ..
        } = &mut lowered.statement
        {
            *command_binding = binding.clone();
        }
        if lowered.binding.is_some() {
            lowered.binding = Some(binding);
        }
        Some(Box::new(self.finish_resolved_lowering(seg, lowered)))
    }

    #[inline(never)]
    fn lower_default_boxed(&mut self, seg: &SegmentedCommand, namespace: &str) -> Box<Statement> {
        Box::new(self.lower_default(seg, namespace))
    }

    /// Lower `proc name params body`.
    ///
    /// In order:
    ///   1. Empty-simple-name barrier (`proc ::ns:: {…} {…}`).
    ///   2. Dynamic name resolution (`proc $x …` / `proc [cmd] …`).
    ///   3. Dynamic body / params check, with const-map body
    ///      materialisation when possible.
    ///   4. IR registration + emit the runtime `proc` call.
    fn lower_proc(&mut self, seg: &SegmentedCommand, namespace: &str) -> Statement {
        if self.compilation_scope == tcl_runtime_api::SourceCompilationScope::EnteredSource {
            return self.lower_default(seg, namespace);
        }
        let args_borrow = seg.args();
        let proc_name_initial = &args_borrow[0];

        // Empty simple names need runtime publication; preserve the original
        // invocation instead of registering a lifted procedure.
        if proc_name_initial.ends_with("::") {
            return Statement::Barrier {
                span: seg.span,
                reason: "empty-simple-name proc".into(),
                command: seg.name().into(),
                canonical_command: None,
                args: args_borrow.to_vec(),
                tokens: Some(self.cmd_tokens(seg)),
            };
        }
        // Resolve a dynamic proc name.
        let (proc_name_owned, args_owned, name_was_substituted) =
            match self.resolve_dynamic_proc_name(seg, args_borrow) {
                Ok(triple) => triple,
                Err(barrier) => return *barrier,
            };
        let args: &[String] = &args_owned;
        let proc_name = &proc_name_owned;
        // Check for a dynamic body / params, materialising the body via the
        // const-map where possible.
        let (materialised_body, body_is_dynamic, body_offset) =
            match self.check_proc_body_dynamic(seg, args, name_was_substituted) {
                Ok(triple) => triple,
                Err(barrier) => return *barrier,
            };

        // Lower the body (materialised, static, or empty for
        // dynamic-with-resolved-name), register the Procedure, and emit the
        // runtime `proc` Call.
        // A parameter list Tcl would reject (malformed, an overlong specifier,
        // an array-element or qualified name) creates no procedure: leave it to
        // the runtime `proc`, which raises the error, rather than registering a
        // Procedure whose parameters we guessed at.
        let Some(params) = parse_formal_param_names(
            &args[1],
            WordValueRules::from_config(&self.config),
            self.invocation_dialect
                .and_then(tcl_registry::InvocationDialect::parameter_grammar),
        ) else {
            return Statement::Barrier {
                span: seg.span,
                reason: "malformed proc params".into(),
                command: seg.name().into(),
                canonical_command: None,
                args: seg.args().to_vec(),
                tokens: Some(self.cmd_tokens(seg)),
            };
        };
        let tokens = self.cmd_tokens(seg);
        let Some(publication) = original_procedure_publication(&tokens) else {
            return self.lower_default(seg, namespace);
        };
        let Some(qualified) = publication.reported_full_name() else {
            return self.lower_default(seg, namespace);
        };
        let body_text = &args[2];
        let body = self.lower_declared_proc_body(
            seg,
            materialised_body,
            body_is_dynamic,
            body_text,
            body_offset,
            namespace,
        );

        // A `proc` defined inside a TclOO method body is created
        // at method-call time in the runtime receiver namespace, not at script
        // load — so it must not be lifted into `module.procedures`
        // (codegen would otherwise emit it unconditionally). The body
        // was still lowered above for analysis; only the premature static
        // registration is suppressed.
        if !self.suppress_proc_register {
            if self
                .module
                .procedures
                .values()
                .any(|previous| previous.publication.as_ref() == Some(&publication))
            {
                self.module.redefined_procedures.insert(qualified.clone());
            }
            self.module.retain_procedure(Procedure {
                name: proc_name.clone(),
                qualified_name: qualified,
                publication: Some(publication),
                declaration_site: tokens
                    .source_binding
                    .as_ref()
                    .and_then(|binding| binding.invocation_site())
                    .cloned(),
                body_kind: crate::ir::ProcedureBodyKind::Named,
                params,
                span: seg.span,
                body,
                params_raw: args[1].clone(),
                body_source: Some(args[2].clone()),
                body_offset,
                namespace_scoped: self.in_namespace_eval,
                base_priority: 500,
            });
        }

        Statement::Call {
            span: seg.span,
            command: seg.name().into(),
            canonical_command: None,
            args: seg.args().to_vec(),
            defs: vec![],
            reads: vec![],
            reads_own_defs: false,
            safe_on_uninit: false,
            tokens: Some(self.cmd_tokens(seg)),
            foreach_groups: None,
        }
    }

    /// Prefer the declaration's exact retained script and execution frame.
    fn lower_declared_proc_body(
        &mut self,
        seg: &SegmentedCommand,
        materialised_body: Option<String>,
        body_is_dynamic: bool,
        body_text: &str,
        body_offset: u32,
        body_namespace: &str,
    ) -> Script {
        let retained = seg
            .arg_tokens()
            .get(2)
            .and_then(|token| {
                self.source_bindings
                    .as_ref()?
                    .executed_script_for_word(token.span)
                    .cloned()
            })
            .or_else(|| {
                self.source_bindings
                    .as_ref()?
                    .deferred_rule_declaration_candidates(seg.span.start())?
                    .iter()
                    .find_map(|candidate| {
                        matches!(
                            candidate.declaration,
                            tcl_registry::events::IrulesTopLevelDeclaration::Procedure { .. }
                        )
                        .then(|| candidate.body.clone())
                        .flatten()
                    })
            })
            .or_else(|| {
                // A declaration replaced before any call never enters its body,
                // yet `proc` created it from this exact script: C Tcl runs it in
                // the declaration's namespace if a caller reaches it first.
                let tokens = self.cmd_tokens(seg);
                let declaration = tokens.source_binding.as_ref()?.invocation_site()?;
                let mut bodies = self
                    .source_bindings
                    .as_ref()?
                    .procedure_implementation_bodies()
                    .filter(|body| &body.allocation.site == declaration);
                let first = bodies.next()?.source.clone();
                bodies.all(|body| body.source == &first).then_some(first)
            });
        if let Some(source) = retained {
            let declaration = self
                .cmd_tokens(seg)
                .source_binding
                .as_ref()
                .and_then(|binding| binding.invocation_site())
                .cloned();
            let body_namespace = self
                .source_bindings
                .as_ref()
                .and_then(|bindings| {
                    let declaration = declaration.as_ref()?;
                    let mut bodies = bindings.procedure_implementation_bodies().filter(|body| {
                        &body.allocation.site == declaration && body.source == &source
                    });
                    let first = bodies.next()?.namespace_key;
                    bodies
                        .all(|body| body.namespace_key == first)
                        .then(|| first.clone())
                })
                .or_else(|| {
                    self.source_bindings
                        .as_ref()?
                        .executed_script_namespace_context(&source)
                });
            self.in_procedure_frame(Some(IrulesExecutionContext::ProcedureBody), |lowerer| {
                lowerer.lower_original_body(source, body_namespace.as_ref())
            })
        } else if self.native_entry.is_some() {
            // A native declaration without retained body geometry cannot be
            // reanalysed under a namespace reconstructed from its label.
            over_depth_script(body_offset, body_text.len())
        } else {
            self.lower_proc_body(
                materialised_body,
                body_is_dynamic,
                body_text,
                body_offset,
                body_namespace,
            )
        }
    }

    /// Lower one procedure body in its fresh procedure frame.
    fn lower_proc_body(
        &mut self,
        materialised_body: Option<String>,
        body_is_dynamic: bool,
        body_text: &str,
        body_offset: u32,
        body_namespace: &str,
    ) -> Script {
        // ``lower_body`` otherwise inherits the enclosing scope's tracked
        // scalars, which is sound for control flow but not a proc's fresh
        // runtime frame.
        self.in_procedure_frame(Some(IrulesExecutionContext::ProcedureBody), |lowerer| {
            if let Some(text) = materialised_body {
                lowerer.lower_script_in_irules_context(
                    &text,
                    body_namespace,
                    IrulesExecutionContext::ProcedureBody,
                )
            } else if body_is_dynamic {
                // The resolved body value is dynamic; retain the runtime call but
                // do not compile the literal `$body` spelling as Tcl source.
                Script::default()
            } else if (lowerer.body_cache.is_some() || lowerer.original_body_cache.is_some()) && {
                lowerer.proc_depth == 1
                    && !lowerer
                        .registry
                        .profile()
                        .is_some_and(tcl_dialect::DialectProfile::is_irules)
                    && lowerer.source_bindings.as_ref().is_some_and(|bindings| {
                        bindings.can_reuse_isolated_body(
                            body_text,
                            body_offset,
                            body_namespace,
                            lowerer.config,
                            lowerer.registry,
                        )
                    })
            } {
                // Only context-free Tcl bodies can use the offset-zero body cache.
                let (mut script, issued) = if let Some(cache) = lowerer.original_body_cache {
                    let template = cache(body_text, body_namespace);
                    let issued = template.matches(
                        body_text,
                        body_namespace,
                        lowerer.registry,
                        lowerer.config,
                        lowerer.dialect,
                    );
                    (template.body, issued)
                } else {
                    (
                        (lowerer.body_cache.expect("selected body cache"))(
                            body_text,
                            body_namespace,
                        ),
                        false,
                    )
                };
                crate::lattice_rebase::rebase_script(&mut script, i64::from(body_offset));
                if lowerer
                    .source_bindings
                    .as_ref()
                    .is_some_and(|bindings| bindings.restore_script_bindings(&mut script))
                {
                    if !issued && let Some(integrity) = lowerer.optimiser_lowering_integrity {
                        integrity.set(false);
                    }
                    script
                } else {
                    lowerer.lower_body_in_irules_context(
                        body_text,
                        body_offset,
                        body_namespace,
                        IrulesExecutionContext::ProcedureBody,
                    )
                }
            } else {
                lowerer.lower_body_in_irules_context(
                    body_text,
                    body_offset,
                    body_namespace,
                    IrulesExecutionContext::ProcedureBody,
                )
            }
        })
    }

    /// Resolve a single variable name from its original Native argument value
    /// or quiet Logical source binding. Unknown and compound names retain
    /// runtime dispatch; literal names keep their original argument vector.
    fn resolve_dynamic_proc_name(
        &mut self,
        seg: &SegmentedCommand,
        args_borrow: &[String],
    ) -> Result<(String, Vec<String>, bool), Box<Statement>> {
        let proc_name_initial = &args_borrow[0];
        if !proc_name_initial.contains('$') && !proc_name_initial.contains('[') {
            return Ok((proc_name_initial.clone(), args_borrow.to_vec(), false));
        }

        let arg_tokens = seg.arg_tokens();
        let single_token_proc_name = seg.single_token_word.get(1).copied().unwrap_or(false);
        let resolved = if !proc_name_initial.contains('[')
            && single_token_proc_name
            && arg_tokens
                .first()
                .is_some_and(|t| t.kind == tcl_lexer::TokenType::Var)
        {
            self.original_native_written_argument_value(seg, 0)
                .or_else(|| self.original_authored_written_argument_value(seg, 0))
                .or_else(|| self.const_map_lookup(proc_name_initial))
        } else {
            None
        };

        let Some(literal) = resolved else {
            return Err(Box::new(Statement::Barrier {
                span: seg.span,
                reason: "dynamic proc name".into(),
                command: seg.name().into(),
                canonical_command: None,
                args: args_borrow.to_vec(),
                tokens: Some(self.cmd_tokens(seg)),
            }));
        };

        let mut args_owned = args_borrow.to_vec();
        args_owned[0].clone_from(&literal);
        Ok((literal, args_owned, true))
    }

    /// Check whether the proc body and/or params are dynamic, and
    /// attempt to materialise the body from the const-map.
    ///
    /// Returns:
    ///   * `Ok((Some(text), _, body_offset))` — body materialised
    ///     successfully; caller should lower `text` as a fresh
    ///     script.
    ///   * `Ok((None, body_is_dynamic, body_offset))` — body is
    ///     static (lower from source) or dynamic-with-name-resolved
    ///     (lower as empty Script).
    ///   * `Err(barrier)` — params dynamic, or body dynamic without
    ///     name substitution.  Caller propagates the barrier.
    fn check_proc_body_dynamic(
        &mut self,
        seg: &SegmentedCommand,
        args: &[String],
        name_was_substituted: bool,
    ) -> Result<(Option<String>, bool, u32), Box<Statement>> {
        let arg_tokens = seg.arg_tokens();
        let params_tok = arg_tokens[1];
        let body_tok = arg_tokens[2];
        // `single_token_word[0]` covers the command itself; args[0..]
        // live at indices `[1..]`.  See `SegmentedCommand::arg_single_token`.
        let body_is_single = seg.single_token_word.get(3).copied().unwrap_or(false);
        let params_is_single = seg.single_token_word.get(2).copied().unwrap_or(false);
        let body_is_dynamic = matches!(
            body_tok.kind,
            tcl_lexer::TokenType::Var | tcl_lexer::TokenType::Cmd
        ) || !body_is_single;
        let params_is_dynamic = matches!(
            params_tok.kind,
            tcl_lexer::TokenType::Var | tcl_lexer::TokenType::Cmd
        ) || !params_is_single;
        let materialised_body: Option<String> =
            if body_is_single && body_tok.kind == tcl_lexer::TokenType::Cmd {
                // `args[2]` is the `word_piece`-reconstructed source
                // — for a Cmd token that's `[subst -nocommands {…}]`
                // (with the brackets re-added).
                // `eval_subst_nocommands_body` segments its input as
                // a top-level Tcl command stream and expects the
                // inner content, so strip the outer `[…]` before
                // handing it over.
                self.original_native_written_argument_value(seg, 2)
                    .or_else(|| self.original_authored_written_argument_value(seg, 2))
                    .or_else(|| {
                        args[2]
                            .strip_prefix('[')
                            .and_then(|s| s.strip_suffix(']'))
                            .and_then(|inner| self.eval_subst_nocommands_body(inner))
                    })
            } else if body_is_single && body_tok.kind == tcl_lexer::TokenType::Var {
                self.original_native_written_argument_value(seg, 2)
                    .or_else(|| self.original_authored_written_argument_value(seg, 2))
                    .or_else(|| self.const_map_lookup(&args[2]))
            } else {
                None
            };
        if params_is_dynamic
            || (body_is_dynamic && materialised_body.is_none() && !name_was_substituted)
        {
            return Err(Box::new(Statement::Barrier {
                span: seg.span,
                reason: if params_is_dynamic {
                    "dynamic proc params"
                } else {
                    "dynamic proc body"
                }
                .into(),
                command: seg.name().into(),
                canonical_command: None,
                args: seg.args().to_vec(),
                tokens: Some(self.cmd_tokens(seg)),
            }));
        }
        let body_offset = body_tok.span.start() + u32::from(body_tok.content_offset);
        Ok((materialised_body, body_is_dynamic, body_offset))
    }

    /// Event geometry comes from the retained declaration and original words.
    /// A captured/derived argument cannot borrow a displayed event spelling.
    fn original_when_event_word(
        &self,
        seg: &SegmentedCommand,
        event: &str,
        image: &tcl_lexer::SourceImage,
    ) -> Option<tcl_lexer::NativeWord> {
        use tcl_registry::events::IrulesTopLevelDeclaration;
        let bindings = self.source_bindings.as_ref()?;
        let candidates = bindings.deferred_rule_declaration_candidates(seg.span.start())?;
        let indices = candidates
            .iter()
            .map(|candidate| {
                let IrulesTopLevelDeclaration::Event { event: name, .. } = &candidate.declaration
                else {
                    return None;
                };
                if name != event
                    || !candidate.target.registry_backed
                    || !candidate.target.prepended.is_empty()
                {
                    return None;
                }
                let symbol = self
                    .registry
                    .get(&candidate.target.command)?
                    .defines_symbol?;
                (symbol.kind == tcl_registry::DefinedSymbolKind::Event)
                    .then_some(usize::from(symbol.name_arg) + 1)
            })
            .collect::<Option<Vec<_>>>()?;
        let &index = indices.first()?;
        if indices.iter().any(|candidate| *candidate != index) {
            return None;
        }
        let tokens = self.cmd_tokens(seg);
        let words = crate::registry_invocation::original_native_compiler_words(
            image,
            &tokens.word_exprs,
            seg.span.start(),
            self.config,
        )?;
        let word = words.get(index)?;
        if let Some(context) = self.invocation_metadata_context()
            && context
                .source_analysis_input()
                .is_some_and(crate::analyser::ResolvedAnalysisInput::has_hosted_source_name_context)
        {
            let input = context.source_analysis_input()?;
            let owner = bindings.original_analysis_owner()?;
            let root = bindings.source_origin()?;
            let binding = tokens.source_binding.as_ref()?;
            let site = binding.invocation_site()?;
            if tokens.synthetic.is_some()
                || !tokens.original_words_match_argv_text()
                || words.iter().any(|word| word.group().expand)
                || site.offset != seg.span.start()
                || !std::sync::Arc::ptr_eq(&site.source, root)
                || !owner.matches(bindings, input)
                || bindings.source_origin()?.source_image() != image
                || input.lexer_config() != self.config
                || !context.matches_registry(self.registry)
            {
                return None;
            }
            // The retained declaration owns source geometry, not a current
            // dispatch cell or installation of this event handler.
            let policy = input.vendor_source_policy().or_else(|| {
                let hosted = tcl_dialect::model::bigip_execution_context::BigIpExecutionContext::for_environment(
                    &input.borrowed_context_registry().context().environment.id,
                )?;
                tcl_syntax::naming::VendorSourceNamePolicy::authored(hosted)
            })?;
            let head =
                crate::signature_scan::vendor_name::VendorSourceNameInput::from_original_word(
                    words.first()?,
                    policy,
                );
            let written = std::str::from_utf8(
                head.literal_units(tcl_syntax::naming::VendorSourceNamePurpose::CommandHead)?,
            )
            .ok()?;
            let command = tcl_syntax::naming::unroot_rooted_key(written).unwrap_or(written);
            if candidates
                .iter()
                .any(|candidate| candidate.target.command != command)
            {
                return None;
            }
            let input =
                crate::signature_scan::vendor_name::VendorSourceNameInput::from_original_word(
                    word, policy,
                );
            let literal =
                input.literal_units(tcl_syntax::naming::VendorSourceNamePurpose::EventName)?;
            return literal
                .eq_ignore_ascii_case(event.as_bytes())
                .then(|| word.clone());
        }
        let dialect = self.invocation_dialect?;
        let key = crate::signature_scan::scope::SignatureSourceNameKey::from_original_native_word(
            word,
            dialect.word_values,
            dialect.authored_name_policy()?,
        )?;
        key.bytes()
            .eq_ignore_ascii_case(event.as_bytes())
            .then(|| word.clone())
    }

    fn original_when_source_geometry(
        &self,
        seg: &SegmentedCommand,
        event: &str,
    ) -> (tcl_lexer::SourceImage, Option<tcl_lexer::NativeWord>) {
        let image = self
            .source_bindings
            .as_ref()
            .map(|bindings| bindings.invocation_at_source(seg.name(), seg.span.start()))
            .and_then(|binding| {
                binding
                    .invocation_site()
                    .map(|site| site.source.source_image().clone())
            })
            .unwrap_or_else(|| {
                tcl_lexer::SourceImage::from_bytes(self.source.as_bytes(), self.source_channel)
            });
        let word = self.original_when_event_word(seg, event, &image);
        (image, word)
    }

    /// Lower a registry-validated iRules event declaration.
    fn lower_when(
        &mut self,
        seg: &SegmentedCommand,
        namespace: &str,
        event_name: &str,
        body_idx: usize,
        priority: Option<u16>,
    ) -> Statement {
        if self.compilation_scope == tcl_runtime_api::SourceCompilationScope::EnteredSource {
            return self.lower_default(seg, namespace);
        }
        let args = seg.args();
        let body_tok = seg.arg_tokens()[body_idx];
        let retained = self
            .source_bindings
            .as_ref()
            .and_then(|bindings| bindings.deferred_rule_declaration_candidates(seg.span.start()))
            .and_then(|candidates| {
                candidates
                    .iter()
                    .find_map(|candidate| candidate.body.clone())
            });
        let body = self.in_procedure_frame(Some(IrulesExecutionContext::EventBody), |lowerer| {
            if let Some(source) = retained {
                lowerer.lower_retained_script(source)
            } else {
                lowerer.lower_body_from_tok(&args[body_idx], Some(&body_tok), namespace)
            }
        });
        let body_offset = body_tok.span.start() + u32::from(body_tok.content_offset);

        let base_priority = u32::from(priority.unwrap_or(self.irules_priority));

        let n = self.when_counts.get(event_name).copied().unwrap_or(0);
        *self.when_counts.entry(event_name.to_owned()).or_insert(0) += 1;
        let qualified = if n == 0 {
            format!("::when::{event_name}")
        } else {
            format!("::when::{event_name}#{n}")
        };

        let (image, event_word) = self.original_when_source_geometry(seg, event_name);
        let event_body = std::sync::Arc::new(crate::ir::SourceIrulesEventBody::from_lowering(
            event_name,
            seg.span,
            &body,
            image,
            self.config,
            self.registry,
            event_word,
        ));
        let id = self.module.retain_procedure(Procedure {
            name: event_name.to_owned(),
            qualified_name: qualified,
            publication: None,
            declaration_site: self
                .cmd_tokens(seg)
                .source_binding
                .as_ref()
                .and_then(|binding| binding.invocation_site())
                .cloned(),
            body_kind: crate::ir::ProcedureBodyKind::Event,
            params: vec![],
            span: seg.span,
            body,
            params_raw: String::new(),
            body_source: None,
            body_offset,
            namespace_scoped: false,
            base_priority,
        });
        self.module.irules_event_bodies.insert(id, event_body);

        Statement::Call {
            span: seg.span,
            command: "when".into(),
            canonical_command: None,
            args: args.to_vec(),
            defs: vec![],
            reads: vec![],
            reads_own_defs: false,
            safe_on_uninit: false,
            tokens: Some(self.cmd_tokens(seg)),
            foreach_groups: None,
        }
    }

    /// Lower `namespace eval ns body`.
    /// Try to lower `uplevel ?level? {body}` to a static-body
    /// [`Statement::UpFrame`] when:
    ///
    /// 1. The body argument is a brace-string token (`TokenType::Str`),
    ///    and
    /// 2. The level argument (if present) parses as a positive integer
    ///    or `#0` / `#N` global form.
    ///
    /// Returns `None` if the call doesn't match the static shape, in
    /// which case the caller falls back to [`Self::lower_default`]
    /// (producing a runtime [`Statement::Barrier`]).
    fn try_lower_uplevel_static(
        &mut self,
        seg: &SegmentedCommand,
        namespace: &str,
    ) -> Option<Statement> {
        use tcl_lexer::TokenType;

        // Static-body `uplevel` lowers to `Statement::UpFrame` so the analysers
        // (interproc purity, code-sinking, var-escape, the inline_uplevel pass)
        // see a structured frame-shift with a lowered body instead of an opaque
        // runtime barrier. Runtime correctness is preserved at codegen: a
        // surviving `UpFrame` re-emits the original `uplevel <level> {body}`
        // invoke from its preserved command tokens (see
        // `codegen::statements`), producing byte-identical bytecode to the old
        // barrier path and dispatching through the `uplevel` builtin's correct
        // frame semantics. The whole-callee inline_uplevel splice (which would
        // need frame-shift opcodes to run a *bare* UpFrame against the right
        // activation) is an opt-in optimiser pass, not wired into codegen.
        let args = seg.args();
        let arg_tokens = seg.arg_tokens();
        let (level, body_tok_idx) = match args.len() {
            // A bare `uplevel {body}` means relative level 1.
            1 => (
                UplevelLevel {
                    shift: 1,
                    absolute: false,
                },
                0,
            ),
            2 => (parse_uplevel_level(&args[0])?, 1),
            _ => return None,
        };
        let body_tok = arg_tokens.get(body_tok_idx)?;
        // Barrier gate: see `try_lower_eval_static` for the
        // rationale.  A static-body `uplevel 1 {eval $x}` would
        // relax to inline IR with a still-dynamic `eval`; reject.
        if body_tok.kind == TokenType::Str {
            let body_text = &args[body_tok_idx];
            if body_has_dynamic_barrier(body_text, self.registry, self.config) {
                return None;
            }
        }
        let body_namespace = match (level.absolute, level.shift) {
            (true, 0) => "::",
            // A non-zero relative frame is selected only at runtime. Keep the
            // lexical fallback for lowering; ExecutionNamespace later marks
            // the body runtime-selected and invalidates relative typed proof.
            _ => namespace,
        };
        let body = if body_tok.kind == TokenType::Str {
            self.lower_body_from_tok(&args[body_tok_idx], Some(body_tok), body_namespace)
        } else if body_tok.kind == TokenType::Var {
            // Retain the original Native argument or quiet Logical source value.
            let literal = self
                .original_native_written_argument_value(seg, body_tok_idx)
                .or_else(|| self.const_map_lookup(&args[body_tok_idx]))?;
            self.lower_script(
                &literal,
                body_namespace,
                SourceSegmentationPurpose::NestedScript,
            )
        } else {
            return None;
        };
        Some(Statement::UpFrame {
            span: seg.span,
            frame_shift: level.shift,
            absolute: level.absolute,
            body,
            tokens: Some(self.cmd_tokens(seg)),
        })
    }

    /// If *`cmd_text`* is a call whose template-word plan
    /// (`docs/design/compiler/value-transfers.md` § *The template-word
    /// plan*) runs exactly [`SUBST_NOCOMMANDS_KINDS`] over a braced
    /// template AND every variable that template reads is in the current
    /// const-map, return the substituted string. Otherwise `None` so the
    /// caller falls back to runtime dispatch.
    ///
    /// Used to materialise the tcltest-style `Option` factory body
    /// at compile time when the surrounding proc has all the
    /// template vars const-tracked.
    ///
    /// The plan is the registry's answer over the call's literal words: any
    /// other set of kinds is a call this evaluator does not reproduce, and a
    /// computed switch word is no spelling a release accepts, so it folds
    /// nothing.
    fn eval_subst_nocommands_body(&self, cmd_text: &str) -> Option<String> {
        use tcl_lexer::TokenType;
        let inner = self.segment_source(cmd_text, 0, SourceSegmentationPurpose::NestedScript)?;
        let [inner_cmd] = inner.as_slice() else {
            return None;
        };
        let head = inner_cmd.texts.first()?;
        let texts = inner_cmd.args();
        let arg_refs: Vec<&str> = texts.iter().map(String::as_str).collect();
        // A braced word is one `Str` token; only it is a template this can
        // substitute at compile time.
        let source = |index: usize| {
            let braced = inner_cmd
                .single_token_word
                .get(index + 1)
                .copied()
                .unwrap_or(false)
                && inner_cmd
                    .arg_tokens()
                    .get(index)
                    .is_some_and(|token| token.kind == TokenType::Str);
            crate::value_transfer::SourceWord::of(arg_refs.get(index).copied(), braced)
        };
        let plan =
            crate::value_transfer::literal_template_plan(self.registry, head, &arg_refs, source)?;
        if plan.kinds != SUBST_NOCOMMANDS_KINDS || self.proc_depth == 0 {
            return None;
        }
        let template = arg_refs.get(plan.operand.0)?;
        let scope = self.const_map_stack.last()?;
        crate::subst_nocommands::subst_nocommands(template, &plan, scope)
    }

    /// Try to lower `eval ?body?` to a static-body
    /// [`Statement::Block`] when the body is a brace-string literal,
    /// a const-mapped `$var`, or an `eval [list lit1 lit2 ...]`
    /// command-substitution shape. Returns `None` for dynamic
    /// bodies so the caller falls through to runtime barrier
    /// dispatch.
    fn try_lower_eval_static(
        &mut self,
        seg: &SegmentedCommand,
        namespace: &str,
        error_context: Option<tcl_registry::InlineBodyErrorContext>,
    ) -> Option<Statement> {
        use tcl_lexer::TokenType;
        let args = seg.args();
        let arg_tokens = seg.arg_tokens();
        // Single-body shape only: ``eval $body`` / ``eval {body}``.
        // The list form (``eval cmd arg1 arg2``) keeps runtime
        // semantics — joining the words with spaces is observable.
        if args.len() != 1 || arg_tokens.is_empty() {
            return None;
        }
        let body_tok = arg_tokens[0];
        // Barrier gate: a braced literal body might contain a
        // nested ``eval $x`` / ``uplevel $lvl {...}`` whose own body
        // is still dynamic.  Relaxing the outer barrier in that case
        // produces IR that runs a compiled inner barrier with a
        // still-dynamic shape — we'd lose the runtime barrier without
        // gaining static knowledge.  Reject and fall back to the
        // default Statement::Barrier dispatch.
        if body_tok.kind == TokenType::Str {
            let body_text = &args[0];
            if body_has_dynamic_barrier(body_text, self.registry, self.config) {
                return None;
            }
            // Parse gate: inlining lowers the body with the LSP-lenient
            // lowering, which gives malformed text a meaning C never gives it
            // — `eval {set y "a"b}` would quietly mean `set y ab` instead of
            // raising `extra characters after close-quote` (#1829).  C parses
            // an `eval` body when the command runs, so decline the relaxation
            // and fall back to the runtime barrier, which is the path a
            // non-literal `eval $body` already takes and which reports the
            // error correctly.
            if !matches!(
                tcl_lexer::first_parse_cut_image_checked(
                    &tcl_lexer::SourceImage::from_bytes(
                        self.guarded_body_text(body_tok, body_text).as_bytes(),
                        self.current_source_channel()
                    ),
                    self.config.nested()
                ),
                Ok(None)
            ) {
                return None;
            }
        }
        let body = if body_tok.kind == TokenType::Str {
            self.lower_body_from_tok(&args[0], Some(&body_tok), namespace)
        } else if body_tok.kind == TokenType::Var {
            // The script `eval` evaluates at run time is a unit of its own
            // (8.4 runs it directly), which creates no locals and reaches only
            // those the procedure compiled (`TclFindCompiledLocal`), and whose
            // errors name its own commands; folded into the body it would
            // create them and be logged as the body's text. Analysis keeps the
            // structure it can see.
            if self.target.is_bytecode() {
                return None;
            }
            let literal = self
                .original_native_written_argument_value(seg, 0)
                .or_else(|| self.const_map_lookup(&args[0]))?;
            if body_has_dynamic_barrier(&literal, self.registry, self.config) {
                return None;
            }
            self.lower_script(&literal, namespace, SourceSegmentationPurpose::NestedScript)
        } else if body_tok.kind == TokenType::Cmd {
            // ``eval [list lit1 lit2 ...]`` — synthesise the
            // body by joining the list's literal arguments and
            // re-lowering. The bracket-substitution text retains
            // the surrounding ``[...]``; strip them via
            // ``content_offset`` if present, otherwise the helper
            // strips them itself.
            let inner_text = if body_tok.content_offset > 0 {
                let start = u32::from(body_tok.content_offset) as usize;
                &args[0][start..args[0].len() - start]
            } else {
                args[0].trim_start_matches('[').trim_end_matches(']')
            };
            let synthesised = eval_list_literal_body(inner_text, self.config)?;
            // `eval` runs the list as one command without compiling it; a word
            // the release compiles apart stays with the runtime `eval`.
            let release = self
                .dialect
                .map_or(tcl_dialect::TclVersion::V9_0, |profile| {
                    profile.vm_runtime_version
                });
            if crate::const_subst::folded_literal_reads_apart(&synthesised, release) {
                return None;
            }
            self.lower_script(
                &synthesised,
                namespace,
                SourceSegmentationPurpose::NestedScript,
            )
        } else {
            return None;
        };
        Some(Statement::Block {
            span: seg.span,
            body,
            namespace: namespace.to_string(),
            tokens: Some(self.cmd_tokens(seg)),
            error_context,
        })
    }

    /// Retain a synthetic analysis body under its issued Module ID.
    /// Labels are displays; the body retains its own namespace/source receipt.
    /// Lambda parameters bind a fresh frame, while namespace bodies do not.
    fn register_body_unit(
        &mut self,
        label: &str,
        params: Vec<String>,
        span: tcl_lexer::Span,
        body: Script,
        is_lambda: bool,
    ) {
        let n = self.body_unit_count;
        self.body_unit_count += 1;
        let prefix = tcl_syntax::naming::unroot_rooted_key(label).unwrap_or(label);
        let qualified = tcl_syntax::naming::root_unrooted_key(&format!("{prefix}#{n}"));
        let short_name = tcl_syntax::naming::key_tail(label).to_owned();
        let id = self.module.retain_body_unit(Procedure {
            name: short_name,
            qualified_name: qualified,
            publication: None,
            declaration_site: body.executed_source.as_ref().map(|source| {
                crate::command_binding::CommandAllocationSite {
                    source: std::sync::Arc::clone(&source.origin),
                    offset: source.base(),
                }
            }),
            body_kind: if is_lambda {
                crate::ir::ProcedureBodyKind::Lambda
            } else {
                crate::ir::ProcedureBodyKind::NamespaceScript
            },
            params,
            span,
            body,
            params_raw: String::new(),
            body_source: None,
            body_offset: 0,
            namespace_scoped: false,
            base_priority: 500,
        });
        if is_lambda {
            self.module.lambda_body_units.insert(id);
        }
    }

    fn lower_apply(&mut self, seg: &SegmentedCommand) -> Statement {
        let args = seg.args();
        let arg_tokens = seg.arg_tokens();

        let tokens = self.cmd_tokens(seg);
        let selected = self
            .resolved_metadata_invocation(&tokens)
            .and_then(|invocation| {
                let dialect = invocation.dialect?;
                let values = (0..invocation.arguments.len())
                    .map(|index| invocation.argument_literal(index))
                    .collect::<Vec<_>>();
                let words = values
                    .iter()
                    .map(|value| {
                        value.as_deref().map_or(
                            tcl_registry::InvocationWord::Dynamic,
                            tcl_registry::InvocationWord::Literal,
                        )
                    })
                    .collect::<Vec<_>>();
                let arguments =
                    tcl_registry::InvocationArguments::structured(&words).with_dialect(dialect);
                let tcl_registry::lambda_invocation::LambdaInvocationSelection::Selected(lambda) =
                    tcl_registry::lambda_invocation::select_lambda_invocation(arguments, 0)
                else {
                    return None;
                };
                let parameters = tcl_syntax::formal_params::parse_formal_parameters_in(
                    &lambda.parameters,
                    dialect.parameter_grammar()?,
                )
                .ok()?
                .into_iter()
                .map(|parameter| parameter.name)
                .collect();
                let source = self
                    .source_bindings
                    .as_ref()?
                    .executed_script_for_list_element(arg_tokens.first()?.span, 1)?
                    .clone();
                let namespace = self.original_body_namespace_context(&tokens, 0, &source);
                Some((lambda, parameters, source, namespace))
            });

        if let Some((lambda, params, source, namespace)) = selected {
            let body_offset = source.base();
            let body_length = source.text.len();
            let body_ns = join_namespace("::", &lambda.namespace);
            let body = self.in_procedure_frame(None, |lowerer| {
                lowerer.lower_original_body(source, namespace.as_ref())
            });

            // A body defined inside a TclOO method body is not registered
            // globally (`suppress_proc_register`), but a body unit is
            // analysis-only (never codegen-emitted), so it is always safe to
            // record for coverage.
            let span = tcl_lexer::Span::new(
                body_offset,
                body_offset + u32::try_from(body_length).unwrap_or(u32::MAX),
            );
            // The body retains its own lambda namespace; the label is a display.
            // tclsh8.6/9.0-confirmed: inside
            // `::foo::runIt`, `apply {{x} { helper $x } ::foo} b` calls
            // `::foo::helper`, not `::helper`.
            self.register_body_unit(&join_namespace(&body_ns, "apply"), params, span, body, true);
        }

        Statement::Barrier {
            span: seg.span,
            reason: "unsupported body command".into(),
            command: seg.name().into(),
            canonical_command: None,
            args: args.to_vec(),
            tokens: Some(self.cmd_tokens(seg)),
        }
    }

    /// `array for {keyVar valueVar} arrayName body` (Tcl 9.0).
    ///
    /// The body runs in the caller's frame with the two loop variables bound
    /// per entry. C Tcl compiles this to an `invokeStk` of `::tcl::array::for`
    /// with the body pushed as an unparsed literal — it does not compile the
    /// body — so, exactly like [`Self::lower_apply`], the call itself stays a
    /// runtime [`Statement::Barrier`] (codegen unchanged, byte-identical to C
    /// Tcl). But a braced literal body is walked in a fresh frame bound to the
    /// loop variables and recorded as a body unit so static analysis reaches
    /// inside it. A `$var` / `[cmd]` body stays fully opaque.
    fn lower_array_for(&mut self, seg: &SegmentedCommand, namespace: &str) -> Statement {
        use tcl_lexer::TokenType;
        let args = seg.args();
        let arg_tokens = seg.arg_tokens();
        let arg_single = seg.arg_single_token();

        // `array for {k v} arr body` → args = [for, {k v}, arr, body].
        // The body (index 3) must be a single braced-literal token to walk.
        let body_is_braced = arg_tokens.get(3).is_some_and(|t| t.kind == TokenType::Str)
            && arg_single.get(3).copied() == Some(true);
        // A varList Tcl would refuse to split binds nothing statically, so it
        // falls through to the opaque runtime barrier below. Decided before the
        // body is walked, so a rejected loop leaves no const-map traces behind.
        if args.len() == 4
            && body_is_braced
            && let Some(vars) = crate::registry_invocation::original_name_role_values(
                self.registry,
                &self.cmd_tokens(seg),
                1,
                tcl_registry::ArgRole::LoopVarList,
            )
        {
            let body_tok = &arg_tokens[3];
            // The body runs in the *caller's* frame (`vm.eval_source` in place),
            // so lower it inline — inheriting the caller's const-map — into a
            // loop-variable-bound `Foreach` rather than isolating it in a
            // fresh-frame body unit. The analysis CFG inlines this into the
            // caller unit (so a body `$re` resolves to a caller literal for
            // regex-source / taint), while codegen barriers it to the byte-
            // identical `::tcl::array::for` invoke — see `lower_foreach_dispatch`.
            let body = self.lower_body_from_tok(&args[3], Some(body_tok), namespace);
            return Statement::Foreach {
                span: seg.span,
                iterators: vec![ForeachIterator {
                    vars,
                    list_arg: args[2].clone(),
                    // `array for {k v} {arr} …` — a braced array-name word
                    // is a literal name, not a substitution.
                    list_braced: self.cmd_tokens(seg).arg_is_braced_literal(2),
                }],
                body,
                body_span: self.script_word_span(body_tok),
                is_lmap: false,
                raw_args: args.to_vec(),
                is_dict_iteration: false,
                is_array_iteration: true,
                raw_tokens: Some(self.cmd_tokens(seg)),
            };
        }

        // A dynamic (`$body` / `[cmd]`) body stays fully opaque: the runtime
        // barrier re-emits `array for …`.
        self.lower_default(seg, namespace)
    }

    fn lower_namespace_eval(&mut self, seg: &SegmentedCommand, namespace: &str) -> Statement {
        // The body is walked from its *written* spelling, rebased by the body
        // word's own content offset, so the word must not substitute.
        // A `$body` / `[list …]` word's value is run-time data
        // that appears nowhere in this document: rebasing its unsubstituted
        // spelling fabricates statement spans that overrun the source —
        // `namespace eval ::ns [list $o fw]` rebases the whole `[list $o fw]`
        // text past the opening `[`, one byte off the end.
        // [`Self::guarded_body_text`] deliberately passes such words through
        // untouched because clamping run-time data proves nothing; refusing to
        // walk them is the caller-side half of that contract.  The namespace is
        // still entered at run time — the `Barrier` below re-emits the call —
        // the body just stays opaque to static analysis, exactly as
        // [`Self::lower_apply`] and [`Self::lower_array_for`] leave a dynamic
        // body opaque.
        if !seg_word_substitutes(seg, 3) {
            self.walk_namespace_eval_body(seg, namespace);
        }

        Statement::Barrier {
            span: seg.span,
            reason: "namespace eval".into(),
            command: "namespace".into(),
            canonical_command: None,
            args: seg.args().to_vec(),
            tokens: Some(self.cmd_tokens(seg)),
        }
    }

    /// A generic namespace handler can retain entered declarations while its
    /// original invocation remains generic. The exact source carrier supplies
    /// the body; no lexical fallback or executable hook is inferred here.
    fn retain_entered_namespace_body(
        &mut self,
        seg: &SegmentedCommand,
        namespace: &str,
        tokens: &CommandTokens,
    ) {
        if self.compilation_scope == tcl_runtime_api::SourceCompilationScope::EnteredSource {
            return;
        }
        let Some(invocation) = self.resolved_metadata_invocation(tokens) else {
            return;
        };
        if invocation.facts.operation
            != tcl_registry::SemanticOperationId::StructuredLowering(LoweringHookId::NamespaceEval)
            || tokens
                .source_binding
                .as_ref()
                .and_then(|binding| binding.proved_execution_target())
                .is_none_or(|target| !target.prepended.is_empty())
        {
            return;
        }
        let name_at = invocation.facts.argument_offset;
        let body_at = name_at + 1;
        if seg.args().len() != body_at + 1 {
            return;
        }
        let Some(child) = invocation.argument_literal(name_at) else {
            return;
        };
        let Some(token) = seg.arg_tokens().get(body_at) else {
            return;
        };
        let Some(source) = self
            .source_bindings
            .as_ref()
            .and_then(|bindings| bindings.executed_script_for_word(token.span))
            .cloned()
        else {
            return;
        };
        let child_namespace = join_namespace(namespace, &child);
        let body_span = tcl_lexer::Span::new(
            source.base(),
            source.base() + u32::try_from(source.text.len()).unwrap_or(u32::MAX),
        );
        let previous = self.in_namespace_eval;
        self.in_namespace_eval = true;
        let namespace = self.original_body_namespace_context(tokens, body_at, &source);
        let body = self.lower_original_body(source, namespace.as_ref());
        self.in_namespace_eval = previous;
        self.register_body_unit(
            &join_namespace(&child_namespace, "namespace-eval"),
            vec![],
            body_span,
            body,
            false,
        );
    }

    /// Walk a `namespace eval` body inline and record it as a body unit.
    ///
    /// Only reached for a body word that does not substitute — see
    /// [`Self::lower_namespace_eval`] for why.
    fn walk_namespace_eval_body(&mut self, seg: &SegmentedCommand, namespace: &str) {
        let args = seg.args();
        let child_ns = join_namespace(namespace, &args[1]);
        let body_tok = seg.arg_tokens()[2];
        // `namespace eval` inlines whatever literal body word it is given,
        // including a compound `{…}x` one, so the rebase below needs the
        // clamp in [`Self::guarded_body_text`] — both for the body itself and
        // for the body unit's span derived from its length.
        let body_text = self.guarded_body_text(body_tok, &args[2]);
        let body_offset = body_tok.span.start() + u32::from(body_tok.content_offset);
        let prev = self.in_namespace_eval;
        self.in_namespace_eval = true;
        let body = self.lower_body_from_tok(&args[2], Some(&body_tok), &child_ns);
        self.in_namespace_eval = prev;

        // A `namespace eval` body runs in the child namespace's own frame — its
        // straight-line statements are a real analysable script, so record them
        // as a body unit (no bound params: namespace vars, not locals).
        let span = tcl_lexer::Span::new(
            body_offset,
            body_offset + u32::try_from(body_text.len()).unwrap_or(u32::MAX),
        );
        // Original body context selects the child namespace; labels do not.
        // tclsh8.6-confirmed:
        // `namespace eval ::foo { helper }` calls `::foo::helper` even when
        // nested inside an unrelated proc, never a same-named proc in the
        // caller's own namespace.
        self.register_body_unit(
            &join_namespace(&child_ns, "namespace-eval"),
            vec![],
            span,
            body,
            false,
        );
    }

    /// Registry-resolved reads hidden inside the value word of a generic
    /// value-passthrough store.
    ///
    /// An alias/rename of `set` must remain a runtime [`Statement::Call`], but
    /// its one value word still has the same expression semantics as a direct
    /// `set`.  Capture those reads while the lowering alias map and resolved
    /// dialect context are live, rather than asking SSA to reconstruct command
    /// bindings from a flattened call later.
    fn nested_expr_reads_in_set_value(
        &self,
        seg: &SegmentedCommand,
        namespace: &str,
        resolved_command: &str,
        prepend_n: usize,
    ) -> Vec<String> {
        if prepend_n != 0
            || seg.args().len() != 2
            || !matches!(
                seg.argv.get(2).map(|token| token.kind),
                Some(TokenType::Cmd)
            )
            || !seg.single_token_word.get(2).copied().unwrap_or(false)
            || self
                .registry
                .get(resolved_command)
                .and_then(|spec| spec.lowering_hook)
                != Some(LoweringHookId::Set)
        {
            return Vec::new();
        }

        let value = &seg.args()[1];
        let inner = value
            .strip_prefix('[')
            .and_then(|text| text.strip_suffix(']'))
            .unwrap_or(value);
        let context = self
            .dialect_context
            .as_deref()
            .map(tcl_registry::model::ContextRegistry::context);
        let tokens = self.cmd_tokens(seg);
        let Some((_, _, expression, _)) = extract_proved_expr_arg(
            (Some(&tokens), 2),
            inner,
            &self.aliases,
            namespace,
            self.registry,
            context,
            self.config,
        ) else {
            return Vec::new();
        };
        parse_expr_for_profile_with_lexer_config(&expression, self.dialect, self.config)
            .vars_element_qualified_with_config(self.config)
            .into_iter()
            .collect()
    }

    fn retained_metadata_descriptor_label(&self, tokens: &CommandTokens) -> Option<String> {
        self.resolved_metadata_invocation(tokens)
            .map(|invocation| invocation.facts.descriptor_key().label().to_owned())
    }

    fn advisory_method_instance_names(&self, statement: &Statement) -> Vec<String> {
        let Statement::Call { args, tokens, .. } = statement else {
            return Vec::new();
        };
        let possible = tokens.as_ref().and_then(|tokens| {
            let context = self.invocation_metadata_context()?;
            let advice = crate::registry_invocation::original_registry_invocation_assistance_with_metadata_context(
                self.registry, Some(context), tokens,
            )?;
            if advice.unknown_residual || advice.may_be_absent || advice.candidates.is_empty() {
                return None;
            }
            let mut names = Vec::new();
            for candidate in &advice.candidates {
                names.extend(candidate.possible_method_instance_variable_names(
                    self.registry,
                    context,
                    tokens,
                )?);
            }
            Some(names)
        });
        // Unavailable source advice only widens the textual protection inventory.
        possible.unwrap_or_else(|| args.clone())
    }

    fn resolved_metadata_invocation(
        &self,
        tokens: &CommandTokens,
    ) -> Option<crate::registry_invocation::ResolvedStatementInvocation> {
        // Explicit standalone authoring has its own metadata context. An
        // unavailable supplied owner cannot enter the scalar compatibility API.
        match self.invocation_metadata_context() {
            Some(context) => {
                crate::registry_invocation::resolved_tokens_invocation_with_metadata_context(
                    self.registry,
                    Some(context),
                    tokens,
                )
            }
            None if self.allows_standalone_registry_metadata() => {
                crate::registry_invocation::resolved_tokens_invocation(self.registry, None, tokens)
            }
            None => None,
        }
    }

    fn allows_standalone_registry_metadata(&self) -> bool {
        self.source_entry_origin == SourceEntryOrigin::Authoring
            && self.metadata_origin == LoweringMetadataOrigin::Standalone
            && self.metadata_input.is_none()
            && self.logical_source_input.is_none()
            && self.vendor_source_input.is_none()
            && self.dialect_context.is_none()
    }

    fn source_metadata_input(&self) -> crate::registry_invocation::InvocationMetadataInput<'_> {
        use crate::registry_invocation::InvocationMetadataInput;
        if let Some(input) = self
            .metadata_input
            .as_ref()
            .or(self.logical_source_input.as_ref())
            .or(self.vendor_source_input.as_ref())
        {
            return InvocationMetadataInput::SuppliedSource(Some(input));
        }
        if let Some(context) = self.dialect_context.as_ref() {
            return InvocationMetadataInput::Supplied(context);
        }
        if self.allows_standalone_registry_metadata() {
            InvocationMetadataInput::Standalone
        } else {
            InvocationMetadataInput::SuppliedSource(None)
        }
    }

    fn invocation_metadata_context(
        &self,
    ) -> Option<crate::registry_invocation::InvocationMetadataContext<'_>> {
        if let Some(input) = self
            .metadata_input
            .as_ref()
            .or(self.logical_source_input.as_ref())
            .or(self.vendor_source_input.as_ref())
        {
            return crate::registry_invocation::InvocationMetadataContext::for_source_input(
                self.registry,
                input,
                self.config,
                self.dialect,
            );
        }
        match self.dialect_context.as_deref() {
            Some(context) => Some(context.into()),
            None if self.allows_standalone_registry_metadata() => self
                .dialect
                .or_else(|| self.registry.profile())
                .map(tcl_registry::model::semantic::SemanticContext::for_profile)
                .map(crate::registry_invocation::InvocationMetadataContext::from),
            None => None,
        }
    }

    /// Default lowering: generic [`Statement::Call`] with registry-based
    /// arg roles.
    // The generic path deliberately assembles every registry-owned call fact
    // in one place so consumers never need per-command recovery logic.
    #[allow(clippy::too_many_lines)]
    fn lower_default(&mut self, seg: &SegmentedCommand, namespace: &str) -> Statement {
        let cmd_name = seg.name();
        let args = seg.args();

        let original_tokens = self.cmd_tokens(seg);
        let tokens = self.attach_evaluated_body(seg, namespace, original_tokens);
        let Some(target) = tokens
            .source_binding
            .as_ref()
            .and_then(|binding| binding.proved_execution_target())
            .filter(|target| target.registry_backed)
        else {
            return source_body_syntax::generic_call(seg.span, cmd_name, args, Some(tokens));
        };
        let Some(role_cmd) = self.retained_metadata_descriptor_label(&tokens) else {
            return Statement::Call {
                span: seg.span,
                command: cmd_name.into(),
                canonical_command: None,
                args: args.to_vec(),
                defs: vec![],
                reads: vec![],
                reads_own_defs: false,
                safe_on_uninit: false,
                tokens: Some(tokens),
                foreach_groups: None,
            };
        };
        let prepend_n = target.prepended.len();
        let Some(prefix): Option<Vec<String>> = target
            .prepended
            .iter()
            .map(|word| match word {
                crate::registry_invocation::EffectiveInvocationWord::Literal(value) => {
                    Some(value.clone())
                }
                _ => None,
            })
            .collect()
        else {
            // A retained alias operand still contributes one argv slot when
            // its value is unknown. Presentation text must never license
            // specialised lowering or move the remaining operand positions.
            return Statement::Call {
                span: seg.span,
                command: cmd_name.into(),
                canonical_command: Some(role_cmd),
                args: args.to_vec(),
                defs: vec![],
                reads: vec![],
                reads_own_defs: false,
                safe_on_uninit: false,
                tokens: Some(tokens),
                foreach_groups: None,
            };
        };
        let role_args: Vec<String> = prefix.into_iter().chain(args.iter().cloned()).collect();
        let canonical = (role_cmd != cmd_name).then(|| role_cmd.clone());

        let context = self.invocation_metadata_context();
        let invocation = context.and_then(|context| {
            crate::registry_invocation::resolved_tokens_invocation_with_metadata_context(
                self.registry,
                Some(context),
                &tokens,
            )
        });
        let facts = invocation.as_ref().map(|invocation| &invocation.facts);
        let realm = tokens
            .source_binding
            .as_ref()
            .and_then(crate::command_binding::SourceInvocationBinding::invocation_realm)
            .unwrap_or(self.invocation_realm);
        let role_indices = |role| {
            facts.as_ref().map_or_else(Vec::new, |facts| {
                facts
                    .arg_roles
                    .iter()
                    .filter_map(|&(index, found)| {
                        (found == role).then_some(facts.argument_offset + usize::from(index))
                    })
                    .collect()
            })
        };
        let mut executable_indices = role_indices(ArgRole::Body);
        for role in [ArgRole::LambdaLiteral, ArgRole::CommandPrefix] {
            executable_indices.extend(role_indices(role));
        }
        executable_indices.sort_unstable();
        executable_indices.dedup();
        // Incomplete dynamic option/argument resolution cannot establish a
        // strong definition. The shared place owner retains the uncertainty.
        let var_indices = if facts.as_ref().is_none_or(|facts| {
            !facts.arg_roles_complete
                || facts.frame_effect.is_some_and(|effect| {
                    effect.layout == tcl_registry::frame_effect::FrameArgLayout::AliasPairs
                })
        }) {
            Vec::new()
        } else {
            role_indices(ArgRole::VarWrite)
        };
        let var_read_indices = role_indices(ArgRole::VarRead);
        let reads_before_write = facts.as_ref().is_some_and(|facts| {
            facts
                .traits
                .contains(tcl_registry::Traits::READS_BEFORE_WRITE)
        });

        // A stored callback is data for this invocation, not executable code
        // that can complete or mutate the caller before the command returns.
        // Every live Body, LambdaLiteral, or CommandPrefix whose exact timing
        // is SameInvocation needs the opaque runtime barrier. This is checked
        // per index because one invocation may mix immediate and deferred code.
        let has_same_invocation_executable = executable_indices.iter().any(|&index| {
            invocation
                .as_ref()
                .and_then(|invocation| {
                    invocation.with_metadata_schema(self.registry, context?, realm, |selected| {
                        selected.authored_source_script_timing_at(index)
                    })
                })
                .is_none_or(|timing| timing == tcl_registry::ScriptTiming::SameInvocation)
        });
        if has_same_invocation_executable && tokens.evaluated_body().is_none() {
            return Statement::Barrier {
                span: seg.span,
                reason: "unsupported body command".into(),
                command: cmd_name.into(),
                canonical_command: canonical.clone(),
                args: args.to_vec(),
                tokens: Some(tokens.clone()),
            };
        }

        if !var_indices.is_empty() || !var_read_indices.is_empty() {
            // A brace-quoted name word (`set {$n} 1`, `unset {$n}`) is Tcl's
            // literal spelling for a name that contains `$` / `[`: it
            // substitutes nothing, so the word's content **is** the variable
            // name. The de-braced `args` text cannot show that;
            // the word's own token kind can.
            let variable_at = |index: usize| -> Option<String> {
                let invocation = invocation.as_ref()?;
                let effective = &invocation.effective;
                let word = effective.words.get(index + 1)?;
                let value = invocation.argument_literal(index)?;
                let braced = matches!(word, crate::ir::WordExpr::BracedLiteral { .. })
                    || effective.written_argument(index).is_none();
                let name = crate::naming::element_var_name_braced(&value, braced);
                if invocation.with_metadata_schema(self.registry, context?, realm, |selected| {
                    selected.authored_source_option_variable_scope_at(index)
                }) == Some(tcl_registry::VariableScope::Global)
                    && !name.starts_with("::")
                {
                    Some(format!("::{name}"))
                } else {
                    Some(name.to_owned())
                }
            };
            let var_defs: Vec<String> = var_indices
                .iter()
                .filter_map(|&index| variable_at(index))
                .collect();
            let mut var_reads: Vec<String> = var_read_indices
                .iter()
                .filter_map(|&index| variable_at(index))
                .collect();
            let nested_expr_reads =
                self.nested_expr_reads_in_set_value(seg, namespace, &role_cmd, prepend_n);
            var_reads.extend(nested_expr_reads);
            let reads_own_defs = reads_before_write
                || var_reads
                    .iter()
                    .any(|read| var_defs.iter().any(|definition| definition == read));
            return Statement::Call {
                span: seg.span,
                command: cmd_name.into(),
                canonical_command: canonical.clone(),
                args: args.to_vec(),
                defs: var_defs,
                reads: var_reads,
                reads_own_defs,
                safe_on_uninit: self.safe_on_uninit(&role_cmd, &role_args),
                tokens: Some(tokens.clone()),
                foreach_groups: None,
            };
        }

        Statement::Call {
            span: seg.span,
            command: cmd_name.into(),
            canonical_command: canonical,
            args: args.to_vec(),
            defs: vec![],
            reads: vec![],
            reads_own_defs: false,
            safe_on_uninit: false,
            tokens: Some(tokens.clone()),
            foreach_groups: None,
        }
    }

    // TclOO method-body lowering (method purity for O126)

    /// Populate `module.methods` from the fully-assembled IR.
    ///
    /// Runs as a cache-independent post-pass (mirroring
    /// [`populate_trace_facts`]): clone the top-level script and proc
    /// bodies, then walk them — plus any `namespace eval` blocks — for
    /// `oo::class create` / `oo::define` barriers and lift each
    /// `method` / `constructor` / `destructor` body to an
    /// [`MethodDef`]. Method bodies are lowered for analysis only —
    /// codegen never reads `module.methods`, and the barrier emitted
    /// for the class command is unchanged, so bytecode is
    /// byte-identical.
    pub fn extract_oo_methods_pass(&mut self) {
        let retained = self.module_source_bindings.take();
        let enclosing = self.exchange_boxed_source_bindings(retained);
        // The walk borrows each script out of the module rather than cloning
        // it: the derived `Clone` of cap-deep structured IR recurses several
        // frames per nesting level, which overflowed a 2 MiB thread at the
        // structured-lowering depth cap. No member extraction reads these
        // scripts back from the module.
        let top_level = std::mem::take(&mut self.module.top_level);
        let top_namespace = if self.module.top_level_namespace.is_empty() {
            "::".to_owned()
        } else {
            self.module.top_level_namespace.clone()
        };
        self.walk_for_oo_methods(&top_level.statements, &top_namespace);
        self.module.top_level = top_level;
        let procs: Vec<(crate::ir::ProcedureId, String)> = self
            .module
            .procedures
            .iter()
            .filter_map(|(id, p)| Some((*id, p.body.namespace_context.as_deref()?.advisory_key()?)))
            .collect();
        for (id, namespace) in &procs {
            let Some(body) = self
                .module
                .procedures
                .get_mut(id)
                .map(|procedure| std::mem::take(&mut procedure.body))
            else {
                continue;
            };
            self.walk_for_oo_methods(&body.statements, namespace);
            if let Some(procedure) = self.module.procedures.get_mut(id) {
                procedure.body = body;
            }
        }
        // Every definition block for every class has now been walked, so the
        // per-class instance-variable union is complete.  Merge it into each
        // method: a method extracted from an early block must still see state
        // a later `oo::define` block declared for its class, or a consumer
        // reading `MethodDef::instance_vars` (the optimiser's method-body
        // propagation gate, `elimination.rs`'s dead-store protection) would
        // treat object state as a private local.  Order-free by construction —
        // the union does not depend on which block was walked first.
        for method in self.module.methods.values_mut() {
            if method.body.executed_source.is_none()
                && let Some(class_vars) = self.class_instance_vars.get(&method.class_name)
            {
                method.instance_vars.extend(class_vars.iter().cloned());
            }
        }
        self.module_source_bindings = self.exchange_boxed_source_bindings(enclosing);
    }

    /// Recursive walk for `oo::class` / `oo::define` definition
    /// barriers. Descends `namespace eval` blocks (tracking the active
    /// namespace) and extracts methods from any class/define command
    /// carrying a static braced body. The lowerer evaluates a
    /// `namespace eval` body inline and discards it (emitting a
    /// `Barrier`), so rather than descending a preserved block this
    /// walk re-segments the barrier's body token instead (see
    /// [`Self::walk_segments_for_oo`]).
    fn walk_for_oo_methods(&mut self, statements: &[Statement], namespace: &str) {
        for stmt in statements {
            match stmt {
                // Folded `eval` / `uplevel` bodies survive as Blocks.
                Statement::Block {
                    body,
                    namespace: block_ns,
                    ..
                } => {
                    let ns = if block_ns.is_empty() {
                        namespace
                    } else {
                        block_ns.as_str()
                    };
                    self.walk_for_oo_methods(&body.statements, ns);
                }
                Statement::Call {
                    tokens: Some(ct), ..
                }
                | Statement::Barrier {
                    tokens: Some(ct), ..
                } => {
                    if let Some(call) = self.classify_definer_call(ct) {
                        self.extract_definer_members(
                            call,
                            ct,
                            ct.argv[call.body_idx].start() + 1,
                            namespace,
                        );
                    } else if self.definer_invocation_may_supply_body(ct) {
                        self.module.oo_evidence.unretained_executable_roots = true;
                    } else if self.is_namespace_eval_shape(ct) {
                        // The body was lowered inline and discarded;
                        // re-segment it to find classes defined directly
                        // inside the namespace.
                        let child_ns = join_namespace(namespace, &ct.argv_texts[2]);
                        let body_off = ct.argv[3].start() + 1;
                        let Some(segments) = self.segment_source(
                            &ct.argv_texts[3],
                            body_off,
                            SourceSegmentationPurpose::NestedScript,
                        ) else {
                            self.module.oo_evidence.unretained_executable_roots = true;
                            continue;
                        };
                        self.walk_segments_for_oo(&segments, &child_ns);
                    }
                }
                _ => {}
            }
        }
    }

    /// Segment-level counterpart of [`Self::walk_for_oo_methods`] used
    /// for `namespace eval` bodies (which the lowerer discards). Walks
    /// re-segmented commands, recursing through nested `namespace eval`
    /// and extracting members from any registry-classified definer block.
    fn walk_segments_for_oo(&mut self, segments: &[SegmentedCommand], namespace: &str) {
        for seg in segments {
            if seg.texts.is_empty() {
                continue;
            }
            let tokens = self.cmd_tokens(seg);
            if seg.is_partial {
                if self.definer_invocation_may_supply_body(&tokens) {
                    self.module.oo_evidence.unretained_executable_roots = true;
                }
                continue;
            }
            if let Some(call) = self.classify_definer_call(&tokens) {
                let body = seg.argv[call.body_idx];
                let off = body.span.start() + u32::from(body.content_offset);
                self.extract_definer_members(call, &tokens, off, namespace);
            } else if self.definer_invocation_may_supply_body(&tokens) {
                self.module.oo_evidence.unretained_executable_roots = true;
            } else if self.is_namespace_eval_shape(&tokens) {
                let child_ns = join_namespace(namespace, &seg.texts[2]);
                let off = seg.argv[3].span.start() + u32::from(seg.argv[3].content_offset);
                let Some(sub) = self.segment_source(
                    &seg.texts[3],
                    off,
                    SourceSegmentationPurpose::NestedScript,
                ) else {
                    self.module.oo_evidence.unretained_executable_roots = true;
                    continue;
                };
                self.walk_segments_for_oo(&sub, &child_ns);
            }
        }
    }

    /// Retain each selected class-relation member with its authentic outer
    /// definer. Value formation and target selection belong to the source owner;
    /// punctuation in the written operand never determines ancestry here.
    fn record_class_relation_member(
        &mut self,
        call: &DefinerCall,
        definer: &CommandTokens,
        seg: &SegmentedCommand,
        class_qname: &str,
    ) -> bool {
        let head = seg.texts[0].as_str();
        let Some(member) = self.source_definition_member(call.grammar, head) else {
            return false;
        };
        if member.all_args_ref != Some(tcl_registry::definer::MemberRefKind::Class) {
            return false;
        }
        self.module.class_relations.push(crate::ir::ClassRelation {
            declaring_class: class_qname.to_owned(),
            definer: std::sync::Arc::new(definer.clone()),
            member: std::sync::Arc::new(self.cmd_tokens(seg)),
            target_word: call.name_idx,
            body_word: call.body_idx,
        });
        true
    }

    /// Retain each member's actual body ID, typed kind and declaring source owner.
    /// The selected [`DefinerCall::grammar`] supplies recognition and operand layout.
    ///
    /// `texts` is the definer command's full per-word text array;
    /// `body_content_offset` is the absolute source offset of the first
    /// byte inside the body's braces.
    fn extract_definer_members(
        &mut self,
        call: DefinerCall,
        definer: &CommandTokens,
        body_content_offset: u32,
        namespace: &str,
    ) {
        let call = DefinerCall {
            definition_scope: Some(self.module.retain_definition_script_source(
                definer,
                call.body_idx,
                call.name_idx,
                call.per_object,
                body_content_offset,
                call.grammar,
                call.descriptor,
                self.registry,
            )),
            ..call
        };
        let texts = &definer.argv_texts;
        let body_text = texts[call.body_idx].as_str();
        let target = definer
            .words()
            .first()
            .and_then(|head| head.original_written_span(self.module.source.bytes()))
            .and_then(|span| {
                crate::registry_invocation::original_native_compiler_words(
                    &self.module.source,
                    definer.words(),
                    span.start(),
                    self.config,
                )
            })
            .and_then(|words| {
                words
                    .get(call.name_idx)
                    .and_then(crate::registry_invocation::original_source_receiver_name_operand)
            })
            .filter(|target| match target {
                crate::registry_invocation::SourceReceiverNameOperand::Literal(name)
                | crate::registry_invocation::SourceReceiverNameOperand::ScalarVariable(name) => {
                    !name.as_bytes().contains(&0)
                }
            });
        let class_qname = match (call.per_object, target) {
            // This label reports per-object source units; definition IDs own their scope.
            (
                true,
                Some(
                    crate::registry_invocation::SourceReceiverNameOperand::Literal(name)
                    | crate::registry_invocation::SourceReceiverNameOperand::ScalarVariable(name),
                ),
            ) => format!("::@objdefine@::{name}"),
            (false, Some(crate::registry_invocation::SourceReceiverNameOperand::Literal(name))) => {
                qualify_proc_name(namespace, &name)
            }
            _ => {
                self.module.oo_evidence.dynamic_target = true;
                self.module.oo_evidence.unretained_executable_roots = true;
                return;
            }
        };
        let Some(segments) = self.segment_source(
            body_text,
            body_content_offset,
            SourceSegmentationPurpose::NestedScript,
        ) else {
            self.module.oo_evidence.unretained_executable_roots = true;
            return;
        };

        let surface = self
            .invocation_metadata_context()
            .map(|context| context.context().authoring_query());
        let class_ivars = declared_member_vars(call.grammar, &segments, surface, self.config);
        // This block sees only its own declarations; a sibling `oo::define`
        // block may declare more state for the same class, and may be walked
        // *after* the methods that use it.  Accumulate the whole-class union
        // for `extract_oo_methods_pass`'s merge — see
        // [`Self::class_instance_vars`].  A per-object block accumulates
        // under its own synthetic key, so per-object `variable` declarations
        // stay per-object by construction.
        if !class_ivars.is_empty() {
            self.class_instance_vars
                .entry(class_qname.clone())
                .or_default()
                .extend(class_ivars.iter().cloned());
        }

        self.extract_members_from_segments(
            &call,
            definer,
            &segments,
            &class_qname,
            &class_ivars,
            namespace,
        );
    }

    /// The per-segment member walk behind [`Self::extract_definer_members`],
    /// factored out so a wrapper's block form (`self { … }` /
    /// `private { … }`) can recurse into its nested definition script with
    /// the same class context.
    fn extract_members_from_segments(
        &mut self,
        call: &DefinerCall,
        definer: &CommandTokens,
        segments: &[SegmentedCommand],
        class_qname: &str,
        class_ivars: &HashSet<String>,
        namespace: &str,
    ) {
        for seg in segments {
            if seg.texts.is_empty() {
                continue;
            }
            let head = seg.texts[0].as_str();
            let member_supplies_body = self.member_invocation_supplies_body(call.grammar, seg);
            if seg.is_partial {
                self.module.oo_evidence.unretained_executable_roots |= member_supplies_body;
                continue;
            }
            if self.record_class_relation_member(call, definer, seg, class_qname) {
                continue;
            }
            let Some(member) = self.source_definition_member(call.grammar, head) else {
                // Definition scripts can call ordinary absolute commands (or
                // dynamically installed definition helpers). Their execution
                // is not represented by a MethodDef root.
                self.module.oo_evidence.unretained_executable_roots = true;
                continue;
            };
            // A wrapper member (`self …`, `private …`, itcl's access
            // modifiers) either prefixes an inner member (shift one place
            // right) or — for `wrapper_block_body` wrappers — carries a
            // whole nested definition script to recurse into.
            let (member, kw, base) = match member.kind {
                tcl_registry::definer::MemberKind::Wrapper => match seg.texts.get(1) {
                    Some(inner) if self.source_definition_member(call.grammar, inner).is_some() => {
                        let inner_member = self
                            .source_definition_member(call.grammar, inner)
                            .expect("selected source member");
                        // No double wrapping (`self private method …` is not
                        // a real Tcl shape).
                        if inner_member.kind != tcl_registry::definer::MemberKind::Flat {
                            self.module.oo_evidence.unretained_executable_roots |=
                                member_supplies_body;
                            continue;
                        }
                        (inner_member, inner.as_str(), 2usize)
                    }
                    Some(_)
                        if member.wrapper_block_body
                            && seg.texts.len() >= 2
                            && seg_word_is_static_braced(seg, 1) =>
                    {
                        // `self { … }` / `private { … }` — a nested
                        // definition script with the same member grammar.
                        let block_tok = seg.argv[1];
                        let off = block_tok.span.start() + u32::from(block_tok.content_offset);
                        let Some(sub) = self.segment_source(
                            &seg.texts[1],
                            off,
                            SourceSegmentationPurpose::NestedScript,
                        ) else {
                            self.module.oo_evidence.unretained_executable_roots = true;
                            continue;
                        };
                        // A `self { variable v }` declares per-class-object
                        // state, not instance state; keep it out of the
                        // instance union — only the members are lifted.
                        let wrapped_call = DefinerCall { ..*call };
                        let empty = HashSet::new();
                        let moves_off_the_instances = member
                            .wrapper_shift
                            .and_then(|shift| shift.receiver)
                            .is_some_and(|receiver| receiver != MemberReceiver::Instance);
                        let ivars = if moves_off_the_instances {
                            &empty
                        } else {
                            class_ivars
                        };
                        self.extract_members_from_wrapper_block(
                            &wrapped_call,
                            &sub,
                            class_qname,
                            ivars,
                            namespace,
                            head,
                        );
                        continue;
                    }
                    _ => {
                        self.module.oo_evidence.unretained_executable_roots |= member_supplies_body;
                        continue;
                    }
                },
                tcl_registry::definer::MemberKind::Flat => (member, head, 1usize),
                // Flag-keyed bodies (`property … -get/-set …`) are accessor
                // scripts, not method frames — no unit today (documented
                // limit).
                tcl_registry::definer::MemberKind::FlagKeyed => {
                    self.module.oo_evidence.unretained_executable_roots |= member_supplies_body;
                    continue;
                }
            };
            let frame = self.member_frame_for_segment(call, seg);
            self.extract_one_member(
                MemberExtraction {
                    call,
                    seg,
                    member,
                    kw,
                    base,
                    frame,
                },
                class_qname,
                class_ivars,
                namespace,
            );
        }
    }

    fn member_frame_for_segment(&self, call: &DefinerCall, seg: &SegmentedCommand) -> MemberFrame {
        let effective = statement_words(&self.cmd_tokens(seg), self.config);
        let words: Vec<_> = effective
            .iter()
            .map(|word| word.as_registry_word())
            .collect();
        MemberFrame::of_row(
            call.grammar,
            call.grammar
                .member_row(0, InvocationArguments::structured(&words), None)
                .as_ref(),
        )
    }

    /// Recurse into a wrapper's block form with the wrapper prefixed onto
    /// each member — `self { method m … }` records `m` as a class-object
    /// method, and `private { method m … }` as an instance method, exactly
    /// like their prefix spellings, because the registry answers the prefixed
    /// statement's row with the wrapper's shift applied.
    fn extract_members_from_wrapper_block(
        &mut self,
        call: &DefinerCall,
        segments: &[SegmentedCommand],
        class_qname: &str,
        class_ivars: &HashSet<String>,
        namespace: &str,
        wrapper: &str,
    ) {
        for seg in segments {
            if seg.texts.is_empty() {
                continue;
            }
            let head = seg.texts[0].as_str();
            let member_supplies_body = self.member_invocation_supplies_body(call.grammar, seg);
            if seg.is_partial {
                self.module.oo_evidence.unretained_executable_roots |= member_supplies_body;
                continue;
            }
            let Some(member) = self.source_definition_member(call.grammar, head) else {
                self.module.oo_evidence.unretained_executable_roots = true;
                continue;
            };
            if member.kind != tcl_registry::definer::MemberKind::Flat {
                self.module.oo_evidence.unretained_executable_roots |= member_supplies_body;
                continue;
            }
            let effective = statement_words(&self.cmd_tokens(seg), self.config);
            let words: Vec<_> = std::iter::once(InvocationWord::Literal(wrapper))
                .chain(effective.iter().map(|word| word.as_registry_word()))
                .collect();
            let frame = MemberFrame::of_row(
                call.grammar,
                call.grammar
                    .member_row(0, InvocationArguments::structured(&words), None)
                    .as_ref(),
            );
            self.extract_one_member(
                MemberExtraction {
                    call,
                    seg,
                    member,
                    kw: head,
                    base: 1,
                    frame,
                },
                class_qname,
                class_ivars,
                namespace,
            );
        }
    }

    /// Lift one body-bearing member call to a [`MethodDef`] unit, when its
    /// grammar layout and this consumer's kind routing say it opens a
    /// method frame.
    // One grammar-driven member extraction with shared validation paths.
    #[allow(clippy::too_many_lines)]
    fn extract_one_member(
        &mut self,
        ex: MemberExtraction<'_, '_>,
        class_qname: &str,
        class_ivars: &HashSet<String>,
        namespace: &str,
    ) {
        let MemberExtraction {
            call,
            seg,
            member,
            kw,
            base,
            frame,
        } = ex;
        let args = &seg.texts[base..];
        let Some(context) = self
            .invocation_metadata_context()
            .filter(|context| context.matches_registry(self.registry))
        else {
            self.module.oo_evidence.unretained_executable_roots = true;
            return;
        };
        let surface = Some(context.context().authoring_query());
        // Argument layout comes from the grammar: which relative index (0-
        // based after the keyword) is the body / name / parameter list.
        let Some(body_rel) = self
            .source_member_body_indices(call.grammar, kw, seg, base)
            .and_then(|indices| indices.into_iter().find(|&index| index < args.len()))
        else {
            self.module.oo_evidence.unretained_executable_roots = true;
            return;
        };
        let kind = match frame {
            MemberFrame::Opens(kind) => kind,
            MemberFrame::NoFrame => {
                self.module.oo_evidence.unretained_executable_roots = true;
                return;
            }
            // The layout the body word sits in is unknowable (a computed word
            // where an optional one may stand): whichever method it defines,
            // no scan can read it, so the class abstains as a whole — the
            // same answer a computed name gives below.
            MemberFrame::Unreadable => {
                self.module
                    .oo_unanalysed_classes
                    .insert(class_qname.to_string());
                self.module.oo_evidence.unretained_executable_roots = true;
                return;
            }
        };
        // A member that also declares a variable (itcl `variable NAME ?init?
        // ?configbody?`, snit 1.x `onconfigure`) is a declaration whose
        // trailing script is not an ordinary method frame — skipped
        // (documented limit; `MemberFrame::of_row` already excludes them by
        // effect, this keeps the exclusion structural too).
        if member
            .indices_for_call_in(args, surface, ArgRole::VarWrite)
            .next()
            .is_some()
        {
            self.module.oo_evidence.unretained_executable_roots = true;
            return;
        }
        let b_idx = base + body_rel;
        let name_owned: String;
        let name: &str = if let Some(rel) = member
            .indices_for_call_in(args, surface, ArgRole::Name)
            .next()
        {
            let Some(n) = seg.texts.get(base + rel) else {
                self.module.oo_evidence.unretained_executable_roots = true;
                return;
            };
            n.as_str()
        } else {
            // Nameless members: the synthetic id is the keyword, matching
            // the established `<constructor>` / `<destructor>` scheme.
            name_owned = format!("<{kw}>");
            &name_owned
        };
        // Dynamic method names / non-static bodies are left un-lowered —
        // and recorded as an unanalysable member of the class: any method of
        // the class may have been (re)defined with a body no scan can read,
        // so per-class analysis must abstain for the whole class.
        if name.contains('$') || name.contains('[') || !seg_word_is_static_braced(seg, b_idx) {
            self.module
                .oo_unanalysed_classes
                .insert(class_qname.to_string());
            self.module.oo_evidence.unretained_executable_roots = true;
            return;
        }
        // A parameter list Tcl would reject defines no method, and the class as
        // a whole becomes unanalysable — the same abstention the dynamic name /
        // body check above makes.
        let Some(params) = member_param_names(
            member,
            args,
            seg,
            base,
            WordValueRules::from_config(&self.config),
            self.invocation_dialect
                .and_then(tcl_registry::InvocationDialect::parameter_grammar),
            surface,
        ) else {
            self.module
                .oo_unanalysed_classes
                .insert(class_qname.to_string());
            self.module.oo_evidence.unretained_executable_roots = true;
            return;
        };
        // Lower the method body in its own frame (fresh const-map +
        // proc-depth) so the enclosing scope's tracked scalars
        // don't leak into the body's barrier-relaxation gate —
        // exactly as the `proc` case does — and suppress
        // nested-proc registration while doing so.
        let body_tok = seg.argv[b_idx];
        let body_off = body_tok.span.start() + u32::from(body_tok.content_offset);
        let execution_namespace = match call.grammar.member_current_namespace() {
            tcl_registry::definer::MemberCurrentNamespace::DefinedEntity => {
                crate::ir::ExecutionNamespace::exact(class_qname)
            }
            tcl_registry::definer::MemberCurrentNamespace::RuntimeReceiver => {
                crate::ir::ExecutionNamespace::RuntimeSelected
            }
        };
        // A runtime receiver namespace cannot be named during lowering. Keep
        // the lexical namespace for source reconstruction; the typed
        // execution context carried by MethodDef makes every proof consumer
        // abstain from relative command-resolution assumptions.
        let lowering_namespace = execution_namespace.for_head("").unwrap_or(namespace);
        self.proc_depth += 1;
        self.const_map_stack.push(HashMap::new());
        let prev_suppress = self.suppress_proc_register;
        self.suppress_proc_register = true;
        let retained = self
            .source_bindings
            .as_ref()
            .and_then(|bindings| bindings.executed_script_for_word(body_tok.span).cloned());
        let body_script = if let Some(source) = retained {
            let tokens = self.cmd_tokens(seg);
            let namespace = b_idx
                .checked_sub(1)
                .and_then(|argument| {
                    self.original_body_namespace_context(&tokens, argument, &source)
                })
                .or_else(|| {
                    self.source_bindings
                        .as_ref()?
                        .executed_script_namespace_context(&source)
                });
            self.lower_original_body(source, namespace.as_ref())
        } else {
            self.lower_body(seg.texts[b_idx].as_str(), body_off, lowering_namespace)
        };
        self.suppress_proc_register = prev_suppress;
        self.const_map_stack.pop();
        self.proc_depth -= 1;
        if self.method_body_may_install_definition(&body_script) {
            self.module.oo_evidence.unretained_executable_roots = true;
        }

        // Instance vars in scope: class-level decls (plus the grammar's
        // implicit member-body variables — snit's `self`/`selfns`/`type`/
        // `options`, a widget's `win`/`hull`, itcl's `this`) plus this
        // method's own top-level `variable` declarations. A write to any of
        // these mutates object state (impure for O126).
        let mut method_ivars = class_ivars.clone();
        method_ivars.extend(call.grammar.implicit_vars.iter().map(|s| (*s).to_string()));
        for statement in &body_script.statements {
            method_ivars.extend(self.advisory_method_instance_names(statement));
        }

        let original_receiver_context = body_script.executed_source.as_deref().and_then(|source| {
            self.source_bindings
                .as_ref()?
                .original_receiver_body_context(source)
        });
        let original_parameters = body_script.executed_source.as_deref().and_then(|source| {
            self.source_bindings
                .as_ref()?
                .original_script_formals(source)
        });
        if body_script.executed_source.is_some() {
            method_ivars.clear();
        }
        let def = MethodDef {
            definition_scope: call.definition_scope,
            class_name: class_qname.to_string(),
            method_name: name.to_string(),
            params,
            body: body_script,
            execution_namespace,
            kind,
            span: Some(seg.span),
            instance_vars: method_ivars,
            original_receiver_context,
            original_parameters,
        };
        self.module.retain_method(def);
    }
}

/// Formal-parameter names of a body-bearing member, read from the word its
/// grammar marks as the parameter list (`base + rel` in `seg.texts`).
///
/// An absent or empty word is the nullary member `method m {} {…}`, so it
/// yields no names; `None` is a list Tcl itself would reject.
fn member_param_names(
    member: &tcl_registry::definer::MemberSpec,
    args: &[String],
    seg: &SegmentedCommand,
    base: usize,
    rules: WordValueRules,
    grammar: Option<tcl_dialect::ParameterGrammar>,
    surface: Option<tcl_dialect::model::SurfaceQuery<'_>>,
) -> Option<Vec<String>> {
    let param_text = member
        .indices_for_call_in(args, surface, ArgRole::ParamList)
        .next()
        .and_then(|rel| seg.texts.get(base + rel))
        .filter(|text| !text.is_empty());
    match param_text {
        Some(text) => parse_formal_param_names(text, rules, grammar),
        None => Some(Vec::new()),
    }
}

/// One body-bearing member call ready to lift — bundles the walk context so
/// [`Lowerer::extract_one_member`] stays under the argument limit.
#[derive(Clone, Copy)]
struct MemberExtraction<'a, 'b> {
    call: &'a DefinerCall,
    seg: &'a SegmentedCommand,
    member: &'b tcl_registry::definer::MemberSpec,
    /// The effective member keyword (the inner one for a wrapper prefix).
    kw: &'a str,
    /// Index of the member's first argument word in `seg.texts` (1, or 2
    /// past a wrapper prefix).
    base: usize,
    /// The frame the member's body opens, read off its row.
    frame: MemberFrame,
}

/// The frame a member statement's body opens, read off the statement's
/// [`MemberRow`] — its effect and the side it resolves to after every wrapper
/// shift — never its keyword.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum MemberFrame {
    /// A method frame of this shape ([`MethodKind::from_effect`]).
    Opens(MethodKind),
    /// A body that is not a method frame: an option accessor or mutator, a
    /// declaration's configuration script, a definition-time script whose
    /// namespace no name reaches.
    NoFrame,
    /// The registry cannot read the statement's layout (a computed word where
    /// an optional one may stand).
    Unreadable,
}

impl MemberFrame {
    /// The frame `row` opens under `grammar`.
    ///
    /// A callable opens the frame [`MethodKind::from_effect`] names. A script
    /// run once at definition opens a class-level frame when the family runs
    /// member bodies in the defined entity's own namespace
    /// ([`MemberCurrentNamespace::DefinedEntity`] — snit's `typeconstructor`
    /// is the proc `${type}::Snit_typeconstructor`, run with `type` bound);
    /// under [`MemberCurrentNamespace::RuntimeReceiver`] it runs in the class
    /// object's own namespace (`TclOO`'s `initialise`, in `::oo::ObjN`), which
    /// neither the class name nor a receiver names, so it opens none.
    fn of_row(grammar: &DefinitionBodyGrammar, row: Option<&MemberRow>) -> Self {
        let Some(row) = row else {
            return Self::Unreadable;
        };
        let kind = match row.effect {
            MemberEffect::Callable { role, .. } => MethodKind::from_effect(role, row.receiver),
            MemberEffect::InitScript {
                timing: InitTiming::AtDefinition,
                ..
            } if grammar.member_current_namespace() == MemberCurrentNamespace::DefinedEntity => {
                Some(MethodKind::ClassMethod)
            }
            _ => None,
        };
        kind.map_or(Self::NoFrame, Self::Opens)
    }
}

/// Value-conservative definition-member words from the original positioned
/// token owner, under the source's retained lexical axes. Wrapper prefixes
/// are composed by the caller after this projection.
fn statement_words(
    tokens: &CommandTokens,
    config: tcl_lexer::LexerConfig,
) -> Vec<crate::registry_invocation::EffectiveInvocationWord> {
    tokens
        .words()
        .iter()
        .map(|word| {
            crate::registry_invocation::effective_invocation_word(
                word,
                config.escapes,
                WordValueRules::from_config(&config),
            )
        })
        .collect()
}

/// The instance variables one definition body declares at class level, per
/// the definer's grammar: every `all_args_var` member's names (the `TclOO`
/// `variable` slot — skipping a leading slot-operation word, which names no
/// variable) plus every `VarWrite`-role name (snit's `variable` /
/// `typevariable` / `component` / `typecomponent`, itcl's `variable` /
/// `common`), including itcl's access-modifier-wrapped spellings.
///
/// The result is the **union of every name ever declared** across the
/// block: slot removal operations (`variable -remove a`, `-set`, `-clear`)
/// are deliberately not folded here — the union is the conservative
/// direction for every consumer of [`crate::ir::MethodDef::instance_vars`]
/// (existence-fold abstention, W-family known-bound, O126 impurity), where
/// a stale extra name only widens abstention while a missed name produces a
/// false claim.  A *sibling* definition block may declare more, which is
/// why the caller accumulates a per-class union rather than using this
/// result directly.
fn declared_member_vars(
    grammar: &tcl_registry::definer::DefinitionBodyGrammar,
    segments: &[crate::segmenter::SegmentedCommand],
    surface: Option<tcl_dialect::model::SurfaceQuery<'_>>,
    config: tcl_lexer::LexerConfig,
) -> HashSet<String> {
    let mut out = HashSet::new();
    for seg in segments {
        if seg.is_partial || seg.texts.is_empty() {
            continue;
        }
        let head = seg.texts[0].as_str();
        let Some(member) = grammar.source_member_in(head.as_bytes(), surface) else {
            continue;
        };
        // Unwrap an access-modifier prefix (itcl `public variable x`,
        // TclOO 9's `private variable x`) one level.
        let (member, args, base): (&tcl_registry::definer::MemberSpec, &[String], usize) =
            if member.kind == tcl_registry::definer::MemberKind::Wrapper {
                match seg
                    .texts
                    .get(1)
                    .and_then(|inner| grammar.source_member_in(inner.as_bytes(), surface))
                {
                    Some(inner_member)
                        if inner_member.kind == tcl_registry::definer::MemberKind::Flat
                            && seg.texts.len() >= 3 =>
                    {
                        (inner_member, &seg.texts[2..], 2)
                    }
                    _ => continue,
                }
            } else {
                (member, &seg.texts[1..], 1)
            };
        let decoded: Vec<Option<String>> = args
            .iter()
            .enumerate()
            .map(|(relative, text)| {
                let index = base.checked_add(relative)?;
                if seg.single_token_word.get(index) != Some(&true) {
                    return None;
                }
                let token = seg.argv.get(index)?;
                crate::value_transfer::literal_token_value(text, token.kind, &config)
                    .map(std::borrow::Cow::into_owned)
            })
            .collect();
        let Some(values) = decoded.iter().cloned().collect::<Option<Vec<_>>>() else {
            // Unknown member operands widen the union of known literal names.
            out.extend(decoded.into_iter().flatten());
            continue;
        };
        if member.all_args_var {
            let names = match member.slot {
                Some(slot) => match slot.split_call(&values) {
                    Some((_, names)) => names,
                    None => continue,
                },
                None => &values,
            };
            out.extend(names.iter().cloned());
        } else {
            out.extend(
                member
                    .indices_for_call_in(&values, surface, ArgRole::VarWrite)
                    .filter_map(|relative| values.get(relative).cloned()),
            );
        }
    }
    out
}

// Public API

/// Lower Tcl source to an IR module.
///
/// This is the main entry point for the lowering phase.  Lexes with the
/// default (Tcl-8.5+) config and parses expressions in the plain-Tcl grammar;
/// use [`lower_to_ir_with_dialect`] to honour a document's dialect.
#[must_use]
pub fn lower_to_ir(source: &str, registry: &CommandRegistry) -> Module {
    // dialect-drift-ok: the test-only entry point — every production caller
    // now goes through `lower_to_ir_with_config` / `_with_dialect` with the
    // document's own config; the test fixtures across the workspace still
    // spell the plain-Tcl default this way.
    lower_to_ir_with_config(source, registry, tcl_lexer::LexerConfig::default())
}

/// Lower a single `proc` body in isolation at `proc_depth == 1` (a fresh
/// [`Lowerer`] with an empty const-map frame), returning the **offset-0** body
/// [`Script`].  Replicates the body-lowering setup `lower_proc` performs for a
/// static literal body (`proc_depth += 1`; push an empty const-map;
/// `lower_body(text, 0, namespace)`).
///
/// For a body free of cross-item context (no nested `proc` / `namespace
/// import`/`export` / command alias / const-map materialisation), this is
/// byte-identical to the body the whole-file lowering produces for that
/// procedure, normalised to offset 0 — the seam the per-procedure
/// lowering memo keys on the offset-0 body text and feeds back through
/// [`Lowerer::with_body_cache`].
#[must_use]
pub fn lower_proc_body_isolated(
    body_text: &str,
    namespace: &str,
    registry: &CommandRegistry,
    config: tcl_lexer::LexerConfig,
    dialect: Option<&'static tcl_dialect::DialectProfile>,
) -> Script {
    let mut lowerer = Lowerer::for_standalone_source(registry, config, dialect);
    lowerer.start_module();
    lowerer.source.clone_from(&body_text.to_owned());
    let frame = crate::var_resolve::VariableExecutionFrame::Procedure {
        namespace: namespace.to_owned(),
        identity: "::body-cache".to_owned(),
    };
    lowerer.source_bindings = Some(
        SourceCommandBindings::analyse_in_frame_with_options(
            body_text,
            &frame,
            config,
            registry,
            lowerer.module.source_entry.options(),
        )
        .into(),
    );
    lowerer.in_procedure_frame(Some(IrulesExecutionContext::ProcedureBody), |lowerer| {
        lowerer.lower_body(body_text, 0, namespace)
    })
}

/// Lower one runtime procedure body as a complete IR module.
///
/// Unlike the ordinary module entry point, the outer source runs at procedure
/// depth in `namespace`. This preserves procedure-only lowering semantics and
/// retains any nested procedure definitions and whole-unit command-mutation
/// facts for bytecode emission.
#[must_use]
pub fn lower_proc_body_module_for_bytecode(
    body_text: &str,
    namespace: &str,
    registry: &CommandRegistry,
    config: tcl_lexer::LexerConfig,
    dialect: Option<&'static tcl_dialect::DialectProfile>,
    plain_command_dispatch: bool,
) -> Module {
    lower_proc_body_module_for_bytecode_with_options(
        body_text,
        namespace,
        registry,
        config,
        dialect,
        plain_command_dispatch,
        None,
    )
}

/// Runtime lowering with an explicit live interpreter entry contract.
#[must_use]
pub fn lower_proc_body_module_for_bytecode_with_options(
    body_text: &str,
    namespace: &str,
    registry: &CommandRegistry,
    config: tcl_lexer::LexerConfig,
    dialect: Option<&'static tcl_dialect::DialectProfile>,
    plain_command_dispatch: bool,
    options: Option<SourceAnalysisOptions<'_>>,
) -> Module {
    lower_procedure_target_module_for_bytecode_with_options(
        tcl_runtime_api::ProcedureCompileTarget {
            source: body_text,
            namespace,
            parameters: &[],
        },
        registry,
        config,
        dialect,
        plain_command_dispatch,
        options,
    )
}

/// Lower a runtime procedure with its actual formal input contract.
/// C formal names are ordinary slots. Name-only Jim headers cannot prove
/// reference/default binding kind, so they retain the live entry's uncertainty.
#[must_use]
pub fn lower_procedure_target_module_for_bytecode_with_options(
    target: tcl_runtime_api::ProcedureCompileTarget<'_>,
    registry: &CommandRegistry,
    config: tcl_lexer::LexerConfig,
    dialect: Option<&'static tcl_dialect::DialectProfile>,
    plain_command_dispatch: bool,
    options: Option<SourceAnalysisOptions<'_>>,
) -> Module {
    let mut lowerer = Lowerer::with_config(registry, config)
        .with_dialect(dialect)
        .for_bytecode_backend();
    if let Some(options) = options {
        lowerer.set_source_analysis_options(options);
    }
    if plain_command_dispatch {
        lowerer = lowerer.trace_visible();
    }
    if lowerer
        .invocation_dialect
        .and_then(tcl_registry::InvocationDialect::parameter_grammar)
        == Some(tcl_dialect::ParameterGrammar::Tcl)
    {
        lowerer.incoming_formals = target.parameters.to_vec();
    }
    lowerer.lower_procedure_target(target.source, target.namespace);
    lowerer.finish_module(target.source)
}

/// Lower one runtime script as a complete bytecode IR module in its exact
/// constructed command-resolution namespace.
#[must_use]
pub fn lower_script_module_for_bytecode(
    source: &str,
    namespace: &str,
    registry: &CommandRegistry,
    config: tcl_lexer::LexerConfig,
    dialect: Option<&'static tcl_dialect::DialectProfile>,
    plain_command_dispatch: bool,
) -> Module {
    lower_script_module_for_bytecode_with_options(
        source,
        namespace,
        registry,
        config,
        dialect,
        plain_command_dispatch,
        None,
    )
}

/// Runtime lowering with an explicit live interpreter entry contract.
#[must_use]
pub fn lower_script_module_for_bytecode_with_options(
    source: &str,
    namespace: &str,
    registry: &CommandRegistry,
    config: tcl_lexer::LexerConfig,
    dialect: Option<&'static tcl_dialect::DialectProfile>,
    plain_command_dispatch: bool,
    options: Option<SourceAnalysisOptions<'_>>,
) -> Module {
    let mut lowerer = Lowerer::with_config(registry, config)
        .with_dialect(dialect)
        .for_bytecode_backend();
    if let Some(options) = options {
        lowerer.set_source_analysis_options(options);
    }
    if plain_command_dispatch {
        lowerer = lowerer.trace_visible();
    }
    lowerer.lower_script_target(source, namespace);
    lowerer.finish_module(source)
}

/// Lower original native script operands through the shared byte lexical owner.
/// No Unicode projection supplies execution or compiler-admission authority.
///
/// # Errors
/// Returns the exact lexical operand capability failure.
pub fn lower_script_bytes_module_for_bytecode_with_options(
    target: tcl_runtime_api::ScriptCompileTargetBytes<'_>,
    registry: &CommandRegistry,
    config: tcl_lexer::LexerConfig,
    dialect: Option<&'static tcl_dialect::DialectProfile>,
    plain_command_dispatch: bool,
    options: Option<SourceAnalysisOptions<'_>>,
) -> Result<Module, tcl_lexer::word_parts::NativeWordError> {
    lower_native_target(
        NativeLoweringTarget {
            source: target.source,
            namespace: target.namespace,
            kind: crate::ir::TopLevelKind::Script,
        },
        registry,
        config,
        dialect,
        plain_command_dispatch,
        options,
    )
}

/// Lower a native procedure body while retaining its exact namespace and source.
/// Formal binding is owned by the caller's original-object activation contract.
///
/// # Errors
/// Returns the exact lexical operand capability failure.
pub fn lower_procedure_bytes_module_for_bytecode_with_options(
    target: tcl_runtime_api::ProcedureCompileTargetBytes<'_>,
    registry: &CommandRegistry,
    config: tcl_lexer::LexerConfig,
    dialect: Option<&'static tcl_dialect::DialectProfile>,
    plain_command_dispatch: bool,
    options: Option<SourceAnalysisOptions<'_>>,
) -> Result<Module, tcl_lexer::word_parts::NativeWordError> {
    lower_native_target(
        NativeLoweringTarget {
            source: target.source,
            namespace: target.namespace,
            kind: crate::ir::TopLevelKind::ProcedureBody,
        },
        registry,
        config,
        dialect,
        plain_command_dispatch,
        options,
    )
}

#[derive(Clone, Copy)]
struct NativeLoweringTarget<'a> {
    source: &'a tcl_lexer::SourceImage,
    namespace: &'a tcl_core_types::ByteNamespacePath,
    kind: crate::ir::TopLevelKind,
}

fn lower_native_target(
    target: NativeLoweringTarget<'_>,
    registry: &CommandRegistry,
    config: tcl_lexer::LexerConfig,
    dialect: Option<&'static tcl_dialect::DialectProfile>,
    plain_command_dispatch: bool,
    options: Option<SourceAnalysisOptions<'_>>,
) -> Result<Module, tcl_lexer::word_parts::NativeWordError> {
    let NativeLoweringTarget {
        source,
        namespace,
        kind,
    } = target;
    let mut lowerer = Lowerer::with_config(registry, config)
        .with_dialect(dialect)
        .for_bytecode_backend();
    if let Some(options) = options {
        lowerer.set_source_analysis_options(options);
    }
    if plain_command_dispatch {
        lowerer = lowerer.trace_visible();
    }
    lowerer.set_source_image_channel(source);
    lowerer.module.native_namespace = Some(namespace.clone());
    if let (Ok(text), Some(namespace_key)) = (
        source.try_text(),
        lowerer.module.advisory_top_level_namespace(),
    ) {
        if crate::segmenter::segment_commands_image_with_offset_and_config(
            source,
            0,
            lowerer.config,
        )
        .is_none()
        {
            return Err(tcl_lexer::word_parts::NativeWordError::LexicalStreamUnavailable);
        }
        let namespace_key = tcl_syntax::naming::unroot_rooted_key(&namespace_key)
            .expect("checked analytical namespace is rooted");
        match kind {
            crate::ir::TopLevelKind::Script => {
                lowerer.lower_script_target(text, namespace_key);
            }
            crate::ir::TopLevelKind::ProcedureBody => {
                lowerer.lower_procedure_target(text, namespace_key);
            }
        }
        let mut module = lowerer.finish_module(text);
        module.source = source.clone();
        module.native_namespace = Some(namespace.clone());
        return Ok(module);
    }
    lower_native_byte_calls(lowerer, source, namespace, registry, options, kind)
}

fn lower_native_byte_calls(
    mut lowerer: Lowerer<'_>,
    source: &tcl_lexer::SourceImage,
    namespace: &tcl_core_types::ByteNamespacePath,
    registry: &CommandRegistry,
    options: Option<SourceAnalysisOptions<'_>>,
    kind: crate::ir::TopLevelKind,
) -> Result<Module, tcl_lexer::word_parts::NativeWordError> {
    lowerer.start_module();
    let config = lowerer.config;
    let tokens = tcl_lexer::Lexer::with_source_image(source, config)
        .tokenise_all()
        .map_err(|_| tcl_lexer::word_parts::NativeWordError::LexicalStreamUnavailable)?;
    let groups = tcl_lexer::group_commands_bytes(&tokens, source.bytes(), config);
    let mut module = lowerer.module;
    module.source = source.clone();
    module.native_namespace = Some(namespace.clone());
    module.top_level_kind = kind;
    module.top_level_namespace = module.advisory_top_level_namespace().unwrap_or_default();
    for group in groups {
        let words = group
            .words
            .iter()
            .map(|word| {
                let word = tcl_lexer::word_parts::NativeWord::from_group(
                    source.clone(),
                    config,
                    &tokens,
                    word,
                )?;
                Ok(word)
            })
            .collect::<Result<Vec<_>, _>>()?;
        if let (Some(first), Some(last)) = (words.first(), words.last()) {
            module.top_level.statements.push(Statement::NativeCall {
                span: tcl_lexer::Span::new(first.span().start(), last.span().end()),
                words,
            });
        }
    }
    let origin = std::sync::Arc::new(crate::command_binding::SourceOriginId::authored_image(
        source.clone(),
    ));
    let executed =
        crate::command_binding::ExecutedScriptSource::contiguous_image(origin, source.clone(), 0)
            .expect("the complete original image is contiguous");
    module.top_level.executed_source = Some(std::sync::Arc::new(executed.clone()));
    let compiler_dialect = options.and_then(|options| options.native_compiler_dialect());
    let native_inline_disabled = compiler_dialect
        .and_then(tcl_registry::InvocationDialect::native_string_protocol)
        .is_some_and(|protocol| protocol.tcl_version().is_some())
        && options
            .and_then(|options| options.native_entry)
            .is_some_and(|entry| entry.inline_compilation_disabled);
    let original_byte_compilation = options
        .and_then(|options| options.native_entry)
        .is_some_and(|entry| {
            let mut context = module.source_entry.native_compilation;
            if module.top_level_kind == crate::ir::TopLevelKind::ProcedureBody {
                context.mode =
                    tcl_registry::native_compilation::NativeCompilationMode::BytecodeObject;
                context.frame =
                    tcl_registry::native_compilation::NativeCompilationFrame::ProcedureCode;
            }
            crate::native_byte_compilation::closed_original_byte_compilation(
                &module, entry, registry, context,
            )
        });
    if !native_inline_disabled
        && !original_byte_compilation
        && compiler_dialect
            .is_none_or(|dialect| dialect.family() != Some(tcl_dialect::model::Family::Jim))
    {
        module.top_level.native_compilation_admission = Some(std::sync::Arc::new(
            crate::native_compilation_admission::NativeCompilationAdmission {
                source: Some(executed),
                failure: None,
                provider_required: true,
            },
        ));
    }
    // Native calls retain unconstrained callbacks and variable effects.
    module.has_dynamic_trace = true;
    module.has_dynamic_variable_trace = true;
    module.retain_original_byte_source_namespace(namespace, registry);
    Ok(module)
}

/// Legacy text-shape predicate retained for callers that inspect source shape.
///
/// This does not prove cache eligibility. The lowering ingress uses
/// [`SourceCommandBindings::can_reuse_isolated_body`] and restores exact
/// positioned proof carriers through
/// [`SourceCommandBindings::restore_script_bindings`] after a cache hit.
/// A command's spelling cannot establish the implementation it executes.
#[must_use]
pub fn body_cache_eligible(body: &str) -> bool {
    // Command keywords whose body-level use carries a cross-item effect the
    // isolated lowering drops. `proc` covers a nested procedure definition.
    // Matched as a word followed by Tcl inter-word whitespace (space, tab, CR,
    // newline, or a `\`-continuation), so a tab-separated `interp\talias` trips
    // it too.
    const WORD_DISQUALIFIERS: &[&str] = &[
        "namespace",
        "interp",
        "rename",
        "method",
        "when",
        "apply",
        "alias",
        "proc",
    ];
    // Substring markers (the token itself is the marker — no trailing arg).
    const SUBSTR_DISQUALIFIERS: &[&str] = &["oo::", "::oo", "itcl"];
    !SUBSTR_DISQUALIFIERS.iter().any(|kw| body.contains(kw))
        && !WORD_DISQUALIFIERS
            .iter()
            .any(|kw| contains_word_followed_by_ws(body, kw))
}

/// Legacy lexical indication that source contains alias-related words.
///
/// This is a presentation/compatibility predicate, not command-table evidence
/// or a cache gate. Use the shared positioned binding owner for those questions.
#[must_use]
pub fn source_may_alias_commands(source: &str) -> bool {
    contains_word_followed_by_ws(source, "interp") || contains_word_followed_by_ws(source, "rename")
}

/// True when `word` occurs in `source` followed by Tcl inter-word whitespace —
/// i.e. used as a command with an argument. Ignores the character *before* the
/// word (a preceding non-boundary only over-disqualifies, which is safe).
fn contains_word_followed_by_ws(source: &str, word: &str) -> bool {
    source.match_indices(word).any(|(i, _)| {
        source
            .as_bytes()
            .get(i + word.len())
            .is_some_and(|b| matches!(b, b' ' | b'\t' | b'\r' | b'\n' | b'\\'))
    })
}

#[cfg(test)]
mod body_cache_eligible_tests {
    use crate::interprocedural::test_body_identity::fixture_id;

    use super::body_cache_eligible;

    #[test]
    fn isolated_body_profile_keeps_the_original_standalone_source_purpose() {
        let environment = crate::environment_ingress::resolve_environment("tcl9.0");
        let context = environment.default_context_registry();
        let registry = context.commands();
        let profile = environment.unit_profile();
        let config = tcl_lexer::LexerConfig::for_file_grammar(profile.grammar);
        let source = "upvar 1 ${odd name} local";
        let body = super::lower_proc_body_isolated(source, "::", registry, config, Some(profile));
        let statement = body.statements.first().expect("original statement");
        let tokens = body
            .retained_source_tokens_for_statement(statement)
            .expect("original source tokens");
        let binding = tokens.source_binding.as_ref().expect("original binding");
        let metadata = tcl_registry::model::semantic::SemanticContext::for_profile(profile).into();
        assert_eq!(
            binding.original_source_advice_purpose(tokens, metadata, registry),
            Some(crate::command_binding::OriginalInvocationSourcePurpose::Standalone)
        );
        assert!(
            binding
                .original_invocation_source_purpose(tokens, metadata, registry)
                .is_none()
        );
        let retained = body
            .executed_source
            .as_ref()
            .expect("original isolated body source");
        assert_eq!(retained.try_text().unwrap(), source);
        assert_eq!(retained.base(), 0);
        assert!(body.native_compilation_admission.is_none());
        assert!(
            crate::registry_invocation::admitted_native_compiler_invocation(registry, None, tokens)
                .is_none()
        );
        let info = crate::cfg_builder::upvar_info::collect_upvar_targets_with_registry(
            &body,
            &["odd name".to_owned()],
            registry,
        );
        assert_eq!(
            info.param_targets.get("local").map(String::as_str),
            Some("odd name")
        );
    }

    #[test]
    fn plain_bodies_are_eligible() {
        assert!(body_cache_eligible("set x 1"));
        assert!(body_cache_eligible("puts \"hi $name\"\nreturn $x"));
        assert!(body_cache_eligible("if {$x} { foo } else { bar }"));
        assert!(body_cache_eligible(""));
    }

    #[test]
    fn cross_item_constructs_disqualify() {
        for body in [
            "namespace eval x { }",
            "namespace import ::ns::*",
            "interp alias {} x {} y",
            "rename set myset",
            "apply {{} { }}",
            "when HTTP_REQUEST { }",
            "oo::class create C { }",
            "itcl::class C { }",
            "proc inner {} { }",
        ] {
            assert!(!body_cache_eligible(body), "should disqualify: {body}");
        }
    }

    #[test]
    fn tab_separated_command_still_disqualifies() {
        assert!(!body_cache_eligible("interp\talias {} x {} y"));
        assert!(!body_cache_eligible("namespace\timport ::ns::*"));
    }

    #[test]
    fn substring_only_use_is_safe() {
        assert!(body_cache_eligible("set myproclist {a b c}"));
        assert!(body_cache_eligible("set renamed 1"));
    }

    #[test]
    fn source_may_alias_commands_flags_interp() {
        use super::source_may_alias_commands;
        // `interp alias` establishes an alias a cached body cannot see.
        assert!(source_may_alias_commands(
            "interp alias {} = {} expr\nproc f {} { = 1 }\n"
        ));
        assert!(source_may_alias_commands("interp\talias {} = {} expr"));
        // No `interp` -> safe to cache.
        assert!(!source_may_alias_commands(
            "proc f {x} { set y $x }\nproc g {} { return 1 }\n"
        ));
        // `interp` as a substring of a bareword does not trip it.
        assert!(!source_may_alias_commands("set interpreter 1"));
    }

    // Proves *why* `source_may_alias_commands` must guard the file: with a
    // top-level `interp alias {} = {} expr` in scope, lowering `f`'s
    // body through the isolated body cache (empty alias table) resolves `=` as an
    // unknown command, whereas the in-place whole-file lowering resolves it to
    // `expr` — so the module IRs differ. The db therefore must not install the
    // cache for such a file.
    fn assert_scope_withdraws_cache(source: &str, expected_target: &str) {
        let registry = tcl_registry::CommandRegistry::build_default();
        let config = tcl_lexer::LexerConfig::default();
        let cache_calls = std::cell::Cell::new(0);
        let cache = |body: &str, namespace: &str| {
            cache_calls.set(cache_calls.get() + 1);
            super::lower_proc_body_isolated(body, namespace, &registry, config, None)
        };
        let cached = super::lower_to_ir_with_body_cache(source, &registry, config, None, &cache);
        let fresh = super::lower_to_ir_with_config(source, &registry, config);
        assert_eq!(
            cache_calls.get(),
            0,
            "an isolated cache lacks this dispatch context"
        );
        // Separate analyses have distinct activation/source identities. Test
        // the actual withdrawal and retained dispatch instead of equating the
        // debug serialization of two different physical worlds.
        for module in [&cached, &fresh] {
            let procedure = module
                .procedures
                .get(&fixture_id(&module.procedures, "::f"))
                .expect("authored fixture body");
            assert_eq!(procedure.params, ["x"]);
            let mut retained_target = false;
            crate::ir::for_each_statement(&procedure.body, &mut |statement| {
                if let Some(tokens) = statement.tokens() {
                    retained_target |= tokens
                        .source_binding
                        .iter()
                        .chain(tokens.nested_bindings.iter().map(|(_, binding)| binding))
                        .filter_map(|binding| binding.proved_execution_target())
                        .any(|target| target.command == expected_target && target.registry_backed);
                }
            });
            assert!(
                retained_target,
                "the original invocation must retain {expected_target}"
            );
        }
    }

    #[test]
    fn alias_in_scope_withdraws_isolated_cache_proof() {
        assert_scope_withdraws_cache(
            "interp alias {} = {} expr\nproc f {x} { return [= {$x + 1}] }\n",
            "::expr",
        );
    }

    #[test]
    fn source_may_alias_commands_flags_rename() {
        use super::source_may_alias_commands;
        // A static `rename` establishes an alias a cached body cannot see —
        // same hazard as `interp alias`, see `detect_rename`.
        assert!(source_may_alias_commands(
            "rename puts myputs\nproc f {x} { myputs $x }\n"
        ));
        assert!(source_may_alias_commands("rename\tputs myputs"));
        // `rename` as a substring of a bareword does not trip it.
        assert!(!source_may_alias_commands("set renamed 1"));
    }

    // Same hazard as `alias_in_scope_makes_body_cache_diverge`, for a static
    // `rename`: `rename puts myputs` at the top level must make `f`'s body
    // resolve `myputs` to `puts`, which the isolated (empty-alias-table) body
    // cache cannot see.
    #[test]
    fn rename_in_scope_withdraws_isolated_cache_proof() {
        assert_scope_withdraws_cache("rename puts myputs\nproc f {x} { myputs $x }\n", "::puts");
    }
}

/// Like [`lower_to_ir_with_dialect`] but with a memoised per-procedure body-lowering
/// callback: a top-level `proc`'s static body is lowered
/// through `body_cache` `(offset-0 body text, namespace) -> offset-0 Script` and
/// rebased, so an unchanged proc's body IR is reused across edits.  The caller must
/// only install a cache for **context-free** files (see [`Lowerer::body_cache`]);
/// byte-identity is guarded by the corpus differential gates.
///
/// The cached bodies must be produced by [`lower_proc_body_isolated`] under the
/// **same** `dialect`, since the dialect selects the expression grammar the
/// body's conditions are parsed with.
#[must_use]
pub fn lower_to_ir_with_body_cache(
    source: &str,
    registry: &CommandRegistry,
    config: tcl_lexer::LexerConfig,
    dialect: Option<&'static tcl_dialect::DialectProfile>,
    body_cache: &dyn Fn(&str, &str) -> Script,
) -> Module {
    lower_with(
        Lowerer::with_config(registry, config)
            .with_dialect(dialect)
            .with_body_cache(body_cache),
        source,
    )
}

/// Like [`lower_to_ir`] but with an explicit dialect
/// [`tcl_lexer::LexerConfig`], threaded into every body re-segmentation
/// so `{*}` expansion (off for Tcl 8.4 / iRules) and the iRules `}{`
/// ghost SEP are honoured.
///
/// Expressions are still parsed in the plain-Tcl grammar — a caller that
/// knows the dialect *name* should use [`lower_to_ir_with_dialect`], which
/// also gives `if` / `while` / `for` / `expr` the dialect's operator set.
#[must_use]
pub fn lower_to_ir_with_config(
    source: &str,
    registry: &CommandRegistry,
    config: tcl_lexer::LexerConfig,
) -> Module {
    lower_with(Lowerer::with_config(registry, config), source)
}

/// Like [`lower_to_ir_with_config`] but also naming the document's analysis
/// `dialect` (`""` for plain Tcl), so every `if` / `while` / `for` condition
/// and every inlined `expr` is parsed with that dialect's operator set.
///
/// This is what makes an iRules word-operator condition — `if {$x contains
/// "cd"}` — reach the IR as a real
/// [`BinOp::Contains`](crate::expr_ast::BinOp::Contains) comparison instead of
/// an opaque [`ExprNode::Raw`](crate::expr_ast::ExprNode::Raw), which is the
/// only shape the constant folder (and the I230 constant-condition
/// diagnostic behind it) can evaluate.
#[must_use]
pub fn lower_to_ir_with_dialect(
    source: &str,
    registry: &CommandRegistry,
    config: tcl_lexer::LexerConfig,
    dialect: Option<&'static tcl_dialect::DialectProfile>,
) -> Module {
    lower_with(
        Lowerer::with_config(registry, config).with_dialect(dialect),
        source,
    )
}

/// Lower `source` with an already-configured [`Lowerer`].
///
/// The seam a host uses when it has more to install than the fixed-argument
/// entry points above accept — the document's own
/// [`with_declared_commands`](Lowerer::with_declared_commands) surface, above
/// all. Every other `lower_to_ir_*` function is this one with a `Lowerer`
/// built for it.
#[must_use]
pub fn lower_to_ir_with(lowerer: Lowerer<'_>, source: &str) -> Module {
    lower_with(lowerer, source)
}

/// Like [`lower_to_ir`] but for the bytecode/VM compile path: constructs the
/// backend can't compile correctly (`try`, and a `foreach`/`lmap` directly
/// nesting another) are lowered to runtime-command barriers (see
/// [`Lowerer::for_bytecode`]). Analysis callers keep the structured IR via
/// [`lower_to_ir`].
#[must_use]
pub fn lower_to_ir_for_bytecode(source: &str, registry: &CommandRegistry) -> Module {
    lower_to_ir_for_bytecode_with_dialect(source, registry, tcl_lexer::LexerConfig::default(), None)
}

/// Like [`lower_to_ir_for_bytecode`] but also naming the document's `dialect`
/// (`""` for plain Tcl) — the bytecode-path counterpart of
/// [`lower_to_ir_with_dialect`], so a dialect expression such as an iRules
/// word-operator condition compiles to its dedicated opcode rather than the
/// generic runtime-`expr` fallback.
#[must_use]
pub fn lower_to_ir_for_bytecode_with_dialect(
    source: &str,
    registry: &CommandRegistry,
    config: tcl_lexer::LexerConfig,
    dialect: Option<&'static tcl_dialect::DialectProfile>,
) -> Module {
    lower_with(
        Lowerer::with_config(registry, config)
            .with_dialect(dialect)
            .for_bytecode_backend(),
        source,
    )
}

/// Like [`lower_to_ir_for_bytecode`] but with every inline/structured
/// lowering hook suppressed (see [`Lowerer::trace_visible`]) — every command
/// in `source` compiles to a plain runtime dispatch, so an execution trace
/// observes it. For recompiling a proc/script body once a step-capable
/// execution trace targets it; see
/// [`tcl_runtime_api::CompileService::compile_traced`].
#[must_use]
pub fn lower_to_ir_traced(source: &str, registry: &CommandRegistry) -> Module {
    lower_to_ir_traced_with_config(source, registry, tcl_lexer::LexerConfig::default())
}

/// Like [`lower_to_ir_traced`] but with an explicit dialect
/// [`tcl_lexer::LexerConfig`], so a version-pinned host's traced recompiles
/// parse under the same grammar as its ordinary compiles.
#[must_use]
pub fn lower_to_ir_traced_with_config(
    source: &str,
    registry: &CommandRegistry,
    config: tcl_lexer::LexerConfig,
) -> Module {
    lower_to_ir_traced_with_dialect(source, registry, config, None)
}

/// Like [`lower_to_ir_traced_with_config`] but also records the exact dialect
/// selected by the host.  Runtime compile services for a named profile must
/// use this entry point so the resulting bytecode artifact retains the
/// profile identity that its lexer, registry, and expression grammar used.
#[must_use]
pub fn lower_to_ir_traced_with_dialect(
    source: &str,
    registry: &CommandRegistry,
    config: tcl_lexer::LexerConfig,
    dialect: Option<&'static tcl_dialect::DialectProfile>,
) -> Module {
    lower_with(
        Lowerer::with_config(registry, config)
            .with_dialect(dialect)
            .for_bytecode_backend()
            .trace_visible(),
        source,
    )
}

/// Return the first hard parse-error message in `source`, in source order, or
/// `None` if `source` parses cleanly.
///
/// A VM compile front-end (`CompileService::compile`) calls this so that a
/// malformed script becomes a catchable runtime error carrying the **exact**
/// C Tcl message (e.g. `extra characters after close-quote`), matching C Tcl's
/// deferral of a compile-time parse error to a runtime instruction. The lexer
/// otherwise recovers from these for the benefit of editor diagnostics, so the
/// IR / bytecode never sees them.
///
/// Lexes with the default (Tcl-8.5+) dialect config — the same one
/// [`lower_to_ir_for_bytecode`] uses.
#[must_use]
pub fn first_fatal_parse_error(source: &str) -> Option<String> {
    first_fatal_parse_error_with_config(source, tcl_lexer::LexerConfig::default())
}

/// Like [`first_fatal_parse_error`] but lexing under an explicit dialect
/// [`tcl_lexer::LexerConfig`], so a version-pinned host rejects exactly what
/// its emulated release rejects — under the Tcl 8.4 grammar `{*}{a b}` is a
/// hard `extra characters after close-brace`, which the default (8.5+) config
/// lexes as an ordinary expansion.
#[must_use]
pub fn first_fatal_parse_error_with_config(
    source: &str,
    config: tcl_lexer::LexerConfig,
) -> Option<String> {
    first_fatal_parse_cut(source, config).map(|cut| cut.message.to_owned())
}

/// The full [`tcl_lexer::ParseCut`] for `source` — the message *and* the
/// index of the top-level command it was found under.
///
/// The command index is what separates this from
/// [`first_fatal_parse_error_with_config`]: C runs every command before the
/// cut and only then raises, so a front-end that wants C's behaviour has to
/// know where the clean prefix ends. The message alone cannot say.
///
/// This is a thin re-export of [`tcl_lexer::first_parse_cut`] — the shared
/// owner — and exists so `tcl-compiler`'s consumers have one import for the
/// whole parse-error question rather than reaching past it into the lexer.
/// The lexer's flat **warning stream** cannot answer it: filtering that
/// stream by message and taking the lowest-offset hit disagrees with C
/// whenever the failure is nested — `list [sfx one] [list "oops]` warns
/// `missing close-bracket` where C reports `missing "` — and a welded
/// close-brace (`set y {a}b`) does not appear in the warning stream at all.
#[must_use]
pub fn first_fatal_parse_cut(
    source: &str,
    config: tcl_lexer::LexerConfig,
) -> Option<tcl_lexer::ParseCut> {
    tcl_lexer::first_parse_cut(source, config)
}

/// A Tcl script split at the first command whose parse is fatally malformed.
///
/// Both bytecode inline control-flow emission and runtime compilation consume
/// this owner. Keeping the command boundary beside the dialect-aware lexer
/// prevents `catch`/`try` paths from growing their own separator scanners.
pub(crate) struct CommandAtTimeScript {
    /// Complete commands before the malformed tail (all commands when clean).
    pub(crate) commands: Vec<crate::segmenter::SegmentedCommand>,
    /// Byte offset and Tcl parse message for the first malformed command,
    /// with the offset of the unclosed delimiter when there is one.
    ///
    /// That third field is C's `parsePtr->term`: `TclCompileScript` quotes
    /// `source[start ..= term]` in the `while executing` frame, so it is not
    /// derivable from the start offset or from the end of input (#2172).
    pub(crate) fatal_tail: Option<(usize, String, Option<u32>)>,
}

/// Segment `source` using `config`, retaining only complete commands before a
/// fatal command and recording the exact suffix boundary/error.
pub(crate) fn command_at_time_script_with_config(
    source: &str,
    config: tcl_lexer::LexerConfig,
) -> Result<CommandAtTimeScript, tcl_lexer::ParseCutUnavailable> {
    command_at_time_script_image(&tcl_lexer::SourceImage::document(source), config)
}

/// Complete command prefix of an original source image. Unavailable lexical
/// ownership remains distinct from an authentic malformed command tail.
pub(crate) fn command_at_time_script_image(
    source: &tcl_lexer::SourceImage,
    config: tcl_lexer::LexerConfig,
) -> Result<CommandAtTimeScript, tcl_lexer::ParseCutUnavailable> {
    let script = crate::segmenter::segment_script_image_with_offset_and_config(source, 0, config)?;
    Ok(CommandAtTimeScript {
        commands: script.commands,
        fatal_tail: script.fatal_tail.map(|tail| {
            (
                tail.command.span.start() as usize,
                tail.cut.message.to_owned(),
                Some(tail.cut.term),
            )
        }),
    })
}

/// Drive a configured [`Lowerer`] to a finished [`Module`] (the shared tail of
/// the `lower_to_ir*` entry points).
fn lower_with(mut lowerer: Lowerer<'_>, source: &str) -> Module {
    lowerer.lower(source);
    lowerer.finish_module(source)
}

impl Lowerer<'_> {
    /// Complete either module entry path after its top-level script has been
    /// lowered.  Namespace tables, OO extraction, source/profile stamps, and
    /// trace and callback-write facts deliberately have this one owner so
    /// compiling a runtime procedure target cannot drift from ordinary module
    /// lowering.
    pub(crate) fn finish_module(mut self, source: &str) -> Module {
        source.clone_into(&mut self.source);
        self.module.source =
            tcl_lexer::SourceImage::from_bytes(source.as_bytes(), self.source_channel);
        // Surface namespace import / export directives onto the module for
        // downstream consumers (codegen import resolution and warning passes).
        self.module.namespace_imports = std::mem::take(&mut self.namespace_imports);
        self.module.namespace_exports = std::mem::take(&mut self.namespace_exports);
        // Extract TclOO method bodies from the fully-assembled module
        // (cache-independent — see `extract_oo_methods_pass`).
        if self.compilation_scope == tcl_runtime_api::SourceCompilationScope::WholeModule {
            self.retain_installed_procedure_body_units();
            self.retain_hosted_procedure_body_units();
            self.extract_oo_methods_pass();
        }
        let registry = self.registry;
        let standalone_metadata = self.metadata_origin == LoweringMetadataOrigin::Standalone
            && self.source_entry_origin == SourceEntryOrigin::Authoring;
        let declared_frame_effects = crate::declared_frame_effects::collect_declared_frame_effects(
            registry,
            self.source_declared_commands
                .as_ref()
                .or(self.declared_commands),
        );
        let mut module = self.module;
        module.declared_frame_effects = declared_frame_effects;
        module.retained_source_bindings =
            self.module_source_bindings.as_deref().and_then(|bindings| {
                crate::command_binding::RetainedSourceModuleBindings::retain(
                    bindings, &module, registry,
                )
            });
        populate_trace_facts(&mut module, registry, standalone_metadata);
        module.deferred_writes = crate::deferred_writes::scan_module(&module, registry);
        module
    }
}

/// Post-lower scan for `trace add ...` calls that populates
/// `Module::traced_commands` / `has_dynamic_trace` (execution traces)
/// and `Module::traced_variables` / `has_dynamic_variable_trace`
/// (variable traces).
///
/// Runs over the top-level script + every procedure body + every `TclOO`
/// method body (`module.methods`, already populated by
/// `extract_oo_methods_pass` before this runs). Original command operands
/// contribute source-renderable keys from their retained lookup geometry;
/// missing or opaque geometry sets `has_dynamic_trace` so GVN treats every
/// call as potentially traced. Authored compatibility has its separate written
/// grammar; a descriptor label cannot supply an original trace operand.
/// Literal variable names targeted by any `Traits::
/// ESTABLISHES_VARIABLE_TRACE` subcommand — the registry's
/// `ArgRole::VarWrite` resolution for `trace add|remove|variable|vdelete`,
/// covering both the modern and deprecated legacy spellings — land in
/// `traced_variables`; non-literal targets flip
/// `has_dynamic_variable_trace`.
fn populate_trace_facts(module: &mut Module, registry: &CommandRegistry, standalone: bool) {
    // naming.compiler.original-analysis-metadata-context

    let actual = crate::registry_invocation::retained_module_metadata_context(registry, module);
    let context = actual.as_deref().map(Into::into).or_else(|| {
        (standalone && module.source_metadata_input.is_none())
            .then(|| {
                registry
                    .profile()
                    .map(tcl_registry::model::semantic::SemanticContext::for_profile)
                    .map(crate::registry_invocation::InvocationMetadataContext::from)
            })
            .flatten()
    });
    // Borrow every retained body instead of cloning it: a derived `Clone` of
    // cap-deep structured IR overflows a 2 MiB thread. The facts collect
    // separately and are applied once the walk has finished.
    let mut facts = TraceFacts::default();
    walk_for_trace(&module.top_level, &mut facts, registry, context);
    // Every statically-known frame, not just named procedures: a `trace`
    // call inside a `namespace eval` / `apply` body (`Module::body_units`)
    // or a `TclOO` method (`Module::methods`) is just as live as one inside
    // a `proc` — omitting either class here would silently under-populate
    // `traced_variables` the moment an optimiser pass starts reaching into
    // those bodies (`CompilationUnit::all_body_function_units`).
    for body in module
        .procedures
        .values()
        .map(|p| &p.body)
        .chain(module.body_lowerings().map(|(_, p)| &p.body))
        .chain(module.methods.values().map(|m| &m.body))
    {
        walk_for_trace(body, &mut facts, registry, context);
    }
    module.traced_variables.extend(facts.variables);
    module.traced_commands.extend(facts.commands);
    module.has_dynamic_variable_trace |= facts.dynamic_variable;
    module.has_dynamic_trace |= facts.dynamic;
}

/// Trace facts one retained-body walk collects for its [`Module`].
#[derive(Default)]
struct TraceFacts {
    variables: std::collections::BTreeSet<String>,
    commands: std::collections::BTreeSet<String>,
    dynamic_variable: bool,
    dynamic: bool,
}

/// Possible variable registrations are observer hazards even when receiver
/// lookup cannot select a unique normal handler. Execution traces retain their
/// stricter dispatch proof in the separate path below.
fn record_possible_variable_trace(
    transition: &tcl_registry::TraceTransition,
    module: &mut TraceFacts,
) {
    use tcl_registry::{TraceTarget, TraceTransition};
    let (TraceTransition::Add { target, .. } | TraceTransition::Remove { target, .. }) = transition;
    let TraceTarget::Variable(subject) = target else {
        return;
    };
    if let Some(target) = subject.literal() {
        let name = crate::variable_observation_names::module_observation_key(target);
        module.variables.insert(name.to_owned());
    } else {
        module.dynamic_variable = true;
    }
}

/// Collect typed trace transitions through the shared retained-body visitor.
fn walk_for_trace(
    script: &Script,
    module: &mut TraceFacts,
    registry: &CommandRegistry,
    context: Option<crate::registry_invocation::InvocationMetadataContext<'_>>,
) {
    crate::ir::for_each_statement(script, &mut |stmt| {
        if !matches!(stmt, Statement::Call { .. } | Statement::Barrier { .. }) {
            return;
        }
        let Some(context) = context else {
            // Missing source metadata cannot close either observer-hazard inventory.
            module.dynamic_variable = true;
            module.dynamic = true;
            return;
        };
        if let Some(possible) = stmt.tokens().and_then(|tokens| {
            crate::registry_invocation::possible_variable_trace_transitions_with_metadata_context(
                registry,
                Some(context),
                tokens,
            )
        }) {
            for transition in possible.transitions() {
                record_possible_variable_trace(transition, module);
            }
            if possible.metadata_unavailable() {
                module.dynamic_variable = true;
                module.dynamic = true;
            }
        }
        let Some(invocation) =
            crate::registry_invocation::resolved_statement_invocation_with_metadata_context(
                registry,
                Some(context),
                stmt,
            )
        else {
            return;
        };
        let Some(transitions) = invocation.facts.state_transitions.declared() else {
            return;
        };
        for fact in transitions.facts() {
            use tcl_registry::{StateTransition, TraceTarget, TraceTransition};
            let StateTransition::Trace(transition) = &fact.transition else {
                continue;
            };
            let (target, add) = match transition {
                TraceTransition::Add { target, .. } => (target, true),
                TraceTransition::Remove { target, .. } => (target, false),
            };
            match target {
                TraceTarget::Execution(subject) if add => {
                    let keys = stmt.tokens().and_then(|tokens| {
                        crate::registry_invocation::original_execution_trace_keys(
                            registry, context, tokens, subject,
                        )
                    });
                    if let Some(keys) = keys {
                        module.commands.extend(keys);
                    } else {
                        module.dynamic = true;
                    }
                }
                TraceTarget::Variable(_) | TraceTarget::Command(_) | TraceTarget::Execution(_) => {}
            }
        }
    });
}

#[cfg(test)]
mod tests {
    use crate::interprocedural::test_body_identity::{fixture_id, fixture_id_if_present};

    /// A Windows document: the cooked `namespace eval` body folds CRLF while
    /// the lowered body unit keeps original offsets, so its span must cover
    /// the whole written region up to the closing brace.
    #[test]
    fn crlf_namespace_eval_body_unit_spans_its_written_region() {
        let source = "namespace eval ::x {\r\n    set a 1\r\n    set b 2\r\n}\r\n";
        let registry = tcl_registry::model::ingress::static_context_for("tcl8.6").commands();
        let module = super::lower_to_ir_with_dialect(
            source,
            registry,
            tcl_lexer::LexerConfig::for_dialect("tcl8.6"),
            Some(tcl_dialect::DialectProfile::find("tcl8.6").expect("profile")),
        );
        let open = u32::try_from(source.find('{').unwrap() + 1).unwrap();
        let close = u32::try_from(source.rfind('}').unwrap()).unwrap();
        let spans = module
            .body_units
            .values()
            .filter(|unit| unit.body_kind == crate::ir::ProcedureBodyKind::NamespaceScript)
            .map(|unit| unit.span)
            .collect::<Vec<_>>();
        assert_eq!(spans, vec![tcl_lexer::Span::new(open, close)]);
    }

    fn fixture_method<'a>(
        methods: &'a crate::ir::MethodInventory,
        label: &str,
    ) -> Option<&'a crate::ir::MethodDef> {
        methods.unique_display(label).map(|(_, method)| method)
    }

    /// An opaque invocation retains its original evaluated argv without licensing
    /// native instructions, a known normal store, or an invented entered body.
    pub(super) fn assert_runtime_opaque_call(
        statement: &crate::ir::Statement,
        registry: &tcl_registry::CommandRegistry,
        expected_head: &str,
    ) {
        let crate::ir::Statement::Call {
            command,
            args,
            tokens: Some(tokens),
            ..
        } = statement
        else {
            panic!("expected retained invocation, got {statement:?}");
        };
        assert_eq!(command, expected_head);
        assert_eq!(tokens.words().len(), args.len() + 1);
        assert!(tokens.source_binding.is_some(), "missing dispatch receipt");
        assert!(crate::registry_invocation::proved_native_inline_operation(tokens).is_none());
        if let Some(region) = tokens.evaluated_body() {
            assert!(
                region.possible_bodies.is_some(),
                "runtime retains an analysis-only body inventory"
            );
            assert_eq!(
                region.selection,
                crate::execution_region::RegionSelection::MaySkip
            );
            assert_eq!(
                region.residual_effects,
                crate::execution_region::WrapperEffectProjection::OpaqueResidual
            );
        }
        let context = &tokens.source_binding.as_ref().unwrap().variable_context;
        let mutations =
            crate::place_bridge::statement_mutation_places(statement, context, registry);
        assert!(
            mutations
                .iter()
                .any(|place| place.kind == crate::place::PlaceKind::Unknown)
                || tokens.evaluated_body().is_some()
                || crate::registry_invocation::normal_transfer_invocation(registry, None, tokens)
                    .is_none(),
            "a runtime body cannot grant bounded normal stores: {mutations:?}"
        );
    }

    /// Every C-Tcl dialect folds a brace-word line continuation; the Jim
    /// answer is asserted in `jim_brace_continuation_binds_different_names`.
    const FOLD_RULES: WordValueRules = WordValueRules {
        brace: tcl_dialect::BraceBackslashNewline::Folds,
        list: tcl_dialect::ListParse::Strict,
    };

    /// `JimTcl`: the braced word keeps its bytes, and a malformed remainder is
    /// split rather than raised.
    const LITERAL_RULES: WordValueRules = WordValueRules {
        brace: tcl_dialect::BraceBackslashNewline::Literal,
        list: tcl_dialect::ListParse::Lenient,
    };

    /// A brace-word line continuation is folded to a space by every build of
    /// the Tcl core and kept verbatim by `JimTcl`, so a wrapped parameter or
    /// variable list binds *different names* in the two.
    ///
    /// Measured on jimsh 0.84 against tclsh 8.6. The two word kinds resolve
    /// the surviving `\<newline>` differently, because only one of them has a
    /// `name ?default?` level:
    ///
    /// * **Formal parameters** — `proc p {a b\<newline>c} {}` binds three
    ///   parameters under Tcl and *two* under Jim: the second element is the
    ///   specifier `b c`, so the parameter is `b` **defaulting to `c`**
    ///   (`p 1` leaves `b` as `c`; `p 1 2` sets it to `2`).
    /// * **Variable lists** — `foreach {a b\<newline>c} …` has no such level,
    ///   so Jim binds a variable whose name really is `b c`
    ///   (`info exists {b c}` is 1 and `info exists b` is 0).
    ///
    /// Jim's `info args` is no help here: unlike Tcl's it reports the raw
    /// specifiers (`a {b c}`), not the parameter names.
    #[test]
    fn jim_brace_continuation_binds_different_names() {
        let wrapped = "a b\\\nc";

        assert_eq!(
            parse_formal_param_names(
                wrapped,
                FOLD_RULES,
                Some(tcl_dialect::ParameterGrammar::Tcl)
            )
            .unwrap(),
            vec!["a", "b", "c"],
            "C Tcl folds the continuation into a separator"
        );
        assert_eq!(
            parse_formal_param_names(
                wrapped,
                LITERAL_RULES,
                Some(tcl_dialect::ParameterGrammar::Jim)
            )
            .unwrap(),
            vec!["a", "b"],
            "Jim keeps the bytes, so `b c` is one specifier: `b` defaulting to `c`"
        );

        assert_eq!(
            parse_var_list_names(wrapped, FOLD_RULES).unwrap(),
            vec!["a", "b", "c"]
        );
        assert_eq!(
            parse_var_list_names(wrapped, LITERAL_RULES).unwrap(),
            vec!["a", "b c"]
        );
    }

    /// `JimTcl`'s list parser never raises, so a word whose list text is
    /// malformed still binds names instead of collapsing lowering to a
    /// barrier. `llength "a {b"` is 2 under jimsh 0.84 and an error under
    /// tclsh 8.6, and the same split backs `foreach`'s variable list.
    #[test]
    fn malformed_list_word_binds_names_only_for_jim() {
        assert_eq!(
            parse_var_list_names("a {b", FOLD_RULES),
            None,
            "C Tcl raises, which lowering turns into a barrier"
        );
        assert_eq!(
            parse_var_list_names("a {b", LITERAL_RULES).unwrap(),
            vec!["a", "b"],
            "Jim splits it anyway — the unterminated element runs to the end"
        );
    }

    /// Both axes reach the helpers from the dialect, so `list_parse` is not
    /// silently left at its `Strict` default for a Jim document.
    #[test]
    fn list_word_rules_come_from_the_dialect() {
        use tcl_dialect::model::{Family, grammar};
        for &release in Family::Jim.releases() {
            let config = tcl_lexer::LexerConfig::from_grammar(grammar(Family::Jim, release));
            assert_eq!(
                WordValueRules::from_config(&config),
                LITERAL_RULES,
                "{release}"
            );
        }
        for &release in Family::Tcl.releases() {
            let config = tcl_lexer::LexerConfig::from_grammar(grammar(Family::Tcl, release));
            assert_eq!(
                WordValueRules::from_config(&config),
                FOLD_RULES,
                "{release}"
            );
        }
    }

    /// The knob is wired to the dialect, not chosen per call site.
    #[test]
    fn brace_continuation_comes_from_the_dialect() {
        use tcl_dialect::model::{Family, grammar};
        for &release in Family::Jim.releases() {
            assert_eq!(
                grammar(Family::Jim, release).brace_backslash_newline,
                tcl_dialect::BraceBackslashNewline::Literal,
                "{release}"
            );
        }
        for &release in Family::Tcl.releases() {
            assert_eq!(
                grammar(Family::Tcl, release).brace_backslash_newline,
                tcl_dialect::BraceBackslashNewline::Folds,
                "{release}"
            );
        }
    }

    use super::*;

    fn reg() -> CommandRegistry {
        // These fixtures assert concrete C Tcl behaviour, including 9.1 grammar.
        CommandRegistry::build_default().project_for_profile(
            tcl_registry::model::ingress::resolve_environment("tcl9.1").analyser_profile(),
        )
    }

    #[test]
    fn borrowed_lowering_retains_exact_ingress_before_finalisation() {
        let registry = tcl_registry::model::ingress::static_context_for("jim").commands();
        let profile = registry.profile().expect("selected profile");
        let config = tcl_lexer::LexerConfig::for_profile(Some(profile));
        let mut lowerer = Lowerer::with_config(registry, config);
        let module = lowerer.lower("set x 003");
        assert!(std::ptr::eq(
            module.resolved_profile().expect("profile"),
            profile
        ));
        assert!(module.registry_snapshot.is_some());
        assert_eq!(module.lexer_config, config);
        assert_eq!(
            module.word_values(),
            tcl_syntax::word_rules::WordValueRules::from_config(&config)
        );
    }

    #[test]
    fn runtime_procedure_target_retains_its_actual_activation() {
        let registry = tcl_registry::model::ingress::static_context_for("tcl8.6").commands();
        let mut lowerer = Lowerer::new(registry);
        let module = lowerer.lower_procedure_target("puts $x", "");
        let binding = module.top_level.statements[0]
            .tokens()
            .and_then(|tokens| tokens.source_binding.as_ref())
            .expect("positioned runtime procedure invocation");
        assert_eq!(
            binding.variable_frame,
            crate::var_resolve::VariableExecutionFrame::Procedure {
                namespace: "::".to_owned(),
                identity: "::top".to_owned(),
            }
        );
        assert_eq!(
            binding.variable_context.activation.as_deref(),
            Some("::top")
        );
    }

    #[test]
    fn catch_options_specialisation_requires_the_selected_completion_grammar() {
        for version in tcl_dialect::TclVersion::ALL {
            let dialect = format!("tcl{}", version.version_string());
            let registry = tcl_registry::model::ingress::static_context_for(&dialect).commands();
            let module = lower_to_ir("catch {set x executed} result options", registry);
            if version == tcl_dialect::TclVersion::V8_4 {
                assert!(matches!(
                    module.top_level.statements[0],
                    Statement::Barrier { .. }
                ));
            } else {
                assert!(matches!(
                    module.top_level.statements[0],
                    Statement::Catch { .. }
                ));
            }
        }
    }

    #[test]
    fn fatal_array_index_source_mask_follows_the_release() {
        let source = "puts $array({key})";
        for dialect in ["tcl8.4", "tcl8.6"] {
            assert_eq!(
                first_fatal_parse_error_with_config(
                    source,
                    tcl_lexer::LexerConfig::for_dialect(dialect)
                ),
                None,
                "{dialect} accepts the index text"
            );
        }
        for dialect in ["tcl9.0", "tcl9.1"] {
            assert_eq!(
                first_fatal_parse_error_with_config(
                    source,
                    tcl_lexer::LexerConfig::for_dialect(dialect)
                ),
                Some(tcl_lexer::INVALID_CHARACTER_IN_ARRAY_INDEX.to_owned()),
                "{dialect} rejects the raw brace"
            );
        }
    }

    #[test]
    fn irules_priority_uses_proved_native_identity_and_frozen_argument_value() {
        let profile = tcl_dialect::DialectProfile::irules();
        let registry = tcl_registry::model::ingress::static_context_for_profile(profile).commands();
        for (source, expected) in [
            (
                "proc priority {value} {return}; priority 700; when HTTP_REQUEST {}",
                500,
            ),
            (
                "set selected 700; priority $selected; when HTTP_REQUEST {}",
                700,
            ),
        ] {
            let module = lower_to_ir_with_config(
                source,
                registry,
                tcl_lexer::LexerConfig::from_grammar(profile.grammar),
            );
            assert_eq!(
                module
                    .procedures
                    .get(&fixture_id(&module.procedures, "::when::HTTP_REQUEST"))
                    .expect("authored fixture body")
                    .base_priority,
                expected
            );
        }
    }

    #[test]
    fn irules_event_priorities_follow_file_state_and_keep_repeated_handlers() {
        let profile = tcl_dialect::DialectProfile::irules();
        let registry = tcl_registry::model::ingress::static_context_for_profile(profile).commands();
        let module = lower_to_ir_with_config(
            "priority 700\n\
             when HTTP_REQUEST {}\n\
             priority 400\n\
             when HTTP_REQUEST {}\n\
             when HTTP_REQUEST priority 200 {}\n\
             when HTTP_REQUEST {}",
            registry,
            tcl_lexer::LexerConfig::from_grammar(profile.grammar),
        );

        let priorities: Vec<_> = [
            "::when::HTTP_REQUEST",
            "::when::HTTP_REQUEST#1",
            "::when::HTTP_REQUEST#2",
            "::when::HTTP_REQUEST#3",
        ]
        .into_iter()
        .map(|name| {
            module
                .procedures
                .get(&fixture_id(&module.procedures, name))
                .expect("authored fixture body")
                .base_priority
        })
        .collect();
        assert_eq!(priorities, [700, 400, 200, 400]);
    }

    #[test]
    fn irules_declaration_body_shape_gates_lowered_regions() {
        let profile = tcl_dialect::DialectProfile::irules();
        let registry = tcl_registry::model::ingress::static_context_for_profile(profile).commands();
        let module = lower_to_ir_with_config(
            "when HTTP_REQUEST priority 1001 {}\n\
             when HTTP_REQUEST bare_body\n\
             when CLIENT_DATA \"quoted body\"\n\
             proc bare_proc {} bare_body\n\
             proc quoted_proc {} \"return\"\n\
             proc valid_proc {} { return }\n\
             when NOT_A_REAL_EVENT {}\n\
             when HTTP_REQUEST priority 200 {}\n\
             when HTTP_REQUEST {}",
            registry,
            tcl_lexer::LexerConfig::from_grammar(profile.grammar),
        );

        assert!(
            fixture_id_if_present(&module.procedures, "::when::NOT_A_REAL_EVENT").is_some(),
            "a syntactically valid unknown event is lowered so the XC translator can report it"
        );
        for name in ["::when::CLIENT_DATA", "::bare_proc", "::quoted_proc"] {
            assert!(
                !fixture_id_if_present(&module.procedures, name).is_some(),
                "a non-braced declaration body must not open {name}"
            );
        }
        assert!(fixture_id_if_present(&module.procedures, "::valid_proc").is_some());
        let request = [
            module
                .procedures
                .get(&fixture_id(&module.procedures, "::when::HTTP_REQUEST"))
                .expect("authored fixture body")
                .base_priority,
            module
                .procedures
                .get(&fixture_id(&module.procedures, "::when::HTTP_REQUEST#1"))
                .expect("authored fixture body")
                .base_priority,
        ];
        assert_eq!(request, [200, 500], "valid repeated handlers keep priority");
    }

    #[test]
    fn irules_declarations_only_lower_at_the_file_surface() {
        let profile = tcl_dialect::DialectProfile::irules();
        let registry = tcl_registry::model::ingress::static_context_for_profile(profile).commands();
        let module = lower_to_ir_with_config(
            "if {1} {\n\
                 when CLIENT_DATA { pool top_level_nested_when }\n\
                 proc top_level_nested_proc {} { pool top_level_nested_proc }\n\
             }\n\
             when HTTP_REQUEST {\n\
                 if {1} {\n\
                     when SERVER_DATA { pool event_nested_when }\n\
                     proc event_nested_proc {} { pool event_nested_proc }\n\
                 }\n\
                 pool live_event\n\
             }\n\
             proc helper {} {\n\
                 if {1} {\n\
                     when HTTP_RESPONSE { pool proc_nested_when }\n\
                     proc proc_nested_proc {} { pool proc_nested_proc }\n\
                 }\n\
                 pool live_proc\n\
             }\n",
            registry,
            tcl_lexer::LexerConfig::from_grammar(profile.grammar),
        );

        for absent in [
            "::when::CLIENT_DATA",
            "::when::SERVER_DATA",
            "::when::HTTP_RESPONSE",
            "::top_level_nested_proc",
            "::event_nested_proc",
            "::proc_nested_proc",
        ] {
            assert!(
                fixture_id_if_present(&module.procedures, absent).is_none(),
                "nested declaration must remain inert: {absent}"
            );
        }
        assert!(fixture_id_if_present(&module.procedures, "::when::HTTP_REQUEST").is_some());
        assert!(fixture_id_if_present(&module.procedures, "::helper").is_some());
    }

    #[test]
    fn static_bool_accepts_unique_prefix_booleans() {
        // A condition folds boolean words by unique prefix, like Tcl
        // (`if {tr}` runs, `if {of}` does not — verified against tclsh).
        assert_eq!(static_bool("tr"), Some(true));
        assert_eq!(static_bool(" ye "), Some(true));
        assert_eq!(static_bool("on"), Some(true));
        assert_eq!(static_bool("of"), Some(false));
        assert_eq!(static_bool("n"), Some(false));
        assert_eq!(static_bool("0"), Some(false));
        assert_eq!(static_bool("1"), Some(true));
        // Ambiguous `o` (on/off) is not a static boolean.
        assert_eq!(static_bool("o"), None);
        assert_eq!(static_bool("$x"), None);
    }

    #[test]
    fn lowering_is_dialect_aware_via_expand_syntax() {
        // Lowering re-segments each
        // body under the document dialect.  For `if {*}$cond { puts hi }`,
        // on 8.5+ the `{*}` expands the condition, so the structured `if`
        // trips the expand-barrier (an opaque `Statement::Barrier` — the
        // structure can't be reasoned about); on 8.4 `{*}` is a literal
        // word, so the `if` lowers normally (no barrier).
        let reg = reg();
        let src = "if {*}$cond { puts hi }";
        let m90 = lower_to_ir_with_config(src, &reg, tcl_lexer::LexerConfig::default());
        let m84 = lower_to_ir_with_config(src, &reg, tcl_lexer::LexerConfig::for_dialect("tcl8.4"));
        let is_barrier = |m: &Module| {
            matches!(
                m.top_level.statements.first(),
                Some(Statement::Barrier { .. })
            )
        };
        assert!(
            is_barrier(&m90),
            "9.0 expands `{{*}}` → structured `if` becomes a barrier: {:?}",
            m90.top_level.statements,
        );
        assert!(
            !is_barrier(&m84),
            "8.4 treats `{{*}}` as literal → `if` lowers without a barrier: {:?}",
            m84.top_level.statements,
        );
    }

    /// Every structured form `try_dispatch_structured_hook` covers must
    /// barrier on `{*}` expansion.  A form that instead commits to its
    /// *un-expanded* argv fabricates nonsense IR — `lmap i {*}$spec {…}`
    /// becomes an `IRForeach` with one iterator over the literal word
    /// `${spec}`, making W210 claim a loop variable is read before it is set.
    #[test]
    fn every_argv_shaped_hook_barriers_on_expansion() {
        let reg = reg();
        for src in [
            // Forms whose argv shape is fixed by the hook.
            "foreach i {*}$spec {puts $i}",
            "if {*}$cond {puts hi}",
            "switch {*}$spec {a {puts hi}}",
            "while {*}$spec {puts hi}",
            "for {*}$spec {puts hi}",
            "proc {*}$spec {puts hi}",
            "namespace eval {*}$spec {puts hi}",
            // Forms it missed.
            "lmap i {*}$spec {puts $i}",
            "dict for {k v} {*}$rest {puts $k}",
            "array for {k v} {*}$rest {puts $k}",
            "foreachLine ln {*}$rest {puts $ln}",
            "catch {puts hi} {*}$rest",
            "try {puts hi} {*}$rest",
            "eval {*}$rest",
            "uplevel {*}$rest",
            "apply {*}$rest",
        ] {
            let m = lower_to_ir(src, &reg);
            assert!(
                matches!(
                    m.top_level.statements.first(),
                    Some(Statement::Barrier { .. })
                ),
                "`{src}` must barrier on `{{*}}` expansion: {:?}",
                m.top_level.statements,
            );
        }
    }

    /// The barrier is an *expansion* gate, not a blanket one: the same
    /// structured forms without `{*}` keep their specialised lowering, and a
    /// non-structured hook (`set`) never barriers on expansion at all — its
    /// own `has_expansion` check declines and the call reaches
    /// `lower_default`.
    #[test]
    fn expansion_barrier_leaves_unexpanded_and_non_structured_forms_alone() {
        let reg = reg();
        for src in [
            "foreach i $spec {puts $i}",
            "lmap i $spec {puts $i}",
            "catch {puts hi} err",
            "set {*}$rest",
            "puts {*}$rest",
        ] {
            let m = lower_to_ir(src, &reg);
            assert!(
                !matches!(
                    m.top_level.statements.first(),
                    Some(Statement::Barrier { .. })
                ),
                "`{src}` must not raise the expansion barrier: {:?}",
                m.top_level.statements,
            );
        }
    }

    /// The barrier reason names the command, which the compiler-explorer
    /// `--show ir` view quotes.
    #[test]
    fn expansion_barrier_reason_names_the_command() {
        let m = lower_to_ir("lmap i {*}$spec {puts $i}", &reg());
        let Some(Statement::Barrier { reason, .. }) = m.top_level.statements.first() else {
            panic!("expected a barrier: {:?}", m.top_level.statements);
        };
        assert_eq!(reason, "lmap with argument expansion");
    }

    #[test]
    fn empty_source() {
        let m = lower_to_ir("", &reg());
        assert_eq!(m.top_level.statements, [] as [crate::ir::Statement; 0]);
    }

    #[test]
    fn simple_set() {
        let m = lower_to_ir("set x 1", &reg());
        assert_eq!(m.top_level.statements.len(), 1);
        assert!(matches!(
            &m.top_level.statements[0],
            Statement::AssignConst { name, value, .. } if name == "x" && value == "1"
        ));
    }

    #[test]
    fn set_with_variable_value() {
        let m = lower_to_ir("set y $x", &reg());
        assert_eq!(m.top_level.statements.len(), 1);
        assert!(matches!(
            &m.top_level.statements[0],
            Statement::AssignValue { name, .. } if name == "y"
        ));
    }

    #[test]
    fn incr_command() {
        let m = lower_to_ir("incr i", &reg());
        assert_eq!(m.top_level.statements.len(), 1);
        assert!(matches!(
            &m.top_level.statements[0],
            Statement::Incr { name, .. } if name == "i"
        ));
    }

    // The `extract_oo_methods_pass` post-pass
    // lifts TclOO method bodies into `module.methods`.

    #[test]
    fn extracts_oo_class_methods() {
        let src = "oo::class create Counter {\n\
                   \x20   variable n\n\
                   \x20   constructor {} { set n 0 }\n\
                   \x20   method bump {} { incr n }\n\
                   \x20   method get {} { return $n }\n\
                   }\n";
        let m = lower_to_ir(src, &reg());
        let mut keys: Vec<String> = m
            .methods
            .values()
            .map(crate::ir::MethodDef::reporting_label)
            .collect();
        keys.sort();
        assert_eq!(
            keys,
            vec![
                "::Counter::<constructor>".to_string(),
                "::Counter::bump".to_string(),
                "::Counter::get".to_string(),
            ],
            "methods: {keys:?}",
        );
        let get =
            fixture_method(&m.methods, "::Counter::get").expect("unique retained fixture method");
        assert_eq!(get.method_name, "get");
        assert_eq!(get.kind, MethodKind::Method);
        assert_eq!(get.class_name, "::Counter");
        assert_eq!(
            get.execution_namespace,
            crate::ir::ExecutionNamespace::RuntimeSelected,
            "TclOO resolves relative commands in the runtime receiver namespace"
        );
        // `variable n` in the class body is an in-scope instance var
        // for every method (auto-linked).
        assert!(
            get.instance_vars.contains("n"),
            "get ivars: {:?}",
            get.instance_vars
        );
        // The method body is lowered for analysis (the `incr n` /
        // `return $n` statements are present, not an empty barrier).
        let bump =
            fixture_method(&m.methods, "::Counter::bump").expect("unique retained fixture method");
        assert!(
            !bump.body.statements.is_empty(),
            "bump body should be lowered"
        );
        let ctor = fixture_method(&m.methods, "::Counter::<constructor>")
            .expect("unique retained fixture method");
        assert_eq!(ctor.kind, MethodKind::Constructor);
        assert_eq!(m.redefined_methods.len(), 0);
        assert!(
            !m.oo_evidence.unretained_executable_roots,
            "every executable body in a fully static class was retained"
        );
    }

    #[test]
    fn lowers_oo_configurable_class_body() {
        // `oo::configurable create` (and `oo::abstract` / `oo::singleton`)
        // share the `METACLASS create NAME { body }` shape, so their bodies
        // must be lowered and their methods lifted like `oo::class`'s — not left
        // as an unanalysed barrier, which would skip every method body of a
        // class defined with `oo::configurable`.
        let src = "oo::configurable create Pin {\n\
                   \x20   property node\n\
                   \x20   method describe {} { return [my configure -node] }\n\
                   }\n";
        let m = lower_to_ir(src, &reg());
        assert!(
            m.methods
                .values()
                .any(|method| method.reporting_label() == "::Pin::describe"),
            "oo::configurable method must be lifted; methods: {:?}",
            m.methods.keys().collect::<Vec<_>>()
        );
        assert!(
            !fixture_method(&m.methods, "::Pin::describe")
                .expect("unique retained fixture method")
                .body
                .statements
                .is_empty(),
            "the method body should be lowered, not barriered"
        );
    }

    #[test]
    fn extracts_oo_define_methods_and_namespaced_class() {
        // `oo::define` adds methods to an existing class, and a class
        // created inside `namespace eval` qualifies under that ns.
        let src = "namespace eval ::app {\n\
                   \x20   oo::class create Widget {\n\
                   \x20       method draw {} { return ok }\n\
                   \x20   }\n\
                   }\n\
                   oo::define ::app::Widget {\n\
                   \x20   method hide {} { return done }\n\
                   }\n";
        let m = lower_to_ir(src, &reg());
        assert!(
            m.methods
                .values()
                .any(|method| method.reporting_label() == "::app::Widget::draw"),
            "methods: {:?}",
            m.methods.keys().collect::<Vec<_>>()
        );
        assert!(
            m.methods
                .values()
                .any(|method| method.reporting_label() == "::app::Widget::hide"),
            "methods: {:?}",
            m.methods.keys().collect::<Vec<_>>()
        );
    }

    // Extraction is driven by the registry definer grammars, so
    // oo::objdefine, snit, and itcl bodies produce method units too.

    // TP: an `oo::objdefine $obj { … }` body produces per-object method
    // units, so the body is visible to analysis.
    #[test]
    fn objdefine_bodies_produce_per_object_method_units() {
        let src = "oo::class create C {}\n\
                   set k [C new]\n\
                   oo::objdefine $k {\n\
                   \x20   variable z\n\
                   \x20   method probe {} { return $z }\n\
                   }\n";
        let m = lower_to_ir(src, &reg());
        let unit = m
            .methods
            .unique_display("::@objdefine@::k::probe")
            .map(|(_, method)| method)
            .unwrap_or_else(|| panic!("methods: {:?}", m.methods.keys().collect::<Vec<_>>()));
        assert_eq!(unit.method_name, "probe");
        assert!(!unit.body.statements.is_empty(), "body must be lowered");
        // The block's `variable z` is per-object state in scope for the
        // per-object method.
        assert!(
            unit.instance_vars.contains("z"),
            "ivars: {:?}",
            unit.instance_vars
        );
    }

    // TN: objdefine `variable` declarations are
    // per-object — they must NOT pollute the real class's cross-block
    // instance-variable union.
    #[test]
    fn objdefine_variables_stay_out_of_the_class_union() {
        let src = "oo::class create C {\n\
                   \x20   method m {} { info exists z }\n\
                   }\n\
                   set k [C new]\n\
                   oo::objdefine $k { variable z }\n";
        let m = lower_to_ir(src, &reg());
        let class_m = fixture_method(&m.methods, "::C::m").expect("unique retained fixture method");
        assert!(
            !class_m.instance_vars.contains("z"),
            "per-object `z` leaked into the class union: {:?}",
            class_m.instance_vars
        );
    }

    // TP (item 2): snit method / typemethod / constructor bodies become
    // method units, with the grammar's implicit member-body variables
    // (self / selfns / type / options) and declared type variables in scope.
    #[test]
    fn snit_type_bodies_produce_method_units() {
        let src = "snit::type Dog {\n\
                   \x20   variable name\n\
                   \x20   constructor {args} { set name fido }\n\
                   \x20   method bark {} { return \"$name barks\" }\n\
                   \x20   typemethod count {} { return 0 }\n\
                   }\n";
        let m = lower_to_ir(src, &reg());
        let bark = m
            .methods
            .unique_display("::Dog::bark")
            .map(|(_, method)| method)
            .unwrap_or_else(|| panic!("methods: {:?}", m.methods.keys().collect::<Vec<_>>()));
        assert_eq!(bark.kind, MethodKind::Method);
        assert_eq!(
            bark.execution_namespace,
            crate::ir::ExecutionNamespace::exact("::Dog")
        );
        assert_ne!(bark.body.statements, [] as [crate::ir::Statement; 0]);
        for implicit in ["self", "selfns", "type", "options", "name"] {
            assert!(
                bark.instance_vars.contains(implicit),
                "missing {implicit}: {:?}",
                bark.instance_vars
            );
        }
        assert_eq!(
            fixture_method(&m.methods, "::Dog::count")
                .expect("unique retained fixture method")
                .kind,
            MethodKind::ClassMethod,
            "typemethod dispatches on the type command"
        );
        assert!(
            m.methods
                .values()
                .any(|method| method.reporting_label() == "::Dog::<constructor>")
        );
    }

    // TP: the widget grammar's extra implicit vars (win / hull) reach
    // widget method units — registry data, not a name-suffix check.
    #[test]
    fn snit_widget_bodies_see_win_and_hull() {
        let src = "snit::widget MyBar {\n\
                   \x20   method redraw {} { return $win }\n\
                   }\n";
        let m = lower_to_ir(src, &reg());
        let redraw = m
            .methods
            .unique_display("::MyBar::redraw")
            .map(|(_, method)| method)
            .unwrap_or_else(|| panic!("methods: {:?}", m.methods.keys().collect::<Vec<_>>()));
        assert!(redraw.instance_vars.contains("win"));
        assert!(redraw.instance_vars.contains("hull"));
    }

    // TP (item 2): itcl method bodies — including the access-modifier
    // wrapped spellings — become method units with `this`, instance
    // variables, and commons in scope.
    #[test]
    fn itcl_class_bodies_produce_method_units() {
        let src = "itcl::class Toaster {\n\
                   \x20   variable crumbs 0\n\
                   \x20   common heat 3\n\
                   \x20   public method toast {n} { incr crumbs $n }\n\
                   \x20   method clean {} { set crumbs 0 }\n\
                   \x20   constructor {} { set crumbs 0 }\n\
                   }\n";
        let m = lower_to_ir(src, &reg());
        let toast = m
            .methods
            .unique_display("::Toaster::toast")
            .map(|(_, method)| method)
            .unwrap_or_else(|| panic!("methods: {:?}", m.methods.keys().collect::<Vec<_>>()));
        assert_eq!(toast.params, vec!["n".to_string()]);
        assert_eq!(
            toast.execution_namespace,
            crate::ir::ExecutionNamespace::exact("::Toaster")
        );
        for name in ["this", "crumbs", "heat"] {
            assert!(
                toast.instance_vars.contains(name),
                "missing {name}: {:?}",
                toast.instance_vars
            );
        }
        assert!(
            m.methods
                .values()
                .any(|method| method.reporting_label() == "::Toaster::clean")
        );
        assert!(
            m.methods
                .values()
                .any(|method| method.reporting_label() == "::Toaster::<constructor>")
        );
    }

    #[test]
    fn definition_member_words_use_positioned_source_and_retained_grammar() {
        // Software source projection only: no runtime member or frame grant.
        use crate::registry_invocation::EffectiveInvocationWord as Word;
        let source = "method {a\\\n  b} \"$name\" {*}$args";
        let config = tcl_lexer::LexerConfig::for_dialect("tcl8.6");
        for (config, expected) in [
            (config, "a b"),
            (
                tcl_lexer::LexerConfig {
                    brace_backslash_newline: tcl_dialect::BraceBackslashNewline::Literal,
                    ..config
                },
                "a\\\n  b",
            ),
        ] {
            let segment =
                crate::segmenter::segment_commands_with_offset_and_config(source, 0, config)
                    .pop()
                    .expect("one original member invocation");
            let tokens =
                CommandTokens::from_segmented(&tcl_lexer::SourceMap::new(source), config, &segment);
            assert_eq!(
                statement_words(&tokens, config),
                vec![
                    Word::Literal("method".to_owned()),
                    Word::Literal(expected.to_owned()),
                    Word::Dynamic,
                    Word::Expanded,
                ]
            );
        }
    }

    // TP: TclOO wrapper members — `self { method … }` lifts a
    // classmethod-kind unit, `private { method … }` an instance one; the
    // prefix spellings match.
    #[test]
    fn tcloo_wrapper_members_produce_units() {
        let src = "oo::class create W {\n\
                   \x20   self { method make {} { return [my new] } }\n\
                   \x20   private { method hidden {} { return 1 } }\n\
                   \x20   self method direct {} { return 2 }\n\
                   }\n";
        let m = lower_to_ir(src, &reg());
        assert_eq!(
            fixture_method(&m.methods, "::W::make").map_or_else(
                || panic!("methods: {:?}", m.methods.keys().collect::<Vec<_>>()),
                |d| d.kind
            ),
            MethodKind::ClassMethod
        );
        assert_eq!(
            fixture_method(&m.methods, "::W::direct")
                .expect("unique retained fixture method")
                .kind,
            MethodKind::ClassMethod
        );
        assert_eq!(
            fixture_method(&m.methods, "::W::hidden")
                .expect("unique retained fixture method")
                .kind,
            MethodKind::Method
        );
        assert!(!m.oo_evidence.unretained_executable_roots);
    }

    // TN: an `initialise` body is a *definition script* evaluated in the
    // class object's namespace, not a method frame — no unit.
    #[test]
    fn tcloo_initialise_body_is_not_a_method_unit() {
        let src = "oo::class create I {\n\
                   \x20   initialise { variable cache {} }\n\
                   \x20   method read {} { return 1 }\n\
                   }\n";
        let m = lower_to_ir(src, &reg());
        assert!(
            !m.methods
                .values()
                .any(|m| m.reporting_label().contains("initialise")),
            "methods: {:?}",
            m.methods.keys().collect::<Vec<_>>()
        );
        assert!(
            m.methods
                .values()
                .any(|method| method.reporting_label() == "::I::read")
        );
        assert!(
            m.oo_evidence.unretained_executable_roots,
            "the unrepresented initialise script must remain explicit evidence"
        );
    }

    // TN: `self constructor` / `self destructor` name no member (tclsh
    // 8.6.18, 9.0.4 and 9.1: `invalid command name "constructor"`), so
    // neither lifts a unit —
    // while the instance-side spellings beside them do.
    #[test]
    fn tcloo_self_constructor_and_destructor_lift_no_unit() {
        let src = "oo::class create S {\n\
                   \x20   self constructor {} { set a 1 }\n\
                   \x20   self destructor { set b 2 }\n\
                   \x20   method m {} { return 3 }\n\
                   }\n";
        let m = lower_to_ir(src, &reg());
        assert!(
            m.methods
                .values()
                .all(|d| !matches!(d.kind, MethodKind::Constructor | MethodKind::Destructor)),
            "methods: {:?}",
            m.methods.keys().collect::<Vec<_>>()
        );
        assert!(
            m.methods
                .values()
                .any(|method| method.reporting_label() == "::S::m")
        );
        let src = "oo::class create T {\n\
                   \x20   constructor {} { set a 1 }\n\
                   \x20   destructor { set b 2 }\n\
                   }\n";
        let m = lower_to_ir(src, &reg());
        assert_eq!(
            fixture_method(&m.methods, "::T::<constructor>")
                .expect("unique retained fixture method")
                .kind,
            MethodKind::Constructor
        );
        assert!(
            m.methods.values().any(|d| d.kind == MethodKind::Destructor),
            "methods: {:?}",
            m.methods.keys().collect::<Vec<_>>()
        );
    }

    // TN: a dynamic objdefine receiver that is not a simple variable
    // reference (a command substitution) stays un-extracted.
    #[test]
    fn objdefine_command_substitution_receiver_abstains() {
        let src = "oo::class create C {}\n\
                   oo::objdefine [C new] { method m {} { return 1 } }\n";
        let m = lower_to_ir(src, &reg());
        assert!(
            !m.methods
                .values()
                .any(|m| m.reporting_label().starts_with("::@objdefine@")),
            "methods: {:?}",
            m.methods.keys().collect::<Vec<_>>()
        );
        assert!(m.oo_evidence.unretained_executable_roots);
    }

    #[test]
    fn colliding_method_reports_retain_distinct_bodies_and_constructor_purposes() {
        let source = "namespace eval A {}\noo::class create A::B {method c {} {return LEFT}}\noo::class create A {method B::c {} {return RIGHT}; method <constructor> {} {return NAMED}; constructor {} {set local ACTUAL}; export B::c <constructor>}\n";
        let module = lower_to_ir(source, &reg());
        assert_eq!(module.methods.len(), 4);
        assert_eq!(
            module
                .methods
                .keys()
                .copied()
                .collect::<std::collections::HashSet<_>>()
                .len(),
            4
        );
        assert!(module.methods.unique_display("::A::B::c").is_none());
        assert!(
            module
                .methods
                .unique_display("::A::<constructor>")
                .is_none()
        );
        assert_eq!(
            module
                .methods
                .values()
                .filter(|method| method.kind == MethodKind::Constructor)
                .count(),
            1
        );
        assert_eq!(
            module
                .methods
                .values()
                .filter(|method| method.kind == MethodKind::Method
                    && method.method_name == "<constructor>")
                .count(),
            1
        );
        assert!(module.redefined_methods.is_empty());
        for id in module.methods.keys() {
            assert_eq!(module.method_definition_bodies(*id).count(), 1);
        }
    }

    #[test]
    fn redefined_oo_method_retains_the_replacement_body() {
        // A method redefined by a later `oo::define` keeps the first
        // body in `methods`, and RETAINS the replacement in
        // `redefined_methods` so analysis consumers can
        // scan every body a dispatch may run instead of abstaining.
        let src = "oo::class create C {\n\
                   \x20   method m {} { return 1 }\n\
                   }\n\
                   oo::define C {\n\
                   \x20   method m {} { return 2 }\n\
                   }\n";
        let m = lower_to_ir(src, &reg());
        assert!(
            m.methods
                .values()
                .any(|method| method.reporting_label() == "::C::m")
        );
        let (primary, replacements) = m
            .redefined_methods
            .iter()
            .next()
            .unwrap_or_else(|| panic!("redefined: {:?}", m.redefined_methods));
        assert_eq!(m.methods.get(primary).unwrap().method_name, "m");
        assert_eq!(replacements.len(), 1, "one replacement body retained");
        let retained = m.methods.get(&replacements[0]).unwrap();
        assert_eq!(retained.class_name, "::C");
        assert!(
            !retained.body.statements.is_empty(),
            "the replacement body is lowered, not discarded"
        );
        assert_eq!(m.oo_unanalysed_classes.len(), 0);
        assert!(!m.oo_evidence.dynamic_target);
        assert!(!m.oo_evidence.unretained_executable_roots);
    }

    #[test]
    fn unreadable_oo_members_flag_the_class_or_module() {
        // A dynamic member NAME may redefine any method of the class —
        // the class is flagged unanalysable.
        let m = lower_to_ir(
            "oo::class create C {\n    method m {} { return 1 }\n    method $n {} { return 2 }\n}\n",
            &reg(),
        );
        assert!(m.oo_unanalysed_classes.contains("::C"), "{m:?}");
        assert!(m.oo_evidence.unretained_executable_roots);
        // A dynamic member BODY is a method whose code no scan can read.
        let m = lower_to_ir("oo::class create C {\n    method m {} $body\n}\n", &reg());
        assert!(m.oo_unanalysed_classes.contains("::C"));
        assert!(m.oo_evidence.unretained_executable_roots);
        // A dynamic CLASS word may touch any class — module-wide flag.
        let m = lower_to_ir("oo::define $cls { method m {} { return 1 } }\n", &reg());
        assert!(m.oo_evidence.dynamic_target);
        assert!(m.oo_evidence.unretained_executable_roots);
        // A fully-static module sets neither.
        let m = lower_to_ir("oo::class create C { method m {} { return 1 } }\n", &reg());
        assert_eq!(m.oo_unanalysed_classes.len(), 0);
        assert!(!m.oo_evidence.dynamic_target);
        assert!(!m.oo_evidence.unretained_executable_roots);
    }

    #[test]
    fn every_unextracted_oo_body_shape_leaves_module_evidence() {
        for source in [
            // The outer definition script is computed, so the definer post-pass
            // cannot segment it.
            "oo::class create C [list method mutate {} { return 1 }]",
            // Inline oo::define is body-bearing but is not a braced definition
            // block accepted by classify_definer_call.
            "oo::class create C {}; oo::define C method mutate {} { return 1 }",
            // Accessor and configuration scripts are deliberately not MethodDef
            // frames, but remain runtime-callable executable bodies.
            "oo::configurable create C { property p -get { return 1 } }",
            "itcl::class C { variable value 0 { return 1 } }",
            // A definition created when an already-extracted method runs is not
            // visited by this source-root post-pass.
            "oo::class create Outer { method install {} { oo::class create Inner { method mutate {} { return 1 } } } }",
            // Definition scripts may invoke ordinary commands; such execution
            // is not represented by a lifted method body.
            "oo::class create C { ::rename ::set ::saved_set }",
        ] {
            let module = lower_to_ir(source, &reg());
            assert!(
                module.oo_evidence.unretained_executable_roots,
                "unretained executable definition body was not recorded: {source}"
            );
        }
    }

    #[test]
    fn oo_method_nested_proc_not_registered_globally() {
        // A `proc` defined inside a method body is created at
        // method-call time, not script load — it must not leak into
        // `module.procedures` (codegen safety).
        let src = "oo::class create C {\n\
                   \x20   method m {} { proc helper {} { return 1 }; return 2 }\n\
                   }\n\
                   proc toplevel {} { return 3 }\n";
        let m = lower_to_ir(src, &reg());
        assert!(
            fixture_id_if_present(&m.procedures, "::toplevel").is_some(),
            "procs: {:?}",
            m.procedures.keys().collect::<Vec<_>>()
        );
        assert!(
            !fixture_id_if_present(&m.procedures, "::helper").is_some(),
            "nested method proc must not be registered: {:?}",
            m.procedures.keys().collect::<Vec<_>>()
        );
        // The method body still lowered the `proc helper ...` call.
        assert!(
            m.methods
                .values()
                .any(|method| method.reporting_label() == "::C::m")
        );
    }

    #[test]
    fn apply_body_proc_registers_in_lambda_namespace_not_callers() {
        // `apply`'s body runs in the namespace named by the lambda — or the
        // *global* namespace when none is given — NOT the caller's namespace.
        // So a nested `proc` registers as `::helper`, never `::foo::helper`
        // (Tcl `apply` manual).
        let src = "namespace eval foo {\n\
                   \x20   apply {{} { proc helper {} { return 1 } }}\n\
                   }\n";
        let m = lower_to_ir(src, &reg());
        assert!(
            fixture_id_if_present(&m.procedures, "::helper").is_some(),
            "apply body proc must register in the global namespace: {:?}",
            m.procedures.keys().collect::<Vec<_>>()
        );
        assert!(
            !fixture_id_if_present(&m.procedures, "::foo::helper").is_some(),
            "apply body proc must NOT inherit the caller namespace: {:?}",
            m.procedures.keys().collect::<Vec<_>>()
        );
    }

    #[test]
    fn apply_body_proc_uses_explicit_lambda_namespace() {
        // A lambda whose element 2 pins a namespace runs its body there.
        let src = "apply {{} { proc helper {} { return 1 } } ::bar}\n";
        let m = lower_to_ir(src, &reg());
        assert!(
            fixture_id_if_present(&m.procedures, "::bar::helper").is_some(),
            "explicit lambda namespace must be honoured: {:?}",
            m.procedures.keys().collect::<Vec<_>>()
        );
    }

    /// TP — a relative lambda namespace element homes against the GLOBAL
    /// namespace even from inside a qualified-name proc (`doc/apply.n`:
    /// "interpreted relative to the global namespace even if its name does
    /// not start with ::"; tclsh 9.0.4 probe `a2b_apply.tcl`). Mirrors the
    /// analyser's `handle_apply_command` so IR and analysis agree.
    #[test]
    fn apply_relative_lambda_namespace_homes_globally_not_to_the_caller() {
        let src = "proc ::caller::p {} { apply {{} { proc helper {} { return 1 } } sub} }\n";
        let m = lower_to_ir(src, &reg());
        assert!(
            fixture_id_if_present(&m.procedures, "::sub::helper").is_some(),
            "relative lambda ns must resolve against ::: {:?}",
            m.procedures.keys().collect::<Vec<_>>()
        );
        assert!(
            !fixture_id_if_present(&m.procedures, "::caller::sub::helper").is_some(),
            "relative lambda ns must NOT pin against the caller: {:?}",
            m.procedures.keys().collect::<Vec<_>>()
        );
    }

    #[test]
    fn no_oo_methods_for_plain_script() {
        let m = lower_to_ir("proc greet {} { puts hi }", &reg());
        assert_eq!(m.methods.len(), 0);
        assert_eq!(m.redefined_methods.len(), 0);
    }

    #[test]
    fn proc_definition() {
        let m = lower_to_ir("proc greet {name} {puts $name}", &reg());
        // proc emits a Statement::Call + registers a procedure.
        assert!(fixture_id_if_present(&m.procedures, "::greet").is_some());
        let p = m
            .procedures
            .get(&fixture_id(&m.procedures, "::greet"))
            .expect("authored fixture body");
        assert_eq!(p.params, vec!["name"]);
    }

    #[test]
    fn if_statement() {
        let m = lower_to_ir("if {1} {set x 1}", &reg());
        assert_eq!(m.top_level.statements.len(), 1);
        assert!(matches!(&m.top_level.statements[0], Statement::If { .. }));
    }

    #[test]
    fn logical_structure_does_not_grant_native_compilation() {
        let registry = reg();
        let source = "if {1} {set x 1}";
        let logical = lower_to_ir(source, &registry);
        assert!(matches!(
            logical.top_level.statements.first(),
            Some(Statement::If { .. })
        ));
        let mut native = Lowerer::new(&registry).for_bytecode_backend();
        native.source_entry_origin = SourceEntryOrigin::Driver;
        native.native_compilation.mode =
            tcl_registry::native_compilation::NativeCompilationMode::Direct;
        let emitted = lower_to_ir_with(native, source);
        let Some(Statement::Call {
            tokens: Some(tokens),
            ..
        }) = emitted.top_level.statements.first()
        else {
            panic!(
                "direct source entry has no admitted native compiler: {:?}",
                emitted.top_level
            );
        };
        assert!(
            crate::registry_invocation::admitted_native_compiler_invocation(
                &registry, None, tokens
            )
            .is_none()
        );
    }

    #[test]
    fn for_loop() {
        let m = lower_to_ir("for {set i 0} {$i < 10} {incr i} {puts $i}", &reg());
        assert_eq!(m.top_level.statements.len(), 1);
        assert!(matches!(&m.top_level.statements[0], Statement::For { .. }));
    }

    #[test]
    fn while_loop() {
        let m = lower_to_ir("while {1} {puts loop}", &reg());
        assert_eq!(m.top_level.statements.len(), 1);
        assert!(matches!(
            &m.top_level.statements[0],
            Statement::While { .. }
        ));
    }

    #[test]
    fn foreach_loop() {
        let m = lower_to_ir("foreach x {a b c} {puts $x}", &reg());
        assert_eq!(m.top_level.statements.len(), 1);
        assert!(matches!(
            &m.top_level.statements[0],
            Statement::Foreach { .. }
        ));
    }

    #[test]
    fn catch_statement() {
        let m = lower_to_ir("catch {error oops} result", &reg());
        assert_eq!(m.top_level.statements.len(), 1);
        assert!(matches!(
            &m.top_level.statements[0],
            Statement::Catch { .. }
        ));
    }

    #[test]
    fn generic_command() {
        let m = lower_to_ir("puts hello", &reg());
        assert_eq!(m.top_level.statements.len(), 1);
        assert!(matches!(
            &m.top_level.statements[0],
            Statement::Call { command, .. } if command == "puts"
        ));
    }

    #[test]
    fn multiple_commands() {
        let m = lower_to_ir("set x 1\nset y 2\nputs $x", &reg());
        assert_eq!(m.top_level.statements.len(), 3);
    }

    #[test]
    fn return_statement() {
        let m = lower_to_ir("return 42", &reg());
        assert_eq!(m.top_level.statements.len(), 1);
        assert!(matches!(
            &m.top_level.statements[0],
            Statement::Return { value: Some(v), .. } if v == "42"
        ));
    }

    #[test]
    fn returned_module_snapshots_retain_their_actual_source_owner() {
        use std::sync::Arc;

        let generation = tcl_registry::model::ingress::static_context_for("tcl8.6");
        let context = Arc::new(generation.with_command_store(Arc::clone(generation.commands())));
        let registry = generation.commands();
        let config = tcl_lexer::LexerConfig::for_dialect("tcl8.6");
        let source = "throw ERROR payload";
        for target in 0..3 {
            let mut lowerer = Lowerer::with_config(registry, config)
                .with_dialect(registry.profile())
                .with_context_registry(Arc::clone(&context));
            let module = match target {
                0 => lowerer.lower(source),
                1 => lowerer.lower_procedure_target(source, "::N"),
                _ => lowerer.lower_script_target(source, "::N"),
            };
            let owner = module
                .retained_source_bindings
                .as_ref()
                .expect("actual completed source");
            assert_eq!(module.source.bytes(), source.as_bytes());
            assert!(
                owner.positioned_for_module(module, registry).is_some(),
                "{target}"
            );
            let mut changed = module.clone();
            changed.source = tcl_lexer::SourceImage::document("throw ERROR changed");
            assert!(owner.positioned_for_module(&changed, registry).is_none());
            let mut changed = module.clone();
            changed.lexer_config.strict_quoting = !changed.lexer_config.strict_quoting;
            assert!(owner.positioned_for_module(&changed, registry).is_none());
        }
    }

    #[test]
    fn lower_to_ir_public_api() {
        let r = reg();
        let m = lower_to_ir("set x 1\nproc foo {} {return 1}", &r);
        assert_eq!(m.top_level.statements.len(), 2);
        assert!(fixture_id_if_present(&m.procedures, "::foo").is_some());
    }

    // A proc body homes nested definitions to the proc's *defining*
    // namespace, not the lexical namespace of the `proc` call.

    #[test]
    fn configured_source_ingress_retains_one_input_for_entry_and_module() {
        let registry = tcl_registry::model::ingress::static_context_for("tcl8.6").commands();
        let profile = registry.profile().unwrap();
        let config = tcl_lexer::LexerConfig::from_grammar(profile.grammar);
        let source = "proc f {p} {return $p}";
        let module = lower_to_ir_with_dialect(source, registry, config, Some(profile));
        let input = module
            .source_metadata_input
            .as_ref()
            .expect("actual configured source input");
        assert_eq!(
            module.source_entry.metadata_context.source_analysis_input(),
            Some(input)
        );
        assert!(module.source_entry.logical_source_input.is_none());
        assert_eq!(
            module
                .source_entry
                .options()
                .execution_name_policy()
                .unwrap()
                .native_recipe()
                .unwrap()
                .authority(),
            tcl_syntax::naming::NamePolicyAuthority::AuthoredSimulation
        );
        assert!(module.source_entry.native_entry.is_none());
        assert!(
            module
                .retained_source_bindings
                .as_ref()
                .unwrap()
                .matches_module(&module, registry)
        );
        let procedures = module.procedures.iter().collect::<Vec<_>>();
        assert_eq!(procedures.len(), 1);
        assert!(module.procedure_ids.owns(*procedures[0].0));
        assert_eq!(procedures[0].1.qualified_name, "::f");
    }

    #[test]
    fn original_name_operand_publishes_a_body_without_borrowing_the_head_lookup() {
        let registry = tcl_registry::model::ingress::static_context_for("tcl8.6").commands();
        let profile = registry.profile().unwrap();
        let source = r#"proc f {p} {set b [set {$p}]; set a 1; set a 2; return "$a$b"}"#;
        let module = lower_to_ir_with_dialect(
            source,
            registry,
            tcl_lexer::LexerConfig::from_grammar(profile.grammar),
            Some(profile),
        );
        let procedures = module.procedures.iter().collect::<Vec<_>>();
        assert_eq!(procedures.len(), 1);
        let (id, procedure) = procedures[0];
        assert!(module.procedure_ids.owns(*id));
        assert_eq!(procedure.qualified_name, "::f");
        let tokens = module
            .top_level
            .statements
            .iter()
            .find_map(Statement::tokens)
            .expect("the actual original declaration command");
        let binding = tokens
            .source_binding
            .as_ref()
            .expect("original source binding");
        let input = binding
            .original_written_name_input(tokens, 1)
            .expect("actual original name operand");
        assert!(
            binding.original_command_lookup(tokens, &input).is_none(),
            "an operand cannot replace the original command-head owner"
        );
        assert!(module.source_entry.native_entry.is_none());
        assert_eq!(
            procedure.declaration_site.as_ref(),
            binding.invocation_site()
        );
        let head = binding
            .original_written_name_input(tokens, 0)
            .expect("actual original declaration head");
        assert_eq!(head.bytes(), b"proc");
        assert_eq!(input.bytes(), b"f");
        assert_ne!(
            head.original_word_key().unwrap().original_word(),
            input.original_word_key().unwrap().original_word()
        );
        let crate::signature_scan::scope::SignatureSourceNameInput::OriginalWord(key) = &input
        else {
            panic!("original literal name word");
        };
        assert_eq!(
            key.policy().authority(),
            tcl_syntax::naming::NamePolicyAuthority::AuthoredSimulation
        );
        if let Some(scope) = binding.original_operand_naming_scope(&input) {
            assert_eq!(
                procedure.publication.as_ref(),
                crate::signature_scan::scope::SignatureSourceCommand::procedure_from_key(
                    &scope, key
                )
                .as_ref()
            );
        } else {
            assert!(procedure.publication.is_none());
        }
    }

    #[test]
    fn proc_body_namespace_peels_the_names_own_qualifier() {
        // Unit-level: the helper is the inverse of `qualify_proc_name`.
        assert_eq!(proc_body_namespace("::a::outer", "::"), "::a");
        assert_eq!(proc_body_namespace("::b::c::o2", "::"), "::b::c");
        assert_eq!(proc_body_namespace("::plain", "::ignored"), "::");
        // A bare (unrooted) key can't come out of `qualify_proc_name`, but the
        // fallback must not manufacture an empty namespace if it ever did.
        assert_eq!(proc_body_namespace("plain", "::lex"), "::lex");
    }

    #[test]
    fn nested_proc_homes_to_the_outer_procs_defining_namespace() {
        // TP. On tclsh 9.0.4 and 8.6.16, identically:
        //   namespace eval ::a {}
        //   proc a::outer {} { proc helper {x} {return $x} }
        //   a::outer ; info commands ::a::helper   -> ::a::helper
        //              info commands ::helper      -> {}
        let m = lower_to_ir(
            "namespace eval ::a {}\nproc a::outer {} { proc helper {x} { return $x } }\n",
            &reg(),
        );
        assert!(
            fixture_id_if_present(&m.procedures, "::a::helper").is_some(),
            "nested proc must home to ::a, got {:?}",
            m.procedures.keys().collect::<Vec<_>>(),
        );
        assert!(
            !fixture_id_if_present(&m.procedures, "::helper").is_some(),
            "nested proc must NOT home lexically to ::",
        );
    }

    #[test]
    fn nested_proc_homing_composes_through_three_levels() {
        // TP. On tclsh, `proc g::o7 {} { proc o7b {} { proc h7 {u} … } }` →
        // running `g::o7` then `::g::o7b` leaves `::g::h7` (never `::h7`).
        let m = lower_to_ir(
            "namespace eval ::g {}\nproc g::o7 {} { proc o7b {} { proc h7 {u} { return $u } } }\n",
            &reg(),
        );
        assert!(fixture_id_if_present(&m.procedures, "::g::o7b").is_some());
        assert!(
            fixture_id_if_present(&m.procedures, "::g::h7").is_some(),
            "third level must stay in ::g, got {:?}",
            m.procedures.keys().collect::<Vec<_>>(),
        );
        assert!(!fixture_id_if_present(&m.procedures, "::h7").is_some());
    }

    #[test]
    fn nested_proc_name_qualifier_beats_the_lexical_namespace_eval() {
        // TP. On tclsh, inside `namespace eval ::d`, `proc ::e::o3` still homes
        // its body to `::e` — `::e::h3` exists, `::d::h3` and `::h3` do not.
        let m = lower_to_ir(
            "namespace eval ::e {}\nnamespace eval ::d {\n    proc ::e::o3 {} { proc h3 {z} { return $z } }\n}\n",
            &reg(),
        );
        assert!(
            fixture_id_if_present(&m.procedures, "::e::h3").is_some(),
            "got {:?}",
            m.procedures.keys().collect::<Vec<_>>(),
        );
        assert!(!fixture_id_if_present(&m.procedures, "::d::h3").is_some());
        assert!(!fixture_id_if_present(&m.procedures, "::h3").is_some());
    }

    #[test]
    fn unqualified_outer_proc_leaves_nested_homing_unchanged() {
        // TN. The common shape: lexical and defining namespace agree, so
        // homing changes nothing. Both at top level…
        let m = lower_to_ir("proc outer {} { proc inner {} { return 1 } }\n", &reg());
        assert!(fixture_id_if_present(&m.procedures, "::inner").is_some());
        // …and inside a `namespace eval`, where both are `::ns`.
        let m = lower_to_ir(
            "namespace eval ::ns {\n    proc outer {} { proc inner {} { return 1 } }\n}\n",
            &reg(),
        );
        assert!(
            fixture_id_if_present(&m.procedures, "::ns::inner").is_some(),
            "got {:?}",
            m.procedures.keys().collect::<Vec<_>>(),
        );
    }

    #[test]
    fn absolutely_named_nested_proc_is_unaffected() {
        // TN. On tclsh, `proc a::outer4 {} { proc ::abs {q} … }` creates `::abs`
        // — an absolute inner name ignores the enclosing frame entirely.
        let m = lower_to_ir(
            "namespace eval ::a {}\nproc a::outer4 {} { proc ::abs {q} { return $q } }\n",
            &reg(),
        );
        assert!(fixture_id_if_present(&m.procedures, "::abs").is_some());
        assert!(!fixture_id_if_present(&m.procedures, "::a::abs").is_some());
    }

    #[test]
    fn original_formal_name_headers_use_selected_grammar_and_keep_activation_separate() {
        // naming.variable.original-readonly-formal-topology

        let tcl = Some(tcl_dialect::ParameterGrammar::Tcl);
        let jim = Some(tcl_dialect::ParameterGrammar::Jim);
        assert_eq!(parse_formal_param_names("{a::b}", FOLD_RULES, tcl), None);
        assert_eq!(
            parse_formal_param_names("{a::b}", LITERAL_RULES, jim),
            Some(vec!["a::b".to_owned()])
        );
        assert_eq!(parse_formal_param_names("{a(1)}", FOLD_RULES, tcl), None);
        assert_eq!(
            parse_formal_param_names("{a(1)}", LITERAL_RULES, jim),
            Some(vec!["a(1)".to_owned()])
        );
        // Name-only headers retain original link spelling. They cannot claim
        // the ordinary local storage name or manufacture a caller-link frame.
        assert_eq!(
            parse_formal_param_names("&a {&b default}", LITERAL_RULES, jim),
            Some(vec!["&a".to_owned(), "&b".to_owned()])
        );
        assert_eq!(
            parse_formal_param_names("args args", LITERAL_RULES, jim),
            None
        );
        assert_eq!(
            parse_formal_param_names("args args", FOLD_RULES, tcl),
            Some(vec!["args".to_owned(), "args".to_owned()])
        );
        assert_eq!(parse_formal_param_names("a b", FOLD_RULES, None), None);
    }

    #[test]
    fn formal_param_names_take_the_specifier_name_only() {
        assert_eq!(
            parse_formal_param_names(
                "a b c",
                FOLD_RULES,
                Some(tcl_dialect::ParameterGrammar::Tcl)
            )
            .unwrap(),
            vec!["a", "b", "c"],
        );
        assert_eq!(
            parse_formal_param_names(
                "{x default} y",
                FOLD_RULES,
                Some(tcl_dialect::ParameterGrammar::Tcl)
            )
            .unwrap(),
            vec!["x", "y"]
        );
        assert_eq!(
            parse_formal_param_names("", FOLD_RULES, Some(tcl_dialect::ParameterGrammar::Tcl))
                .unwrap(),
            [] as [std::string::String; 0]
        );
        // A wrapped parameter list collapses its continuation before splitting.
        assert_eq!(
            parse_formal_param_names(
                "a b\\\n    c",
                FOLD_RULES,
                Some(tcl_dialect::ParameterGrammar::Tcl)
            )
            .unwrap(),
            vec!["a", "b", "c"]
        );
    }

    #[test]
    fn formal_param_names_reject_what_tcl_rejects() {
        // Tcl refuses to create these procedures, so lowering declines too.
        assert_eq!(
            parse_formal_param_names(
                "{a b c}",
                FOLD_RULES,
                Some(tcl_dialect::ParameterGrammar::Tcl)
            ),
            None
        );
        assert_eq!(
            parse_formal_param_names(
                "{a::b}",
                FOLD_RULES,
                Some(tcl_dialect::ParameterGrammar::Tcl)
            ),
            None
        );
        assert_eq!(
            parse_formal_param_names(
                "{a(1)}",
                FOLD_RULES,
                Some(tcl_dialect::ParameterGrammar::Tcl)
            ),
            None
        );
        assert_eq!(
            parse_formal_param_names("{a", FOLD_RULES, Some(tcl_dialect::ParameterGrammar::Tcl)),
            None
        );
    }

    #[test]
    fn var_list_names_keep_grouped_elements_whole() {
        assert_eq!(
            parse_var_list_names("a b", FOLD_RULES).unwrap(),
            vec!["a", "b"]
        );
        // tclsh 9.0: both spellings bind the one variable named `a b`.
        assert_eq!(
            parse_var_list_names("{a b}", FOLD_RULES).unwrap(),
            vec!["a b"]
        );
        assert_eq!(
            parse_var_list_names("a\\ b", FOLD_RULES).unwrap(),
            vec!["a b"]
        );
        assert_eq!(
            parse_var_list_names("", FOLD_RULES).unwrap(),
            [] as [std::string::String; 0]
        );
        assert_eq!(
            parse_var_list_names("a b\\\n    c", FOLD_RULES).unwrap(),
            vec!["a", "b", "c"]
        );
        // Unbalanced — no binding can be named, so the caller barriers.
        assert_eq!(parse_var_list_names("{a", FOLD_RULES), None);
    }

    // A formal-parameter list has two list levels, so a grouped or escaped
    // specifier is one parameter, not one name per whitespace run:
    // `proc p {a\ b} {}` has arity one.

    /// Parameter names recorded for `::p` when `src` is lowered.
    fn proc_params(src: &str) -> Vec<String> {
        let m = lower_to_ir(src, &reg());
        fixture_id_if_present(&m.procedures, "::p")
            .and_then(|id| m.procedures.get(&id))
            .unwrap_or_else(|| panic!("::p registered for {src:?}"))
            .params
            .clone()
    }

    #[test]
    fn escaped_space_proc_param_is_one_parameter() {
        // tclsh 9.0: `proc p {a\ b} {}` → `info args p` is `a`, with
        // `info default p a` yielding `b`. Only the name reaches the IR, so
        // the arity is one, not two (`a\` and `b`).
        assert_eq!(proc_params("proc p {a\\ b} {}"), vec!["a"]);
        // The grouped spelling decodes identically.
        assert_eq!(proc_params("proc p {{a b}} {}"), vec!["a"]);
    }

    #[test]
    fn proc_params_keep_defaults_and_args_as_names() {
        // FP-guard: `{x {y 2} args}` is still the three parameters `x`, `y`,
        // and the variadic `args`.
        assert_eq!(
            proc_params("proc p {x {y 2} args} {}"),
            vec!["x", "y", "args"]
        );
        assert_eq!(proc_params("proc p {} {}"), [] as [std::string::String; 0]);
    }

    #[test]
    fn proc_params_tcl_rejects_fall_through_to_barrier() {
        // tclsh: `proc p {{a b c}} {}` → "too many fields in argument
        // specifier". No procedure is created, so lowering registers none and
        // leaves the runtime `proc` to report it.
        for src in [
            "proc p {{a b c}} {}",
            "proc p {a::b} {}",
            "proc p {a(1)} {}",
        ] {
            let m = lower_to_ir(src, &reg());
            assert!(
                !fixture_id_if_present(&m.procedures, "::p").is_some(),
                "no ::p for {src:?}: {:?}",
                m.procedures.keys().collect::<Vec<_>>(),
            );
            assert!(
                matches!(&m.top_level.statements[0], Statement::Barrier { reason, .. } if reason == "malformed proc params"),
                "expected a malformed-params barrier for {src:?}, got {:?}",
                m.top_level.statements[0],
            );
        }
    }

    #[test]
    fn oo_method_params_use_the_formal_parameter_grammar() {
        let m = lower_to_ir(
            "oo::class create C {\n    method m {a\\ b {c 1}} { return 1 }\n}\n",
            &reg(),
        );
        let method = fixture_method(&m.methods, "::C::m").unwrap_or_else(|| {
            panic!(
                "::C::m lowered, got {:?}",
                m.methods.keys().collect::<Vec<_>>()
            )
        });
        assert_eq!(method.params, vec!["a", "c"]);
        // A parameter list Tcl rejects makes the whole class unanalysable.
        let m = lower_to_ir(
            "oo::class create C {\n    method m {{a b c}} { return 1 }\n}\n",
            &reg(),
        );
        assert!(m.oo_unanalysed_classes.contains("::C"), "{m:?}");
        assert!(
            !m.methods
                .values()
                .any(|method| method.reporting_label() == "::C::m")
        );
    }

    #[test]
    fn qualify_proc_name_global() {
        assert_eq!(qualify_proc_name("::", "foo"), "::foo");
    }

    #[test]
    fn qualify_proc_name_nested() {
        assert_eq!(qualify_proc_name("::ns", "bar"), "::ns::bar");
    }

    #[test]
    fn qualify_proc_name_already_qualified() {
        assert_eq!(qualify_proc_name("::ns", "::abs"), "::abs");
    }

    #[test]
    fn qualify_proc_name_preserves_colon_named_namespace_keys() {
        assert_eq!(qualify_proc_name(":::", ":"), "::::::");
        assert_eq!(qualify_proc_name("::a", "a:::b"), "::a::a::b");
        assert_eq!(tcl_syntax::naming::key_holder_and_tail("::::::").0, ":::");
    }

    #[test]
    fn parse_uplevel_level_decimal() {
        let relative = |shift| {
            Some(UplevelLevel {
                shift,
                absolute: false,
            })
        };
        assert_eq!(parse_uplevel_level("1"), relative(1));
        assert_eq!(parse_uplevel_level("3"), relative(3));
        assert_eq!(parse_uplevel_level("0"), relative(0));
    }

    #[test]
    fn parse_uplevel_level_hash_form() {
        let absolute = |shift| {
            Some(UplevelLevel {
                shift,
                absolute: true,
            })
        };
        assert_eq!(parse_uplevel_level("#0"), absolute(0));
        assert_eq!(parse_uplevel_level("#3"), absolute(3));
    }

    #[test]
    fn parse_uplevel_level_zero_keeps_absolute_and_relative_apart() {
        // `uplevel #0` runs the body in the global frame; `uplevel 0` runs it
        // in the current frame. Both carry the magnitude 0, so only the
        // `absolute` flag tells them apart — conflating them miscompiled the
        // command-word namespace of every `uplevel 0` body.
        let hash_zero = parse_uplevel_level("#0").expect("#0 parses");
        let bare_zero = parse_uplevel_level("0").expect("0 parses");
        assert_eq!(hash_zero.shift, bare_zero.shift);
        assert!(hash_zero.absolute);
        assert!(!bare_zero.absolute);
        assert_ne!(hash_zero, bare_zero);
    }

    #[test]
    fn parse_uplevel_level_dynamic_returns_none() {
        assert_eq!(parse_uplevel_level("$lvl"), None);
        assert_eq!(parse_uplevel_level("[expr {1+1}]"), None);
        assert_eq!(parse_uplevel_level("foo"), None);
    }

    #[test]
    fn uplevel_static_body_no_level() {
        let m = lower_to_ir("uplevel {set x 1}", &reg());
        assert_eq!(m.top_level.statements.len(), 1);
        match &m.top_level.statements[0] {
            Statement::UpFrame {
                frame_shift, body, ..
            } => {
                assert_eq!(*frame_shift, 1);
                assert_eq!(body.statements.len(), 1);
            }
            other => panic!("expected UpFrame, got {other:?}"),
        }
    }

    #[test]
    fn uplevel_static_body_with_level_one() {
        let m = lower_to_ir("uplevel 1 {set x 1}", &reg());
        match &m.top_level.statements[0] {
            Statement::UpFrame {
                frame_shift,
                absolute,
                ..
            } => {
                assert_eq!(*frame_shift, 1);
                assert!(!*absolute, "`uplevel 1` is the relative form");
            }
            other => panic!("expected UpFrame, got {other:?}"),
        }
    }

    #[test]
    fn uplevel_static_body_with_hash_zero() {
        let m = lower_to_ir("uplevel #0 {set x 1}", &reg());
        match &m.top_level.statements[0] {
            Statement::UpFrame {
                frame_shift,
                absolute,
                ..
            } => {
                assert_eq!(*frame_shift, 0);
                assert!(*absolute, "`uplevel #0` is the absolute global form");
            }
            other => panic!("expected UpFrame for #0, got {other:?}"),
        }
    }

    #[test]
    fn uplevel_static_body_with_bare_zero_is_relative() {
        // `uplevel 0 {body}` evaluates the body in the *current* frame, not
        // the global one. It shares the magnitude 0 with `#0` and is told
        // apart only by `absolute`.
        let m = lower_to_ir("uplevel 0 {set x 1}", &reg());
        match &m.top_level.statements[0] {
            Statement::UpFrame {
                frame_shift,
                absolute,
                ..
            } => {
                assert_eq!(*frame_shift, 0);
                assert!(!*absolute, "`uplevel 0` is the relative current-frame form");
            }
            other => panic!("expected UpFrame for bare 0, got {other:?}"),
        }
    }

    #[test]
    fn uplevel_dynamic_body_falls_back_to_default() {
        // ``uplevel 1 $body`` body is a $var, not a brace literal —
        // can't be statically resolved without const-propagation.
        // Falls back to ``lower_default`` (Statement::Call).
        let m = lower_to_ir("uplevel 1 $body", &reg());
        assert!(matches!(
            m.top_level.statements[0],
            Statement::Call { .. } | Statement::Barrier { .. }
        ));
    }

    #[test]
    fn uplevel_dynamic_level_falls_back_to_default() {
        // ``uplevel $lvl {body}`` — level is dynamic, can't pick a
        // ``frame_shift``. Falls back to default lowering.
        let m = lower_to_ir("uplevel $lvl {set x 1}", &reg());
        assert!(matches!(
            m.top_level.statements[0],
            Statement::Call { .. } | Statement::Barrier { .. }
        ));
    }

    #[test]
    fn const_prop_uplevel_resolves_set_var_body() {
        // ``set body {set x 1}; uplevel 1 $body`` inside a
        // proc — the const-map records ``body`` and the uplevel
        // folds in the literal as an UpFrame.
        let m = lower_to_ir("proc f {} { set body {set x 1}\n uplevel 1 $body }", &reg());
        let proc = fixture_id_if_present(&m.procedures, "::f")
            .and_then(|id| m.procedures.get(&id))
            .expect("proc registered");
        // proc body: [AssignConst(body), UpFrame { body: [...] }]
        let last = proc.body.statements.last().expect("body has statements");
        match last {
            Statement::UpFrame { body, .. } => {
                assert!(!body.statements.is_empty(), "expected lowered body");
            }
            other => panic!("expected UpFrame, got {other:?}"),
        }
    }

    #[test]
    fn const_prop_eval_resolves_set_var_body() {
        // ``eval $body`` with const-mapped body folds to a
        // Statement::Block.
        let m = lower_to_ir("proc f {} { set body {set x 1}\n eval $body }", &reg());
        let proc = fixture_id_if_present(&m.procedures, "::f")
            .and_then(|id| m.procedures.get(&id))
            .expect("proc registered");
        let last = proc.body.statements.last().expect("body has statements");
        match last {
            Statement::Block { body, .. } => {
                assert!(!body.statements.is_empty(), "expected lowered block");
            }
            other => panic!("expected Block, got {other:?}"),
        }
    }

    #[test]
    fn const_prop_eval_brace_body_emits_block() {
        // ``eval {body}`` in a proc context lowers to Block.
        let m = lower_to_ir("proc f {} { eval {set x 1} }", &reg());
        let proc = fixture_id_if_present(&m.procedures, "::f")
            .and_then(|id| m.procedures.get(&id))
            .expect("proc registered");
        assert!(matches!(proc.body.statements[0], Statement::Block { .. }));
    }

    #[test]
    fn const_prop_disabled_at_top_level() {
        // The const-map is gated on ``proc_depth > 0``. At
        // top-level, ``set body {set x 1}; uplevel 1 $body``
        // does NOT relax — the uplevel falls back to default
        // dispatch (Call / Barrier).
        let m = lower_to_ir("set body {set x 1}\nuplevel 1 $body", &reg());
        // statements[0] = AssignConst(body), [1] = uplevel call
        assert!(matches!(
            m.top_level.statements[1],
            Statement::Call { .. } | Statement::Barrier { .. }
        ));
    }

    #[test]
    fn const_prop_invalidated_on_reassignment() {
        // ``set body {a}; set body $other; uplevel 1 $body`` — the
        // second ``set`` invalidates the binding (RHS is a $var,
        // not a brace literal), so the uplevel can't fold.
        let m = lower_to_ir(
            "proc f {} { set body {a}\n set body $other\n uplevel 1 $body }",
            &reg(),
        );
        let proc = fixture_id_if_present(&m.procedures, "::f")
            .and_then(|id| m.procedures.get(&id))
            .expect("proc registered");
        let last = proc.body.statements.last().expect("body");
        assert!(
            !matches!(last, Statement::UpFrame { .. }),
            "expected fallback after re-assignment, got {last:?}",
        );
    }

    #[test]
    fn const_prop_eval_list_literal() {
        // ``eval [list set x 42]`` recognised as static body.
        let m = lower_to_ir("proc f {} { eval [list set x 42] }", &reg());
        let proc = fixture_id_if_present(&m.procedures, "::f")
            .and_then(|id| m.procedures.get(&id))
            .expect("proc registered");
        assert!(matches!(proc.body.statements[0], Statement::Block { .. }));
    }

    #[test]
    fn const_prop_eval_list_with_dynamic_arg_rejected() {
        // ``eval [list set x $v]`` — dynamic ``\$v`` rejects the
        // list-literal shape. Falls back to runtime barrier.
        let m = lower_to_ir("proc f {} { eval [list set x $v] }", &reg());
        let proc = fixture_id_if_present(&m.procedures, "::f")
            .and_then(|id| m.procedures.get(&id))
            .expect("proc registered");
        assert!(!matches!(proc.body.statements[0], Statement::Block { .. }));
    }

    #[test]
    fn const_prop_eval_non_list_command_rejected() {
        // ``eval [foo arg]`` — inner command isn't ``list``;
        // can't synthesise a body. Falls back to runtime barrier.
        let m = lower_to_ir("proc f {} { eval [foo arg] }", &reg());
        let proc = fixture_id_if_present(&m.procedures, "::f")
            .and_then(|id| m.procedures.get(&id))
            .expect("proc registered");
        assert!(!matches!(proc.body.statements[0], Statement::Block { .. }));
    }

    #[test]
    fn const_prop_does_not_leak_into_nested_proc() {
        // A ``set body {literal}`` in the outer proc must
        // NOT appear to a nested ``proc inner``'s
        // barrier-relaxation gate as a tracked literal.
        let m = lower_to_ir(
            "proc outer {} {\n  set body {set x 1}\n  proc inner {} { uplevel 1 $body }\n}",
            &reg(),
        );
        let inner = fixture_id_if_present(&m.procedures, "::inner")
            .and_then(|id| m.procedures.get(&id))
            .expect("inner registered");
        // The inner uplevel must remain a Call/Barrier — NOT an
        // UpFrame. If the const-map leaked, the inner body would
        // be folded as UpFrame { body: [set x 1], .. }.
        let last = inner.body.statements.last().expect("body");
        assert!(
            !matches!(last, Statement::UpFrame { .. }),
            "outer scope's const-map must not leak into nested proc, got {last:?}",
        );
    }

    #[test]
    fn ns_import_recorded_with_context_namespace() {
        // ``namespace import ::tcltest::*`` at top-level
        // records (``::``, ``::tcltest::*``).
        let m = lower_to_ir("namespace import ::tcltest::*", &reg());
        assert_eq!(
            m.namespace_imports,
            vec![("::".to_string(), "::tcltest::*".to_string())]
        );
    }

    #[test]
    fn ns_import_retains_relative_dependency_pattern() {
        let m = lower_to_ir("namespace import foo::*", &reg());
        assert_eq!(
            m.namespace_imports,
            vec![("::".to_owned(), "foo::*".to_owned())]
        );
    }

    #[test]
    fn ns_import_dependencies_preserve_selected_literal_patterns_and_order() {
        let m = lower_to_ir("namespace import foo::* ::* ::::* ::foo::* foo::*", &reg());
        assert_eq!(
            m.namespace_imports,
            ["foo::*", "::*", "::::*", "::foo::*", "foo::*"]
                .into_iter()
                .map(|pattern| ("::".to_owned(), pattern.to_owned()))
                .collect::<Vec<_>>()
        );
        let shadowed = lower_to_ir(
            "proc namespace args {}; namespace import foo::* ::foo::*",
            &reg(),
        );
        assert!(shadowed.namespace_imports.is_empty());
    }

    #[test]
    fn ns_import_handles_force_flag() {
        // ``-force`` is the documented option; the next word is
        // the pattern.
        let m = lower_to_ir("namespace import -force ::tcltest::*", &reg());
        assert_eq!(
            m.namespace_imports,
            vec![("::".to_string(), "::tcltest::*".to_string())]
        );
    }

    #[test]
    fn proc_dynamic_name_resolved_via_const_map() {
        // ``set name {Verbose}; proc \$name {} { ... }``
        // inside a proc — ``name`` is in the const-map, so the
        // inner proc registers as ``::Verbose``.
        let m = lower_to_ir(
            "proc factory {} { set name {Verbose}\n proc $name {} { puts hi } }",
            &reg(),
        );
        assert!(
            fixture_id_if_present(&m.procedures, "::Verbose").is_some(),
            "expected ::Verbose in {:?}",
            m.procedures.keys().collect::<Vec<_>>()
        );
    }

    #[test]
    fn proc_dynamic_name_no_binding_stays_barrier() {
        // ``proc \$name`` with no const-map entry — bail to barrier.
        let m = lower_to_ir("proc factory {} { proc $name {} { puts hi } }", &reg());
        let factory = fixture_id_if_present(&m.procedures, "::factory")
            .and_then(|id| m.procedures.get(&id))
            .expect("factory registered");
        let last = factory.body.statements.last().expect("body");
        assert!(
            matches!(last, Statement::Barrier { .. }),
            "expected Barrier, got {last:?}"
        );
    }

    #[test]
    fn proc_with_trailing_colons_routes_through_barrier() {
        // Tcl 9 ``proc ::ns:: {args} {body}`` registers a command
        // named ``""`` inside ``::ns``.  Static normalisation would
        // strip the trailing ``::`` and register the proc under the
        // namespace name itself — wrong cmd.  Route through
        // Statement::Barrier so the runtime ``proc`` builtin handles
        // the registration.
        let m = lower_to_ir("proc ::ns:: {a b} { puts $a$b }", &reg());
        // No procedure entry should have been AOT-registered under
        // ``::ns`` (which is what the bug would produce) or any
        // empty-key variant.
        assert!(
            !fixture_id_if_present(&m.procedures, "::ns").is_some()
                && !fixture_id_if_present(&m.procedures, "::ns::").is_some()
                && !fixture_id_if_present(&m.procedures, "").is_some(),
            "trailing-:: proc should not be AOT-registered; got {:?}",
            m.procedures.keys().collect::<Vec<_>>()
        );
        // The top-level statement should be a Barrier with the
        // empty-simple-name reason.
        let top = m
            .top_level
            .statements
            .last()
            .expect("at least one top-level statement");
        match top {
            Statement::Barrier {
                reason, command, ..
            } => {
                assert_eq!(command, "proc");
                assert!(
                    reason.contains("empty-simple-name"),
                    "unexpected barrier reason: {reason}"
                );
            }
            other => panic!("expected Statement::Barrier, got {other:?}"),
        }
    }

    #[test]
    fn proc_with_command_substitution_in_name_stays_barrier() {
        // ``proc \$name[suffix]`` — multi-token name with a command
        // substitution. The const-map gate only covers single-VAR
        // tokens; this stays on the runtime path.
        let m = lower_to_ir(
            "proc factory {} { set name {x}\n proc $name[suffix] {} { puts hi } }",
            &reg(),
        );
        // ``::factory`` registered; the inner proc must NOT be
        // registered under any literal name (``::x...``).
        assert!(
            !m.procedures
                .values()
                .any(|body| body.qualified_name.contains("suffix"))
        );
    }

    #[test]
    fn proc_subst_nocommands_body_materialised() {
        // ``proc \$name {x} [subst -nocommands {return \$default}]``
        // with both ``name`` and ``default`` const-tracked materialises
        // the body to ``return 0`` and lowers it as a real script.
        let m = lower_to_ir(
            "proc factory {} { set name {Verbose}\n set default {0}\n proc $name {x} [subst -nocommands {return $default}] }",
            &reg(),
        );
        let inner = fixture_id_if_present(&m.procedures, "::Verbose")
            .and_then(|id| m.procedures.get(&id))
            .expect("::Verbose registered");
        // Body should contain a Return statement (or at least be
        // non-empty — the materialised body lowers to a real
        // statement, not a Barrier).
        assert!(
            !inner.body.statements.is_empty(),
            "expected lowered body, got empty"
        );
    }

    #[test]
    fn foreach_line_lowers_to_foreach_statement() {
        // `foreachLine var filename body` lowers
        // to a single-iterator Statement::Foreach so variables assigned
        // inside the body propagate to the enclosing scope.  The
        // generic stdlib-proc path would route through Statement::Barrier and
        // lose that lattice information.
        let m = lower_to_ir(
            "foreachLine line /etc/hosts { set count [expr {$count + 1}] }",
            &reg(),
        );
        let stmts = &m.top_level.statements;
        let last = stmts.last().expect("at least one statement");
        match last {
            Statement::Foreach {
                iterators, is_lmap, ..
            } => {
                assert!(!is_lmap);
                assert_eq!(iterators.len(), 1);
                assert_eq!(iterators[0].vars, vec!["line".to_owned()]);
            }
            other => panic!("expected Statement::Foreach, got {other:?}"),
        }
    }

    #[test]
    fn foreach_line_var_body_routes_through_barrier() {
        // `foreachLine line file $body` — the body is a Var token,
        // which is single-token but NOT a braced literal.  Compiling
        // the literal `$body` text as a static loop body would
        // produce incorrect IR / data-flow; the lowering must fall
        // through to the runtime command via Barrier.
        let m = lower_to_ir("foreachLine line /etc/hosts $body", &reg());
        let last = m.top_level.statements.last().expect("top-level statement");
        match last {
            Statement::Barrier {
                reason, command, ..
            } => {
                assert_eq!(command, "foreachLine");
                assert!(
                    reason.contains("dynamic body"),
                    "unexpected reason: {reason}"
                );
            }
            other => panic!("expected Barrier for Var body, got {other:?}"),
        }
    }

    #[test]
    fn foreach_line_cmd_body_routes_through_barrier() {
        // Same guard for a `[cmd]` body — single-token but a Cmd
        // substitution, not a braced literal.
        let m = lower_to_ir("foreachLine line /etc/hosts [build-body]", &reg());
        let last = m.top_level.statements.last().expect("top-level statement");
        assert_runtime_opaque_call(last, &reg(), "foreachLine");
    }

    #[test]
    fn proc_var_body_const_map_materialised() {
        // A bare `$body` body word whose value
        // is in the const-map materialises into the Procedure body
        // (matching the `proc $name {x} $body` shape).
        let m = lower_to_ir(
            "proc factory {} { set name {Greeter}\n set body {return hi}\n proc $name {} $body }",
            &reg(),
        );
        let inner = fixture_id_if_present(&m.procedures, "::Greeter")
            .and_then(|id| m.procedures.get(&id))
            .expect("::Greeter registered");
        // The body was const-resolved to "return hi"; lowering it
        // produces a Return statement.
        assert!(
            !inner.body.statements.is_empty(),
            "expected lowered body, got empty"
        );
    }

    #[test]
    fn proc_var_body_unresolved_keeps_empty_body() {
        // `$body` has no const-map binding but `$name` does — the
        // proc name resolves, but the body stays empty (the runtime
        // proc call below carries the dynamic body text).
        let m = lower_to_ir(
            "proc factory {} { set name {Greeter}\n proc $name {} $body }",
            &reg(),
        );
        let inner = fixture_id_if_present(&m.procedures, "::Greeter")
            .and_then(|id| m.procedures.get(&id))
            .expect("::Greeter registered");
        assert_eq!(
            inner.body.statements.len(),
            0,
            "expected empty body for unresolved dynamic body, got {:?}",
            inner.body.statements
        );
    }

    #[test]
    fn proc_dynamic_params_routes_through_barrier() {
        // A dynamic params word — there's no static arg-list to
        // build a real Procedure from, so the whole proc shape
        // bails to a Barrier.  Even when the name resolves via the
        // const-map.
        let m = lower_to_ir(
            "proc factory {} { set name {x}\n proc $name $params { puts hi } }",
            &reg(),
        );
        // No inner procedure should be registered — params couldn't
        // be parsed statically.
        assert!(
            !fixture_id_if_present(&m.procedures, "::x").is_some(),
            "dynamic-params shape must not AOT-register: {:?}",
            m.procedures.keys().collect::<Vec<_>>()
        );
    }

    #[test]
    fn proc_multi_token_body_word_is_dynamic() {
        // `proc foo {} "pre${body}post"` — the body is a quoted
        // multi-token word.  Even though the first token is Str,
        // single_token_word is false so the whole word is dynamic
        // and we route through Barrier (the multi-token guard).
        let m = lower_to_ir(
            r#"proc factory {} { set body {return hi}; proc inner {} "pre${body}post" }"#,
            &reg(),
        );
        // `::inner` would only be registered if the body was
        // materialised — which can't happen for multi-token words.
        // We allow either no entry or an empty-body entry; the key
        // assertion is that the literal source text isn't compiled
        // as a script.
        if let Some(inner) =
            fixture_id_if_present(&m.procedures, "::inner").and_then(|id| m.procedures.get(&id))
        {
            assert_eq!(
                inner.body.statements.len(),
                0,
                "multi-token body must not be statically lowered, got {:?}",
                inner.body.statements
            );
        }
    }

    #[test]
    fn proc_subst_nocommands_missing_var_skips_materialisation() {
        // ``\$default`` is not in the const-map — the materialiser
        // refuses, leaving the body to fall back to runtime
        // dispatch.
        let m = lower_to_ir(
            "proc factory {} { set name {Verbose}\n proc $name {x} [subst -nocommands {return $default}] }",
            &reg(),
        );
        // Verbose not registered (because \$default missing means
        // we keep the dynamic body which routes via Barrier — but
        // the proc name itself was substituted). Actually
        // the proc IS registered with whatever the body lowering
        // produces; the assertion is that it's NOT the materialised
        // form.
        let inner =
            fixture_id_if_present(&m.procedures, "::Verbose").and_then(|id| m.procedures.get(&id));
        if let Some(p) = inner {
            // The body should not contain a Return whose value is
            // the literal "0" — that would be the materialised
            // form. It can be empty / contain a Barrier.
            // Conservative check: just verify the helper refused.
            // (The body might still lower the original CMD-token
            // text as a runtime call.)
            assert!(
                p.body.statements.is_empty()
                    || matches!(
                        p.body.statements[0],
                        Statement::Call { .. } | Statement::Barrier { .. }
                    )
            );
        }
    }

    /// Tcl 9.1's positive family names the same effect set `-nocommands`
    /// leaves — variables and backslashes on, commands off — so the body
    /// materialises the same way.
    ///
    /// tclsh 9.1b0, with `name` set to `world`:
    /// `subst -variables -backslashes {hello $name\n[format X]}` → `hello
    /// world`, a newline, then the untouched `[format X]`.
    #[test]
    fn proc_subst_tcl91_positive_switches_materialised() {
        let m = lower_to_ir(
            "proc factory {} { set name {Verbose}\n set default {0}\n proc $name {x} [subst -variables -backslashes {return $default}] }",
            &reg(),
        );
        let inner = fixture_id_if_present(&m.procedures, "::Verbose")
            .and_then(|id| m.procedures.get(&id))
            .expect("::Verbose registered");
        assert!(
            !inner.body.statements.is_empty(),
            "expected lowered body, got empty"
        );
        assert!(
            !matches!(inner.body.statements[0], Statement::Barrier { .. }),
            "expected a materialised body, got {:?}",
            inner.body.statements
        );
    }

    /// A computed switch word leaves the call unreadable, so the registry
    /// answers every kind and the materialiser refuses.
    #[test]
    fn proc_subst_computed_switch_word_refused() {
        let m = lower_to_ir(
            "proc factory {opt} { set name {Verbose}\n set default {0}\n proc $name {x} [subst $opt {return $default}] }",
            &reg(),
        );
        if let Some(p) =
            fixture_id_if_present(&m.procedures, "::Verbose").and_then(|id| m.procedures.get(&id))
        {
            assert!(
                p.body.statements.is_empty()
                    || matches!(
                        p.body.statements[0],
                        Statement::Call { .. } | Statement::Barrier { .. }
                    ),
                "expected no materialised body, got {:?}",
                p.body.statements
            );
        }
    }

    #[test]
    fn proc_subst_nocommands_nobackslashes_refused() {
        // ``-nobackslashes`` flag — semantics differ from our
        // evaluator's default. Refuse and fall through.
        let m = lower_to_ir(
            "proc factory {} { set name {Verbose}\n set default {0}\n proc $name {x} [subst -nobackslashes -nocommands {return $default}] }",
            &reg(),
        );
        let inner =
            fixture_id_if_present(&m.procedures, "::Verbose").and_then(|id| m.procedures.get(&id));
        if let Some(p) = inner {
            // Body did not materialise — should be empty or have
            // a fallback shape.
            assert!(
                p.body.statements.is_empty()
                    || matches!(
                        p.body.statements[0],
                        Statement::Call { .. } | Statement::Barrier { .. }
                    )
            );
        }
    }

    #[test]
    fn proc_dynamic_name_picks_latest_set() {
        // Multiple ``set`` calls — the most recent literal wins.
        let m = lower_to_ir(
            "proc factory {} { set name {First}\n set name {Second}\n proc $name {} { puts hi } }",
            &reg(),
        );
        assert!(fixture_id_if_present(&m.procedures, "::Second").is_some());
        assert!(!fixture_id_if_present(&m.procedures, "::First").is_some());
    }

    #[test]
    fn ns_export_recorded() {
        let m = lower_to_ir("namespace eval ::tcltest { namespace export test }", &reg());
        // The export was inside a ``namespace eval`` body so the
        // context namespace is ``::tcltest``.
        assert!(
            m.namespace_exports
                .iter()
                .any(|(ns, pat)| ns == "::tcltest" && pat == "test")
        );
    }

    #[test]
    fn namespace_directive_metadata_keeps_actual_availability_and_source_config() {
        // naming.compiler.original-analysis-metadata-context

        let baseline = tcl_registry::model::ingress::static_context_for("tcl8.6");
        let profile = tcl_dialect::DialectProfile::find("tcl8.6").unwrap();
        let mut registry = baseline.commands().project_for_profile(profile);
        let mut descriptor = registry.get("namespace").unwrap().clone();
        descriptor.surface = Some(tcl_dialect::model::SpecSurface::TCL86_PLUS);
        registry.insert(descriptor);
        let current =
            std::sync::Arc::new(baseline.with_command_store(std::sync::Arc::new(registry)));
        let older = std::sync::Arc::new(
            tcl_registry::model::ingress::static_context_for("tcl8.4")
                .with_command_store(std::sync::Arc::clone(current.commands())),
        );
        let config = tcl_lexer::LexerConfig::for_file_grammar(profile.grammar);
        let (_owner, native) =
            crate::environment_ingress::captured_native_entry_with_owner(profile);
        let entry = crate::command_binding::SourceAnalysisEntry {
            native_entry: Some(std::sync::Arc::new(native)),
            invocation_dialect: Some(tcl_registry::InvocationDialect::of_profile(profile)),
            native_compilation: crate::environment_ingress::authoring_native_compilation(),
            ..Default::default()
        };
        let make = |context: std::sync::Arc<tcl_registry::model::ContextRegistry>| {
            let input =
                crate::analyser::ResolvedAnalysisInput::new(profile, profile, context, config);
            let mut lowerer =
                Lowerer::with_config(current.commands(), config).with_dialect(Some(profile));
            lowerer.set_source_analysis_options(entry.options());
            lowerer.with_resolved_analysis_input(input)
        };
        let source = "namespace export exposed";
        let mut selected = make(std::sync::Arc::clone(&current));
        selected.lower(source);
        assert_eq!(
            selected.namespace_exports,
            [("::".to_owned(), "exposed".to_owned())]
        );
        let mut unavailable = make(older);
        unavailable.lower(source);
        assert!(unavailable.namespace_exports.is_empty());
        let mut missing = make(std::sync::Arc::clone(&current));
        missing.metadata_input = None;
        missing.dialect_context = None;
        missing.lower(source);
        assert!(missing.namespace_exports.is_empty());
        let logical_profile = tcl_dialect::DialectProfile::plain_tcl();
        let logical_input = crate::analyser::ResolvedAnalysisInput::new(
            logical_profile,
            logical_profile,
            std::sync::Arc::clone(&current),
            tcl_lexer::LexerConfig::for_file_grammar(logical_profile.grammar),
        );
        let mut missing_authoring =
            Lowerer::with_config(current.commands(), logical_input.lexer_config())
                .with_resolved_analysis_input(logical_input);
        assert!(missing_authoring.invocation_metadata_context().is_some());
        assert_eq!(
            missing_authoring.source_entry_origin,
            SourceEntryOrigin::Authoring
        );
        missing_authoring.metadata_input = None;
        missing_authoring.logical_source_input = None;
        missing_authoring.dialect_context = None;
        assert!(!missing_authoring.allows_standalone_registry_metadata());
        assert!(missing_authoring.invocation_metadata_context().is_none());
        missing_authoring.lower(source);
        assert!(missing_authoring.namespace_exports.is_empty());
        let mut stale = make(std::sync::Arc::clone(&current));
        stale.config.strict_quoting = !config.strict_quoting;
        stale.lower(source);
        assert!(stale.namespace_exports.is_empty());
        let mut foreign = make(
            tcl_registry::model::ingress::resolve_environment("tcl9.1").default_context_registry(),
        );
        foreign.lower(source);
        assert!(foreign.namespace_exports.is_empty());
    }

    #[test]
    fn namespace_directive_metadata_uses_frozen_handler_operands() {
        for source in [
            "set pattern {-c}; namespace export OLD; namespace export -clear $pattern -- x",
            "rename namespace ns; set pattern {-c}; ns export OLD; ns export -clear $pattern -- x",
        ] {
            let module = lower_to_ir(source, &reg());
            assert_eq!(
                module.namespace_exports,
                ["OLD", "-c", "--", "x"].map(|pattern| ("::".to_owned(), pattern.to_owned())),
                "{source}",
            );
        }
        let replaced = lower_to_ir("proc namespace args {}; namespace export x", &reg());
        assert_eq!(
            replaced.namespace_exports,
            [] as [(std::string::String, std::string::String); 0]
        );
    }

    #[test]
    fn ns_import_in_dead_branch_suppressed() {
        // ``if {0} { namespace import ::evil::* }`` — the
        // import is inside a syntactically-dead branch so it must
        // NOT be recorded.
        let m = lower_to_ir("if {0} { namespace import ::evil::* }", &reg());
        assert_eq!(
            m.namespace_imports.len(),
            0,
            "imports inside dead if{{0}} branch must not be collected, got {:?}",
            m.namespace_imports,
        );
    }

    #[test]
    fn ns_import_in_static_true_else_suppressed() {
        // ``if {1} { ... } else { namespace import ::evil::* }``
        // — the else branch is dead.
        let m = lower_to_ir(
            "if {1} { namespace import ::good::* } else { namespace import ::evil::* }",
            &reg(),
        );
        // Only ``::good::*`` recorded.
        assert_eq!(m.namespace_imports.len(), 1);
        assert_eq!(m.namespace_imports[0].1, "::good::*");
    }

    #[test]
    fn const_prop_inherited_into_catch_body() {
        // Child scope (catch body) inherits parent's const-map.
        let m = lower_to_ir(
            "proc f {} { set body {set x 1}\n catch { uplevel 1 $body } }",
            &reg(),
        );
        let proc = fixture_id_if_present(&m.procedures, "::f")
            .and_then(|id| m.procedures.get(&id))
            .expect("proc registered");
        // Look for a Catch wrapping an UpFrame.
        let catch_stmt = proc
            .body
            .statements
            .iter()
            .find(|s| matches!(s, Statement::Catch { .. }))
            .expect("expected Catch");
        if let Statement::Catch { body, .. } = catch_stmt {
            assert!(
                body.statements
                    .iter()
                    .any(|s| matches!(s, Statement::UpFrame { .. })),
                "expected UpFrame inside catch body, got {body:?}",
            );
        }
    }

    // trace add execution module-fact population

    #[test]
    fn trace_add_execution_literal_recorded() {
        let m = lower_to_ir("trace add execution foo enter handler", &reg());
        assert!(m.traced_commands.contains("foo"));
        assert!(!m.has_dynamic_trace);
    }

    #[test]
    fn trace_add_execution_dynamic_widens() {
        let m = lower_to_ir("trace add execution $cmd enter handler", &reg());
        assert!(m.has_dynamic_trace);
        assert_eq!(m.traced_commands.len(), 0);
    }

    #[test]
    fn trace_add_execution_qualified_canonicalised() {
        let m = lower_to_ir("trace add execution ::ns::foo enter h", &reg());
        // Stripped of leading ``::`` so the GVN gate's
        // `command.trim_start_matches("::")` lookup hits.
        assert!(m.traced_commands.contains("ns::foo"));
    }

    #[test]
    fn trace_add_variable_does_not_record_execution_trace() {
        // `trace add variable` is a separate channel — should not
        // populate `traced_commands` (those are command traces only).
        let m = lower_to_ir("trace add variable x write h", &reg());
        assert_eq!(m.traced_commands.len(), 0);
        assert!(!m.has_dynamic_trace);
    }

    /// `walk_for_trace`'s post-lower scan recurses once per nested
    /// `if`/`for`/`while`/`foreach`/`catch`/`try`/`switch`/`Block`/`UpFrame`
    /// body, with no depth cap of its own. Transitively bounded to
    /// `MAX_LOWER_NEST_DEPTH`
    /// (256) by `lower_script`/`lower_body` (this same `lower_to_ir` call
    /// builds the `Script` `walk_for_trace` then scans), so this is
    /// defence-in-depth / consistency with every other full-tree walker in
    /// this crate, not a currently-reproducible crash. 1000 levels of
    /// source nesting is comfortably past the cap; the assertion is
    /// that lowering (which runs `populate_trace_facts` ->
    /// `walk_for_trace`) returns at all, not what it returns. Spawns its
    /// own big-stack thread since the lexer/CST/segmenter stages upstream
    /// of `lower_script`'s own cap still walk the full un-truncated source
    /// nesting before that cap trims it — same rationale as
    /// `codegen::structured::tests::deeply_nested_if_survives_structured_walk`.
    #[test]
    fn deeply_nested_if_survives_walk_for_trace() {
        const DEPTH: usize = 1000;
        const STACK_SIZE: usize = 64 * 1024 * 1024;
        let mut src = String::new();
        for _ in 0..DEPTH {
            src.push_str("if {1} {\n");
        }
        src.push_str("trace add execution foo enter handler\n");
        for _ in 0..DEPTH {
            src.push_str("}\n");
        }
        std::thread::Builder::new()
            .stack_size(STACK_SIZE)
            .spawn(move || {
                let _ = lower_to_ir(&src, &reg());
            })
            .unwrap()
            .join()
            .unwrap();
    }

    // trace add/remove/variable/vdelete module-fact population

    #[test]
    fn trace_target_names_keep_empty_and_literal_sigil_data() {
        let registry = reg();
        let empty = lower_to_ir("trace add variable {} write callback", &registry);
        assert!(empty.traced_variables.contains(""));
        assert!(!empty.traced_variables.contains("$"));
        let literal = lower_to_ir("trace add variable {$counter} write callback", &registry);
        assert!(literal.traced_variables.contains("$counter"));
        assert!(!literal.traced_variables.contains("counter"));
    }

    #[test]
    fn trace_add_variable_literal_recorded() {
        let m = lower_to_ir("trace add variable x write h", &reg());
        assert!(m.traced_variables.contains("x"), "{:?}", m.traced_variables);
        assert!(!m.has_dynamic_variable_trace);
    }

    #[test]
    fn trace_remove_variable_literal_recorded() {
        // A `remove` only proves a trace *might* have existed — still
        // conservative to record, mirroring `trace add`.
        let m = lower_to_ir("trace remove variable x write h", &reg());
        assert!(m.traced_variables.contains("x"), "{:?}", m.traced_variables);
    }

    #[test]
    fn trace_add_variable_qualified_canonicalised() {
        let m = lower_to_ir("trace add variable ::x write h", &reg());
        // `::`-stripped so a top-level `set x 5` (chain key `x`) matches.
        assert!(m.traced_variables.contains("x"), "{:?}", m.traced_variables);
    }

    #[test]
    fn trace_add_variable_dynamic_widens() {
        let m = lower_to_ir("trace add variable $name write h", &reg());
        assert!(m.has_dynamic_variable_trace);
        assert_eq!(m.traced_variables.len(), 0);
    }

    #[test]
    fn trace_add_variable_inside_proc_recorded() {
        let m = lower_to_ir(
            "proc setup {} { trace add variable ::x read onread }",
            &reg(),
        );
        assert!(m.traced_variables.contains("x"), "{:?}", m.traced_variables);
    }

    #[test]
    fn trace_add_variable_inside_method_recorded() {
        // TclOO method bodies are extracted into `module.methods` (a
        // separate map from `module.procedures`) before this scan runs —
        // must not be missed just because it isn't a plain proc.
        let m = lower_to_ir(
            "oo::class create C {\n method m {} { trace add variable v write cb }\n}",
            &reg(),
        );
        assert!(m.traced_variables.contains("v"), "{:?}", m.traced_variables);
    }

    #[test]
    fn trace_legacy_variable_form_recorded() {
        // The deprecated `trace variable name ops command` spelling must
        // populate the same fact as `trace add variable` — no
        // hardcoded-per-form gap.
        let registry = tcl_registry::model::ingress::static_context_for("tcl8.6").commands();
        let m = lower_to_ir("trace variable x r onread", registry);
        assert!(m.traced_variables.contains("x"), "{:?}", m.traced_variables);
    }

    #[test]
    fn trace_legacy_vdelete_form_recorded() {
        let registry = tcl_registry::model::ingress::static_context_for("tcl8.6").commands();
        let m = lower_to_ir("trace vdelete x r onread", registry);
        assert!(m.traced_variables.contains("x"), "{:?}", m.traced_variables);
    }

    #[test]
    fn removed_legacy_trace_forms_do_not_donate_tcl9_transitions() {
        let registry = tcl_registry::model::ingress::static_context_for("tcl9.0").commands();
        for source in ["trace variable x r onread", "trace vdelete x r onread"] {
            let module = lower_to_ir(source, registry);
            assert!(module.traced_variables.is_empty());
            assert!(!module.has_dynamic_variable_trace);
        }
    }

    #[test]
    fn trace_info_variable_does_not_record() {
        // `trace info`/`vinfo` only query trace state — no
        // `ESTABLISHES_VARIABLE_TRACE` trait, so they must not widen the
        // module fact.
        let m = lower_to_ir("trace info variable x", &reg());
        assert_eq!(m.traced_variables.len(), 0);
        assert!(!m.has_dynamic_variable_trace);
    }

    #[test]
    fn trace_add_variable_through_interp_alias_recorded() {
        // `interp alias {} tracer {} trace` means `tracer add variable ...`
        // is really a `trace add variable ...` call — the whole-module scan
        // must key off the canonical (alias-resolved) command name, not the
        // source-surface `tracer` spelling, or this trace target is missed.
        let m = lower_to_ir(
            "interp alias {} tracer {} trace\ntracer add variable x write h",
            &reg(),
        );
        assert!(m.traced_variables.contains("x"), "{:?}", m.traced_variables);
    }

    #[test]
    fn trace_add_execution_through_interp_alias_recorded() {
        // Same alias-resolution requirement for the execution-trace channel:
        // `walk_for_trace` gates entry into both `traced_commands` and
        // `populate_variable_trace_facts` on one shared canonical-name check.
        let m = lower_to_ir(
            "interp alias {} tracer {} trace\ntracer add execution foo enter h",
            &reg(),
        );
        assert!(m.traced_commands.contains("foo"), "{:?}", m.traced_commands);
        assert!(!m.has_dynamic_trace);
    }

    #[test]
    fn trace_add_execution_does_not_record_variable_trace() {
        // The command-execution channel is separate — should not
        // populate `traced_variables`.
        let m = lower_to_ir("trace add execution foo enter h", &reg());
        assert_eq!(m.traced_variables.len(), 0);
        assert!(!m.has_dynamic_variable_trace);
    }

    #[test]
    fn trace_add_execution_inside_proc_recorded() {
        let m = lower_to_ir("proc init {} { trace add execution foo enter h }", &reg());
        assert!(
            m.traced_commands.contains("foo"),
            "traced_commands={:?}",
            m.traced_commands,
        );
    }

    #[test]
    fn trace_add_variable_abbreviated_type_word_recorded() {
        // `trace add v x write h` / `trace add var x write h` install the
        // same variable trace as the full `variable` spelling — C Tcl
        // accepts any unique prefix (checked against tclsh 8.6.14).
        let m = lower_to_ir("trace add v x write h", &reg());
        assert!(m.traced_variables.contains("x"), "{:?}", m.traced_variables);
        let m = lower_to_ir("trace add var x write h", &reg());
        assert!(m.traced_variables.contains("x"), "{:?}", m.traced_variables);
    }

    #[test]
    fn trace_remove_variable_abbreviated_type_word_recorded() {
        let m = lower_to_ir("trace remove var x write h", &reg());
        assert!(m.traced_variables.contains("x"), "{:?}", m.traced_variables);
    }

    #[test]
    fn trace_add_execution_abbreviated_type_word_not_variable() {
        // `e`/`exec` abbreviate `execution`, not `variable` — must not
        // widen `traced_variables`.
        let m = lower_to_ir("trace add e foo enter h", &reg());
        assert_eq!(m.traced_variables.len(), 0);
        assert!(m.traced_commands.contains("foo"), "{:?}", m.traced_commands);
    }

    #[test]
    fn trace_add_variable_inside_namespace_eval_body_recorded() {
        // A trace installed inside a `namespace eval` body (a synthetic
        // `Module::body_units` entry, not a named proc) must populate the
        // same whole-module fact as one inside a `proc`.
        let m = lower_to_ir(
            "namespace eval ::n { trace add variable ::x write h }",
            &reg(),
        );
        assert!(m.traced_variables.contains("x"), "{:?}", m.traced_variables);
    }

    #[test]
    fn trace_add_variable_inside_apply_body_recorded() {
        let m = lower_to_ir("apply {{} { trace add variable ::x write h }}", &reg());
        assert!(m.traced_variables.contains("x"), "{:?}", m.traced_variables);
    }

    #[test]
    fn trace_add_variable_inside_method_body_recorded() {
        let m = lower_to_ir(
            "oo::class create C { method m {} { trace add variable ::x write h } }",
            &reg(),
        );
        assert!(m.traced_variables.contains("x"), "{:?}", m.traced_variables);
    }

    // barrier-gate

    #[test]
    fn body_has_dynamic_barrier_clean() {
        // No barriers at all.
        assert!(!body_has_dynamic_barrier(
            "set x 1",
            &reg(),
            tcl_lexer::LexerConfig::default()
        ));
        // Barrier with a fully literal body.
        assert!(!body_has_dynamic_barrier(
            "eval { set x 1 }",
            &reg(),
            tcl_lexer::LexerConfig::default()
        ));
        // Nested literal.
        assert!(!body_has_dynamic_barrier(
            "if { 1 } { eval { set x 1 } }",
            &reg(),
            tcl_lexer::LexerConfig::default()
        ));
    }

    #[test]
    fn descriptor_binding_requirement_keeps_original_head_and_exact_metadata_without_native_receipt()
     {
        let mut registry = reg();
        let prototype = registry.get_exact("list").unwrap().clone();
        for label in ["::probe", ":probe", "A:::probe", "probe::", ""] {
            let mut descriptor = prototype.clone();
            descriptor.name = label;
            registry.insert(descriptor);
        }
        for label in ["::probe", ":probe", "A:::probe", "probe::", ""] {
            let source = if label.is_empty() {
                "{} value".to_owned()
            } else {
                format!("{label} value")
            };
            let mut lowerer = Lowerer::new(&registry);
            lowerer.word_space = WordSpace::new(&source, 0, lowerer.source_channel);
            lowerer.command_binding_site_stack.push(Vec::new());
            let commands = crate::segmenter::segment_commands_with_offset_and_config(
                &source,
                0,
                lowerer.config,
            );
            let key = registry.get_exact(label).unwrap().descriptor_key();
            lowerer.record_consumed_command_binding(
                &commands[0],
                "::",
                crate::registry_invocation::SelectedLoweringBindingIdentity::Logical(key),
            );
            let site = &lowerer.command_binding_site_stack[0][0];
            assert_eq!(site.binding.name, label);
            assert_eq!(
                site.binding.identity,
                tcl_syntax::naming::unroot_rooted_key(label).unwrap_or(label)
            );
            assert!(site.binding.namespace_context.is_none());
            assert!(
                site.source_tokens
                    .as_deref()
                    .unwrap()
                    .source_binding
                    .is_none()
            );
        }
    }

    #[test]
    fn unavailable_lowering_metadata_keeps_generic_dispatch_and_conservative_method_names() {
        let registry = reg();
        let source = "unresolved local $dynamic";
        let mut lowerer = Lowerer::new(&registry);
        lowerer.source_entry_origin = SourceEntryOrigin::Driver;
        lowerer.metadata_origin = LoweringMetadataOrigin::Supplied;
        lowerer.word_space = WordSpace::new(source, 0, lowerer.source_channel);
        let commands =
            crate::segmenter::segment_commands_with_offset_and_config(source, 0, lowerer.config);
        let statement = lowerer.lower_default(&commands[0], "::");
        let Statement::Call {
            canonical_command,
            defs,
            reads,
            ..
        } = &statement
        else {
            panic!("missing original/context ownership must retain a generic call");
        };
        assert!(canonical_command.is_none());
        assert!(defs.is_empty());
        assert!(reads.is_empty());
        assert_eq!(
            lowerer.advisory_method_instance_names(&statement),
            vec!["local", "${dynamic}"]
        );
    }

    #[test]
    fn method_variable_advice_preserves_literal_names_and_captured_prefix_values() {
        let registry = reg();
        let mut lowerer = Lowerer::new(&registry).trace_visible();
        lowerer.lower("variable {}; variable {$counter}; variable {brace{name}}; variable {-dash}");
        let names: Vec<_> = lowerer
            .module
            .top_level
            .statements
            .iter()
            .flat_map(|statement| lowerer.advisory_method_instance_names(statement))
            .collect();
        assert_eq!(names, vec!["", "$counter", "brace{name}", "-dash"]);

        let mut captured = Lowerer::new(&registry).trace_visible();
        captured.lower("interp alias {} ivar {} variable {$counter}; ivar");
        let statement = captured.module.top_level.statements.last().unwrap();
        assert_eq!(
            captured.advisory_method_instance_names(statement),
            vec!["$counter"]
        );
    }

    #[test]
    fn unresolved_method_name_protection_keeps_original_source_text_without_reparsing() {
        let registry = reg();
        let source = "unresolved {} {$counter} {brace{name}} {a(b)} {-dash} $dynamic";
        let mut lowerer = Lowerer::new(&registry);
        lowerer.source_entry_origin = SourceEntryOrigin::Driver;
        lowerer.metadata_origin = LoweringMetadataOrigin::Supplied;
        lowerer.word_space = WordSpace::new(source, 0, lowerer.source_channel);
        let commands =
            crate::segmenter::segment_commands_with_offset_and_config(source, 0, lowerer.config);
        let statement = lowerer.lower_default(&commands[0], "::");
        let Statement::Call { args, .. } = &statement else {
            panic!("generic source fallback");
        };
        assert_eq!(lowerer.advisory_method_instance_names(&statement), *args);
        assert_eq!(
            args,
            &vec!["", "$counter", "brace{name}", "a(b)", "-dash", "${dynamic}"]
        );
    }

    #[test]
    fn local_body_literal_reference_lookup_uses_whole_scalar_source_geometry() {
        let registry = reg();
        let mut lowerer = Lowerer::new(&registry);
        lowerer.proc_depth = 1;
        lowerer.const_map_stack.push(HashMap::from([(
            "body".to_owned(),
            "return original".to_owned(),
        )]));
        for reference in ["$body", "${body}"] {
            assert_eq!(
                lowerer.const_map_lookup(reference).as_deref(),
                Some("return original")
            );
        }
        for reference in [
            "body",
            "$body suffix",
            "${body}suffix",
            "$body(index)",
            "${body(index)}",
            "$",
            "${body",
            "$::body",
        ] {
            assert_eq!(lowerer.const_map_lookup(reference), None, "{reference}");
        }
        lowerer.proc_depth = 0;
        assert_eq!(lowerer.const_map_lookup("$body"), None);
    }

    #[test]
    fn local_body_literal_retention_requires_actual_assignment_and_decodes_the_written_key() {
        let config = tcl_lexer::LexerConfig::default();
        let source = r"set b\x6fdy {return original}";
        let commands = crate::segmenter::segment_commands_with_offset_and_config(source, 0, config);
        let seg = &commands[0];
        let assignment = Statement::AssignConst {
            span: seg.span,
            name: seg.args()[0].clone(),
            name_braced: false,
            value: seg.args()[1].clone(),
            value_span: None,
        };
        assert_eq!(
            assigned_local_body_literal(seg, &assignment, config),
            Some(("body".to_owned(), "return original".to_owned()))
        );
        let opaque = Statement::Barrier {
            span: seg.span,
            reason: "opaque invocation".to_owned(),
            command: "set".to_owned(),
            canonical_command: None,
            args: seg.args().to_vec(),
            tokens: None,
        };
        assert_eq!(assigned_local_body_literal(seg, &opaque, config), None);
    }

    #[test]
    fn local_body_literal_invalidation_distinguishes_literal_sigils_and_decodes_write_keys() {
        let config = tcl_lexer::LexerConfig::default();
        let mut scope = HashMap::from([("body".to_owned(), "return original".to_owned())]);
        let write = |name: &str, name_braced: bool| Statement::AssignConst {
            span: tcl_lexer::Span::new(0, 0),
            name: name.to_owned(),
            name_braced,
            value: "replacement".to_owned(),
            value_span: None,
        };
        invalidate_const_map_for(&write("$body", true), &mut scope, config);
        assert!(scope.contains_key("body"));
        invalidate_const_map_for(&write("::body", true), &mut scope, config);
        assert!(scope.contains_key("body"));
        invalidate_const_map_for(&write(r"b\x6fdy", false), &mut scope, config);
        assert!(scope.is_empty());
        scope.insert("body".to_owned(), "return original".to_owned());
        invalidate_const_map_for(&write("body(index)", true), &mut scope, config);
        assert!(scope.is_empty());
        scope.insert("body".to_owned(), "return original".to_owned());
        invalidate_const_map_for(&write("$computed", false), &mut scope, config);
        assert!(scope.is_empty());
    }

    #[test]
    fn local_body_literal_generic_call_with_empty_defs_withdraws_all_retained_values() {
        let config = tcl_lexer::LexerConfig::default();
        let registry = reg();
        let mut lowerer = Lowerer::new(&registry);
        let source = "unknown_writer $computed replacement";
        lowerer.word_space = WordSpace::new(source, 0, lowerer.source_channel);
        let commands = crate::segmenter::segment_commands_with_offset_and_config(source, 0, config);
        let call = lowerer.lower_default(&commands[0], "::");
        assert!(matches!(&call, Statement::Call { defs, .. } if defs.is_empty()));
        let mut scope = HashMap::from([("body".to_owned(), "return original".to_owned())]);
        invalidate_const_map_for(&call, &mut scope, config);
        assert!(scope.is_empty());
    }

    #[test]
    fn local_body_literal_quiet_logical_source_retains_factory_names_and_bodies() {
        let context =
            tcl_registry::model::ingress::resolve_environment("tcl8.6").default_context_registry();
        let profile = tcl_dialect::DialectProfile::plain_tcl();
        let input = crate::analyser::ResolvedAnalysisInput::new(
            profile,
            profile,
            std::sync::Arc::clone(&context),
            tcl_lexer::LexerConfig::for_file_grammar(profile.grammar),
        );
        let source = "proc factory {} {set name {LiteralChild}; set body {return original}; proc $name {} $body}";
        let mut lowerer = Lowerer::with_config(context.commands(), input.lexer_config())
            .with_resolved_analysis_input(input);
        lowerer.lower(source);
        let module = lowerer.finish_module(source);
        let child = fixture_id_if_present(&module.procedures, "::LiteralChild")
            .and_then(|id| module.procedures.get(&id))
            .expect("genuine quiet Logical source retains the original child");
        assert_eq!(child.body_source.as_deref(), Some("return original"));
        assert!(module.source_entry.native_entry.is_none());
    }

    #[test]
    fn local_body_literal_opcode_without_original_quiet_source_owner_cannot_retain_contents() {
        let registry = reg();
        let source = "set body {return original}";
        let mut lowerer = Lowerer::new(&registry);
        lowerer.proc_depth = 1;
        lowerer.const_map_stack.push(HashMap::from([(
            "previous".to_owned(),
            "return stale".to_owned(),
        )]));
        lowerer.word_space = WordSpace::new(source, 0, lowerer.source_channel);
        let commands =
            crate::segmenter::segment_commands_with_offset_and_config(source, 0, lowerer.config);
        let seg = &commands[0];
        let synthetic = Statement::AssignConst {
            span: seg.span,
            name: seg.args()[0].clone(),
            name_braced: false,
            value: seg.args()[1].clone(),
            value_span: None,
        };
        lowerer.update_const_map(seg, &synthetic);
        assert!(lowerer.const_map_stack.last().unwrap().is_empty());
        assert_eq!(lowerer.original_native_written_argument_value(seg, 1), None);
    }

    #[test]
    fn local_body_literal_expression_and_value_evaluation_withdraw_unclosed_effects() {
        let registry = reg();
        let config = tcl_lexer::LexerConfig::default();
        for source in [
            "expr {[overwrite]}",
            "expr {$watched}",
            "set other [overwrite]",
            "set other $watched",
            "incr other $watched",
        ] {
            let module = lower_to_ir(source, &registry);
            let statement = module
                .top_level
                .statements
                .first()
                .expect("original statement");
            assert!(!matches!(statement, Statement::AssignConst { .. }));
            let mut scope = HashMap::from([("body".to_owned(), "return original".to_owned())]);
            invalidate_const_map_for(statement, &mut scope, config);
            assert!(scope.is_empty(), "unclosed effects: {source}");
        }
    }

    #[test]
    fn class_variable_source_union_keeps_decoded_names_and_slot_operation_boundaries() {
        let registry = reg();
        let profile = registry.profile().unwrap();
        let config = tcl_lexer::LexerConfig::for_profile(Some(profile));
        let source = r"variable -set {} {$counter} {brace{name}} {-dash}; variable \$counter";
        let segments = crate::segmenter::segment_commands_with_offset_and_config(source, 0, config);
        let names = declared_member_vars(
            &tcl_registry::definer::TCLOO_GRAMMAR,
            &segments,
            Some(profile.surface_query()),
            config,
        );
        assert_eq!(
            names,
            HashSet::from([
                "".to_owned(),
                "$counter".to_owned(),
                "brace{name}".to_owned(),
                "-dash".to_owned()
            ])
        );
        assert!(!names.contains("counter"));
        assert!(!names.contains("-set"));
        let escaped_segments = crate::segmenter::segment_commands_with_offset_and_config(
            r"variable \$counter",
            0,
            config,
        );
        assert_eq!(
            declared_member_vars(
                &tcl_registry::definer::TCLOO_GRAMMAR,
                &escaped_segments,
                Some(profile.surface_query()),
                config,
            ),
            HashSet::from(["$counter".to_owned()])
        );
    }

    #[test]
    fn class_variable_unknown_operands_keep_known_literal_protection_without_reference_parsing() {
        let registry = reg();
        let profile = registry.profile().unwrap();
        let config = tcl_lexer::LexerConfig::for_profile(Some(profile));
        let segments = crate::segmenter::segment_commands_with_offset_and_config(
            "variable $dynamic {} {$counter} {a(b)}",
            0,
            config,
        );
        let names = declared_member_vars(
            &tcl_registry::definer::TCLOO_GRAMMAR,
            &segments,
            Some(profile.surface_query()),
            config,
        );
        assert_eq!(
            names,
            HashSet::from(["".to_owned(), "$counter".to_owned(), "a(b)".to_owned()])
        );
        assert!(!names.contains("counter"));
        assert!(!names.contains("a"));
        assert!(!names.contains("dynamic"));
    }

    #[test]
    fn body_barrier_metadata_keeps_exact_selected_rooted_descriptor() {
        let mut registry = reg();
        assert!(body_has_dynamic_barrier(
            "::eval $body",
            &registry,
            tcl_lexer::LexerConfig::default()
        ));
        let mut rooted = registry.get_exact("list").unwrap().clone();
        rooted.name = "::eval";
        registry.insert(rooted);
        assert!(!body_has_dynamic_barrier(
            "::eval $body",
            &registry,
            tcl_lexer::LexerConfig::default()
        ));
        assert!(body_has_dynamic_barrier(
            "eval $body",
            &registry,
            tcl_lexer::LexerConfig::default()
        ));
        for head in ["::::eval", ":eval", "eval::", "eval:::member"] {
            assert!(!body_has_dynamic_barrier(
                &format!("{head} $body"),
                &registry,
                tcl_lexer::LexerConfig::default()
            ));
        }
    }

    #[test]
    fn body_has_dynamic_barrier_dynamic_eval_body() {
        // ``eval $x`` inside the outer body — dynamic.
        assert!(body_has_dynamic_barrier(
            "eval $x",
            &reg(),
            tcl_lexer::LexerConfig::default()
        ));
        // Same shape nested.
        assert!(body_has_dynamic_barrier(
            "if { 1 } { eval $x }",
            &reg(),
            tcl_lexer::LexerConfig::default()
        ));
    }

    #[test]
    fn body_has_dynamic_barrier_dynamic_uplevel_body() {
        assert!(body_has_dynamic_barrier(
            "uplevel 1 $body",
            &reg(),
            tcl_lexer::LexerConfig::default()
        ));
        assert!(body_has_dynamic_barrier(
            "uplevel #0 $b",
            &reg(),
            tcl_lexer::LexerConfig::default()
        ));
    }

    #[test]
    fn body_has_dynamic_barrier_requires_proved_uplevel_level() {
        // A numeric value selects a frame, but "marker" is the first script
        // word on every pinned C release. Bracing the last word cannot decide
        // which operation an unknown first value requests.
        for source in ["uplevel 0 {set x 1}", "uplevel #0 {set x 1}"] {
            assert!(!body_has_dynamic_barrier(
                source,
                &reg(),
                tcl_lexer::LexerConfig::default()
            ));
        }
        assert!(body_has_dynamic_barrier(
            "uplevel $lvl {set x 1}",
            &reg(),
            tcl_lexer::LexerConfig::default()
        ));
    }

    #[test]
    fn body_has_dynamic_barrier_qualified_eval_uplevel() {
        // ``::eval`` and ``::uplevel`` are also caught.
        assert!(body_has_dynamic_barrier(
            "::eval $x",
            &reg(),
            tcl_lexer::LexerConfig::default()
        ));
        assert!(body_has_dynamic_barrier(
            "::uplevel 1 $body",
            &reg(),
            tcl_lexer::LexerConfig::default()
        ));
    }

    /// The gate resolves `uplevel`'s script word through the
    /// registry's `ArgRole::Body` resolver, not a local level-word sniff, so
    /// every documented `uplevel ?level? arg ?arg ...?` shape agrees with
    /// `uplevel_body_arg_role_skips_optional_level` in `tcl-registry`.
    #[test]
    fn body_has_dynamic_barrier_uplevel_level_shapes_follow_the_registry() {
        let r = reg();
        // TN — a literal script in each level spelling relaxes.
        for clean in [
            "uplevel {set x 1}",
            "uplevel 1 {set x 1}",
            "uplevel #0 {set x 1}",
            "uplevel 0 {set x 1}",
        ] {
            assert!(
                !body_has_dynamic_barrier(clean, &r, tcl_lexer::LexerConfig::default()),
                "{clean} must not poison"
            );
        }
        // TP — a substituted script word in each level spelling poisons.
        for dirty in [
            "uplevel $body",
            "uplevel 1 $body",
            "uplevel #0 $body",
            "uplevel $lvl $body",
            "uplevel $lvl {set x 1}",
            "uplevel [expr {$n - 1}] {set x 1}",
            "uplevel 1 [gen]",
        ] {
            assert!(
                body_has_dynamic_barrier(dirty, &r, tcl_lexer::LexerConfig::default()),
                "{dirty} must poison"
            );
        }
        // FN guard — the words after the script word concatenate into it
        // (`SCRIPT_CONCATENATES_ARGS`), so a dynamic tail is still dynamic
        // even though the marked body word is a braced literal.
        assert!(body_has_dynamic_barrier(
            "uplevel 1 {set x} $tail",
            &reg(),
            tcl_lexer::LexerConfig::default()
        ));
        assert!(body_has_dynamic_barrier(
            "eval {set x} $tail",
            &reg(),
            tcl_lexer::LexerConfig::default()
        ));
        // …and an all-literal multi-word tail stays clean.
        assert!(!body_has_dynamic_barrier(
            "uplevel 1 {set x} {1}",
            &reg(),
            tcl_lexer::LexerConfig::default()
        ));
        // A bodyless `uplevel 1` is a wrong-#args error the registry exposes
        // no body word for — poison rather than guess.
        assert!(body_has_dynamic_barrier(
            "uplevel 1",
            &reg(),
            tcl_lexer::LexerConfig::default()
        ));
        // A local level sniff that strips a leading `-` before the digit test
        // would accept `-N` as a level; the registry does not, and the
        // registry is right.  On tclsh 8.6.14, with `proc -1 {args} {…}`
        // defined, `uplevel -1 {set x 1}` *calls* `-1` with `set x 1` — the
        // word is the script's first word, not a level.  tclsh9.0.4 instead
        // errors `bad level "-1"`.  Under either reading the word is an
        // unbraced script word, so the gate poisons.
        assert!(body_has_dynamic_barrier(
            "uplevel -1 {set x 1}",
            &reg(),
            tcl_lexer::LexerConfig::default()
        ));
    }

    /// The eval-family *subcommand*
    /// members carry `EVALUATES_CODE` / `SCRIPT_CONCATENATES_ARGS` on the
    /// subcommand, not on the `namespace` / `interp` spec.  Composing them
    /// (`invocation_traits`) plus registry-resolved body indices makes them
    /// flow through the same path a bare `eval` does, which a parent-only
    /// trait test missed entirely.
    #[test]
    fn body_has_dynamic_barrier_covers_compound_eval_family() {
        let r = reg();
        // TP — the script is substituted.
        assert!(body_has_dynamic_barrier(
            "namespace eval ns $body",
            &r,
            tcl_lexer::LexerConfig::default()
        ));
        assert!(body_has_dynamic_barrier(
            "namespace inscope ns $body",
            &r,
            tcl_lexer::LexerConfig::default()
        ));
        assert!(body_has_dynamic_barrier(
            "interp eval slave $body",
            &r,
            tcl_lexer::LexerConfig::default()
        ));
        // TN — a braced literal script relaxes, and its own contents are
        // still recursed.
        assert!(!body_has_dynamic_barrier(
            "namespace eval ns {set x 1}",
            &r,
            tcl_lexer::LexerConfig::default()
        ));
        assert!(body_has_dynamic_barrier(
            "namespace eval ns {eval $x}",
            &r,
            tcl_lexer::LexerConfig::default()
        ));
        // TN — a `namespace` subcommand that evaluates nothing is not a
        // barrier, however dynamic its arguments are.
        assert!(!body_has_dynamic_barrier(
            "namespace delete $ns",
            &r,
            tcl_lexer::LexerConfig::default()
        ));
        assert!(!body_has_dynamic_barrier(
            "namespace current",
            &r,
            tcl_lexer::LexerConfig::default()
        ));
    }

    /// TN for the barrier test itself: an ordinary command with a
    /// substituted argument is not a script evaluator, so it never poisons —
    /// the gate keys on the registry trait, not on "has a `$var` argument".
    #[test]
    fn body_has_dynamic_barrier_non_body_command_is_clean() {
        let r = reg();
        assert!(!body_has_dynamic_barrier(
            "set x $y",
            &r,
            tcl_lexer::LexerConfig::default()
        ));
        assert!(!body_has_dynamic_barrier(
            "puts [format %s $x]",
            &r,
            tcl_lexer::LexerConfig::default()
        ));
        assert!(!body_has_dynamic_barrier(
            "lappend acc $item",
            &r,
            tcl_lexer::LexerConfig::default()
        ));
        // A user command the registry does not know at all is not a barrier.
        assert!(!body_has_dynamic_barrier(
            "mycmd $script",
            &r,
            tcl_lexer::LexerConfig::default()
        ));
    }

    #[test]
    fn try_lower_eval_static_rejects_nested_dynamic_barrier() {
        // The relaxer would normally promote ``eval { ... }`` to a
        // ``Statement::Block``; with the barrier gate, the nested
        // ``eval $x`` poisons the relaxation and we fall back to
        // ``Statement::Barrier``.
        let m = lower_to_ir(r"eval { eval $x }", &reg());
        let stmt = m.top_level.statements.first().expect("at least one stmt");
        assert_runtime_opaque_call(stmt, &reg(), "eval");
    }

    #[test]
    fn try_lower_eval_static_clean_body_relaxes() {
        // No nested barrier — relaxes to Block.
        let m = lower_to_ir("eval { set x 1 }", &reg());
        let stmt = m.top_level.statements.first().expect("at least one stmt");
        let Statement::Block { error_context, .. } = stmt else {
            panic!("expected Block (relaxed), got {stmt:?}");
        };
        assert_eq!(
            *error_context,
            Some(tcl_registry::InlineBodyErrorContext::SameFrameScriptEvaluation),
        );
    }

    // The next three tests confirm `eval` and `uplevel` dispatch
    // through the registry-driven hook ID to the expected output.

    #[test]
    fn registry_dispatch_eval_static_body_lowers_to_block() {
        // `eval {body}` with a literal body should still relax
        // to `Statement::Block` when dispatched through the
        // registry-driven path.
        let m = lower_to_ir("eval { set y 2 }", &reg());
        let stmt = m.top_level.statements.first().expect("at least one stmt");
        assert!(
            matches!(stmt, Statement::Block { .. }),
            "expected Block via registry hook, got {stmt:?}",
        );
    }

    #[test]
    fn registry_dispatch_uplevel_static_body_lowers_to_upframe() {
        // `uplevel 1 {body}` with a literal body should lower
        // to a UpFrame via the registry-driven path.
        let m = lower_to_ir("uplevel 1 { set z 3 }", &reg());
        let stmt = m.top_level.statements.first().expect("at least one stmt");
        assert!(
            matches!(stmt, Statement::UpFrame { .. }),
            "expected UpFrame via registry hook, got {stmt:?}",
        );
    }

    #[test]
    fn registry_dispatch_unknown_command_falls_through_to_default() {
        // `lower_command` has no per-
        // name fallback — commands that aren't in the registry
        // (or whose `lowering_hook` is `None`) route directly
        // to [`Lowerer::lower_default`], which emits a generic
        // `Statement::Call`.  Pin that contract with a clearly
        // unknown command name.
        let m = lower_to_ir("totallyMadeUpCommand arg1 arg2", &reg());
        let stmt = m.top_level.statements.first().expect("at least one stmt");
        match stmt {
            Statement::Call { command, .. } => assert_eq!(
                command, "totallyMadeUpCommand",
                "expected generic Call via lower_default, got command={command}",
            ),
            other => panic!("expected Call via lower_default, got {other:?}"),
        }
    }

    #[test]
    fn deferred_tk_callback_does_not_hide_constructor_variable_defs() {
        let m = lower_to_ir(
            "entry .e -textvariable input -validatecommand {return 1}",
            &reg(),
        );
        let stmt = m.top_level.statements.first().expect("entry call");
        match stmt {
            Statement::Call { command, defs, .. } => {
                assert_eq!(command, "entry");
                assert_eq!(defs, &["::input"]);
            }
            other => panic!("deferred callback must not make the constructor opaque: {other:?}"),
        }
    }

    #[test]
    fn immediate_tcltest_body_remains_a_runtime_barrier() {
        let m = lower_to_ir(
            "tcltest::test sample description -body {error failure}",
            &reg(),
        );
        let stmt = m.top_level.statements.first().expect("test call");
        assert_runtime_opaque_call(stmt, &reg(), "tcltest::test");
    }

    #[test]
    fn same_invocation_command_prefix_is_a_runtime_barrier() {
        // naming.compiler.original-analysis-metadata-context

        let m = lower_to_ir("lsort -command compare {b a}", &reg());
        let stmt = m.top_level.statements.first().expect("lsort call");
        assert_runtime_opaque_call(stmt, &reg(), "lsort");
    }

    #[test]
    fn deferred_command_prefix_does_not_create_a_runtime_barrier() {
        // naming.compiler.original-analysis-metadata-context

        for (source, expected_command) in [
            ("scrollbar .s -command moved", "scrollbar"),
            ("trace add variable v write changed", "trace"),
        ] {
            let m = lower_to_ir(source, &reg());
            let stmt = m.top_level.statements.first().expect("callback host call");
            assert!(
                matches!(stmt, Statement::Call { command, .. } if command == expected_command),
                "a stored command prefix cannot affect its registration invocation: {stmt:?}",
            );
        }
    }

    #[test]
    fn complete_logical_source_keeps_original_structure_and_native_absence() {
        // naming.compiler.original-analysis-metadata-context

        let context =
            tcl_registry::model::ingress::resolve_environment("tcl9.1").default_context_registry();
        let profile = tcl_dialect::DialectProfile::plain_tcl();
        let input = crate::analyser::ResolvedAnalysisInput::new(
            profile,
            profile,
            std::sync::Arc::clone(&context),
            tcl_lexer::LexerConfig::for_file_grammar(profile.grammar),
        );
        let source = "proc subject {} {return VALUE}; set result VALUE";
        let mut current = Lowerer::with_config(context.commands(), input.lexer_config())
            .with_resolved_analysis_input(input.clone());
        current.lower(source);
        let module = current.finish_module(source);
        assert!(fixture_id_if_present(&module.procedures, "::subject").is_some());
        // Upstream keeps non-numeric bare literals as AssignValue so escape
        // spelling survives. This assertion covers IR/source ownership only.
        let statement = module.top_level.statements.iter().find(|statement| {
            matches!(statement, Statement::AssignValue { name, value, value_needs_backsubst: false, .. }
                if name == "result" && value == "VALUE")
        }).expect("unchanged literal assignment retains the upstream representation");
        let tokens = module
            .top_level
            .retained_source_tokens_for_statement(statement)
            .unwrap();
        let literal = crate::type_infer::original_literal_argument_contents(
            context.commands(),
            &module,
            tokens,
            1,
        )
        .expect("assignment retains its genuine original source");
        assert_eq!(literal.value(), "VALUE");
        assert_eq!(
            module.source_entry.logical_source_input.as_ref(),
            Some(&input)
        );
        assert!(module.source_entry.native_entry.is_none());
        assert!(module.source_entry.execution_name_policy.is_none());

        let mut stale = Lowerer::with_config(context.commands(), input.lexer_config());
        stale.config.strict_quoting = !stale.config.strict_quoting;
        stale = stale.with_resolved_analysis_input(input.clone());
        assert!(!fixture_id_if_present(&stale.lower(source).procedures, "::subject").is_some());
        let foreign = crate::analyser::ResolvedAnalysisInput::new(
            profile,
            profile,
            tcl_registry::model::ingress::resolve_environment("tcl8.6").default_context_registry(),
            input.lexer_config(),
        );
        let mut foreign = Lowerer::with_config(context.commands(), foreign.lexer_config())
            .with_resolved_analysis_input(foreign);
        assert!(!fixture_id_if_present(&foreign.lower(source).procedures, "::subject").is_some());

        let native_profile = context.commands().profile().unwrap();
        let native = crate::analyser::ResolvedAnalysisInput::new(
            native_profile,
            native_profile,
            std::sync::Arc::clone(&context),
            tcl_lexer::LexerConfig::for_file_grammar(native_profile.grammar),
        );
        // No supplied entry: a fresh tclsh defines `::subject`. Explicit unknown history still withholds it.
        let mut fresh = Lowerer::with_config(context.commands(), native.lexer_config())
            .with_resolved_analysis_input(native.clone());
        let module = fresh.lower(source);
        assert!(fixture_id_if_present(&module.procedures, "::subject").is_some());
        assert!(module.source_entry.logical_source_input.is_none());
        assert!(module.source_entry.native_entry.is_none());
        assert!(!module.source_entry.unknown_entry);
        let mut absent = Lowerer::with_config(context.commands(), native.lexer_config())
            .with_resolved_analysis_input(native)
            .with_explicit_unknown_entry();
        let module = absent.lower(source);
        assert!(!fixture_id_if_present(&module.procedures, "::subject").is_some());
        assert!(module.source_entry.logical_source_input.is_none());
        assert!(module.source_entry.native_entry.is_none());
        assert!(module.source_entry.unknown_entry);
    }

    #[test]
    fn logical_original_declaration_layout_keeps_unicode_and_qualified_alias_heads() {
        // naming.compiler.original-analysis-metadata-context

        // These exact UTF-8 source spellings exercise conditional Logical
        // layout selection, independently of any Native slot or execution.
        let context =
            tcl_registry::model::ingress::resolve_environment("tcl9.1").default_context_registry();
        let profile = tcl_dialect::DialectProfile::plain_tcl();
        let input = crate::analyser::ResolvedAnalysisInput::new(
            profile,
            profile,
            std::sync::Arc::clone(&context),
            tcl_lexer::LexerConfig::for_file_grammar(profile.grammar),
        );
        for source in [
            "rename proc ::α; ::α subject {} {return VALUE}",
            "interp alias {} ::α {} proc; ::α subject {} {return VALUE}",
            "rename proc ::α; interp alias {} ::β {} ::α; ::β subject {} {return VALUE}",
            r"rename proc ::α; \u003a\u003aα subject {} {return VALUE}",
        ] {
            let mut lowerer = Lowerer::with_config(context.commands(), input.lexer_config())
                .with_resolved_analysis_input(input.clone());
            let module = lowerer.lower(source);
            assert!(
                fixture_id_if_present(&module.procedures, "::subject").is_some(),
                "{source}"
            );
            assert!(module.source_entry.native_entry.is_none());
            assert!(module.source_entry.execution_name_policy.is_none());
            assert_eq!(
                module.source_entry.logical_source_input.as_ref(),
                Some(&input)
            );
        }
        for source in [
            "interp alias {} ::α {} proc subject; ::α {} {return VALUE}",
            "interp alias {} ::α {} proc subject {}; ::α {return VALUE}",
        ] {
            let mut lowerer = Lowerer::with_config(context.commands(), input.lexer_config())
                .with_resolved_analysis_input(input.clone());
            let module = lowerer.lower(source);
            let procedure = fixture_id_if_present(&module.procedures, "::subject")
                .and_then(|id| module.procedures.get(&id))
                .expect("captured source declaration");
            assert!(procedure.params.is_empty());
            assert_eq!(procedure.params_raw, "");
            assert!(module.source_entry.native_entry.is_none());
        }
        let source = "rename proc ::α; ::α ::α args {return PAYLOAD}; ::α subject {} {}";
        let mut replaced = Lowerer::with_config(context.commands(), input.lexer_config())
            .with_resolved_analysis_input(input);
        assert!(!fixture_id_if_present(&replaced.lower(source).procedures, "::subject").is_some());
    }

    #[test]
    fn complete_source_input_declines_changed_unit_profile_without_authoring_fallback() {
        // naming.compiler.original-analysis-metadata-context

        let context =
            tcl_registry::model::ingress::resolve_environment("tcl8.6").default_context_registry();
        let profile = tcl_dialect::DialectProfile::plain_tcl();
        let input = crate::analyser::ResolvedAnalysisInput::new(
            profile,
            profile,
            std::sync::Arc::clone(&context),
            tcl_lexer::LexerConfig::from_grammar(profile.grammar),
        );
        let selected = Lowerer::with_config(context.commands(), input.lexer_config())
            .with_resolved_analysis_input(input.clone());
        assert!(selected.invocation_metadata_context().is_some());
        assert_eq!(selected.logical_source_input.as_ref(), Some(&input));
        let mut wrong = Lowerer::with_config(context.commands(), input.lexer_config())
            .with_dialect(Some(tcl_dialect::DialectProfile::find("tcl8.6").unwrap()))
            .with_resolved_analysis_input(input.clone());
        assert!(wrong.invocation_metadata_context().is_none());
        assert!(wrong.unknown_entry);
        let module = wrong.lower("puts VALUE");
        assert_eq!(module.source_metadata_input.as_ref(), Some(&input));
        assert!(module.source_entry.unknown_entry);
        assert!(module.source_entry.logical_source_input.is_none());
    }

    #[test]
    fn lowered_generic_metadata_keeps_supplied_context_and_refuses_missing_driver_input() {
        // naming.compiler.original-analysis-metadata-context

        let context = tcl_registry::model::ingress::context_for_profile(
            tcl_registry::model::ingress::resolve_environment("tcl8.6").analyser_profile(),
        );
        let registry = context.commands();
        let config = tcl_lexer::LexerConfig::for_dialect("tcl8.6");
        let mut missing = Lowerer::with_config(registry, config).with_dialect(registry.profile());
        missing.set_source_analysis_options(SourceAnalysisOptions::default());
        missing = missing.with_dialect(registry.profile());
        assert!(missing.invocation_metadata_context().is_none());
        assert!(
            missing
                .lower("puts retained")
                .source_metadata_input
                .is_none()
        );
        let mut supplied = Lowerer::with_config(registry, config)
            .with_context_registry(std::sync::Arc::clone(&context))
            .with_dialect(registry.profile());
        supplied.set_source_analysis_options(SourceAnalysisOptions::default());
        assert!(
            supplied
                .invocation_metadata_context()
                .unwrap()
                .matches_registry(registry)
        );
        let module = supplied.lower("puts retained");
        assert!(std::sync::Arc::ptr_eq(
            &module
                .source_metadata_input
                .as_ref()
                .unwrap()
                .context_registry(),
            &context
        ));
        let foreign = tcl_registry::model::ingress::context_for_profile(
            tcl_registry::model::ingress::resolve_environment("tcl9.1").analyser_profile(),
        );
        let mut wrong = Lowerer::with_config(registry, config)
            .with_context_registry(std::sync::Arc::clone(&foreign));
        wrong.set_source_analysis_options(SourceAnalysisOptions::default());
        assert!(
            !wrong
                .invocation_metadata_context()
                .unwrap()
                .matches_registry(registry)
        );
        assert!(!wrong.safe_on_uninit("incr", &["value".to_owned()]));
        let older = std::sync::Arc::new(
            tcl_registry::model::ingress::static_context_for("tcl8.4")
                .with_command_store(std::sync::Arc::clone(registry)),
        );
        let actual = Lowerer::with_config(registry, config)
            .with_dialect(registry.profile())
            .with_context_registry(older);
        assert!(!actual.safe_on_uninit("incr", &["value".to_owned()]));
        let current = Lowerer::with_config(registry, config)
            .with_dialect(registry.profile())
            .with_context_registry(std::sync::Arc::clone(&context));
        assert!(current.safe_on_uninit("incr", &["value".to_owned()]));
    }

    #[test]
    fn reference_only_command_prefix_does_not_create_a_runtime_barrier() {
        // naming.compiler.original-analysis-metadata-context

        let m = lower_to_ir("trace remove variable v write changed", &reg());
        let stmt = m.top_level.statements.first().expect("trace remove call");
        assert!(
            matches!(stmt, Statement::Call { command, .. } if command == "trace"),
            "matching a prior registration does not execute the prefix: {stmt:?}",
        );
    }

    // These tests pin the registry-driven hook-ID dispatch of `if`,
    // `switch`, `for`, `while`, `catch`, `try` to the expected shape.

    #[test]
    fn registry_dispatch_if_lowers_to_if() {
        let m = lower_to_ir("if {1} { set q 4 }", &reg());
        let stmt = m.top_level.statements.first().expect("at least one stmt");
        assert!(
            matches!(stmt, Statement::If { .. }),
            "expected If via registry hook, got {stmt:?}",
        );
    }

    #[test]
    fn registry_dispatch_switch_lowers_to_switch() {
        let m = lower_to_ir("switch a { a { set q 1 } b { set q 2 } }", &reg());
        let stmt = m.top_level.statements.first().expect("at least one stmt");
        assert!(
            matches!(stmt, Statement::Switch { .. }),
            "expected Switch via registry hook, got {stmt:?}",
        );
    }

    #[test]
    fn registry_dispatch_for_lowers_to_for() {
        let m = lower_to_ir("for {set i 0} {$i < 3} {incr i} { set q $i }", &reg());
        let stmt = m.top_level.statements.first().expect("at least one stmt");
        assert!(
            matches!(stmt, Statement::For { .. }),
            "expected For via registry hook, got {stmt:?}",
        );
    }

    #[test]
    fn registry_dispatch_while_lowers_to_while() {
        let m = lower_to_ir("while {0} { set q 1 }", &reg());
        let stmt = m.top_level.statements.first().expect("at least one stmt");
        assert!(
            matches!(stmt, Statement::While { .. }),
            "expected While via registry hook, got {stmt:?}",
        );
    }

    #[test]
    fn registry_dispatch_catch_lowers_to_catch() {
        let m = lower_to_ir("catch { set q 1 }", &reg());
        let stmt = m.top_level.statements.first().expect("at least one stmt");
        assert!(
            matches!(stmt, Statement::Catch { .. }),
            "expected Catch via registry hook, got {stmt:?}",
        );
    }

    #[test]
    fn registry_dispatch_try_lowers_to_try() {
        let m = lower_to_ir("try { set q 1 } on error e { set q 2 }", &reg());
        let stmt = m.top_level.statements.first().expect("at least one stmt");
        assert!(
            matches!(stmt, Statement::Try { .. }),
            "expected Try via registry hook, got {stmt:?}",
        );
    }

    // `proc`, `namespace eval`, `foreach`, `lmap`, `dict` dispatch
    // through registry-driven hook-ID, with shape preconditions
    // enforced inside each match arm.

    #[test]
    fn registry_dispatch_proc_lowers_to_proc_call_and_registers_procedure() {
        let m = lower_to_ir("proc greet {name} { puts hi }", &reg());
        let stmt = m.top_level.statements.first().expect("at least one stmt");
        match stmt {
            Statement::Call { command, .. } => assert_eq!(
                command, "proc",
                "expected `proc` call via registry hook, got command={command}",
            ),
            other => panic!("expected Call via registry hook, got {other:?}"),
        }
        assert!(
            fixture_id_if_present(&m.procedures, "::greet").is_some(),
            "expected ::greet to be registered in module.procedures, got keys={:?}",
            m.procedures.keys().collect::<Vec<_>>(),
        );
    }

    #[test]
    fn registry_dispatch_proc_wrong_arity_falls_through_to_default() {
        // `proc` with two args — fails the `args.len() == 3`
        // precondition.  The registry-driven path returns None,
        // falls through to the residual string match's
        // `_ => lower_default(...)` arm, which produces a
        // runtime `Call` rather than registering a procedure.
        let m = lower_to_ir("proc greet onlytwo", &reg());
        let stmt = m.top_level.statements.first().expect("at least one stmt");
        assert!(
            matches!(stmt, Statement::Call { .. }),
            "expected Call via lower_default fallback, got {stmt:?}",
        );
        assert!(
            !fixture_id_if_present(&m.procedures, "::greet").is_some(),
            "expected ::greet NOT to be registered when arity is wrong",
        );
    }

    #[test]
    fn registry_dispatch_namespace_eval_lowers_to_barrier() {
        // `lower_namespace_eval` emits a `Statement::Barrier`
        // tagged with `reason: "namespace eval"`.
        let m = lower_to_ir("namespace eval ::myns { set q 1 }", &reg());
        let stmt = m.top_level.statements.first().expect("at least one stmt");
        match stmt {
            Statement::Barrier { reason, .. } => assert_eq!(
                reason, "namespace eval",
                "expected `namespace eval` barrier via registry hook, got reason={reason}",
            ),
            other => panic!("expected Barrier via registry hook, got {other:?}"),
        }
    }

    #[test]
    fn registry_dispatch_namespace_non_eval_subcommand_falls_through() {
        // `namespace import` has no `lowering_hook` on its
        // subcommand spec, so `resolve_call` returns hook=None.
        // The registry-driven dispatcher returns None and the
        // residual string match's `_ => lower_default(...)`
        // arm produces a generic `Call`.
        let m = lower_to_ir("namespace import ::foo::*", &reg());
        let stmt = m.top_level.statements.first().expect("at least one stmt");
        assert!(
            matches!(stmt, Statement::Call { .. }),
            "expected Call via lower_default fallback, got {stmt:?}",
        );
    }

    #[test]
    fn registry_dispatch_foreach_lowers_to_foreach() {
        let m = lower_to_ir("foreach v {1 2 3} { set q $v }", &reg());
        let stmt = m.top_level.statements.first().expect("at least one stmt");
        assert!(
            matches!(stmt, Statement::Foreach { .. }),
            "expected Foreach via registry hook, got {stmt:?}",
        );
    }

    #[test]
    fn registry_dispatch_lmap_lowers_to_foreach() {
        // `lmap` shares `lower_foreach(... is_lmap=true)` with
        // `foreach`; both produce `Statement::Foreach`.
        let m = lower_to_ir("lmap v {1 2 3} { expr {$v + 1} }", &reg());
        let stmt = m.top_level.statements.first().expect("at least one stmt");
        assert!(
            matches!(stmt, Statement::Foreach { .. }),
            "expected Foreach (is_lmap=true) via registry hook, got {stmt:?}",
        );
    }

    #[test]
    fn registry_dispatch_dict_lowers_via_lower_dict() {
        // `dict set d k v` exercises the `lower_dict`
        // subcommand-dispatch path.  Pin the registry-driven
        // route by checking the canonical command name on the
        // emitted Call.
        let m = lower_to_ir("dict set d k v", &reg());
        let stmt = m.top_level.statements.first().expect("at least one stmt");
        match stmt {
            Statement::Call { command, .. } => assert_eq!(
                command, "dict",
                "expected `dict` call via registry hook, got command={command}",
            ),
            other => panic!("expected Call via registry hook, got {other:?}"),
        }
    }

    #[test]
    fn registry_dispatch_dict_empty_args_falls_through_to_default() {
        // Bare `dict` — fails the `!args.is_empty()`
        // precondition, falls through to `lower_default`.
        let m = lower_to_ir("dict", &reg());
        let stmt = m.top_level.statements.first().expect("at least one stmt");
        assert!(
            matches!(stmt, Statement::Call { .. }),
            "expected Call via lower_default fallback, got {stmt:?}",
        );
    }

    // `when` and `foreachLine` dispatch through registry-driven
    // hook-ID.  `when` is dialect-gated (iRules), so its test
    // registry loads the dialect explicitly.  `foreachLine` is
    // a Tcl 9.0+ command always registered in `build_default()`.

    #[test]
    fn registry_dispatch_when_lowers_via_lower_when_with_irules_loaded() {
        // The iRules `when` spec carries `LoweringHookId::When`
        // and only enters the registry after
        // `load_dialect(IRULES)`.  Production callers (the LSP
        // server) always pair `build_default()`
        // with the active dialect; this test mirrors that.
        let profile = tcl_dialect::DialectProfile::irules();
        let registry = tcl_registry::model::ingress::static_context_for_profile(profile).commands();
        let m = lower_to_ir_with_config(
            "when HTTP_REQUEST { set q 1 }",
            registry,
            tcl_lexer::LexerConfig::for_profile(Some(profile)),
        );
        let stmt = m.top_level.statements.first().expect("at least one stmt");
        match stmt {
            Statement::Call { command, .. } => assert_eq!(
                command, "when",
                "expected `when` call via registry hook, got command={command}",
            ),
            other => panic!("expected Call via registry hook, got {other:?}"),
        }
        assert!(
            fixture_id_if_present(&m.procedures, "::when::HTTP_REQUEST").is_some(),
            "expected ::when::HTTP_REQUEST procedure to be registered, got keys={:?}",
            m.procedures.keys().collect::<Vec<_>>(),
        );
    }

    #[test]
    fn registry_dispatch_when_without_irules_loaded_falls_through() {
        // Without `load_irules()`, the registry has no `when`
        // spec, so `resolve_call` returns `None` and
        // `try_dispatch_structured_hook` falls through to
        // `lower_default`.  This is a misconfiguration on the
        // caller's side (the source uses iRules but the
        // registry doesn't know about it); the lowerer emits a
        // generic `Call` rather than silently treating it as
        // an event handler.  Pinning this behaviour catches
        // future drift if `build_default()` ever folds in
        // iRules.
        let m = lower_to_ir("when HTTP_REQUEST { set q 1 }", &reg());
        let stmt = m.top_level.statements.first().expect("at least one stmt");
        match stmt {
            Statement::Call { command, .. } => assert_eq!(
                command, "when",
                "expected generic Call via lower_default, got command={command}",
            ),
            other => panic!("expected Call via lower_default, got {other:?}"),
        }
        assert!(
            !m.procedures
                .values()
                .any(|body| body.qualified_name.starts_with("::when::")),
            "expected NO ::when::* procedure registered without iRules loaded",
        );
    }

    #[test]
    fn registry_dispatch_foreach_line_lowers_via_lower_foreach_line() {
        // `foreachLine` is a Tcl 9.0+ command (TIP 670) and
        // `build_default()` registers it via the
        // `tcl::foreachline` spec.  No dialect-load dance is
        // needed.  The body is a brace-string literal here, so
        // the dedicated lowerer relaxes to a typed `Foreach`
        // (not a barrier).
        let m = lower_to_ir("foreachLine line readme.txt { set q $line }", &reg());
        let stmt = m.top_level.statements.first().expect("at least one stmt");
        assert!(
            matches!(stmt, Statement::Foreach { .. }),
            "expected Foreach via registry hook, got {stmt:?}",
        );
    }

    #[test]
    fn registry_dispatch_foreach_line_wrong_arity_falls_through_to_default() {
        // `foreachLine` with two args — fails the
        // `args.len() == 3` precondition, falls through to
        // `lower_default`.
        let m = lower_to_ir("foreachLine onlytwo args", &reg());
        let stmt = m.top_level.statements.first().expect("at least one stmt");
        match stmt {
            Statement::Call { command, .. } => assert_eq!(
                command, "foreachLine",
                "expected generic Call via lower_default, got command={command}",
            ),
            other => panic!("expected Call via lower_default, got {other:?}"),
        }
    }

    /// `if {1} { if {1} { ... } }`, `depth` levels deep.
    fn nested_if_source(depth: u32) -> String {
        let mut source = String::new();
        for _ in 0..depth {
            source.push_str("if {1} {\n");
        }
        for _ in 0..depth {
            source.push_str("}\n");
        }
        source
    }

    /// Depth-first search for a [`Statement::Barrier`] whose `reason`
    /// contains `needle`, anywhere in `script`'s tree (into `If` clauses and
    /// `else` bodies — the only nesting `nested_if_source` produces).
    fn contains_barrier_reason(script: &Script, needle: &str) -> bool {
        script.statements.iter().any(|stmt| match stmt {
            Statement::Barrier { reason, .. } => reason.contains(needle),
            Statement::If {
                clauses, else_body, ..
            } => {
                clauses
                    .iter()
                    .any(|c| contains_barrier_reason(&c.body, needle))
                    || else_body
                        .as_ref()
                        .is_some_and(|e| contains_barrier_reason(e, needle))
            }
            _ => false,
        })
    }

    /// `lower_script` / `lower_body` recurse one Rust frame group per `if`
    /// nesting level, so they need the same depth cap as `analyse_body`
    /// (`tcl_compiler::analyser::commands::MAX_BODY_DEPTH`) and
    /// `cfg_builder::lower_script` (`MAX_LOWER_DEPTH`). A document whose IR
    /// lowering runs unguarded defeats the CFG builder's own guard
    /// downstream — the crash happens one stage earlier. Lowering 2000
    /// levels must neither hang nor overflow the stack, and must record the
    /// cap trip as a `Statement::Barrier` (unknown effects) rather than
    /// silently truncating to an empty, falsely-dead-looking script.
    #[test]
    fn deeply_nested_if_past_max_lower_depth_barriers_not_crashes() {
        let source = nested_if_source(2000);
        // `cargo test` runs each test on a small default-stack thread — see
        // the identical helper's doc comment in `analyser::commands::tests`.
        let m = std::thread::Builder::new()
            .stack_size(64 * 1024 * 1024)
            .spawn(move || lower_to_ir(&source, &reg()))
            .expect("spawn big-stack test thread")
            .join()
            .expect("lower_to_ir on big-stack thread panicked");
        assert!(
            contains_barrier_reason(&m.top_level, "nesting depth exceeds analysis limit"),
            "expected a depth-cap Barrier somewhere in the lowered tree"
        );
    }

    /// Depth of the deepest chain of nested `If` statements in `script`.
    fn if_chain_depth(script: &Script) -> u32 {
        script
            .statements
            .iter()
            .map(|stmt| match stmt {
                Statement::If { clauses, .. } => {
                    1 + clauses.first().map_or(0, |c| if_chain_depth(&c.body))
                }
                _ => 0,
            })
            .max()
            .unwrap_or(0)
    }

    #[test]
    fn shallow_nested_if_lowers_with_no_barrier() {
        // False-positive guard: ordinary, hand-written nesting must lower
        // as real `If` statements all the way down, never barriered.
        let source = nested_if_source(10);
        let m = lower_to_ir(&source, &reg());
        assert!(
            !contains_barrier_reason(&m.top_level, "nesting depth exceeds analysis limit"),
            "shallow nesting must not trip the depth cap"
        );
        // 10 real nested `If`s, not a single opaque barrier standing in for
        // all of them.
        assert_eq!(if_chain_depth(&m.top_level), 10);
    }

    /// Regression (JimTcl/iRules dialect drift): every re-lex of a *body*
    /// this lowering performs takes its grammar from the document's own
    /// [`tcl_lexer::LexerConfig`], not the Tcl 9.x default.
    ///
    /// `body_has_dynamic_barrier` re-segments a braced body to find a nested
    /// dynamic `eval`/`uplevel`.  Under `f5-irules` the lexer treats `}{` as a
    /// word separator, so `foo {a}{eval $x}` is **three** words and its third
    /// is a braced script containing a dynamic `eval`; under the default
    /// grammar the two braces weld into one compound word whose text is
    /// `aeval $x`, whose head `aeval` is nobody's barrier.  Before the config
    /// was threaded, the iRules document was re-segmented under Tcl rules and
    /// the barrier was missed — the outer `eval` relaxed to inline IR that
    /// runs a still-dynamic inner `eval`.
    #[test]
    fn body_relex_follows_the_document_dialect_not_the_default() {
        let irules = tcl_dialect::DialectProfile::irules();
        let irules_config = tcl_lexer::LexerConfig::from_grammar(irules.grammar);
        let registry = tcl_registry::model::ingress::static_context_for_profile(irules).commands();

        let body = "foo {a}{eval $x}";
        assert!(
            !body_has_dynamic_barrier(body, registry, tcl_lexer::LexerConfig::default()),
            "under the default grammar `}}{{` welds one word, so no nested barrier is visible"
        );
        assert!(
            body_has_dynamic_barrier(body, registry, irules_config),
            "under f5-irules `}}{{` separates words, exposing the nested dynamic `eval`"
        );

        // End to end: the same fact decides whether the outer `eval` relaxes
        // to an inline `Block` or stays a runtime `Barrier`.
        let source = "eval {foo {a}{eval $x}}";
        let irules_module = lower_to_ir_with_config(source, registry, irules_config);
        assert_eq!(irules_module.top_level.statements.len(), 1);
        assert_runtime_opaque_call(&irules_module.top_level.statements[0], registry, "eval");

        // Under the default grammar the weld makes `{a}{eval $x}` a *single*
        // word, and that word is not valid Tcl — C answers `extra characters
        // after close-brace` for this very body, on 8.6 and 9.0 alike. So the
        // relaxation is declined here too, by the parse gate rather than the
        // barrier gate (#1829): inlining would lower the malformed text with
        // the lenient lowering and give it a meaning C never gives it.
        let tcl_module =
            lower_to_ir_with_config(source, registry, tcl_lexer::LexerConfig::default());
        assert!(
            matches!(
                tcl_module.top_level.statements.as_slice(),
                [Statement::Barrier { .. }]
            ),
            "a body that does not parse keeps the runtime barrier: {:?}",
            tcl_module.top_level.statements
        );

        // Positive control: the relaxation is still alive. A body with no
        // nested barrier that *does* parse must still reach the inline Block,
        // so neither assertion above can pass merely because relaxation
        // stopped happening at all.
        let relaxable = lower_to_ir_with_config(
            "eval {foo a b}",
            registry,
            tcl_lexer::LexerConfig::default(),
        );
        assert!(
            matches!(
                relaxable.top_level.statements.as_slice(),
                [Statement::Block { .. }]
            ),
            "a parsing, barrier-free body still relaxes to a Block: {:?}",
            relaxable.top_level.statements
        );
    }

    /// `JimTcl`'s `$(…)` lowers as the expression it is, end to end from the
    /// lexer: `set x $($a*2)` becomes the `AssignExpr` a `[expr {$a*2}]`
    /// value produces, with the body anchored two bytes past the `$(` so
    /// expression diagnostics land on the right source; `return $($a+1)`
    /// carries its expression the same way.
    #[test]
    fn jim_expr_sugar_lowers_as_an_anchored_expression() {
        let jim = tcl_registry::model::resolve_environment("jim").unit_profile();
        let registry = tcl_registry::model::ingress::static_context_for_profile(jim).commands();
        let config = tcl_lexer::LexerConfig::from_grammar(jim.grammar);
        let module = lower_to_ir_with_config("set x $($a*2)\nreturn $($a+1)\n", registry, config);
        let statements = module.top_level.statements.as_slice();
        match statements {
            [
                Statement::AssignExpr {
                    name,
                    expr,
                    expr_base,
                    command_binding,
                    ..
                },
                Statement::Return {
                    expr: return_expr, ..
                },
            ] => {
                assert_eq!(name, "x");
                let rendered = format!("{expr:?}");
                assert!(rendered.contains('a'), "operand missing from {rendered}");
                // `set x ` is six bytes, `$(` two more: the body starts at 8.
                assert_eq!(*expr_base, Some(8), "the sugar body's absolute anchor");
                assert!(
                    command_binding.is_none(),
                    "Jim expression syntax must not manufacture an expr command binding"
                );
                assert!(return_expr.is_some(), "return $(…) carries its expression");
            }
            other => panic!("expected AssignExpr + Return; got {other:?}"),
        }
    }
}

#[cfg(test)]
mod original_script_purpose_tests {

    use super::*;

    fn first_invocation(script: &Script) -> &CommandTokens {
        script
            .statements
            .iter()
            .find_map(Statement::tokens)
            .expect("retained original invocation")
    }

    #[test]
    fn original_whole_and_zero_base_body_parsers_keep_distinct_bom_purposes() {
        // naming.source.original-configured-script-completeness

        // Parser purpose and retained source ancestry; no Native entry or Normal store.
        let mut prepared = crate::analyser::Analyser::new();
        let input = prepared.prepare_analysis_input("tcl9.1").unwrap();
        let context = input.context_registry();
        let registry = context.commands();
        let source = "\u{feff}unknown argument";
        for bom in [tcl_lexer::LeadingBom::Skip, tcl_lexer::LeadingBom::Content] {
            let mut config = input.lexer_config();
            config.leading_bom = bom;
            config.braced_var = tcl_lexer::BracedVarStyle::FirstClose;
            let supplied = crate::analyser::ResolvedAnalysisInput::new(
                input.analyser_profile(),
                input.unit_profile(),
                input.context_registry(),
                config,
            );
            let config = supplied.lexer_config();
            let mut whole = Lowerer::with_config(registry, config)
                .with_resolved_analysis_input(supplied.clone());
            let module = whole.lower(source);
            let command = first_invocation(&module.top_level);
            assert_eq!(
                command.argv_texts[0],
                if bom == tcl_lexer::LeadingBom::Skip {
                    "unknown"
                } else {
                    "\u{feff}unknown"
                }
            );
            assert_eq!(
                command.argv[0].start(),
                if bom == tcl_lexer::LeadingBom::Skip {
                    3
                } else {
                    0
                }
            );
            assert_eq!(module.lexer_config, config);
            assert_eq!(module.source_metadata_input.as_ref(), Some(&supplied));

            let mut body = Lowerer::with_config(registry, config)
                .with_resolved_analysis_input(supplied.clone());
            let script = body.lower_into_script(source, "::");
            let command = first_invocation(&script);
            assert_eq!(command.argv_texts[0], "\u{feff}unknown");
            assert_eq!(command.argv[0].start(), 0);
            assert_eq!(body.config, config);
            assert_eq!(body.metadata_input.as_ref(), Some(&supplied));
            if bom == tcl_lexer::LeadingBom::Skip {
                // This fresh local span space does not own a projected input.
                // Keep the actual parent input; mismatched metadata is terminal.
                assert!(
                    body.source_metadata_input()
                        .retain()
                        .metadata_context_for_source(
                            registry,
                            config.nested(),
                            Some(supplied.unit_profile())
                        )
                        .is_none()
                );
            }
            assert!(crate::registry_invocation::proved_native_inline_operation(command).is_none());

            // An explicit non-BOM grammar override is retained for body parsing.
            let script = body.lower_into_script("puts \"${a{}\"", "::");
            let command = first_invocation(&script);
            assert_eq!(command.argv_texts, ["puts", "${a{}"]);
            assert!(
                body.eval_subst_nocommands_body("\u{feff}subst -nocommands {literal}")
                    .is_none()
            );
            assert!(eval_list_literal_body("\u{feff}list item", config).is_none());
        }
    }

    #[test]
    fn original_selected_nested_body_keeps_parent_metadata_for_known_command_advice() {
        // naming.source.original-registry-header-advice

        // Existing original body inventory and metadata; no entered/Normal handler donation.
        let mut prepared = crate::analyser::Analyser::new();
        let input = prepared.prepare_analysis_input("tcl9.1").unwrap();
        for bom in [tcl_lexer::LeadingBom::Skip, tcl_lexer::LeadingBom::Content] {
            let mut config = input.lexer_config();
            config.leading_bom = bom;
            config.braced_var = tcl_lexer::BracedVarStyle::FirstClose;
            let supplied = crate::analyser::ResolvedAnalysisInput::new(
                input.analyser_profile(),
                input.unit_profile(),
                input.context_registry(),
                config,
            );
            let context = supplied.context_registry();
            let registry = context.commands();
            let source = "eval {puts hi}";
            let identities =
                crate::realm::document_realm_bindings_with_resolved_input(source, &supplied, None);
            let parent = crate::segmenter::segment_commands_with_offset_and_config(
                source,
                0,
                supplied.lexer_config(),
            )
            .pop()
            .unwrap();
            let original = identities
                .executed_script_for_word(parent.argv[1].span)
                .unwrap();
            let bindings = identities
                .source_bindings_ref()
                .selected_source(original)
                .unwrap();
            let mut lowerer = Lowerer::with_config(registry, supplied.lexer_config())
                .with_resolved_analysis_input(supplied.clone());
            lowerer.set_source_image_channel(&original.text);
            let script = lowerer.lower_into_script_with_bindings(
                original.try_text().unwrap(),
                original.base(),
                "::",
                bindings,
            );
            let command = first_invocation(&script);
            let site = command
                .source_binding
                .as_ref()
                .unwrap()
                .invocation_site()
                .unwrap();
            assert_eq!(&site.source, &original.origin);
            assert_eq!(site.offset, original.base());
            assert_eq!(command.argv_texts, ["puts", "hi"]);
            let advice = crate::registry_invocation::original_registry_invocation_assistance_with_metadata_context(
                registry, lowerer.invocation_metadata_context(), command).unwrap();
            assert_eq!(advice.unanimous_command_words().unwrap().command(), "puts");
            assert_eq!(lowerer.metadata_input.as_ref(), Some(&supplied));
            let mut changed_config = supplied.lexer_config();
            changed_config.strict_quoting = !changed_config.strict_quoting;
            let changed = crate::analyser::ResolvedAnalysisInput::new(
                supplied.analyser_profile(),
                supplied.unit_profile(),
                supplied.context_registry(),
                changed_config,
            );
            assert!(
                crate::registry_invocation::InvocationMetadataContext::for_source_input(
                    registry,
                    &changed,
                    supplied.lexer_config(),
                    Some(supplied.unit_profile())
                )
                .is_none()
            );
        }
    }

    #[test]
    fn original_materialised_zero_base_body_keeps_its_selected_point_owner() {
        // naming.source.original-configured-script-completeness

        // Actual original escaped body and selected derived source; no compiler/frame grant.
        let mut prepared = crate::analyser::Analyser::new();
        let input = prepared.prepare_analysis_input("tcl9.1").unwrap();
        let context = input.context_registry();
        let registry = context.commands();
        let source = "eval \\uFEFFunknown";
        let identities =
            crate::realm::document_realm_bindings_with_resolved_input(source, &input, None);
        let parent = crate::segmenter::segment_commands_with_offset_and_config(
            source,
            0,
            input.lexer_config(),
        )
        .pop()
        .unwrap();
        let original = identities
            .executed_script_for_word(parent.argv[1].span)
            .expect("original evaluated script");
        assert_eq!(original.base(), 0);
        assert_eq!(
            original.mapping,
            crate::command_binding::ExecutedScriptMapping::Materialised
        );
        let body = original.try_text().unwrap();
        assert_eq!(body, "\u{feff}unknown");
        let bindings = identities
            .source_bindings_ref()
            .selected_source(original)
            .unwrap();
        assert_eq!(bindings.source_origin(), Some(&original.origin));
        let mut lowerer = Lowerer::with_config(registry, input.lexer_config())
            .with_resolved_analysis_input(input.clone());
        lowerer.set_source_image_channel(&original.text);
        let script = lowerer.lower_into_script_with_bindings(body, 0, "::", bindings);
        let command = first_invocation(&script);
        assert_eq!(command.argv_texts, ["\u{feff}unknown"]);
        let site = command
            .source_binding
            .as_ref()
            .unwrap()
            .invocation_site()
            .expect("actual derived point");
        assert_eq!(site.offset, 0);
        assert_eq!(&site.source, &original.origin);
        assert_eq!(site.source.source_image().bytes(), body.as_bytes());
        assert_eq!(
            script.executed_source.as_ref().unwrap().origin,
            original.origin
        );
        assert!(crate::registry_invocation::proved_native_inline_operation(command).is_none());
        assert_eq!(lowerer.config, input.lexer_config());
        assert_eq!(lowerer.metadata_input.as_ref(), Some(&input));

        // Equal derived text under another original parent has no retained point.
        let foreign_parent = crate::command_binding::CommandAllocationSite {
            source: std::sync::Arc::new(crate::command_binding::SourceOriginId::authored(
                &std::sync::Arc::from("eval $other"),
            )),
            offset: 0,
        };
        let foreign = crate::command_binding::ExecutedScriptSource::materialised(
            foreign_parent,
            vec![0],
            body,
        );
        let foreign_bindings = identities
            .source_bindings_ref()
            .selected_source(&foreign)
            .unwrap();
        let refused = lowerer.lower_into_script_with_bindings(body, 0, "::", foreign_bindings);
        assert!(
            first_invocation(&refused)
                .source_binding
                .as_ref()
                .unwrap()
                .invocation_site()
                .is_none()
        );
    }
    #[test]
    fn original_definer_targets_keep_literal_data_distinct_from_scalar_references() {
        for (target, expected) in [
            ("{$obj}", "::@objdefine@::$obj"),
            ("$obj", "::@objdefine@::obj"),
            ("${two words}", "::@objdefine@::two words"),
            ("{two words}", "::@objdefine@::two words"),
            ("{}", "::@objdefine@::"),
            ("{[obj]}", "::@objdefine@::[obj]"),
        ] {
            let source = format!("oo::objdefine {target} {{method m {{}} {{return VALUE}}}}");
            let analysis = crate::analyser::Analyser::new().analyse(&source, "tcl");
            let input = analysis.resolved_input.as_ref().unwrap();
            let module = lower_to_ir_with(
                Lowerer::with_config(
                    input.borrowed_context_registry().commands(),
                    input.lexer_config(),
                )
                .with_resolved_analysis_input(input.clone()),
                &source,
            );
            let method = module
                .methods
                .values()
                .find(|method| method.method_name == "m")
                .expect("actual conditional original definition body");
            assert_eq!(method.class_name, expected);
            assert!(method.definition_scope.is_some());
        }
        for target in [
            "$obj(key)",
            "${obj(key)}",
            "[pick]",
            "x$obj",
            "{nul\0receiver}",
        ] {
            let source = format!("oo::objdefine {target} {{method m {{}} {{return VALUE}}}}");
            let analysis = crate::analyser::Analyser::new().analyse(&source, "tcl");
            let input = analysis.resolved_input.as_ref().unwrap();
            let module = lower_to_ir_with(
                Lowerer::with_config(
                    input.borrowed_context_registry().commands(),
                    input.lexer_config(),
                )
                .with_resolved_analysis_input(input.clone()),
                &source,
            );
            assert!(module.methods.is_empty());
            assert!(module.oo_evidence.unretained_executable_roots);
        }
    }
}

/// What [`Lowerer::lower_command`] does after its out-of-line selection.
enum CommandLoweringSelection {
    /// A finished statement, built outside the recursive descent frame.
    Lowered(Box<Statement>),
    /// The resolved label of a possible structured form, whose hook may
    /// recurse into nested bodies.
    Structured(String),
}
