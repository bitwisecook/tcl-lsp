from pathlib import Path
import hashlib,difflib,subprocess,json,datetime
root=Path('/workspace/naming-migration-active/tcl-lsp');b=Path('/tmp/compiler-names-var-escape-fixture-owner-v1');b.mkdir(exist_ok=False);rel='rust/tcl-compiler/tests/var_escape_residual2.rs';old=(root/rel).read_text();s=old;start=s.index('struct EscapeSummaries {');end=s.index('\nfn escape_cu(src:',start);s=s[:start]+'''enum EscapeSource {
    Unit(Box<CompilationUnit>),
    Ir(Box<tcl_compiler::Module>),
}

struct EscapeSummaries {
    source: EscapeSource,
    by_body: HashMap<tcl_core_types::BodyFrameId, ProcEscapeSummary>,
}

impl EscapeSummaries {
    fn module(&self) -> &tcl_compiler::Module {
        match &self.source {
            EscapeSource::Unit(unit) => &unit.ir_module,
            EscapeSource::Ir(module) => module,
        }
    }

    fn fixture_body(&self, label: &str) -> tcl_core_types::BodyFrameId {
        let module = self.module();
        if label == tcl_compiler::var_escape::TOP_LEVEL_QNAME {
            return tcl_core_types::BodyFrameId::Top(module.procedure_ids.module_id());
        }
        if std::env::var_os("TCL_LSP_TRACE_VAR_ESCAPE_BODY_OWNERS").is_some() {
            for (id, body) in module.procedures.iter().chain(module.body_lowerings()) {
                let original = match &self.source {
                    EscapeSource::Unit(unit) => unit.original_procedure_for_body(*id).is_some(),
                    EscapeSource::Ir(_) => module.procedures.contains_key(id),
                };
                eprintln!(
                    "ESCAPE_BODY_OWNER id={id:?} kind={:?} label={:?} span={:?} original={} summary={}",
                    body.body_kind,
                    body.qualified_name,
                    body.span,
                    original,
                    self.by_body.contains_key(&tcl_core_types::BodyFrameId::Body(*id)),
                );
            }
        }
        let mut bodies = module
            .procedures
            .iter()
            .chain(module.body_lowerings())
            .filter(|(id, body)| match &self.source {
                EscapeSource::Unit(unit) => unit
                    .original_procedure_for_body(**id)
                    .is_some_and(|original| std::ptr::eq(original, *body)),
                EscapeSource::Ir(_) => module.procedures.contains_key(id),
            })
            .filter(|(_, body)| body.qualified_name == label);
        let (id, body) = bodies.next().expect("original authored fixture body");
        assert!(
            bodies.next().is_none(),
            "ambiguous authored fixture body {label}"
        );
        assert!(module.procedure_ids.owns(*id));
        if matches!(&self.source, EscapeSource::Unit(_)) {
            assert!(matches!(
                body.body_kind,
                tcl_compiler::ir::ProcedureBodyKind::Named
                    | tcl_compiler::ir::ProcedureBodyKind::OriginalDeclaration
            ));
        }
        tcl_core_types::BodyFrameId::Body(*id)
    }
}
''' + s[end:]
a='''    EscapeSummaries {
        module: cu.ir_module,
        by_body,
    }''';assert s.count(a)==2;s=s.replace(a,'''    EscapeSummaries {
        source: EscapeSource::Unit(Box::new(cu)),
        by_body,
    }''');a='''    EscapeSummaries { module, by_body }''';assert s.count(a)==1;s=s.replace(a,'''    EscapeSummaries {
        source: EscapeSource::Ir(Box::new(module)),
        by_body,
    }''');p=b/'shadow'/rel;p.parent.mkdir(parents=True);p.write_text(s);f=subprocess.run(['/workspace/.rustup/toolchains/1.99.1-x86_64-unknown-linux-gnu/bin/rustfmt','--edition','2024',str(p)],text=True,capture_output=True);assert f.returncode==0,f.stderr;patch=''.join(difflib.unified_diff(old.splitlines(True),p.read_text().splitlines(True),fromfile='a/'+rel,tofile='b/'+rel));(b/'proposal.patch').write_text(patch);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m={'utc':datetime.datetime.now(datetime.UTC).isoformat(),'status':'OFFTREE test-helper-only current authentic original-body selection; actual full census and Frame assertion UNRUN','path':rel,'before_sha256':hashlib.sha256(old.encode()).hexdigest(),'final_sha256':sha(p),'patch_sha256':sha(b/'proposal.patch'),'actual_first_refusal':'source46 compiler58 integration25 helper var_escape_residual2.rs107 fails named-only fixture match before by_body lookup or original Frame assertion; no actual complete owner/summary census yet','static_production_path':'CompilationUnit::build_body_units builds all actual body_units. analyse_var_escape_cu(_with_registry) iterates procedures+methods+body_lowering_functions; EscapeCallGraph includes body_lowerings. No static production coverage omission found.','scope':'Keep actual full CompilationUnit for CU fixtures, never clone/reconstruct Module. Resolve across actual named/body-lowering stores only after existing public unit.original_procedure_for_body validates exact current owner/card, then exact label + unique match + module-issued ID + Named/OriginalDeclaration role. IR-only helper preserves named-only domain. No first/Installed-role fallback, map-key reconstruction or source-role relabel. All original test source/assertions unchanged.','trace':'Test-only dedicated TCL_LSP_TRACE_VAR_ESCAPE_BODY_OWNERS prints complete held body role/id/span/label/card eligibility/summary-present census before selection; no runtime/provider operation. Future protocol env successor required if used.','limits':'Candidate may expose absent authentic source card, ambiguous label, or actual Frame-tag failure; none inverted. No typing/runtime/census pass claim.','checks':'Pinnedfmt2024 parsePASS; no canonical source/Cargo/Git/GO.'};(b/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps(m))
