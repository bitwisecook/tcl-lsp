This is a builder and template, not a runnable v10 protocol. The reviewed v9 protocol remains unchanged. There is no v10 plan, input manifest, root GO, launcher allocation or compilation claim here.

Root must supply an ACTUAL newly committed identity matching actual-identity-required-schema.json, plus an explicit reviewed candidate manifest path and SHA256. The candidate is read only as an expected patch/map; its HEAD labels never become an approved future product. The builder verifies the actual Git commit/tree, reviewed-source baseline/final blobs, worktree/index, exact regenerated patch, intermediate path scope, docs-only descendants and untracked-source refusal. It refuses unchanged predecessor HEAD and any absent/malformed/future identity. It performs the full proof twice and permits only monotonic docs-only HEAD movement between samples.

The builder uses only allowlisted read-only Git commands. It never invokes Cargo, opens a build lock, queues a process, writes a GO, launches a suite, or changes canonical Git/source. Default invocation validates without writing protocol files. --materialize writes only a fresh fixed /tmp/name-handling-eight-package-check-v10-source<verified-count> directory after all actual checks, with exclusive creation; interrupted partial output is not overwritten. Root launches separately after reviewing the materialized plan, pins and GO schema.

Future command shape (placeholders are schema, not values to execute):
python3 builder.py --identity ACTUAL_IDENTITY --candidate-manifest REVIEWED_MANIFEST --candidate-manifest-sha256 REVIEWED_SHA --builder-manifest-sha256 THIS_PREPARATION_MANIFEST_SHA [--materialize]

All eight packages, all-target Cargo argv, 88125 executor, deadlines/caps/disk/whole-process checks, zero-warning parsing, tool/environment override refusal, durable launcher, source/provider seals and final docs-HEAD recheck are inherited exactly from v9. Only version/path/source-map labels and the approved path count change. Complete source collection remains dynamic and exact before/after. Its tracked membership can legitimately add the one reviewed Jim test; this is not a waiver for arbitrary source count drift and is separate from the exact root-reviewed changed-product paths.

Before integration only AST/template-delta and no-argument refusal are checked. No positive builder verification/materialization/Git command or runtime typing evidence is executed. Each generated protocol still needs actual root GO and a real eight-package PASS/zero-warning closure before any runtime prerequisite can be accepted.

Normal-owner v3 is separate: it appends the genuine second equal-source analysis own-seed/own-bindings positive after every old assertion; production and old four-field equality remain v2-identical. That positive and all runtime controls remain unrun until the actual new product is typed and tested.

V2 counts and source-map labels are late-bound from the explicit root-reviewed manifest. Every cumulative path is still proved against an actual commit/tree/worktree before rendering the concrete hardcoded suite count and plan/input manifest. No latest-manifest search or guessed count is used. V1 fixed64 template remains immutable predecessor.

V3 refuses duplicate JSON keys at every object depth for all builder-loaded JSON, including reviewed candidate, actual identity, actual integrated map, policy, templates and predecessor inputs. Runtime templates and all other builder guard logic are unchanged from v2. V2 remains immutable predecessor pending this interpretation guard.
