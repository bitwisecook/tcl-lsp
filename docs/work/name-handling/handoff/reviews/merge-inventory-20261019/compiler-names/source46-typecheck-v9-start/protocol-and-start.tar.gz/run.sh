#!/bin/sh
exec python3 /tmp/name-handling-eight-package-check-v9-source46/launch.py "$@"
