#!/usr/bin/env python3
"""Validate closed evidence and mint one reviewed protocol GO; never launch it."""
from pathlib import Path
import argparse, ast, contextlib, datetime, fcntl, hashlib, json, os, re, shutil, subprocess, sys, tempfile

BASE = Path('/tmp/naming-source46-root-allocator-v2')
ROOT = Path('/workspace/naming-migration-active/tcl-lsp')
V9 = Path('/tmp/name-handling-eight-package-check-v9-source46')

class Refusal(Exception):
    pass

def require(value, message):
    if not value:
        raise Refusal(message)

def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def read(path):
    return json.loads(Path(path).read_text())

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def verify_inputs(path, expected):
    require(digest(path) == expected, 'input manifest changed: '+str(path))
    for name, pin in read(path)['inputs'].items():
        require(digest(name) == pin, 'input changed: '+name)

def load_functions(path, names, namespace):
    """Load only named frozen read-only guard definitions, never suite top-level code."""
    tree = ast.parse(Path(path).read_text())
    functions = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in names]
    require({node.name for node in functions} == set(names), 'guard function inventory changed')
    require(all(not node.decorator_list and not node.args.defaults and not any(node.args.kw_defaults) for node in functions), 'guard definition has executable decorator/default')
    exec(compile(ast.Module(body=functions, type_ignores=[]), str(path), 'exec'), namespace)
    return namespace

class MemoryGo:
    def __init__(self, value):
        self.text = json.dumps(value, sort_keys=True, indent=2)+'\n'
        self.sha256 = hashlib.sha256(self.text.encode()).hexdigest()
    def read_text(self):
        return self.text

@contextlib.contextmanager
def selected_environment(policy):
    previous = os.environ.copy()
    refused = [key for key in previous if key in policy['refused_environment_exact'] or any(
        key.startswith(rule['prefix']) and key.endswith(rule['suffix'])
        for rule in policy['refused_environment_patterns'])]
    require(not refused, 'unsupported inherited compiler overrides: '+','.join(refused))
    try:
        os.environ.update(policy['required_environment'])
        os.environ['PATH'] = policy['path_prefix']+':'+previous.get('PATH', '')
        yield
    finally:
        os.environ.clear()
        os.environ.update(previous)

def guard_namespace(base, plan, candidate):
    memory = MemoryGo(candidate)
    namespace = dict(Path=Path, hashlib=hashlib, json=json, os=os, re=re,
        datetime=datetime, subprocess=subprocess, shutil=shutil,
        ROOT=ROOT, BASE=base, GO=memory, plan=plan,
        PLAN=base/'plan.json', MANIFEST=base/'runner-input-manifest.json',
        CARGO=Path(plan.get('build_environment',plan)['cargo_path']),
        plan_sha=digest(base/'plan.json'), RUNNER_MANIFEST=base/'runner-input-manifest.json',
        SOURCE46=Path(plan.get('integrated_manifest_path', str(V9/'source46-manifest.json'))),
        LAST_HEAD=None, last_head=None, head_samples=[])
    def bound_digest(path):
        return memory.sha256 if path is memory else digest(path)
    namespace['digest'] = bound_digest
    namespace['sha'] = bound_digest
    return namespace, memory

def closed_v9_gate(final_path, launcher_path, config):
    require(final_path.is_file(), 'v9 final does not exist; run not closed')
    require(launcher_path.is_file(), 'v9 launcher does not exist')
    require(final_path.name == 'final.json' and final_path.resolve().is_relative_to(V9/'runs'), 'final outside exact v9 run root')
    require(launcher_path.name == 'launcher.json' and launcher_path.resolve().is_relative_to(V9/'launcher-runs'), 'launcher outside exact v9 launch root')
    final, launcher = read(final_path), read(launcher_path)
    require(final.get('status') == 'PASS', 'v9 is not PASS; no GO')
    require(type(launcher.get('exit_code')) is int and launcher['exit_code'] == 0 and launcher.get('finished_utc'), 'v9 launcher not closed PASS')
    require(final.get('finished_utc'), 'v9 final has no finish time')
    started = datetime.datetime.fromisoformat(launcher['started_utc'])
    finished = datetime.datetime.fromisoformat(final['finished_utc'])
    closed = datetime.datetime.fromisoformat(launcher['finished_utc'])
    require(started <= finished <= closed <= datetime.datetime.now(datetime.timezone.utc), 'v9 completion timestamps inconsistent')
    require(final.get('plan_sha256') == config['v9']['plan_sha256'], 'wrong v9 final plan')
    return final, launcher

def common_v9(final_path, launcher_path, config):
    final, launcher = closed_v9_gate(final_path, launcher_path, config)
    v9 = config['v9']
    require(digest(V9/'plan.json') == v9['plan_sha256'], 'v9 plan changed')
    verify_inputs(V9/'runner-input-manifest.json', v9['runner_input_manifest_sha256'])
    require(digest(V9/'source46-manifest.json') == config['source46_sha256'], 'v9 source46 map changed')
    require(digest(V9/'root-go.json') == v9['root_go_sha256'], 'actual v9 approval changed')
    expected_pins = dict(read(V9/'runner-input-manifest.json')['inputs'])
    expected_pins[str(V9/'runner-input-manifest.json')] = v9['runner_input_manifest_sha256']
    expected_pins[str(V9/'root-go.json')] = v9['root_go_sha256']
    require(launcher.get('input_pins_before') == expected_pins and launcher.get('input_pins_after') == expected_pins, 'v9 launcher exact before/after input inventory mismatch')
    require(launcher.get('manifest_sha256') == v9['runner_input_manifest_sha256'], 'v9 launcher manifest mismatch')
    parent = final_path.parent
    for name in ('root-go-before.json', 'root-go-after.json'):
        require(read(parent/name) == read(V9/'root-go.json'), 'v9 GO snapshot mismatch')
    require(read(parent/'plan.json') == read(V9/'plan.json'), 'v9 actual plan snapshot mismatch')
    require(digest(parent/'process.json') == final.get('process_receipt_sha256'), 'v9 process receipt pin mismatch')
    process = read(parent/'process.json')
    require(process.get('consecutive_complete_empty_group_scans', 0) >= 2, 'v9 two-empty-group proof missing')
    require(process.get('cwd') == str(ROOT), 'v9 actual Cargo cwd mismatch')
    require(process.get('timer_armed_monotonic_ns', 1) <= process.get('spawn_return_monotonic_ns', 0), 'v9 timer was not armed before spawn')
    require(launcher.get('transcript') == str(launcher_path.parent/'launcher.transcript'), 'v9 transcript outside actual launcher')
    # Reuse the compiler protocol's already-reviewed deep raw v9 receipt authenticator.
    compiler = Path(config['protocols']['compiler58']['base'])
    plan = read(compiler/'plan.json')
    namespace, _ = guard_namespace(compiler, plan, {})
    load_functions(compiler/'suite.py', ['utc','source_manifest','authenticate_typecheck8'], namespace)
    provider_before = read(parent/'providers-before.json')
    current_env = dict(read(V9/'plan.json')['required_environment'])
    for suffix in ('84','85','86','90','91'):
        key = 'TCL_LSP_TCLSH'+suffix
        records = [row for label,row in provider_before.items() if label.startswith(key+':')]
        if records:
            require(len(records) == 1 and records[0]['path'] == '/workspace/naming-toolchains/bin/tclsh'+suffix[0]+'.'+suffix[1], 'v9 oracle environment selection mismatch')
            current_env[key] = records[0]['path']
    policy = dict(read(V9/'plan.json'))
    policy['required_environment'] = current_env
    with selected_environment(policy), tempfile.TemporaryDirectory(prefix='root-allocator-provider-') as temporary:
        provider_path = Path(temporary)/'providers.json'
        subprocess.run([sys.executable, '/tmp/compiler-c6-provider-manifest.py', str(provider_path)], cwd=ROOT, check=True)
        namespace['providers'] = read(provider_path)
        namespace['authenticate_typecheck8']({
            'typecheck8_final_receipt':str(final_path), 'typecheck8_final_sha256':digest(final_path),
            'typecheck8_launcher_receipt':str(launcher_path), 'typecheck8_launcher_sha256':digest(launcher_path)})
    # Authenticate every recorded historical/current HEAD and its docs-only advance.
    samples = [('head_before','head-before.txt'), ('head_pre_spawn','head-pre-spawn.txt'),
        ('head_after_cargo','head-after-cargo.txt'), ('head_after','head-after.txt')]
    previous = config['approved_head']
    for field, name in samples:
        head = (parent/name).read_text().strip()
        require(head == final.get(field) and re.fullmatch(r'[0-9a-f]{40}',head), 'v9 actual HEAD sample mismatch')
        require(subprocess.run(['git','merge-base','--is-ancestor',previous,head],cwd=ROOT).returncode == 0, 'v9 nonmonotonic HEAD samples')
        for commit in subprocess.check_output(['git','rev-list',config['approved_head']+'..'+head],cwd=ROOT,text=True).splitlines():
            paths = subprocess.check_output(['git','diff-tree','--no-commit-id','--name-only','-r','-m',commit],cwd=ROOT,text=True).splitlines()
            require(all(path.startswith('docs/work/name-handling/') for path in paths), 'v9 sampled non-doc commit')
        previous = head
    require(subprocess.run(['git','merge-base','--is-ancestor',previous,'HEAD'],cwd=ROOT).returncode == 0, 'current HEAD is not descendant of completed v9 final HEAD')
    return namespace['providers']

def candidate_go(key, protocol, final_path, launcher_path, config):
    base = Path(protocol['base'])
    go = dict(source_commit=config['baseline'], approved_integrated_head=config['approved_head'],
        approved_integrated_tree=config['approved_tree'], plan_sha256=protocol['plan_sha256'],
        runner_input_manifest_sha256=protocol['runner_input_manifest_sha256'],
        source46_manifest_sha256=config['source46_sha256'], approved_utc=utc(),
        scope='One chosen original finite protocol only; no launch/runtime/release admission',
        typecheck8_final_receipt=str(final_path), typecheck8_final_sha256=digest(final_path),
        typecheck8_launcher_receipt=str(launcher_path), typecheck8_launcher_sha256=digest(launcher_path))
    evidence = {'path':str(final_path),'sha256':digest(final_path)}
    launch_evidence = {'path':str(launcher_path),'sha256':digest(launcher_path)}
    if key in ('compiler58','jim7'):
        for name in ('final','launcher'):
            item = config['compiler49'][name]
            require(digest(item['path']) == item['sha256'], 'original49 evidence changed')
            go['compiler49_'+name+'_receipt'] = item['path']
            go['compiler49_'+name+'_sha256'] = item['sha256']
    if key in ('lsp23','native15'):
        go['post46_eight_package_typecheck_evidence'] = evidence
        go['post46_eight_package_typecheck_launcher_evidence'] = launch_evidence
    if key in ('native15','ccg3','ccg-hook2'):
        item = config['report14']
        require(digest(item['path']) == item['sha256'], 'historical report14 context changed')
        go['prior_report14_context_evidence' if key == 'native15' else 'prior_report14_evidence'] = item
    if key in ('ccg3','ccg-hook2'):
        go['source46_manifest_path'] = str(base/'source46-manifest.json')
        go['source46_typecheck_evidence'] = evidence
        go['source46_typecheck_launcher_evidence'] = launch_evidence
    return go

def validate_selected(key, protocol, candidate, providers, config):
    base = Path(protocol['base']); plan = read(base/'plan.json')
    rows = plan.get('required_filters',plan.get('selectors'))
    require(len(rows) == protocol['expected_filters'] and sum(row.get('expected_selected',row.get('expected_tests',0)) for row in rows) == protocol['expected_selected'], 'registered selector/count inventory changed')
    require(digest(base/'plan.json') == protocol['plan_sha256'], 'selected plan changed')
    verify_inputs(base/'runner-input-manifest.json', protocol['runner_input_manifest_sha256'])
    require(digest(base/'suite.py') == protocol['suite_sha256'], 'selected suite changed')
    require(digest(base/'guarded-exec.py') == config['executor_sha256'], 'selected executor changed')
    if key == 'ccg-hook2':
        peer = config['ccg_hook2_peer']
        require(digest(peer['path']) == peer['sha256'], 'additional hook2 peer receipt changed')
        review = read(peer['path'])
        require(review.get('verdict','').startswith('CLEAR') and review.get('pins',{}).get('plan.json') == protocol['plan_sha256'], 'additional hook2 peer is not CLEAR for exact plan')
    namespace, memory = guard_namespace(base, plan, candidate)
    namespace['providers'] = providers
    policy = plan.get('build_environment', plan)
    with selected_environment(policy):
        if key in ('compiler58','jim7'):
            names = ['utc','source_manifest','authenticate_typecheck8','source_view']
            load_functions(base/'suite.py', names, namespace)
            with tempfile.TemporaryDirectory(prefix='root-allocator-selected-provider-') as temporary:
                path = Path(temporary)/'providers.json'
                subprocess.run([sys.executable,'/tmp/compiler-c6-provider-manifest.py',str(path)],cwd=ROOT,check=True)
                namespace['providers'] = read(path)
                namespace['source_view']('allocator-before-GO', memory.sha256)
        elif key in ('lsp23','native15'):
            names = ['utc','git','require','environment_override_keys','source_view']
            load_functions(base/'suite.py', names, namespace)
            namespace['source_view'](candidate, memory.sha256, plan)
        else:
            names = ['utc','environment_override_keys','check_build_environment','check_legacy_pins','source_view']
            load_functions(base/'suite.py', names, namespace)
            namespace['check_legacy_pins']()
            namespace['source_view']('allocator-before-GO', memory.sha256)
    # Independent common exact46 baseline/current/approved blobs, also for LSP schemas.
    source = read(V9/'source46-manifest.json')
    require(source['approved_product_head'] == config['approved_head'] and source['approved_product_tree'] == config['approved_tree'], 'map/product tuple mismatch')
    require(len(source['paths']) == len({row['path'] for row in source['paths']}) == 46, 'exact46 inventory changed')
    for row in source['paths']:
        require(digest(ROOT/row['path']) == row['after_sha256'], 'current source46 hash mismatch')
        for commit, expected in ((config['baseline'],row['before_sha256']), (config['approved_head'],row['after_sha256'])):
            result = subprocess.run(['git','show',commit+':'+row['path']],cwd=ROOT,capture_output=True)
            actual = hashlib.sha256(result.stdout).hexdigest() if result.returncode == 0 else None
            require(actual == expected, 'source46 baseline/approved blob mismatch: '+row['path'])
    require(subprocess.run(['git','diff','--quiet',config['approved_head'],'--','.',':(exclude)docs/work/name-handling'],cwd=ROOT).returncode == 0, 'worktree product changed')
    allowed = {row['path'] for row in source['paths']}
    exclusions = [':(exclude)docs/work/name-handling']+[':(exclude)'+path for path in sorted(allowed)]
    require(subprocess.run(['git','diff','--quiet',config['baseline'],'--','.',*exclusions],cwd=ROOT).returncode == 0, 'other product differs from baseline')
    for commit in subprocess.check_output(['git','rev-list',config['baseline']+'..'+config['approved_head']],cwd=ROOT,text=True).splitlines():
        paths = subprocess.check_output(['git','diff-tree','--no-commit-id','--name-only','-r','-m',commit],cwd=ROOT,text=True).splitlines()
        require(all(path in allowed or path.startswith('docs/work/name-handling/') for path in paths), 'unreviewed product integration history')
    untracked = subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=ROOT).split(b'\0')
    require(all(not path or os.fsdecode(path).startswith('docs/work/name-handling/') for path in untracked), 'untracked product outside docs')

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--protocol',required=True,choices=['compiler58','jim7','lsp23','native15','ccg3','ccg-hook2'])
    parser.add_argument('--v9-final',required=True,type=Path)
    parser.add_argument('--v9-launcher',required=True,type=Path)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--dry-run',action='store_true')
    mode.add_argument('--mint-reviewed',action='store_true')
    parser.add_argument('--expected-manifest-sha256')
    args = parser.parse_args()
    if args.mint_reviewed:
        require(args.expected_manifest_sha256 and digest(BASE/'manifest.json') == args.expected_manifest_sha256, 'mint requires exact root-reviewed allocator manifest SHA')
    manifest = read(BASE/'manifest.json')
    for name, pin in manifest['files'].items():
        require(digest(BASE/name) == pin, 'allocator input changed: '+name)
    config = read(BASE/'config.json')
    require(sum(row['expected_selected'] for row in config['protocols'].values() if row['group']=='original106') == 106 and config['protocols']['ccg-hook2']['expected_selected'] == 2, 'original106/additional2 inventory changed')
    # This cheap closure gate runs before any lock, Git, provider tool or GO activity.
    closed_v9_gate(args.v9_final.resolve(),args.v9_launcher.resolve(),config)
    os.chdir(ROOT)
    protocol = config['protocols'][args.protocol]
    go_path = Path(protocol['base'])/'root-go.json'
    require(not go_path.exists(), 'chosen protocol already has root GO; immutable allocation will not overwrite')
    for item in config['protocols'].values():
        require(digest(Path(item['base'])/'plan.json') == item['plan_sha256'], 'registered protocol plan changed')
        verify_inputs(Path(item['base'])/'runner-input-manifest.json',item['runner_input_manifest_sha256'])
    with open('/tmp/tcl-lsp-naming-build.lock','a') as lock:
        try: fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError: raise Refusal('shared build slot occupied; allocator never queues')
        final_path, launcher_path = args.v9_final.resolve(), args.v9_launcher.resolve()
        evidence_pins = (digest(final_path), digest(launcher_path))
        providers = common_v9(final_path,launcher_path,config)
        candidate = candidate_go(args.protocol,protocol,final_path,launcher_path,config)
        candidate['allocator_manifest_sha256'] = digest(BASE/'manifest.json')
        validate_selected(args.protocol,protocol,candidate,providers,config)
        # Reauthenticate complete source/provider/approval evidence after selected preflight.
        common_v9(final_path,launcher_path,config)
        require((digest(final_path),digest(launcher_path)) == evidence_pins, 'v9 completed evidence changed during allocation')
        if args.dry_run:
            print(json.dumps({'status':'VALIDATED DRY RUN; no GO written/no launch','protocol':args.protocol,
                'expected_selected':protocol['expected_selected'],'v9_final_sha256':digest(final_path),
                'v9_launcher_sha256':digest(launcher_path),'approved_head':config['approved_head'],
                'approved_tree':config['approved_tree']},sort_keys=True))
            return 0
        # Exclusive creation: at most the chosen protocol GO, no future approvals or launch.
        with go_path.open('x') as stream:
            stream.write(json.dumps(candidate,sort_keys=True,indent=2)+'\n')
            stream.flush(); os.fsync(stream.fileno())
        print(json.dumps({'status':'ONE GO WRITTEN; root launches separately','protocol':args.protocol,
            'path':str(go_path),'sha256':digest(go_path)},sort_keys=True))
    return 0

if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (Refusal,FileNotFoundError,KeyError,ValueError,RuntimeError,TypeError,subprocess.CalledProcessError) as error:
        print('REFUSED: '+str(error),file=sys.stderr)
        raise SystemExit(2)
