# Repaired source46 single-protocol allocator preparation

Prepared only. This directory has no root GO. It never launches a protocol, Cargo or a test. Root reviews its exact manifest before a future mint.

The original five protocols remain 106 selected tests: compiler58, jim7, lsp23, native15 and ccg3. Optional ccg-hook2 selects two separate existing live-fold/no-host controls; the total is 108 only when that additional protocol is used. Its exact CLEAR VM peer receipt is pinned. No selectors, assertions, environment policy, budgets or executor88125 bytes change.

Required arguments are one --protocol choice, --v9-final and --v9-launcher. Choose exactly one mode:

    python3 allocate.py --protocol compiler58 --v9-final /actual/v9/run/final.json --v9-launcher /actual/v9/launch/launcher.json --dry-run

    python3 allocate.py --protocol compiler58 --v9-final /actual/v9/run/final.json --v9-launcher /actual/v9/launch/launcher.json --mint-reviewed --expected-manifest-sha256 ROOT_REVIEWED_MANIFEST_SHA

The examples contain placeholders, not evidence or authorization. Incomplete, missing, failed or wrong-version v9 evidence refuses before Git, provider tools, build lock or GO. After closed evidence passes the initial gate, validation takes the nonblocking shared build lock; it never queues. A dry run writes no GO. A reviewed mint exclusively creates only the chosen protocol root-go.json and refuses an existing file. Root invokes the actual launcher separately after reviewing allocation output; no future protocol GOs are created upfront.

Validation binds the actual897b4f9b product/tree0b11e3a0, source46 mapf7568b84, v9plan983d3418/inputs1b16beb7 and actual GOfe533d5d. It checks closed launcher input/GO hashes and transcript, exact eight-package process/argv/timer/group/cargo artifact, raw Cargo diagnostics and zero warnings, full source/provider snapshots and fresh current provider/source equality, monotonic recorded docs-only HEADs and current descendants, all46 baseline/current/committed hashes and worktree/product history. It repeats deep v9 evidence authentication after the selected protocol preflight. Historical failed49/report14 results stay historical; failed typechecking is never admitted.

The allocator AST-loads only explicitly named read-only function definitions from the exact frozen suites. It never imports or executes suite top-level code. Definitions with decorators or defaults are refused. Existing suite source_view functions receive an in-memory GO object, so no provisional GO file is created. Compiler/Jim prerequisite helpers validate the exact archived49 final/launcher and raw/sorted GO distinction. LSP and CCG retain their different evidence field names. The pinned actual compiler/Rust/Tcl environment is process-local and restored; relevant provider paths come from the actual typecheck snapshot, and the selected compiler/Jim provider inventory is checked again under its runtime environment.

Preparation checks are parsing, frozen input/schema inspection and negative dry-run refusal only. The positive path cannot execute before actual v9 closes PASS. Root review and the independent LSP allocator peer are required before minting. No actual GO, Git command, provider process, lock, Cargo or test was run during preparation.

V1 is held: reused LSP source_view required CARGO/PLAN/MANIFEST globals omitted by the initial namespace. V2 supplies their exact frozen base/plan-bound Paths. Static recursive global-name checks cover every loaded guard set; no positive guard path was executed during preparation.
