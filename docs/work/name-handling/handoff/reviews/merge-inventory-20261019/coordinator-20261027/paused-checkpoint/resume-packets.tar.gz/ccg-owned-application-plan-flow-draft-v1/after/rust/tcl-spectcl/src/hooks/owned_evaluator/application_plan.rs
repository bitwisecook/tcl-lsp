// tcl-lsp — a language server and toolchain for Tcl
// Copyright (C) 2026 James Deucker (bitwisecook)
// SPDX-License-Identifier: AGPL-3.0-or-later

//! Data-only source inventory for the separate owned application consumer.
//!
//! This inventory does not implement `ClosedNativeBackend`, select a rewrite,
//! retain normal completion, or grant an ordinary compilation unit authority.
//! The owning backend must additionally validate emitted code, every reached
//! nested compilation, input representations and the locally owned evaluator.

use std::collections::{BTreeMap, BTreeSet};

use tcl_lexer::word_parts::{SubstFlags, WordPart as TemplatePart};
use tcl_registry::hooks::LoweringHookId;
use tcl_registry::native_compilation::NativeCompilationGrammar;
use tcl_registry::substitution::SubstitutionTemplateSelection;
use tcl_registry::{CommandRegistry, InvocationDialect, SemanticOperationId};
use tcl_runtime_api::closed_native_consumer::ClosedSourceRefusal;

use tcl_compiler::ir::{CommandTokens, WordExpr, WordPart};

const MAX_SOURCE_BYTES: usize = 4096;
const MAX_NESTED_SCRIPTS: usize = 64;
const MAX_COMMANDS: usize = 128;
const MAX_DEPTH: usize = 8;

/// Complete original source and nested-source inventory, never a permission.
pub(crate) struct ApplicationSourceInventory {
    source: String,
    scripts: Vec<String>,
    commands: Vec<String>,
    scalar_roots: Vec<String>,
    sites: Vec<ApplicationInvocationSite>,
    templates: Vec<ApplicationTemplateInput>,
    registry: tcl_registry::RegistrySnapshot,
    profile: tcl_dialect::DialectProfileKey,
}

/// Ordered lexical invocation inventory; a site is not a runtime invocation.
pub(crate) struct ApplicationInvocationSite {
    pub(crate) script_index: usize,
    pub(crate) parent_invocation: Option<usize>,
    pub(crate) command_index: usize,
    pub(crate) source_range: std::ops::Range<usize>,
    pub(crate) canonical_target: String,
    pub(crate) operation: SemanticOperationId,
    pub(crate) template_selection: Option<(usize, bool, bool, bool)>,
}

/// Exact owned template data and descriptor flags, still not a reached input.
pub(crate) struct ApplicationTemplateInput {
    pub(crate) invocation_index: usize,
    pub(crate) text: String,
    pub(crate) variables: bool,
    pub(crate) commands: bool,
    pub(crate) backslashes: bool,
}

impl ApplicationSourceInventory {
    pub(crate) fn original_source(&self) -> &str {
        &self.source
    }

    pub(crate) fn nested_scripts(&self) -> &[String] {
        &self.scripts
    }

    pub(crate) fn command_targets(&self) -> &[String] {
        &self.commands
    }

    pub(crate) fn scalar_roots(&self) -> &[String] {
        &self.scalar_roots
    }

    pub(crate) fn invocation_sites(&self) -> &[ApplicationInvocationSite] {
        &self.sites
    }

    pub(crate) fn template_inputs(&self) -> &[ApplicationTemplateInput] {
        &self.templates
    }

    pub(crate) fn matches_metadata(
        &self,
        registry: &CommandRegistry,
        profile: &'static tcl_dialect::DialectProfile,
    ) -> bool {
        self.registry.semantic_key() == registry.snapshot().semantic_key()
            && self.profile == profile.cache_key()
    }
}

/// Inventory the entire source, including known template data and catch bodies.
/// Success only provides input data for the independently checked backend.
pub(crate) fn inventory_application_source(
    source: &str,
    registry: &CommandRegistry,
    profile: &'static tcl_dialect::DialectProfile,
) -> Result<ApplicationSourceInventory, ClosedSourceRefusal> {
    if source.len() > MAX_SOURCE_BYTES {
        return Err(ClosedSourceRefusal::Budget);
    }
    let mut walk = Inventory {
        registry,
        profile,
        scripts: Vec::new(),
        commands: Vec::new(),
        scalars: BTreeMap::new(),
        command_count: 0,
        writes: Vec::new(),
        sites: Vec::new(),
        templates: Vec::new(),
        active_invocation: None,
    };
    walk.script(source, 0)?;
    Ok(ApplicationSourceInventory {
        source: source.to_owned(),
        scripts: walk.scripts,
        commands: walk
            .commands
            .into_iter()
            .collect::<BTreeSet<_>>()
            .into_iter()
            .collect(),
        scalar_roots: walk.scalars.into_keys().collect(),
        sites: walk.sites,
        templates: walk.templates,
        registry: registry.snapshot(),
        profile: profile.cache_key(),
    })
}

struct Inventory<'a> {
    registry: &'a CommandRegistry,
    profile: &'static tcl_dialect::DialectProfile,
    scripts: Vec<String>,
    commands: Vec<String>,
    // Only literal assignments retain template bytes. Unknown values never
    // become a template merely because a later operation expects a string.
    scalars: BTreeMap<String, Option<String>>,
    command_count: usize,
    writes: Vec<String>,
    sites: Vec<ApplicationInvocationSite>,
    active_invocation: Option<usize>,
    templates: Vec<ApplicationTemplateInput>,
}

impl Inventory<'_> {
    fn script(&mut self, source: &str, depth: usize) -> Result<(), ClosedSourceRefusal> {
        if depth > MAX_DEPTH || self.scripts.len() >= MAX_NESTED_SCRIPTS {
            return Err(ClosedSourceRefusal::Budget);
        }
        if source.len() > MAX_SOURCE_BYTES {
            return Err(ClosedSourceRefusal::Budget);
        }
        // This first domain refuses escape processing altogether. In
        // particular raw braced backslash-newline bytes are never treated as
        // the cooked body or template supplied to an original operation.
        if source.as_bytes().contains(&b'\\') {
            return Err(ClosedSourceRefusal::Source);
        }
        let script_index = self.scripts.len();
        let parent_invocation = self.active_invocation;
        self.scripts.push(source.to_owned());
        let config = tcl_lexer::LexerConfig::from_grammar(self.profile.grammar);
        check_geometry(source, config)?;
        let source_map = tcl_lexer::SourceMap::new(source);
        for (command_index, command) in
            tcl_compiler::segmenter::segment_commands_with_offset_and_config(source, 0, config)
                .into_iter()
                .enumerate()
        {
            self.command_count += 1;
            if self.command_count > MAX_COMMANDS || command.is_partial {
                return Err(ClosedSourceRefusal::Source);
            }
            let tokens = CommandTokens::from_segmented(&source_map, config, &command);
            let words = tokens.words();
            if !matches!(words.first(), Some(WordExpr::Literal { .. })) {
                return Err(ClosedSourceRefusal::Source);
            }
            let dialect = InvocationDialect::of_profile(self.profile);
            let effective = words
                .iter()
                .map(|word| {
                    tcl_compiler::registry_invocation::effective_invocation_word(
                        word,
                        dialect.lexer_grammar.escapes,
                        dialect.word_values,
                    )
                })
                .collect::<Vec<_>>();
            let registry_words = effective
                .iter()
                .map(|word| word.as_registry_word())
                .collect::<Vec<_>>();
            let invocation =
                tcl_registry::InvocationWords::structured(registry_words[0], &registry_words[1..])
                    .with_dialect(dialect);
            let resolution =
                tcl_registry::model::assembly::resolve_structured_invocation_in_resolved_context(
                    self.registry,
                    None,
                    invocation,
                    tcl_dialect::model::InvocationRealm::RuleLoader,
                );
            let Some(resolved) = resolution.resolved() else {
                return Err(ClosedSourceRefusal::Source);
            };
            let facts = resolved.facts();
            let template_selection = resolved.native_substitution_template();
            self.commands.push(facts.canonical_command.clone());
            let template_flags = match &template_selection {
                SubstitutionTemplateSelection::Template {
                    template_at, kinds, ..
                } => Some((
                    *template_at,
                    kinds.variables,
                    kinds.commands,
                    kinds.backslashes,
                )),
                _ => None,
            };
            let site_index = self.sites.len();
            self.sites.push(ApplicationInvocationSite {
                script_index,
                parent_invocation,
                command_index,
                source_range: command.span.as_range(),
                canonical_target: facts.canonical_command.clone(),
                operation: facts.operation,
                template_selection: template_flags,
            });
            self.active_invocation = Some(site_index);
            for word in &words[1..] {
                self.word(word, depth)?;
            }
            match facts.operation {
                SemanticOperationId::StructuredLowering(LoweringHookId::Set) => {
                    let [_, WordExpr::Literal { text: name, .. }, value] = words else {
                        return Err(ClosedSourceRefusal::Source);
                    };
                    if !super::plain_scalar(name) {
                        return Err(ClosedSourceRefusal::Source);
                    }
                    self.writes.push(name.clone());
                    self.scalars.insert(name.clone(), literal(value));
                }
                SemanticOperationId::Intrinsic(tcl_registry::IntrinsicId::ChannelWrite)
                    if words.len() == 2 => {}
                SemanticOperationId::Intrinsic(tcl_registry::IntrinsicId::ListConstruct) => {}
                SemanticOperationId::StructuredLowering(LoweringHookId::Catch) => {
                    let [_, WordExpr::BracedLiteral { text, .. }] = words else {
                        return Err(ClosedSourceRefusal::Source);
                    };
                    let writes_at_entry = self.writes.len();
                    self.script(text, depth + 1)?;
                    // Any potentially abrupt prefix may leave a write live,
                    // even when a later statement restores the original bytes.
                    for name in &self.writes[writes_at_entry..] {
                        self.scalars.insert(name.clone(), None);
                    }
                }
                SemanticOperationId::Invoke => {
                    if let SubstitutionTemplateSelection::Template {
                        template_at,
                        kinds,
                        parse_errors,
                    } = template_selection
                    {
                        let word = words
                            .get(template_at + 1)
                            .ok_or(ClosedSourceRefusal::Source)?;
                        self.template(
                            word,
                            SubstFlags {
                                vars: kinds.variables,
                                cmds: kinds.commands,
                                backslashes: kinds.backslashes,
                                ..SubstFlags::default()
                            },
                            parse_errors.variable_syntax(),
                            depth,
                        )?;
                    } else if matches!(
                        facts.native_compilation.map(|spec| spec.grammar),
                        Some(NativeCompilationGrammar::StringMap(_))
                    ) && words.len() == facts.argument_offset + 3
                    {
                        // Complete mapping validity and abrupt behavior remain
                        // backend obligations; catch withdraws every prefix write.
                    } else {
                        return Err(ClosedSourceRefusal::Source);
                    }
                }
                _ => return Err(ClosedSourceRefusal::Source),
            }
        }
        self.active_invocation = parent_invocation;
        Ok(())
    }

    fn word(&mut self, word: &WordExpr, depth: usize) -> Result<(), ClosedSourceRefusal> {
        match word {
            WordExpr::Literal { .. } | WordExpr::BracedLiteral { .. } => Ok(()),
            WordExpr::Variable { spelling, .. } => self.read(spelling),
            WordExpr::CommandSubstitution { spelling, .. } => self.bracket(spelling, depth),
            WordExpr::Template {
                parts,
                rejected: None,
                ..
            } => {
                for part in parts {
                    match part {
                        WordPart::Text { .. } => {}
                        WordPart::Variable { spelling, .. } => self.read(spelling)?,
                        WordPart::CommandSubstitution { spelling, .. } => {
                            self.bracket(spelling, depth)?
                        }
                        WordPart::Opaque { .. } => return Err(ClosedSourceRefusal::Source),
                    }
                }
                Ok(())
            }
            _ => Err(ClosedSourceRefusal::Source),
        }
    }

    fn bracket(&mut self, spelling: &str, depth: usize) -> Result<(), ClosedSourceRefusal> {
        let source = spelling
            .strip_prefix('[')
            .and_then(|s| s.strip_suffix(']'))
            .ok_or(ClosedSourceRefusal::Source)?;
        self.script(source, depth + 1)
    }

    fn read(&self, spelling: &str) -> Result<(), ClosedSourceRefusal> {
        let name = variable_name(spelling).ok_or(ClosedSourceRefusal::Source)?;
        self.scalars
            .contains_key(name)
            .then_some(())
            .ok_or(ClosedSourceRefusal::Source)
    }

    fn template(
        &mut self,
        word: &WordExpr,
        flags: SubstFlags,
        variable_syntax: tcl_lexer::word_parts::TemplateVariableSyntax,
        depth: usize,
    ) -> Result<(), ClosedSourceRefusal> {
        let text = if let Some(value) = literal(word) {
            value
        } else if let WordExpr::Variable { spelling, .. } = word {
            self.scalars
                .get(variable_name(spelling).ok_or(ClosedSourceRefusal::Source)?)
                .and_then(Clone::clone)
                .ok_or(ClosedSourceRefusal::Source)?
        } else {
            return Err(ClosedSourceRefusal::Source);
        };
        self.templates.push(ApplicationTemplateInput {
            invocation_index: self.active_invocation.ok_or(ClosedSourceRefusal::Source)?,
            text: text.clone(),
            variables: flags.vars,
            commands: flags.cmds,
            backslashes: flags.backslashes,
        });
        let config = tcl_lexer::LexerConfig::from_grammar(self.profile.grammar);
        let parts = tcl_lexer::word_parts::decompose_template_spanned(
            text.as_bytes(),
            flags,
            config,
            variable_syntax,
        )
        .map_err(|_| ClosedSourceRefusal::Source)?;
        for part in parts {
            match part.part {
                TemplatePart::Text(_) => {}
                TemplatePart::Variable(value) if value.index.is_none() => {
                    let name =
                        std::str::from_utf8(value.name).map_err(|_| ClosedSourceRefusal::Source)?;
                    if !super::plain_scalar(name) || !self.scalars.contains_key(name) {
                        return Err(ClosedSourceRefusal::Source);
                    }
                }
                TemplatePart::Command(script) => {
                    self.script(
                        std::str::from_utf8(script).map_err(|_| ClosedSourceRefusal::Source)?,
                        depth + 1,
                    )?;
                }
                _ => return Err(ClosedSourceRefusal::Source),
            }
        }
        Ok(())
    }
}

// Resource geometry only; successful scanning grants no source semantics.
fn check_geometry(source: &str, config: tcl_lexer::LexerConfig) -> Result<(), ClosedSourceRefusal> {
    if !tcl_lexer::Lexer::with_config(source, config)
        .braced_word_nesting_within(tcl_core_types::RecursionLimit(8))
        .map_err(|_| ClosedSourceRefusal::Source)?
    {
        return Err(ClosedSourceRefusal::Budget);
    }
    let brackets = tcl_lexer::BracketIndex::build_with_config(source, config);
    let mut depth = 0;
    for &(_, delta) in brackets.events() {
        depth = (depth + delta).max(0);
        if depth > 8 {
            return Err(ClosedSourceRefusal::Budget);
        }
    }
    Ok(())
}

fn literal(word: &WordExpr) -> Option<String> {
    match word {
        WordExpr::Literal { text, .. } | WordExpr::BracedLiteral { text, .. } => Some(text.clone()),
        WordExpr::Template {
            parts,
            rejected: None,
            ..
        } => parts.iter().try_fold(String::new(), |mut value, part| {
            let WordPart::Text { text, .. } = part else {
                return None;
            };
            if text.contains('\\') {
                return None;
            }
            value.push_str(text);
            Some(value)
        }),
        _ => None,
    }
}

fn variable_name(spelling: &str) -> Option<&str> {
    let name = spelling.strip_prefix('$')?;
    let name = name
        .strip_prefix('{')
        .and_then(|n| n.strip_suffix('}'))
        .unwrap_or(name);
    super::plain_scalar(name).then_some(name)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn inventory(source: &str) -> Result<ApplicationSourceInventory, ClosedSourceRefusal> {
        let profile = tcl_registry::model::ingress::resolve_known_environment("tcl9.1")
            .and_then(|environment| environment.catalogue_profile())
            .expect("maintained Tcl 9.1 metadata");
        inventory_application_source(
            source,
            tcl_registry::model::static_context_for("tcl9.1").commands(),
            profile,
        )
    }

    #[test]
    fn inventory_keeps_the_complete_sample_and_its_injection_body() {
        let source = include_str!(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/../../samples/diagnostics/W102_subst_injection/example.tcl"
        ));
        let plan = inventory(source).expect("the whole original source has a bounded inventory");
        assert_eq!(plan.original_source(), source);
        assert!(
            plan.nested_scripts()
                .iter()
                .any(|script| script == "subst $evil")
        );
        assert!(
            plan.nested_scripts()
                .iter()
                .any(|script| script == "puts \"INJECTED\"")
        );
        assert!(
            plan.command_targets()
                .iter()
                .any(|command| command == "catch")
        );
        assert!(plan.scalar_roots().iter().any(|name| name == "evil"));
    }

    #[test]
    fn inventory_refuses_an_unsupported_tail_instead_of_admitting_a_prefix() {
        assert!(inventory("set name World\nputs $name\nexec external").is_err());
        assert!(inventory("set script {exec external}\nsubst $script").is_ok());
        assert!(inventory("set script {[exec external]}\nsubst $script").is_err());
    }

    #[test]
    fn inventory_requires_owned_literal_template_data_and_known_scalar_reads() {
        assert!(inventory("subst $foreign").is_err());
        assert!(inventory("set value [list data]\nsubst $value").is_err());
        assert!(inventory("set value {$foreign}\nsubst $value").is_err());
        assert!(inventory("set value {literal}\nsubst $value").is_ok());
    }

    #[test]
    fn inventory_refuses_braced_escape_cooking_without_a_cooked_source_owner() {
        assert!(inventory("set v {a\\\n b}\nsubst $v").is_err());
        assert!(inventory("catch {puts a\\\n b}").is_err());
    }

    #[test]
    fn inventory_refuses_excessive_geometry_before_the_full_token_walk() {
        assert!(matches!(
            inventory("set v {{{{{{{{{data}}}}}}}}}"),
            Err(ClosedSourceRefusal::Budget)
        ));
        assert!(matches!(
            inventory("puts [list [list [list [list [list [list [list [list [list data]]]]]]]]]"),
            Err(ClosedSourceRefusal::Budget)
        ));
    }

    #[test]
    fn inventory_does_not_assign_set_semantics_to_a_same_named_untyped_row() {
        let mut registry = CommandRegistry::build_default();
        registry.insert(tcl_registry::CommandSpec {
            name: "set",
            ..tcl_registry::CommandSpec::DEFAULT
        });
        let profile = tcl_registry::model::ingress::resolve_environment("tcl9.1").unit_profile();
        assert!(inventory_application_source("set value literal", &registry, profile).is_err());
    }

    #[test]
    fn inventory_does_not_hide_a_catch_prefix_write_that_is_later_restored() {
        assert!(inventory(
            "set v safe\ncatch {set v {[exec external]}; string map {odd} hi; set v safe}\nsubst $v"
        ).is_err());
    }

    #[test]
    fn inventory_preserves_nocommands_as_data_without_promoting_nested_text() {
        let plan = inventory("set value {[exec external]}\nsubst -nocommands $value")
            .expect("bracket spelling is data in this exact operation");
        assert!(
            !plan
                .command_targets()
                .iter()
                .any(|command| command == "exec")
        );
        assert!(inventory("set value {[exec external]}\nsubst $value").is_err());
    }
}
