// tcl-lsp — a language server and toolchain for Tcl
// Copyright (C) 2026 James Deucker (bitwisecook) <https://github.com/bitwisecook>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.
//
// SPDX-License-Identifier: AGPL-3.0-or-later

//! A pack is a **logical unit, not a file**.
//!
//! `docs/design/registry/spec-packs.md` is explicit about it: authors group however
//! they like — one big `.tclspec`, one per namespace, one per command — and
//! every file whose `speclib` names the same pack merges into one pack model
//! at load. This module is that merge, and the precedence rules around it:
//!
//! - **Merge order is sorted path order**, so the result does not depend on
//!   directory-iteration order, which no filesystem promises.
//! - **A command defined twice within one pack is a load-time diagnostic with
//!   the first definition winning**, never a silent overwrite.
//! - **Nearest tier wins**: a live Spec Studio override, then a workspace,
//!   user, or bundled pack. A pack name declared at more than one tier loads
//!   only from its nearest one, and the shadowed files are reported. This is
//!   whole-pack, not per-command — a user-tier pack is not a base a workspace
//!   pack patches, it is a different copy of the same pack, and merging them
//!   would produce a pack that exists on no one's disk.

use std::collections::BTreeMap;
use std::path::{Path, PathBuf};

use tcl_dialect::model::{Provenance, WorkspaceTrust};
use tcl_registry::registry::CommandRegistry;

use crate::discovery::{Origin, PackFile, Tier};
use crate::hooks::{DormantHook, dormant_hooks};
use crate::loader::{Notice, Pack, PackCommand};
use crate::stamps::StampRefusal;

/// How loudly a notice should be shown. Severity is presentation, not a load
/// verdict: [`PackSet::load_errors`] carries whole-pack evaluation failures.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub enum Severity {
    /// Something the author wrote was dropped: an unknown word, a duplicate
    /// definition, an unreadable file. Worth fixing.
    Warning,
    /// Something the loader decided, correctly, that the author may not have
    /// expected: a shipped name left alone, a shadowed tier, a hook body an
    /// untrusted workspace holds dormant.
    Information,
}

/// One notice, carrying the file it belongs to so the server can publish it as
/// a diagnostic on that file.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct PackNotice {
    /// The `.tclspec` the notice is about.
    pub path: PathBuf,
    /// 1-based line within that file. Line 1 for a whole-file notice.
    pub line: u32,
    /// Where in the pack the notice arose (`"command lsort"`, `"pack"`).
    pub context: String,
    /// What happened.
    pub message: String,
    /// How loudly to show it.
    pub severity: Severity,
    /// Actual loader-issued source subject, independent of rendered notice text.
    pub subject: Option<tcl_lsp_core::code_actions::SpecPackNoticeSubject>,
}

impl PackNotice {
    fn from_loader(path: &Path, notice: &Notice) -> Self {
        Self {
            subject: notice.subject.clone(),
            path: path.to_path_buf(),
            line: notice.line,
            context: notice.context.clone(),
            message: notice.message.clone(),
            severity: Severity::Warning,
        }
    }

    /// A notice about the pack as a whole, on its first line — the shape a
    /// finding that belongs to no single row takes (an environment
    /// registration the live registry refused, a shadowed tier).
    #[must_use]
    pub fn whole_file(path: &Path, message: impl Into<String>, severity: Severity) -> Self {
        Self {
            subject: None,
            path: path.to_path_buf(),
            line: 1,
            context: "pack".to_owned(),
            message: message.into(),
            severity,
        }
    }

    /// The warning a refused codegen-axis stamp draws
    /// ([`crate::stamps`]): on the declaring command's row, naming the
    /// stamp, the provenance or the rule that refused it, and the target the
    /// stamp would have had to sit on. A warning, because something the
    /// author wrote was dropped — though only the stamp: the command loads
    /// with every analysis fact it declared.
    #[must_use]
    pub fn stamp_refused(command: &PackCommand, refusal: &StampRefusal) -> Self {
        Self {
            subject: None,
            path: command.file.clone(),
            line: command.line,
            context: format!("command {}", command.spec.name),
            message: refusal.message(),
            severity: Severity::Warning,
        }
    }

    /// The warning a declaration the package's distance from the root
    /// forbids draws ([`crate::stamps::admit_declarations`]): on the
    /// declaring command's row, naming the declaration and the tier. A
    /// warning, because something the author wrote was dropped — though only
    /// that declaration: the command loads with every analysis fact it
    /// declared.
    #[must_use]
    pub fn declaration_refused(
        command: &PackCommand,
        refusal: &crate::stamps::DeclarationRefusal,
    ) -> Self {
        Self {
            subject: None,
            path: command.file.clone(),
            line: command.line,
            context: format!("command {}", command.spec.name),
            message: refusal.message(),
            severity: Severity::Warning,
        }
    }

    /// The notice a hook body held dormant by an untrusted workspace draws:
    /// once per hook, on the row that declares it, never once per call. It
    /// is information, not a warning — nothing is wrong with the pack, and
    /// granting the workspace trust is what runs the body.
    #[must_use]
    pub fn dormant(hook: &DormantHook) -> Self {
        Self {
            subject: None,
            path: hook.file.clone(),
            line: hook.line,
            context: format!("command {}", hook.command),
            message: format!(
                "`{}` is dormant: the workspace is not trusted, so this hook body does not \
                 run and the command keeps its declarative facts",
                hook.field
            ),
            severity: Severity::Information,
        }
    }

    /// The notice a `runtime_backing tcl-body {-pack-text …}` draws: once,
    /// on the declaring command's row. The body text travels with the pack,
    /// so an upgrade of the library it models diverges from it silently;
    /// information, because nothing is wrong with the pack, and the sites that
    /// rest on such a body turn plain on the first mismatch.
    #[must_use]
    pub fn pack_text_backing(command: &PackCommand) -> Self {
        Self {
            subject: None,
            path: command.file.clone(),
            line: command.line,
            context: format!("command {}", command.spec.name),
            message:
                "`runtime_backing tcl-body {-pack-text …}` carries the body in the pack, so an \
                      upgrade of the library it models diverges from it silently; sites that rest \
                      on it turn plain dispatch on the first mismatch"
                    .to_owned(),
            severity: Severity::Information,
        }
    }
}

/// One pack, merged from every file that named it.
#[derive(Debug, Clone)]
pub struct MergedPack {
    /// The `speclib` name every contributing file agreed on.
    pub name: String,
    /// The DSL vocabulary version, from the first file in merge order.
    pub dsl_version: String,
    /// The tier the pack loaded from.
    pub tier: Tier,
    /// The editor's Workspace Trust state the pack loaded under — the
    /// workspace's for a workspace-tier pack, [`WorkspaceTrust::Trusted`]
    /// for every other tier ([`Tier::trust_under`]). With [`Self::tier`] it
    /// is the pack's provenance ([`Self::provenance`]).
    pub trust: WorkspaceTrust,
    /// The files that contributed, in merge (sorted path) order.
    pub files: Vec<PathBuf>,
    /// The pack's human-readable name, from the first file that declares
    /// one (`display_name {IEEE 1801 UPF}`).
    pub display_name: Option<String>,
    /// The file extensions the pack's language is written under, merged
    /// first-declaration-wins across the pack's files.
    pub file_extensions: Vec<crate::loader::FileExtension>,
    /// The packages the pack declares ambient, merged across its files.
    ///
    /// Every row is kept, including two files naming the same package: they
    /// are floors, and [`CommandRegistry::ambient_package_floor`] takes the
    /// highest. Dropping one here would silently lower the floor instead.
    pub ambient_packages: Vec<crate::loader::AmbientPackage>,
    /// The special variables the pack declares, merged
    /// first-declaration-wins across the pack's files.
    pub special_vars: Vec<crate::loader::PackSpecialVar>,
    /// The `environment NAME { … }` blocks the pack declares (`SpecTcl`
    /// 2.0), merged first-declaration-wins across the pack's files.
    ///
    /// Carried; registering them into the live registry is
    /// [`crate::registration::publish_pack_set`]'s call — made for the
    /// whole set at the one publish point
    /// ([`crate::bundled::set_active`]), so a pack that leaves the
    /// workspace has its environments retired by the same call that
    /// re-registers the ones that stayed. It consumes exactly these
    /// blocks (declarations through
    /// [`PackEnvironment::to_definition`](crate::PackEnvironment::to_definition),
    /// `-extend` blocks through `to_extension`) under the §6.4 trust
    /// lattice.
    pub environments: Vec<crate::loader::PackEnvironment>,
    /// The `dialect NAME { … }` blocks the pack declares (`SpecTcl` 2.0),
    /// merged first-declaration-wins across the pack's files.
    ///
    /// Converted to live family data by the same publish call, through
    /// [`crate::dialect_conversion`]: a namespaced `PACK/DIALECT` family
    /// with a grammar per declared release, plus the core bindings of the
    /// environments above that ride one.
    pub dialects: Vec<crate::loader::PackDialect>,
    /// The `include from … into …` surface rosters the pack declares
    /// (`SpecTcl` 2.0, design **Q6**), concatenated across its files.
    ///
    /// Concatenated, not first-wins: several rows are how one roster with
    /// per-release windows is written, so dropping a later row for the
    /// same pair would silently truncate the surface it enumerates. The
    /// fold into one roster per pair happens at conversion
    /// ([`crate::surface_roster_conversion`]).
    pub surface_rosters: Vec<crate::loader::PackSurfaceRoster>,
    /// The merged commands: first definition of a name wins.
    pub commands: Vec<PackCommand>,
}

impl MergedPack {
    /// The command of that name, if the pack declares one.
    #[must_use]
    pub fn command(&self, name: &str) -> Option<&PackCommand> {
        self.commands.iter().find(|c| c.spec.name == name)
    }

    /// The §6.4 trust class the pack's definitions carry: its tier read
    /// under its trust state, so a pack from a workspace the editor has not
    /// trusted is [`Provenance::WorkspaceUntrusted`]. Authority does not
    /// read this — every declarative fact the pack states reaches the
    /// registry whatever it answers — only the gates the trust ruling names.
    #[must_use]
    pub fn provenance(&self) -> Provenance {
        crate::loader::PackEnvironmentTier::of(self.tier, self.trust).provenance()
    }
}

/// Every pack a workspace loads, plus everything the load wanted to say.
#[derive(Debug, Clone, Default)]
pub struct PackSet {
    /// The merged packs, in name order.
    pub packs: Vec<MergedPack>,
    /// Every notice, from every file, in file-then-line order.
    pub notices: Vec<PackNotice>,
    /// Whole-pack evaluation failures, with their source files, before merging.
    /// Ordinary notices do not imply failure: a valid pack may declare no commands.
    pub load_errors: Vec<(PathBuf, crate::LoadError)>,
    /// Content key over every contributing file plus the vocabulary version
    /// and loader build — the identity this pack set installs under in the
    /// per-profile registry cache. `0` for an empty set, which is the
    /// "no packs" identity [`crate::install::registry_with_packs`] short-
    /// circuits on.
    pub key: u64,
}

impl PackSet {
    /// `true` when no pack contributed anything the registry would carry.
    ///
    /// Commands are not the only payload: a pack whose whole content is
    /// `ambient_package` rows still floors those packages for every document
    /// the pack is active in, so it is *not* empty. Counting only commands
    /// made [`crate::install::registry_with_packs`] short-circuit on such a
    /// pack and drop the floor with no notice — the silent-drop class this
    /// loader exists to make impossible.
    #[must_use]
    pub fn is_empty(&self) -> bool {
        self.packs.iter().all(|p| {
            p.commands.is_empty() && p.ambient_packages.is_empty() && p.special_vars.is_empty()
        })
    }

    /// Every file that contributed to, or produced a notice about, this set —
    /// the files a reload must watch.
    #[must_use]
    pub fn files(&self) -> Vec<PathBuf> {
        let mut files: Vec<PathBuf> = self
            .packs
            .iter()
            .flat_map(|p| p.files.iter().cloned())
            .chain(self.notices.iter().map(|n| n.path.clone()))
            .collect();
        files.sort();
        files.dedup();
        files
    }

    /// The notices that belong to `path`.
    pub fn notices_for<'a>(&'a self, path: &Path) -> impl Iterator<Item = &'a PackNotice> {
        let path = path.to_path_buf();
        self.notices.iter().filter(move |n| n.path == path)
    }

    /// The pack facts a VM holds while it runs code compiled against this
    /// set's installed registry (`tcl_vm::Vm::set_pack_facts`): one stamp
    /// for each pack file whose commands the set installs, under the set's
    /// key (the registry's overlay generation) and `evaluator_revision` —
    /// the revision the compiling thread's sites recorded
    /// (`tcl_compiler::site_claims::evaluator_revision`). A site whose claim
    /// is not among them is refused, so a changed pack turns its sites plain.
    #[must_use]
    pub fn fact_stamps(&self, evaluator_revision: u64) -> Vec<tcl_runtime_api::PackFactStamp> {
        let mut stamps: Vec<tcl_runtime_api::PackFactStamp> = self
            .packs
            .iter()
            .flat_map(|pack| {
                pack.commands.iter().map(move |command| {
                    tcl_compiler::site_claims::pack_fact_stamp(
                        &crate::install::pack_origin(pack, command),
                        self.key,
                        evaluator_revision,
                    )
                })
            })
            .collect();
        stamps.sort();
        stamps.dedup();
        stamps
    }

    /// Every `(extension, dialect)` routing pair the set's packs declare —
    /// the rows with a `-dialect`, deduplicated first-pack-wins in the
    /// set's (name-sorted) pack order.
    #[must_use]
    pub fn extension_dialects(&self) -> Vec<(String, &'static str)> {
        let mut out: Vec<(String, &'static str)> = Vec::new();
        for pack in &self.packs {
            for row in &pack.file_extensions {
                if let Some(dialect) = row.dialect
                    && !out.iter().any(|(ext, _)| *ext == row.extension)
                {
                    out.push((row.extension.clone(), dialect));
                }
            }
        }
        out
    }
}

/// [`load_sources`] with the sources already in hand and no prior notices —
/// the door `tcl spec upgrade --verify` loads a rewritten pack through
/// without ever putting it on disk. Trusted: an authoring tool's own file,
/// never an editor's workspace ([`load_in_memory_under`] names the state).
#[must_use]
pub fn load_in_memory(sources: Vec<(PackFile, String)>) -> PackSet {
    load_in_memory_under(sources, WorkspaceTrust::Trusted)
}

/// [`load_in_memory`] with the workspace tier's files loaded under `trust`.
#[must_use]
pub fn load_in_memory_under(sources: Vec<(PackFile, String)>, trust: WorkspaceTrust) -> PackSet {
    load_sources(sources, Vec::new(), trust, None)
}

/// Load and merge every discovered file, the workspace tier trusted — a
/// caller holding an editor's trust state loads through [`load_under`].
#[must_use]
pub fn load(files: &[PackFile]) -> PackSet {
    load_under(files, WorkspaceTrust::Trusted)
}

/// Load and merge every discovered file, the workspace tier's under `trust`.
///
/// Reads each file, loads it through [`crate::cache::evaluate_pack_cached`]
/// at the file's own provenance tier and trust state (so an unchanged pack
/// costs a hash check, and design E-R2 gates what an untrusted provenance may
/// register), then groups by `speclib` name.
#[must_use]
pub fn load_under(files: &[PackFile], trust: WorkspaceTrust) -> PackSet {
    let store = tcl_lsp_core::vfs::NativeStore;
    let (sources, notices) = read_sources(&store, files);
    load_sources(sources, notices, trust, Some(&store))
}

/// Original ordinary loader inputs, separate from labels and discovery paths.
/// These retained images supply no currentness until their provider reborrows.
#[derive(Default)]
pub struct LoadedSourceInputs {
    sources: Vec<LoadedSourceInput>,
    selection_sources: Vec<LoadedSourceInput>,
    selection_unavailable: bool,
    pub(crate) unretained_nested_inputs: bool,
}

struct LoadedSourceInput {
    path: std::path::PathBuf,
    origin: Option<tcl_lsp_core::vfs::SourcePathOrigin>,
    source: String,
}

pub(crate) struct LoadedSourceRead {
    pub(crate) sources: Vec<(PackFile, String)>,
    pub(crate) notices: Vec<PackNotice>,
    pub(crate) inputs: LoadedSourceInputs,
}

impl LoadedSourceInputs {
    pub(crate) fn retain_manifest_selection(
        &mut self,
        store: &dyn tcl_lsp_core::vfs::SourceStore,
        selection: &crate::discovery::ManifestSelectionInputs,
    ) {
        self.selection_unavailable |= !selection.issues.is_empty();
        for (path, source) in &selection.sources {
            let origin = store.source_path_origin(path).ok().filter(|origin| {
                origin.path().as_os_str() == path.as_os_str()
                    && store.validate_source_path_origin(origin).is_ok()
            });
            self.selection_sources.push(LoadedSourceInput {
                path: path.clone(),
                source: source.clone(),
                origin,
            });
        }
    }

    /// Paths of all actual ordinary images read for the merged installed set.
    /// This is retained loader selection, not a new discovery inventory.
    #[must_use]
    pub fn retained_paths(&self) -> Vec<std::path::PathBuf> {
        self.sources
            .iter()
            .map(|input| input.path.clone())
            .collect()
    }

    /// Borrow exact ordinary inputs for the selected contributing native paths.
    /// Missing provider origins or missing loader images remain unavailable.
    #[must_use]
    pub fn selected<'a>(
        &'a self,
        paths: &[std::path::PathBuf],
    ) -> Option<Vec<(&'a tcl_lsp_core::vfs::SourcePathOrigin, &'a [u8])>> {
        if self.unretained_nested_inputs || self.selection_unavailable {
            return None;
        }
        let mut selected: Vec<_> = paths
            .iter()
            .map(|path| {
                let mut sources = self.sources.iter().filter(|input| &input.path == path);
                let input = sources.next()?;
                if sources.next().is_some() {
                    return None;
                }
                Some((input.origin.as_ref()?, input.source.as_bytes()))
            })
            .collect::<Option<_>>()?;
        // The same source-publication receipt reborrows the actual manifest
        // images which selected this set, even when those are not pack files.
        for input in &self.selection_sources {
            selected.push((input.origin.as_ref()?, input.source.as_bytes()));
        }
        Some(selected)
    }
}

/// Read every discovered file, turning an unreadable one into a notice rather
/// than dropping it silently.
///
/// Split out of [`load`] so [`crate::bundled::load_discovered`] can add the
/// embedded bundled sources to the same vec before the merge, instead of
/// merging twice and reconciling two content keys.
pub(crate) fn read_sources(
    store: &dyn tcl_lsp_core::vfs::SourceStore,
    files: &[PackFile],
) -> (Vec<(PackFile, String)>, Vec<PackNotice>) {
    let read = read_sources_with_inputs(store, files);
    (read.sources, read.notices)
}

pub(crate) fn read_sources_with_inputs(
    store: &dyn tcl_lsp_core::vfs::SourceStore,
    files: &[PackFile],
) -> LoadedSourceRead {
    let mut sources: Vec<(PackFile, String)> = Vec::with_capacity(files.len());
    let mut notices: Vec<PackNotice> = Vec::new();
    let mut inputs = LoadedSourceInputs::default();

    for file in files {
        let origin = store
            .source_path_origin(&file.path)
            .ok()
            .filter(|origin| origin.path().as_os_str() == file.path.as_os_str());
        match store.read_to_string(&file.path) {
            Ok(source) => {
                inputs.sources.push(LoadedSourceInput {
                    path: file.path.clone(),
                    origin: origin
                        .filter(|origin| store.validate_source_path_origin(origin).is_ok()),
                    source: source.clone(),
                });
                sources.push((file.clone(), source));
            }
            Err(err) => {
                // A selected read with no retained image cannot certify the merge.
                inputs.unretained_nested_inputs = true;
                notices.push(PackNotice::whole_file(
                    &file.path,
                    format!("cannot read pack file: {err}"),
                    Severity::Warning,
                ));
            }
        }
    }

    LoadedSourceRead {
        sources,
        notices,
        inputs,
    }
}

/// [`load`]'s merge, taken with the source text already in hand rather than
/// read from `file.path` on disk.
///
/// [`crate::bundled`]'s embedded-pack fallback is the one other caller: a
/// standalone binary with no `specs/` directory beside it (every
/// `tcl-lsp-server-<triple>` / `tcl-mcp-<triple>` / `tcl-<triple>` /
/// `f5-query-<triple>` release asset, until something stages one there —
/// the VSIX/JetBrains/Sublime bundles, a dev checkout, or
/// `TCL_LSP_SPEC_PACK_DIR`) has the eight shipped `.tclspec` sources compiled
/// in via `include_str!` but nowhere on disk to point a [`PackFile`] at.
/// Everything past "read the bytes" — cache lookup, `speclib` grouping,
/// tier-shadowing, duplicate-command detection, the content key — is
/// identical either way, so this is the one seam that seam splits on, not a
/// second implementation of the merge.
///
/// `notices` carries whatever the caller already collected before sources
/// were in hand (e.g. [`load`]'s unreadable-file notices); embedded sources
/// never fail to "read", so [`crate::bundled`] always passes an empty vec.
///
/// `trust` is the editor's Workspace Trust state; each file reads it through
/// its own tier ([`Tier::trust_under`]), so only the workspace tier's files
/// evaluate, cache and merge under it.
#[must_use]
pub(crate) fn load_sources(
    sources: Vec<(PackFile, String)>,
    notices: Vec<PackNotice>,
    trust: WorkspaceTrust,
    store: Option<&dyn tcl_lsp_core::vfs::SourceStore>,
) -> PackSet {
    let set = load_sources_unpublished(sources, notices, trust, store);
    crate::registration::publish_pack_extension_routes(&set);
    set
}

/// Construct unpublished packs solely from immutable declarative text.
/// No caller callbacks, source store, include resolver or VM fallback enter.
pub(crate) fn load_owned_static_sources(
    sources: Vec<(PackFile, String)>,
    trust: WorkspaceTrust,
) -> Option<PackSet> {
    if sources.is_empty() || sources.len() > 64 {
        return None;
    }
    let key = set_key(&sources, trust);
    let mut by_name: BTreeMap<String, Vec<(PackFile, Pack)>> = BTreeMap::new();
    for (file, source) in sources {
        let options = crate::loader::EvalOptions {
            tier: file.tier,
            trust: file.tier.trust_under(trust),
            ..crate::loader::EvalOptions::default()
        };
        let pack = crate::loader::evaluate_owned_static_pack(&source, &options)?;
        if pack.name.is_empty() {
            return None;
        }
        by_name
            .entry(pack.name.clone())
            .or_default()
            .push((file, pack));
    }
    let set = finish_loaded_sources(
        by_name,
        Vec::new(),
        Vec::new(),
        trust,
        None,
        None,
        LoadedMergeState {
            key,
            provisioned: xxhash_rust::xxh3::Xxh3::new(),
            read_any: false,
        },
    );
    // Package backings and extension artefacts require separate providers;
    // this first private owner accepts neither.
    if !set.load_errors.is_empty()
        || set.packs.iter().any(|pack| {
            pack.commands
                .iter()
                .any(|command| crate::package_sources::declared_source_path(command).is_some())
                || crate::extension_artefacts::has_external_inputs(&pack.commands)
        })
    {
        return None;
    }
    Some(set)
}

/// Prepare through the same evaluator/merge without publishing global routing.
/// The actual host must publish only at its own current-source boundary.
pub(crate) fn load_sources_unpublished(
    sources: Vec<(PackFile, String)>,
    notices: Vec<PackNotice>,
    trust: WorkspaceTrust,
    store: Option<&dyn tcl_lsp_core::vfs::SourceStore>,
) -> PackSet {
    load_sources_unpublished_inner(sources, notices, trust, store, None, None)
}

pub(crate) fn load_sources_unpublished_with_inputs(
    sources: Vec<(PackFile, String)>,
    notices: Vec<PackNotice>,
    trust: WorkspaceTrust,
    store: Option<&dyn tcl_lsp_core::vfs::SourceStore>,
    inputs: &mut LoadedSourceInputs,
    owned_store: Option<std::sync::Arc<dyn tcl_lsp_core::vfs::SourceStore>>,
) -> PackSet {
    load_sources_unpublished_inner(sources, notices, trust, store, Some(inputs), owned_store)
}

// `owned_store` is cloned once per pack file, so the caller's handle is shared.
#[allow(clippy::too_many_lines, clippy::needless_pass_by_value)]
fn load_sources_unpublished_inner(
    sources: Vec<(PackFile, String)>,
    mut notices: Vec<PackNotice>,
    trust: WorkspaceTrust,
    store: Option<&dyn tcl_lsp_core::vfs::SourceStore>,
    mut inputs: Option<&mut LoadedSourceInputs>,
    owned_store: Option<std::sync::Arc<dyn tcl_lsp_core::vfs::SourceStore>>,
) -> PackSet {
    // Keyed from the bytes, before anything is parsed: the key must describe
    // the input, not what the loader made of it.
    let key = set_key(&sources, trust);
    // What the load reads beside the packs — the package files their
    // `-package-source` backings name — is input too.
    let mut provisioned = xxhash_rust::xxh3::Xxh3::new();
    let mut read_any = false;

    // Group by declared pack name. `BTreeMap` so the resulting pack order is
    // by name, deterministically. Each file is parsed exactly once here — the
    // merge below consumes these `Pack`s rather than re-reading the source.
    let mut by_name: BTreeMap<String, Vec<(PackFile, Pack)>> = BTreeMap::new();
    let mut load_errors = Vec::new();
    for (file, source) in sources {
        let file_trust = file.tier.trust_under(trust);
        // The resolver is lazy: helper/computed include invocations receive
        // the same actual provider even when no direct source row names it.
        let pack = {
            let reader = owned_store
                .clone()
                .or_else(|| store.and_then(tcl_lsp_core::vfs::SourceStore::retained_source_reader));
            let observations = std::rc::Rc::new(std::cell::RefCell::new(Vec::new()));
            let context = if let Some(reader) = reader {
                crate::loader::IncludeContext::for_source_store(
                    &file.path,
                    reader,
                    std::rc::Rc::clone(&observations),
                )
            } else {
                let observations = std::rc::Rc::clone(&observations);
                let including_file = file.path.clone();
                crate::loader::IncludeContext::new(move |name| {
                    let path = tcl_compiler::parsing::spectcl_source::include_file_path(
                        &including_file,
                        name,
                    )
                    .unwrap_or_else(|| including_file.clone());
                    let error = "include requires an owned source-provider reader".to_owned();
                    observations
                        .borrow_mut()
                        .push(crate::loader::IncludeSourceObservation {
                            path,
                            origin: None,
                            image: Err(error.clone()),
                        });
                    Err(error)
                })
            };
            let pack = crate::cache::evaluate_pack_including(
                &source,
                file.tier,
                file_trust,
                &std::rc::Rc::new(context),
            );
            for observation in observations.borrow_mut().drain(..) {
                // The same images that were evaluated feed both content key
                // and provider publication; no second read or cached roster.
                read_any = true;
                let path = observation.path.as_os_str().as_encoded_bytes();
                provisioned.update(&(path.len() as u64).to_le_bytes());
                provisioned.update(path);
                match observation.image {
                    Ok(source) => {
                        provisioned.update(&[1]);
                        provisioned.update(&(source.len() as u64).to_le_bytes());
                        provisioned.update(source.as_bytes());
                        if let Some(inputs) = inputs.as_deref_mut() {
                            inputs.selection_sources.push(LoadedSourceInput {
                                path: observation.path,
                                source,
                                origin: observation.origin,
                            });
                        }
                    }
                    Err(error) => {
                        provisioned.update(&[0]);
                        provisioned.update(&(error.len() as u64).to_le_bytes());
                        provisioned.update(error.as_bytes());
                        if let Some(inputs) = inputs.as_deref_mut() {
                            inputs.unretained_nested_inputs = true;
                        }
                    }
                }
            }
            pack
        };
        if let Some(error) = &pack.load_error {
            load_errors.push((file.path.clone(), error.clone()));
        }
        if pack.name.is_empty() {
            // No `speclib` wrapper: nothing to merge, but the loader's
            // explanation of why still belongs on the file.
            for notice in &pack.notices {
                notices.push(PackNotice::from_loader(&file.path, notice));
            }
            continue;
        }
        by_name
            .entry(pack.name.clone())
            .or_default()
            .push((file, pack));
    }

    finish_loaded_sources(
        by_name,
        notices,
        load_errors,
        trust,
        store,
        inputs,
        LoadedMergeState {
            key,
            provisioned,
            read_any,
        },
    )
}

struct LoadedMergeState {
    key: u64,
    provisioned: xxhash_rust::xxh3::Xxh3,
    read_any: bool,
}

fn finish_loaded_sources(
    by_name: BTreeMap<String, Vec<(PackFile, Pack)>>,
    mut notices: Vec<PackNotice>,
    load_errors: Vec<(std::path::PathBuf, crate::LoadError)>,
    trust: WorkspaceTrust,
    store: Option<&dyn tcl_lsp_core::vfs::SourceStore>,
    mut inputs: Option<&mut LoadedSourceInputs>,
    state: LoadedMergeState,
) -> PackSet {
    let LoadedMergeState {
        mut key,
        mut provisioned,
        mut read_any,
    } = state;
    let mut packs = Vec::new();
    for (name, mut group) in by_name {
        // `PackFile` orders by (tier, path), which is exactly precedence then
        // merge order — one sort settles both questions.
        group.sort_by(|a, b| a.0.cmp(&b.0));
        let winning_tier = group[0].0.tier;
        let (winners, shadowed): (Vec<_>, Vec<_>) =
            group.into_iter().partition(|(f, _)| f.tier == winning_tier);

        for (file, _) in &shadowed {
            notices.push(PackNotice::whole_file(
                &file.path,
                format!(
                    "pack `{name}` also loads from the {} tier, which is nearer; \
                     this {} copy is not loaded",
                    winning_tier.label(),
                    file.tier.label()
                ),
                Severity::Information,
            ));
        }

        let mut merged = merge_group(
            &name,
            winning_tier,
            winning_tier.trust_under(trust),
            winners,
            &mut notices,
        );
        admit_commands(&mut merged, &mut notices);
        if let Some(inputs) = inputs.as_deref_mut()
            && (merged
                .commands
                .iter()
                .any(|command| crate::package_sources::declared_source_path(command).is_some())
                || crate::extension_artefacts::has_external_inputs(&merged.commands))
        {
            inputs.unretained_nested_inputs = true;
        }
        read_any |= provision_beside(&mut merged, store, &mut provisioned, &mut notices);
        crate::loader::derive_implementations(&mut merged.commands, &mut notices);
        say_pack_text_backings(&merged, &mut notices);
        // The execution half of the trust ruling, said where the author
        // looks: each body an untrusted workspace holds dormant, on its own
        // row. `hooks::plan_for` reads the same list and allocates none of
        // them a slot.
        notices.extend(
            dormant_hooks(&merged.name, &merged.commands, merged.provenance())
                .iter()
                .map(PackNotice::dormant),
        );
        packs.push(merged);
    }

    // Cross-pack collisions, once every pack is merged — the only point where
    // all of them are known at once.
    notices.extend(cross_pack_command_notices(&packs));
    notices.extend(cross_pack_extension_notices(&packs));

    notices.sort_by(|a, b| {
        (&a.path, a.line, &a.context, &a.message).cmp(&(&b.path, b.line, &b.context, &b.message))
    });
    notices.dedup();

    if read_any {
        // A set that read nothing keeps the key its sources gave it. A
        // digest of 0 would read as "no packs" to the registry cache.
        key = match xxhash_rust::xxh3::xxh3_64(
            &[&key.to_le_bytes()[..], &provisioned.digest().to_le_bytes()].concat(),
        ) {
            0 => 1,
            folded => folded,
        };
    }

    PackSet {
        packs,
        notices,
        load_errors,
        key,
    }
}

/// What the load reads beside a pack, through the store that read the packs:
/// the files its `-package-source` backings point at and the compiled
/// extensions its `-host wasm_extension` implementations run, each digest
/// folded into `provisioned`. A load with no store reads neither, and a
/// command whose body is not in hand is simply not inlined. Answers whether
/// it read anything.
fn provision_beside(
    merged: &mut MergedPack,
    store: Option<&dyn tcl_lsp_core::vfs::SourceStore>,
    provisioned: &mut xxhash_rust::xxh3::Xxh3,
    notices: &mut Vec<PackNotice>,
) -> bool {
    let Some(store) = store else {
        return false;
    };
    let sources = crate::package_sources::provision(&mut merged.commands, store, notices);
    let artefacts =
        crate::extension_artefacts::provision(&merged.name, &mut merged.commands, store, notices);
    for digest in [sources, artefacts].into_iter().flatten() {
        provisioned.update(&digest.to_le_bytes());
    }
    sources.is_some() || artefacts.is_some()
}

/// The capability gate on the merged commands of one pack, each refusal said on
/// its command's row.
///
/// The stamp rejection rule: a codegen-axis stamp survives only as a bundled
/// pack's `alias_of` target's own. Only the stamp goes; the command keeps every
/// analysis fact it declared. Then the gate's other two declarations, on the same
/// command: what a package too far from the root may not say.
fn admit_commands(merged: &mut MergedPack, notices: &mut Vec<PackNotice>) {
    let provenance = merged.provenance();
    for command in &mut merged.commands {
        for refusal in
            crate::stamps::admit_codegen_stamps(command, provenance, crate::stamps::shipped())
        {
            notices.push(PackNotice::stamp_refused(command, &refusal));
        }
        for refusal in crate::stamps::admit_declarations(command) {
            notices.push(PackNotice::declaration_refused(command, &refusal));
        }
    }
}

/// A body carried in the pack is the one backing that goes stale without anyone
/// touching the pack, so it is said at load.
fn say_pack_text_backings(merged: &MergedPack, notices: &mut Vec<PackNotice>) {
    for command in &merged.commands {
        if matches!(
            command.spec.runtime_backing,
            tcl_registry::RuntimeBacking::TclBody {
                source: tcl_registry::BodySource::PackText { .. },
                ..
            }
        ) {
            notices.push(PackNotice::pack_text_backing(command));
        }
    }
}

/// Report every command name two *different* packs both claim.
///
/// The in-pack duplicate is caught by [`merge_group`] and the shipped-command
/// clash by [`collision_notices`]; between two packs neither of those fires,
/// so without this check the loser would be dropped by [`installs_over`] and
/// the winner decided by pack-name sort order, in silence.
///
/// This walks the packs in exactly the order [`crate::install::install_into`]
/// does and applies the same rule, so the notice can never disagree with what
/// actually reached the registry: a later claim wins only if it says
/// `-override`, and either way the losing declaration is named.
///
/// # The vendor gate applies here too
///
/// [`crate::install::install_into`] skips a command whose `required_package`
/// names a closed-world vendor package the profile does not ship, which is
/// what lets the bundled tier carry all six EDA libraries at once: four of
/// them declare a `report_timing`, and they never meet because no profile
/// admits two vendors. A collision check that ignored that gate would report
/// every one of those as a clash — a dozen warnings on the *shipped* packs, in
/// every user's Problems panel, for something that cannot happen.
///
/// So two claims collide only when some profile would install both, which
/// [`could_collide`] asks exactly.
///
/// # Two shipped packs layering on purpose is not a collision either
///
/// `sdc_base` declares the SDC commands every EDA vendor implements, and each
/// vendor pack then declares its own richer spec for the same name. On a
/// Cadence profile both are admitted and `eda_cadence` wins on pack-name
/// order — which is the intended layering, not an accident. Reporting it would
/// put six warnings on the shipped packs that no user can act on.
///
/// So a collision between two **bundled** packs is left alone. Every other
/// combination is reported, including a workspace pack shadowing a bundled
/// one, which is exactly the case a user can do something about.
fn cross_pack_command_notices(packs: &[MergedPack]) -> Vec<PackNotice> {
    /// The claim currently holding a name.
    struct Claim {
        pack: String,
        file: PathBuf,
        line: u32,
        package: Option<&'static str>,
        tier: Tier,
    }

    let mut out = Vec::new();
    // Every claim that still stands for a name, not just the most recent one.
    //
    // One entry per name is not enough, because claims can be *mutually
    // exclusive*: several stand at once, one per vendor that could be live.
    // Three packs claiming `report_timing` — the first for Synopsys, the next
    // two for Cadence — leave the Synopsys claim standing while the two
    // Cadence claims genuinely collide with each other. A single-entry map
    // compares the third claim only against the first, finds them
    // vendor-disjoint, and reports nothing; the real collision goes unreported.
    // So each claim is checked against every standing
    // claim and settles against the first it *could* collide with — which is
    // the one `install_into` would have let win, since both walk packs in the
    // same order.
    let mut claimed: BTreeMap<&'static str, Vec<Claim>> = BTreeMap::new();

    for pack in packs {
        for command in &pack.commands {
            let claim = Claim {
                pack: pack.name.clone(),
                file: command.file.clone(),
                line: command.line,
                package: command.spec.required_package,
                tier: pack.tier,
            };
            let standing = claimed.entry(command.spec.name).or_default();
            let Some(idx) = standing
                .iter()
                .position(|prior| could_collide(prior.package, command.spec.required_package))
            else {
                // Nothing standing is ever live in the same registry as this
                // one, so it shadows nothing and nothing shadows it: it joins
                // the standing set rather than replacing it.
                standing.push(claim);
                continue;
            };
            // Copied out before the standing set is mutated below.
            let prior_pack = standing[idx].pack.clone();
            let prior_file = standing[idx].file.clone();
            let prior_line = standing[idx].line;
            let prior_tier = standing[idx].tier;
            if prior_tier == Tier::Bundled && pack.tier == Tier::Bundled {
                // Shipped layering — see the note above.
                continue;
            }
            if command.overrides_shipped {
                // This one replaces the standing claim; the notice belongs on
                // the declaration that just lost its place.
                out.push(PackNotice {
                    subject: None,
                    path: prior_file.clone(),
                    line: prior_line,
                    context: format!("command {}", command.spec.name),
                    message: format!(
                        "`{}` is also declared by pack `{}` ({}:{}) with `-override`, \
                         which replaces this one",
                        command.spec.name,
                        pack.name,
                        command.file.display(),
                        command.line
                    ),
                    severity: Severity::Warning,
                });
                // Replaces the claim it displaced, in place — the other
                // standing claims for this name are for other vendors and are
                // untouched by an override aimed at this one.
                standing[idx] = claim;
            } else {
                out.push(PackNotice {
                    subject: None,
                    path: command.file.clone(),
                    line: command.line,
                    context: format!("command {}", command.spec.name),
                    message: format!(
                        "`{}` is already declared by pack `{prior_pack}` ({}:{prior_line}); \
                         that declaration wins and this one is not installed \
                         (declare it `-override` to replace it)",
                        command.spec.name,
                        prior_file.display()
                    ),
                    severity: Severity::Warning,
                });
            }
        }
    }
    out
}

/// Whether two commands' `required_package`s can ever be live in one registry.
///
/// The exact question [`crate::install::install_into`]'s vendor gate answers,
/// asked across every profile rather than for one: two declarations collide
/// only if some profile would admit both. Two different closed-world EDA
/// vendors never do, which is why the six shipped loadables can all declare a
/// `report_timing` without shadowing each other.
///
/// Identical requirements short-circuit to `true` — the common case, and one
/// no profile sweep could disagree with.
fn could_collide(a: Option<&'static str>, b: Option<&'static str>) -> bool {
    if a == b {
        return true;
    }
    tcl_dialect::DialectProfile::all().iter().any(|profile| {
        let context = tcl_registry::model::ingress::static_document_context_for_profile(profile);
        context.required_package_available(a) && context.required_package_available(b)
    })
}

/// Report every `file_extension` two different packs both claim.
///
/// One owner per extension is the invariant, and [`PackSet::extension_dialects`]
/// enforces it by dropping all but the first, silently — so this notice is
/// what makes the drop visible. The loser matters more here than for a
/// command: an extension routed to the
/// wrong dialect mis-lexes every file of that type.
///
/// Only rows carrying a `-dialect` can collide in the sense that matters, since
/// those are the ones `extension_dialects` publishes for routing.
fn cross_pack_extension_notices(packs: &[MergedPack]) -> Vec<PackNotice> {
    let mut out = Vec::new();
    // extension -> (pack name, dialect) of the row that owns the routing.
    let mut owner: BTreeMap<String, (String, &'static str)> = BTreeMap::new();

    for pack in packs {
        for row in &pack.file_extensions {
            let Some(dialect) = row.dialect else {
                continue;
            };
            match owner.get(&row.extension) {
                Some((prior_pack, prior_dialect)) => out.push(PackNotice {
                    subject: None,
                    // The row's *own* file, not the merged pack's first one:
                    // a logical pack can span several files, and `row.line` is
                    // a line in this one.
                    path: row.file.clone(),
                    line: row.line,
                    context: format!("file_extension {}", row.extension),
                    message: format!(
                        "`.{}` is already claimed by pack `{prior_pack}` (routing to \
                         `{prior_dialect}`); one extension has one owner, so this row's \
                         `-dialect {dialect}` is not used",
                        row.extension
                    ),
                    severity: Severity::Warning,
                }),
                None => {
                    owner.insert(row.extension.clone(), (pack.name.clone(), dialect));
                }
            }
        }
    }
    out
}

/// Append each of `rows` whose name no row in `into` already has: across a
/// pack's files the first declaration wins, as it does within one file.
fn merge_first_wins<T>(into: &mut Vec<T>, rows: Vec<T>, name: impl for<'a> Fn(&'a T) -> &'a str) {
    for row in rows {
        if !into.iter().any(|prior| name(prior) == name(&row)) {
            into.push(row);
        }
    }
}

/// Merge one tier's files for one pack name, first-definition-wins.
fn merge_group(
    name: &str,
    tier: Tier,
    trust: WorkspaceTrust,
    files: Vec<(PackFile, Pack)>,
    notices: &mut Vec<PackNotice>,
) -> MergedPack {
    let mut merged = MergedPack {
        name: name.to_owned(),
        dsl_version: String::new(),
        tier,
        trust,
        files: files.iter().map(|(f, _)| f.path.clone()).collect(),
        display_name: None,
        file_extensions: Vec::new(),
        ambient_packages: Vec::new(),
        special_vars: Vec::new(),
        environments: Vec::new(),
        dialects: Vec::new(),
        surface_rosters: Vec::new(),
        commands: Vec::new(),
    };
    // Where each command name was first defined, so the duplicate notice can
    // name the file that won rather than just saying "somewhere else".
    let mut first_seen: BTreeMap<&'static str, (PathBuf, u32)> = BTreeMap::new();
    let first_file = merged.files.first().cloned().unwrap_or_default();

    for (file, pack) in files {
        if merged.dsl_version.is_empty() {
            merged.dsl_version.clone_from(&pack.dsl_version);
        } else if !pack.dsl_version.is_empty() && pack.dsl_version != merged.dsl_version {
            notices.push(PackNotice::whole_file(
                &file.path,
                format!(
                    "pack `{name}` declares DSL version {} here and {} in {}; \
                     the first in merge order is used",
                    pack.dsl_version,
                    merged.dsl_version,
                    first_file.display()
                ),
                Severity::Warning,
            ));
        }
        for notice in &pack.notices {
            notices.push(PackNotice::from_loader(&file.path, notice));
        }
        if merged.display_name.is_none() {
            merged.display_name.clone_from(&pack.display_name);
        }
        for mut row in pack.file_extensions {
            // Same reason as the command loop below: the merge is the only
            // layer that knows which file of a multi-file pack a row came
            // from.
            row.file.clone_from(&file.path);
            if !merged
                .file_extensions
                .iter()
                .any(|prior| prior.extension == row.extension)
            {
                merged.file_extensions.push(row);
            }
        }
        merged.ambient_packages.extend(pack.ambient_packages);
        merge_first_wins(&mut merged.special_vars, pack.special_vars, |row| {
            row.spec.name
        });
        for environment in pack.environments {
            // Declarations dedupe by id (first wins, as within one file);
            // `-extend` blocks are additive contributions and every one is
            // kept — two files may each extend the same base.
            let duplicate = !environment.extends
                && merged
                    .environments
                    .iter()
                    .any(|prior| !prior.extends && prior.id == environment.id);
            if !duplicate {
                merged.environments.push(environment);
            }
        }
        merge_first_wins(&mut merged.dialects, pack.dialects, |dialect| {
            dialect.name.as_str()
        });
        merged.surface_rosters.extend(pack.surface_rosters);
        for mut command in pack.commands {
            // The merge is the only layer that knows which file a command came
            // from, so this is where that gets recorded.
            command.file.clone_from(&file.path);
            command.dependency_tier = file.dependency_tier;
            if let Some((first_path, first_line)) = first_seen.get(command.spec.name) {
                notices.push(PackNotice {
                    subject: None,
                    path: file.path.clone(),
                    // The *ignored* declaration's own line, not line 1. The
                    // squiggle belongs on the duplicate the author can delete,
                    // not on the `speclib` header.
                    line: command.line,
                    context: format!("command {}", command.spec.name),
                    message: if *first_path == file.path {
                        // Same file: naming the path the reader already has
                        // open tells them nothing — the line does.
                        format!(
                            "`{}` is already defined on line {first_line} of this file; \
                             this definition is ignored",
                            command.spec.name
                        )
                    } else {
                        format!(
                            "`{}` is already defined in pack `{name}` by {}:{first_line}; \
                             this definition is ignored",
                            command.spec.name,
                            first_path.display()
                        )
                    },
                    severity: Severity::Warning,
                });
                continue;
            }
            first_seen.insert(command.spec.name, (file.path.clone(), command.line));
            merged.commands.push(command);
        }
    }
    merged
}

/// The content key for a whole pack set.
///
/// Covers, in order, every file's tier, trust state, dependency tier, path and
/// byte content, plus the vocabulary version and loader build — so moving a
/// pack between tiers, its package moving in the lockfile's graph, the editor
/// granting or withdrawing trust in the workspace, or upgrading the server, is
/// as much a change as editing it.
fn set_key(sources: &[(PackFile, String)], trust: WorkspaceTrust) -> u64 {
    if sources.is_empty() {
        return 0;
    }
    let mut hasher = xxhash_rust::xxh3::Xxh3::new();
    crate::cache::stamp_build(&mut hasher);
    for (file, source) in sources {
        hasher.update(&[file.tier as u8]);
        hasher.update(&[file.tier.trust_under(trust) as u8]);
        // A package moving in the lockfile's graph changes what its packs may
        // declare, so it changes the set as much as an edit does.
        hasher.update(&[file.dependency_tier.map_or(0, |tier| tier as u8 + 1)]);
        // A source path is an OS value, not its lossy display. Frame both
        // variable-width fields so embedded source/path bytes cannot donate
        // another field boundary. This key is local to this build/platform.
        let path = file.path.as_os_str().as_encoded_bytes();
        hasher.update(
            &u64::try_from(path.len())
                .expect("path length fits u64")
                .to_le_bytes(),
        );
        hasher.update(path);
        hasher.update(
            &u64::try_from(source.len())
                .expect("source length fits u64")
                .to_le_bytes(),
        );
        hasher.update(source.as_bytes());
    }
    // A pack set never keys as 0 — that value means "no packs" to the
    // registry-cache layer, and a real set must not be able to collide with it.
    match hasher.digest() {
        0 => 1,
        digest => digest,
    }
}

/// Every command in this set that collides with a name `registry` already
/// declares, and what the collision policy did about it.
///
/// **Shipped wins unless the pack says `-override`** — so a collision without
/// `-override` reports and drops, and one with it reports and replaces. Both
/// are reported: a silent override is exactly as surprising as a silent drop.
#[must_use]
pub fn collision_notices(packs: &PackSet, registry: &CommandRegistry) -> Vec<PackNotice> {
    let mut out = Vec::new();
    for pack in &packs.packs {
        for command in &pack.commands {
            if registry.get(command.spec.name).is_none() {
                continue;
            }
            let file = pack.files.first().cloned().unwrap_or_default();
            out.push(PackNotice {
                subject: None,
                path: file,
                line: 1,
                context: format!("command {}", command.spec.name),
                message: if command.overrides_shipped {
                    format!(
                        "`{}` replaces the shipped command of that name (`-override`)",
                        command.spec.name
                    )
                } else {
                    format!(
                        "`{}` is already a shipped command; the shipped spec wins \
                         (declare it `-override` to replace it)",
                        command.spec.name
                    )
                },
                severity: Severity::Information,
            });
        }
    }
    out
}

/// `true` when this command should be installed over `registry`'s existing
/// entry — the one place the collision policy is decided, shared by
/// [`collision_notices`] and [`crate::install`] so the report and the
/// behaviour cannot drift.
pub(crate) fn installs_over(command: &PackCommand, registry: &CommandRegistry) -> bool {
    command.overrides_shipped || registry.get(command.spec.name).is_none()
}

/// The tier/origin pair as it reads in a log line: `workspace (.tcl-lsp/)`.
#[must_use]
pub fn describe_source(tier: Tier, origin: Origin) -> String {
    format!("{} ({})", tier.label(), origin.label())
}

#[cfg(test)]
mod tests {
    use super::*;

    fn tmpdir(name: &str) -> PathBuf {
        let dir = std::env::temp_dir().join(format!(
            "tcl-spectcl-pack-{name}-{}-{:?}",
            std::process::id(),
            std::thread::current().id()
        ));
        let _ = std::fs::remove_dir_all(&dir);
        std::fs::create_dir_all(&dir).expect("temp dir");
        dir
    }

    fn write(dir: &Path, name: &str, body: &str) -> PathBuf {
        let path = dir.join(name);
        if let Some(parent) = path.parent() {
            std::fs::create_dir_all(parent).expect("parent");
        }
        std::fs::write(&path, body).expect("write");
        path
    }

    /// Loading a pack writes a compiled-cache entry, and `cache`'s own tests
    /// count the entries under a redirected directory — so every test in this
    /// crate that loads a pack holds the same lock they do.
    fn cache_guard() -> std::sync::MutexGuard<'static, ()> {
        crate::cache::REDIRECT_LOCK
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
    }

    fn workspace_file(path: PathBuf) -> PackFile {
        PackFile {
            tier: Tier::Workspace,
            path,
            origin: Origin::DotDir,
            dependency_tier: None,
        }
    }

    #[test]
    fn merged_sets_retain_load_failures_even_before_a_pack_names_itself() {
        let _cache = cache_guard();
        let dir = tmpdir("load-errors");
        let unsupported = write(&dir, "unsupported.tclspec", "speclib demo 99.0 {}");
        let broken = write(&dir, "broken.tclspec", "error before_header");
        let empty = write(&dir, "empty.tclspec", "speclib empty 2.0 {}");
        let set = load(&[
            workspace_file(unsupported.clone()),
            workspace_file(broken.clone()),
            workspace_file(empty.clone()),
        ]);
        assert_eq!(set.load_errors.len(), 2, "{set:#?}");
        assert_eq!(
            set.load_errors[0],
            (
                unsupported,
                crate::LoadError::UnsupportedMajor("99.0".to_owned())
            )
        );
        assert_eq!(set.load_errors[1].0, broken);
        assert!(matches!(
            set.load_errors[1].1,
            crate::LoadError::EvaluationFailed(_)
        ));
        assert!(set.packs.iter().any(|pack| pack.files.contains(&empty)));
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn files_naming_one_speclib_merge_into_one_pack() {
        let _cache = cache_guard();
        let dir = tmpdir("merge");
        let a = write(
            &dir,
            "a.tclspec",
            "speclib mylib 1 {\n  command mylib::alpha { arity 1 }\n}\n",
        );
        let b = write(
            &dir,
            "b.tclspec",
            "speclib mylib 1 {\n  command mylib::beta { arity 2 }\n}\n",
        );

        let set = load(&[workspace_file(b), workspace_file(a)]);
        assert_eq!(set.packs.len(), 1, "{:#?}", set.packs);
        let pack = &set.packs[0];
        assert_eq!(pack.name, "mylib");
        assert_eq!(pack.files.len(), 2);
        // Merge order is sorted path order regardless of the order in.
        assert!(pack.files[0].ends_with("a.tclspec"));
        let names: Vec<&str> = pack.commands.iter().map(|c| c.spec.name).collect();
        assert_eq!(names, vec!["mylib::alpha", "mylib::beta"]);
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn a_command_defined_twice_in_one_pack_is_a_notice_and_the_first_wins() {
        let _cache = cache_guard();
        let dir = tmpdir("dupe");
        let a = write(
            &dir,
            "a.tclspec",
            "speclib mylib 1 {\n  command mylib::dup { arity 1 }\n}\n",
        );
        let b = write(
            &dir,
            "b.tclspec",
            "speclib mylib 1 {\n  command mylib::dup { arity 9 }\n}\n",
        );

        let set = load(&[workspace_file(a), workspace_file(b.clone())]);
        let pack = &set.packs[0];
        assert_eq!(pack.commands.len(), 1, "first definition wins");
        assert_eq!(pack.commands[0].spec.arity.min, 1);
        let dupe: Vec<&PackNotice> = set
            .notices
            .iter()
            .filter(|n| n.message.contains("already defined"))
            .collect();
        assert_eq!(dupe.len(), 1, "{:#?}", set.notices);
        assert_eq!(dupe[0].path, b, "the notice lands on the losing file");
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn distinct_speclib_names_stay_distinct_packs() {
        let _cache = cache_guard();
        let dir = tmpdir("distinct");
        let a = write(
            &dir,
            "a.tclspec",
            "speclib alpha 1 {\n  command a::one { arity 1 }\n}\n",
        );
        let b = write(
            &dir,
            "b.tclspec",
            "speclib beta 1 {\n  command b::one { arity 1 }\n}\n",
        );
        let set = load(&[workspace_file(a), workspace_file(b)]);
        let names: Vec<&str> = set.packs.iter().map(|p| p.name.as_str()).collect();
        assert_eq!(names, vec!["alpha", "beta"]);
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn a_nearer_tier_shadows_the_whole_pack_and_says_so() {
        let _cache = cache_guard();
        let dir = tmpdir("tiers");
        let ws = write(
            &dir,
            "ws/mylib.tclspec",
            "speclib mylib 1 {\n  command mylib::ws { arity 1 }\n}\n",
        );
        let studio = write(
            &dir,
            "studio/mylib.tclspec",
            "speclib mylib 1 {\n  command mylib::live { arity 2 }\n}\n",
        );
        let user = write(
            &dir,
            "user/mylib.tclspec",
            "speclib mylib 1 {\n  command mylib::user { arity 1 }\n}\n",
        );
        let set = load(&[
            PackFile {
                tier: Tier::StudioOverride,
                path: studio,
                origin: Origin::StudioOverride,
                dependency_tier: None,
            },
            workspace_file(ws.clone()),
            PackFile {
                tier: Tier::User,
                path: user.clone(),
                origin: Origin::UserDir,
                dependency_tier: None,
            },
        ]);
        assert_eq!(set.packs.len(), 1);
        let names: Vec<&str> = set.packs[0].commands.iter().map(|c| c.spec.name).collect();
        assert_eq!(names, vec!["mylib::live"]);
        assert!(
            set.notices
                .iter()
                .any(|n| n.path == user && n.message.contains("is not loaded"))
                && set
                    .notices
                    .iter()
                    .any(|n| n.path == ws && n.message.contains("Spec Studio override")),
            "{:#?}",
            set.notices
        );
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn loader_notices_carry_their_file_and_line() {
        let _cache = cache_guard();
        let dir = tmpdir("notices");
        let a = write(
            &dir,
            "a.tclspec",
            "speclib mylib 1 {\n  command mylib::x {\n    nonsense 1\n  }\n}\n",
        );
        let set = load(&[workspace_file(a.clone())]);
        let notice = set
            .notices
            .iter()
            .find(|n| n.message.contains("nonsense"))
            .unwrap_or_else(|| panic!("{:#?}", set.notices));
        assert_eq!(notice.path, a);
        assert_eq!(notice.line, 3);
        assert_eq!(notice.severity, Severity::Warning);
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn an_unreadable_file_is_a_notice_not_a_panic() {
        let _cache = cache_guard();
        let dir = tmpdir("unreadable");
        let missing = dir.join("gone.tclspec");
        let set = load(&[workspace_file(missing.clone())]);
        assert!(set.packs.is_empty());
        assert_eq!(set.notices.len(), 1);
        assert_eq!(set.notices[0].path, missing);
        assert!(set.notices[0].message.contains("cannot read"));
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn the_set_key_tracks_content_and_never_collides_with_empty() {
        let _cache = cache_guard();
        let dir = tmpdir("key");
        let a = write(
            &dir,
            "a.tclspec",
            "speclib mylib 1 {\n  command mylib::x { arity 1 }\n}\n",
        );
        let before = load(&[workspace_file(a.clone())]).key;
        assert_ne!(
            before, 0,
            "a non-empty set never keys as the empty identity"
        );
        assert_eq!(
            before,
            load(&[workspace_file(a.clone())]).key,
            "the key is stable for unchanged content"
        );
        write(
            &dir,
            "a.tclspec",
            "speclib mylib 1 {\n  command mylib::x { arity 2 }\n}\n",
        );
        assert_ne!(before, load(&[workspace_file(a)]).key, "an edit rekeys");
        assert_eq!(load(&[]).key, 0);
        let _ = std::fs::remove_dir_all(&dir);
    }
}

#[cfg(test)]
mod loaded_source_input_tests {
    use super::*;
    use tcl_lsp_core::vfs::{MemoryStore, SourceStore, SourceUriPathUnavailable};

    #[test]
    fn actual_loader_images_reject_changed_and_foreign_provider_sources() {
        let store = MemoryStore::new();
        let path = std::path::PathBuf::from("/packs/requested.tclspec");
        let source = "speclib requested 1 {}\n";
        store.upsert(path.clone(), source.as_bytes().to_vec());
        let file = PackFile {
            path: path.clone(),
            tier: Tier::Workspace,
            origin: crate::discovery::Origin::Setting,
            dependency_tier: None,
        };
        let read = read_sources_with_inputs(&store, &[file]);
        assert_eq!(read.sources[0].1, source);
        let selected = read.inputs.selected(std::slice::from_ref(&path)).unwrap();
        let mut published = false;
        store
            .with_current_saved_source_inputs(&[], &selected, &mut || published = true)
            .unwrap();
        assert!(published);
        published = false;
        store.upsert(path.clone(), b"speclib changed 1 {}\n".to_vec());
        assert_eq!(
            store.with_current_saved_source_inputs(&[], &selected, &mut || published = true),
            Err(SourceUriPathUnavailable::SourceImageUnavailable)
        );
        assert!(!published);
        let foreign = MemoryStore::new();
        foreign.upsert(path.clone(), source.as_bytes().to_vec());
        assert_eq!(
            foreign.with_current_saved_source_inputs(&[], &selected, &mut || published = true),
            Err(SourceUriPathUnavailable::ForeignProvider)
        );
        assert!(!published);
        assert!(
            read.inputs
                .selected(&[std::path::PathBuf::from("/packs/unrelated.tclspec")])
                .is_none()
        );
    }
}

#[cfg(test)]
mod complete_retained_loader_input_tests {
    use super::*;
    use tcl_lsp_core::vfs::{MemoryStore, SourceStore, SourceUriPathUnavailable};

    fn selected_file(path: &str) -> PackFile {
        PackFile {
            path: std::path::PathBuf::from(path),
            tier: Tier::Workspace,
            origin: crate::discovery::Origin::Setting,
            dependency_tier: None,
        }
    }

    #[test]
    fn another_selected_merge_input_must_remain_current() {
        let store = MemoryStore::new();
        let requested = selected_file("/packs/requested.tclspec");
        let shadow = selected_file("/packs/workspace.tclspec");
        store.upsert(requested.path.clone(), b"speclib shared 1 {}\n".to_vec());
        store.upsert(shadow.path.clone(), b"speclib shared 1 {}\n".to_vec());
        let read = read_sources_with_inputs(&store, &[requested.clone(), shadow.clone()]);
        let paths = read.inputs.retained_paths();
        assert_eq!(paths, vec![requested.path.clone(), shadow.path.clone()]);
        let selected = read.inputs.selected(&paths).unwrap();
        let mut published = false;
        store
            .with_current_saved_source_inputs(&[], &selected, &mut || published = true)
            .unwrap();
        assert!(published);
        store.upsert(shadow.path, b"speclib shared 2 {}\n".to_vec());
        published = false;
        assert_eq!(
            store.with_current_saved_source_inputs(&[], &selected, &mut || published = true),
            Err(SourceUriPathUnavailable::SourceImageUnavailable)
        );
        assert!(!published);
        assert!(read.inputs.selected(&[requested.path]).is_some());
    }

    #[test]
    fn selected_unreadable_input_withholds_a_complete_merge_receipt() {
        let store = MemoryStore::new();
        let missing = selected_file("/packs/missing.tclspec");
        let read = read_sources_with_inputs(&store, &[missing]);
        assert_eq!(read.notices.len(), 1);
        assert!(read.sources.is_empty());
        assert!(
            read.inputs
                .selected(&read.inputs.retained_paths())
                .is_none()
        );
    }
}

#[cfg(all(test, unix))]
mod opaque_path_cache_key_tests {
    use super::*;
    use std::os::unix::ffi::OsStringExt;

    #[test]
    fn equal_lossy_path_labels_do_not_share_actual_pack_input_keys() {
        let file = |byte| PackFile {
            tier: Tier::Bundled,
            path: PathBuf::from(std::ffi::OsString::from_vec(vec![b'/', byte, b'.', b't'])),
            origin: crate::discovery::Origin::Bundled,
            dependency_tier: None,
        };
        let left = file(0x80);
        let right = file(0x81);
        assert_eq!(left.path.to_string_lossy(), right.path.to_string_lossy());
        let source = "speclib same 1 {}".to_owned();
        assert_ne!(
            set_key(&[(left.clone(), source.clone())], WorkspaceTrust::Trusted),
            set_key(&[(right, source.clone())], WorkspaceTrust::Trusted)
        );
        assert_eq!(
            set_key(&[(left.clone(), source.clone())], WorkspaceTrust::Trusted),
            set_key(&[(left, source)], WorkspaceTrust::Trusted)
        );
    }
}

#[cfg(test)]
mod actual_include_input_controls {
    use super::*;
    use std::sync::Arc;
    use tcl_lsp_core::vfs::{MemoryStore, SourceStore};

    #[test]
    fn included_provider_image_changes_set_key_and_is_retained_for_publication() {
        let store = Arc::new(MemoryStore::new());
        let file = PackFile {
            path: "/actual/root.tclspec".into(),
            tier: Tier::Workspace,
            origin: crate::discovery::Origin::Setting,
            dependency_tier: None,
        };
        store.upsert(
            file.path.clone(),
            b"speclib demo 2.0 {include child}".to_vec(),
        );
        store.upsert("/actual/child", b"command first {arity 1}".to_vec());
        let load = || {
            let mut read = read_sources_with_inputs(store.as_ref(), std::slice::from_ref(&file));
            let reader: Arc<dyn SourceStore> = store.clone();
            let set = load_sources_unpublished_with_inputs(
                read.sources,
                read.notices,
                WorkspaceTrust::Trusted,
                Some(store.as_ref()),
                &mut read.inputs,
                Some(reader),
            );
            (set, read.inputs)
        };
        let (first, first_inputs) = load();
        assert!(
            first
                .packs
                .iter()
                .any(|pack| pack.command("first").is_some())
        );
        let paths = first_inputs.retained_paths();
        let selected = first_inputs.selected(&paths).unwrap();
        assert!(selected.iter().any(|(origin, image)| origin.path()
            == std::path::Path::new("/actual/child")
            && *image == b"command first {arity 1}"));
        store.upsert("/actual/child", b"command second {arity 2}".to_vec());
        let (second, second_inputs) = load();
        assert_ne!(first.key, second.key);
        assert!(
            second
                .packs
                .iter()
                .any(|pack| pack.command("second").is_some())
        );
        let second_paths = second_inputs.retained_paths();
        let selected = second_inputs.selected(&second_paths).unwrap();
        assert!(
            selected
                .iter()
                .any(|(_, image)| *image == b"command second {arity 2}")
        );
        assert!(
            !selected
                .iter()
                .any(|(_, image)| *image == b"command first {arity 1}")
        );
    }

    #[test]
    fn borrowed_foreign_provider_cannot_resolve_an_include_through_host_filesystem() {
        let store = MemoryStore::new();
        let file = PackFile {
            path: "/foreign/root.tclspec".into(),
            tier: Tier::Workspace,
            origin: crate::discovery::Origin::Setting,
            dependency_tier: None,
        };
        store.upsert(
            file.path.clone(),
            b"speclib demo 2.0 {include child}".to_vec(),
        );
        store.upsert("/foreign/child", b"command foreign {arity 1}".to_vec());
        let mut read = read_sources_with_inputs(&store, std::slice::from_ref(&file));
        let loaded = load_sources_unpublished_with_inputs(
            read.sources,
            read.notices,
            WorkspaceTrust::Trusted,
            Some(&store),
            &mut read.inputs,
            None,
        );
        assert!(
            !loaded
                .packs
                .iter()
                .any(|pack| pack.command("foreign").is_some())
        );
        assert!(
            loaded
                .notices
                .iter()
                .any(|notice| notice.message.contains("owned source-provider reader"))
        );
        assert!(
            read.inputs
                .selected(&read.inputs.retained_paths())
                .is_none()
        );
    }
}

#[cfg(test)]
mod lazy_actual_include_ingress_controls {
    use super::*;
    use std::sync::Arc;
    use tcl_lsp_core::vfs::{MemoryStore, SourceStore};

    #[test]
    fn helper_and_computed_include_invocations_retain_actual_dependency_images() {
        let store = Arc::new(MemoryStore::new());
        let file = PackFile {
            path: "/actual/root.tclspec".into(),
            tier: Tier::Workspace,
            origin: crate::discovery::Origin::Setting,
            dependency_tier: None,
        };
        store.upsert("/actual/child", b"command actual {arity 1}".to_vec());
        for source in [
            "speclib demo 2.0 {proc add {} {include child}; add}",
            "speclib demo 2.0 {set word include; set file child; $word $file}",
        ] {
            assert!(!crate::loader::uses_include(source));
            store.upsert(file.path.clone(), source.as_bytes().to_vec());
            let mut read = read_sources_with_inputs(store.as_ref(), std::slice::from_ref(&file));
            let reader: Arc<dyn SourceStore> = store.clone();
            let loaded = load_sources_unpublished_with_inputs(
                read.sources,
                read.notices,
                WorkspaceTrust::Trusted,
                Some(store.as_ref()),
                &mut read.inputs,
                Some(reader),
            );
            assert!(
                loaded
                    .packs
                    .iter()
                    .any(|pack| pack.command("actual").is_some()),
                "{source}: {:?}",
                loaded.notices
            );
            let paths = read.inputs.retained_paths();
            let selected = read.inputs.selected(&paths).unwrap();
            assert!(selected.iter().any(|(origin, image)| origin.path()
                == std::path::Path::new("/actual/child")
                && *image == b"command actual {arity 1}"));
        }
    }

    #[test]
    fn unavailable_borrowed_resolver_does_not_poison_a_clean_unrelated_pack() {
        let store = MemoryStore::new();
        let file = PackFile {
            path: "/foreign/clean.tclspec".into(),
            tier: Tier::Workspace,
            origin: crate::discovery::Origin::Setting,
            dependency_tier: None,
        };
        store.upsert(
            file.path.clone(),
            b"speclib clean 2.0 {command unrelated {arity 1}}".to_vec(),
        );
        let mut read = read_sources_with_inputs(&store, std::slice::from_ref(&file));
        let loaded = load_sources_unpublished_with_inputs(
            read.sources,
            read.notices,
            WorkspaceTrust::Trusted,
            Some(&store),
            &mut read.inputs,
            None,
        );
        assert!(
            loaded
                .packs
                .iter()
                .any(|pack| pack.command("unrelated").is_some())
        );
        assert!(
            !loaded
                .notices
                .iter()
                .any(|notice| notice.message.contains("owned source-provider reader"))
        );
        assert!(
            read.inputs
                .selected(&read.inputs.retained_paths())
                .is_some()
        );
    }
}
