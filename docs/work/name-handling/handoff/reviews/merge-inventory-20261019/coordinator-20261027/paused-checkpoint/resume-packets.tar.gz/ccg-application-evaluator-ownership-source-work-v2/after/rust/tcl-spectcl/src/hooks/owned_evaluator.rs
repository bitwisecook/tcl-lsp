// tcl-lsp — a language server and toolchain for Tcl
// Copyright (C) 2026 James Deucker (bitwisecook)
// SPDX-License-Identifier: AGPL-3.0-or-later

//! Concrete worker-local evaluator ownership; this issues no execution scope.
//!
//! Only the application backend under construction will use this owner. It
//! must separately prove its VM/compiler/getter/literal and emitted-code
//! closure. Holding this evaluator never makes a source CU or Native handler
//! complete, and these counters never stand in for optimiser call attempts.

use std::cell::{Cell, RefCell};
use std::rc::Rc;
use std::sync::Arc;

use tcl_engine_tclvm::{PrivateApplicationHookHost, TclVmEngine, private_application_hook_engine};
use tcl_registry::pack_hooks::{self, HookAnswer, HookCall, HookFamily, HookSlot, PackHookHost};
use tcl_registry::{CommandRegistry, InvocationDialect, InvocationFacts, RegistrySemanticKey};
use tcl_runtime_api::closed_native_consumer::ClosedSourceRefusal;
use tcl_spec_hooks::{HookHost, HookOwner, HostConfig};

use super::HookPlan;

#[derive(Clone, Copy, Default)]
struct InvocationCounts {
    total: u64,
    fold: u64,
    fold_answers: u64,
    abstentions: u64,
}

struct CountedEvaluator {
    actual: Rc<dyn PackHookHost>,
    counts: Cell<InvocationCounts>,
}

impl PackHookHost for CountedEvaluator {
    fn invoke(&self, slot: HookSlot, call: &HookCall<'_>) -> HookAnswer {
        let mut counts = self.counts.get();
        counts.total = counts.total.saturating_add(1);
        if matches!(
            slot.family(),
            HookFamily::ConstFold | HookFamily::ConstFoldVersioned
        ) {
            counts.fold = counts.fold.saturating_add(1);
        }
        self.counts.set(counts);
        // No RefCell or mutable counter borrow spans the actual evaluator.
        let answer = self.actual.invoke(slot, call);
        let mut counts = self.counts.get();
        if matches!(&answer, HookAnswer::Fold(_)) {
            counts.fold_answers = counts.fold_answers.saturating_add(1);
        }
        if matches!(&answer, HookAnswer::Abstain) {
            counts.abstentions = counts.abstentions.saturating_add(1);
        }
        self.counts.set(counts);
        answer
    }

    fn is_available(&self, slot: HookSlot) -> bool {
        self.actual.is_available(slot)
    }
}

/// This must be created inside the new private worker, never on an analysis
/// caller's thread. No caller-supplied Engine, Host, callback or evaluator is
/// accepted. The retained plan owns the exact immutable programs installed.
struct OwnedApplicationEvaluator {
    plan: Arc<HookPlan>,
    registry: RegistrySemanticKey,
    config: HostConfig,
    host: Rc<HookHost<TclVmEngine>>,
    evaluator: Rc<CountedEvaluator>,
    receiver: Rc<dyn PackHookHost>,
    active_call: Cell<bool>,
    live: Cell<bool>,
    private_hosts: Rc<RefCell<Vec<PrivateApplicationHookHost>>>,
    generation: tcl_registry::value_transfer::EvaluatorGeneration,
}

impl OwnedApplicationEvaluator {
    fn new(
        plan: Arc<HookPlan>,
        registry: &CommandRegistry,
        config: HostConfig,
    ) -> Result<Self, ClosedSourceRefusal> {
        // Refuse existing state; do not clear it to manufacture a private world.
        if pack_hooks::has_host() || plan.is_empty() {
            return Err(ClosedSourceRefusal::NativeContext);
        }
        // The finite initial engine roster is populated only AFTER the empty
        // owned TLS receiver is installed. No factory accepts caller engines.
        let initial: Rc<RefCell<Vec<TclVmEngine>>> = Rc::default();
        let private_hosts: Rc<RefCell<Vec<PrivateApplicationHookHost>>> = Rc::default();
        let factory_initial = Rc::clone(&initial);
        let pinned_hosts = Rc::clone(&private_hosts);
        let actual = Rc::new(
            HookHost::with_config(
                move || {
                    factory_initial
                        .borrow_mut()
                        .pop()
                        .expect("the private finite initial engine roster is exact")
                },
                config.clone(),
            )
            .with_pinned_engine_factory(move |profile| {
                let version = tcl_registry::model::ingress::resolve_known_environment(profile)
                    .and_then(|environment| environment.catalogue_profile())
                    .and_then(|profile| InvocationDialect::of_profile(profile).tcl_version)
                    .filter(|version| *version == tcl_dialect::TclVersion::V9_1)
                    .ok_or(tcl_engine_api::EngineError::Unsupported(
                        "private application pinned profile",
                    ))?;
                let (engine, retained) =
                    private_application_hook_engine(version, true).map_err(|_| {
                        tcl_engine_api::EngineError::Unsupported(
                            "private application pinned bootstrap",
                        )
                    })?;
                pinned_hosts.borrow_mut().push(retained);
                Ok(engine)
            }),
        );
        let evaluator = Rc::new(CountedEvaluator {
            actual: actual.clone(),
            counts: Cell::new(InvocationCounts::default()),
        });
        // Install the actual EMPTY owned host before constructing any engine.
        // HookHost construction has only allocated its Rust bookkeeping. This
        // direct host prevents the lazy global installer from being consulted
        // by compiler generation reads while hook programs are compiled.
        let receiver: Rc<dyn PackHookHost> = evaluator.clone();
        pack_hooks::install_host(Rc::clone(&receiver));
        if !pack_hooks::current_host_is(&receiver) {
            return Err(ClosedSourceRefusal::NativeContext);
        }
        let generation = pack_hooks::evaluator_generation();
        if generation == tcl_registry::value_transfer::EvaluatorGeneration::NO_HOST {
            return Err(ClosedSourceRefusal::NativeContext);
        }
        let owned = Self {
            plan,
            registry: registry.snapshot().semantic_key(),
            config,
            host: Rc::clone(&actual),
            evaluator,
            receiver,
            active_call: Cell::new(false),
            live: Cell::new(true),
            private_hosts,
            generation,
        };
        // The cleanup owner now exists on every early-return path. Its Drop
        // retires the TLS host before actual engine/host Rc owners are freed.
        for _ in owned.plan.packs() {
            let (engine, retained) =
                private_application_hook_engine(tcl_dialect::TclVersion::V9_0, false)?;
            owned.private_hosts.borrow_mut().push(retained);
            initial.borrow_mut().push(engine);
        }
        for programs in owned.plan.packs() {
            let installed = actual.install_pack_hooks(programs.clone());
            if installed.len() != programs.programs.len()
                || installed
                    .iter()
                    .zip(&programs.programs)
                    .any(|(got, wanted)| {
                        got.slot.is_none()
                            || got.declined.is_some()
                            || got.slot != wanted.slot
                            || got.command != wanted.command
                            || got.owner != wanted.owner
                            || got.family != wanted.family
                    })
                || pack_hooks::evaluator_generation() != owned.generation
            {
                return Err(ClosedSourceRefusal::NativeContext);
            }
        }
        if !initial.borrow().is_empty() {
            return Err(ClosedSourceRefusal::NativeContext);
        }
        owned.check_current(&owned.plan, registry, &owned.config)?;
        Ok(owned)
    }

    /// The real optimiser-time request, not a replay after execution. The
    /// enclosing backend must admit the complete source and Native effects
    /// before reaching this method; this only closes the owned evaluator join.
    fn run_selected_fold(
        &self,
        plan: &Arc<HookPlan>,
        registry: &CommandRegistry,
        config: &HostConfig,
        facts: &InvocationFacts,
        values: &[String],
        dialect: InvocationDialect,
    ) -> Result<Option<String>, ClosedSourceRefusal> {
        self.check_current(plan, registry, config)?;
        if dialect.tcl_version != Some(tcl_dialect::TclVersion::V9_1) {
            return Err(ClosedSourceRefusal::NativeContext);
        }
        if self.active_call.replace(true) {
            return Err(ClosedSourceRefusal::Currency);
        }
        let _call = ActiveCall(&self.active_call);
        let query = dialect
            .authoring_query()
            .ok_or(ClosedSourceRefusal::NativeContext)?;
        // This is exactly the selection used by the value-flow consumer;
        // registry.get(last spec) is deliberately insufficient here.
        let spec = registry
            .get_for_surface(&facts.canonical_command, Some(query))
            .ok_or(ClosedSourceRefusal::Source)?;
        let arguments = values
            .get(facts.argument_offset..)
            .ok_or(ClosedSourceRefusal::Source)?
            .iter()
            .map(String::as_str)
            .collect::<Vec<_>>();
        let member = if spec.subcommands.is_empty() {
            None
        } else {
            Some(
                facts
                    .subcommand
                    .canonical_name()
                    .ok_or(ClosedSourceRefusal::Source)?,
            )
        };
        let (ordinary, versioned) = if let Some(name) = member {
            let selected = spec.subcommand(name).ok_or(ClosedSourceRefusal::Source)?;
            (selected.const_fold, selected.const_fold_versioned)
        } else {
            (spec.const_fold, spec.const_fold_versioned)
        };
        let family = if versioned.is_some() {
            HookFamily::ConstFoldVersioned
        } else {
            HookFamily::ConstFold
        };
        let matches = self
            .plan
            .bindings
            .iter()
            .filter(|binding| {
                let owner_matches = match (&binding.owner, member) {
                    (HookOwner::Command, None) => true,
                    (HookOwner::Subcommand(expected), Some(actual)) => expected == actual,
                    _ => false,
                };
                owner_matches
                    && binding.declaration.0.name == spec.name
                    && binding.family == family
                    && self.evaluator.actual.is_available(binding.slot)
                    && match family {
                        HookFamily::ConstFold => {
                            match (ordinary, pack_hooks::const_fold_fn(binding.slot)) {
                                (Some(actual), Some(expected)) => {
                                    std::ptr::fn_addr_eq(actual, expected)
                                }
                                _ => false,
                            }
                        }
                        HookFamily::ConstFoldVersioned => {
                            match (versioned, pack_hooks::const_fold_versioned_fn(binding.slot)) {
                                (Some(actual), Some(expected)) => {
                                    std::ptr::fn_addr_eq(actual, expected)
                                }
                                _ => false,
                            }
                        }
                        _ => false,
                    }
            })
            .count();
        if matches != 1 {
            return Err(ClosedSourceRefusal::Currency);
        }
        self.check_current(plan, registry, config)?;
        let answer = if let Some(name) = member {
            spec.subcommand(name)
                .ok_or(ClosedSourceRefusal::Source)?
                .run_const_fold_in(&arguments, dialect)
        } else {
            spec.run_const_fold_in(&arguments, dialect)
        };
        self.check_current(plan, registry, config)?;
        Ok(answer)
    }

    /// Detached observations of this actual owned evaluator only. Callers must
    /// not add these to another thread's CountingEngine metrics or describe
    /// cache hits as VM invocations.
    fn telemetry(&self) -> OwnedEvaluatorTelemetry {
        let counts = self.evaluator.counts.get();
        let slots = self
            .plan
            .bindings
            .iter()
            .map(|binding| binding.slot)
            .collect::<std::collections::HashSet<_>>();
        OwnedEvaluatorTelemetry {
            actual_invocations: counts.total,
            actual_fold_invocations: counts.fold,
            fold_answers: counts.fold_answers,
            abstentions: counts.abstentions,
            errors: self.host.error_log(),
            crashes: self.host.crash_records(),
            quarantined: slots
                .into_iter()
                .filter(|slot| self.host.is_quarantined(*slot))
                .count(),
        }
    }

    fn check_current(
        &self,
        plan: &Arc<HookPlan>,
        registry: &CommandRegistry,
        config: &HostConfig,
    ) -> Result<(), ClosedSourceRefusal> {
        let result = (|| {
            if !self.live.get()
                || !pack_hooks::current_host_is(&self.receiver)
                || !Arc::ptr_eq(&self.plan, plan)
                || self.registry != registry.snapshot().semantic_key()
                || &self.config != config
                || pack_hooks::evaluator_generation() != self.generation
                || self
                    .plan
                    .bindings
                    .iter()
                    .any(|binding| !self.evaluator.actual.is_available(binding.slot))
            {
                return Err(ClosedSourceRefusal::Currency);
            }
            let private_hosts = self
                .private_hosts
                .try_borrow()
                .map_err(|_| ClosedSourceRefusal::Currency)?;
            for retained in private_hosts.iter() {
                retained.check_quiet_host()?;
            }
            Ok(())
        })();
        if result.is_err() {
            self.live.set(false);
        }
        result
    }
}

impl Drop for OwnedApplicationEvaluator {
    fn drop(&mut self) {
        self.live.set(false);
        // Retire only our actual receiver. Generation equality alone cannot
        // revive ownership or justify clearing a foreign replacement.
        let _ = pack_hooks::clear_current_host_if(&self.receiver);
    }
}

struct ActiveCall<'a>(&'a Cell<bool>);
impl Drop for ActiveCall<'_> {
    fn drop(&mut self) {
        self.0.set(false);
    }
}

struct OwnedEvaluatorTelemetry {
    actual_invocations: u64,
    actual_fold_invocations: u64,
    fold_answers: u64,
    abstentions: u64,
    errors: Vec<String>,
    crashes: Vec<tcl_spec_hooks::CrashRecord>,
    quarantined: usize,
}
