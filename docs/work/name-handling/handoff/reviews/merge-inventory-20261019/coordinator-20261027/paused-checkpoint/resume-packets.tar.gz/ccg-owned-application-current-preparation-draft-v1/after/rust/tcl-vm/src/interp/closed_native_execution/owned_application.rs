// tcl-lsp — a language server and toolchain for Tcl
// Copyright (C) 2026 James Deucker (bitwisecook)
// SPDX-License-Identifier: AGPL-3.0-or-later

//! Opaque actual installed-service preparation for the private application owner.
//! This is NOT a closed-consumer grant or an alternative integer-domain check.
//! The owning backend must validate the complete unchanged returned module.

use super::*;

/// Actual callback result with its original entry; callers cannot construct it.
pub struct PreparedOwnedApplicationSource {
    module: ModuleAsm,
    entry: NativeCompilationEntry,
}

impl PreparedOwnedApplicationSource {
    /// Inspect unchanged canonical output before deciding backend admission.
    #[must_use]
    pub fn module(&self) -> &ModuleAsm {
        &self.module
    }
}

impl Vm {
    /// Compile through THIS interpreter's currently installed service.
    ///
    /// The result carries no closed-consumer permission. Its complete code,
    /// auxiliaries and nested callbacks require the private backend's checks.
    pub fn prepare_owned_application_source(
        &self,
        source: &str,
        commands: &[String],
        scalars: &[String],
        observation: &NativeCompilationEntry,
    ) -> Result<PreparedOwnedApplicationSource, ClosedSourceRefusal> {
        let before = self.observe_closed_native_state(commands, scalars, observation)?;
        let image = tcl_runtime_api::SourceImage::native(source.as_bytes());
        let namespace = self.source_namespace_path();
        let module = self
            .compiler
            .as_ref()
            .ok_or(ClosedSourceRefusal::NativeContext)?
            .compile_plain_script_bytes_with_entry(
                tcl_runtime_api::ScriptCompileTargetBytes {
                    source: &image,
                    namespace: &namespace,
                },
                self.source_profile(),
                &before,
            )
            .map_err(|_| ClosedSourceRefusal::Execution)?;
        if module.profile.cache_key() != self.source_profile().cache_key()
            || module.source != image
            || module.source_namespace != namespace
            || !module.plain_command_dispatch
            || !module.procedures.is_empty()
            || !module.procedure_provenance.is_empty()
        {
            return Err(ClosedSourceRefusal::NativeContext);
        }
        self.validate_module_profile(&module)
            .map_err(|_| ClosedSourceRefusal::NativeContext)?;
        for function in [&module.top_level, &module.top_level_body] {
            function
                .validate_native_compilation_entry()
                .map_err(|_| ClosedSourceRefusal::NativeContext)?;
            if !self.native_compiler_prerequisites_match(function)
                || !self.native_math_table_prerequisite_matches(function)
            {
                return Err(ClosedSourceRefusal::Currency);
            }
        }
        let after = self.observe_closed_native_state(commands, scalars, observation)?;
        if before != after {
            return Err(ClosedSourceRefusal::Currency);
        }
        Ok(PreparedOwnedApplicationSource {
            module,
            entry: after,
        })
    }

    /// Execute only the unchanged result of this reached installed-service call.
    /// No completion value escapes. Ordinary callers acquire no scope grant.
    pub fn execute_owned_application_preparation(
        &mut self,
        prepared: PreparedOwnedApplicationSource,
        commands: &[String],
        scalars: &[String],
    ) -> Result<(), ClosedSourceRefusal> {
        let current = self.observe_closed_native_state(commands, scalars, &prepared.entry)?;
        if current != prepared.entry {
            return Err(ClosedSourceRefusal::Currency);
        }
        let completion = self.run_current_module_at(&prepared.module, None);
        if self.limit_exceeded().is_some()
            || completion.code != Code::Ok
            || self.execution_refusal.is_some()
        {
            return Err(ClosedSourceRefusal::Execution);
        }
        drop(completion);
        drop(prepared);
        Ok(())
    }
}
