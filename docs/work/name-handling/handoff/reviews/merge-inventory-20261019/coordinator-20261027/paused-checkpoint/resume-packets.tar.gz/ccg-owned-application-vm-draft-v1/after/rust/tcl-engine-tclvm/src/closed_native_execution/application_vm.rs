// tcl-lsp — a language server and toolchain for Tcl
// Copyright (C) 2026 James Deucker (bitwisecook)
// SPDX-License-Identifier: AGPL-3.0-or-later

//! Actual single private application VM and its consuming execution boundary.
//! No constructor here issues a closed scope or accepts caller resources.

use std::rc::Rc;
use std::time::Duration;

use tcl_compiler::compile_service::{
    BytecodeCompileService, OwnedApplicationCompileService, OwnedApplicationCompilerInputs,
};
use tcl_platform::{Host, NumericEnvironment};
use tcl_runtime_api::NativeCompilationEntry;
use tcl_runtime_api::closed_native_consumer::{ClosedSourceRefusal, ClosedSourceTranscript};
use tcl_vm::{PreparedOwnedApplicationSource, Vm};

use super::{MemoryHost, MemoryWriter};

/// A bounded canonical preparation still owned by the same actual VM.
/// Neither its module nor retained entry can be recovered by an ordinary caller.
pub struct PrivateApplicationPreparation {
    module: PreparedOwnedApplicationSource,
    entry: NativeCompilationEntry,
}

/// Resources only: this is deliberately not an implementation of
/// `ClosedNativeBackend`. The final application backend must additionally own
/// its authenticated pack evaluator, full plan, candidate and all nested code.
pub struct PrivateApplicationVm {
    vm: Vm,
    host: Rc<MemoryHost>,
    compiler: OwnedApplicationCompileService,
    observation: NativeCompilationEntry,
    commands: Vec<String>,
    scalars: Vec<String>,
}

impl PrivateApplicationVm {
    /// Construct a real C9.1 core, private memory I/O and fixed stock compiler.
    /// `commands` and `scalars` are descriptive restrictions, not authority.
    ///
    /// # Errors
    /// Refuses unavailable bootstrap, nonoriginal commands, initial scalar
    /// roots/observers or unavailable canonical compiler/context prerequisites.
    pub fn new(
        inputs: Rc<OwnedApplicationCompilerInputs>,
        commands: Vec<String>,
        scalars: Vec<String>,
    ) -> Result<Self, ClosedSourceRefusal> {
        let profile = tcl_registry::model::ingress::resolve_known_environment("tcl9.1")
            .and_then(|environment| environment.catalogue_profile())
            .ok_or(ClosedSourceRefusal::NativeContext)?;
        let host = Rc::new(MemoryHost::new());
        let mut vm = Vm::with_native_core(
            Box::new(MemoryWriter(Rc::clone(&host.sinks))),
            Rc::clone(&host) as Rc<dyn Host>,
            profile,
            tcl_registry::special_vars::NativeBootstrapInputs::default(),
        )
        .ok_or(ClosedSourceRefusal::NativeContext)?;
        // Match the existing private producer's real compiler installation
        // before asking for its first closed observation. This temporary
        // concrete provider never receives caller source or a callback.
        let stock = tcl_registry::CommandRegistry::build_default().project_for_profile(profile);
        vm.set_compiler(Box::new(BytecodeCompileService::new(stock)));
        let initial = vm.restrict_closed_native_commands(&commands, &scalars)?;
        let compiler = OwnedApplicationCompileService::new(inputs, initial.interpreter)
            .map_err(|_| ClosedSourceRefusal::NativeContext)?;
        vm.set_compiler(Box::new(compiler.clone()));
        vm.set_command_limit(Some(256));
        vm.set_wall_clock_budget(Some(Duration::from_millis(250)));
        vm.set_value_size_limit(Some(4096));
        // set_compiler retires the original pass currency. Do not reuse the
        // before-replacement entry/empty-literal observation as a fresh one.
        drop(initial);
        let observation = vm.restrict_closed_native_commands(&commands, &scalars)?;
        let result = Self {
            vm,
            host,
            compiler,
            observation,
            commands,
            scalars,
        };
        result.capture_actual_state()?;
        Ok(result)
    }

    /// Actual read-only state, without reading a variable or invoking resolver
    /// fallback. This still grants no Native handler completion or CU mutation.
    ///
    /// # Errors
    /// Refuses changed owner/frame/command/observer/literal/scalar state or
    /// nonquiet private I/O/numerical prerequisites.
    pub fn capture_actual_state(&self) -> Result<NativeCompilationEntry, ClosedSourceRefusal> {
        let quiet = {
            let sinks = self
                .host
                .sinks
                .try_borrow()
                .map_err(|_| ClosedSourceRefusal::Currency)?;
            !sinks.refused && sinks.stdout.is_empty() && sinks.stderr.is_empty()
        };
        let empty_environment = self
            .host
            .environment
            .try_borrow()
            .map_err(|_| ClosedSourceRefusal::Currency)?
            .is_empty();
        if !quiet || !empty_environment {
            return Err(ClosedSourceRefusal::NativeContext);
        }
        let numeric = self
            .host
            .state()
            .map_err(|_| ClosedSourceRefusal::NativeContext)?;
        if numeric.range_error || numeric.domain_error {
            return Err(ClosedSourceRefusal::NativeContext);
        }
        self.vm
            .observe_closed_native_state(&self.commands, &self.scalars, &self.observation)
    }

    /// Call the actual fixed canonical provider without installing any object
    /// array. No old integer-domain preparation/checker is weakened or reused.
    ///
    /// # Errors
    /// Refuses unavailable full returned-code/literal domain or entry drift.
    pub fn prepare(
        &self,
        source: &str,
    ) -> Result<PrivateApplicationPreparation, ClosedSourceRefusal> {
        let before = self.capture_actual_state()?;
        self.compiler
            .validate_root_selection(source)
            .map_err(|_| ClosedSourceRefusal::Source)?;
        // The actual installed service produces this opaque preparation;
        // no caller-supplied module is retagged as current-service output.
        let module = self.vm.prepare_owned_application_source(
            source,
            &self.commands,
            &self.scalars,
            &self.observation,
        )?;
        let after = self.capture_actual_state()?;
        if before != after {
            return Err(ClosedSourceRefusal::Currency);
        }
        Ok(PrivateApplicationPreparation {
            module,
            entry: after,
        })
    }

    /// Consume this actual VM once. The existing VM performs all reached
    /// NativeLiteralPool/cache/getter/COW/write/return/retirement operations;
    /// there is no evaluator replay or getter-result simulation here.
    ///
    /// # Errors
    /// Refuses drift, actual native preflight/completion or bounded output.
    /// No partial transcript or Native value escapes on refusal.
    pub fn execute_owned(
        mut self,
        prepared: PrivateApplicationPreparation,
    ) -> Result<ClosedSourceTranscript, ClosedSourceRefusal> {
        if self.capture_actual_state()? != prepared.entry {
            return Err(ClosedSourceRefusal::Currency);
        }
        self.vm.execute_owned_application_preparation(
            prepared.module,
            &self.commands,
            &self.scalars,
        )?;
        drop(prepared.entry);
        drop(self.observation);
        drop(self.compiler);
        drop(self.vm);
        let mut sinks = self
            .host
            .sinks
            .try_borrow_mut()
            .map_err(|_| ClosedSourceRefusal::Currency)?;
        if sinks.refused || !sinks.stderr.is_empty() {
            return Err(ClosedSourceRefusal::Execution);
        }
        Ok(ClosedSourceTranscript {
            stdout: std::mem::take(&mut sinks.stdout),
            stderr: std::mem::take(&mut sinks.stderr),
        })
    }
}
