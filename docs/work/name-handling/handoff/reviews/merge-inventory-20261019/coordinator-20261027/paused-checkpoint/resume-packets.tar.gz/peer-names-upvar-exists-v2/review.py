import ast, collections, datetime, hashlib, json, os, pathlib, re, subprocess

P = pathlib.Path('/workspace/naming-proof-storage/names-clean-fixture-table-upvar-exists-v2')
R = pathlib.Path('/workspace/naming-lsp-release/tcl-lsp')
O = pathlib.Path(__file__).parent
def sha(b): return hashlib.sha256(b).hexdigest()
def git(*args):
    return subprocess.check_output(['git', '--no-optional-locks', *args], cwd=R,
        env={**os.environ, 'GIT_NO_LAZY_FETCH':'1'})
def load(p): return json.loads(p.read_bytes())

# Reuse only the previously independently authored Rust lexical definitions.
lexical = ast.parse(pathlib.Path('/workspace/naming-proof-storage/peer-release-comment-format-20261026/review.py').read_text())
nodes = [n for n in lexical.body if isinstance(n, ast.FunctionDef) and n.name in ('ident','lex')
         or isinstance(n, ast.Assign) and any(isinstance(t,ast.Name) and t.id in ('char_re','raw_re') for t in n.targets)]
ns = {'re':re}
exec(compile(ast.Module(nodes, []), '<bounded lexical definitions>', 'exec'), ns)
lex = ns['lex']

top = load(P/'manifest.json')
assert sha((P/'manifest.json').read_bytes()) == 'aea08787efeca602f9bfdd7f6f3b8908db4943012f46daf0f35b802f2869cb04'
for path, digest in top.items():
    if path.endswith('_sha256'): continue
    assert sha((P/path).read_bytes()) == digest, path
M = load(P/'CLEAN/manifest.json')
assert sha((P/'CLEAN/manifest.json').read_bytes()) == top['CLEAN_manifest_sha256']
patch = (P/'CLEAN/proposal.patch').read_bytes()
assert sha(patch) == M['patch_sha256']
head = git('rev-parse','HEAD').decode().strip()
before, after, modes = {}, {}, {}
for f in M['files']:
    p = f['path']; tree = git('ls-tree',head,'--',p).decode()
    if f['operation'] == 'create':
        assert not tree, p
        assert not (R/p).exists(), ('untracked current create collision',p)
        before[p] = b''
    else:
        assert tree.startswith('100644 blob '), (p,tree)
        modes[p] = '100644'
        b = git('show',head+':'+p)
        assert sha(b) == f['before_sha256'], ('current preimage',p)
        assert b == (P/'CLEAN/before'/p).read_bytes()
        assert (R/p).read_bytes() == b and not (R/p).is_symlink(), ('working preimage',p)
        before[p] = b
    if f['operation'] == 'delete': after[p] = b''
    else:
        b = (P/'CLEAN/after'/p).read_bytes()
        assert sha(b) == f['after_sha256'], p
        assert not ((P/'CLEAN/after'/p).stat().st_mode & 0o111)
        after[p] = b

# Parse every actual hunk, prove both directions and its exact manifest path set.
lines = patch.decode().splitlines(keepends=True); i=0; seen=[]
while i < len(lines):
    assert lines[i].startswith('--- ')
    old = lines[i][4:].strip(); new = lines[i+1][4:].strip(); i += 2
    p = (old[2:] if old != '/dev/null' else new[2:]); seen.append(p)
    src=before[p].decode().splitlines(keepends=True); dst=[]; pos=0
    while i < len(lines) and lines[i].startswith('@@ '):
        m = re.fullmatch(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@[^\n]*\n',lines[i]); assert m
        a=int(m[1]); n=int(m[2] or 1); b=int(m[3]); z=int(m[4] or 1); i+=1
        start = a-1 if n else a
        assert start >= pos; dst += src[pos:start]; pos=start
        removed=[]; added=[]
        while i < len(lines) and lines[i][:1] in (' ','+','-') and not lines[i].startswith('--- '):
            s=lines[i]; i+=1
            content=s[1:]
            if i<len(lines) and lines[i]=='\\ No newline at end of file\n':
                assert content.endswith('\n');content=content[:-1];i+=1
            if s[0] in ' -': removed.append(content)
            if s[0] in ' +': added.append(content)
        assert len(removed)==n and len(added)==z
        assert src[pos:pos+n] == removed, p
        assert len(dst) == (b-1 if z else b), (p,len(dst),b,z)
        dst += added; pos += n
    dst += src[pos:]
    assert ''.join(dst).encode() == after[p], p
assert len(seen)==len(set(seen)) and set(seen)==set(before)

assert sha((P/'old-path-to-table-record.json').read_bytes())==top['map_sha256']
mapping=load(P/'old-path-to-table-record.json');assert len(mapping)==10
modpaths=[f['path']for f in M['files']if f['operation']=='modify'];tables=[f['path']for f in M['files']if f['operation']=='create'];assert len(modpaths)==4 and len(tables)==1 and len(before)==15
records={};roundtrips=[]
for p in tables:
 t={}
 for line in after[p].decode().splitlines():
  if line.startswith('#') or line=='key\thex':continue
  key,hx=line.split('\t');assert key not in t and re.fullmatch('[0-9a-f]*',hx)and len(hx)%2==0;t[key]=bytes.fromhex(hx)
 records[p]=t
for row in mapping:
 p=row['old_path'];value=records[row['table_path']][row['key']]
 assert value==before[p] and len(value)==row['bytes'] and sha(value)==row['sha256'];value.decode('utf8')
 assert os.path.normpath(str(pathlib.PurePosixPath(row['table_path']).parent/row['key']))==p
 roundtrips.append({'path':p,'key':row['key'],'bytes':len(value),'sha256':sha(value)})
assert sum(len(t)for t in records.values())==10
assert {(r['table_path'],r['key'])for r in mapping}=={(p,k)for p,t in records.items()for k in t}
helper={'path':'rust/tcl-test-support/src/fixture_tables.rs','sha256':'30460803530dd768f2b77df1684b421441c91743b318576ab3c630ce5ecb2c49'};assert sha(git('show',head+':'+helper['path']))==helper['sha256'] and sha((R/helper['path']).read_bytes())==helper['sha256']
fmt='/workspace/.rustup/toolchains/1.99.1-x86_64-unknown-linux-gnu/bin/rustfmt'
def formatted(t,edition):
 q=subprocess.run([fmt,'--edition',edition,'--config','skip_children=true','--emit','stdout'],input=t.encode(),capture_output=True,check=True);assert not q.stderr;return q.stdout
import tomllib
calls=re.compile(r'tcl_test_support::fixture_tables::text\(\s*(?:include_str!\(\s*"([^"]+)"\s*\)|(CAPTURES)),\s*"([^"]+)"\s*,?\s*\)',re.S)
const=re.compile(r'^[ \t]*const CAPTURES: &str =\s*include_str!\(\s*"([^"]+)"\s*\);\n',re.M)

def balanced(t,start,opening,closing):
 _,cc,ll=lex(t);skip={i:j for i,j,_ in cc};skip.update({i:j for i,j in ll});i=start;depth=0
 while i<len(t):
  if i in skip:i=skip[i];continue
  depth+=(t[i]==opening)-(t[i]==closing)
  if depth==0:return i+1
  i+=1
 raise AssertionError('unclosed')
def fn(t,name):
 s=t.index('fn '+name+'(');brace=t.index('{',s);e=balanced(t,brace,'{','}');return s,e,t[s:e]
pattern=re.compile(r'tcl_test_support::fixture_tables::text\(\s*include_str!\(\s*"([^"]+)"\s*\),\s*"([^"]+)"\s*,?\s*\)',re.S);joins=[];inverses=[];bounds=[]
for p in modpaths:
 b=before[p].decode();a=after[p].decode();x=a;found=list(pattern.finditer(a));assert len(found)==(5 if '/tcl-registry/src/'in p else 10)
 for m in reversed(found):
  table=os.path.normpath(str(pathlib.PurePosixPath(p).parent/m[1]));rel=str(pathlib.PurePosixPath(m[1]).parent/m[2]);old=os.path.normpath(str(pathlib.PurePosixPath(p).parent/rel));assert records[table][m[2]]==before[old];joins.append({'consumer':p,'old_path':old,'table':table,'key':m[2]});x=x[:m.start()]+'include_str!("'+rel+'")'+x[m.end():]
 if '/tcl-registry/src/'in p:
  s,e,body=fn(x,'original_compiler_tables');arr=body[body.index('{')+1:body.rfind('}')].strip();at=b.index('let tables = [');br=b.index('[',at);en=balanced(b,br,'[',']');oldlet=b[at:en+1];assert oldlet.endswith(';');assert lex(arr)[0]==lex(b[br:en])[0];assert x[e:e+2]=='\n\n';startline=x.rfind('\n',0,s)+1;x=x[:startline]+x[e+2:];assert x.count('let tables = original_compiler_tables();')==1;x=x.replace('let tables = original_compiler_tables();',oldlet,1)
 else:
  for factory,const in [('original_tables','TABLES'),('original_quiet_tables','QUIET_TABLES')]:
   s,e,body=fn(x,factory);arr=body[body.index('{')+1:body.rfind('}')].strip();st=b.index('const '+const+':');init=b.index('= ',st)+2;br=b.index('[',init);en=balanced(b,br,'[',']');oldconst=b[st:en+1];assert oldconst.endswith(';');assert lex(arr)[0]==lex(b[br:en])[0];x=x[:s]+oldconst+x[e:];assert x.count('&'+factory+'()')==1;x=x.replace('&'+factory+'()',const,1)
  assert x.count('tables: &[(&str, String)]')==1;x=x.replace('tables: &[(&str, String)]','tables: &[(&str, &str)]',1);assert x.count('for &(engine, ref table) in tables')==1;x=x.replace('for &(engine, ref table) in tables','for &(engine, table) in tables',1)
 bt,bc,bl=lex(b);xt,xc,xl=lex(x);assert bt==xt,('tokens',p);assert[b[i:j]for i,j,_ in bc]==[x[i:j]for i,j,_ in xc];assert[b[i:j]for i,j in bl]==[x[i:j]for i,j in xl];edition='2021'if p.startswith('runtime/')else '2024';
 if formatted(x,edition)!=formatted(b,edition):
  import difflib
  print(p, ''.join(difflib.unified_diff(formatted(b,edition).decode().splitlines(True),formatted(x,edition).decode().splitlines(True)))[:2000]);raise AssertionError('formatted inverse')
 assert formatted(a,edition)==a.encode(),('afterfmt',p);inverses.append({'path':p,'actual_edition':edition,'entire_old_tokens_literals_comments_formatted_bytes_inverse':True})
 _,cc,ll=lex(a);skip=[(i,j)for i,j,_ in cc]+ll
 for m in re.finditer(r'\bfn\s+(\w+)\s*\(',a):
  if any(i<=m.start()<j for i,j in skip):continue
  s,e,body=fn(a,m[1]);count=sum(bool(line.strip())for line in body.splitlines());assert count<=100,(p,m[1],count);bounds.append({'path':p,'function':m[1],'nonblank_lines':count})
assert len(joins)==30 and len({(r['table'],r['key'])for r in joins})==10;assert sorted((r['consumer'],r['old_path'],r['key'])for r in joins)==sorted((r['consumer'],r['old_path'],r['key'])for r in M['actual_read_occurrences'])
inputs={}
for rel in ['rust/tcl-registry/tests/data/native_upvar_info_exists/cases.rs','rust/tcl-registry/tests/data/native_upvar_info_exists/quiet/cases.rs']:
 data=git('show',head+':'+rel);assert rel not in before and(R/rel).read_bytes()==data;inputs[rel]=sha(data)
num=git('apply','--numstat',str(P/'CLEAN/proposal.patch')).decode().splitlines();assert len(num)==15 and{n.split('\t',2)[2]for n in num}==set(before)and not any('/dev/null'in n for n in num)
r={'disposition':'CLEAR bounded CLEAN-only fixture/source/type/lifetime review; Rust UNRUN','master_sha256':sha((P/'manifest.json').read_bytes()),'patch_sha256':sha(patch),'current_CLEAN_head':head,'all15_current_paths_modes_hunks_createabsence':True,'all10_complete_original_record_roundtrips':roundtrips,'all30_actual_reads_all10keys':joins,'all4_whole_original_module_inverses':inverses,'every_actual_function_below100_nonblank_lines':bounds,'unchanged_original_input_case_arrays':inputs,'existing_shared_loader_unchanged':helper,'type_lifetime':'Runtime/VM &[(&str,String)] arguments borrow five-row owned array temporaries through entire same compare call; for &(engine,ref table) copies only &str and borrows String, never moves String from borrowed tuple. Registry factories construct same original five rows at exact former let tables position; for(version,table) owns eachString until existing inner parse/assert loop ends. table.lines/splits borrow only within those lifetimes; returned comparisons/results/header counts remain owned primitive tuples. Fixture String allocations are ordinary Rust text; Native Value creation/eval/cache/refcount/header/trace callbacks/counters/drop/order/assertions byteinverse untouched. All production registry compiler code unchanged; new factories remain cfgtest private.','coverage':'Original140completion+20header and15quiet windows, registry60opcode windows/upvar opcode assertions identical; source representation only, no actual passing validation inferred. Ten outputs retain distinct standard/quiet/provider keys; no input equality assertion weakened/tautological.','held_predecessor':'V1 author-held >100line test; V2 actual complete function census below100.','WORK_change':False,'actual_Rust':'UNRUN','canonical_mutation':False,'gate_waiver':False};f=O/'receipt.json';f.write_text(json.dumps(r,indent=2)+'\n');print(sha(f.read_bytes()))
