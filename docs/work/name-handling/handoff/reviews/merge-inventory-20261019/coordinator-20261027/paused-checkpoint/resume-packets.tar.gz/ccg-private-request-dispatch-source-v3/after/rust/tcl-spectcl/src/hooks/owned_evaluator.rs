// tcl-lsp — a language server and toolchain for Tcl
// Copyright (C) 2026 James Deucker (bitwisecook)
// SPDX-License-Identifier: AGPL-3.0-or-later

//! Concrete worker-local evaluator ownership; this issues no execution scope.
//!
//! Only the application backend under construction will use this owner. It
//! must separately prove its VM/compiler/getter/literal and emitted-code
//! closure. Holding this evaluator never makes a source CU or Native handler
//! complete, and these counters never stand in for optimiser call attempts.

use std::cell::{Cell, RefCell};
use std::rc::Rc;
use std::sync::Arc;

use tcl_engine_tclvm::{PrivateApplicationHookHost, TclVmEngine, private_application_hook_engine};
use tcl_registry::pack_hooks::{self, HookAnswer, HookCall, HookFamily, HookSlot, PackHookHost};
use tcl_registry::{CommandRegistry, InvocationDialect, InvocationFacts, RegistrySemanticKey};
use tcl_runtime_api::closed_native_consumer::ClosedSourceRefusal;
use tcl_spec_hooks::{HookHost, HookOwner, HostConfig};

use super::HookPlan;

#[derive(Clone, Copy, Default)]
struct InvocationCounts {
    total: u64,
    fold: u64,
    fold_answers: u64,
    abstentions: u64,
}

#[derive(Clone, Copy, PartialEq, Eq)]
enum RequestPhase {
    Idle,
    Preparing,
    Armed,
    Running,
    Answered,
    Failed,
}

struct FoldRequest {
    slot: HookSlot,
    arguments: Vec<String>,
    profile: &'static str,
    version: Option<tcl_dialect::TclVersion>,
}

impl FoldRequest {
    fn matches(&self, slot: HookSlot, call: &HookCall<'_>) -> bool {
        slot == self.slot
            && call.dialect == Some(self.profile)
            && pack_hooks::current_dialect() == Some(self.profile)
            && call.version == self.version
            && !call.in_event_body
            && call.option.is_none()
            && call.constraints.is_none()
            && call.targets.is_empty()
            && call.budget == tcl_registry::value_transfer::ImplementationBudget::default()
            && call.depends.is_empty()
            && call.words.len() == self.arguments.len()
            && call
                .words
                .iter()
                .zip(&self.arguments)
                .all(|(word, expected)| {
                    word.kind == tcl_registry::invocation_words::InvocationWordKind::Literal
                        && word.value == expected
                })
    }
}

struct RequestGate {
    phase: Cell<RequestPhase>,
    request: RefCell<Option<FoldRequest>>,
    receiver: RefCell<Option<std::rc::Weak<dyn PackHookHost>>>,
    live: Cell<bool>,
}

impl RequestGate {
    fn new() -> Self {
        Self {
            phase: Cell::new(RequestPhase::Idle),
            request: RefCell::new(None),
            receiver: RefCell::new(None),
            live: Cell::new(true),
        }
    }

    fn refuse(&self) {
        self.live.set(false);
        self.phase.set(RequestPhase::Failed);
    }

    fn begin(&self) -> Result<ActiveCall<'_>, ClosedSourceRefusal> {
        if !self.live.get() || self.phase.get() != RequestPhase::Idle {
            self.refuse();
            return Err(ClosedSourceRefusal::Currency);
        }
        self.phase.set(RequestPhase::Preparing);
        Ok(ActiveCall {
            gate: self,
            completed: false,
        })
    }

    fn arm(&self, request: FoldRequest) -> Result<(), ClosedSourceRefusal> {
        if !self.live.get() || self.phase.get() != RequestPhase::Preparing {
            self.refuse();
            return Err(ClosedSourceRefusal::Currency);
        }
        let Ok(mut held) = self.request.try_borrow_mut() else {
            self.refuse();
            return Err(ClosedSourceRefusal::Currency);
        };
        if held.is_some() {
            self.refuse();
            return Err(ClosedSourceRefusal::Currency);
        }
        *held = Some(request);
        self.phase.set(RequestPhase::Armed);
        Ok(())
    }

    fn consume(&self, slot: HookSlot, call: &HookCall<'_>) -> bool {
        let current = self
            .receiver
            .try_borrow()
            .ok()
            .and_then(|held| held.as_ref().and_then(std::rc::Weak::upgrade))
            .is_some_and(|receiver| pack_hooks::current_host_is(&receiver));
        if !current || !self.live.get() || self.phase.get() != RequestPhase::Armed {
            self.refuse();
            return false;
        }
        let request = match self.request.try_borrow_mut() {
            Ok(mut held) => held.take(),
            Err(_) => {
                self.refuse();
                return false;
            }
        };
        if !request.is_some_and(|request| request.matches(slot, call)) {
            self.refuse();
            return false;
        }
        self.phase.set(RequestPhase::Running);
        true
    }

    fn answered(&self) -> bool {
        if !self.live.get() || self.phase.get() != RequestPhase::Running {
            self.refuse();
            return false;
        }
        self.phase.set(RequestPhase::Answered);
        true
    }
}

struct ActiveCall<'a> {
    gate: &'a RequestGate,
    completed: bool,
}

impl ActiveCall<'_> {
    fn complete(mut self) -> Result<(), ClosedSourceRefusal> {
        if !self.gate.live.get() || self.gate.phase.get() != RequestPhase::Answered {
            return Err(ClosedSourceRefusal::Currency);
        }
        self.gate.phase.set(RequestPhase::Idle);
        self.completed = true;
        Ok(())
    }
}

impl Drop for ActiveCall<'_> {
    fn drop(&mut self) {
        if !self.completed {
            self.gate.refuse();
        }
        if let Ok(mut request) = self.gate.request.try_borrow_mut() {
            request.take();
        }
    }
}

struct CountedEvaluator {
    actual: Rc<dyn PackHookHost>,
    counts: Cell<InvocationCounts>,
    gate: Rc<RequestGate>,
}

impl PackHookHost for CountedEvaluator {
    fn invoke(&self, slot: HookSlot, call: &HookCall<'_>) -> HookAnswer {
        if !self.gate.consume(slot, call) {
            return HookAnswer::Abstain;
        }
        let mut counts = self.counts.get();
        counts.total = counts.total.saturating_add(1);
        if matches!(
            slot.family(),
            HookFamily::ConstFold | HookFamily::ConstFoldVersioned
        ) {
            counts.fold = counts.fold.saturating_add(1);
        }
        self.counts.set(counts);
        // No RefCell or mutable counter borrow spans the actual evaluator.
        let answer = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
            self.actual.invoke(slot, call)
        }));
        let Ok(answer) = answer else {
            self.gate.refuse();
            return HookAnswer::Abstain;
        };
        if !self.gate.answered() {
            return HookAnswer::Abstain;
        }
        let mut counts = self.counts.get();
        if matches!(&answer, HookAnswer::Fold(_)) {
            counts.fold_answers = counts.fold_answers.saturating_add(1);
        }
        if matches!(&answer, HookAnswer::Abstain) {
            counts.abstentions = counts.abstentions.saturating_add(1);
        }
        self.counts.set(counts);
        answer
    }

    fn requires_uncached_dispatch(&self) -> bool {
        true
    }

    fn is_available(&self, slot: HookSlot) -> bool {
        self.gate.live.get()
            && self.gate.phase.get() != RequestPhase::Running
            && self.actual.is_available(slot)
    }
}

/// This must be created inside the new private worker, never on an analysis
/// caller's thread. No caller-supplied Engine, Host, callback or evaluator is
/// accepted. The retained plan owns the exact immutable programs installed.
struct OwnedApplicationEvaluator {
    plan: Arc<HookPlan>,
    registry: Arc<CommandRegistry>,
    registry_key: RegistrySemanticKey,
    installed: crate::install::OwnedHookRegistry,
    config: HostConfig,
    host: Rc<HookHost<TclVmEngine>>,
    evaluator: Rc<CountedEvaluator>,
    receiver: Rc<dyn PackHookHost>,
    gate: Rc<RequestGate>,
    private_hosts: Rc<RefCell<Vec<PrivateApplicationHookHost>>>,
    generation: tcl_registry::value_transfer::EvaluatorGeneration,
}

impl OwnedApplicationEvaluator {
    fn new(
        installed: crate::install::OwnedHookRegistry,
        config: HostConfig,
    ) -> Result<Self, ClosedSourceRefusal> {
        let plan = Arc::clone(installed.plan());
        let registry = Arc::clone(installed.registry());
        let profile = installed.profile();
        if profile.name != "tcl9.1"
            || InvocationDialect::of_profile(profile).tcl_version
                != Some(tcl_dialect::TclVersion::V9_1)
        {
            return Err(ClosedSourceRefusal::NativeContext);
        }
        // Refuse existing state; do not clear it to manufacture a private world.
        if pack_hooks::has_host() || plan.is_empty() {
            return Err(ClosedSourceRefusal::NativeContext);
        }
        // The finite initial engine roster is populated only AFTER the empty
        // owned TLS receiver is installed. No factory accepts caller engines.
        let initial: Rc<RefCell<Vec<TclVmEngine>>> = Rc::default();
        let private_hosts: Rc<RefCell<Vec<PrivateApplicationHookHost>>> = Rc::default();
        let factory_initial = Rc::clone(&initial);
        let pinned_hosts = Rc::clone(&private_hosts);
        let actual = Rc::new(
            HookHost::with_config(
                move || {
                    factory_initial
                        .borrow_mut()
                        .pop()
                        .expect("the private finite initial engine roster is exact")
                },
                config.clone(),
            )
            .with_pinned_engine_factory(move |profile| {
                let version = tcl_registry::model::ingress::resolve_known_environment(profile)
                    .and_then(|environment| environment.catalogue_profile())
                    .and_then(|profile| InvocationDialect::of_profile(profile).tcl_version)
                    .filter(|version| *version == tcl_dialect::TclVersion::V9_1)
                    .ok_or(tcl_engine_api::EngineError::Unsupported(
                        "private application pinned profile",
                    ))?;
                let (engine, retained) =
                    private_application_hook_engine(version, true).map_err(|_| {
                        tcl_engine_api::EngineError::Unsupported(
                            "private application pinned bootstrap",
                        )
                    })?;
                pinned_hosts.borrow_mut().push(retained);
                Ok(engine)
            }),
        );
        let gate = Rc::new(RequestGate::new());
        let evaluator = Rc::new(CountedEvaluator {
            actual: actual.clone(),
            counts: Cell::new(InvocationCounts::default()),
            gate: Rc::clone(&gate),
        });
        // Install the actual EMPTY owned host before constructing any engine.
        // HookHost construction has only allocated its Rust bookkeeping. This
        // direct host prevents the lazy global installer from being consulted
        // by compiler generation reads while hook programs are compiled.
        let receiver: Rc<dyn PackHookHost> = evaluator.clone();
        *gate.receiver.borrow_mut() = Some(Rc::downgrade(&receiver));
        pack_hooks::install_host(Rc::clone(&receiver));
        if !pack_hooks::current_host_is(&receiver) {
            return Err(ClosedSourceRefusal::NativeContext);
        }
        let generation = pack_hooks::evaluator_generation();
        if generation == tcl_registry::value_transfer::EvaluatorGeneration::NO_HOST {
            return Err(ClosedSourceRefusal::NativeContext);
        }
        let owned = Self {
            plan,
            registry_key: registry.snapshot().semantic_key(),
            registry,
            installed,
            config,
            host: Rc::clone(&actual),
            evaluator,
            receiver,
            gate,
            private_hosts,
            generation,
        };
        // The cleanup owner now exists on every early-return path. Its Drop
        // retires the TLS host before actual engine/host Rc owners are freed.
        for _ in owned.plan.packs() {
            let (engine, retained) =
                private_application_hook_engine(tcl_dialect::TclVersion::V9_0, false)?;
            owned.private_hosts.borrow_mut().push(retained);
            initial.borrow_mut().push(engine);
        }
        for programs in owned.plan.packs() {
            let installed = actual.install_pack_hooks(programs.clone());
            if installed.len() != programs.programs.len()
                || installed
                    .iter()
                    .zip(&programs.programs)
                    .any(|(got, wanted)| {
                        got.slot.is_none()
                            || got.declined.is_some()
                            || got.slot != wanted.slot
                            || got.command != wanted.command
                            || got.owner != wanted.owner
                            || got.family != wanted.family
                    })
                || pack_hooks::evaluator_generation() != owned.generation
            {
                return Err(ClosedSourceRefusal::NativeContext);
            }
        }
        if !initial.borrow().is_empty() {
            return Err(ClosedSourceRefusal::NativeContext);
        }
        owned.check_current(&owned.plan, &owned.registry, &owned.config)?;
        Ok(owned)
    }

    /// The real optimiser-time request, not a replay after execution. The
    /// enclosing backend must admit the complete source and Native effects
    /// before reaching this method; this only closes the owned evaluator join.
    fn run_selected_fold(
        &self,
        plan: &Arc<HookPlan>,
        registry: &Arc<CommandRegistry>,
        config: &HostConfig,
        facts: &InvocationFacts,
        values: &[String],
        dialect: InvocationDialect,
    ) -> Result<Option<String>, ClosedSourceRefusal> {
        // Refuse reentry before availability checks can borrow HookHost state.
        let call = self.gate.begin()?;
        self.check_current(plan, registry, config)?;
        let profile = self.installed.profile();
        if dialect != InvocationDialect::of_profile(profile) {
            return Err(ClosedSourceRefusal::NativeContext);
        }
        let _dialect = pack_hooks::DialectScope::enter(Some(profile.name));
        let query = dialect
            .authoring_query()
            .ok_or(ClosedSourceRefusal::NativeContext)?;
        // This is exactly the selection used by the value-flow consumer;
        // registry.get(last spec) is deliberately insufficient here.
        let spec = registry
            .get_for_surface(&facts.canonical_command, Some(query))
            .ok_or(ClosedSourceRefusal::Source)?;
        let arguments = values
            .get(facts.argument_offset..)
            .ok_or(ClosedSourceRefusal::Source)?
            .iter()
            .map(String::as_str)
            .collect::<Vec<_>>();
        let member = if spec.subcommands.is_empty() {
            None
        } else {
            Some(
                facts
                    .subcommand
                    .canonical_name()
                    .ok_or(ClosedSourceRefusal::Source)?,
            )
        };
        let (ordinary, versioned) = if let Some(name) = member {
            let selected = spec.subcommand(name).ok_or(ClosedSourceRefusal::Source)?;
            (selected.const_fold, selected.const_fold_versioned)
        } else {
            (spec.const_fold, spec.const_fold_versioned)
        };
        let family = if versioned.is_some() {
            HookFamily::ConstFoldVersioned
        } else {
            HookFamily::ConstFold
        };
        let mut matches = self.plan.bindings.iter().filter(|binding| {
            let owner_matches = match (&binding.owner, member) {
                (HookOwner::Command, None) => true,
                (HookOwner::Subcommand(expected), Some(actual)) => expected == actual,
                _ => false,
            };
            owner_matches
                && self.installed.owns_binding(
                    spec,
                    binding.declaration.0,
                    &binding.file,
                    &binding.pack,
                )
                && binding.family == family
                && self.evaluator.actual.is_available(binding.slot)
                && match family {
                    HookFamily::ConstFold => {
                        match (ordinary, pack_hooks::const_fold_fn(binding.slot)) {
                            (Some(actual), Some(expected)) => {
                                std::ptr::fn_addr_eq(actual, expected)
                            }
                            _ => false,
                        }
                    }
                    HookFamily::ConstFoldVersioned => {
                        match (versioned, pack_hooks::const_fold_versioned_fn(binding.slot)) {
                            (Some(actual), Some(expected)) => {
                                std::ptr::fn_addr_eq(actual, expected)
                            }
                            _ => false,
                        }
                    }
                    _ => false,
                }
        });
        let selected = matches.next().ok_or(ClosedSourceRefusal::Currency)?;
        if matches.next().is_some() {
            return Err(ClosedSourceRefusal::Currency);
        }
        self.check_current(plan, registry, config)?;
        self.gate.arm(FoldRequest {
            slot: selected.slot,
            arguments: arguments.iter().map(|value| (*value).to_owned()).collect(),
            profile: profile.name,
            version: (family == HookFamily::ConstFoldVersioned)
                .then_some(tcl_dialect::TclVersion::V9_1),
        })?;
        let answer = if let Some(name) = member {
            spec.subcommand(name)
                .ok_or(ClosedSourceRefusal::Source)?
                .run_const_fold_in(&arguments, dialect)
        } else {
            spec.run_const_fold_in(&arguments, dialect)
        };
        self.check_current(plan, registry, config)?;
        if pack_hooks::current_dialect() != Some(profile.name) {
            return Err(ClosedSourceRefusal::Currency);
        }
        call.complete()?;
        Ok(answer)
    }

    /// Detached observations of this actual owned evaluator only. Callers must
    /// not add these to another thread's CountingEngine metrics or describe
    /// cache hits as VM invocations.
    fn telemetry(&self) -> OwnedEvaluatorTelemetry {
        let counts = self.evaluator.counts.get();
        let slots = self
            .plan
            .bindings
            .iter()
            .map(|binding| binding.slot)
            .collect::<std::collections::HashSet<_>>();
        OwnedEvaluatorTelemetry {
            actual_invocations: counts.total,
            actual_fold_invocations: counts.fold,
            fold_answers: counts.fold_answers,
            abstentions: counts.abstentions,
            errors: self.host.error_log(),
            crashes: self.host.crash_records(),
            quarantined: slots
                .into_iter()
                .filter(|slot| self.host.is_quarantined(*slot))
                .count(),
        }
    }

    fn check_current(
        &self,
        plan: &Arc<HookPlan>,
        registry: &Arc<CommandRegistry>,
        config: &HostConfig,
    ) -> Result<(), ClosedSourceRefusal> {
        let result = (|| {
            if !self.gate.live.get()
                || !pack_hooks::current_host_is(&self.receiver)
                || !Arc::ptr_eq(&self.plan, plan)
                || !Arc::ptr_eq(&self.registry, registry)
                || self.registry_key != registry.snapshot().semantic_key()
                || &self.config != config
                || pack_hooks::evaluator_generation() != self.generation
                || self
                    .plan
                    .bindings
                    .iter()
                    .any(|binding| !self.evaluator.actual.is_available(binding.slot))
            {
                return Err(ClosedSourceRefusal::Currency);
            }
            let private_hosts = self
                .private_hosts
                .try_borrow()
                .map_err(|_| ClosedSourceRefusal::Currency)?;
            for retained in private_hosts.iter() {
                retained.check_quiet_host()?;
            }
            Ok(())
        })();
        if result.is_err() {
            self.gate.refuse();
        }
        result
    }
}

impl Drop for OwnedApplicationEvaluator {
    fn drop(&mut self) {
        self.gate.refuse();
        // Retire only our actual receiver. Generation equality alone cannot
        // revive ownership or justify clearing a foreign replacement.
        let _ = pack_hooks::clear_current_host_if(&self.receiver);
    }
}

struct OwnedEvaluatorTelemetry {
    actual_invocations: u64,
    actual_fold_invocations: u64,
    fold_answers: u64,
    abstentions: u64,
    errors: Vec<String>,
    crashes: Vec<tcl_spec_hooks::CrashRecord>,
    quarantined: usize,
}

#[cfg(test)]
mod tests {
    use super::*;

    struct RecordingHost {
        calls: Cell<usize>,
        reenter: bool,
        held: RefCell<()>,
    }

    impl PackHookHost for RecordingHost {
        fn invoke(&self, slot: HookSlot, call: &HookCall<'_>) -> HookAnswer {
            let _held = self.held.borrow_mut();
            self.calls.set(self.calls.get() + 1);
            if self.reenter {
                assert!(!pack_hooks::slot_available(slot));
                assert!(matches!(
                    pack_hooks::dispatch(slot, call),
                    HookAnswer::Abstain
                ));
            }
            HookAnswer::Fold(call.words[0].value.to_owned())
        }
    }

    fn installed(
        actual: Rc<dyn PackHookHost>,
    ) -> (Rc<CountedEvaluator>, Rc<RequestGate>, Rc<dyn PackHookHost>) {
        let gate = Rc::new(RequestGate::new());
        let counted = Rc::new(CountedEvaluator {
            actual,
            counts: Cell::new(InvocationCounts::default()),
            gate: Rc::clone(&gate),
        });
        let receiver: Rc<dyn PackHookHost> = counted.clone();
        *gate.receiver.borrow_mut() = Some(Rc::downgrade(&receiver));
        pack_hooks::install_host(Rc::clone(&receiver));
        (counted, gate, receiver)
    }

    fn slot() -> HookSlot {
        pack_hooks::allocate(
            HookFamily::ConstFoldVersioned,
            &pack_hooks::HookInputs::parse(&["words"]),
        )
        .unwrap()
    }

    fn request(slot: HookSlot, value: &str) -> FoldRequest {
        FoldRequest {
            slot,
            arguments: vec![value.to_owned()],
            profile: "tcl9.1",
            version: Some(tcl_dialect::TclVersion::V9_1),
        }
    }

    #[test]
    fn real_thunk_consumes_one_owned_request_and_restores_ambient_profile() {
        std::thread::spawn(|| {
            let actual = Rc::new(RecordingHost {
                calls: Cell::new(0),
                reenter: false,
                held: RefCell::new(()),
            });
            let (counted, gate, receiver) = installed(actual.clone());
            let slot = slot();
            let fold = pack_hooks::const_fold_versioned_fn(slot).unwrap();
            let _foreign = pack_hooks::DialectScope::enter(Some("tcl8.6"));
            for value in ["first", "second"] {
                let active = gate.begin().unwrap();
                {
                    let _profile = pack_hooks::DialectScope::enter(Some("tcl9.1"));
                    gate.arm(request(slot, value)).unwrap();
                    assert_eq!(
                        fold(&[value], Some(tcl_dialect::TclVersion::V9_1)),
                        Some(value.into())
                    );
                    active.complete().unwrap();
                }
                assert_eq!(pack_hooks::current_dialect(), Some("tcl8.6"));
            }
            assert_eq!(actual.calls.get(), 2);
            assert_eq!(counted.counts.get().fold, 2);
            assert_eq!(pack_hooks::cache_stats().entries, 0);
            assert_eq!(fold(&["second"], Some(tcl_dialect::TclVersion::V9_1)), None);
            assert_eq!(actual.calls.get(), 2);
            assert!(!gate.live.get());
            assert!(pack_hooks::clear_current_host_if(&receiver));
        })
        .join()
        .unwrap();
    }

    #[test]
    fn real_dispatch_refuses_foreign_request_axes_before_calling_the_evaluator() {
        std::thread::spawn(|| {
            for wrong in 0..5 {
                let actual = Rc::new(RecordingHost {
                    calls: Cell::new(0),
                    reenter: false,
                    held: RefCell::new(()),
                });
                let (_, gate, receiver) = installed(actual.clone());
                let selected = slot();
                let invoked = if wrong == 0 { slot() } else { selected };
                let active = gate.begin().unwrap();
                gate.arm(request(selected, "owned")).unwrap();
                let _profile = pack_hooks::DialectScope::enter(match wrong {
                    1 => None,
                    4 => Some("tcl8.6"),
                    _ => Some("tcl9.1"),
                });
                let fold = pack_hooks::const_fold_versioned_fn(invoked).unwrap();
                assert_eq!(
                    fold(
                        &[if wrong == 2 { "foreign" } else { "owned" }],
                        Some(if wrong == 3 {
                            tcl_dialect::TclVersion::V9_0
                        } else {
                            tcl_dialect::TclVersion::V9_1
                        }),
                    ),
                    None
                );
                assert!(active.complete().is_err());
                assert_eq!(actual.calls.get(), 0);
                assert!(gate.begin().is_err());
                assert!(pack_hooks::clear_current_host_if(&receiver));
            }
        })
        .join()
        .unwrap();
    }

    #[test]
    fn nested_actual_dispatch_refuses_before_an_active_evaluator_borrow() {
        std::thread::spawn(|| {
            let actual = Rc::new(RecordingHost {
                calls: Cell::new(0),
                reenter: true,
                held: RefCell::new(()),
            });
            let (_, gate, receiver) = installed(actual.clone());
            let slot = slot();
            let active = gate.begin().unwrap();
            let _profile = pack_hooks::DialectScope::enter(Some("tcl9.1"));
            gate.arm(request(slot, "owned")).unwrap();
            assert_eq!(
                pack_hooks::const_fold_versioned_fn(slot).unwrap()(
                    &["owned"],
                    Some(tcl_dialect::TclVersion::V9_1)
                ),
                None
            );
            assert!(active.complete().is_err());
            assert_eq!(actual.calls.get(), 1);
            assert!(!gate.live.get());
            assert!(pack_hooks::clear_current_host_if(&receiver));
        })
        .join()
        .unwrap();
    }

    #[test]
    fn superseded_receiver_and_abandoned_request_cannot_revive() {
        std::thread::spawn(|| {
            let actual = Rc::new(RecordingHost {
                calls: Cell::new(0),
                reenter: false,
                held: RefCell::new(()),
            });
            let (counted, gate, receiver) = installed(actual.clone());
            let slot = slot();
            let active = gate.begin().unwrap();
            gate.arm(request(slot, "owned")).unwrap();
            pack_hooks::install_host(actual.clone());
            let words = [pack_hooks::HookWord {
                value: "owned",
                kind: tcl_registry::invocation_words::InvocationWordKind::Literal,
            }];
            let call = HookCall {
                words: &words,
                version: Some(tcl_dialect::TclVersion::V9_1),
                in_event_body: false,
                option: None,
                constraints: None,
                dialect: Some("tcl9.1"),
                targets: &[],
                budget: tcl_registry::value_transfer::ImplementationBudget::default(),
                depends: &[],
            };
            assert!(matches!(counted.invoke(slot, &call), HookAnswer::Abstain));
            assert!(active.complete().is_err());
            assert_eq!(actual.calls.get(), 0);
            assert!(!pack_hooks::clear_current_host_if(&receiver));
            pack_hooks::clear_host();
            let (_, gate, receiver) = installed(actual);
            let active = gate.begin().unwrap();
            gate.arm(request(slot, "owned")).unwrap();
            drop(active);
            assert!(gate.begin().is_err());
            assert!(pack_hooks::clear_current_host_if(&receiver));
        })
        .join()
        .unwrap();
    }
}
