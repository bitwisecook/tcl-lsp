// tcl-lsp — a language server and toolchain for Tcl
// Copyright (C) 2026 James Deucker (bitwisecook)
// SPDX-License-Identifier: AGPL-3.0-or-later

//! Private optimiser-time value flow for a genuinely owning application scope.
//!
//! The descriptive prediction below supplies no Native completion or entry.
//! Only `prepare_owned_application` may invoke installed fold hooks, after the
//! real backend admits the entire original source. Its final candidate must
//! pass that same backend again. No ordinary CU or source walker is modified.

use std::{collections::BTreeMap, ops::Range};

use tcl_lexer::word_parts::{SubstFlags, WordPart as TemplatePart};
use tcl_registry::hooks::LoweringHookId;
use tcl_registry::native_compilation::NativeCompilationGrammar;
use tcl_registry::substitution::SubstitutionTemplateSelection;
use tcl_registry::{CommandRegistry, InvocationDialect, InvocationFacts, SemanticOperationId};
use tcl_runtime_api::closed_native_consumer::{
    ClosedNativeBackend, ClosedNativeConsumerScope, ClosedSourceRefusal, ClosedSourceRewrite,
};

use super::application_plan::ApplicationSourceInventory;
use tcl_compiler::ir::{CommandTokens, WordExpr, WordPart};

const MAX_VALUE_BYTES: usize = 4096;
const MAX_DEPTH: usize = 8;

/// Passive provenance of a real pre-execution selected hook answer.
/// This record is not an ordinary optimiser rewrite or execution permission.
pub(crate) struct ApplicationFoldProposal {
    pub(crate) invocation_index: usize,
    pub(crate) range: Range<usize>,
    pub(crate) canonical_target: String,
    pub(crate) selected_member: Option<String>,
    pub(crate) ordered_arguments: Vec<String>,
    pub(crate) value: String,
}

pub(crate) struct PreparedApplicationAnalysis<'owner, B: ClosedNativeBackend> {
    pub(crate) rewrite: ClosedSourceRewrite<'owner, B>,
    pub(crate) proposals: Vec<ApplicationFoldProposal>,
    pub(crate) predicted_stdout: Vec<u8>,
}

/// Consume the complete backend admission before any installed hook executes.
/// A source inventory, metadata flag or caller-provided Native entry cannot
/// construct this permission. The future concrete backend must own its actual
/// application VM, compiler, all objects and the internal hook evaluator.
pub(crate) fn prepare_owned_application<'owner, B: ClosedNativeBackend>(
    plan: &ApplicationSourceInventory,
    registry: &CommandRegistry,
    profile: &'static tcl_dialect::DialectProfile,
    scope: &ClosedNativeConsumerScope<'owner, B>,
    evaluator: &'owner super::OwnedApplicationEvaluator,
) -> Result<PreparedApplicationAnalysis<'owner, B>, ClosedSourceRefusal> {
    let dialect = InvocationDialect::of_profile(profile);
    if !std::ptr::eq(registry, evaluator.registry.as_ref())
        || scope.source() != plan.original_source()
        || scope.profile() != &profile.cache_key()
        || dialect.execution_point() != Some(scope.execution_point())
        || dialect.tcl_version != Some(tcl_dialect::TclVersion::V9_1)
        || !plan.matches_metadata(registry, profile)
    {
        return Err(ClosedSourceRefusal::NativeContext);
    }
    // This performs actual closed-state and complete original-footprint
    // validation. The selection is superseded by the final candidate below.
    let original_admission = scope.select(plan.original_source().to_owned())?;
    let mut flow = ValueFlow::new(plan, registry, profile, true);
    flow.evaluator = Some(evaluator);
    let result = flow.evaluate()?;
    let mut candidate = plan.original_source().to_owned();
    let mut ranges = result
        .proposals
        .iter()
        .map(|p| p.range.clone())
        .collect::<Vec<_>>();
    ranges.sort_by_key(|range| range.start);
    if ranges.windows(2).any(|pair| pair[0].end > pair[1].start) {
        return Err(ClosedSourceRefusal::Source);
    }
    let mut edits = result.proposals.iter().collect::<Vec<_>>();
    edits.sort_by_key(|proposal| std::cmp::Reverse(proposal.range.start));
    for proposal in edits {
        candidate.replace_range(
            proposal.range.clone(),
            &tcl_syntax::list::list_element(&proposal.value),
        );
    }
    // No Native resource or authority is obtained from the prediction. This
    // independently rechecks the full candidate and original correspondence.
    let rewrite = scope.select(candidate)?;
    drop(original_admission);
    Ok(PreparedApplicationAnalysis {
        rewrite,
        proposals: result.proposals,
        predicted_stdout: result.stdout,
    })
}

pub(super) fn canonical_stdout(
    plan: &ApplicationSourceInventory,
    registry: &CommandRegistry,
    profile: &'static tcl_dialect::DialectProfile,
) -> Result<Vec<u8>, ClosedSourceRefusal> {
    ValueFlow::new(plan, registry, profile, false)
        .evaluate()
        .map(|result| result.stdout)
}

struct Evaluation {
    stdout: Vec<u8>,
    proposals: Vec<ApplicationFoldProposal>,
}

struct Value {
    text: String,
    // Logical source writes/output only. False does NOT prove Native getter,
    // representation/cache/free or observer closure; the owning backend does.
    source_effect: bool,
}

struct ValueFlow<'a> {
    plan: &'a ApplicationSourceInventory,
    registry: &'a CommandRegistry,
    canonical: CommandRegistry,
    profile: &'static tcl_dialect::DialectProfile,
    installed_hooks: bool,
    evaluator: Option<&'a super::OwnedApplicationEvaluator>,
    scalars: BTreeMap<String, String>,
    stdout: Vec<u8>,
    proposals: Vec<ApplicationFoldProposal>,
    next_script: usize,
    next_invocation: usize,
    next_template: usize,
    active_invocation: Option<usize>,
}

impl<'a> ValueFlow<'a> {
    fn new(
        plan: &'a ApplicationSourceInventory,
        registry: &'a CommandRegistry,
        profile: &'static tcl_dialect::DialectProfile,
        installed_hooks: bool,
    ) -> Self {
        Self {
            plan,
            registry,
            profile,
            installed_hooks,
            evaluator: None,
            canonical: CommandRegistry::build_default().project_for_profile(profile),
            scalars: BTreeMap::new(),
            stdout: Vec::new(),
            proposals: Vec::new(),
            next_script: 0,
            next_invocation: 0,
            next_template: 0,
            active_invocation: None,
        }
    }

    fn evaluate(mut self) -> Result<Evaluation, ClosedSourceRefusal> {
        let source = self.plan.original_source();
        if source.as_bytes().contains(&0) {
            return Err(ClosedSourceRefusal::Source);
        }
        self.script(source, Some(0), None, 0)?;
        if self.next_script != self.plan.nested_scripts().len()
            || self.next_invocation != self.plan.invocation_sites().len()
            || self.next_template != self.plan.template_inputs().len()
        {
            return Err(ClosedSourceRefusal::Source);
        }
        Ok(Evaluation {
            stdout: self.stdout,
            proposals: self.proposals,
        })
    }

    fn script(
        &mut self,
        source: &str,
        root_offset: Option<usize>,
        whole_call: Option<Range<usize>>,
        depth: usize,
    ) -> Result<Value, ClosedSourceRefusal> {
        if depth > MAX_DEPTH
            || self
                .plan
                .nested_scripts()
                .get(self.next_script)
                .map(String::as_str)
                != Some(source)
        {
            return Err(ClosedSourceRefusal::Source);
        }
        let script_index = self.next_script;
        let parent_invocation = self.active_invocation;
        self.next_script += 1;
        let config = tcl_lexer::LexerConfig::from_grammar(self.profile.grammar);
        let map = tcl_lexer::SourceMap::new(source);
        let commands =
            tcl_compiler::segmenter::segment_commands_with_offset_and_config(source, 0, config);
        let single = commands.len() == 1;
        let mut last = Value {
            text: String::new(),
            source_effect: false,
        };
        let mut effects = false;
        for (command_index, command) in commands.iter().enumerate() {
            let tokens = CommandTokens::from_segmented(&map, config, command);
            let words = tokens.words();
            let dialect = InvocationDialect::of_profile(self.profile);
            let effective = words
                .iter()
                .map(|word| {
                    tcl_compiler::registry_invocation::effective_invocation_word(
                        word,
                        dialect.lexer_grammar.escapes,
                        dialect.word_values,
                    )
                })
                .collect::<Vec<_>>();
            let registry_words = effective
                .iter()
                .map(|word| word.as_registry_word())
                .collect::<Vec<_>>();
            let invocation =
                tcl_registry::InvocationWords::structured(registry_words[0], &registry_words[1..])
                    .with_dialect(dialect);
            let resolution =
                tcl_registry::model::assembly::resolve_structured_invocation_in_resolved_context(
                    self.registry,
                    None,
                    invocation,
                    tcl_dialect::model::InvocationRealm::RuleLoader,
                );
            let selected = resolution.resolved().ok_or(ClosedSourceRefusal::Source)?;
            let facts = selected.facts();
            let template = selected.native_substitution_template();
            let invocation_index = self.next_invocation;
            let site = self
                .plan
                .invocation_sites()
                .get(invocation_index)
                .ok_or(ClosedSourceRefusal::Source)?;
            let selected_template = match &template {
                SubstitutionTemplateSelection::Template {
                    template_at, kinds, ..
                } => Some((
                    *template_at,
                    kinds.variables,
                    kinds.commands,
                    kinds.backslashes,
                )),
                _ => None,
            };
            if site.script_index != script_index
                || site.parent_invocation != parent_invocation
                || site.template_selection != selected_template
                || site.command_index != command_index
                || site.source_range != command.span.as_range()
                || site.canonical_target != facts.canonical_command
                || site.operation != facts.operation
            {
                return Err(ClosedSourceRefusal::Source);
            }
            self.next_invocation += 1;
            self.active_invocation = Some(invocation_index);
            let proposal_start = self.proposals.len();
            let mut args = Vec::new();
            for word in &words[1..] {
                args.push(self.word(word, source, root_offset, depth)?);
            }
            let input_effect = args.iter().any(|arg| arg.source_effect);
            let values = args.iter().map(|arg| arg.text.clone()).collect::<Vec<_>>();
            check_values(&values)?;
            let text = match facts.operation {
                SemanticOperationId::StructuredLowering(LoweringHookId::Set) => {
                    let [name, value] = values.as_slice() else {
                        return Err(ClosedSourceRefusal::Source);
                    };
                    self.scalars.insert(name.clone(), value.clone());
                    last.source_effect = true;
                    value.clone()
                }
                SemanticOperationId::Intrinsic(tcl_registry::IntrinsicId::ChannelWrite) => {
                    let [value] = values.as_slice() else {
                        return Err(ClosedSourceRefusal::Source);
                    };
                    if self
                        .stdout
                        .len()
                        .checked_add(value.len() + 1)
                        .is_none_or(|n| n > super::MAX_CLOSED_OUTPUT_BYTES)
                    {
                        return Err(ClosedSourceRefusal::Budget);
                    }
                    self.stdout.extend_from_slice(value.as_bytes());
                    self.stdout.push(b'\n');
                    last.source_effect = true;
                    String::new()
                }
                SemanticOperationId::Intrinsic(tcl_registry::IntrinsicId::ListConstruct) => {
                    last.source_effect = input_effect;
                    tcl_registry::const_fold::fold_list(
                        &values.iter().map(String::as_str).collect::<Vec<_>>(),
                    )
                    .ok_or(ClosedSourceRefusal::Source)?
                }
                SemanticOperationId::StructuredLowering(LoweringHookId::Catch) => {
                    let [
                        _,
                        WordExpr::BracedLiteral {
                            text,
                            source: body_site,
                        },
                    ] = words
                    else {
                        return Err(ClosedSourceRefusal::Source);
                    };
                    let range = body_site.span.as_range();
                    let body_offset = root_offset.and_then(|offset| {
                        (source.get(range.clone()) == Some(format!("{{{text}}}").as_str()))
                            .then_some(offset + range.start + 1)
                    });
                    self.script(text, body_offset, None, depth + 1)?;
                    // Unsupported/error paths refuse the whole value model;
                    // this is not a guessed caught Error completion.
                    last.source_effect = true;
                    "0".to_owned()
                }
                SemanticOperationId::Invoke => match template {
                    SubstitutionTemplateSelection::Template {
                        template_at,
                        kinds,
                        parse_errors,
                    } => {
                        let text = values.get(template_at).ok_or(ClosedSourceRefusal::Source)?;
                        let value = self.template(
                            text,
                            invocation_index,
                            SubstFlags {
                                vars: kinds.variables,
                                cmds: kinds.commands,
                                backslashes: kinds.backslashes,
                                ..SubstFlags::default()
                            },
                            parse_errors.variable_syntax(),
                            depth,
                        )?;
                        last.source_effect = input_effect || value.source_effect;
                        value.text
                    }
                    _ if matches!(
                        facts.native_compilation.map(|spec| spec.grammar),
                        Some(NativeCompilationGrammar::StringMap(_))
                    ) =>
                    {
                        let canonical = selected_fold(&self.canonical, &facts, &values, dialect)
                            .ok_or(ClosedSourceRefusal::Source)?;
                        if !input_effect && single && self.installed_hooks {
                            if let Some(range) = whole_call.clone() {
                                let evaluator =
                                    self.evaluator.ok_or(ClosedSourceRefusal::NativeContext)?;
                                if let Some(answer) = evaluator.run_selected_fold(
                                    &evaluator.plan,
                                    &evaluator.registry,
                                    &evaluator.config,
                                    &facts,
                                    &values,
                                    dialect,
                                )? {
                                    if answer != canonical {
                                        return Err(ClosedSourceRefusal::Source);
                                    }
                                    self.proposals.truncate(proposal_start);
                                    self.proposals.push(ApplicationFoldProposal {
                                        invocation_index,
                                        range,
                                        canonical_target: facts.canonical_command.clone(),
                                        selected_member: facts
                                            .subcommand
                                            .canonical_name()
                                            .map(str::to_owned),
                                        ordered_arguments: values
                                            .get(facts.argument_offset..)
                                            .ok_or(ClosedSourceRefusal::Source)?
                                            .to_vec(),
                                        value: answer,
                                    });
                                }
                            }
                        }
                        last.source_effect = input_effect;
                        canonical
                    }
                    _ => return Err(ClosedSourceRefusal::Source),
                },
                _ => return Err(ClosedSourceRefusal::Source),
            };
            if !text.is_ascii() || text.as_bytes().contains(&0) {
                return Err(ClosedSourceRefusal::Source);
            }
            if text.len() > MAX_VALUE_BYTES {
                return Err(ClosedSourceRefusal::Budget);
            }
            last.text = text;
            effects |= last.source_effect;
        }
        last.source_effect = effects;
        self.active_invocation = parent_invocation;
        Ok(last)
    }

    fn word(
        &mut self,
        word: &WordExpr,
        parent: &str,
        root_offset: Option<usize>,
        depth: usize,
    ) -> Result<Value, ClosedSourceRefusal> {
        let config = tcl_lexer::LexerConfig::from_grammar(self.profile.grammar);
        match word {
            WordExpr::Literal { text, .. } | WordExpr::BracedLiteral { text, .. } => Ok(Value {
                text: text.clone(),
                source_effect: false,
            }),
            WordExpr::Variable { spelling, .. } => {
                let name = tcl_compiler::value_shapes::whole_word_scalar_var_name(spelling, config)
                    .ok_or(ClosedSourceRefusal::Source)?;
                Ok(Value {
                    text: self
                        .scalars
                        .get(name)
                        .ok_or(ClosedSourceRefusal::Source)?
                        .clone(),
                    source_effect: false,
                })
            }
            WordExpr::CommandSubstitution { spelling, source } => {
                let range = source.span.as_range();
                let exact_bracket = parent.get(range.clone()) == Some(spelling.as_str());
                let word_range = tcl_lexer::word_span_at(parent, source.span).as_range();
                let editable = root_offset.and_then(|offset| {
                    exact_bracket.then_some(offset + word_range.start..offset + word_range.end)
                });
                let child_offset = root_offset
                    .and_then(|offset| exact_bracket.then_some(offset + range.start + 1));
                self.bracket(spelling, child_offset, editable, depth)
            }
            WordExpr::Template {
                parts,
                rejected: None,
                ..
            } => {
                let mut value = Value {
                    text: String::new(),
                    source_effect: false,
                };
                for part in parts {
                    let component = match part {
                        WordPart::Text { text, .. } => Value {
                            text: text.clone(),
                            source_effect: false,
                        },
                        WordPart::Variable { spelling, .. } => {
                            let name = tcl_compiler::value_shapes::whole_word_scalar_var_name(
                                spelling, config,
                            )
                            .ok_or(ClosedSourceRefusal::Source)?;
                            Value {
                                text: self
                                    .scalars
                                    .get(name)
                                    .ok_or(ClosedSourceRefusal::Source)?
                                    .clone(),
                                source_effect: false,
                            }
                        }
                        WordPart::CommandSubstitution { spelling, .. } => {
                            self.bracket(spelling, None, None, depth)?
                        }
                        _ => return Err(ClosedSourceRefusal::Source),
                    };
                    append(&mut value.text, &component.text)?;
                    value.source_effect |= component.source_effect;
                }
                Ok(value)
            }
            _ => Err(ClosedSourceRefusal::Source),
        }
    }

    fn bracket(
        &mut self,
        spelling: &str,
        child_offset: Option<usize>,
        editable: Option<Range<usize>>,
        depth: usize,
    ) -> Result<Value, ClosedSourceRefusal> {
        let text = spelling
            .strip_prefix('[')
            .and_then(|s| s.strip_suffix(']'))
            .ok_or(ClosedSourceRefusal::Source)?;
        self.script(text, child_offset, editable, depth + 1)
    }

    fn template(
        &mut self,
        text: &str,
        invocation_index: usize,
        flags: SubstFlags,
        syntax: tcl_lexer::word_parts::TemplateVariableSyntax,
        depth: usize,
    ) -> Result<Value, ClosedSourceRefusal> {
        let expected = self
            .plan
            .template_inputs()
            .get(self.next_template)
            .ok_or(ClosedSourceRefusal::Source)?;
        if expected.invocation_index != invocation_index
            || expected.text != text
            || expected.variables != flags.vars
            || expected.commands != flags.cmds
            || expected.backslashes != flags.backslashes
        {
            return Err(ClosedSourceRefusal::Source);
        }
        self.next_template += 1;
        let config = tcl_lexer::LexerConfig::from_grammar(self.profile.grammar);
        let parts = tcl_lexer::word_parts::decompose_template_spanned(
            text.as_bytes(),
            flags,
            config,
            syntax,
        )
        .map_err(|_| ClosedSourceRefusal::Source)?;
        let mut value = Value {
            text: String::new(),
            source_effect: false,
        };
        for part in parts {
            let component = match part.part {
                TemplatePart::Text(bytes) => Value {
                    text: String::from_utf8(bytes.into_owned())
                        .map_err(|_| ClosedSourceRefusal::Source)?,
                    source_effect: false,
                },
                TemplatePart::Variable(variable) if variable.index.is_none() => {
                    let name = std::str::from_utf8(variable.name)
                        .map_err(|_| ClosedSourceRefusal::Source)?;
                    Value {
                        text: self
                            .scalars
                            .get(name)
                            .ok_or(ClosedSourceRefusal::Source)?
                            .clone(),
                        source_effect: false,
                    }
                }
                TemplatePart::Command(script) => self.script(
                    std::str::from_utf8(script).map_err(|_| ClosedSourceRefusal::Source)?,
                    None,
                    None,
                    depth + 1,
                )?,
                _ => return Err(ClosedSourceRefusal::Source),
            };
            append(&mut value.text, &component.text)?;
            value.source_effect |= component.source_effect;
        }
        Ok(value)
    }
}

fn append(output: &mut String, value: &str) -> Result<(), ClosedSourceRefusal> {
    if !value.is_ascii() || value.as_bytes().contains(&0) {
        return Err(ClosedSourceRefusal::Source);
    }
    if output
        .len()
        .checked_add(value.len())
        .is_none_or(|n| n > MAX_VALUE_BYTES)
    {
        return Err(ClosedSourceRefusal::Budget);
    }
    output.push_str(value);
    Ok(())
}

fn check_values(values: &[String]) -> Result<(), ClosedSourceRefusal> {
    if values
        .iter()
        .any(|value| !value.is_ascii() || value.as_bytes().contains(&0))
    {
        return Err(ClosedSourceRefusal::Source);
    }
    if values
        .iter()
        .try_fold(0usize, |sum, value| sum.checked_add(value.len()))
        .is_none_or(|n| n > MAX_VALUE_BYTES)
    {
        return Err(ClosedSourceRefusal::Budget);
    }
    Ok(())
}

fn selected_fold(
    registry: &CommandRegistry,
    facts: &InvocationFacts,
    values: &[String],
    dialect: InvocationDialect,
) -> Option<String> {
    let spec =
        registry.get_for_surface(&facts.canonical_command, Some(dialect.authoring_query()?))?;
    let arguments = values
        .get(facts.argument_offset..)?
        .iter()
        .map(String::as_str)
        .collect::<Vec<_>>();
    if spec.subcommands.is_empty() {
        spec.run_const_fold_in(&arguments, dialect)
    } else {
        spec.subcommand(facts.subcommand.canonical_name()?)?
            .run_const_fold_in(&arguments, dialect)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    // This exercises the conditional value model only. It neither constructs
    // a scope nor invokes an installed pack evaluator or reports hook counts.
    fn prediction(source: &str) -> Result<Evaluation, ClosedSourceRefusal> {
        let profile = tcl_registry::model::ingress::resolve_environment("tcl9.1").unit_profile();
        let registry = tcl_registry::model::static_context_for("tcl9.1").commands();
        let plan = super::super::application_plan::inventory_application_source(
            source, registry, profile,
        )?;
        ValueFlow::new(&plan, registry, profile, false).evaluate()
    }

    #[test]
    fn conditional_model_keeps_the_complete_original_sample_transcript() {
        let source = include_str!(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/../../samples/diagnostics/W102_subst_injection/example.tcl"
        ));
        let model = prediction(source).expect("bounded source value prediction");
        assert_eq!(model.stdout, b"subst (risky): Hello, World\nsubst -nocommands: Hello, World\nstring map: Hello, World\ninjection attempt:\nINJECTED\nW102 test complete\n");
        assert!(
            model.proposals.is_empty(),
            "a canonical model did not invoke an installed hook"
        );
    }

    #[test]
    fn conditional_model_preserves_nested_output_and_assignment_order() {
        let model = prediction(
            "set value initial\ncatch {set value [puts one]; set value safe}\nputs $value",
        )
        .expect("all nested commands have supported successful value semantics");
        assert_eq!(model.stdout, b"one\nsafe\n");
        assert!(model.proposals.is_empty());
    }

    #[test]
    fn conditional_model_refuses_values_outside_its_ascii_non_nul_domain() {
        assert!(prediction("set value {café}\nputs $value").is_err());
        assert!(prediction("set value {a\0b}\nputs $value").is_err());
    }

    #[test]
    fn conditional_model_bounds_repeated_value_concatenation() {
        let source = "set value 0123456789abcdef\nset value $value$value\nset value $value$value\nset value $value$value\nset value $value$value\nset value $value$value\nset value $value$value\nset value $value$value\nset value $value$value\nset value $value$value\nputs $value";
        assert!(matches!(
            prediction(source),
            Err(ClosedSourceRefusal::Budget)
        ));
    }
}
