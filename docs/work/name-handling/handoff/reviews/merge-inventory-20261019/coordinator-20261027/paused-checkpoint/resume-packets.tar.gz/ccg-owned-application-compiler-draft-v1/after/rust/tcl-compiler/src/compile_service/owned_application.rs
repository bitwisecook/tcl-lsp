// tcl-lsp — a language server and toolchain for Tcl
// Copyright (C) 2026 James Deucker (bitwisecook)
// SPDX-License-Identifier: AGPL-3.0-or-later

//! Restricted canonical callbacks for the separately owned application VM.
//!
//! This adapter returns the actual canonical module unchanged. It neither
//! materialises literals nor runs/replays a getter or synthesises a result.
//! The existing VM owns every reached cache lookup/retirement, original source
//! getter, NativeLiteralPool action and bytecode installation. This data policy
//! is NOT a Native handler completion, a closed backend, or ordinary CU authority.

use std::cell::RefCell;
use std::rc::Rc;

use tcl_bytecode::{FunctionAsm, ModuleAsm, NativeLiteralAction, Op};
use tcl_runtime_api::native_substitution::{
    NativeSubstitutionCompilationEntry, NativeSubstitutionFlags, NativeSubstitutionTarget,
};
use tcl_runtime_api::{
    CompileError, CompileService, NativeCompilationEntry, NativeCompilationFrame,
    ScriptCommandPlan, ScriptCompileTargetBytes, SourceImage,
};

use super::BytecodeCompileService;

const MAX_BYTES: usize = 4096;
const MAX_OPERATIONS: usize = 4096;
const MAX_LITERAL_BYTES: usize = 32 * 1024;

/// Internal preparation data. Only the actual application owner may select a
/// candidate after its independent complete-source/proposal checks. This type
/// supplies no execution permission, input representation or Native world.
pub struct OwnedApplicationCompilerInputs {
    original: SourceImage,
    scripts: Vec<SourceImage>,
    templates: Vec<(SourceImage, NativeSubstitutionFlags)>,
    selected: RefCell<Option<SourceImage>>,
}

impl OwnedApplicationCompilerInputs {
    pub fn new(
        original: String,
        scripts: Vec<String>,
        templates: Vec<(String, NativeSubstitutionFlags)>,
    ) -> Result<Rc<Self>, CompileError> {
        if original.is_empty()
            || original.len() > MAX_BYTES
            || scripts.len() > 64
            || templates.len() > 128
            || scripts.iter().any(|source| source.len() > MAX_BYTES)
            || templates.iter().any(|(source, _)| source.len() > MAX_BYTES)
        {
            return Err(unsupported());
        }
        Ok(Rc::new(Self {
            original: SourceImage::native(original.as_bytes()),
            scripts: scripts
                .into_iter()
                .map(|s| SourceImage::native(s.as_bytes()))
                .collect(),
            templates: templates
                .into_iter()
                .map(|(s, flags)| (SourceImage::native(s.as_bytes()), flags))
                .collect(),
            selected: RefCell::new(None),
        }))
    }

    /// Records data only. Full candidate/source/site/value equivalence must be
    /// checked by the live backend before this is called; it cannot mint scope.
    pub fn select_candidate(&self, source: &str) -> Result<(), CompileError> {
        if source.is_empty() || source.len() > MAX_BYTES {
            return Err(unsupported());
        }
        *self.selected.try_borrow_mut().map_err(|_| unsupported())? =
            Some(SourceImage::native(source.as_bytes()));
        Ok(())
    }

    fn accepts_script(&self, source: &SourceImage) -> bool {
        source == &self.original
            || self.scripts.contains(source)
            || self
                .selected
                .try_borrow()
                .is_ok_and(|selected| selected.as_ref() == Some(source))
    }
}

/// Actual fixed canonical provider; callers cannot supply a CompileService,
/// registry callable, VM, Host or Native object to this constructor.
#[derive(Clone)]
pub struct OwnedApplicationCompileService {
    canonical: Rc<BytecodeCompileService>,
    inputs: Rc<OwnedApplicationCompilerInputs>,
    interpreter: tcl_runtime_api::native_compilation::NativeInterpreterIdentity,
    profile: &'static tcl_dialect::DialectProfile,
}

impl OwnedApplicationCompileService {
    pub fn new(
        inputs: Rc<OwnedApplicationCompilerInputs>,
        interpreter: tcl_runtime_api::native_compilation::NativeInterpreterIdentity,
    ) -> Result<Self, CompileError> {
        let profile = tcl_registry::model::ingress::resolve_known_environment("tcl9.1")
            .and_then(|environment| environment.catalogue_profile())
            .ok_or_else(unsupported)?;
        let registry = tcl_registry::CommandRegistry::build_default().project_for_profile(profile);
        Ok(Self {
            canonical: Rc::new(BytecodeCompileService::new(registry)),
            inputs,
            interpreter,
            profile,
        })
    }

    /// Check root selection data only; this does not compile or issue authority.
    pub fn validate_root_selection(&self, source: &str) -> Result<(), CompileError> {
        let image = SourceImage::native(source.as_bytes());
        if image == self.inputs.original
            || self
                .inputs
                .selected
                .try_borrow()
                .map_err(|_| unsupported())?
                .as_ref()
                == Some(&image)
        {
            Ok(())
        } else {
            Err(unsupported())
        }
    }

    /// Prepare an actual canonical root module without materialising its object
    /// array. The enclosing actual VM checks entry currency again before use.
    pub fn prepare_root(
        &self,
        source: &str,
        entry: &NativeCompilationEntry,
    ) -> Result<OwnedApplicationModule, CompileError> {
        let image = SourceImage::native(source.as_bytes());
        if &image != &self.inputs.original
            && self
                .inputs
                .selected
                .try_borrow()
                .map_err(|_| unsupported())?
                .as_ref()
                != Some(&image)
        {
            return Err(unsupported());
        }
        let namespace = tcl_runtime_api::ByteNamespacePath::root();
        let module = self.compile_plain_script_bytes_with_entry(
            ScriptCompileTargetBytes {
                source: &image,
                namespace: &namespace,
            },
            self.profile,
            entry,
        )?;
        Ok(OwnedApplicationModule { module })
    }

    fn entry_matches(
        &self,
        entry: &NativeCompilationEntry,
        profile: &'static tcl_dialect::DialectProfile,
    ) -> bool {
        entry.interpreter == self.interpreter
            && entry.profile == self.profile.cache_key()
            && profile.cache_key() == self.profile.cache_key()
            && entry.frame == NativeCompilationFrame::Global
            && entry.compiled_local_layout.is_none()
            && entry
                .namespaces
                .iter()
                .filter(|namespace| {
                    namespace.token == entry.current_namespace && namespace.path.is_root()
                })
                .count()
                == 1
    }

    fn script_matches(
        &self,
        target: ScriptCompileTargetBytes<'_>,
        profile: &'static tcl_dialect::DialectProfile,
        entry: &NativeCompilationEntry,
    ) -> bool {
        target.namespace.is_root()
            && self.entry_matches(entry, profile)
            && self.inputs.accepts_script(target.source)
    }

    fn checked(
        &self,
        module: ModuleAsm,
        source: &SourceImage,
        entry: &NativeCompilationEntry,
        plain: bool,
    ) -> Result<ModuleAsm, CompileError> {
        if &module.source != source
            || module.profile.cache_key() != self.profile.cache_key()
            || !module.source_namespace.is_root()
            || module.plain_command_dispatch != plain
            || !module.procedures.is_empty()
            || !module.procedure_provenance.is_empty()
        {
            return Err(unsupported());
        }
        check_function(&module.top_level, entry, plain)?;
        check_function(&module.top_level_body, entry, plain)?;
        // All literal/action/cache/prerequisite metadata is retained, not
        // flattened into bytes or relabelled as an ordinary plain module.
        Ok(module)
    }
}

impl CompileService for OwnedApplicationCompileService {
    type Module = ModuleAsm;

    fn compile(&self, _source: &str) -> Result<ModuleAsm, CompileError> {
        Err(unsupported())
    }

    fn compile_plain_script_bytes_with_entry(
        &self,
        target: ScriptCompileTargetBytes<'_>,
        profile: &'static tcl_dialect::DialectProfile,
        entry: &NativeCompilationEntry,
    ) -> Result<ModuleAsm, CompileError> {
        if !self.script_matches(target, profile, entry) {
            return Err(unsupported());
        }
        let module = self
            .canonical
            .compile_plain_script_bytes_with_entry(target, profile, entry)?;
        self.checked(module, target.source, entry, true)
    }

    fn compile_script_bytes_with_entry(
        &self,
        target: ScriptCompileTargetBytes<'_>,
        profile: &'static tcl_dialect::DialectProfile,
        entry: &NativeCompilationEntry,
    ) -> Result<ModuleAsm, CompileError> {
        if !self.script_matches(target, profile, entry) {
            return Err(unsupported());
        }
        let module = self
            .canonical
            .compile_script_bytes_with_entry(target, profile, entry)?;
        self.checked(module, target.source, entry, false)
    }

    fn script_command_plan_bytes_with_entry(
        &self,
        source: &SourceImage,
        profile: &'static tcl_dialect::DialectProfile,
        entry: &NativeCompilationEntry,
    ) -> Result<ScriptCommandPlan, CompileError> {
        if !self.inputs.accepts_script(source) || !self.entry_matches(entry, profile) {
            return Err(unsupported());
        }
        self.canonical
            .script_command_plan_bytes_with_entry(source, profile, entry)
    }

    fn compile_substitution_with_entry(
        &self,
        target: NativeSubstitutionTarget<'_>,
        profile: &'static tcl_dialect::DialectProfile,
        entry: NativeSubstitutionCompilationEntry<'_>,
    ) -> Result<ModuleAsm, CompileError> {
        if !target.namespace.is_root()
            || !self.entry_matches(entry.snapshot(), profile)
            || !self
                .inputs
                .templates
                .iter()
                .any(|(source, flags)| source == target.source && *flags == entry.flags())
        {
            return Err(unsupported());
        }
        let module = self
            .canonical
            .compile_substitution_with_entry(target, profile, entry)?;
        self.checked(module, target.source, entry.snapshot(), false)
    }
}

/// Only the canonical bounded module check, not Native input/effect authority.
/// No constructor is public; all executable and cache metadata stays original.
pub struct OwnedApplicationModule {
    module: ModuleAsm,
}
impl OwnedApplicationModule {
    pub fn module(&self) -> &ModuleAsm {
        &self.module
    }
}

fn check_function(
    function: &FunctionAsm,
    entry: &NativeCompilationEntry,
    plain: bool,
) -> Result<(), CompileError> {
    // No rest pattern: changes to executable function metadata require review.
    let FunctionAsm {
        name: _,
        native_compilation_failure: _,
        native_compilation_preflight: _,
        native_math_table_prerequisite: _,
        native_compiler_prerequisites: _,
        required_compiled_local_layout: _,
        literals: _,
        lvt: _,
        instructions: _,
        labels: _,
        loop_targets: _,
        body_base_line: _,
        proc_body_src: _,
        error_regions: _,
        plain_command_dispatch: _,
        command_bindings: _,
        procedure_bindings: _,
        site_claims: _,
    } = function;
    if function.native_compilation_failure.is_some()
        || function.validate_native_compilation_entry().is_err()
        || function.required_compiled_local_layout.is_some()
        || !function.procedure_bindings.is_empty()
        || !function.site_claims.is_empty()
        || !function.loop_targets.is_empty()
        || function.instructions.len() > MAX_OPERATIONS
        || function.plain_command_dispatch != plain && !function.instructions.is_empty()
    {
        return Err(unsupported());
    }
    check_literals(&function.literals, entry)?;
    // A nonverbatim PUSH can enter substitution through the executor even
    // though PUSH itself appears inert. This first domain refuses that path;
    // it never infers nested source/site/flags from opcode spelling alone.
    for instruction in &function.instructions {
        // All fields are accounted for explicitly. Provenance is retained on
        // the unchanged canonical module and consumed by the actual VM; the
        // executable auxiliary fields below are independently refused.
        let tcl_bytecode::Instruction {
            op: _,
            operands: _,
            comment: _,
            offset: _,
            jump_table: _,
            native_switch_bytes: _,
            native_switch_integers: _,
            native_switch_version: _,
            native_string_index_purpose: _,
            native_fixed_math_call: _,
            no_fold: _,
            source_line: _,
            source_value_line: _,
            source_cmd_text: _,
            error_stack_context: _,
            error_info_command: _,
            error_origin: _,
            source_command_namespace: _,
            source_command_namespace_context: _,
            source_command_boundary: _,
            completion_option_scope: _,
            source_span: _,
            foreach_vars: _,
            native_each: _,
            native_list_index: _,
            native_list_range: _,
            native_list_insertion: _,
            foreach_collect: _,
            dict_vars: _,
            push_verbatim: _,
            literal_rep: _,
            evaluation: _,
            release_binding: _,
            release_hold: _,
            script_command: _,
            release_body: _,
            release_body_entry: _,
            entered_command: _,
            native_compiler_selection: _,
            native_operation_selections: _,
            catch_target: _,
            catch_start: _,
            catch_end: _,
            release_compiled: _,
        } = instruction;
        if !matches!(
            instruction.op,
            Op::NOP
                | Op::PUSH1
                | Op::PUSH4
                | Op::POP
                | Op::DUP
                | Op::LOAD_STK
                | Op::LOAD_SCALAR_STK
                | Op::LOAD_SCALAR1
                | Op::LOAD_SCALAR4
                | Op::INVOKE_STK1
                | Op::INVOKE_STK4
                | Op::DONE
                | Op::START_CMD
                | Op::STR_CONCAT1
                | Op::BEGIN_CATCH4
                | Op::END_CATCH
                | Op::PUSH_RETURN_OPTS
                | Op::PUSH_RESULT
                | Op::PUSH_RETURN_CODE
                | Op::RETURN_CODE_BRANCH
                | Op::RETURN_STK
                | Op::RETURN_IMM
                | Op::REVERSE
                | Op::JUMP1
                | Op::JUMP4
        ) || (matches!(instruction.op, Op::PUSH1 | Op::PUSH4) && !instruction.push_verbatim)
            || instruction.jump_table.is_some()
            || instruction.native_switch_bytes.is_some()
            || instruction.native_switch_integers.is_some()
            || instruction.native_switch_version.is_some()
            || instruction.native_fixed_math_call.is_some()
            || instruction.foreach_vars.is_some()
            || instruction.native_each.is_some()
            || instruction.foreach_collect
            || instruction.dict_vars.is_some()
            || instruction.native_string_index_purpose.is_some()
            || instruction.native_list_index.is_some()
            || instruction.native_list_range.is_some()
            || instruction.native_list_insertion.is_some()
        {
            return Err(unsupported());
        }
    }
    Ok(())
}

fn check_literals(
    table: &tcl_bytecode::LiteralTable,
    entry: &NativeCompilationEntry,
) -> Result<(), CompileError> {
    use tcl_bytecode::NativeLiteralAllocation as Allocation;
    if table.len() > 512
        || table.native_actions().len() > 2048
        || !table.discarded_native_passes().is_empty()
        || table.compiler_replay_environment().is_some()
    {
        return Err(unsupported());
    }
    let mut bytes = 0usize;
    for literal in table.entries() {
        let payload = literal.byte_payload().ok_or_else(unsupported)?;
        bytes = bytes
            .checked_add(payload.len())
            .filter(|count| *count <= MAX_LITERAL_BYTES)
            .ok_or_else(unsupported)?;
        match literal.allocation() {
            Allocation::RegisteredData | Allocation::Unshared | Allocation::PrivateConcatString => {
            }
            Allocation::RegisteredNativeCommand { context, .. }
                if context.interpreter == entry.interpreter
                    && context.entry_epoch == entry.epoch
                    && entry
                        .namespaces
                        .iter()
                        .filter(|n| {
                            n.token == context.namespace_token && n.path == context.namespace_path
                        })
                        .count()
                        == 1 => {}
            _ => return Err(unsupported()),
        }
    }
    let mut next = 0usize;
    let mut hidden = vec![false; table.len()];
    for action in table.native_actions() {
        match action {
            NativeLiteralAction::Register(index) if *index == next && next < table.len() => {
                next += 1;
            }
            NativeLiteralAction::PrimeCommandName { index, receipt }
                if *index < next && !hidden[*index] && receipt.matches_entry(entry) => {}
            NativeLiteralAction::Hide(index) if *index < next && !hidden[*index] => {
                hidden[*index] = true;
            }
            _ => return Err(unsupported()),
        }
    }
    if next != table.len() {
        return Err(unsupported());
    }
    Ok(())
}

fn unsupported() -> CompileError {
    CompileError::Unsupported("private application compiler footprint is unavailable".into())
}
