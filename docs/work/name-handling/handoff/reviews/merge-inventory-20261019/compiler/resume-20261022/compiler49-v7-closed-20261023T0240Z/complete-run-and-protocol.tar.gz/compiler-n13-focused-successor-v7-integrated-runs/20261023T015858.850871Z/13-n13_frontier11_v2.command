/workspace/naming-migration-active/tcl-lsp/target/debug/deps/tcl_compiler-ef22ef87d0bd65a7 registry_invocation::source_structure::source_load::frontier::controls:: --nocapture --test-threads=1
