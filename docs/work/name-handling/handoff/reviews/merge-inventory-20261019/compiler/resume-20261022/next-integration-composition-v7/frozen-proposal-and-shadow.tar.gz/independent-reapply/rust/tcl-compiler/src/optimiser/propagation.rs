// tcl-lsp — a language server and toolchain for Tcl
// Copyright (C) 2026 James Deucker (bitwisecook) <https://github.com/bitwisecook>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.
//
// SPDX-License-Identifier: AGPL-3.0-or-later

//! Constant / copy propagation optimiser pass.
//!
//! Entry points:
//!
//! - **`optimise_constant_var_refs`** (`O100`) — replace a
//!   single-token `$var` call argument with its SCCP-proved
//!   literal, when the value is safe to inline as a bare word.
//! - **`optimise_static_proc_calls`** (`O103`) — fold calls to
//!   pure procs whose return is a proven constant
//!   (`can_fold_static_calls`). Fires
//!   applicable rewrites when the call appears as a `[proc …]`
//!   command substitution inside another call's argv (the argv
//!   span is the rewrite target); the bare statement form stays
//!   hint-only because the call result is discarded and folding
//!   `::answer` to `42` would leave an invalid command name.
//! - **`optimise_return_terminator`** (`O100`) — rewrite
//!   `return $v` as `return K` when `v` is SCCP-constant.
//!   (`O104` is reserved by the canonical optimisation-codes
//!   table for the string-build chain fold, so this path uses
//!   `O100`.)
//!
//! - **`optimise_string_interpolation_var_refs`** (`O100`) —
//!   inline SCCP-proved constants into `"…$x…"` double-quoted
//!   string arguments of calls (only when the interpolation is
//!   safe: the string contains no other substitutions, the
//!   constant value contains no Tcl metacharacters).
//! - **`optimise_load_forwarding`** (`O102`) — forward the
//!   single-reaching literal value of a variable at a use site,
//!   even when SCCP didn't fold it (e.g., when another path
//!   through the CFG makes the lattice Overdefined, but this
//!   particular use is dominated by one literal def). Fires
//!   applicable rewrites with argv-level spans when the use is
//!   a bare `$var` / `${var}` word in a `Statement::Call`; falls
//!   back to hint-only on statements without `CommandTokens` or
//!   on uses inside interpolated strings (the latter covered by
//!   the O100 string-interpolation path).
//!
//! Constant propagation into the condition sub-expressions of
//! `if` / `while` / `for` and the bodies of standalone `expr`
//! commands is handled elsewhere:
//! `branch_folding::propagate_into_branches` (for branch
//! conditions) and [`super::expr_simplify::run`] (for standalone
//! `expr` commands).

use crate::analyses::{ConstValue, LatticeValue};
use crate::compilation_unit::{CompilationUnit, FunctionUnit};
use crate::interprocedural::ConstantReturn;
use crate::ir::{CommandTokens, Script, Statement};
use crate::tcl_expr_eval::FoldPolicy;
use tcl_core_types::DiagCode;
use tcl_registry::CommandRegistry;

use super::helpers::expr_simplify::{NumericCtx, operand_types};
use super::helpers::literals::is_safe_word;
use super::helpers::spans::{
    line_delete_span, original_quoted_word_rewrite_span, original_statement_rewrite_span,
};
use super::{Optimisation, PassContext};
use tcl_syntax::naming::whole_scalar_variable_reference_name;

// Off-tree diagnostic only: exact original row24, enabled explicitly.
macro_rules! ccg_row24_trace {
    ($ctx:expr, $($arg:tt)*) => {
        #[cfg(debug_assertions)]
        if std::env::var_os("TCL_LSP_TRACE_CCG_ROW24").is_some()
            && $ctx.source == "set x 1\nputs [expr {$x + 1}]\nputs $x\n"
        {
            eprintln!($($arg)*);
        }
    };
}

/// Run the propagation pass across every function.
///
/// Emits one `O100` per single-token `$var` argument that SCCP
/// proved to be a safe literal value. "Safe" means the value
/// parses as a decimal integer or as a bare identifier-shaped
/// word; string literals with Tcl metacharacters (`$`, `[`, `\`,
/// …) are skipped because substituting them as a bare word
/// would change the command's interpretation.
macro_rules! n17_live_trace {
    ($($arg:tt)*) => {
        #[cfg(debug_assertions)]
        if std::env::var("TCL_LSP_TRACE_N17_FOLD").as_deref() == Ok("first-gate-v1") {
            eprintln!("N17G_LIVE {}", format_args!($($arg)*));
        }
    };
}

macro_rules! n17_live_some {
    ($value:expr, $gate:literal) => {{
        let value = $value;
        n17_live_trace!("gate={} present={}", $gate, value.is_some());
        value
    }};
}

pub fn run(ctx: &mut PassContext<'_>, cu: &CompilationUnit) {
    ccg_row24_trace!(ctx, "CCG24 stage=pass-enter");
    n17_live_trace!("propagation-entry procedures={}", cu.procedures.len());
    run_oo_method_folds(ctx, cu);
    // The top-level body's extra escaping set (names some other procedure
    // declares `global`) — shared by the top-level constants projection
    // below and by `run_load_forwarding`.
    //
    // `scan_module_global_names` resolves the `global` alias grammar through
    // the registry, so it answers only for the dialect `cu` was lowered
    // under — and a *missing* name is the unsound direction here: it tells
    // the top level a name does not escape, licensing a fold of a value some
    // other procedure reassigns through `global`. So this deliberately has no
    // default-dialect fallback: with no registry the top-level body is left
    // un-propagated rather than propagated against a guess.
    //
    // Every production entry point does set `ctx.registry` —
    // `super::manager::build_pass_context` is the single chokepoint every
    // `optimise*` / `find_dead_stores` entry builds through — so this `None`
    // arm is reachable only from a hand-built `PassContext` in a pass-level
    // unit test, and a test that wants top-level coverage wires the registry
    // the way this pass's own `run_pass` helper does.
    let top_level_extra_escaping = ctx.registry.map(|registry| {
        crate::var_observability::scan_module_global_names(&cu.ir_module, registry)
    });
    let no_extra_escaping = std::collections::HashSet::new();
    if let Some(top_level_extra_escaping) = &top_level_extra_escaping {
        run_function(
            ctx,
            cu,
            &cu.top_level,
            &cu.ir_module.top_level,
            "::",
            top_level_extra_escaping,
        );
    }
    for (qname, fu) in &cu.procedures {
        let Some(proc) = cu.ir_module.procedures.get(qname) else {
            n17_live_trace!("decline=propagation-procedure-missing name={qname}");
            continue;
        };
        // The call-site namespace for O103 chain resolution is the proc's
        // own namespace (`::ns::foo` resolves a bare `bar` against `::ns`).
        let Some(namespace) = proc
            .body
            .namespace_context
            .as_deref()
            .and_then(crate::command_binding::SourceNamespaceKey::advisory_key)
        else {
            n17_live_trace!("decline=propagation-namespace name={qname}");
            continue;
        };
        n17_live_trace!("propagation-procedure name={qname} namespace={namespace}");
        run_function(ctx, cu, fu, &proc.body, &namespace, &no_extra_escaping);
    }
    // Load-forwarding runs a separate per-function pass on top
    // of the SCCP-based substitutions. It consults the def-use
    // chains directly and fires independently of the SCCP
    // lattice — a variable whose *sole* reaching def is a
    // literal Assign is forwarded even when other paths make
    // the lattice Overdefined. Being independent of the SCCP lattice, it
    // must apply the *same* externally-mutable guard SCCP applies itself
    // (`global`/`variable`/`upvar`/`trace` aliasing, plus — for the
    // top-level body specifically — any name some other procedure declares
    // via `global`; see `scan_module_global_names`, and, for every function,
    // a name traced by some *other* proc, via the registry-driven whole-
    // module `Module::traced_variables`/`has_dynamic_variable_trace` facts),
    // or it would forward a stale literal past a call that reassigns or
    // traces the "sole" def.
    if let (Some(registry), Some(top_level_extra_escaping)) =
        (ctx.registry, &top_level_extra_escaping)
    {
        let trace = crate::sccp::TraceInputs {
            registry,
            source_metadata_input:
                crate::registry_invocation::InvocationMetadataContext::for_module(
                    registry,
                    &cu.ir_module,
                )
                .and_then(
                    crate::registry_invocation::InvocationMetadataContext::source_analysis_input,
                ),
            traced_variables: &cu.ir_module.traced_variables,
            has_dynamic_variable_trace: cu.ir_module.has_dynamic_variable_trace,
            deferred_writes: &cu.ir_module.deferred_writes,
            analysis_context: None,
            existence: None,
        };
        run_load_forwarding(
            ctx,
            &cu.ir_module,
            &cu.top_level,
            top_level_extra_escaping,
            trace,
        );
        for fu in cu.procedures.values() {
            run_load_forwarding(ctx, &cu.ir_module, fu, &no_extra_escaping, trace);
        }
    }
    // O127 store-to-load forwarding for *computed* single-use
    // assignments (`set x [cmd]` inlined to its sole use site, then the
    // store deleted).  Skips the top-level body.
    for fu in cu.procedures.values() {
        run_store_to_load_forwarding(ctx, fu);
    }
}

/// Whether `stmt`, if it appears between a `O127` store-to-load
/// forwarding candidate's definition and use, must block the forward:
/// moving the definition's *computed* side-effecting value (a command
/// substitution) later, past `stmt`, could reorder its observable effects
/// relative to `stmt`'s own — a barrier (`eval`/`uplevel`/`interp eval`/…),
/// a frame-crossing `uplevel`/`upvar` body, a call the registry cannot
/// prove pure (including every call to a proc, since an unregistered name
/// classifies as an unknown write — see
/// `side_effects::fallback_unknown_write`), or an assignment whose value
/// itself runs a command substitution.
///
/// Used only by the `O127` store-to-load `intervening_is_safe` gate.
/// `O102`'s plain-variable load-forwarding ([`run_load_forwarding`]) does
/// *not* need this: it never moves a side-effecting computation, only a
/// literal value, and a plain proc-local variable cannot be rewritten by
/// an intervening call at all without an alias/trace/barrier — each of
/// which `run_load_forwarding` already checks directly (see its own doc
/// comment).
fn statement_may_have_untracked_effects(
    stmt: &Statement,
    registry: &tcl_registry::CommandRegistry,
    metadata: Option<crate::registry_invocation::InvocationMetadataContext<'_>>,
    traced: &std::collections::BTreeSet<String>,
    has_dynamic_trace: bool,
) -> bool {
    use super::helpers::expr_simplify::expr_has_command_subst;
    use crate::gvn::is_pure_tokens_with_metadata_context;

    match stmt {
        Statement::Barrier { .. } | Statement::NativeCall { .. } | Statement::UpFrame { .. } => {
            true
        }
        Statement::AssignValue { value, .. } => value.contains('['),
        Statement::AssignExpr { expr, .. } => expr_has_command_subst(expr),
        Statement::Call { tokens, .. } => !tokens.as_ref().is_some_and(|tokens| {
            is_pure_tokens_with_metadata_context(
                registry,
                metadata,
                tokens,
                traced,
                has_dynamic_trace,
            )
        }),
        _ => false,
    }
}

fn synthetic_forwarding_use(
    fu: &FunctionUnit,
    use_site: &crate::def_use::UseSite,
    index: usize,
    cell_name: &crate::var_resolve::VariableCellKey,
) -> bool {
    fu.ssa
        .blocks
        .values()
        .find(|block| block.name == use_site.block)
        .and_then(|block| block.statements.get(index))
        .is_some_and(|statement| {
            fu.ssa
                .cell_symbol(cell_name)
                .is_some_and(|symbol| statement.may_defs.contains(&symbol))
        })
}

/// Fail closed for legacy SSA without physical point receipts.
fn compatibility_def_is_external(
    fu: &FunctionUnit,
    block: crate::cfg::BlockId,
    index: usize,
    symbol: crate::ssa::Symbol,
    names: &std::collections::HashSet<String>,
    trace: crate::sccp::TraceInputs<'_>,
) -> bool {
    fu.ssa.point_contexts.is_none()
        && crate::ssa::SsaSourceView::at_statement(&fu.ssa, block, index).externally_mutable_by(
            symbol,
            names,
            trace.has_dynamic_variable_trace,
            trace.registry,
        ) != Some(false)
}

/// Forward a single reaching literal definition to each of its
/// Operand use sites. Emits `O102` ("Forward literal load") with
/// the literal text as replacement.
///
/// When the consuming statement is a `Statement::Call` with
/// [`CommandTokens`] populated, fire one applicable `O102` per
/// argv entry whose text is `$var` / `${var}` matching the
/// defined variable — the argv span is the precise rewrite
/// target. Fall back to a hint-only diagnostic covering the whole
/// consuming statement when no `CommandTokens` are present or the
/// use is on a non-Call statement (where we still don't have
/// per-operand spans).
///
/// Production rewrites require the exact retained reference to name the same
/// physical binding and represented SSA contents version as the definition.
/// Unrepresented callee writes, retargeting and observers withdraw that proof.
/// Whole-function alias and barrier scans remain compatibility gates only for
/// SSA fixtures without point contexts.
/// Safety gates layer two independent alias/trace facts plus one
/// intervening-effect scan, each catching cases the other misses. A plain
/// proc-local variable that is never `global`/`variable`/`upvar`/`trace`
/// declared anywhere in the module cannot be touched by an intervening
/// call to *any* other proc — Tcl's frame-based scoping gives a callee no
/// way to reach a caller's private local without one of those four
/// mechanisms — so, unlike an earlier revision of this pass, an ordinary
/// intervening call does *not* gate the forward on its own (see
/// `o102_still_forwards_top_level_global_no_proc_touches` and
/// `o102_still_forwards_genuinely_local_proc_variable`, which lock this
/// precision in):
///
/// - `escaping` (this function's own [`analyse_var_observability`] plus
///   `extra_escaping` — the top-level's
///   [`crate::var_observability::scan_module_global_names`] result, or an
///   empty set for an ordinary procedure — plus `trace.traced_variables`,
///   the registry-driven whole-module [`crate::ir::Module::traced_variables`]
///   fact, and the names a callback script writes,
///   [`crate::ir::Module::deferred_writes`]) via
///   [`crate::sccp::is_externally_mutable`] — the same guard SCCP
///   applies to its own lattice, so O102 (independent of the SCCP lattice)
///   stays consistent with it.
/// - [`has_intervening_barrier`] — a `Statement::Barrier`/`UpFrame`
///   (a literal-body `uplevel`/`interp eval`, which *can* reach into an
///   arbitrary frame) between def and use, checked both same-block
///   (precisely) and cross-block (conservatively).
fn run_load_forwarding(
    ctx: &mut PassContext<'_>,
    module: &crate::ir::Module,
    fu: &crate::compilation_unit::FunctionUnit,
    extra_escaping: &std::collections::HashSet<String>,
    trace: crate::sccp::TraceInputs<'_>,
) {
    use crate::def_use::{DefKind, UseKind};

    if fu.cfg.has_opaque_native_accesses() {
        return;
    }

    // Compatibility SSA lacks the physical reference proof used below.
    if fu.ssa.point_contexts.is_none() && fu.dynamic_barrier_blocks_value_motion() {
        return;
    }

    let Some((trace, escaping)) = load_forwarding_escaping(module, fu, extra_escaping, trace)
    else {
        return;
    };

    for chain in fu.def_use.chains.values() {
        if chain.definition.kind != DefKind::Statement {
            continue;
        }
        let cell_name = &chain.key.0;
        let Some(symbol) = fu.def_use.symbol(&fu.ssa, *cell_name) else {
            continue;
        };
        let Some(cell_name) = fu.ssa.cell_key(symbol) else {
            continue;
        };
        let (Some(block_id), Ok(idx)) = (
            fu.cfg.block_id(&chain.definition.block),
            usize::try_from(chain.definition.statement_index),
        ) else {
            continue;
        };
        let var_name = fu.ssa.var_name(symbol);
        if compatibility_def_is_external(fu, block_id, idx, symbol, &escaping, trace) {
            continue;
        }
        // A synthetic may-def (the element fan of a dynamic-key write, or a
        // base refresh) is not a real reaching definition — forwarding its
        // statement's value would forward the *other* element's literal.
        if fu.ssa.is_synthetic_def(
            &chain.definition.block,
            chain.definition.statement_index,
            cell_name,
        ) {
            continue;
        }
        // Find the defining statement — must be an AssignConst
        // with a literal value to forward. AssignValue without
        // substitutions could also work, but we're conservative
        // and restrict to the same shapes.
        let Some(block) = fu.cfg.block_by_name(&chain.definition.block) else {
            continue;
        };
        let Some(def_stmt) = block.statements.get(idx) else {
            continue;
        };
        // Which code claims the rewrite follows from *why* the value is known,
        // and the two contracts are different: O102 forwards a variable whose
        // single reaching definition is written out as a literal, O100 inlines
        // a constant SCCP proved. `set a 1; incr a` is the second — the
        // defining statement computes its value — so it is folded, not
        // forwarded.
        let Some((code, literal)) =
            forwarding_literal(fu, def_stmt, cell_name, chain.key.1, ctx.fold_policy())
        else {
            continue;
        };
        if !is_value_safe_bare_word(&literal) {
            continue;
        }
        let message = load_forward_message(code, var_name);
        for use_site in &chain.uses {
            if use_site.kind != UseKind::Operand {
                continue;
            }
            let Ok(use_idx) = usize::try_from(use_site.statement_index) else {
                continue;
            };
            let Some(use_block) = fu.cfg.block_by_name(&use_site.block) else {
                continue;
            };
            let Some(use_stmt) = use_block.statements.get(use_idx) else {
                continue;
            };
            // A fanned may-def's prior-version read is a synthetic use —
            // there is no `$var` in that statement to rewrite.
            if synthetic_forwarding_use(fu, use_site, use_idx, cell_name) {
                continue;
            }
            if fu.ssa.point_contexts.is_none()
                && has_intervening_barrier(
                    fu,
                    &chain.definition.block,
                    idx,
                    &use_site.block,
                    use_idx,
                )
            {
                continue;
            }
            let Some(use_block_id) = fu.cfg.block_id(&use_site.block) else {
                continue;
            };
            report_load_forward(
                ctx,
                fu,
                (use_block_id, use_idx),
                use_stmt,
                LoadForwardReport {
                    code,
                    symbol,
                    version: chain.key.1,
                    message: &message,
                    literal: &literal,
                },
            );
        }
    }
}

fn load_forward_message(code: DiagCode, var_name: &str) -> String {
    if code == DiagCode::O102 {
        format!("Forward literal load of '{var_name}' from its single reaching definition")
    } else {
        format!("Inline the constant value of '{var_name}' proved at this read")
    }
}

fn load_forwarding_escaping<'a>(
    module: &'a crate::ir::Module,
    fu: &'a FunctionUnit,
    extra_escaping: &std::collections::HashSet<String>,
    trace: crate::sccp::TraceInputs<'a>,
) -> Option<(
    crate::sccp::TraceInputs<'a>,
    std::collections::HashSet<String>,
)> {
    // Independent of the SCCP lattice (see the doc comment on the call
    // site in `run`), this pass must apply the same externally-mutable
    // guard SCCP applies to its own lattice — a `global`/`variable`/
    // `upvar`/`trace`-aliased name's "sole reaching def" is not actually
    // sole: some other call frame can reassign it between the def and a
    // later use.
    let metadata = fu.invocation_metadata_context_for_module(trace.registry, module)?;
    let trace = crate::sccp::TraceInputs {
        source_metadata_input: metadata.source_analysis_input(),
        ..trace
    };
    let mut escaping = crate::var_observability::analyse_var_observability_with_metadata_context(
        &fu.cfg,
        trace.registry,
        Some(metadata),
    )
    .escaping_var_names();
    escaping.extend(extra_escaping.iter().cloned());
    trace.extend_module_escaping(&mut escaping);

    Some((trace, escaping))
}

fn forwarding_literal(
    fu: &crate::compilation_unit::FunctionUnit,
    def_stmt: &Statement,
    cell_name: &crate::var_resolve::VariableCellKey,
    version: crate::ssa::Version,
    policy: FoldPolicy,
) -> Option<(DiagCode, String)> {
    Some(match def_stmt {
        Statement::AssignConst { value, .. } => (DiagCode::O102, value.clone()),
        Statement::AssignValue { value, .. }
            if !value.contains(['$', '[', '\\', '"']) && !value.is_empty() =>
        {
            (DiagCode::O102, value.clone())
        }
        // The name-keyed projection `sccp_constants_for` the other O100
        // forms read cannot answer here: it drops any variable whose
        // versions hold different constants, which is every variable that
        // is ever reassigned — precisely this shape. A def-use consumer
        // already knows which version it is inlining, so it can index the
        // lattice by `(symbol, version)` and get an answer where the
        // name-keyed map has none. Every guard above this point still
        // applies.
        _ => (
            DiagCode::O100,
            sccp_value_literal(fu, cell_name, version, policy)?,
        ),
    })
}

/// True when an opaque effect — a `Statement::Barrier` or `Statement::UpFrame`
/// (the CFG shape for a literal-body `uplevel`/`interp eval`) — could run
/// between `def_block[def_idx]` and `use_block[use_idx]`, making a "sole
/// reaching definition" forward unsound: `uplevel 1 {…}` / `uplevel #0 {…}`
/// evaluates its body in a *different* frame (the caller's, or the absolute
/// global one) and can reassign any name visible there, exactly like an
/// opaque call. Independent of [`crate::ssa::SsaSourceView::externally_mutable_by`] (which
/// only catches `global`/`variable`/`upvar`/`trace`-*declared* aliasing): a
/// plain proc-local variable with no alias/trace at all can still be mutated
/// by a literal `uplevel #0 {…}` body a few lines later.
///
/// Same-block case: checked precisely (only the statements strictly between
/// the two indices). Cross-block case: conservatively checks the remainder of
/// `def_block`, the prefix of `use_block`, and — since enumerating every path
/// between two arbitrary blocks is more machinery than this cheap forwarding
/// pass warrants — every *other* block in the function; a barrier/upframe
/// anywhere else in the body blocks the forward even if it turns out to sit on
/// an unrelated branch.
fn has_intervening_barrier(
    fu: &crate::compilation_unit::FunctionUnit,
    def_block: &str,
    def_idx: usize,
    use_block: &str,
    use_idx: usize,
) -> bool {
    fn is_barrier(stmt: &Statement) -> bool {
        matches!(
            stmt,
            Statement::Barrier { .. } | Statement::NativeCall { .. } | Statement::UpFrame { .. }
        )
    }

    if def_block == use_block {
        let Some(block) = fu.cfg.block_by_name(def_block) else {
            return true; // can't verify safety — conservatively block the forward
        };
        let (lo, hi) = if def_idx <= use_idx {
            (def_idx, use_idx)
        } else {
            (use_idx, def_idx)
        };
        return block.statements[lo.saturating_add(1)..hi.min(block.statements.len())]
            .iter()
            .any(is_barrier);
    }
    let Some(def_blk) = fu.cfg.block_by_name(def_block) else {
        return true;
    };
    if def_blk.statements[(def_idx + 1).min(def_blk.statements.len())..]
        .iter()
        .any(is_barrier)
    {
        return true;
    }
    let Some(use_blk) = fu.cfg.block_by_name(use_block) else {
        return true;
    };
    if use_blk.statements[..use_idx.min(use_blk.statements.len())]
        .iter()
        .any(is_barrier)
    {
        return true;
    }
    fu.cfg
        .blocks
        .values()
        .any(|b| b.name != def_block && b.name != use_block && b.statements.iter().any(is_barrier))
}

/// Emit the `O102` rewrite(s) for one use site: a precise, applicable
/// per-argv rewrite for each bare `$var` / `${var}` word in a
/// `Statement::Call`'s tracked tokens, or a hint-only fallback covering
/// the whole consuming statement when no such word is found (the use is
/// on a non-`Call` statement, `CommandTokens` weren't captured, or the
/// read is nested inside a larger construct — e.g. an interpolated
/// string, which the O100 string-interpolation path handles instead).
#[derive(Clone, Copy)]
struct LoadForwardReport<'a> {
    code: DiagCode,
    symbol: crate::ssa::Symbol,
    version: crate::ssa::Version,
    message: &'a str,
    literal: &'a str,
}

fn report_load_forward(
    ctx: &mut PassContext<'_>,
    fu: &crate::compilation_unit::FunctionUnit,
    site: (crate::cfg::BlockId, usize),
    use_stmt: &Statement,
    report: LoadForwardReport<'_>,
) {
    if fu.cfg.statement_source_edit_span(site.0, site.1).is_none() {
        return;
    }
    let LoadForwardReport {
        code,
        symbol,
        version,
        message,
        literal,
    } = report;
    let mut emitted_applicable = false;
    if let Statement::Call {
        tokens: Some(tokens),
        ..
    } = use_stmt
    {
        for (i, argv_span) in tokens.argv.iter().enumerate() {
            let Some(word @ crate::ir::WordExpr::Variable { spelling, .. }) = tokens.words().get(i)
            else {
                continue;
            };
            // A braced word (`{$x}`) is a literal — Tcl performs no
            // substitution inside braces — so `$x` there must not be
            // forwarded. `argv_texts` has the braces stripped, so the
            // word kind is the only signal.
            if tokens.argv_kinds.get(i) == Some(&tcl_lexer::TokenType::Str) {
                continue;
            }
            let view = crate::ssa::SsaSourceView::at_statement(&fu.ssa, site.0, site.1);
            let Some(read) = view.read_word(word) else {
                continue;
            };
            if whole_scalar_variable_reference_name(spelling, fu.source_lexer_config()).is_none()
                || read.symbol != symbol
                || read.version != Some(version)
            {
                continue;
            }
            ctx.report(Optimisation::new(
                code,
                message.to_owned(),
                tcl_lexer::word_span_at(ctx.source, fu.abs_span(*argv_span)),
                literal.to_owned(),
            ));
            emitted_applicable = true;
        }
    }
    if emitted_applicable {
        return;
    }
    let view = crate::ssa::SsaSourceView::at_statement(&fu.ssa, site.0, site.1);
    if !view.source_tokens().is_some_and(|tokens| {
        tokens.variable_accesses.iter().any(|access| {
            view.read_reference(&access.source, &access.original_spelling)
                .is_some_and(|read| read.symbol == symbol && read.version == Some(version))
        })
    }) {
        return;
    }
    // No operand word was found to target, so the span is the whole consuming
    // statement — and `literal` is not a valid replacement for it. Record the
    // hint with no replacement rather than a payload that would corrupt the
    // statement if anything ever applied it: `1` recorded over the whole of
    // `incr a` reads as a one-click rewrite to a bare `1` in command position
    // wherever a surface shows the payload without the flag. The appliers
    // filter `hint_only`; this keeps the data model in agreement with them.
    let mut opt = Optimisation::new(
        code,
        message.to_owned(),
        fu.abs_span(use_stmt.span()),
        String::new(),
    );
    opt.hint_only = true;
    ctx.report(opt);
}

/// O127 — store-to-load forwarding for a *computed* single-use
/// assignment.
///
/// The O127 store-to-load-forwarding path.  When `set x [cmd]` (a command
/// substitution or a command-bearing expr) has exactly one
/// `Operand` use of `$x` later in the same block, and nothing
/// between the def and the use can change the value the expression
/// would recompute, emit a grouped rewrite: inline `[set x [cmd]]`
/// at the use site (`O127`) and delete the original store (`O127`,
/// empty replacement).
///
/// Safety gates: single operand use; same
/// executable block; use after def; the value is not SCCP-constant
/// (those are O100/O102); neither the defined name nor any name the
/// expression reads is memory-SSA aliased (upvar / global /
/// variable); no intervening barrier, side-effecting call, or
/// command-substitution assignment; no intervening redefinition of a
/// read name; and, intra-statement, no command substitution appears
/// before `$x` in the use word list unless the inlined expression
/// reads nothing.
fn run_store_to_load_forwarding(ctx: &mut PassContext<'_>, fu: &FunctionUnit) {
    use crate::memory_ssa::compute_aliases_with_metadata_context;
    use std::collections::BTreeSet;

    // Like O102, O127 moves a value across statements. A dynamic or opaque
    // variable name can change either the stored name or a name read by the
    // expression under an unseen spelling, so this whole-function rewrite
    // must honour the same fail-closed barrier.
    if fu.dynamic_barrier_blocks_value_motion() {
        return;
    }

    let Some(registry) = ctx.registry else {
        return;
    };
    let Some(context) = fu.invocation_metadata_context(registry) else {
        return;
    };

    // Names whose writes may be visible through an alias (upvar /
    // global / variable). Prefer the on-demand memory-SSA annotation;
    // fall back to a direct alias computation.
    let aliased: std::collections::HashSet<String> = match &fu.memory_ssa {
        Some(m) => m.aliased_names().into_iter().collect(),
        None => compute_aliases_with_metadata_context(&fu.ssa, registry, Some(context))
            .iter()
            .flat_map(crate::memory_ssa::AliasSet::names)
            .collect(),
    };

    // Trace context: a traced command is never pure (its write set is
    // unknown), so the intervening-effect check must see it.
    let (traced, has_dynamic_trace) = match ctx.ir_module {
        Some(m) => (m.traced_commands.clone(), m.has_dynamic_trace),
        None => (BTreeSet::new(), false),
    };

    // Source ranges already targeted by earlier passes — O127 must not
    // overlap them. Snapshot before we start emitting.
    let rewritten: Vec<(u32, u32)> = ctx
        .optimisations
        .iter()
        .map(|o| (o.span.start(), o.span.end()))
        .collect();

    // Collect emissions first; group ids + ctx pushes happen after the
    // immutable walk over `fu`.
    let env = ForwardEnv {
        ctx,
        fu,
        registry,
        context: Some(context),
        aliased: &aliased,
        traced: &traced,
        has_dynamic_trace,
        rewritten: &rewritten,
    };
    let mut pending: Vec<(Optimisation, Optimisation)> = fu
        .def_use
        .chains
        .values()
        .filter_map(|chain| forward_candidate(&env, chain))
        .collect();
    // `def_use.chains` is a `HashMap`, so the candidate order — and hence the
    // monotonic group ids allocated below — would vary run-to-run (and between
    // the offset-0 memo build and the whole-module build).  Sort on the edit
    // spans so emission order, group numbering, and the final Vec are
    // byte-identical regardless of map iteration order.
    pending.sort_by_key(|(inline, delete)| {
        (
            inline.span.start(),
            inline.span.end(),
            delete.span.start(),
            delete.span.end(),
        )
    });

    // Emit, allocating a shared group id per inline/delete pair so the
    // two edits apply all-or-nothing.
    for (mut inline, mut delete) in pending {
        let group = ctx.alloc_group();
        inline.group = Some(group);
        delete.group = Some(group);
        ctx.report(inline);
        ctx.report(delete);
    }
}

/// Read-only context threaded into [`forward_candidate`] so the
/// per-chain evaluation stays a pure function over the borrowed
/// analysis state.
struct ForwardEnv<'a> {
    ctx: &'a PassContext<'a>,
    fu: &'a FunctionUnit,
    registry: &'a tcl_registry::CommandRegistry,
    context: Option<crate::registry_invocation::InvocationMetadataContext<'a>>,
    aliased: &'a std::collections::HashSet<String>,
    traced: &'a std::collections::BTreeSet<String>,
    has_dynamic_trace: bool,
    rewritten: &'a [(u32, u32)],
}

/// Evaluate one def-use chain as an O127 store-to-load-forwarding
/// candidate, returning the `(inline, delete)` edit pair when every
/// safety gate passes (see [`run_store_to_load_forwarding`] for the
/// gate list). Returns `None` for any chain that doesn't qualify.
fn forward_candidate(
    env: &ForwardEnv<'_>,
    chain: &crate::def_use::DefUseChain,
) -> Option<(Optimisation, Optimisation)> {
    use crate::def_use::{DefKind, UseKind};
    let (ctx, fu) = (env.ctx, env.fu);

    // Exactly one *non-terminator* use, and it must be a statement operand.
    // A `return $x` / branch-condition read is a `Terminator` use; def-use
    // records those in the chain. The forward preserves the assignment
    // (`[set x …]`), and the operand use precedes the block terminator, so
    // any terminator read still sees `x` — exclude terminator uses from the
    // single-use test. (A phi use still blocks it.)
    let mut non_terminator = chain.uses.iter().filter(|u| u.kind != UseKind::Terminator);
    let use_site = non_terminator.next()?;
    if non_terminator.next().is_some() || use_site.kind != UseKind::Operand {
        return None;
    }
    let def = &chain.definition;
    if def.kind != DefKind::Statement {
        return None;
    }
    // Same executable block; use strictly after def. `def.block` /
    // `use_site.block` are block names; resolve to the shared `BlockId`
    // for the `executable_blocks` / `cfg.blocks` / `ssa.blocks` lookups.
    let def_block = fu.cfg.block_id(&def.block)?;
    if def.block != use_site.block || !fu.sccp.executable_blocks.contains(&def_block) {
        return None;
    }
    let (Ok(def_idx), Ok(use_idx)) = (
        usize::try_from(def.statement_index),
        usize::try_from(use_site.statement_index),
    ) else {
        return None;
    };
    if use_idx <= def_idx {
        return None;
    }
    fu.cfg.statement_source_edit_span(def_block, def_idx)?;
    fu.cfg.statement_source_edit_span(def_block, use_idx)?;
    let block = fu.cfg.blocks.get(&def_block)?;
    let ssa_block = fu.ssa.blocks.get(&def_block)?;
    let (def_stmt, use_stmt) = (
        block.statements.get(def_idx)?,
        block.statements.get(use_idx)?,
    );

    // The use must be a `Call` with tokens so we can pinpoint the `$x`
    // word and check intra-statement evaluation order. Tcl evaluates words
    // left-to-right before invoking the outer command. A command substitution
    // before `$x` would therefore run before the moved assignment; reject it
    // even when the RHS has no scalar reads, because it can still establish an
    // alias or reorder observable effects.
    let Statement::Call {
        tokens: Some(tokens),
        ..
    } = use_stmt
    else {
        return None;
    };
    let symbol = fu.def_use.symbol(&fu.ssa, chain.key.0)?;
    let use_source = crate::ssa::SsaSourceView::at_statement(&fu.ssa, def_block, use_idx);
    let (var_span, has_earlier_effect) = locate_use_var(
        tokens,
        use_source,
        symbol,
        chain.key.1,
        env.registry,
        fu.source_lexer_config(),
    )?;
    if has_earlier_effect {
        return None;
    }

    // An opaque outer invocation at the endpoint runs only after `$x` has
    // been substituted, so it cannot retroactively alias that read. Wildcard
    // transitions at every other statement remain a conservative blocker.
    if has_non_endpoint_wildcard_aliasing(env, def_block, use_idx) {
        return None;
    }

    // The def must be a *computed* assignment — a command substitution
    // or a command-bearing expr. Literal / constant assignments are the
    // O102 / O100 path.
    if !is_computed_assignment(def_stmt) {
        return None;
    }

    if forwarding_value_consumed(env, chain, use_site, def_idx, use_idx) {
        return None;
    }

    let def_source = crate::ssa::SsaSourceView::at_statement(&fu.ssa, def_block, def_idx);
    let def_reads = &ssa_block.statements[def_idx].uses;
    if !forwarded_cells_are_private(env, def_source, symbol, def_reads) {
        return None;
    }
    let (Statement::AssignValue { name: def_name, .. }
    | Statement::AssignExpr { name: def_name, .. }) = def_stmt
    else {
        return None;
    };

    // Intervening statements must not change the value the inlined
    // expression would recompute.
    if !intervening_is_safe(env, block, ssa_block, def_idx, use_idx, def_reads) {
        return None;
    }

    build_forward_edits(
        ctx,
        def_stmt,
        def_name,
        var_span,
        env.rewritten,
        fu.base_offset,
    )
}

fn forwarding_value_consumed(
    env: &ForwardEnv<'_>,
    chain: &crate::def_use::DefUseChain,
    use_site: &crate::def_use::UseSite,
    def_idx: usize,
    use_idx: usize,
) -> bool {
    let fu = env.fu;
    let ctx = env.ctx;
    let def = &chain.definition;
    let def_key = chain.key;
    // SCCP constants belong to O100.
    if let Some(sym) = fu.def_use.symbol(&fu.ssa, def_key.0)
        && matches!(
            fu.sccp.values.get(&(sym, def_key.1)),
            Some(LatticeValue::Const(_))
        )
        && fu.sccp.materialises((sym, def_key.1))
    {
        return true;
    }
    // Skip statements another pass already rewrote or consumed.
    let def_key_sym = fu
        .def_use
        .symbol(&fu.ssa, def_key.0)
        .map(|s| (s, def_key.1));
    if ctx
        .propagated_expr_stmts
        .contains(&(def.block.clone(), def_idx))
        || ctx
            .propagated_expr_stmts
            .contains(&(use_site.block.clone(), use_idx))
        || def_key_sym.is_some_and(|k| ctx.propagated_branch_uses.contains(&k))
    {
        return true;
    }

    false
}

/// Whether any statement other than the endpoint use has a wildcard
/// variable-cell transition obligation.
///
/// This remains deliberately flow-insensitive: a wildcard elsewhere in the
/// function suppresses O127. The sole exception is the outer endpoint
/// invocation, which Tcl runs after substituting the forwarded variable.
fn has_non_endpoint_wildcard_aliasing(
    env: &ForwardEnv<'_>,
    use_block: crate::cfg::BlockId,
    use_idx: usize,
) -> bool {
    env.fu.ssa.blocks.iter().any(|(&block_id, block)| {
        block.statements.iter().enumerate().any(|(idx, statement)| {
            (block_id != use_block || idx != use_idx)
                && crate::memory_ssa::statement_has_wildcard_aliasing_with_metadata_context(
                    &statement.statement,
                    env.registry,
                    env.context,
                )
        })
    })
}

/// Construct the grouped O127 `(inline, delete)` edits for a resolved
/// forwarding candidate, or `None` when the def span is degenerate or
/// would collide with an earlier pass's rewrite.
fn build_forward_edits(
    ctx: &PassContext<'_>,
    def_stmt: &Statement,
    def_name: &str,
    var_span: tcl_lexer::Span,
    rewritten: &[(u32, u32)],
    base_offset: i64,
) -> Option<(Optimisation, Optimisation)> {
    let source = ctx.source;
    // `def_stmt` / `var_span` come from the unit's `cfg`, so they are relative
    // to `base_offset`; absolutise before slicing `source` / comparing against
    // the (absolute) already-rewritten ranges.
    let shift = |sp: tcl_lexer::Span| -> tcl_lexer::Span {
        if base_offset == 0 {
            return sp;
        }
        let s = (i64::from(sp.start()) + base_offset).max(0);
        let e = (i64::from(sp.end()) + base_offset).max(0);
        // Clamped `>= 0`; an absolutised offset past `u32::MAX` is degenerate
        // and clamps to the max (spans are `u32` source offsets).
        tcl_lexer::Span::new(
            u32::try_from(s).unwrap_or(u32::MAX),
            u32::try_from(e).unwrap_or(u32::MAX),
        )
    };
    let def_span = shift(def_stmt.source_edit_span()?);
    let var_span = shift(var_span);
    let (ds, de) = (def_span.start(), def_span.end());
    if de as usize > source.len() || ds >= de {
        return None;
    }
    let target = tcl_lexer::word_span_at(source, var_span);
    // Don't collide with an earlier pass's rewrite (def line or use word).
    if ranges_overlap(rewritten, ds, de) || ranges_overlap(rewritten, target.start(), target.end())
    {
        return None;
    }
    // The def span follows the lexer's inner-end convention, so a value word
    // that is quoted, braced, or bracketed leaves its closer outside. Both the
    // replayed text and the deletion extent need the whole written statement,
    // or the closer is copied without its opener and dropped from its own
    // line.
    let def_span = original_statement_rewrite_span(ctx, def_span)?;
    let stmt_text = &source[def_span.start() as usize..def_span.end() as usize];
    let inline = Optimisation::new(
        DiagCode::O127,
        format!("Inline single-use variable `${def_name}`"),
        target,
        format!("[{stmt_text}]"),
    );
    let delete = Optimisation::new(
        DiagCode::O127,
        "Remove inlined assignment",
        line_delete_span(source, def_span),
        "",
    );
    Some((inline, delete))
}

/// True when `stmt` is a `set`-style assignment whose value is
/// *computed* — an `AssignValue` carrying a `[command substitution]`
/// or an `AssignExpr` whose expression contains one.  Literal
/// assignments are handled by the O100 / O102 paths instead.
fn is_computed_assignment(stmt: &Statement) -> bool {
    use super::helpers::expr_simplify::expr_has_command_subst;
    match stmt {
        Statement::AssignValue { value, .. } => value.contains('['),
        Statement::AssignExpr { expr, .. } => expr_has_command_subst(expr),
        _ => false,
    }
}

/// Check the statements strictly between `def_idx` and `use_idx` for
/// anything that could change the value the inlined expression would
/// recompute: a barrier, a side-effecting call, a
/// command-substitution assignment, or a redefinition of a name the
/// expression reads.  The trace / registry / dialect safety context is
/// carried by `env`.
fn intervening_is_safe(
    env: &ForwardEnv<'_>,
    block: &crate::cfg::Block,
    ssa_block: &crate::ssa::SsaBlock,
    def_idx: usize,
    use_idx: usize,
    def_reads: &std::collections::HashMap<crate::ssa::Symbol, crate::ssa::Version>,
) -> bool {
    for idx in (def_idx + 1)..use_idx {
        let Some(stmt) = block.statements.get(idx) else {
            break;
        };
        if statement_may_have_untracked_effects(
            stmt,
            env.registry,
            env.context,
            env.traced,
            env.has_dynamic_trace,
        ) {
            return false;
        }
        // A redefinition of an actual physical read invalidates the forward.
        if let Some(sb) = ssa_block.statements.get(idx)
            && def_reads.keys().any(|symbol| sb.defs.contains_key(symbol))
        {
            return false;
        }
    }
    true
}

/// Verify observer and alias exclusions against the definition's actual cells.
fn forwarded_cells_are_private(
    env: &ForwardEnv<'_>,
    source: crate::ssa::SsaSourceView<'_>,
    defined: crate::ssa::Symbol,
    reads: &std::collections::HashMap<crate::ssa::Symbol, crate::ssa::Version>,
) -> bool {
    source.externally_mutable_by(defined, &env.ctx.cross_event_vars, false, env.registry)
        == Some(false)
        && std::iter::once(defined)
            .chain(reads.keys().copied())
            .all(|symbol| {
                source.externally_mutable_by(symbol, env.aliased, false, env.registry)
                    == Some(false)
            })
}

/// Locate the original single-variable operand by its captured physical read.
/// Earlier opaque words or observed reads retain an evaluation-order obligation.
fn locate_use_var(
    tokens: &CommandTokens,
    source: crate::ssa::SsaSourceView<'_>,
    symbol: crate::ssa::Symbol,
    version: crate::ssa::Version,
    registry: &tcl_registry::CommandRegistry,
    config: tcl_lexer::LexerConfig,
) -> Option<(tcl_lexer::Span, bool)> {
    use crate::ir::WordExpr;
    let mut has_earlier_effect = false;
    for word in tokens.words() {
        match word {
            WordExpr::Variable {
                spelling,
                source: site,
            } => {
                if whole_scalar_variable_reference_name(spelling, config).is_some()
                    && source.read_word_produces_value(word, registry)
                    && source
                        .read_word(word)
                        .is_some_and(|read| read.symbol == symbol && read.version == Some(version))
                {
                    return Some((site.span, has_earlier_effect));
                }
                has_earlier_effect |= !source.read_word_produces_value(word, registry)
                    || source
                        .read_word(word)
                        .is_none_or(|read| read.version.is_none());
            }
            WordExpr::Literal { .. } | WordExpr::BracedLiteral { .. } => {}
            _ => has_earlier_effect = true,
        }
    }
    None
}

/// True when `[start, end)` overlaps any of the recorded ranges.
fn ranges_overlap(ranges: &[(u32, u32)], start: u32, end: u32) -> bool {
    ranges.iter().any(|&(s, e)| start < e && s < end)
}

/// Original declaring-class report, separate from method display metadata.
#[derive(Debug, Clone)]
struct OoFrame {
    defining_class: String,
}

fn oo_frame_for(
    method: &crate::ir::MethodDef,
    mutations: &crate::command_binding::ModuleCommandMutations,
    world: &crate::command_binding::OriginalCompletedCommandWorld,
) -> Option<OoFrame> {
    if mutations.has_runtime_selected_frames() || method.kind == crate::ir::MethodKind::ClassMethod
    {
        return None;
    }
    let (defining_class, original_operand) = world.defining_class_name_for_body(method)?;
    if !mutations.trusts_proc_binding(&original_operand) {
        return None;
    }
    Some(OoFrame { defining_class })
}

/// The method-local constants a method body may propagate, or an empty map
/// when it may propagate none.
///
/// This applies `elimination.rs`'s escaping model to the propagation
/// lattice.  `elimination.rs` already knows that a `TclOO` instance variable
/// escapes the method frame — it feeds
/// [`crate::ir::MethodDef::instance_vars`] through the same channel iRules
/// cross-event state uses, so a state-mutating `set ivar …` is never deleted
/// as a dead store.  The propagation lattice needs the same model, or this
/// walk can only carry an empty constants map.
///
/// SCCP is therefore **re-run** for the method with those names in its
/// escaping set, rather than the shared [`FunctionUnit::sccp`] being rebuilt
/// that way: forcing them `Overdefined` also poisons everything *derived*
/// from them (`set a $ivar ; set b $a`), which no filter on a projected map
/// could do — but it is a deliberately propagation-only view.  The unit's own
/// lattice stays as built, because other consumers read facts an instance
/// variable legitimately carries (object-collection element typing harvests
/// `dict set pins $k [Pin new]` out of exactly such a name).
///
/// What survives the projection is provably method-local: a name the class
/// never declares as state, never aliased by `variable` / `my variable` /
/// `upvar` / `global` inside the body (the per-function
/// [`crate::var_observability`] scan SCCP runs covers those), and not under a
/// trace.  A `my …` / `next` / `[self …]` dispatch is then no longer a barrier
/// for it: object state is the only thing such a dispatch can reach, and every
/// name that names object state has already left the map.
fn oo_method_constants(
    ctx: &PassContext<'_>,
    cu: &CompilationUnit,
    body_id: &crate::ir::ProcedureId,
    frame: &OoFrame,
    allow_locals: bool,
) -> std::collections::HashMap<String, String> {
    if !allow_locals {
        return std::collections::HashMap::new();
    }
    let (Some(fu), Some(registry)) = (cu.methods.get(body_id), ctx.registry) else {
        return std::collections::HashMap::new();
    };
    if fu.complexity_guarded {
        return std::collections::HashMap::new();
    }
    // This re-run bypasses the unit build's dynamic-name widening of the
    // SCCP escaping switch, so apply the same abstention here: a computed
    // variable name in the body makes no method-local constant trustworthy
    if fu.dynamic_barrier_blocks_value_motion() {
        return std::collections::HashMap::new();
    }
    // The re-run also carries the registry builtin-fold context:
    // `set base [self class]; set ns [namespace qualifiers $base]`
    // folds to fixpoint *inside* the lattice, so `base` and `ns` both
    // project as method-local constants rather than the chain stopping
    // after the first O129 suggestion. The frame's defining class is
    // proven by [`oo_frame_for`], so the `[self class]` frame fact is
    // sound here and only here.
    //
    // The escaping set is the unit's own `method_facts` carrier — the same
    // struct the existence fold and the W-family diagnostics read — never a
    // second lookup of `MethodDef::instance_vars`.
    let Some(facts) = fu.method_facts.as_deref() else {
        return std::collections::HashMap::new();
    };
    let sccp = crate::sccp::sccp_in_module(&crate::sccp::SolveInputs {
        cfg: &fu.cfg,
        ssa: &fu.ssa,
        param_constants: None,
        policy: FoldPolicy::from_registry(registry),
        extra_escaping: &facts.instance_vars,
        trace: crate::sccp::TraceInputs {
            registry,
            source_metadata_input: fu
                .invocation_metadata_context_for_module(registry, &cu.ir_module)
                .and_then(
                    crate::registry_invocation::InvocationMetadataContext::source_analysis_input,
                ),
            traced_variables: &cu.ir_module.traced_variables,
            has_dynamic_variable_trace: cu.ir_module.has_dynamic_variable_trace,
            deferred_writes: &cu.ir_module.deferred_writes,
            analysis_context: None,
            existence: None,
        },
        folds: Some(crate::sccp::BuiltinFoldInputs {
            registry,
            source_metadata_input: fu
                .invocation_metadata_context_for_module(registry, &cu.ir_module)
                .and_then(
                    crate::registry_invocation::InvocationMetadataContext::source_analysis_input,
                ),
            mutations: &ctx.command_mutations,
            dialect: ctx.dialect,
            defining_class: Some(&frame.defining_class),
            registry_engine: true,
            trust: crate::sccp::FoldTrust::WholeModule,
            proven_pure_parameters: false,
        }),
        module: crate::sccp::ModuleRun {
            analysis_body: Some(Some(*body_id)),
            ..crate::sccp::ModuleRun::NONE
        },
    });
    sccp_constants_from(&sccp, &fu.ssa, ctx.fold_policy())
}

/// Fold the command substitutions in every `TclOO` method body that the
/// enclosing method frame makes constant — `[self class]`, anything built
/// purely out of it (`[namespace qualifiers [self class]]` folds in one step,
/// since the builtin fold resolves nested substitutions first), and anything
/// built out of a *provably method-local* variable as well.
///
/// Deliberately narrower than [`run_function`]: no O103 static-proc-call fold
/// and no `namespace`-relative chain resolution runs here.  The constants map
/// comes from [`oo_method_constants`], which models which names are object
/// state.
fn run_oo_method_folds(ctx: &mut PassContext<'_>, cu: &CompilationUnit) {
    let Some(registry) = ctx.registry else {
        return;
    };
    let Some(bindings) = cu
        .ir_module
        .retained_source_bindings
        .as_deref()
        .filter(|bindings| bindings.matches_module(&cu.ir_module, registry))
    else {
        return;
    };
    let Some(world) = bindings
        .positioned_for_module(&cu.ir_module, registry)
        .and_then(crate::command_binding::SourceCommandBindings::original_completed_command_world)
    else {
        return;
    };
    // The PER-METHOD dispatch barrier: a method is barred
    // only when its dispatches can actually reach a caller-frame-reaching
    // (or unreadable) method — see `super::method_barrier`. The registry is
    // present (checked above), so unwrap-by-default to an all-barred
    // stance is unreachable; a bare context without one folds nothing
    // anyway.
    let barrier = ctx
        .registry
        .map(|registry| super::method_barrier::compute(&cu.ir_module, registry));
    // Sorted so the emitted rewrite order is deterministic across runs
    // (`ir_module.methods` is a `HashMap`).
    let mut qnames: Vec<&crate::ir::ProcedureId> = cu.ir_module.methods.keys().collect();
    qnames.sort();
    for qname in qnames {
        let Some(method) = cu.ir_module.methods.get(qname) else {
            continue;
        };
        let Some(frame) = oo_frame_for(method, &ctx.command_mutations, &world) else {
            continue;
        };
        let allow_locals = barrier.as_ref().is_some_and(|b| b.allows_locals(*qname));
        let constants = oo_method_constants(ctx, cu, qname, &frame, allow_locals);
        walk_oo_script(ctx, cu, &method.body, &frame, &constants, 0);
    }
}

/// `depth` is the nesting level of `script` — see
/// [`super::MAX_OPTIMISER_WALK_DEPTH`].
fn walk_oo_script(
    ctx: &mut PassContext<'_>,
    cu: &CompilationUnit,
    script: &Script,
    frame: &OoFrame,
    constants: &std::collections::HashMap<String, String>,
    depth: u32,
) {
    if super::MAX_OPTIMISER_WALK_DEPTH.exceeded(depth) || !script.is_authored_source() {
        return;
    }
    for stmt in &script.statements {
        walk_oo_statement(ctx, cu, script, stmt, frame, constants, depth);
    }
}

/// Visit one statement's command words for the frame-constant fold, then
/// recurse into any nested body it carries.
fn walk_oo_statement(
    ctx: &mut PassContext<'_>,
    cu: &CompilationUnit,
    script: &Script,
    stmt: &Statement,
    frame: &OoFrame,
    constants: &std::collections::HashMap<String, String>,
    depth: u32,
) {
    match stmt {
        Statement::Call {
            tokens: Some(t), ..
        }
        | Statement::AssignValue {
            tokens: Some(t), ..
        } => {
            // O100 / O129-in-interpolation over the method-local constants
            // (empty unless the escaping model proved some name
            // method-local), then the frame-constant cmd-sub folds.
            visit_call_tokens(ctx, cu, t, constants);
            visit_oo_frame_folds(ctx, cu, t, frame, constants);
        }
        // `return [self class]` is the single most common shape of all, and a
        // Retain its actual Script-owned vector and result word when replacing
        // the value; the original head and unrelated argv stay untouched.
        Statement::Return {
            value: Some(raw),
            expr: None,
            ..
        } => try_oo_frame_return_fold(
            ctx,
            cu,
            stmt,
            raw,
            frame,
            script.retained_source_tokens_for_statement(stmt),
        ),
        Statement::If {
            clauses, else_body, ..
        } => {
            for c in clauses {
                walk_oo_script(ctx, cu, &c.body, frame, constants, depth + 1);
            }
            if let Some(b) = else_body {
                walk_oo_script(ctx, cu, b, frame, constants, depth + 1);
            }
        }
        Statement::For {
            init, next, body, ..
        } => {
            walk_oo_script(ctx, cu, init, frame, constants, depth + 1);
            walk_oo_script(ctx, cu, next, frame, constants, depth + 1);
            walk_oo_script(ctx, cu, body, frame, constants, depth + 1);
        }
        Statement::While { body, .. }
        | Statement::Catch { body, .. }
        | Statement::Foreach { body, .. }
        | Statement::Block { body, .. } => {
            walk_oo_script(ctx, cu, body, frame, constants, depth + 1);
        }
        Statement::Try {
            body,
            handlers,
            finally_body,
            ..
        } => {
            walk_oo_script(ctx, cu, body, frame, constants, depth + 1);
            for h in handlers {
                walk_oo_script(ctx, cu, &h.body, frame, constants, depth + 1);
            }
            if let Some(fb) = finally_body {
                walk_oo_script(ctx, cu, fb, frame, constants, depth + 1);
            }
        }
        Statement::Switch {
            arms, default_body, ..
        } => {
            for a in arms {
                if let Some(body) = &a.body {
                    walk_oo_script(ctx, cu, body, frame, constants, depth + 1);
                }
            }
            if let Some(b) = default_body {
                walk_oo_script(ctx, cu, b, frame, constants, depth + 1);
            }
        }
        _ => {}
    }
}

fn retained_substitution_calls(
    tokens: &CommandTokens,
    module: &crate::ir::Module,
    registry: &CommandRegistry,
) -> Option<Vec<crate::word_subst::LiftedCall>> {
    n17_live_trace!("substitution-inventory-entry");
    // naming.compiler.original-analysis-metadata-context
    // docs/design/analysis/name-resolution-proofs/original-analysis-metadata-context.md
    if module.source_metadata_input.is_none()
        && module.source_entry.metadata_context.is_standalone()
    {
        return n17_live_some!(
            crate::word_subst::checked_lifted_calls(
                tokens,
                tokens.native_lexer_config(module.lexer_config.nested()),
            ),
            "substitution-standalone-inventory"
        );
    }
    if !module
        .retained_source_bindings
        .as_deref()
        .or_else(|| {
            n17_live_trace!("decline=substitution-retained-bindings");
            None
        })?
        .matches_module(module, registry)
    {
        n17_live_trace!("decline=substitution-module-currency");
        return None;
    }
    let metadata = n17_live_some!(
        crate::registry_invocation::InvocationMetadataContext::for_module(registry, module),
        "substitution-metadata"
    )?;
    n17_live_some!(
        crate::word_subst::checked_original_lifted_calls_with_metadata_context(
            tokens,
            module.lexer_config.nested(),
            registry,
            metadata,
        ),
        "substitution-original-inventory"
    )
}

fn retained_call_at(
    calls: &[crate::word_subst::LiftedCall],
    start: u32,
) -> Option<&crate::word_subst::LiftedCall> {
    let mut matching = calls.iter().filter(|call| call.span.start() == start);
    let call = matching.next()?;
    matching.next().is_none().then_some(call)
}

/// A result whose literal spelling a script evaluation would read apart from
/// the result itself ([`crate::const_subst::folded_literal_reads_apart`])
/// abstains: `[list string range $s 0 end-2147483649]` evaluates directly,
/// its braced literal compiles. `dialect` names the release that reads it.
fn fold_retained_builtin(
    registry: &CommandRegistry,
    call: &crate::word_subst::LiftedCall,
    calls: &[crate::word_subst::LiftedCall],
    defining_class: Option<&str>,
    metadata: Option<crate::registry_invocation::InvocationMetadataContext<'_>>,
    dialect: Option<&'static tcl_dialect::DialectProfile>,
) -> Option<String> {
    n17_live_trace!("builtin-entry span={:?}", call.span);
    let metadata = n17_live_some!(metadata, "builtin-metadata")?;
    let release = dialect.map_or(tcl_dialect::TclVersion::V9_0, |profile| {
        profile.vm_runtime_version
    });
    crate::const_subst::ConstSubstCtx {
        registry,
        resolution_namespace: "::",
        namespace_context: call
            .tokens
            .as_ref()
            .and_then(crate::registry_invocation::compiled_namespace_context),
        version: None,
        defining_class,
        trusts: &|_| false,
        lookup_var: &|_| None,
    }
    .fold_retained_call_with_metadata_context(call, calls, metadata)
    .filter(|value| !crate::const_subst::folded_literal_reads_apart(value, release))
}

fn retained_expr_call(
    call: &crate::word_subst::LiftedCall,
    registry: &CommandRegistry,
    metadata: Option<crate::registry_invocation::InvocationMetadataContext<'_>>,
) -> bool {
    let Some(metadata) = metadata else {
        return false;
    };
    call.tokens
        .as_ref()
        .and_then(|tokens| {
            crate::registry_invocation::resolved_tokens_invocation_with_metadata_context(
                registry,
                Some(metadata),
                tokens,
            )
        })
        .is_some_and(|invocation| {
            invocation.facts.operation
                == tcl_registry::SemanticOperationId::StructuredLowering(
                    tcl_registry::hooks::LoweringHookId::Expr,
                )
        })
}

fn retained_o115(
    ctx: &PassContext<'_>,
    module: &crate::ir::Module,
    _tokens: &CommandTokens,
    call: &crate::word_subst::LiftedCall,
    word: &str,
    registry: &CommandRegistry,
) -> Option<String> {
    let actual = crate::registry_invocation::retained_module_metadata_context(registry, module)?;
    let metadata = Some(actual.as_ref().into());
    if !retained_expr_call(call, registry, metadata) {
        return None;
    }
    let tokens = call.tokens.as_ref()?;
    let (_, command) = tokens
        .source_binding
        .as_ref()?
        .nested_expression_normalisation_source(
            registry,
            tokens,
            &ctx.fold_policy().preparation_context()?,
            None,
        )?;
    // The call was selected from the exact original whole substitution. The
    // inner command source comes from its retained outer expression owner.
    (ctx.source.get(call.span.as_range()) == Some(word)).then_some(command)
}

/// Report an `O129` for each single-token `[cmd …]` word of this command that
/// the method frame folds to a constant.
fn visit_oo_frame_folds(
    ctx: &mut PassContext<'_>,
    cu: &CompilationUnit,
    tokens: &CommandTokens,
    frame: &OoFrame,
    _constants: &std::collections::HashMap<String, String>,
) {
    let Some(registry) = ctx.registry else {
        return;
    };
    let actual =
        crate::registry_invocation::retained_module_metadata_context(registry, &cu.ir_module);
    let metadata = actual.as_deref().map(Into::into);
    let Some(calls) = retained_substitution_calls(tokens, &cu.ir_module, registry) else {
        return;
    };
    let mut rewrites: Vec<(tcl_lexer::Span, String)> = Vec::new();
    for word in tokens.words() {
        let crate::ir::WordExpr::CommandSubstitution { source, .. } = word else {
            continue;
        };
        let Some(call) = retained_call_at(&calls, source.span.start()) else {
            continue;
        };
        if let Some(value) = fold_retained_builtin(
            registry,
            call,
            &calls,
            Some(&frame.defining_class),
            metadata,
            ctx.dialect,
        ) && let Some(word) = render_propagation_word(&value, ctx.lexer_config())
        {
            rewrites.push((call.span, word));
        }
    }
    for (span, folded) in rewrites {
        ctx.report(Optimisation::new(
            DiagCode::O129,
            "Fold constant builtin command substitution",
            tcl_lexer::word_span_at(ctx.source, span),
            folded,
        ));
    }
}

/// `return [self class]` → `return ::TheClass`.
///
/// The original whole statement is the rewrite target. Its retained result
/// word selects the replacement site, preserving the actual written head.
fn try_oo_frame_return_fold(
    ctx: &mut PassContext<'_>,
    cu: &CompilationUnit,
    statement: &Statement,
    raw: &str,
    frame: &OoFrame,
    tokens: Option<&CommandTokens>,
) {
    let Some(registry) = ctx.registry else {
        return;
    };
    let Some(tokens) = tokens else {
        return;
    };
    let actual =
        crate::registry_invocation::retained_module_metadata_context(registry, &cu.ir_module);
    let metadata = actual.as_deref().map(Into::into);
    let Some(calls) = retained_substitution_calls(tokens, &cu.ir_module, registry) else {
        return;
    };
    let mut roots = calls.iter().filter(|call| {
        ctx.source
            .get(call.span.start() as usize..call.span.end() as usize)
            == Some(raw.trim())
    });
    let Some(call) = roots.next() else {
        return;
    };
    if roots.next().is_some() {
        return;
    }
    let Some(value) = fold_retained_builtin(
        registry,
        call,
        &calls,
        Some(&frame.defining_class),
        metadata,
        ctx.dialect,
    ) else {
        return;
    };
    let Some((rewrite_span, replacement)) =
        original_return_value_replacement(ctx, statement, tokens, &value)
    else {
        return;
    };
    ctx.report(Optimisation::new(
        DiagCode::O129,
        "Fold constant builtin command substitution",
        rewrite_span,
        replacement,
    ));
}

fn run_function(
    ctx: &mut PassContext<'_>,
    cu: &CompilationUnit,
    fu: &FunctionUnit,
    script: &Script,
    namespace: &str,
    extra_escaping: &std::collections::HashSet<String>,
) {
    ccg_row24_trace!(
        ctx,
        "CCG24 stage=function-enter authored={}",
        script.is_authored_source()
    );
    // A computed or opaque variable name can rewrite any local binding under
    // a spelling absent from SCCP's per-name lattice.  Do not let its raw
    // constants reach the text-level folds below: unlike
    // `run_load_forwarding`, this path would otherwise bypass the shared
    // dynamic-name guard and could emit (for example) `return 1` after a
    // depth-capped nested substitution may have run `set $name 2`.
    if fu.dynamic_barrier_blocks_value_motion() {
        ccg_row24_trace!(ctx, "CCG24 stage=dynamic-barrier");
        // A local value-motion barrier withdraws lattice substitutions. Exact
        // original invocation receipts still independently authorise closed
        // constant calls that consume no such local facts.
        walk_script(
            ctx,
            cu,
            script,
            &std::collections::HashMap::new(),
            None,
            namespace,
            0,
        );
        return;
    }

    // Project the per-function SCCP lattice into a name → literal
    // map that survives only when every tracked version of the
    // variable collapses to the same single constant value. No
    // additional trace/alias filtering is needed here: `sccp()` itself
    // forces a traced or frame-aliased name's own lattice entry (and
    // anything derived from it) to `Overdefined`, so a projected literal
    // is already trace/alias-safe by construction — `run_load_forwarding`
    // (below) is the one exception that still needs its own check, since it
    // runs an independent def-use-chain scan that never consults `fu.sccp`.
    let constants = constants_with_builtin_folds(ctx, cu, fu, extra_escaping);
    ccg_row24_trace!(
        ctx,
        "CCG24 stage=projected-constants x={:?}",
        constants.get("x")
    );
    let numeric = operand_types(fu);
    walk_script(ctx, cu, script, &constants, Some(&numeric), namespace, 0);
}

/// The function's projected constants map, widened with the registry
/// builtin-fold lattice.
///
/// The baseline is the shared [`FunctionUnit::sccp`] projection
/// ([`sccp_constants_for`]) — untouched, so every existing single-hop fold
/// stays byte-identical and the per-unit lattice memo (which cannot carry
/// the whole-module command-mutation fact in its key) is not disturbed.
/// When the body contains a command-substitution assignment, SCCP is
/// re-run with [`crate::sccp::BuiltinFoldInputs`] so chains like `set a
/// [string length abcdef]; set b [expr {$a + 1}]` close inside the
/// lattice; the re-run's projection is overlaid **additively**
/// (`entry().or_insert`) — it can only add names, never change or drop a
/// baseline constant. The re-run passes no interprocedural seeds (they
/// are not stored on the unit); a fold needing a seeded parameter is
/// simply missed, never wrong.
///
/// Cost containment: the re-run is skipped entirely (returning the
/// baseline) when the registry is absent, the unit is complexity-guarded,
/// or no `AssignValue` RHS is a whole-word `[…]` substitution — so a body
/// with nothing to fold pays one cheap scan and nothing else.
fn constants_with_builtin_folds(
    ctx: &PassContext<'_>,
    cu: &CompilationUnit,
    fu: &FunctionUnit,
    extra_escaping: &std::collections::HashSet<String>,
) -> std::collections::HashMap<String, String> {
    let mut constants = sccp_constants_for(fu, ctx.fold_policy());
    let Some(registry) = ctx.registry else {
        return constants;
    };
    if fu.complexity_guarded || !has_cmd_subst_assignment(fu) {
        return constants;
    }
    let rerun = crate::sccp::sccp_with_builtin_folds(
        &fu.cfg,
        &fu.ssa,
        None,
        FoldPolicy::from_registry(registry),
        extra_escaping,
        crate::sccp::TraceInputs {
            registry,
            source_metadata_input: fu
                .invocation_metadata_context_for_module(registry, &cu.ir_module)
                .and_then(
                    crate::registry_invocation::InvocationMetadataContext::source_analysis_input,
                ),
            traced_variables: &cu.ir_module.traced_variables,
            has_dynamic_variable_trace: cu.ir_module.has_dynamic_variable_trace,
            deferred_writes: &cu.ir_module.deferred_writes,
            analysis_context: None,
            existence: None,
        },
        Some(crate::sccp::BuiltinFoldInputs {
            registry,
            source_metadata_input: fu
                .invocation_metadata_context_for_module(registry, &cu.ir_module)
                .and_then(
                    crate::registry_invocation::InvocationMetadataContext::source_analysis_input,
                ),
            mutations: &ctx.command_mutations,
            dialect: ctx.dialect,
            // No method frame here — `[self class]`-style frame facts fold
            // only in `run_oo_method_folds`' proven method re-runs.
            defining_class: None,
            registry_engine: true,
            trust: crate::sccp::FoldTrust::WholeModule,
            proven_pure_parameters: false,
        }),
    );
    for (name, text) in sccp_constants_from(&rerun, &fu.ssa, ctx.fold_policy()) {
        constants.entry(name).or_insert(text);
    }
    constants
}

/// Whether any statement in the unit assigns a whole-word `[cmd …]`
/// command substitution — the only shape the registry builtin-fold
/// lattice can improve, and therefore the cost gate for re-running SCCP
/// in [`constants_with_builtin_folds`].
fn has_cmd_subst_assignment(fu: &FunctionUnit) -> bool {
    fu.cfg.blocks.values().any(|block| {
        block.statements.iter().any(|stmt| {
            matches!(stmt, Statement::AssignValue { value, .. } if {
                let trimmed = value.trim();
                trimmed.starts_with('[') && trimmed.ends_with(']')
            })
        })
    })
}

/// `depth` is the nesting level of `script` — see
/// [`super::MAX_OPTIMISER_WALK_DEPTH`].
fn walk_script(
    ctx: &mut PassContext<'_>,
    cu: &CompilationUnit,
    script: &Script,
    constants: &std::collections::HashMap<String, String>,
    numeric: NumericCtx<'_>,
    namespace: &str,
    depth: u32,
) {
    ccg_row24_trace!(
        ctx,
        "CCG24 stage=walk-script depth={depth} authored={} count={}",
        script.is_authored_source(),
        script.statements.len()
    );
    if super::MAX_OPTIMISER_WALK_DEPTH.exceeded(depth) || !script.is_authored_source() {
        return;
    }
    for stmt in &script.statements {
        walk_statement(
            ctx,
            cu,
            StatementSource {
                statement: stmt,
                tokens: script.retained_source_tokens_for_statement(stmt),
            },
            constants,
            numeric,
            namespace,
            depth,
        );
    }
}

#[derive(Clone, Copy)]
struct StatementSource<'a> {
    statement: &'a Statement,
    tokens: Option<&'a CommandTokens>,
}

fn walk_statement(
    ctx: &mut PassContext<'_>,
    cu: &CompilationUnit,
    source: StatementSource<'_>,
    constants: &std::collections::HashMap<String, String>,
    numeric: NumericCtx<'_>,
    namespace: &str,
    depth: u32,
) {
    match source.statement {
        Statement::Call {
            span,
            command,
            tokens,
            ..
        } => {
            ccg_row24_trace!(
                ctx,
                "CCG24 stage=call span={span:?} tokens={}",
                tokens.is_some()
            );
            if let Some(t) = tokens {
                visit_call_tokens(ctx, cu, t, constants);
                visit_call_cmd_subst_folds(ctx, cu, t, constants, namespace, *span);
            }
            try_fold_static_proc_call(ctx, cu, *span, command, tokens.as_ref(), namespace);
        }
        // `set TARGET [cmd-sub]` lowers to `AssignValue` carrying the
        // full command's tokens (`["set", TARGET, "[cmd-sub]"]`). Walk
        // its value words for the value-position cmd-sub folds — O115
        // redundant-nested-expr collapse and the O103 pure-proc
        // constant-return fold — so a `set` target gets the same folds a
        // command-argument position already gets. Only the cmd-sub fold
        // path is wired (not `visit_call_tokens`): a bare `set y $c` RHS
        // is handled by SCCP / load-forwarding, and folding it here would
        // change behaviour beyond the documented gap.
        //
        // Note: the *canonical* `set x [expr {[expr {E}]}]` does not reach
        // this arm — `extract_single_expr_arg` strips the outer `expr` at
        // lowering time, producing an `AssignExpr` whose `ExprCommand`
        // holds the inner `[expr {E}]`. So O115 fires here only for the
        // rarer AssignValue forms that retain a nested-expr cmd-sub word;
        // the O103 pure-proc fold is the common reachable case.
        Statement::AssignValue {
            span,
            tokens: Some(t),
            ..
        } => {
            visit_call_cmd_subst_folds(ctx, cu, t, constants, namespace, *span);
        }
        statement @ Statement::Return { .. } => {
            try_fold_return_terminator(ctx, statement, constants, &cu.ir_module, source.tokens);
        }
        Statement::AssignExpr { span, expr, .. } => {
            try_substitute_assign_expr(ctx, source, *span, expr, constants, numeric);
        }
        Statement::If {
            clauses, else_body, ..
        } => {
            for c in clauses {
                walk_script(ctx, cu, &c.body, constants, numeric, namespace, depth + 1);
            }
            if let Some(b) = else_body {
                walk_script(ctx, cu, b, constants, numeric, namespace, depth + 1);
            }
        }
        Statement::For {
            init, next, body, ..
        } => {
            walk_script(ctx, cu, init, constants, numeric, namespace, depth + 1);
            walk_script(ctx, cu, next, constants, numeric, namespace, depth + 1);
            walk_script(ctx, cu, body, constants, numeric, namespace, depth + 1);
        }
        Statement::While { body, .. }
        | Statement::Catch { body, .. }
        | Statement::Foreach { body, .. } => {
            walk_script(ctx, cu, body, constants, numeric, namespace, depth + 1);
        }
        Statement::Try {
            body,
            handlers,
            finally_body,
            ..
        } => {
            walk_script(ctx, cu, body, constants, numeric, namespace, depth + 1);
            for h in handlers {
                walk_script(ctx, cu, &h.body, constants, numeric, namespace, depth + 1);
            }
            if let Some(fb) = finally_body {
                walk_script(ctx, cu, fb, constants, numeric, namespace, depth + 1);
            }
        }
        Statement::Switch {
            arms, default_body, ..
        } => {
            for a in arms {
                if let Some(b) = &a.body {
                    walk_script(ctx, cu, b, constants, numeric, namespace, depth + 1);
                }
            }
            if let Some(b) = default_body {
                walk_script(ctx, cu, b, constants, numeric, namespace, depth + 1);
            }
        }
        _ => {}
    }
}

/// Evaluate a pure procedure with its parameters bound to the call's
/// constant arguments, returning the constant return value when every
/// reachable `return` agrees on it.
///
/// Seeds the parameters as version-0 lattice constants, re-runs SCCP over
/// the callee's CFG, then reads the one exact value every reachable exit
/// gives ([`crate::interprocedural::exit_value`], the reading the summary's
/// seedless run shares). Used for the argument-sensitive O103 fold
/// (`[::math::add 2 4]` → `6`) that the summary's argument-independent
/// `constant_return` cannot express.
///
/// This re-runs SCCP fresh (not `callee.sccp`), so it must feed the same
/// registry + whole-module trace facts the original build did — otherwise
/// this specific re-run path would be independently trace-blind (the same
/// silent-miscompile class `run_function`/`run_load_forwarding` guard
/// against). The callee and unit must retain the same supplied owner;
/// unavailable callee metadata cannot borrow the caller's grammar or folds.
fn evaluate_proc_with_constants(
    (ctx, cu): (&PassContext<'_>, &CompilationUnit),
    callee: &FunctionUnit,
    params: &[tcl_syntax::formal_params::FormalParameter],
    args: &[ConstValue],
    grammar: tcl_dialect::ParameterGrammar,
    policy: FoldPolicy,
) -> Option<tcl_registry::value_transfer::ExactValue> {
    let seed = seed_params_from_args(params, args, grammar, policy)?;
    let registry = ctx.registry?;
    let metadata = callee.invocation_metadata_context_for_module(registry, &cu.ir_module)?;
    let source_metadata_input = metadata.source_analysis_input()?;
    let folds = crate::sccp::BuiltinFoldInputs {
        source_metadata_input: Some(source_metadata_input),
        dialect: Some(source_metadata_input.unit_profile()),
        proven_pure_parameters: true,
        ..ctx.rewrite_folds()
    };
    // A call the callee makes to another procedure of the module is applied
    // as that procedure's transfer summary says, its result too: the
    // re-run's module is the unit's.
    let module = crate::interprocedural::ModuleProcedures::of_unit(cu, registry);
    let no_escaping = std::collections::HashSet::new();
    let result = crate::sccp::sccp_in_module(&crate::sccp::SolveInputs {
        cfg: &callee.cfg,
        ssa: &callee.ssa,
        param_constants: Some(&seed),
        policy,
        extra_escaping: &no_escaping,
        trace: crate::sccp::TraceInputs {
            registry,
            source_metadata_input: Some(source_metadata_input),
            traced_variables: &cu.ir_module.traced_variables,
            has_dynamic_variable_trace: cu.ir_module.has_dynamic_variable_trace,
            deferred_writes: &cu.ir_module.deferred_writes,
            analysis_context: None,
            existence: None,
        },
        // This re-run feeds an O103 *rewrite*, so it takes the whole-module
        // stance. Without any trust fact — what it used before — it folded
        // `[llength …]` with builtin semantics even where the module shadows
        // `llength`, handing O103 a value the rest of the pipeline disagrees
        // with (#2164).
        folds: Some(folds),
        module: crate::sccp::ModuleRun {
            analysis_body: callee.body_id.map(Some),
            procedures: Some(&module),
            owned: None,
            level: crate::sccp::ModuleLevel::Results,
            reads_exits: true,
        },
    });
    crate::interprocedural::exit_value(
        crate::interprocedural::ExitBody::of(callee),
        &result,
        crate::interprocedural::ExitReading {
            policy,
            grammar: callee
                .source_lexer_config()
                .grammar_over(source_metadata_input.unit_profile().grammar),
            folds,
            module: Some((&module, &callee.body_id?)),
        },
    )
}

/// Seed ordinary incoming formal values using the shared native activation
/// plan. Defaults and rest names retain their selected Tcl/Jim semantics;
/// caller links cannot supply ordinary constant local slots.
fn seed_params_from_args(
    params: &[tcl_syntax::formal_params::FormalParameter],
    args: &[ConstValue],
    grammar: tcl_dialect::ParameterGrammar,
    policy: FoldPolicy,
) -> Option<std::collections::HashMap<(String, crate::ssa::Version), LatticeValue>> {
    use tcl_syntax::formal_params::FormalArgumentBinding;
    let plan =
        tcl_syntax::formal_params::bind_formal_arguments(params, args.len(), grammar).ok()?;
    let mut seed = std::collections::HashMap::new();
    for formal in plan {
        let (name, value) = match formal {
            FormalArgumentBinding::Value {
                parameter,
                argument,
            } => (
                params.get(parameter)?.name.clone(),
                args.get(argument)?.clone(),
            ),
            FormalArgumentBinding::Default { parameter } => {
                let formal = params.get(parameter)?;
                (
                    formal.name.clone(),
                    crate::sccp::parse_literal_value(formal.default.as_deref()?),
                )
            }
            FormalArgumentBinding::Rest {
                name, start, len, ..
            } => {
                let end = start.checked_add(len)?;
                let tail = args
                    .get(start..end)?
                    .iter()
                    .map(|value| const_value_text(value, policy))
                    .collect::<Option<Vec<_>>>()?;
                (name, ConstValue::String(tcl_syntax::list::join_list(tail)))
            }
            FormalArgumentBinding::CallerLink { .. } => return None,
        };
        seed.insert((name, 0), LatticeValue::Const(value));
    }
    Some(seed)
}

/// Render a [`ConstValue`] back to its plain text form — the inverse of
/// [`crate::sccp::parse_literal_value`], used to re-serialise a call
/// argument's already-typed constant into one element of the canonical
/// list text [`seed_params_from_args`] builds for a variadic `args`
/// parameter.
fn const_value_text(cv: &ConstValue, policy: FoldPolicy) -> Option<String> {
    super::helpers::literals::format_constant_with_policy(cv, policy)
}

/// Resolve a call's head word to a procedure qname that has an
/// interprocedural summary, following Tcl's real bareword command
/// resolution via [`crate::naming::bareword_resolution_candidates`] —
/// current namespace first, then global, exactly two levels, never every
/// enclosing ancestor namespace (Tcl's own command lookup does not walk
/// intermediate namespaces absent an explicit `namespace path`, which this
/// analysis does not model — a body using it is more conservatively left
/// unresolved here rather than risk folding to the wrong proc).
///
/// Shared with the analyser's identical same-file resolution chase
/// (`Analyser::resolve_indirect_call_target`) so the two can't diverge on
/// the same rule: a relative dotted word (`inner::p`) must not resolve
/// straight to `::inner::p`, rooted at global, because real Tcl (and the
/// analyser side) tries the *current* namespace first
/// (`{namespace}::inner::p`); two procs of that shape in different
/// namespaces could fold a call to the wrong one's constant return.
///
/// Returns the first candidate that has a summary, else `None`.
#[cfg(test)]
fn resolve_proc_qname(
    command: &str,
    namespace: &str,
    ia: &crate::interprocedural::InterproceduralAnalysis,
) -> Option<String> {
    if command.is_empty() {
        return None;
    }
    crate::naming::resolve_command_with::<&str, _>(namespace, &[], command, |qname| {
        ia.procedures
            .values()
            .filter(|summary| summary.qualified_name == qname)
            .count()
            == 1
    })
}

/// O103: if `command` resolves to a proc with `can_fold_static_calls`
/// and a `constant_return`, and the call is one [`summary_answers`],
/// emit a rewrite replacing the call with the literal return value.
fn try_fold_static_proc_call(
    ctx: &mut PassContext<'_>,
    cu: &CompilationUnit,
    span: tcl_lexer::Span,
    command: &str,
    tokens: Option<&CommandTokens>,
    _namespace: &str,
) {
    let Some(ia) = cu.interproc.as_ref() else {
        return;
    };
    let Some(registry) = ctx.registry else {
        return;
    };
    let Some(calls) = tokens.and_then(|tokens| {
        crate::registry_invocation::original_source_procedure_calls_for_word_for_module(
            tokens,
            command,
            &cu.ir_module,
            registry,
        )
    }) else {
        return;
    };
    let [call] = calls.as_slice() else {
        return;
    };
    let Some(summary) = ia.procedures.get(&call.id()) else {
        return;
    };
    let qname = &call.procedure().qualified_name;
    // A redefined proc has an ambiguous body — never fold its calls
    // (the flow-sensitive rename gate, mirroring the cmd-subst form and
    // `redefined_procedures` check).
    if cu.ir_module.redefined_procedures.contains(qname) {
        return;
    }
    // Nor a proc whose bare name is later `rename`d over or `interp
    // alias`ed elsewhere in the module — folding this call site to the
    // *originally-declared* proc's constant return would miscompile a
    // script where `command` no longer denotes that proc by the time this
    // call runs (e.g. `proc a {…} …; proc b {…} …; rename b a` moves `b`'s
    // body onto the name `a`; a later `[a …]` call must not fold to `a`'s
    // original body).
    if !ctx.command_mutations.trusts_proc_binding(qname) {
        return;
    }
    if !summary.can_fold_static_calls {
        return;
    }
    let literal_words = call
        .effective_arguments()
        .words
        .iter()
        .all(|word| {
            matches!(
                word,
                crate::ir::WordExpr::Literal { .. } | crate::ir::WordExpr::BracedLiteral { .. }
            )
        })
        .then(|| call.argument_count())
        .flatten();
    if !summary_answers(&summary.params, literal_words) {
        return;
    }
    let Some(cr) = &summary.constant_return else {
        return;
    };
    let replacement = match cr {
        ConstantReturn::Int(i) => i.to_string(),
        ConstantReturn::Float(f) => {
            let Some(text) = crate::tcl_expr_eval::format_tcl_value_with_policy(
                &crate::tcl_expr_eval::TclValue::Float(*f),
                ctx.fold_policy(),
            ) else {
                return;
            };
            text
        }
        ConstantReturn::Bool(true) => "1".to_owned(),
        ConstantReturn::Bool(false) => "0".to_owned(),
        ConstantReturn::Str(s) => {
            if is_value_safe_bare_word(s) {
                s.clone()
            } else {
                return;
            }
        }
    };
    // The span here covers the whole Statement::Call — applying
    // the literal replacement would turn `::answer` into a
    // command named `42`, which is invalid Tcl. Targeting
    // `[procName …]` command substitutions with their token span
    // would avoid this. Until CMD-subst spans are tracked at
    // the call argument level, emit as a hint so
    // editors surface the fold without proposing an applicable
    // quick-fix.
    let mut opt = Optimisation::new(
        DiagCode::O103,
        format!(
            "Fold pure-proc call to '{}' to its constant return",
            summary.qualified_name
        ),
        span,
        replacement,
    );
    opt.hint_only = true;
    ctx.report(opt);
}

/// Replace only the retained original result word of a simple lowered return.
/// This constructs source; the caller must independently approve the fold.
fn original_return_value_replacement(
    ctx: &PassContext<'_>,
    statement: &Statement,
    tokens: &CommandTokens,
    value: &str,
) -> Option<(tcl_lexer::Span, String)> {
    let replacement = render_propagation_word(value, ctx.lexer_config())?;
    original_return_word_replacement(ctx, statement, tokens, &replacement)
}

/// Splice one deliberately constructed complete word into the same original
/// return's retained result ordinal. This supplies source geometry only.
fn original_return_word_replacement(
    ctx: &PassContext<'_>,
    statement: &Statement,
    tokens: &CommandTokens,
    replacement: &str,
) -> Option<(tcl_lexer::Span, String)> {
    let image = tcl_lexer::SourceImage::document(replacement);
    let extent = tcl_lexer::Span::new(0, u32::try_from(replacement.len()).ok()?);
    let plan = tcl_lexer::native_script_words_in(image, extent, ctx.lexer_config()).ok()?;
    if plan.fatal_tail.is_some() {
        return None;
    }
    let [proposed] = plan.commands.as_slice() else {
        return None;
    };
    let [proposed_word] = proposed.words.as_slice() else {
        return None;
    };
    if proposed_word.span() != extent || proposed_word.group().expand {
        return None;
    }
    let Statement::Return {
        value_word: Some(value_word),
        ..
    } = statement
    else {
        return None;
    };
    let module = ctx.ir_module?;
    let registry = ctx.registry?;
    let config = ctx.lexer_config();
    let span = original_statement_rewrite_span(ctx, statement.span())?;
    let binding = tokens.source_binding.as_ref()?;
    binding.original_invocation_metadata_for_module(tokens, module, registry)?;
    let site = binding.invocation_site()?;
    if site.offset != span.start() || site.source.source_image() != &module.source {
        return None;
    }
    let command = site
        .source
        .original_lexical_command(tokens.words(), site.offset, config)?;
    let mut matches = tokens
        .words()
        .iter()
        .enumerate()
        .filter(|(_, word)| *word == value_word);
    let (written, _) = matches.next()?;
    if matches.next().is_some() {
        return None;
    }
    let word = command.native_words().get(written)?;
    let start = usize::try_from(word.span().start().checked_sub(span.start())?).ok()?;
    let end = usize::try_from(word.span().end().checked_sub(span.start())?).ok()?;
    let mut source = ctx
        .source
        .get(span.start() as usize..span.end() as usize)?
        .to_owned();
    source.get(start..end)?;
    source.replace_range(start..end, replacement);
    // Full proposed statement parsing detects any quote/continuation seam.
    let image = tcl_lexer::SourceImage::document(&source);
    let extent = tcl_lexer::Span::new(0, u32::try_from(source.len()).ok()?);
    let after = tcl_lexer::native_script_words_in(image, extent, config).ok()?;
    if after.fatal_tail.is_some() {
        return None;
    }
    let [after] = after.commands.as_slice() else {
        return None;
    };
    (after.words.len() == command.native_words().len()).then_some((span, source))
}

/// Fold an original return operand using its retained word kind and constants.
fn try_fold_return_terminator(
    ctx: &mut PassContext<'_>,
    statement: &Statement,
    constants: &std::collections::HashMap<String, String>,
    module: &crate::ir::Module,
    tokens: Option<&CommandTokens>,
) {
    let Statement::Return {
        span,
        value,
        value_word,
        expr,
        ..
    } = statement
    else {
        return;
    };
    let span = *span;
    let value = value.as_deref();
    let expr = expr.as_ref();

    // O115: `return [expr {[expr {E}]}]` → `return [expr {E}]`. Checked
    // before the `expr.is_some()` early-return below because the return
    // value of a cmd-sub also populates `expr`, yet the redundant-nested-
    // expr collapse operates on the raw value text. Also requires `expr`
    // to be untouched anywhere in the module (mirrors the O129
    // builtin-fold trust check) — both the outer and inner `[expr {…}]`
    // are genuine command substitutions, and a shadowed `expr` no longer
    // has builtin semantics.
    let collapse = tokens.and_then(|tokens| {
        let registry = ctx.registry?;
        let calls = retained_substitution_calls(tokens, module, registry)?;
        let raw = value?.trim();
        let mut matching = calls.iter().filter(|call| {
            ctx.source
                .get(call.span.start() as usize..call.span.end() as usize)
                == Some(raw)
        });
        let call = matching.next()?;
        if matching.next().is_some() {
            return None;
        }
        retained_o115(ctx, module, tokens, call, raw, registry)
    });
    if let Some(collapsed) = collapse
        && let Some((span, replacement)) = tokens
            .and_then(|tokens| original_return_word_replacement(ctx, statement, tokens, &collapsed))
    {
        ctx.report(Optimisation::new(
            DiagCode::O115,
            "Remove redundant nested expr",
            span,
            replacement,
        ));
        return;
    }

    if let Some(expression) = expr {
        let env = constants
            .iter()
            .map(|(name, value)| {
                (
                    name.clone(),
                    crate::tcl_expr_eval::EnvValue::Str(value.clone()),
                )
            })
            .collect::<crate::tcl_expr_eval::Env>();
        if let Some(value) = ctx.eval_expression_at(expression, &env, span)
            && let Some(folded) =
                crate::tcl_expr_eval::format_tcl_value_with_policy(&value, ctx.fold_policy())
            && !folded.contains(['$', '['])
            && let Some((rewrite_span, replacement)) = tokens.and_then(|tokens| {
                original_return_value_replacement(ctx, statement, tokens, &folded)
            })
        {
            ctx.report(Optimisation::new(
                DiagCode::O101,
                "Fold constant expression",
                rewrite_span,
                replacement,
            ));
            return;
        }
    }

    // Only fold `return $v` — numeric/bare literals and complex
    // values are left to richer passes.
    if expr.is_some() {
        return;
    }
    let Some(crate::ir::WordExpr::Variable { spelling, .. }) = value_word.as_ref() else {
        return;
    };
    let Some(name) = whole_scalar_variable_reference_name(spelling, module.lexer_config) else {
        return;
    };
    let Some(resolved) = constants.get(name) else {
        return;
    };
    // Render the constant as a single self-contained word
    // rather than bailing on metacharacters (`return {Hello World}`).
    let Some((rewrite_span, replacement)) = tokens
        .and_then(|tokens| original_return_value_replacement(ctx, statement, tokens, resolved))
    else {
        return;
    };
    ctx.report(Optimisation::new(
        DiagCode::O100,
        "Fold return of constant variable",
        rewrite_span,
        replacement,
    ));
}

/// O100 (`AssignExpr` form): substitute SCCP-proved constants
/// into ``set name [expr { … }]`` expressions.
///
/// Builds on ``substitute_expr_constants`` — the same helper the
/// branch-condition pass uses. Emits an O100 rewrite targeting
/// the whole ``set`` statement with the substituted expression
/// re-wrapped in ``[expr { … }]``. The rewrite span is extended
/// through the original retained command vector so nested substitutions do not
/// leave orphan delimiters. The actual written target and head are retained.
fn try_substitute_assign_expr(
    ctx: &mut PassContext<'_>,
    source: StatementSource<'_>,
    span: tcl_lexer::Span,
    expr: &crate::expr_ast::ExprNode,
    constants: &std::collections::HashMap<String, String>,
    numeric: NumericCtx<'_>,
) {
    use super::helpers::expr_simplify::{
        expr_has_command_subst, instcombine_expr_typed, substitute_expr_constants_for_execution,
    };
    use crate::tcl_expr_eval::{Env, format_tcl_value_with_policy};

    let Some(rewrite_span) = original_statement_rewrite_span(ctx, span) else {
        return;
    };

    if matches!(expr, crate::expr_ast::ExprNode::Raw { .. }) {
        return;
    }
    if expr_has_command_subst(expr) {
        return;
    }
    // `expr` renamed/aliased anywhere in the module means the source's
    // `[expr {…}]` no longer has builtin semantics — do not propagate a
    // rewrite computed as if it did.
    if !ctx.command_mutations.trusts("expr") {
        return;
    }
    let original = source.tokens.and_then(|tokens| {
        super::expr_simplify::OriginalExpressionStatementSource::capture_with_tokens(
            ctx,
            source.statement,
            tokens,
            expr,
        )
    });
    let expr_text = crate::expr_ast::render_expr(expr);
    let result = substitute_expr_constants_for_execution(
        &expr_text,
        constants,
        ctx.dialect,
        &crate::tcl_expr_eval::NativeOperandProofs::new(),
    );
    if !result.changed {
        return;
    }
    // After substitution, try to fold the result to a constant
    // — the cascade where O100 enables O101. When
    // the substituted expression is fully constant we can emit
    // the unwrapped ``set name VALUE`` form directly. Otherwise
    // keep the expression wrapper around the substituted text.
    let env = constants
        .iter()
        .map(|(name, value)| {
            (
                name.clone(),
                crate::tcl_expr_eval::EnvValue::Str(value.clone()),
            )
        })
        .collect::<Env>();
    if let Some(val) = ctx.eval_expression_at(expr, &env, span)
        && let Some(folded) = format_tcl_value_with_policy(&val, ctx.fold_policy())
    {
        let needs_quoting = folded.is_empty()
            || folded.contains([
                ' ', '\t', '\n', '\r', '$', '[', ']', '{', '}', '"', '\\', '\0', ';',
            ]);
        if !needs_quoting
            && let Some(replacement) = original.as_ref().and_then(|source| source.folded(&folded))
        {
            ctx.report(Optimisation::new(
                DiagCode::O100,
                "Propagate constant and fold",
                rewrite_span,
                replacement,
            ));
            return;
        }
    }
    // Not fully constant; try one pass of instcombine on the
    // substituted expression to pick up identity simplifications
    // (e.g. ``$a + 0`` after ``$a`` folds to ``3``).
    let (simplified, _changed) = instcombine_expr_typed(&result.text, false, numeric, ctx.dialect);
    let final_text = if simplified.trim().is_empty() {
        result.text.clone()
    } else {
        simplified
    };
    if ctx
        .expression_rewrite_equivalence_at(expr, &final_text, &env, span)
        .is_err()
    {
        return;
    }
    let Some(replacement) = original
        .as_ref()
        .and_then(|source| source.simplified(&final_text))
    else {
        return;
    };
    ctx.report(Optimisation::new(
        DiagCode::O100,
        "Propagate constant into expr argument",
        rewrite_span,
        replacement,
    ));
}

/// O103 (CMD-subst form): walk each argv word looking for a
/// command substitution `[cmd …]` whose head resolves to a proc
/// with `can_fold_static_calls` and a proven `constant_return`.
/// Emits an applicable rewrite with the argv span and the literal
/// return value as replacement.
///
/// This is the "word-level" companion to the bare-call form in
/// [`try_fold_static_proc_call`], which stays hint-only because
/// folding `::answer` as a statement would turn the discarded
/// call into a bare `42` (invalid as a command name).
/// Fold a constant `[expr {…}]` command substitution in an argument position,
/// returning the rewritten word (`[expr {1 + 2}]` → `3`). A *braced* body folds
/// under the known `constants` (value substitution); a quoted / bare `expr "…"`
/// folds only as a literal (textual substitution is conservative). `None` when
/// the inner command is not `expr` or does not fold to a substitution-free
/// constant. Extracted from [`visit_call_cmd_subst_folds`].
fn try_o101_expr_arg_fold(
    ctx: &PassContext<'_>,
    cu: &CompilationUnit,
    tokens: &CommandTokens,
    call: &crate::word_subst::LiftedCall,
    constants: &std::collections::HashMap<String, String>,
) -> Option<String> {
    ccg_row24_trace!(ctx, "CCG24 stage=expr-enter constants={constants:?}");
    let registry = ctx.registry?;
    ccg_row24_trace!(ctx, "CCG24 stage=expr-registry");
    let input = cu.ir_module.source_metadata_input.as_ref()?;
    ccg_row24_trace!(ctx, "CCG24 stage=expr-input");
    let context = PassContext {
        source: ctx.source,
        dialect: ctx.dialect,
        registry: Some(registry),
        ir_module: Some(&cu.ir_module),
        ..PassContext::default()
    };
    let actual = context.retained_metadata_context()?;
    ccg_row24_trace!(ctx, "CCG24 stage=expr-metadata");
    let mut parser = tcl_syntax::expr::parser::ExprParseContext::for_profile(input.unit_profile());
    parser.lexer_grammar = input.lexer_config().grammar_over(parser.lexer_grammar);
    let expression = crate::word_subst::lifted_source_expressions_with_metadata_context(
        Some(tokens),
        registry,
        Some(actual.as_ref().into()),
        input.lexer_config(),
        parser,
    )
    .into_iter()
    .find(|expression| expression.span == call.span)?;
    ccg_row24_trace!(ctx, "CCG24 stage=expr-lifted-match");
    let env = constants
        .iter()
        .map(|(name, value)| {
            (
                name.clone(),
                crate::tcl_expr_eval::EnvValue::Str(value.clone()),
            )
        })
        .collect();
    let value = context.eval_expression_at(&expression.expression, &env, call.span)?;
    ccg_row24_trace!(ctx, "CCG24 stage=expr-evaluated");
    crate::tcl_expr_eval::format_tcl_value_with_policy(&value, context.fold_policy())
        .and_then(|value| render_propagation_word(&value, input.lexer_config()))
}

fn visit_call_cmd_subst_folds(
    ctx: &mut PassContext<'_>,
    cu: &CompilationUnit,
    tokens: &CommandTokens,
    constants: &std::collections::HashMap<String, String>,
    _namespace: &str,
    statement_span: tcl_lexer::Span,
) {
    n17_live_trace!("substitution-visit span={statement_span:?}");
    let Some(registry) = ctx.registry else {
        return;
    };
    let actual =
        crate::registry_invocation::retained_module_metadata_context(registry, &cu.ir_module);
    let metadata = actual.as_deref().map(Into::into);
    let Some(calls) = retained_substitution_calls(tokens, &cu.ir_module, registry) else {
        ccg_row24_trace!(ctx, "CCG24 stage=no-retained-calls");
        return;
    };
    ccg_row24_trace!(ctx, "CCG24 stage=retained-calls count={}", calls.len());
    n17_live_trace!("substitution-count count={}", calls.len());
    for word in tokens.words() {
        let crate::ir::WordExpr::CommandSubstitution { spelling, source } = word else {
            continue;
        };
        let Some(call) = retained_call_at(&calls, source.span.start()) else {
            continue;
        };
        if let Some(collapsed) = retained_o115(ctx, &cu.ir_module, tokens, call, spelling, registry)
        {
            let wrapper =
                crate::registry_invocation::resolved_handler_invocation_with_metadata_context(
                    registry, metadata, tokens,
                )
                .filter(|invocation| {
                    invocation.facts.operation
                        == tcl_registry::SemanticOperationId::StructuredLowering(
                            tcl_registry::hooks::LoweringHookId::Return,
                        )
                        && tokens.words().len() == 2
                })
                .and_then(|_| {
                    let original = ctx.source.get(statement_span.as_range())?;
                    let start = call.span.start().checked_sub(statement_span.start())? as usize;
                    let end = call.span.end().checked_sub(statement_span.start())? as usize;
                    let mut replacement = original.to_owned();
                    replacement.replace_range(start..end, &collapsed);
                    Some((statement_span, replacement))
                });
            let (span, replacement) = wrapper.unwrap_or((call.span, collapsed));
            ctx.report(Optimisation::new(
                DiagCode::O115,
                "Remove redundant nested expr",
                span,
                replacement,
            ));
            continue;
        }
        let is_expr = retained_expr_call(call, registry, metadata);
        ccg_row24_trace!(ctx, "CCG24 stage=expr-call selected={is_expr}");
        if is_expr && let Some(folded) = try_o101_expr_arg_fold(ctx, cu, tokens, call, constants) {
            ctx.report(Optimisation::new(
                DiagCode::O101,
                "Fold constant expression",
                call.span,
                folded,
            ));
            continue;
        }
        if let Some(value) =
            fold_retained_builtin(registry, call, &calls, None, metadata, ctx.dialect)
            && let Some(word) = render_propagation_word(&value, ctx.lexer_config())
        {
            let code = call
                .tokens
                .as_ref()
                .and_then(|tokens| {
                    crate::registry_invocation::resolved_tokens_invocation_with_metadata_context(
                        registry, metadata, tokens,
                    )
                })
                .map_or(DiagCode::O129, |invocation| {
                    match invocation.facts.canonical_command.as_str() {
                        "list" => DiagCode::O116,
                        "lindex" => DiagCode::O118,
                        _ => DiagCode::O129,
                    }
                });
            ctx.report(Optimisation::new(
                code,
                "Fold constant builtin command substitution",
                call.span,
                word,
            ));
            continue;
        }
        if let Some((name, replacement)) = try_o103_proc_fold(ctx, cu, call, &calls) {
            ctx.report(Optimisation::new(
                DiagCode::O103,
                format!("Fold pure-proc call to '{name}' to its constant return"),
                call.span,
                replacement,
            ));
        }
    }
}

/// Fold a pure-proc command substitution to its constant return (O103),
/// returning `(qualified_name, replacement_word)`. Uses the interprocedural
/// summary's argument-independent constant return when present and the call
/// is one it answers ([`summary_answers`]), else re-runs the pure callee
/// under the call's constant arguments. `None` when the head
/// is not a foldable internal proc. Extracted from [`visit_call_cmd_subst_folds`].
fn try_o103_proc_fold(
    ctx: &PassContext<'_>,
    cu: &CompilationUnit,
    call: &crate::word_subst::LiftedCall,
    calls: &[crate::word_subst::LiftedCall],
) -> Option<(String, String)> {
    let ia = cu.interproc.as_ref()?;
    let tokens = call.tokens.as_ref()?;
    let binding = tokens.source_binding.as_ref()?;
    let scoped = binding.scoped_procedure_evaluation(tokens);
    let target = binding
        .proved_execution_target()
        .or_else(|| scoped.as_ref().map(|receipt| receipt.target))?;
    if target.kind != crate::command_binding::BindingKind::Proc || target.registry_backed {
        return None;
    }
    let qname = target.command.clone();
    let (declaration_id, declaration) = cu.ir_module.source_procedure_for_target(target)?;
    if !target.matches_authored_implementation_image(&cu.ir_module.source, declaration.span.start())
    {
        return None;
    }
    let summary = ia.procedures.get(&declaration_id)?;
    // A redefined proc has an ambiguous body — never fold its calls.
    if cu.ir_module.redefined_procedures.contains(&qname) {
        return None;
    }
    let grammar = binding
        .variable_context
        .invocation_dialect?
        .parameter_grammar()?;
    let parameters =
        tcl_syntax::formal_params::parse_formal_parameters_in(&declaration.params_raw, grammar)
            .ok()?;
    let registry = ctx.registry?;
    let actual =
        crate::registry_invocation::retained_module_metadata_context(registry, &cu.ir_module)?;
    let original = crate::const_subst::ConstSubstCtx {
        registry,
        resolution_namespace: "::",
        namespace_context: binding.lookup_namespace_key.to_compiled_context(),
        version: None,
        defining_class: None,
        trusts: &|_| false,
        lookup_var: &|_| None,
    }
    .retained_arguments_with_metadata_context(call, calls, actual.as_ref().into())?;
    let plan =
        tcl_syntax::formal_params::bind_formal_arguments(&parameters, original.len(), grammar)
            .ok()?;
    if plan.iter().any(|formal| {
        matches!(
            formal,
            tcl_syntax::formal_params::FormalArgumentBinding::CallerLink { .. }
        )
    }) {
        return None;
    }
    if summary.pure
        && let Some(scoped) = scoped
    {
        return Some((
            qname,
            render_propagation_word(scoped.result.text(), ctx.lexer_config())?,
        ));
    }
    if summary.pure
        && binding.original_invocation_completes_normally(tokens)
        && let Some(result) = binding.original_normal_result(tokens)
    {
        return Some((
            qname,
            render_propagation_word(result.text(), ctx.lexer_config())?,
        ));
    }
    let args: Vec<_> = original
        .iter()
        .map(|value| crate::sccp::parse_literal_value(value))
        .collect();
    let replacement = if summary.can_fold_static_calls
        && let Some(cr) = &summary.constant_return
        && tcl_syntax::formal_params::bind_formal_arguments(&parameters, args.len(), grammar)
            .is_ok()
    {
        render_proc_constant_return(ctx, cr)?
    } else if summary.pure
        && let Some(callee) = cu.procedures.get(&declaration_id)
        && let Some(value) = evaluate_proc_with_constants(
            (ctx, cu),
            callee,
            &parameters,
            &args,
            grammar,
            ctx.fold_policy(),
        )
    {
        // Argument-sensitive: re-run SCCP on the pure callee with the call's
        // constant arguments bound and fold the constant return.
        render_propagation_word(value.as_str().ok()?, ctx.lexer_config())?
    } else {
        return None;
    };
    Some((summary.qualified_name.clone(), replacement))
}

fn render_proc_constant_return(
    ctx: &PassContext<'_>,
    constant: &crate::interprocedural::ConstantReturn,
) -> Option<String> {
    Some(match constant {
        ConstantReturn::Int(value) => value.to_string(),
        ConstantReturn::Float(value) => crate::tcl_expr_eval::format_tcl_value_with_policy(
            &crate::tcl_expr_eval::TclValue::Float(*value),
            ctx.fold_policy(),
        )?,
        ConstantReturn::Bool(true) => "1".to_owned(),
        ConstantReturn::Bool(false) => "0".to_owned(),
        ConstantReturn::Str(value) => render_propagation_word(value, ctx.lexer_config())?,
    })
}
/// Whether a procedure's argument-independent constant return answers a
/// call whose words after the head are `literal_words` many, all literal
/// (`None` when one substitutes): only a call the argument-sensitive re-run
/// could make — every word literal, as many as the parameters accept. A
/// word that substitutes runs before the call and may raise or write, and a
/// count the parameters do not accept raises; the constant says neither
/// (#2389).
fn summary_answers(params: &[String], literal_words: Option<usize>) -> bool {
    literal_words
        .and_then(|count| u16::try_from(count).ok())
        .is_some_and(|count| crate::interprocedural::arity_from_names(params).accepts(count))
}

/// Parse the head word out of a CMD-subst interior. Returns
/// `None` when the head word is empty or contains metacharacters
/// that would change the parsed command name under substitution.
#[cfg(test)]
fn parse_cmd_subst_head(inner: &str) -> Option<&str> {
    let trimmed = inner.trim_start();
    let end = trimmed
        .find(|c: char| c.is_whitespace())
        .unwrap_or(trimmed.len());
    let head = &trimmed[..end];
    if head.is_empty() {
        return None;
    }
    if head.contains(['$', '[', '\\', '"', '{', '(', '}', ']']) {
        return None;
    }
    Some(head)
}

fn visit_call_tokens(
    ctx: &mut PassContext<'_>,
    cu: &CompilationUnit,
    tokens: &CommandTokens,
    constants: &std::collections::HashMap<String, String>,
) {
    for (i, span) in tokens.argv.iter().enumerate() {
        let single = tokens.single_token_word.get(i).copied().unwrap_or(false);
        let Some(text) = tokens.argv_texts.get(i) else {
            continue;
        };
        // A braced `{…}` word (kind `Str`) is a literal / script body: Tcl
        // performs NO substitution inside braces, so neither the simple-`$var`
        // fold nor the `"…"` / `[cmd]` interpolation folds may touch it (else
        // `puts {$x}` is wrongly rewritten to `puts 42`, or a proc body like
        // `{ set d [dict create a 1] }` is spliced into a quoted string).
        if tokens.argv_kinds.get(i).copied() == Some(tcl_lexer::TokenType::Str) {
            continue;
        }
        // A word the lexer reads as one `[…]` is a command substitution, not
        // interpolation text: `visit_call_cmd_subst_folds` folds it through
        // its route, whose decline is final, so neither rewriter below
        // may take it apart — a `]` inside a braced argument
        // (`[string match -nocase {a]€} {€a}]`) is no close of it.
        if single && tokens.argv_kinds.get(i).copied() == Some(tcl_lexer::TokenType::Cmd) {
            continue;
        }
        if single
            && let Some(crate::ir::WordExpr::Variable { spelling, .. }) = tokens.words().get(i)
        {
            visit_simple_var_word(ctx, *span, spelling, constants, cu.ir_module.lexer_config);
        }
        // `"..."` interpolation substitution — works on both
        // single-token (quoted strings) and composite (mixed
        // text + var) words.
        visit_string_interpolation(ctx, *span, text, constants, cu.ir_module.lexer_config);
        // Fold a pure-builtin `[cmd …]` substitution
        // embedded *inside* an interpolation string.
        visit_string_interpolation_cmd_subs(ctx, cu, tokens, *span, text, constants);
    }
}

/// True when `inside` is exactly one bracket-balanced `[…]` covering the
/// whole word (a free-standing command substitution), as opposed to a
/// sub embedded in surrounding interpolation text.
fn is_whole_word_cmd_subst(inside: &str) -> bool {
    let b = inside.as_bytes();
    if b.first() != Some(&b'[') {
        return false;
    }
    let mut depth = 0u32;
    let mut i = 0;
    while i < b.len() {
        match b[i] {
            b'\\' => i += 1,
            b'[' => depth += 1,
            b']' => {
                depth -= 1;
                if depth == 0 {
                    return i == b.len() - 1;
                }
            }
            _ => {}
        }
        i += 1;
    }
    false
}

/// Fold a pure-builtin command substitution
/// embedded *inside* an interpolation string, splicing the raw result
/// into the surrounding `"…"` (O129): `puts "v=[string length abc]"` →
/// `puts "v=5"`.
///
/// Each original substitution with a proved executable registry target and
/// closed original arguments is folded through the shared retained-call owner.  Soundness guards: the result must not
/// reintroduce a substitution into the `"…"` context — a result
/// carrying `$`, `[`, `]`, `\`, or `"` is left unfolded.  `$var`
/// substitutions and any non-foldable `[cmd]` are kept verbatim; at
/// least one successful fold is required to emit.
fn visit_string_interpolation_cmd_subs(
    ctx: &mut PassContext<'_>,
    cu: &CompilationUnit,
    tokens: &CommandTokens,
    span: tcl_lexer::Span,
    text: &str,
    _constants: &std::collections::HashMap<String, String>,
) {
    let Some(registry) = ctx.registry else {
        return;
    };
    let actual =
        crate::registry_invocation::retained_module_metadata_context(registry, &cu.ir_module);
    let metadata = actual.as_deref().map(Into::into);
    let Some(calls) = retained_substitution_calls(tokens, &cu.ir_module, registry) else {
        return;
    };
    let inside = text
        .strip_prefix('"')
        .and_then(|s| s.strip_suffix('"'))
        .unwrap_or(text);
    if !inside.contains('[') {
        return;
    }
    // A whole-word `[…]` cmd-sub is already folded by
    // `visit_call_cmd_subst_folds`; this path only handles a sub *embedded* in
    // surrounding interpolation text (else we'd emit a duplicate O129).
    if is_whole_word_cmd_subst(inside) {
        return;
    }
    let Some(rewrite_span) = original_quoted_word_rewrite_span(ctx, span, inside) else {
        return;
    };
    let content_base = if ctx.source.as_bytes().get(rewrite_span.start() as usize) == Some(&b'"') {
        rewrite_span.start().checked_add(1)
    } else {
        Some(rewrite_span.start())
    };
    let Some(content_base) = content_base else {
        return;
    };
    let Some(content_end) = u32::try_from(inside.len())
        .ok()
        .and_then(|length| content_base.checked_add(length))
    else {
        return;
    };
    if ctx.source.get(content_base as usize..content_end as usize) != Some(inside) {
        return;
    }
    let contained: Vec<_> = calls
        .iter()
        .filter(|call| call.span.start() >= content_base && call.span.end() <= content_end)
        .collect();
    let mut roots: Vec<_> = contained
        .iter()
        .copied()
        .filter(|call| {
            !contained.iter().any(|outer| {
                outer.span.start() < call.span.start() && outer.span.end() >= call.span.end()
            })
        })
        .collect();
    roots.sort_by_key(|call| call.span.start());
    let mut out = String::with_capacity(inside.len());
    let mut last = 0;
    let mut folded_any = false;
    for call in roots {
        let Some(result) =
            fold_retained_builtin(registry, call, &calls, None, metadata, ctx.dialect)
        else {
            continue;
        };
        if result
            .bytes()
            .any(|byte| matches!(byte, b'$' | b'[' | b']' | b'\\' | b'"'))
        {
            continue;
        }
        let start = (call.span.start() - content_base) as usize;
        let end = (call.span.end() - content_base) as usize;
        let Some(prefix) = inside.get(last..start) else {
            return;
        };
        out.push_str(prefix);
        out.push_str(&result);
        last = end;
        folded_any = true;
    }
    if !folded_any {
        return;
    }
    out.push_str(&inside[last..]);
    ctx.report(Optimisation::new(
        DiagCode::O129,
        "Fold constant builtin command substitution in interpolation",
        rewrite_span,
        format!("\"{out}\""),
    ));
}

fn visit_simple_var_word(
    ctx: &mut PassContext<'_>,
    span: tcl_lexer::Span,
    text: &str,
    constants: &std::collections::HashMap<String, String>,
    config: tcl_lexer::LexerConfig,
) {
    let Some(name) = whole_scalar_variable_reference_name(text, config) else {
        return;
    };
    let Some(value) = constants.get(name) else {
        return;
    };
    // Re-render a metacharacter-bearing constant as a
    // single self-contained word instead of bailing.
    let Some(word) = render_propagation_word(value, config) else {
        return;
    };
    ctx.report(Optimisation::new(
        DiagCode::O100,
        "Propagate constant into command argument",
        span,
        word,
    ));
}

/// Inline SCCP-proved constants into a `"…$x…"` string arg.
///
/// Rewrites only when:
/// 1. The argument begins with `"` and ends with `"` (a
///    double-quoted word).
/// 2. Every `$name` / `${name}` reference inside resolves to a
///    constant whose string form is safe for `"…"`
///    interpolation — no `$`, `[`, `\`, or `"`.
///
/// Produces a single `O100` diagnostic spanning the whole arg
/// with the fully-substituted string text.
fn visit_string_interpolation(
    ctx: &mut PassContext<'_>,
    span: tcl_lexer::Span,
    text: &str,
    constants: &std::collections::HashMap<String, String>,
    config: tcl_lexer::LexerConfig,
) {
    // The lexer's argv_text strips outer `"…"` delimiters, so
    // we accept either form. Skip strings whose content is a
    // single bare `$var` — that path is already covered by
    // `visit_simple_var_word` with a more appropriate span.
    let inside = text
        .strip_prefix('"')
        .and_then(|s| s.strip_suffix('"'))
        .unwrap_or(text);
    if !inside.contains('$') {
        return;
    }
    if whole_scalar_variable_reference_name(inside, config).is_some() {
        return;
    }
    // A free-standing `[cmd …]` word is a command substitution, not a
    // `"…"` interpolation: wrapping it in quotes (below) and extending the
    // span to a non-existent close-quote both corrupt the output (e.g.
    // `puts [expr {$a + $b}]` → `puts "[expr {3 + 4}]"]`). Whole-word subs
    // are folded by `visit_call_cmd_subst_folds`; leave them alone here.
    if is_whole_word_cmd_subst(inside) {
        return;
    }
    let Some(rewritten) = substitute_dollar_refs(inside, constants, config.nested()) else {
        return;
    };
    if rewritten == inside {
        return;
    }
    // The argv span for a composite `"$a $b $c"` word holds only
    // the opening-quote token (e.g. `"$` at 5..7). Extend to the
    // matching close quote so the rewrite target covers the full
    // string — otherwise we leave trailing `$b $c"` garbage.
    let Some(rewrite_span) = original_quoted_word_rewrite_span(ctx, span, inside) else {
        return;
    };
    ctx.report(Optimisation::new(
        DiagCode::O100,
        "Inline constant into string interpolation",
        rewrite_span,
        format!("\"{rewritten}\""),
    ));
}

/// Scan `text` — the inside of a quoted word — for `$name` / `${name}`
/// references and replace each with the corresponding literal from
/// `constants`, rejecting any value that would re-introduce new
/// substitutions. Returns `None` when any reference names something that is
/// not a known constant (a partial substitution would be worse than no
/// substitution), or when the word does not lex.
///
/// The references are the lexer's own `Var` tokens, so only what Tcl
/// substitutes is rewritten: a command substitution is lexed as the script it
/// is, and a braced word in it (`"b:[list {$x}]"`) is a `Str` token whose
/// `$x` stays (#2250), while a `{` inside a quoted word of that script
/// (`"q:[list "foo {$x}"]"`) is literal text and its `$x` is substituted.
/// Unchanged text is copied as `&str` slices, so a multi-byte character keeps
/// its bytes (#2251).
fn substitute_dollar_refs(
    text: &str,
    constants: &std::collections::HashMap<String, String>,
    config: tcl_lexer::LexerConfig,
) -> Option<String> {
    let word = format!("\"{text}\"");
    let mut refs = Vec::new();
    collect_var_refs(&word, config, 0, 0, &mut refs)?;
    refs.sort_unstable_by_key(|r| r.start);
    let mut out = String::with_capacity(text.len());
    let mut copied = 0;
    for r in refs {
        // Offsets are into `word`, one past `text`'s.
        let (start, end) = (r.start - 1, r.end - 1);
        let value = constants.get(&r.name)?;
        if value.contains(['$', '[', '\\', '"']) {
            return None;
        }
        // Inside a `[…]` command substitution the value becomes a command
        // word, so it must be a single self-contained word — a value with
        // whitespace (a list literal like `tran 1n 100n uic`) would split
        // into multiple arguments. Plain string-text occurrences
        // (`cmd_depth == 0`) inline the value verbatim.
        if r.cmd_depth > 0 && !is_value_safe_bare_word(value) {
            return None;
        }
        out.push_str(text.get(copied..start)?);
        out.push_str(value);
        copied = end;
    }
    out.push_str(text.get(copied..)?);
    Some(out)
}

/// One variable substitution [`substitute_dollar_refs`] may rewrite: its byte
/// range in the lexed word, the variable it names, and how many command
/// substitutions enclose it.
struct VarRef {
    start: usize,
    end: usize,
    name: String,
    cmd_depth: u32,
}

/// Collect the `Var` tokens of `src` (a script or a quoted word, lexed under
/// `config`) at offset `base` into `out`, recursing into each command
/// substitution's script. A braced word is a `Str` token and holds none.
/// `None` when the text does not lex or holds a substitution this rewrite
/// cannot map (Jim's `$(…)`).
fn collect_var_refs(
    src: &str,
    config: tcl_lexer::LexerConfig,
    base: usize,
    cmd_depth: u32,
    out: &mut Vec<VarRef>,
) -> Option<()> {
    use tcl_lexer::TokenType;
    if crate::depth_guard::MAX_BRACKET_TEXT_DEPTH.exceeded(cmd_depth) {
        return None;
    }
    let sm = tcl_lexer::SourceMap::new(src);
    let tokens = tcl_lexer::Lexer::with_config(src, config)
        .tokenise_all()
        .ok()?;
    for tok in tokens {
        let (start, end) = (tok.span.start() as usize, tok.span.end() as usize);
        match tok.kind {
            TokenType::Var => {
                let name = sm.token_text(tok);
                // An element index that substitutes (`$arr($idx)`, `$a([k])`,
                // `$a(\x)`) names the element its value selects, not the one
                // its spelling does, so it is left as written.
                if tok.content_offset != 2
                    && tcl_syntax::naming::split_element_ref(name)
                        .is_some_and(|(_, index)| index.contains(['$', '[', '\\']))
                {
                    continue;
                }
                // A `${name}` span stops before its closing brace, but the
                // empty `${}` span already covers it.
                let close =
                    usize::from(tok.content_offset == 2 && src.get(start..end) != Some("${}"));
                out.push(VarRef {
                    start: base + start,
                    end: base + end + close,
                    name: name.to_owned(),
                    cmd_depth,
                });
            }
            TokenType::Cmd => {
                let inner = start + usize::from(tok.content_offset);
                collect_var_refs(
                    sm.token_text(tok),
                    config.nested(),
                    base + inner,
                    cmd_depth + 1,
                    out,
                )?;
            }
            TokenType::ExprSugar => return None,
            _ => {}
        }
    }
    Some(())
}

/// Allow a literal to be inlined as a bare word if it is
/// decimal-integer-shaped or matches the safe-word grammar.
/// Rejects anything containing Tcl metacharacters that would
/// introduce new substitutions.
fn is_value_safe_bare_word(value: &str) -> bool {
    if value.is_empty() {
        return false;
    }
    if value.parse::<i64>().is_ok() {
        return true;
    }
    is_safe_word(value)
}

/// Construct one literal source word under the caller's complete configuration.
/// The shared Syntax owner verifies its decoded value and complete word shape;
/// failure supplies no replacement. Evaluation and erasure proofs stay separate.
fn render_propagation_word(value: &str, config: tcl_lexer::LexerConfig) -> Option<String> {
    tcl_syntax::word_rules::lexical_unicode_source_word(value, config)
}

/// The SCCP-proved constant for one exact SSA value, rendered as source text.
///
/// The per-value counterpart of [`sccp_constants_for`]'s name-keyed map: that
/// projection answers "is this *name* always this constant", which is the
/// question a by-name source substitution has to ask, and it necessarily
/// abstains for a name whose versions hold different constants. A def-use
/// consumer already knows which version it is forwarding, so it can ask the
/// stronger question and get an answer where the map has none.
fn sccp_value_literal(
    fu: &FunctionUnit,
    var_name: &crate::var_resolve::VariableCellKey,
    version: crate::ssa::Version,
    policy: FoldPolicy,
) -> Option<String> {
    use super::helpers::literals::format_constant_with_policy;

    let sym = fu.ssa.cell_symbol(var_name)?;
    if !fu.sccp.materialises((sym, version)) {
        return None;
    }
    match fu.sccp.values.get(&(sym, version))? {
        LatticeValue::Const(cv) => format_constant_with_policy(cv, policy),
        _ => None,
    }
}

pub(super) fn sccp_constants_for(
    fu: &FunctionUnit,
    policy: FoldPolicy,
) -> std::collections::HashMap<String, String> {
    sccp_constants_from(&fu.sccp, &fu.ssa, policy)
}

/// [`sccp_constants_for`]'s projection, over an explicitly-supplied lattice.
///
/// Split out so a caller that re-runs SCCP under a *wider* escaping set can
/// project the result the same way — see [`oo_method_constants`], which does
/// exactly that for a `TclOO` method body without disturbing the shared
/// [`FunctionUnit`] lattice other consumers read.
fn sccp_constants_from(
    sccp: &crate::sccp::SccpResult,
    ssa: &crate::ssa::SsaFunction,
    policy: FoldPolicy,
) -> std::collections::HashMap<String, String> {
    use super::helpers::literals::format_constant_with_policy;

    let mut per_var: std::collections::HashMap<crate::ssa::Symbol, Vec<&ConstValue>> =
        std::collections::HashMap::new();
    let mut dirty: std::collections::HashSet<crate::ssa::Symbol> = std::collections::HashSet::new();
    for (&(sym, ver), lv) in &sccp.values {
        if dirty.contains(&sym) {
            continue;
        }
        if let LatticeValue::Const(cv) = lv
            && sccp.materialises((sym, ver))
        {
            per_var.entry(sym).or_default().push(cv);
        } else {
            dirty.insert(sym);
            per_var.remove(&sym);
        }
    }
    let mut out = std::collections::HashMap::new();
    for (sym, cvs) in per_var {
        let first = cvs[0];
        if !cvs.iter().all(|cv| *cv == first) {
            continue;
        }
        let display = ssa.var_name(sym);
        if ssa.var_symbol(display) == Some(sym)
            && let Some(text) = format_constant_with_policy(first, policy)
        {
            out.insert(display.to_owned(), text);
        }
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::interprocedural::test_body_identity::{
        fixture_id, fixture_id_if_present, fixture_proc,
    };
    use tcl_registry::CommandRegistry;

    use crate::interprocedural::InterproceduralAnalysis;

    #[test]
    fn return_literal_replacement_keeps_original_head_and_result_word_owner() {
        let context =
            tcl_registry::model::ingress::resolve_environment("tcl8.6").default_context_registry();
        let profile = tcl_dialect::DialectProfile::plain_tcl();
        let config = tcl_lexer::LexerConfig::for_file_grammar(profile.grammar);
        let input = crate::analyser::ResolvedAnalysisInput::new(
            profile,
            profile,
            std::sync::Arc::clone(&context),
            config,
        );
        let registry = context.commands();
        for (source, expected) in [
            ("::return $result", "::return {Hello World}"),
            ("return [::expr {2 + 3}]", "return {Hello World}"),
        ] {
            let mut lowerer = crate::lowering::Lowerer::with_config(registry, config)
                .with_resolved_analysis_input(input.clone());
            lowerer.lower(source);
            let module = lowerer.finish_module(source);
            let statement = module.top_level.statements.last().unwrap();
            assert!(matches!(
                statement,
                Statement::Return {
                    value_word: Some(_),
                    ..
                }
            ));
            let tokens = module
                .top_level
                .retained_source_tokens_for_statement(statement)
                .unwrap();
            let mut ctx = PassContext::new(source, InterproceduralAnalysis::default());
            ctx.registry = Some(registry);
            ctx.ir_module = Some(&module);
            let (span, replacement) =
                original_return_value_replacement(&ctx, statement, tokens, "Hello World").unwrap();
            assert_eq!(
                span,
                tcl_lexer::Span::new(0, u32::try_from(source.len()).unwrap())
            );
            assert_eq!(replacement, expected);
            ctx.source = "return foreign";
            assert!(
                original_return_value_replacement(&ctx, statement, tokens, "Hello World").is_none()
            );
        }
    }

    #[test]
    fn return_source_word_constructor_keeps_head_and_rejects_multiple_words() {
        let context =
            tcl_registry::model::ingress::resolve_environment("tcl8.6").default_context_registry();
        let profile = tcl_dialect::DialectProfile::plain_tcl();
        let config = tcl_lexer::LexerConfig::for_file_grammar(profile.grammar);
        let input = crate::analyser::ResolvedAnalysisInput::new(
            profile,
            profile,
            std::sync::Arc::clone(&context),
            config,
        );
        let registry = context.commands();
        for (source, expected) in [
            ("::return $result", "::return [::expr {$x}]"),
            ("return [::expr {2 + 3}]", "return [::expr {$x}]"),
        ] {
            let mut lowerer = crate::lowering::Lowerer::with_config(registry, config)
                .with_resolved_analysis_input(input.clone());
            lowerer.lower(source);
            let module = lowerer.finish_module(source);
            let statement = module.top_level.statements.last().unwrap();
            assert!(matches!(
                statement,
                Statement::Return {
                    value_word: Some(_),
                    ..
                }
            ));
            let tokens = module
                .top_level
                .retained_source_tokens_for_statement(statement)
                .unwrap();
            let mut ctx = PassContext::new(source, InterproceduralAnalysis::default());
            ctx.registry = Some(registry);
            ctx.ir_module = Some(&module);
            let (span, replacement) =
                original_return_word_replacement(&ctx, statement, tokens, "[::expr {$x}]").unwrap();
            assert_eq!(
                span,
                tcl_lexer::Span::new(0, u32::try_from(source.len()).unwrap())
            );
            assert_eq!(replacement, expected);
            assert!(
                original_return_word_replacement(
                    &ctx,
                    statement,
                    tokens,
                    "[::expr {$x}]; unwanted"
                )
                .is_none()
            );
            assert!(
                original_return_word_replacement(&ctx, statement, tokens, "{*}[::expr {$x}]")
                    .is_none()
            );
            ctx.source = "return foreign";
            assert!(
                original_return_word_replacement(&ctx, statement, tokens, "[::expr {$x}]")
                    .is_none()
            );
        }
    }

    fn registry() -> CommandRegistry {
        CommandRegistry::build_default()
    }

    fn proc_fold_context(cu: &CompilationUnit, name: &str) -> String {
        let summary = cu.interproc.as_ref().and_then(|ia| fixture_proc(ia, name));
        let summary = summary.map(|s| {
            (
                s.pure,
                s.can_fold_static_calls,
                s.has_barrier,
                s.has_unknown_calls,
                s.writes_global,
                &s.constant_return,
            )
        });
        let body = cu.function(name).map(|fu| {
            let statements: Vec<_> = fu
                .cfg
                .blocks
                .iter()
                .map(|(id, block)| {
                    let kinds: Vec<_> = block
                        .statements
                        .iter()
                        .map(std::mem::discriminant)
                        .collect();
                    (
                        id,
                        kinds,
                        block.terminator.as_ref().map(std::mem::discriminant),
                    )
                })
                .collect();
            (statements, &fu.sccp.values, &fu.sccp.executable_blocks)
        });
        format!("summary(pure,fold,barrier,unknown,global,return)={summary:?}, body={body:?}")
    }

    fn run_pass(source: &str) -> Vec<Optimisation> {
        let reg = registry();
        let cu = CompilationUnit::build_for(source, &reg, false);
        let mut ctx = PassContext::new(&cu.source, InterproceduralAnalysis::default());
        // Mirror `optimise_unit_raw`'s production wiring — `run_load_forwarding`
        // (O102) needs `ctx.registry` for its intervening-call purity scan, and
        // the trace/alias safety gates need `ctx.ir_module`. Without these two
        // fields set, a hand-built `PassContext` silently loses O102 coverage
        // (and O127's pre-existing trace-purity gate), which is exactly the bug
        // this test helper would otherwise mask.
        ctx.registry = Some(&reg);
        ctx.ir_module = Some(&cu.ir_module);
        run(&mut ctx, &cu);
        ctx.optimisations
    }

    #[test]
    fn propagation_literal_words_retain_selected_grammar_and_exact_unicode_value() {
        for dialect in ["tcl8.4", "tcl8.6", "tcl9.0"] {
            let profile = tcl_dialect::DialectProfile::find(dialect).unwrap();
            let mut config = tcl_lexer::LexerConfig::for_file_grammar(profile.grammar);
            config.strict_quoting = !config.strict_quoting;
            for value in [
                "",
                "42",
                "has space",
                "$literal [data]",
                "brace}tail",
                "λ",
                "line\nnext",
                "trailing\\",
            ] {
                let word = render_propagation_word(value, config).unwrap();
                assert!(tcl_syntax::word_rules::lexical_unicode_source_word_matches(
                    &word, value, config
                ));
            }
        }
    }

    #[test]
    fn resolve_proc_qname_walks_namespace_chain() {
        // Two procs in `::ns`; a bare `inner` call from `::ns` resolves to
        // `::ns::inner`, not the (absent) root `::inner`.
        let module = crate::lowering::lower_to_ir(
            "namespace eval ::ns {\n proc inner {} { return 1 }\n proc outer {} { inner }\n}",
            &registry(),
        );
        let ia = crate::interprocedural::build_interprocedural_analysis(
            &module,
            &registry(),
            None,
            crate::interprocedural::ObjectTypeMap::none(),
            crate::realm::CommandBindingRealm::none(),
            None,
        );
        assert!(
            fixture_id_if_present(&ia.procedures, "::ns::inner").is_some(),
            "expected ::ns::inner in IA, got {:?}",
            ia.procedures.keys().collect::<Vec<_>>(),
        );
        assert_eq!(
            resolve_proc_qname("inner", "::ns", &ia).as_deref(),
            Some("::ns::inner"),
            "bare call should resolve against the enclosing namespace",
        );
        // An absolute spelling is taken as-is.
        assert_eq!(
            resolve_proc_qname("::ns::inner", "::other", &ia).as_deref(),
            Some("::ns::inner"),
        );
        // A bare call with no matching namespace candidate fails to resolve.
        assert_eq!(resolve_proc_qname("missing", "::ns", &ia), None);
        // From the root namespace a bare `inner` does *not* reach `::ns::inner`.
        assert_eq!(resolve_proc_qname("inner", "::", &ia), None);
    }

    #[test]
    fn resolve_proc_qname_does_not_walk_ancestor_namespaces() {
        // Real Tcl bareword resolution is exactly two levels — current
        // namespace, then global — absent an explicit `namespace path`.
        // `::a::b::c::caller`'s body calling bare `foo` must NOT resolve to
        // a `::a::foo` defined in a *grandparent* namespace: real tclsh
        // raises "invalid command name" there, it does not silently walk up
        // to find `::a::foo`.
        let module = crate::lowering::lower_to_ir(
            "namespace eval ::a {\n proc foo {} { return 1 }\n namespace eval b {\n  namespace eval c {\n   proc caller {} { foo }\n  }\n }\n}",
            &registry(),
        );
        let ia = crate::interprocedural::build_interprocedural_analysis(
            &module,
            &registry(),
            None,
            crate::interprocedural::ObjectTypeMap::none(),
            crate::realm::CommandBindingRealm::none(),
            None,
        );
        assert!(
            fixture_id_if_present(&ia.procedures, "::a::foo").is_some(),
            "expected ::a::foo in IA, got {:?}",
            ia.procedures.keys().collect::<Vec<_>>(),
        );
        assert_eq!(
            resolve_proc_qname("foo", "::a::b::c", &ia),
            None,
            "a grandparent-namespace proc must not resolve for a bare call",
        );
        // Control: the *direct* enclosing namespace still resolves.
        let module2 = crate::lowering::lower_to_ir(
            "namespace eval ::a::b::c {\n proc foo {} { return 1 }\n proc caller {} { foo }\n}",
            &registry(),
        );
        let ia2 = crate::interprocedural::build_interprocedural_analysis(
            &module2,
            &registry(),
            None,
            crate::interprocedural::ObjectTypeMap::none(),
            crate::realm::CommandBindingRealm::none(),
            None,
        );
        assert_eq!(
            resolve_proc_qname("foo", "::a::b::c", &ia2).as_deref(),
            Some("::a::b::c::foo"),
        );
    }

    #[test]
    fn resolve_proc_qname_relative_dotted_word_prefers_current_namespace() {
        // A relative *dotted* word (`ns2::inner`, containing `::` but not
        // starting with it) must resolve against the current namespace
        // first, not be rooted straight at global — the same rule
        // `bareword_resolution_candidates` documents (confirmed against
        // tclsh 9.0.4). Two procs of this shape exist here, one nested
        // under `::ns` and one at the root; a bare `ns2::inner` call from
        // inside `::ns` must reach the nearer one.
        let module = crate::lowering::lower_to_ir(
            "proc ns2::inner {} { return 1 }\n\
             namespace eval ::ns {\n proc ns2::inner {} { return 2 }\n proc caller {} { ns2::inner }\n}",
            &registry(),
        );
        let ia = crate::interprocedural::build_interprocedural_analysis(
            &module,
            &registry(),
            None,
            crate::interprocedural::ObjectTypeMap::none(),
            crate::realm::CommandBindingRealm::none(),
            None,
        );
        assert!(fixture_id_if_present(&ia.procedures, "::ns2::inner").is_some());
        assert!(fixture_id_if_present(&ia.procedures, "::ns::ns2::inner").is_some());
        assert_eq!(
            resolve_proc_qname("ns2::inner", "::ns", &ia).as_deref(),
            Some("::ns::ns2::inner"),
            "a relative dotted call must prefer the current-namespace proc \
             over the root one",
        );
        // Falls back to the root proc when there is no current-namespace
        // candidate.
        assert_eq!(
            resolve_proc_qname("ns2::inner", "::other", &ia).as_deref(),
            Some("::ns2::inner"),
        );
    }

    /// Run the whole optimiser (raw, unfiltered) so the registry is
    /// threaded — needed for the O127 store-to-load-forwarding pass,
    /// which bails without a registry.
    fn o127(source: &str) -> Vec<Optimisation> {
        crate::optimiser::optimise_raw_for_profile(
            source,
            &registry(),
            Some(tcl_registry::model::ingress::resolve_environment("tcl8.6").analyser_profile()),
        )
        .into_iter()
        .filter(|o| o.code == DiagCode::O127)
        .collect()
    }

    #[test]
    fn o127_forwards_single_use_computed_assignment() {
        // `set x [llength $y]` is computed and used once → inline at the
        // use site + delete the store, both O127 in one group.
        let src = "proc p {y} {\n    set x [llength $y]\n    puts $x\n}\n";
        let opts = o127(src);
        assert_eq!(opts.len(), 2, "{opts:?}");
        // Both edits share a group id (all-or-nothing).
        assert_eq!(opts[0].group, opts[1].group);
        assert!(opts[0].group.is_some());
        // One edit inlines `[set x [llength $y]]`; the other deletes.
        assert!(
            opts.iter()
                .any(|o| o.replacement.contains("[set x [llength $y]]"))
        );
        assert!(opts.iter().any(|o| o.replacement.is_empty()));
    }

    #[test]
    fn o127_operand_selection_follows_the_actual_alias_cell() {
        use crate::ssa::SsaSourceView;
        let registry = tcl_registry::model::ingress::static_context_for("tcl8.6").commands();
        for names in [("value", "pointer"), ("pointer", "value")] {
            let source = format!(
                "proc p {{input}} {{set {} [llength $input]; set other [llength $input]; upvar 0 {} {}; puts ${{{}}}}}",
                names.0, names.0, names.1, names.1
            );
            let unit = CompilationUnit::build_for(&source, registry, false);
            let function = unit.function("::p").unwrap();
            let mut checked = false;
            for (&block, body) in &function.ssa.blocks {
                for (index, statement) in body.statements.iter().enumerate() {
                    let Some(tokens) = statement.statement.tokens() else {
                        continue;
                    };
                    if tokens.argv_texts.first().map(String::as_str) != Some("puts") {
                        continue;
                    }
                    let view = SsaSourceView::at_statement(&function.ssa, block, index);
                    let operand = &tokens.words()[1];
                    let read = view.read_word(operand).unwrap();
                    let version = read.version.unwrap();
                    let (span, prior_effect) = locate_use_var(
                        tokens,
                        view,
                        read.symbol,
                        version,
                        registry,
                        unit.ir_module.lexer_config,
                    )
                    .unwrap();
                    assert!(!prior_effect);
                    let span = tcl_lexer::word_span_at(&source, span);
                    assert_eq!(
                        &source[span.start() as usize..span.end() as usize],
                        format!("${{{}}}", names.1)
                    );
                    let other = view.reaching_binding("other", registry).unwrap().symbol;
                    assert_ne!(other, read.symbol);
                    assert!(
                        locate_use_var(
                            tokens,
                            view,
                            other,
                            version,
                            registry,
                            unit.ir_module.lexer_config
                        )
                        .is_none()
                    );
                    checked = true;
                }
            }
            assert!(checked);
            assert!(
                o127(&source).is_empty(),
                "an aliased receiver cannot move its store"
            );
        }
    }

    #[test]
    fn o127_observed_alias_receiver_keeps_its_original_store() {
        let source = "proc observe args {}; proc p {input} {set value [llength $input]; upvar 0 value pointer; trace add variable pointer write observe; puts $pointer}";
        assert_eq!(o127(source), [] as [crate::optimiser::Optimisation; 0]);
    }

    #[test]
    fn o127_skips_intervening_side_effect() {
        // The intervening `puts` is impure → forwarding past it is
        // unsafe.
        let src = "proc p {y} {\n    set x [llength $y]\n    puts hi\n    puts $x\n}\n";
        assert_eq!(o127(src).len(), 0, "{:?}", o127(src));
    }

    #[test]
    fn o127_skips_intervening_upframe() {
        // An intervening `uplevel` lowers to a `Statement::UpFrame`,
        // whose opaque body can reach into / out of this frame and
        // mutate any name the forwarded `[llength $y]` reads.  It must
        // suppress the forward exactly like a barrier — otherwise the
        // re-evaluated inline could compute a different value.
        let src =
            "proc p {y} {\n    set x [llength $y]\n    uplevel 1 {incr ::n}\n    puts $x\n}\n";
        assert_eq!(o127(src).len(), 0, "{:?}", o127(src));
    }

    #[test]
    fn o127_skips_command_substitution_before_endpoint_use() {
        // Tcl substitutes words left-to-right. Moving the `llength` past the
        // preceding substitution would make it observe the emptied `y`.
        let src = "proc p {y} {\n    set x [llength $y]\n    puts [set y {}] $x\n}\n";
        assert_eq!(o127(src).len(), 0, "{:?}", o127(src));
    }

    #[test]
    fn o127_skips_multiple_uses() {
        // Two uses of `$x` → not single-use, no forwarding.
        let src = "proc p {y} {\n    set x [llength $y]\n    puts $x\n    puts $x\n}\n";
        assert_eq!(o127(src).len(), 0, "{:?}", o127(src));
    }

    #[test]
    fn o127_forwards_past_extra_terminator_use() {
        // `$x` has one operand use (`baz $x`) plus a terminator use
        // (`return $x`). Def-use records the terminator use, but it must not
        // block the forward — the forward still fires into the operand use
        // while preserving the assignment for the `return`. The inlined
        // `[set x …]` keeps `x` defined for the trailing `return`.
        let src = "proc baz {value} {return $value}\nproc p {y} {\n    set x [llength $y]\n    baz $x\n    return $x\n}\n";
        let opts = o127(src);
        assert_eq!(opts.len(), 2, "{opts:?}");
        assert!(
            opts.iter()
                .any(|o| o.replacement.contains("[set x [llength $y]]")),
            "{opts:?}"
        );
    }

    #[test]
    fn o127_declines_a_later_unproved_call_after_an_opaque_endpoint() {
        let source = "proc p {y} {set x [llength $y]; baz $x; return $x}";
        assert_eq!(o127(source), [] as [crate::optimiser::Optimisation; 0]);
    }

    #[test]
    fn o127_skips_literal_assignment() {
        // A literal `set x 5` is the O102 path, not O127.
        let src = "proc p {} {\n    set x 5\n    puts $x\n}\n";
        assert_eq!(o127(src).len(), 0, "{:?}", o127(src));
    }

    // internal helpers

    /// The `${…}` closer comes from the shared owner, so the constant this
    /// rewrite inlines belongs to the name the lexer spanned.
    ///
    /// The rewritten text is written back into the document as an O100 fix, so
    /// resolving the wrong name substitutes some other variable's value into
    /// the user's string.
    #[test]
    fn substitute_dollar_refs_follows_the_release_close_rule() {
        use tcl_dialect::BracedVarStyle::{FirstClose, Tcl9Nesting};
        let braced = |braced_var| tcl_lexer::LexerConfig {
            braced_var,
            ..tcl_lexer::LexerConfig::default()
        };
        let mut c = std::collections::HashMap::new();
        c.insert("a{b}c".to_owned(), "NESTED".to_owned());
        c.insert("a{b".to_owned(), "FIRST".to_owned());

        // 9.x names `a{b}c`; the whole reference is consumed.
        assert_eq!(
            substitute_dollar_refs("v=${a{b}c}", &c, braced(Tcl9Nesting)).as_deref(),
            Some("v=NESTED")
        );
        // 8.x names `a{b`, and `c}` stays as literal word text.
        assert_eq!(
            substitute_dollar_refs("v=${a{b}c}", &c, braced(FirstClose)).as_deref(),
            Some("v=FIRSTc}")
        );
        // An unterminated reference declines the whole rewrite rather than
        // inventing a name that runs to end-of-input.
        assert!(substitute_dollar_refs("v=${a{b", &c, braced(Tcl9Nesting)).is_none());
    }

    #[test]
    fn interpolation_uses_retained_close_policy_over_catalogue_profile() {
        // naming.compiler.original-analysis-metadata-context
        // docs/design/analysis/name-resolution-proofs/original-analysis-metadata-context.md
        // Lexical rewrite software control, not variable/frame or Native evidence.
        let source = "\"v=${a{b}c}\"";
        let profile = tcl_dialect::DialectProfile::find("tcl8.6").unwrap();
        let mut context =
            PassContext::with_dialect(source, InterproceduralAnalysis::default(), Some(profile));
        let original_config = context.lexer_config();
        context.source_lexer_config = Some(tcl_lexer::LexerConfig {
            braced_var: tcl_dialect::BracedVarStyle::Tcl9Nesting,
            ..tcl_lexer::LexerConfig::from_grammar(profile.grammar)
        });
        let registry_context =
            tcl_registry::model::ingress::resolve_environment("tcl8.6").default_context_registry();
        let registry = registry_context.commands();
        let module_for = |config| {
            let input = crate::analyser::ResolvedAnalysisInput::new(
                profile,
                profile,
                std::sync::Arc::clone(&registry_context),
                config,
            );
            let mut lowerer = crate::lowering::Lowerer::with_config(registry, config)
                .with_resolved_analysis_input(input);
            lowerer.lower(source);
            lowerer.finish_module(source)
        };
        let selected_module = module_for(context.lexer_config());
        context.registry = Some(registry);
        context.ir_module = Some(&selected_module);
        let constants = std::collections::HashMap::from([
            ("a{b}c".into(), "NESTED".into()),
            ("a{b".into(), "FIRST".into()),
        ]);
        let config = context.lexer_config();
        visit_string_interpolation(
            &mut context,
            tcl_lexer::Span::new(0, u32::try_from(source.len()).unwrap()),
            source,
            &constants,
            config,
        );
        assert_eq!(context.optimisations.len(), 1);
        assert_eq!(context.optimisations[0].replacement, "\"v=NESTED\"");
        context.source_lexer_config = None;
        let original_module = module_for(original_config);
        context.ir_module = Some(&original_module);
        context.optimisations.clear();
        let config = context.lexer_config();
        visit_string_interpolation(
            &mut context,
            tcl_lexer::Span::new(0, u32::try_from(source.len()).unwrap()),
            source,
            &constants,
            config,
        );
        assert_eq!(context.optimisations.len(), 1);
        assert_eq!(context.optimisations[0].replacement, "\"v=FIRSTc}\"");
    }

    #[test]
    fn interpolation_element_indices_keep_literal_braced_names_and_dynamic_refusal() {
        // naming.compiler.original-analysis-metadata-context
        // docs/design/analysis/name-resolution-proofs/original-analysis-metadata-context.md
        let constants = std::collections::HashMap::from([
            ("a($idx)".into(), "ELEMENT".into()),
            ("a($idx".into(), "SCALAR".into()),
        ]);
        let config = tcl_lexer::LexerConfig::for_dialect("tcl8.6");
        assert_eq!(
            substitute_dollar_refs("v=$a($idx)", &constants, config).as_deref(),
            Some("v=$a($idx)")
        );
        assert_eq!(
            substitute_dollar_refs("v=${a($idx)}", &constants, config).as_deref(),
            Some("v=ELEMENT")
        );
        assert_eq!(
            substitute_dollar_refs("v=${a($idx}", &constants, config).as_deref(),
            Some("v=SCALAR")
        );
    }

    #[test]
    fn retained_substitution_inventory_keeps_module_input_config_and_availability() {
        // naming.compiler.original-analysis-metadata-context
        // docs/design/analysis/name-resolution-proofs/original-analysis-metadata-context.md
        // Conditional original child geometry, without handler or erasure permission.
        let context =
            tcl_registry::model::ingress::resolve_environment("tcl8.6").default_context_registry();
        let profile = tcl_dialect::DialectProfile::find("tcl").unwrap();
        let config = tcl_lexer::LexerConfig {
            expand_syntax: false,
            strict_quoting: true,
            ..tcl_lexer::LexerConfig::from_grammar(profile.grammar)
        };
        let input = crate::analyser::ResolvedAnalysisInput::new(
            profile,
            profile,
            std::sync::Arc::clone(&context),
            config,
        );
        let unit = CompilationUnit::build_with_analysis_input(
            "expr {[dict size [dict create key value]]}",
            crate::compilation_unit::UnitBuildOptions {
                registry: context.commands(),
                defer_top_level: false,
                config,
                dialect: Some(profile),
                external_call_sites: None,
                declared_commands: None,
            },
            None,
            &input,
        );
        assert!(unit.ir_module.source_entry.native_entry.is_none());
        let module = &unit.ir_module;
        let script = &module.top_level;
        let tokens = script
            .retained_source_tokens_for_statement(&script.statements[0])
            .unwrap();
        let calls = retained_substitution_calls(tokens, module, context.commands()).unwrap();
        assert_eq!(calls.len(), 2);
        assert!(
            calls
                .iter()
                .all(|call| call.tokens.as_ref().is_some_and(|tokens| tokens
                    .source_binding
                    .as_ref()
                    .is_some_and(|binding| binding.invocation_site().is_some())))
        );
        for change in 0..5 {
            let mut changed = module.clone();
            match change {
                0 => changed.retained_source_bindings = None,
                1 => changed.source_entry.unknown_entry = !changed.source_entry.unknown_entry,
                2 => changed.top_level_namespace = "::other".into(),
                3 => {
                    changed.native_namespace =
                        Some(tcl_core_types::ByteNamespacePath::from_segments(["other"]))
                }
                4 => changed.top_level_kind = crate::ir::TopLevelKind::ProcedureBody,
                _ => unreachable!(),
            }
            assert!(
                crate::registry_invocation::InvocationMetadataContext::for_module(
                    context.commands(),
                    &changed
                )
                .is_some()
            );
            assert!(retained_substitution_calls(tokens, &changed, context.commands()).is_none());
        }
        let mut changed = module.clone();
        changed.lexer_config.expand_syntax = true;
        assert!(retained_substitution_calls(tokens, &changed, context.commands()).is_none());
        let older = std::sync::Arc::new(
            tcl_registry::model::ingress::static_context_for("tcl8.4")
                .with_command_store(std::sync::Arc::clone(context.commands())),
        );
        assert!(std::sync::Arc::ptr_eq(older.commands(), context.commands()));
        let foreign =
            tcl_registry::model::ingress::resolve_environment("tcl9.1").default_context_registry();
        for supplied in [Some(older), Some(foreign), None] {
            changed = module.clone();
            changed.source_metadata_input = supplied.map(|availability| {
                crate::analyser::ResolvedAnalysisInput::new(profile, profile, availability, config)
            });
            assert!(retained_substitution_calls(tokens, &changed, context.commands()).is_none());
        }
    }

    #[test]
    fn simple_var_ref_parses_bare_and_braced() {
        let config = tcl_lexer::LexerConfig::for_dialect("tcl9.0");
        assert_eq!(
            whole_scalar_variable_reference_name("$foo", config),
            Some("foo")
        );
        assert_eq!(
            whole_scalar_variable_reference_name("${bar}", config),
            Some("bar")
        );
        assert!(whole_scalar_variable_reference_name("$foo(idx)", config).is_none());
        assert!(whole_scalar_variable_reference_name("plain", config).is_none());
    }

    #[test]
    fn safe_bare_word_accepts_int_and_safe_words() {
        assert!(is_value_safe_bare_word("42"));
        assert!(is_value_safe_bare_word("-7"));
        assert!(is_value_safe_bare_word("foo_bar"));
        assert!(!is_value_safe_bare_word(""));
        assert!(!is_value_safe_bare_word("has space"));
        assert!(!is_value_safe_bare_word("$dollar"));
    }

    // end-to-end tests

    #[test]
    fn constant_int_propagates_into_call_arg() {
        let opts = run_pass("set x 42\nputs $x");
        assert!(
            opts.iter()
                .any(|o| o.code == DiagCode::O100 && o.replacement == "42"),
            "expected O100 propagating 42, got {opts:?}",
        );
    }

    #[test]
    fn unsafe_string_constant_is_not_propagated() {
        // Tcl metacharacters in the value → must not inline as
        // a bare word.
        let opts = run_pass("set x \"$other\"\nputs $x");
        assert!(
            opts.iter().all(|o| o.code != DiagCode::O100),
            "unsafe string should not be propagated, got {opts:?}",
        );
    }

    #[test]
    fn o100_multi_word_constant_renders_via_quoter() {
        // A constant containing whitespace or
        // metacharacters is re-rendered as a single self-contained word
        // via the canonical quoter instead of bailing.
        // `return` value position → `return {Hello World}`.
        let ret = run_pass("proc ::f {} { set msg {Hello World}\nreturn $msg }");
        assert!(
            ret.iter()
                .any(|o| o.code == DiagCode::O100 && o.replacement == "return {Hello World}"),
            "expected O100 `return {{Hello World}}`, got {ret:?}",
        );
        // Command-argument position → `puts {Hello World}`.
        let arg = run_pass("proc ::f {} { set msg {Hello World}\nputs $msg }");
        assert!(
            arg.iter()
                .any(|o| o.code == DiagCode::O100 && o.replacement == "{Hello World}"),
            "expected O100 `{{Hello World}}` arg, got {arg:?}",
        );
        // A `$`/`[`-bearing literal constant is brace-quoted (the value
        // is literal — braces suppress the would-be substitution).
        let meta = run_pass("proc ::f {} { set m {a$b}\nputs $m }");
        assert!(
            meta.iter()
                .any(|o| o.code == DiagCode::O100 && o.replacement == "{a$b}"),
            "expected O100 `{{a$b}}` arg, got {meta:?}",
        );
    }

    #[test]
    fn non_const_lattice_skipped() {
        // Two different writes to x → ConstSet or Overdefined,
        // not a single Const.
        let opts = run_pass("set x 1\nif {$cond} { set x 2 }\nputs $x");
        assert!(
            opts.iter().all(|o| o.code != DiagCode::O100),
            "non-const lattice should be skipped, got {opts:?}",
        );
    }

    #[test]
    fn braced_var_reference_also_propagated() {
        let opts = run_pass("set x 7\nputs ${x}");
        assert!(
            opts.iter()
                .any(|o| o.code == DiagCode::O100 && o.replacement == "7"),
            "expected O100 for braced var ref, got {opts:?}",
        );
    }

    #[test]
    fn return_literal_and_compound_names_do_not_borrow_scalar_constants() {
        for source in [
            "proc f {} {set x 42; return {$x}}",
            "proc f {} {set a 42; set a:b 99; return $a:b}",
            "proc f {} {set arr 42; return ${arr(k)}}",
        ] {
            let optimisations = run_pass(source);
            assert!(
                optimisations.iter().all(|optimisation| {
                    optimisation.code != DiagCode::O100
                        || !optimisation.replacement.starts_with("return ")
                }),
                "{source}: {optimisations:?}"
            );
        }
    }

    #[test]
    fn return_terminator_folds_constant_variable() {
        let opts = run_pass("proc ::f {} { set x 42; return $x }");
        assert!(
            opts.iter()
                .any(|o| o.code == DiagCode::O100 && o.replacement.contains("42")),
            "expected O100 folding return $x to return 42, got {opts:?}",
        );
    }

    #[test]
    fn static_proc_call_folds_to_constant_return() {
        // ::answer returns 42 unconditionally and is pure — a
        // call to ::answer can be folded.
        use tcl_registry::CommandRegistry;
        let registry = CommandRegistry::build_default();
        let cu = CompilationUnit::build_for(
            "proc ::answer {} { return 42 }\n::answer",
            &registry,
            false,
        )
        .with_interprocedural(&registry, None);
        let mut ctx = PassContext::new(&cu.source, cu.interproc.clone().unwrap_or_default());
        ctx.registry = Some(&registry);
        run(&mut ctx, &cu);
        assert!(
            ctx.optimisations.iter().any(|o| o.code == DiagCode::O103),
            "expected O103 static-proc fold, got {:?}",
            ctx.optimisations,
        );
    }

    #[test]
    fn return_expr_does_not_fold_stale_pre_loop_constant() {
        // `x` is overwritten by the loop, so its exit version at the return is
        // a non-Const phi (Overdefined). `::f` is pure but has no
        // argument-independent constant return, so `[::f]` reaches the
        // argument-sensitive fold's reading of a returned `expr`
        // (`interprocedural::exit_value`). That
        // fold must NOT leak the pre-loop `set x 0`: tclsh returns 3 (x ends
        // at 2), so folding `[::f]` to 1 would be a miscompile.
        use tcl_registry::CommandRegistry;
        let registry = CommandRegistry::build_default();
        let cu = CompilationUnit::build_for(
            "proc ::f {} { set x 0; foreach v {1 2} { set x $v }; return [expr {$x + 1}] }\nputs [::f]",
            &registry,
            false,
        )
        .with_interprocedural(&registry, None);
        let mut ctx = PassContext::new(&cu.source, cu.interproc.clone().unwrap_or_default());
        ctx.registry = Some(&registry);
        run(&mut ctx, &cu);
        assert!(
            ctx.optimisations.iter().all(|o| o.code != DiagCode::O103),
            "loop-overwritten var must not fold from a stale pre-loop constant, got {:?}",
            ctx.optimisations,
        );
    }

    #[test]
    fn return_expr_after_unresolved_handler_does_not_fold_seeded_argument() {
        let registry = tcl_registry::CommandRegistry::build_default();
        let cu = CompilationUnit::build_for(
            "proc p {x} {missing_command; return [expr {$x + 1}]}\nputs [p 5]",
            &registry,
            false,
        )
        .with_interprocedural(&registry, None);
        let mut ctx = PassContext::new(&cu.source, cu.interproc.clone().unwrap_or_default());
        ctx.registry = Some(&registry);
        run(&mut ctx, &cu);
        assert!(
            ctx.optimisations.iter().all(|o| o.code != DiagCode::O103),
            "a handler can change the seeded argument: {:?}",
            ctx.optimisations
        );
    }

    #[test]
    fn return_expr_folds_argument_sensitive_constant() {
        // Control: the argument-sensitive Path 3 still folds when the return
        // expr genuinely depends only on the constant call arguments — the
        // documented `[::add 2 4]` → 6 case (params bound at version 0).
        use tcl_registry::CommandRegistry;
        let registry = CommandRegistry::build_default();
        let cu = CompilationUnit::build_for(
            "proc ::add {a b} { return [expr {$a + $b}] }\nputs [::add 2 4]",
            &registry,
            false,
        )
        .with_interprocedural(&registry, None);
        let mut ctx = PassContext::new(&cu.source, cu.interproc.clone().unwrap_or_default());
        ctx.registry = Some(&registry);
        run(&mut ctx, &cu);
        assert!(
            ctx.optimisations
                .iter()
                .any(|o| o.code == DiagCode::O103 && o.replacement == "6"),
            "expected O103 folding [::add 2 4] to 6, got {:?}; {}",
            ctx.optimisations,
            proc_fold_context(&cu, "::add"),
        );
    }

    #[test]
    fn string_interpolation_const_is_inlined() {
        // `set count 42` → Const(42) in SCCP → interpolation into
        // `"count is $count"` substitutes to `"count is 42"`.
        let opts = run_pass("set count 42\nputs \"count is $count\"");
        assert!(
            opts.iter()
                .any(|o| o.code == DiagCode::O100 && o.replacement.contains("42")),
            "expected O100 inlining count into interpolation, got {opts:?}",
        );
    }

    #[test]
    fn braced_expr_cmd_sub_arg_folds_under_constants() {
        // `puts [expr {$a + $b}]` with a, b proven constant folds the braced
        // expr in the call-argument position to its value.
        let opts = run_pass("set a 3\nset b 4\nputs [expr {$a + $b}]");
        assert!(
            opts.iter()
                .any(|o| o.code == DiagCode::O101 && o.replacement == "7"),
            "expected O101 folding [expr {{$a + $b}}] to 7, got {opts:?}",
        );
    }

    #[test]
    fn shadowed_mathfunc_cmd_sub_arg_not_folded() {
        // FP guard: `proc ::tcl::mathfunc::abs` shadows the builtin
        // everywhere in the module — the cmd-sub-argument O101 fold path
        // (try_o101_expr_arg_fold) must not fold `abs(-5)` using builtin
        // semantics.
        let opts = run_pass("proc ::tcl::mathfunc::abs {x} { return 999 }\nputs [expr {abs(-5)}]");
        assert!(
            opts.iter().all(|o| o.code != DiagCode::O101),
            "must not fold a shadowed math function in a cmd-sub argument: {opts:?}",
        );
    }

    #[test]
    fn shadowed_mathfunc_return_value_not_folded() {
        // FP guard: `return [expr {…}]` folding must also respect the
        // math-function shadow gate.
        use tcl_registry::CommandRegistry;
        let reg = CommandRegistry::build_default();
        let source =
            "proc ::tcl::mathfunc::abs {x} { return 999 }\nproc f {} { return [expr {abs(-5)}] }";
        let cu = CompilationUnit::build_for(source, &reg, false).with_interprocedural(&reg, None);
        let mut ctx = PassContext::new(&cu.source, cu.interproc.clone().unwrap_or_default());
        ctx.registry = Some(&reg);
        run(&mut ctx, &cu);
        assert!(
            ctx.optimisations.iter().all(|o| o.code != DiagCode::O101),
            "must not fold a shadowed math function in a return value: {:?}",
            ctx.optimisations,
        );
    }

    #[test]
    fn quoted_expr_cmd_sub_arg_not_folded_under_constants() {
        // `puts [expr "$a + $b"]` is the quoted form — it uses textual
        // substitution, so we conservatively never fold it.
        let opts = run_pass("set a 3\nset b 4\nputs [expr \"$a + $b\"]");
        assert!(
            opts.iter()
                .all(|o| !(o.code == DiagCode::O101 && o.replacement == "7")),
            "quoted expr must not fold under constants, got {opts:?}",
        );
    }

    /// Like [`run_pass`] but populates `ctx.command_mutations` from the
    /// whole module, the way the real pipeline does — needed to exercise
    /// the `expr`-redefinition trust gate.
    fn run_pass_with_mutations(source: &str) -> Vec<Optimisation> {
        let reg = registry();
        let cu = CompilationUnit::build_for(source, &reg, false);
        let mut ctx = PassContext::new(&cu.source, InterproceduralAnalysis::default());
        // Same production wiring `run_pass` above documents: the top-level
        // body's `scan_module_global_names` set is registry-resolved, so a
        // context without a registry is deliberately not propagated at all.
        ctx.registry = Some(&reg);
        ctx.command_mutations =
            crate::command_binding::scan_module_command_mutations(&cu.ir_module, &reg);
        ctx.ir_module = Some(&cu.ir_module);
        run(&mut ctx, &cu);
        ctx.optimisations
    }

    #[test]
    fn renamed_expr_cmd_sub_arg_not_folded() {
        // FP guard: once `expr` is renamed anywhere in the module,
        // `puts [expr {$a + $b}]` no longer calls the builtin evaluator.
        let opts = run_pass_with_mutations(
            "rename expr real_expr\nset a 3\nset b 4\nputs [expr {$a + $b}]",
        );
        assert!(
            opts.iter().all(|o| o.code != DiagCode::O101),
            "must not fold a cmd-sub through a renamed expr: {opts:?}",
        );
    }

    #[test]
    fn renamed_expr_assign_expr_substitution_not_folded() {
        // FP guard: `set x [expr {$a + $b}]` (the AssignExpr form,
        // try_substitute_assign_expr) must also respect the trust gate.
        let opts = run_pass_with_mutations("rename expr real_expr\nset a 3\nset x [expr {$a + 1}]");
        assert!(
            opts.iter()
                .all(|o| !(o.code == DiagCode::O100 || o.code == DiagCode::O101)),
            "must not propagate/fold set x [expr {{…}}] through a renamed expr: {opts:?}",
        );
    }

    #[test]
    fn ordinary_expr_cmd_sub_arg_still_folds_under_mutation_scan() {
        // TN/control: an unrelated module-wide mutation scan (no rename of
        // `expr` itself) must not block the fold.
        let opts = run_pass_with_mutations("set a 3\nset b 4\nputs [expr {$a + $b}]");
        assert!(
            opts.iter()
                .any(|o| o.code == DiagCode::O101 && o.replacement == "7"),
            "expected O101 fold under an unrelated mutation scan, got {opts:?}",
        );
    }

    #[test]
    fn renamed_expr_return_value_not_folded() {
        // FP guard: `return [expr {…}]` folding (try_fold_return_terminator)
        // must also respect the trust gate.
        use tcl_registry::CommandRegistry;
        let reg = CommandRegistry::build_default();
        let source = "rename expr real_expr\nproc f {} { return [expr {1 + 2}] }";
        let cu = CompilationUnit::build_for(source, &reg, false).with_interprocedural(&reg, None);
        let mut ctx = PassContext::new(&cu.source, cu.interproc.clone().unwrap_or_default());
        ctx.command_mutations =
            crate::command_binding::scan_module_command_mutations(&cu.ir_module, &reg);
        run(&mut ctx, &cu);
        assert!(
            ctx.optimisations.iter().all(|o| o.code != DiagCode::O101),
            "must not fold a renamed expr in a return value: {:?}",
            ctx.optimisations,
        );
    }

    #[test]
    fn string_interpolation_unknown_var_skipped() {
        // `$name` is not in the constants map → must not fire.
        let opts = run_pass("puts \"hello $name\"");
        assert!(
            opts.iter().all(|o| o.code != DiagCode::O100),
            "unknown var should not be inlined, got {opts:?}",
        );
    }

    #[test]
    fn substitute_dollar_refs_handles_braced_and_missing_vars() {
        let mut c = std::collections::HashMap::new();
        c.insert("x".into(), "42".into());
        assert_eq!(
            substitute_dollar_refs("a${x}b", &c, tcl_lexer::LexerConfig::default()).as_deref(),
            Some("a42b"),
        );
        // Missing var → None (cannot partially substitute).
        assert!(
            substitute_dollar_refs("$unknown", &c, tcl_lexer::LexerConfig::default()).is_none()
        );
    }

    /// Inside a command substitution a braced word substitutes nothing, so
    /// its `$x` stays; a `$x` elsewhere, including one after a mid-word
    /// brace, is inlined. tclsh 8.4.20 through 9.1b0 print `b:{$x}`,
    /// `b:{a $x b}`, `m:a{5}` and `w:{5} {$x} 5` for these (#2250).
    #[test]
    fn substitute_dollar_refs_leaves_a_braced_word_in_a_cmd_sub_as_written() {
        let mut c = std::collections::HashMap::new();
        c.insert("x".into(), "5".into());
        let sub = |text: &str| substitute_dollar_refs(text, &c, tcl_lexer::LexerConfig::default());
        for (text, want) in [
            ("b:[list {$x}]", "b:[list {$x}]"),
            ("b:[list {a $x b}]", "b:[list {a $x b}]"),
            ("b:[list [list {$x}]]", "b:[list [list {$x}]]"),
            ("s:[set y 1;list {$x}]", "s:[set y 1;list {$x}]"),
            ("c:[list {a]b} $x]", "c:[list {a]b} 5]"),
            ("b:[list {a\\}b $x}]", "b:[list {a\\}b $x}]"),
            ("m:[list a{$x}]", "m:[list a{5}]"),
            ("w:{$x} [list {$x}] $x", "w:{5} [list {$x}] 5"),
            // A `{` inside a quoted word of the substituted script is literal
            // text, and Tcl substitutes the `$x` after it (found in review).
            ("q:[list \"foo {$x}\"]", "q:[list \"foo {5}\"]"),
            ("q:[list \"a]b\" $x]", "q:[list \"a]b\" 5]"),
        ] {
            assert_eq!(sub(text).as_deref(), Some(want), "{text}");
        }
        // A braced word that never closes rewrites nothing.
        assert!(sub("b:[list {$x]").is_none_or(|r| r == "b:[list {$x]"));
    }

    /// Unchanged text keeps its bytes: copying a byte at a time as `char`
    /// turned `é` into `Ã©` (#2251).
    #[test]
    fn substitute_dollar_refs_keeps_non_ascii_text() {
        let mut c = std::collections::HashMap::new();
        c.insert("x".into(), "5".into());
        for (text, want) in [
            ("café $x", "café 5"),
            ("é\\t$x€", "é\\t5€"),
            ("v:[string length é$x]", "v:[string length é5]"),
        ] {
            assert_eq!(
                substitute_dollar_refs(text, &c, tcl_lexer::LexerConfig::default()).as_deref(),
                Some(want),
                "{text}"
            );
        }
    }

    #[test]
    fn substitute_dollar_refs_ends_the_empty_braced_name_at_its_brace() {
        let mut c = std::collections::HashMap::new();
        c.insert(String::new(), "5".into());
        for (text, want) in [
            ("a=${}b", "a=5b"),
            ("a=${}", "a=5"),
            ("${}${}", "55"),
            ("v:[list ${}]c", "v:[list 5]c"),
        ] {
            assert_eq!(
                substitute_dollar_refs(text, &c, tcl_lexer::LexerConfig::default()).as_deref(),
                Some(want),
                "{text}"
            );
        }
    }

    #[test]
    fn substitute_dollar_refs_guards_multiword_in_cmd_sub() {
        let mut c = std::collections::HashMap::new();
        c.insert("lst".into(), "a b c".into());
        c.insert("n".into(), "5".into());
        // A multi-word value in plain string text inlines verbatim (it stays
        // part of the one string word).
        assert_eq!(
            substitute_dollar_refs("x=$lst", &c, tcl_lexer::LexerConfig::default()).as_deref(),
            Some("x=a b c"),
        );
        // The SAME value inside a `[…]` command substitution would split one
        // argument into several — bail, keeping `$lst`.
        assert!(
            substitute_dollar_refs("r: [lsearch $lst x]", &c, tcl_lexer::LexerConfig::default())
                .is_none()
        );
        // A single-word value inside a cmd-sub is still safe to inline.
        assert_eq!(
            substitute_dollar_refs("r: [expr $n + 1]", &c, tcl_lexer::LexerConfig::default())
                .as_deref(),
            Some("r: [expr 5 + 1]"),
        );
    }

    #[test]
    fn whole_word_cmd_sub_not_wrapped_as_string_interpolation() {
        // Regression: `puts [expr {$a + $b}]` is a free-standing command
        // substitution, not a `"…"` string. The interpolation path must not
        // wrap it in quotes / mis-span it (which produced the corrupt
        // `puts "[expr {3 + 4}]"]`). No O100 string-interpolation rewrite may
        // fire on a whole-word `[…]`.
        let opts = run_pass("set a 3\nset b 4\nputs [expr {$a + $b}]");
        assert!(
            opts.iter()
                .all(|o| o.replacement != "\"[expr {3 + 4}]\"" && !o.replacement.contains("\"]")),
            "whole-word cmd-sub must not be string-interpolated, got {opts:?}",
        );
    }

    #[test]
    fn list_constant_not_inlined_into_string_cmd_sub() {
        // Regression: `[lsearch -exact $tokens uic]` must NOT become
        // `[lsearch -exact tran 1n 100n uic uic]` — that splits the list into
        // separate args and errors at runtime (`bad option "tran"`).
        let opts =
            run_pass("set tokens {tran 1n 100n uic}\nputs \"r: [lsearch -exact $tokens uic]\"");
        assert!(
            opts.iter()
                .all(|o| !o.replacement.contains("tran 1n 100n uic uic")),
            "list literal must not be word-split into the cmd-sub, got {opts:?}",
        );
    }

    #[test]
    fn load_forwarding_fires_o102_for_single_reaching_def() {
        // `set n 7; puts $n` — single reaching def is literal 7
        // → emit O102 on the puts use site.
        let opts = run_pass("set n 7\nputs $n");
        assert!(
            opts.iter().any(|o| o.code == DiagCode::O102),
            "expected O102 load-forwarding, got {opts:?}",
        );
    }

    /// A definition whose value SCCP proved still forwards.
    ///
    /// `set a 1; incr a` leaves `a` provably `2`, and that is what a use of it
    /// should see. O102 only ever recognised a *syntactic* literal as a
    /// reaching definition, so the chain stopped at the `incr` and the whole
    /// snippet optimised to nothing. The name-keyed `sccp_constants_for`
    /// projection cannot rescue it either: `a` holds `1` at one version and
    /// `2` at another, so that map drops the variable entirely.
    #[test]
    fn a_computed_definition_forwards_the_constant_sccp_proved() {
        for (source, want) in [
            ("set a 1\nincr a\nputs \"$a\"\n", "2"),
            ("set a 1\nincr a\nputs $a\n", "2"),
            ("set a 1\nincr a 5\nputs $a\n", "6"),
        ] {
            let opts = run_pass(source);
            assert!(
                opts.iter()
                    .any(|o| o.code == DiagCode::O100 && !o.hint_only && o.replacement == want),
                "expected an applicable O100 inlining {want:?} for {source:?}, got {opts:?}",
            );
        }
    }

    /// A hint-only forward records no replacement.
    ///
    /// Its span is the whole consuming statement, so the literal is not a
    /// valid replacement for it — recording one anyway is what let a hint on
    /// `incr a` read as a one-click rewrite to a bare `1`.
    #[test]
    fn a_hint_only_forward_carries_no_replacement() {
        let opts = run_pass("set n 7\nputs \"n=$n\"\n");
        let hints: Vec<&Optimisation> = opts.iter().filter(|o| o.hint_only).collect();
        assert!(!hints.is_empty(), "expected a hint-only O102, got {opts:?}");
        assert!(
            hints.iter().all(|o| o.replacement.is_empty()),
            "a hint with no sub-span target must carry no payload, got {hints:?}",
        );
    }

    /// A variable-*name* argument is not an operand, so no propagation code
    /// may target it.
    ///
    /// `set a 1; incr a` has one reaching literal for `a`, and `incr a`'s only
    /// mention of `a` names the cell it mutates. Forwarding the literal there
    /// produced `O102 … → 1` over the whole of `incr a`: a rewrite that
    /// destroys the increment and leaves `1` in command position, where tclsh
    /// answers `invalid command name "1"`. It was unreachable behind the
    /// `hint_only` guard, but it was a wrong payload sitting one guard away
    /// from being applied, and wrong advice about the statement either way.
    #[test]
    fn no_o1xx_targets_a_variable_name_argument() {
        // One row per registry role that names a variable rather than passing
        // a value: `VarWrite` read-modify-write, `VarRead`, and the
        // destroying form. Each is the *only* mention of the variable in its
        // statement, so any O1xx on that line is targeting the name.
        for source in [
            "set a 1\nincr a\n",
            "set a 1\nappend a x\n",
            "set a 1\nlappend a x\n",
            "set a 1\ndict incr a k\n",
            "set a 1\ninfo exists a\n",
            "set a 1\nunset a\n",
            "set a 1\nbinary scan xy c a\n",
            "set a 1\nregexp {(x)} xy -> a\n",
        ] {
            let opts = run_pass(source);
            let forwarded: Vec<&Optimisation> = opts
                .iter()
                .filter(|o| o.code.as_str().starts_with("O1") && o.replacement == "1")
                .collect();
            assert_eq!(
                forwarded.len(),
                0,
                "no O1xx may forward the literal into a variable-name position \
                 of {source:?}, got {forwarded:?}",
            );
        }
    }

    /// The guard is about the *position*, not the command: the same commands
    /// still forward into a genuine operand word beside the name.
    #[test]
    fn a_value_operand_beside_a_name_argument_still_forwards() {
        let opts = run_pass("set n 7\nset a {}\nlappend a $n\n");
        assert!(
            opts.iter().any(|o| o.code == DiagCode::O102),
            "the `$n` operand is still an operand, got {opts:?}",
        );
    }

    // A computed variable name (`set $name 2`) between the
    // "sole" reaching def and the use can rewrite `x` under a spelling the
    // def-use chains cannot see: `f x` prints 2 in tclsh, so forwarding the
    // literal 1 (via O102's chain scan or O100's SCCP projection) is a
    // miscompile. The whole function abstains.
    #[test]
    fn dynamic_name_write_blocks_load_forwarding() {
        let opts = run_pass("proc ::f {name} { set x 1; set $name 2; puts $x }");
        assert!(
            opts.iter()
                .all(|o| !matches!(o.code, DiagCode::O100 | DiagCode::O102)),
            "must not forward the pre-dynamic-write literal 1, got {opts:?}",
        );
    }

    /// The native-stack depth cap is not evidence that no
    /// dynamic write exists below it. Keep the actual O100/O102 consumer in
    /// this regression: the source mutation is hidden past the cap, yet it
    /// must still prevent forwarding the stale `x = 1` into the return.
    #[test]
    fn depth_exhaustion_blocks_dynamic_name_load_forwarding() {
        let mut nested = "[set $name 2]".to_owned();
        for _ in 0..=crate::depth_guard::MAX_BRACKET_TEXT_DEPTH.0 {
            nested = format!("[list {nested}]");
        }
        let source = format!("proc ::f {{name}} {{ set x 1; set sink {nested}; return $x }}");
        let reg = registry();
        let cu = CompilationUnit::build_for(&source, &reg, false);
        assert_eq!(
            cu.function("::f")
                .expect("procedure analysed")
                .dynamic_names,
            crate::dynamic_names::DynamicNameBarrier::OPAQUE_SCRIPT,
            "the depth cap must fail closed before the optimiser runs"
        );
        let mut ctx = PassContext::new(&cu.source, InterproceduralAnalysis::default());
        ctx.registry = Some(&reg);
        ctx.ir_module = Some(&cu.ir_module);
        run(&mut ctx, &cu);
        let opts = ctx.optimisations;
        assert!(
            opts.iter().all(|opt| {
                !matches!(opt.code, DiagCode::O100 | DiagCode::O102)
                    || opt.replacement != "return 1"
            }),
            "a hidden dynamic write must block the stale return fold: {opts:?}"
        );
    }

    // Regression: a top-level `global` name reassigned by a proc call must
    // never be folded as if its "sole reaching def" were stable — on tclsh
    // 8.6/9.0, `set tcl_precision 4; proc helper {} {global tcl_precision;
    // set tcl_precision 17}; helper; puts $tcl_precision` prints `17`, not
    // the `4` a sole-reaching-def fold would give.  See
    // `crate::var_observability::scan_module_global_names`.
    #[test]
    fn o102_does_not_forward_top_level_global_reassigned_by_callee() {
        let src = "set g 4\nproc helper {} { global g\nset g 17 }\nhelper\nputs $g";
        let opts = run_pass(src);
        assert!(
            opts.iter()
                .all(|o| !(matches!(o.code, DiagCode::O100 | DiagCode::O102)
                    && o.replacement == "4")),
            "must not fold the stale pre-call literal 4, got {opts:?}",
        );
    }

    // TN control: an ordinary proc that itself `global`-declares the name it
    // reassigns is *already* protected via SCCP/O100's per-function escaping
    // set — O102's independent def-use-chain path must apply the identical
    // guard rather than bypassing it (this fired incorrectly before O102
    // consulted `var_observability` at all).
    #[test]
    fn o102_does_not_forward_proc_local_global_reassigned_by_callee() {
        let src = "proc p {} {\n    global g\n    set g 4\n    helper\n    puts $g\n}\nproc helper {} { global g\nset g 17 }\n";
        let opts = run_pass(src);
        assert!(
            opts.iter()
                .all(|o| !(matches!(o.code, DiagCode::O100 | DiagCode::O102)
                    && o.replacement == "4")),
            "must not fold the stale pre-call literal 4, got {opts:?}",
        );
    }

    // Precision control: a top-level name that *no* procedure ever
    // `global`-declares must still fold — the whole-module scan must not
    // over-widen to every top-level variable.
    //
    // Note this now folds via O100, not O102: the intervening call to
    // `other` is a command O102 cannot prove pure (it has no interprocedural
    // purity or upvar-reach information — a callee can dynamically alias
    // any name in the caller's frame via `upvar` with no textual
    // `global`/`variable` declaration anywhere), so O102's own independent
    // same-block scan conservatively withholds. SCCP (O100) already proves
    // `safe_const` a genuine whole-function constant via its own escaping
    // set (which correctly found no alias/trace anywhere for it), so the
    // fold still happens end to end.
    #[test]
    fn o102_still_forwards_top_level_global_no_proc_touches() {
        let src = "set safe_const 42\nproc other {} { puts unrelated }\nother\nputs $safe_const";
        let opts = run_pass(src);
        assert!(
            opts.iter().any(|o| matches!(o.code, DiagCode::O100 | DiagCode::O102)
                && o.replacement == "42"),
            "expected an untouched top-level constant to still fold, got {opts:?}",
        );
    }

    // TN control: a plain proc-local variable (never `global`/`variable`
    // declared) is genuinely private to that call frame — O102 must still
    // forward it.
    #[test]
    fn o102_still_forwards_genuinely_local_proc_variable() {
        let src = "proc p {} {\n    set n 7\n    puts $n\n}\n";
        let opts = run_pass(src);
        assert!(
            opts.iter()
                .any(|o| o.code == DiagCode::O102 && o.replacement == "7"),
            "expected O102 to still fold a genuinely private proc-local var, got {opts:?}",
        );
    }

    // Regression: a literal-body `interp eval {}` (targeting the *current*
    // interpreter — Tcl's documented meaning of the empty-string path) can
    // reassign a variable in the calling scope exactly like an opaque call,
    // even though it carries no `global`/`variable`/`upvar`/`trace`
    // declaration for it. Confirmed against tclsh 8.6/9.0: `set n 5; interp
    // eval {} {set n 99}; puts $n` prints `99`, not the stale `5`.
    #[test]
    fn o102_does_not_forward_past_interp_eval_barrier() {
        let src = "set n 5\ninterp eval {} { set n 99 }\nputs $n\n";
        let opts = run_pass(src);
        assert!(
            opts.iter()
                .all(|o| !(o.code == DiagCode::O102 && o.replacement == "5")),
            "must not forward the stale literal 5 past `interp eval {{}}`, got {opts:?}",
        );
    }

    // Regression: a literal-body `uplevel #0 {…}` evaluates in the absolute
    // global frame — at top level that coincides with the calling scope, so
    // it can reassign a variable there too, with no alias declaration of its
    // own. Confirmed against tclsh 8.6/9.0: `set n 5; uplevel #0 {set n
    // 99}; puts $n` prints `99`.
    #[test]
    fn o102_does_not_forward_past_uplevel_hash0_upframe() {
        let src = "set n 5\nuplevel #0 { set n 99 }\nputs $n\n";
        let opts = run_pass(src);
        assert!(
            opts.iter()
                .all(|o| !(o.code == DiagCode::O102 && o.replacement == "5")),
            "must not forward the stale literal 5 past `uplevel #0`, got {opts:?}",
        );
    }

    #[test]
    fn o102_operand_span_fires_applicable_on_call_argv() {
        // `set n 7; puts $n` — the O102 emitted on the puts use
        // must target the `$n` argv span (not the whole Call) and
        // be applicable (not hint-only). The argv span lands on
        // the last 2 chars of the source: `$n`.
        let source = "set n 7\nputs $n";
        let opts = run_pass(source);
        let o102s: Vec<_> = opts.iter().filter(|o| o.code == DiagCode::O102).collect();
        assert!(
            !o102s.is_empty(),
            "expected at least one O102, got {opts:?}"
        );
        let found = o102s.iter().any(|o| {
            let start = o.span.start() as usize;
            let end = o.span.end() as usize;
            !o.hint_only
                && o.replacement == "7"
                && end <= source.len()
                && &source[start..end] == "$n"
        });
        assert!(
            found,
            "expected applicable O102 with argv span covering `$n`, got {o102s:?}"
        );
    }

    #[test]
    fn o102_operand_span_matches_braced_var_word() {
        // ${n} forms must also be recognised at the argv-text
        // level and produce an applicable rewrite.
        let source = "set n 7\nputs ${n}";
        let opts = run_pass(source);
        let o102s: Vec<_> = opts.iter().filter(|o| o.code == DiagCode::O102).collect();
        assert!(
            o102s.iter().any(|o| !o.hint_only
                && o.replacement == "7"
                && &source[o.span.start() as usize..o.span.end() as usize] == "${n}"),
            "expected applicable O102 over ${{n}}, got {o102s:?}",
        );
    }

    #[test]
    fn o102_falls_back_to_hint_only_when_var_is_inside_interpolation() {
        // `$n` appears only inside a double-quoted composite word
        // — no argv text matches the bare `$n` form, so the
        // rewrite stays hint-only (the O100 string-interpolation
        // path handles the actual inlining).
        let source = "set n 7\nputs \"n=$n\"";
        let opts = run_pass(source);
        let o102s: Vec<_> = opts.iter().filter(|o| o.code == DiagCode::O102).collect();
        assert!(!o102s.is_empty(), "expected O102 hint, got {opts:?}");
        assert!(
            o102s.iter().all(|o| o.hint_only),
            "expected all O102s to be hint-only for interpolated use, got {o102s:?}",
        );
    }

    #[test]
    fn o103_cmd_subst_fires_applicable_rewrite() {
        // `[::answer]` inside an argv → applicable O103 with the
        // argv span covering `[::answer]` and the constant return
        // as replacement.
        use tcl_registry::CommandRegistry;
        let registry = CommandRegistry::build_default();
        let source = "proc ::answer {} { return 42 }\nputs [::answer]";
        let cu = CompilationUnit::build_for(source, &registry, false)
            .with_interprocedural(&registry, None);
        let mut ctx = PassContext::new(&cu.source, cu.interproc.clone().unwrap_or_default());
        ctx.registry = Some(&registry);
        run(&mut ctx, &cu);
        let o103s: Vec<_> = ctx
            .optimisations
            .iter()
            .filter(|o| o.code == DiagCode::O103)
            .collect();
        assert!(
            o103s.iter().any(|o| !o.hint_only
                && o.replacement == "42"
                && &source[o.span.start() as usize..o.span.end() as usize] == "[::answer]"),
            "expected applicable O103 spanning `[::answer]`, got {o103s:?}",
        );
    }

    #[test]
    fn o103_folds_multi_word_string_return_list_quoted() {
        // A pure proc returning a multi-word
        // string folds in a cmd-sub position, list-quoted as one word
        // (a bare `a b c` is not a safe single word).
        use tcl_registry::CommandRegistry;
        let registry = CommandRegistry::build_default();
        let source = "proc ::greet {} { return \"a b c\" }\nputs [::greet]";
        let cu = CompilationUnit::build_for(source, &registry, false)
            .with_interprocedural(&registry, None);
        let mut ctx = PassContext::new(&cu.source, cu.interproc.clone().unwrap_or_default());
        ctx.registry = Some(&registry);
        run(&mut ctx, &cu);
        let o103s: Vec<_> = ctx
            .optimisations
            .iter()
            .filter(|o| o.code == DiagCode::O103)
            .collect();
        assert!(
            o103s
                .iter()
                .any(|o| !o.hint_only && o.replacement == "{a b c}"),
            "expected applicable O103 folding [::greet] to {{a b c}}, got {o103s:?}",
        );
    }

    #[test]
    fn o103_cmd_subst_fires_on_set_value_target() {
        // The value-position cmd-sub folds must also
        // fire on a `set TARGET [cmd-sub]` target. `set` lowers to
        // `AssignValue`, which `walk_statement` did not visit for cmd-sub
        // folds, so `set y [::answer]` missed the O103 fold that the same
        // `[::answer]` gets in a command-argument position (`puts
        // [::answer]`). With the AssignValue arm wired, the set value
        // folds identically.
        use tcl_registry::CommandRegistry;
        let registry = CommandRegistry::build_default();
        let source = "proc ::answer {} { return 42 }\nproc ::f {} { set y [::answer]\nputs $y }";
        let cu = CompilationUnit::build_for(source, &registry, false)
            .with_interprocedural(&registry, None);
        let mut ctx = PassContext::new(&cu.source, cu.interproc.clone().unwrap_or_default());
        ctx.registry = Some(&registry);
        run(&mut ctx, &cu);
        let o103s: Vec<_> = ctx
            .optimisations
            .iter()
            .filter(|o| o.code == DiagCode::O103)
            .collect();
        assert!(
            o103s.iter().any(|o| !o.hint_only
                && o.replacement == "42"
                && &source[o.span.start() as usize..o.span.end() as usize] == "[::answer]"),
            "expected applicable O103 spanning the `[::answer]` set value, got {o103s:?}",
        );
    }

    #[test]
    fn o103_scoped_call_withdraws_later_callee_changes_and_unknown_entry() {
        for source in [
            "proc answer {} {return 42}; proc f {} {set y [answer]}; rename answer saved; proc answer {} {return 99}",
            "proc answer {} {return 42}; proc f {} {set y [answer]}; unknown_future_entry",
            "proc answer {} {return 42}; proc f {} {set y [answer]}; trace add execution answer enter callback",
        ] {
            let opts = run_pass_with_command_mutations(source);
            assert!(
                opts.iter()
                    .all(|optimisation| optimisation.code != DiagCode::O103
                        || optimisation.hint_only),
                "{source}: {opts:?}"
            );
        }
    }

    #[test]
    fn o103_bare_call_stays_hint_only() {
        // Top-level `::answer` — the call result is discarded, so
        // folding it as a statement would leave an invalid `42`
        // command. Diagnostic must stay hint-only.
        use tcl_registry::CommandRegistry;
        let registry = CommandRegistry::build_default();
        let cu = CompilationUnit::build_for(
            "proc ::answer {} { return 42 }\n::answer",
            &registry,
            false,
        )
        .with_interprocedural(&registry, None);
        let mut ctx = PassContext::new(&cu.source, cu.interproc.clone().unwrap_or_default());
        ctx.registry = Some(&registry);
        run(&mut ctx, &cu);
        let o103s: Vec<_> = ctx
            .optimisations
            .iter()
            .filter(|o| o.code == DiagCode::O103)
            .collect();
        assert!(!o103s.is_empty(), "expected at least one O103");
        assert!(
            o103s.iter().all(|o| o.hint_only),
            "bare-call form must stay hint-only, got {o103s:?}",
        );
    }

    #[test]
    fn o103_folds_arg_sensitive_passthrough_cmd_subst() {
        // `::not_const {x} { return $x }` has no argument-*independent*
        // constant return, but with the call's constant arg bound it folds:
        // `[::not_const 1]` → `1` (the passthrough folds). The applicable
        // rewrite fires only for the CMD-subst form; the bare-call form
        // stays hint-only.
        use tcl_registry::CommandRegistry;
        let registry = CommandRegistry::build_default();
        let cu = CompilationUnit::build_for(
            "proc ::not_const {x} { return $x }\nputs [::not_const 1]",
            &registry,
            false,
        )
        .with_interprocedural(&registry, None);
        let mut ctx = PassContext::new(&cu.source, cu.interproc.clone().unwrap_or_default());
        ctx.registry = Some(&registry);
        run(&mut ctx, &cu);
        assert!(
            ctx.optimisations
                .iter()
                .any(|o| o.code == DiagCode::O103 && o.replacement == "1" && !o.hint_only),
            "expected applicable O103 folding [::not_const 1] to 1, got {:?}",
            ctx.optimisations,
        );
    }

    #[test]
    fn o103_folds_arg_sensitive_passthrough_with_braced_multiword_literal() {
        // `parse_static_call_args` shares `literal_words`'s proper Tcl-aware
        // tokeniser rather than a naive `split_whitespace`, so a braced
        // multi-word call argument (`{a b}` — one clean literal argument in
        // real Tcl) folds too.
        use tcl_registry::CommandRegistry;
        let registry = CommandRegistry::build_default();
        let cu = CompilationUnit::build_for(
            "proc ::passthrough {x} { return $x }\nputs [::passthrough {a b}]",
            &registry,
            false,
        )
        .with_interprocedural(&registry, None);
        let mut ctx = PassContext::new(&cu.source, cu.interproc.clone().unwrap_or_default());
        ctx.registry = Some(&registry);
        run(&mut ctx, &cu);
        assert!(
            ctx.optimisations
                .iter()
                .any(|o| o.code == DiagCode::O103 && o.replacement == "{a b}" && !o.hint_only),
            "expected applicable O103 folding [::passthrough {{a b}}] to {{a b}}, got {:?}",
            ctx.optimisations,
        );
    }

    #[test]
    fn o103_folds_variadic_args_proc_returning_args_directly() {
        // TP: `args` is seeded as a canonical Tcl list (see
        // `seed_params_from_args`), not skipped outright — `proc ::foo {a
        // args} { return $args }` called as `[::foo 1 2]` binds `a=1`,
        // `args={2}` (a one-element list, which renders bare as `2` with
        // no braces needed), so `return $args` folds to `2`. Confirmed
        // against tclsh 8.6: `puts [::foo 1 2]` prints `2`.
        use tcl_registry::CommandRegistry;
        let registry = CommandRegistry::build_default();
        let cu = CompilationUnit::build_for(
            "proc ::foo {a args} { return $args }\nputs [::foo 1 2]",
            &registry,
            false,
        )
        .with_interprocedural(&registry, None);
        let mut ctx = PassContext::new(&cu.source, cu.interproc.clone().unwrap_or_default());
        ctx.registry = Some(&registry);
        run(&mut ctx, &cu);
        assert!(
            ctx.optimisations
                .iter()
                .any(|o| o.code == DiagCode::O103 && o.replacement == "2" && !o.hint_only),
            "expected applicable O103 folding [::foo 1 2] to 2 (args seeded as a list), got {:?}",
            ctx.optimisations,
        );
    }

    #[test]
    fn o103_does_not_fold_recursive_or_loop_proc() {
        // A proc whose return SCCP cannot determine under the bound args must
        // not fold — a loop-carried `return $total` is a phi (Overdefined at
        // exit), even though a pre-loop `set total 0` leaves a stale Const(0).
        // Mis-folding it would be a miscompile.
        use tcl_registry::CommandRegistry;
        let registry = CommandRegistry::build_default();
        let src = "proc ::sum {ns} {\n  set total 0\n  foreach n $ns { set total [expr {$total + $n}] }\n  return $total\n}\nputs [::sum {1 2 3}]\n";
        let cu =
            CompilationUnit::build_for(src, &registry, false).with_interprocedural(&registry, None);
        let mut ctx = PassContext::new(&cu.source, cu.interproc.clone().unwrap_or_default());
        ctx.registry = Some(&registry);
        run(&mut ctx, &cu);
        assert!(
            ctx.optimisations
                .iter()
                .all(|o| o.code != DiagCode::O103 || o.hint_only),
            "loop-carried return must not fold, got {:?}",
            ctx.optimisations,
        );
    }

    #[test]
    fn o103_folds_implicit_return_proc_cmd_subst() {
        // TP: the KCS O103 doc's own canonical example — a proc with NO
        // explicit `return`, whose result is Tcl's "value of the last
        // command executed" (a bare `expr {…}`) — must fold. Before the
        // fall-through fix, `resolve_return_constant` only looked at
        // `Terminator::Return` blocks, so a pure proc that relies entirely
        // on implicit return never folded at all (`[double 21]` stayed
        // unrewritten even though tclsh evaluates it to `42`).
        use tcl_registry::CommandRegistry;
        let registry = CommandRegistry::build_default();
        let src = "proc double {n} { expr {$n * 2} }\nset x [double 21]\n";
        let cu =
            CompilationUnit::build_for(src, &registry, false).with_interprocedural(&registry, None);
        let mut ctx = PassContext::new(&cu.source, cu.interproc.clone().unwrap_or_default());
        ctx.registry = Some(&registry);
        run(&mut ctx, &cu);
        assert!(
            ctx.optimisations
                .iter()
                .any(|o| o.code == DiagCode::O103 && o.replacement == "42" && !o.hint_only),
            "expected applicable O103 folding [double 21] to 42 (implicit return), got {:?}",
            ctx.optimisations,
        );
    }

    #[test]
    fn o103_folds_implicit_return_zero_arg_proc() {
        // TP: a zero-parameter implicit-return proc (`set` as the trailing
        // statement — Tcl's `set` returns the value it just assigned, so
        // this is exactly like `return $pi`) also folds via the CMD-subst
        // path.
        use tcl_registry::CommandRegistry;
        let registry = CommandRegistry::build_default();
        let src = "proc pi {} { set p 3 }\nputs [pi]\n";
        let cu =
            CompilationUnit::build_for(src, &registry, false).with_interprocedural(&registry, None);
        let mut ctx = PassContext::new(&cu.source, cu.interproc.clone().unwrap_or_default());
        ctx.registry = Some(&registry);
        run(&mut ctx, &cu);
        assert!(
            ctx.optimisations
                .iter()
                .any(|o| o.code == DiagCode::O103 && o.replacement == "3" && !o.hint_only),
            "expected applicable O103 folding [pi] to 3 (implicit `set` return), got {:?}; {}",
            ctx.optimisations,
            proc_fold_context(&cu, "::pi"),
        );
    }

    #[test]
    fn o103_does_not_fold_when_return_and_fallthrough_disagree() {
        // FN / miscompile-guard: `helper`'s result is opaque to intraprocedural
        // SCCP (it's a call, not folded interprocedurally), so `g`'s `if`
        // condition can't be resolved even after `n` is seeded to 5 — both the
        // `return 1` branch AND the fall-through `expr {99}` stay executable.
        // tclsh 9.0.4 ground truth: `g 5` calls `helper 5` (== 6), `6 > 100` is
        // false, so `g 5` falls through and returns `99` — NOT `1`. Before the
        // fall-through fix, the return reading silently ignored the
        // reachable non-`Return` exit and confidently (wrongly) folded to the
        // `return 1` branch's value — a real miscompile, not just an
        // over-eager fold.
        use tcl_registry::CommandRegistry;
        let registry = CommandRegistry::build_default();
        let src = "proc helper {n} { expr {$n + 1} }\nproc g {n} {\n    if {[helper $n] > 100} {\n        return 1\n    }\n    expr {99}\n}\nputs [g 5]\n";
        let cu =
            CompilationUnit::build_for(src, &registry, false).with_interprocedural(&registry, None);
        let mut ctx = PassContext::new(&cu.source, cu.interproc.clone().unwrap_or_default());
        ctx.registry = Some(&registry);
        run(&mut ctx, &cu);
        assert!(
            ctx.optimisations
                .iter()
                .all(|o| o.code != DiagCode::O103 || o.hint_only),
            "disagreeing return/fall-through exits must not produce an applicable fold, got {:?}",
            ctx.optimisations,
        );
    }

    #[test]
    fn o103_does_not_fold_through_empty_if_body() {
        // FP guard / miscompile-guard (reported in code review): a trailing
        // `if {$c} {}` with an empty body (and no `else`) is itself a real
        // Tcl command whose result is `""` — whether the condition is true
        // (the empty body's own result) or false (no branch ran, no
        // `else`). tclsh 9.0.4 ground truth: `f 0` and `f 1` both return
        // `""`, NOT `1` from the preceding `set x 1`. An earlier, more
        // permissive fall-through resolver walked straight through the
        // empty `if`-body block back to `set x 1` and wrongly folded `[f
        // 0]` to `1` — treating "0 statements" as "no command ran here"
        // rather than "this command's own result is empty". The fold must
        // decline entirely rather than inherit a stale prior value.
        use tcl_registry::CommandRegistry;
        let registry = CommandRegistry::build_default();
        let src = "proc f {c} { set x 1\nif {$c} {} }\nputs [f 0]\n";
        let cu =
            CompilationUnit::build_for(src, &registry, false).with_interprocedural(&registry, None);
        let mut ctx = PassContext::new(&cu.source, cu.interproc.clone().unwrap_or_default());
        ctx.registry = Some(&registry);
        run(&mut ctx, &cu);
        assert!(
            ctx.optimisations
                .iter()
                .all(|o| o.code != DiagCode::O103 || o.hint_only),
            "empty if-body fall-through must not produce an applicable fold, got {:?}",
            ctx.optimisations,
        );
    }

    #[test]
    fn o103_folds_variadic_args_proc_ignoring_trailing_args() {
        // TP: a proc with a trailing `args` parameter folds on its fixed
        // parameter when the call supplies MORE arguments than the proc has
        // fixed params — the extra args collect into `args`, unused by this
        // body. Before the `args` fix, `evaluate_proc_with_constants`
        // required `params.len() == args.len()` exactly, so a call
        // supplying more than one trailing argument (`[f 5 x y z]` for
        // `proc f {a args}`) never even reached the fold attempt.
        use tcl_registry::CommandRegistry;
        let registry = CommandRegistry::build_default();
        let src = "proc f {a args} { expr {$a * 2} }\nputs [f 5 x y z]\n";
        let cu =
            CompilationUnit::build_for(src, &registry, false).with_interprocedural(&registry, None);
        let mut ctx = PassContext::new(&cu.source, cu.interproc.clone().unwrap_or_default());
        ctx.registry = Some(&registry);
        run(&mut ctx, &cu);
        assert!(
            ctx.optimisations
                .iter()
                .any(|o| o.code == DiagCode::O103 && o.replacement == "10" && !o.hint_only),
            "expected applicable O103 folding [f 5 x y z] to 10, got {:?}",
            ctx.optimisations,
        );
    }

    /// Run the propagation pass with `ctx.command_mutations` populated —
    /// the piece `optimise_raw` (used by the O129 trust-gate test) never
    /// wires (it doesn't set `cu.interproc` either, so it can't drive
    /// O103 at all) and a bare `PassContext::new` + `run` leaves at its
    /// all-trusting `Default`. Mirrors the whole-module scan every real
    /// production entry point (`optimise_unit_raw`, `find_dead_stores`,
    /// `optimise_by_pass`) performs before running passes.
    fn run_pass_with_command_mutations(source: &str) -> Vec<Optimisation> {
        let registry = CommandRegistry::build_default();
        let cu = CompilationUnit::build_for(source, &registry, false)
            .with_interprocedural(&registry, None);
        let mut ctx = PassContext::new(&cu.source, cu.interproc.clone().unwrap_or_default());
        ctx.registry = Some(&registry);
        ctx.command_mutations =
            crate::command_binding::scan_module_command_mutations(&cu.ir_module, &registry);
        ctx.ir_module = Some(&cu.ir_module);
        run(&mut ctx, &cu);
        ctx.optimisations
    }

    #[test]
    fn o103_does_not_fold_call_to_proc_renamed_over() {
        // The selected moved allocation cannot borrow the replaced body's summary.
        // Original C9.0.4: double 21 returns 63 after this rename.
        let src = "proc double {n} { expr {$n * 2} }\nproc triple {n} { expr {$n * 3} }\nrename triple double\nputs [double 21]\n";
        let opts = run_pass_with_command_mutations(src);
        assert!(
            opts.iter().all(|o| o.code != DiagCode::O103 || o.hint_only),
            "call to a proc name later `rename`d over must not fold, got {opts:?}",
        );
    }

    #[test]
    fn o103_folds_the_actual_procedure_selected_by_interp_alias() {
        // The selected alias target returns 99 on C Tcl 8.4–9.1.
        let src = "proc answer {} { return 42 }\nproc other {} { return 99 }\ninterp alias {} answer {} other\nputs [answer]\n";
        let opts = run_pass_with_command_mutations(src);
        assert!(
            opts.iter()
                .any(|o| o.code == DiagCode::O103 && !o.hint_only && o.replacement == "99"),
            "the exact alias target must fold to its own result, got {opts:?}",
        );
        let jim = crate::optimiser::optimise_raw(src, &registry(), Some("jim"));
        assert!(jim.iter().all(|o| o.code != DiagCode::O103 || o.hint_only));
    }

    #[test]
    fn o103_still_folds_unrelated_proc_despite_unrelated_rename_elsewhere() {
        // TN control: `trusts_proc_binding` must be per-name, not a blanket
        // "any rename anywhere disables all O103 folds" — an unrelated
        // rename of a *different* proc must not block folding calls to
        // procs it never touched.
        let src = "proc double {n} { expr {$n * 2} }\nproc triple {n} { expr {$n * 3} }\nrename triple somethingElse\nputs [double 21]\n";
        let opts = run_pass_with_command_mutations(src);
        assert!(
            opts.iter()
                .any(|o| o.code == DiagCode::O103 && o.replacement == "42" && !o.hint_only),
            "unrelated proc must still fold despite an unrelated rename, got {opts:?}",
        );
    }

    #[test]
    fn o103_does_not_fold_call_to_proc_renamed_over_via_namespace_relative_rename() {
        // FP guard / miscompile-guard (reported in code review): `rename
        // triple double` inside `proc ::ns::doit` resolves both bare names
        // relative to `::ns` (the proc's own namespace) — it renames
        // `::ns::triple` onto `::ns::double`, NOT the (nonexistent)
        // top-level `::triple`/`::double`. tclsh 9.0.4 ground truth: after
        // `::ns::doit` runs, `::ns::double 21` executes `triple`'s body
        // (21*3 == 63), not `double`'s original body (21*2 == 42). An
        // earlier version of `collect_proc_rebindings` always rooted a bare
        // rename argument at the GLOBAL namespace (`::double`/`::triple`),
        // so it never marked `::ns::double`/`::ns::triple` as rebound and
        // O103 could fold `[::ns::double 21]` to the wrong `42`.
        let src = "namespace eval ::ns {\n    proc double {n} { expr {$n * 2} }\n    proc triple {n} { expr {$n * 3} }\n}\nproc ::ns::doit {} { rename triple double }\n::ns::doit\nputs [::ns::double 21]\n";
        let opts = run_pass_with_command_mutations(src);
        assert!(
            opts.iter().all(|o| o.code != DiagCode::O103 || o.hint_only),
            "call to a proc renamed over via a namespace-relative rename must not fold, got {opts:?}",
        );
    }

    #[test]
    fn parse_cmd_subst_head_rejects_metachars() {
        assert_eq!(parse_cmd_subst_head("::answer"), Some("::answer"));
        assert_eq!(parse_cmd_subst_head("::answer 1 2"), Some("::answer"));
        assert_eq!(parse_cmd_subst_head("  ::answer"), Some("::answer"));
        assert_eq!(parse_cmd_subst_head(""), None);
        // Leading `$` / `[` / `{` / `"` → would re-substitute.
        assert_eq!(parse_cmd_subst_head("$cmd"), None);
        assert_eq!(parse_cmd_subst_head("[cmd]"), None);
    }

    #[test]
    fn o115_collapses_redundant_nested_expr_in_value_positions() {
        // A redundant double-`expr` cmd-sub
        // `[expr {[expr {E}]}]` collapses to `[expr {E}]` in command-arg
        // and return value positions (O115 otherwise fires only on a
        // standalone `expr` statement).
        let collapsed = |src: &str| -> Vec<String> {
            crate::optimiser::optimise_raw(src, &registry(), None)
                .into_iter()
                .filter(|o| o.code == DiagCode::O115)
                .map(|o| o.replacement)
                .collect()
        };
        assert_eq!(
            collapsed("proc ::f {x} { puts [expr {[expr {$x * 2}]}] }"),
            vec!["[expr {$x * 2}]".to_string()],
            "command-arg position should collapse",
        );
        assert_eq!(
            collapsed("proc ::f {x} { return [expr {[expr {$x * 2}]}] }"),
            vec!["return [expr {$x * 2}]".to_string()],
            "return position should collapse",
        );
    }

    #[test]
    fn o115_value_position_is_sound() {
        // A single `[expr {$x + 1}]` must NOT collapse (its unwrap
        // `$x + 1` would be invalid as a bare value), and an
        // `[expr {[other]}]` whose inner is not itself `expr` is not
        // value-equivalent for non-numeric results.
        let has_o115 = |src: &str| -> bool {
            crate::optimiser::optimise_raw(src, &registry(), None)
                .iter()
                .any(|o| o.code == DiagCode::O115)
        };
        assert!(!has_o115("proc ::f {x} { puts [expr {$x + 1}] }"));
        assert!(!has_o115("proc ::f {x} { return [expr {$x + 1}] }"));
        assert!(!has_o115("proc ::f {x} { puts [expr {[someproc]}] }"));
    }

    #[test]
    fn o129_folds_pure_builtin_cmd_subst() {
        // A pure-builtin cmd-sub with constant
        // (literal) args folds via the registry `const_fold` callback
        // (O129). `optimise_raw` sets `ctx.registry`, which the O129
        // path requires.
        let fold = |src: &str| -> Vec<String> {
            crate::optimiser::optimise_raw(src, &registry(), None)
                .into_iter()
                .filter(|o| o.code == DiagCode::O129)
                .map(|o| o.replacement)
                .collect()
        };
        assert_eq!(fold("puts [string toupper foo]"), vec!["FOO".to_string()]);
        assert_eq!(fold("puts [string tolower BAR]"), vec!["bar".to_string()]);
        assert_eq!(fold("puts [string reverse abc]"), vec!["cba".to_string()]);
        // The headline O129 example.
        assert_eq!(fold("puts [string length abcde]"), vec!["5".to_string()]);
        // The cat / repeat / trim folds.
        assert_eq!(
            fold("puts [string cat foo bar]"),
            vec!["foobar".to_string()]
        );
        assert_eq!(
            fold("puts [string repeat ab 3]"),
            vec!["ababab".to_string()]
        );
        assert_eq!(fold("puts [string trim {  hi  }]"), vec!["hi".to_string()]);
        assert_eq!(
            fold("puts [string range abcde 1 3]"),
            vec!["bcd".to_string()]
        );
        assert_eq!(fold("puts [string index abc end]"), vec!["c".to_string()]);
        // List + dict folds.
        assert_eq!(fold("puts [llength {a b c}]"), vec!["3".to_string()]);
        // The cmd-sub replacement is one word, so a spaced result is
        // brace-quoted by `render_propagation_word`.
        assert_eq!(fold("puts [concat a b c]"), vec!["{a b c}".to_string()]);
        assert_eq!(fold("puts [join {a b c} -]"), vec!["a-b-c".to_string()]);
        // `lindex` / `list` report their own codes (O118 / O116) for
        // editor granularity, so filter by those rather than O129.
        let fold_code = |src: &str, code: &str| -> Vec<String> {
            crate::optimiser::optimise_raw(src, &registry(), None)
                .into_iter()
                .filter(|o| o.code.as_str() == code)
                .map(|o| o.replacement)
                .collect()
        };
        assert_eq!(
            fold_code("puts [lindex {a b c} 1]", "O118"),
            vec!["b".to_string()]
        );
        assert_eq!(fold_code("set x [list]", "O116"), vec!["{}".to_string()]);
        // A list 8.6 would read apart as a script, once a literal, stays the
        // list (`if 1 $x` ranges nothing; the braced literal ranges `abc`).
        let hazard = "set x [list string range abc 0 end-2147483649]\nif 1 $x";
        let o116 = |dialect| {
            crate::optimiser::optimise_raw(hazard, &registry(), Some(dialect))
                .into_iter()
                .filter(|o| o.code.as_str() == "O116")
                .count()
        };
        assert_eq!(o116("tcl8.6"), 0);
        assert_eq!(o116("tcl9.0"), 1);
        assert_eq!(fold("puts [dict get {a 1 b 2} b]"), vec!["2".to_string()]);
        assert_eq!(
            fold("puts [lreverse {a b c}]"),
            vec!["{c b a}".to_string()],
            "list result is brace-quoted as one word",
        );
        assert_eq!(fold("puts [string map {a b} aaa]"), vec!["bbb".to_string()]);
        assert_eq!(fold("puts [subst hello]"), vec!["hello".to_string()]);
        // `subst` with a substitution must NOT fold (no upstream resolution).
        assert_eq!(fold("puts [subst {$x}]"), [] as [std::string::String; 0]);
        // `string is` Tcl-faithful classes.
        assert_eq!(fold("puts [string is alpha abc]"), vec!["1".to_string()]);
        assert_eq!(fold("puts [string is lower abc1]"), vec!["0".to_string()]);
        assert_eq!(fold("puts [string is boolean yes]"), vec!["1".to_string()]);
        // The convenience driver retains its documented C9 native target.
        // Actual C8.4 and Jim reject these classes; the selected target matters.
        assert_eq!(fold("puts [string is list {a b c}]"), vec!["1".to_owned()]);
        let legacy = tcl_registry::model::ingress::static_context_for("tcl8.4");
        for source in [
            "puts [string is list {a b c}]",
            "puts [string is wideinteger 42]",
        ] {
            assert!(
                crate::optimiser::optimise_raw_for_profile(
                    source,
                    legacy.commands(),
                    Some(
                        tcl_registry::model::ingress::resolve_environment("tcl8.4")
                            .analyser_profile()
                    ),
                )
                .iter()
                .all(|finding| finding.code != DiagCode::O129)
            );
        }
        // `format` %s / %d / %% subset.
        assert_eq!(fold("puts [format %d 42]"), vec!["42".to_string()]);
        assert_eq!(fold("puts [format {v=%s} hi]"), vec!["v=hi".to_string()]);
        // `format` flag / width / precision folds for
        // the decimal-integer + string conversions (dialect-invariant).
        assert_eq!(fold("puts [format %05d 7]"), vec!["00007".to_string()]);
        assert_eq!(fold("puts [format %.3d 5]"), vec!["005".to_string()]);
        // `%#d` stays unfolded (`0d5` on Tcl 9, `5` on 8.6 — divergent).
        assert_eq!(fold("puts [format %#d 5]"), [] as [std::string::String; 0]);
        // `string is integer` / `double` fold over their
        // dialect-invariant subsets.
        assert_eq!(fold("puts [string is integer 42]"), vec!["1".to_string()]);
        assert_eq!(fold("puts [string is double 1.5]"), vec!["1".to_string()]);
        assert_eq!(fold("puts [string is double abc]"), vec!["0".to_string()]);
        assert_eq!(
            fold("puts [string is wideinteger 42]"),
            vec!["1".to_owned()]
        );
        // A braced literal with a space → result rendered as one word.
        assert_eq!(
            fold("puts [string toupper {a b}]"),
            vec!["{A B}".to_string()],
        );
        // A `$var` arg is not a constant literal → no fold.
        assert_eq!(
            fold("puts [string toupper $x]"),
            [] as [std::string::String; 0]
        );
        // The range form (`string toupper s first last`) does not fold.
        assert_eq!(
            fold("puts [string toupper foo 0 0]"),
            [] as [std::string::String; 0]
        );
        // A non-builtin head (a user proc) is not an O129 candidate.
        assert_eq!(
            fold("proc ::p {} { return 1 }\nputs [::p]"),
            [] as [std::string::String; 0]
        );
    }

    /// The folded command substitution carries its own quoted argument, so
    /// the rewrite span has to cross that inner `"b"`. A scanner that stops
    /// at the first unescaped `"` produces a span covering only
    /// `"a[string toupper "`, and applying the fix leaves the
    /// tail `b"]c"` behind as a stray fragment. Applying the rewrite must
    /// yield well-formed source.
    #[test]
    fn o129_interpolation_fold_replaces_the_whole_quoted_word() {
        let src = "puts \"a[string toupper \"b\"]c\"\n";
        let opts = crate::optimiser::optimise_raw(src, &registry(), None);
        let fold = opts
            .iter()
            .find(|o| o.code == DiagCode::O129 && !o.hint_only)
            .unwrap_or_else(|| panic!("expected an applicable O129, got {opts:?}"));
        let mut rewritten = src.to_owned();
        rewritten.replace_range(
            fold.span.start() as usize..fold.span.end() as usize,
            &fold.replacement,
        );
        assert_eq!(rewritten, "puts \"aBc\"\n");
    }

    #[test]
    fn retained_const_subst_accepts_only_closed_literal_templates() {
        let literal = "puts [string toupper \"a\\tb\"]";
        let findings = crate::optimiser::optimise_raw(literal, &registry(), None);
        let fold = findings
            .iter()
            .find(|finding| finding.code == DiagCode::O129 && !finding.hint_only)
            .expect("the native word owner resolves a quoted literal");
        assert_eq!(
            tcl_syntax::list::split_list(&fold.replacement).unwrap(),
            vec!["A\tB"]
        );
        for source in [
            "proc p {value} {puts [string toupper \"$value\"]}",
            "puts [string toupper \"[operation]\"]",
        ] {
            assert!(
                crate::optimiser::optimise_raw(source, &registry(), None)
                    .iter()
                    .all(|finding| finding.code != DiagCode::O129 || finding.hint_only),
                "{source}"
            );
        }
    }

    /// A `"…"` word holding a command-position comment reaches across a
    /// backslash-newline continuation. `tclsh` prints `x3abc`; a rewrite that
    /// mis-spans the word prints `x3ab""b"c`.
    ///
    /// Both the canonical lexer and `close_quote_offset` keep command
    /// position across the continuation and reach the final `"`, so the safe
    /// rewrite folds only the first command substitution and preserves the
    /// commented-out closer verbatim.
    #[test]
    fn o129_fold_preserves_comment_hidden_closer() {
        let src = "puts \"x[string length abc]a[\n\\\n# ] comment\nset y \"b\"\n]c\"\n";
        let opts = crate::optimiser::optimise_raw(src, &registry(), None);
        let rewrites = opts
            .iter()
            .filter(|o| o.code == DiagCode::O129 && !o.hint_only)
            .collect::<Vec<_>>();
        assert_eq!(rewrites.len(), 1, "expected one safe O129: {opts:?}");
        let opt = rewrites[0];
        let mut rewritten = src.to_owned();
        rewritten.replace_range(
            opt.span.start() as usize..opt.span.end() as usize,
            &opt.replacement,
        );
        assert_eq!(
            rewritten,
            "puts \"x3a[\n\\\n# ] comment\nset y \"b\"\n]c\"\n"
        );
    }

    #[test]
    fn o129_concat_preserves_native_trailing_backslash_space_bytes() {
        // All six native engines re-expose exactly one trailing byte after a
        // backslash. The shared concat owner now models that operation.
        for (source, expected) in [
            ("puts [concat a b c]", "a b c"),
            ("puts [concat a {b\\ } c]", "a b\\  c"),
            ("puts [concat {b\\ }]", "b\\ "),
            ("puts [concat a {b\\\\   } c]", "a b\\\\  c"),
        ] {
            let replacements = crate::optimiser::optimise_raw(source, &registry(), None)
                .into_iter()
                .filter(|finding| finding.code == DiagCode::O129 && !finding.hint_only)
                .map(|finding| finding.replacement)
                .collect::<Vec<_>>();
            assert_eq!(replacements.len(), 1, "{source}");
            assert_eq!(
                tcl_syntax::list::split_list(&replacements[0]).unwrap(),
                vec![expected],
                "{source}"
            );
        }
    }

    #[test]
    fn o129_resolves_constant_var_args_b2() {
        // A constant `$var` arg in a builtin
        // cmd-sub is resolved (whole-function-constant → sound) before
        // folding; a multi-word value stays a single argument.
        let fold = |src: &str| -> Vec<String> {
            crate::optimiser::optimise_raw(src, &registry(), None)
                .into_iter()
                .filter(|o| o.code == DiagCode::O129)
                .map(|o| o.replacement)
                .collect()
        };
        assert_eq!(
            fold("set s abcde\nputs [string length $s]"),
            vec!["5".to_string()],
        );
        // A multi-word constant value is kept as one arg.
        assert_eq!(
            fold("set s {a b}\nputs [llength $s]"),
            vec!["2".to_string()],
        );
        // Combined: a resolved var inside an interpolation cmd-sub.
        assert_eq!(
            fold("set s abc\nputs \"len=[string length $s]\""),
            vec!["\"len=3\"".to_string()],
        );
        // A non-constant var does not resolve → no fold.
        assert_eq!(
            fold("puts [string length $undefined]"),
            [] as [std::string::String; 0]
        );
    }

    #[test]
    fn o129_folds_embedded_cmd_subst_in_interpolation() {
        // A pure-builtin cmd-sub embedded inside
        // an interpolation string folds, splicing the raw result.
        let fold = |src: &str| -> Vec<String> {
            crate::optimiser::optimise_raw(src, &registry(), None)
                .into_iter()
                .filter(|o| o.code == DiagCode::O129)
                .map(|o| o.replacement)
                .collect()
        };
        assert_eq!(
            fold("puts \"v=[string length abc]\""),
            vec!["\"v=3\"".to_string()],
        );
        assert_eq!(
            fold("puts \"n=[llength {a b c}] items\""),
            vec!["\"n=3 items\"".to_string()],
        );
        // A non-foldable embedded sub leaves the string unfolded.
        assert_eq!(
            fold("puts \"x=[someproc]\""),
            [] as [std::string::String; 0]
        );
        // Soundness guard: a result that would re-introduce a `$`
        // substitution into the `\"…\"` is not spliced.
        assert_eq!(
            fold("puts \"v=[string cat {$} x]\""),
            [] as [std::string::String; 0]
        );
    }

    #[test]
    fn o129_uses_the_actual_binding_before_and_after_a_rebinder() {
        let fold = |src: &str| -> Vec<String> {
            crate::optimiser::optimise_raw(src, &registry(), None)
                .into_iter()
                .filter(|o| o.code == DiagCode::O129)
                .map(|o| o.replacement)
                .collect()
        };
        // Baseline: untouched `string` folds.
        assert_eq!(fold("puts [string toupper foo]"), vec!["FOO".to_string()]);
        // An uncalled declaration leaves the stock command selected.
        assert_eq!(
            fold("proc clobber {} { rename string {} }\nputs [string toupper foo]"),
            vec!["FOO".to_string()],
        );
        assert_eq!(
            fold("proc clobber {} { rename string {} }\nclobber\nputs [string toupper foo]"),
            [] as [String; 0],
            "a completed rebinder removes the reached builtin",
        );
        assert_eq!(
            fold("rename string {}\nputs [string toupper foo]").len(),
            0,
            "renamed-away builtin must not fold",
        );
    }

    #[test]
    fn run_passes_dispatches_propagation() {
        let reg = registry();
        let cu = CompilationUnit::build_for("set x 9\nputs $x", &reg, false);
        let mut ctx = PassContext::new(&cu.source, InterproceduralAnalysis::default());
        ctx.registry = Some(&reg);
        super::super::run_passes(&mut ctx, &cu, &[super::super::PassId::Propagation]);
        assert!(
            ctx.optimisations.iter().any(|o| o.code == DiagCode::O100),
            "expected O100 via run_passes, got {:?}",
            ctx.optimisations,
        );
    }
    #[test]
    fn retained_substitution_folds_use_the_selected_namespace_path_procedure() {
        let registry = tcl_registry::model::ingress::static_context_for("tcl9.0").commands();
        let source = "proc ::p {} {return GLOBAL}\n\
                      namespace eval ::lib {proc p {} {return PATH}}\n\
                      namespace eval ::N {namespace path ::lib; proc caller {} {puts [p]}}\n\
                      ::N::caller";
        let cu = CompilationUnit::build_for_dialect(source, registry, false, "tcl9.0")
            .with_interprocedural(
                registry,
                Some(
                    tcl_registry::model::ingress::resolve_environment("tcl9.0").analyser_profile(),
                ),
            );
        let mut context = PassContext::new(&cu.source, cu.interproc.clone().unwrap_or_default());
        context.registry = Some(registry);
        run(&mut context, &cu);
        assert!(
            context.optimisations.iter().all(|optimisation| {
                optimisation.code != DiagCode::O103
                    || optimisation.hint_only
                    || optimisation.replacement != "GLOBAL"
            }),
            "{:?}",
            context.optimisations
        );
    }

    #[test]
    fn retained_substitution_folds_decline_namespaced_builtin_shadows() {
        let registry = tcl_registry::model::ingress::static_context_for("tcl9.0").commands();
        for invocation in ["[expr {1 + 2}]", "[string length abc]", "[list a b]"] {
            let source = format!(
                "namespace eval N {{proc expr {{args}} {{return EXPR}}; proc string {{args}} {{return STRING}}; proc list {{args}} {{return LIST}}; proc run {{}} {{puts {invocation}}}}}\nN::run"
            );
            let cu = CompilationUnit::build_for_dialect(&source, registry, false, "tcl9.0")
                .with_interprocedural(
                    registry,
                    Some(
                        tcl_registry::model::ingress::resolve_environment("tcl9.0")
                            .analyser_profile(),
                    ),
                );
            let mut context =
                PassContext::new(&cu.source, cu.interproc.clone().unwrap_or_default());
            context.registry = Some(registry);
            run(&mut context, &cu);
            assert!(
                context.optimisations.iter().all(|optimisation| {
                    !matches!(
                        optimisation.code,
                        DiagCode::O101
                            | DiagCode::O115
                            | DiagCode::O116
                            | DiagCode::O118
                            | DiagCode::O129
                    ) || optimisation.hint_only
                        || !source
                            .get(optimisation.span.as_range())
                            .is_some_and(|text| text.contains(invocation))
                }),
                "{source}: {:?}",
                context.optimisations
            );
        }
    }

    #[test]
    fn retained_substitution_missing_child_receipt_withdraws_applicable_folding() {
        let registry = tcl_registry::model::ingress::static_context_for("tcl9.0").commands();
        let source = "puts [list a b]";
        let cu = CompilationUnit::build_for_dialect(source, registry, false, "tcl9.0");
        let statement = &cu.ir_module.top_level.statements[0];
        let mut tokens = cu
            .ir_module
            .top_level
            .retained_source_tokens_for_statement(statement)
            .expect("original carrier")
            .clone();
        tokens.source_binding = None;
        let mut context = PassContext::new(source, InterproceduralAnalysis::default());
        context.registry = Some(registry);
        visit_call_cmd_subst_folds(
            &mut context,
            &cu,
            &tokens,
            &std::collections::HashMap::new(),
            "::",
            statement.span(),
        );
        assert!(context.optimisations.is_empty());
    }
    #[test]
    fn retained_substitution_procedure_folding_preserves_arity_and_argument_effects() {
        let registry = tcl_registry::model::ingress::static_context_for("tcl9.0").commands();
        for source in [
            "proc f {required} {return CONSTANT}; puts [f]",
            "proc f {} {return CONSTANT}; puts [f EXTRA]",
            "proc f {ignored} {return CONSTANT}; set x 0; puts [f [incr x]]; puts $x",
        ] {
            let cu = CompilationUnit::build_for_dialect(source, registry, false, "tcl9.0")
                .with_interprocedural(registry, registry.profile());
            let mut context =
                PassContext::new(&cu.source, cu.interproc.clone().unwrap_or_default());
            context.registry = Some(registry);
            run(&mut context, &cu);
            assert!(
                context
                    .optimisations
                    .iter()
                    .all(|optimisation| optimisation.code != DiagCode::O103
                        || optimisation.hint_only),
                "{source}: {:?}",
                context.optimisations
            );
        }
    }

    /// A literal a write the statements do not show may have replaced is
    /// never forwarded: an arm of a `switch` the flow graph keeps as one
    /// statement, a callback script, or a command the module cannot see.
    #[test]
    fn o100_and_o102_never_forward_a_literal_a_hidden_write_may_have_replaced() {
        for (src, stale) in [
            (
                "set go 1\nset s q1\nswitch -glob -- $s { q* { set go 0 } }\nputs $go",
                "1",
            ),
            (
                "set go 1\nswitch -nocase -- [gets stdin] { q { set go 0 } }\nputs $go",
                "1",
            ),
            (
                "proc p {s} {\n set go 1\n switch -glob -- $s { q* { set go 0 } }\n puts $go\n}",
                "1",
            ),
            (
                "set go 1\ntrace add variable x write { set ::go 0 ;# }\nset x 1\nputs $go",
                "1",
            ),
            (
                "set done 0\nafter 10 { set done 1 }\nafter 50\nupdate\nputs $done",
                "0",
            ),
            (
                "proc tick {} { set ::done 1 }\nset done 0\nafter 10 tick\nafter 50\nupdate\nputs $done",
                "0",
            ),
            ("set g 5\nfoo\nputs $g", "5"),
            ("set ::g 5\nfoo\nputs $::g", "5"),
            ("proc p {} {\n set g 5\n foo\n puts $g\n}", "5"),
            ("set g 5\nsource other.tcl\nputs $g", "5"),
            ("proc p {} {\n set g 5\n source other.tcl\n puts $g\n}", "5"),
            (
                "proc zero {v} {upvar 1 $v x; set x 0}\nproc p {s} {\n set line 5\n switch -glob -- $s { g* { zero line } }\n puts $line\n}",
                "5",
            ),
            (
                "set go 1\nswitch -glob -- [gets stdin] { q* { namespace eval :: {set go 0} } }\nputs $go",
                "1",
            ),
        ] {
            let opts = run_pass(src);
            assert!(
                opts.iter()
                    .all(|o| !(matches!(o.code, DiagCode::O100 | DiagCode::O102)
                        && o.replacement == stale)),
                "{src}: {opts:?}"
            );
        }
    }

    #[test]
    fn retained_substitution_native_object_callbacks_withdraw_builtin_erasure() {
        let registry = tcl_registry::model::ingress::static_context_for("tcl9.1").commands();
        let source = "proc f {input} {puts [llength $input]}";
        let cu = CompilationUnit::build_for_dialect(source, registry, false, "tcl9.1");
        let statement = &cu
            .ir_module
            .procedures
            .get(&fixture_id(&cu.ir_module.procedures, "::f"))
            .expect("authored fixture body")
            .body
            .statements[0];
        let tokens = cu
            .ir_module
            .procedures
            .get(&fixture_id(&cu.ir_module.procedures, "::f"))
            .expect("authored fixture body")
            .body
            .retained_source_tokens_for_statement(statement)
            .expect("original carrier");
        let calls = retained_substitution_calls(tokens, &cu.ir_module, registry)
            .expect("complete children");
        let call = calls
            .iter()
            .find(|call| {
                call.tokens.as_ref().is_some_and(|tokens| {
                    tokens
                        .argv_texts
                        .first()
                        .is_some_and(|head| head == "llength")
                })
            })
            .expect("original length invocation");
        let metadata = Some(cu.top_level.invocation_metadata_context(registry).unwrap());
        let invocation =
            crate::registry_invocation::resolved_tokens_invocation_with_metadata_context(
                registry,
                metadata,
                call.tokens.as_ref().unwrap(),
            )
            .expect("selected builtin independent of native object effects");
        assert!(invocation.facts.effects.requires_world_barrier());
        assert!(fold_retained_builtin(registry, call, &calls, None, metadata, None).is_none());
    }

    #[test]
    fn retained_substitution_formal_seeds_share_defaults_and_jim_rest_names() {
        use tcl_dialect::ParameterGrammar::{Jim, Tcl};
        let policy = crate::tcl_expr_eval::FoldPolicy::default();
        let parameters =
            tcl_syntax::formal_params::parse_formal_parameters_in("{value DEFAULT} args", Tcl)
                .unwrap();
        let seed = seed_params_from_args(&parameters, &[], Tcl, policy).unwrap();
        assert_eq!(
            seed.get(&("value".into(), 0)),
            Some(&LatticeValue::Const(ConstValue::String("DEFAULT".into())))
        );
        assert_eq!(
            seed.get(&("args".into(), 0)),
            Some(&LatticeValue::Const(ConstValue::String(String::new())))
        );
        let parameters =
            tcl_syntax::formal_params::parse_formal_parameters_in("{args remaining} tail", Jim)
                .unwrap();
        let seed = seed_params_from_args(
            &parameters,
            &[ConstValue::Int(1), ConstValue::Int(2), ConstValue::Int(3)],
            Jim,
            policy,
        )
        .unwrap();
        assert_eq!(
            seed.get(&("remaining".into(), 0)),
            Some(&LatticeValue::Const(ConstValue::String("1 2".into())))
        );
        assert_eq!(
            seed.get(&("tail".into(), 0)),
            Some(&LatticeValue::Const(ConstValue::Int(3)))
        );
        let parameters =
            tcl_syntax::formal_params::parse_formal_parameters_in("&reference", Jim).unwrap();
        assert!(
            seed_params_from_args(&parameters, &[ConstValue::String("x".into())], Jim, policy)
                .is_none()
        );
    }
    #[test]
    fn retained_expression_argument_folding_requires_actual_availability() {
        // naming.compiler.original-analysis-metadata-context
        // docs/design/analysis/name-resolution-proofs/original-analysis-metadata-context.md
        // Actual original registrations are retained independently of metadata
        // availability. The owner stays alive through every refusal control.
        let baseline = tcl_registry::model::ingress::static_context_for("tcl8.6");
        let mut catalogue = baseline
            .commands()
            .project_for_profile(tcl_dialect::DialectProfile::find("tcl8.6").unwrap());
        let mut descriptor = catalogue.get("expr").unwrap().clone();
        descriptor.surface = Some(tcl_dialect::model::SpecSurface::TCL86_PLUS);
        catalogue.insert(descriptor);
        let current =
            std::sync::Arc::new(baseline.with_command_store(std::sync::Arc::new(catalogue)));
        let registry = current.commands();
        let (_owner, native) = crate::environment_ingress::captured_native_entry_with_owner(
            registry.profile().unwrap(),
        );
        let entry = crate::command_binding::SourceAnalysisEntry {
            invocation_dialect: registry
                .profile()
                .map(tcl_registry::InvocationDialect::of_profile),
            native_compilation: crate::environment_ingress::authoring_native_compilation(),
            native_entry: Some(std::sync::Arc::new(native)),
            ..crate::command_binding::SourceAnalysisEntry::default()
        };
        let mut unit = CompilationUnit::build_with_context_registry(
            "puts [expr {1 + 2}]",
            crate::compilation_unit::UnitBuildOptions {
                registry,
                defer_top_level: false,
                config: tcl_lexer::LexerConfig::for_dialect("tcl8.6"),
                dialect: registry.profile(),
                external_call_sites: None,
                declared_commands: None,
            },
            Some(&entry),
            std::sync::Arc::clone(&current),
        );
        let statement = &unit.ir_module.top_level.statements[0];
        let tokens = unit
            .ir_module
            .top_level
            .retained_source_tokens_for_statement(statement)
            .unwrap()
            .clone();
        let calls = retained_substitution_calls(&tokens, &unit.ir_module, registry).unwrap();
        let call = calls.iter().find(|call| call.command == "expr").unwrap();
        let constants = std::collections::HashMap::new();
        let mut context = PassContext::new(&unit.source, InterproceduralAnalysis::default());
        context.registry = Some(registry);
        assert_eq!(
            try_o101_expr_arg_fold(&context, &unit, &tokens, call, &constants),
            Some("3".into())
        );
        let input = unit.ir_module.source_metadata_input.clone().unwrap();
        let older = std::sync::Arc::new(
            tcl_registry::model::ingress::static_context_for("tcl8.4")
                .with_command_store(std::sync::Arc::clone(registry)),
        );
        assert!(std::sync::Arc::ptr_eq(older.commands(), registry));
        let foreign =
            tcl_registry::model::ingress::resolve_environment("tcl9.1").default_context_registry();
        for withheld in [Some(older), Some(foreign), None] {
            unit.ir_module.source_metadata_input = withheld.map(|availability| {
                crate::analyser::ResolvedAnalysisInput::new(
                    input.analyser_profile(),
                    input.unit_profile(),
                    availability,
                    input.lexer_config(),
                )
            });
            let mut context = PassContext::new(&unit.source, InterproceduralAnalysis::default());
            context.registry = Some(registry);
            assert!(try_o101_expr_arg_fold(&context, &unit, &tokens, call, &constants).is_none());
        }
    }

    #[test]
    fn retained_recursive_folding_preserves_actual_availability() {
        // naming.compiler.original-analysis-metadata-context
        // docs/design/analysis/name-resolution-proofs/original-analysis-metadata-context.md
        let current = tcl_registry::model::ingress::static_context_for("tcl8.6");
        let registry = current.commands();
        let cu = CompilationUnit::build_for_dialect(
            "puts [list [dict create key value]]",
            registry,
            false,
            "tcl8.6",
        );
        let statement = &cu.ir_module.top_level.statements[0];
        let tokens = cu
            .ir_module
            .top_level
            .retained_source_tokens_for_statement(statement)
            .unwrap();
        let calls = retained_substitution_calls(tokens, &cu.ir_module, registry).unwrap();
        let outer = calls.iter().find(|call| call.command == "list").unwrap();
        assert_eq!(
            fold_retained_builtin(registry, outer, &calls, None, Some(current.into()), None),
            Some("{key value}".into())
        );
        let older = tcl_registry::model::ingress::static_context_for("tcl8.4")
            .with_command_store(std::sync::Arc::clone(registry));
        let foreign = tcl_registry::model::ingress::static_context_for("tcl9.1");
        for metadata in [Some((&older).into()), Some(foreign.into()), None] {
            assert!(fold_retained_builtin(registry, outer, &calls, None, metadata, None).is_none());
        }
        let tokens = tokens.clone();
        let span = statement.span();
        let mut missing = cu;
        missing.ir_module.source_metadata_input = None;
        let mut context = PassContext::new(&missing.source, InterproceduralAnalysis::default());
        context.registry = Some(registry);
        visit_call_cmd_subst_folds(
            &mut context,
            &missing,
            &tokens,
            &std::collections::HashMap::new(),
            "::",
            span,
        );
        assert!(context.optimisations.is_empty());
    }
    /// The controls: a name the hidden writes never name, a name assigned
    /// after the call the module cannot see, and a read the call follows still
    /// forward.
    #[test]
    fn o100_and_o102_still_forward_a_literal_no_hidden_write_can_replace() {
        for (src, literal) in [
            ("proc p {} {\n set g 5\n puts $g\n foo\n}", "5"),
            (
                "set go 1\nswitch -glob -- [gets stdin] { q* { set other 0 } }\nputs $go",
                "1",
            ),
            ("foo\nset g 5\nputs $g", "5"),
            (
                "proc hit {} {global hits; incr hits}\nproc p {s} {\n set n 5\n switch -glob -- $s { g* { hit } }\n puts $n\n}",
                "5",
            ),
        ] {
            let opts = run_pass(src);
            assert!(
                opts.iter()
                    .any(|o| matches!(o.code, DiagCode::O100 | DiagCode::O102)
                        && o.replacement == literal),
                "{src}: {opts:?}"
            );
        }
    }
}
