#!/bin/sh
exec python3 /tmp/compiler-source46-focused58-v1/launch.py "$@"
