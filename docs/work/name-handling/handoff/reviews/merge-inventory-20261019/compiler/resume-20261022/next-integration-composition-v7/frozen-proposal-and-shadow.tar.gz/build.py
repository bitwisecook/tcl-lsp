#!/usr/bin/env python3
"""Off-tree exact reviewed component union; no Git, Cargo or canonical writes."""
import argparse, pathlib, json, hashlib, difflib, subprocess, shutil, tomllib
P=pathlib.Path
H=lambda b:hashlib.sha256(b).hexdigest()
def need(ok, why):
 if not ok:raise SystemExit('STOP: '+why)
def rows(patch):
 paths=[];normalized=[]
 for line in patch.splitlines(True):
  if line.startswith('--- ') and not line.startswith(('--- a/','--- /dev/null')):line='--- a/'+line[4:]
  if line.startswith('+++ ') and not line.startswith(('+++ b/','+++ /dev/null')):line='+++ b/'+line[4:]
  if line.startswith('+++ b/'):paths.append(line[6:].strip().split('\t')[0])
  normalized.append(line)
 need(paths and len(paths)==len(set(paths)), 'duplicate/no component paths')
 for p in paths:need(not P(p).is_absolute() and '..' not in P(p).parts,'unsafe path')
 return paths,''.join(normalized)
def apply(sh,patch):
 r=subprocess.run(['patch','--batch','--fuzz=0','-p1','-i',str(patch)],cwd=sh,capture_output=True,text=True)
 need(r.returncode==0 and 'offset' not in r.stdout.lower() and 'fuzz' not in r.stdout.lower(),r.stdout+r.stderr)
def main():
 a=argparse.ArgumentParser();a.add_argument('--spec',type=P,required=True);a.add_argument('--spec-sha256',required=True);a.add_argument('--output',type=P,required=True);o=a.parse_args()
 need(H(o.spec.read_bytes())==o.spec_sha256,'spec hash');spec=json.loads(o.spec.read_text());root=P(spec['root']);pred=P(spec['predecessor_manifest']);need(H(pred.read_bytes())==spec['predecessor_manifest_sha256'],'predecessor hash');m=json.loads(pred.read_text());v=m['variants'][0]
 need(H(P(v['combined_patch']).read_bytes())==v['combined_patch_sha256'],'predecessor combined hash')
 need(o.output.is_absolute() and o.output.parent==P('/tmp') and not o.output.exists(),'fresh direct/tmp output required');o.output.mkdir()
 base={};edits={};components=list(m['components']);pre_final={}
 def current(path):
  if path not in base:base[path]=(root/path).read_bytes() if (root/path).exists() else b''
  return base[path]
 def diff(owner,path,before,after):
  need(before==current(path),'current base mismatch '+path)
  al=before.decode().splitlines(True);bl=after.decode().splitlines(True)
  for tag,i,j,k,l in difflib.SequenceMatcher(None,al,bl,autojunk=False).get_opcodes():
   if tag!='equal':edits.setdefault(path,[]).append(dict(owner=owner,start=i,end=j,old=al[i:j],new=bl[k:l]))
 for r in v['files']:
  b=current(r['path']);need((H(b) if (root/r['path']).exists() else None)==r['before_sha256'],'predecessor currentpin '+r['path']);p=P(v['combined_patch']).parent/v['id']/r['path'];f=p.read_bytes();need(H(f)==r['after_sha256'],'predecessor shadowpin '+r['path']);pre_final[r['path']]=f;diff('reviewed-predecessor',r['path'],b,f)
 stages=[]
 for c in spec['additions']:
  patch=P(c['patch_path']);need(H(patch.read_bytes())==c['patch_sha256'],'component hash '+c['id']);paths,text=rows(patch.read_text());sh=o.output/'components'/c['id'];sh.mkdir(parents=True);norm=o.output/(c['id']+'.patch');norm.write_text(text);files=[]
  for p in paths:
   b=pre_final.get(p,current(p)) if c.get('base_kind')=='predecessor-final' else current(p)
   if b or (root/p).exists():q=sh/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
  apply(sh,norm)
  for p in paths:
   b=pre_final.get(p,current(p)) if c.get('base_kind')=='predecessor-final' else current(p);f=(sh/p).read_bytes();files.append(dict(path=p,before_sha256=H(b) if (root/p).exists() else None,after_sha256=H(f)))
   if c.get('base_kind')=='predecessor-final':stages.append((c['id'],p,b,f))
   else:diff(c['id'],p,b,f)
  components.append(dict(c,files=files,testing_gaps='Typing/runtime UNRUN',independent_apply='zero-fuzz/no-offset PASS'))
 final={};union=[]
 for path,es in sorted(edits.items()):
  es.sort(key=lambda e:(e['start'],e['end'],e['owner']));unique=[]
  for e in es:
   if any((e['start'],e['end'],e['new'])==(x['start'],x['end'],x['new']) for x in unique):continue
   same=next((x for x in unique if e['start']==e['end']==x['start']==x['end']),None)
   if same:
    policy=next((z for z in spec.get('allowed_same_site_pure_logs',[]) if z['path']==path and z['start']==e['start']),None)
    need(policy is not None,'same-site union lacks exact policy '+path)
    parts={x['owner']:x for x in (same,e)};order=policy['ordered_fragments'];need(set(parts)=={z['owner'] for z in order},'same-site owner mismatch')
    for z in order:need(H(''.join(parts[z['owner']]['new']).encode())==z['sha256'],'same-site fragment hash mismatch')
    same['new']=[line for z in order for line in parts[z['owner']]['new']];same['owner']='+'.join(z['owner'] for z in order);same['reviewed_insert_fragments']=order
    continue
   for x in unique:
    collision=(e['start']<e['end'] and x['start']<x['end'] and e['start']<x['end'] and x['start']<e['end']) or (e['start']==e['end'] and x['start']<e['start']<x['end']) or (x['start']==x['end'] and e['start']<x['start']<e['end']) or (e['start']==e['end']==x['start']==x['end'])
    need(not collision,'unreviewed overlap '+path+' '+x['owner']+' / '+e['owner'])
   unique.append(e)
  lines=current(path).decode().splitlines(True)
  for e in reversed(unique):need(lines[e['start']:e['end']]==e['old'],'fragment mismatch');lines[e['start']:e['end']]=e['new']
  final[path]=''.join(lines).encode();union.append(dict(path=path,owners=sorted(set(e['owner'] for e in unique)),fragments=[dict(owner=e['owner'],start=e['start'],end=e['end'],before_sha256=H(''.join(e['old']).encode()),after_sha256=H(''.join(e['new']).encode())) for e in unique]))
 for owner,p,b,f in stages:need(final.get(p,current(p))==b,'dependent stage base changed '+owner+' '+p);final[p]=f
 shadow=o.output/'successor-without-alias';shadow.mkdir();combined='';files=[]
 for p,f in sorted(final.items()):
  q=shadow/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(f);b=current(p);combined+=''.join(difflib.unified_diff(b.decode().splitlines(True),f.decode().splitlines(True),fromfile='a/'+p if (root/p).exists() else '/dev/null',tofile='b/'+p));files.append(dict(path=p,before_sha256=H(b) if (root/p).exists() else None,after_sha256=H(f)))
 patch=o.output/'successor-without-alias.patch';patch.write_text(combined);check=o.output/'independent-reapply';check.mkdir()
 for p in final:
  if (root/p).exists():q=check/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(current(p))
 apply(check,patch)
 for p,f in final.items():need((check/p).read_bytes()==f,'whole union reapply '+p)
 source=P(m['source46_manifest_path']);need(H(source.read_bytes())==m['source46_manifest_sha256'],'source46 map');sm=json.loads(source.read_text());mp={r['path']:r.copy() for r in sm['paths']}
 for r in sm['paths']:need(H((root/r['path']).read_bytes())==r['after_sha256'],'source46 moved '+r['path'])
 for r in files:
  if r['path'] in mp:need(mp[r['path']]['after_sha256']==r['before_sha256'],'cumulative before');mp[r['path']]['after_sha256']=r['after_sha256']
  else:mp[r['path']]=r.copy()
 candidate=o.output/'candidate-source-map.json';candidate.write_text(json.dumps(dict(schema='PROPOSED-map-not-actual-identity',source_commit=sm['source_commit'],path_count=len(mp),paths=[mp[p] for p in sorted(mp)],typing=False,runtime_tested=False),indent=2)+'\n')
 out=dict(m,schema='offtree-next-integration-reviewed-successor',components=components,variants=[dict(id=shadow.name,component_count=len(components),path_count=len(files),combined_patch=str(patch),combined_patch_sha256=H(patch.read_bytes()),files=files,status='offtree/untyped/unrun/not rootGO')],reviewed_predecessor_manifest_path=str(pred),predecessor_manifest_sha256=spec['predecessor_manifest_sha256'],spec_sha256=o.spec_sha256,proposed_source_map=str(candidate),proposed_source_map_sha256=H(candidate.read_bytes()),proposed_source_count=len(mp),peer_status='new successor union peer pending',testing='All new combined typing/runtime UNRUN; predecessor results not acceptance')
 (o.output/'manifest.json').write_text(json.dumps(out,indent=2)+'\n');(o.output/'fragment-union.json').write_text(json.dumps(union,indent=2)+'\n');print(json.dumps(dict(manifest_sha256=H((o.output/'manifest.json').read_bytes()),patch_sha256=H(patch.read_bytes()),components=len(components),batch_paths=len(files),proposed_cumulative=len(mp))))
if __name__=='__main__':main()
