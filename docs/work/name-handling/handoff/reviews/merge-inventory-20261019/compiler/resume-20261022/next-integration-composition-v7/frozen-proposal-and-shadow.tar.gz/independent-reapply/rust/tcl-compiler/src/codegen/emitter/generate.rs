// tcl-lsp — a language server and toolchain for Tcl
// Copyright (C) 2026 James Deucker (bitwisecook) <https://github.com/bitwisecook>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.
//
// SPDX-License-Identifier: AGPL-3.0-or-later

//! Main `generate()` dispatcher.
//!
//! Walks the CFG in block-order (from [`ordering::linearise`]) and
//! delegates per-block work to handlers. Runs peephole passes and
//! the layout pass to produce the final [`FunctionAsm`].

#![allow(dead_code)]

use std::collections::{BTreeSet, HashMap, HashSet};

use tcl_registry::InlineBodyErrorContext;

use crate::cfg::BodyErrorContext;

use crate::cfg::{Function as CfgFunction, Terminator};
use crate::ir::Statement;

use super::super::CodegenCtx;
use super::super::layout::{optimise_jumps, resolve_layout};
use super::super::{FunctionAsm, Op, Operand, SourceCommandBoundary};
use super::loop_blocks::{ComplexForeach, ForeachInfo, detect_complex_foreach, detect_foreach};
use super::ordering::{
    self, LOOP_BODY_PREFIXES, LOOP_END_PREFIXES, VALUE_JOIN_PREFIXES, linearise, starts_with_any,
};
use super::try_blocks::{
    CatchRegionInfo, TryFinallyInfo, detect_catch_regions, detect_try_finally, is_catch_defs_marker,
};

/// Per-block `(continue, break)` loop-target labels, innermost-first.
/// Continue is `None` for a `for`-step block (continue propagates out).
type LoopContext = HashMap<String, (Option<String>, String)>;

type SourceCommandOwner = (
    u32,
    Option<tcl_lexer::Span>,
    tcl_lexer::SourceImage,
    tcl_runtime_api::ByteNamespacePath,
    Option<tcl_runtime_api::CompiledNamespaceContext>,
);

/// Convert a target-neutral Tcl inline-body error context to the bytecode
/// runtime's body-frame label ABI.
const fn inline_body_frame_label(context: InlineBodyErrorContext) -> &'static str {
    match context {
        InlineBodyErrorContext::SameFrameScriptEvaluation => "eval",
    }
}

/// Transient state passed between the per-block handlers in `generate`.
struct GenerateState {
    /// Block names to skip — consumed by jump tables or try/finally.
    skip_blocks: HashSet<String>,
    /// Detected try/finally chains keyed by `try_body` block.
    try_finally_info: HashMap<String, TryFinallyInfo>,
    /// Detected `catch` regions keyed by `catch_body` block.
    catch_region_info: HashMap<String, CatchRegionInfo>,
    /// While-loop startCommand end labels: `while_end_N` → deferred
    /// label to place at the end block.
    while_end_labels: HashMap<String, String>,
    /// For-init startCommand end labels: `for_end_N` → deferred label.
    for_init_end_labels: HashMap<String, String>,
    /// Foreach startCommand end labels: `foreach_end_N` → deferred
    /// label placed at the `foreach_end` block's trailing pop.
    foreach_end_labels: HashMap<String, String>,
    /// Pending startCommand end labels for if/switch join pops — each
    /// label is placed *before* the join pop once it is emitted.
    pending_join_labels: HashMap<String, String>,
    /// Explicit inline structured-command continuation block to its replay
    /// label. The continuation pops either the optimised region's result or the
    /// transparent plain-dispatch child's result into `last_result`.
    command_boundary_end_labels: HashMap<String, String>,
    /// Proc-only constant-true `if` bodies whose first source command begins at
    /// the same bytecode position as the enclosing command. Tcl represents the
    /// pair with one count-two `START_CMD`, not nested markers.
    first_command_covered_by_if: HashSet<String>,
    /// `if`/`switch` head blocks whose command `START_CMD` is already open.
    opened_branch_commands: HashSet<String>,
    /// Blocks in the emitted layout; a join outside it has no result pop to
    /// end a `START_CMD` at.
    laid_out: HashSet<String>,
}

impl GenerateState {
    fn new() -> Self {
        Self {
            skip_blocks: HashSet::new(),
            try_finally_info: HashMap::new(),
            catch_region_info: HashMap::new(),
            while_end_labels: HashMap::new(),
            for_init_end_labels: HashMap::new(),
            foreach_end_labels: HashMap::new(),
            pending_join_labels: HashMap::new(),
            command_boundary_end_labels: HashMap::new(),
            first_command_covered_by_if: HashSet::new(),
            opened_branch_commands: HashSet::new(),
            laid_out: HashSet::new(),
        }
    }
}

/// Read-only foreach detection results, bundled so the per-block
/// emission helpers can borrow them without a long argument list.
struct ForeachData {
    /// Simple foreach loops keyed by their header block.
    info: HashMap<String, ForeachInfo>,
    /// Body blocks of simple foreach loops.
    bodies: HashSet<String>,
    /// Synthetic loop-control landing pads for simple loops, keyed by their
    /// body block.  A `continue` must run `FOREACH_STEP`, rather than re-enter
    /// `FOREACH_START` and reset the iterator; a `break` must run
    /// `FOREACH_END` to release the iterator state.  These are data about the
    /// opcode layout, not command-specific behaviour in the VM.
    simple_control: HashMap<String, SimpleForeachControl>,
    /// Complex foreach loops (bodies with a Branch terminator) keyed by header.
    complex: HashMap<String, ComplexForeach>,
    /// `foreach_end` block name → its header block name (complex only).
    end_to_header: HashMap<String, String>,
    /// Body blocks belonging to a complex foreach loop.
    complex_body_blocks: HashSet<String>,
    /// Body blocks of *collecting* (simple `lmap`) loops — their trailing `POP`
    /// is stripped and an `LMAP_COLLECT` appended (only simple `lmap` lowers
    /// inline; a branching `lmap` body stays on the runtime builtin).
    collect_bodies: HashSet<String>,
    /// End blocks of collecting loops — their loop-result `""` push is suppressed
    /// because the paired `FOREACH_END` already pushed `list(accum)`.
    collect_ends: HashSet<String>,
}

/// Synthetic landing pads for one straight-line foreach body.
#[derive(Clone)]
struct SimpleForeachControl {
    /// Label immediately before `FOREACH_STEP`.
    step_label: String,
    /// Label immediately before `FOREACH_END`.
    break_label: String,
}

/// Detect foreach loops, allocate their opcode-layout control labels on `ctx`,
/// and redirect `loop_ctx` so every body reaches the appropriate step/end
/// opcode for a non-local loop completion.
fn setup_foreach(
    ctx: &mut CodegenCtx,
    cfg: &CfgFunction,
    loop_ctx: &mut LoopContext,
) -> ForeachData {
    // Detect foreach loops; bodies are marked so we can append
    // foreach_step/foreach_end after their statements.
    let info: HashMap<String, ForeachInfo> = detect_foreach(cfg).unwrap_or_else(|| {
        ctx.refuse_native_dependency();
        HashMap::new()
    });
    let bodies: HashSet<String> = info.values().map(|i| i.body.clone()).collect();
    // Collecting (`lmap`) loops: gather their body + end blocks so the emitter can
    // strip the body's trailing `POP` (→ `LMAP_COLLECT`) and suppress the end
    // block's `""` result push. Only *simple* lmaps reach codegen (a branching
    // body is barriered to the runtime builtin), so these are simple-loop blocks.
    let collect_bodies: HashSet<String> = info
        .values()
        .filter(|i| i.collect)
        .map(|i| i.body.clone())
        .collect();
    let collect_ends: HashSet<String> = info
        .values()
        .filter(|i| i.collect)
        .map(|i| i.end.clone())
        .collect();

    // Detect complex foreach loops (bodies with Branch terminator).
    // For these, foreach_step/foreach_end are emitted at the foreach_end
    // block (bottom-tested), and continue/break are rerouted through
    // synthetic step/break labels. Allocate labels directly on ctx so
    // they share the main label-counter pool.
    let mut tmp_counter: u32 = 0;
    let complex: HashMap<String, ComplexForeach> =
        detect_complex_foreach(cfg, &info, &mut tmp_counter)
            .into_iter()
            .map(|(hdr, mut ci)| {
                ci.step_label = ctx.fresh_label("foreach_continue");
                ci.break_label = ctx.fresh_label("foreach_break");
                (hdr, ci)
            })
            .collect();
    let end_to_header: HashMap<String, String> = complex
        .iter()
        .map(|(h, ci)| (ci.end.clone(), h.clone()))
        .collect();
    // Redirect loop context: body blocks of a complex foreach route
    // continue → step_label, break → break_label.
    let mut complex_body_blocks: HashSet<String> = HashSet::new();
    for (hdr, ci) in &complex {
        for bb in &ci.body_blocks {
            if let Some((cont, _brk)) = loop_ctx.get(bb)
                && cont.as_deref() == Some(hdr.as_str())
            {
                loop_ctx.insert(
                    bb.clone(),
                    (Some(ci.step_label.clone()), ci.break_label.clone()),
                );
                complex_body_blocks.insert(bb.clone());
            }
        }
    }

    // Straight-line bodies emit their paired opcodes inline.  They still need
    // synthetic targets: the CFG header would run `FOREACH_START` again, which
    // reconstructs the iterator at element zero, and the CFG end would skip
    // `FOREACH_END`, which owns the iterator teardown.  Keeping the targets in
    // this shared layout descriptor also makes literal and command-produced
    // `break`/`continue` take the same route.
    let mut simple_control = HashMap::new();
    for (header, foreach) in &info {
        if complex.contains_key(header) {
            continue;
        }
        let control = SimpleForeachControl {
            step_label: ctx.fresh_label("foreach_continue"),
            break_label: ctx.fresh_label("foreach_break"),
        };
        if let Some((cont, _)) = loop_ctx.get(&foreach.body)
            && cont.as_deref() == Some(header.as_str())
        {
            loop_ctx.insert(
                foreach.body.clone(),
                (
                    Some(control.step_label.clone()),
                    control.break_label.clone(),
                ),
            );
        }
        simple_control.insert(foreach.body.clone(), control);
    }

    ForeachData {
        info,
        bodies,
        simple_control,
        complex,
        end_to_header,
        complex_body_blocks,
        collect_bodies,
        collect_ends,
    }
}

/// Emit the synthetic per-block prologue: complex-foreach step/end at the
/// loop bottom, the loop-end result push, deferred loop end labels, and the
/// empty-loop-body NOPs. Returns whether `bname` is a loop-end block (its
/// result push must not be re-pushed by the arm-value handling).
fn emit_block_prologue(
    ctx: &mut CodegenCtx,
    cfg: &CfgFunction,
    state: &mut GenerateState,
    fe: &ForeachData,
    bname: &str,
    blk: &crate::cfg::Block,
) -> bool {
    if let Some(label) = state.command_boundary_end_labels.remove(bname) {
        ctx.place_label(&label);
        ctx.emit(Op::POP, vec![]);
    }

    // Complex foreach: emit foreach_step + foreach_end at the
    // bottom of the loop body, before the loop-result push/pop.
    if let Some(header) = fe.end_to_header.get(bname)
        && let Some(info) = fe.complex.get(header)
    {
        ctx.place_label(&info.step_label);
        ctx.emit(Op::FOREACH_STEP, vec![]);
        ctx.place_label(&info.break_label);
        ctx.emit(Op::FOREACH_END, vec![]);
    }

    // Loop-end blocks push "" as the loop command's result — except a
    // *collecting* loop (`lmap`), whose `list(accum)` result is already on the
    // stack from the paired `FOREACH_END`, so its end block pushes nothing.
    let is_loop_end = starts_with_any(bname, LOOP_END_PREFIXES);
    if is_loop_end && blk.statements.is_empty() && !fe.collect_ends.contains(bname) {
        let target = match &blk.terminator {
            Some(Terminator::Goto { target, .. }) => Some(cfg.block_name(*target).to_owned()),
            _ => None,
        };
        if let Some(t) = &target {
            if t.starts_with("exit_") {
                ctx.push_lit("");
            } else {
                ctx.literals.intern("");
                ctx.emit(Op::NOP, vec![]);
                ctx.emit(Op::NOP, vec![]);
                ctx.emit(Op::NOP, vec![]);
            }
        } else {
            ctx.push_lit("");
        }
    }

    // Place deferred for-init / while-loop / foreach startCommand
    // end labels at the loop-end block's pop.
    if let Some(lbl) = state.for_init_end_labels.remove(bname) {
        place_label_before_trailing_pop(ctx, &lbl);
    }
    if let Some(lbl) = state.while_end_labels.remove(bname) {
        place_label_before_trailing_pop(ctx, &lbl);
    }
    if let Some(lbl) = state.foreach_end_labels.remove(bname) {
        place_label_before_trailing_pop(ctx, &lbl);
    }

    // Empty loop body: emit 3 nops.
    if starts_with_any(bname, LOOP_BODY_PREFIXES)
        && blk.statements.is_empty()
        && matches!(blk.terminator, Some(Terminator::Goto { .. }))
    {
        ctx.literals.intern("");
        ctx.emit(Op::NOP, vec![]);
        ctx.emit(Op::NOP, vec![]);
        ctx.emit(Op::NOP, vec![]);
    }

    is_loop_end
}

/// Place any pending `if`/`switch` startCommand end label, then pop the
/// incoming arm value at join blocks with work.
fn emit_join_prologue(
    ctx: &mut CodegenCtx,
    cfg: &CfgFunction,
    state: &mut GenerateState,
    bname: &str,
    blk: &crate::cfg::Block,
) {
    // Pop incoming arm value at join blocks with work. Place any
    // pending startCommand end label *before* the pop so the
    // startCommand covers only the arm body, not the result
    // cleanup.
    if starts_with_any(bname, VALUE_JOIN_PREFIXES) {
        if let Some(lbl) = state.pending_join_labels.remove(bname) {
            ctx.place_label(&lbl);
        }
        if block_has_work(cfg, blk, ctx.is_proc) {
            ctx.emit(Op::POP, vec![]);
        }
    }
}

/// Emit a `foreach_header` block's list loads + `FOREACH_START` opcode.
/// Returns `true` if the block was a foreach header (caller should
/// `return` past normal statement/terminator emission).
fn emit_foreach_header(
    ctx: &mut CodegenCtx,
    cfg: &CfgFunction,
    state: &mut GenerateState,
    fe: &ForeachData,
    bname: &str,
) -> bool {
    let Some(fi) = fe.info.get(bname) else {
        return false;
    };
    if ctx.cmd_index > 0 {
        ctx.set_command_boundary_site(
            cfg.block_id(bname)
                .and_then(|id| cfg.command_boundary_sites.get(&id)),
        );
        let fe_lbl = ctx.fresh_label("cmd_end");
        ctx.emit_comment(
            Op::START_CMD,
            vec![Operand::Label(fe_lbl.clone()), Operand::Imm(1)],
            "",
        );
        ctx.seen_generic_invoke = true;
        state.foreach_end_labels.insert(fi.end.clone(), fe_lbl);
    }
    // `CompileEachloopCmd` makes each loop variable a compiled local before
    // it compiles the list words.
    for var in fi.var_groups.iter().flatten() {
        ctx.intern_compiled_local(var);
    }
    // Native compilation allocates every iterator target before compiling the
    // value words. Original dynamic names remain data on authored backends.
    let targets = fi
        .var_groups
        .iter()
        .map(|group| {
            group
                .iter()
                .map(|name| {
                    ctx.command_variable_slot(name.as_bytes()).map_or_else(
                        || {
                            tcl_bytecode::CompiledVariableTarget::Name(
                                tcl_runtime_api::NameBytes::from(name.as_bytes()),
                            )
                        },
                        tcl_bytecode::CompiledVariableTarget::Slot,
                    )
                })
                .collect()
        })
        .collect();
    for (i, la) in fi.list_args.iter().enumerate() {
        // A braced list word is a literal in every direction: `TclFindElement`'s
        // brace semantics keep `$` / `[…]` inert both for the word itself and
        // for any braced element inside it, so it must be pushed verbatim.
        // Pushing it as an ordinary literal lets the VM's `subst_word` run the
        // substitution at loop entry — `foreach e {{a[b]c} x}` then raises
        // `invalid command name "b"` where tclsh prints `a[b]c`.
        if fi.list_braced.get(i).copied().unwrap_or(false) {
            ctx.push_lit_verbatim(la);
        } else {
            // Nonbraced list words substitute at loop entry. Use the
            // canonical path for dynamic array references such as
            // `$opts(-$key)`; `list_braced` is source-owned metadata, so this
            // consumer never reparses flattened text.
            ctx.emit_value(la, true);
        }
    }
    let fs_idx = ctx.emit(Op::FOREACH_START, vec![Operand::Imm(0)]);
    // Carry the loop-variable groups (C Tcl `ForeachInfo.varLists`) so
    // the VM can bind them; not rendered in disassembly.
    ctx.instructions[fs_idx].foreach_vars = Some(targets);
    // A collecting loop (`lmap`) tells the VM to accumulate each iteration's
    // result and yield `list(accum)` at `FOREACH_END`.
    ctx.instructions[fs_idx].foreach_collect = fi.collect;
    ctx.cmd_index += 1;
    true
}

/// Emit a simple `foreach_body` block: its statements followed by
/// `foreach_step` + `foreach_end`. Returns `true` if the block was a simple
/// foreach body (caller should `return`).
fn emit_foreach_body(
    ctx: &mut CodegenCtx,
    fe: &ForeachData,
    cfg: &CfgFunction,
    bname: &str,
    blk: &crate::cfg::Block,
) -> bool {
    if !fe.bodies.contains(bname) || fe.complex_body_blocks.contains(bname) {
        return false;
    }
    for (index, stmt) in blk.statements.iter().enumerate() {
        ctx.pending_math_source = cfg
            .block_id(bname)
            .and_then(|id| cfg.statement_sources.get(&(id, index)))
            .cloned()
            .flatten();
        ctx.emit_stmt_with_start_cmd(stmt, None, None);
    }
    // foreach_step/foreach_end are synthetic loop machinery with no
    // source construct; clear the sticky statement span so they
    // serialise as null rather than inheriting the last body
    // statement's range.
    ctx.clear_source_site();
    // Collecting loop (`lmap`): strip the body's trailing `POP` so its result
    // stays on the stack, then append it VM-side via `LMAP_COLLECT` on the
    // fall-through path (a break/continue redirect jumps past it, contributing
    // nothing — as C `lmap` does). A result-less body (empty, or ending in a
    // `NOP`-padded shape) has no trailing `POP`, so push the empty string it
    // returns. This mirrors `dict map`'s keep-last-result trick.
    if fe.collect_bodies.contains(bname) {
        if ctx.instructions.last().map(|i| i.op) == Some(Op::POP) {
            ctx.instructions.pop();
        } else {
            ctx.push_lit("");
        }
        ctx.emit(Op::LMAP_COLLECT, vec![]);
    }
    let control = fe
        .simple_control
        .get(bname)
        .expect("every simple foreach body has loop-control labels");
    ctx.place_label(&control.step_label);
    ctx.emit(Op::FOREACH_STEP, vec![]);
    ctx.place_label(&control.break_label);
    ctx.emit(Op::FOREACH_END, vec![]);
    true
}

/// Emit the statements of a normal (non-foreach) block, including for-init
/// and `<cond>` startCommand wrapping.
fn emit_block_statements(
    ctx: &mut CodegenCtx,
    cfg: &CfgFunction,
    state: &mut GenerateState,
    bname: &str,
    blk: &crate::cfg::Block,
) {
    // For-init blocks: the last statement before a Goto to a
    // for_header_N block is the for command's init clause. Wrap
    // it with a count=2 startCommand spanning the whole for loop.
    let for_init_last_idx = detect_for_init_last_stmt(cfg, blk);

    let first_command_covered = state
        .first_command_covered_by_if
        .remove(bname)
        .then(|| {
            blk.statements
                .iter()
                .position(crate::ir::Statement::is_executable_invocation)
        })
        .flatten();
    let is_catch_end_block = state
        .catch_region_info
        .values()
        .any(|info| info.catch_end == *bname);
    for (stmt_idx, stmt) in blk.statements.iter().enumerate() {
        ctx.pending_math_source = cfg
            .block_id(bname)
            .and_then(|id| cfg.statement_sources.get(&(id, stmt_idx)))
            .cloned()
            .flatten();
        // The defs-only marker `lower_catch` leaves on a `catch_end` block
        // exists for SSA; its stores were emitted with the scaffolding. Keyed
        // on the block being a *detected* catch end, so an ordinary
        // zero-argument command that happens to be named `catch` — a document
        // stub, or a user command — is still emitted.
        if is_catch_end_block && is_catch_defs_marker(stmt) {
            continue;
        }
        if Some(stmt_idx) == first_command_covered {
            ctx.emit_stmt_under_start_cmd(stmt);
            continue;
        }
        if Some(stmt_idx) == for_init_last_idx {
            // For-init: emit startCommand with deferred end label
            // and count=2 (for + init both start at this offset).
            if let Some(Terminator::Goto {
                target: fi_header, ..
            }) = &blk.terminator
                && let Some(fi_header_blk) = cfg.blocks.get(fi_header)
                && let Some(Terminator::Branch {
                    false_target: for_end,
                    ..
                }) = &fi_header_blk.terminator
            {
                let fi_label = ctx.fresh_label("for_cmd_end");
                state
                    .for_init_end_labels
                    .insert(cfg.block_name(*for_end).to_owned(), fi_label.clone());
                let before = ctx.instructions.len();
                ctx.emit_stmt_with_start_cmd(stmt, Some(2), Some(&fi_label));
                if let Some(start_cmd) = (before..ctx.instructions.len())
                    .find(|&idx| ctx.instructions[idx].op == Op::START_CMD)
                {
                    ctx.stamp_command_boundary(
                        start_cmd,
                        cfg.block_id(bname)
                            .and_then(|id| cfg.command_boundary_sites.get(&id)),
                    );
                }
                continue;
            }
        }
        // Synthetic condition placeholders get a
        // startCommand whose end label is deferred until the
        // ExprCommand in the branch condition has been emitted.
        // The label is placed by `emit_expr` in expressions.rs.
        // Keyed on the typed marker, not the `<cond>` spelling — that is a
        // legal Tcl command name a script may define and call (see
        // `crate::ir::SyntheticMarker`).
        if let Statement::Call { tokens, .. } = stmt
            && tokens
                .as_ref()
                .and_then(|t| t.synthetic)
                .is_some_and(|m| m == crate::ir::SyntheticMarker::Condition)
        {
            open_branch_command(ctx, cfg, state, bname, blk);
            let cond_label = ctx.fresh_label("cmd_end");
            ctx.pending_cond_end_label = Some(cond_label.clone());
            ctx.emit_stmt_with_start_cmd(stmt, None, Some(&cond_label));
            continue;
        }
        ctx.emit_stmt_with_start_cmd(stmt, None, None);
    }
}

/// Emit the owning command boundary for a structured block that CFG lowering
/// split into an explicit entry/body/continuation region.
fn emit_inline_block_command_boundary(
    ctx: &mut CodegenCtx,
    cfg: &CfgFunction,
    state: &mut GenerateState,
    bname: &str,
) {
    let Some(entry) = cfg.block_id(bname) else {
        return;
    };
    let Some(continuation) = cfg.command_boundary_continuations.get(&entry) else {
        return;
    };
    let Some(site) = cfg.command_boundary_sites.get(&entry) else {
        return;
    };

    ctx.set_command_boundary_site(Some(site));
    let end_label = ctx.fresh_label("inline_block_cmd_end");
    let begin = ctx.emit_comment(
        Op::START_CMD,
        vec![Operand::Label(end_label.clone()), Operand::Imm(1)],
        "",
    );
    ctx.mark_completion_option_scope(
        begin,
        tcl_runtime_api::completion_options::ControlOptionPolicy::FRESH_FORWARDED,
    );
    state
        .command_boundary_end_labels
        .insert(cfg.block_name(*continuation).to_owned(), end_label);
    ctx.cmd_index += 1;
    ctx.seen_generic_invoke = true;
}

/// Emit a block's terminator: constant-folded `if {1}` startCommand,
/// switch jump tables, proc returns, or the generic terminator.
fn emit_block_terminator(
    ctx: &mut CodegenCtx,
    cfg: &CfgFunction,
    state: &mut GenerateState,
    bname: &str,
    blk: &crate::cfg::Block,
    block_order: &[String],
    i: usize,
) {
    let source = cfg
        .block_id(bname)
        .and_then(|id| cfg.terminator_sources.get(&id).and_then(Clone::clone));
    let previous_source = std::mem::replace(&mut ctx.math_source, source);
    let base = match &blk.terminator {
        Some(Terminator::Branch { condition_base, .. }) => *condition_base,
        Some(Terminator::Return { expr_base, .. }) => *expr_base,
        _ => None,
    };
    let previous_base = std::mem::replace(&mut ctx.math_expression_base, base);
    let tokens = cfg
        .block_id(bname)
        .and_then(|id| cfg.source_tokens_at(id, usize::MAX));
    ctx.with_invocation_tokens(tokens, |ctx| {
        emit_block_terminator_inner(ctx, cfg, state, bname, blk, block_order, i);
    });
    ctx.math_source = previous_source;
    ctx.math_expression_base = previous_base;
}

fn emit_block_terminator_inner(
    ctx: &mut CodegenCtx,
    cfg: &CfgFunction,
    state: &mut GenerateState,
    bname: &str,
    blk: &crate::cfg::Block,
    block_order: &[String],
    i: usize,
) {
    let next_block = block_order.get(i + 1).map(String::as_str);
    if let Some(term) = &blk.terminator {
        let switch_dispatch = matches!(
            term,
            Terminator::Branch {
                true_target,
                false_target,
                ..
            } if cfg.block_name(*true_target).starts_with("switch_arm_body_")
                && (cfg.block_name(*false_target).starts_with("switch_next_")
                    || cfg.block_name(*false_target).starts_with("switch_default_"))
        );
        // A constant-true `if` and its first selected-body command begin at the
        // same bytecode offset. In a proc, Tcl emits the owning count-two
        // marker only when an earlier generic invocation could have changed
        // the compile epoch; the first body command then shares that marker.
        // Top-level emission always emits the marker; later peepholes remove
        // it when the unit has no generic invocation.
        if let Some((true_target, join)) = constant_true_if(cfg, term) {
            if ctx.is_proc {
                state
                    .first_command_covered_by_if
                    .insert(cfg.block_name(true_target).to_owned());
            }
            if !ctx.is_proc || ctx.seen_generic_invoke {
                ctx.set_command_boundary_site(
                    cfg.block_id(bname)
                        .and_then(|id| cfg.command_boundary_sites.get(&id)),
                );
                let end_label = ctx.fresh_label("cmd_end");
                ctx.emit_comment(
                    Op::START_CMD,
                    vec![
                        Operand::Label(end_label.clone()),
                        Operand::Imm(if ctx.is_proc { 2 } else { 1 }),
                    ],
                    "",
                );
                ctx.cmd_index += 1;
                ctx.seen_generic_invoke = true;
                state
                    .pending_join_labels
                    .insert(cfg.block_name(join).to_owned(), end_label);
            }
        }

        // Try switch-dispatch jump-table emission first.
        if ctx.try_emit_jump_table(cfg, blk, next_block, &mut state.skip_blocks) {
            // Switch dispatch counts as a command so the first arm
            // body gets its own startCommand.
            ctx.cmd_index += 1;
        } else if ctx.is_proc && matches!(term, Terminator::Return { .. }) {
            ctx.emit_proc_return(term, bname, next_block, block_order, i, cfg);
        } else {
            let begin = ctx.instructions.len();
            ctx.emit_term(cfg, term, next_block);
            if switch_dispatch && begin < ctx.instructions.len() {
                ctx.mark_completion_option_scope(
                    begin,
                    tcl_runtime_api::completion_options::ControlOptionPolicy::FRESH_FORWARDED,
                );
            }
        }
    } else if next_block.is_some() {
        // Terminal block not last in layout — emit done to prevent
        // fallthrough into successor blocks.
        ctx.emit(Op::DONE, vec![]);
    }
}

fn preserve_value_join_result(
    ctx: &mut CodegenCtx,
    cfg: &CfgFunction,
    blk: &crate::cfg::Block,
    is_loop_end: bool,
) {
    let Some(Terminator::Goto { target, .. }) = &blk.terminator else {
        return;
    };
    if !starts_with_any(cfg.block_name(*target), VALUE_JOIN_PREFIXES) {
        return;
    }
    let has_executable_statement = blk
        .statements
        .iter()
        .any(crate::ir::Statement::is_executable_invocation);
    if has_executable_statement && ctx.instructions.last().is_some_and(|i| i.op == Op::POP) {
        ctx.instructions.pop();
    } else if !has_executable_statement && !is_loop_end {
        // Else-less if: false path needs an empty-string result.
        ctx.push_lit("");
    }
}

/// Select lexical loop labels for this block, including inline catch/try bodies.
/// Layout order cannot carry labels from an unrelated, previously emitted block.
fn select_lexical_loop_context(ctx: &mut CodegenCtx, loop_ctx: &LoopContext, block: &str) {
    if let Some((continue_target, break_target)) = loop_ctx.get(block) {
        ctx.continue_target.clone_from(continue_target);
        ctx.break_target = Some(break_target.clone());
    } else {
        ctx.continue_target = None;
        ctx.break_target = None;
    }
}

/// Emit one CFG block (the body of the main block-order loop). Skips
/// try/finally-consumed blocks, dispatches foreach headers/bodies, emits
/// statements, and finishes with the block's terminator.
fn emit_block(
    ctx: &mut CodegenCtx,
    cfg: &CfgFunction,
    state: &mut GenerateState,
    fe: &ForeachData,
    loop_ctx: &LoopContext,
    block_order: &[String],
    i: usize,
) {
    let bname = &block_order[i];
    if state.skip_blocks.contains(bname) {
        ctx.place_label(bname);
        return;
    }
    let blk = cfg.block_by_name(bname).expect("layout block exists");
    ctx.place_label(bname);

    // Synthetic per-block instructions (loop-result pushes, padding
    // NOPs, startCommand boundary markers emitted before any statement)
    // carry no direct source span; statement / terminator emission
    // sets a real span below.
    ctx.clear_source_site();

    // A `for` step has no local continue target; its completion propagates.
    select_lexical_loop_context(ctx, loop_ctx, bname);

    // try/finally inline compilation at try_body block.
    if let Some(info) = state.try_finally_info.get(bname).cloned() {
        ctx.set_command_boundary_site(
            cfg.block_id(bname)
                .and_then(|id| cfg.command_boundary_sites.get(&id)),
        );
        ctx.emit_try_finally_inline(cfg, bname, &info.try_finally);
        return;
    }

    // `catch` region inline compilation at the catch_body block. The body's
    // statements are emitted with the scaffolding, not by the ordinary walk,
    // which pops every statement's value — `catch` needs the last one kept
    // for its result variable. The end block is *not* skipped: it carries the
    // continuation.
    if let Some(info) = state.catch_region_info.get(bname).cloned() {
        ctx.set_command_boundary_site(
            cfg.block_id(bname)
                .and_then(|id| cfg.command_boundary_sites.get(&id)),
        );
        ctx.with_invocation_tokens(info.tokens.as_ref(), |ctx| {
            ctx.emit_catch_region_inline(
                cfg,
                bname,
                info.result_var.as_deref(),
                info.options_var.as_deref(),
            );
        });
        return;
    }

    let is_loop_end = emit_block_prologue(ctx, cfg, state, fe, bname, blk);
    emit_join_prologue(ctx, cfg, state, bname, blk);

    if emit_foreach_header(ctx, cfg, state, fe, bname) {
        return;
    }
    if emit_foreach_body(ctx, fe, cfg, bname, blk) {
        return;
    }

    emit_block_statements(ctx, cfg, state, bname, blk);

    emit_inline_block_command_boundary(ctx, cfg, state, bname);

    // If/switch arms preserve their final executable value for the join.
    preserve_value_join_result(ctx, cfg, blk, is_loop_end);

    // Complex foreach: suppress back-edge Gotos from body blocks
    // to the foreach header. Fall through to foreach_step/foreach_end
    // at the foreach_end block, or jump to step label if not adjacent.
    if fe.complex_body_blocks.contains(bname)
        && let Some(Terminator::Goto { target, .. }) = &blk.terminator
        && let Some(info) = fe.complex.get(cfg.block_name(*target))
    {
        let next_peek = block_order.get(i + 1).map(String::as_str);
        if next_peek != Some(info.end.as_str()) {
            ctx.emit_comment(
                Op::JUMP4,
                vec![Operand::Label(info.step_label.clone())],
                "foreach continue",
            );
        }
        // Back-edge handled; skip terminator emission.
        return;
    }

    // While-loop startCommand: emit before the jump to while_header.
    if ctx.cmd_index > 0
        && let Some(Terminator::Goto {
            target: wh_header, ..
        }) = &blk.terminator
    {
        let is_while_entry = cfg.block_name(*wh_header).starts_with("while_header_")
            && !bname.starts_with("while_body_")
            && !bname.starts_with("while_step_");
        // A body block ending in a join (`if_end_*`) also jumps back to the
        // header; the entry is laid out first, so its end label is pending.
        if is_while_entry
            && let Some(wh_blk) = cfg.blocks.get(wh_header)
            && let Some(Terminator::Branch {
                false_target: wh_end,
                ..
            }) = &wh_blk.terminator
            && !state.while_end_labels.contains_key(cfg.block_name(*wh_end))
        {
            ctx.set_command_boundary_site(
                cfg.block_id(bname)
                    .and_then(|id| cfg.command_boundary_sites.get(&id)),
            );
            let wh_label = ctx.fresh_label("while_cmd_end");
            ctx.emit_comment(
                Op::START_CMD,
                vec![Operand::Label(wh_label.clone()), Operand::Imm(1)],
                "",
            );
            state
                .while_end_labels
                .insert(cfg.block_name(*wh_end).to_owned(), wh_label);
            ctx.cmd_index += 1;
        }
    }

    open_branch_command(ctx, cfg, state, bname, blk);
    emit_block_terminator(ctx, cfg, state, bname, blk, block_order, i);
}

/// The selected arm and join of a constant-true `if` whose arm falls through
/// to the join: the shape Tcl gives one count-sharing `startCommand`.
fn constant_true_if(
    cfg: &CfgFunction,
    term: &Terminator,
) -> Option<(crate::cfg::BlockId, crate::cfg::BlockId)> {
    let Terminator::Branch {
        condition,
        true_target,
        ..
    } = term
    else {
        return None;
    };
    if ordering::fold_const_branch(condition) != Some(true) {
        return None;
    }
    let Some(Terminator::Goto { target: join, .. }) = &cfg.blocks.get(true_target)?.terminator
    else {
        return None;
    };
    cfg.block_name(*join)
        .starts_with("if_end_")
        .then_some((*true_target, *join))
}

/// Open the replayable `START_CMD` of a branch-lowered `if` or exact `switch`
/// at its head block, ending it before the join's result pop. Without it a
/// command-table change replays the preceding command and resumes at the
/// first command inside an arm, skipping the test.
fn open_branch_command(
    ctx: &mut CodegenCtx,
    cfg: &CfgFunction,
    state: &mut GenerateState,
    bname: &str,
    blk: &crate::cfg::Block,
) {
    let Some(term @ Terminator::Branch { .. }) = &blk.terminator else {
        return;
    };
    let Some(head) = cfg.block_id(bname) else {
        return;
    };
    let Some(join) = cfg.branch_command_joins.get(&head) else {
        return;
    };
    // A constant-true `if` whose arm reaches the join opens its own
    // count-sharing marker in `emit_block_terminator`. A join outside the
    // layout has no result pop to end a marker at.
    let join_name = cfg.block_name(*join);
    if ctx.cmd_index == 0
        || !state.laid_out.contains(join_name)
        || constant_true_if(cfg, term).is_some()
        || !state.opened_branch_commands.insert(bname.to_owned())
    {
        return;
    }
    ctx.set_command_boundary_site(cfg.command_boundary_sites.get(&head));
    let end_label = ctx.fresh_label("cmd_end");
    ctx.emit_comment(
        Op::START_CMD,
        vec![Operand::Label(end_label.clone()), Operand::Imm(1)],
        "",
    );
    ctx.cmd_index += 1;
    state
        .pending_join_labels
        .insert(join_name.to_owned(), end_label);
}

/// Emit the trailing `DONE` / proc-exit machinery after all blocks.
fn emit_function_tail(ctx: &mut CodegenCtx, cfg: &CfgFunction) {
    // Empty proc body: push "" as the implicit return value.
    if ctx.is_proc && ctx.instructions.is_empty() {
        ctx.push_lit("");
    }

    // Proc bodies with control flow: trailing done as proc-level exit.
    let has_branches = cfg
        .blocks
        .values()
        .any(|b| matches!(b.terminator, Some(Terminator::Branch { .. })));
    if ctx.is_proc && has_branches {
        if let Some(lbl) = ctx.proc_exit_label.clone() {
            ctx.place_label(&lbl);
        }
        ctx.emit(Op::DONE, vec![]);
    } else if !ctx
        .instructions
        .last()
        .is_some_and(|i| matches!(i.op, Op::DONE | Op::RETURN_IMM))
    {
        ctx.emit(Op::DONE, vec![]);
    }
}

/// Run the peephole passes and layout pass, then assemble the final
/// [`FunctionAsm`] (loop-target table + inline-body error regions).
// Finalisation is one ordered sequence of metadata-sensitive passes.
#[allow(clippy::too_many_lines)]
fn finalize_function(
    ctx: &mut CodegenCtx,
    cfg: &CfgFunction,
    block_order: &[String],
    loop_ctx: &LoopContext,
) -> FunctionAsm {
    if let Some(failure) = cfg.native_compilation_failure.as_deref() {
        super::super::native_failure::retain_dependencies(ctx, failure);
    }
    super::super::native_compiler_pass::capture_first_pass(ctx);
    if ctx.compact_compiler_pass {
        super::super::native_compiler_pass::omit_command_markers(ctx);
    }
    // Peephole passes.
    ctx.strip_empty_start_cmd();
    ctx.remove_trailing_pop();
    ctx.fold_tail_return_to_done();
    ctx.strip_unused_start_cmd();
    ctx.fixup_top_level_start_cmd();
    ctx.fold_const_push_pop_nops();
    ctx.dedup_push_literals();
    ctx.strip_nodedup_tags();

    // Layout pass.
    optimise_jumps(&mut ctx.instructions, &ctx.label_positions, 10);
    let labels = resolve_layout(&mut ctx.instructions, &ctx.label_positions);

    // Mark actual source-command entry independently of diagnostic metadata.
    // START_CMD owns its own replay/continuation path and deliberately does not
    // change the implicit owner: nested inline catch/try instructions retain
    // the enclosing absolute span, and returning to that span is not a second
    // execution of the outer command.
    let mut source_owner: Option<SourceCommandOwner> = None;
    let mut nested_start_owner: Option<SourceCommandOwner> = None;
    for instruction in &mut ctx.instructions {
        if let Some(site) = instruction.source_span.and_then(|span| {
            cfg.command_binding_sites
                .iter()
                .rev()
                .find(|site| site.span == span)
        }) {
            instruction.source_command_namespace =
                super::super::namespace_path_for_binding(&site.binding);
            instruction
                .source_command_namespace_context
                .clone_from(&site.binding.namespace_context);
        }
        if instruction.op == Op::START_CMD {
            if instruction.source_command_boundary.is_start() {
                source_owner = Some((
                    instruction.source_line,
                    instruction.source_span,
                    instruction.source_cmd_text.clone(),
                    instruction.source_command_namespace.clone(),
                    instruction.source_command_namespace_context.clone(),
                ));
                nested_start_owner = None;
            } else if !instruction.source_cmd_text.is_empty() {
                nested_start_owner = Some((
                    instruction.source_line,
                    instruction.source_span,
                    instruction.source_cmd_text.clone(),
                    instruction.source_command_namespace.clone(),
                    instruction.source_command_namespace_context.clone(),
                ));
            }
            continue;
        }
        instruction.source_command_boundary = SourceCommandBoundary::None;
        if instruction.source_cmd_text.is_empty() {
            nested_start_owner = None;
            continue;
        }
        let owner = (
            instruction.source_line,
            instruction.source_span,
            instruction.source_cmd_text.clone(),
            instruction.source_command_namespace.clone(),
            instruction.source_command_namespace_context.clone(),
        );
        if nested_start_owner.as_ref() == Some(&owner) {
            continue;
        }
        nested_start_owner = None;
        if source_owner.as_ref() != Some(&owner) {
            instruction.source_command_boundary = SourceCommandBoundary::Start;
            source_owner = Some(owner);
        }
    }

    let direct_commands = std::mem::take(&mut ctx.direct_commands);
    for instruction in &mut ctx.instructions {
        instruction.script_command = instruction.source_command_boundary.is_start()
            && instruction
                .source_span
                .is_some_and(|span| direct_commands.contains(&span));
    }
    ctx.direct_commands = direct_commands;

    stamp_release_units(ctx, cfg, block_order);

    // Loop-target table: each loop-body instruction → its loop's break/continue
    // byte offsets, so the executor can catch a command-returned break/continue
    // (`if {…} $z`, `eval break`). Built post-layout from the (innermost-first)
    // `loop_ctx` block targets + the final block index ranges. `label_positions`
    // is maintained through the peephole removals, so the indices are final.
    let mut loop_targets = build_loop_targets(
        block_order,
        loop_ctx,
        &ctx.label_positions,
        &labels,
        ctx.instructions.len(),
    );
    for region in ctx.inline_loop_regions.iter().rev() {
        let (Some(&start), Some(&end), Some(&break_offset)) = (
            ctx.label_positions.get(&region.start),
            ctx.label_positions.get(&region.end),
            labels.get(&region.break_target),
        ) else {
            panic!("native inline loop labels must be placed before layout");
        };
        let targets = (
            Some(i32::try_from(break_offset).expect("native loop offset fits i32")),
            region.continue_target.as_ref().map(|target| {
                i32::try_from(
                    *labels
                        .get(target)
                        .expect("native loop continue label must be placed"),
                )
                .expect("native loop offset fits i32")
            }),
        );
        for index in start..end {
            // The outer region is installed first; recursively emitted inner
            // loops then replace its targets for their own instructions.
            loop_targets.insert(index, targets);
        }
    }

    // Inline-body error regions: each registry-described body context the CFG
    // builder retained becomes a region keyed by the enclosing command's source
    // span. Source text is used only for Tcl's `invoked from within` payload;
    // the body-frame identity comes from semantic metadata, never re-parsing.
    // A structured command the release compiles where it stands adds no
    // frame; one it runs — evaluating it directly, or declining to compile
    // it there — adds the frame its command does.
    // A script an inlined `eval` runs is compiled apart from the procedure
    // body holding it, as a script outside one.
    let compiled_apart = |span: tcl_lexer::Span| {
        cfg.inline_body_error_sites.iter().any(|eval| {
            matches!(eval.context, BodyErrorContext::Registry(_))
                && eval.span != span
                && eval.region.start() <= span.start()
                && span.end() <= eval.region.end()
        })
    };
    let compiled_here = |site: &crate::cfg::InlineBodyErrorSite| {
        !ctx.direct_commands.contains(&site.span)
            && !ctx.direct_body_commands.contains(&site.span)
            && if ctx.compiles_locals() && !compiled_apart(site.span) {
                site.compiled.in_procedure
            } else {
                site.compiled.outside_procedure
            }
    };
    let error_regions = cfg
        .inline_body_error_sites
        .iter()
        .filter(|site| !compiled_here(site))
        .filter_map(|site| {
            let span = site.span;
            let cmd_text = ctx.error_info_source_text(span);
            if cmd_text.is_empty() {
                return None;
            }
            let cmd_line = ctx.source_line(span);
            let (frame, base_line) = match site.context {
                BodyErrorContext::Registry(context) => (
                    tcl_bytecode::ErrorRegionFrame::Body(
                        inline_body_frame_label(context).to_owned(),
                    ),
                    cmd_line,
                ),
                BodyErrorContext::LoopBody(label) => (
                    tcl_bytecode::ErrorRegionFrame::Body(label.to_owned()),
                    ctx.source_line(site.region),
                ),
                BodyErrorContext::Clause(text) => (
                    tcl_bytecode::ErrorRegionFrame::Fixed(text.to_owned()),
                    ctx.source_line(site.region),
                ),
                BodyErrorContext::Arm(pattern) => {
                    let pattern = ctx
                        .source
                        .get(pattern.start() as usize..pattern.end() as usize);
                    let text = tcl_cmd_core::switch::arm_frame_text(
                        pattern.unwrap_or_default(),
                        ctx.vm_release(),
                    );
                    (
                        tcl_bytecode::ErrorRegionFrame::Line(
                            String::from_utf8_lossy(&text).into_owned(),
                        ),
                        ctx.source_line(site.region),
                    )
                }
                BodyErrorContext::Script => (
                    tcl_bytecode::ErrorRegionFrame::None,
                    ctx.source_line(site.region),
                ),
            };
            Some(tcl_bytecode::ErrorRegion {
                start: site.region.start(),
                end: site.region.end(),
                frame,
                cmd_text,
                line_base: base_line.saturating_sub(1),
                cmd_line,
                compiled_in_procedure: site.compiled.in_procedure,
            })
        })
        .collect();

    let native_compilation_failure = cfg
        .native_compilation_failure
        .as_deref()
        .and_then(super::super::native_failure::error);
    #[cfg(debug_assertions)]
    if std::env::var("TCL_LSP_NATIVE_ADMISSION_DIAGNOSTIC").as_deref() == Ok("first-decline-v1") {
        eprintln!(
            "ZZ_NATIVE_EMITTER_ADMISSION function={} dependency_refusal={} cfg_admission_required={:?} cfg_failure={} presented_failure={}",
            cfg.name,
            ctx.native_dependency_refusal,
            cfg.native_compilation_admission
                .as_ref()
                .map(|admission| admission.provider_required),
            cfg.native_compilation_failure.is_some(),
            native_compilation_failure.is_some(),
        );
    }
    let native_compilation_preflight =
        if cfg.native_compilation_failure.is_some() && native_compilation_failure.is_none() {
            tcl_runtime_api::NativeCompilationPreflight::UnpresentedDefiniteFailure
        } else if ctx.native_dependency_refusal
            || (native_compilation_failure.is_none()
                && cfg
                    .native_compilation_admission
                    .as_ref()
                    .is_some_and(|admission| admission.provider_required))
        {
            tcl_runtime_api::NativeCompilationPreflight::ProviderRequired
        } else {
            tcl_runtime_api::NativeCompilationPreflight::NotRequired
        };
    FunctionAsm {
        name: cfg.name.clone(),
        required_compiled_local_layout: ctx.required_compiled_local_layout.take(),
        native_compilation_failure,
        native_compilation_preflight,
        native_math_table_prerequisite: ctx.math_table_prerequisite.take(),
        native_compiler_prerequisites: std::mem::take(&mut ctx.native_compiler_prerequisites),
        literals: std::mem::take(&mut ctx.literals),
        lvt: std::mem::take(&mut ctx.lvt),
        instructions: std::mem::take(&mut ctx.instructions),
        labels,
        loop_targets,
        body_base_line: 0,
        proc_body_src: None,
        error_regions,
        plain_command_dispatch: ctx.plain_command_dispatch,
        command_bindings: std::mem::take(&mut ctx.command_binding_requirements)
            .into_iter()
            .collect(),
        procedure_bindings: cfg
            .procedure_binding_requirements
            .iter()
            .cloned()
            .collect::<BTreeSet<_>>()
            .into_iter()
            .collect(),
        site_claims: std::mem::take(&mut ctx.site_claim_requirements)
            .into_iter()
            .collect(),
    }
}

/// Generate bytecode for one CFG function.
///
/// Handles: straight-line code, if/else, switch jump tables, proc
/// returns with dead-code jumps, foreach loops (simple and
/// complex-body variants) with native `foreach_start`/`step`/`end`
/// opcodes, for-init / while `startCommand` wrapping with deferred
/// end labels at the loop-end pop, try/finally CFG patterns,
/// bottom-tested loop layout (via `ordering::reorder_bottom_tested`).
///
/// # Panics
/// Rejects an analysis graph containing [`Terminator::Complete`] before any
/// instruction is emitted. Build execution graphs with
/// [`crate::cfg_builder::build_cfg_codegen_with_registry_and_config`]. Analysis
/// completion summaries cannot replace runtime invocation continuations.
pub fn generate(ctx: &mut CodegenCtx, cfg: &CfgFunction) -> FunctionAsm {
    // Completion summaries describe analysis reachability. Execution retains
    // the original invocation and its runtime continuation instead. Check the
    // whole function before emission, so an analysis CFG cannot accidentally
    // become a partial executable or a fabricated Tcl return.
    assert!(
        cfg.blocks
            .values()
            .all(|block| !matches!(block.terminator, Some(Terminator::Complete { .. }))),
        "bytecode emission requires an execution CFG, not an analysis completion summary"
    );
    ctx.math_invocations
        .clone_from(&cfg.implicit_math_invocations);
    ctx.expression_preparations
        .clone_from(&cfg.expression_preparations);
    ctx.math_table_prerequisite = cfg
        .native_compilation_failure
        .as_deref()
        .and_then(|failure| failure.math_table_prerequisite.clone());
    if cfg.native_compilation_failure.is_some() {
        // The retained compiler traversal ends at this rejection. Required
        // transforms and later source instructions never run at that entry;
        // its original prefix dependencies and unknown presentation remain.
        let block_order = linearise(cfg);
        let loop_ctx = ordering::build_loop_context(cfg);
        return finalize_function(ctx, cfg, &block_order, &loop_ctx);
    }
    ctx.native_dependency_refusal = !ctx
        .retain_expression_preparations(&cfg.required_expression_preparations)
        || !ctx.retain_math_invocations(&cfg.required_math_invocations);
    if !ctx.plain_command_dispatch {
        for site in &cfg.command_binding_sites {
            ctx.require_command_site(site);
        }
    }
    let block_order = linearise(cfg);
    let mut loop_ctx = ordering::build_loop_context(cfg);
    let mut state = GenerateState::new();
    state.laid_out = block_order.iter().cloned().collect();
    // Native Tcl compiles an original zero-command script as an empty result,
    // independently of the synthetic return used to terminate an IR graph.
    // The retained source instance also covers procedure bodies whose parent
    // module contains commands; an empty module projection is insufficient.
    if ctx.instructions.is_empty()
        && cfg.native_compilation_failure.is_none()
        && let Some(protocol @ tcl_syntax::native_string::NativeStringProtocol::C(_)) =
            ctx.source_string_protocol
        && cfg.executed_source.as_ref().is_some_and(|source| {
            crate::lowering::command_at_time_script_image(&source.text, ctx.lexer_config())
                .is_ok_and(|script| script.commands.is_empty() && script.fatal_tail.is_none())
        })
    {
        if tcl_runtime_api::native_literal::source_literal_empty_result_is_unshared(protocol) {
            ctx.push_lit_no_dedup_verbatim("");
        } else {
            ctx.push_lit_verbatim("");
        }
        ctx.emit(Op::DONE, vec![]);
        return finalize_function(ctx, cfg, &block_order, &loop_ctx);
    }
    state.try_finally_info = detect_try_finally(cfg, &block_order);
    state.catch_region_info = detect_catch_regions(cfg, &block_order, ctx.registry);

    // The same-frame script bodies folded into this function, so the variable
    // emitters can decline the compiled-local forms inside them
    // (`CodegenCtx::compiles_locals`). Same regions the `errorInfo` body frames
    // are built from at the end of this function.
    ctx.same_frame_eval_spans = cfg
        .inline_body_error_sites
        .iter()
        .filter(|site| {
            site.context
                == BodyErrorContext::Registry(
                    tcl_registry::InlineBodyErrorContext::SameFrameScriptEvaluation,
                )
        })
        .map(|site| (site.span.start(), site.span.end()))
        .collect();

    let fe = setup_foreach(ctx, cfg, &mut loop_ctx);

    // Mark try_end/try_finally/try_after_finally as skipped — they
    // are emitted as part of the try_body block's inline sequence.
    for info in state.try_finally_info.values() {
        state.skip_blocks.insert(info.try_end.clone());
        state.skip_blocks.insert(info.try_finally.clone());
        state.skip_blocks.insert(info.try_after.clone());
    }

    let bodies = BodyTree::new(cfg);
    for i in 0..block_order.len() {
        let block = cfg.block_id(&block_order[i]);
        ctx.direct_body = block.is_some_and(|block| bodies.block_evaluated_directly(ctx, block));
        if ctx.direct_body
            && let Some(block) = block.and_then(|block| cfg.blocks.get(&block))
        {
            let condition_owner = match &block.terminator {
                Some(crate::cfg::Terminator::Branch {
                    span: Some(span), ..
                }) => cfg.condition_owners.get(span).map(|owner| owner.command),
                _ => None,
            };
            ctx.direct_body_commands.extend(
                block
                    .statements
                    .iter()
                    .map(crate::ir::Statement::span)
                    .chain(condition_owner),
            );
        }
        emit_block(ctx, cfg, &mut state, &fe, &loop_ctx, &block_order, i);
    }
    ctx.direct_body = false;
    intern_dead_compiled_locals(ctx, cfg, &state.laid_out);

    emit_function_tail(ctx, cfg);
    finalize_function(ctx, cfg, &block_order, &loop_ctx)
}

/// Make compiled locals of the variables of the code C compiles though this
/// compiler laid none of it out: the clauses of a `for` whose test is a
/// literal constant false, and the commands after one that never completes
/// (`return`, an endless loop). C's `if` and `while` alone leave the script
/// a literal constant test never runs uncompiled.
fn intern_dead_compiled_locals(
    ctx: &mut CodegenCtx,
    cfg: &CfgFunction,
    laid_out: &std::collections::HashSet<String>,
) {
    if !ctx.compiles_locals() || laid_out.len() == cfg.blocks.len() {
        return;
    }
    let predecessors = cfg.predecessors();
    let mut stack: Vec<crate::cfg::BlockId> = std::iter::once(cfg.entry)
        .chain(
            cfg.blocks
                .keys()
                .copied()
                .filter(|block| predecessors.get(block).is_none_or(HashSet::is_empty)),
        )
        .collect();
    let mut compiled: HashSet<crate::cfg::BlockId> = HashSet::new();
    while let Some(block) = stack.pop() {
        if !compiled.insert(block) {
            continue;
        }
        let Some(data) = cfg.blocks.get(&block) else {
            continue;
        };
        let successors = match &data.terminator {
            Some(Terminator::Branch {
                condition,
                true_target,
                false_target,
                span,
                ..
            }) if span
                .and_then(|span| cfg.condition_owners.get(&span))
                .is_some_and(|owner| owner.skips_constant_dead_script) =>
            {
                match ordering::fold_const_branch(condition) {
                    Some(true) => vec![*true_target],
                    Some(false) => vec![*false_target],
                    None => vec![*true_target, *false_target],
                }
            }
            _ => data.successors(),
        };
        stack.extend(successors);
    }
    let mut dead: Vec<crate::cfg::BlockId> = compiled
        .into_iter()
        .filter(|block| !laid_out.contains(cfg.block_name(*block)))
        .collect();
    dead.sort_unstable();
    for block in dead {
        let scripts: Vec<String> = cfg.blocks[&block]
            .statements
            .iter()
            .filter(|statement| statement.is_executable_invocation())
            // A script with no Unicode spelling has no text to lower here.
            .filter_map(|statement| {
                ctx.error_info_source_text(statement.span())
                    .try_text()
                    .ok()
                    .map(str::to_owned)
            })
            .collect();
        for script in scripts {
            ctx.intern_script_locals(&script);
        }
    }
}

/// Stamp what a release that keeps the commands running bytecode compiled
/// needs to run this function as it would: each command's
/// [`release_hold`](tcl_bytecode::Instruction::release_hold), and the script
/// body each instruction runs part of
/// ([`release_body`](tcl_bytecode::Instruction::release_body)) with where each
/// body starts. Whether the release compiles a body into the unit enclosing it
/// depends on whether that unit is a procedure body, which for a script
/// compiled at run time only the activation running it knows.
fn stamp_release_units(ctx: &mut CodegenCtx, cfg: &CfgFunction, block_order: &[String]) {
    if ctx.vm_release().revalidates_running_bytecode() {
        return;
    }
    for index in 0..ctx.instructions.len() {
        let instruction = &ctx.instructions[index];
        if instruction.source_command_boundary != SourceCommandBoundary::None
            || (instruction.op == Op::START_CMD && !instruction.source_cmd_text.is_empty())
        {
            let hold = ctx.release_hold(instruction.source_span);
            ctx.instructions[index].release_hold = hold;
        }
    }

    let tree = BodyTree::new(cfg);
    let mut starts: Vec<(usize, crate::cfg::BlockId)> = block_order
        .iter()
        .filter_map(|name| Some((*ctx.label_positions.get(name)?, cfg.block_id(name)?)))
        .collect();
    starts.sort_by_key(|&(position, _)| position);
    for (k, &(start, block)) in starts.iter().enumerate() {
        let end = starts
            .get(k + 1)
            .map_or(ctx.instructions.len(), |&(position, _)| position);
        if let Some(body) = tree.innermost(block) {
            for instruction in &mut ctx.instructions[start.min(end)..end] {
                instruction.release_body = BodyTree::id(body);
            }
        }
    }
    // A body starts where control reaches its first block, whichever block
    // its first instruction was emitted in.
    for (index, body) in cfg.body_scripts.iter().enumerate() {
        let Some(position) = ctx
            .label_positions
            .get(cfg.block_name(body.entry))
            .copied()
            .filter(|&position| {
                ctx.instructions
                    .get(position)
                    .is_some_and(|instruction| instruction.release_body == BodyTree::id(index))
            })
        else {
            continue;
        };
        let parent = tree.parent(index);
        let owner_direct = ctx.direct_commands.contains(&body.owner.span)
            || parent.is_some_and(|parent| tree.evaluated_directly(ctx, parent));
        let owner = if owner_direct {
            tcl_runtime_api::ReleaseBinding::Invoked
        } else {
            ctx.release_binding_of(&body.owner.binding.name, &body.owner.shape)
                .unwrap_or(tcl_runtime_api::ReleaseBinding::Invoked)
        };
        ctx.instructions[position].release_body_entry = Some(tcl_bytecode::ReleaseBodyEntry {
            parent: parent.map_or(0, BodyTree::id),
            owner,
        });
    }
}

/// The script bodies of a CFG function ([`CfgFunction::body_scripts`]) as
/// they nest.
struct BodyTree<'c> {
    bodies: &'c [crate::cfg::BodyScript],
    /// How many other bodies enclose each body.
    depths: Vec<usize>,
}

impl<'c> BodyTree<'c> {
    fn new(cfg: &'c CfgFunction) -> Self {
        let bodies = cfg.body_scripts.as_slice();
        let depths = (0..bodies.len())
            .map(|inner| {
                (0..bodies.len())
                    .filter(|&outer| Self::encloses(bodies, outer, inner))
                    .count()
            })
            .collect();
        Self { bodies, depths }
    }

    fn encloses(bodies: &[crate::cfg::BodyScript], outer: usize, inner: usize) -> bool {
        outer != inner && bodies[outer].contains(bodies[inner].entry)
    }

    /// The [`tcl_bytecode::Instruction::release_body`] of body `index`.
    fn id(index: usize) -> u32 {
        u32::try_from(index + 1).expect("body count fits in u32")
    }

    /// The innermost body `block` runs part of.
    fn innermost(&self, block: crate::cfg::BlockId) -> Option<usize> {
        (0..self.bodies.len())
            .filter(|&index| self.bodies[index].contains(block))
            .max_by_key(|&index| self.depths[index])
    }

    /// The body enclosing body `index`.
    fn parent(&self, index: usize) -> Option<usize> {
        (0..self.bodies.len())
            .filter(|&outer| Self::encloses(self.bodies, outer, index))
            .max_by_key(|&outer| self.depths[outer])
    }

    /// Whether the release evaluates body `index` directly, as its owner's
    /// script ([`tcl_registry::release_compilation::evaluates_script_directly`]).
    fn evaluated_directly(&self, ctx: &CodegenCtx, index: usize) -> bool {
        tcl_registry::release_compilation::evaluates_script_directly(
            ctx.vm_release(),
            &self.bodies[index].owner.binding.name,
            1,
        )
    }

    /// Whether the release evaluates the commands of `block` directly: the
    /// innermost body it runs part of is one it evaluates directly.
    fn block_evaluated_directly(&self, ctx: &CodegenCtx, block: crate::cfg::BlockId) -> bool {
        self.innermost(block)
            .is_some_and(|index| self.evaluated_directly(ctx, index))
    }
}

/// Build the per-instruction loop-target table (see `FunctionAsm::loop_targets`).
///
/// `loop_ctx` maps each loop-body block to its `(continue, break)` target
/// labels (innermost-first). Each block occupies the instruction range
/// `[its start, the next block's start)` — `label_positions` gives the final
/// (post-peephole) start index of every block; `labels` resolves the target
/// labels to byte offsets. Stamp every instruction in each loop block's range.
fn build_loop_targets(
    block_order: &[String],
    loop_ctx: &HashMap<String, (Option<String>, String)>,
    label_positions: &HashMap<String, usize>,
    labels: &HashMap<String, usize>,
    n_instructions: usize,
) -> HashMap<usize, (Option<i32>, Option<i32>)> {
    let mut out: HashMap<usize, (Option<i32>, Option<i32>)> = HashMap::new();
    if loop_ctx.is_empty() {
        return out;
    }
    // (start index, block name) for each emitted block, in index order.
    let mut starts: Vec<(usize, &str)> = block_order
        .iter()
        .filter_map(|b| label_positions.get(b).map(|&i| (i, b.as_str())))
        .collect();
    starts.sort_by_key(|&(i, _)| i);
    for (k, &(start, bname)) in starts.iter().enumerate() {
        let Some((cont_lbl, brk_lbl)) = loop_ctx.get(bname) else {
            continue;
        };
        let end = starts.get(k + 1).map_or(n_instructions, |&(i, _)| i);
        let brk_off = labels.get(brk_lbl).and_then(|&o| i32::try_from(o).ok());
        let cont_off = cont_lbl
            .as_ref()
            .and_then(|l| labels.get(l))
            .and_then(|&o| i32::try_from(o).ok());
        for idx in start..end {
            out.insert(idx, (brk_off, cont_off));
        }
    }
    out
}

/// Return `Some(idx)` where `idx` is the index of the for-init
/// statement within `blk.statements`. Returns `None` if this block
/// is not a for-init block.
///
/// A for-init block ends with a `Goto` to a `for_header_N` block and
/// is not itself a `for_step_*` block. The init statement is the
/// last executable one in the block; analysis-only markers do not own a
/// source-command boundary.
fn detect_for_init_last_stmt(cfg: &CfgFunction, blk: &crate::cfg::Block) -> Option<usize> {
    let Terminator::Goto { target, .. } = blk.terminator.as_ref()? else {
        return None;
    };
    if !cfg.block_name(*target).starts_with("for_header_") {
        return None;
    }
    if blk.name.starts_with("for_step_") {
        return None;
    }
    if blk.statements.is_empty() {
        return None;
    }
    // Ensure the target header block exists and has a Branch.
    let header = cfg.blocks.get(target)?;
    if !matches!(header.terminator, Some(Terminator::Branch { .. })) {
        return None;
    }
    blk.statements
        .iter()
        .rposition(crate::ir::Statement::is_executable_invocation)
}

/// Place `label` at the instruction immediately before a trailing
/// `pop` (if any), or at the current instruction index otherwise.
///
/// Used for deferred startCommand end labels that must land at the
/// loop-result cleanup pop.
fn place_label_before_trailing_pop(ctx: &mut CodegenCtx, label: &str) {
    let pos = if ctx.instructions.last().is_some_and(|i| i.op == Op::POP) {
        ctx.instructions.len() - 1
    } else {
        ctx.instructions.len()
    };
    ctx.label_positions.insert(label.to_owned(), pos);
}

/// Return `true` if the join block has work beyond a single fallthrough.
fn block_has_work(cfg: &CfgFunction, blk: &crate::cfg::Block, is_proc: bool) -> bool {
    if !blk.statements.is_empty() {
        return true;
    }
    match &blk.terminator {
        Some(Terminator::Branch { .. } | Terminator::Complete { .. }) => true,
        Some(Terminator::Return { .. }) => is_proc,
        Some(Terminator::Goto { target, .. }) => !cfg.block_name(*target).starts_with("exit_"),
        None => false,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::cfg::{Block, Function as CfgFunction, InlineBodyErrorSite, Terminator};
    use crate::codegen::CodegenCtx;
    use crate::ir::Statement;
    use tcl_lexer::Span;
    use tcl_registry::CommandRegistry;

    fn sp() -> Span {
        Span::new(0, 0)
    }

    fn trivial_cfg() -> CfgFunction {
        let mut cfg = CfgFunction::new("::top", "entry_0");
        let entry = cfg.entry;
        cfg.blocks.get_mut(&entry).unwrap().terminator = Some(Terminator::Return {
            expr_base: None,
            tokens: None,
            value: None,
            value_word: None,
            span: None,
            expr: None,
            braced: false,
        });
        cfg
    }

    #[test]
    fn generate_empty_toplevel_terminates() {
        let cfg = trivial_cfg();
        let registry = CommandRegistry::build_default();
        let mut ctx = CodegenCtx::new(false, &[], &registry);
        let asm = generate(&mut ctx, &cfg);
        assert_eq!(asm.name, "::top");
        assert_ne!(asm.instructions, [] as [tcl_bytecode::Instruction; 0]);
        // Top-level scripts terminate with RETURN_IMM or DONE
        let last = asm.instructions.last().unwrap().op;
        assert!(
            matches!(last, Op::DONE | Op::RETURN_IMM),
            "expected DONE or RETURN_IMM, got {last:?}"
        );
    }

    #[test]
    fn original_empty_script_uses_the_selected_native_literal_producer() {
        use tcl_dialect::TclVersion;
        use tcl_syntax::native_string::NativeStringProtocol;
        for (engine, version) in [
            ("tcl8.4", TclVersion::V8_4),
            ("tcl8.5", TclVersion::V8_5),
            ("tcl8.6", TclVersion::V8_6),
            ("tcl9.0", TclVersion::V9_0),
            ("tcl9.1", TclVersion::V9_1),
        ] {
            let registry = tcl_registry::model::ingress::static_context_for(engine).commands();
            let config = tcl_lexer::LexerConfig::for_profile(registry.profile());
            for source in ["", " \t\n", "# comment\n"] {
                let module = crate::lowering::lower_to_ir_with_config(source, registry, config);
                let cfg =
                    crate::cfg_builder::build_cfg_codegen_with_registry(&module, false, registry);
                for is_proc in [false, true] {
                    let mut ctx = CodegenCtx::new(is_proc, &[], registry);
                    ctx.source_string_protocol = Some(NativeStringProtocol::C(version));
                    let asm = generate(&mut ctx, &cfg.top_level);
                    assert_eq!(asm.instructions.len(), 2, "{engine} {source:?}");
                    assert_eq!(asm.instructions[0].op, Op::PUSH1);
                    assert_eq!(asm.instructions[1].op, Op::DONE);
                    assert_eq!(asm.literals.entries().len(), 1);
                    assert_eq!(
                        matches!(
                            asm.literals.entries()[0].allocation(),
                            tcl_bytecode::NativeLiteralAllocation::Unshared
                        ),
                        version == TclVersion::V8_5,
                        "{engine} {source:?} procedure={is_proc}",
                    );
                }
            }
        }
    }

    #[test]
    fn analysis_completion_graph_is_rejected_before_any_emission() {
        let mut cfg = trivial_cfg();
        cfg.blocks.get_mut(&cfg.entry).unwrap().terminator = Some(Terminator::Complete {
            route: tcl_registry::completion_route::InvocationCompletionRoute::Tcl(
                tcl_registry::CompletionCode::Error,
            ),
            span: Some(sp()),
        });
        let registry = CommandRegistry::build_default();
        let mut ctx = CodegenCtx::new(false, &[], &registry);
        let result =
            std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| generate(&mut ctx, &cfg)));
        assert!(result.is_err());
        assert_eq!(ctx.instructions, [] as [tcl_bytecode::Instruction; 0]);
    }

    #[test]
    fn inline_body_error_region_uses_semantic_context_not_command_text() {
        let source = "renamed-body-command {error boom}";
        let span = Span::new(0, u32::try_from(source.len()).unwrap());
        let mut cfg = trivial_cfg();
        cfg.inline_body_error_sites.push(InlineBodyErrorSite {
            span,
            context: crate::cfg::BodyErrorContext::Registry(
                InlineBodyErrorContext::SameFrameScriptEvaluation,
            ),
            region: span,
            compiled: crate::cfg::CompiledAt::NEVER,
        });
        let registry = CommandRegistry::build_default();
        let mut ctx = CodegenCtx::new(false, &[], &registry);
        ctx.set_source(source);

        let asm = generate(&mut ctx, &cfg);

        let [region] = asm.error_regions.as_slice() else {
            panic!("semantic inline-body context should emit exactly one error region");
        };
        assert_eq!(
            region.frame,
            tcl_bytecode::ErrorRegionFrame::Body("eval".to_owned())
        );
        assert_eq!(region.cmd_text, source);

        let mut source_less = CodegenCtx::new(false, &[], &registry);
        let source_less_asm = generate(&mut source_less, &cfg);
        assert!(
            source_less_asm.error_regions.is_empty(),
            "a source-less context retains the previous no-region behaviour",
        );
    }

    #[test]
    fn generate_stamps_statement_source_span() {
        // A statement with a non-trivial span: its lowered instructions
        // (push / store) must carry that span; the synthetic trailing
        // DONE carries none.
        let mut cfg = CfgFunction::new("::top", "entry_0");
        let entry = cfg.entry;
        let stmt_span = Span::new(4, 10);
        cfg.blocks
            .get_mut(&entry)
            .unwrap()
            .statements
            .push(Statement::AssignConst {
                span: stmt_span,
                name: "x".into(),
                value: "42".into(),
                name_braced: false,
                value_span: None,
            });
        cfg.blocks.get_mut(&entry).unwrap().terminator = Some(Terminator::Return {
            expr_base: None,
            tokens: None,
            value: None,
            value_word: None,
            span: None,
            expr: None,
            braced: false,
        });
        let registry = CommandRegistry::build_default();
        let mut ctx = CodegenCtx::new(false, &[], &registry);
        let asm = generate(&mut ctx, &cfg);

        // The store-into-x instruction came from the AssignConst statement.
        let store = asm
            .instructions
            .iter()
            .find(|i| i.op == Op::STORE_STK)
            .expect("store emitted");
        assert_eq!(
            store.source_span,
            Some(stmt_span),
            "statement-driven op carries its source span"
        );
        // The synthetic terminator (Return with no span) leaves none.
        let done = asm
            .instructions
            .iter()
            .rev()
            .find(|i| matches!(i.op, Op::DONE | Op::RETURN_IMM))
            .expect("terminator emitted");
        assert_eq!(done.source_span, None, "synthetic terminator has no span");
    }

    #[test]
    fn generate_simple_set() {
        let mut cfg = CfgFunction::new("::top", "entry_0");
        let entry = cfg.entry;
        cfg.blocks
            .get_mut(&entry)
            .unwrap()
            .statements
            .push(Statement::AssignConst {
                span: sp(),
                name: "x".into(),
                value: "42".into(),
                name_braced: false,
                value_span: None,
            });
        cfg.blocks.get_mut(&entry).unwrap().terminator = Some(Terminator::Return {
            expr_base: None,
            tokens: None,
            value: None,
            value_word: None,
            span: None,
            expr: None,
            braced: false,
        });
        let registry = CommandRegistry::build_default();
        let mut ctx = CodegenCtx::new(false, &[], &registry);
        let asm = generate(&mut ctx, &cfg);
        // Should contain push and store (tail pop is folded away)
        let ops: Vec<Op> = asm.instructions.iter().map(|i| i.op).collect();
        assert!(ops.contains(&Op::PUSH1));
        assert!(ops.contains(&Op::STORE_STK));
    }

    #[test]
    fn generate_proc_empty_body() {
        let cfg = CfgFunction::new("::foo", "entry_0");
        let registry = CommandRegistry::build_default();
        let mut ctx = CodegenCtx::new(true, &[], &registry);
        // Give the entry block a return terminator
        let mut cfg = cfg;
        let entry = cfg.entry;
        cfg.blocks.get_mut(&entry).unwrap().terminator = Some(Terminator::Return {
            expr_base: None,
            tokens: None,
            value: None,
            value_word: None,
            span: None,
            expr: None,
            braced: false,
        });
        let asm = generate(&mut ctx, &cfg);
        // Proc with empty body should push "" and emit done
        assert_eq!(asm.instructions.last().unwrap().op, Op::DONE);
    }

    #[test]
    fn generate_if_diamond() {
        use crate::expr_ast::ExprNode;
        let mut cfg = CfgFunction::new("::top", "entry_0");
        let entry = cfg.entry;
        let then = cfg.intern_block("if_then_1");
        cfg.blocks.insert(then, Block::new("if_then_1"));
        let els = cfg.intern_block("if_else_1");
        cfg.blocks.insert(els, Block::new("if_else_1"));
        let end = cfg.intern_block("if_end_1");
        cfg.blocks.insert(end, Block::new("if_end_1"));

        cfg.blocks.get_mut(&entry).unwrap().terminator = Some(Terminator::Branch {
            condition: ExprNode::Var {
                text: "$x".into(),
                name: "x".into(),
                start: 0,
                end: 2,
            },
            true_target: then,
            false_target: els,
            span: None,
            condition_base: None,
        });
        cfg.blocks
            .get_mut(&then)
            .unwrap()
            .statements
            .push(Statement::AssignConst {
                span: sp(),
                name: "r".into(),
                value: "1".into(),
                name_braced: false,
                value_span: None,
            });
        cfg.blocks.get_mut(&then).unwrap().terminator = Some(Terminator::Goto {
            target: end,
            span: None,
        });
        cfg.blocks
            .get_mut(&els)
            .unwrap()
            .statements
            .push(Statement::AssignConst {
                span: sp(),
                name: "r".into(),
                value: "2".into(),
                name_braced: false,
                value_span: None,
            });
        cfg.blocks.get_mut(&els).unwrap().terminator = Some(Terminator::Goto {
            target: end,
            span: None,
        });
        cfg.blocks.get_mut(&end).unwrap().terminator = Some(Terminator::Return {
            expr_base: None,
            tokens: None,
            value: None,
            value_word: None,
            span: None,
            expr: None,
            braced: false,
        });

        let registry = CommandRegistry::build_default();

        let mut ctx = CodegenCtx::new(false, &[], &registry);
        let asm = generate(&mut ctx, &cfg);
        let ops: Vec<Op> = asm.instructions.iter().map(|i| i.op).collect();
        // Should include a conditional jump (maybe shrunk to 1-byte)
        assert!(
            ops.contains(&Op::JUMP_FALSE4) || ops.contains(&Op::JUMP_FALSE1),
            "expected conditional jump, got {ops:?}"
        );
    }
}
