// tcl-lsp — a language server and toolchain for Tcl
// Copyright (C) 2026 James Deucker (bitwisecook) <https://github.com/bitwisecook>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.
//
// SPDX-License-Identifier: AGPL-3.0-or-later

//! **The compiled-in core surface packs** — design **Q6**.
//!
//! Q1 ruled that the shipped command surfaces stay native Rust, with one
//! carve-out: Jim's. Its surface is *authored as `SpecTcl` and loaded*,
//! because what it has to say — "of Tcl 8.6's commands, Jim implements
//! these, and adds these" — is a roster and a list of commands, and a roster
//! written as Rust is a second catalogue to keep in step with the first.
//!
//! Two packs carry it. `jim.tclspec` names the Tcl commands Jim inherits (an
//! `include from tcl into jim` roster); `jim-own-surface.tclspec` is the
//! commands Jim adds, each with the release window it was measured in.
//!
//! ## Why this is not a discoverable pack
//!
//! [`crate::bundled`]'s eight EDA loadables ship in `specs/` and are
//! *replaceable*: a distribution, `TCL_LSP_SPEC_PACK_DIR`, or a dev
//! checkout can put a different `specs/` in front of them, and the
//! embedded copies exist only for a bare binary with no directory beside
//! it. That contract is right for a vendor library and wrong for a core
//! surface — under it, an empty `specs/` directory would delete `proc`
//! from Jim.
//!
//! So the sources here are compiled in and loaded **unconditionally**,
//! ahead of and independently of discovery, at [`Provenance::BuiltIn`].
//! They are `SpecTcl` in the sense Q1 meant — authored in the vocabulary,
//! read by the one loader, exercising the same words a third-party pack
//! would — without being a file anyone can take away.
//!
//! ## Where the commands go
//!
//! A roster narrows an ancestor's surface and registers with the dialect
//! model ([`builtin_rosters`]). Commands register with the registry
//! ([`builtin_commands`]) as a family's own compiled-in surface, not as a
//! pack overlay: an overlay is built per pack set and reaches only the
//! catalogue profiles, while a `jim` document is served by a store of its
//! own family that must carry these commands whatever pack set is loaded.
//!
//! ## Ordering
//!
//! [`ensure`] seeds the dialect model and the registry once per process and
//! costs a lock and a flag after that. Every path that hands a consumer a
//! registry or a pack set goes through it — [`crate::install::registry_with_packs`],
//! [`crate::bundled::packs`], [`crate::registration::publish_pack_set`] — and
//! the language server calls it in its `initialize` handler, before any
//! client message can open a document. A document analysed before the first
//! pack set is loaded therefore sees the surface a document analysed after
//! it does.
//!
//! [`crate::registration::publish_pack_set`] folds these rosters in with
//! whatever the loaded set declares, so the model-side sync (which replaces
//! the whole store) can never drop them, and a seed that runs after a
//! publication leaves the published rosters in place.

use std::sync::{Mutex, MutexGuard, OnceLock, PoisonError};

use tcl_dialect::model::{InheritedSurface, InheritedSurfaceRegistration, Provenance};
use tcl_registry::spec::CommandSpec;

use crate::loader::{Pack, PackSurfaceRoster};

/// The core surface packs' `SpecTcl` sources, by the name their notices
/// report against.
const CORE_SURFACES: &[(&str, &str)] = &[
    ("jim.tclspec", include_str!("../core-surfaces/jim.tclspec")),
    (
        "jim-own-surface.tclspec",
        include_str!("../core-surfaces/jim-own-surface.tclspec"),
    ),
];

/// The compiled-in packs, evaluated once, in source order.
fn packs() -> &'static [Pack] {
    static PACKS: OnceLock<Vec<Pack>> = OnceLock::new();
    PACKS.get_or_init(|| {
        CORE_SURFACES
            .iter()
            .map(|(_, source)| prepare_builtin_pack(crate::loader::evaluate_pack(source)))
            .collect()
    })
}

// Only the fixed CORE_SURFACES load above reaches this preparation boundary.
fn prepare_builtin_pack(mut pack: Pack) -> Pack {
    for command in &mut pack.commands {
        let original = command.spec;
        if original.procedure_definition.is_some() {
            continue;
        }
        let descriptor = tcl_registry::native_procedure::BUILTIN_CORE_PROCEDURE_DESCRIPTORS
            .iter()
            .find(|descriptor| {
                original.name == descriptor.name
                    && original.analyser_hook == Some(descriptor.analyser_hook)
                    && original.traits.contains(descriptor.traits)
                    && original.surface.is_some_and(|surface| {
                        surface
                            .iter()
                            .any(|row| row.provider == descriptor.provider)
                    })
            });
        if let Some(descriptor) = descriptor {
            let mut canonical = original.clone();
            canonical.procedure_definition = Some(descriptor.definition);
            command.spec = Box::leak(Box::new(canonical));
        }
    }
    pack
}

/// The roster rows the compiled-in sources declare, parsed once.
fn rows() -> Vec<PackSurfaceRoster> {
    packs()
        .iter()
        .flat_map(|pack| pack.surface_rosters.iter().cloned())
        .collect()
}

/// The compiled-in rosters, as the model's own data.
///
/// Recomputed per call from the parsed rows (which are cached), so a
/// caller folding these in with pack-declared rosters gets a fresh,
/// owned set to hand to the sync.
#[must_use]
pub fn builtin_rosters() -> Vec<InheritedSurface> {
    crate::surface_roster_conversion::to_inherited_surfaces(&rows(), Provenance::BuiltIn)
}

/// The commands the compiled-in sources declare, in source order.
///
/// The fixed compiled-in loader prepares descriptor metadata once; this read
/// neither seeds nor replaces the active registry. Every registration shares
/// these canonical row pointers and therefore recognises an unchanged set.
#[must_use]
pub fn builtin_commands() -> Vec<&'static CommandSpec> {
    packs()
        .iter()
        .flat_map(|pack| pack.commands.iter().map(|command| command.spec))
        .collect()
}

/// Register the compiled-in commands with the registry as their families' own
/// surface. Registering the set again changes nothing.
///
/// Returns the registry's core-surface generation after the call.
#[must_use]
pub fn register_builtin_commands() -> u64 {
    tcl_registry::register_core_surface_specs(builtin_commands())
}

/// Whether the compiled-in rosters and commands have been registered.
///
/// Held across each registration as well as read, so a seed and a
/// publication never interleave: whichever runs second sees the flag and the
/// roster store the first one left.
static SEEDED: Mutex<bool> = Mutex::new(false);

fn seeded() -> MutexGuard<'static, bool> {
    SEEDED.lock().unwrap_or_else(PoisonError::into_inner)
}

/// Register the compiled-in rosters followed by `pack_rosters`, and the
/// compiled-in commands, and record that both are in.
fn seed(seeded: &mut bool, pack_rosters: Vec<InheritedSurface>) -> InheritedSurfaceRegistration {
    let mut rosters = builtin_rosters();
    rosters.extend(pack_rosters);
    let outcome = tcl_dialect::model::register_inherited_surfaces(rosters);
    let _ = register_builtin_commands();
    *seeded = true;
    outcome
}

/// Register the compiled-in rosters together with the ones a pack set
/// declares, replacing the model's whole roster store, and the compiled-in
/// commands with the registry.
pub(crate) fn register_with(pack_rosters: Vec<InheritedSurface>) -> InheritedSurfaceRegistration {
    seed(&mut seeded(), pack_rosters)
}

/// Register the compiled-in rosters and commands, if nothing has registered
/// them yet.
///
/// The compiled-in surface is part of the state a process starts from, so
/// every constructor that hands out a registry calls this rather than leaving
/// it to whichever consumer happens to publish a pack set. A call after a
/// publication changes nothing: the publication registered the same rosters
/// alongside the set's own.
pub fn ensure() {
    let mut seeded = seeded();
    if !*seeded {
        let _ = seed(&mut seeded, Vec::new());
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use tcl_dialect::model::Family;

    /// The pack parses, and what it parses to is Jim's roster of Tcl's
    /// surface — not an empty one, which is the failure mode that would
    /// otherwise be silent (an empty roster still registers, and would
    /// delete Jim's entire inherited surface).
    #[test]
    fn the_compiled_in_jim_roster_loads_and_is_not_empty() {
        let surfaces = builtin_rosters();
        let [jim] = surfaces.as_slice() else {
            panic!("one compiled-in roster: {surfaces:?}");
        };
        assert_eq!(jim.target, Family::Jim);
        assert_eq!(jim.source, Family::Tcl);
        assert_eq!(jim.provenance, Provenance::BuiltIn);
        assert_eq!(
            jim.names.len(),
            84,
            "the measured jim ∩ tclsh8.6 surface across 0.76-0.84"
        );
    }

    /// The two halves the roster exists to separate, at the pack level:
    /// what `jimsh` has, and what only the inherited edge offered.
    #[test]
    fn the_roster_carries_what_jimsh_has_and_not_what_it_lacks() {
        let jim = builtin_rosters().pop().expect("the jim roster");
        for present in ["set", "proc", "if", "dict", "lmap", "lassign", "try"] {
            assert!(jim.admits(present, None), "{present}");
        }
        for absent in [
            "coroutine",
            "trace",
            "yield",
            "yieldto",
            "chan",
            "encoding",
            "fblocked",
            "fcopy",
            "unload",
            "case",
            "unknown",
            "tclLog",
            "auto_load",
        ] {
            assert!(
                !jim.admits(absent, None),
                "{absent} is in `tclsh8.6` and not in any `jimsh` 0.76-0.84"
            );
        }
    }

    /// Both compiled-in packs evaluate without a load error and declare no
    /// hook body: a hook needs a per-pack-set host these packs are never
    /// loaded with, so one would abstain without saying so. The one notice
    /// either raises is `proc` naming the native `Proc` lowering hook, which
    /// the IR lowering and the command-binding replay both key on to treat a
    /// call as a procedure definition.
    #[test]
    fn the_compiled_in_packs_load_clean_and_declare_no_hook_bodies() {
        for ((name, _), pack) in CORE_SURFACES.iter().zip(packs()) {
            assert!(pack.load_error.is_none(), "{name}: {:?}", pack.load_error);
            let unexpected: Vec<_> = pack
                .notices
                .iter()
                .filter(|notice| {
                    !(notice.context == "command proc"
                        && notice.message.starts_with("names a lowering hook"))
                })
                .collect();
            assert!(unexpected.is_empty(), "{name}: {unexpected:?}");
            for command in &pack.commands {
                assert!(
                    command.hooks.is_empty(),
                    "{name}: `{}` declares a hook body",
                    command.spec.name
                );
            }
        }
        assert!(
            packs()[0].commands.is_empty(),
            "the roster pack declares no commands"
        );
    }

    /// The commands register once: the same set again is the same
    /// generation, so republishing a pack set does not invalidate every jim
    /// registry generation.
    #[test]
    fn registering_the_compiled_in_commands_is_idempotent() {
        let first = register_builtin_commands();
        assert_eq!(register_builtin_commands(), first);
        ensure();
        assert_eq!(register_builtin_commands(), first);
    }

    /// The two names that arrived mid-ladder keep their windows through
    /// the pack → model conversion.
    #[test]
    fn the_two_mid_ladder_names_keep_their_windows() {
        use tcl_dialect::model::Version;
        let jim = builtin_rosters().pop().expect("the jim roster");
        let at = |text: &str| Version::parse(text).expect("test version");
        assert!(!jim.admits("interp", Some(&at("0.76"))));
        assert!(jim.admits("interp", Some(&at("0.77"))));
        assert!(!jim.admits("zlib", Some(&at("0.77"))));
        assert!(jim.admits("zlib", Some(&at("0.78"))));
        // Everything else spans the whole ladder.
        assert!(jim.admits("proc", Some(&at("0.76"))));
    }
}
