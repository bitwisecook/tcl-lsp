#!/bin/sh
exec python3 /tmp/compiler-jim7-source46-v2/launch.py "$@"
