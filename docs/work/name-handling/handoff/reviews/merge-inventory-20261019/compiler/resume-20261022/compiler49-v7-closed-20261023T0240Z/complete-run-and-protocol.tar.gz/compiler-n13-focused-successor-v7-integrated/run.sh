#!/bin/bash
set -u
source /tmp/tcl-lsp-naming-env.sh
exec python3 /tmp/compiler-n13-focused-successor-v7-integrated/suite.py "$1"
