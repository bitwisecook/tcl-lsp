#!/usr/bin/env bash
set -euo pipefail
source /tmp/tcl-lsp-naming-env.sh
export NH_VALIDATION_DIR=/tmp/lsp-native-protocol-v8-source30-direct15/validation
exec python3 /tmp/lsp-native-protocol-v8-source30-direct15/suite.py
