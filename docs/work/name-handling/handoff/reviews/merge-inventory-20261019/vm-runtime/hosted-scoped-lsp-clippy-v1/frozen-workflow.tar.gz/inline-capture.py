import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import TypedDict


class Outcome(TypedDict, total=False):
    package: str
    state: str
    disk_before: dict[str, int]
    disk_after: dict[str, int]
    argv: list[str]
    started: float
    ended: float
    pid: int
    exit_code: int
    log_truncated: bool


out = Path(os.environ["OUT"])
root = Path.cwd()
mounts = (root, Path(os.environ["RUNNER_TEMP"]))
packages = ("tcl-lsp-core", "tcl-lsp-db", "tcl-lsp-server")
rows: list[Outcome] = [
    {"package": package, "state": "UNREACHED"} for package in packages
]
remaining = 20 * 1024 * 1024
incomplete = False


def save() -> None:
    (out / "outcomes.json").write_text(json.dumps(rows, indent=2) + "\n")


save()
for package, row in zip(packages, rows):
    floor = {str(path): shutil.disk_usage(path).free for path in mounts}
    row["disk_before"] = floor
    if min(floor.values()) < 2 * 1024**3:
        row["state"] = "REFUSED_DISK_FLOOR"
        incomplete = True
        save()
        continue
    argv = [
        "cargo",
        "clippy",
        "--locked",
        "--no-deps",
        "-p",
        package,
        "--all-targets",
        "--all-features",
        "--",
        "-Dwarnings",
    ]
    row.update(argv=argv, state="RUNNING", started=time.time())
    save()
    with (out / (package + ".log.txt")).open("wb") as log:
        process = subprocess.Popen(
            argv, stdout=subprocess.PIPE, stderr=subprocess.STDOUT
        )
        row["pid"] = process.pid
        save()
        if process.stdout is None:
            raise RuntimeError("owned Cargo stdout pipe unavailable")
        truncated = False
        while data := process.stdout.read(65536):
            kept = data[:remaining]
            log.write(kept)
            sys.stdout.buffer.write(kept)
            sys.stdout.buffer.flush()
            remaining -= len(kept)
            truncated |= len(kept) != len(data)
        code = process.wait()
    floor = {str(path): shutil.disk_usage(path).free for path in mounts}
    row.update(
        state="CLOSED",
        exit_code=code,
        ended=time.time(),
        log_truncated=truncated,
        disk_after=floor,
    )
    incomplete |= truncated or code < 0 or min(floor.values()) < 2 * 1024**3
    save()
(out / "capture-incomplete.txt").write_text(str(int(incomplete)) + "\n")
sys.exit(125 if incomplete else int(any(row.get("exit_code") != 0 for row in rows)))
