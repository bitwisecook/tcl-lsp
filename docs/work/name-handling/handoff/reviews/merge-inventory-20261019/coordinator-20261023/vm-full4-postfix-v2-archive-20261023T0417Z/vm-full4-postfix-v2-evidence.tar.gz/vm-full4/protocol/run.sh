#!/bin/bash
set -u
source /tmp/tcl-lsp-naming-env.sh
exec python3 /tmp/vm-runtime-c84-catch4-postfix-v2-lifecycle/run.py --execute --phase full_tommath4 --output "$1"
