#!/bin/sh
exec python3 /tmp/name-handling-seven-package-check-v4-source30/launch.py "$@"
