# Seven-package all-target typecheck protocol, source30 v4

This is an off-tree runnable suite bound to the exact FINAL30 source composition. It has not been launched against a build. Its absent-GO guard refuses before runner lock acquisition or Cargo. It makes no runtime or release-acceptance claim.

`run.sh` launches `launch.py`, which validates the root GO against the exact runner-input manifest and plan, checks every input hash, and writes durable launcher stdout plus before/after input and GO hashes. `suite.py` independently repeats the pinned-input checks before any lock or build. A post-30 GO must supply the source commit, exact plan and runner-manifest digests, source30-manifest digest, and approved integrated HEAD. No root GO is present in this preparation directory.

The seven selected packages and Cargo argv are unchanged from reviewed source22 v3: `tcl-compiler`, `tcl-lsp-core`, `tcl-lsp-db`, `tcl-lsp-server`, `tcl-vm`, `tcl-fuzz`, and `tcl-spectcl`. The sole invocation is direct pinned Cargo `check --locked --keep-going --all-targets --message-format=json` with explicit `CARGO_TARGET_DIR`; this compiles targets and runs no tests.

Before execution, the suite requires all 30 final hashes and their 3b1 baselines, the approved HEAD ancestry, equality of every other product path to 3b1, and docs-only descendants after approved integration. It snapshots source and provider manifests plus HEAD and GO before/after, and takes the shared build lock exclusively before Cargo. It invokes the reviewed `guarded-exec.run` directly with absolute pinned Cargo as argv[0] and artifact, a 3600-second deadline, 20 MiB combined durable stdout/stderr cap, and 2 GiB free-space guard on actual workspace, temporary, target, and receipt paths. It uses no polling wrapper or second process cleanup loop.

The suite rejects Cargo JSON compiler warnings/errors, build-script diagnostics, warning lines on stdout/stderr, malformed nonempty stdout, nonzero Cargo exit, any executor lifecycle/artifact/hash failure, or any changed source/provider/GO/HEAD seal. It writes process, diagnostics, source/provider snapshots, final receipt, and a durable transcript with `LOCK_RELEASED` after unlocking. A failing or incomplete guard/build fails closed.

The FINAL30 patch and owner-edition format proof are archived at `coordinator-20261023/final30-composition-v1`. This protocol prepares compilation evidence only; it provides no test execution, runtime, ABI, performance, or release-acceptance evidence.

Version note: reviewed v3/source22 is preserved unchanged. This v4/source30 protocol has a separate exact30 source manifest and changes only the bound source map/count/path and protocol version.
