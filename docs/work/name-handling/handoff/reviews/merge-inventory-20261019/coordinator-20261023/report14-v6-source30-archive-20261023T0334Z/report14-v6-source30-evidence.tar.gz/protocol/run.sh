#!/bin/bash
set -u
source /tmp/tcl-lsp-naming-env.sh
exec python3 /tmp/compiler-authenticated-report-focused14-v6-source30/suite.py "$1"
