#!/bin/sh
exec python3 /tmp/name-handling-eight-package-check-v13-source135/launch.py "$@"
