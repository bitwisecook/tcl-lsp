// tcl-lsp — a language server and toolchain for Tcl
// Copyright (C) 2026 James Deucker (bitwisecook) <https://github.com/bitwisecook>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.
//
// SPDX-License-Identifier: AGPL-3.0-or-later

//! CFG construction from structured IR.
//!
//! Flattens structured IR (`If`, `For`, `While`, `Switch`, `Catch`,
//! `Try`) into a graph of basic blocks connected by terminators.
//! The per-construct lowering methods live in [`cfg_lower`].
//!
//! Public API:
//! - [`build_cfg`] — build CFGs for a whole module (top-level + procs).
//! - [`build_cfg_function`] — build a CFG for a single script body.

use std::collections::{BTreeSet, HashMap};
use std::sync::Arc;

use rustc_hash::{FxHashMap, FxHashSet};
use tcl_lexer::{Span, TokenType};
#[cfg(test)]
use tcl_registry::EffectiveRegistrySemantics;
#[cfg(test)]
use tcl_registry::hooks::LoweringHookId;
use tcl_registry::{CommandRegistry, Traits};

use crate::cfg::{Block, BlockId, CfgModule, Function, LoopNode, Terminator};
use crate::command_binding::ModuleCommandBindings;
use crate::expr_ast::ExprNode;
use crate::ir::{CommandBindingSite, CommandTokens, Module, Script, Statement};
use crate::var_refs::{VarReferenceScanner, VarScanOptions};

use self::global_write_info::GlobalWriteInfo;
pub use self::summary_candidates::OriginalProcedureSummaryOwners;
use self::upvar_info::{FrameReach, UpvarInfo};

/// Registry traits by which a command declares that it runs code, or raises a
/// barrier, where it is invoked. A head that reaches such a command through a
/// binding other than its own spelling — an `interp alias`, a `rename`, the
/// registry's unresolved-command handler — runs code the graph never lowers,
/// so it is a call to code the module cannot see
/// ([`CfgBuilder::head_is_unseen`]). The command binding lattice resolves
/// aliases and unresolved-command handlers to terminal registry targets before
/// this set is consulted, so it does not name `unknown` directly.
const REGISTRY_BARRIER_TRAITS: Traits = CODE_RUNNING_TRAITS;

const CODE_RUNNING_TRAITS: Traits = Traits::EVALUATES_CODE
    .union(Traits::CREATES_BARRIER)
    .union(Traits::CREATES_DYNAMIC_BARRIER);

/// Choose the [`CommandTokens`] for a "frozen" `while`/`for` runtime call.
///
/// The frozen-loop barrier hands the source words (the condition expression
/// text, the body script text) to the runtime `while` / `for` builtin, which
/// re-evaluates the condition and body on each iteration. Each word must be
/// pushed *as written*: a braced `{cond}` / `{body}` word verbatim
/// (substitution suppressed), a `$body` word interpolated. The codegen's
/// [`emit_call`] decides this from `argv_kinds[i] == Str && single_token_word`,
/// so the barrier needs the real per-word kinds.
///
/// `source` is the loop's recorded [`Statement::While::raw_tokens`] — the exact
/// segmenter token metadata. When present (always, for lowered loops) it is
/// used directly; the all-verbatim fallback ([`all_str_tokens`]) only covers
/// synthetically-constructed loops that carry no token metadata, matching the
/// braced-word idiom they are built from. Without this the words are pushed as
/// interpolated literals and the condition's command substitution is evaluated
/// *once* at the call site, freezing the loop (`while {[gets $f line] >= 0}`
/// happens to work, but a bare `while {[string length $x]}` would spin forever).
fn frozen_loop_tokens(cmd: &str, args: &[String], source: Option<&CommandTokens>) -> CommandTokens {
    source.cloned().unwrap_or_else(|| all_str_tokens(cmd, args))
}

/// Return `tokens` with the word at `idx` removed from every per-word vector.
///
/// Used to derive a `dict for`/`map` barrier's tokens from the source
/// `dict for {vars} $d {body}` tokens by dropping the `for`/`map` subcommand
/// word (index 1), so the remaining words line up with the barrier's
/// `::tcl::dict::for {vars} $d {body}` argv.
fn drop_word(tokens: &CommandTokens, idx: usize) -> CommandTokens {
    let mut out = tokens.clone();
    if idx < out.argv.len() {
        out.argv.remove(idx);
    }
    if idx < out.argv_texts.len() {
        out.argv_texts.remove(idx);
    }
    if idx < out.word_exprs.len() {
        out.word_exprs.remove(idx);
    }
    if idx < out.argv_kinds.len() {
        out.argv_kinds.remove(idx);
    }
    if idx < out.single_token_word.len() {
        out.single_token_word.remove(idx);
    }
    if let Some(expand) = out.expand_word.as_mut()
        && idx < expand.len()
    {
        expand.remove(idx);
    }
    debug_assert!(out.words_align_with_argv_text());
    out
}

/// Synthesise [`CommandTokens`] marking every word as a single brace-string
/// token — the verbatim fallback for a frozen loop with no recorded source
/// tokens. See [`frozen_loop_tokens`].
fn all_str_tokens(cmd: &str, args: &[String]) -> CommandTokens {
    let word_count = 1 + args.len();
    let mut argv_texts = Vec::with_capacity(word_count);
    argv_texts.push(cmd.to_owned());
    argv_texts.extend(args.iter().cloned());
    CommandTokens::from_lossy_parts(
        vec![Span::new(0, 0); word_count],
        argv_texts,
        vec![TokenType::Str; word_count],
        vec![true; word_count],
        Vec::new(),
        None,
    )
}

/// Whether a `switch` lowers to a dispatch chain of `StrEq` branches, one
/// per arm, rather than to one opaque statement: only an exact,
/// case-sensitive one with no fall-through arm, whose subject no option scan
/// may read, does — the registry's release and whether the arms are one list
/// word or pattern and body words decide that. Its selection is then the
/// chain's decided branches; the opaque forms' is the selection record.
pub(crate) fn switch_is_flattened(
    stmt: &Statement,
    registry: &CommandRegistry,
    config: &tcl_lexer::LexerConfig,
) -> bool {
    let Statement::Switch {
        mode, nocase, arms, ..
    } = stmt
    else {
        return false;
    };
    *mode == crate::ir::SwitchMode::Exact
        && !*nocase
        && !arms.iter().any(|arm| arm.fallthrough)
        && !cfg_lower::subject_may_scan_as_option(stmt, registry, config)
}

/// Where the registry's release compiles the control command `command` of
/// `args`, the word texts after it, each braced where `tokens` says so
/// ([`tcl_registry::release_compilation::compiles_control`]); compiled
/// everywhere where the release or the command is not modelled.
pub(crate) fn release_compiles_control(
    registry: &CommandRegistry,
    command: &str,
    args: &[String],
    tokens: Option<&CommandTokens>,
) -> crate::cfg::CompiledAt {
    let Some(release) =
        tcl_registry::value_transfer::TargetSemantics::of(registry.profile()).release
    else {
        return crate::cfg::CompiledAt::ALWAYS;
    };
    let words: Vec<tcl_registry::release_compilation::CompileWord<'_>> = args
        .iter()
        .enumerate()
        .map(|(index, text)| {
            let braced = tokens.is_some_and(|tokens| {
                tokens.argv_kinds.get(index + 1) == Some(&TokenType::Str)
                    && tokens
                        .single_token_word
                        .get(index + 1)
                        .copied()
                        .unwrap_or(false)
            });
            tcl_registry::release_compilation::CompileWord {
                text,
                literal: !tcl_syntax::naming::word_is_dynamic(text, braced),
            }
        })
        .collect();
    let compiles = |in_procedure| {
        tcl_registry::release_compilation::compiles_control(release, command, &words, in_procedure)
            .unwrap_or(true)
    };
    crate::cfg::CompiledAt {
        in_procedure: compiles(true),
        outside_procedure: compiles(false),
    }
}

/// Whether the registry's release compiles the `switch` `stmt` with its
/// compile procedure ([`tcl_registry::release_compilation::compiles_control`]),
/// where its release and command are known.
pub(crate) fn release_compiles_switch(
    stmt: &Statement,
    registry: &CommandRegistry,
) -> Option<bool> {
    let Statement::Switch {
        raw_args,
        raw_arg_braced,
        command,
        ..
    } = stmt
    else {
        return None;
    };
    let release = tcl_registry::value_transfer::TargetSemantics::of(registry.profile()).release?;
    let words: Vec<tcl_registry::release_compilation::CompileWord<'_>> = raw_args
        .iter()
        .enumerate()
        .map(
            |(index, text)| tcl_registry::release_compilation::CompileWord {
                text,
                literal: !tcl_syntax::naming::word_is_dynamic(
                    text,
                    raw_arg_braced.get(index).copied().unwrap_or(false),
                ),
            },
        )
        .collect();
    tcl_registry::release_compilation::compiles_control(release, command, &words, true)
}

mod cfg_lower;
pub(crate) use cfg_lower::matches_foreach_header;
mod execution_regions;
pub mod global_write_info;
mod summary_candidates;
pub mod upvar_info;

/// Mutable block used during construction, frozen into [`Block`] at the end.
struct MutableBlock {
    name: String,
    statements: Vec<Statement>,
    terminator: Option<Terminator>,
}

#[derive(Default)]
struct ResolvedUpvarEffects {
    defs: Vec<String>,
    opaque_arguments: bool,
    has_unresolvable_target: bool,
    frame_barrier: crate::dynamic_names::DynamicNameBarrier,
}

/// The variable effects a loop or branch condition's `[…]` substitutions
/// contribute to the frame the condition is evaluated in.
#[derive(Default)]
struct ConditionEffects {
    /// Variables the condition's substitutions write.
    defs: Vec<String>,
    /// What the condition reads of [`Self::defs`] ahead of their writes, as
    /// [`EmbeddedSubstExtras::reads`] states it.
    reads: Vec<String>,
    /// An embedded callee runs an unreadable script at the global frame.
    opaque_global: bool,
    /// An embedded command is one the module cannot see.
    unseen: bool,
    /// A source-order invocation reaches a registry evaluation barrier.
    registry_barrier: bool,
}

/// The caller-frame effects a statement's `[…]` substitutions contribute.
#[derive(Default)]
struct EmbeddedSubstExtras {
    /// Variables an embedded substitution writes.
    defs: Vec<String>,
    /// What the statement reads of [`Self::defs`] ahead of their writes: the
    /// names an embedded command reads before it writes (`[incr n]`,
    /// `[append s x]`), and those the statement's words read beside a write
    /// ([`CfgBuilder::read_beside_writes`]).
    reads: Vec<String>,
    /// An embedded callee runs an unreadable script at the global frame.
    opaque_global: bool,
    /// An embedded command is one the module cannot see.
    unseen: bool,
}

/// Whether a call-shaped IR statement has one statically literal command
/// head. Computed dispatch already has its own dynamic-command handling; a
/// runtime-selected namespace only adds uncertainty for a literal relative
/// head that could be shadowed there.
fn statement_has_literal_head(stmt: &Statement) -> bool {
    match stmt {
        Statement::Call { tokens, .. } | Statement::Barrier { tokens, .. } => {
            tokens.as_ref().is_none_or(|tokens| {
                tokens.synthetic.is_none()
                    && tokens.words().first().is_none_or(|head| {
                        crate::registry_invocation::invocation_word(head)
                            .literal()
                            .is_some()
                    })
            })
        }
        _ => false,
    }
}

/// Builder that accumulates blocks and loop metadata for one function.
///
/// The independent flags describe separate lowering policies; grouping them
/// would hide that each can be selected by a different public CFG entry point.
#[allow(clippy::struct_excessive_bools)]
pub(crate) struct CfgBuilder<'a> {
    counter: u32,
    blocks: HashMap<String, MutableBlock>,
    statement_sources: HashMap<
        (BlockId, usize),
        Option<std::sync::Arc<crate::command_binding::ExecutedScriptSource>>,
    >,
    current_source: Option<std::sync::Arc<crate::command_binding::ExecutedScriptSource>>,
    source_may_calls: HashMap<(usize, u32), Vec<global_write_info::OriginalSourceCallMayWrites>>,
    implicit_math_invocations: Vec<crate::command_binding::SourceMathInvocation>,
    expression_preparations: Vec<crate::command_binding::SourceExpressionPreparation>,
    terminator_sources:
        HashMap<BlockId, Option<std::sync::Arc<crate::command_binding::ExecutedScriptSource>>>,
    /// Block name → [`BlockId`], assigned in block-creation order so the
    /// frozen [`Function`]'s interner reflects that order.
    block_ids: FxHashMap<String, BlockId>,
    loop_nodes: HashMap<String, LoopNode>,
    /// The bodies of the opaque `catch` calls, by span
    /// ([`Function::opaque_catch_bodies`]).
    opaque_catch_bodies: HashMap<Span, Script>,
    inline_loops: bool,
    /// Whether the function being built is a procedure body rather than the
    /// top-level script. Only a procedure has a local variable table, so only
    /// there can a `catch` be inlined (#2207): C compiles a top-level
    /// `catch {set a 1} m o` as a plain `invokeStk`, having nowhere to put the
    /// result variable's slot.
    is_proc_body: bool,
    /// Set when the module's own top level is a procedure body, so
    /// `build_function` treats `::top` as one. See
    /// [`Module::top_level_is_procedure_body`](crate::ir::Module::top_level_is_procedure_body).
    top_level_is_proc_body: bool,
    /// Map from issued body to caller-frame summary, used to pre-populate
    /// caller-side `defs` on calls to procs that use `upvar`.  Empty
    /// when the builder is constructed without an upvar context
    /// (e.g. for one-off CFGs that don't have a Module to scan).
    upvar_procs: HashMap<crate::ir::ProcedureId, UpvarInfo>,
    procedure_summary_owners: OriginalProcedureSummaryOwners,
    /// Map from issued body to parameter list, used by the upvar
    /// wiring to resolve param-based upvar sources (`upvar 1 $param
    /// local`) against the actual call-site argument.
    proc_params: HashMap<crate::ir::ProcedureId, Vec<String>>,
    /// Map from issued body to the outer-scope (global/namespace) variable
    /// names that proc's body writes (see [`global_write_info`]), used to
    /// widen caller-side `defs` at a call site exactly like `upvar_procs` —
    /// so SCCP treats a global/namespace name as overdefined across an
    /// opaque call that writes it, not as an ordinary untouched local.
    global_write_procs: HashMap<crate::ir::ProcedureId, GlobalWriteInfo>,
    /// Whether any procedure's [`Self::global_write_procs`] summary names
    /// an outer-scope write, so a module with none skips the per-statement
    /// scan [`Self::record_alias_observed`] makes for them.
    global_writers: bool,
    /// Closed module command state used to resolve direct and parsed embedded
    /// spellings to effective user-procedure targets, including alias chains.
    command_bindings: ModuleCommandBindings,
    /// Source-order snapshots for the root currently being lowered. Kept
    /// parallel to the historical module lattice so independent roots do not
    /// contaminate each other's executable entry state.
    source_binding_timeline: Option<crate::command_binding::SourceBindingTimeline>,
    /// Namespace in which direct command heads in this function resolve.
    invocation_namespace: crate::ir::ExecutionNamespace,
    /// Whether registry-declared `TclOO` self/next dispatch must conservatively
    /// invalidate this method's caller frame. Method reachability analysis
    /// owns this decision; user-procedure summaries stay identity-pure.
    widen_oo_dispatch: bool,
    /// Stack of `(break_target, continue_target)` block names for the
    /// enclosing loops, so `break` / `continue` in a body lower to a CFG
    /// edge.  Without this a `while 1 { … break }` exit block is
    /// unreachable and O107 false-fires on the code after the loop.
    loop_stack: Vec<(String, String)>,
    /// `try` body→handler exception edges (analysis builds only).
    exception_edges: Vec<(String, String)>,
    analysis_edges: Vec<(String, String)>,
    /// The exception edges that run from the block before a flattened body,
    /// with the block of the body's first command
    /// ([`crate::cfg::Function::region_entries`]).
    region_entries: Vec<(String, String, String)>,
    /// The flattened `catch` regions, each as the block before its body, the
    /// block that ends it and the `catch` written as a call
    /// ([`crate::cfg::Function::catch_ends`]).
    catch_ends: Vec<(String, String, Statement)>,
    /// The protected region being lowered in an analysis build — a flattened
    /// `catch` body or a `try` body — whose scripts give each statement a
    /// block of its own, so every point at which the body can fail ends a
    /// block an exception edge leaves from; the region's inner blocks are
    /// collected in [`Self::split_blocks`].
    split_region: Option<SplitRegion>,
    /// The points a throw may leave the region from: the blocks its scripts
    /// end a statement in other than their last.
    split_points: Vec<SplitPoint>,
    /// For each block a split began, the block the statement before it ended
    /// in: a region's first statements are the run from its first block.
    split_parent: FxHashMap<String, String>,
    /// The subset of [`Self::exception_edges`] that resume a `break` /
    /// `continue` after a `finally` clause: `(the clause's last block, jump
    /// target)`. An enclosing `try … finally` reroutes them through its own
    /// clause, as it does the jumps its own body makes.
    finally_jump_edges: Vec<(String, String)>,
    /// Blocks a plain `return` with a value that cannot substitute ends:
    /// they complete with `TCL_RETURN`, which a `try` handler may select.
    plain_return_blocks: FxHashSet<String>,
    /// Blocks that intercept *every* completion reaching them by an exception
    /// edge: a `catch`'s end block, and the end block of a `try` whose
    /// `finally` routes every exit through it. A `try` handler is not one —
    /// it selects only some codes.
    total_interceptors: FxHashSet<String>,
    /// The body block of the `try` whose handler edges are being recorded:
    /// the one block of its body that nothing inside the construct runs
    /// before, so the only one whose completion can be known exactly.
    try_entry: Option<String>,
    /// Blocks one of their `try`'s unconditional handlers catches whole: an
    /// enclosing construct must not route them past that handler.
    handler_caught: FxHashSet<String>,
    /// Last blocks of `finally` clauses that both fall through and resume an
    /// unwinding exit (a `return` or an error) once the clause is done. The
    /// fall-through `Goto` stands only for normal completion, so an enclosing
    /// construct treats such a block as an exit of its own.
    unwinding_tails: FxHashSet<String>,
    /// When `true`, record [`Self::exception_edges`] in `lower_try`.  Off for
    /// codegen builds so the default bytecode is unchanged.
    faithful_exceptions: bool,
    /// Every command must retain ordinary runtime dispatch semantics. This is
    /// the CFG half of `Module::plain_command_dispatch`: command-name traits
    /// must not promote a generic call to a builtin-specific return/loop edge,
    /// because the live command may have been replaced.
    plain_command_dispatch: bool,
    /// The exact registry that lowered the IR this builder consumes.  CFG
    /// variable-write recovery must query this registry rather than rebuilding
    /// a release-only approximation from [`Module::dialect`]: callers may add
    /// pack commands or override command descriptors without changing the
    /// dialect name.
    registry: &'a CommandRegistry,
    /// Release/dialect-specific command control-flow facts, derived from the
    /// same registry profile that lowered the module.  Keeping this on the
    /// builder prevents a Tcl 9 command (for example `throw`) from shaping a
    /// Tcl 8.4 CFG where that spelling can be a user procedure.
    command_classes: CfgCommandClasses,
    /// When `Some`, every block that raises an explicit `error` / `throw`
    /// is recorded here. `lower_try` installs a fresh list around its body
    /// so the on-error edge is sourced from each throw point (at its
    /// throw-time SSA versions) rather than the pre-`try` block — a
    /// body-set var is defined at a later throw.
    throw_blocks: Option<Vec<String>>,
    /// The block where the most recent `lower_script` call's straight-line
    /// control finally terminated, when that script had no normal
    /// fall-through (e.g. a trailing `return` / `error`). `None` when the
    /// script fell through. `lower_try` reads this to source an on-error
    /// edge from a body that terminated without an explicit `error`/`throw`
    /// (a bare `return`).
    last_terminal_block: Option<String>,
    /// Registry-described error contexts for inlined command bodies flattened
    /// into the function currently being built. Drained into
    /// [`crate::cfg::Function`] for source-text-independent error-frame
    /// emission.
    inline_body_error_sites: Vec<crate::cfg::InlineBodyErrorSite>,
    /// Structured command dependencies collected from every recursively
    /// flattened IR script in this function.
    command_binding_sites: Vec<CommandBindingSite>,
    /// User-procedure dependencies retained by executable IR inlining.
    procedure_binding_requirements: Vec<tcl_runtime_api::ProcedureBindingIdentity>,
    /// Block name to exact owning structured Tcl command for synthetic runtime
    /// revalidation boundaries.
    command_boundary_sites: HashMap<String, CommandBindingSite>,
    condition_binding_sites: HashMap<String, CommandBindingSite>,
    condition_owners: HashMap<Span, crate::cfg::ConditionOwner>,
    /// Entry block to continuation block for an explicitly delimited inline
    /// structured-command region.
    command_boundary_continuations: HashMap<String, String>,
    /// Head dispatch block to join block for a branch-lowered `if`/`switch`.
    branch_command_joins: HashMap<String, String>,
    /// The script bodies structured commands evaluate.
    body_scripts: Vec<crate::cfg::BodyScript>,
    /// Caller-frame injection the function currently being built is subject
    /// to: the union of every called procedure's
    /// [`UpvarInfo::caller_frame_barrier`].  Drained into
    /// [`crate::cfg::Function::caller_frame_barrier`], which
    /// [`crate::dynamic_names::dynamic_name_barrier`] folds into the
    /// function's blindness lattice.
    caller_frame_barrier: crate::dynamic_names::DynamicNameBarrier,
    /// Caller-frame names a callee may touch through an `upvar` alias or
    /// `uplevel` write — see [`CfgBuilder::record_alias_observed`].  Drained
    /// into [`crate::cfg::Function::alias_observed_vars`].
    alias_observed_vars: std::collections::BTreeSet<String>,
    /// Current `lower_script` recursion depth, bounded by [`MAX_LOWER_DEPTH`]
    /// so deeply-nested bodies cannot overflow the stack.
    depth: u32,
    /// The document's lexer configuration.  The embedded-substitution scans
    /// below (`command_heads_in_text`, `upvar_defs_from_text`,
    /// `global_write_defs_from_text`, `builtin_write_defs_from_text`) re-lex
    /// an IR statement's own argument text to find its `[…]` tokens and split
    /// each one into words, so they must read it under the grammar the
    /// document was lexed with — under `f5-irules` `}{` separates two words,
    /// under Jim `$(…)` is one, under 8.4 `{*}` is literal — or the head they
    /// credit is not the head that runs. Defaults to
    /// `LexerConfig::default()`; the pipeline threads the document's config
    /// through [`build_cfg_with_config`] and friends.
    config: tcl_lexer::LexerConfig,
}

/// Maximum nesting depth for the recursive `lower_script` descent.
/// `lower_script` ↔ `lower_if`/`lower_for`/`lower_while`/`lower_foreach`/
/// `lower_switch`/`lower_try` are mutually recursive with one Rust frame
/// per nesting level; deeply-nested (generated / minified) bodies would
/// otherwise overflow the stack — an uncatchable SIGABRT that takes down
/// the LSP worker or the `tcl` CLI. At the cap we stop descending and
/// treat the over-deep script as a non-fall-through tail, yielding a
/// truncated-but-valid CFG instead of a crash. No real source nests
/// anywhere near this.
///
/// Shares [`crate::depth_guard::MAX_SOURCE_NEST_DEPTH`] with the lowering
/// and analyser body walks — one budget, derived from a measured per-level
/// stack cost, rather than three copies of a hand-picked 256.
///
/// Through the normal pipeline this cap is **unreachable**: `lowering`'s
/// copy of the same number already bounds the IR handed here, so a
/// `Module` built from source cannot nest deeper than the cap in the first
/// place. It matters for a host that builds a `Module` some other way, and
/// its 8,288 bytes a level is what the budget must still afford for that
/// caller — the same defence-in-depth role the optimiser and codegen walks
/// play over the same IR.
const MAX_LOWER_DEPTH: tcl_core_types::RecursionLimit = crate::depth_guard::MAX_SOURCE_NEST_DEPTH;

impl<'a> CfgBuilder<'a> {
    fn with_procedure_summary_owners(mut self, owners: OriginalProcedureSummaryOwners) -> Self {
        self.procedure_summary_owners = owners;
        self
    }

    fn original_tokens_for_statement<'s>(
        &'s self,
        statement: &'s Statement,
    ) -> Option<&'s CommandTokens> {
        crate::ir::CommandBindingSites::unanimous_statement_source_tokens(
            self.command_binding_sites.iter(),
            statement,
        )
    }

    fn original_tokens_at(&self, span: Span) -> Option<&CommandTokens> {
        let mut candidates = self
            .command_binding_sites
            .iter()
            .filter(|site| site.span == span)
            .filter_map(|site| site.source_tokens.as_deref());
        let first = candidates.next()?;
        candidates
            .all(|candidate| candidate == first)
            .then_some(first)
    }

    fn with_source_binding_timeline(
        mut self,
        timeline: crate::command_binding::SourceBindingTimeline,
    ) -> Self {
        self.source_binding_timeline = Some(timeline);
        self
    }

    fn new(inline_loops: bool, registry: &'a CommandRegistry) -> Self {
        Self::new_with_upvars(
            inline_loops,
            HashMap::new(),
            HashMap::new(),
            HashMap::new(),
            ModuleCommandBindings::default(),
            registry,
        )
    }

    fn new_with_upvars(
        inline_loops: bool,
        upvar_procs: HashMap<crate::ir::ProcedureId, UpvarInfo>,
        proc_params: HashMap<crate::ir::ProcedureId, Vec<String>>,
        global_write_procs: HashMap<crate::ir::ProcedureId, GlobalWriteInfo>,
        command_bindings: ModuleCommandBindings,
        registry: &'a CommandRegistry,
    ) -> Self {
        let command_classes = CfgCommandClasses::from_registry(registry);
        Self::new_with_upvars_and_classes(
            inline_loops,
            upvar_procs,
            proc_params,
            global_write_procs,
            command_bindings,
            registry,
            command_classes,
        )
    }

    fn new_with_upvars_and_classes(
        inline_loops: bool,
        upvar_procs: HashMap<crate::ir::ProcedureId, UpvarInfo>,
        proc_params: HashMap<crate::ir::ProcedureId, Vec<String>>,
        global_write_procs: HashMap<crate::ir::ProcedureId, GlobalWriteInfo>,
        command_bindings: ModuleCommandBindings,
        registry: &'a CommandRegistry,
        command_classes: CfgCommandClasses,
    ) -> Self {
        let global_writers = global_write_procs
            .values()
            .any(|info| !info.names.is_empty());
        Self {
            counter: 0,
            blocks: HashMap::new(),
            statement_sources: HashMap::new(),
            current_source: None,
            source_may_calls: HashMap::new(),
            implicit_math_invocations: Vec::new(),
            expression_preparations: Vec::new(),
            terminator_sources: HashMap::new(),
            block_ids: FxHashMap::default(),
            loop_nodes: HashMap::new(),
            opaque_catch_bodies: HashMap::new(),
            inline_loops,
            is_proc_body: false,
            top_level_is_proc_body: false,
            upvar_procs,
            procedure_summary_owners: OriginalProcedureSummaryOwners::default(),
            proc_params,
            global_write_procs,
            global_writers,
            command_bindings,
            source_binding_timeline: None,
            invocation_namespace: crate::ir::ExecutionNamespace::exact("::"),
            widen_oo_dispatch: false,
            loop_stack: Vec::new(),
            exception_edges: Vec::new(),
            analysis_edges: Vec::new(),
            region_entries: Vec::new(),
            catch_ends: Vec::new(),
            split_region: None,
            split_points: Vec::new(),
            split_parent: FxHashMap::default(),
            finally_jump_edges: Vec::new(),
            plain_return_blocks: FxHashSet::default(),
            total_interceptors: FxHashSet::default(),
            try_entry: None,
            handler_caught: FxHashSet::default(),
            unwinding_tails: FxHashSet::default(),
            faithful_exceptions: false,
            plain_command_dispatch: false,
            registry,
            command_classes,
            throw_blocks: None,
            last_terminal_block: None,
            inline_body_error_sites: Vec::new(),
            command_binding_sites: Vec::new(),
            procedure_binding_requirements: Vec::new(),
            command_boundary_sites: HashMap::new(),
            condition_binding_sites: HashMap::new(),
            condition_owners: HashMap::new(),
            command_boundary_continuations: HashMap::new(),
            branch_command_joins: HashMap::new(),
            body_scripts: Vec::new(),
            caller_frame_barrier: crate::dynamic_names::DynamicNameBarrier::default(),
            alias_observed_vars: std::collections::BTreeSet::new(),
            depth: 0,
            // dialect-drift-ok: the builder's own default; the pipeline
            // replaces it via `with_lexer_config` from the unit's config.
            config: tcl_lexer::LexerConfig::default(),
        }
    }

    /// Enable `try` exception-edge recording (analysis builds).
    fn with_faithful_exceptions(mut self) -> Self {
        self.faithful_exceptions = true;
        self
    }

    /// Read every embedded `[…]` substitution under the document's own
    /// grammar (see [`Self::config`]).
    fn with_lexer_config(mut self, config: tcl_lexer::LexerConfig) -> Self {
        if matches!(&self.command_classes.metadata, CfgMetadataContext::SuppliedSource(input) if input.lexer_config().normalized() != config.normalized())
        {
            self.command_classes.metadata = CfgMetadataContext::Unavailable;
        }

        self.config = config;
        self
    }

    /// Bind every command-sensitive CFG decision to one resolved command
    /// surface and dispatch mode. Single-function consumers cannot recover
    /// either fact from a detached [`Script`], so their public entry points
    /// require them and funnel through this seam.
    fn with_command_surface(mut self, plain_command_dispatch: bool) -> Self {
        self.plain_command_dispatch = plain_command_dispatch;
        self
    }

    fn with_invocation_namespace(mut self, namespace: crate::ir::ExecutionNamespace) -> Self {
        self.invocation_namespace = namespace;
        self
    }

    fn with_oo_dispatch_widening(mut self) -> Self {
        self.widen_oo_dispatch = true;
        self
    }

    /// Registry-owned variable writes projected in the function's actual
    /// command-resolution context. A receiver-selected relative head may be
    /// shadowed by an arbitrary object-local command and therefore widens the
    /// whole variable frame.
    fn variable_write_projection(&self, stmt: &Statement) -> tcl_registry::VariableWriteProjection {
        let (Statement::Call { command: head, .. } | Statement::Barrier { command: head, .. }) =
            stmt
        else {
            return tcl_registry::VariableWriteProjection::default();
        };
        let Some(namespace) = self.invocation_namespace.for_head_context(head) else {
            if !statement_has_literal_head(stmt) {
                return tcl_registry::VariableWriteProjection::default();
            }
            return tcl_registry::VariableWriteProjection {
                literal_names: Vec::new(),
                read_before_write_names: Vec::new(),
                opaque_variable_frame: true,
            };
        };
        self.command_bindings
            .variable_write_projection(stmt, self.registry, namespace.as_ref())
    }

    /// Join caller-frame summaries through exact original call receipts and
    /// their frozen effective arguments.
    fn direct_upvar_effects(&self, stmt: &Statement) -> ResolvedUpvarEffects {
        if !matches!(stmt, Statement::Call { .. } | Statement::Barrier { .. }) {
            return ResolvedUpvarEffects::default();
        }
        self.source_upvar_effects(self.original_tokens_for_statement(stmt))
    }

    fn source_upvar_effects(&self, tokens: Option<&CommandTokens>) -> ResolvedUpvarEffects {
        let mut combined = ResolvedUpvarEffects::default();
        let calls =
            tokens.and_then(|tokens| self.procedure_summary_owners.calls(tokens, self.registry));
        let Some(calls) = calls else {
            combined.has_unresolvable_target = true;
            combined.opaque_arguments = true;
            combined.frame_barrier = crate::dynamic_names::DynamicNameBarrier::OPAQUE_SCRIPT;
            return combined;
        };
        if self.widen_oo_dispatch
            && let Some(tokens) = tokens
            && let Some(binding) = tokens.source_binding.as_ref()
            && let Some(head) = summary_candidates::original_head(tokens)
            && binding
                .lookup_command_word(&head)
                .targets
                .iter()
                .any(|target| {
                    target.registry_backed
                        && matches!(
                            self.registry.method_dispatch_keyword(&target.command),
                            Some(
                                tcl_registry::MethodDispatchKind::SelfDispatch
                                    | tcl_registry::MethodDispatchKind::NextChain
                            )
                        )
                })
        {
            combined.has_unresolvable_target = true;
            combined.frame_barrier =
                combined
                    .frame_barrier
                    .union(crate::dynamic_names::DynamicNameBarrier {
                        writes: true,
                        destroys: false,
                        reads: false,
                    });
        }
        for (id, words) in calls {
            let facts = words
                .words
                .iter()
                .skip(1)
                .map(|word| {
                    crate::registry_invocation::effective_invocation_word(
                        word,
                        self.config.escapes,
                        tcl_syntax::word_rules::WordValueRules::from_config(&self.config),
                    )
                })
                .collect::<Vec<_>>();
            let arguments = facts
                .iter()
                .map(crate::registry_invocation::EffectiveInvocationWord::as_registry_word)
                .collect::<Vec<_>>();
            self.extend_upvar_effects(
                &mut combined,
                id,
                tcl_registry::InvocationArguments::structured(&arguments),
            );
        }
        combined
    }

    /// Whether any recovered command substitution reaches a registry operation
    /// with a barrier/evaluation trait. Substitutions execute before their
    /// host statement, so callers place the synthetic barrier before that
    /// host in the CFG.
    fn embedded_registry_barrier(&self, stmt: &Statement) -> bool {
        let bindings = self
            .source_binding_timeline
            .as_ref()
            .and_then(|timeline| timeline.before_substitutions(stmt.span()))
            .cloned()
            .unwrap_or_else(|| self.command_bindings.clone());
        let Some(metadata) = self.command_classes.metadata_context() else {
            return true;
        };
        let state = std::cell::RefCell::new(bindings);
        let barrier = std::cell::Cell::new(false);
        let resolve = |head: &str| {
            state
                .borrow()
                .resolved_embedded_head(head, &self.invocation_namespace)
        };
        let observe = |words: &[crate::ir_helpers::CommandWord], conditional: bool| {
            let found = state
                .borrow_mut()
                .source_order_registry_barrier_for_command_with_metadata_context(
                    words,
                    conditional,
                    self.registry,
                    &self.invocation_namespace,
                    REGISTRY_BARRIER_TRAITS,
                    metadata,
                );
            barrier.set(barrier.get() || found);
        };
        let embedded =
            crate::ir_helpers::evaluated_command_substitutions_with_replay_and_metadata_context(
                stmt,
                self.registry,
                Some(&resolve),
                Some(&observe),
                metadata,
                self.config,
            );
        embedded.opaque || barrier.get()
    }

    fn registry_barrier_statement(stmt: &Statement, reason: &str) -> Statement {
        Self::registry_barrier_statement_at(stmt.span(), reason)
    }

    fn registry_barrier_statement_at(span: Span, reason: &str) -> Statement {
        Statement::Barrier {
            span,
            reason: reason.to_owned(),
            command: "<registry-barrier>".to_owned(),
            canonical_command: None,
            args: Vec::new(),
            tokens: Some(crate::ir::CommandTokens::marker(
                crate::ir::SyntheticMarker::RegistryBarrier,
            )),
        }
    }

    /// The command bindings in force where the call at `span` dispatches: the
    /// source-order state the timeline recorded before it, or the module's
    /// closed state where the timeline holds none.
    fn bindings_before_call(&self, span: Span) -> &ModuleCommandBindings {
        self.source_binding_timeline
            .as_ref()
            .and_then(|timeline| timeline.before_direct_call(span))
            .unwrap_or(&self.command_bindings)
    }

    /// Whether a command a `[…]` substitution of `stmt` runs is one the module
    /// cannot see ([`Self::command_reaches_unseen`]). The substitutions run in
    /// Tcl's evaluation order before the statement does, and each is asked
    /// under the command bindings the ones before it leave: a `[rename …]`
    /// earlier in the statement decides what a later head reaches.
    fn embedded_reaches_unseen(&self, stmt: &Statement) -> bool {
        if !self.command_bindings.holds_a_command_table() {
            return false;
        }
        let bindings = self
            .source_binding_timeline
            .as_ref()
            .and_then(|timeline| timeline.before_substitutions(stmt.span()))
            .cloned()
            .unwrap_or_else(|| self.command_bindings.clone());
        let state = std::cell::RefCell::new(bindings);
        let unseen = std::cell::Cell::new(false);
        let resolve = |head: &str| {
            state
                .borrow()
                .resolved_embedded_head(head, &self.invocation_namespace)
        };
        let observe = |words: &[crate::ir_helpers::CommandWord], conditional: bool| {
            self.observe_in_source_order(&state, &unseen, words, conditional);
        };
        let _ = crate::ir_helpers::evaluated_command_substitutions_with_replay(
            stmt,
            self.registry,
            Some(&resolve),
            Some(&observe),
        );
        unseen.get()
    }

    /// One step of a source-order replay over the commands a statement's
    /// substitutions run: whether `words` reaches code the module cannot see
    /// under the bindings in `state`, then the binding transition the command
    /// makes, which the next command is resolved after.
    fn observe_in_source_order(
        &self,
        state: &std::cell::RefCell<ModuleCommandBindings>,
        unseen: &std::cell::Cell<bool>,
        words: &[crate::ir_helpers::CommandWord],
        conditional: bool,
    ) {
        if !unseen.get()
            && self.command_bindings.holds_a_command_table()
            && self.command_reaches_unseen(&state.borrow(), words, 0)
        {
            unseen.set(true);
        }
        state.borrow_mut().advance_source_order_for_command(
            words,
            conditional,
            self.registry,
            &self.invocation_namespace,
        );
    }

    /// Fold one binding-resolved terminal user procedure into a caller-frame
    /// effect set. Both direct statements and parsed embedded commands enter
    /// here, so their parameter projection and barrier semantics cannot drift.
    fn extend_upvar_effects(
        &self,
        combined: &mut ResolvedUpvarEffects,
        id: crate::ir::ProcedureId,
        arguments: tcl_registry::InvocationArguments<'_>,
    ) {
        let (Some(info), Some(params)) = (self.upvar_procs.get(&id), self.proc_params.get(&id))
        else {
            combined.has_unresolvable_target = true;
            combined.opaque_arguments = true;
            combined.frame_barrier = combined
                .frame_barrier
                .union(crate::dynamic_names::DynamicNameBarrier::OPAQUE_SCRIPT);
            return;
        };
        let effects = info.caller_side_effects(arguments, params);
        combined.opaque_arguments |= effects.opaque;
        combined.has_unresolvable_target |= info.has_unresolvable_caller_target;
        combined.frame_barrier = combined.frame_barrier.union(info.caller_frame_barrier());
        for name in effects.defs {
            if !combined.defs.contains(&name) {
                combined.defs.push(name);
            }
        }
    }

    /// Augment a statement's effective `defs` with caller-side
    /// variable names that any callee proc will modify via `upvar`.
    /// Returns a list of statements — the original (possibly with
    /// merged `defs` for the direct-call form) plus, ahead of it, the
    /// statement's word effects ([`Statement::word_effects`]) when the
    /// embedded-substitution form contributes defs that can't be merged
    /// into the host statement (e.g. an `AssignValue` whose `value` text
    /// contains `[upvar_proc arg]`).
    ///
    /// Direct-call form: resolves the statement through the module command
    /// state, then maps the effective user-procedure target and its
    /// alias-prepended structured arguments through `UpvarInfo` into the
    /// call's own `defs`.
    ///
    /// Embedded-substitution form: scans the call's args / the
    /// `AssignValue`'s value text for `[command_substitution]`
    /// tokens whose head is a known upvar proc; merges those defs
    /// into the host Call when possible, or puts the statement's word
    /// effects, paired with it, ahead of a non-Call host.
    ///
    /// The same two forms also widen `defs` with `global_write_procs`
    /// (a callee that writes an outer-scope name via `global`/`variable`/
    /// `upvar #0`, see [`global_write_info`]) — a global name doesn't
    /// depend on call-site arguments, so no params-based mapping is
    /// needed, just the literal name list.
    fn apply_upvar_invalidation(&mut self, stmt: Statement) -> Vec<Statement> {
        self.record_caller_frame_barrier(&stmt);
        self.record_alias_observed(&stmt);
        let original = matches!(
            &stmt,
            Statement::Call {
                foreach_groups: None,
                ..
            }
        )
        .then(|| self.original_tokens_for_statement(&stmt).cloned())
        .flatten();
        let logical_call = matches!(&stmt, Statement::Call { tokens, foreach_groups: None, .. } if tokens.as_ref().is_none_or(|tokens| tokens.synthetic.is_none()))
            && self
                .command_classes
                .metadata
                .source_analysis_input()
                .is_some_and(
                    crate::analyser::ResolvedAnalysisInput::has_logical_source_name_context,
                );
        let span = stmt.span();
        let mut produced = self.upvar_invalidated(stmt);
        let mut unknown_locations = logical_call;
        if let Some(original) = original {
            for statement in &produced {
                if let Some(receipt) = self.source_call_may_writes(&original, statement) {
                    unknown_locations = !receipt.writes().is_empty();
                    let same_site = self.source_may_calls.entry(receipt.site_key()).or_default();
                    if !same_site.iter().any(|held| held.same_owner(&receipt)) {
                        same_site.push(receipt);
                    }
                }
            }
        }
        if unknown_locations
            && !produced
                .last()
                .is_some_and(crate::ssa::is_unseen_call_marker)
        {
            produced.push(Statement::unseen_call_marker(span));
        }
        produced
    }

    fn source_call_may_writes(
        &self,
        original: &CommandTokens,
        emitted: &Statement,
    ) -> Option<global_write_info::OriginalSourceCallMayWrites> {
        let module = self.procedure_summary_owners.module(self.registry)?;
        let calls = self
            .procedure_summary_owners
            .may_calls(original, self.registry)?;
        if calls.unknown_alternatives {
            return None;
        }
        let mut writes = Vec::new();
        for body in &calls.bodies {
            for place in self
                .global_write_procs
                .get(body)?
                .original_source_writes()?
            {
                if !writes.iter().any(|held: &crate::signature_scan::variable_symbol::SignatureSourceVariableOccurrence| held.symbol() == place.symbol()) {
                    writes.push(place.clone());
                }
            }
        }
        global_write_info::OriginalSourceCallMayWrites::for_emission(
            module,
            self.registry,
            original,
            emitted,
            calls.bodies,
            writes,
        )
    }

    /// Record every caller-frame name a callee invoked by `stmt` may touch
    /// through an `upvar` alias or an `uplevel` write, so the dead-store /
    /// unused-assignment passes never delete a store such a callee can
    /// observe (`set callervar 5; get` where `get` runs `upvar 1 callervar
    /// m; return $m`).  The names land on
    /// [`crate::cfg::Function::alias_observed_vars`]; recording them as
    /// *reads* on the call statement instead would fabricate
    /// read-before-set uses (a false W210) for the pure out-param shape.
    fn record_alias_observed(&mut self, stmt: &Statement) {
        if self.upvar_procs.is_empty() && !self.global_writers {
            return;
        }
        let embedded = crate::ir_helpers::evaluated_command_substitutions(stmt, self.registry);
        if self.global_writers {
            // A callee that writes an outer-scope name may read it first —
            // `incr ::hits`, `global g; incr g 5` — so a store the caller
            // made to it is observed, not dead: O109 deleted `set hits 0`
            // ahead of a `bump` whose body is `set y [incr ::hits]`
            // (#2214). The summary records writes, not reads, so every
            // name it holds counts as observed.
            let observed: Vec<String> = self
                .direct_global_writes(stmt)
                .into_iter()
                .chain(
                    self.global_write_defs_from_commands(
                        &embedded.commands,
                        self.original_tokens_for_statement(stmt),
                    )
                    .0,
                )
                .collect();
            self.alias_observed_vars.extend(observed);
        }
        if self.upvar_procs.is_empty() {
            return;
        }
        self.alias_observed_vars
            .extend(self.direct_upvar_effects(stmt).defs);
        self.alias_observed_vars.extend(
            self.upvar_effects_from_commands(
                &embedded.commands,
                self.original_tokens_for_statement(stmt),
            )
            .defs,
        );
    }

    /// Whether the call statement `stmt` itself runs code the module cannot
    /// see: its head is computed, or is a literal the module cannot name
    /// ([`Self::head_is_unseen`]) under the command bindings in force where it
    /// dispatches, or it sources a file ([`Traits::SOURCES_FILE`]).
    ///
    /// The code such a call reaches can write, unset or read any name of the
    /// frame it runs from with nothing in this function's text to show it: a
    /// plain name at the top level is the global `::name`, and a procedure's
    /// local is in the reach of a callee that runs `upvar 1` or `uplevel 1`.
    /// An autoloaded or unknown-handled callee can do either on every release,
    /// so the CFG marks the call ([`Statement::unseen_call_marker`]) in a procedure
    /// body as at the top level. A head the module can name brings its frame
    /// effect from the registry or from the procedure summary instead. A
    /// builder that holds no module's command table names no head, so it marks
    /// nothing.
    fn call_is_unseen(&self, stmt: &Statement) -> bool {
        let Statement::Call {
            command,
            canonical_command,
            args,
            tokens,
            ..
        } = stmt
        else {
            return false;
        };
        if !self.command_bindings.holds_a_command_table()
            || tokens
                .as_ref()
                .is_some_and(|tokens| tokens.synthetic.is_some())
        {
            return false;
        }
        if !statement_has_literal_head(stmt) {
            return true;
        }
        let spellings: Vec<&str> = args.iter().map(String::as_str).collect();
        let lookup = canonical_command.as_deref().unwrap_or(command.as_str());
        self.sources_a_file(lookup, &spellings)
            || self.head_is_unseen(self.bindings_before_call(stmt.span()), command, &spellings)
    }

    /// Whether the command `head args…` sources a file, which runs in the
    /// frame of the call ([`Traits::SOURCES_FILE`]).
    fn sources_a_file(&self, head: &str, args: &[&str]) -> bool {
        self.registry
            .invocation_traits(head, args, self.registry.own_surface_query())
            .contains(Traits::SOURCES_FILE)
    }

    /// Whether the command `words`, or code it runs, runs code the module cannot
    /// see under `bindings`: a computed head, a literal one that sources a file
    /// or that the module cannot name ([`Self::head_is_unseen`]). Every word the
    /// command runs as code is read, whichever frame it runs in: a body of this
    /// frame (the script of a `catch`), a body that runs in another (`uplevel`,
    /// `namespace eval`), a lambda's body (`apply`), the commands in the text a
    /// `subst` substitutes and those in an expression word; a computed one is
    /// code the module cannot see. Whether such code runs is all this answers:
    /// the names the commands of a substitution write are not stated.
    fn command_reaches_unseen(
        &self,
        bindings: &ModuleCommandBindings,
        words: &[crate::ir_helpers::CommandWord],
        depth: u32,
    ) -> bool {
        let Some(head) = words
            .first()
            .and_then(crate::ir_helpers::CommandWord::literal)
        else {
            return true;
        };
        let spellings: Vec<&str> = words
            .iter()
            .skip(1)
            .map(|word| word.literal().unwrap_or_default())
            .collect();
        if self.sources_a_file(head, &spellings) || self.head_is_unseen(bindings, head, &spellings)
        {
            return true;
        }
        // Past the cap the text is not read, so it is taken to run anything.
        if crate::depth_guard::MAX_BRACKET_TEXT_DEPTH.exceeded(depth) {
            return true;
        }
        let reaches = |text: &str| {
            crate::ir_helpers::tokenise_command_words(text, self.config)
                .iter()
                .any(|inner| self.command_reaches_unseen(bindings, inner, depth + 1))
        };
        // A script's own substitutions are not among the commands recovered
        // from the statement, whose words are the only ones scanned for them.
        if depth > 0
            && words.iter().filter(|word| word.substituted).any(|word| {
                crate::var_refs::command_subst_texts_with_config(&word.raw, self.config)
                    .iter()
                    .any(|inner| reaches(inner))
            })
        {
            return true;
        }
        let runs = |index: usize, text_runs: &dyn Fn(&str) -> bool| match words.get(index + 1) {
            Some(word) if !word.substituted => text_runs(&word.text),
            Some(_) => true,
            None => false,
        };
        let role_indices = |role| self.registry.arg_indices_for_role(head, &spellings, role);
        if role_indices(tcl_registry::ArgRole::Body)
            .into_iter()
            .any(|index| runs(index, &reaches))
        {
            return true;
        }
        // A lambda literal is a list of its parameters, its body and a namespace.
        let lambda_runs =
            |text: &str| match tcl_syntax::list::split_list_in(text, self.config.escapes) {
                Ok(elements) => elements.get(1).is_some_and(|body| reaches(body)),
                Err(_) => true,
            };
        if role_indices(tcl_registry::ArgRole::LambdaLiteral)
            .into_iter()
            .any(|index| runs(index, &lambda_runs))
        {
            return true;
        }
        let substitutes = self
            .registry
            .substitutions_performed(head, &spellings)
            .is_some_and(|kinds| kinds.commands);
        let concatenates = self
            .registry
            .get(head)
            .is_some_and(|spec| spec.traits.contains(Traits::EXPR_CONCATENATES_ARGS));
        let expressions = role_indices(tcl_registry::ArgRole::Expr);
        (0..spellings.len())
            .filter(|index| substitutes || concatenates || expressions.contains(index))
            .any(|index| match words.get(index + 1) {
                Some(word) if !word.substituted => {
                    crate::var_refs::command_subst_texts_with_config(&word.text, self.config)
                        .iter()
                        .any(|inner| reaches(inner))
                }
                _ => false,
            })
    }

    /// What the commands the arms of the opaque `switch` `stmt` run do to this
    /// frame, beyond the writes the SSA reads off the statement itself
    /// ([`crate::ssa::switch_may_defs`]), as the statements that follow it
    /// ([`Self::opaque_script_effects`]).
    fn opaque_arm_effects(&mut self, stmt: &Statement) -> Vec<Statement> {
        let Statement::Switch {
            arms, default_body, ..
        } = stmt
        else {
            return Vec::new();
        };
        let bodies: Vec<&Script> = arms
            .iter()
            .filter_map(|arm| arm.body.as_ref())
            .chain(default_body.as_ref())
            .collect();
        self.opaque_script_effects(
            stmt.span(),
            &bodies,
            BTreeSet::new(),
            true,
            "a command an arm of the switch runs may write any name",
        )
    }

    /// What the commands of the scripts a statement keeps inside itself do to
    /// this frame, as the statements to put beside it.
    ///
    /// The scripts stay inside the statement, so the scans of the statements the
    /// graph lowers never reach a command in one. Each is asked what the graph
    /// would have put beside it had it lowered the script
    /// ([`Self::apply_upvar_invalidation`], whose function-level facts this
    /// records too): the names a callee writes into this frame, which join
    /// `written` as the statement's may-definitions
    /// ([`crate::ir::SyntheticMarker::ArmWrites`]); a barrier for a command that
    /// may write any name (`namespace eval`, `dict with`, `eval $script`, a
    /// callee that aliases a computed name), unless the command leaves the
    /// procedure and `leaves_the_procedure` says that leaving is no resumption
    /// after the statement (an error inside a `catch` or a `try` resumes
    /// there); and a marker where code the module cannot see runs.
    fn opaque_script_effects(
        &mut self,
        span: Span,
        scripts: &[&Script],
        mut written: BTreeSet<String>,
        leaves_the_procedure: bool,
        barrier_reason: &str,
    ) -> Vec<Statement> {
        let mut barrier = scripts.iter().fold(false, |unknown, script| {
            crate::ssa::nested_writes(script, self.registry, &mut written) || unknown
        });
        let mut unseen = false;
        for script in scripts {
            crate::ir::for_each_statement(script, &mut |inner| {
                let own: &[String] = match inner {
                    Statement::Call { defs, .. } => defs,
                    _ => &[],
                };
                // A command that leaves the procedure (`exit`, `error`) writes
                // nothing the code after the statement can read.
                let exits = leaves_the_procedure
                    && flow_facts_stmt_with_classes(inner, &self.command_classes).1
                        == Completion::ProcExit;
                for produced in self.apply_upvar_invalidation(inner.clone()) {
                    match &produced {
                        _ if crate::ssa::is_unseen_call_marker(&produced) => unseen = true,
                        Statement::Barrier { .. } | Statement::UpFrame { .. } => {
                            barrier |= !exits;
                        }
                        Statement::Call { defs, .. } => {
                            written.extend(defs.iter().filter(|name| !own.contains(name)).cloned());
                        }
                        _ => {}
                    }
                }
            });
        }
        let mut effects = Vec::new();
        if !written.is_empty() {
            effects.push(Self::arm_writes_marker(span, written));
        }
        if barrier {
            effects.push(Self::caller_frame_opaque(span, barrier_reason.to_owned()));
        }
        if unseen {
            effects.push(Statement::unseen_call_marker(span));
        }
        effects
    }

    /// The statement that states the names a statement keeps its scripts in
    /// may write ([`crate::ir::SyntheticMarker::ArmWrites`]).
    fn arm_writes_marker(span: Span, names: BTreeSet<String>) -> Statement {
        Statement::Call {
            span,
            command: "<arm-writes>".to_owned(),
            canonical_command: None,
            args: Vec::new(),
            defs: names.into_iter().collect(),
            reads: Vec::new(),
            reads_own_defs: false,
            safe_on_uninit: false,
            tokens: Some(crate::ir::CommandTokens::marker(
                crate::ir::SyntheticMarker::ArmWrites,
            )),
            foreach_groups: None,
        }
    }

    /// A widening *effect*, not a command to run: every tracked value is
    /// widened where it stands ([`crate::ir::SyntheticMarker::CallerFrameOpaque`]).
    fn caller_frame_opaque(span: Span, reason: String) -> Statement {
        Statement::Barrier {
            span,
            reason,
            command: "<caller-frame-opaque>".to_owned(),
            canonical_command: None,
            args: Vec::new(),
            tokens: Some(crate::ir::CommandTokens::marker(
                crate::ir::SyntheticMarker::CallerFrameOpaque,
            )),
        }
    }

    /// Whether the literal head `head`, called with `args` in this function's
    /// namespace under `bindings`, may reach code the module cannot name: a
    /// spelling neither the registry ships for the dialect nor the module binds,
    /// which Tcl dispatches to the unresolved-command handler
    /// ([`ModuleCommandBindings::may_dispatch_unresolved`]); a binding the
    /// source-order timeline cannot name — one a `rename` or an alias of a
    /// computed name may have replaced, or any spelling once a `rename` or an
    /// alias moved a name the timeline cannot name; and a registry command the
    /// head reaches through another binding — an alias, a rename, the
    /// unresolved-command handler — that declares it runs code
    /// ([`CODE_RUNNING_TRAITS`]), which the graph never lowers. A head whose
    /// namespace the builder does not know is taken to.
    fn head_is_unseen(&self, bindings: &ModuleCommandBindings, head: &str, args: &[&str]) -> bool {
        // The same identity-aware selector the frame projection reads
        // ([`Self::variable_write_projection`]): a source-context frame (the
        // fresh-interpreter entry's authored `::`) names its heads as an
        // exact one does; only a receiver-selected relative head is unnamed.
        let Some(namespace) = self.invocation_namespace.for_head_context(head) else {
            return true;
        };
        let namespace = namespace.as_ref();
        if bindings.has_unnameable_rebinding_subject()
            || bindings.may_dispatch_unresolved(head, namespace)
            || bindings.target_resolution_may_be_unknown(head, namespace)
        {
            return true;
        }
        let selected = self.registry.get(head);
        bindings.targets(head, namespace).iter().any(|target| {
            if !target.registry_backed
                || (target.prepended.is_empty()
                    && selected.is_some_and(|spec| {
                        tcl_registry::command_descriptor_labels_match(
                            &target.command,
                            spec.descriptor_key().label(),
                        )
                    }))
            {
                return false;
            }
            let Some(mut words) = target
                .prepended
                .iter()
                .map(|word| match word {
                    crate::registry_invocation::EffectiveInvocationWord::Literal(value) => {
                        Some(value.as_str())
                    }
                    _ => None,
                })
                .collect::<Option<Vec<_>>>()
            else {
                return true;
            };
            words.extend(args.iter().copied());
            self.registry
                .invocation_traits(&target.command, &words, self.registry.own_surface_query())
                .intersects(CODE_RUNNING_TRAITS)
        })
    }

    /// The outer-scope names the procedure a direct call statement reaches
    /// writes ([`GlobalWriteInfo::names`]).
    fn direct_global_writes(&self, stmt: &Statement) -> Vec<String> {
        self.source_global_writes(self.original_tokens_for_statement(stmt))
            .0
    }

    fn source_global_writes(&self, tokens: Option<&CommandTokens>) -> (Vec<String>, bool) {
        let Some(calls) = tokens.and_then(|tokens| {
            self.procedure_summary_owners
                .may_calls(tokens, self.registry)
        }) else {
            return (Vec::new(), true);
        };
        let mut names = BTreeSet::new();
        let mut opaque = calls.unknown_alternatives;
        for id in calls.bodies {
            match self.global_write_procs.get(&id) {
                Some(info) => {
                    names.extend(info.names.iter().cloned());
                    opaque |= info.opaque_global_frame;
                }
                None => opaque = true,
            }
        }
        (names.into_iter().collect(), opaque)
    }

    /// Whole-frame blindness the statement's calls impose on *this*
    /// function, as distinct from the per-name `defs` widening
    /// [`Self::upvar_invalidated`] applies.
    ///
    /// A callee that runs `uplevel 1 $body` — or aliases a caller-frame name
    /// it cannot place — reaches names no `defs` list can enumerate.
    /// Recorded flow-insensitively on the function, in the same lattice and
    /// the same abstention direction as the dynamic-name barrier
    /// ([`crate::dynamic_names`]).
    fn record_caller_frame_barrier(&mut self, stmt: &Statement) {
        let embedded = crate::ir_helpers::evaluated_command_substitutions(stmt, self.registry);
        if embedded.opaque {
            self.caller_frame_barrier = self
                .caller_frame_barrier
                .union(crate::dynamic_names::DynamicNameBarrier::OPAQUE_SCRIPT);
        }
        let direct = self.direct_upvar_effects(stmt);
        let embedded = self.upvar_effects_from_commands(
            &embedded.commands,
            self.original_tokens_for_statement(stmt),
        );
        self.caller_frame_barrier = self
            .caller_frame_barrier
            .union(direct.frame_barrier)
            .union(embedded.frame_barrier);
        if direct.opaque_arguments || embedded.opaque_arguments {
            self.caller_frame_barrier =
                self.caller_frame_barrier
                    .union(crate::dynamic_names::DynamicNameBarrier {
                        writes: true,
                        destroys: false,
                        reads: false,
                    });
        }
    }

    /// The `defs`-widening half of [`Self::apply_upvar_invalidation`], with
    /// no side effect on the function-level barrier — so a speculative query
    /// ([`Self::init_written_names`]) can ask what a statement writes without
    /// recording the statement twice.
    fn upvar_invalidated(&self, stmt: Statement) -> Vec<Statement> {
        let call_unseen = self.call_is_unseen(&stmt);
        let span = stmt.span();
        let (mut out, substitution_unseen) = self.upvar_effect_statements(stmt);
        // An embedded command runs while the host's words are still being
        // evaluated, so its marker goes ahead of the host's own reads; the
        // call's own head runs after its words are, so its marker follows:
        // the words read the versions before it, and a read after the call
        // finds the fresh one the marker leaves
        // ([`crate::ssa::SsaFunction::value_clobbers`]).
        if substitution_unseen {
            out.insert(0, Statement::unseen_call_marker(span));
        }
        if call_unseen {
            out.push(Statement::unseen_call_marker(span));
        }
        out
    }

    /// The statements [`Self::upvar_invalidated`] puts for `stmt` before its
    /// call is marked, and whether a command a `[…]` substitution of it runs is
    /// one the module cannot see.
    fn upvar_effect_statements(&self, mut stmt: Statement) -> (Vec<Statement>, bool) {
        // 1. Direct-call extras: command is a known upvar proc / a proc
        //    that writes outer-scope names.
        let direct_extras = self.direct_call_extras(&stmt);

        // 2. A callee whose caller-frame effect cannot be fully enumerated per
        //    name widens the call site with an opaque barrier after the call
        //    (SCCP/propagation widen every tracked value at a
        //    `Statement::Barrier`). Keep processing the call, though: a
        //    summary may contain both precise caller-side defs and an opaque
        //    remainder, and dropping the known defs loses useful facts such
        //    as `uplevel 1 [list set $parameter value]`.
        let direct_opaque_barrier = self.opaque_call_barrier(&stmt);

        // 3. Embedded-substitution extras: walk text for
        //    `[upvar_proc arg]` / `[global_write_proc arg]` substitutions.
        let EmbeddedSubstExtras {
            defs: embedded_extras,
            reads: embedded_reads,
            opaque_global: embedded_opaque_global,
            unseen: substitution_unseen,
        } = self.embedded_subst_extras(&stmt);

        if direct_extras.is_empty()
            && embedded_extras.is_empty()
            && embedded_reads.is_empty()
            && !embedded_opaque_global
        {
            let out = match direct_opaque_barrier {
                Some(barrier) => vec![stmt, barrier],
                None => vec![stmt],
            };
            return (out, substitution_unseen);
        }

        // 2b. An embedded call to a proc that runs an unreadable script at
        //     the global frame (`set y [setter]` where `setter` does
        //     `uplevel #0 $body`): no def list can enumerate
        //     what it clobbers, so prepend an opaque barrier — the same
        //     program-order position the statement's word effects take,
        //     so the host statement's own reads already see the widened
        //     state.
        let opaque_barrier = embedded_opaque_global.then(|| Statement::Barrier {
            span: stmt.span(),
            reason: "embedded call runs an unreadable script at the global frame".to_owned(),
            command: "<global-frame-script>".to_owned(),
            canonical_command: None,
            args: Vec::new(),
            tokens: Some(crate::ir::CommandTokens::marker(
                crate::ir::SyntheticMarker::GlobalFrameScript,
            )),
        });

        // 3. Merge into the host statement when it's a Call.
        if let Statement::Call { defs, reads, .. } = &mut stmt {
            for d in direct_extras {
                if !defs.contains(&d) {
                    defs.push(d);
                }
            }
            for d in embedded_extras {
                if !defs.contains(&d) {
                    defs.push(d);
                }
            }
            // `puts [incr n]` writes `n` *and* reads the value it increments.
            // Recording only the write makes the feeding `set n 1` look
            // overwritten-before-read, and O109 deletes it (#2050).
            for r in embedded_reads {
                if !reads.contains(&r) {
                    reads.push(r);
                }
            }
            let mut out = Vec::new();
            if let Some(barrier) = opaque_barrier {
                out.push(barrier);
            }
            out.push(stmt);
            if let Some(barrier) = direct_opaque_barrier {
                out.push(barrier);
            }
            return (out, substitution_unseen);
        }

        // 4. Non-Call host (e.g. AssignValue) with embedded extras — its
        //    word effects go right ahead of it as a definition point paired
        //    with it, so the affected vars are written in program order.
        let mut out = Vec::new();
        if let Some(barrier) = opaque_barrier {
            out.push(barrier);
        }
        if !embedded_extras.is_empty() || !embedded_reads.is_empty() {
            out.push(Statement::word_effects(
                stmt.span(),
                (embedded_extras, embedded_reads),
                crate::ir::WordEffectsHost::Statement,
            ));
        }
        out.push(stmt);
        if let Some(barrier) = direct_opaque_barrier {
            out.push(barrier);
        }
        (out, substitution_unseen)
    }

    /// The opaque widening barrier for a direct call whose callee's
    /// caller-frame effect has no sound per-name def list: a callee whose
    /// `upvar` caller-side name is unresolvable (`upvar 1 $computed x`) can
    /// write ANY caller variable, and a callee that runs an unreadable
    /// script at the global frame (`uplevel #0 $body`) can write or read ANY
    /// global/namespace name.
    fn opaque_call_barrier(&self, stmt: &Statement) -> Option<Statement> {
        let Statement::Call {
            command,
            span,
            tokens,
            ..
        } = stmt
        else {
            return None;
        };
        let literal_head = tokens.as_ref().is_none_or(|tokens| {
            tokens.synthetic.is_none()
                && tokens.words().first().is_none_or(|head| {
                    crate::registry_invocation::invocation_word(head)
                        .literal()
                        .is_some()
                })
        });
        let direct_upvar = self.direct_upvar_effects(stmt);
        let unresolvable_upvar = direct_upvar.has_unresolvable_target;
        let opaque_global = literal_head
            && self
                .source_global_writes(self.original_tokens_for_statement(stmt))
                .1;
        let source_opaque_upvar = direct_upvar.opaque_arguments;
        let opaque_variable_write = self.variable_write_projection(stmt).opaque_variable_frame;
        #[cfg(test)]
        if std::env::var_os("ZZ_PROBE_LOWER").is_some() {
            eprintln!(
                "ZZ_CALL_BARRIER {command} unresolvable={unresolvable_upvar} source_opaque={source_opaque_upvar} global={opaque_global} variable={opaque_variable_write} original_tokens={}",
                self.original_tokens_for_statement(stmt).is_some()
            );
        }
        if !unresolvable_upvar && !source_opaque_upvar && !opaque_global && !opaque_variable_write {
            return None;
        }
        let reason = if unresolvable_upvar || source_opaque_upvar {
            format!("{command} upvar-aliases a dynamic caller variable")
        } else if opaque_global {
            format!("{command} runs an unreadable script at the global frame")
        } else {
            format!("{command} writes a source-opaque variable name")
        };
        // Not a command to run: the call itself is already in the statement
        // stream immediately beside this barrier, so naming the callee here
        // would make codegen invoke it a second time: `proc p {} { upvar 1 {a
        // b} v ; puts "u=$v" }; p` would print `u=…` twice on the VM where
        // tclsh 8.6.14 / 9.0.4 print it once; `proc setter {body} { uplevel #0
        // $body }; setter {set q 1}` failed with `wrong # args` from the
        // re-invoke. The typed `SyntheticMarker` on the tokens is what stops
        // codegen dispatching it, and `reason` keeps the callee's name.
        Some(Self::caller_frame_opaque(*span, reason))
    }

    /// The direct-call half of [`Self::upvar_invalidated`]: the caller-side
    /// names a known upvar proc / global-writing proc defines at this call.
    /// Extras are merged as DEFS only; the "the callee may also *read* the
    /// aliased cell" half is recorded on
    /// [`crate::cfg::Function::alias_observed_vars`] by
    /// [`Self::record_alias_observed`] (a read here would fabricate
    /// read-before-set uses — a false W210 — for the pure out-param shape).
    fn direct_call_extras(&self, stmt: &Statement) -> Vec<String> {
        if !matches!(stmt, Statement::Call { .. }) {
            return Vec::new();
        }
        let mut extras = self.direct_upvar_effects(stmt).defs;
        for name in self.variable_write_projection(stmt).literal_names {
            if !extras.contains(&name) {
                extras.push(name);
            }
        }
        for name in self.direct_global_writes(stmt) {
            if !extras.contains(&name) {
                extras.push(name);
            }
        }
        extras
    }

    /// Resolve a recovered substitution's head through the module's command
    /// bindings, so a registry-owned role question about it is asked of the
    /// command it really reaches.
    ///
    /// Without this, `interp alias {} e {} expr` hid an expression word from
    /// the in-frame descent: the raw spelling `e` has no `ArgRole::Expr`, so
    /// the `[incr x]` of `[e {$x + [incr x]}]` was invisible and the later
    /// read folded to the stale literal — tclsh 8.6.18 / 9.0.4 print `3` then
    /// `2`.
    ///
    /// Answers only for a spelling with exactly one statically known
    /// registry-backed target. Several possible bindings mean the role
    /// question has no single answer, and a user procedure carries no
    /// registry roles at all; both fall back to the raw spelling.
    fn embedded_head_resolver(
        &self,
    ) -> impl Fn(&str) -> Option<crate::ir_helpers::ResolvedEmbeddedHead> + '_ {
        |head: &str| {
            self.command_bindings
                .resolved_embedded_head(head, &self.invocation_namespace)
        }
    }

    /// The embedded-substitution half of [`Self::upvar_invalidated`]: the
    /// caller-side defs contributed by `[…]` substitutions in the
    /// statement's argument words (or an assignment's value), the subset of
    /// those the embedded command reads before writing, plus whether any
    /// embedded callee runs an unreadable script at the global frame.
    fn embedded_subst_extras(&self, stmt: &Statement) -> EmbeddedSubstExtras {
        let resolve = self.embedded_head_resolver();
        let embedded = crate::ir_helpers::evaluated_command_substitutions_with_heads(
            stmt,
            self.registry,
            Some(&resolve),
        );
        let mut embedded_extras: Vec<String> = Vec::new();
        let mut embedded_opaque_global = embedded.opaque;
        let upvar = self.upvar_effects_from_commands(
            &embedded.commands,
            self.original_tokens_for_statement(stmt),
        );
        embedded_opaque_global |= upvar.opaque_arguments;
        for d in upvar.defs {
            if !embedded_extras.contains(&d) {
                embedded_extras.push(d);
            }
        }
        let (global_defs, opaque) = self.global_write_defs_from_commands(
            &embedded.commands,
            self.original_tokens_for_statement(stmt),
        );
        embedded_opaque_global |= opaque;
        for d in global_defs {
            if !embedded_extras.contains(&d) {
                embedded_extras.push(d);
            }
        }
        // A var-mutating builtin inside a command substitution
        // (`set y [append x b]`, `[incr x]`, `[lset l …]`) writes its
        // target variable as a side effect; record it so copy / constant
        // propagation (O100) does not propagate a stale value past the
        // mutation (FP-OPT-06).
        // The variable-effect view takes the in-frame words too: a `[incr x]`
        // inside `[expr {…}]`, or the `incr x` of `[catch {incr x}]`, writes
        // `x` whatever word carried it.
        // The call-graph consumers above deliberately do not — see
        // `EvaluatedCommandSubstitutions::in_frame_commands`.
        let writes = crate::ir_helpers::variable_write_effects_from_commands(
            embedded.all_commands(),
            self.registry,
        );
        embedded_opaque_global |= writes.opaque;
        #[cfg(test)]
        if std::env::var_os("ZZ_PROBE_LOWER").is_some() {
            eprintln!(
                "ZZ_EMBEDDED stmt={:?} embedded_opaque={} upvar_opaque={} global_opaque={opaque} writes_opaque={} commands={:?}",
                stmt.span(),
                embedded.opaque,
                upvar.opaque_arguments,
                writes.opaque,
                embedded
                    .commands
                    .iter()
                    .map(|command| format!("{command:?}").chars().take(160).collect::<String>())
                    .collect::<Vec<_>>()
            );
        }
        for d in writes.names {
            if !embedded_extras.contains(&d) {
                embedded_extras.push(d);
            }
        }
        // A `VarRead`-role word inside a substitution observes its target
        // without writing it (`set e [info exists x]`), so it is never among
        // the write effects. Same rule as the condition path (#2132).
        let mut reads = writes.read_names;
        let role_reads = crate::ir_helpers::variable_read_effects_from_commands(
            embedded.all_commands(),
            self.registry,
        );
        // As above, deliberately *not* folded into `opaque`: an unnameable **read**
        // (`[info exists $p]`) observes a cell we cannot name, which is a
        // precision loss, not a claim that anything is written. The
        // `opaque_global` barrier means "this may write any name anywhere",
        // and asserting that for a read made an `[info exists Params($k)]`
        // guard stop folding. A dynamic read's effect on dead-store
        // elimination is already owned by `dynamic_names.reads`, which
        // abstains for the whole function.
        for r in role_reads.names {
            if !reads.contains(&r) {
                reads.push(r);
            }
        }
        let beside = self.read_beside_writes(
            &embedded_extras,
            self.original_tokens_for_statement(stmt),
            |scanner| {
                crate::ir_helpers::statement_substituted_reads(
                    stmt,
                    &embedded,
                    scanner,
                    self.registry,
                )
            },
        );
        for name in beside.into_iter().chain(self.protected_writes(&embedded)) {
            if !reads.contains(&name) {
                reads.push(name);
            }
        }
        EmbeddedSubstExtras {
            defs: embedded_extras,
            reads,
            opaque_global: embedded_opaque_global,
            unseen: self.embedded_reaches_unseen(stmt),
        }
    }

    /// The places a protected script among `embedded` writes — a `catch` or
    /// `try` body inside a substitution — each of which the statement reads
    /// as well as defines. The script stops at its first error and the
    /// `catch` or `try` absorbs it, so a place written only after a command
    /// that may fail keeps what it held, and the store before the statement
    /// is what a later read sees there: `set c old; set r [catch {lassign {x
    /// y z} a b c} m]` leaves `c` old where `b` is an array (tclsh 8.5 to
    /// 9.1). Read by name, like a read beside a write, of the version before
    /// it.
    fn protected_writes(
        &self,
        embedded: &crate::ir_helpers::EvaluatedCommandSubstitutions,
    ) -> Vec<String> {
        crate::ir_helpers::variable_write_effects_from_commands(
            embedded.protected_commands.iter(),
            self.registry,
        )
        .names
    }

    /// Protect incoming values read around a substitution write.
    /// Original roles and lexical reads contribute MAY protection; missing
    /// ownership keeps every written name's incoming version live.
    fn read_beside_writes(
        &self,
        written: &[String],
        tokens: Option<&CommandTokens>,
        host_reads: impl FnOnce(&mut VarReferenceScanner) -> BTreeSet<String>,
    ) -> Vec<String> {
        if written.is_empty() {
            return Vec::new();
        }
        let mut scanner = VarReferenceScanner::with_config(
            VarScanOptions {
                include_var_read_roles: false,
                recurse_cmd_substitutions: true,
                include_reads_before_write: false,
                element_qualified: true,
            },
            self.config,
        );
        let base = |name: &str| {
            crate::variable_observation_names::module_observation_key(
                tcl_syntax::naming::normalise_var_name_braced(name, true),
            )
            .to_owned()
        };
        let mut read: BTreeSet<String> = host_reads(&mut scanner)
            .iter()
            .map(|name| base(name))
            .collect();
        let Some(children) = tokens.and_then(|tokens| {
            self.procedure_summary_owners
                .children(tokens, self.registry)
        }) else {
            return written.to_vec();
        };
        for child in &children {
            let Some(binding) = child.source_binding.as_ref() else {
                return written.to_vec();
            };
            let metadata = match self.procedure_summary_owners.module(self.registry) {
                Some(module) => {
                    binding.original_invocation_metadata_for_module(child, module, self.registry)
                }
                None => binding
                    .original_source_metadata_for_advice(child, self.registry)
                    .ok()
                    .flatten(),
            };
            let Some(metadata) = metadata else {
                return written.to_vec();
            };
            let Some(roles) =
                crate::registry_invocation::possible_variable_name_operands_with_metadata_context(
                    self.registry,
                    Some(metadata),
                    child,
                )
            else {
                return written.to_vec();
            };
            if roles.unknown_residual()
                || roles
                    .unresolved_roles()
                    .any(|role| role == tcl_registry::ArgRole::VarRead)
            {
                return written.to_vec();
            }
            for (role, word) in roles.operands() {
                if role != tcl_registry::ArgRole::VarRead {
                    continue;
                }
                match word {
                    crate::registry_invocation::EffectiveInvocationWord::Literal(name) => {
                        read.insert(base(name));
                    }
                    crate::registry_invocation::EffectiveInvocationWord::ArrayElementName {
                        root,
                    } => {
                        read.insert(base(root));
                    }
                    _ => return written.to_vec(),
                }
            }
        }
        written
            .iter()
            .filter(|name| read.contains(&base(name)))
            .cloned()
            .collect()
    }

    fn upvar_effects_from_commands(
        &self,
        commands: &[Vec<crate::ir_helpers::CommandWord>],
        tokens: Option<&CommandTokens>,
    ) -> ResolvedUpvarEffects {
        let mut combined = ResolvedUpvarEffects::default();
        if commands.is_empty() && tokens.is_none() {
            return combined;
        }
        let Some(children) = tokens.and_then(|tokens| {
            self.procedure_summary_owners
                .children(tokens, self.registry)
        }) else {
            combined.opaque_arguments = true;
            combined.frame_barrier = crate::dynamic_names::DynamicNameBarrier::OPAQUE_SCRIPT;
            return combined;
        };
        for child in &children {
            let effects = self.source_upvar_effects(Some(child));
            combined.opaque_arguments |= effects.opaque_arguments;
            combined.has_unresolvable_target |= effects.has_unresolvable_target;
            combined.frame_barrier = combined.frame_barrier.union(effects.frame_barrier);
            for name in effects.defs {
                if !combined.defs.contains(&name) {
                    combined.defs.push(name);
                }
            }
        }
        combined
    }

    fn global_write_defs_from_commands(
        &self,
        commands: &[Vec<crate::ir_helpers::CommandWord>],
        tokens: Option<&CommandTokens>,
    ) -> (Vec<String>, bool) {
        if commands.is_empty() && tokens.is_none() {
            return (Vec::new(), false);
        }
        let Some(children) = tokens.and_then(|tokens| {
            self.procedure_summary_owners
                .children(tokens, self.registry)
        }) else {
            return (Vec::new(), true);
        };
        let mut names = BTreeSet::new();
        let mut opaque = false;
        for child in &children {
            let (writes, unknown) = self.source_global_writes(Some(child));
            names.extend(writes);
            opaque |= unknown;
        }
        (names.into_iter().collect(), opaque)
    }

    /// Condition-position effects combine registry variable roles, resolved
    /// procedure summaries, and whether a command the condition's
    /// substitutions run, in source order, is one the module cannot see.
    fn condition_out_vars(&self, condition: &ExprNode, span: Span) -> ConditionEffects {
        let bindings = self
            .source_binding_timeline
            .as_ref()
            .and_then(|timeline| timeline.before_substitutions(span))
            .cloned()
            .unwrap_or_else(|| self.command_bindings.clone());
        let metadata = self.command_classes.metadata_context().flatten();
        let writes = crate::ir_helpers::expression_possible_writes_with_metadata_context(
            condition,
            self.registry,
            &bindings,
            &self.invocation_namespace,
            metadata,
            self.config,
        );
        let mut defs = writes.names;
        let state = std::cell::RefCell::new(bindings);
        let unseen = std::cell::Cell::new(false);
        let registry_barrier = std::cell::Cell::new(false);
        let resolve = |head: &str| {
            state
                .borrow()
                .resolved_embedded_head(head, &self.invocation_namespace)
        };
        let observe = |words: &[crate::ir_helpers::CommandWord], conditional: bool| {
            let found = state
                .borrow_mut()
                .source_order_registry_barrier_for_command_with_metadata_context(
                    words,
                    conditional,
                    self.registry,
                    &self.invocation_namespace,
                    REGISTRY_BARRIER_TRAITS,
                    metadata,
                );
            registry_barrier.set(registry_barrier.get() || found);
            self.observe_in_source_order(&state, &unseen, words, conditional);
        };
        let embedded =
            crate::ir_helpers::expression_command_substitutions_with_replay_and_metadata_context(
                condition,
                self.registry,
                Some(&resolve),
                Some(&observe),
                metadata,
                self.config,
            );
        let upvar =
            self.upvar_effects_from_commands(&embedded.commands, self.original_tokens_at(span));
        let opaque_upvar = upvar.opaque_arguments;
        for name in upvar.defs {
            if !defs.contains(&name) {
                defs.push(name);
            }
        }
        let (global_defs, mut opaque_global) =
            self.global_write_defs_from_commands(&embedded.commands, self.original_tokens_at(span));
        opaque_global |= embedded.opaque || opaque_upvar;
        opaque_global |= writes.opaque;
        for name in global_defs {
            if !defs.contains(&name) {
                defs.push(name);
            }
        }
        // A condition's `[incr n]` observes `n` before overwriting it, exactly
        // as the same substitution does in an argument word. Recording only
        // the write made the store feeding the condition look
        // overwritten-before-read, and O109 deleted it: tclsh 9.0.4 prints `6`
        // for `proc p {} {set n 5; if {[incr n]} {puts $n}}` and the optimised
        // program printed `1` (#2132).
        // An `[info exists n]` / `[array size a]` in the condition reads its
        // target without writing it at all, so the read never appears among
        // the write effects above. `proc p {} {set x 1; if {[info exists x]}
        // {puts yes}}` prints `yes` on tclsh 9.0.4; without this the store was
        // removed as unused and the program printed nothing.
        //
        // Deliberately *not* folded into `opaque_global`: an unnameable
        // **read** (`[info exists $p]`) observes a cell we cannot name, which
        // is a precision loss, not a claim that anything is written. A
        // dynamic read's effect on dead-store elimination is already owned by
        // `dynamic_names.reads`, which abstains for the whole function.
        let mut reads = writes.read_names;
        let beside = self.read_beside_writes(&defs, self.original_tokens_at(span), |scanner| {
            crate::ir_helpers::condition_substituted_reads(
                condition,
                &embedded,
                scanner,
                self.registry,
            )
        });
        for name in beside.into_iter().chain(self.protected_writes(&embedded)) {
            if !reads.contains(&name) {
                reads.push(name);
            }
        }
        ConditionEffects {
            defs,
            reads,
            opaque_global,
            unseen: unseen.get(),
            registry_barrier: embedded.opaque || registry_barrier.get(),
        }
    }

    /// Push the synthetic condition effects and analysis-only barriers.
    fn push_condition_effects(&mut self, condition: &ExprNode, span: Span, block: &str) {
        let ConditionEffects {
            defs,
            reads,
            opaque_global,
            unseen,
            registry_barrier,
        } = self.condition_out_vars(condition, span);
        if unseen {
            self.block_mut(block)
                .statements
                .push(Statement::unseen_call_marker(span));
        }
        if !defs.is_empty() || !reads.is_empty() {
            self.push_statement(
                block,
                Statement::Call {
                    span,
                    command: "<cond>".into(),
                    canonical_command: None,
                    args: Vec::new(),
                    defs,
                    reads,
                    reads_own_defs: false,
                    safe_on_uninit: false,
                    tokens: Some(crate::ir::CommandTokens::marker(
                        crate::ir::SyntheticMarker::Condition,
                    )),
                    foreach_groups: None,
                },
            );
        }
        if opaque_global {
            self.push_statement(
                block,
                Statement::Barrier {
                    span,
                    reason: "condition runs an unreadable script at the global frame".into(),
                    command: "<global-frame-script>".into(),
                    canonical_command: None,
                    args: Vec::new(),
                    tokens: Some(crate::ir::CommandTokens::marker(
                        crate::ir::SyntheticMarker::GlobalFrameScript,
                    )),
                },
            );
        }
        if registry_barrier {
            self.block_mut(block)
                .statements
                .push(Self::registry_barrier_statement_at(
                    span,
                    "condition reaches a registry-declared evaluation barrier",
                ));
        }
    }

    /// Consume a proved native break/continue in an analysis loop. Completion
    /// comes from the shared frozen invocation projection; missing proof or
    /// dynamic completion cannot establish an edge. Execution graphs retain
    /// the invocation and its normal runtime-replay continuation.
    fn lower_loop_jump(&mut self, current: &str, stmt: &Statement) -> bool {
        use tcl_registry::completion_route::InvocationCompletionRoute as Route;
        // Execution retains the invocation's normal continuation for runtime
        // binding replay. The emitter handles a native jump in its selected
        // lexical loop; a replacement command can return normally instead.
        if self.plain_command_dispatch || !self.faithful_exceptions {
            return false;
        }
        let Statement::Call { span, .. } = stmt else {
            return false;
        };
        let is_break = match self.command_classes.completion_route(stmt) {
            Some(Route::Tcl(tcl_registry::CompletionCode::Break)) => true,
            Some(Route::Tcl(tcl_registry::CompletionCode::Continue)) => false,
            _ => return false,
        };
        let Some((brk, cont)) = self.loop_stack.last().cloned() else {
            return false;
        };
        let target_name = if is_break { brk } else { cont };
        let target = self.bid(&target_name);
        self.push_statement(current, stmt.clone());
        self.set_terminator(
            current,
            Terminator::Goto {
                target,
                span: Some(*span),
            },
        );
        true
    }

    /// Whether `stmt` ends the block it is lowered into and leaves from the
    /// state before it: a `return`, a `break` or `continue` a loop takes, or a
    /// command that terminates the block (`error`, `throw`, `exit`, and in an
    /// analysis build `tailcall`), each with words that substitute nothing, so
    /// it stores nothing and cannot fail before it completes with its code. A
    /// split region keeps such a statement in the block before it: the block's
    /// exit is the state the statement leaves from, and the block's statements
    /// are the run whose exact completion a handler is matched against
    /// (`set z 0; error boom` completes with an error whichever command raises).
    fn leaves_from_the_state_before(&self, stmt: &Statement) -> bool {
        let literal = |word: &crate::ir::WordExpr| {
            matches!(
                word,
                crate::ir::WordExpr::Literal { .. } | crate::ir::WordExpr::BracedLiteral { .. }
            )
        };
        match stmt {
            Statement::Return {
                value,
                value_word,
                braced,
                ..
            } => value.is_none() || *braced || value_word.as_ref().is_some_and(literal),
            Statement::Call { tokens, .. } => {
                if self.plain_command_dispatch
                    || !tokens
                        .as_ref()
                        .is_some_and(|tokens| tokens.word_exprs.iter().all(literal))
                {
                    return false;
                }
                match self.command_classes.completion_route(stmt) {
                    Some(tcl_registry::completion_route::InvocationCompletionRoute::Tcl(
                        tcl_registry::CompletionCode::Break
                        | tcl_registry::CompletionCode::Continue,
                    )) => !self.loop_stack.is_empty(),
                    Some(route) => !route.normal_possible(),
                    None => false,
                }
            }
            _ => false,
        }
    }

    /// The point a split ends at `ended`, where `next` is the statement after
    /// it: a statement of `ended` may leave after its own stores, unless each
    /// is a literal assignment, which raises before it stores if it raises at
    /// all — a block with no statement joins paths that may — and `next` may
    /// fail before it stores ([`NextFailure::of`]).
    fn split_point(&self, ended: String, next: &Statement) -> SplitPoint {
        let after_stores = self.blocks.get(&ended).is_none_or(|block| {
            block.statements.is_empty() || !block.statements.iter().all(is_literal_assignment)
        });
        SplitPoint {
            block: ended,
            after_stores,
            next: NextFailure::of(next),
        }
    }

    /// Push a non-control-flow statement into `current` (after upvar
    /// invalidation), promoting `error` / `throw` / `exit` (and, in analysis
    /// builds, `tailcall`) to a `Return` terminator so any following statements
    /// become dead code (mirrors the `TERMINATES_BLOCK` registry trait).
    fn push_plain_statement(&mut self, current: &str, stmt: &Statement) {
        for s in self.apply_upvar_invalidation(stmt.clone()) {
            self.push_statement(current, s);
        }
        // A runtime binding check can replay a specialised command through a
        // replacement that returns normally. Codegen must retain that normal
        // continuation rather than manufacture a Tcl return after the invoke.
        if self.plain_command_dispatch || !self.faithful_exceptions {
            return;
        }
        if let Statement::Call { span, .. } | Statement::Barrier { span, .. } = stmt
            && self.block_mut(current).terminator.is_none()
        {
            let route = self.command_classes.completion_route(stmt).or_else(|| {
                let tokens = stmt.tokens()?;
                self.command_classes
                    .conditional_source_completion_route(tokens)
                    .or_else(|| {
                        self.command_classes
                            .logical_structured_invocation(tokens)
                            .map(|invocation| {
                                invocation.conditional_completion_route(self.registry)
                            })
                    })
            });
            let Some(route) = route else {
                return;
            };
            if !route.normal_possible() {
                if !matches!(
                    route,
                    tcl_registry::completion_route::InvocationCompletionRoute::ProcessExit
                ) && let Some(blocks) = self.throw_blocks.as_mut()
                {
                    blocks.push(current.to_owned());
                }
                self.set_terminator(
                    current,
                    Terminator::Complete {
                        route,
                        span: Some(*span),
                    },
                );
            }
        }
    }

    /// Allocate a new empty block with a unique name, interning its
    /// [`BlockId`] in creation order.
    fn new_block(&mut self, prefix: &str) -> String {
        self.counter += 1;
        let name = format!("{prefix}_{}", self.counter);
        let id = BlockId(u32::try_from(self.block_ids.len()).expect("CFG block count fits in u32"));
        self.block_ids.insert(name.clone(), id);
        self.blocks.insert(
            name.clone(),
            MutableBlock {
                name: name.clone(),
                statements: Vec::new(),
                terminator: None,
            },
        );
        name
    }

    /// The [`BlockId`] interned for a created block name. Panics if the
    /// name was never created by [`Self::new_block`].
    fn bid(&self, name: &str) -> BlockId {
        *self
            .block_ids
            .get(name)
            .unwrap_or_else(|| panic!("block {name} has no id"))
    }

    /// Borrow a mutable block by name. Panics if missing.
    fn block_mut(&mut self, name: &str) -> &mut MutableBlock {
        self.blocks
            .get_mut(name)
            .unwrap_or_else(|| panic!("block {name} not found"))
    }

    /// Set a `Goto` terminator on a block only if it doesn't already
    /// have one.
    fn ensure_goto(&mut self, block_name: &str, target: &str, span: Option<Span>) {
        let target = self.bid(target);
        let block = self.block_mut(block_name);
        if block.terminator.is_none() {
            block.terminator = Some(Terminator::Goto { target, span });
        }
    }

    /// Build a [`Function`] by lowering a script starting at a fresh
    /// entry block, then freezing all mutable blocks.
    /// Mark this builder's `::top` as a procedure body.
    fn with_top_level_proc_body(mut self, is_proc_body: bool) -> Self {
        self.top_level_is_proc_body = is_proc_body;
        self
    }

    fn build_function(&mut self, name: &str, script: &Script) -> Function {
        self.is_proc_body = name != "::top" || self.top_level_is_proc_body;
        let entry = self.new_block("entry");
        let tail = self.lower_script(script, &entry);
        if let Some(tail) = tail {
            let exit = self.new_block("exit");
            self.ensure_goto(&tail, &exit, None);
        }

        // Seed the function's interner in block-creation order (by `BlockId`),
        // so the frozen interner's ids match the ones the builder stamped into
        // every terminator / loop node / exception edge.
        let mut func = Function::new(name, &entry);
        func.metadata_context = self.command_classes.metadata.clone();
        func.namespace_context =
            script
                .namespace_context
                .clone()
                .or_else(|| match &self.invocation_namespace {
                    crate::ir::ExecutionNamespace::SourceContext(key) => {
                        Some(Box::new(key.clone()))
                    }
                    _ => None,
                });
        func.executed_source.clone_from(&script.executed_source);
        func.implicit_math_invocations = std::mem::take(&mut self.implicit_math_invocations);
        func.expression_preparations = std::mem::take(&mut self.expression_preparations);
        func.statement_sources = std::mem::take(&mut self.statement_sources);
        func.source_may_calls = std::mem::take(&mut self.source_may_calls);
        func.terminator_sources = std::mem::take(&mut self.terminator_sources);
        func.native_compilation_failure
            .clone_from(&script.native_compilation_failure);
        func.native_compilation_admission =
            crate::native_compilation_admission::retained_script_admission(script);
        let mut ordered: Vec<(BlockId, &String)> =
            self.block_ids.iter().map(|(n, id)| (*id, n)).collect();
        ordered.sort_by_key(|(id, _)| *id);
        for (_, n) in &ordered {
            func.intern_block((*n).clone());
        }

        func.blocks = self
            .blocks
            .drain()
            .map(|(k, mb)| {
                let id = func
                    .block_id(&k)
                    .unwrap_or_else(|| panic!("frozen block {k} not interned"));
                (
                    id,
                    Block {
                        name: mb.name,
                        statements: mb.statements,
                        terminator: mb.terminator,
                    },
                )
            })
            .collect();

        func.loop_nodes = std::mem::take(&mut self.loop_nodes)
            .into_iter()
            .map(|(k, ln)| (self.bid(&k), ln))
            .collect();
        func.opaque_catch_bodies = std::mem::take(&mut self.opaque_catch_bodies);
        self.finally_jump_edges.clear();
        self.plain_return_blocks.clear();
        self.split_parent.clear();
        self.total_interceptors.clear();
        self.handler_caught.clear();
        self.unwinding_tails.clear();
        func.exception_edges = std::mem::take(&mut self.exception_edges)
            .into_iter()
            .map(|(from, to)| (self.bid(&from), self.bid(&to)))
            .collect();
        func.analysis_edges = std::mem::take(&mut self.analysis_edges)
            .into_iter()
            .map(|(from, to)| (self.bid(&from), self.bid(&to)))
            .collect();
        func.region_entries = std::mem::take(&mut self.region_entries)
            .into_iter()
            .map(|(source, handler, first)| crate::cfg::RegionEntry {
                source: self.bid(&source),
                handler: self.bid(&handler),
                first: self.bid(&first),
            })
            .collect();
        func.catch_ends = std::mem::take(&mut self.catch_ends)
            .into_iter()
            .map(|(entry, end, call)| crate::cfg::CatchEnd {
                entry: self.bid(&entry),
                end: self.bid(&end),
                call,
            })
            .collect();
        func.inline_body_error_sites = std::mem::take(&mut self.inline_body_error_sites);
        func.command_binding_sites = std::mem::take(&mut self.command_binding_sites);
        func.procedure_binding_requirements =
            std::mem::take(&mut self.procedure_binding_requirements);
        func.condition_owners = std::mem::take(&mut self.condition_owners);
        func.command_boundary_sites = std::mem::take(&mut self.command_boundary_sites)
            .into_iter()
            .map(|(block, site)| (self.bid(&block), site))
            .collect();
        func.condition_binding_sites = std::mem::take(&mut self.condition_binding_sites)
            .into_iter()
            .map(|(block, site)| (self.bid(&block), site))
            .collect();
        func.command_boundary_continuations =
            std::mem::take(&mut self.command_boundary_continuations)
                .into_iter()
                .map(|(entry, continuation)| (self.bid(&entry), self.bid(&continuation)))
                .collect();
        func.branch_command_joins = std::mem::take(&mut self.branch_command_joins)
            .into_iter()
            .map(|(head, join)| (self.bid(&head), self.bid(&join)))
            .collect();
        func.body_scripts = std::mem::take(&mut self.body_scripts);
        func.caller_frame_barrier = self.caller_frame_barrier;
        func.declared_frame_effects = self.command_bindings.declared_frame_effects();
        func.alias_observed_vars = std::mem::take(&mut self.alias_observed_vars);
        func
    }

    /// Lower a script (sequence of IR statements) into CFG blocks.
    ///
    /// `block_name` is the block where the first statement lands.
    /// Returns `Some(tail_block)` — the block where subsequent code
    /// should go — or `None` if control doesn't fall through (e.g.
    /// the script ends with a `return`).
    /// Depth-guarded entry to the recursive lowering. Every
    /// nested body re-enters here, so bounding this one point caps the
    /// whole `lower_*` recursion. At the cap we stop descending and report
    /// "no fall-through" — `build_function` already handles a `None` tail,
    /// so the result is a truncated-but-valid CFG rather than a stack
    /// overflow.
    /// Append under the exact source instance active during child lowering.
    fn push_statement(&mut self, block: &str, statement: Statement) {
        let id = self.block_ids[block];
        let index = self.blocks[block].statements.len();
        self.statement_sources
            .insert((id, index), self.current_source.clone());
        self.block_mut(block).statements.push(statement);
    }

    fn set_terminator(&mut self, block: &str, terminator: Terminator) {
        self.terminator_sources
            .insert(self.bid(block), self.current_source.clone());
        self.block_mut(block).terminator = Some(terminator);
    }

    fn lower_script(&mut self, script: &Script, block_name: &str) -> Option<String> {
        for proof in &script.expression_preparations {
            if !self.expression_preparations.contains(proof) {
                self.expression_preparations.push(proof.clone());
            }
        }
        for proof in &script.implicit_math_invocations {
            if !self.implicit_math_invocations.contains(proof) {
                self.implicit_math_invocations.push(proof.clone());
            }
        }
        let previous_source =
            std::mem::replace(&mut self.current_source, script.executed_source.clone());
        if self.faithful_exceptions && script.native_compilation_failure.is_some() {
            // Compilation happens before this chunk's first source effect.
            // Analysis must not retain fictitious stores or calls preceding the
            // rejected syntax. Execution retains source instructions separately
            // for admission-time dependency validation and native presentation.
            self.set_terminator(
                block_name,
                Terminator::Complete {
                    route: tcl_registry::completion_route::InvocationCompletionRoute::Tcl(
                        tcl_registry::completion::CompletionCode::Error,
                    ),
                    span: None,
                },
            );
            if let Some(blocks) = self.throw_blocks.as_mut() {
                blocks.push(block_name.to_owned());
            }
            self.current_source = previous_source;
            return Some(block_name.to_owned());
        }
        self.command_binding_sites
            .extend(script.command_binding_sites.iter().cloned());
        self.procedure_binding_requirements
            .extend(script.procedure_binding_requirements.iter().cloned());
        self.depth += 1;
        if MAX_LOWER_DEPTH.exceeded(self.depth) {
            self.depth -= 1;
            self.current_source = previous_source;
            return None;
        }

        let result = self.lower_script_inner(script, block_name);
        self.current_source = previous_source;
        self.depth -= 1;
        result
    }

    /// Push a "frozen" loop (`for` / `while` whose condition is a command
    /// substitution) into `current` as an opaque [`Statement::Barrier`]; the
    /// body is kept un-lowered so it is treated as an opaque effect.
    ///
    /// A `Statement::Barrier` has no `defs` field — its own
    /// [`crate::ssa::uses_of`] textually scans *both* `condition` and the
    /// un-lowered body text for `$var` reads (attributing them all to the
    /// barrier's own span), but nothing analogous computes defs for it
    /// beyond the registry's ordinary `VarWrite` role query, which `for` /
    /// `while` themselves never declare. So a `catch`/`regexp`/`scan`
    /// result var, or a known upvar/global-writing user proc's write,
    /// reached only through the frozen condition (`while {[getopt argv
    /// $opts opt arg]} { ... }`, tcllib's `cmdline::getoptions`) would be
    /// invisible to the def-use graph: the read inside
    /// the (un-lowered, but still textually-scanned) body looked
    /// read-before-set even though the condition's own command
    /// substitution completes — including the write — before the body
    /// (or even a second evaluation of the condition) ever runs. Fixed by
    /// pushing a synthetic `<cond>` `Statement::Call` carrying those defs
    /// immediately before the barrier, exactly mirroring the non-frozen
    /// `lower_if`/`lower_while` path's own `condition_out_vars` use — the
    /// barrier's textually-scanned read then resolves to this new SSA
    /// version instead of the undef origin.
    fn push_frozen_loop_barrier(
        &mut self,
        command: &str,
        condition: &ExprNode,
        raw_args: &[String],
        raw_tokens: Option<&CommandTokens>,
        span: Span,
        current: &str,
    ) {
        self.push_condition_effects(condition, span, current);
        self.push_statement(
            current,
            Statement::Barrier {
                span,
                reason: format!("frozen {command} (cmd-subst condition)"),
                command: command.to_owned(),
                canonical_command: None,
                args: raw_args.to_vec(),
                tokens: Some(frozen_loop_tokens(command, raw_args, raw_tokens)),
            },
        );
    }

    /// Lower a `for`, or freeze it as an opaque barrier when its condition is a
    /// command substitution (`for {…} [cond] {…} {…}`).
    fn lower_for_or_frozen(&mut self, stmt: &Statement, current: &str) -> Option<String> {
        if let Statement::For {
            condition,
            raw_args,
            raw_tokens,
            span,
            ..
        } = stmt
            && matches!(condition, ExprNode::Command { .. })
            && !raw_args.is_empty()
        {
            self.push_frozen_loop_barrier(
                "for",
                condition,
                raw_args,
                raw_tokens.as_deref(),
                *span,
                current,
            );
            Some(current.to_owned())
        } else {
            self.lower_for(stmt, current)
        }
    }

    /// Lower a `while`, or freeze it as an opaque barrier when its condition is
    /// a command substitution (`while [cond] {…}`).
    fn lower_while_or_frozen(&mut self, stmt: &Statement, current: &str) -> String {
        if let Statement::While {
            condition,
            raw_args,
            raw_tokens,
            span,
            ..
        } = stmt
            && matches!(condition, ExprNode::Command { .. })
            && !raw_args.is_empty()
        {
            self.push_frozen_loop_barrier(
                "while",
                condition,
                raw_args,
                raw_tokens.as_ref(),
                *span,
                current,
            );
            current.to_owned()
        } else {
            self.lower_while(stmt, current)
        }
    }

    /// Retain the original return-with-options invocation and project its
    /// established abrupt route without evaluating a second return.
    fn lower_return_options_barrier(&mut self, stmt: &Statement, span: Span, current: &str) {
        let Some(route) = self.command_classes.completion_route(stmt) else {
            return;
        };
        self.push_plain_statement(current, stmt);
        self.set_terminator(
            current,
            Terminator::Complete {
                route,
                span: Some(span),
            },
        );
    }

    fn lower_return_statement(&mut self, stmt: &Statement, current: &str) {
        let Statement::Return {
            span,
            tokens,
            value,
            value_word,
            expr,
            expr_base,
            command_binding,
            braced,
        } = stmt
        else {
            unreachable!();
        };

        // Every substitution in the returned value runs before the frame
        // unwinds. Materialise its analysis effects before installing the
        // terminator.
        self.push_embedded_control_effects(
            stmt,
            current,
            "return value invokes an opaque embedded command",
        );
        if let Some(binding) = command_binding {
            self.command_binding_sites.push(CommandBindingSite {
                span: *span,
                binding: binding.clone(),
                known_namespaces: None,
                variable_frame: None,
                variable_context: None,
                existing_namespace_cells: None,
                source_tokens: None,
                shape: tcl_registry::release_compilation::InvocationShape::counted(usize::from(
                    value.is_some() || expr.is_some(),
                )),
            });
        }
        // No value, a braced one, or a literal word: nothing can raise before
        // the `return` itself completes with `TCL_RETURN`.
        if value.is_none()
            || *braced
            || matches!(
                value_word,
                Some(
                    crate::ir::WordExpr::Literal { .. } | crate::ir::WordExpr::BracedLiteral { .. }
                )
            )
        {
            self.plain_return_blocks.insert(current.to_owned());
        }
        self.set_terminator(
            current,
            Terminator::Return {
                value: value.clone(),
                tokens: tokens.clone().map(Box::new),
                value_word: value_word.clone(),
                span: Some(*span),
                expr: expr.clone(),
                expr_base: *expr_base,
                braced: *braced,
            },
        );
    }

    /// Materialise the variable effects of substitutions executed by a
    /// control statement before its terminator or dispatch is installed.
    fn push_embedded_control_effects(
        &mut self,
        stmt: &Statement,
        current: &str,
        opaque_reason: &str,
    ) {
        self.record_caller_frame_barrier(stmt);
        self.record_alias_observed(stmt);
        let EmbeddedSubstExtras {
            defs: extras,
            reads: extra_reads,
            opaque_global: opaque,
            unseen,
        } = self.embedded_subst_extras(stmt);

        if unseen {
            self.block_mut(current)
                .statements
                .push(Statement::unseen_call_marker(stmt.span()));
        }
        if opaque {
            self.push_statement(
                current,
                Statement::Barrier {
                    span: stmt.span(),
                    reason: opaque_reason.to_owned(),
                    command: "<global-frame-script>".to_owned(),
                    canonical_command: None,
                    args: Vec::new(),
                    tokens: Some(crate::ir::CommandTokens::marker(
                        crate::ir::SyntheticMarker::GlobalFrameScript,
                    )),
                },
            );
        }
        if !extras.is_empty() || !extra_reads.is_empty() {
            self.block_mut(current)
                .statements
                .push(Statement::word_effects(
                    stmt.span(),
                    (extras, extra_reads),
                    crate::ir::WordEffectsHost::Dispatch,
                ));
        }
    }

    fn lower_script_statement(&mut self, stmt: &Statement, current: &str) -> Option<String> {
        self.mark_command_boundary(current, stmt);
        self.record_body_error_sites(stmt);
        if self.faithful_exceptions
            && !self.plain_command_dispatch
            && let Some(region) = Self::evaluated_body_region(stmt)
        {
            return Some(self.lower_evaluated_body(stmt, region, current));
        }
        match stmt {
            Statement::If { .. } => Some(self.lower_if(stmt, current)),
            Statement::For { .. } => self.lower_for_or_frozen(stmt, current),
            Statement::While { .. } => Some(self.lower_while_or_frozen(stmt, current)),
            Statement::Foreach { .. } => Some(self.lower_foreach_dispatch(stmt, current)),
            Statement::Catch { .. } => Some(self.lower_catch_dispatch(stmt, current)),
            Statement::Try { .. } => Some(self.lower_try_dispatch(stmt, current)),
            Statement::Switch { .. } => Some(self.lower_switch(stmt, current)),
            Statement::Return { .. } => {
                self.lower_return_statement(stmt, current);
                Some(current.to_owned())
            }
            // Inline block: flatten the body's statements into the current
            // control-flow stream so SSA / codegen see them as plain inline
            // statements. Preserve any registry-described Tcl error context
            // with the original command span.
            Statement::Block {
                body,
                span,
                error_context,
                ..
            } => {
                if !self.faithful_exceptions
                    && crate::registry_invocation::block_requires_runtime_script(stmt)
                {
                    let boundary =
                        crate::registry_invocation::original_block_runtime_invocation(stmt)
                            .unwrap_or_else(|| stmt.clone());
                    self.push_plain_statement(current, &boundary);
                    return Some(current.to_owned());
                }
                if let Some(context) = error_context {
                    self.inline_body_error_sites
                        .push(crate::cfg::InlineBodyErrorSite {
                            span: *span,
                            context: crate::cfg::BodyErrorContext::Registry(*context),
                            region: *span,
                            compiled: crate::cfg::CompiledAt::NEVER,
                        });
                }
                let owns_inline_region = self
                    .command_boundary_sites
                    .get(current)
                    .is_some_and(|site| site.span == *span);
                if !self.faithful_exceptions && owns_inline_region {
                    let owner = self.command_boundary_sites.get(current).cloned();
                    let body_block = self.new_block("inline_block_body");
                    let continuation = self.new_block("inline_block_end");
                    self.ensure_goto(current, &body_block, Some(*span));
                    self.command_boundary_continuations
                        .insert(current.to_owned(), continuation.clone());
                    if let Some(tail) = self.lower_body(owner.as_ref(), body, &body_block) {
                        self.ensure_goto(&tail, &continuation, Some(*span));
                    }
                    Some(continuation)
                } else {
                    self.lower_script(body, current)
                }
            }
            // `return -options …` / `return {*}…args` lower to a
            // Statement::Barrier, but still unconditionally exit the proc
            // in analysis builds.
            Statement::Barrier { span, .. }
                if self.faithful_exceptions
                    && stmt.is_return_barrier()
                    && self
                        .command_classes
                        .completion_route(stmt)
                        .is_some_and(|route| !route.normal_possible()) =>
            {
                self.lower_return_options_barrier(stmt, *span, current);
                Some(current.to_owned())
            }
            other => {
                self.push_plain_statement(current, other);
                Some(current.to_owned())
            }
        }
    }

    /// Whether this build lowers the `switch` `stmt` to a chain of branches
    /// ([`switch_is_flattened`]); for bytecode, only a form the release
    /// compiles, any other running as the command.
    fn flattens_switch(&self, stmt: &Statement) -> bool {
        switch_is_flattened(stmt, self.registry, &self.config)
            && (self.faithful_exceptions
                || release_compiles_switch(stmt, self.registry) != Some(false))
    }

    /// Record the `errorInfo` frame each body of the structured control
    /// command `stmt` adds where the release runs the command rather than
    /// compiling it, and where it compiles it ([`InlineBodyErrorSite`]).
    fn record_body_error_sites(&mut self, stmt: &Statement) {
        use crate::cfg::{BodyErrorContext, CompiledAt};
        let mut sites: Vec<(BodyErrorContext, Span)> = Vec::new();
        let compiled = match stmt {
            Statement::Foreach {
                body_span,
                is_lmap,
                is_dict_iteration: false,
                is_array_iteration: false,
                raw_args,
                raw_tokens,
                ..
            } => {
                let command = if *is_lmap { "lmap" } else { "foreach" };
                sites.push((BodyErrorContext::LoopBody(command), *body_span));
                release_compiles_control(self.registry, command, raw_args, raw_tokens.as_ref())
            }
            Statement::While {
                body_span,
                raw_args,
                raw_tokens,
                ..
            } => {
                sites.push((BodyErrorContext::LoopBody("while"), *body_span));
                release_compiles_control(self.registry, "while", raw_args, raw_tokens.as_ref())
            }
            Statement::For {
                init_span,
                next_span,
                body_span,
                raw_args,
                raw_tokens,
                ..
            } => {
                sites.push((
                    BodyErrorContext::Clause("\"for\" initial command"),
                    *init_span,
                ));
                sites.push((
                    BodyErrorContext::Clause("\"for\" loop-end command"),
                    *next_span,
                ));
                sites.push((BodyErrorContext::LoopBody("for"), *body_span));
                release_compiles_control(self.registry, "for", raw_args, raw_tokens.as_deref())
            }
            Statement::If {
                clauses, else_span, ..
            } => {
                sites.extend(
                    clauses
                        .iter()
                        .map(|clause| (BodyErrorContext::Script, clause.body_span)),
                );
                sites.extend(else_span.map(|span| (BodyErrorContext::Script, span)));
                CompiledAt::ALWAYS
            }
            Statement::Switch { arms, .. } if self.flattens_switch(stmt) => {
                sites.extend(arms.iter().filter_map(|arm| {
                    arm.body_span
                        .map(|body| (BodyErrorContext::Arm(arm.pattern_span), body))
                }));
                CompiledAt::ALWAYS
            }
            _ => return,
        };
        let span = stmt.span();
        self.inline_body_error_sites
            .extend(
                sites
                    .into_iter()
                    .map(|(context, region)| crate::cfg::InlineBodyErrorSite {
                        span,
                        context,
                        region,
                        compiled,
                    }),
            );
    }

    /// Associate `block` with the explicit structured-command site retained by
    /// lowering for `stmt`. Statements without such a site are deliberately not
    /// inferred from their source text.
    fn mark_command_boundary(&mut self, block: &str, stmt: &Statement) {
        if let Some(site) = self
            .command_binding_sites
            .iter()
            .rev()
            .find(|site| site.span == stmt.span())
            .cloned()
        {
            self.command_boundary_sites.insert(block.to_owned(), site);
        }
    }

    /// Lower `body`, a script the structured command `owner` evaluates, into
    /// `entry`, recording the blocks that run it.
    fn lower_body(
        &mut self,
        owner: Option<&CommandBindingSite>,
        body: &Script,
        entry: &str,
    ) -> Option<String> {
        let block_count = |builder: &Self| {
            u32::try_from(builder.block_ids.len()).expect("CFG block count fits in u32")
        };
        let nested_from = block_count(self);
        let tail = self.lower_script(body, entry);
        if let Some(site) = owner {
            self.body_scripts.push(crate::cfg::BodyScript {
                owner: site.clone(),
                entry: self.bid(entry),
                nested: nested_from..block_count(self),
            });
        }
        tail
    }

    /// Propagate an established owner to a helper block which emits the same
    /// structured command's synthetic runtime boundary.
    fn copy_command_boundary(&mut self, owner: &str, block: &str) {
        if let Some(site) = self.command_boundary_sites.get(owner).cloned() {
            self.command_boundary_sites.insert(block.to_owned(), site);
        }
    }

    /// Retain an established source owner for native condition reads only.
    fn copy_condition_binding(&mut self, owner: &str, condition: &str) {
        let site = self.command_boundary_sites.get(owner).cloned();
        self.retain_condition_binding(site.as_ref(), condition);
    }

    fn retain_condition_binding(&mut self, site: Option<&CommandBindingSite>, condition: &str) {
        if let Some(site) = site {
            self.condition_binding_sites
                .insert(condition.to_owned(), site.clone());
        }
    }

    fn lower_script_inner(&mut self, script: &Script, block_name: &str) -> Option<String> {
        let mut current = block_name.to_owned();
        // The block the *main* (reachable) path ends in once it hits an
        // unconditional terminator — everything after is dead code captured
        // in orphan blocks, and the script does not fall through to its
        // caller — with the number of throw points recorded by then.
        let mut main_terminal: Option<(String, usize)> = None;
        // A `catch` body's request is for this script alone, not for those it
        // holds; a `try` body's holds for every script inside it.
        let split = match self.split_region {
            Some(region) if region.nested() => Some(region),
            _ => self.split_region.take(),
        };

        for (index, stmt) in script.statements.iter().enumerate() {
            if let Some(region) = split
                && index > 0
                && self.block_mut(&current).terminator.is_none()
                && !(region.selective() && self.leaves_from_the_state_before(stmt))
            {
                let next = self.new_block(region.step());
                self.copy_command_boundary(block_name, &next);
                self.ensure_goto(&current, &next, Some(stmt.span()));
                self.split_parent.insert(next.clone(), current.clone());
                let ended = std::mem::replace(&mut current, next);
                let point = self.split_point(ended, stmt);
                if !region.selective() || point.may_leave() {
                    self.split_points.push(point);
                }
            }
            // If the current block is already terminated, subsequent
            // statements are dead code.  Route them into a fresh orphan
            // block with no incoming edge (rather than dropping them) so
            // SCCP marks it unreachable and O107 can flag the dead code.
            if self.block_mut(&current).terminator.is_some() {
                if main_terminal.is_none() {
                    let throws = self.throw_blocks.as_ref().map_or(0, Vec::len);
                    main_terminal = Some((current.clone(), throws));
                }
                current = self.new_block("unreachable");
            }

            // `break` / `continue` inside a loop body lower to a CFG edge to
            // the loop's exit / continue target, so the loop-exit block stays
            // reachable (a `while 1 { … break }` post-loop block is live).
            if self.lower_loop_jump(&current, stmt) {
                continue;
            }
            current = self.lower_script_statement(stmt, &current)?;
        }

        // Always return the block control finally rests in, even when it is
        // terminated by a straight-line `return`/`error`.
        // `build_function` then appends a synthetic (unreachable) `exit` block
        // via `ensure_goto` (a no-op on the already-terminated block).
        // Termination is tracked separately in
        // `last_terminal_block` so `lower_try`
        // can source an on-error edge from a body that ended without an explicit
        // `error`/`throw`.  Nested control-flow lowerings still signal "no
        // continuation" by returning `None` (propagated through this loop's
        // `?` / explicit-`None` arms).
        // The script leaves where its main path ends, not in the dead code
        // after it, and the dead code holds no throw point: a `try` handler is
        // thrown to from there, so in `try {return r3; set y 1} on return {}
        // {…}` the handler's source is the block of `return r3`, never the
        // orphan block of `set y 1`, which no path reaches.
        self.last_terminal_block = match main_terminal {
            Some((block, throws)) => {
                if let Some(blocks) = self.throw_blocks.as_mut() {
                    blocks.truncate(throws);
                }
                Some(block)
            }
            None => self
                .block_mut(&current)
                .terminator
                .is_some()
                .then(|| current.clone()),
        };
        Some(current)
    }

    /// List operands run before loop-variable binding or any body entry.
    /// Preserve the original global-frame and registry-barrier order here.
    fn record_foreach_operand_barriers(&mut self, stmt: &Statement, current: &str) {
        let list_effects = self.embedded_subst_extras(stmt);
        if list_effects.unseen {
            self.push_statement(current, Statement::unseen_call_marker(stmt.span()));
        }
        if list_effects.opaque_global {
            self.block_mut(current).statements.push(Statement::Barrier {
                span: stmt.span(),
                reason: "foreach list runs an unreadable script at the global frame".to_owned(),
                command: "<global-frame-script>".to_owned(),
                canonical_command: None,
                args: Vec::new(),
                tokens: Some(crate::ir::CommandTokens::marker(
                    crate::ir::SyntheticMarker::GlobalFrameScript,
                )),
            });
        }

        // Foreach/lmap list words are evaluated before the header binds any
        // iteration variables. A substitution there can reach the registry
        // fallback just like a substitution in an ordinary value or
        // condition, so widen scalar facts before the header executes.
        if self.embedded_registry_barrier(stmt) {
            self.block_mut(current)
                .statements
                .push(Self::registry_barrier_statement(
                    stmt,
                    "foreach list evaluation reaches a registry-declared evaluation barrier",
                ));
        }
    }

    /// Dispatch `Foreach` — dict for/map, opaque top-level, or inlined.
    fn lower_foreach_dispatch(&mut self, stmt: &Statement, current: &str) -> String {
        let Statement::Foreach {
            is_dict_iteration,
            is_array_iteration,
            raw_args,
            raw_tokens,
            iterators,
            is_lmap,
            span,
            ..
        } = stmt
        else {
            unreachable!();
        };

        self.record_foreach_operand_barriers(stmt, current);

        // `array for {k v} arr body` (Tcl 9.0): the body runs in the caller's
        // frame, so the analysis CFG inlines it (shared reaching-defs / const
        // lattice, loop vars bound) while codegen barriers it to the
        // `::tcl::array::for` ensemble invoke the array hook resolves — keeping
        // the emitted bytecode byte-identical to C Tcl.
        if *is_array_iteration {
            if self.faithful_exceptions {
                return self.lower_foreach(stmt, current);
            }
            self.push_statement(
                current,
                Statement::Barrier {
                    span: *span,
                    reason: "array for".into(),
                    command: "array".into(),
                    canonical_command: None,
                    args: raw_args.clone(),
                    tokens: raw_tokens.clone(),
                },
            );
            return current.to_owned();
        }

        if *is_dict_iteration && !raw_args.is_empty() {
            // `dict for`/`dict map {k v} $d body`: the body runs in the caller's
            // frame, so the analysis CFG inlines it (shared reaching-defs / const
            // lattice, loop vars bound, and — crucially — the body's *own* control
            // flow lowered into real blocks, so a read nested inside an `if` /
            // `while` / `catch` body is a first-class SSA use). Codegen barriers it
            // to the `::tcl::dict::for`/`::tcl::dict::map` ensemble invoke below,
            // keeping the emitted bytecode byte-identical to C Tcl. Mirrors the
            // `array for` split above. Without the inlined body, a command-name or
            // brace-nested `$var` read the shallow barrier-word scan can't see is
            // lost, so the loop's outer reads look dead.
            if self.faithful_exceptions {
                return self.lower_foreach(stmt, current);
            }
            let sub = &raw_args[0];
            let qual_cmd = format!("::tcl::dict::{sub}");
            // The barrier re-emits `::tcl::dict::for {vars} $dict {body}` — the
            // source `dict for …` tokens with the `for`/`map` subcommand word
            // dropped — so the braced var-list / body push verbatim and the
            // `$dict` argument substitutes (else the body's command subs are
            // evaluated once, before the loop variables exist).
            let args = raw_args[1..].to_vec();
            let tokens = raw_tokens
                .as_ref()
                .map_or_else(|| all_str_tokens(&qual_cmd, &args), |t| drop_word(t, 1));
            self.push_statement(
                current,
                Statement::Barrier {
                    span: *span,
                    reason: "dict for/map".into(),
                    command: qual_cmd,
                    canonical_command: None,
                    args,
                    tokens: Some(tokens),
                },
            );
            return current.to_owned();
        }

        let has_qualified_vars = iterators
            .iter()
            .any(|it| it.vars.iter().any(|v| v.starts_with("::")));

        // The original Each compiler owns local declarations, value-script
        // visits and the body range. Flattening it here would reserve body
        // locals before visiting the original value operands. Analysis keeps
        // its structural graph; executable emission consumes the exact source
        // once through the independently admitted compiler.
        let original_each =
            !self.faithful_exceptions
                && !self.plain_command_dispatch
                && raw_tokens.as_ref().is_some_and(|tokens| {
                    tokens.argv_texts.get(1..) == Some(raw_args.as_slice())
                        && tokens
                            .source_binding
                            .as_ref()
                            .and_then(|binding| binding.original_structured_compilation(tokens))
                            .is_some_and(|preparation| {
                                matches!(
                        preparation.recipe(),
                        tcl_registry::native_instruction_plan::NativeInstructionPlan::Each(_)
                    )
                            })
                });

        if original_each || (!self.inline_loops && !raw_args.is_empty()) || has_qualified_vars {
            let cmd = if *is_lmap { "lmap" } else { "foreach" };
            let loop_vars: Vec<String> = iterators.iter().flat_map(|it| it.vars.clone()).collect();
            self.push_statement(
                current,
                Statement::Call {
                    span: *span,
                    command: cmd.into(),
                    canonical_command: None,
                    args: raw_args.clone(),
                    defs: loop_vars,
                    reads: vec![],
                    reads_own_defs: false,
                    safe_on_uninit: false,
                    tokens: Some(frozen_loop_tokens(cmd, raw_args, raw_tokens.as_ref())),
                    foreach_groups: None,
                },
            );
            return current.to_owned();
        }

        self.lower_foreach(stmt, current)
    }

    /// Dispatch `Catch` — inlined into real blocks, or deferred opaque.
    ///
    /// Mirrors [`Self::lower_try_dispatch`]. Inlining is what lets the
    /// ordinary emitters compile the body, so its variables reach the LVT and
    /// the optimiser can see inside it (#2207); the opaque arm stays for the
    /// shapes that cannot be lowered faithfully.
    ///
    /// `{*}` expansion keeps the opaque path: the body word is re-parsed by
    /// the inline emitters, and `parse_cmd_parts` splits an adjacent
    /// `{*}$args` into a literal `*` and `$args`, changing the callee's argv.
    /// A qualified result/options variable keeps it too — those are not frame
    /// locals, so the store the inline form emits would address the wrong
    /// variable.
    fn lower_catch_dispatch(&mut self, stmt: &Statement, current: &str) -> String {
        self.push_embedded_control_effects(
            stmt,
            current,
            "catch header invokes an opaque embedded command",
        );
        let Statement::Catch { body, raw_args, .. } = stmt else {
            unreachable!();
        };

        let expands = raw_args.iter().any(|arg| arg.contains("{*}"));
        // The destination words have to be written as plain scalar locals.
        // Lowering normalises `$dst` to `dst` and `a(key)` to `a`, so the
        // names alone no longer say what was written: inlining
        // `catch {…} $dst` would store into `dst` rather than into the
        // variable it names, and `catch {…} a(key)` into a scalar `a`.
        let indirect_destination = raw_args
            .iter()
            .skip(1)
            .any(|word| !is_plain_local_destination(word));

        // Semantic expansion is independent of the backend's local-table and
        // one-block emitter restrictions. Invalid/dynamic argv stays opaque;
        // a count the release's `catch` refuses never lowers to a `Catch`.
        if self.faithful_exceptions && !raw_args.is_empty() && !expands && !indirect_destination {
            return self.lower_catch(stmt, current);
        }

        if !self.is_proc_body
            || raw_args.is_empty()
            || body.statements.is_empty()
            || expands
            || indirect_destination
            || stmt
                .tokens()
                .and_then(|tokens| {
                    let context = self
                        .registry
                        .profile()
                        .map(tcl_registry::model::semantic::SemanticContext::for_profile);
                    crate::registry_invocation::normal_transfer_invocation(
                        self.registry,
                        context,
                        tokens,
                    )
                })
                .and_then(|normal| normal.variable_output_arguments())
                .is_none()
            || !self.catch_body_is_one_block(body)
        {
            self.emit_opaque_catch(stmt, current);
            return current.to_owned();
        }

        self.lower_catch(stmt, current)
    }

    /// Whether a `catch` body lowers to a single straight-line block.
    ///
    /// The inline emitter compiles the body itself, so that it can leave the
    /// last statement's value on the stack for `catch`'s result variable
    /// rather than popping it as the ordinary block walk would. That only
    /// works while the body *is* one block. A final call stays inside that
    /// block and its captured range, including its independently guarded
    /// runtime fallback. A terminating call followed by more commands, or a
    /// structured/return node, requires a complete multi-block exception range.
    ///
    /// The terminator set is the registry's [`Traits::TERMINATES_BLOCK`], not
    /// a name list here. Nested control flow needs its own blocks for the
    /// same reason and is rejected too.
    fn catch_body_is_one_block(&self, body: &Script) -> bool {
        body.statements
            .iter()
            .enumerate()
            .all(|(index, s)| match s {
                Statement::If { .. }
                | Statement::For { .. }
                | Statement::While { .. }
                | Statement::Foreach { .. }
                | Statement::Catch { .. }
                | Statement::Try { .. }
                | Statement::Switch { .. }
                | Statement::Block { .. }
                | Statement::UpFrame { .. }
                | Statement::Barrier { .. }
                | Statement::Return { .. } => false,
                Statement::Call { command, .. } => {
                    let terminates = self
                        .registry
                        .get(command)
                        .is_some_and(|spec| spec.traits.contains(Traits::TERMINATES_BLOCK));
                    !terminates || index + 1 == body.statements.len()
                }
                _ => true,
            })
    }

    /// Emit an opaque `catch` call, with the effects of its body ahead of it.
    ///
    /// The body runs inside the statement and stops at its first error, so every
    /// name it writes is a may-definition, and what its commands do to the frame
    /// ([`Self::opaque_script_effects`]) goes ahead of the call, which assigns
    /// its result and options variables once the body has finished.
    fn emit_opaque_catch(&mut self, stmt: &Statement, current: &str) {
        let Statement::Catch {
            body,
            result_var,
            options_var,
            raw_args,
            span,
            tokens,
            ..
        } = stmt
        else {
            unreachable!();
        };

        let mut written = BTreeSet::new();
        crate::ssa::nested_writes(body, self.registry, &mut written);
        for effect in self.opaque_script_effects(
            *span,
            &[body],
            written,
            false,
            "a command the catch body runs may write any name",
        ) {
            self.block_mut(current).statements.push(effect);
        }
        let mut catch_defs: Vec<String> = result_var.iter().chain(options_var).cloned().collect();
        dedup_preserve_order(&mut catch_defs);
        // Preserve ``tokens`` on the synthetic ``Statement::Call``
        // so the codegen's eval-fallback can detect the braced
        // body word and re-wrap it in ``{…}`` when reconstructing
        // the script for ``tcl_eval``.  Without this,
        // ``catch {$undef} msg`` would lower to ``catch $undef
        // msg`` and the var-read trap would fire before catch
        // could intercept it.
        self.push_statement(
            current,
            Statement::Call {
                span: *span,
                command: "catch".into(),
                canonical_command: None,
                args: raw_args.clone(),
                defs: catch_defs,
                reads: vec![],
                reads_own_defs: false,
                safe_on_uninit: false,
                tokens: tokens.clone(),
                foreach_groups: None,
            },
        );
        self.opaque_catch_bodies.insert(*span, body.clone());
    }

    /// Dispatch `Try` — deferred opaque or inlined.
    fn lower_try_dispatch(&mut self, stmt: &Statement, current: &str) -> String {
        // Header words substitute before either the generic invocation or
        // the inlined body begins, and may mutate this frame through a handler.
        self.push_embedded_control_effects(
            stmt,
            current,
            "try header invokes an opaque embedded command",
        );
        let Statement::Try {
            handlers,
            finally_body,
            raw_args,
            body,
            span,
            ..
        } = stmt
        else {
            unreachable!();
        };

        let defer = !self.inline_loops
            && !raw_args.is_empty()
            && (!handlers.is_empty() || finally_body.is_none());

        if defer {
            // As an opaque `catch`: what the body, the handlers and the
            // `finally` script write is a may-definition, since each stops at
            // its first error, and a handler's variables are set only when it
            // runs.
            let mut written = BTreeSet::new();
            let mut scripts: Vec<&Script> = vec![body];
            for handler in handlers {
                written.extend(handler.var_name.iter().cloned());
                written.extend(handler.options_var.iter().cloned());
                scripts.push(&handler.body);
            }
            scripts.extend(finally_body.as_ref());
            for script in &scripts {
                crate::ssa::nested_writes(script, self.registry, &mut written);
            }
            let mut try_defs: Vec<_> = written.iter().cloned().collect();
            for effect in self.opaque_script_effects(
                *span,
                &scripts,
                written,
                false,
                "a command the try body or its handlers run may write any name",
            ) {
                self.block_mut(current).statements.push(effect);
            }
            dedup_preserve_order(&mut try_defs);
            self.push_statement(
                current,
                Statement::Call {
                    span: *span,
                    command: "try".into(),
                    canonical_command: None,
                    args: raw_args.clone(),
                    defs: try_defs,
                    reads: vec![],
                    reads_own_defs: false,
                    safe_on_uninit: false,
                    tokens: None,
                    foreach_groups: None,
                },
            );
            return current.to_owned();
        }

        self.lower_try(stmt, current)
    }
}

// Public API

fn opaque_frame_summary() -> UpvarInfo {
    UpvarInfo {
        has_unresolvable_caller_target: true,
        caller_frame_opaque_writes: true,
        caller_frame_opaque_reads: true,
        frame_reach: FrameReach::PastTheCaller,
        ..UpvarInfo::default()
    }
}

/// Caller-frame facts retained separately for every genuine source body.
#[must_use]
pub fn detect_upvar_procs(module: &Module) -> HashMap<crate::ir::ProcedureId, UpvarInfo> {
    detect_upvar_procs_with_registry(module, module.resolved_registry())
}

/// Caller-frame facts under the Module's exact retained registry.
#[must_use]
pub fn detect_upvar_procs_with_registry(
    module: &Module,
    registry: &CommandRegistry,
) -> HashMap<crate::ir::ProcedureId, UpvarInfo> {
    detect_upvar_bodies_with_registry(module, registry)
}

pub(crate) fn detect_upvar_bodies_with_registry(
    module: &Module,
    registry: &CommandRegistry,
) -> HashMap<crate::ir::ProcedureId, UpvarInfo> {
    let bindings = ModuleCommandBindings::analyse(module, registry);
    let owner = module
        .retained_source_bindings
        .as_ref()
        .filter(|owner| owner.matches_module(module, registry));
    let mut summaries: HashMap<_, _> = module
        .original_source_procedure_bodies()
        .map(|(id, procedure)| {
            let namespace = procedure.body.namespace_context.as_deref();
            let mut info = if let Some(namespace) = namespace.filter(|_| {
                module.procedure_ids.owns(*id)
                    && owner.is_some_and(|owner| {
                        owner.matches_original_procedure_summary(*id, procedure)
                    })
            }) {
                upvar_info::collect_upvar_targets_with_bindings(
                    &procedure.body,
                    &procedure.params,
                    registry,
                    &bindings,
                    namespace,
                    module,
                )
            } else {
                opaque_frame_summary()
            };
            if !info.uplevel_forwarded_calls.is_empty() {
                info = opaque_frame_summary();
            }
            info.param_defaults =
                upvar_info::name_param_defaults(&info, &procedure.params_raw, module.word_values());
            info.plain_calls.clear();
            (*id, info)
        })
        .collect();
    let prior = summaries.clone();
    let owners = OriginalProcedureSummaryOwners::for_module(module, registry);
    for (id, procedure) in module.original_source_procedure_bodies() {
        let (calls, opaque) =
            global_write_info::direct_call_targets(&procedure.body, &owners, registry);
        if opaque
            || calls.iter().any(|callee| {
                prior.get(callee).is_none_or(|summary| {
                    summary.frame_reach == upvar_info::FrameReach::PastTheCaller
                })
            })
        {
            summaries.insert(*id, opaque_frame_summary());
        }
    }
    summaries
}

/// Body-keyed caller-frame, parameter and outer-write summaries, closed
/// command bindings, and the original Module owner selecting summary edges.
/// [`crate::compilation_unit`] shares this canonical tuple.
pub type CfgContext = (
    HashMap<crate::ir::ProcedureId, UpvarInfo>,
    HashMap<crate::ir::ProcedureId, Vec<String>>,
    HashMap<crate::ir::ProcedureId, GlobalWriteInfo>,
    ModuleCommandBindings,
    OriginalProcedureSummaryOwners,
);

/// Prepared module facts shared by every CFG builder in one lowering pipeline.
/// The tuple [`CfgContext`] remains the public compatibility boundary.
pub struct PreparedCfgContext {
    pub(crate) context: CfgContext,
    command_classes: CfgCommandClasses,
}

impl PreparedCfgContext {
    /// Retain the source producer's complete availability for body CFGs.
    /// Missing input refuses metadata; it never selects standalone advice.
    #[must_use]
    pub fn from_source_input(
        context: CfgContext,
        registry: &CommandRegistry,
        input: Option<&crate::analyser::ResolvedAnalysisInput>,
    ) -> Self {
        Self::from_metadata_input(
            context,
            registry,
            crate::registry_invocation::InvocationMetadataInput::SuppliedSource(input),
        )
    }

    /// Retain the original metadata ingress purpose without converting absent
    /// supplied input into standalone catalogue compatibility.
    #[must_use]
    pub fn from_metadata_input(
        context: CfgContext,
        registry: &CommandRegistry,
        metadata: crate::registry_invocation::InvocationMetadataInput<'_>,
    ) -> Self {
        Self {
            context,
            command_classes: CfgCommandClasses::from_metadata_input(registry, metadata),
        }
    }

    /// Borrow the closed binding lattice shared by downstream CFG and codegen
    /// consumers.
    pub(crate) fn command_bindings(&self) -> &ModuleCommandBindings {
        &self.context.3
    }
}

/// Retain body-keyed caller-frame, parameter and outer-place facts alongside
/// their actual original Module and command-binding owners.
#[must_use]
pub fn prepare_cfg_context(module: &Module) -> CfgContext {
    let registry = module.resolved_registry();
    prepare_cfg_context_with_registry(module, registry)
}

/// Prepare the module-wide CFG context against the exact registry that
/// lowered the module.
#[must_use]
pub fn prepare_cfg_context_with_registry(
    module: &Module,
    registry: &CommandRegistry,
) -> CfgContext {
    prepare_cfg_context_bundle(module, registry).context
}

#[must_use]
pub(crate) fn prepare_cfg_context_bundle(
    module: &Module,
    registry: &CommandRegistry,
) -> PreparedCfgContext {
    let command_bindings = ModuleCommandBindings::analyse(module, registry);
    let upvar_procs = detect_upvar_bodies_with_registry(module, registry);
    let global_write_procs =
        global_write_info::detect_global_write_bodies_with_registry(module, registry);
    let proc_params = module
        .original_source_procedure_bodies()
        .filter(|(id, procedure)| {
            module.procedure_ids.owns(**id)
                && module
                    .retained_source_bindings
                    .as_ref()
                    .is_some_and(|owner| {
                        owner.matches_module(module, registry)
                            && owner.matches_original_procedure_summary(**id, procedure)
                    })
        })
        .map(|(id, procedure)| (*id, procedure.params.clone()))
        .collect();
    let procedure_summary_owners = OriginalProcedureSummaryOwners::for_module(module, registry);
    PreparedCfgContext {
        context: (
            upvar_procs,
            proc_params,
            global_write_procs,
            command_bindings,
            procedure_summary_owners,
        ),
        command_classes: CfgCommandClasses::from_metadata_input(
            registry,
            if module
                .retained_source_bindings
                .as_ref()
                .is_some_and(|retained| retained.positioned_for_module(module, registry).is_some())
                && match &module.source_entry.metadata_context {
                    CfgMetadataContext::SuppliedSource(_) => {
                        crate::registry_invocation::InvocationMetadataContext::for_module(
                            registry, module,
                        )
                        .is_some()
                    }
                    _ => module.source_metadata_input.is_none(),
                }
            {
                crate::registry_invocation::InvocationMetadataInput::Retained(
                    &module.source_entry.metadata_context,
                )
            } else {
                crate::registry_invocation::InvocationMetadataInput::SuppliedSource(None)
            },
        ),
    }
}

/// Build CFGs for a whole module: top-level script + each procedure.
///
/// When `defer_top_level` is `true`, `foreach`/`catch`/`try` at the
/// top level are compiled as opaque calls (matching tclsh bytecode
/// output). Analysis passes should leave this `false` to get full
/// inlining of loop bodies.
///
/// The builder also applies the upvar-invalidation pass — calls to
/// procedures whose bodies use `upvar` have their `defs` augmented
/// with the caller-side variable names the callee will modify.  See
/// [`prepare_cfg_context`] for the per-module scan.
#[must_use]
pub fn build_cfg(module: &Module, defer_top_level: bool) -> CfgModule {
    let registry = module.resolved_registry();
    let config = module.lexer_config;
    build_cfg_with_registry_and_config(module, defer_top_level, registry, config)
}

/// [`build_cfg`] with the document's exact [`tcl_lexer::LexerConfig`].
#[must_use]
pub fn build_cfg_with_config(
    module: &Module,
    defer_top_level: bool,
    config: tcl_lexer::LexerConfig,
) -> CfgModule {
    let registry = module.resolved_registry();
    build_cfg_with_registry_and_config(module, defer_top_level, registry, config)
}

/// Build analysis CFGs against the exact registry that lowered `module`.
#[must_use]
pub fn build_cfg_with_registry(
    module: &Module,
    defer_top_level: bool,
    registry: &CommandRegistry,
) -> CfgModule {
    build_cfg_with_registry_and_config(module, defer_top_level, registry, module.lexer_config)
}

/// Build analysis CFGs against both the exact command surface and lexer
/// configuration that lowered `module`.
#[must_use]
pub fn build_cfg_with_registry_and_config(
    module: &Module,
    defer_top_level: bool,
    registry: &CommandRegistry,
    config: tcl_lexer::LexerConfig,
) -> CfgModule {
    build_cfg_inner(module, defer_top_level, true, registry, config)
}

/// Build analysis CFGs from an already-prepared registry-owned module context.
pub(crate) fn build_cfg_with_registry_and_context(
    module: &Module,
    defer_top_level: bool,
    registry: &CommandRegistry,
    context: &PreparedCfgContext,
    config: tcl_lexer::LexerConfig,
) -> CfgModule {
    build_cfg_inner_with_context(module, defer_top_level, true, registry, context, config)
}

/// Build CFGs for codegen (bytecode / WASM): the plain, byte-identical loop /
/// switch shape with no analysis-only transforms.
#[must_use]
pub fn build_cfg_codegen(module: &Module, defer_top_level: bool) -> CfgModule {
    let registry = module.resolved_registry();
    let config = module.lexer_config;
    build_cfg_codegen_with_registry_and_config(module, defer_top_level, registry, config)
}

/// [`build_cfg_codegen`] with the document's exact lexer configuration.
#[must_use]
pub fn build_cfg_codegen_with_config(
    module: &Module,
    defer_top_level: bool,
    config: tcl_lexer::LexerConfig,
) -> CfgModule {
    let registry = module.resolved_registry();
    build_cfg_codegen_with_registry_and_config(module, defer_top_level, registry, config)
}

/// Build code-generation CFGs against the exact registry that lowered
/// `module`.
#[must_use]
pub fn build_cfg_codegen_with_registry(
    module: &Module,
    defer_top_level: bool,
    registry: &CommandRegistry,
) -> CfgModule {
    build_cfg_codegen_with_registry_and_config(
        module,
        defer_top_level,
        registry,
        module.lexer_config,
    )
}

/// Build code-generation CFGs against both the exact command surface and lexer
/// configuration that lowered `module`.
#[must_use]
pub fn build_cfg_codegen_with_registry_and_config(
    module: &Module,
    defer_top_level: bool,
    registry: &CommandRegistry,
    config: tcl_lexer::LexerConfig,
) -> CfgModule {
    build_cfg_inner(module, defer_top_level, false, registry, config)
}

/// Build code-generation CFGs from an already-prepared registry-owned module
/// context.
pub(crate) fn build_cfg_codegen_with_registry_and_context(
    module: &Module,
    defer_top_level: bool,
    registry: &CommandRegistry,
    context: &PreparedCfgContext,
    config: tcl_lexer::LexerConfig,
) -> CfgModule {
    build_cfg_inner_with_context(module, defer_top_level, false, registry, context, config)
}

fn build_cfg_inner(
    module: &Module,
    defer_top_level: bool,
    faithful: bool,
    registry: &CommandRegistry,
    config: tcl_lexer::LexerConfig,
) -> CfgModule {
    let context = prepare_cfg_context_bundle(module, registry);
    build_cfg_inner_with_context(
        module,
        defer_top_level,
        faithful,
        registry,
        &context,
        config,
    )
}

fn build_cfg_inner_with_context(
    module: &Module,
    defer_top_level: bool,
    faithful: bool,
    registry: &CommandRegistry,
    context: &PreparedCfgContext,
    config: tcl_lexer::LexerConfig,
) -> CfgModule {
    let (upvar_procs, proc_params, global_write_procs, command_bindings, procedure_summary_owners) =
        &context.context;

    let new_builder = |inline: bool| {
        let b = CfgBuilder::new_with_upvars_and_classes(
            inline,
            upvar_procs.clone(),
            proc_params.clone(),
            global_write_procs.clone(),
            command_bindings.clone(),
            registry,
            context.command_classes.clone(),
        )
        .with_procedure_summary_owners(procedure_summary_owners.clone())
        .with_lexer_config(config)
        .with_command_surface(module.plain_command_dispatch);
        if faithful {
            b.with_faithful_exceptions()
        } else {
            b
        }
    };

    let top_namespace = if module.top_level_namespace.is_empty() {
        "::".to_owned()
    } else {
        module.top_level_namespace.clone()
    };
    let top_context = module.top_level.execution_namespace(
        module.top_level_namespace_context.as_ref().map_or_else(
            || crate::ir::ExecutionNamespace::exact(top_namespace),
            |key| crate::ir::ExecutionNamespace::SourceContext(key.clone()),
        ),
    );
    let top_timeline =
        command_bindings.source_binding_timeline(&module.top_level, registry, &top_context, true);
    let mut top_builder = new_builder(!defer_top_level)
        .with_invocation_namespace(top_context)
        .with_source_binding_timeline(top_timeline.clone())
        .with_top_level_proc_body(module.top_level_kind == crate::ir::TopLevelKind::ProcedureBody);
    let top_cfg = top_builder.build_function("::top", &module.top_level);

    let mut proc_cfgs = HashMap::new();
    for (qname, proc) in &module.procedures {
        let namespace = proc
            .body
            .execution_namespace(crate::ir::ExecutionNamespace::RuntimeSelected);
        let timeline = top_timeline
            .entry_after(proc.span, command_bindings)
            .map_or_else(
                || {
                    command_bindings
                        .source_binding_timeline(&proc.body, registry, &namespace, false)
                },
                |initial| {
                    ModuleCommandBindings::source_binding_timeline_from_initial(
                        &proc.body, registry, &namespace, &initial,
                    )
                },
            );
        let mut builder = new_builder(true)
            .with_invocation_namespace(namespace)
            .with_source_binding_timeline(timeline);
        proc_cfgs.insert(
            *qname,
            builder.build_function(&proc.qualified_name, &proc.body),
        );
    }

    CfgModule {
        top_level: top_cfg,
        procedures: proc_cfgs,
    }
}

/// Build a CFG for a single script body against one resolved command surface.
#[must_use]
pub fn build_cfg_function(
    name: &str,
    script: &Script,
    inline_loops: bool,
    registry: &CommandRegistry,
    plain_command_dispatch: bool,
) -> Function {
    build_cfg_function_with_config(
        name,
        script,
        inline_loops,
        registry,
        plain_command_dispatch,
        tcl_lexer::LexerConfig::for_profile(registry.profile()),
    )
}

/// [`build_cfg_function`] with the exact lexer configuration used to lower
/// `script`.
#[must_use]
pub fn build_cfg_function_with_config(
    name: &str,
    script: &Script,
    inline_loops: bool,
    registry: &CommandRegistry,
    plain_command_dispatch: bool,
    config: tcl_lexer::LexerConfig,
) -> Function {
    let mut builder = CfgBuilder::new(inline_loops, registry)
        .with_lexer_config(config)
        .with_command_surface(plain_command_dispatch)
        .with_invocation_namespace(script.execution_namespace(
            crate::ir::ExecutionNamespace::exact(command_namespace(name)),
        ));
    builder.build_function(name, script)
}

/// Build a closed-language phase whose command scope is explicitly selected
/// by its caller. The generated function label grants no namespace identity;
/// source correspondence and target-language admission remain caller duties.
#[must_use]
pub fn build_cfg_function_in_runtime_selected_scope(
    name: &str,
    script: &Script,
    inline_loops: bool,
    registry: &CommandRegistry,
    plain_command_dispatch: bool,
    config: tcl_lexer::LexerConfig,
) -> Function {
    CfgBuilder::new(inline_loops, registry)
        .with_lexer_config(config)
        .with_command_surface(plain_command_dispatch)
        .with_invocation_namespace(crate::ir::ExecutionNamespace::RuntimeSelected)
        .build_function(name, script)
}

/// Build a secondary analysis body in its retained execution namespace.
/// Possible body regions and exceptional continuations remain analysis facts;
/// the synthetic unit label does not select a command lookup namespace.
pub(crate) fn build_analysis_body(
    name: &str,
    script: &Script,
    namespace: crate::ir::ExecutionNamespace,
    registry: &CommandRegistry,
    config: tcl_lexer::LexerConfig,
    metadata: Arc<tcl_registry::model::ContextRegistry>,
) -> Function {
    CfgBuilder::new_with_upvars_and_classes(
        true,
        HashMap::new(),
        HashMap::new(),
        HashMap::new(),
        ModuleCommandBindings::default(),
        registry,
        CfgCommandClasses::from_metadata(registry, Some(metadata)),
    )
    .with_faithful_exceptions()
    .with_lexer_config(config)
    .with_invocation_namespace(script.execution_namespace(namespace))
    .build_function(name, script)
}

/// Build a CFG for one body with the registry-owned module context prepared by
/// [`prepare_cfg_context`].
#[must_use]
pub fn build_cfg_function_with_upvars(
    name: &str,
    script: &Script,
    inline_loops: bool,
    registry: &CommandRegistry,
    plain_command_dispatch: bool,
    context: CfgContext,
) -> Function {
    build_cfg_function_with_upvars_and_config(
        name,
        script,
        inline_loops,
        registry,
        plain_command_dispatch,
        context,
        tcl_lexer::LexerConfig::for_profile(registry.profile()),
    )
}

/// Build a CFG for one body with both the registry-owned module context and the
/// exact dialect-aware lexer configuration used during lowering.
#[must_use]
pub fn build_cfg_function_with_upvars_and_config(
    name: &str,
    script: &Script,
    inline_loops: bool,
    registry: &CommandRegistry,
    plain_command_dispatch: bool,
    context: CfgContext,
    config: tcl_lexer::LexerConfig,
) -> Function {
    build_cfg_function_with_upvars_inner(
        name,
        script,
        crate::ir::ExecutionNamespace::exact(command_namespace(name)),
        inline_loops,
        registry,
        plain_command_dispatch,
        context,
        false,
        None,
        config,
    )
}

/// Build an ordinary body CFG using the module's already-prepared facts.
/// Missing or foreign original metadata refuses command assistance.
#[must_use]
pub fn build_cfg_function_with_prepared_context(
    name: &str,
    script: &Script,
    inline_loops: bool,
    registry: &CommandRegistry,
    plain_command_dispatch: bool,
    context: &PreparedCfgContext,
    config: tcl_lexer::LexerConfig,
) -> Function {
    build_cfg_function_with_upvars_inner(
        name,
        script,
        crate::ir::ExecutionNamespace::exact(command_namespace(name)),
        inline_loops,
        registry,
        plain_command_dispatch,
        context.context.clone(),
        false,
        Some(context.command_classes.clone()),
        config,
    )
}

/// Test seam for building one method with an explicitly supplied context.
#[cfg(test)]
#[allow(clippy::too_many_arguments)]
fn build_cfg_method_function_with_upvars(
    name: &str,
    script: &Script,
    execution_namespace: crate::ir::ExecutionNamespace,
    inline_loops: bool,
    registry: &CommandRegistry,
    plain_command_dispatch: bool,
    context: CfgContext,
    widen_oo_dispatch: bool,
) -> Function {
    build_cfg_function_with_upvars_inner(
        name,
        script,
        execution_namespace,
        inline_loops,
        registry,
        plain_command_dispatch,
        context,
        widen_oo_dispatch,
        None,
        tcl_lexer::LexerConfig::for_profile(registry.profile()),
    )
}

/// Build a method CFG using the module's already-prepared facts.
#[allow(clippy::too_many_arguments)]
pub(crate) fn build_cfg_method_function_with_prepared_context(
    name: &str,
    script: &Script,
    execution_namespace: crate::ir::ExecutionNamespace,
    inline_loops: bool,
    registry: &CommandRegistry,
    plain_command_dispatch: bool,
    context: &PreparedCfgContext,
    widen_oo_dispatch: bool,
    config: tcl_lexer::LexerConfig,
) -> Function {
    build_cfg_function_with_upvars_inner(
        name,
        script,
        execution_namespace,
        inline_loops,
        registry,
        plain_command_dispatch,
        context.context.clone(),
        widen_oo_dispatch,
        Some(context.command_classes.clone()),
        config,
    )
}

#[allow(clippy::too_many_arguments)]
fn build_cfg_function_with_upvars_inner(
    name: &str,
    script: &Script,
    execution_namespace: crate::ir::ExecutionNamespace,
    inline_loops: bool,
    registry: &CommandRegistry,
    plain_command_dispatch: bool,
    context: CfgContext,
    widen_oo_dispatch: bool,
    command_classes: Option<CfgCommandClasses>,
    config: tcl_lexer::LexerConfig,
) -> Function {
    let (upvar_procs, proc_params, global_write_procs, command_bindings, procedure_summary_owners) =
        context;
    let command_classes =
        command_classes.unwrap_or_else(|| CfgCommandClasses::from_registry(registry));
    let execution_namespace = script.execution_namespace(execution_namespace);
    let timeline = command_bindings.source_binding_timeline_from_boundary(
        script,
        registry,
        &execution_namespace,
    );
    let mut builder = CfgBuilder::new_with_upvars_and_classes(
        inline_loops,
        upvar_procs,
        proc_params,
        global_write_procs,
        command_bindings,
        registry,
        command_classes,
    )
    .with_procedure_summary_owners(procedure_summary_owners)
    .with_faithful_exceptions()
    .with_lexer_config(config)
    .with_command_surface(plain_command_dispatch)
    .with_invocation_namespace(execution_namespace)
    .with_source_binding_timeline(timeline);
    if widen_oo_dispatch {
        builder = builder.with_oo_dispatch_widening();
    }
    builder.build_function(name, script)
}

/// Whether a `catch` destination word is a plain scalar frame local, written
/// literally.
///
/// Anything needing substitution (`$dst`, `[cmd]`), an array element
/// (`a(key)`), a qualified name (`::ns::v`) or an empty word keeps the opaque
/// path, where the runtime resolves the word itself.
fn is_plain_local_destination(word: &str) -> bool {
    !word.is_empty()
        && !word.contains("::")
        && !word.contains(['$', '[', ']', '(', ')', '{', '}', '\\', ' ', '\t', '\n'])
}

fn command_namespace(qname: &str) -> String {
    let (holder, _) = tcl_syntax::naming::key_holder_and_tail(qname);
    if holder.is_empty() {
        "::".to_owned()
    } else {
        holder.to_owned()
    }
}

/// Deduplicate a `Vec` while preserving first-occurrence order.
fn dedup_preserve_order(v: &mut Vec<String>) {
    let mut seen = std::collections::HashSet::new();
    v.retain(|item| seen.insert(item.clone()));
}

// Registry-derived command classifications
//
// These are facts of one resolved release/dialect registry, not a
// process-global union. In particular Tcl 8.4 has no builtin `throw`; a
// procedure with that name is an ordinary fall-through call in that profile.
// The owning [`CfgBuilder`] carries the classes derived for its module and
// passes them through the recursive flow-fact helpers below.

/// The actual source metadata owner, separate from explicit compatibility.
pub(crate) use crate::registry_invocation::OwnedInvocationMetadataContext as CfgMetadataContext;

#[derive(Clone)]
struct CfgCommandClasses {
    /// Actual immutable command surface used by the shared invocation owner.
    registry: tcl_registry::RegistrySnapshot,
    metadata: CfgMetadataContext,
    /// The registry's one effective-spec index, shared with command-binding
    /// analysis. Classification stays trait-driven without rebuilding five
    /// complete name sets for every compilation unit.
    #[cfg(test)]
    semantics: Arc<EffectiveRegistrySemantics>,
}

impl CfgCommandClasses {
    fn proved_statement_command(stmt: &Statement) -> Option<&str> {
        let target = stmt
            .tokens()?
            .source_binding
            .as_ref()?
            .proved_execution_target()?;
        target.registry_backed.then_some(target.command.as_str())
    }
    fn from_registry(registry: &CommandRegistry) -> Self {
        Self {
            registry: registry.snapshot(),
            metadata: CfgMetadataContext::Standalone,
            #[cfg(test)]
            semantics: registry.effective_semantics_for_dialect(
                crate::environment_ingress::authoring_invocation_dialect(
                    registry,
                    None,
                    tcl_lexer::LexerConfig::default(),
                ),
            ),
        }
    }

    fn from_source_input(
        registry: &CommandRegistry,
        input: Option<&crate::analyser::ResolvedAnalysisInput>,
    ) -> Self {
        let mut classes = Self::from_registry(registry);
        classes.metadata = input
            .and_then(|input| {
                crate::registry_invocation::InvocationMetadataContext::for_analysis_input(
                    registry, input,
                )
                .map(|_| input)
            })
            .map_or(CfgMetadataContext::Unavailable, |input| {
                CfgMetadataContext::SuppliedSource(Box::new(input.clone()))
            });
        classes
    }

    fn from_metadata_input(
        registry: &CommandRegistry,
        input: crate::registry_invocation::InvocationMetadataInput<'_>,
    ) -> Self {
        let mut classes = Self::from_registry(registry);
        let retained = input.retain();
        classes.metadata = if retained.metadata_context(registry).is_some() {
            retained
        } else {
            CfgMetadataContext::Unavailable
        };
        classes
    }

    fn from_metadata(
        registry: &CommandRegistry,
        metadata: Option<Arc<tcl_registry::model::ContextRegistry>>,
    ) -> Self {
        let mut classes = Self::from_registry(registry);
        classes.metadata = metadata.map_or(
            CfgMetadataContext::Unavailable,
            CfgMetadataContext::Supplied,
        );
        classes
    }

    fn metadata_context(
        &self,
    ) -> Option<Option<crate::registry_invocation::InvocationMetadataContext<'_>>> {
        self.metadata
            .metadata_context(self.registry.registry())
            .map(crate::registry_invocation::InvocationMetadataSelection::context)
    }

    /// Source numeral grammar is independent of catalogue availability.
    fn source_numbers(&self, config: tcl_lexer::LexerConfig) -> tcl_syntax::number::Numbers {
        use tcl_syntax::number::Numbers;
        match &self.metadata {
            CfgMetadataContext::SuppliedSource(input)
                if input.lexer_config().normalized() == config.normalized()
                    && self.metadata_context().is_some() =>
            {
                Numbers::Target(config.grammar_over(input.unit_profile().grammar).numbers)
            }
            CfgMetadataContext::Standalone => {
                Numbers::of_profile(self.registry.registry().profile())
            }
            CfgMetadataContext::Supplied(_)
            | CfgMetadataContext::SuppliedSource(_)
            | CfgMetadataContext::Unavailable => Numbers::Unknown,
        }
    }

    fn resolved_tokens(
        &self,
        tokens: &CommandTokens,
    ) -> Option<crate::registry_invocation::ResolvedStatementInvocation> {
        crate::registry_invocation::resolved_tokens_invocation_with_metadata_context(
            self.registry.registry(),
            self.metadata_context()?,
            tokens,
        )
    }

    fn logical_structured_invocation(
        &self,
        tokens: &CommandTokens,
    ) -> Option<crate::registry_invocation::LogicalStructuredInvocation> {
        match &self.metadata {
            CfgMetadataContext::Supplied(context) => {
                crate::registry_invocation::logical_structured_invocation_with_metadata_context(
                    self.registry.registry(),
                    context.as_ref().into(),
                    tokens,
                    None,
                )
            }
            CfgMetadataContext::SuppliedSource(input) => {
                crate::registry_invocation::logical_structured_invocation_with_metadata_context(
                    self.registry.registry(),
                    crate::registry_invocation::InvocationMetadataContext::for_analysis_input(
                        self.registry.registry(),
                        input,
                    )?,
                    tokens,
                    None,
                )
            }
            CfgMetadataContext::Standalone => {
                crate::registry_invocation::logical_structured_invocation(
                    self.registry.registry(),
                    tokens,
                    None,
                )
            }
            CfgMetadataContext::Unavailable => None,
        }
    }

    fn conditional_source_completion_route(
        &self,
        tokens: &CommandTokens,
    ) -> Option<tcl_registry::completion_route::InvocationCompletionRoute> {
        let registry = self.registry.registry();
        let metadata = self
            .metadata_context()?
            .filter(|context| context.source_analysis_input().is_some())?;
        if let Some(route) =
            crate::registry_invocation::original_native_source_conditional_completion(
                registry, metadata, tokens,
            )
        {
            return Some(route);
        }
        let invocation = crate::registry_invocation::original_logical_operation_invocation_with_metadata_context(
            registry, metadata, tokens,
        )?;
        invocation.dialect?;
        Some(invocation.completion_route(registry))
    }

    fn exact_completion(
        &self,
        stmt: &Statement,
        resolve: &dyn Fn(&str) -> Option<crate::ir_helpers::ResolvedEmbeddedHead>,
    ) -> Option<tcl_registry::registry::ExactInvocationCompletion> {
        exact_statement_completion(
            stmt,
            self.registry.registry(),
            resolve,
            self.metadata_context()?
                .map(|context| context.context().authoring_query()),
        )
    }

    fn exits_process(
        &self,
        stmt: &Statement,
        resolve: &dyn Fn(&str) -> Option<crate::ir_helpers::ResolvedEmbeddedHead>,
    ) -> bool {
        self.exact_completion(stmt, resolve)
            == Some(tcl_registry::registry::ExactInvocationCompletion::ProcessExit)
    }

    fn completion_route(
        &self,
        stmt: &Statement,
    ) -> Option<tcl_registry::completion_route::InvocationCompletionRoute> {
        Self::proved_statement_command(stmt)?;
        let registry = self.registry.registry();
        self.resolved_tokens(stmt.tokens()?)
            .map(|invocation| invocation.completion_route(registry))
    }

    fn flow_completion(&self, stmt: &Statement) -> Completion {
        use tcl_registry::completion_route::InvocationCompletionRoute as Route;
        let Some(route) = self.completion_route(stmt) else {
            return Completion::Normal;
        };
        if route.normal_possible() {
            Completion::Normal
        } else if route.alternatives().iter().any(|route| {
            matches!(
                route,
                Route::Tcl(
                    tcl_registry::CompletionCode::Break | tcl_registry::CompletionCode::Continue
                )
            )
        }) {
            Completion::LoopJump
        } else {
            Completion::ProcExit
        }
    }

    #[cfg(test)]
    fn for_dialect(dialect: Option<&str>) -> Self {
        Self::from_registry(
            tcl_registry::model::ingress::static_context_for(dialect.unwrap_or("tcl")).commands(),
        )
    }

    #[cfg(test)]
    fn is_block_terminating_command(&self, command: &str) -> bool {
        self.semantics
            .command(command.trim_start_matches(':'))
            .is_some_and(|facts| {
                facts.has_traits(Traits::TERMINATES_BLOCK)
                    && facts.lowering_hook() != Some(LoweringHookId::Return)
            })
    }

    #[cfg(test)]
    fn is_tailcall_command(&self, command: &str) -> bool {
        self.semantics
            .command(command.trim_start_matches(':'))
            .is_some_and(|facts| facts.has_traits(Traits::REPLACES_FRAME))
    }

    #[cfg(test)]
    fn is_loop_break_command(&self, name: &str) -> bool {
        self.semantics
            .command(name)
            .is_some_and(|facts| facts.has_traits(Traits::BREAKS_LOOP))
    }

    #[cfg(test)]
    fn is_loop_continue_command(&self, name: &str) -> bool {
        self.semantics
            .command(name)
            .is_some_and(|facts| facts.has_traits(Traits::CONTINUES_LOOP))
    }
}

impl Default for CfgCommandClasses {
    fn default() -> Self {
        Self::from_registry(&CommandRegistry::build_default())
    }
}

// Definite-assignment ("flow facts") over un-lowered IR scripts
//
// Shared by the CFG builder (to promote an opaque `switch` whose every arm
// exits the *procedure* — FP-RBS-15 — and to wire its loop-jump edges) and
// by SSA (to recover the def set an opaque switch *definitely* establishes —
// FP-RBS-14).  Both consumers agree on one model.
//
// Each statement/script is classified by how it leaves: it can complete NORMALly
// (fall through to the next statement), jump within an enclosing loop (LoopJump
// — `break`/`continue`), or exit the procedure (ProcExit —
// `return`/`error`/`throw`/`exit`/`tailcall`).  The distinction matters for an
// *opaque* switch (whose arm bodies are not lowered into the CFG, so their
// loop-jump edges are invisible): a ProcExit arm reaches no later code at all,
// but a LoopJump arm still reaches the code after the enclosing loop *without*
// the other arms' definitions — so it must NOT be treated as vacuous when
// recovering the switch's defs, and an all-LoopJump switch is NOT a procedure
// terminator.

/// How a statement/script leaves: fall through, jump to an enclosing loop, or
/// exit the procedure.
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub(crate) enum Completion {
    /// Falls through to the next statement.
    Normal,
    /// `break` / `continue` — leaves to an enclosing-loop target (still reaches
    /// the code after that loop).
    LoopJump,
    /// `return` / `error` / `throw` / `exit` / `tailcall` — leaves the proc.
    ProcExit,
}

/// How a protected region's scripts split their statements into blocks in an
/// analysis build, so that every point at which the region can fail ends a
/// block an exception edge leaves from.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(super) enum SplitRegion {
    /// A flattened `catch` body: each of its straight-line statements, every
    /// block a split ends a point the end block is thrown to from.
    Catch,
    /// A `try` body: each statement of it and of every script it holds, save
    /// a nested `try` or `catch` body, which is a region of its own.
    Try,
}

impl SplitRegion {
    /// The prefix the blocks a split begins are named with.
    pub(super) const fn step(self) -> &'static str {
        match self {
            Self::Catch => "catch_step",
            Self::Try => "try_step",
        }
    }

    /// Whether the scripts the region's statements hold — an `if` arm, a loop
    /// body, a handler of a nested `try` — split too. A flattened `catch` body
    /// is straight-line statements and holds none.
    pub(super) const fn nested(self) -> bool {
        matches!(self, Self::Try)
    }

    /// Whether a statement that leaves from the state before it stays in the
    /// block before it ([`CfgBuilder::leaves_from_the_state_before`]), and a
    /// block a split ends is a point a throw leaves from only where one may
    /// ([`CfgBuilder::a_throw_may_leave_from`]): a `try`'s handlers select by
    /// completion, so an edge one cannot take is a path that never runs.
    pub(super) const fn selective(self) -> bool {
        matches!(self, Self::Try)
    }
}

/// A point a throw may leave a protected region from: the exit of a block a
/// split ends.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(super) struct SplitPoint {
    /// The block whose exit the point is.
    pub(super) block: String,
    /// Whether a statement of the block may leave after its own stores, with
    /// any code.
    pub(super) after_stores: bool,
    /// How the statement after the block fails before it stores.
    pub(super) next: NextFailure,
}

impl SplitPoint {
    /// A point anything may leave from: a body's tail, a throw point, or a
    /// point of a nested body that hands its ways out to the region around it.
    pub(super) fn any(block: String) -> Self {
        Self {
            block,
            after_stores: true,
            next: NextFailure::Any,
        }
    }

    /// Whether a throw may leave from the point at all.
    pub(super) fn may_leave(&self) -> bool {
        self.after_stores || self.next != NextFailure::Intercepted
    }

    /// Whether the statement after the point may fail before it stores with
    /// a code a target takes when `takes` says so.
    pub(super) fn next_fails_for(&self, takes: impl Fn(tcl_core_types::Code) -> bool) -> bool {
        match self.next {
            NextFailure::Intercepted => false,
            NextFailure::Error => takes(tcl_core_types::Code::Error),
            NextFailure::Any => true,
        }
    }
}

/// How a statement fails before it stores, for the state before it.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(super) enum NextFailure {
    /// It runs a clause of its own first — a `catch`, which takes every
    /// completion of its script, or a `try` with a `finally`, whose clause is
    /// the way out of it — so nothing leaves from the state before it.
    Intercepted,
    /// It raises an error if it fails at all: a literal assignment.
    Error,
    /// It may complete with any code.
    Any,
}

impl NextFailure {
    /// How `stmt` fails before it stores.
    pub(super) fn of(stmt: &Statement) -> Self {
        if matches!(
            stmt,
            Statement::Catch { .. }
                | Statement::Try {
                    finally_body: Some(_),
                    ..
                }
        ) {
            Self::Intercepted
        } else if is_literal_assignment(stmt) {
            Self::Error
        } else {
            Self::Any
        }
    }
}

/// Whether `stmt` assigns a literal to a name that substitutes nothing: it
/// completes normally or raises `TCL_ERROR` (the name is an array, a write
/// trace fails), never another code, and it raises before it stores.
pub(super) fn is_literal_assignment(stmt: &Statement) -> bool {
    matches!(stmt, Statement::AssignConst { name, name_braced, .. }
        if *name_braced || !name.contains('['))
}

/// Whether `stmt` certainly ends the interpreter, running no enclosing
/// `finally`: a process-terminating command (`Traits::TERMINATES_PROCESS`,
/// e.g. `exit`) that nothing can stop from running.
///
/// [`Completion`] folds `exit` into `ProcExit` with `return` and `error`,
/// which is right for what follows the statement and wrong for an enclosing
/// `finally`: a `return` runs it, an `exit` does not (tclsh 8.6.18 and 9.0.4:
/// `try {exit 7} finally {puts FINALLY}` prints nothing).
///
/// "Nothing can stop it" is the whole difficulty, and review found it three
/// ways: an earlier statement may `return`; the command's own words may throw
/// before it runs (`exit [error boom]` runs the clause); and so may a literal
/// word it rejects (`exit abc` raises "expected integer"; `exit 09` does in
/// 8.x). The same holds for an `if` condition or a `switch` subject in front
/// of an all-`exit` body — `switch -glob $nosuch {…}` throws on the unset
/// variable. So this accepts only the command itself, with every word
/// literal and a status the registry says it accepts, and an enclosing
/// construct is never looked through. Missing a real exit
/// costs an O107; accepting a false one rewrote a live program.
/// The completion `stmt` certainly produces, when the registry can say:
/// every word literal, the call resolved by the command-binding owner to one
/// registry-backed target, and that target's alias prefix joined to the
/// written words before the registry classifies the composed invocation.
///
/// Every word must be literal because a substituted one runs first and may
/// throw. The words must be *all* the words: `interp alias {} bye {} exit abc`
/// — or the same alias named `::foo::exit` and called as `exit` inside
/// `::foo` — raises "expected integer" (found in review). Whether a literal
/// is a status the command accepts is the registry's release-aware answer:
/// `exit 09` is an invalid octal in 8.x but status 9 in 9.0.
fn exact_statement_completion(
    stmt: &Statement,
    registry: &CommandRegistry,
    resolve: &dyn Fn(&str) -> Option<crate::ir_helpers::ResolvedEmbeddedHead>,
    query: Option<tcl_dialect::model::SurfaceQuery<'_>>,
) -> Option<tcl_registry::registry::ExactInvocationCompletion> {
    let (Statement::Call {
        command, tokens, ..
    }
    | Statement::Barrier {
        command, tokens, ..
    }) = stmt
    else {
        return None;
    };
    let tokens = tokens.as_ref()?;
    let dialect = tokens
        .source_binding
        .as_ref()
        .and_then(|binding| binding.variable_context.invocation_dialect)
        .or_else(|| {
            registry
                .profile()
                .map(tcl_registry::InvocationDialect::of_profile)
        });
    let config = dialect.map_or_else(tcl_lexer::LexerConfig::default, |dialect| {
        tcl_lexer::LexerConfig::from_grammar(dialect.lexer_grammar)
    });
    let rules = tcl_syntax::word_rules::WordValueRules::from_config(&config);
    let literal =
        |word: &crate::ir::WordExpr| match crate::registry_invocation::effective_invocation_word(
            word,
            config.escapes,
            rules,
        ) {
            crate::registry_invocation::EffectiveInvocationWord::Literal(value) => Some(value),
            _ => None,
        };
    // Words execute before dispatch. An exact command completion cannot hide
    // an error from a substituted head or argument.
    tokens
        .words()
        .iter()
        .map(literal)
        .collect::<Option<Vec<_>>>()?;
    let (target, values) = if tokens.source_binding.is_some() {
        let target = tokens
            .source_binding
            .as_ref()?
            .proved_execution_target()?
            .clone();
        if !target.registry_backed {
            return None;
        }
        let effective = crate::registry_invocation::effective_command_words(tokens)?;
        let values = effective
            .words
            .iter()
            .skip(1)
            .map(literal)
            .collect::<Option<Vec<_>>>()?;
        (target.command, values)
    } else {
        let target = resolve(command)?;
        let values = target
            .prepended
            .into_iter()
            .chain(
                tokens
                    .words()
                    .iter()
                    .skip(1)
                    .map(literal)
                    .collect::<Option<Vec<_>>>()?,
            )
            .collect();
        (target.command, values)
    };
    let words: Vec<_> = values.iter().map(String::as_str).collect();
    let mut arguments = tcl_registry::InvocationArguments::literals(&words);
    if let Some(dialect) = dialect {
        arguments = arguments.with_dialect(dialect);
    }
    registry.exact_invocation_completion_words(&target, arguments, query)
}

fn structural_write_roots(stmt: &Statement) -> Option<Vec<String>> {
    let projection = crate::ir_helpers::structural_variable_write_projection(stmt);
    if projection.opaque_variable_frame {
        return None;
    }
    Some(
        projection
            .literal_names
            .into_iter()
            .map(|name| {
                tcl_syntax::naming::split_element_ref(&name)
                    .map_or(name.as_str(), |(root, _)| root)
                    .to_owned()
            })
            .collect(),
    )
}

/// `(must-defines, completion)` for a single statement.
///
/// * assignments (`set`/`incr`/`expr`-assign) contribute their target and
///   complete normally; a plain `Call` contributes its synthetic `defs` and
///   completes normally — *except* `error`/`throw`/`exit` and `tailcall`, which
///   `ProcExit`, and `break`/`continue`, which `LoopJump`; `Return` and a
///   `return -code` / expansion `Barrier` `ProcExit`;
/// * `Block` / `UpFrame` bodies always run, so recurse;
/// * an `If` *with* an else, or a `Switch` *with* a default, combine their
///   branches via [`intersect_completing`]; an else-less `If` / default-less
///   `Switch` has a fall-through path, so it completes normally assigning
///   nothing for certain;
/// * loops (`For`/`While`/`Foreach`), `Catch`/`Try` and everything else may not
///   execute / always complete (`catch` even swallows `break`), so they
///   contribute no must-define and complete normally.
fn flow_facts_stmt_with_classes(
    stmt: &Statement,
    command_classes: &CfgCommandClasses,
) -> (BTreeSet<String>, Completion) {
    match stmt {
        Statement::AssignConst { .. }
        | Statement::AssignExpr { .. }
        | Statement::AssignValue { .. }
        | Statement::Incr { .. } => (
            structural_write_roots(stmt)
                .unwrap_or_default()
                .into_iter()
                .collect(),
            Completion::Normal,
        ),
        Statement::Return { .. } => (BTreeSet::new(), Completion::ProcExit),
        Statement::Barrier { .. } => (BTreeSet::new(), command_classes.flow_completion(stmt)),
        Statement::Call { defs, .. } => (
            defs.iter().cloned().collect(),
            command_classes.flow_completion(stmt),
        ),
        Statement::Block { body, .. } | Statement::UpFrame { body, .. } => {
            flow_facts_script_with_classes(body, command_classes)
        }
        Statement::If {
            clauses,
            else_body: Some(eb),
            ..
        } => {
            let mut bodies: Vec<&Script> = clauses.iter().map(|c| &c.body).collect();
            bodies.push(eb);
            intersect_completing(&bodies, command_classes)
        }
        Statement::Switch {
            arms,
            default_body: Some(default),
            ..
        } => {
            let mut bodies: Vec<&Script> = vec![default];
            bodies.extend(arms.iter().filter_map(|arm| arm.body.as_ref()));
            intersect_completing(&bodies, command_classes)
        }
        // An else-less `If` / default-less `Switch` has a fall-through path that
        // assigns nothing for certain; everything else may not run / always
        // completes.
        _ => (BTreeSet::new(), Completion::Normal),
    }
}

/// Profile-less compatibility entry point. Module CFG construction uses the
/// release-aware `*_with_classes` path owned by its [`CfgBuilder`].
#[cfg(test)]
pub(crate) fn flow_facts_stmt(stmt: &Statement) -> (BTreeSet<String>, Completion) {
    flow_facts_stmt_with_classes(stmt, &CfgCommandClasses::default())
}

/// `(vars definitely assigned, completion)` for an un-lowered IR script.
///
/// Walk statements in order accumulating must-defines; the first statement that
/// does not complete normally makes the rest dead and gives the script that
/// statement's completion (`ProcExit` or `LoopJump`), with the must-defines
/// being those accumulated up to (and including) it.  Only names guaranteed to
/// be assigned are returned, so it never over-claims (which would hide a real
/// read-before-set).
fn flow_facts_script_with_classes(
    script: &Script,
    command_classes: &CfgCommandClasses,
) -> (BTreeSet<String>, Completion) {
    let mut assigned = BTreeSet::new();
    for stmt in &script.statements {
        let (defs, completion) = flow_facts_stmt_with_classes(stmt, command_classes);
        assigned.extend(defs);
        if completion != Completion::Normal {
            return (assigned, completion);
        }
    }
    (assigned, Completion::Normal)
}

/// Combine branch bodies into `(must-defines, completion)`.
///
/// A `ProcExit` branch reaches no code after the construct, so it is vacuous
/// (⊤) and excluded from the must-define intersection.  A `Normal` or
/// `LoopJump` branch *does* reach later code (the fall-through successor, or —
/// for a loop jump — the code after the enclosing loop), so its must-defines
/// (those established before it leaves) ARE intersected: this keeps the result
/// sound when a `break`/`continue` arm escapes an opaque switch without the
/// other arms' defs.  The combined completion is `Normal` if any branch falls
/// through, else `LoopJump` if any jumps, else `ProcExit` (every branch exits).
fn intersect_completing(
    bodies: &[&Script],
    command_classes: &CfgCommandClasses,
) -> (BTreeSet<String>, Completion) {
    let mut common: Option<BTreeSet<String>> = None;
    let mut any_normal = false;
    let mut any_loop_jump = false;
    for body in bodies {
        let (assigned, completion) = flow_facts_script_with_classes(body, command_classes);
        match completion {
            Completion::ProcExit => continue,
            Completion::Normal => any_normal = true,
            Completion::LoopJump => any_loop_jump = true,
        }
        common = Some(match common {
            None => assigned,
            Some(acc) => acc.intersection(&assigned).cloned().collect(),
        });
    }
    let combined = if any_normal {
        Completion::Normal
    } else if any_loop_jump {
        Completion::LoopJump
    } else {
        Completion::ProcExit
    };
    (common.unwrap_or_default(), combined)
}

/// Variables an opaque `switch` assigns on *every* non-proc-exit path.
///
/// Empty unless the switch has a `default` arm (otherwise an unmatched subject
/// falls through assigning nothing).  Intersection over the default and every
/// arm-with-a-body, excluding only arms that exit the procedure (which reach no
/// later code).  A `break`/`continue` arm is *kept* (with the defs it makes
/// before jumping), because it still reaches the code after the enclosing loop —
/// so an arm that breaks without assigning `y` correctly drops `y` rather than
/// letting it be claimed defined.
pub(crate) fn switch_must_defines(
    stmt: &Statement,
    registry: Option<&CommandRegistry>,
) -> BTreeSet<String> {
    let command_classes = registry.map_or_else(CfgCommandClasses::default, |registry| {
        CfgCommandClasses::from_registry(registry)
    });
    flow_facts_stmt_with_classes(stmt, &command_classes).0
}

/// Must-defined source names under the supplied complete availability owner.
/// Missing input keeps completion metadata unavailable; it does not select the
/// standalone catalogue. Original structural writes retain their IR ownership.
pub(crate) fn switch_must_defines_with_source_input(
    stmt: &Statement,
    registry: &CommandRegistry,
    input: Option<&crate::analyser::ResolvedAnalysisInput>,
) -> BTreeSet<String> {
    if input.is_none() {
        return BTreeSet::new();
    }
    let command_classes = CfgCommandClasses::from_source_input(registry, input);
    if command_classes.metadata_context().is_none() {
        return BTreeSet::new();
    }
    flow_facts_stmt_with_classes(stmt, &command_classes).0
}

/// `(can_break, can_continue)` for `break`/`continue` that escape *script* to an
/// enclosing loop.
///
/// Recurses into `if`/`switch`/`Block`/`UpFrame` bodies (which don't capture a
/// loop jump) and into `try` — a `try` does NOT capture `break`/`continue`:
/// without a matching `on`/`trap` handler a jump in the body, a handler body, or
/// the `finally` body propagates to the enclosing loop (confirmed in tclsh
/// 9.0.3, contrast `catch {break}` which yields code 3 and is absorbed).  Does
/// NOT recurse into nested loops (`for`/`while`/`foreach`) or `catch`, which
/// capture their own jumps.  Scanning stops at the first statement that cannot
/// complete normally (`return`/`error`/`exit`/`tailcall`, or `break`/`continue`
/// itself): a jump after it is dead code that never executes, so it must not
/// create a spurious loop-exit edge.
/// `depth` is the nesting level of `script` — reuses [`MAX_LOWER_DEPTH`]
/// (this walk is mutually recursive with [`switch_escaping_jumps`], and
/// both are transitively bounded today via the same cap `lower_script`
/// already builds every `Script` under, so this is defence-in-depth /
/// consistency with that cap rather than a currently-reachable path).
fn escaping_loop_jumps_with_classes(
    script: &Script,
    depth: u32,
    command_classes: &CfgCommandClasses,
) -> (bool, bool) {
    if MAX_LOWER_DEPTH.exceeded(depth) {
        return (false, false);
    }
    let mut can_break = false;
    let mut can_continue = false;
    for stmt in &script.statements {
        // An opaque arm is conditional source, so it need not have an actual
        // handler visit. Its retained source schema can still establish the
        // completion when that arm runs, without granting execution authority.
        let completion = command_classes
            .completion_route(stmt)
            .or_else(|| command_classes.conditional_source_completion_route(stmt.tokens()?));
        match stmt {
            Statement::Call { .. } => {
                if let Some(route) = &completion {
                    for route in route.alternatives() {
                        match route {
                            tcl_registry::completion_route::InvocationCompletionRoute::Tcl(
                                tcl_registry::CompletionCode::Break,
                            ) => can_break = true,
                            tcl_registry::completion_route::InvocationCompletionRoute::Tcl(
                                tcl_registry::CompletionCode::Continue,
                            ) => can_continue = true,
                            _ => {}
                        }
                    }
                }
            }
            Statement::If {
                clauses, else_body, ..
            } => {
                for clause in clauses {
                    let (b, c) =
                        escaping_loop_jumps_with_classes(&clause.body, depth + 1, command_classes);
                    can_break |= b;
                    can_continue |= c;
                }
                if let Some(eb) = else_body {
                    let (b, c) = escaping_loop_jumps_with_classes(eb, depth + 1, command_classes);
                    can_break |= b;
                    can_continue |= c;
                }
            }
            Statement::Switch { .. } => {
                let (b, c) = switch_escaping_jumps_with_classes(stmt, depth, command_classes);
                can_break |= b;
                can_continue |= c;
            }
            Statement::Block { body, .. } | Statement::UpFrame { body, .. } => {
                let (b, c) = escaping_loop_jumps_with_classes(body, depth + 1, command_classes);
                can_break |= b;
                can_continue |= c;
            }
            Statement::Try {
                body,
                handlers,
                finally_body,
                ..
            } => {
                let (b, c) = escaping_loop_jumps_with_classes(body, depth + 1, command_classes);
                can_break |= b;
                can_continue |= c;
                for h in handlers {
                    let (b, c) =
                        escaping_loop_jumps_with_classes(&h.body, depth + 1, command_classes);
                    can_break |= b;
                    can_continue |= c;
                }
                if let Some(fb) = finally_body {
                    let (b, c) = escaping_loop_jumps_with_classes(fb, depth + 1, command_classes);
                    can_break |= b;
                    can_continue |= c;
                }
            }
            _ => {}
        }
        // A statement that cannot complete normally makes everything after it
        // dead code (a later `break`/`continue` never runs), so stop scanning —
        // otherwise a dead `break` after `error`/`return` would forge a
        // loop-exit edge and fire W210 on unreachable post-loop code.
        if completion.is_some_and(|route| !route.normal_possible())
            || flow_facts_stmt_with_classes(stmt, command_classes).1 != Completion::Normal
        {
            break;
        }
    }
    (can_break, can_continue)
}

/// Profile-less compatibility entry point. Module CFG construction uses the
/// release-aware `*_with_classes` path owned by its [`CfgBuilder`].
#[cfg(test)]
pub(crate) fn escaping_loop_jumps(script: &Script, depth: u32) -> (bool, bool) {
    escaping_loop_jumps_with_classes(script, depth, &CfgCommandClasses::default())
}

/// `(can_break, can_continue)` over all bodies of an opaque `switch`.
/// `depth` is `stmt`'s own nesting level — see
/// [`escaping_loop_jumps_with_classes`].
fn switch_escaping_jumps_with_classes(
    stmt: &Statement,
    depth: u32,
    command_classes: &CfgCommandClasses,
) -> (bool, bool) {
    let Statement::Switch {
        arms, default_body, ..
    } = stmt
    else {
        return (false, false);
    };
    let mut can_break = false;
    let mut can_continue = false;
    if let Some(default) = default_body {
        let (b, c) = escaping_loop_jumps_with_classes(default, depth + 1, command_classes);
        can_break |= b;
        can_continue |= c;
    }
    for arm in arms {
        if let Some(body) = &arm.body {
            let (b, c) = escaping_loop_jumps_with_classes(body, depth + 1, command_classes);
            can_break |= b;
            can_continue |= c;
        }
    }
    (can_break, can_continue)
}

// Guaranteed-iteration loops
//
// A loop whose body provably runs at least once does not skip its body, so a
// variable the body assigns is defined when code after the loop reads it.  The
// usual CFG models every loop as possibly running zero times (the header's exit
// edge), false-firing W210 on such a read.  In analysis builds we *rotate* a
// provably-non-empty loop so the 0-iteration skip becomes a *separate*
// entry-guard edge whose condition is statically true; SCCP marks that edge dead
// and the FP-RBS-16 dead-edge phi filter then ignores the version-0 operand it
// carried — with no synthetic def, so SCCP values are untouched.  `break` /
// `continue` stay real CFG edges, so partial-def exits remain sound.

/// True when `text` is a static, non-empty Tcl list literal.
///
/// Conservative: any `$` / `[` (a possible substitution) disqualifies it, so a
/// runtime-computed list is never claimed non-empty.  `foreach` stores a braced
/// list with its outer braces stripped (`{1 2 3}` → `1 2 3`), so a literal
/// splits directly.
fn list_literal_nonempty(text: &str, rules: tcl_syntax::word_rules::WordValueRules) -> bool {
    if text.is_empty() || text.contains('$') || text.contains('[') {
        return false;
    }
    !crate::tcl_expr_eval::split_tcl_list(text, rules).is_empty()
}

/// True when a `foreach`/`lmap` provably iterates ≥1 time.
///
/// `foreach` runs `max` over its iterator groups, so *any* non-empty iterator
/// list guarantees at least one iteration (shorter lists just pad their loop
/// vars with `""`).
pub(crate) fn foreach_runs_at_least_once(
    stmt: &Statement,
    rules: tcl_syntax::word_rules::WordValueRules,
) -> bool {
    let Statement::Foreach { iterators, .. } = stmt else {
        return false;
    };
    iterators
        .iter()
        .any(|it| list_literal_nonempty(&it.list_arg, rules))
}

impl CfgBuilder<'_> {
    /// Names a non-`AssignConst` init statement may write.  `None` means "can't
    /// tell" — the caller then drops *all* constant bindings (a write it can't
    /// characterise might clobber any of them).
    ///
    /// A `Call`'s write set includes the caller-side variables an `upvar`-using
    /// callee modifies (direct call or `[upvar_proc …]` embedded substitution),
    /// recovered via [`Self::apply_upvar_invalidation`] — the module upvar pass
    /// adds these to a call's `defs`, but they are absent from the raw IR the
    /// init clause carries.  Without this, `for {set i 0; setter} {$i < 3} …`
    /// where `setter` runs `upvar 1 i i; set i 5` would keep the stale
    /// `i = 0` binding and be wrongly judged guaranteed.
    fn init_written_names(&self, stmt: &Statement) -> Option<Vec<String>> {
        let mut names: Vec<String> = match stmt {
            Statement::AssignValue { .. }
            | Statement::AssignExpr { .. }
            | Statement::Incr { .. } => structural_write_roots(stmt)?,
            // A plain call contributes only the (augmented) defs collected
            // below.
            Statement::Call { .. } => Vec::new(),
            // Any other statement shape in the init (a nested if/loop/…) is not
            // characterised here — clear every constant binding to stay sound.
            _ => return None,
        };
        for s in self.upvar_invalidated(stmt.clone()) {
            // A widening barrier means the callee can write ANY caller
            // variable (an `upvar` with a dynamic caller-side name) — no
            // per-name set exists, so report "can't tell" and let the
            // caller drop every constant binding.
            if matches!(s, Statement::Barrier { .. }) {
                return None;
            }
            if let Statement::Call { defs, .. } = &s {
                for d in defs {
                    if !names.contains(d) {
                        names.push(d.clone());
                    }
                }
            }
        }
        Some(names)
    }

    /// True when a `for` loop's condition is statically true on entry.
    ///
    /// Evaluates the condition against the constant bindings the init clause
    /// establishes (`for {set i 0} {$i < 3} …` → `i = 0` → `0 < 3` is true),
    /// which proves the first iteration always runs.  Init statements are
    /// processed in order: an `AssignConst` (re)binds a constant, but any
    /// *other* write *invalidates* that variable's binding — so
    /// `for {set i 0; set i $n} …` and `for {set i 0; incr i 5} …` leave `i`
    /// unknown rather than stale-constant `0`, and an `upvar`-writing call in
    /// the init invalidates the var it writes through the caller frame.
    /// Conservative: a condition referencing an unbound variable (or
    /// a command-substitution condition) evaluates to `None` → not guaranteed.
    pub(crate) fn for_runs_at_least_once(&self, stmt: &Statement) -> bool {
        use crate::tcl_expr_eval::TclValue;
        let Statement::For {
            init, condition, ..
        } = stmt
        else {
            return false;
        };
        let mut env: crate::tcl_expr_eval::Env = std::collections::HashMap::new();
        for s in &init.statements {
            if let Statement::AssignConst { value, .. } = s {
                let projection = crate::ir_helpers::structural_variable_write_projection(s);
                if projection.opaque_variable_frame {
                    env.clear();
                } else {
                    for name in projection.literal_names {
                        if let Some((root, _)) = tcl_syntax::naming::split_element_ref(&name) {
                            env.remove(root);
                        } else {
                            env.insert(name, coerce_scalar(value));
                        }
                    }
                }
                continue;
            }
            match self.init_written_names(s) {
                // Unknown write — every prior constant binding is now suspect.
                None => env.clear(),
                Some(names) => {
                    for n in names {
                        env.remove(&n);
                    }
                }
            }
        }
        match crate::tcl_expr_eval::eval_tcl_expr_with_policy(
            condition,
            &env,
            crate::tcl_expr_eval::FoldPolicy::from_registry(self.registry),
        ) {
            Some(TclValue::Int(i)) => i != 0,
            Some(TclValue::Float(f)) => f != 0.0,
            // A bignum is canonical (beyond i64), hence never zero.
            Some(TclValue::Big(_)) => true,
            None => false,
        }
    }
}

/// Coerce a literal assignment value to int/float when possible (else str),
/// for the `for`-init constant environment.
fn coerce_scalar(text: &str) -> crate::tcl_expr_eval::EnvValue {
    use crate::tcl_expr_eval::EnvValue;
    if let Ok(i) = text.parse::<i64>() {
        return EnvValue::Int(i);
    }
    if let Ok(f) = text.parse::<f64>() {
        return EnvValue::Float(f);
    }
    EnvValue::Str(text.to_owned())
}

#[cfg(test)]
mod tests {
    use crate::interprocedural::test_body_identity::{fixture_id, fixture_id_if_present};

    use super::*;
    fn summary_id(module: &Module, label: &str) -> crate::ir::ProcedureId {
        let matching: Vec<_> = module
            .original_source_procedure_bodies()
            .filter(|(_, procedure)| {
                procedure.qualified_name == label
                    || procedure.name == label
                    || tcl_syntax::naming::key_tail(&procedure.name) == label
            })
            .map(|(id, _)| *id)
            .collect();
        assert_eq!(
            matching.len(),
            1,
            "authored fixture summary {label:?} must identify one body"
        );
        matching[0]
    }

    use crate::ir::{ForeachIterator, IfClause, Script, SwitchArm, SwitchMode};
    use tcl_lexer::Span;

    #[test]
    fn folded_eval_keeps_a_separate_executable_compilation_boundary() {
        let registry = native_registry();
        let module = crate::lowering::lower_to_ir(
            "proc p {} {eval {set later CHILD}; set later PARENT; return $later}",
            &registry,
        );
        let procedure = module
            .procedures
            .get(&fixture_id(&module.procedures, "::p"))
            .expect("authored fixture body");
        let block = procedure
            .body
            .statements
            .iter()
            .find(|statement| {
                matches!(
                    statement,
                    Statement::Block {
                        error_context: Some(
                            tcl_registry::InlineBodyErrorContext::SameFrameScriptEvaluation
                        ),
                        ..
                    }
                )
            })
            .expect("folded logical eval body");
        let original = block.tokens().expect("original invocation");
        let executable = build_cfg_codegen_with_registry(&module, false, &registry);
        let function = executable
            .procedures
            .get(&fixture_id(&executable.procedures, "::p"))
            .expect("authored fixture body");
        let boundary = function
            .blocks
            .values()
            .flat_map(|block| &block.statements)
            .find_map(|statement| match statement {
                Statement::Barrier {
                    tokens: Some(tokens),
                    args,
                    ..
                } if tokens.argv_texts == original.argv_texts => Some((tokens, args)),
                _ => None,
            })
            .expect("runtime eval invocation");
        assert_eq!(boundary.0, original);
        assert_eq!(boundary.1, &original.argv_texts[1..]);
        assert!(!function.blocks.values().flat_map(|block| &block.statements)
            .any(|statement| matches!(statement, Statement::AssignConst { value, .. } if value == "CHILD")));
        let analysis = build_cfg_with_registry(&module, false, &registry);
        assert!(
            analysis
                .procedures
                .get(&fixture_id(&analysis.procedures, "::p"))
                .expect("authored fixture body")
                .blocks
                .values()
                .flat_map(|block| &block.statements)
                .any(|statement| {
                    if matches!(statement, Statement::AssignConst { value, .. } if value == "CHILD")
                    {
                        return true;
                    }
                    statement.tokens().is_some_and(|tokens| {
                        crate::registry_invocation::advisory_value_assignments(&registry, tokens)
                            .iter()
                            .any(|assignment| {
                                assignment.name == "later"
                                    && assignment.value.legacy_text() == "CHILD"
                            })
                    })
                })
        );
        let assembly = crate::codegen::codegen_module(&executable, &module, &registry)
            .expect("original source namespace");
        let body = assembly.procedures.values().next().expect("compiled p");
        assert!(body.lvt.find_bytes(b"later").is_some());
        assert!(
            !body
                .literals
                .entries()
                .iter()
                .any(|literal| literal.bytes() == b"CHILD")
        );
        assert!(
            body.literals
                .entries()
                .iter()
                .any(|literal| literal.bytes() == b"set later CHILD")
        );
    }

    fn native_registry() -> CommandRegistry {
        CommandRegistry::build_default().project_for_profile(
            tcl_registry::model::ingress::resolve_environment("tcl9.1").analyser_profile(),
        )
    }

    fn build_test_cfg_function(name: &str, script: &Script, inline_loops: bool) -> Function {
        let registry = native_registry();
        CfgBuilder::new(inline_loops, &registry)
            .with_lexer_config(tcl_lexer::LexerConfig::for_profile(registry.profile()))
            .with_faithful_exceptions()
            .with_invocation_namespace(crate::ir::ExecutionNamespace::exact(command_namespace(
                name,
            )))
            .build_function(name, script)
    }

    /// The registry-derived commands which leave a procedure when they appear
    /// as ordinary calls. Keep test data tied to traits rather than duplicating
    /// command names alongside the production lookup.
    fn proc_exit_host_commands() -> Vec<String> {
        let classes = CfgCommandClasses::for_dialect(Some("tcl9.0"));
        let mut commands: Vec<_> = classes
            .semantics
            .command_names_with_traits(Traits::TERMINATES_BLOCK)
            .filter(|name| {
                classes
                    .semantics
                    .command(name)
                    .is_some_and(|facts| facts.lowering_hook() != Some(LoweringHookId::Return))
            })
            .chain(
                classes
                    .semantics
                    .command_names_with_traits(Traits::REPLACES_FRAME),
            )
            .map(str::to_owned)
            .collect();
        commands.sort_unstable();
        commands.dedup();
        commands
    }

    fn host_tokens(command: &str) -> CommandTokens {
        let registry = native_registry();
        let mut lowerer = crate::lowering::Lowerer::new(&registry);
        let module = lowerer.lower(command);
        module.top_level.statements[0]
            .tokens()
            .expect("real source invocation proof")
            .clone()
    }

    fn host_call(command: String) -> Statement {
        let tokens = host_tokens(&command);
        Statement::Call {
            span: Span::new(0, u32::try_from(command.len()).unwrap()),
            command,
            canonical_command: None,
            args: Vec::new(),
            defs: Vec::new(),
            reads: Vec::new(),
            reads_own_defs: false,
            safe_on_uninit: false,
            tokens: Some(tokens),
            foreach_groups: None,
        }
    }

    fn host_barrier(command: String) -> Statement {
        let tokens = host_tokens(&command);
        Statement::Barrier {
            span: Span::new(0, u32::try_from(command.len()).unwrap()),
            reason: "opaque host command".into(),
            command,
            canonical_command: None,
            args: Vec::new(),
            tokens: Some(tokens),
        }
    }

    fn build_analysis_cfg(name: &str, script: &Script) -> Function {
        CfgBuilder::new(true, tcl_registry::default_registry())
            .with_faithful_exceptions()
            .build_function(name, script)
    }

    fn proc_exit_barrier_switch(mode: SwitchMode) -> Script {
        let commands = proc_exit_host_commands();
        let arms = commands
            .iter()
            .enumerate()
            .map(|(i, command)| SwitchArm {
                pattern: i.to_string(),
                pattern_braced: true,
                pattern_span: Span::new(0, 1),
                // Exercise absolute spellings inside both flattened and opaque
                // switch paths; classification must normalise the `::` prefix.
                body: Some(Script::from_statements(vec![host_barrier(format!(
                    "::{command}"
                ))])),
                body_span: Some(Span::new(0, 1)),
                fallthrough: false,
            })
            .collect();
        Script::from_statements(vec![Statement::Switch {
            subject_braced: false,
            raw_arg_braced: Vec::new(),
            raw_arg_quoted: Vec::new(),
            command: "switch".into(),
            span: Span::new(0, 1),
            subject: "$which".into(),
            subject_span: Span::new(0, 1),
            arms,
            default_body: Some(Script::from_statements(vec![host_barrier(format!(
                "::{}",
                commands[0]
            ))])),
            default_span: Some(Span::new(0, 1)),
            mode,
            nocase: false,
            raw_args: Vec::new(),
            patterns_braced: true,
        }])
    }

    /// Drift guard: the registry-derived classification sets must equal the
    /// name lists pinned here, so a trait stamping change is a conscious
    /// CFG-shape decision rather than a silent one.
    #[test]
    fn registry_derived_cfg_classes_match_previous_hardcodes() {
        fn sorted(classes: &CfgCommandClasses, traits: Traits) -> Vec<&str> {
            let mut v: Vec<&str> = classes
                .semantics
                .command_names_with_traits(traits)
                .collect();
            v.sort_unstable();
            v
        }
        let classes = CfgCommandClasses::for_dialect(Some("tcl9.0"));
        // `return` carries TERMINATES_BLOCK but lowers to
        // `Statement::Return`, so the name-keyed terminator set excludes it.
        let mut terminates = sorted(&classes, Traits::TERMINATES_BLOCK);
        terminates.retain(|name| {
            classes
                .semantics
                .command(name)
                .is_some_and(|facts| facts.lowering_hook() != Some(LoweringHookId::Return))
        });
        assert_eq!(terminates, ["error", "exit", "throw"]);
        assert_eq!(
            sorted(&classes, Traits::CATCHABLE_THROW),
            ["error", "throw"]
        );
        assert_eq!(sorted(&classes, Traits::REPLACES_FRAME), ["tailcall"]);
        assert_eq!(sorted(&classes, Traits::BREAKS_LOOP), ["break"]);
        assert_eq!(sorted(&classes, Traits::CONTINUES_LOOP), ["continue"]);

        let tcl84 = CfgCommandClasses::for_dialect(Some("tcl8.4"));
        assert!(
            !tcl84.is_block_terminating_command("throw")
                && !tcl84
                    .semantics
                    .command("throw")
                    .is_some_and(|facts| facts.has_traits(Traits::CATCHABLE_THROW)),
            "Tcl 8.4 must select its visible spec set, not inherit later `throw` traits"
        );
    }

    #[test]
    fn observed_completion_never_manufactures_a_procedure_return() {
        use tcl_registry::completion::CompletionCode;
        use tcl_registry::completion_route::InvocationCompletionRoute as Route;
        let registry = native_registry().project_for_profile(
            tcl_registry::model::ingress::resolve_environment("tcl8.6").analyser_profile(),
        );
        for (source, expected) in [
            ("return -level 0 VALUE; set reached 1", None),
            ("return -level $level VALUE; set reached 1", None),
            (
                "return -code error -level 0 BOOM; set reached 1",
                Some(Route::Tcl(CompletionCode::Error)),
            ),
            ("exit 0; set reached 1", Some(Route::ProcessExit)),
        ] {
            let module = crate::lowering::lower_to_ir(source, &registry);
            let cfg = build_cfg_with_registry(&module, false, &registry);
            let entry = &cfg.top_level.blocks[&cfg.top_level.entry];
            if let Some(expected) = expected {
                assert!(
                    matches!(entry.terminator, Some(Terminator::Complete {route, ..}) if route == expected),
                    "{source}: {entry:?}"
                );
            } else {
                assert!(
                    !matches!(
                        entry.terminator,
                        Some(Terminator::Complete { .. } | Terminator::Return { .. })
                    ),
                    "{source}: {entry:?}"
                );
                assert!(entry.statements.iter().any(|statement| matches!(statement,
                    Statement::AssignConst {name, ..} | Statement::AssignValue {name, ..} if name == "reached")), "{source}: {entry:?}");
            }
        }
    }

    #[test]
    fn cfg_and_binding_analysis_retain_the_same_registry_generation() {
        let registry = native_registry();
        let module = crate::lowering::lower_to_ir("set value 1", &registry);
        let bindings = ModuleCommandBindings::analyse(&module, &registry);
        let classes = CfgCommandClasses::from_registry(&registry);

        assert!(Arc::ptr_eq(
            &registry.effective_semantics(),
            &module.resolved_registry().effective_semantics(),
        ));
        // The actual entry roster is narrower than catalogue assistance. Both
        // projections query the same frozen registry generation.
        assert!(bindings.effective_semantics().command("set").is_some());
        assert!(classes.semantics.command("set").is_some());
    }

    #[test]
    fn prepared_cfg_source_metadata_preserves_availability_and_refuses_missing_owners() {
        // naming.compiler.original-analysis-metadata-context
        // docs/design/analysis/name-resolution-proofs/original-analysis-metadata-context.md
        let generation = tcl_registry::model::ingress::static_context_for("tcl8.6");
        let context = Arc::new(generation.with_command_store(Arc::clone(generation.commands())));
        let registry = generation.commands();
        let config = tcl_lexer::LexerConfig::for_dialect("tcl8.6");
        let mut lowerer = crate::lowering::Lowerer::with_config(registry, config)
            .with_dialect(registry.profile())
            .with_context_registry(Arc::clone(&context));
        let module = lowerer.lower("throw ERROR payload").clone();
        let statement = &module.top_level.statements[0];
        let tokens = statement.tokens().expect("original command words");
        let prepared = prepare_cfg_context_bundle(&module, registry);
        assert!(
            prepared
                .command_classes
                .logical_structured_invocation(tokens)
                .is_some()
        );
        let older = Arc::new(
            tcl_registry::model::ingress::static_context_for("tcl8.4")
                .with_command_store(Arc::clone(registry)),
        );
        let original = module
            .source_metadata_input
            .as_ref()
            .expect("retained metadata");
        let input = crate::analyser::ResolvedAnalysisInput::new(
            original.analyser_profile(),
            original.unit_profile(),
            older,
            original.lexer_config(),
        );
        let unavailable =
            PreparedCfgContext::from_source_input(prepared.context.clone(), registry, Some(&input));
        assert!(
            unavailable
                .command_classes
                .logical_structured_invocation(tokens)
                .is_none()
        );
        assert!(
            unavailable
                .command_classes
                .completion_route(statement)
                .is_none()
        );
        let foreign = CfgCommandClasses::from_metadata(
            registry,
            Some(tcl_registry::model::ingress::context_for_profile(
                tcl_registry::model::ingress::resolve_environment("tcl9.1").analyser_profile(),
            )),
        );
        assert!(foreign.logical_structured_invocation(tokens).is_none());
        assert!(foreign.resolved_tokens(tokens).is_none());
        let absent =
            PreparedCfgContext::from_source_input(prepared.context.clone(), registry, None);
        assert!(
            absent
                .command_classes
                .logical_structured_invocation(tokens)
                .is_none()
        );
        assert!(absent.command_classes.resolved_tokens(tokens).is_none());
        assert!(
            absent
                .command_classes
                .exact_completion(statement, &|_| None)
                .is_none()
        );
        let mut missing = module.clone();
        missing.source_metadata_input = None;
        assert!(
            prepare_cfg_context_bundle(&missing, registry)
                .command_classes
                .logical_structured_invocation(tokens)
                .is_none()
        );
        assert!(
            CfgCommandClasses::from_registry(registry)
                .logical_structured_invocation(tokens)
                .is_some(),
            "explicit standalone control"
        );
        let mut incomplete = tokens.clone();
        incomplete.source_binding = None;
        assert!(
            prepared
                .command_classes
                .logical_structured_invocation(&incomplete)
                .is_none()
        );
    }

    #[test]
    fn cfg_condition_possible_writes_keep_original_aliases_and_replacements() {
        // naming.diagnostic.original-materialized-write-footprint
        // docs/design/analysis/name-resolution-proofs/diagnostic-original-materialized-write-footprint.md
        // These are analysis-only <cond> footprints, not native stores/entry.
        let profile = tcl_dialect::DialectProfile::find("tcl").unwrap();
        let config = tcl_lexer::LexerConfig::from_grammar(profile.grammar);
        let context =
            tcl_registry::model::ingress::resolve_environment("tcl9.0").default_context_registry();
        let registry = context.commands();
        let input = crate::analyser::ResolvedAnalysisInput::new(
            profile,
            profile,
            Arc::clone(&context),
            config,
        );
        for (source, expected) in [
            (
                "if {[catch {set {café(open} VALUE} result]} {puts ${café(open}}",
                Some("café(open"),
            ),
            (
                "interp alias {} assign {} set {$literal}; if {[assign VALUE]} {puts ${$literal}}",
                Some("$literal"),
            ),
            (
                "proc catch args {}; if {[catch {set hidden VALUE} result]} {puts $hidden}",
                None,
            ),
        ] {
            let unit = crate::compilation_unit::CompilationUnit::build_with_analysis_input(
                source,
                crate::compilation_unit::UnitBuildOptions {
                    registry,
                    defer_top_level: false,
                    config,
                    dialect: Some(profile),
                    external_call_sites: None,
                    declared_commands: None,
                },
                None,
                &input,
            );
            let defs = find_call_defs(&unit.top_level.cfg, "<cond>").unwrap_or_default();
            if let Some(expected) = expected {
                assert!(
                    defs.iter().any(|name| name == expected),
                    "{source}: {defs:?}"
                );
            } else {
                assert!(
                    !defs.iter().any(|name| name == "hidden" || name == "result"),
                    "known replacement: {defs:?}"
                );
            }
        }
    }

    #[test]
    fn prepared_cfg_refuses_changed_module_profile_and_body_configuration() {
        // naming.compiler.original-analysis-metadata-context
        // docs/design/analysis/name-resolution-proofs/original-analysis-metadata-context.md
        let profile = tcl_dialect::DialectProfile::find("tcl").unwrap();
        let config = tcl_lexer::LexerConfig::from_grammar(profile.grammar);
        let context =
            tcl_registry::model::ingress::resolve_environment("tcl9.0").default_context_registry();
        let registry = context.commands();
        let input = crate::analyser::ResolvedAnalysisInput::new(
            profile,
            profile,
            Arc::clone(&context),
            config,
        );
        let unit = crate::compilation_unit::CompilationUnit::build_with_analysis_input(
            "if {[set output VALUE]} {puts $output}",
            crate::compilation_unit::UnitBuildOptions {
                registry,
                defer_top_level: false,
                config,
                dialect: Some(profile),
                external_call_sites: None,
                declared_commands: None,
            },
            None,
            &input,
        );
        let module = &unit.ir_module;
        assert!(
            prepare_cfg_context_bundle(module, registry)
                .command_classes
                .metadata_context()
                .is_some()
        );
        let mut wrong_profile = module.clone();
        wrong_profile.dialect_profile = Some(tcl_dialect::DialectProfile::find("tcl9.0").unwrap());
        assert!(
            prepare_cfg_context_bundle(&wrong_profile, registry)
                .command_classes
                .metadata_context()
                .is_none()
        );
        let prepared = prepare_cfg_context_bundle(module, registry);
        let bad_config = tcl_lexer::LexerConfig {
            expand_syntax: !config.expand_syntax,
            ..config
        };
        let builder = CfgBuilder::new_with_upvars_and_classes(
            true,
            HashMap::new(),
            HashMap::new(),
            HashMap::new(),
            prepared.context.3.clone(),
            registry,
            prepared.command_classes.clone(),
        )
        .with_lexer_config(bad_config);
        assert!(builder.command_classes.metadata_context().is_none());
        // Complete source metadata is still independently retained by its owner.
        assert_eq!(wrong_profile.source_metadata_input.as_ref(), Some(&input));
    }

    #[test]
    fn original_cfg_metadata_preserves_explicit_standalone_and_missing_purposes() {
        let context = tcl_registry::model::ingress::context_for_profile(
            tcl_registry::model::ingress::resolve_environment("tcl8.6").analyser_profile(),
        );
        let registry = context.commands();
        let mut lowerer = crate::lowering::Lowerer::with_config(
            registry,
            tcl_lexer::LexerConfig::for_dialect("tcl8.6"),
        )
        .with_dialect(registry.profile());
        let module = lowerer.lower("set value 1; puts $value").clone();
        assert!(module.source_entry.metadata_context.is_standalone());
        assert!(module.source_metadata_input.is_none());
        let original = prepare_cfg_context_bundle(&module, registry);
        assert!(matches!(
            original.command_classes.metadata,
            CfgMetadataContext::Standalone
        ));
        let explicit = PreparedCfgContext::from_metadata_input(
            original.context.clone(),
            registry,
            crate::registry_invocation::InvocationMetadataInput::Retained(
                &module.source_entry.metadata_context,
            ),
        );
        assert!(matches!(
            explicit.command_classes.metadata,
            CfgMetadataContext::Standalone
        ));
        let missing =
            PreparedCfgContext::from_source_input(original.context.clone(), registry, None);
        assert!(matches!(
            missing.command_classes.metadata,
            CfgMetadataContext::Unavailable
        ));
        let mut changed = module.clone();
        changed.source_entry.metadata_context = CfgMetadataContext::Unavailable;
        assert!(matches!(
            prepare_cfg_context_bundle(&changed, registry)
                .command_classes
                .metadata,
            CfgMetadataContext::Unavailable
        ));
        let foreign = CommandRegistry::build_default();
        assert!(matches!(
            prepare_cfg_context_bundle(&module, &foreign)
                .command_classes
                .metadata,
            CfgMetadataContext::Unavailable
        ));
    }

    #[test]
    fn prepared_cfg_source_metadata_is_shared_by_module_and_body_builders() {
        // naming.compiler.original-analysis-metadata-context
        // docs/design/analysis/name-resolution-proofs/original-analysis-metadata-context.md
        let context = tcl_registry::model::ingress::context_for_profile(
            tcl_registry::model::ingress::resolve_environment("tcl8.6").analyser_profile(),
        );
        let registry = context.commands();
        let mut lowerer = crate::lowering::Lowerer::with_config(
            registry,
            tcl_lexer::LexerConfig::for_dialect("tcl8.6"),
        )
        .with_dialect(registry.profile())
        .with_context_registry(Arc::clone(&context));
        let module = lowerer.lower("throw ERROR payload; set reached 1").clone();
        let prepared = prepare_cfg_context_bundle(&module, registry);
        let shared = PreparedCfgContext::from_source_input(
            prepared.context.clone(),
            registry,
            module.source_metadata_input.as_ref(),
        );
        let CfgMetadataContext::SuppliedSource(retained) = &shared.command_classes.metadata else {
            panic!("the actual body request retains its original context");
        };
        assert!(Arc::ptr_eq(&retained.context_registry(), &context));
        let cfg = build_cfg_with_registry(&module, false, registry);
        let body = build_cfg_function_with_prepared_context(
            "::top",
            &module.top_level,
            true,
            registry,
            module.plain_command_dispatch,
            &shared,
            module.lexer_config,
        );
        let expected = Some(Terminator::Complete {
            route: tcl_registry::completion_route::InvocationCompletionRoute::Tcl(
                tcl_registry::CompletionCode::Error,
            ),
            span: Some(module.top_level.statements[0].span()),
        });
        assert_eq!(
            cfg.top_level.blocks[&cfg.top_level.entry].terminator,
            expected
        );
        assert_eq!(body.blocks[&body.entry].terminator, expected);
    }

    #[test]
    fn whole_module_cfg_uses_the_exact_custom_registry_traits() {
        let mut registry = native_registry();
        let mut custom = registry.get("puts").expect("puts spec").clone();
        custom.traits |= Traits::TERMINATES_BLOCK;
        custom.completion = Some(tcl_registry::CompletionDescriptor::exact(&[
            tcl_registry::CompletionCode::Error,
        ]));
        registry.insert(custom);

        let module = crate::lowering::lower_to_ir("puts before\nset reached 1", &registry);
        let cfg = build_cfg_with_registry(&module, false, &registry);
        let entry = &cfg.top_level.blocks[&cfg.top_level.entry];
        assert!(
            matches!(
                entry.terminator,
                Some(Terminator::Complete {
                    route: tcl_registry::completion_route::InvocationCompletionRoute::Tcl(
                        tcl_registry::CompletionCode::Error
                    ),
                    ..
                })
            ),
            "the custom registry's completion must shape the whole-module CFG: {entry:?}"
        );
        assert!(
            cfg.top_level.blocks.values().any(|block| {
                block.name.starts_with("unreachable") && block.statements.iter().any(|statement| {
                    matches!(statement, Statement::AssignConst { name, .. } if name == "reached")
                        || matches!(statement, Statement::Call { command, args, .. }
                                if command == "set" && args == &["reached", "1"])
                })
            }),
            "the statement after the custom terminator must be unreachable"
        );
    }

    #[test]
    fn condition_var_writes_use_the_exact_custom_registry_roles() {
        let mut registry = native_registry();
        let mut custom = registry.get("list").expect("list spec").clone();
        custom.arg_roles = &[(0, tcl_registry::ArgRole::VarWrite)];
        custom.arg_role_resolver = None;
        registry.insert(custom);

        let module = crate::lowering::lower_to_ir("if {[list slot]} {puts yes}", &registry);
        let cfg = build_cfg_with_registry(&module, false, &registry);
        let condition_defs = cfg
            .top_level
            .blocks
            .values()
            .flat_map(|block| &block.statements)
            .find_map(|statement| match statement {
                Statement::Call { command, defs, .. } if command == "<cond>" => Some(defs),
                _ => None,
            })
            .expect("condition command substitutions produce a synthetic CFG call");
        assert!(
            condition_defs.iter().any(|name| name == "slot"),
            "custom VarWrite role was replaced by a default Tcl registry: {condition_defs:?}"
        );
    }

    /// The classification helpers keep each site's own name
    /// normalisation: the terminator / throw / tailcall checks trim
    /// leading `:` runs (so canonical `::error` classifies), while
    /// [`CfgBuilder::lower_loop_jump`] matches the raw word (so
    /// `::break` stays a plain call there).
    #[test]
    fn cfg_class_helpers_keep_site_normalisation() {
        let classes = CfgCommandClasses::for_dialect(Some("tcl9.0"));
        assert!(classes.is_block_terminating_command("error"));
        assert!(classes.is_block_terminating_command("::throw"));
        assert!(classes.is_block_terminating_command("exit"));
        assert!(!classes.is_block_terminating_command("return"));
        assert!(!classes.is_block_terminating_command("break"));
        assert!(
            classes
                .semantics
                .command("error")
                .is_some_and(|facts| facts.has_traits(Traits::CATCHABLE_THROW))
        );
        assert!(
            !classes
                .semantics
                .command("exit")
                .is_some_and(|facts| facts.has_traits(Traits::CATCHABLE_THROW))
        );
        assert!(classes.is_tailcall_command("::tailcall"));
        assert!(!classes.is_tailcall_command("error"));
        assert!(classes.is_loop_break_command("break"));
        assert!(!classes.is_loop_break_command("::break"));
        assert!(classes.is_loop_continue_command("continue"));
        assert!(!classes.is_loop_continue_command("break"));
    }

    #[test]
    fn opaque_host_barriers_match_calls_for_every_registry_proc_exit_command() {
        // This is deliberately registry-driven: today the traits yield
        // `error`, `exit`, `throw`, and `tailcall`, but a trait change must
        // extend this test automatically. Test both source spellings the CFG
        // accepts, including the global-qualified form.
        for command in proc_exit_host_commands() {
            for spelling in [command.clone(), format!("::{command}")] {
                for (kind, statement) in [
                    ("Call", host_call(spelling.clone())),
                    ("Barrier", host_barrier(spelling.clone())),
                ] {
                    assert_eq!(
                        flow_facts_stmt(&statement).1,
                        Completion::ProcExit,
                        "{kind} {spelling} must leave the procedure",
                    );

                    let script = Script::from_statements(vec![
                        statement,
                        Statement::AssignConst {
                            span: Span::new(2, 3),
                            name: "dead".into(),
                            name_braced: false,
                            value: "1".into(),
                            value_span: None,
                        },
                    ]);
                    let func = build_analysis_cfg("::test", &script);
                    let entry = &func.blocks[&func.entry];
                    assert_eq!(
                        entry.statements.len(),
                        1,
                        "{kind} {spelling} must keep following statements unreachable",
                    );
                    assert!(
                        matches!(entry.terminator, Some(Terminator::Complete { .. })),
                        "{kind} {spelling} must terminate its CFG block, got {:?}",
                        entry.terminator,
                    );
                }
            }
        }
    }

    #[test]
    fn proc_exit_host_barriers_terminate_direct_and_opaque_switch_forms() {
        // Exact switches lower each arm directly; glob switches remain an
        // opaque Statement::Switch. In both representations, barriers whose
        // host command is a registry-described proc exit must retain the same
        // completion fact as a Call.
        let commands = proc_exit_host_commands();
        let direct = build_analysis_cfg("::direct", &proc_exit_barrier_switch(SwitchMode::Exact));
        assert!(matches!(
            direct.blocks[&direct.entry].terminator,
            Some(Terminator::Branch { .. })
        ));
        let direct_barriers: Vec<_> = direct
            .blocks
            .values()
            .filter(|block| {
                block
                    .statements
                    .iter()
                    .any(|stmt| matches!(stmt, Statement::Barrier { .. }))
            })
            .collect();
        assert_eq!(direct_barriers.len(), commands.len() + 1);
        assert!(
            direct_barriers
                .iter()
                .all(|block| { matches!(block.terminator, Some(Terminator::Complete { .. })) })
        );

        let opaque = build_analysis_cfg("::opaque", &proc_exit_barrier_switch(SwitchMode::Glob));
        let entry = &opaque.blocks[&opaque.entry];
        assert!(matches!(
            entry.statements.as_slice(),
            [Statement::Switch { .. }]
        ));
        assert!(
            matches!(entry.terminator, Some(Terminator::Complete { .. })),
            "an all-proc-exit opaque switch must not fall through, got {:?}",
            entry.terminator,
        );
    }

    #[test]
    fn structured_cfg_writes_keep_literal_name_data_and_dynamic_unknowns() {
        for (name, root) in [
            ("", ""),
            ("$counter", "$counter"),
            ("${braced}", "${braced}"),
            ("$array(key)", "$array"),
        ] {
            let statement = Statement::AssignConst {
                span: Span::new(0, 0),
                name: name.into(),
                name_braced: true,
                value: "1".into(),
                value_span: None,
            };
            assert_eq!(
                flow_facts_stmt(&statement).0,
                BTreeSet::from([root.to_owned()])
            );
            let mutation = Statement::Incr {
                span: Span::new(0, 0),
                name: name.into(),
                name_braced: true,
                amount: Some("1".into()),
                amount_braced: true,
                safe_on_uninit: false,
            };
            let registry = CommandRegistry::build_default();
            assert_eq!(
                CfgBuilder::new(true, &registry).init_written_names(&mutation),
                Some(vec![root.to_owned()])
            );
        }
        let dynamic = Statement::Incr {
            span: Span::new(0, 0),
            name: "$counter".into(),
            name_braced: false,
            amount: Some("1".into()),
            amount_braced: true,
            safe_on_uninit: false,
        };
        assert!(flow_facts_stmt(&dynamic).0.is_empty());
        let registry = CommandRegistry::build_default();
        assert_eq!(
            CfgBuilder::new(true, &registry).init_written_names(&dynamic),
            None
        );
    }

    #[test]
    fn for_initialisation_does_not_publish_array_elements_as_scalar_constants() {
        let registry = native_registry();
        let profile = registry.profile().unwrap();
        let config = tcl_lexer::LexerConfig::for_profile(Some(profile));
        let builder = CfgBuilder::new(true, &registry).with_lexer_config(config);
        for (name, condition, expected) in [
            ("a", "$a == 1", true),
            ("$a", "${$a} == 1", true),
            ("", "${} == 1", true),
            ("a(key)", "$a == 1", false),
            ("$a(key)", "${$a} == 1", false),
        ] {
            let source = format!("for {{set {{{name}}} 1}} {{{condition}}} {{}} {{}}");
            let module = crate::lowering::lower_procedure_target_module_for_bytecode_with_options(
                tcl_runtime_api::ProcedureCompileTarget {
                    source: &source,
                    namespace: "",
                    parameters: &[],
                },
                &registry,
                config,
                Some(profile),
                false,
                None,
            );
            let statement = &module.top_level.statements[0];
            let Statement::For { raw_tokens, .. } = statement else {
                panic!("original bytecode for grammar: {statement:?}");
            };
            assert!(raw_tokens.as_deref().is_some());
            assert_eq!(
                builder.for_runs_at_least_once(statement),
                expected,
                "{source}"
            );
        }
    }

    #[test]
    fn empty_script_produces_entry_exit() {
        let func = build_test_cfg_function("::test", &Script::new(), true);
        assert_eq!(func.name, "::test");
        assert!(func.blocks.contains_key(&func.entry));
        // entry → exit
        assert!(func.blocks.len() >= 2);
    }

    #[test]
    fn linear_script() {
        let script = Script::from_statements(vec![
            Statement::AssignConst {
                span: Span::new(0, 7),
                name: "x".into(),
                name_braced: false,
                value: "1".into(),
                value_span: None,
            },
            Statement::AssignConst {
                span: Span::new(8, 15),
                name: "y".into(),
                name_braced: false,
                value: "2".into(),
                value_span: None,
            },
        ]);
        let func = build_test_cfg_function("::test", &script, true);
        // Entry block should have both statements.
        let entry = &func.blocks[&func.entry];
        assert_eq!(entry.statements.len(), 2);
    }

    #[test]
    fn return_terminates() {
        let script = Script::from_statements(vec![
            Statement::AssignConst {
                span: Span::new(0, 7),
                name: "x".into(),
                name_braced: false,
                value: "1".into(),
                value_span: None,
            },
            Statement::Return {
                expr_base: None,
                tokens: None,
                span: Span::new(8, 16),
                value: Some("$x".into()),
                value_word: None,
                expr: None,
                command_binding: None,
                braced: false,
            },
            Statement::AssignConst {
                span: Span::new(17, 24),
                name: "y".into(),
                name_braced: false,
                value: "2".into(), // dead code
                value_span: None,
            },
        ]);
        let func = build_test_cfg_function("::test", &script, true);
        let entry = &func.blocks[&func.entry];
        // Only one statement before the return terminator.
        assert_eq!(entry.statements.len(), 1);
        assert!(matches!(entry.terminator, Some(Terminator::Return { .. })));
    }

    #[test]
    fn if_creates_branches() {
        let script = Script::from_statements(vec![Statement::If {
            span: Span::new(0, 30),
            clauses: vec![IfClause {
                condition: ExprNode::Var {
                    text: "$x".into(),
                    name: "x".into(),
                    start: 0,
                    end: 2,
                },
                condition_span: Span::new(3, 5),
                body: Script::from_statements(vec![Statement::AssignConst {
                    span: Span::new(7, 14),
                    name: "y".into(),
                    name_braced: false,
                    value: "1".into(),
                    value_span: None,
                }]),
                body_span: Span::new(6, 15),
                condition_base: None,
            }],
            else_body: None,
            else_span: None,
        }]);
        let func = build_test_cfg_function("::test", &script, true);
        // Should have at least: entry, if_then, if_next, if_end, exit
        assert!(func.blocks.len() >= 4);
        // Entry block should have a Branch terminator.
        let entry = &func.blocks[&func.entry];
        assert!(
            matches!(entry.terminator, Some(Terminator::Branch { .. })),
            "entry should branch; got {:?}",
            entry.terminator
        );
    }

    #[test]
    fn build_cfg_module() {
        let module = Module::default();
        let cfg = build_cfg(&module, false);
        assert_eq!(cfg.top_level.name, "::top");
        assert!(cfg.procedures.is_empty());
    }

    #[test]
    fn prepared_context_cfg_matches_compatibility_entry_point() {
        let registry = native_registry();
        let module = crate::lowering::lower_to_ir(
            "proc writer {} { global answer; set answer 42 }\n\
             interp alias {} write-answer {} writer\n\
             write-answer\n",
            &registry,
        );
        let context = prepare_cfg_context_bundle(&module, &registry);

        assert_eq!(
            build_cfg_with_registry_and_context(
                &module,
                false,
                &registry,
                &context,
                tcl_lexer::LexerConfig::for_profile(registry.profile()),
            ),
            build_cfg_with_registry(&module, false, &registry),
        );
    }

    #[test]
    fn drop_word_keeps_structured_words_aligned() {
        let tokens = CommandTokens::from_lossy_parts(
            vec![Span::new(0, 4), Span::new(5, 8), Span::new(9, 13)],
            vec!["dict".into(), "for".into(), "body".into()],
            vec![TokenType::Esc, TokenType::Esc, TokenType::Str],
            vec![true, true, true],
            Vec::new(),
            None,
        );
        let dropped = drop_word(&tokens, 1);
        assert_eq!(dropped.argv_texts, vec!["dict", "body"]);
        assert!(dropped.words_align_with_argv_text());
        assert_eq!(dropped.words()[1].legacy_text(), "body");
    }

    /// A `catch` whose body is one straight-line block is lowered into real
    /// blocks, so the ordinary emitters compile it: its variables reach the
    /// LVT and the optimiser can see inside (#2207).
    #[test]
    fn straight_line_catch_lowers_to_real_blocks() {
        let func = build_test_cfg_function("::test", &straight_line_catch_script(), true);
        let body_id = func
            .blocks
            .keys()
            .find(|id| func.block_name(**id).starts_with("catch_body_"))
            .copied()
            .expect("expected a catch_body block");
        // The body's own statement is in the body block, not summarised onto
        // an opaque call.
        assert!(
            func.blocks[&body_id]
                .statements
                .iter()
                .any(|s| matches!(s, Statement::AssignConst { name, .. } if name == "inner")),
            "the body's write belongs to the body block",
        );
        // The result variable is still defined for SSA, on the block both
        // paths reach.
        assert!(
            func.blocks.iter().any(|(id, blk)| {
                func.block_name(*id).starts_with("catch_end_")
                    && blk.statements.iter().any(|s| {
                        matches!(
                            s,
                            Statement::Call { tokens: Some(tokens), defs, .. }
                                if tokens.synthetic == Some(crate::ir::SyntheticMarker::CapturedCatchOutputs)
                                    && defs.iter().any(|d| d == "result")
                        )
                    })
            }),
            "result var must be defined at the merge",
        );
    }

    /// A body that terminates its block — here an `error` — keeps the opaque
    /// form: the split-off part would fall outside the exception range.
    #[test]
    fn catch_with_terminating_body_stays_opaque() {
        let script = Script::from_statements(vec![Statement::Catch {
            span: Span::new(0, 30),
            body: Script::from_statements(vec![Statement::Call {
                span: Span::new(7, 14),
                command: "error".into(),
                canonical_command: None,
                args: vec!["boom".into()],
                defs: vec![],
                reads: vec![],
                reads_own_defs: false,
                safe_on_uninit: false,
                tokens: None,
                foreach_groups: None,
            }]),
            body_span: Span::new(6, 15),
            result_var: Some("result".into()),
            options_var: None,
            raw_args: vec!["{error boom}".into(), "result".into()],
            tokens: None,
        }]);
        let registry = native_registry();
        let func = CfgBuilder::new(true, &registry)
            .with_lexer_config(tcl_lexer::LexerConfig::for_profile(registry.profile()))
            .build_function("::test", &script);
        let entry = &func.blocks[&func.entry];
        assert!(
            entry.statements.iter().any(|s| matches!(
                s,
                Statement::Call { command, defs, .. } if command == "catch" && !defs.is_empty()
            )),
            "a terminating body keeps the opaque call with summarised defs",
        );
        assert!(
            !func
                .blocks
                .keys()
                .any(|id| func.block_name(*id).starts_with("catch_body_")),
            "and is not lowered into blocks",
        );
    }

    fn straight_line_catch_script() -> Script {
        Script::from_statements(vec![Statement::Catch {
            span: Span::new(0, 30),
            body: Script::from_statements(vec![Statement::AssignConst {
                span: Span::new(7, 14),
                name: "inner".into(),
                name_braced: false,
                value: "1".into(),
                value_span: None,
            }]),
            body_span: Span::new(6, 15),
            result_var: Some("result".into()),
            options_var: None,
            raw_args: vec!["{set inner 1}".into(), "result".into()],
            tokens: None,
        }])
    }

    #[test]
    fn foreach_synthetic_call_records_iterator_group_sizes() {
        // ``foreach {a b} L1 c L2 { … }`` has two iterator groups
        // — the first binds two vars, the second binds one.  The
        // synthesised header `Statement::Call` must record the
        // group sizes via ``foreach_groups`` so codegen can
        // reconstruct the original pairing.
        let body = Script::from_statements(vec![Statement::AssignConst {
            span: Span::new(0, 0),
            name: "x".into(),
            name_braced: false,
            value: "1".into(),
            value_span: None,
        }]);
        let script = Script::from_statements(vec![Statement::Foreach {
            span: Span::new(0, 0),
            iterators: vec![
                ForeachIterator {
                    vars: vec!["a".into(), "b".into()],
                    list_arg: "L1".into(),
                    list_braced: false,
                },
                ForeachIterator {
                    vars: vec!["c".into()],
                    list_arg: "L2".into(),
                    list_braced: false,
                },
            ],
            body,
            body_span: Span::new(0, 0),
            is_lmap: false,
            raw_args: vec![],
            is_dict_iteration: false,
            is_array_iteration: false,
            raw_tokens: None,
        }]);
        let func = build_test_cfg_function("::test", &script, true);
        let mut found_groups: Option<Vec<usize>> = None;
        for block in func.blocks.values() {
            for stmt in &block.statements {
                if let Statement::Call {
                    command,
                    foreach_groups,
                    ..
                } = stmt
                    && command == "foreach"
                {
                    found_groups = foreach_groups.clone();
                }
            }
        }
        assert_eq!(found_groups, Some(vec![2, 1]));
    }

    #[test]
    fn dedup_preserves_order() {
        let mut v = vec!["a".into(), "b".into(), "a".into(), "c".into(), "b".into()];
        dedup_preserve_order(&mut v);
        assert_eq!(v, vec!["a", "b", "c"]);
    }

    // Uplevel-literal-set wiring tests.
    //
    // Each test drives the full pipeline:
    // `lower_to_ir` → `build_cfg` (which calls `prepare_cfg_context`).
    // The assertions inspect the resulting CFG to confirm that calls
    // to upvar-using procs carry the expected caller-side defs.

    fn lower_module(src: &str) -> Module {
        crate::lowering::lower_to_ir(src, &native_registry())
    }

    // --- escaping_loop_jumps: try propagation and
    // dead-code early-stop
    //
    // These exercise the helper directly: their end-to-end W210 effect is
    // masked by a separate, pre-existing `while 1` exit-reachability behaviour
    // (Rust treats the post-loop block of an infinite loop as reachable), so we
    // assert the `(can_break, can_continue)` result the wiring keys off.

    #[test]
    fn escaping_loop_jumps_follows_try_but_not_catch() {
        // `try { break }` (no matching handler) propagates the break to the
        // enclosing loop; `catch { break }` absorbs it (yields code 3). Confirmed
        // against tclsh 9.0.3.
        assert_eq!(
            escaping_loop_jumps(&lower_module("try { break }").top_level, 0),
            (true, false),
            "try propagates break",
        );
        assert_eq!(
            escaping_loop_jumps(&lower_module("try { continue } finally { }").top_level, 0),
            (false, true),
            "try (with finally) propagates continue",
        );
        assert_eq!(
            escaping_loop_jumps(
                &lower_module("try { puts x } on error {} { break }").top_level,
                0
            ),
            (true, false),
            "a break in a try handler body propagates",
        );
        assert_eq!(
            escaping_loop_jumps(&lower_module("catch { break }").top_level, 0),
            (false, false),
            "catch absorbs break (does not propagate)",
        );
    }

    #[test]
    fn escaping_loop_jumps_stops_after_non_completing_stmt() {
        // A `break`/`continue` after a statement that cannot complete normally
        // is dead code and must not be collected as an escaping jump (else it
        // forges a spurious loop-exit edge).
        assert_eq!(
            escaping_loop_jumps(&lower_module("error bad\nbreak").top_level, 0),
            (false, false),
            "dead break after error is not collected",
        );
        assert_eq!(
            escaping_loop_jumps(&lower_module("return\ncontinue").top_level, 0),
            (false, false),
            "dead continue after return is not collected",
        );
        // A live jump before dead code IS collected (and stops the scan there).
        assert_eq!(
            escaping_loop_jumps(&lower_module("break\nset x 1").top_level, 0),
            (true, false),
            "live break is collected",
        );
    }

    /// `escaping_loop_jumps` and the
    /// mutually-recursive `switch_escaping_jumps` recurse once per nested
    /// `if`/`switch`/`Block`/`UpFrame`/`try` body, with no depth cap of
    /// their own before this fix. Transitively bounded to
    /// `MAX_LOWER_DEPTH` (256) by the lowering pass today, so this is
    /// defence-in-depth / consistency with every other full-tree walker in
    /// this crate, not a currently-reproducible crash. 1000 levels of
    /// source nesting is comfortably past this new cap; the assertion is
    /// that `escaping_loop_jumps` returns at all, not what it returns.
    /// Spawns its own big-stack thread since the lexer/CST/segmenter
    /// stages upstream of the lowering cap still walk the full
    /// un-truncated source nesting before that cap trims it — same
    /// rationale as
    /// `codegen::structured::tests::deeply_nested_if_survives_structured_walk`.
    #[test]
    fn deeply_nested_if_survives_escaping_loop_jumps() {
        const DEPTH: usize = 1000;
        const STACK_SIZE: usize = 64 * 1024 * 1024;
        let mut src = String::new();
        for _ in 0..DEPTH {
            src.push_str("if {1} {\n");
        }
        src.push_str("break\n");
        for _ in 0..DEPTH {
            src.push_str("}\n");
        }
        std::thread::Builder::new()
            .stack_size(STACK_SIZE)
            .spawn(move || {
                let _ = escaping_loop_jumps(&lower_module(&src).top_level, 0);
            })
            .unwrap()
            .join()
            .unwrap();
    }

    fn find_call_defs<'a>(func: &'a Function, command: &str) -> Option<&'a [String]> {
        for block in func.blocks.values() {
            for stmt in &block.statements {
                if let Statement::Call {
                    command: c, defs, ..
                } = stmt
                    && c == command
                {
                    return Some(defs);
                }
            }
        }
        None
    }

    #[test]
    fn rooted_regexp_value_form_does_not_widen_runtime_selected_method_frame() {
        let registry = native_registry();
        let module = crate::lowering::lower_to_ir(
            "oo::class create C {\n\
                 method value {re s} {::regexp $re $s}\n\
                 method capture {re s target} {::regexp $re $s $target}\n\
             }",
            &registry,
        );
        let context = prepare_cfg_context_with_registry(&module, &registry);
        let build = |name: &str| {
            let method = &module
                .methods
                .get(&fixture_id(&module.methods, name))
                .expect("authored fixture body");
            build_cfg_method_function_with_upvars(
                name,
                &method.body,
                method.execution_namespace.clone(),
                true,
                &registry,
                module.plain_command_dispatch,
                context.clone(),
                false,
            )
        };
        let has_opaque_variable_barrier = |function: &Function| {
            function.blocks.values().any(|block| {
                block.statements.iter().any(|statement| {
                    matches!(
                        statement,
                        Statement::Barrier { reason, .. }
                            if reason.contains("writes a source-opaque variable name")
                    )
                })
            })
        };

        let value = build("::C::value");
        assert!(
            !has_opaque_variable_barrier(&value),
            "an absolute two-operand regexp has no capture variable"
        );

        let capture = build("::C::capture");
        assert!(
            has_opaque_variable_barrier(&capture),
            "a dynamic capture name must still widen the variable frame"
        );
    }

    #[test]
    fn detect_upvar_procs_retains_issued_body_effects() {
        let module = lower_module("proc ::ns::p {} { upvar 1 caller_x x }\nproc ::ns::p2 {} {}");
        let upvar_procs = detect_upvar_procs(&module);
        assert!(!upvar_procs[&summary_id(&module, "::ns::p")].is_empty());
        assert!(!upvar_procs[&summary_id(&module, "p")].is_empty());
        // The empty body has an independently retained empty effect row.
        assert!(upvar_procs[&summary_id(&module, "::ns::p2")].is_empty());
        assert!(upvar_procs[&summary_id(&module, "p2")].is_empty());
    }

    #[test]
    fn redefined_procedure_generation_is_an_opaque_frame_effect() {
        let module = lower_module(
            "proc p {} {}\n\
             rename p old\n\
             proc p {} {upvar 1 x y; set y 2}\n\
             proc caller {} {p}",
        );
        let summaries = detect_upvar_procs(&module);
        let writer_start = module
            .source
            .try_text()
            .unwrap()
            .rfind("proc p {} {upvar")
            .unwrap() as u32;
        let writer: Vec<_> = module
            .procedures
            .iter()
            .filter(|(_, procedure)| procedure.span.start() == writer_start)
            .collect();
        assert_eq!(writer.len(), 1);
        assert_eq!(
            module
                .procedures
                .values()
                .filter(|procedure| procedure.qualified_name == "::p")
                .count(),
            2
        );
        assert!(summaries[writer[0].0].caller_frame_barrier().writes);
        let cfg = build_cfg(&module, false);
        assert!(
            cfg.procedures
                .get(&fixture_id(&cfg.procedures, "::caller"))
                .expect("authored fixture body")
                .caller_frame_barrier
                .writes
        );
    }

    #[test]
    fn recovered_procedure_without_a_published_summary_is_opaque() {
        let module = lower_module(
            "namespace eval ::n [list proc writer {} {upvar 1 x y; ::set y 2}]\n\
             proc caller {} {::n::writer}",
        );
        assert!(!fixture_id_if_present(&module.procedures, "::n::writer").is_some());
        let cfg = build_cfg(&module, false);
        assert!(
            cfg.procedures
                .get(&fixture_id(&cfg.procedures, "::caller"))
                .expect("authored fixture body")
                .caller_frame_barrier
                .writes
        );
    }

    // A wrapper proc
    // that reaches an already-known upvar proc through a *plain* call
    // (`real_worker $fvar $nvar $script`, not `uplevel`) does NOT itself
    // become an upvar-write target for its own caller — tclsh9.0/8.6-
    // verified (`can't read "myf": no such variable"` when the caller reads
    // the variable in a statement separate from the call, i.e. genuinely
    // outside any `uplevel`'d script argument). A plain call only shares
    // *values*, not stack frames: `real_worker`'s own `upvar 1` reaches the
    // wrapper's frame, not the wrapper's caller's frame; treating such a
    // pass-through as transitive is wrong, as reading the variable outside
    // any uplevel'd script shows. The tcllib idiom
    // (`page::util::flow`) reaches its own worker via `uplevel 1 [list
    // ... ]`, not a plain call — that genuinely propagates one frame further,
    // confirmed against tclsh9.0 — but modelling it soundly (composing the
    // wrapper's own uplevel level with the callee's upvar level) is not done
    // here.

    #[test]
    fn detect_upvar_procs_does_not_propagate_through_a_plain_call_wrapper() {
        // TN — `wrapper` has no `upvar` of its own, and its call to the
        // known upvar proc `real_worker` is a plain call (not `uplevel`),
        // so it must NOT be registered as a transitive upvar proc.
        let module = lower_module(
            "proc real_worker {fvar nvar script} {\n\
             upvar 1 $fvar f\n\
             upvar 1 $nvar n\n\
             set f 1\n\
             set n 2\n\
             uplevel 1 $script\n\
             }\n\
             proc wrapper {fvar nvar script} {\n\
             real_worker $fvar $nvar $script\n\
             }",
        );
        let upvar_procs = detect_upvar_procs(&module);
        assert!(
            upvar_procs[&summary_id(&module, "wrapper")].is_empty(),
            "a plain-call wrapper must not be treated as a transitive upvar proc",
        );
    }

    #[test]
    fn detect_upvar_procs_does_not_propagate_when_args_are_not_passed_through() {
        // TN — `unrelated_wrapper` calls the known upvar proc `real_worker`,
        // but with literal args ("x"/"y"), not its own parameters passed
        // through unchanged — real tclsh9.0/8.6 confirms this genuinely
        // errors ("can't read \"myf\": no such variable"), so it must NOT
        // be registered.
        let module = lower_module(
            "proc real_worker {fvar nvar script} {\n\
             upvar 1 $fvar f\n\
             upvar 1 $nvar n\n\
             set f 1\n\
             set n 2\n\
             uplevel 1 $script\n\
             }\n\
             proc unrelated_wrapper {a b c} {\n\
             real_worker x y $c\n\
             }",
        );
        let upvar_procs = detect_upvar_procs(&module);
        assert!(
            upvar_procs[&summary_id(&module, "unrelated_wrapper")].is_empty(),
            "unrelated_wrapper passes literal args, not its own params — must not propagate",
        );
    }

    /// The *other* half of the rule
    /// the two tests above pin. A level-**1** effect stops at the wrapper's
    /// own frame, but a level that lands past the callee's caller reaches
    /// this proc's caller through an ordinary call, so the wrapper really
    /// does become a caller-frame writer.
    ///
    /// Byte-identical on tclsh 9.0.4 and 8.6.16:
    ///
    /// ```tcl
    /// proc setUp2 {var} { uplevel 2 [list set $var 99] }
    /// proc middle {}    { setUp2 answer }
    /// proc outer  {}    { middle ; return $answer }
    /// puts [outer]        ;# -> 99
    /// ```
    #[test]
    fn detect_upvar_procs_propagates_a_beyond_caller_effect_one_plain_hop() {
        let module = lower_module(
            "proc setUp2 {var} {\n             uplevel 2 [list set $var 99]\n             }\n             proc middle {} {\n             setUp2 answer\n             }",
        );
        let upvar_procs = detect_upvar_procs(&module);
        let middle = upvar_procs
            .get(&summary_id(&module, "middle"))
            .expect("a plain call to a beyond-caller writer registers the wrapper");
        assert!(
            middle.caller_frame_opaque_writes,
            "setUp2's `uplevel 2` lands in middle's caller: {middle:?}"
        );
        assert!(
            middle.caller_frame_opaque_reads,
            "the same script may read there too: {middle:?}"
        );
    }

    /// On tclsh 9.0.4:
    ///
    /// ```tcl
    /// proc far {} {uplevel 2 {set x 2}}
    /// interp alias {} via {} far
    /// proc middle {} {via}
    /// proc outer {} {set x 1; middle; return $x}
    /// puts [outer] ;# -> 2
    /// ```
    #[test]
    fn alias_terminal_proc_propagates_a_beyond_caller_effect() {
        let module = lower_module(
            "proc far {} {uplevel 2 {set x 2}}\n\
             interp alias {} via {} far\n\
             proc middle {} {via}",
        );
        let upvar_procs = detect_upvar_procs(&module);
        let middle = upvar_procs
            .get(&summary_id(&module, "::middle"))
            .expect("the alias resolves to far's beyond-caller effect");
        assert!(middle.caller_frame_opaque_writes, "{middle:?}");
        assert!(middle.caller_frame_opaque_reads, "{middle:?}");
    }

    /// TN — `uplevel #0` (global) and `uplevel 0` (the callee's own frame)
    /// reach no caller at all, so neither is a beyond-caller effect and
    /// neither makes a plain-call wrapper one.
    #[test]
    fn detect_upvar_procs_does_not_propagate_a_global_or_own_frame_level() {
        for level in ["#0", "0"] {
            let module = lower_module(&format!(
                "proc setSomewhere {{var}} {{\n                 uplevel {level} [list set $var 99]\n                 }}\n                 proc wrapper {{}} {{\n                 setSomewhere answer\n                 }}"
            ));
            let upvar_procs = detect_upvar_procs(&module);
            assert!(
                upvar_procs[&summary_id(&module, "wrapper")].is_empty(),
                "`uplevel {level}` never touches a caller frame: {upvar_procs:?}"
            );
        }
    }

    /// The published summaries carry no composition bookkeeping — they are
    /// folded into every procedure's `function_lattice` memo key, so only
    /// what a call site actually reads may travel in them.
    #[test]
    fn detect_upvar_procs_publishes_no_plain_call_bookkeeping() {
        let module = lower_module(
            "proc setUp2 {var} {\n             uplevel 2 [list set $var 99]\n             }\n             proc middle {} {\n             setUp2 answer\n             }",
        );
        for (name, info) in detect_upvar_procs(&module) {
            assert!(
                info.plain_calls.is_empty(),
                "{name:?} published composition input: {info:?}"
            );
        }
    }

    #[test]
    fn prepare_cfg_context_registers_params_for_all_procs() {
        let module = lower_module("proc ::ns::p {a b} { upvar 1 $a x }\nproc q {c} {}");
        let (_upvar_procs, proc_params, _global_write_procs, _command_bindings, _owners) =
            prepare_cfg_context(&module);
        assert_eq!(
            proc_params.get(&summary_id(&module, "::ns::p")),
            Some(&vec!["a".to_string(), "b".to_string()]),
        );
        assert_eq!(
            proc_params.get(&summary_id(&module, "::ns::p")),
            Some(&vec!["a".to_string(), "b".to_string()]),
        );
        // q has no upvar but its params should still be in proc_params.
        assert_eq!(
            proc_params.get(&summary_id(&module, "::q")),
            Some(&vec!["c".to_string()])
        );
    }

    #[test]
    fn literal_upvar_proc_call_augments_defs() {
        // Caller invokes a proc whose body has `upvar 1 caller_x x`.
        // The call should land with `caller_x` in its defs.
        let module = lower_module(
            "proc setter {} { upvar 1 caller_x x; set x 1 }\n\
             setter",
        );
        let cfg = build_cfg(&module, false);
        let defs = find_call_defs(&cfg.top_level, "setter")
            .expect("setter call should be in top-level CFG");
        assert!(
            defs.contains(&"caller_x".to_string()),
            "expected caller_x in defs, got {defs:?}",
        );
    }

    #[test]
    fn alias_to_upvar_uses_its_prepended_frame_level() {
        // Tcl 9.0.4: `bind` executes `upvar 1 target local`; assigning
        // `local` in `setter` therefore assigns `target` in its caller.
        // The frame descriptor and argv are both supplied by the closed
        // command binding, not by the source spelling `bind`.
        let module = lower_module(
            "interp alias {} bind {} upvar 1\n\
             proc setter {} { bind target local; set local 99 }\n\
             setter",
        );
        let cfg = build_cfg(&module, false);
        let defs = find_call_defs(&cfg.top_level, "setter")
            .expect("setter call should be in top-level CFG");
        assert!(
            defs.contains(&"target".to_owned()),
            "the aliased upvar target must invalidate its caller: {defs:?}"
        );
    }

    #[test]
    fn param_upvar_proc_call_resolves_call_site_arg() {
        // `proc setter {name} { upvar 1 $name x }` aliased to whatever
        // the caller passes for `name`.  Call `setter my_var` should
        // augment the call with `my_var` in defs.
        let module = lower_module(
            "proc setter {name} { upvar 1 $name x; set x 1 }\n\
             setter my_var",
        );
        let cfg = build_cfg(&module, false);
        let defs = find_call_defs(&cfg.top_level, "setter")
            .expect("setter call should be in top-level CFG");
        assert!(
            defs.contains(&"my_var".to_string()),
            "expected my_var in defs, got {defs:?}",
        );
    }

    #[test]
    fn early_and_late_aliases_to_upvar_proc_prepend_the_caller_target() {
        for source in [
            "interp alias {} assign {} setter target\n\
             proc setter {name} { upvar 1 $name x; set x 1 }\n\
             proc outer {} { assign }",
            "proc setter {name} { upvar 1 $name x; set x 1 }\n\
             proc outer {} { assign }\n\
             interp alias {} assign {} setter target",
        ] {
            let module = lower_module(source);
            let cfg = build_cfg(&module, false);
            let outer = fixture_id_if_present(&cfg.procedures, "::outer")
                .and_then(|id| cfg.procedures.get(&id))
                .expect("outer proc CFG should exist");
            let defs = find_call_defs(outer, "assign").expect("alias call should be in outer CFG");
            assert!(
                defs.contains(&"target".to_owned()),
                "alias definition order must not hide its prepended upvar target: {defs:?}",
            );
        }
    }

    #[test]
    fn alias_chain_preserves_prefix_order_for_upvar_proc_arguments() {
        let module = lower_module(
            "proc setter {first name} { upvar 1 $name x; set x 1 }\n\
             interp alias {} inner {} setter first\n\
             interp alias {} outer {} inner second\n\
             outer",
        );
        let cfg = build_cfg(&module, false);
        let defs = find_call_defs(&cfg.top_level, "outer")
            .expect("outer alias call should be in top-level CFG");
        assert!(
            defs.contains(&"second".to_owned()),
            "inner then outer alias prefixes must remain in runtime argv order: {defs:?}",
        );
        assert!(
            !defs.contains(&"first".to_owned()),
            "the first fixed argument must not be projected onto the second parameter: {defs:?}",
        );
    }

    #[test]
    fn substituted_upvar_actual_is_opaque_not_a_literal_def() {
        // The source spelling `$caller_var` is not the variable name passed
        // at runtime. No precise def may be manufactured from that spelling.
        let module = lower_module(
            "proc setter {name} { upvar 1 $name x }\n\
             setter $caller_var",
        );
        let cfg = build_cfg(&module, false);
        let defs = find_call_defs(&cfg.top_level, "setter")
            .expect("setter call should be in top-level CFG");
        assert!(
            !defs.contains(&"caller_var".to_string()),
            "substituted source text became a literal caller def: {defs:?}",
        );
        assert_eq!(
            cfg.top_level.caller_frame_barrier,
            crate::dynamic_names::DynamicNameBarrier {
                writes: true,
                destroys: false,
                reads: false,
            }
        );
    }

    #[test]
    fn trailing_expansion_preserves_a_known_upvar_actual_prefix() {
        let module = lower_module(
            "proc setter {name args} { upvar 1 $name x; set x 1 }\n\
             setter my_var {*}$rest",
        );
        let cfg = build_cfg(&module, false);
        let defs = find_call_defs(&cfg.top_level, "setter")
            .expect("setter call should be in top-level CFG");
        assert!(defs.contains(&"my_var".to_string()), "defs={defs:?}");
    }

    #[test]
    fn expanded_upvar_actual_is_opaque_not_a_literal_def() {
        let module = lower_module(
            "proc setter {name} { upvar 1 $name x; set x 1 }\n\
             setter {*}$actual",
        );
        let cfg = build_cfg(&module, false);
        let defs = find_call_defs(&cfg.top_level, "setter")
            .expect("setter call should be in top-level CFG");
        assert!(
            defs.is_empty(),
            "expanded source text became defs: {defs:?}"
        );
        assert_eq!(
            cfg.top_level.caller_frame_barrier,
            crate::dynamic_names::DynamicNameBarrier {
                writes: true,
                destroys: false,
                reads: false,
            }
        );
    }

    /// A call omitting a `Name` parameter defines the place the parameter's
    /// default names, as Tcl binds the default; a default that names no
    /// variable the analysis can place widens the caller's frame, as a
    /// substituted argument does.
    #[test]
    fn an_omitted_upvar_parameter_defines_its_default() {
        let module = lower_module(
            "proc setter {{name n}} { upvar 1 $name x; set x 1 }\n\
             setter",
        );
        let cfg = build_cfg(&module, false);
        let defs = find_call_defs(&cfg.top_level, "setter")
            .expect("setter call should be in top-level CFG");
        assert_eq!(defs, vec!["n".to_owned()]);
        assert_eq!(
            cfg.top_level.caller_frame_barrier,
            crate::dynamic_names::DynamicNameBarrier::default()
        );
        let module = lower_module(
            "proc setter {{name a(1)}} { upvar 1 $name x; set x 1 }\n\
             setter",
        );
        let cfg = build_cfg(&module, false);
        assert_eq!(
            cfg.top_level.caller_frame_barrier,
            crate::dynamic_names::DynamicNameBarrier {
                writes: true,
                destroys: false,
                reads: false,
            }
        );
    }

    #[test]
    fn computed_or_expanded_direct_head_is_not_misidentified_as_a_static_callee() {
        for call in ["$command target", "{*}$invocation"] {
            let module = lower_module(&format!(
                "proc setter {{name}} {{ upvar 1 $name x; set x 1 }}\n{call}"
            ));
            let cfg = build_cfg(&module, false);
            assert_eq!(
                cfg.top_level.caller_frame_barrier,
                crate::dynamic_names::DynamicNameBarrier::default(),
                "call={call}"
            );
        }
    }

    #[test]
    fn non_upvar_proc_call_unchanged() {
        // No upvar in the callee — the call's defs should be empty.
        let module = lower_module("proc no_upvar {} { set x 1 }\nno_upvar");
        let cfg = build_cfg(&module, false);
        let defs = find_call_defs(&cfg.top_level, "no_upvar")
            .expect("no_upvar call should be in top-level CFG");
        assert!(defs.is_empty(), "expected no augmented defs, got {defs:?}");
    }

    #[test]
    fn qualified_call_resolves_via_qualified_key() {
        // `proc ::ns::setter` is registered under both `::ns::setter`
        // and `setter`.  A qualified call site `::ns::setter` should
        // resolve via the qualified key.
        let module = lower_module(
            "proc ::ns::setter {} { upvar 1 caller_x x }\n\
             ::ns::setter",
        );
        let cfg = build_cfg(&module, false);
        let defs = find_call_defs(&cfg.top_level, "::ns::setter")
            .expect("::ns::setter call should be in top-level CFG");
        assert!(
            defs.contains(&"caller_x".to_string()),
            "expected caller_x in defs (qualified call), got {defs:?}",
        );
    }

    #[test]
    fn cross_proc_call_inside_proc_body_augments_defs() {
        // Outer proc calls an inner upvar-using proc.  The outer
        // proc's CFG should reflect the augmented defs.
        let module = lower_module(
            "proc inner {} { upvar 1 caller_x x }\n\
             proc outer {} { inner }",
        );
        let cfg = build_cfg(&module, false);
        let outer = fixture_id_if_present(&cfg.procedures, "::outer")
            .and_then(|id| cfg.procedures.get(&id))
            .expect("outer proc CFG should exist");
        let defs = find_call_defs(outer, "inner").expect("inner call should be in outer CFG");
        assert!(
            defs.contains(&"caller_x".to_string()),
            "expected caller_x in inner's defs (called from outer), got {defs:?}",
        );
    }

    #[test]
    fn late_alias_call_inside_proc_uses_projected_global_write_summary() {
        let module = lower_module(
            "proc ::mutate {} { global x; set x 99 }\n\
             proc ::z::mutate {} {}\n\
             proc ::outer {} { call_mutate }\n\
             interp alias {} call_mutate {} mutate",
        );
        let cfg = build_cfg(&module, false);
        let outer = fixture_id_if_present(&cfg.procedures, "::outer")
            .and_then(|id| cfg.procedures.get(&id))
            .expect("outer proc CFG should exist");
        let defs =
            find_call_defs(outer, "call_mutate").expect("late alias call should be in outer CFG");
        assert!(
            defs.contains(&"x".to_owned()),
            "projected alias summary must invalidate x at the inner call: {defs:?}",
        );
    }

    #[test]
    fn upvar_call_inside_if_branch_augments_defs() {
        // Calls inside structured constructs (if branches, while
        // bodies, ...) must also be augmented — the wiring runs in
        // `lower_script`, which is invoked recursively for every
        // body.
        let module = lower_module(
            "proc setter {} { upvar 1 caller_y y }\n\
             if {1} { setter }",
        );
        let cfg = build_cfg(&module, false);
        let defs = find_call_defs(&cfg.top_level, "setter")
            .expect("setter call in if-branch should be in top-level CFG");
        assert!(
            defs.contains(&"caller_y".to_string()),
            "expected caller_y in defs (call inside if branch), got {defs:?}",
        );
    }

    #[test]
    fn empty_module_no_upvar_context_no_panic() {
        // Empty module → empty upvar_procs and proc_params.  Building
        // a CFG should still succeed.
        let module = Module::default();
        let cfg = build_cfg(&module, false);
        assert_eq!(cfg.top_level.name, "::top");
        assert!(cfg.procedures.is_empty());
    }

    #[test]
    fn build_cfg_function_does_not_apply_upvar_wiring() {
        // `build_cfg_function` is the no-context variant used by
        // tests and one-off CFG construction.  It MUST NOT augment
        // defs even when the script calls a known upvar proc —
        // the function only sees the script, not a module.
        let module = lower_module("proc setter {} { upvar 1 caller_x x }\nsetter");
        // Build only the top-level CFG via the no-context API.
        let func = build_cfg_function(
            "::top",
            &module.top_level,
            true,
            &native_registry(),
            module.plain_command_dispatch,
        );
        let defs = find_call_defs(&func, "setter").expect("setter call should be in top-level CFG");
        assert!(
            defs.is_empty(),
            "build_cfg_function without context should leave defs empty, got {defs:?}",
        );
    }

    // Embedded-substitution form: `[upvar_proc arg]` in every evaluated
    // statement value, argument, expression, return, or condition surface.

    /// Walk every block looking for a Call whose `defs` contain
    /// *def*.  Returns the command name when found.
    fn find_call_with_def<'a>(func: &'a Function, def: &str) -> Option<&'a str> {
        for block in func.blocks.values() {
            for stmt in &block.statements {
                if let Statement::Call { command, defs, .. } = stmt
                    && defs.iter().any(|d| d == def)
                {
                    return Some(command);
                }
            }
        }
        None
    }

    #[test]
    fn embedded_subst_in_assign_value_emits_its_word_effects() {
        // `set foo [setter]` where setter upvars caller_x.  The
        // resulting CFG should have a word-effects `<word-effects>`
        // Call with `caller_x` in its defs, emitted BEFORE the
        // `set foo ...` AssignValue.
        let module = lower_module(
            "proc setter {} { upvar 1 caller_x x; return $x }\n\
             set foo [setter]",
        );
        let cfg = build_cfg(&module, false);
        let cmd = find_call_with_def(&cfg.top_level, "caller_x")
            .expect("expected a Call carrying caller_x in defs");
        assert_eq!(cmd, "<word-effects>");
    }

    /// The `(defs, reads)` of the first call named `command` in `func`.
    fn defs_and_reads<'a>(
        func: &'a Function,
        command: &str,
    ) -> Option<(&'a [String], &'a [String])> {
        func.blocks.values().find_map(|block| {
            block.statements.iter().find_map(|stmt| match stmt {
                Statement::Call {
                    command: name,
                    defs,
                    reads,
                    ..
                } if name == command => Some((defs.as_slice(), reads.as_slice())),
                _ => None,
            })
        })
    }

    /// Where a statement's `[…]` substitutions write a place its own words read,
    /// the call that carries the write reads it too — the version before the
    /// write feeds the word that runs ahead of it. A read inside a command the
    /// statement runs, or inside the expression word of one, is a read of the
    /// statement.
    #[test]
    fn the_call_carrying_a_write_reads_the_place_its_statement_reads() {
        for (body, carrier) in [
            ("set r [expr {$x + [set x 10] + $x}]", "<word-effects>"),
            ("expr {$x + [set x 10]}", "<word-effects>"),
            ("set r \"$x [set x 10]\"", "<word-effects>"),
            ("incr r [expr {$x + [set x 10]}]", "<word-effects>"),
            ("return [expr {$x + [set x 10]}]", "<word-effects>"),
            (
                "set r [expr {[string length $x] + [set x 10]}]",
                "<word-effects>",
            ),
            (
                "set r [expr {[expr {$x + 1}] + [set x 10]}]",
                "<word-effects>",
            ),
            ("if {$x + [set x 10] > 3} {puts a}", "<cond>"),
            ("while {$x + [set x 10] < 3} {break}", "<cond>"),
            ("puts [expr {$x + [set x 10] + $x}]", "puts"),
            ("foo $x [incr x] $x", "foo"),
        ] {
            let module = lower_module(&format!("proc p {{}} {{ set x 1; set r 5; {body} }}"));
            let cfg = build_cfg(&module, false);
            let p = fixture_id_if_present(&cfg.procedures, "::p")
                .and_then(|id| cfg.procedures.get(&id))
                .expect("::p CFG");
            let (defs, reads) = defs_and_reads(p, carrier).expect(body);
            assert!(defs.iter().any(|name| name == "x"), "{body}: {defs:?}");
            assert!(reads.iter().any(|name| name == "x"), "{body}: {reads:?}");
        }
    }

    /// A place no word of the statement reads is no read of the call that
    /// carries its write: the store the write overwrites stays dead, as it was
    /// before a statement's reads were told from its writes, and a `gets` that
    /// fills a loop's variable reads nothing of it.
    #[test]
    fn the_call_carrying_a_write_leaves_a_place_its_statement_never_reads_alone() {
        for (body, carrier, place) in [
            ("set r [expr {[set x 10] + 1}]", "<word-effects>", "x"),
            ("puts [set x 2]", "puts", "x"),
            (
                "while {[gets $fd line] >= 0} {puts $line}",
                "<cond>",
                "line",
            ),
            ("if {[set x 10] > $r} {puts a}", "<cond>", "x"),
        ] {
            let module = lower_module(&format!(
                "proc p {{fd}} {{ set x 1; set r 5; set line {{}}; {body} }}"
            ));
            let cfg = build_cfg(&module, false);
            let p = fixture_id_if_present(&cfg.procedures, "::p")
                .and_then(|id| cfg.procedures.get(&id))
                .expect("::p CFG");
            let (defs, reads) = defs_and_reads(p, carrier).expect(body);
            assert!(defs.iter().any(|name| name == place), "{body}: {defs:?}");
            assert!(!reads.iter().any(|name| name == place), "{body}: {reads:?}");
        }
    }

    /// The `(command, defs)` of every call in `func`'s blocks, in order.
    fn calls_in_order(func: &Function) -> Vec<(&str, &[String])> {
        func.blocks
            .values()
            .flat_map(|block| &block.statements)
            .filter_map(|stmt| match stmt {
                Statement::Call { command, defs, .. } => Some((command.as_str(), defs.as_slice())),
                _ => None,
            })
            .collect()
    }

    fn position_of(calls: &[(&str, &[String])], command: &str) -> usize {
        calls
            .iter()
            .position(|(name, _)| *name == command)
            .unwrap_or_else(|| panic!("no {command} in {calls:?}"))
    }

    /// An opaque `catch` keeps its body inside the statement and stops at the
    /// body's first error, so what the body writes is a may-definition stated
    /// ahead of the call, and only the result and options variables the call
    /// assigns once the body has finished are its own definitions.
    #[test]
    fn an_opaque_catch_states_what_its_body_writes_as_may_definitions_ahead_of_the_call() {
        let module =
            lower_module("set g 5\ncatch { if {[gets stdin] eq {q}} { set g 0 } } msg opts\n");
        let cfg = build_cfg(&module, false);
        let calls = calls_in_order(&cfg.top_level);
        let marker = position_of(&calls, "<arm-writes>");
        let catch = position_of(&calls, "catch");
        assert!(marker < catch, "{calls:?}");
        assert_eq!(calls[marker].1, ["g"]);
        assert_eq!(calls[catch].1, ["msg", "opts"]);
    }

    /// A callee an opaque `catch` body calls writes the caller's name through
    /// `upvar`, as it would at a call the graph lowers: the name joins the
    /// may-definitions.
    #[test]
    fn a_callee_an_opaque_catch_body_calls_may_define_the_name_it_writes() {
        let module = lower_module(
            "proc zero {v} {upvar 1 $v x; set x 0}\n\
             proc p {} {\n set go 1\n catch { if {1} { zero go } }\n puts $go\n}\n",
        );
        let cfg = build_cfg(&module, false);
        let p = fixture_id_if_present(&cfg.procedures, "::p")
            .and_then(|id| cfg.procedures.get(&id))
            .expect("::p CFG");
        let calls = calls_in_order(p);
        assert_eq!(calls[position_of(&calls, "<arm-writes>")].1, ["go"]);
    }

    /// The marker for where code the module cannot see runs, and the barrier
    /// for a command that may write any name, stand ahead of the opaque
    /// `catch` call whose body runs it: at the top level a plain name is the
    /// global the code reaches, in a procedure a local is in the reach of a
    /// callee that runs `upvar 1`, and a sourced file runs in the frame of the
    /// call.
    #[test]
    fn an_opaque_catch_marks_the_unseen_code_and_the_barrier_its_body_runs() {
        let has_marker = |func: &Function, marker: crate::ir::SyntheticMarker| {
            func.blocks
                .values()
                .flat_map(|block| &block.statements)
                .any(|stmt| {
                    matches!(
                        stmt,
                        Statement::Call { tokens: Some(tokens), .. }
                            | Statement::Barrier { tokens: Some(tokens), .. }
                            if tokens.synthetic == Some(marker)
                    )
                })
        };
        let top = |src: &str| build_cfg(&lower_module(src), false).top_level;
        let in_proc = |src: &str| {
            let module = lower_module(&format!("proc p {{}} {{\n{src}\n}}"));
            build_cfg(&module, false)
                .procedures
                .get(&fixture_id(&module.procedures, "::p"))
                .expect("authored fixture body")
                .clone()
        };
        for src in [
            "catch {foo}",
            "catch {foo} msg",
            "catch { if {1} { foo } }",
            "catch { puts [foo] }",
            "catch { source other.tcl }",
            "if {[catch {foo}]} { puts bad }",
            "set rc [catch {foo} msg]",
            "puts [catch { puts [foo] }]",
            "while {[catch {if {1} {foo}}]} { break }",
            "set rc [catch $script]",
        ] {
            let func = top(src);
            assert!(
                has_marker(&func, crate::ir::SyntheticMarker::UnseenCall),
                "{src}"
            );
        }
        // An autoloaded or unknown-handled callee reaches a procedure's local
        // through `upvar 1`; a sourced file runs in its frame.
        for src in [
            "catch { if {1} { foo } }",
            "if {[catch {foo}]} { puts bad }",
            "set rc [catch {foo} msg]",
            "puts [catch { puts [foo] }]",
        ] {
            assert!(
                has_marker(&in_proc(src), crate::ir::SyntheticMarker::UnseenCall),
                "proc: {src}"
            );
        }
        assert!(has_marker(
            &in_proc("if {[catch {source other.tcl}]} { puts bad }"),
            crate::ir::SyntheticMarker::UnseenCall
        ));
        assert!(has_marker(
            &in_proc("catch { if {1} { source other.tcl } }"),
            crate::ir::SyntheticMarker::UnseenCall
        ));
        for (func, src) in [
            (top("catch { namespace eval :: {set go 0} }"), "top"),
            (
                in_proc("catch { if {1} { namespace eval :: {set go 0} } }"),
                "proc",
            ),
            (
                in_proc("catch { if {1} { dict with d { set go 0 } } }"),
                "dict with",
            ),
        ] {
            assert!(
                has_marker(&func, crate::ir::SyntheticMarker::CallerFrameOpaque),
                "{src}"
            );
        }
        // A body that writes another name and runs only commands the module
        // knows states no marker.
        let func = top("catch { if {1} { set other 1 } }");
        assert!(!has_marker(&func, crate::ir::SyntheticMarker::UnseenCall));
        assert!(!has_marker(
            &func,
            crate::ir::SyntheticMarker::CallerFrameOpaque
        ));
    }

    /// The marker for a call whose own head runs code the module cannot see
    /// follows the call and carries nothing: the names the call's words read,
    /// which may be rewritten as it runs, are the SSA's to state.
    #[test]
    fn the_marker_for_a_call_follows_it_and_states_no_name() {
        for (src, host) in [
            ("set cmd puts\n$cmd hi", "${cmd}"),
            ("set suffix _hi\nfoo$suffix", "foo${suffix}"),
            ("set a 1\nget $a", "get"),
            ("set f x.tcl\nsource $f", "source"),
        ] {
            let cfg = build_cfg(&lower_module(src), false);
            let calls = calls_in_order(&cfg.top_level);
            assert_eq!(
                calls,
                [(host, &[][..]), ("<unseen-call>", &[][..])],
                "{src}"
            );
        }
    }

    /// A computed head runs whatever its value names, so it is code the module
    /// cannot see, as a literal head it does not define is, at the top level
    /// and in a procedure body alike.
    #[test]
    fn a_computed_head_is_an_unseen_call() {
        let unseen = |func: &Function| {
            calls_in_order(func)
                .iter()
                .any(|(command, _)| *command == "<unseen-call>")
        };
        for src in [
            "$cmd",
            "$cmd arg",
            "puts [$cmd]",
            "set x [$cmd]",
            "if {[$cmd]} { puts a }",
        ] {
            assert!(
                unseen(&build_cfg(&lower_module(src), false).top_level),
                "{src}"
            );
        }
        for src in ["$cmd", "puts [$cmd]", "set x [$cmd]"] {
            let module = lower_module(&format!("proc p {{}} {{\n{src}\n}}"));
            let cfg = build_cfg(&module, false);
            assert!(
                unseen(
                    cfg.procedures
                        .get(&fixture_id(&cfg.procedures, "::p"))
                        .expect("authored fixture body")
                ),
                "proc: {src}"
            );
        }
    }

    /// A command the document declares as a plain call that states its frame
    /// effect is one the module can name: under `-frame own` and `-frame none`
    /// its call, direct or in a substitution, marks nothing, and under
    /// `-frame caller` it brings `argparse`'s caller-frame effect to the
    /// computed-name walk. A declaration that states no frame effect, or
    /// names a word the flow graph would have to follow, stays a call to code
    /// the module cannot see; one with a body word lowers to the barrier
    /// `time {…}` lowers to, whatever its frame effect.
    #[test]
    fn a_declared_plain_call_brings_the_frame_effect_it_states() {
        let registry = tcl_registry::model::ingress::static_context_for("tcl8.6").commands();
        let config = tcl_lexer::LexerConfig::for_profile(registry.profile());
        let build = |stub: &str, body: &str| {
            let src = format!(
                "# tcl-lsp: stubs-begin\n# tcl-lsp: stub {stub}\n# tcl-lsp: stubs-end\n\
                 proc p {{}} {{\n    set g 5\n    {body}\n    puts $g\n}}\n"
            );
            let declared = crate::analyser::utils::document_declared_surface(&src, None, "tcl8.6");
            let module = crate::lowering::lower_to_ir_with(
                crate::lowering::Lowerer::with_config(registry, config)
                    .with_dialect(registry.profile())
                    .with_declared_commands(Some(&declared)),
                &src,
            );
            build_cfg_with_registry(&module, false, registry)
                .procedures
                .get(&fixture_id(&module.procedures, "::p"))
                .expect("authored fixture body")
                .clone()
        };
        let unseen = |func: &Function| {
            calls_in_order(func)
                .iter()
                .any(|(command, _)| *command == "<unseen-call>")
        };
        let writes = |func: &Function| {
            crate::dynamic_names::dynamic_name_barrier(func, registry, config).writes
        };
        for stub in [
            "db_query {sql} -frame own",
            "db_query {sql:pattern} -pure -frame none",
        ] {
            for body in ["db_query {select 1}", "set n [db_query {select 1}]"] {
                let func = build(stub, body);
                assert!(!unseen(&func), "{stub}: {body}");
                assert!(!writes(&func), "{stub}: {body}");
                assert_eq!(
                    func.declared_frame_effects.get("::db_query"),
                    Some(&None),
                    "{stub}"
                );
            }
        }
        for body in ["db_query {select 1}", "set n [db_query {select 1}]"] {
            let func = build("db_query {sql} -frame caller", body);
            assert!(!unseen(&func), "caller: {body}");
            assert!(writes(&func), "caller: {body}");
        }
        for stub in [
            "db_query {sql}",
            "db_query {sql} -frame bogus",
            "db_query {row:var} -frame own",
            "db_query {sql:expr} -frame own",
            "db_query {sql} -barrier -frame own",
            "db_query {sql} -extension -frame own",
        ] {
            let func = build(stub, "db_query {select 1}");
            assert!(unseen(&func), "{stub}");
            assert!(func.declared_frame_effects.is_empty(), "{stub}");
        }
        let barrier_reason = |func: &Function, head: &str| {
            func.blocks
                .values()
                .flat_map(|block| &block.statements)
                .find_map(|stmt| match stmt {
                    Statement::Barrier {
                        command, reason, ..
                    } if command == head => Some(reason.clone()),
                    _ => None,
                })
        };
        let registry_body = build("db_query {sql} -frame own", "time {set x 1}");
        assert!(barrier_reason(&registry_body, "time").is_some());
        for stub in [
            "db_eval {sql script:body} -frame own",
            "db_eval {sql script:body} -frame none",
            "db_eval {sql script:body}",
            "db_eval {sql cb:command_prefix} -frame own",
        ] {
            let declared_body = build(stub, "db_eval {select 1} {set x 1}");
            assert_eq!(
                barrier_reason(&declared_body, "db_eval"),
                barrier_reason(&registry_body, "time"),
                "{stub}"
            );
            assert!(declared_body.declared_frame_effects.is_empty(), "{stub}");
        }
    }

    /// A substitution's command reaches code the module cannot see through every
    /// word it runs as code: a lambda's body, a body that runs in another frame
    /// (`uplevel`, `namespace eval`), the commands in a `subst` text and in an
    /// expression word of a body, as through a body of this frame, in a
    /// procedure as at the top level. A body that holds no such code marks
    /// nothing.
    #[test]
    fn a_substitution_marks_the_unseen_code_in_every_word_its_command_runs() {
        let unseen = |func: &Function| {
            calls_in_order(func)
                .iter()
                .any(|(command, _)| *command == "<unseen-call>")
        };
        for src in [
            "set x [apply {{} {foo}}]",
            "set x [apply {{x} {foo $x}} 1]",
            "set x [apply {{} {if {1} {foo}}}]",
            "set x [namespace eval ns {foo}]",
            "set x [namespace eval ns {namespace eval inner {foo}}]",
            "set x [uplevel #0 {foo}]",
            "set x [subst {[foo]}]",
            "set x [subst -nobackslashes {a [foo] b}]",
            "set x [catch {apply {{} {foo}}}]",
            "set x [catch {if {[foo]} {puts a}}]",
            "set x [catch {while {[foo]} {puts a}}]",
            "set x [catch {expr {[foo] + 1}}]",
            "set x [apply {{} {if {[foo]} {puts a}}}]",
            "puts [apply {{} {foo}}]",
            "if {[apply {{} {foo}}]} {puts a}",
            "set x [apply $lambda]",
            "set x [namespace eval ns $script]",
        ] {
            assert!(
                unseen(&build_cfg(&lower_module(src), false).top_level),
                "{src}"
            );
        }
        for src in [
            "set x [apply {{} {set y 1}}]",
            "set x [apply {{x} {set y $x}} 1]",
            "set x [namespace eval ns {set y 1}]",
            "set x [uplevel #0 {set y 1}]",
            "set x [subst {abc}]",
            "set x [subst {[set y 1]}]",
            "set x [subst -nocommands {a [foo] b}]",
            "set x [catch {apply {{} {set y 1}}}]",
            "set x [catch {if {[set y 1]} {puts a}}]",
            "set x [apply {{} {if {[set y 1]} {puts a}}}]",
        ] {
            assert!(
                !unseen(&build_cfg(&lower_module(src), false).top_level),
                "{src}"
            );
        }
        // A callee the code reaches runs `upvar 1` into a procedure's frame too.
        for src in [
            "set x [apply {{} {foo}}]",
            "set x [namespace eval ns {foo}]",
            "set x [subst {[foo]}]",
        ] {
            let module = lower_module(&format!("proc p {{}} {{\n{src}\n}}"));
            let cfg = build_cfg(&module, false);
            assert!(
                unseen(
                    cfg.procedures
                        .get(&fixture_id(&cfg.procedures, "::p"))
                        .expect("authored fixture body")
                ),
                "proc: {src}"
            );
        }
    }

    /// A `try` the codegen shape keeps as one call states what its body, its
    /// handlers and its `finally` script write as may-definitions, and the
    /// variables its handlers bind are among them: a handler runs only when it
    /// is selected.
    #[test]
    fn a_deferred_try_states_what_its_scripts_write_as_may_definitions() {
        let module =
            lower_module("try { foo } on error {msg opts} { set a 1 } finally { set b 2 }\n");
        let cfg = build_cfg(&module, true);
        let calls = calls_in_order(&cfg.top_level);
        let marker = position_of(&calls, "<arm-writes>");
        let call = position_of(&calls, "try");
        assert!(marker < call, "{calls:?}");
        assert_eq!(calls[marker].1, ["a", "b", "msg", "opts"]);
        assert!(calls[call].1.is_empty(), "{calls:?}");
        assert!(calls.iter().any(|(command, _)| *command == "<unseen-call>"));
    }

    #[test]
    fn embedded_subst_in_return_emits_its_word_effects_before_terminator() {
        let module = lower_module(
            "proc setter {} { upvar 1 caller_x x; set x 1; return 0 }\n\
             proc outer {} { return [setter] }",
        );
        let cfg = build_cfg(&module, false);
        let outer = fixture_id_if_present(&cfg.procedures, "::outer")
            .and_then(|id| cfg.procedures.get(&id))
            .expect("::outer CFG");
        assert_eq!(
            find_call_with_def(outer, "caller_x"),
            Some("<word-effects>")
        );
        assert!(
            outer
                .blocks
                .values()
                .any(|block| { matches!(block.terminator, Some(Terminator::Return { .. })) })
        );
    }

    #[test]
    fn switch_word_substitutions_invalidate_before_dispatch() {
        let module = lower_module(
            "proc setter {name} { upvar 1 $name value; set value 1; return 0 }\n\
             proc outer {} {\n\
                 set subject 1\n\
                 set pattern 1\n\
                 switch [setter subject] [setter pattern] { return ok } default { return no }\n\
             }",
        );
        let cfg = build_cfg(&module, false);
        let outer = fixture_id_if_present(&cfg.procedures, "::outer")
            .and_then(|id| cfg.procedures.get(&id))
            .expect("::outer CFG");
        let boundary = outer
            .blocks
            .values()
            .find_map(|block| {
                block.statements.iter().find(|statement| {
                    matches!(statement, Statement::Call { defs, .. }
                    if defs.iter().any(|name| name == "subject")
                        && defs.iter().any(|name| name == "pattern"))
                })
            })
            .expect("both argument writes must precede body dispatch");
        let Statement::Call {
            command, tokens, ..
        } = boundary
        else {
            unreachable!()
        };
        if command == "switch" {
            // An unresolved compiler protocol retains one runtime invocation.
            // Its argv effects occur before any entered script phase.
            let tokens = tokens.as_ref().expect("original argv carrier");
            assert!(tokens.evaluates_words());
            assert!(tokens.words()[1].sole_command_substitution().is_some());
            assert!(tokens.words()[2].sole_command_substitution().is_some());
            assert_eq!(outer.blocks.values().flat_map(|block| &block.statements)
                .filter(|statement| matches!(statement, Statement::Call {command, tokens, ..}
                    if command == "switch" && tokens.as_ref().is_none_or(crate::ir::CommandTokens::evaluates_words)))
                .count(), 1, "original invocation must execute once");
        } else {
            assert!(boundary.synthetic_marker().is_some());
            assert!(outer.blocks.values().any(|block| {
                block
                    .statements
                    .iter()
                    .any(|statement| std::ptr::eq(statement, boundary))
                    && matches!(block.terminator, Some(Terminator::Branch { .. }))
            }));
        }
    }

    #[test]
    fn braced_switch_words_do_not_invalidate_before_dispatch() {
        let module = lower_module(
            "proc setter {name} { upvar 1 $name value; set value 1; return 0 }\n\
             proc outer {} {\n\
                 switch {[setter subject]} {[setter pattern]} { return ok }\n\
             }",
        );
        let cfg = build_cfg(&module, false);
        let outer = fixture_id_if_present(&cfg.procedures, "::outer")
            .and_then(|id| cfg.procedures.get(&id))
            .expect("::outer CFG");
        assert_eq!(find_call_with_def(outer, "subject"), None);
        assert_eq!(find_call_with_def(outer, "pattern"), None);
    }

    #[test]
    fn embedded_subst_in_assign_expr_and_expr_eval_emits_invalidation() {
        let module = lower_module(
            "proc setter {} { upvar 1 caller_x x; set x 1; return 0 }\n\
             proc assign_expr {} { set result [expr {[setter] + 1}] }\n\
             proc expr_eval {} { expr {[setter] + 1} }",
        );
        let cfg = build_cfg(&module, false);
        for proc_name in ["::assign_expr", "::expr_eval"] {
            let function = cfg
                .procedures
                .get(&fixture_id(&module.procedures, proc_name))
                .expect("procedure CFG");
            assert_eq!(
                find_call_with_def(function, "caller_x"),
                Some("<word-effects>"),
                "missing embedded invalidation in {proc_name}"
            );
        }
    }

    #[test]
    fn embedded_subst_in_call_arg_merges_into_call_defs() {
        // `puts [setter]` — Call host with embedded substitution.
        // The defs should merge into the existing Call's defs (no
        // word effects needed since the host is a Call).
        let module = lower_module(
            "proc setter {} { upvar 1 caller_x x; return $x }\n\
             puts [setter]",
        );
        let cfg = build_cfg(&module, false);
        let defs =
            find_call_defs(&cfg.top_level, "puts").expect("puts call should be in top-level CFG");
        assert!(
            defs.contains(&"caller_x".to_string()),
            "expected caller_x merged into puts's defs, got {defs:?}",
        );
        // No word effects should appear (the Call branch
        // merged in place).
        let synthetic = find_call_with_def(&cfg.top_level, "caller_x");
        assert_eq!(
            synthetic,
            Some("puts"),
            "embedded extras should merge into the Call host, not a synthetic",
        );
    }

    #[test]
    fn embedded_subst_param_form_resolves_call_site_arg() {
        // setter takes a parameter `name`; its upvar source is `$name`.
        // `set foo [setter myvar]` — the embedded call passes "myvar",
        // which becomes the caller-side def.
        let module = lower_module(
            "proc setter {name} { upvar 1 $name x; set x 1 }\n\
             set foo [setter myvar]",
        );
        let cfg = build_cfg(&module, false);
        let cmd = find_call_with_def(&cfg.top_level, "myvar")
            .expect("expected word effects carrying myvar");
        assert_eq!(cmd, "<word-effects>");
    }

    /// On tclsh 9.0.4:
    ///
    /// ```tcl
    /// proc far {name} {upvar 1 $name v; set v 2; return ok}
    /// interp alias {} via {} far x
    /// proc p {} {set x 1; set y [via]; return $x}
    /// puts [p] ;# -> 2
    /// ```
    #[test]
    fn embedded_alias_prefix_terminal_proc_invalidates_its_caller_target() {
        let module = lower_module(
            "proc far {name} {upvar 1 $name v; set v 2; return ok}\n\
             interp alias {} via {} far x\n\
             proc p {} {set x 1; set y [via]; return $x}",
        );
        let cfg = build_cfg(&module, false);
        let p = fixture_id_if_present(&cfg.procedures, "::p")
            .and_then(|id| cfg.procedures.get(&id))
            .expect("::p CFG");
        assert_eq!(find_call_with_def(p, "x"), Some("<word-effects>"));
    }

    #[test]
    fn embedded_terminal_proc_honours_namespace_and_unknown_resolution() {
        let namespace_module = lower_module(
            "namespace eval ::a {\n\
                 proc mutate {} {upvar 1 x v; set v 2; return ok}\n\
                 proc p {} {set x 1; set y [mutate]; return $x}\n\
             }\n\
             namespace eval ::b {\n\
                 proc mutate {} {upvar 1 y v; set v 3; return ok}\n\
             }",
        );
        let namespace_cfg = build_cfg(&namespace_module, false);
        let p = fixture_id_if_present(&namespace_cfg.procedures, "::a::p")
            .and_then(|id| namespace_cfg.procedures.get(&id))
            .expect("::a::p CFG");
        assert_eq!(find_call_with_def(p, "x"), Some("<word-effects>"));
        assert_eq!(find_call_with_def(p, "y"), None);

        let unknown_module = lower_module(
            "proc unknown {name args} {upvar 1 $name v; set v 2; return ok}\n\
             proc p {} {set missing 1; set y [missing]; return $missing}",
        );
        let unknown_cfg = build_cfg(&unknown_module, false);
        let p = fixture_id_if_present(&unknown_cfg.procedures, "::p")
            .and_then(|id| unknown_cfg.procedures.get(&id))
            .expect("::p CFG");
        assert_eq!(find_call_with_def(p, "missing"), Some("<word-effects>"));
    }

    #[test]
    fn embedded_subst_unknown_command_ignored() {
        // `[not_upvar]` — unknown command, should produce no
        // word effects.
        let module = lower_module("proc setter {} { set x 1 }\nset foo [setter]");
        let cfg = build_cfg(&module, false);
        // setter has no upvar, so neither direct nor embedded form
        // contributes — the only Call in the CFG should be
        // for the literal `setter` lookup (none here) or nothing.
        for block in cfg.top_level.blocks.values() {
            for stmt in &block.statements {
                if let Statement::Call { command, .. } = stmt {
                    assert_ne!(
                        command, "<word-effects>",
                        "no word effects should appear for non-upvar embedded calls",
                    );
                }
            }
        }
    }

    #[test]
    fn embedded_subst_no_bracket_in_text_short_circuits() {
        // `set foo "plain string"` — value has no `[`, so the
        // embedded-substitution scan should short-circuit on the
        // `text.contains('[')` guard and produce no extras.
        let module = lower_module(
            "proc setter {} { upvar 1 caller_x x }\n\
             set foo plain",
        );
        let cfg = build_cfg(&module, false);
        let synthetic = find_call_with_def(&cfg.top_level, "caller_x");
        assert!(
            synthetic.is_none(),
            "no word effects expected when text has no `[`, got {synthetic:?}",
        );
    }

    #[test]
    fn embedded_subst_synthetic_appears_before_host_assign() {
        // The word effects must land BEFORE the host
        // AssignValue in program order, so SSA / dataflow correctly
        // see the invalidation before any later use of the variable.
        let module = lower_module(
            "proc setter {} { upvar 1 caller_x x }\n\
             set foo [setter]",
        );
        let cfg = build_cfg(&module, false);
        let entry = &cfg.top_level.blocks[&cfg.top_level.entry];
        // Find the word effects' index and the AssignValue's index; assert
        // ordering.
        let mut synthetic_idx = None;
        let mut assign_idx = None;
        for (i, stmt) in entry.statements.iter().enumerate() {
            match stmt {
                _ if stmt.word_effects_host() == Some(crate::ir::WordEffectsHost::Statement) => {
                    synthetic_idx = Some(i);
                }
                Statement::AssignValue { name, .. } if name == "foo" => {
                    assign_idx = Some(i);
                }
                _ => {}
            }
        }
        let s = synthetic_idx.expect("<word-effects> should be in entry block");
        let a = assign_idx.expect("set foo AssignValue should be in entry block");
        assert!(s < a, "word effects at {s} should precede assign at {a}");
    }

    // A known upvar proc's call-by-name write reached
    // only through a nested `[...]` (a wrapping command around it, or a
    // loop/branch condition) must still be recovered — real tcllib
    // `cmdline::getoptions` repro: `while {[set err [getopt argv $opts
    // opt arg]]} { ... }`.

    #[test]
    fn embedded_subst_recovers_a_wrapped_upvar_proc_call() {
        // TP — `set x [set err [setter]]`: `setter` is nested one bracket
        // deeper than the embedded-substitution scan's own top-level word
        // check reaches (`set` itself is never a known upvar proc), so
        // recovering it requires recursing into the inner text rather than
        // pattern-matching the (bracket-stripped) word list.
        let module = lower_module(
            "proc setter {} { upvar 1 caller_x x; set x 1 }\n\
             set out [set err [setter]]",
        );
        let cfg = build_cfg(&module, false);
        let cmd = find_call_with_def(&cfg.top_level, "caller_x")
            .expect("expected word effects recovering caller_x through the wrapper");
        assert_eq!(cmd, "<word-effects>");
    }

    #[test]
    fn condition_out_vars_recovers_catch_scan_gets_regexp_and_upvar_procs() {
        // TP — `condition_out_vars` unions the hardcoded builtin scan with
        // the upvar-proc / global-write-proc resolution; a known upvar
        // proc's write reached through a condition must appear in the
        // union exactly like a `catch` result var already does.
        let module = lower_module(
            "proc setter {} { upvar 1 caller_x x; set x 1 }\n\
             if {[setter]} { puts $caller_x }",
        );
        let cfg = build_cfg(&module, false);
        let defs =
            find_call_defs(&cfg.top_level, "<cond>").expect("expected a <cond> Call in the CFG");
        assert!(
            defs.contains(&"caller_x".to_string()),
            "expected caller_x in the <cond> Call's defs, got {defs:?}",
        );
    }

    #[test]
    fn frozen_while_condition_carries_upvar_proc_defs() {
        // TP — `while {[getopt ...]}`'s condition is purely a command
        // substitution, so `lower_while_or_frozen` freezes the whole loop
        // as an opaque `Statement::Barrier` (no `defs` field at all) rather
        // than calling `lower_while`. Without a separate synthetic `<cond>`
        // Call carrying the condition's defs, `getopt`'s upvar write to
        // `opt` would be invisible to the def-use graph even though the
        // barrier's own `uses_of` textually scans the (un-lowered) body
        // for `$opt` and attributes the read to the same statement.
        let module = lower_module(
            "proc getopt {ovar} { upvar 1 $ovar opt; set opt 1 }\n\
             while {[getopt opt]} { puts $opt }",
        );
        let cfg = build_cfg(&module, false);
        let defs =
            find_call_defs(&cfg.top_level, "<cond>").expect("expected a <cond> Call in the CFG");
        assert!(
            defs.contains(&"opt".to_string()),
            "expected opt in the frozen while's <cond> Call defs, got {defs:?}",
        );
        // The barrier itself must still be there too — freezing, not
        // ordinary `lower_while`, is exactly the shape under test.
        let has_barrier = cfg.top_level.blocks.values().any(|b| {
            b.statements
                .iter()
                .any(|s| matches!(s, Statement::Barrier { command, .. } if command == "while"))
        });
        assert!(
            has_barrier,
            "expected the loop to still freeze as a Barrier"
        );
    }

    #[test]
    fn frozen_for_condition_carries_upvar_proc_defs() {
        // TP — the `for` loop's identical frozen-barrier path: the same rule
        // applies to `for {...} [cond] {...} {...}`.
        let module = lower_module(
            "proc getopt {ovar} { upvar 1 $ovar opt; set opt 1 }\n\
             for {} {[getopt opt]} {} { puts $opt }",
        );
        let cfg = build_cfg(&module, false);
        let defs =
            find_call_defs(&cfg.top_level, "<cond>").expect("expected a <cond> Call in the CFG");
        assert!(
            defs.contains(&"opt".to_string()),
            "expected opt in the frozen for's <cond> Call defs, got {defs:?}",
        );
    }

    #[test]
    fn frozen_while_condition_with_no_upvar_proc_omits_synthetic_cond() {
        // TN — a frozen loop whose condition calls an *ordinary* (non-
        // upvar, non-`catch`/`scan`/`gets`/`regexp`) command must not gain
        // a synthetic `<cond>` Call at all — nothing for it to carry.
        let module = lower_module("proc pureCheck {} { return 1 }\nwhile {[pureCheck]} { }");
        let cfg = build_cfg(&module, false);
        assert!(
            find_call_defs(&cfg.top_level, "<cond>").is_none(),
            "no synthetic <cond> Call expected when the condition defines nothing",
        );
    }

    #[test]
    fn try_handler_return_options_terminates() {
        // A `try` handler ending in `return -code error …` (lowered to a
        // "return with options" barrier) returns from the proc, so it must
        // *terminate* its block rather than fall through to the post-`try`
        // join. Regression for the spurious `try_handler → try_end` edge +
        // phi (e.g. `auto_mkindex`). Analysis builds only (`build_cfg` sets
        // `faithful_exceptions`); codegen leaves the barrier as a plain stmt.
        let module =
            lower_module("proc f {} { try { set a 1 } on error {} { return -code error boom } }");
        let cfg = build_cfg(&module, false);
        let func = fixture_id_if_present(&cfg.procedures, "::f")
            .and_then(|id| cfg.procedures.get(&id))
            .expect("::f cfg");
        let handler = func
            .blocks
            .values()
            .find(|b| b.name.starts_with("try_handler"))
            .expect("try_handler block");
        assert!(
            matches!(
                handler.terminator,
                Some(Terminator::Complete {
                    route: tcl_registry::completion_route::InvocationCompletionRoute::Return(
                        tcl_registry::completion_route::ReturnCompletionRoute {
                            eventual_code: tcl_registry::CompletionCode::Error,
                            remaining_level: 1,
                        }
                    ),
                    ..
                })
            ),
            "return-options handler must terminate (no fall-through to try_end), got {:?}",
            handler.terminator,
        );
    }

    #[test]
    fn distinct_body_summaries_preserve_conflicting_alias_targets() {
        // naming.analysis.procedure-summary-candidate-keys
        // docs/design/analysis/name-resolution-proofs/procedure-summary-candidate-keys.md
        // Actual whole-module source and existing frame-summary producer.
        let module = lower_module(
            "namespace eval a {proc bind {} {upvar 1 left local; set local 1}}\n\
             namespace eval b {proc bind {} {upvar 1 right local; set local 2}}\n\
             proc forward {} {uplevel 1 [list bind]}",
        );
        let summaries = detect_upvar_procs(&module);
        assert_eq!(
            summaries[&summary_id(&module, "::a::bind")]
                .literal_targets
                .get("local")
                .map(String::as_str),
            Some("left")
        );
        assert_eq!(
            summaries[&summary_id(&module, "::b::bind")]
                .literal_targets
                .get("local")
                .map(String::as_str),
            Some("right")
        );
        assert_eq!(summaries.len(), module.procedures.len());
        let a = summary_id(&module, "::a::bind");
        let b = summary_id(&module, "::b::bind");
        assert_ne!(a, b);
        // The ambiguous constructed call belongs to forward's source receipt.
        let forwarded = &summaries[&summary_id(&module, "::forward")];
        assert!(forwarded.literal_targets.is_empty());
        assert!(forwarded.caller_frame_opaque_writes && forwarded.caller_frame_opaque_reads);
    }

    #[test]
    fn summary_parameters_retain_each_original_signature() {
        // naming.analysis.procedure-summary-candidate-keys
        // docs/design/analysis/name-resolution-proofs/procedure-summary-candidate-keys.md
        // Defaults, order and variadic position belong to the original header.
        let module = lower_module(
            "namespace eval a {proc p {{name left} args} {}; proc q {{name shared} args} {}; proc r {a b} {}; proc s {a args} {}}\n\
             namespace eval b {proc p {{name right} args} {}; proc q {{name shared} args} {}; proc r {b a} {}; proc s {args a} {}}",
        );
        let (_, params, _, _, _) = prepare_cfg_context(&module);
        assert_eq!(params.len(), 8);
        for label in ["::a::p", "::b::p", "::a::q", "::b::q"] {
            assert_eq!(
                params.get(&summary_id(&module, label)),
                Some(&vec!["name".into(), "args".into()])
            );
        }
        assert_eq!(
            params.get(&summary_id(&module, "::a::r")),
            Some(&vec!["a".into(), "b".into()])
        );
        assert_eq!(
            params.get(&summary_id(&module, "::b::r")),
            Some(&vec!["b".into(), "a".into()])
        );
        assert_eq!(
            params.get(&summary_id(&module, "::a::s")),
            Some(&vec!["a".into(), "args".into()])
        );
        assert_eq!(
            params.get(&summary_id(&module, "::b::s")),
            Some(&vec!["args".into(), "a".into()])
        );
        let original = module
            .procedures
            .get(&summary_id(&module, "::a::p"))
            .unwrap();
        let distinct = module
            .procedures
            .get(&summary_id(&module, "::b::p"))
            .unwrap();
        assert_ne!(original.params_raw, distinct.params_raw);
    }

    #[test]
    fn body_summary_selection_declines_foreign_id_at_the_original_declaration() {
        let mut module = lower_module("proc writer {} {upvar 1 x local; set local 1}; writer");
        let foreign = lower_module("proc writer {} {upvar 1 x local; set local 1}; writer");
        let own_id = summary_id(&module, "::writer");
        let foreign_id = summary_id(&foreign, "::writer");
        assert_ne!(own_id, foreign_id);
        let body = module.procedures.get(&own_id).unwrap().clone();
        let call = module.top_level.statements.last().unwrap().clone();
        let original = module
            .top_level
            .retained_source_tokens_for_statement(module.top_level.statements.last().unwrap())
            .unwrap()
            .clone();
        let registry = module.resolved_registry().snapshot().shared_registry();
        let owners = OriginalProcedureSummaryOwners::for_module(&module, &registry);
        assert_eq!(owners.calls(&original, &registry).unwrap()[0].0, own_id);
        module.procedures.insert(foreign_id, body);
        let owners = OriginalProcedureSummaryOwners::for_module(&module, &registry);
        assert!(owners.calls(&original, &registry).is_none());
        let prepared = prepare_cfg_context_bundle(&module, &registry);
        let mut builder = CfgBuilder::new_with_upvars_and_classes(
            true,
            prepared.context.0.clone(),
            prepared.context.1.clone(),
            prepared.context.2.clone(),
            prepared.context.3.clone(),
            &registry,
            prepared.command_classes.clone(),
        )
        .with_procedure_summary_owners(prepared.context.4.clone());
        builder
            .command_binding_sites
            .extend(module.top_level.command_binding_sites.iter().cloned());
        assert!(builder.direct_upvar_effects(&call).opaque_arguments);
    }

    #[test]
    fn read_beside_writes_uses_original_roles_and_preserves_refusals() {
        for (source, expected) in [
            ("puts [set x 2] [info exists x]", vec!["x".to_owned()]),
            ("puts [set x 2]", Vec::new()),
        ] {
            let module = lower_module(source);
            let registry = module.resolved_registry();
            let prepared = prepare_cfg_context_bundle(&module, registry);
            let builder = CfgBuilder::new_with_upvars_and_classes(
                false,
                prepared.context.0.clone(),
                prepared.context.1.clone(),
                prepared.context.2.clone(),
                prepared.context.3.clone(),
                registry,
                prepared.command_classes.clone(),
            )
            .with_procedure_summary_owners(prepared.context.4.clone());
            let statement = module.top_level.statements.last().unwrap();
            let tokens = module
                .top_level
                .retained_source_tokens_for_statement(statement)
                .unwrap();
            let written = vec!["x".to_owned(), "unrelated".to_owned()];
            let reads = builder.read_beside_writes(&written, Some(tokens), |scanner| {
                scanner.scan_lexical_word("", registry)
            });
            assert_eq!(reads, expected, "{source}");
            assert_eq!(
                builder.read_beside_writes(&written, None, |scanner| {
                    scanner.scan_lexical_word("", registry)
                }),
                written
            );
            let mut changed = tokens.clone();
            changed.source_binding = None;
            assert_eq!(
                builder.read_beside_writes(&written, Some(&changed), |scanner| {
                    scanner.scan_lexical_word("", registry)
                }),
                written
            );
        }
    }

    #[test]
    fn summary_keys_decline_one_changed_member_and_foreign_module_source() {
        // naming.analysis.procedure-summary-candidate-keys
        // docs/design/analysis/name-resolution-proofs/procedure-summary-candidate-keys.md
        // Removing original correspondence cannot leave a false unique winner.
        let module = lower_module(
            "namespace eval a {proc p {name} {upvar 1 $name local}}\n\
             namespace eval b {proc p {name} {upvar 1 $name local}}",
        );
        let mut changed = module.clone();
        {
            let id = fixture_id(&changed.procedures, "::b::p");
            changed.procedures.get_mut(&id)
        }
        .unwrap()
        .params_raw
        .push_str(" extra");
        let (summaries, params, _, _, _) = prepare_cfg_context(&changed);
        let unchanged = summary_id(&changed, "::a::p");
        let changed_id = summary_id(&changed, "::b::p");
        assert!(params.contains_key(&unchanged));
        assert!(!params.contains_key(&changed_id));
        assert!(summaries[&changed_id].literal_targets.is_empty());
        assert!(summaries[&changed_id].param_targets.is_empty());
        assert!(summaries[&changed_id].caller_frame_opaque_reads);
        let mut foreign = module;
        foreign.source = tcl_lexer::SourceImage::document("proc replacement {} {}");
        let (summaries, params, _, _, _) = prepare_cfg_context(&foreign);
        assert!(params.is_empty());
        assert!(
            summaries
                .values()
                .all(|summary| summary.literal_targets.is_empty()
                    && summary.param_targets.is_empty()
                    && summary.caller_frame_opaque_writes
                    && summary.caller_frame_opaque_reads)
        );
    }
}
