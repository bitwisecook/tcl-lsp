# Paired Tcl corpus benchmark

INCOMPLETE: exception during candidate pair 1 benchmark: PermissionError: [Errno 1] Operation not permitted
