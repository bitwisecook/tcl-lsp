#!/usr/bin/env python3
"""One guarded seven-package all-target cargo check; never runs tests."""
from pathlib import Path
import datetime, fcntl, hashlib, importlib.util, json, os, re, shutil, subprocess, sys

ROOT = Path('/workspace/naming-migration-active/tcl-lsp')
BASE = Path('/tmp/name-handling-seven-package-check-v1')
PLAN = BASE / 'plan.json'
GO = BASE / 'root-go.json'
MANIFEST = BASE / 'runner-input-manifest.json'
PROVIDER = Path('/tmp/compiler-c6-provider-manifest.py')
SOURCE18 = BASE / 'source18-manifest.json'
LOCK_PATH = Path('/tmp/tcl-lsp-naming-build.lock')
RUNS = BASE / 'runs'
os.chdir(ROOT)
ACTIVE_LOCK = None
ACTIVE_RECEIPT = None

def unlock_on_failure():
    global ACTIVE_LOCK
    if ACTIVE_LOCK is None:
        return
    try:
        fcntl.flock(ACTIVE_LOCK, fcntl.LOCK_UN)
        ACTIVE_LOCK.close()
        if ACTIVE_RECEIPT is not None:
            write_json(ACTIVE_RECEIPT/'failure.json', {'status':'FAIL','utc':utc(),'reason':'suite exited before normal final receipt'})
            transcript = ACTIVE_RECEIPT/'suite.transcript'
            with transcript.open('ab') as f: f.write(b'LOCK_RELEASED_AFTER_FAILURE\n')
    finally:
        ACTIVE_LOCK = None

import atexit
atexit.register(unlock_on_failure)

def digest(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def write_json(path, value):
    path = Path(path)
    tmp = path.with_name(path.name + '.writing')
    tmp.write_text(json.dumps(value, sort_keys=True, indent=2) + '\n')
    os.replace(tmp, path)

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()

def source_view(expected_go_sha):
    plan = json.loads(PLAN.read_text())
    plan_sha = digest(PLAN)
    if digest(GO) != expected_go_sha:
        raise SystemExit('STOP: root GO changed')
    go = json.loads(GO.read_text())
    if (go.get('source_commit') != plan['source_commit'] or
        go.get('plan_sha256') != plan_sha or
        go.get('source18_manifest_sha256') != plan['integrated_manifest_sha256'] or
        go.get('runner_input_manifest_sha256') != digest(MANIFEST)):
        raise SystemExit('STOP: root GO does not bind exact typecheck plan/inputs')
    for path, expected in json.loads(MANIFEST.read_text())['inputs'].items():
        if digest(path) != expected:
            raise SystemExit('STOP: reviewed runner input changed: ' + path)
    if digest(plan['cargo_path']) != plan['cargo_sha256']:
        raise SystemExit('STOP: pinned Cargo binary hash mismatch')
    if digest(SOURCE18) != plan['integrated_manifest_sha256']:
        raise SystemExit('STOP: exact18 source manifest hash changed')
    source = json.loads(SOURCE18.read_text())
    paths = source['paths']
    if len(paths) != 18:
        raise SystemExit('STOP: source manifest is not exact18')
    base = plan['source_commit']
    head = git('rev-parse', 'HEAD')
    approved = go.get('approved_integrated_head')
    if (not approved or subprocess.run(['git','merge-base','--is-ancestor',base,approved],cwd=ROOT).returncode or
        subprocess.run(['git','merge-base','--is-ancestor',approved,head],cwd=ROOT).returncode):
        raise SystemExit('STOP: integrated HEAD is not approved exact18 descendant')
    allowed = {r['path'] for r in paths}
    for row in paths:
        p = ROOT / row['path']
        if not p.is_file() or digest(p) != row['after_sha256']:
            raise SystemExit('STOP: exact18 integrated hash mismatch: ' + row['path'])
        original = subprocess.run(['git','show',base+':'+row['path']],cwd=ROOT,capture_output=True)
        before = hashlib.sha256(original.stdout).hexdigest() if original.returncode == 0 else None
        if before != row['before_sha256']:
            raise SystemExit('STOP: exact18 baseline mismatch: ' + row['path'])
    exclusions = [':(exclude)docs/work/name-handling'] + [':(exclude)'+p for p in sorted(allowed)]
    if subprocess.run(['git','diff','--quiet',base,'--','.',*exclusions],cwd=ROOT).returncode:
        raise SystemExit('STOP: other product differs from 3b1')
    for anchor, permitted in ((base, allowed), (approved, set())):
        for commit in git('rev-list', f'{anchor}..{head}').splitlines():
            touched = subprocess.check_output(['git','diff-tree','--no-commit-id','--name-only','-r','-m',commit],cwd=ROOT,text=True).splitlines()
            if any(p not in permitted and not p.startswith('docs/work/name-handling/') for p in touched):
                raise SystemExit('STOP: non-doc/unapproved source descendant')
    for raw in subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=ROOT).split(b'\0'):
        if raw:
            p = os.fsdecode(raw)
            if p not in allowed and not p.startswith('docs/work/name-handling/'):
                raise SystemExit('STOP: unreviewed untracked path: '+p)
    return head

def source_manifest():
    records = {}
    raw = subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=ROOT)
    for item in raw.split(b'\0'):
        if not item:
            continue
        path = Path(os.fsdecode(item))
        if (path.parts[0] in {'rust','runtime','tests','experiments','spec','specs','data','resources','.cargo'}
            or path.suffix in {'.rs','.c','.h','.tcl','.tclspec'}
            or path.name in {'Cargo.toml','Cargo.lock','rust-toolchain.toml','rustfmt.toml','clippy.toml'}):
            full = ROOT / path
            records[str(path)] = digest(full) if full.is_file() else None
    return records

def provider_snapshot(path):
    subprocess.run([sys.executable, str(PROVIDER), str(path)], check=True)
    return json.loads(Path(path).read_text())

def main():
    global ACTIVE_LOCK, ACTIVE_RECEIPT
    plan = json.loads(PLAN.read_text())
    if not GO.is_file():
        write_json(BASE/'preflight-refusal.json', {'status':'STOP no root GO; no lock/build/Cargo','utc':utc(),'cargo_started':False,'lock_acquired':False})
        raise SystemExit('STOP: post-18 root GO absent; no queue')
    head = source_view(digest(GO))
    if not all(shutil.disk_usage(p).free >= 2*1024**3 for p in ('/workspace','/tmp')):
        raise SystemExit('STOP: actual filesystem below 2 GiB')
    lock = open(LOCK_PATH, 'w')
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        raise SystemExit('STOP: shared build lock occupied; no queue')
    ACTIVE_LOCK = lock
    tag = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')
    receipt = RUNS / tag
    receipt.mkdir(parents=True)
    ACTIVE_RECEIPT = receipt
    transcript = receipt/'suite.transcript'
    go_sha = digest(GO)
    before_source = source_manifest()
    write_json(receipt/'source-before.json', before_source)
    providers_before = provider_snapshot(receipt/'providers-before.json')
    write_json(receipt/'root-go-before.json', json.loads(GO.read_text()))
    (receipt/'head-before.txt').write_text(head+'\n')
    write_json(receipt/'plan.json', plan)
    target = Path(plan['target_dir'])
    env = os.environ.copy()
    env['CARGO_TARGET_DIR'] = str(target)
    command = plan['cargo_argv']
    (receipt/'command.txt').write_text('argv JSON: '+json.dumps(command)+'\n')
    # Recheck after initial captures, under lock and immediately before spawn,
    # so a race during preflight cannot become the accepted baseline.
    if source_view(go_sha) != head:
        raise SystemExit('STOP: source/plan/input identity changed before Cargo')
    providers_pre_spawn = provider_snapshot(receipt/'providers-pre-spawn.json')
    if providers_pre_spawn != providers_before:
        raise SystemExit('STOP: provider set changed before Cargo')
    spec = importlib.util.spec_from_file_location('guarded_exec', BASE/'guarded-exec.py')
    if spec is None or spec.loader is None:
        raise SystemExit('STOP: reviewed executor unavailable')
    executor = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(executor)
    result = executor.run(command, cwd=ROOT, env=env,
        stdout_path=receipt/'stdout.bin', stderr_path=receipt/'stderr.bin',
        receipt_path=receipt/'process.json', artifact_path=plan['cargo_path'],
        deadline_seconds=3600, cap_bytes=20*1024**2, disk_floor_bytes=2*1024**3,
        disk_paths=('/workspace','/tmp',target,receipt))
    stdout = (receipt/'stdout.bin').read_bytes()
    stderr = (receipt/'stderr.bin').read_bytes()
    diagnostics=[]; malformed=[]; build_finished=[]; build_script_warnings=[]
    for number,line in enumerate(stdout.splitlines(),1):
        try: obj=json.loads(line)
        except Exception:
            if line.strip(): malformed.append(number)
            continue
        if obj.get('reason') == 'compiler-message':
            msg=obj.get('message',{})
            if msg.get('level') in {'warning','error'}:
                diagnostics.append({'line':number,'level':msg.get('level'),'message':msg.get('message')})
        if obj.get('reason') == 'build-finished':
            build_finished.append(obj.get('success') is True)
        def inspect_warnings(value, line_number):
            if isinstance(value, dict):
                for key, child in value.items():
                    if key in {'warnings','warning'} and child:
                        build_script_warnings.append({'line':line_number,'field':key,'value':child})
                    else:
                        inspect_warnings(child,line_number)
            elif isinstance(value, list):
                for child in value: inspect_warnings(child,line_number)
        inspect_warnings(obj,number)
    warning_pattern = re.compile(rb'\bwarning:', re.I)
    stderr_warning = [x.decode('utf-8','replace') for x in stderr.splitlines() if warning_pattern.search(x)]
    stdout_warning_lines = [x.decode('utf-8','replace') for x in stdout.splitlines() if warning_pattern.search(x)]
    write_json(receipt/'diagnostics.json', {'compiler_messages':diagnostics,'build_script_warnings':build_script_warnings,'build_finished_events':build_finished,'stderr_warning_lines':stderr_warning,'stdout_warning_lines':stdout_warning_lines,'non_json_stdout_lines':malformed})
    if source_view(go_sha) != head:
        raise SystemExit('STOP: exact source/plan/input/GO view changed after Cargo')
    after_source = source_manifest()
    providers_after = provider_snapshot(receipt/'providers-after.json')
    head_after = git('rev-parse','HEAD')
    stable = after_source==before_source and providers_after==providers_before and digest(GO)==go_sha and head_after==head
    write_json(receipt/'source-after.json',after_source)
    write_json(receipt/'root-go-after.json',json.loads(GO.read_text()))
    (receipt/'head-after.txt').write_text(head_after+'\n')
    guard_ok = (result.get('complete') is True and result.get('stop_reason') is None and
                result.get('timer_armed_before_spawn') is True and
                result.get('group_empty_before_parent_reap') is True and
                result.get('artifact_unchanged') is True and
                result.get('artifact_sha256_before') == plan['cargo_sha256'] and
                result.get('artifact_sha256_after') == plan['cargo_sha256'] and
                result.get('exit_code') == 0)
    clean = not diagnostics and not build_script_warnings and not stderr_warning and not stdout_warning_lines and not malformed and build_finished == [True]
    passed = guard_ok and clean and stable
    final={'status':'PASS' if passed else 'FAIL','scope':'seven-package all-target compile check only; no runtime/test claim',
           'finished_utc':utc(),'head':head,'source_stable':after_source==before_source,
           'providers_stable':providers_after==providers_before,'root_go_stable':digest(GO)==go_sha,
           'head_stable':head_after==head,'guard_valid':guard_ok,'warning_free_json_stderr_stdout':clean,
           'cargo_exit_code':result.get('exit_code'),'selected_packages':plan['packages'],
           'cargo_binary_sha256':result.get('artifact_sha256_before'),
           'process_receipt_sha256':digest(receipt/'process.json'),'plan_sha256':digest(PLAN),
           'root_go_sha256':go_sha,'overall_exit':0 if passed else 1}
    write_json(receipt/'final.json',final)
    with transcript.open('xb') as f:
        f.write((f"COMPLETE receipt={receipt} overall={final['overall_exit']}\n").encode())
    fcntl.flock(lock, fcntl.LOCK_UN)
    lock.close()
    ACTIVE_LOCK = None
    with transcript.open('ab') as f: f.write(b'LOCK_RELEASED\n')
    print(f"COMPLETE receipt={receipt} overall={final['overall_exit']}",flush=True)
    print('LOCK_RELEASED',flush=True)
    return final['overall_exit']

if __name__ == '__main__':
    raise SystemExit(main())
