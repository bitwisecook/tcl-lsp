#!/usr/bin/env python3
"""Durable, fail-closed launcher for the prepared typecheck suite."""
import datetime, hashlib, json, os, subprocess, sys
from pathlib import Path
BASE=Path('/tmp/name-handling-seven-package-check-v2')
GO=BASE/'root-go.json'; PLAN=BASE/'plan.json'; MANIFEST=BASE/'runner-input-manifest.json'; RUNS=BASE/'launcher-runs'
def sha(path):
    with Path(path).open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()
def utc(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(path,obj):
    path=Path(path); tmp=path.with_name(path.name+'.writing'); tmp.write_text(json.dumps(obj,sort_keys=True,indent=2)+'\n'); os.replace(tmp,path)
if not GO.is_file():
    write(BASE/'launch-preflight-refusal.json',{'status':'STOP no root GO; no runner or Cargo started','utc':utc(),'runner_started':False,'cargo_started':False,'reason':'root-go.json absent'})
    print('STOP: post-18 root GO absent; no runner or Cargo started'); raise SystemExit(2)
if not MANIFEST.is_file() or json.loads(GO.read_text()).get('runner_input_manifest_sha256') != sha(MANIFEST): raise SystemExit('STOP: GO does not pin exact runner-input manifest')
manifest=json.loads(MANIFEST.read_text())
for path,expected in manifest['inputs'].items():
    if sha(path)!=expected: raise SystemExit('STOP: runner input changed: '+path)
if json.loads(GO.read_text()).get('plan_sha256') != sha(PLAN): raise SystemExit('STOP: GO does not pin exact plan')
input_paths=[Path(p) for p in manifest['inputs']]+[MANIFEST,GO]
inputs={str(p):sha(p) for p in input_paths}; RUNS.mkdir(exist_ok=True)
tag=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ'); receipt=RUNS/tag; receipt.mkdir(); transcript=receipt/'launcher.transcript'
meta={'started_utc':utc(),'input_pins_before':inputs,'plan_sha256':sha(PLAN),'manifest_sha256':sha(MANIFEST),'root_go_sha256':sha(GO),'transcript':str(transcript),'durable_file_backed_output':True}
write(receipt/'launcher.json',meta)
env=os.environ.copy(); env['CARGO_TARGET_DIR']=json.loads(PLAN.read_text())['target_dir']
with transcript.open('xb') as out: child=subprocess.run([sys.executable,str(BASE/'suite.py')],cwd='/workspace/naming-migration-active/tcl-lsp',env=env,stdout=out,stderr=subprocess.STDOUT,check=False)
meta.update({'finished_utc':utc(),'exit_code':child.returncode,'input_pins_after':{str(p):sha(p) for p in input_paths},'root_go_sha256_after':sha(GO)})
meta['inputs_stable']=meta['input_pins_after']==inputs; meta['root_go_stable']=meta['root_go_sha256_after']==meta['root_go_sha256']; write(receipt/'launcher.json',meta)
try: print(transcript.read_text(errors='replace')[-12000:],end='')
except (BrokenPipeError,OSError): pass
raise SystemExit(child.returncode if meta['inputs_stable'] and meta['root_go_stable'] else 2)
