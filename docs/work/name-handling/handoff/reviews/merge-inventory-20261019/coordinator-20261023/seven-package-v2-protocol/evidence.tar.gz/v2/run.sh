#!/bin/sh
exec python3 /tmp/name-handling-seven-package-check-v2/launch.py "$@"
