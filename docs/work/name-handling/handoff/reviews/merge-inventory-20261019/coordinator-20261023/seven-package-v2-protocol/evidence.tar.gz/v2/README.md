# Seven-package all-target typecheck protocol

This is an off-tree runnable suite for the exact 18-path product. It has not been launched against a build. Its no-GO preflight has been tested; it refuses before lock acquisition or Cargo. It makes no runtime or release-acceptance claim.

`run.sh` launches `launch.py`, which validates the root GO against the exact runner-input manifest and plan, checks every input hash, and writes durable launcher stdout plus before/after input and GO hashes. `suite.py` independently repeats the pinned-input checks before any lock or build. A post-18 GO must supply the source commit, exact plan and runner-manifest digests, source18-manifest digest, and approved integrated HEAD. The GO does not exist yet; no runtime has been queued.

The sole Cargo argv is in `plan.json`: direct pinned Cargo `check --locked --keep-going --all-targets --message-format=json` with exactly `tcl-compiler`, `tcl-lsp-core`, `tcl-lsp-db`, `tcl-lsp-server`, `tcl-vm`, `tcl-fuzz`, and `tcl-spectcl`. `CARGO_TARGET_DIR` is explicit. This compiles all targets but runs no tests.

Before execution, the suite requires the exact18 final hashes and their 3b1 baselines, the approved HEAD ancestry, equality of every other product path to 3b1, and docs-only descendants after the approved integration. It snapshots source and provider manifests plus HEAD and GO before/after, and takes the shared build lock exclusively before Cargo. It invokes the reviewed `guarded-exec.run` directly with the absolute Cargo binary as argv[0] and artifact, a 3600 second deadline, 20 MiB combined durable stdout/stderr cap, and 2 GiB free-space guard on actual workspace, temporary, target, and receipt paths. No polling wrapper or secondary process cleanup loop is used.

The suite rejects Cargo JSON compiler warnings/errors, build-script diagnostics, warning lines on stdout/stderr, malformed nonempty stdout, nonzero Cargo exit, any executor lifecycle/artifact/hash failure, or any changed source/provider/GO/HEAD seal. It writes process, diagnostics, source/provider snapshots, final receipt, and a durable transcript with `LOCK_RELEASED` after unlocking. A failing or incomplete guard/build fails closed.

The result covers compilation only. It provides no test execution, runtime, ABI, performance, or release-acceptance evidence.

Version note: v1 was superseded after peer review found missing under-lock rechecks and build-script warning checks. This v2 directory is the immutable candidate for review.
