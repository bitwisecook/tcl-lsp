/workspace/.rustup/toolchains/1.99.1-x86_64-unknown-linux-gnu/bin/cargo test --locked -p bpf-tcl-ir --lib --no-run --message-format=json
