/workspace/naming-migration-active/tcl-lsp/target/debug/deps/optimiser-583f1f7a12abf4be a_braced_expr_word_with_no_nested_write_still_folds --exact --nocapture --test-threads=1
