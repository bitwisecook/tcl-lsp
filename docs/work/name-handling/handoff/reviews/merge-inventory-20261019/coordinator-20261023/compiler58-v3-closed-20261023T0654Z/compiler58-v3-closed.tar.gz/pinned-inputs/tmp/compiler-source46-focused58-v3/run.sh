#!/bin/sh
exec python3 /tmp/compiler-source46-focused58-v3/launch.py "$@"
