/workspace/.rustup/toolchains/1.99.1-x86_64-unknown-linux-gnu/bin/cargo test --locked -p tcl-compiler --test var_escape_residual2 --no-run --message-format=json
