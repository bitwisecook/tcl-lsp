from pathlib import Path
import json,hashlib,datetime,subprocess,shutil
root=Path('/workspace/naming-migration-active/tcl-lsp')
v1=json.loads(Path('/tmp/coordinator-next-prefix-20261023T034858Z/manifest.json').read_text());v2=json.loads(Path('/tmp/coordinator-next-prefix-v2-20261023T040545Z/manifest.json').read_text())
components=[{'name':x['name'],'path':x['path'],'sha256':x['sha256'],'strip':x['strip']} for x in v1['components'] if x['name']!='quote']
components += [{'name':x['name'],'path':x['patch_path'],'sha256':x['patch_sha256'],'strip':x['strip']} for x in v2['components']]
components += [{'name':'body_issuer_v3','path':'/tmp/compiler-names-body-syntax-source-v3/proposal.patch','sha256':'9bdae8732b912cdf9e6c41c0db54be84ffc320ced0e549672bf9ba6a75d3687d','strip':0},{'name':'quote_body_consumer_v1','path':'/tmp/lsp-quote-body-source-consumer-v1/proposal.patch','sha256':'2834a8b696df8de875c8b598036bcd3bc22974f16e7ed8bd74682833c38b437f','strip':0}]
components += [{'name':'jim_owner_diagnostic_v1','path':'/tmp/compiler-jim-source-stage-diagnostic-v1/proposal.patch','sha256':'68062b5d24c349cce626d7bda30da5ba759137c4d642152d5fe0a2bc05e4d9e5','strip':1},{'name':'ccg_structural_lint_v1','path':'/tmp/ccg-source30-ci5206-lint-v1/proposal.patch','sha256':'684f27d791d1d7f8d9c6bcc71a6969c8171ade8680bdeca72412f6f8e92c7401','strip':0}]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
base=Path('/tmp/coordinator-next-batch-v4-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ'));base.mkdir();shadow=base/'shadow';verify=base/'verify';paths=[]
for c in components:
 assert sha(c['path'])==c['sha256']
 for line in Path(c['path']).read_text().splitlines():
  if line.startswith('--- '):
   path='/'.join(line[4:].split('\t')[0].split('/')[c['strip']:]);assert path.startswith('rust/') and '..' not in Path(path).parts
   if path not in paths:paths.append(path)
before={p:sha(root/p) for p in paths}
for stage in [shadow,verify]:
 for p in paths:
  (stage/p).parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/p,stage/p)
for c in components:
 r=subprocess.run(['patch','--batch','--fuzz=0','-p'+str(c['strip']),'-i',c['path']],cwd=shadow,capture_output=True,text=True);c['apply']={'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr};assert r.returncode==0 and 'offset' not in (r.stdout+r.stderr).lower(),c
final={p:sha(shadow/p) for p in paths};patch=base/'combined.patch'
with patch.open('wb') as out:
 for p in paths:
  r=subprocess.run(['diff','-u','--label',p,'--label',p,str(root/p),str(shadow/p)],capture_output=True);assert r.returncode in [0,1];out.write(r.stdout)
r=subprocess.run(['patch','--batch','--fuzz=0','-p0','-i',str(patch)],cwd=verify,capture_output=True,text=True);assert r.returncode==0 and 'offset' not in (r.stdout+r.stderr).lower();assert all(sha(verify/p)==final[p] for p in paths)
fmt=[]
for p in paths:
 r=subprocess.run(['/workspace/.rustup/toolchains/1.99.1-x86_64-unknown-linux-gnu/bin/rustfmt','--edition','2024','--config','skip_children=true','--check',str(shadow/p)],capture_output=True,text=True);fmt.append({'path':p,'exit':r.returncode,'output':r.stdout+r.stderr})
assert all(r['exit']==0 for r in fmt),fmt
assert all(sha(root/p)==before[p] for p in paths)
prior=subprocess.check_output(['git','diff','--name-only','3b1a750be337993a85ec533d84546e1d827dd9a8','4d4ab9e6a7d3b141ce55f16b8ca98f462e609e57','--','.',':(exclude)docs/work/name-handling'],cwd=root,text=True).splitlines()
data={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base_head':'4d4ab9e6a7d3b141ce55f16b8ca98f462e609e57','base_tree':'9259245b902c9dff672c5978a9ee3e5c1cddbdd6','components':components,'paths':paths,'path_count':len(paths),'before_sha256':before,'final_sha256':final,'combined_patch_sha256':sha(patch),'reapply':{'exit':r.returncode,'final_hashes_match':True,'zero_fuzz_no_offsets':True},'format':fmt,'prior_source30_paths':prior,'cumulative_vs_3b1_paths':sorted(set(prior+paths)),'cumulative_path_count':len(set(prior+paths)),'canonical_unchanged':True,'status':'OFFTREE composition/static only. All component boundedstaticpeers CLEAR; no typing/runtime/GO/integration. Case-list excluded.'}
(base/'manifest.json').write_text(json.dumps(data,indent=2)+'\n');Path('/tmp/naming-next-batch-v4-path').write_text(str(base)+'\n');print(json.dumps({'directory':str(base),'paths':len(paths),'cumulative':len(set(prior+paths)),'combined_sha256':sha(patch),'manifest_sha256':sha(base/'manifest.json'),'fmt_pass':len(fmt)}))
