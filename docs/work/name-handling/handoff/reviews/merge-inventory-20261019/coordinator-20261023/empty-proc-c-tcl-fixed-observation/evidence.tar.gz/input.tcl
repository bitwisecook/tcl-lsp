proc retained {} {}; puts [list [info patchlevel] [llength [info args retained]] [string length [info body retained]] [string length [retained]]]
