#!/bin/bash
set -u
source /tmp/tcl-lsp-naming-env.sh
exec python3 /tmp/compiler-source30-diagnostics-v1/suite.py "$1"
