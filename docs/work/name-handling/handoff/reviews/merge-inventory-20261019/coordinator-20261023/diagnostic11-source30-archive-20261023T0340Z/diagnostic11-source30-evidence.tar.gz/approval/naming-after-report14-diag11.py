from pathlib import Path
import json,hashlib,time,datetime,subprocess,os
report=Path('/tmp/compiler-authenticated-report-focused14-v6-source30-runs/20261023T031436.856477Z')
launch=report.parent/'20261023T031434.015133Z/launcher.json'
nextbase=Path('/tmp/compiler-source30-diagnostics-v1')
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
while not (report/'final.json').is_file() or not json.loads(launch.read_text()).get('finished_utc'):time.sleep(5)
f=json.loads((report/'final.json').read_text());l=json.loads(launch.read_text());rows=json.loads((report/'results.json').read_text());plan=json.loads((report/'plan.json').read_text())
assert f['results']==2 and f['selected']==14 and len(rows)==2
assert all(f[k] is True for k in ['source_stable','providers_stable','artifact_stable','all2_direct_child_timers_valid'])
assert l['inputs_stable'] and l['root_go_stable'] and l['exit_code']==f['overall_exit']
assert 'LOCK_RELEASED ' in Path(l['transcript']).read_text()
for r,e in zip(rows,plan['required_filters'],strict=True):
 assert r['selector']==e['selector'] and r['actual_selected']==e['expected_selected'] and r['started_counts']==[e['expected_selected']] and len(r['summaries'])==1
 status,passed,failed,ignored=r['summaries'][0];passed,failed,ignored=map(int,(passed,failed,ignored))
 assert ignored==0 and passed+failed==e['expected_selected'] and r['exit_code']==(101 if failed else 0) and (status=='ok')==(failed==0)
 assert not r['warnings'] and all(r[k] is True for k in ['source_stable','providers_stable','artifact_stable'])
 assert all(r['process'][k] is True for k in ['complete','timer_armed_before_spawn','group_empty_before_parent_reap']) and r['process']['stop_reason'] is None
assert h(nextbase/'plan.json')=='4a3f2a6ca28622df267c03e0975f67bd2234ec72c9f5a5da3d08acf41202c5d8'
assert h(nextbase/'runner-input-manifest.json')=='509f1863668e8f8e30b9313749167a5a9f87166446a814ddeba391cb57487f3a'
g=Path('/tmp/naming-diag11-reviewed-pending-go.json').read_bytes()
with (nextbase/'root-go.json').open('xb') as out:out.write(g)
receipt={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'prerequisite_report14_final_sha256':h(report/'final.json'),'report14_actual_exit':f['overall_exit'],'report14_guard_validated':True,'next_root_go_sha256':h(nextbase/'root-go.json'),'next_plan_sha256':h(nextbase/'plan.json'),'next_runner_manifest_sha256':h(nextbase/'runner-input-manifest.json'),'test_failures_permitted':True,'source_hold_continues':True}
Path('/tmp/naming-after-report14-diag11-allocation.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
with Path('/tmp/naming-diag11-chain-launch.log').open('xb') as log:
 r=subprocess.run(['bash','-c','. /tmp/tcl-lsp-naming-env.sh\nexec python3 /tmp/compiler-source30-diagnostics-v1/launch.py'],cwd='/workspace/naming-migration-active/tcl-lsp',stdout=log,stderr=subprocess.STDOUT,check=False)
print('DIAG11_LAUNCHER_EXIT',r.returncode,flush=True)
raise SystemExit(r.returncode)
