"""One bounded real-LSP measurement case; the existing direct executor owns its process group."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,os,threading,time,sys,shutil
BASE=Path(__file__).resolve().parent

def require(v,m):
 if not v:raise RuntimeError(m)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
p=argparse.ArgumentParser();p.add_argument('--server',required=True,type=Path);p.add_argument('--case',required=True);p.add_argument('--out',required=True,type=Path);p.add_argument('--project',type=Path);p.add_argument('--relative-file');a=p.parse_args();a.out.mkdir();pins=json.loads((BASE/'input-pins.json').read_text());root=Path(pins['root'])
for rel,pin in pins['pins'].items():require(sha(root/rel)==pin,'measurement input changed '+rel)
lsp=load('shipping_lsp_client',root/'.claude/skills/lsp-client/lsp_client.py');bench=load('shipping_bench',root/'scripts/perf/bench.py');workspace=a.out/'workspace';workspace.mkdir();case=a.case;source='proc p00000000 {} {return 42}\np00000000\n';count=1
if case.startswith('flat-'):
 count=int(case.split('-')[1]);source=''.join(f'proc p{i:08} {{}} {{}}\np{i:08}\n' for i in range(count))
elif case.startswith('source-'):
 count=int(case.split('-')[1]);source='source {hop00000.tcl}\n'
 for i in range(count):
  text=f'source {{hop{i+1:05}.tcl}}\n' if i+1<count else 'proc deep_leaf {} {return 42}\n'
  (workspace/f'hop{i:05}.tcl').write_text(text)
elif case.startswith('project-'):
 count=int(case.split('-')[1])
 for i in range(count):(workspace/f'file{i:05}.tcl').write_text(f'proc project_{i:05} {{}} {{return {i}}}\n')
elif case=='large-file':
 source=''.join(f'set value{i:05} {i}\n' for i in range(20000))
elif case=='corpus-file':
 require(a.project and a.project.is_dir() and a.relative_file,'actual project and relative file required')
 rel=Path(a.relative_file);require(not rel.is_absolute() and '..' not in rel.parts,'relative source path required')
 shutil.copytree(a.project,workspace,dirs_exist_ok=True,ignore=shutil.ignore_patterns('.git','target','node_modules','.vscode-test'),symlinks=True)
 require(not any(p.is_symlink() for p in workspace.rglob('*')),'external symlink input refused')
 source=(workspace/rel).read_text();count=sum(p.is_file() for p in workspace.rglob('*'))
else:require(case=='typical','unknown case')
path=workspace/Path(a.relative_file) if case=='corpus-file' else workspace/'main.tcl';path.write_text(source);fixture_pins={str(p.relative_to(workspace)):sha(p) for p in workspace.rglob('*') if p.is_file()};uri=path.as_uri();events=[];client=lsp.LspClient(str(workspace),[str(a.server)]);sampler=None;result={'case':case,'workload_files':len(fixture_pins),'main_bytes':len(source.encode()),'fixture_pins':fixture_pins,'events':events,'status':'INCOMPLETE'}
def timed(label,method,params):
 t=time.perf_counter_ns()
 try:
  value=client.send_request(method,params,timeout=30);events.append({'event':label,'elapsed_ms':(time.perf_counter_ns()-t)/1e6,'outcome':'response','response_sha256':hashlib.sha256(json.dumps(value,sort_keys=True).encode()).hexdigest()});return value
 except Exception as exc:
  events.append({'event':label,'elapsed_ms':(time.perf_counter_ns()-t)/1e6,'outcome':'error','error':str(exc)});raise
try:
 client.start();sampler=bench.Sampler(client.process.pid);sampler.start();lsp.initialize(client)
 # First query is deliberately not retried and does not wait for scan readiness.
 opened=time.perf_counter_ns();client.send_notification('textDocument/didOpen',{'textDocument':{'uri':uri,'languageId':'tcl','version':1,'text':source}})
 first=timed('cold-first-tokens','textDocument/semanticTokens/full',{'textDocument':{'uri':uri}});require(isinstance(first,dict) and isinstance(first.get('data'),list) and bool(first['data']),'first token response unavailable');result['didOpen_to_first_tokens_ms']=(time.perf_counter_ns()-opened)/1e6
 scan=time.perf_counter_ns();client.wait_for_workspace_scan(timeout=30);events.append({'event':'independent-workspace-scan-barrier','elapsed_ms':(time.perf_counter_ns()-scan)/1e6})
 timed('diagnostic-revision-barrier','textDocument/diagnostic',{'textDocument':{'uri':uri}})
 for version in range(2,22):
  text=source+f'\nset revision_marker {version}\n';t=time.perf_counter_ns();client.send_notification('textDocument/didChange',{'textDocument':{'uri':uri,'version':version},'contentChanges':[{'text':text}]});value=timed('warm-edit-tokens','textDocument/semanticTokens/full',{'textDocument':{'uri':uri}});require(isinstance(value,dict) and isinstance(value.get('data'),list),'warm token response unavailable');events[-1]['edit_to_response_ms']=(time.perf_counter_ns()-t)/1e6;events[-1]['version']=version
 timed('references','textDocument/references',{'textDocument':{'uri':uri},'position':{'line':0,'character':6},'context':{'includeDeclaration':True}})
 timed('code-lens','textDocument/codeLens',{'textDocument':{'uri':uri}})
 timed('prepare-rename','textDocument/prepareRename',{'textDocument':{'uri':uri},'position':{'line':0,'character':6}})
 # Observe the exact request ID when written, then cancel that in-flight request.
 written=threading.Event();record={};send=client._send;send_lock=threading.Lock()
 def observed_send(data,**kwargs):
  with send_lock:answer=send(data,**kwargs)
  if data.get('method')=='textDocument/references' and 'id' in data:record['id']=data['id'];written.set()
  return answer
 client._send=observed_send
 def overlapping():
  try:record['response']=client.send_request('textDocument/references',{'textDocument':{'uri':uri},'position':{'line':0,'character':6},'context':{'includeDeclaration':True}},timeout=30);record['outcome']='completed'
  except Exception as exc:record['outcome']='error';record['error']=str(exc)
 t=time.perf_counter_ns();thread=threading.Thread(target=overlapping,daemon=True);thread.start();require(written.wait(30),'overlap request not written');client.send_notification('$/cancelRequest',{'id':record['id']});client.send_notification('textDocument/didChange',{'textDocument':{'uri':uri,'version':22},'contentChanges':[{'text':source+'\nset revision_marker 22\n'}]});timed('post-cancel-current-tokens','textDocument/semanticTokens/full',{'textDocument':{'uri':uri}});thread.join(timeout=30);require(not thread.is_alive(),'cancelled/overlapping request did not terminate');record.pop('response',None);events.append({'event':'cancellation-overlap','elapsed_ms':(time.perf_counter_ns()-t)/1e6,**record})
 # Lifecycle churn is measured separately from ordinary warm edits.
 for i in range(3):
  client.send_notification('textDocument/didClose',{'textDocument':{'uri':uri}});client.send_notification('workspace/didChangeConfiguration',{'settings':{'tclLsp':{'dialect':('tcl9.0' if i%2 else 'tcl8.6')}}});client.send_notification('textDocument/didOpen',{'textDocument':{'uri':uri,'languageId':'tcl','version':100+i,'text':source}});timed('reopen-tokens','textDocument/semanticTokens/full',{'textDocument':{'uri':uri}})
 status=Path(f'/proc/{client.process.pid}/status').read_text();result['linux_vm_hwm_kib']=next(int(x.split()[1]) for x in status.splitlines() if x.startswith('VmHWM:'));result['retained_rss_after_churn']=sampler.latest();result['status']='MEASURED_NOT_ADMITTED'
except Exception as exc:result['error']=str(exc);raise
finally:
 if sampler:sampler.stop();result['sampled_rss_cpu_timeline']=sampler.samples;result['sampled_peak_rss_kib']=max((x['rss_kib'] for x in sampler.samples),default=None)
 result['last_request_method']=client.last_request_method;result['last_request_id']=client.last_request_id
 for line in client.get_stderr_lines():print(line,file=sys.stderr)
 client.shutdown();result['server_exit']=client.process.returncode if client.process else None;result['fixture_pins_after']={str(p.relative_to(workspace)):sha(p) for p in workspace.rglob('*') if p.is_file()};result['fixture_bytes_stable']=result['fixture_pins_after']==fixture_pins;result['server_sha256_after']=sha(a.server);(a.out/'measurement.json').write_text(json.dumps(result,indent=2)+'\n')
