OFF-TREE native latency/cancellation/RSS measurement protocol. UNRUN.

Authoritative acceptance sources
- naming-migration-review-20261022.md section E (lines144–153): actual release builds, representative small/large projects, cold/warm, open→first tokens, edits, diagnostics convergence, references/rename/code lenses, cancellation/overlap, peak/retained memory across lifecycle/environment/package/source changes; browser separately when shipped.
- engineering-guide.md first tokens: typical files target single-digit milliseconds; regressions beyond run noise block.
- Forty milliseconds is the fast-tier delivery mechanism, not a universal request SLA.
- No numeric memory ceiling or approved maximum workspace/long-request SLA exists in the review. This protocol records bounded workload sizes and memory/timings; it does NOT invent memory acceptance or produce release PASS. A baseline that itself stalls is not an acceptable shipping justification.

Reused implementation and fixtures
- Actual pinned .claude/skills/lsp-client/lsp_client.py transport, initialization, independent workspace-scan barrier and ordinary lifecycle methods.
- Actual pinned scripts/perf/bench.py Sampler, Linux RSS/CPU implementation; add kernel VmHWM for high-water RSS before shutdown.
- Reviewed 88125 guarded-exec direct process authority; 180s per complete session, combined stdout/stderr20MiB, >=2GiB filesystem floor, group-empty-before-reap and artifact hash guards. These are operational containment limits, NOT request/memory acceptance bounds.
- run5.sh is historical build/debug probe orchestration; NEVER run it here (it copies Rust, builds and deletes targets). Its original scaling_rows sizes are reused as source shapes: flat P25/50/100/200 and source chain F250/500/1000/2000, code-lens P25/50/100. All source-depth stress is labelled separately from representative typical files.
- Original e2e naming_source_views source-chain pattern and the common native pull-diagnostics barrier are reused; no repeated naming requests repair a measurement.

Current artifact availability / profile warning
- Baseline run39816429638, fullSHA fcb7927f02b5395753247b322fdd7be87ae5c731: artifact12441329895 named tcl-lsp-server-release, ZIP SHA2c5ed6e7abd1a59a9bf6915a5f575bae52e7646fee16cf51ac33cafe7abb0b4b, available snapshot, expires2026-10-23T16:49:40Z.
- Candidate run39948576685, c611…: artifact list EMPTY at protocol preparation. No executable or full SHA fabricated.
- Despite its name, tcl-lsp-server-release is uploaded from target/ci after cargo build --profile ci. ci inherits release opt-level3 but sets LTO=false,16codegenunits. Actual shipping release uses thinLTO,1codegenunit. Neither this label nor a debug e2e server proves shipping measurements.
- Real shipping build-server-matrix uploads server-bins-<platform>-server with target/<triple>/release/server and build command/provenance; it only runs on tags or native_release_build_proof dispatches. No exact baseline shipping artifact is currently established. Root must provide actual release-profile artifacts for BOTH exact source revisions. Contextual ci-profile pair is allowed only with explicit --context-ci-profile and is marked ci-context-only.
- Pin API artifact metadata, actual build log, downloaded ZIP digest, exact ZIP-member binary digest, full source40SHA, runID, target and profile. measure.py validates those joins before spawning a server. Never extract a benchmark executable from an unjoined nextest/debug archive.

Artifact JSON (actual values required; no sample fake values are runnable)
{
 "baseline": {
  "run_id":39816429638, "head_sha":"<actual full40SHA>",
  "artifact_id":<actual ID>, "artifact_metadata_path":"<actual single API artifact record JSON>", "artifact_metadata_sha256":"<actual SHA256>",
  "build_log_path":"<actual completed producer job log>", "build_log_sha256":"<actual SHA256>",
  "zip_path":"<downloaded ZIP>", "artifact_zip_sha256":"<GitHub digest hex>", "zip_member":"<exact binary member>",
  "server_path":"<extracted native binary>", "server_sha256":"<actual SHA256>",
  "target":"x86_64-unknown-linux-gnu", "profile":"release"
 },
 "candidate": {"same fields, exact run_id":39948576685}
}
The supplied baseline/candidate full source must match the fixed fcb7927f…/c611… pair. API metadata head/run and digest must match. Root authorizes the actual bound artifact JSON; mere editable labels are not artifact provenance.

Runnable commands (PREPARED ONLY; do not execute before artifact allocation)
python3 /tmp/lsp-shipping-latency-protocol-v1/measure.py --artifacts /tmp/actual-server-pair.json --case typical --pairs 5 --out /tmp/fresh-typical-pairs
python3 /tmp/lsp-shipping-latency-protocol-v1/measure.py --artifacts /tmp/actual-server-pair.json --case corpus-file --project /tmp/verified-corpus-stage/SpiceGenTcl --relative-file src/generalClasses.tcl --pairs 5 --out /tmp/fresh-real-project-pairs
python3 /tmp/lsp-shipping-latency-protocol-v1/measure.py --artifacts /tmp/actual-server-pair.json --case flat-100 --pairs 5 --out /tmp/fresh-flat100-pairs
Repeat exact fixed flat cases25/50/100/200, source250/500/1000/2000, project25/200, large-file(20000assignments); keep stress and representative samples separate. 'typical' alone is a tiny controlled microfixture, NOT proof of representative-project target. Actual representative Tcl files must come from the existing verified corpus at MANIFEST.toml commits, with project/file identity recorded. Do not fetch/install/build through this tool. Use the existing perf workflow/corpus fetchers to supply verified inputs under root allocation.

Execution and interpretation
- Five cold sessions per role/case; alternating baseline/candidate order reduces ordering bias. Same host, providers and exact workload bytes; record all repeats, not a best run. Fresh output mandatory. No retries, synthesized success, timeout increases or target cleanup.
- First semantic request immediately follows didOpen, before waiting for the independent scan. Count its latency from before sending didOpen and require nonempty token response. Then independently await documented scan readiness and actual pull-diagnostic revision barrier. First-request errors/refusals are retained; no 'settling' token retry hides them.
- Twenty warm full-text edits produce raw edit→token round trips. Navigation/reference/code-lens/prepareRename measurements use same session. Cancellation sends $/cancelRequest for the exact observed in-flight references ID while a new edit and token request overlap. Completed-before-cancel races are recorded, not called cancellation success. Inspect actual response/error plus continued responsiveness; cancellation semantic correctness remains the native e2e contract.
- Three close/config/open cycles alternate Tcl8.6/Tcl9.0 selected environment and retain memory samples. Kernel VmHWM is process high water; sampled RSS is labelled sampled. Package reload/cross-source provider churn and browser/WASM retained memory remain required separate measurements; no full SectionE/F coverage claim from this subset.
- Each output contains artifact-bound direct process receipt, workload hashes before/after, all event results/timings, sampled CPU/RSS, kernel peak and end-of-churn memory. An incomplete process, refusal, timeout or changed artifact stops the case with retained evidence. A result named MEASURED_NOT_ADMITTED is never PASS.
- Compare distributions/paired differences and measurement noise; report actual stalls and supported-size risk. No invented percentage regression or memory allowance. Root must record actual supported workload/memory disposition before release. Re-run same shipping source after fixes; ci-profile or stale source observations cannot close F.
