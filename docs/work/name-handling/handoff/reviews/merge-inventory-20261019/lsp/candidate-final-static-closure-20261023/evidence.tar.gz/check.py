from pathlib import Path
import os,re,json,datetime,urllib.parse,hashlib
r=Path('/workspace/naming-lsp-release/tcl-lsp');out=Path('/tmp/lsp-candidate-final-closure-v1');files=[]
for d,ds,fs in os.walk(r):
 ds[:]=[x for x in ds if x not in {'.git','node_modules','target','.vscode-test','corpus','servers'}]
 files.extend(Path(d)/x for x in fs)
missing=[];fragment=[];checked=0;mdcount=0
for p in files:
 if p.suffix!='.md':continue
 mdcount+=1;s=p.read_text(errors='replace');s=re.sub(r'```.*?```','',s,flags=re.S)
 refs=dict((k.lower(),v) for k,v in re.findall(r'^\s*\[([^\]]+)\]:\s*<?([^\s>]+)>?',s,re.M))
 urls=re.findall(r'!?\[[^\]]*\]\(\s*(<[^>]+>|[^\s)]+)(?:\s+[^)]*)?\)',s)
 urls += re.findall(r'(?:href|src)=[\"\']([^\"\']+)',s)
 urls += [refs[b.lower()] for a,b in re.findall(r'\[([^\]]+)\]\[([^\]]+)\]',s) if b.lower() in refs]
 for u in urls:
  u=urllib.parse.unquote(u.strip('<>'))
  if re.match(r'^[a-zA-Z][\w+.-]*:',u) or u.startswith('//'):continue
  path,_,frag=u.partition('#');path=path.split('?')[0]
  target=(r/path.lstrip('/')) if path.startswith('/') else (p.parent/path)
  target=target.resolve() if path else p
  checked+=1
  if not target.exists():missing.append({'source':str(p.relative_to(r)),'url':u});continue
  if frag and target.suffix=='.md':
   content=target.read_text(errors='replace');heads=[];counts={}
   for h in re.findall(r'^#{1,6}\s+(.+?)(?:\s+#+)?$',content,re.M):
    h=re.sub('<[^>]+>','',h);h=re.sub('[`*~]','',h).lower();h=re.sub(r'[^\w\- ]','',h).replace(' ','-');n=counts.get(h,0);counts[h]=n+1;heads.append(h+(('-'+str(n)) if n else ''))
   heads+=re.findall(r'(?:id|name)=["\']([^"\']+)',content)
   if frag not in heads:fragment.append({'source':str(p.relative_to(r)),'url':u})
# Process language candidates only: runtime authority/currentness terms deliberately excluded.
chaff=[]
pat=re.compile(r'(?i)\b(?:handoff|work\s*log|resume\s+prompt|intermediate\s+commit|next\s+batch|WIP\s+snapshot|migration\s+ledger|sweep\s+ledger|session\s+transcript|probe-corpus)\b')
for p in files:
 if p.suffix not in {'.md','.json','.toml','.yml','.yaml'}:continue
 for n,line in enumerate(p.read_text(errors='replace').splitlines(),1):
  if pat.search(line):chaff.append({'path':str(p.relative_to(r)),'line':n,'text':line[:350]})
result={'actual_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'markdown_files':mdcount,'links_checked':checked,'missing_paths':missing,'missing_fragments':fragment,'process_language_candidates':chaff}
(out/'links-and-chaff.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v if not isinstance(v,list) else len(v) for k,v in result.items()}))
