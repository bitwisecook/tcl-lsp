import pathlib,json,re,ast,datetime,hashlib,collections
out=pathlib.Path('/tmp/lsp-release-fixture-closure-audit-v1');root=pathlib.Path('/workspace/naming-lsp-release/tcl-lsp');work=pathlib.Path('/workspace/naming-migration-active/tcl-lsp');old=json.loads((out/'include-closure-final-v2.json').read_text());tree=ast.parse((out/'audit.py').read_text());token=re.compile(r'r(?P<h>\#{0,8})".*?"(?P=h)|"(?:\\.|[^"\\])*"|//[^\n]*|/\*.*?\*/|[A-Za-z_]\w*|\S',re.S);exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef)],type_ignores=[]),'pure','exec'))
def close(ts,i):
 pairs={'(':')','{':'}','[':']'};stack=[pairs[ts[i][0]]];j=i+1
 while stack:
  t=ts[j][0]
  if t in pairs:stack.append(pairs[t])
  elif t==stack[-1]:stack.pop()
  j+=1
 return j-1
def args(ts,start,end):
 result=[];i=start;a=[]
 while i<end:
  if ts[i][0] in {'(','{','['}:
   j=close(ts,i);a.extend(x[0] for x in ts[i:j+1]);i=j+1;continue
  if ts[i][0]==',':
   if a:result.append(a);a=[]
  else:a.append(ts[i][0])
  i+=1
 if a:result.append(a)
 return result
def subst(expr,binding):
 result=[];i=0
 while i<len(expr):
  if expr[i]=='$' and i+1<len(expr) and expr[i+1] in binding:result.append(json.dumps(binding[expr[i+1]]));i+=2
  else:result.append(expr[i]);i+=1
 return result
results=[]
for consumer in sorted({r['consumer'] for r in old['rows'] if r['status']=='unresolved-macro-expression'}):
 p=root/consumer;s=p.read_text();ts=toks(s);defs=[]
 for i in range(len(ts)-4):
  if ts[i][0]=='macro_rules' and ts[i+1][0]=='!':
   name=ts[i+2][0];opening=i+3
   if ts[opening][0] not in {'{','('}:continue
   end=close(ts,opening);k=opening+1
   while k<end and ts[k][0]!='(':k+=1
   if k>=end:continue
   paramend=close(ts,k);params=[]
   for n in range(k,paramend-2):
    if ts[n][0]=='$' and ts[n+2][0]==':':params.append(ts[n+1][0])
   defs.append({'name':name,'start':i,'end':end,'params':params,'bindings':[]})
 calls=[]
 for i in range(len(ts)-3):
  if ts[i+1][0]!='!' or ts[i+2][0] not in {'(','{','['}:continue
  choices=[d for d in defs if d['name']==ts[i][0] and d['start']<i]
  if not choices:continue
  d=max(choices,key=lambda d:d['start']);owner=next((z for z in reversed(defs) if z['start']<i<z['end']),None);end=close(ts,i+2);calls.append((d,owner,args(ts,i+3,end),i))
 for repeat in range(8):
  changed=False
  for d,owner,aa,i in calls:
   envs=owner['bindings'] if owner else [{}]
   for env in envs:
    vals=[]
    for a in aa:
     a=subst(a,env)
     try:vals.append(evalexpr(a,p.parent))
     except Exception:vals.append(None)
    if len(vals)!=len(d['params']):continue
    bind={k:v for k,v in zip(d['params'],vals) if v is not None}
    if bind and bind not in d['bindings']:d['bindings'].append(bind);changed=True
  if not changed:break
 for row in [r for r in old['rows'] if r['status']=='unresolved-macro-expression' and r['consumer']==consumer]:
  ii=[i for i,(v,pos) in enumerate(ts) if v==row['macro'] and s.count('\n',0,pos)+1==row['line']];assert len(ii)==1;ii=ii[0];end=close(ts,ii+2);expr=[x[0] for x in ts[ii+3:end]];owner=next((d for d in reversed(defs) if d['start']<ii<d['end']),None);paths=[]
  for bind in owner['bindings'] if owner else [{}]:
   try:
    value=evalexpr(subst(expr,bind),p.parent)
    if '<ENV:' in value:paths.append({'status':'generated-environment-path','target':value,'binding':bind});continue
    q=(p.parent/value).resolve();rel=str(q.relative_to(root));w=work/rel;paths.append({'target':rel,'status':'present' if q.is_file() else 'OMITTED_REQUIRED' if w.is_file() else 'missing-in-both','binding':bind,'sha256':hashlib.sha256(q.read_bytes()).hexdigest() if q.is_file() else hashlib.sha256(w.read_bytes()).hexdigest() if w.is_file() else None})
   except Exception:pass
  results.append({'consumer':consumer,'line':row['line'],'expression':row['expression'],'owner_macro':owner['name'] if owner else None,'owner_parameters':owner['params'] if owner else [],'literal_invocation_bindings':owner['bindings'] if owner else [],'expanded':paths,'status':'expanded' if paths else 'unresolved'})
d={'actual_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Static literal macro_rules substitution only, no Rust expansion or Cargo; unresolved sites remain obligations','sites':results,'counts':{'sites':len(results),'expanded_sites':sum(bool(r['expanded']) for r in results),'unresolved_sites':sum(not r['expanded'] for r in results),'omitted_unique':len({x['target'] for r in results for x in r['expanded'] if x['status']=='OMITTED_REQUIRED'})}};(pathlib.Path('/tmp/lsp-candidate-final-closure-v1')/'macro-closure-current.json').write_text(json.dumps(d,indent=2)+'\n');print(d['counts']);print([(r['consumer'],r['line'],r['owner_macro']) for r in results if not r['expanded']])
