from pathlib import Path
import re,json,hashlib,ast,datetime,os
r=Path('/workspace/naming-lsp-release/tcl-lsp');o=Path('/tmp/lsp-candidate-final-closure-v1');rows=[];missing=[]
files=[r/'Makefile',*r.glob('.github/workflows/*'),*r.glob('scripts/**/*.sh'),*r.glob('scripts/**/*.py'),*r.glob('scripts/**/*.mjs')]
for p in files:
 if not p.is_file():continue
 for n,line in enumerate(p.read_text(errors='replace').splitlines(),1):
  if line.lstrip().startswith('#'):continue
  for rel in re.findall(r'(?<![\w-])(scripts/[\w./-]+\.(?:py|sh|mjs|js|toml|json|txt|yml|yaml))\b',line):
   row={'source':str(p.relative_to(r)),'line':n,'input':rel,'present':(r/rel).is_file()};rows.append(row)
   if not row['present']:missing.append(row)
p=r/'scripts/perf/paired_bench.py';t=ast.parse(p.read_text());pins={}
for n in t.body:
 if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='PINNED_HARNESS_FILES' for x in n.targets):pins=ast.literal_eval(n.value)
pinned=[]
for rel,pin in pins.items():
 q=r/rel;actual=hashlib.sha256(q.read_bytes()).hexdigest() if q.is_file() else None;pinned.append({'path':rel,'expected':pin,'actual':actual,'matches':actual==pin})
imports=[]
for rel in ['scripts/perf/paired_bench.py','scripts/perf/bench.py','scripts/perf/fetch_corpus.py','.claude/skills/lsp-client/lsp_client.py']:
 q=r/rel
 for n in ast.walk(ast.parse(q.read_text())):
  if isinstance(n,(ast.Import,ast.ImportFrom)):imports.append({'source':rel,'line':n.lineno,'module':ast.unparse(n)})
result={'actual_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'static_literal_script_input_references':rows,'missing':missing,'paired_harness_pins':pinned,'paired_imports':imports,'scope':'Literal repository script/config input references in Makefile/workflows/scripts; generated outputs and external tool/corpus fetch availability are separate runtime prerequisites'}
(o/'script-inputs.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'references':len(rows),'missing':missing,'paired_pins_all_match':all(x['matches'] for x in pinned)},indent=2))
