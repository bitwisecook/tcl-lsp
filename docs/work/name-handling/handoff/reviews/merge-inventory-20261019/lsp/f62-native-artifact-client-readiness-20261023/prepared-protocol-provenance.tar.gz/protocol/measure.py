"""Artifact-provenance-bound measurements; outer Python and inner native server are separately authenticated."""
from pathlib import Path
import argparse,json,hashlib,sys,os,importlib.util,datetime,platform,zipfile
BASE=Path(__file__).resolve().parent
EXPECTED={
    'baseline':(39949992948,'fcb7927f02b5395753247b322fdd7be87ae5c731'),
    'candidate':(39978501863,'f62a9386a6de01e157539c5e504ab5cec8f899e7'),
}
def require(value,message):
    if not value:raise RuntimeError('STOP: '+message)
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def unique(pairs):
    result={}
    for key,value in pairs:
        require(key not in result,'duplicate JSON key '+key);result[key]=value
    return result
def read(path):return json.loads(Path(path).read_text(),object_pairs_hook=unique)
parser=argparse.ArgumentParser();parser.add_argument('--artifacts',required=True,type=Path);parser.add_argument('--artifacts-sha256',required=True);parser.add_argument('--protocol-sha256',required=True);parser.add_argument('--case',required=True);parser.add_argument('--pairs',type=int,default=5);parser.add_argument('--out',required=True,type=Path);parser.add_argument('--project',type=Path);parser.add_argument('--relative-file');args=parser.parse_args()
require(sha(BASE/'manifest.json')==args.protocol_sha256,'exact prepared protocol manifest changed');protocol=read(BASE/'manifest.json')
for name,pin in protocol['files'].items():require(sha(BASE/name)==pin,'protocol input changed '+name)
python=Path(sys.executable).resolve();require(str(python)==protocol['python']['path'] and sha(python)==protocol['python']['sha256'],'actual Python path/hash differs')
require(not args.out.exists() and 1<=args.pairs<=5,'fresh output and one to five pairs required');require(platform.system()=='Linux','VmHWM scope is Linux-only');require(sha(args.artifacts)==args.artifacts_sha256,'artifact binding changed');artifacts=read(args.artifacts)
for role,(run,head) in EXPECTED.items():
    row=artifacts[role];require(row['run_id']==run and row['head_sha']==head,'wrong actual CI source/run pair')
    server=Path(row['server_path']);require(server.is_absolute() and server.resolve()==server and sha(server)==row['server_sha256'],'native server path/hash changed')
    require(row['target']=='x86_64-unknown-linux-gnu' and row['profile']=='release','this protocol accepts only actual same-target shipping release artifacts')
    for key in ['build_log','build_job','artifact_metadata']:
        require(sha(row[key+'_path'])==row[key+'_sha256'],'changed producer provenance '+key)
    require(sha(row['zip_path'])==row['artifact_zip_sha256'],'artifact archive digest differs')
    job=read(row['build_job_path']);require(job['id']==row['build_job_id'] and job['run_id']==run and job['head_sha']==head and job['conclusion']=='success','native producer job is not exact completed source success')
    require(any(step.get('conclusion')=='success' and 'Upload server binaries'==step.get('name') for step in job['steps']),'producer did not complete actual native artifact upload')
    log=Path(row['build_log_path']).read_text();require('--release' in log and 'tcl-lsp-server' in log and '--profile ci' not in log,'actual native release build command absent/conflicting')
    metadata=read(row['artifact_metadata_path']);require(metadata['id']==row['artifact_id'] and metadata['workflow_run']['id']==run and metadata['workflow_run']['head_sha']==head and metadata.get('expired') is False,'artifact API run/source mismatch')
    require(metadata['digest']=='sha256:'+row['artifact_zip_sha256'],'GitHub artifact digest mismatch');require(metadata['name'].startswith('server-bins-') and metadata['name'].endswith('-server'),'not a shipping server-matrix artifact')
    require(datetime.datetime.fromisoformat(metadata['expires_at'].replace('Z','+00:00'))>datetime.datetime.now(datetime.timezone.utc),'artifact metadata expired')
    require(row['zip_member']=='x86_64-unknown-linux-gnu/release/tcl-lsp-server','wrong native target/profile member')
    with zipfile.ZipFile(row['zip_path']) as archive:
        require(archive.namelist().count(row['zip_member'])==1 and hashlib.sha256(archive.read(row['zip_member'])).hexdigest()==row['server_sha256'],'ZIP member does not match executed server')
args.out.mkdir();spec=importlib.util.spec_from_file_location('direct88125',BASE/'guarded-exec.py');executor=importlib.util.module_from_spec(spec);spec.loader.exec_module(executor);rows=[]
for pair in range(args.pairs):
    for role in (['baseline','candidate'] if pair%2==0 else ['candidate','baseline']):
        for name,pin in protocol['files'].items():require(sha(BASE/name)==pin,'protocol input changed before spawn '+name)
        require(sha(args.artifacts)==args.artifacts_sha256,'artifact binding changed before spawn')
        row=artifacts[role];require(sha(row['server_path'])==row['server_sha256'],'inner native server changed before spawn');prefix=args.out/f'pair{pair}-{role}'
        argv=[str(python),'-I','-S',str(BASE/'worker.py'),'--server',row['server_path'],'--server-sha256',row['server_sha256'],'--protocol-sha256',args.protocol_sha256,'--case',args.case,'--out',str(prefix)]
        if args.project:argv+=['--project',str(args.project),'--relative-file',args.relative_file or '']
        process=executor.run(argv,cwd=BASE,env=os.environ.copy(),stdout_path=str(prefix)+'.stdout',stderr_path=str(prefix)+'.stderr',receipt_path=str(prefix)+'.process.json',artifact_path=str(python),deadline_seconds=180,cap_bytes=20*1024**2,disk_floor_bytes=2*1024**3,disk_paths=[args.out,BASE])
        receipt=prefix/'measurement.json';measurement=read(receipt) if receipt.is_file() else None;rows.append({'pair':pair,'role':role,'process':process,'measurement':measurement})
        for name,pin in protocol['files'].items():require(sha(BASE/name)==pin,'protocol input changed after execution '+name)
        require(sha(row['server_path'])==row['server_sha256'] and sha(args.artifacts)==args.artifacts_sha256,'inner server or provenance binding changed')
        (args.out/'summary.json').write_text(json.dumps({'actual_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'MEASUREMENT_ONLY_NOT_RELEASE_ADMISSION','profile_scope':'shipping-release','artifact_binding_sha256':args.artifacts_sha256,'python':protocol['python'],'rows':rows,'limits':'No approved numeric memory/long-request ceiling; browser and package reload scopes remain separate.'},indent=2)+'\n')
        require(process['complete'] and not process['stop_reason'] and process['exit_code']==0,'bounded process failed/incomplete; no retry')
        require(measurement and measurement['status']=='MEASURED_NOT_ADMITTED' and measurement['fixture_bytes_stable'] and not measurement['capture_error'],'semantic measurement/guards incomplete')
        require(measurement['server_sha256_before']==measurement['server_sha256_after']==row['server_sha256'],'inner native server authentication incomplete')
        require(measurement['server_pgid']==measurement['worker_pgid']==process['process_group'],'inner server escaped owned process group')
print(args.out/'summary.json')
