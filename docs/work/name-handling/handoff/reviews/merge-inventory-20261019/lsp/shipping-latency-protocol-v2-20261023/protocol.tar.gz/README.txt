Native shipping latency protocol v2 — PREPARED / UNRUN.

Current exact CI producers (actual API metadata read, not artifact availability):
 baseline run39949992948, fcb7927f02b5395753247b322fdd7be87ae5c731
 candidate run39951250208, a6fab9240dcdeca7536973fb01d32680f4286726
Both must supply actual successful native-matrix job/API metadata/build logs and server-bins-<platform>-server ZIPs before execution. No c611/old-normal-CI artifact may substitute. Only x86_64-unknown-linux-gnu true --release binaries accepted; target/ci is refused even though its artifact was named 'release'. No artifact/final/PASS is fabricated here.

Two-level executable and input authority:
1. Root supplies exact manifest SHA and actual artifact-binding JSON SHA. The manifest pins the real resolved Python executable, worker.py, bounded_client.py, semantic_checks.py, reviewed88125 and actual pinned client/Sampler inputs.
2. Outer88125 argv[0] AND artifact_path are that same actual Python executable. Worker runs with -I -S, checks all protocol hashes before helper imports, and receives exact native server path+SHA.
3. Worker rechecks exact absolute, nonsymlink server path/hash immediately before spawn. Existing LspClient launches ONLY [that path]; worker checks actual child argv, kernel /proc/PID/exe hash, and inherited process group. It does not start another session or process group.
4. Native server hash is checked after shutdown by worker and again by outer driver. Driver also checks protocol/input-binding hashes after execution; owned PGID must match the direct-executor receipt. Python authentication never substitutes for server authentication.

Containment (operational limits, NOT product SLAs):
- Original180s complete-session direct executor deadline, combined process stdout/stderr20MiB, >=2GiB disk floor and group-empty-before-reap.
- Additionally, the inner client bounds combined server stdout/stderr wire bytes at20MiB and decoded notification/stderr storage at20MiB. Exceeding either fails; nothing is silently dropped or called success. Content length is bounded before allocation, headers bounded8KiB, stderr reads bounded64KiB. Original wire frames and stderr are written durably as received; metadata receipts are separate. No unbounded in-memory lists remain in this client path.
- Existing client/Sampler reused; no local Cargo/builds/install/downloads/target cleanup. No server has been executed during preparation. Input files only in fresh /tmp case directories; original corpus/source remains unchanged.

Independent semantic/revision checks, not response hashing:
- First token request follows didOpen immediately; no readiness or naming-query retry repairs it. Require nonempty tokens and record open→first response.
- Then independently await the documented scan notification. A separate fixed Tcl fixture declares __latency_probe_v1 and calls it once. Full diagnostic schema, exact definition and reference range set, exact prepareRename call range, two precise rename edits, and issued/resolved code-lens one-call census must match that actual fixture.
- Change to __latency_probe_v2 at document version2 and append 'set __latency_arity_sentinel 1 2'. The known builtin's invalid arity supplies E003 at line2 without introducing an opaque unknown command. Wait only for a strict version2 publishDiagnostics notification containing that exact E003 sentinel; bounded30s, no query retries. After that, make ONE synchronous full pull and require the same sentinel/schema, then check current renamed declaration/reference/edit/lens identity. An initial report cannot close this revision barrier.
- Twenty warm edits require the actual marker variable and current numeral token geometry, not just token JSON hashes. Exact in-flight references ID is observed when written; cancel it while editing and requesting new marker tokens. If cancellation loses the race, completed references must still match the fixed current source. Otherwise only RequestCancelled or ContentModified error is admissible. No transport failure/timeout is relabelled cancellation success.
- Three close/config/open cycles alternate Tcl8.6/Tcl9.0 and check current marker geometry. Record sampled RSS/CPU, kernel VmHWM and retained RSS after churn, before shutdown. Package reload/source-provider and browser/WASM memory remain separate requirements.

Original fixture scope retained:
- flat P25/50/100/200; source-depth F250/500/1000/2000 from run5/scaling_rows, separated from ordinary user projects.
- large-file20000assignments; project25/project200; 'typical' is a tiny controlled microfixture, NOT representative proof by itself.
- corpus-file copies an actual preverified project from existing MANIFEST.toml corpus pins and selects --relative-file. Corpus symlinks are preserved then refused before reading source; .git/target/node_modules outputs excluded. Never run old run5.sh (it builds/copies/deletes Rust artifacts).
- Five alternating baseline/candidate cold sessions per case. Report all repetitions/distributions and paired noise, not best time. Stop failed/incomplete case with evidence, no retries or budget increases.

Existing acceptance contract, unchanged:
ReviewE + engineering guide require typical first semantic tokens in single-digit milliseconds and reject regressions beyond observed run noise/user-scale stalls. Fast-tier40ms is NOT a universal SLA. No numeric memory ceiling, general workspace bound, or allowed-percent slowdown was approved. This protocol records bounded workloads and results but NEVER emits release PASS. Browser/host correctness, package reload, full CI and zero exact P2F remain independent SectionF gates; supported workload/memory disposition must be recorded by root.

Actual artifact-binding JSON fields per baseline and candidate:
 run_id, head_sha, target, profile='release',
 server_path, server_sha256,
 build_job_id, build_job_path, build_job_sha256 (complete actual GitHub job JSON with exact run/head/successful Upload server binaries step),
 build_log_path, build_log_sha256 (actual native --release command, no --profile ci),
 artifact_id, artifact_metadata_path, artifact_metadata_sha256 (single exact GitHub artifact API record),
 zip_path, artifact_zip_sha256, zip_member='x86_64-unknown-linux-gnu/release/tcl-lsp-server'.
API artifact digest, source/run and expiry, job completion, exact ZIP member and executed binary are all joined before any worker spawn.

Root-only runnable command, once ACTUAL producer evidence exists:
python3 -I -S /tmp/lsp-shipping-latency-protocol-v2/measure.py \
 --protocol-sha256 ACTUAL_FROZEN_V2_MANIFEST_SHA \
 --artifacts /tmp/actual-native-release-pair.json --artifacts-sha256 ACTUAL_BINDING_SHA \
 --case typical --pairs 5 --out /tmp/fresh-typical-native-pairs
For representative files add --case corpus-file --project /tmp/verified-corpus-stage/SpiceGenTcl --relative-file src/generalClasses.tcl and choose a fresh output. Each fixed scaling case uses its exact name, e.g flat-100/source-500/project-200/large-file.
No positive measurement, shipping latency, cancellation or memory result is claimed by this prepared protocol.
