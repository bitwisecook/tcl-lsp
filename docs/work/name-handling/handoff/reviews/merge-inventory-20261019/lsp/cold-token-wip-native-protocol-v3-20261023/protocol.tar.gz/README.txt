WORK-only diagnostic. Root materializes only AFTER final canonical sync and actual committed identity.
python materialize.py --identity ACTUAL.json --identity-sha256 ACTUAL_SHA --out /tmp/FRESH
Root independently reviews output pins and creates root-go.json from root-go-schema.json, then python /tmp/FRESH/launch.py.
No positive materialization/build/runtime executed during preparation. Selected dev-server compilation zero warnings is limited evidence, never shipping performance or eight-package typing admission.
Build2400/runtime180/outer2700; shared nonblocking lock; aggregate20MiB (build plus outer worker plus inner raw wire); 2GiB mount floor; exact88125; fresh Cargo event. Same v3 worker.py and semantic_checks.py unchanged. bounded_client only lowers its existing cap to remaining aggregate share, no query/semantic/oracle changes.
Both diagnostic env flags1. Full source/provider/GO/artifact final seals. Actual failed worker remains failed, no retry. Full v3 typical workload may stop at first refusal, later stages then unreached.
No process target cleanup/deletion. Existing CCG target reused. Runtime server inherits executor ownedPGID.

V2 fixes reviewed outer-owner hazard: suite SIGTERM raises into88125 exception cleanup; launcher reserves final60seconds inside2700 for TERM+boundedwait and never SIGKILLs an unresolved process owner. Such unresolved owner is explicit failure requiring root reconciliation, never completion/admission.

V3: every provider capture is owned88125 directPython30seconds, cap256KiB shared aggregate; exact provider script pin retained. Before runtime reserve180seconds plus120seconds final seals inside2700. Cargo own stage ceiling remains2400; full group exhaustion can refuse runtime. Fresh output must equal resolved path beneath /tmp, no lexical traversal/symlink escape.
