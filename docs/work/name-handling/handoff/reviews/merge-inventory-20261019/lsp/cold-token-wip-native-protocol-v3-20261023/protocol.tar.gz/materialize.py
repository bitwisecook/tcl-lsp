"""Root-only preparation. No GO, lock, Cargo or server execution."""
from pathlib import Path
import argparse,ast,hashlib,json,os,shutil,subprocess,sys
BASE=Path(__file__).resolve().parent
ROOT=Path('/workspace/naming-migration-active/tcl-lsp')
def require(v,m):
 if not v:raise RuntimeError(m)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):
 def unique(rows):
  d={}
  for k,v in rows:require(k not in d,'duplicate key');d[k]=v
  return d
 return json.loads(Path(p).read_text(),object_pairs_hook=unique)
def save(p,v):Path(p).write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
p=argparse.ArgumentParser();p.add_argument('--identity',required=True,type=Path);p.add_argument('--identity-sha256',required=True);p.add_argument('--out',required=True,type=Path);a=p.parse_args()
require(sha(a.identity)==a.identity_sha256,'identity pin');identity=read(a.identity);head=identity['head'];tree=identity['tree']
require(not a.out.exists() and a.out.is_absolute() and a.out==a.out.resolve() and a.out.is_relative_to(Path('/tmp').resolve()),'fresh resolved tmp protocol output required')
for name,pin in read(BASE/'preparation-manifest.json')['files'].items():require(sha(BASE/name)==pin,'preparation changed '+name)
require(subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==head,'actual HEAD differs')
require(subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=ROOT,text=True).strip()==tree,'actual tree differs')
require(subprocess.run(['git','diff','--quiet','HEAD','--','.',':(exclude)docs/work/name-handling'],cwd=ROOT).returncode==0,'uncommitted product change')
source={}
for raw in subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=ROOT).split(b'\0'):
 if not raw:continue
 rel=Path(os.fsdecode(raw));f=ROOT/rel
 require(str(rel).startswith('docs/work/name-handling/') or subprocess.run(['git','ls-files','--error-unmatch','--',str(rel)],cwd=ROOT,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0,'untracked product input')
 if rel.parts[0]in{'rust','runtime','tests','experiments','spec','specs','data','resources','.cargo'} or rel.suffix in{'.rs','.c','.h','.tcl','.tclspec','.py','.pyi'} or rel.name in{'Cargo.toml','Cargo.lock','rust-toolchain.toml','rustfmt.toml','clippy.toml'}:source[str(rel)]=sha(f)if f.is_file()else None
legacy=read(BASE/'environment-template.json');v3=Path('/tmp/lsp-shipping-latency-protocol-v3');vm=read(v3/'manifest.json')
for name,pin in vm['files'].items():require(sha(v3/name)==pin,'original v3 input changed')
for rel,pin in read(v3/'input-pins.json')['pins'].items():require(sha(ROOT/rel)==pin,'original worker repository input changed '+rel)
a.out.mkdir();wp=a.out/'worker-protocol';wp.mkdir()
for name in vm['files']:shutil.copyfile(v3/name,wp/name)
bounded=(wp/'bounded_client.py').read_text();require(bounded.count('CAP=20*1024**2')==1,'cap adaptation anchor');bounded=bounded.replace('import json,threading','import json,threading,os').replace('CAP=20*1024**2','CAP=int(os.environ["TCL_LSP_WIP_WIRE_CAP"])\nif not 0<CAP<=20*1024**2:raise ValueError("invalid remaining aggregate wire cap")');(wp/'bounded_client.py').write_text(bounded)
vm['files']={n:sha(wp/n)for n in vm['files']};vm['status']='WIP dev diagnostic only; unchanged v3 semantic worker, reduced shared aggregate wire cap';save(wp/'manifest.json',vm)
for src,dst in [('suite.py.template','suite.py'),('launch.py.template','launch.py'),('guarded-exec.py','guarded-exec.py')]:shutil.copyfile(BASE/src,a.out/dst)
plan={'head':head,'tree':tree,'identity':{'path':str(a.identity),'sha256':a.identity_sha256},'build_environment':legacy['build_environment'],'python':vm['python'],'provider_script':'/tmp/compiler-c6-provider-manifest.py','provider_seal':legacy['provider_seal'],'runs':'/workspace/naming-release-measurement-artifacts/wip-coarse-diagnostic-runs','build_seconds':2400,'runtime_seconds':180,'outer_seconds':2700,'aggregate_log_bytes':20*1024**2,'scope':'selected fresh dev server0W + original v3 typical diagnostic only; no shipping/8package admission'}
save(a.out/'plan.json',plan);save(a.out/'source-manifest.json',{'head':head,'tree':tree,'count':len(source),'paths':source})
inputs={str(f):sha(f)for f in a.out.rglob('*')if f.is_file()};inputs.update({str(a.identity):a.identity_sha256,plan['provider_script']:sha(plan['provider_script']),plan['provider_seal']['path']:sha(plan['provider_seal']['path'])});inputs.update({str(ROOT/r):pin for r,pin in read(v3/'input-pins.json')['pins'].items()});save(a.out/'runner-input-manifest.json',{'inputs':inputs})
save(a.out/'root-go-schema.json',{'wip_diagnostic_only':True,'allow_without_eight_package_typing':True,'head':head,'tree':tree,'identity_sha256':a.identity_sha256,'source_manifest_sha256':sha(a.out/'source-manifest.json'),'plan_sha256':sha(a.out/'plan.json'),'runner_input_manifest_sha256':sha(a.out/'runner-input-manifest.json'),'NOTE':'SCHEMA ONLY. Root must deliberately create root-go.json; no GO is minted.'})
print(json.dumps({'out':str(a.out),'plan_sha256':sha(a.out/'plan.json'),'runner_inputs_sha256':sha(a.out/'runner-input-manifest.json'),'root_go_created':False}))
