proc p00000000 {} {return 42}
p00000000
