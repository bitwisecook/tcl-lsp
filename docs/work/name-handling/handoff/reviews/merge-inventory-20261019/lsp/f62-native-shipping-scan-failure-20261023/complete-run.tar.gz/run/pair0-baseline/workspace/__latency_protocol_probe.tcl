proc __latency_probe_v1 {} {return 42}
__latency_probe_v1
