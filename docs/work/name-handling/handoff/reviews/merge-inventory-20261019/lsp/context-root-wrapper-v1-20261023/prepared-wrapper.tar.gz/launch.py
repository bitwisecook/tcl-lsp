"""Root-invoked durable WIP launcher. No GO creation; original outer2700 ceiling."""
from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys
BASE=Path(__file__).resolve().parent
if not(BASE/'root-go.json').is_file():raise SystemExit('STOP: no root GO; no lock/Cargo')
p=json.loads((BASE/'plan.json').read_text());env=os.environ.copy();env.update(p['build_environment']['required_environment']);env['PATH']=p['build_environment']['path_prefix']+':'+env.get('PATH','');env.update(TCL_LSP_TRACE_COARSE_SOURCE='1',TCL_LSP_TRACE_COMPLETED_COMMAND_WORLD='1')
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
# The two child stages independently own88125 process groups/timers and reap all descendants.
child=subprocess.Popen([p['python']['path'],'-I','-S',str(BASE/'suite.py')],env=env)
outer_stop=False
try:code=child.wait(timeout=2640)
except subprocess.TimeoutExpired:
    outer_stop=True
    # Reserve the final60seconds INSIDE2700 for handler-driven88125 cleanup.
    child.terminate()
    try:code=child.wait(timeout=60)
    except subprocess.TimeoutExpired:
        # Never kill an unproven owner and orphan its independent child group.
        (BASE/'launcher-unresolved-owner.json').write_text(json.dumps({'pid':child.pid,'outer_budget_exhausted':True,'owner_not_killed':True,'requires_root_reconciliation':True})+'\n')
        raise SystemExit('STOP: outer budget exhausted; owner unresolved, root reconciliation required')
(BASE/'launcher.json').write_text(json.dumps({'started_utc':start,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':code,'outer_stop':outer_stop,'wip_diagnostic_only':True},indent=2)+'\n');raise SystemExit(code if not outer_stop else 1)
