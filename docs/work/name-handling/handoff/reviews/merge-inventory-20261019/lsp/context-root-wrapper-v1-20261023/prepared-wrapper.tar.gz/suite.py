"""WORK-only fresh selected server build and unchanged v3 first-token diagnostic worker."""
from pathlib import Path
import signal,datetime,fcntl,hashlib,importlib.util,json,os,re,shutil,subprocess,sys,time
BASE=Path(__file__).resolve().parent
ROOT=Path('/workspace/naming-migration-active/tcl-lsp')
GO=BASE/'root-go.json'
def require(value,message):
    if not value:raise RuntimeError('STOP: '+message)
def sha(path):
    with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(path):
    def unique(pairs):
        out={}
        for k,v in pairs:
            require(k not in out,'duplicate JSON key '+k);out[k]=v
        return out
    return json.loads(Path(path).read_text(),object_pairs_hook=unique)
def save(path,value):Path(path).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
def environment(plan):
    cfg=plan['build_environment'];actual=os.environ
    require(not any(k in cfg['refused_environment_exact'] or any(k.startswith(x['prefix']) and k.endswith(x['suffix']) for x in cfg['refused_environment_patterns']) for k in actual),'unsupported build override / NoTomMath flag')
    require(all(actual.get(k)==v for k,v in cfg['required_environment'].items()),'required pinned environment mismatch')
    require(actual.get('PATH','').startswith(cfg['path_prefix']+':'),'pinned PATH prefix absent')
    require(sha(cfg['cargo_path'])==cfg['cargo_sha256'] and sha(cfg['rustc_path'])==cfg['rustc_sha256'],'Cargo/rustc hash mismatch')
def source_manifest():
    records={}
    for raw in subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=ROOT).split(b'\0'):
        if not raw:continue
        rel=Path(os.fsdecode(raw));p=ROOT/rel
        if rel.parts[0]in{'rust','runtime','tests','experiments','spec','specs','data','resources','.cargo'} or rel.suffix in{'.rs','.c','.h','.tcl','.tclspec','.py','.pyi'} or rel.name in{'Cargo.toml','Cargo.lock','rust-toolchain.toml','rustfmt.toml','clippy.toml'}:records[str(rel)]=sha(p)if p.is_file()else None
    return records
def source_view(plan,go_pin):
    environment(plan);require(sha(GO)==go_pin,'GO changed')
    require(sha(BASE/'plan.json')==approval['plan_sha256'] and sha(BASE/'runner-input-manifest.json')==approval['runner_input_manifest_sha256'],'GO protocol pins differ')
    for path,pin in read(BASE/'runner-input-manifest.json')['inputs'].items():require(sha(path)==pin,'runner input changed '+path)
    require(sha(plan['identity']['path'])==plan['identity']['sha256'],'actual identity changed')
    identity=read(plan['identity']['path']);require(identity['head']==plan['head'] and identity['tree']==plan['tree'],'identity tuple mismatch')
    require(sha(plan['provider_seal']['path'])==plan['provider_seal']['sha256'],'provider seal changed')
    head=git('rev-parse','HEAD');approved=plan['head'];require(git('rev-parse',approved+'^{tree}')==plan['tree'],'approved actual tree mismatch')
    require(subprocess.run(['git','merge-base','--is-ancestor',approved,head],cwd=ROOT).returncode==0,'HEAD not approved/docs descendant')
    for commit in git('rev-list',approved+'..'+head).splitlines():require(all(p.startswith('docs/work/name-handling/')for p in git('diff-tree','--no-commit-id','--name-only','-r','-m',commit).splitlines()),'non-doc descendant')
    require(subprocess.run(['git','diff','--quiet',approved,'--','.',':(exclude)docs/work/name-handling'],cwd=ROOT).returncode==0,'unapproved product worktree change')
    untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=ROOT).split(b'\0');require(all(not p or os.fsdecode(p).startswith('docs/work/name-handling/')for p in untracked),'untracked product change')
    require(source_manifest()==read(BASE/'source-manifest.json')['paths'],'complete source membership/bytes changed')
    if heads:require(subprocess.run(['git','merge-base','--is-ancestor',heads[-1]['head'],head],cwd=ROOT).returncode==0,'HEAD samples not monotonic')
    heads.append({'utc':utc(),'head':head});return head
def provider_snapshot(path):
    global remaining
    require(remaining>0,'aggregate log budget exhausted before provider capture')
    receipt=executor.run([str(python),plan['provider_script'],str(path)],cwd=ROOT,env=os.environ.copy(),stdout_path=path.with_suffix('.stdout'),stderr_path=path.with_suffix('.stderr'),receipt_path=path.with_suffix('.process.json'),artifact_path=str(python),deadline_seconds=30,cap_bytes=min(remaining,64*1024),disk_floor_bytes=2*1024**3,disk_paths=('/workspace','/tmp'))
    processes.append(receipt);remaining-=receipt['retained_bytes'];require(valid_process(receipt)and receipt['exit_code']==0,'bounded owned provider capture failed')
    return read(path)
def disk():
    for raw in ['/workspace','/tmp',plan['build_environment']['required_environment']['CARGO_TARGET_DIR']]:
        p=Path(raw)
        while not p.exists():p=p.parent
        require(shutil.disk_usage(p).free>=2*1024**3,'actual mount below2GiB '+str(p))
def valid_process(value):return value.get('complete')is True and value.get('stop_reason')is None and value.get('group_empty_before_parent_reap')is True and value.get('timer_armed_before_spawn')is True
def authenticate_server():
    proof=plan['producer']
    for path,pin in proof['proofs'].items():require(sha(path)==pin,'selected server producer evidence changed '+path)
    producer=Path(proof['run']);done=read(producer/'final.json');require(done.get('selected_server_compilation_0w')is True and all(done.get(k)is True for k in ['source_stable','providers_stable','artifact_stable','go_stable'])and done.get('final_error')is None,'actual selected server compilation/seals unavailable')
    require(done.get('overall_exit')==1,'expected retained prior scan diagnostic failure scope changed')
    launcher=read('/tmp/lsp-coarse-wip-current-d1b-uri-fixed-v5/launcher.json');require(launcher.get('outer_stop')is False and launcher.get('exit_code')==1 and launcher.get('finished_utc'),'actual producer launcher not closed')
    built=read(producer/'build.process.json');require(valid_process(built)and built.get('exit_code')==0,'actual selected server Cargo process not successful/closed')
    require(read(producer/'plan.json')['head']==plan['head'] and read(producer/'plan.json')['tree']==plan['tree'],'selected server source tuple mismatch')
    require(read(producer/'lock-released.json').get('pid')and read(producer/'lock-released.json').get('utc'),'producer lock release absent')
    rows=[json.loads(line)for line in(producer/'build.stdout').read_text().splitlines()if line.strip()];finished=[r for r in rows if r.get('reason')=='build-finished'];require(len(finished)==1 and finished[0].get('success')is True,'actual Cargo success absent')
    require(not any(r.get('reason')=='compiler-message'and r.get('message',{}).get('level')in{'warning','error'}for r in rows),'actual selected compiler diagnostic');require(not any(r.get('reason')=='build-script-executed'and r.get('warnings')for r in rows),'build script warning');require(not re.search(r'^warning:',(producer/'build.stderr').read_text(),re.M),'actual Cargo stderr warning')
    events=[r for r in rows if r.get('reason')=='compiler-artifact'and r.get('target',{}).get('name')=='tcl-lsp-server'and r.get('target',{}).get('kind')==['bin']and Path(r.get('manifest_path','')).resolve()==ROOT/'rust/tcl-lsp-server/Cargo.toml'and r.get('profile',{}).get('test')is False and r.get('executable')];require(len(events)==1 and events[0].get('fresh')is False,'actual exact fresh selected artifact event absent')
    server=Path(proof['server_path']);require(server.is_file()and server.is_absolute()and server.resolve()==server and server.is_relative_to(Path(plan['build_environment']['required_environment']['CARGO_TARGET_DIR']).resolve())and sha(server)==proof['server_sha256'],'actual selected server path/hash differs')
    require(events[0]==read(producer/'server-artifact.json')['cargo_event']and Path(events[0]['executable']).resolve()==server,'selected artifact Cargo event join differs')
    return {'path':str(server),'sha256':proof['server_sha256'],'scope':'actual closed d1 selected DEV compilation0W, not shipping artifact'}
def outer_stop(signum,frame):raise RuntimeError('outer2700 budget cleanup requested')
signal.signal(signal.SIGTERM,outer_stop)
if not GO.is_file():raise SystemExit('STOP: no root GO; no lock/Cargo/runtime')
plan=read(BASE/'plan.json');approval=read(GO);heads=[]
require(approval.get('wip_diagnostic_only')is True and approval.get('allow_without_eight_package_typing')is True and approval.get('context_reproduction_only')is True,'explicit root Context diagnostic authorization absent')
require(approval.get('head')==plan['head']and approval.get('tree')==plan['tree']and approval.get('identity_sha256')==plan['identity']['sha256']and approval.get('source_manifest_sha256')==sha(BASE/'source-manifest.json'),'GO actual identity/map mismatch')
python=Path(sys.executable).resolve();require(str(python)==plan['python']['path']and sha(python)==plan['python']['sha256'],'actual Python identity differs')
go_pin=sha(GO);source_view(plan,go_pin);artifact=authenticate_server();disk()
lock=Path('/tmp/tcl-lsp-naming-build.lock').open('a')
try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
except BlockingIOError:raise SystemExit('STOP: shared build lock occupied; no queue')
started=time.monotonic();out=Path(plan['runs'])/datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ');out.mkdir(parents=True)
save(out/'root-go.json',approval);save(out/'plan.json',plan);save(out/'source-before.json',source_manifest());save(out/'server-artifact.json',artifact);processes=[];remaining=20*1024**2;providers_before=None;overall=1;error=None;go_stable=False
spec=importlib.util.spec_from_file_location('direct88125',BASE/'guarded-exec.py');executor=importlib.util.module_from_spec(spec);spec.loader.exec_module(executor)
try:
    providers_before=provider_snapshot(out/'providers-before.json');require(providers_before==read(plan['provider_seal']['path']),'full baseline provider bytes differ')
    source_view(plan,go_pin);authenticate_server();disk();require(time.monotonic()-started<2400,'insufficient existing outer2700 for full180 runtime plus120 final-seal reserve')
    repro=plan['reproduction'];require(sha(Path(repro['base'])/'repro-inputs.json')==repro['inputs_sha256'],'reproduction inputs changed')
    argv=[str(python),'-I','-S',str(Path(repro['base'])/'reproduce.py'),'--server',artifact['path'],'--server-sha256',artifact['sha256'],'--inputs-sha256',repro['inputs_sha256'],'--out',str(out/'worker')];save(out/'worker-command.json',argv);env=os.environ.copy();env.update(TCL_LSP_TRACE_COARSE_SOURCE='1',TCL_LSP_TRACE_COMPLETED_COMMAND_WORLD='1');print('RUN native original proj-a Context reproduction; no Cargo',flush=True)
    result=executor.run(argv,cwd=ROOT,env=env,stdout_path=out/'worker.stdout',stderr_path=out/'worker.stderr',receipt_path=out/'worker.process.json',artifact_path=str(python),deadline_seconds=180,cap_bytes=128*1024,disk_floor_bytes=2*1024**3,disk_paths=('/workspace','/tmp',Path(artifact['path']).parent));processes.append(result);remaining-=result['retained_bytes']
    worker=out/'worker';wire=sum((worker/n).stat().st_size for n in ['server.stdout.frames','server.stderr']if(worker/n).is_file());metadata=(worker/'result.json').stat().st_size if(worker/'result.json').is_file()else 0;fixtures=sum(p.stat().st_size for p in(worker/'workspace').rglob('*')if p.is_file());remaining-=wire+metadata+fixtures;require(wire<=20*1024**2-512*1024 and metadata<=128*1024 and fixtures<=128*1024 and remaining>=0,'aggregate20MiB or component cap exceeded')
    require(valid_process(result),'worker owned lifecycle failed');require((worker/'result.json').is_file(),'durable Context result absent');measure=read(worker/'result.json');require(measure.get('server_before')==measure.get('server_after')==artifact['sha256']and measure.get('server_unchanged')is True and measure.get('fixture_unchanged')is True and not measure.get('capture_error'),'worker server/fixture/capture seal failed');require(sha(artifact['path'])==artifact['sha256'],'server binary changed');overall=0 if result['exit_code']==0 and measure.get('status')=='COMPLETE_ORIGINAL_ASSERTIONS'else 1
except BaseException as exc:error=str(exc);save(out/'failure.json',{'utc':utc(),'error':error});overall=1
finally:
    final_error=None
    try:
        source_view(plan,go_pin);save(out/'source-after.json',source_manifest());after=provider_snapshot(out/'providers-after.json');source_stable=read(out/'source-before.json')==read(out/'source-after.json');providers_stable=providers_before is not None and providers_before==after;artifact_stable=sha(artifact['path'])==artifact['sha256'];source_view(plan,go_pin);disk();go_stable=sha(GO)==go_pin;require(source_stable and providers_stable and artifact_stable and go_stable,'final source/provider/artifact/GO seals differ')
    except BaseException as exc:final_error=str(exc);source_stable=providers_stable=artifact_stable=False;overall=1
    save(out/'final.json',{'finished_utc':utc(),'overall_exit':overall,'error':error,'final_error':final_error,'context_reproduction_only':True,'shipping_editor_host_admission':False,'source_stable':source_stable,'providers_stable':providers_stable,'artifact_stable':artifact_stable,'go_stable':go_stable,'head_samples':heads,'processes':processes,'remaining_log_bytes':remaining,'whole_elapsed_seconds':time.monotonic()-started})
    fcntl.flock(lock,fcntl.LOCK_UN);lock.close();save(out/'lock-released.json',{'utc':utc(),'pid':os.getpid()})
print('COMPLETE '+str(out)+' exit='+str(overall),flush=True);raise SystemExit(overall)
