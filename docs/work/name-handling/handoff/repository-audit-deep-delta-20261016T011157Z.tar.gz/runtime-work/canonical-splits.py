# Actual disjoint naming purposes rechecked at their pinned original source.
# Required shared descriptor/transport facets remain separate owner requirements.
# Format: suffix, purpose, kind, [(path,line)], requirement, shared family.
OO='runtime/rust/src/cmd_oo.rs'
SPLITS={
904:[
('foundation','OO foundation/root/helper installation metadata','metadata_schema',[(OO,699)],'Consume selected root/helper registration descriptors for actual foundation installation, retaining authentic object allocation/publication and provider/release admission. Existing literal data alone does not create command authority.','metadata.oo-stock-installation-descriptor'),
('definition-workers','OO definition namespace worker registration metadata','metadata_schema',[(OO,856)],'Adopt selected actual definition-worker declarations and namespace/prefix construction; preserve genuine command handler registration and method/definition activation.','metadata.oo-stock-installation-descriptor'),
('slot-class','OO Slot class method/bootstrap constructor metadata','metadata_schema',[(OO,1566)],'Move actual Slot class/operation/script recipe into selected existing bootstrap descriptor, preserving real published method/procedure identity and script provider purposes.','metadata.oo-stock-installation-descriptor'),
('slot-instances','OO builtin Slot instance descriptor installation','metadata_schema',[(OO,1623)],'Use selected shared Slot instance name/class-reference/accessor metadata instead of local SLOTS roster; preserve actual installed allocation and immutable semantic role provenance.','metadata.oo-stock-installation-descriptor'),
('configurable','OO configurable support namespace and worker installation metadata','metadata_schema',[(OO,943)],'Adopt configurable support declaration facets without copying namespace/property commands or callable name inference. Exact registered roots/release visibility missing facet remains explicit.','metadata.oo-stock-installation-descriptor'),
('singleton','OO singleton support bootstrap script metadata','metadata_schema',[(OO,1058)],'Adopt selected singleton/SingletonInstance original installer script/stock root descriptors while retaining existing separately selected Abstract bootstrap and actual execution/publication.','metadata.oo-stock-installation-descriptor'),
],
909:[
('get','Installed Slot Get authentic role/allocation consumption','consumer_api_adoption',[(OO,2006),(OO,1719),(OO,1732)],'Consume genuine installed selected slot role/allocation through existing method world at Get; remove oo_name report classification. Shared descriptor/continuation producer must be authentic actual installation, not bare report_type DTO. Preserve mutable overrides/clones/retirement.','native.oo-installed-slot-role-transport'),
('set','Installed Slot Set authentic role/allocation consumption','consumer_api_adoption',[(OO,2034),(OO,1772)],'Consume same genuine installed role/current target at Set and checked mutation helper; remove report-driven field selection. Retain actual current definition target, variable/property admission and publication order. Shared transport owner repair counted independently once.','native.oo-installed-slot-role-transport'),
],
927:[
('object-namespace','OO my/myclass namespace command registration descriptor','metadata_schema',[(OO,3967),(OO,3982)],'Adopt actual object-namespace helper descriptor roster; registration still issues actual binding/token, source metadata itself supplies no Native authority.','metadata.oo-object-namespace-and-isa-roster'),
('isa','OO Info object ISA original immutable category table','metadata_schema',[(OO,4654)],'Adopt selected original ISA declaration metadata retaining real native index/cache table identity, noun/flags and reached category arity; do not infer physical table from source catalogue.','metadata.oo-object-namespace-and-isa-roster'),
('methods','OO Info object inherited intrinsic method candidate metadata','metadata_schema',[(OO,4915)],'Adopt shared selected inherited intrinsic visibility/candidate descriptor facet; preserve real method export/unexport/private selection and report result construction. Same owner family as Unknown/Class candidates, distinct changed caller.','metadata.oo-intrinsic-method-visibility'),
],
929:[
('selector','OO Info object actual original selector/table consumption','consumer_api_adoption',[(OO,4581)],'Select actual original provider/member table/cache/getter/arity purpose instead of source-release byte roster. Retain original object lookup and current namespace/allocation; rendered results stay data.','native.oo-info-object-selected-input-inventory'),
('vars-pattern','OO Info object variable inventory pattern purpose','consumer_api_adoption',[(OO,4778),(OO,5801)],'Use selected exact byte name-pattern purpose for actual instance variable inventory, retaining actual target namespace holder and currentness. Generic UTF8 failure cannot mean no match. Original output header/ordering semantics remain validation questions; no invented returned-key owner.','native.oo-info-object-selected-input-inventory'),
],
939:[
('selector','OO Info class actual original selector/table consumption','consumer_api_adoption',[(OO,5492)],'Adopt actual native class-info original selector/declaration/cache/arity purpose, retaining real selected class facet and original requested header/current caller.','native.oo-info-class-selected-input-candidates'),
('patterns','OO Info class instance/subclass name-pattern purposes','consumer_api_adoption',[(OO,5629),(OO,5651)],'Transport selected byte glob/character/name purpose at actual instance and subclass candidate filters; preserve actual class relationship/generation and report-only results. Shared pattern owner repair is once, both caller sites explicit.','native.oo-info-class-selected-input-candidates'),
('methods','OO Info class inherited intrinsic method candidate metadata','metadata_schema',[(OO,5708),(OO,5711)],'Adopt same selected inherited core method visibility/candidate facet as InfoObject/Unknown, preserving real class chain/export/private relation and final report.','metadata.oo-intrinsic-method-visibility'),
],
}

# Explicit Host owner facets: ordinary Unicode APIs remain valid and unchanged.
PLATFORM='rust/tcl-platform/src/lib.rs'
SPLITS[65]=[
('filesystem-path-domain','Shared selected native filesystem path input/output domain','shared_owner_repair',[(PLATFORM,399),(PLATFORM,261)],'Extend the existing Env/Filesystem capability owner with an actual native OS path/selected external encoding facet for cwd/chdir and filesystem path operations/output. Existing Unicode facades and staged Source byte-file purposes remain independently valid. Missing facet must refuse, not turn unrepresentable input or host failure into absence. Concrete host implementations and Runtime consumers are separately counted.','host.native-filesystem-name-domain'),
('process-argv-domain','Shared selected native subprocess argv domain','shared_owner_repair',[(PLATFORM,430)],'Extend the existing Process owner with actual selected native executable/argv units and platform encoding/configuration purpose; the existing Unicode run contract remains unchanged. Concrete NativeProcess and exec adapters are separate sites. No reconstruction from printed Tcl argv.','host.native-process-argv'),
]
SPLITS[6]=[('native-path-operations','NativeFs actual native path operation producer','consumer_api_adoption',[(
'rust/tcl-host-native/src/lib.rs',n) for n in [366,370,375,380,413,426,430,434,448,456,477,485]],'Implement the missing selected native filesystem path facet at actual provider ingress for existence/metadata/read/write/mkdir/remove/rename/copy/link/time operations. Existing Unicode methods can remain and do not become independent native recipes by renaming. Each actual operation site is listed; read_dir/readlink output purposes are separately mapped by rows4/5; staged Source read_bytes/open purpose remains unchanged.','host.native-filesystem-name-domain')]
