from pathlib import Path
import concurrent.futures,subprocess,json,hashlib
base=Path('/workspace/name-session');build=base/'batch-k-build-ordinary';plans=json.loads((base/'k-replay-plans.json').read_text())
def run(label):
 row=plans[label];artifact=row['artifact'];assert hashlib.sha256(Path(artifact['path']).read_bytes()).hexdigest()==artifact['sha256']
 argv=['python3',str(base/'replay-frozen-a.py'),'--package',row['package'],'--plan',str(base/(label+'-k-plan.json')),'--out',str(base/('replay-k-'+label)),'--binary',artifact['path'],'--expected-source',str(build/'source-before.json.gz'),'--timeout','180','--jobs','1','--label','Frozenc448d18f6 ordinary replay; all selected8df controls/budgets retained plus reviewed actual ELF-listed additions; Native/provider closure independent']
 with (base/(label+'-k-runner.log')).open('wb') as out:code=subprocess.run(argv,cwd='/workspace/name-validation',stdout=out,stderr=subprocess.STDOUT).returncode
 p=base/('replay-k-'+label)/'result.json';r=json.loads(p.read_text()) if p.exists() else {};runs=r.get('runs',[])
 summary={'label':label,'exit':code,'selected':len(r.get('selected_tests',[])),'runs':len(runs),'pass':sum(x['exit_code']==0 for x in runs),'fail':sum(x['exit_code']!=0 and not x['timed_out'] for x in runs),'timeout':sum(x['timed_out'] for x in runs),'source_drift':r.get('changed_sources'),'binary_unchanged':r.get('binary_unchanged'),'missing':r.get('missing_exact'),'empty_filters':r.get('empty_filters')};print(json.dumps(summary),flush=True);return summary
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 futures=[pool.submit(run,label) for label in plans]
 results=[f.result() for f in futures]
(base/'replay-k-summary.json').write_text(json.dumps(results,indent=2)+'\n')
