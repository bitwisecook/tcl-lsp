// Diagnostic client of the exact ordinary K libraries; no production instrumentation.
use std::sync::Arc;
use tcl_compiler::analyser::{Analyser, ResolvedAnalysisInput};
use tcl_compiler::compilation_unit::{CompilationUnit, UnitBuildOptions};
use tcl_compiler::registry_invocation::source_structure::source_registry_words;
use tcl_lexer::{LexerConfig, SourceImage};
use tcl_registry::Traits;

fn main() {
    let source = concat!(
        "when HTTP_REQUEST {pool \"a\\\"b\"; pool {茶}; pool $dynamic}\n",
        "when BOGUS_EVENT {pool unknown}\n",
        "when XML_BEGIN_DOCUMENT {pool retired}\n",
    );
    let environment = tcl_registry::model::ingress::resolve_environment("f5-irules");
    let profile = tcl_dialect::DialectProfile::irules();
    for version in ["9.4.0", "16.1.0"] {
        let keyed = tcl_registry::model::KeyedVersions {
            bigip: Some(tcl_dialect::model::Version::parse(version).unwrap()),
            ..Default::default()
        };
        let context = environment.plain_context_registry(&keyed);
        let registry = context.commands();
        let config = LexerConfig {
            braced_var: tcl_lexer::BracedVarStyle::Tcl9Nesting,
            ..LexerConfig::for_profile(Some(profile))
        };
        let input = ResolvedAnalysisInput::new(profile, profile, context.clone(), config);
        let unit = Arc::new(CompilationUnit::build_with_context_registry(
            source,
            UnitBuildOptions {
                registry,
                defer_top_level: false,
                config,
                dialect: Some(profile),
                external_call_sites: None,
                declared_commands: None,
            },
            None,
            context.clone(),
        ));
        let mut analyser = Analyser::new().with_resolved_input(input);
        analyser.set_cu_override(unit.clone());
        let analysis = analyser.analyse(source, profile.name);
        let module = &unit.ir_module;
        let image = SourceImage::document(source);
        println!(
            "VERSION {version} config={config:?} module_config={:?} module_source_equal={} registry_equal={} descriptors={} procedures={}",
            module.lexer_config,
            module.source == image,
            module.registry_snapshot.as_ref().is_some_and(
                |snapshot| snapshot.semantic_key() == registry.snapshot().semantic_key()
            ),
            module.irules_event_bodies.len(),
            module.procedures.len()
        );
        let catalogue = tcl_registry::events::EventRegistry::build();
        for (id, procedure) in &module.procedures {
            let original = module.irules_event_bodies.get(id);
            let owned = tcl_compiler::source_graph::event_body_for_procedure(
                module, id, procedure, registry,
            );
            println!(
                "PROCEDURE id={id:?} module_id={} label={:?} span={:?} body_stmts={} descriptor={} authentic_owner={}",
                module.procedure_ids.owns(*id),
                procedure.qualified_name,
                procedure.span,
                procedure.body.statements.len(),
                original.is_some(),
                owned.is_some()
            );
            if let Some(event) = original {
                let word = event.event_word(&module.source, module.lexer_config, registry);
                println!(
                    "EVENT event={:?} matches_module_source={} matches_requested_source={} word={:?} known={} available={} placement_floor={:?}",
                    event.event(),
                    event.matches_source(&module.source, module.lexer_config),
                    event.matches_source(&image, config),
                    word.map(|word| (word.span(), word.config())),
                    catalogue.is_known(event.event()),
                    catalogue.event_available_at(event.event(), version),
                    context.context().placement_floor("f5-irules-cmds")
                );
                if owned.is_none() {
                    println!("UNOWNED_EVENT_FULL {event:#?}");
                    println!("UNOWNED_PROCEDURE_FULL {procedure:#?}");
                }
            }
        }
        let occurrences = analysis.original_vendor_source_names().collect::<Vec<_>>();
        println!(
            "VENDOR_OCCURRENCES count={} starts={:?}",
            occurrences.len(),
            occurrences
                .iter()
                .map(|occurrence| occurrence.site().offset)
                .collect::<Vec<_>>()
        );
        for occurrence in occurrences
            .iter()
            .filter(|occurrence| occurrence.site().offset == 0)
        {
            println!(
                "ROOT_OCCURRENCE head_match={} words={:?}",
                occurrence.original_words().first()
                    == Some(occurrence.name_input().original_word()),
                occurrence
                    .original_words()
                    .iter()
                    .map(|word| (word.span(), word.config(), word.group().kind))
                    .collect::<Vec<_>>()
            );
        }
        for segment in
            tcl_compiler::segmenter::segment_commands_with_offset_and_config(source, 0, config)
        {
            let words = source_registry_words(source, &analysis, &segment);
            println!(
                "SOURCE_VECTOR start={} span={:?} schema_vector={}",
                segment.span.start(),
                segment.span,
                words.is_some()
            );
            if let Some(words) = words {
                let bodies = words.source_script_bodies_for(&context, tcl_compiler::registry_invocation::OriginalSourceScriptPurpose::PotentialEvaluation);
                println!(
                    "SOURCE_SCHEMA original={} context={} registry={} roles={:?} event_trait={:?} timing1={:?} bodies={:?}",
                    words.matches_source(&image, config),
                    words.context() == Some(context.context()),
                    words.matches_registry(registry),
                    words.roles(),
                    words.with_source_schema(&context, |schema| schema
                        .semantics
                        .traits
                        .contains(Traits::IS_EVENT_HANDLER)),
                    words.with_source_schema(&context, |schema| schema
                        .authored_source_script_timing_at(1)),
                    bodies
                        .iter()
                        .map(|body| (
                            body.content_span(),
                            source.get(body.content_span().as_range())
                        ))
                        .collect::<Vec<_>>()
                );
            }
        }
        let inventory = tcl_irules::OriginalIrulesSourceContext::from_analysis(
            source, &analysis, module, &context,
        );
        println!(
            "FINAL_INVENTORY {:?}",
            inventory.as_ref().map(|inventory| inventory
                .events()
                .iter()
                .map(|event| event.event())
                .collect::<Vec<_>>())
        );
    }
}
