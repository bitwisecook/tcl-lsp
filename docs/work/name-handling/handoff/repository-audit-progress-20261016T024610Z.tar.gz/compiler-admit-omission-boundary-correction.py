import json,hashlib,datetime
from pathlib import Path
P=Path('/workspace/name-session/full-consumer-audit');pp=P/'compiler-vm-omission-boundary-read.json';assert hashlib.sha256(pp.read_bytes()).hexdigest()=='ea1877c4afb6e49b9f73f8b24fd877335374ecf844c56fd4b231107ca945f734';peer=json.load(open(pp));contexts=P/peer['raw_contexts']['path'];assert hashlib.sha256(contexts.read_bytes()).hexdigest()==peer['raw_contexts']['sha256'];c=json.load(open(P/'compiler-file-coverage.json'));prod=[]
for x in peer['rows']:
 r=next(y for y in c['rows'] if y['path']==x['path']);assert r['source_sha256']==x['source_sha256']==hashlib.sha256((P/'compiler-baseline'/x['path']).read_bytes()).hexdigest()
 r.setdefault('cfg_test_boundary_correction_admissions',[]).append(dict(peer=pp.name,candidate_index=x['candidate_index'],classification=x['classification'],actually_read_context=x['actually_read_context'],production_supplement_ranges=x['production_supplement_ranges_including_comments_and_structure']))
 if x['production_supplement_ranges_including_comments_and_structure']:prod.append(x)
# Preserve original aid SHA geometry. Corrected classification is explicit supplement, not regenerated aid.
annex=dict(baseline=peer['baseline'],review='Every original omitted range globally lexical-screened; all31 changed-boundary candidates individually actual raw-source interpreted by VM with complete contexts. Includes exact fields/variants, match arms and genuine closure false positives.',source_review_only=True,old_aids='Immutable original aids/sourceSHA retained, supplemental production ranges admitted by exact peer contexts.',summary=peer['summary'],peer_receipt=pp.name,peer_sha256=hashlib.sha256(pp.read_bytes()).hexdigest(),rows=prod,execution='Unexecuted. No semantic migration count from extraction classification alone.')
for n,o in [('compiler-file-coverage.json',c),('compiler-production-omission-correction-admission.json',annex)]:
 t=P/(n+'.tmp');t.write_text(json.dumps(o,indent=2)+'\n');t.replace(P/n)
print('Global exact omitted-boundary correction admitted:',len(prod),'real ranges,',peer['summary']['production_supplement_lines_including_comments_and_structure'],'production supplement lines actual read.')
