import json,hashlib,datetime,runpy,collections
from pathlib import Path
B=Path('/workspace/name-session/full-consumer-audit');x=runpy.run_path(str(B/'audit-review-tools.py'));c,s=x['load']();R={r['path']:r for r in c['files']};raw=json.loads((B/'audit-canonical-pending-ordered-roster.json').read_text());p=B/'audit-migration-units.json';a=json.loads(p.read_text());U=a['units'];cache={};dec=[]
def unit(key,ix,purpose,kind,family,effort,change,api,unchanged=(),owner=None):
 rows=[raw[i] for i in ix];assert all(r['disposition']=='needs_migration' for r in rows);sites=[]
 for r in rows:
  if r['path'] not in cache:cache[r['path']]=x['content'](R[r['path']]).decode().splitlines()
  ln=r['line'];line=cache[r['path']][ln-1];assert line.strip();sites.append({'path':r['path'],'symbol':r['symbol'],'line':ln,'source_line':line,'blob':r['blob'],'source_sha256':r['source_sha256'],'anchor_kind':'actual reviewed function or source-boundary declaration; internal exact expression anchors retained in original source evidence'})
 z={'id':'audit:'+key,'source_owner':'audit','work_kind':kind,'family_id':family,'purpose':purpose,'code_change_sites':sites,'representation_and_context':[{'original_row':r['id'],'context':r['actual_input_context']} for r in rows],'existing_shared_api':api,'required_owner_extension':owner,'required_change':change,'source_evidence':[{'original_row_id':r['id'],'source':r['source_evidence'],'source_required_change':r['missing_integration']} for r in rows],'original_row_ids':[r['id'] for r in rows],'relative_effort':effort,'state':'source_confirmed_change_required_unimplemented','control_obligations':[r['relevant_original_assertions'] for r in rows],'affected_unchanged_callers':list(unchanged),'validation':'Source-only actual purpose review; no source/build/provider/generator/test execution. Existing original oracle APIs remain independent.','limitations':'Exact current integration purpose, not one unit per raw match/helper or repair family. Any unspecified shared-owner/provider/schema requirement remains explicit in required_owner_extension; no minimum-adopter count assumed.'};U[:]=[q for q in U if q['id']!=z['id']];U.append(z);dec.append({'unit':z['id'],'raw_indexes':ix,'reason':change})
def same(key,ix,why):
 u=next(z for z in U if z['id']=='audit:'+key)
 for i in ix:
  r=raw[i];u['original_row_ids'].append(r['id']);u.setdefault('mapped_unchanged_helper_or_dispatch_rows',[]).append({'id':r['id'],'path':r['path'],'symbol':r['symbol'],'line':r['line'],'reason':why,'source_sha256':r['source_sha256']})
 dec.append({'existing_unit':'audit:'+key,'unchanged_or_same_boundary_raw_indexes':ix,'reason':why})
