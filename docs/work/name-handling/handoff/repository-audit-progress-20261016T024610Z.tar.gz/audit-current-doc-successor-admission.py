import json,hashlib,datetime,re
from pathlib import Path
B=Path('/workspace/name-session/full-consumer-audit');root=Path('/workspace/tcl-lsp');p=B/'root-current-source-successor-annex.json';a=json.loads(p.read_text());assert hashlib.sha256(p.read_bytes()).hexdigest()=='bbc3f5a6f273b531f151584aa0a34460fc02fbafc0e745abadcf75180447ab49';out=[]
for z in a['records']:
 if z['path'] not in a['durable_design_paths']:continue
 actual=hashlib.sha256((root/z['path']).read_bytes()).hexdigest();assert actual==z['after_sha256'];ranges=[]
 for l in z['diff'].splitlines():
  m=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',l)
  if m:ranges.append({'baseline_start':int(m[1]),'baseline_lines':int(m[2] or 1),'successor_start':int(m[3]),'successor_lines':int(m[4] or 1)})
 out.append({'path':z['path'],'before_blob':z['before_blob'],'before_sha256':z['before_sha256'],'after_blob':z['after_blob'],'after_sha256':z['after_sha256'],'actual_worktree_sha256':actual,'actual_complete_diff_read':True,'bounded_hunks':ranges,'diff_sha256':hashlib.sha256(z['diff'].encode()).hexdigest(),'source_receipt':p.name,'disposition':'Current docs add exact original Logical formal/source-field/canonical scope and strict source-vs-Native/edit denial wording. No executable production branch change or source/API/test acceptance granted.'})
p=B/'audit-current-doc-successor-admission.json';p.write_text(json.dumps({'baseline':a['baseline'],'successor':a['head'],'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_only':True,'records':out,'coverage_limit':'Primary retains whole cc24 guides and exact bounded actual successor diffs only; this annex is not a fresh whole current guide read or implementation validation. Known three documentation drift is fully matched to Root bounded annex, not suppressed/unexplained.','current_question_precision':'Private source field wording was corrected in exact current successor. Baseline utility45 inventory-scope pending question must not be advertised as still-unmodified current docs or required omission defect.'},indent=2)+'\n');print(p,hashlib.sha256(p.read_bytes()).hexdigest())
