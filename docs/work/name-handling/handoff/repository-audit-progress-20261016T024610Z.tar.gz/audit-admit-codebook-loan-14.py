import json,runpy,hashlib,datetime
from pathlib import Path
B=Path('/workspace/name-session/full-consumer-audit');g=runpy.run_path(str(B/'audit-review-tools.py'));h=runpy.run_path(str(B/'audit-review-surfaces.py'));c,s=g['load']();R={r['path']:r for r in c['files']};peers=[('lsp-audit-kcs-codes-source-receipt.json','47086258c83a63fdd136e601238d8c8c167b432f51780dd7e8192636a016157d')];ad=[];news=[]
for fn,sha in peers:
 p=B/fn;assert hashlib.sha256(p.read_bytes()).hexdigest()==sha;a=json.loads(p.read_text())
 for f in a['whole_source_files']:
  path=f['path'];r=R[path];d=g['content'](r);assert hashlib.sha256(d).hexdigest()==f['source_sha256']==r['source_sha256'];assert f['blob']==r['blob'];assert len(d.splitlines())==f['whole_lines'];assert hashlib.sha256(Path(f['aid']).read_bytes()).hexdigest()==f['aid_sha256'];assert f['actual_read_ranges']==[[1,f['whole_lines']]];es=[]
  for z in a['purpose_rows']:
   if z['path']!=path:continue
   assert d.decode().splitlines()[z['line']-1].strip()==z['source_line'].strip();es.append((z['symbol'],z['line'],z['purpose'],z['disposition'],z.get('context',z.get('reason','')),z.get('shared_api',''),z.get('missing_integration',z.get('reason','')),z.get('controls',[])))
   if z['disposition']=='needs_migration':news.append(z)
  h['surface'](c,s,path,'whole_current_authored_guidance_inert_source_peer',f"Whole1–{f['whole_lines']}actual original lines, including every long table/recipe/code cell. Independent whole read, exact baseline blob/source/aid equality; docs read inertly, no skill/provider/generator/test executed.",es,mode='whole_independent_authored_guidance_peer_read')
  for z in a['purpose_rows']:
   if z['path']!=path:continue
   q=next(x for x in s['consumers'] if x['path']==path and x['symbol']==z['symbol'] and x['purpose']==z['purpose']);q['source_evidence'].append({'peer':fn,'peer_sha256':sha,'source_line':z['source_line'],'reason':z.get('reason'),'repair_family':z.get('repair_family')});q['repair_family']=z.get('repair_family');q['peer_original_work_kind']=z.get('work_kind')
  r['peer_receipt']=fn;ad.append(path)
g['save'](c,s);act=json.loads((B/'audit-tooling-active-reservations.json').read_text())
for z in act['reservations']:
 if z['path'] in ad:z['reservation_status']='released';z['read_status']='whole_actual_guidance_peer_admitted_source_only'
(B/'audit-tooling-active-reservations.json').write_text(json.dumps(act,indent=2)+'\n')
out={'baseline':c['baseline'],'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'peers':peers,'paths':ad,'paths_count':len(ad),'required_raw_purposes':news,'primary_decisions':['Current quoted conditional diagnostic messages differ from codebook old definite message quotations; provider protocol facts are not refuted merely by conditional source analysis.','Explicit offered code action conflicts actual ConditionalSourceNoAction authoring purpose; do not reenable fixes to match docs.','T101 exact same-page sanitizer outcome claims contradict; O128 exact same-page single-index versus first multi-index scope contradicts. Scope corrections require actual owner/control reconciliation, not inferred provider answers.','All pending grammar/runtime/diagnostic-domain claims retain pending_audit or pending_validation source purposes, not required code migrations. Exact predecessor and UI-scope successor retained by LSP.'],'purpose_rows_after':len(s['consumers'])};p=B/'audit-loans-14-codebook-admission.json';p.write_text(json.dumps(out,indent=2)+'\n');print(p,hashlib.sha256(p.read_bytes()).hexdigest(),len(ad),len(news),len(s['consumers']))
