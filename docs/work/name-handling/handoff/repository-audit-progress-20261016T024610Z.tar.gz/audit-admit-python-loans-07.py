import runpy,json,hashlib,datetime
from pathlib import Path
B=Path('/workspace/name-session/full-consumer-audit');x=runpy.run_path(str(B/'audit-review-tools.py'));u=runpy.run_path(str(B/'audit-review-surfaces.py'));c,s=x['load']();by={r['path']:r for r in c['files']};decisions=[];admitted=[]
for fname in ['lsp-audit-python-ownership-source-receipt.json']:
 d=json.loads((B/fname).read_text());rows=d.get('purpose_rows',d.get('purpose_proposals'));fs=d.get('whole_source_files',d.get('files'))
 for f in fs:
  r=by[f['path']];data=x['content'](r);assert r['blob']==f['blob'] and hashlib.sha256(data).hexdigest()==f['source_sha256']==r['source_sha256'];assert len(data.splitlines())==f['whole_lines'];assert hashlib.sha256(Path(f['aid']).read_bytes()).hexdigest()==f['aid_sha256'];entries=[];own=[]
  for z in rows:
   if z['path']!=f['path']:continue
   assert data.decode().splitlines()[z['line']-1].strip()==z['source_line'].strip(),(z['symbol'],z['line'])
   state=z['disposition'];reason=z.get('reason',z.get('evidence',''));purpose=z.get('purpose',z['symbol']+' actual host or validation protocol');api=z.get('shared_api',z.get('actual_shared_api',''));missing=z.get('missing_integration',reason if state.startswith('pending') or state=='needs_migration' else '') or '';context=z.get('context',reason)
   if state=='intentional_no_change':state='shared_owner'
   assert state!='migrated_validation_pending'
   
   if z.get('id')=='lsp-audit-python-capi-selected-header-completeness':
    context+=' Primary precision: header doc195–198 explicitly best effort; preserve optional policy. Empty-selection success/status is confirmed; universal required three-header coverage and multiheader policy remain unresolved domains.'
    missing='Preserve explicit selection unavailable/empty status and truthful success projection; define intentional best-effort header coverage/ambiguity policy without assuming all optional headers are mandatory.'
   entries.append((z['symbol'],z['line'],purpose,state,context,api,missing,z.get('controls',[])));own.append((z,purpose,reason));decisions.append({'peer':fname,'proposal':z.get('id',z['symbol']),'path':f['path'],'purpose':purpose,'state':state,'reason':reason})
  extent=f"Whole{f['whole_lines']}original operational source lines actually read by {('Root' if fname.startswith('root') else 'LSP')}, every shell/Python/Node/AWK/sed/template/mock/helper/assertion stage. Exactblob/source/aidSHA checked and primary bounded source/purpose challenge. No execution/publication/provider/network or dependent whole source donation. Peer {fname}."
  u['surface'](c,s,f['path'],'independent_whole_operational_host_validation_source_peer',extent,entries,mode='whole_independent_operational_source_peer_read')
  for z,purpose,reason in own:
   row=next(q for q in s['consumers'] if q['path']==f['path'] and q['symbol']==z['symbol'] and q['purpose']==purpose);row['source_evidence'].append({'peer':fname,'peer_sha256':hashlib.sha256((B/fname).read_bytes()).hexdigest(),'actual_source_line':z['source_line'],'reason':reason,'code_change_sites':z.get('code_change_sites',[])});row['repair_family']=z.get('repair_family');row['peer_original_work_kind']=z.get('work_kind')
  r['peer_receipt']=fname;admitted.append(f['path'])
x['save'](c,s);o=json.loads((B/'audit-tooling-active-reservations.json').read_text())
for q in o['reservations']:
 if q['path'] in admitted:q['read_status']='whole_actual_peer_admitted_source_only';q['reservation_status']='released'
(B/'audit-tooling-active-reservations.json').write_text(json.dumps(o,indent=2)+'\n');p=B/'audit-loans-07-python-admission.json';p.write_text(json.dumps({'baseline':c['baseline'],'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Four whole operational Python source admissions; actual source/semantic challenge, no target imports/execution or migration acceptance.','primary_challenges':['Selected header source opt-in status and truthful success projection is confirmed. Preserve explicitly documented best-effort header cross-check policy and absent opt-in skip.','Missing optional headers are not automatically an obligation to require all three; selected root contract/header inventory policy remains explicit.','Multiple-version first candidate ambiguity is a domain question without an actual selected-root ambiguity contract; no demonstrated wrong current provider chosen.','No current alternate Rust export annotation mismatch established; preserve finite actual export scanner domain.','Synthetic proof and encoding fixtures remain independent inputs, not invented Native original observations.'],'admitted_paths':admitted,'decisions':decisions,'purpose_rows_after':len(s['consumers'])},indent=2)+'\n');print(p,hashlib.sha256(p.read_bytes()).hexdigest(),len(s['consumers']))
