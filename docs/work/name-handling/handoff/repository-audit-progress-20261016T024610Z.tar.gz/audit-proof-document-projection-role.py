import json,runpy,hashlib,datetime
from pathlib import Path
B=Path('/workspace/name-session/full-consumer-audit');g=runpy.run_path(str(B/'audit-review-tools.py'));c,s=g['load']();R={r['path']:r for r in c['files']};mp='docs/design/analysis/name-resolution-proofs/manifest.json';md=g['content'](R[mp]);assert hashlib.sha256(md).hexdigest()=='ce655b170aff119f96a1dcf11eb694e11462a6f15f877b4f6032d8ba47fc8fc6';records=json.loads(md)['proofs'];owner=R['scripts/dev/update-name-resolution-proof-index.py'];assert owner['review_status']=='reviewed' and owner['source_sha256']=='e3a6728b81388b29b9f7403b97288e5dd8e251fabded039d7b77f81e4f516ab2'
# Static byte/field comparator transcribed from the already whole-read render
# source80–120. The maintained target updater is never imported or run, no
# document files are generated/published and no assertion/provider is evaluated.
def fragments(q):
 yield f"# {q['id']}\n\nKind: `{q['kind']}`\n\n"
 for title,key in [('Problem statement','problem_statement'),('Question','question'),('Conclusion','conclusion'),('Scope','scope')]:yield f"## {title}\n\n{q[key].rstrip()}\n\n"
 yield '## Provider answers\n\n'
 for p in q['providers']:yield f"### {p['id']}\n\nStatus: `{p['status']}`. Version: {p['version']}. Build: {p['build']}. Channel: {p['input_channel']}. Dialect: {p['dialect']}.\n\n{p['answer']}\n\n"
 yield '## Exact evidence\n\n'
 for e in q['evidence']:
  selector=f" JSON pointer `{e['json_pointer']}`." if 'json_pointer' in e else ''
  if 'lines' in e:selector+=f" Lines {e['lines'][0]}–{e['lines'][1]}."
  yield f"- `{e['id']}` ({e['role']}): [{e['path']}](../../../../{e['path']}). SHA-256 `{e['sha256']}`.{selector} {e['description']}\n"
 if not q['evidence']:yield 'No evidence artifact is attached.\n'
 yield '\n## Source inspection\n\n'
 if not q['source_anchors']:yield 'No implementation source excerpt is attached. Native outputs do not supply an implementation explanation.\n'
 for p in q['source_anchors']:
  geom=''
  if 'line_unit' in p:geom+=f" Line unit: {p['line_unit']}."
  if 'byte_range' in p:geom+=f" Original byte range [{p['byte_range'][0]}, {p['byte_range'][1]})."
  yield f"{p['provider']} {p['version']}, revision `{p['revision']}`, `{p['original_path']}`, function `{p['function']}`, lines {p['lines'][0]}–{p['lines'][1]}.{geom} Full-source SHA-256 `{p['source_sha256']}`; snippet SHA-256 `{p['snippet_sha256']}`; retained evidence `{p['evidence']}`.\n\n```text\n{p['snippet']}\n```\n\n"
 yield '\n## Consumer bindings\n\n'
 for p in q['owners']:yield f"- [{p['path']}](../../../../{p['path']}), `{p['symbol']}`: {p['purpose']}\n"
 for p in q['tests']:yield f"- [{p['path']}](../../../../{p['path']}), `{p['selector']}` ({p['status']}): {p['assertion']}\n"
 if not q['tests'] and not q['owners']:yield 'No implementation binding is claimed by this observation record.\n'
 yield '\nA named test is a coverage binding, not a claim that it executed.\n\n## Replay\n\n'
 if q['replay']['command']:yield 'Recorded argument vector:\n\n```json\n'+json.dumps(q['replay']['command'],indent=2)+'\n```\n\n'
 yield q['replay']['limitations']+'\n'
ad=[];mismatch=[]
for q in records:
 p=q['document'];r=R.get(p)
 if not r or r['review_status']=='reviewed':continue
 d=g['content'](r);assert hashlib.sha256(d).hexdigest()==r['source_sha256'];pieces=list(fragments(q));at=0;ok=True
 for fragment in pieces:
  f=fragment.encode()
  if d[at:at+len(f)]!=f:ok=False;break
  at+=len(f)
 if not ok or at!=len(d):mismatch.append({'path':p,'first_unmatched_byte':at,'source_sha256':r['source_sha256']});continue
 ev={'actual_generator_owner':owner['path'],'owner_source_sha256':owner['source_sha256'],'actual_owner_source_ranges':[[80,120]],'manifest':mp,'manifest_sha256':hashlib.sha256(md).hexdigest(),'record_id':q['id'],'kind':q['kind'],'document':p,'complete_static_fragment_correspondence':True,'unmatched_bytes':0,'record_roles':{'provider_rows':len(q['providers']),'evidence_rows':len(q['evidence']),'source_anchor_rows':len(q['source_anchors']),'consumer_rows':len(q['owners']),'test_rows':len(q['tests'])}}
 r.update(review_status='reviewed',review_mode='complete_static_generator_template_and_record_field_correspondence',classification='derived_question_record_document_not_current_operational_source',reason='Exact authentic reviewed updater render route, actual central record.document membership and full file static template/field byte correspondence; no authored/executable remainder. Original question/provider/conclusion/source/test semantics are record evidence and separate unfinished proof gate, not another product naming implementation or generated-marker exemption.',reviewed_production_extent='Complete bytes partition into known literal template and exact central record fields, no unmatched bytes. Not a manual semantic read of provider prose, original expected result, source snippet or invocation argument.',evidence=[ev],consumer_ids=[],tests='No generator imported/run, no docs published, no source/provider/test/original answer accepted. Static correspondence only.');ad.append({'path':p,'blob':r['blob'],'source_sha256':r['source_sha256'],'provenance':ev})
g['save'](c,s);out={'baseline':c['baseline'],'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_only':True,'manifest_sha256':hashlib.sha256(md).hexdigest(),'static_fragment_projection_paths':ad,'unmatched_remaining':mismatch,'scope':'Only newly unfinished actual central document members with full strict byte/field template correspondence; not all Markdown or archive paths. Existing reviewed outputs unchanged. Original record/provider/answer semantics and full proof gate remain independently unresolved.'};p=B/'audit-proof-document-projection-role.json';p.write_text(json.dumps(out,indent=2)+'\n');print(p,hashlib.sha256(p.read_bytes()).hexdigest(),len(ad),len(mismatch))
