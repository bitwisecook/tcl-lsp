import runpy,json,hashlib,datetime
from pathlib import Path
B=Path('/workspace/name-session/full-consumer-audit');x=runpy.run_path(str(B/'audit-review-tools.py'));u=runpy.run_path(str(B/'audit-review-surfaces.py'));c,s=x['load']();by={r['path']:r for r in c['files']};ds=[];ad=[]
for fn in ['lsp-audit-live-tcl-source-receipt.json','root-audit-release-peer.json']:
 d=json.loads((B/fn).read_text());rs=d.get('purpose_rows',d.get('purpose_proposals'));fs=d.get('whole_source_files',d.get('files'))
 for f in fs:
  p=f['path'];r=by[p];data=x['content'](r);assert r['blob']==f.get('blob',f.get('git_blob')) and hashlib.sha256(data).hexdigest()==f['source_sha256']==r['source_sha256'];lines=data.decode().splitlines();n=f.get('whole_lines',len(lines));assert len(lines)==n
  if 'aid' in f:assert hashlib.sha256(Path(f['aid']).read_bytes()).hexdigest()==f['aid_sha256']
  else:assert f['actual_read_lines']==[[1,n]]
  es=[];own=[]
  for z in rs:
   if z['path']!=p:continue
   assert lines[z['line']-1].strip()==z['source_line'].strip();state=z['disposition'];reason=z.get('reason',z.get('evidence',''));purpose=z.get('purpose',z['symbol']+' actual operational source purpose');api=z.get('shared_api',z.get('actual_shared_api',''));missing=z.get('missing_integration',reason if state.startswith('pending') or state=='needs_migration' else '') or '';ctx=z.get('context',reason)
   if state=='intentional_no_change':state='shared_owner'
   if p=='scripts/release/rust_release.sh' and z['line']==185:
    state='needs_migration';missing='Actual ls-remote --exit-code match/nomatch/provider-error outcomes must remain distinct before reporting remote tag free. No remote/network command run.'
   if p=='scripts/release/smoke_installer.sh' and z['line']==53:
    state='needs_migration';missing='Keep destructive cleanup within exclusively claimed smoke root or explicitly authorize/validate selected override ownership. Arbitrary TCL_LSP_PREFIX is not owned by independent SMOKE_ROOT mktemp.'
   if p=='scripts/release/smoke_installer.sh' and z['line']==127:
    ctx+=' Primary precision: any-manifest-hash membership is explicitly the documented weak policy133–135, not proven selected-asset correspondence. Version-correct promise20–21 requires separate CLI value and MCP structured protocol result/id/error controls; no fresh failing runtime observation.'
   if z.get('id')=='lsp-audit-live-tcl-handler-publication-lifetime':
    missing+=' Primary bound: actual generated proc command is published via original Tcl proc value argv, so no source injection allegation. Required integration is publication freshness and held handler ownership/lifetime; do not automatically call every trusted-framework slot rename a security defect.'
   if state=='migrated_validation_pending':raise AssertionError(z)
   es.append((z['symbol'],z['line'],purpose,state,ctx,api,missing,z.get('controls',[])));own.append((z,purpose,reason,state));ds.append({'peer':fn,'path':p,'symbol':z['symbol'],'line':z['line'],'peer_disposition':z['disposition'],'primary_disposition':state,'purpose':purpose,'reason':reason})
  if p=='scripts/release/resolve-release-artefact.sh':
   # Existing whole primary owner not replaced/duplicated by same single-subject callee.
   for q in s['consumers']:
    if q['path']==p:q['source_evidence'].append({'peer':fn,'sha256':hashlib.sha256((B/fn).read_bytes()).hexdigest(),'extent':f'Whole{n} additional actual source peer; existing owner row retained.','pending_domain':'Legal newline/general path domain is distinct from maintained closed artifact vocabulary; no universal path obligation inferred.'})
   ad.append(p);continue
  extent=f'Whole{n}actual original lines read by '+('LSP' if fn.startswith('lsp') else 'Root')+' including every executable Tcl/shell/Python/AWK/Node/YAML/process/provider/source/setup/cleanup/assertion statement; exact baseline blob/source and aid hashes or whole supplemental ranges verified. Primary bounded source/purpose challenge. No execution.'
  u['surface'](c,s,p,'independent_whole_current_operational_source_peer',extent,es,mode='whole_independent_operational_source_peer_read')
  for z,purpose,reason,state in own:
   q=next(q for q in s['consumers'] if q['path']==p and q['symbol']==z['symbol'] and q['purpose']==purpose);q['source_evidence'].append({'peer':fn,'peer_sha256':hashlib.sha256((B/fn).read_bytes()).hexdigest(),'actual_source_line':z['source_line'],'reason':reason,'peer_disposition':z['disposition'],'code_change_sites':z.get('code_change_sites',[])});q['repair_family']=z.get('repair_family');q['peer_original_work_kind']=z.get('work_kind')
  r['peer_receipt']=fn;ad.append(p)
# Retain exact previous Python admission history after successor precision correction.
old=B/'lsp-audit-python-ownership-source-receipt-before-precision-5f2bb02e.json';assert hashlib.sha256(old.read_bytes()).hexdigest()=='5f2bb02e12adef7f30b94ffa972958e47adec3e1c637cdabb6b898281d3ee1f3'
for q in s['consumers']:
 if q['path'] in {f['path'] for f in json.loads(old.read_text())['whole_source_files']}:
  for ev in q['source_evidence']:
   if ev.get('peer')=='lsp-audit-python-ownership-source-receipt.json' and ev.get('peer_sha256')=='5f2bb02e12adef7f30b94ffa972958e47adec3e1c637cdabb6b898281d3ee1f3':ev['peer']=old.name
  q['source_evidence'].append({'peer':'lsp-audit-python-ownership-source-receipt.json','peer_sha256':hashlib.sha256((B/'lsp-audit-python-ownership-source-receipt.json').read_bytes()).hexdigest(),'scope':'Successor precision preserves best-effort optional headers; selected unavailable/empty status only confirmed; multiheader domain pending.'})
x['save'](c,s);a=json.loads((B/'audit-tooling-active-reservations.json').read_text())
for r in a['reservations']:
 if r['path'] in ad:r['read_status']='whole_actual_peer_admitted_source_only';r['reservation_status']='released'
(B/'audit-tooling-active-reservations.json').write_text(json.dumps(a,indent=2)+'\n');p=B/'audit-loans-08-live-release-admission.json';p.write_text(json.dumps({'baseline':c['baseline'],'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_only':True,'admitted_paths':ad,'primary_challenges':['Live runner standalone JSON wire source is not a proven Rust LiveSession caller.','SCF source grammar, object selection, alias publication, profile kind, attached rule identity and destination value are distinct purposes; exact bridge missing, not new local Rust/Python/Tcl parser.','Event actual configured lifecycle consumption distinct from correct generated vocabulary/order and unknown flow tie policy.','Actual handler publication via Tcl proc argv is not source injection; freshness/body-owner lifetime separate.','Root remote tag state and arbitrary smoke override cleanup are source-confirmed validation-setup code repairs, preserving peer pending_validation chronology.','Any-manifest hash policy explicitly documented; selected-asset correspondence stronger contract remains separate. CLI/MCP exact values and structured protocol controls not satisfied by substring.','Original Python predecessor receipt retained with exact prior SHA and current successor precision, no history overwrite.'],'decisions':ds,'purpose_rows_after':len(s['consumers'])},indent=2)+'\n');print(p,hashlib.sha256(p.read_bytes()).hexdigest(),len(s['consumers']))
