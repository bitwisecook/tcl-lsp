from pathlib import Path
import json,re,hashlib
P=Path('/workspace/name-session/full-consumer-audit');ns={};exec((P/'compiler-extract-production.py').read_text().split('rows=[]')[0],ns);mask=ns['mask'];out=[]
for r in json.load(open(P/'compiler-production-index.json')):
 s=(P/'compiler-baseline'/r['path']).read_text();m=mask(s);offsets=[0]
 for l in s.splitlines(True):offsets.append(offsets[-1]+len(l))
 for a,b in r['omitted_cfg_test_line_ranges']:
  attr=re.search(r'#\s*\[\s*cfg\s*\(\s*test\s*\)\s*\]',m[offsets[a-1]:]);
  if not attr:continue
  i=offsets[a-1]+attr.end();stack=[];j=i
  while j<len(m):
   ch=m[j]
   if ch in '([':stack.append(ch)
   elif ch in ')]' and stack:stack.pop()
   elif not stack and ch in ',;':j+=1;break
   elif not stack and ch=='}':break
   elif not stack and ch=='{':
    dep=1;j+=1
    while j<len(m) and dep:
     if m[j]=='{':dep+=1
     elif m[j]=='}':dep-=1
     j+=1
    break
   j+=1
  end=s.count('\n',0,j)+1
  if end<b:
   first=end+1
   # End can land before a production closing brace on the same line. Retain end line as supplemental.
   if j<len(m) and m[j]=='}':first=end
   rr=[first,b]
   out.append(dict(path=r['path'],source_sha256=r['source_sha256'],old_omitted_range=[a,b],bounded_cfg_end_line=end,recovered_original_lines=rr,source=''.join(s.splitlines(True)[first-1:b]),review_status='unexamined_recovered_production_or_surrounding_item_structure'))
res={'baseline':'cc24c394004fc187378ba0eefb6c2c5b2615fb00','method':'Screen every original omitted range with top-level comma/unmatched-close termination in addition to semicolon/block; exact recovered source retained. This is a conservative lexical correction candidate inventory, not Rust AST proof or automatic actual read. Original aids stay immutable.','rows':out}
(P/'compiler-omitted-boundary-recovery.json').write_text(json.dumps(res,indent=2)+'\n')
print('recovery ranges',len(out),'lines',sum(x['recovered_original_lines'][1]-x['recovered_original_lines'][0]+1 for x in out))
for x in out:print(x['path'],x['old_omitted_range'],'=>',x['recovered_original_lines'])
