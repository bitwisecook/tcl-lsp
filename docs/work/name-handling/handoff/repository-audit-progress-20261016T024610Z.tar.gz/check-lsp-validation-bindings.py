from pathlib import Path
import json,subprocess,hashlib,datetime
D=Path('/workspace/name-session/full-consumer-audit');p=D/'lsp-migration-units.json';raw=p.read_bytes();j=json.loads(raw);R=Path('/workspace/tcl-lsp');B=j['baseline'];errors=[];cache={};checked=[]
for u in j['validation_infrastructure_units']:
 for e in u['sites']:
  s=e['site'];path=s['path']
  if path not in cache:cache[path]=subprocess.check_output(['git','show',B+':'+path],cwd=R)
  b=cache[path];original=b.decode().splitlines();nums=s.get('lines',[s.get('line')]);texts=s.get('source_lines',[s.get('source_line')]);assert len(nums)==len(texts)
  for n,t in zip(nums,texts):
   ok=hashlib.sha256(b).hexdigest()==s['source_sha256'] and n is not None and 1<=n<=len(original) and original[n-1]==t;checked.append(dict(unit=u['id'],path=path,line=n,state=e['disposition'],exact_source_binding=ok))
   if not ok:errors.append(checked[-1])
o=dict(baseline=B,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_catalogue_sha256=hashlib.sha256(raw).hexdigest(),families=len(j['validation_infrastructure_units']),actual_anchors=len(checked),checks=checked,errors=errors,status='Mechanical originalSHA/fulloriginal line only; families include source questions and existing oracle validation, not all required code changes. No purpose/uniqueness/test/provider/acceptance donated.')
q=D/'root-lsp-validation-family-binding-check.json';q.write_text(json.dumps(o,indent=2)+'\n');print(json.dumps({k:o[k] for k in ['families','actual_anchors','errors']}))
