import json,runpy,hashlib,datetime
from pathlib import Path
B=Path('/workspace/name-session/full-consumer-audit');g=runpy.run_path(str(B/'audit-review-tools.py'));h=runpy.run_path(str(B/'audit-review-surfaces.py'));c,s=g['load']();R={r['path']:r for r in c['files']};peers=[('lsp-audit-value-guide-source-receipt.json','b1da7a77fb5467ac1b2f43ffdd76c32d026d715142b57c62ab6e0cb628666b30'),('lsp-audit-kcs-guidance-source-receipt.json','aa7f4cad2a83017733daf3b52b0f6ef97d9293e02b7c838f0746bd7aaa68c5bd'),('lsp-audit-kcs-features-source-receipt.json','09a612b6320729363414b19d3363b001b27a82376347ab603c0d9ba375f2da94')];ad=[];news=[]
for fn,sha in peers:
 p=B/fn;assert hashlib.sha256(p.read_bytes()).hexdigest()==sha;a=json.loads(p.read_text())
 for f in a['whole_source_files']:
  path=f['path'];r=R[path];d=g['content'](r);assert hashlib.sha256(d).hexdigest()==f['source_sha256']==r['source_sha256'];assert f['blob']==r['blob'];assert len(d.splitlines())==f['whole_lines'];assert hashlib.sha256(Path(f['aid']).read_bytes()).hexdigest()==f['aid_sha256'];assert f['actual_read_ranges']==[[1,f['whole_lines']]];es=[]
  for z in a['purpose_rows']:
   if z['path']!=path:continue
   assert d.decode().splitlines()[z['line']-1].strip()==z['source_line'].strip();es.append((z['symbol'],z['line'],z['purpose'],z['disposition'],z.get('context',z.get('reason','')),z.get('shared_api',''),z.get('missing_integration',z.get('reason','')),z.get('controls',[])))
   if z['disposition']=='needs_migration':news.append(z)
  h['surface'](c,s,path,'whole_current_authored_guidance_inert_source_peer',f"Whole1–{f['whole_lines']}actual original lines, including every long table/recipe/code cell. Independent whole read, exact baseline blob/source/aid equality; docs read inertly, no skill/provider/generator/test executed.",es,mode='whole_independent_authored_guidance_peer_read')
  for z in a['purpose_rows']:
   if z['path']!=path:continue
   q=next(x for x in s['consumers'] if x['path']==path and x['symbol']==z['symbol'] and x['purpose']==z['purpose']);q['source_evidence'].append({'peer':fn,'peer_sha256':sha,'source_line':z['source_line'],'reason':z.get('reason'),'repair_family':z.get('repair_family')});q['repair_family']=z.get('repair_family');q['peer_original_work_kind']=z.get('work_kind')
  r['peer_receipt']=fn;ad.append(path)
g['save'](c,s);act=json.loads((B/'audit-tooling-active-reservations.json').read_text())
for z in act['reservations']:
 if z['path'] in ad:z['reservation_status']='released';z['read_status']='whole_actual_guidance_peer_admitted_source_only'
(B/'audit-tooling-active-reservations.json').write_text(json.dumps(act,indent=2)+'\n')
out={'baseline':c['baseline'],'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'peers':peers,'paths':ad,'paths_count':len(ad),'required_raw_purposes':news,'primary_decisions':['Value-guide apparent ancestor example is not discriminatory: actual one-level current-to-root fallback supplies no implicit ancestor behavior proof. Successor pending_audit admitted, no mandatory example/doc change. Exact prior receipt preserved by LSP.','Quoted list variable substitution and raw braced-list backslash-newline claims are explicit false phase descriptions against actual shared list owner. Two raw sites belong one documentation purpose, not product parser changes.','KCS exact seed replay assurance joins actual existing source/config replay and marker guidance family, no second generator repair.','W123 blanket whole-file load/rename/import and skipped qualified-name documentation conflicts actual positioned diagnostic presence owner and only-Absent emission. Required docs correction, no extra product resolver.','Every standalone catalogue/example/omission scope question remains pending; no documentation or semantic acceptance inferred from source read.'],'purpose_rows_after':len(s['consumers'])};p=B/'audit-loans-13-guidance-admission.json';p.write_text(json.dumps(out,indent=2)+'\n');print(p,hashlib.sha256(p.read_bytes()).hexdigest(),len(ad),len(news),len(s['consumers']))
