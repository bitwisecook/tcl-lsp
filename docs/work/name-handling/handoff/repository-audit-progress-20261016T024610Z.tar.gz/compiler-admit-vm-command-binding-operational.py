import json,hashlib,datetime
from pathlib import Path
P=Path('/workspace/name-session/full-consumer-audit');pp=P/'compiler-vm-command-binding-operational-read.json';assert hashlib.sha256(pp.read_bytes()).hexdigest()=='457ddc16d8c444a4cfda2a8bb6c79d4fd9884f5cc903877ebdbb3aaab04f16c0';peer=json.load(open(pp));path=peer['source']['path'];c=json.load(open(P/'compiler-file-coverage.json'));r=next(x for x in c['rows'] if x['path']==path);assert r['source_sha256']==peer['source']['source_sha256'];assert hashlib.sha256((P/'compiler-baseline'/path).read_bytes()).hexdigest()==r['source_sha256'];r.update(embedded_cfg_test_operational_review_complete=True,review_complete=True,review_status='source_reviewed',review_mode='whole_production_and_exact_all_inline_operational_source_peer_read',operational_review_receipt=pp.name,operational_review_limits='Inprocess setup/debug/thread and helper source reviewed; no provider/test execution. External cfg(test) child modules separate.')
b=json.load(open(P/'compiler-inline-test-operational-backlog.json'))
for x in b['rows']:
 if x['path']==path:
  x.update(kind='all_exact_omitted_operational_ranges_actual_read_complete',operational_review_complete=True,receipt=pp.name)
  for m in x.get('members',[]):m.update(body_review_mode='actual_full_operational_source_read_by_exact_peer',operational_setup_disposition='Actual inprocess setup/fixtures/helpers/debug/thread source read; no test/provider execution or external child coverage.')
rec=dict(baseline=peer['baseline'],peer_receipt=pp.name,peer_sha256=hashlib.sha256(pp.read_bytes()).hexdigest(),path=path,operational_raw_ranges=len(peer['source']['read_ranges']),source_admission='Exact original all29 omission ranges actual-read; callee admissions and fixed NativeDeep recipe retain bounded independent evidence.',new_required_units=0,utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
for n,o in [('compiler-file-coverage.json',c),('compiler-inline-test-operational-backlog.json',b),('compiler-vm-command-binding-operational-admission.json',rec)]:
 t=P/(n+'.tmp');t.write_text(json.dumps(o,indent=2)+'\n');t.replace(P/n)
print('Admitted main command_binding full actual operational source, no execution donation.')
