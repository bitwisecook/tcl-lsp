import json,hashlib,datetime,subprocess
from pathlib import Path
P=Path('/workspace/name-session/full-consumer-audit');c=json.load(open(P/'compiler-file-coverage.json'));d=json.load(open(P/'compiler-consumers.json'));now=datetime.datetime.now(datetime.timezone.utc).isoformat()
packets=[('analyser-types','1f51cbc13f68aaf13f332a34dd6b56efb7b9baa3697111e01113e165fbc9f022','compiler-root-analyser-types-reservation.json','Actual member/property/lifecycle string key collision is a shared typed report/item identity owner change, with existing LSP Core/server adapters linked once. No unchanged caller inflation; actual retained scope/frame/source joins remain. Synthetic declared-keyword lifecycle selector is a caller/domain question, not blanket defect.')]


for name,sha,resname,challenge in packets:
 pp=P/('root-compiler-'+name+'-peer.json');peer=json.load(open(pp));assert hashlib.sha256(pp.read_bytes()).hexdigest()==sha;assert peer['baseline']==c['baseline']
 for f in peer['files']:
  r=next(x for x in c['rows'] if x['path']==f['path']);assert hashlib.sha256((P/'compiler-baseline'/f['path']).read_bytes()).hexdigest()==f['source_sha256']==r['source_sha256'];assert hashlib.sha256((P/'compiler-production'/f['path']).read_bytes()).hexdigest()==f['aid_sha256'];assert r['git_blob']==f['git_blob'];test=bool(f['omitted_cfg_test_line_ranges']);r.update(production_review_complete=True,review_complete=not test,review_status='production_reviewed_inline_tests_pending' if test else 'source_reviewed',review_mode='full_production_source_read_by_root_peer_exact_hash_receipt',embedded_cfg_test_operational_review_complete=not test,classification='source_purpose_consumer_reviewed',peer_review_receipt=pp.name,reviewed_utc=now,justification=challenge+' Omitted operational source remains unexamined.')
 for f in peer.get('supplemental_actual_reads',[]):
  local=P/'compiler-baseline'/f['path'];raw=local.read_bytes() if local.exists() else subprocess.check_output(['git','show',peer['baseline']+':'+f['path']],cwd='/workspace/tcl-lsp');assert 'source_sha256' not in f or hashlib.sha256(raw).hexdigest()==f['source_sha256']
 for f in peer['purpose_proposals']:
  r=next(x for x in c['rows'] if x['path']==f['path']);key=f['path']+'#'+f['symbol']+'#'+f['actual_shared_api'];disp=f['disposition'];q=dict(key=key,canonical_site_key=key,path=f['path'],symbol=f['symbol'],line=f['line'],site_purpose=f['actual_shared_api'],source_sha256=r['source_sha256'],git_blob=r['git_blob'],actual_shared_api=f['actual_shared_api'],missing_integration=f['evidence'],disposition=disp,work_kind='consumer_integration' if disp=='needs_migration' else 'unreconciled' if disp=='pending_audit' else 'intentional/exclusion',work_kind_reason='Exact independent source-purpose peer; actual adapters separate from shared owner prerequisites and unchanged callers.',evidence=[f['evidence'],challenge],tests=[],validation='Source review only. Omitted operational source and all execution/provider parity unexecuted.',repair_family=f.get('repair_family'));d['rows']=[x for x in d['rows'] if x['key']!=key]+[q];r.setdefault('consumer_keys',[])
  if key not in r['consumer_keys']:r['consumer_keys'].append(key)
 respath=P/resname;res=json.load(open(respath));res.update(status='released_after_complete_peer_admission',admission_receipt='compiler-'+name+'-peer-admission.json')
 receipt=dict(baseline=peer['baseline'],peer_receipt=pp.name,peer_sha256=sha,admitted_files=[x['path'] for x in peer['files']],production_aid_lines=peer['actual_production_aid_lines'],purpose_rows=len(peer['purpose_proposals']),disposition_counts=peer['disposition_counts'],independent_challenge=challenge,tests='Unexecuted. Omitted operational source not admitted.',utc=now)
 for path,obj in [(respath,res),(P/receipt['peer_receipt'].replace('root-','').replace('-peer.json','-peer-admission.json'),receipt)]:
  t=path.with_name(path.name+'.tmp');t.write_text(json.dumps(obj,indent=2)+'\n');t.replace(path)
for n,obj in [('compiler-file-coverage.json',c),('compiler-consumers.json',d)]:
 t=P/(n+'.tmp');t.write_text(json.dumps(obj,indent=2)+'\n');t.replace(P/n)
print('Admitted Root diagnostic/bounds and analyser-state complete production peers; exact actual adapter purposes and unresolved questions retained.')
