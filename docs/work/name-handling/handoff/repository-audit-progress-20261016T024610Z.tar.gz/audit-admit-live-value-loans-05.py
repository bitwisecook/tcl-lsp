import runpy,json,hashlib,datetime
from pathlib import Path
B=Path('/workspace/name-session/full-consumer-audit');x=runpy.run_path(str(B/'audit-review-tools.py'));u=runpy.run_path(str(B/'audit-review-surfaces.py'));c,s=x['load']();by={r['path']:r for r in c['files']};decisions=[];admitted=[]
for fname in ['lsp-audit-value-generator-source-receipt.json','lsp-audit-live-smoke-source-receipt.json','root-audit-builtins-peer.json']:
 d=json.loads((B/fname).read_text());rows=d.get('purpose_rows',d.get('purpose_proposals'));fs=d.get('whole_source_files')
 if fs is None:
  f=d['source'];fs=[dict(path=f['path'],blob=f['git_blob'],source_sha256=f['sha256'],aid=f['aid'],aid_sha256=f['aid_sha256'],whole_lines=1771)]
 for f in fs:
  r=by[f['path']];data=x['content'](r);assert r['blob']==f['blob'] and hashlib.sha256(data).hexdigest()==f['source_sha256']==r['source_sha256'];assert len(data.splitlines())==f['whole_lines'];assert hashlib.sha256(Path(f['aid']).read_bytes()).hexdigest()==f['aid_sha256'];entries=[];own=[]
  for z in rows:
   if z['path']!=f['path']:continue
   assert data.decode().splitlines()[z['line']-1].strip()==z['source_line'].strip(),(z['symbol'],z['line'])
   state=z['disposition'];reason=z.get('reason',z.get('evidence',''));purpose=z.get('purpose');api=z.get('shared_api','');missing=z.get('missing_integration',z.get('unresolved_requirement',reason if state.startswith('pending') or state=='needs_migration' else '')) or '';context=z.get('context',reason)
   if state=='intentional_no_change':
    state='shared_owner'
    if z['symbol'] in ['format_catalogue/arity']:state='display_only'
    if z['symbol']=='catalogue/add/recursion tests':state='out_of_scope'
   assert state!='migrated_validation_pending','No historical migration receipt admitted from current source alone'
   if not purpose:
    purpose={'Builtin/BuiltinSpec/lookup/all_specs/build_registry':'actual query builtin declaration and exact dispatch owner','format_catalogue/arity':'actual query catalogue and arity display','registrations/plain/ctx/special':'actual query invocation mode and feature declaration','as_str/type_name':'explicit query scalar text conversion purpose','object_entries/to_jsonable/value_children':'structured query key and JSON projection','all_paths/value_at_path/coerce_path_list':'typed query object key and list index paths','set_at_path/delete_at_path/scalar_key_str':'query read versus mutation key coercion contract','scalar_key_str/py_repr':'query key coercion and diagnostic repr contract','bi_has/keys/keys_unsorted/from_entries':'exact query dictionary membership and entry conversion','bi_add/str/tostring/tonumber':'explicit query aggregate and scalar conversion','catalogue/add/recursion tests':'independent actual query controls and worker stack setup'}[z['symbol']]
   controls=z.get('controls',[]);entries.append((z['symbol'],z['line'],purpose,state,context,api,missing,controls));own.append((z,purpose,reason,state));decisions.append({'peer':fname,'proposal':z.get('id',z['symbol']),'path':f['path'],'purpose':purpose,'state':state,'reason':reason})
  extent=f"Whole{f['whole_lines']}actual original lines read by independent {('Root' if fname.startswith('root') else 'LSP')} reviewer including every operational test/helper/template/source/process stage; exactblob/source/aidSHA checked and bounded primary purpose/source challenge. No dependency/execution donation. Receipt {fname}."
  u['surface'](c,s,f['path'],'independent_whole_live_operational_source_peer',extent,entries,mode='whole_independent_production_and_operational_peer_read')
  for z,purpose,reason,state in own:
   row=next(q for q in s['consumers'] if q['path']==f['path'] and q['symbol']==z['symbol'] and q['purpose']==purpose);row['source_evidence'].append({'peer':fname,'peer_sha256':hashlib.sha256((B/fname).read_bytes()).hexdigest(),'actual_source_line':z['source_line'],'reason':reason,'code_change_sites':z.get('code_change_sites',[]),'affected_call_sites':z.get('affected_call_sites',[])});row['repair_family']=z.get('repair_family');row['peer_original_work_kind']=z.get('work_kind')
  r['peer_receipt']=fname;admitted.append(f['path'])
# Rebind corrected KCS peer metadata, preserving exact earlier receipt under its retained beforeimage.
old=B/'root-kcs-index-links-before-prefix-peer.json';cur=B/'root-kcs-index-links-peer.json';oldsha=hashlib.sha256(old.read_bytes()).hexdigest()
for row in s['consumers']:
 if row['path']=='rust/xtask/src/kcs_index_links.rs':
  for ev in row['source_evidence']:
   if ev.get('peer')=='root-kcs-index-links-peer.json' and ev.get('peer_sha256')==oldsha:ev['peer']='root-kcs-index-links-before-prefix-peer.json';ev['successor_peer']='root-kcs-index-links-peer.json';ev['successor_peer_sha256']=hashlib.sha256(cur.read_bytes()).hexdigest()
x['save'](c,s);o=json.loads((B/'audit-tooling-active-reservations.json').read_text())
for q in o['reservations']:
 if q['path'] in admitted:q['read_status']='whole_actual_peer_admitted_source_only';q['reservation_status']='released'
(B/'audit-tooling-active-reservations.json').write_text(json.dumps(o,indent=2)+'\n');p=B/'audit-loans-05-admission.json';p.write_text(json.dumps({'baseline':c['baseline'],'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Five exact whole-source independent admissions plus bounded primary source/semantic challenge. No source/provider/Cargo/test/gate execution or all-repository migration acceptance.','actual_challenges':['Net object path parse/render/partition visibility uses genuine same-domain value/folder.rs and partition.rs; lookup policies not donor. New leaf construction remains purpose/domain question.','Generator finite source/error productions are original independent oracle inputs; selected backend/version caller does not force replacing independent menu from implementation.','Live fire_event decoded name interpolation distinct from run_http_request intentionally authored args source. Actual source_file has OS Path display inverse.','Smoke source inventory native path records and POSIX marker source constructors are actual operational endpoints, distinct codecs.','Five current-code migration states individually corrected by peer: standalone host source ingress shared_owner; measured/enrol/result/source constructor acceptance pending_validation, no historical beforeimage donation.','KCS exact old peer beforeimage preserved and successor narrowed safe ASCII prefix classification.'],'admitted_paths':admitted,'decisions':decisions,'purpose_rows_after':len(s['consumers'])},indent=2)+'\n');print(p,hashlib.sha256(p.read_bytes()).hexdigest(),len(s['consumers']))
