import json,runpy,hashlib,datetime,gzip,re,collections
from pathlib import Path,PurePosixPath
B=Path('/workspace/name-session/full-consumer-audit');g=runpy.run_path(str(B/'audit-review-tools.py'));c,s=g['load']();R={r['path']:r for r in c['files']};target={'binary','build','changed_sources','empty_filters','finished_utc','missing_exact','run','runs','selected_tests','started_utc','summaries'};ad=[];co=[];unmatched=[];runner=collections.Counter()
def checked(r):
 d=g['content'](r);assert hashlib.sha256(d).hexdigest()==r['source_sha256'];return d
def mark(r,kind,ev):
 if r['review_status']=='reviewed':return
 r.update(review_status='reviewed',review_mode='complete_historical_execution_record_schema_and_referenced_artifact_role_projection',classification=kind,reason='Actual closed process receipt schema, original argument vector, recorded binary/time/source metadata and exact referenced artifact membership establish retained result/input/output data role. This is not an archive-prefix exclusion, current executable source, fixture-derived semantic authority or a replay/test pass donation.',reviewed_production_extent='Complete recursive JSON record/type projection or exact referenced opaque process-output bytes / closed source-digest map, as identified per artifact. No manual process-log or original test/body semantic read claimed.',evidence=[ev],consumer_ids=[],tests='Historical provider/compiler/runner/binary/source/elapsed status and result authenticity remain separate. No current command, generator, original provider, build or test executed.');ad.append(r['path'])
for r in list(R.values()):
 if r['review_status']=='reviewed' or PurePosixPath(r['path']).name!='result.json':continue
 try:q=json.loads(checked(r))
 except (ValueError,UnicodeDecodeError):continue
 if not isinstance(q,dict) or set(q)!=target:continue
 parent=str(PurePosixPath(r['path']).parent);start=R.get(parent+'/start.json')
 if not start:unmatched.append({'path':r['path'],'reason':'No paired original start record'});continue
 t=json.loads(checked(start));allowed={'started_utc','label','package','target','source_paths','plan','rustc','cargo','runner_sha256','source_channel'}
 if not isinstance(t,dict) or set(t)-allowed or set(t)<allowed-{'runner_sha256'}:unmatched.append({'path':r['path'],'reason':'Unclassified start shape'});continue
 if q['started_utc']!=t['started_utc']:unmatched.append({'path':r['path'],'reason':'Paired start timestamp differs'});continue
 assert isinstance(q['runs'],list) and isinstance(q['binary'],dict) and set(q['binary'])=={'bytes','path','sha256'} and re.fullmatch('[0-9a-f]{64}',q['binary']['sha256']);assert isinstance(q['selected_tests'],list) and all(isinstance(z,str) for z in q['selected_tests']);assert isinstance(q['changed_sources'],dict)
 linked=[];bad=[]
 for phase,z in [('build',q['build']),('run',q['run'])]+[('test',z) for z in q['runs']]:
  if z is None:continue
  allowedrun={'command','exit_code','seconds','log','timed_out','test','summaries','running_counts'}
  if not isinstance(z,dict) or set(z)-allowedrun or not {'command','exit_code','seconds','log','timed_out'}<=set(z):bad.append({'phase':phase,'reason':'Unclassified process shape'});continue
  assert isinstance(z['command'],list) and all(isinstance(v,str) for v in z['command']);assert z['exit_code'] is None or isinstance(z['exit_code'],int);assert isinstance(z['timed_out'],bool);assert isinstance(z['seconds'],(float,int));log=z['log'];pp=PurePosixPath(log)
  if not isinstance(log,str) or pp.is_absolute() or '..' in pp.parts or parent+'/'+log not in R:bad.append({'phase':phase,'reason':'Missing/unadmitted relative output path','log':log});continue
  linked.append((R[parent+'/'+log],{'record':r['path'],'phase':phase,'command':z['command'],'recorded_exit':z['exit_code'],'recorded_timeout':z['timed_out'],'output_field':'log','actual_path':parent+'/'+log}))
 if bad:unmatched.append({'path':r['path'],'reason':'Incomplete linked process projection','gaps':bad});continue
 ev={'record':r['path'],'record_sha256':r['source_sha256'],'paired_start':start['path'],'paired_start_sha256':start['source_sha256'],'closed_record_keys':sorted(q),'recorded_process_count':len(q['runs']),'binary':q['binary'],'runner_source_sha256':t.get('runner_sha256'),'source_channel':t['source_channel'],'recorded_start':t['started_utc'],'recorded_finish':q['finished_utc'],'schema_role':'Historical process/build/selector/source-bound record. Strings/argv remain stored data; no arbitrary code imported/evaluated.','producer_provenance_limit':'Runner hash identifies claimed historical producer only; actual historical execution/import/current source pairing not established from record or archive presence.'}
 mark(r,'fixed_historical_execution_result_record',ev);mark(start,'fixed_historical_execution_plan_and_tool_metadata',ev)
 for lr,le in linked:mark(lr,'fixed_historical_process_output_referenced_by_closed_result',dict(ev,actual_output=le))
 maps=[]
 for suffix in ['source-before.json.gz','source-after.json.gz']:
  mr=R.get(parent+'/'+suffix)
  if not mr or mr['review_status']=='reviewed':continue
  try:v=json.loads(gzip.decompress(checked(mr)))
  except (OSError,ValueError):continue
  if not isinstance(v,dict) or not all(isinstance(k,str) and isinstance(vv,str) and re.fullmatch('[0-9a-f]{64}',vv) for k,vv in v.items()):continue
  me=dict(ev,source_digest_map={'entries':len(v),'role':'Source path→SHA256 snapshot: data correspondence only, no actual source bodies retained or whole-current-file read supplied.','recorded_source_path_count':t['source_paths'],'record_count_matches_start':len(v)==t['source_paths']});mark(mr,'fixed_historical_source_path_digest_inventory',me);maps.append({'path':mr['path'],'entries':len(v),'matches_recorded_source_count':len(v)==t['source_paths']})
 runner[t.get('runner_sha256','unrecorded')]+=1;co.append({'record':r['path'],'result_sha256':r['source_sha256'],'start':start['path'],'recorded_processes':len(q['runs']),'referenced_output_paths':len(linked),'source_map_roles':maps,'runner_sha256':t.get('runner_sha256')})
g['save'](c,s);out={'baseline':c['baseline'],'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_only':True,'actual_role_contract':'Manually inspected representative complete result/start/build/test process record and source map schema; exact strict per-record validation above excludes unknown keys/shapes. Referenced opaque logs are process output data, no manual text semantics or current source read. Historical command vectors are inert independent execution metadata, not executable integration points.','closed_schema_records':co,'role_classified_paths':ad,'counts':{'records':len(co),'paths':len(ad),'unmatched':len(unmatched)},'unmatched_records':unmatched,'claimed_historical_producer_sha_counts':dict(runner),'unresolved_questions':['Historical runner source/actual launched binary/tool/header/library/source and current acceptance are not established by this data role.','No raw log/reference/helper is imported, interpreted, replayed or treated as an implementation from this record. Nonuniform active runner/setup/generator source remains separate actual-read queue.','Recorded source drift/failed/pass/timeout/status values are historical data, not recomputed/accepted current results. No unsupported fields silently ignored.']};p=B/'audit-historical-execution-receipt-role.json';p.write_text(json.dumps(out,indent=2)+'\n');print(p,hashlib.sha256(p.read_bytes()).hexdigest(),out['counts'])
