import json,runpy,hashlib,datetime,re,collections
from pathlib import Path,PurePosixPath
B=Path('/workspace/name-session/full-consumer-audit');g=runpy.run_path(str(B/'audit-review-tools.py'));c,s=g['load']();R={r['path']:r for r in c['files']};siblings=collections.defaultdict(list)
for r in c['files']:siblings[str(PurePosixPath(r['path']).parent)].append(r)
ad=[];records=[];unmatched=[];hexsha=re.compile('[0-9a-f]{64}')
def mark(r,kind,ev):
 if r['review_status']=='reviewed':return
 r.update(review_status='reviewed',review_mode='complete_recorded_process_schema_and_exact_original_byte_role_projection',classification=kind,reason='Positive actual recorded argv/return/status/hash fields and exact input/output member bytes establish fixed original measurement/process record role. Complete JSON node-role structure or exact referenced original input/output bytes classified; not an archive-path exclusion or semantic/original-result approval. Original independent programs are preserved, not centralised through product naming helpers.',reviewed_production_extent='Exact role metadata below. Original program/output bytes are complete SHA-bound independent inputs/data, not manual whole C/Tcl/program semantics or historical runtime/ABI/input-channel proof. Actual maintained/admission/helper implementation remains separate source scope.',evidence=[ev],consumer_ids=[],tests='No original script/provider/build/test/process/generator imported/executed, expected answer derived or old result/current source accepted. All extra JSON data/prose fields remain inert record content; no active acceptance consumer code inferred from data.');ad.append(r['path'])
for r in list(c['files']):
 if r['review_status']=='reviewed' or PurePosixPath(r['path']).name not in {'record.json','result.json','receipt.json','provenance.json'}:continue
 if not r['path'].startswith(('experiments/','docs/design/analysis/name-resolution-proofs/rust-validation/')):continue
 data=g['content'](r)
 try:q=json.loads(data)
 except (ValueError,UnicodeDecodeError):continue
 if not isinstance(q,dict):continue
 argv=q.get('argv',q.get('command'));exitkeys=[k for k in ['exit','exit_code','process_exit_code'] if k in q]
 if not isinstance(argv,list) or not argv or not all(isinstance(z,str) for z in argv) or not exitkeys:continue
 if not all(q[k] is None or isinstance(q[k],int) for k in exitkeys):continue
 if not all(isinstance(q.get(k),str) and hexsha.fullmatch(q[k]) for k in ['stdout_sha256','stderr_sha256']):continue
 assert hashlib.sha256(data).hexdigest()==r['source_sha256'];parent=str(PurePosixPath(r['path']).parent);outs={}
 for channel in ['stdout','stderr']:
  outs[channel]=[z for z in siblings[parent] if (PurePosixPath(z['path']).name==channel or PurePosixPath(z['path']).name.startswith(channel+'.') or PurePosixPath(z['path']).name.endswith('.'+channel)) and z['source_sha256']==q[channel+'_sha256']]
 if any(not outs[k] for k in outs):unmatched.append({'path':r['path'],'reason':'Exact recorded process-stream file members not both available/matching; no guessed alias or stdout normalization.','stream_match_counts':{k:len(v) for k,v in outs.items()}});continue
 counts=collections.Counter()
 def nodes(v):
  counts[type(v).__name__]+=1
  if isinstance(v,dict):
   for key,z in v.items():assert isinstance(key,str);nodes(z)
  elif isinstance(v,list):
   for z in v:nodes(z)
  else:assert v is None or isinstance(v,(str,int,float,bool))
 nodes(q);ev={'record':r['path'],'record_sha256':r['source_sha256'],'recorded_argv':argv,'recorded_exit_fields':{k:q[k] for k in exitkeys},'complete_JSON_data_roles':{'all_top_level_fields':sorted(q),'all_node_types':dict(counts),'unknown_executable_nodes':0,'extra_field_role':'Inert recorded metadata/source/answer/prose, not an evaluated resolver/acceptance helper. All actual field semantics/provider proof unapproved.'},'exact_process_stream_members':{k:[v['path'] for v in vs] for k,vs in outs.items()},'original_provider_limit':'Recorded argv/labels/hashes/return values do not authenticate historical invocation, selected source/library/header/init/ABI/channel or current conformance. Actual independent expected rows remain byte-exact.'};mark(r,'fixed_original_or_selected_validation_process_record',ev)
 for channel,vs in outs.items():
  for z in vs:mark(z,'fixed_recorded_process_'+channel+'_byte_stream',{'record':r['path'],'record_sha256':r['source_sha256'],'field':channel+'_sha256','recorded_digest':q[channel+'_sha256'],'source_role':'Complete raw original output bytes by exact recorded digest; no manual output semantics, process status/result normalization or current execution admission.'})
 inputs=[]
 for field,names in [('input_sha256',{'input.tcl','source.tcl','probe.tcl','question.tcl'}),('source_sha256',{'source.tcl','question.tcl'}),('probe_sha256',{'probe.c'}),('question_sha256',{'question.tcl'}),('setup_sha256',{'setup.tcl'})]:
  digest=q.get(field)
  if not isinstance(digest,str) or not hexsha.fullmatch(digest):continue
  for z in siblings[parent]:
   if PurePosixPath(z['path']).name not in names or z['source_sha256']!=digest:continue
   mark(z,'fixed_independent_original_measurement_program_input',{'record':r['path'],'record_sha256':r['source_sha256'],'field':field,'recorded_digest':digest,'recorded_argv':argv,'source_role':'Exact independent measured source/program bytes retained as original input, not a current helper/implementation or implementation-derived expected oracle. Actual input channel/phase/ABI/provider/historical run remains separate. No Python/shell helper classified through this original-program rule.','limits':'Complete input bytes/hash/member association only, not manual original C/Tcl semantics/source-provider parity or unsupported runtime behavior claim.'});inputs.append({'path':z['path'],'field':field,'source_sha256':digest})
 records.append({'path':r['path'],'source_sha256':r['source_sha256'],'matched_streams':{k:[v['path'] for v in vs] for k,vs in outs.items()},'original_program_members':inputs,'record_node_roles':dict(counts),'historical_execution_admitted':False})
g['save'](c,s);out={'baseline':c['baseline'],'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_only':True,'record_contract':'Positive recorded argv+return+two exact stream digests, recursively complete JSON typed data classification, exact same-directory named stream/file members. Original C/Tcl byte input joins use explicit original input/source/probe/question/setup SHA fields, never arbitrary source code extension alone. All captured metadata/prose semantics and invocation/provider authority remain separate.','closed_record_roles':records,'new_role_classified_paths':ad,'unmatched_original_records':unmatched,'counts':{'records':len(records),'paths':len(ad),'unmatched':len(unmatched)},'limits':['No metadata value/expected answer/current pass accepted. No current helper imported or old source modified.','No Python/shell capture/helper/source snapshot classified as a mere original program input; those actual source/admission/retention roles remain separately reviewed.','Current maintained source/probe loaders and their actual invocation/setup/publication/currentness requirements remain independent code consumers, not hidden by fixed original record role.','This closes fixed input/output/process data roles for migration scope, not full proof gate/provider/oracle authenticity or source semantic execution.']};p=B/'audit-original-process-record-data-role.json';p.write_text(json.dumps(out,indent=2)+'\n');print(p,hashlib.sha256(p.read_bytes()).hexdigest(),out['counts'])
