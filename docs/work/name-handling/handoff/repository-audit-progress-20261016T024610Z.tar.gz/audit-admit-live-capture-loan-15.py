import json,runpy,hashlib,datetime
from pathlib import Path
B=Path('/workspace/name-session/full-consumer-audit');g=runpy.run_path(str(B/'audit-review-tools.py'));h=runpy.run_path(str(B/'audit-review-surfaces.py'));c,s=g['load']();R={r['path']:r for r in c['files']};peers=[('lsp-audit-live-name-patterns-source-receipt.json','d4179f1f27e61bddad09e3134c060529fc6eae50cdfe920cdfbf3f3aefae7689')];ad=[];news=[]
for fn,sha in peers:
 p=B/fn;assert hashlib.sha256(p.read_bytes()).hexdigest()==sha;a=json.loads(p.read_text())
 for f in a['whole_source_files']:
  path=f['path'];r=R[path];d=g['content'](r);assert hashlib.sha256(d).hexdigest()==f['source_sha256']==r['source_sha256'];assert f['blob']==r['blob'];assert len(d.splitlines())==f['whole_lines'];assert hashlib.sha256(Path(f['aid']).read_bytes()).hexdigest()==f['aid_sha256'];assert f['actual_read_ranges']==[[1,f['whole_lines']]];es=[]
  for z in a['purpose_rows']:
   if z['path']!=path:continue
   assert d.decode().splitlines()[z['line']-1].strip()==z['source_line'].strip();es.append((z['symbol'],z['line'],z['purpose'],z['disposition'],z.get('context',z.get('reason','')),z.get('shared_api',''),z.get('missing_integration',z.get('reason','')),z.get('controls',[])))
   if z['disposition']=='needs_migration':news.append(z)
  h['surface'](c,s,path,'whole_current_maintained_original_capture_source_peer',f"Whole1–{f['whole_lines']}actual original lines, including every long table/recipe/code cell. Independent whole read, exact baseline blob/source/aid equality; docs read inertly, no skill/provider/generator/test executed.",es,mode='whole_independent_original_capture_operational_source_peer_read')
  for z in a['purpose_rows']:
   if z['path']!=path:continue
   q=next(x for x in s['consumers'] if x['path']==path and x['symbol']==z['symbol'] and x['purpose']==z['purpose']);q['source_evidence'].append({'peer':fn,'peer_sha256':sha,'source_line':z['source_line'],'reason':z.get('reason'),'repair_family':z.get('repair_family')});q['repair_family']=z.get('repair_family');q['peer_original_work_kind']=z.get('work_kind')
  r['peer_receipt']=fn;ad.append(path)
g['save'](c,s);act=json.loads((B/'audit-tooling-active-reservations.json').read_text())
for z in act['reservations']:
 if z['path'] in ad:z['reservation_status']='released';z['read_status']='whole_actual_guidance_peer_admitted_source_only'
(B/'audit-tooling-active-reservations.json').write_text(json.dumps(act,indent=2)+'\n')
out={'baseline':c['baseline'],'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'peers':peers,'paths':ad,'paths_count':len(ad),'required_raw_purposes':news,'primary_decisions':['Two actual maintained imported entrypoints accept arbitrary run tag and interpolate remote shell/config source before genuine capture main admission; rpc/run_job do not validate tag. One reusable true capture-preparation/tag owner facet and two actual caller admissions required, validation infrastructure only.','Campaign resume skipping a failed loader attempt can be intentional progress policy; no actual runtime/source-success admission inferred. Requirement stays pending_audit until actual scheduling/reached/current-source contract proven.','Parse_capture full group keys and duplicate incomplete handling already prevent suspected repeated-stage dictionary collapse after actual report caller grouping; no extra parser repair.','Existing independent original source/capture/helper operations and original expected data remain independent, not product naming resolvers. Historical import,55config mismatch,actual provider/context/F5 observations are separate unfinished acceptance questions.'],'purpose_rows_after':len(s['consumers'])};p=B/'audit-loans-15-live-capture-admission.json';p.write_text(json.dumps(out,indent=2)+'\n');print(p,hashlib.sha256(p.read_bytes()).hexdigest(),len(ad),len(news),len(s['consumers']))
