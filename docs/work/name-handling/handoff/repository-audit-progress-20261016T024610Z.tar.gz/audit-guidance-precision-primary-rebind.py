import json,hashlib,runpy,datetime
from pathlib import Path
B=Path('/workspace/name-session/full-consumer-audit');g=runpy.run_path(str(B/'audit-review-tools.py'));c,s=g['load']();pairs=[('guidance-install','8c16a345','8c16a345a7decd897d4235cc9575bd3874f40b9e9bd2e57df45a9a39b4d8e1e1'),('root-guidance','15d15835','15d1583565ae4c3f645d68081bd14fc67d11c56ab31bfae08ddee1f7ed8c2aa4'),('large-implementer','fcd6730d','fcd6730d2c33b77e25c5a35d5ac58f0b42e64b4bd6ff81c2f328a4b9a13734be')];changes=[]
for stem,short,sha in pairs:
 old=f'lsp-audit-{stem}-source-receipt.json';before=f'lsp-audit-{stem}-source-receipt-before-scope-precision-{short}.json';assert hashlib.sha256((B/before).read_bytes()).hexdigest()==sha
 successor=hashlib.sha256((B/old).read_bytes()).hexdigest()
 for row in s['consumers']:
  for ev in row['source_evidence']:
   if isinstance(ev,dict) and ev.get('peer')==old and ev.get('peer_sha256')==sha:ev['peer']=before;ev['successor_receipt']=old;ev['successor_sha256']=successor;changes.append(row['id'])
 for r in c['files']:
  if r.get('peer_receipt')==old:r['peer_receipt_original']=before;r['peer_receipt_successor_sha256']=successor
p=B/'audit-guidance-precision-primary-rebind.json';p.write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_only':True,'rebound_original_evidence_rows':changes,'correction_receipt':'lsp-audit-guidance-scope-precision-corrections.json','correction_sha256':hashlib.sha256((B/'lsp-audit-guidance-scope-precision-corrections.json').read_bytes()).hexdigest(),'reason':'Three individual omission-only claims already pending_audit on primary admission09. Preserve actual predecessor bytes for original peer evidence and exact source/read chronology; successors admit same scope corrections. No source or acceptance donation.'},indent=2)+'\n');g['save'](c,s);print(p,hashlib.sha256(p.read_bytes()).hexdigest(),len(changes))
