from pathlib import Path
import json,hashlib,tarfile,io,datetime
root=Path('/workspace/name-session');dest=Path('/workspace/tcl-lsp/docs/work/name-handling/handoff')
paths=set()
for p in root.iterdir():
 if 'm12' in p.name.lower():
  if p.is_file():paths.add(p)
  elif p.is_dir() and p.name.startswith(('replay-m12-','batch-m12-')):paths.update(x for x in p.rglob('*') if x.is_file())
paths.add(root/'replay-frozen-a.py')
assert (root/'m12-guarded-replay-seal.json') in paths
seal=json.loads((root/'m12-guarded-replay-seal.json').read_text());assert seal['latest_per_selector_counts']=={'PASS':1133,'FAIL':410,'TIMEOUT':1,'NOT_ACCEPTED_RUN_COUNT':2}
manifest=[];name='ordinary-m12-complete-1546-and-permission-repairs.tar.gz'
with tarfile.open(dest/name,'w:gz') as a:
 for p in sorted(paths):
  b=p.read_bytes();n=str(p.relative_to(root));h=hashlib.sha256(b).hexdigest();manifest.append({'path':n,'sha256':h,'size':len(b)})
  info=tarfile.TarInfo(n);info.size=len(b);a.addfile(info,io.BytesIO(b))
 b=json.dumps({'captured_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Actual frozen c9e M12 complete replay and separate seven exact permission repairs; no Native plan or full gate acceptance','members':manifest},indent=2).encode();info=tarfile.TarInfo('CAPTURE-MEMBERS.json');info.size=len(b);a.addfile(info,io.BytesIO(b))
with tarfile.open(dest/name) as a:
 for m in manifest:assert hashlib.sha256(a.extractfile(m['path']).read()).hexdigest()==m['sha256']
packet={'file':name,'sha256':hashlib.sha256((dest/name).read_bytes()).hexdigest(),'status':'Complete frozen c9e M12 ordinary23ELF build and1546 exact selected attempts: strict1126PASS410FAIL7ABORT1TIMEOUT2NOT_ACCEPTED_RUN_COUNT. Seven independent unchanged-selector/assertion/budget/source/artifact/runner permission repairs allPASS; combined1133PASS410FAIL1TIMEOUT2NOT_ACCEPTED_RUN_COUNT. All1491 predecessor controls retained,4gains0priorPASSregressions0drops;55new53PASS2FAIL. Original2286FIRSTPASS71.841791191s/original180. Initial EPERM aborts and Host nested-harness guard rejections retained. Source/artifact/selector guards verified. Native Runtime174/VM133 current replay, formatter/integration and required gates remain separate/unexecuted.'}
p=dest/'packets.json';j=json.loads(p.read_text());assert not any(x['file']==name for x in j);j.append(packet);p.write_text(json.dumps(j,indent=2)+'\n')
p=dest/'SHA256SUMS';p.write_text(p.read_text()+packet['sha256']+'  '+name+'\n')
print(json.dumps({**packet,'verified_members':len(manifest),'bytes':(dest/name).stat().st_size}))
