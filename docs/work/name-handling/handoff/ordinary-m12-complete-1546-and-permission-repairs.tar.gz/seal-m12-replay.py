from pathlib import Path
import collections, datetime, hashlib, json

base = Path('/workspace/name-session')
plans = json.loads((base / 'm12-replay-plans.json').read_text())

def read_result(path):
    result = json.loads(path.read_text())
    comparison = json.loads((path.parent / 'expected-source-comparison.json').read_text())
    assert comparison['expected_paths'] > 0 and not comparison['mismatches'], str(path)
    assert not result['changed_sources'] and result['binary_unchanged'], str(path)
    assert not result.get('missing_exact') and not result.get('empty_filters'), str(path)
    assert len(result['runs']) == len(result['selected_tests']), str(path)
    assert len({r['test'] for r in result['runs']}) == len(result['runs']), str(path)
    return result

def status(run):
    if run['timed_out']:
        return 'TIMEOUT'
    if run['exit_code'] < 0:
        return 'ABORT'
    if run['running_counts'] != ['1'] or len(run['summaries']) != 1:
        return 'NOT_ACCEPTED_RUN_COUNT'
    if run['exit_code'] == 0 and run['summaries'] == [['ok', '1', '0']]:
        return 'PASS'
    if run['exit_code'] != 0 and run['summaries'] == [['FAILED', '0', '1']]:
        return 'FAIL'
    return 'NOT_ACCEPTED_SUMMARY'

def collect(batch, labels):
    rows = {}
    results = {}
    for label in labels:
        path = base / f'replay-{batch}-{label}' / 'result.json'
        result = read_result(path)
        results[label] = result
        for run in result['runs']:
            key = (label, run['test'])
            assert key not in rows
            rows[key] = {'status': status(run), 'log': str(path.parent / run['log']),
                         'seconds': run['seconds'], 'binary_sha256': result['binary']['sha256']}
    first = read_result(base / f'replay-{batch}-first' / 'result.json')
    assert len(first['runs']) == 1 and status(first['runs'][0]) == 'PASS'
    run = first['runs'][0]
    assert run['test'] == 'analyser::diagnostics::tests::tcltest_oracle_program_keeps_missing_reads_and_setup_completion'
    first_start = json.loads((base / f'replay-{batch}-first' / 'start.json').read_text())
    assert first_start['plan']['test_timeouts'][run['test']] == 180
    key = ('compiler', run['test'])
    assert key not in rows
    rows[key] = {'status': status(run), 'log': str(base / f'replay-{batch}-first' / run['log']),
                 'seconds': run['seconds'], 'binary_sha256': first['binary']['sha256']}
    return rows, results

def repair(rows, batch, labels, expected):
    out = dict(rows)
    receipts = []
    for label in labels:
        path = base / f'replay-{batch}-{label}-permission-repair' / 'result.json'
        result = read_result(path)
        for run in result['runs']:
            key = (label, run['test'])
            assert rows[key]['status'] == 'ABORT' and status(run) == 'PASS'
            assert rows[key]['binary_sha256'] == result['binary']['sha256']
            out[key] = {**rows[key], 'status': 'PASS',
                        'permission_repair_log': str(path.parent / run['log'])}
            receipts.append({'scope': label, 'test': run['test'], 'result': str(path)})
    assert len(receipts) == expected
    return out, receipts

initial, results = collect('m12', plans)
assert len(initial) == 1546
latest, repairs = repair(initial, 'm12', ['sandbox', 'pkg'], 7)
prior, _ = collect('l15', plans)
assert len(prior) == 1491
prior, _ = repair(prior, 'l15', ['sandbox', 'pkg'], 6)
dropped = [list(k) for k in prior if k not in latest]
assert not dropped
gains = [{'scope': k[0], 'test': k[1]} for k in prior
         if prior[k]['status'] != 'PASS' and latest[k]['status'] == 'PASS']
regressions = [{'scope': k[0], 'test': k[1], 'status': latest[k]['status']} for k in prior
               if prior[k]['status'] == 'PASS' and latest[k]['status'] != 'PASS']
build = json.loads((base / 'batch-m12-build-ordinary/result.json').read_text())
assert build['exit_code'] == 0 and len(build['test_artifacts']) == 23 and not build['changed_sources']
for label, row in plans.items():
    assert hashlib.sha256(Path(row['artifact']['path']).read_bytes()).hexdigest() == row['artifact']['sha256']
    assert results[label]['binary']['sha256'] == row['artifact']['sha256']
seal = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'frozen_source': build['started']['commit'], 'selected_controls': len(latest),
        'initial_counts': dict(collections.Counter(r['status'] for r in initial.values())),
        'latest_per_selector_counts': dict(collections.Counter(r['status'] for r in latest.values())),
        'predecessor_controls': len(prior), 'dropped_predecessors': dropped,
        'predecessor_gains': gains, 'prior_PASS_regressions': regressions,
        'new_controls': [{'scope': k[0], 'test': k[1], **v} for k, v in latest.items() if k not in prior],
        'permission_repair_receipts': repairs,
        'source_drift': {}, 'artifact_drift': {},
        'limits': 'Original aborted runs retained; seven exact signal-handler EPERM controls rerun outside sandbox with unchanged artifacts/selectors/assertions/budgets/strict guards. Two original Host nested-child run-count rejections remain unaccepted. No Native future-plan, complete consumer migration, proof/generated/repository-gate or issue closure inferred.'}
(base / 'm12-guarded-replay-seal.json').write_text(json.dumps(seal, indent=2) + '\n')
print(json.dumps({k: seal[k] for k in ['selected_controls', 'initial_counts',
    'latest_per_selector_counts', 'predecessor_gains', 'prior_PASS_regressions']}, indent=2))
