from pathlib import Path
import datetime, gzip, hashlib, json, os, subprocess, time

root = Path('/workspace/name-validation')
out = Path('/workspace/name-session/batch-i-build-ordinary')
assert Path(os.environ['CARGO_TARGET_DIR']).resolve() == (root / 'target').resolve(), 'wrong worktree target'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip() == '1a78dde360b80cb82ce16f5a9fcce08329b62561', 'wrong frozen source'
out.mkdir(exist_ok=False)
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()
def inventory():
    names = subprocess.check_output(['git', 'ls-files', '-z'], cwd=root).decode().split('\0')
    return {n: sha(root / n) for n in names if n and (root / n).is_file()}
def save(name, value):
    with gzip.open(out / name, 'wt') as f:
        json.dump(value, f, sort_keys=True)
before = inventory()
save('source-before.json.gz', before)
packages = ['tcl-spectcl', 'tcl-spec-studio', 'tcl-compiler', 'tcl-lsp-server',
            'tcl-lsp-core', 'tcl-lsp-db', 'xtask', 'tcl-syntax', 'bpf-tcl-ir',
            'tcl-vm', 'tcl-irules', 'tcl-registry', 'tcl-lexer', 'tcl-mcp']
command = ['cargo', 'test', '--no-run', '--message-format=json', '-j1']
for package in packages:
    command.extend(['-p', package])
command.extend(['--lib', '--bin', 'xtask', '--bin', 'tcl-mcp'])
start = {'utc': now(), 'argv': command, 'root': str(root),
         'commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
         'target': os.environ['CARGO_TARGET_DIR'], 'executed_tests': 0,
         'rustc': subprocess.check_output(['rustc', '-Vv'], text=True),
         'scope': 'Fresh isolated ordinary batch I library artifacts; no temporary instrumentation; source/provider/exact-run acceptance separate.'}
(out / 'start.json').write_text(json.dumps(start, indent=2) + '\n')
t = time.monotonic()
with (out / 'build.jsonl').open('wb') as stdout, (out / 'build.stderr').open('wb') as stderr:
    code = subprocess.run(command, cwd=root, stdout=stdout, stderr=stderr).returncode
after = inventory()
save('source-after.json.gz', after)
errors, artifacts = [], []
for line in (out / 'build.jsonl').read_text().splitlines():
    try:
        row = json.loads(line)
    except ValueError:
        continue
    if row.get('reason') == 'compiler-message' and row['message']['level'] == 'error':
        errors.append(row['message'])
    if row.get('reason') == 'compiler-artifact' and row.get('profile', {}).get('test') and row.get('executable'):
        artifacts.append({'path': row['executable'], 'sha256': sha(Path(row['executable']))})
result = {'started': start, 'finished_utc': now(), 'exit_code': code,
          'seconds': time.monotonic() - t, 'executed_tests': 0,
          'changed_sources': {n: {'before': before.get(n), 'after': after.get(n)}
                              for n in before.keys() | after.keys() if before.get(n) != after.get(n)},
          'errors': errors, 'test_artifacts': artifacts}
(out / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'exit_code': code, 'errors': [x['message'] for x in errors],
                  'artifacts': len(artifacts), 'changed_sources': len(result['changed_sources'])}))
