import runpy,json,hashlib,datetime
from pathlib import Path
B=Path('/workspace/name-session/full-consumer-audit');x=runpy.run_path(str(B/'audit-review-tools.py'));u=runpy.run_path(str(B/'audit-review-surfaces.py'));c,s=x['load']();by={r['path']:r for r in c['files']};decisions=[]
lsp=json.loads((B/'lsp-audit-tooling-source-receipt.json').read_text());root=json.loads((B/'root-kcs-index-links-peer.json').read_text());peers=[('lsp-audit-tooling-source-receipt.json',lsp),('root-kcs-index-links-peer.json',root)]
for fname,d in peers:
 fs=d.get('whole_source_files',[{'path':d.get('path'),'blob':d.get('git_blob'),'source_sha256':d.get('source_sha256'),'whole_lines':983,'aid':d.get('aid_path'),'aid_sha256':d.get('aid_sha256')}]);rows=d.get('purpose_rows',d.get('purpose_proposals'))
 for f in fs:
  r=by[f['path']];data=x['content'](r);assert r['blob']==f['blob'] and hashlib.sha256(data).hexdigest()==f['source_sha256']==r['source_sha256'];assert len(data.splitlines())==f['whole_lines'];assert hashlib.sha256(Path(f['aid']).read_bytes()).hexdigest()==f['aid_sha256'];entries=[];own=[]
  for z in rows:
   if z['path']!=f['path']:continue
   assert data.decode().splitlines()[z['line']-1].strip()==z['source_line'].strip(),(z['symbol'],z['line'])
   state=z['disposition'];reason=z.get('reason',z.get('evidence',''));missing=z.get('missing_integration',z.get('owner_extension','')) or '';context=z.get('context',reason);api=z.get('shared_api',z.get('actual_shared_api',''))
   if state=='no_additional_change':state='out_of_scope' if z['symbol'] in ['EXPECTED_DIAGNOSTIC_STAGES/DIAGNOSTIC_KCS_TAGS','inline tests'] else 'shared_owner'
   if fname.startswith('root') and z['line']==787:
    reason+=' Independent bounded challenge: lossy prefix predicate842 itself preserves actual Path and cannot alias ASCII kcs-; it is NOT an additional defect. SKIP_NAMES ASCII comparison is also safe. Genuine identity consumers remain rel_to595/603 and file_name636/649/parent link608.'
    missing+=' Do not migrate unchanged list_kcs_notes fixedASCII prefix classifier solely for lossy predicate; its output preserves original Path.'
   controls=z.get('test_obligations',[]);entries.append((z['symbol'],z['line'],z['purpose'],state,context,api,missing,controls));own.append((z,reason,state));decisions.append({'peer':fname,'proposal_id':z.get('id',z['symbol']),'path':f['path'],'state':state,'reason':reason})
  extent=f"Independent actual whole-source loan{f['whole_lines']}lines (all production, inline tests/helpers/templates). Exact original blob/source/numbered-aid SHA verified; full read by {d.get('reviewer','Root')}, bounded primary kernel/purpose challenge, not a duplicate full reread. No foreign dependencies or execution admitted. Peer {fname}."
  u['surface'](c,s,f['path'],'independent_whole_tooling_source_and_operational_test_peer',extent,entries,mode='whole_independent_production_and_operational_peer_read')
  for z,reason,state in own:
   row=next(q for q in s['consumers'] if q['path']==f['path'] and q['symbol']==z['symbol'] and q['purpose']==z['purpose']);row['source_evidence'].append({'peer':fname,'peer_sha256':hashlib.sha256((B/fname).read_bytes()).hexdigest(),'actual_source_line':z['source_line'],'reason':reason,'sub_sites':z.get('sub_sites',[]),'code_change_sites':z.get('code_change_sites',[])});row['peer_original_work_kind']=z.get('work_kind');row['repair_family']=z.get('repair_family');row['validation_result']='Source-only actual full peer plus bounded independent primary semantic/source challenge; no tests/gates/provider/build/generator execution.'
  r['peer_receipt']=fname
x['save'](c,s)
res=json.loads((B/'audit-tooling-active-reservations.json').read_text())
for q in res['reservations']:
 if q['path'] in [f['path'] for f in lsp['whole_source_files']]+[root['path']]:q['read_status']='whole_actual_peer_admitted_source_only';q['reservation_status']='released'
(B/'audit-tooling-active-reservations.json').write_text(json.dumps(res,indent=2)+'\n')
o=B/'audit-tooling-loan-04-admission.json';o.write_text(json.dumps({'baseline':c['baseline'],'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Four exact whole-source peer admissions, primary bounded kernel/purpose/source challenge only; no execution/whole dependency or migration acceptance. No pending→implemented status conversion.','independent_corrections':['Registry axes blank expiry claim withdrawn: whole-input trim prevents that acceptance; only empty reason with nonempty change remains actual gap. Corrected peer SHA retained.','KCS lossy fixed ASCII kcs- prefix predicate is safe classification preserving original Path, not additional identity repair; actual rendered membership keys remain.'],'decisions':decisions,'purpose_rows_after':len(s['consumers'])},indent=2)+'\n');print(o,hashlib.sha256(o.read_bytes()).hexdigest(),len(s['consumers']))
