"""Reconcile purpose-reviewed source records. No source/test/provider execution."""
import json,re,hashlib,collections
from pathlib import Path
R=Path('/workspace/name-session/full-consumer-audit')
d=json.load(open(R/'lsp-consumers.json')); rows=d['consumers']; byid={x['id']:x for x in rows}
follow=json.load(open(R/'lsp-operational-followup-sites.json'))['sites']
base=d['baseline']
merges=[
 ('lsp-editor-explorer-webview-result-owner',['lsp-editor-explorer-webview-result-owner','lsp-explorer-html-result-currency'],'Same actual result listener at compilerExplorerHtml.ts1213 assigns latest lastSource/lastDialect to an asynchronous unowned result. The two records describe one source/result-currentness integration, not two code changes.'),
 ('lsp-definition-member-unavailable-vs-nonmember',['lsp-definition-member-unavailable-vs-nonmember','lsp-format-engine-member-nonmember-unavailable'],'Same authenticated nonmember versus unavailable/unsupported selected-member-body disposition repair. Existing source_structure adapter and formatter consumer must preserve that one shared owner result; all exact changed adapters are listed, not counted as two independent semantic owners.'),
 ('lsp-tk-source-path-parent',['lsp-tk-source-path-parent','lsp-tk-preview-orphan-parent-projection'],'One shared source-widget pathname parent/depth projection repair, transported through Core model into editor. Two local algorithms require changes but neither is a distinct runtime widget identity resolver.')]
merge_for={i:(k,ids,why)for k,ids,why in merges for i in ids}
# These families have actual cross-owner/source evidence; all other independent
# purposes retain their own family id until genuine reuse is demonstrated.
families={
'lsp-source-run-order-purpose':'source.conditional-run-order',
'lsp-workspace-conditional-source-order':'source.conditional-run-order',
'lsp-workspace-package-key-and-order-advice':'source.conditional-run-order',
'lsp-workspace-source-phase-body-column':'source.phase-body-correspondence',
'lsp-workspace-source-namespace-seed':'source.load-namespace-recipe',
'lsp-server-analysis-source-namespace-ingress':'source.load-namespace-recipe',
'lsp-server-source-seed-rehoming':'source.load-namespace-recipe',
'lsp-definition-member-unavailable-vs-nonmember':'source.definition-member-disposition',
'lsp-tk-source-path-parent':'source.widget-path-parent',
'lsp-member-reference-hazard-inventory':'source.complete-reference-region-inventory',
'lsp-potential-source-region-walker':'source.complete-reference-region-inventory',
'lsp-rename-hazard-incomplete-document-census':'source.complete-reference-region-inventory',
'lsp-references-dispatch-region-positive-vs-census':'source.complete-reference-region-inventory',
'lsp-refactor-selected-case-descriptor-transport':'registry.selected-case-body-descriptor',
'lsp-loader-notice-original-subject':'spectcl.original-notice-subject',
'lsp-code-actions-spectcl-notice-selection':'spectcl.original-notice-subject',
'lsp-server-write-rule-back-currency':'host.original-rule-source-action',
'lsp-browser-rule-scratch-source-and-byte-currency':'host.original-rule-source-action',
'lsp-node-rule-scratch-source-byte-and-lifetime':'host.original-rule-source-action',
'lsp-server-xc-diagnostic-input':'translation.document-input-transport',
'lsp-editor-xc-document-context':'translation.document-input-transport',
'lsp-browser-xc-document-input-transport':'translation.document-input-transport',
'lsp-node-xc-document-full-input-transport':'translation.document-input-transport',
'lsp-jb-xc-diagram-document-input-loss':'translation.document-input-transport',
'lsp-semantic-embedded-bigip-body-owner':'bigip.original-embedded-rule-body',
'lsp-apl-original-tcl-region-semantic-caller':'apl.original-embedded-tcl-body',
'lsp-semantic-lexical-math-catalogue':'expr.configured-source-math-catalogue',
'lsp-definition-logical-oo-next-source-provider':'oo.typed-nameless-member-role',
'lsp-references-itcl-qualified-selector-geometry':'source.original-command-component-geometry',
}
validation_family={
'lsp-native-test-root-uri-construction':'validation.native-path-uri',
'lsp-native-encoding-test-path-uri':'validation.native-path-uri',
'lsp-root-operational-wave1-02':'validation.native-path-uri',
'lsp-root-operational-wave1-06':'validation.native-path-uri',
'lsp-native-path-uri-test-provider':'validation.native-path-uri',
'lsp-test-native-path-uri-provider':'validation.native-path-uri',
'native-test-project-path-input':'validation.native-path-unicode-config',
'lsp-native-test-project-path-input':'validation.native-path-unicode-config',
'lsp-validation-native-path-unicode-domain':'validation.native-path-unicode-config',
'lsp-editor-test-diagnostic-source-association':'validation.editor-diagnostic-source-association',
'lsp-package-oracle-provider-provenance':'validation.original-provider-provenance',
}
def family(i):return families.get(i,i)
def actual_site(x):
 p=x['path']; s=(R/'lsp-baseline'/p).read_text(); lines=s.splitlines();n=x['line']
 assert hashlib.sha256(s.encode()).hexdigest()==x['source_sha256'];assert 1<=n<=len(lines)
 return {'path':p,'line':n,'symbol':x['symbol'],'source_sha256':x['source_sha256'],'source_line':lines[n-1],'purpose':x['context']}
def additional_symbols(x):
 s=(R/'lsp-baseline'/x['path']).read_text(); lines=s.splitlines(); names=[]
 # Actual declaration lines only, not guessed body spans or semantic ownership.
 for name in re.findall(r'[A-Za-z_][A-Za-z_0-9]*',x['symbol']):
  if name in {'fn','pub','self','Logical','Native','branch','source','ingress'}:continue
  hits=[(i,l)for i,l in enumerate(lines,1)if re.search(r'\b(?:fn|function)\s+'+re.escape(name)+r'\s*(?:<[^>]*>)?\s*\(',l)]
  if len(hits)==1 and hits[0][0]!=x['line']:
   names.append({'symbol':name,'line':hits[0][0],'source_line':hits[0][1],'scope':'additional actual declaration for the recorded integration purpose; no new count or whole-helper review inferred by extraction'})
 return names
units=[];unresolved=[];validation=[];nochange=[];mapping=[];seen=set();decisions=[]
for x in rows:
 i=x['id'];w=x['work_kind'];disp=x['disposition']
 if i in seen:continue
 key,ids,why=merge_for.get(i,(i,[i],None));rs=[byid[z]for z in ids];seen.update(ids)
 if why:decisions.append({'canonical_unit':key,'original_rows':ids,'decision':why})
 if w in {'shared_owner','display_only','exclusion'}:
  for z in rs:
   nochange.append({'original_row':z['id'],'classification':z['disposition'],'site':actual_site(z),'reason':z['work_kind_reason'],'scope_limits':z['missing_integration'],'evidence':z['evidence']})
   mapping.append({'original_row':z['id'],'disposition':'no_code_change_for_recorded_purpose','target':z['id']})
  continue
 if w=='validation_only' or disp in {'pending_validation','migrated_validation_pending'}:
  validation.append({'id':key,'original_rows':ids,'state':'validation_pending','implementation_state':'already_integrated_bounded_purpose'if disp=='migrated_validation_pending'else'no_new_implementation_claim','sites':[actual_site(z)for z in rs],'existing_tests':[z['tests']for z in rs],'required_validation':[z['missing_integration']for z in rs],'source_evidence':[z['evidence']for z in rs],'not_counted_as_remaining_code_migration':True})
  for z in rs:mapping.append({'original_row':z['id'],'disposition':'bounded_validation_obligation','target':key})
  continue
 if w=='validation_infrastructure':
  continue # Deliberately handled with actual inline/external repair-family census.
 scopes=[actual_site(z)for z in rs]
 obj={'id':key,'family_id':family(key),'original_rows':ids,'integration_purpose':[z['context']for z in rs],'representation_context':[z['context']for z in rs],'code_change_sites':scopes,'additional_actual_symbol_declarations':{z['id']:additional_symbols(z)for z in rs},'shared_api':[z['shared_api']for z in rs],'required_change':[z['missing_integration']for z in rs],'source_evidence':[z['evidence']for z in rs],'control_obligations':[z['tests']for z in rs],'work_kind':w,'implementation_state':'not_complete','review_state':'actual_source_purpose_reviewed','validation_state':'not_accepted_by_this_audit','unchanged_affected_callers':[],'caller_roster_limit':'Only listed sites are counted; other readers/callers of the same owner are not additional units unless an actual separate code change/purpose is established. Shared families link cross-owner consolidation without asserting missing API exists.'}
 if w=='owner_requirement_unresolved' or disp=='pending_audit':
  obj.update(state='unresolved_owner_or_domain_requirement',effort='L',effort_reason='Listed genuine source/context/identity/phase purpose lacks a demonstrated admissible owner projection; owner transport and downstream proof closure must be designed before adapter scope can be fixed.',risk='High: preserve all unknown/absence/currentness/Native/action purpose boundaries stated in required_change. Actual owner reuse versus extension remains explicitly unresolved.',counted_as_resolved_code_migration=False)
  unresolved.append(obj);target='unresolved_owner_or_domain_requirement'
 else:
  effort='S'if w=='documentation_cleanup'else'L'if w=='shared_owner_extension'else'M'
  obj.update(state='needs_migration',effort=effort,effort_reason={'S':'Bounded documentation/template cleanup at the actual listed source; preserve durable contracts/provenance before removal.','M':'Actual existing-owner adoption or descriptor/schema propagation at the listed consumer surfaces; preserve each independent role/context and tests.','L':'Existing shared owner needs the precise missing purpose/receipt/disposition and actual producer plus consumer transport; controls must cover unavailable versus positive cases.'}[effort],risk='Purpose/currentness and representation risk is specific to required_change; no migration may erase unknown phases or borrow execution/cell/edit authority. Relative effort describes scope, not duration or accepted behavior.',counted_as_resolved_code_migration=True)
  units.append(obj);target='canonical_code_migration'
 for z in rs:mapping.append({'original_row':z['id'],'disposition':target,'target':key})
# Actual validation transport repairs, one purpose/family with exact individual
# changed call sites, independently of unchanged semantic test callers.
vg=collections.defaultdict(list)
for x in rows:
 if x['work_kind']=='validation_infrastructure'and x['disposition'] not in {'pending_validation','migrated_validation_pending'}:
  k=validation_family.get(x['id'],x['id']);vg[k].append({'original_row':x['id'],'site':actual_site(x),'disposition':x['disposition'],'required_change':x['missing_integration'],'source_evidence':x['evidence'],'controls':x['tests']})
for n,x in enumerate(follow):
 k=validation_family.get(x['family_link'],x['family_link']);s=(R/'lsp-baseline'/x['path']).read_text();assert hashlib.sha256(s.encode()).hexdigest()==x['source_sha256']
 vg[k].append({'operational_followup_index':n,'site':{'path':x['path'],'lines':x['site_lines'],'source_sha256':x['source_sha256'],'source_lines':[s.splitlines()[i-1]for i in x['site_lines']],'purpose':x['purpose']},'disposition':x['disposition'],'required_change':x['purpose'],'source_evidence':x['evidence']})
vu=[]
for k,rs in vg.items():
 state='needs_migration'if any(x['disposition']=='needs_migration'for x in rs)else'pending_audit'if any(x['disposition']=='pending_audit'for x in rs)else'pending_validation'
 vu.append({'id':k,'family_id':k,'work_kind':'validation_infrastructure'if state!='pending_validation'else'validation_only','state':state,'sites':rs,'effort':'L'if k=='validation.original-provider-provenance'else'M'if len({x['site']['path']for x in rs})>1 else'S','effort_reason':'Existing actual validation owner transport/lifecycle or fail-closed setup/result assertion at these exact changed sites; unchanged fixtures/assertions/budgets/callers remain independent controls. Original interpreter oracle bodies are not migrated into implementation.','risk':'Preserve failed setup versus observed semantics and actual provider/source/version/channel/URI identity; no expected result may be derived from implementation. Pending per-site domain questions remain explicit even if other sites in family require change.','unchanged_affected_callers':'Every reached original test/assertion using these helpers remains a control, not an extra live Tcl consumer unit; exact actual reads in file/inline receipts.','counted_as_live_consumer_migration':False})
 for x in rs:
  if 'original_row'in x:mapping.append({'original_row':x['original_row'],'disposition':'validation_infrastructure_repair'if state=='needs_migration'else state,'target':k})
assert len(mapping)==len(rows);assert len({x['original_row']for x in mapping})==len(rows)
result={'baseline':base,'scope':'All1203 assigned production/external paths and368 exact inline regions source-reviewed; original fixed oracle fixtures/provenance remain independent. This is source audit, not build/test/provider acceptance.','count_contract':'COUNT-UNITS.md','source_records_sha256':hashlib.sha256((R/'lsp-consumers.json').read_bytes()).hexdigest(),'operational_followups_sha256':hashlib.sha256((R/'lsp-operational-followup-sites.json').read_bytes()).hexdigest(),'reconciliation_decisions':decisions,'code_migration_units':units,'unresolved_owner_or_domain_requirements':unresolved,'validation_infrastructure_units':vu,'validation_obligations':validation,'no_change_for_recorded_purpose':nochange,'original_row_mapping':mapping,'counts':{'original_purpose_rows':len(rows),'resolved_code_migration_units':len(units),'resolved_code_by_kind':dict(collections.Counter(x['work_kind']for x in units)),'unresolved_owner_or_domain_requirements':len(unresolved),'validation_infrastructure_families':len(vu),'validation_infrastructure_by_state':dict(collections.Counter(x['state']for x in vu)),'bounded_validation_obligations':len(validation),'no_change_records':len(nochange),'original_rows_mapped':len(mapping)},'limits':['Unresolved owner/domain requirements are remaining work, not guessed ordinary consumer adoptions or accepted new API designs.','Independent purpose records can share one function; they remain separate when distinct role/currentness/representation changes are required. Exact duplicate listener and shared repair records explicitly reconciled above.','Additional declaration discovery only records actual source locations; it does not infer full body purpose/closure from a regex. Original source review receipts remain evidence.','Cross-owner family links require root consolidation; no duplicated owner fix should be counted per unchanged affected caller.','All original programs/assertions/selectors/budgets/refusal guards retained as obligations; no provider or tests executed by this audit.']}
(R/'lsp-migration-units.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n');print(json.dumps(result['counts'],indent=2))
