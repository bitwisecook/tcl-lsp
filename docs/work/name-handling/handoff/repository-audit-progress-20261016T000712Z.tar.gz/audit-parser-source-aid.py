from pathlib import Path
import subprocess,re,json,hashlib
B=Path('/workspace/name-session/full-consumer-audit');d=subprocess.check_output(['git','cat-file','blob','65f8d760df88b3f8505754a47ceb92b8ab191503'],cwd='/workspace/tcl-lsp');s=d.decode();pat=re.compile(r'''/// Scalar parser for `(\w+)` \(generated\)\. Structured fields stay\n/// at their `Default`; faithful for scalar-only kinds\.\n#\[must_use\]\npub fn (\w+)\(\s*full_path: &str,\s*body: &str,\s*range: crate::range::Range,?\s*\) -> (\w+) \{\s*let props = crate::parser::scalar::props_map\(body\);\s*let mut obj = (\w+)::default\(\);\s*let _ = &props;(?P<body>.*?)\n    obj\n\}''',re.S);cursor=s.index('/// Scalar');records=[];unmatched=[]
for m in pat.finditer(s):
 if s[cursor:m.start()].strip():unmatched.append(s[cursor:m.start()])
 cursor=m.end();assert m[1]==m[3]==m[4];body=m['body'];at=0;fields=[]
 for f in re.finditer(r'\s*obj\.(\w+)\s*=\s*([^;]+);',body):
  assert not body[at:f.start()].strip(),(m[2],body[at:f.start()]);at=f.end();fields.append({'field':f[1],'expression':f[2].strip(),'line':s[:m.start('body')+f.start()].count('\n')+1})
 assert not body[at:].strip(),(m[2],body[at:]);records.append({'type':m[1],'function':m[2],'line':s[:m.start()].count('\n')+1,'fields':fields})
if s[cursor:].strip():unmatched.append(s[cursor:])
assert not unmatched,[x[:150] for x in unmatched]
o=B/'audit-parser-complete-shape-records.json';o.write_text(json.dumps({'blob':'65f8d760df88b3f8505754a47ceb92b8ab191503','source_sha256':hashlib.sha256(d).hexdigest(),'original_lines':len(s.splitlines()),'source_header':s[:s.index('/// Scalar')],'template':'Complete exact function signature, shared props_map(body), same actual returnType::default, unused props borrow, only obj.field=complete expression assignments, return same obj. All full source consumed, no unmatched function/code/tail. No generator provenance inference.','records':records,'unmatched_code':unmatched},indent=2)+'\n');a=B/'audit-parser-complete-source-aid.txt';a.write_text('\n'.join(f"{r['line']} {r['function']} ->{r['type']}: "+'; '.join(f"{f['line']} {f['field']}="+' '.join(f['expression'].split()) for f in r['fields']) for r in records)+'\n');print(len(records),sum(len(r['fields']) for r in records),len(s.splitlines()),a.stat().st_size)
