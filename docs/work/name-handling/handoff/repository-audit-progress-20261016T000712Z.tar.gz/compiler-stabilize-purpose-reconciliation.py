import json,hashlib,datetime,os
from pathlib import Path
P=Path('/workspace/name-session/full-consumer-audit');now=datetime.datetime.now(datetime.timezone.utc).isoformat();f=P/'compiler-consumers.json';before=f.read_bytes();d=json.loads(before)
needs=[r for r in d['rows'] if r['disposition']=='needs_migration']
# Individual exact existing source/API/evidence rows were reread in this batch (all131); these ordinal references are converted NOW to stable keys and never retained as a future lookup rule.
assert len(needs)==131
owner={3,4,5,6,7,9,10,13,15,16,17,27,30,39,40,50,53,57,58,91,94,95,96,100,101,102,108,109,116,121,128}
metadata={14,92}
overrides={r['key']:{'work_kind':('shared_owner_extension' if i in owner else 'registry_metadata_repair' if i in metadata else 'consumer_integration'),'reason':'Individually reconciled existing exact-source/API/purpose evidence; shared issuer extension versus selected consumer adapter versus build/provider metadata. No row position is part of this decision.'} for i,r in enumerate(needs)}
aliases=[dict(members=[needs[0]['key'],needs[34]['key']],canonical=needs[34]['key'],reason='Earlier partial and later full review describe the same legacy-text argument-taint read. Later row additionally records the return-read caller; both membership/evidence sets remain retained.'),dict(members=[needs[41]['key'],needs[45]['key']],canonical=needs[45]['key'],reason='signature_scan legacy list-prefix builder and script_arg wrapper are the same concrete Uplevel source reconstruction repair chain, not two independent failures.')]
contract=dict(baseline=d['baseline'],generated_utc=now,source='Individual existing-row actual API/evidence reread, 131 source migration purposes. This is classification only, not whole scope/source or final migration-unit closure.',overrides=overrides,canonical_aliases=aliases)
name='compiler-consumers-before-stable-key-reconciliation.json';(P/name).write_bytes(before)
for r in d['rows']:
 if r['key'] in overrides:r.update(work_kind=overrides[r['key']]['work_kind'],work_kind_reason=overrides[r['key']]['reason'])
 r.pop('canonical_group_reason',None);r['canonical_site_key']=r['key']
for a in aliases:
 for r in d['rows']:
  if r['key'] in a['members']:r.update(canonical_site_key=a['canonical'],canonical_group_reason=a['reason'])
s=P/'compiler-reconcile-census.py';old=s.read_text();start=old.index('# Explicit source-purpose decisions');end=old.index('G={}\n',start)
new='''# Stable exact-key source-purpose decisions. No mutable row index participates.
contract=json.loads((P/'compiler-purpose-stable-key-contract.json').read_text())
for r in d['rows']:
 override=contract['overrides'].get(r['key'])
 if r['disposition']=='needs_migration':
  kind=override['work_kind'] if override else r.get('work_kind','unreconciled')
  reason=override['reason'] if override else r.get('work_kind_reason','New purpose requires individual key-bound classification before final count.')
 elif r['disposition']=='pending_audit':kind='unreconciled';reason='Recorded actual source/caller domain unresolved; no implemented integration or confirmed repair inferred.'
 elif r['disposition']=='pending_validation':kind='validation_only';reason='Specific semantic/provider question requires validation; no implemented migration inferred.'
 elif r['disposition']=='migrated_validation_pending':kind='validation_only';reason='Legacy state still needs individual source disposition; this is not a count of established production integrations.'
 else:kind='intentional/exclusion';reason='Bounded source role is an existing shared owner, presentation or explicit exclusion; not whole-file/global acceptance.'
 r['work_kind']=kind;r['work_kind_reason']=reason;r['canonical_site_key']=r['key'];r.pop('canonical_group_reason',None)
for a in contract['canonical_aliases']:
 for r in d['rows']:
  if r['key'] in a['members']:r['canonical_site_key']=a['canonical'];r['canonical_group_reason']=a['reason']
'''
s.with_name('compiler-reconcile-census-before-stable-keys.py').write_text(old)
receipt=dict(baseline=d['baseline'],utc=now,before_consumer_sha256=hashlib.sha256(before).hexdigest(),beforeimage=name,individual_needs_rows_reread=len(needs),correction='Replace historical index-based work-kind and alias rules with exact stable keys. Source reading coverage, original evidence and dispositions unchanged. Previous intermediate work-kind/alias counts superseded, not final actual repair counts.',limitations='Every legacy validation state still requires individual source disposition. Canonical migration-units not yet complete; no execution/source mutation.')
def write(name,obj):
 f=P/name;t=f.with_name(f.name+'.tmp');t.write_text(json.dumps(obj,indent=2)+'\n');os.replace(t,f)
write('compiler-consumers.json',d);write('compiler-purpose-stable-key-contract.json',contract);write('compiler-stable-key-correction-receipt.json',receipt)
s.write_text(old[:start]+new+old[end:])
print('131 existing need-purpose keys individually classified; two exact aliases stable; no source/disposition changed.')
