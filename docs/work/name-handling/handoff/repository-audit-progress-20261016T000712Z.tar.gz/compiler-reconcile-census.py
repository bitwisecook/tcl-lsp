import json,datetime,collections
from pathlib import Path
P=Path('/workspace/name-session/full-consumer-audit');now=datetime.datetime.now(datetime.timezone.utc).isoformat()
c=json.loads((P/'compiler-file-coverage.json').read_text());d=json.loads((P/'compiler-consumers.json').read_text());m=json.loads((P/'compiler-test-source-manifest.json').read_text());idx={x['path']:x for x in json.loads((P/'compiler-production-index.json').read_text())};tm={x['path']:x for x in m['rows']}
# Actual parent module chains were manually read in the preceding audit turn. No helper body is marked reviewed here.
for a in m['rows']:
 if not a.get('actual_parent_cfg_test_checked'):
  a['actual_parent_cfg_test_checked']=True;a['parent_chain_review_note']='Actual listed cfg(test)/inherited module declaration blocks manually read at exact baseline; assertion bodies classified by retained function SHA/extent, operational helper bodies remain pending unless separately marked.'
# Stable exact-key source-purpose decisions. No mutable row index participates.
contract=json.loads((P/'compiler-purpose-stable-key-contract.json').read_text())
for r in d['rows']:
 override=contract['overrides'].get(r['key'])
 if r['disposition']=='needs_migration':
  kind=override['work_kind'] if override else r.get('work_kind','unreconciled')
  reason=override['reason'] if override else r.get('work_kind_reason','New purpose requires individual key-bound classification before final count.')
 elif r['disposition']=='pending_audit':kind='unreconciled';reason='Recorded actual source/caller domain unresolved; no implemented integration or confirmed repair inferred.'
 elif r['disposition']=='pending_validation':kind='validation_only';reason='Specific semantic/provider question requires validation; no implemented migration inferred.'
 elif r['disposition']=='migrated_validation_pending':kind='validation_only';reason='Legacy state still needs individual source disposition; this is not a count of established production integrations.'
 else:kind='intentional/exclusion';reason='Bounded source role is an existing shared owner, presentation or explicit exclusion; not whole-file/global acceptance.'
 r['work_kind']=kind;r['work_kind_reason']=reason;r['canonical_site_key']=r['key'];r.pop('canonical_group_reason',None)
for a in contract['canonical_aliases']:
 for r in d['rows']:
  if r['key'] in a['members']:r['canonical_site_key']=a['canonical'];r['canonical_group_reason']=a['reason']
G={}
for r in d['rows']:
 g=G.setdefault(r['canonical_site_key'],{'canonical_site_key':r['canonical_site_key'],'members':[],'dispositions':set(),'work_kinds':set()});g['members'].append({'key':r['key'],'path':r['path'],'symbol':r['symbol'],'line':r['line']});g['dispositions'].add(r['disposition']);g['work_kinds'].add(r['work_kind'])
for g in G.values():g['dispositions']=sorted(g['dispositions']);g['work_kinds']=sorted(g['work_kinds'])
d['canonical_grouping']='Only demonstrated alternate labels/repair chains are merged; distinct source-purpose dependencies remain separate. All raw member evidence retained.';d['generated_utc']=now;d['summary']={'raw_purpose_rows':len(d['rows']),'canonical_purpose_sites':len(G),'raw_needs_migration_rows':sum(r['disposition']=='needs_migration' for r in d['rows']),'canonical_sites_needing_migration':sum('needs_migration' in g['dispositions'] for g in G.values()),'canonical_work_kind_membership':dict(collections.Counter(k for g in G.values() for k in g['work_kinds'])),'whole_scope_complete':False}
remaining=[];allgroups=collections.Counter();bytegroups=collections.Counter()
for r in c['rows']:
 path=r['path'];status=r.get('review_status','unexamined');complete=r.get('review_complete',False)
 if status=='manifest_classified_fixture':cat='fixed_data_or_provider_manifest_only'
 elif path in tm and not tm[path].get('production_include_also_present'):
  if r.get('review_status')=='test_operational_inline_pending':cat='cfg_test_child_inline_operational_setup_pending'
  else:cat='cfg_test_child_operational_helpers_reviewed' if complete else 'cfg_test_child_operational_helpers_pending'
 elif '/tests/' in path or '/benches/' in path or '/examples/' in path:cat='operational_harness_reviewed' if complete else 'operational_harness_pending'
 elif complete or r.get('production_review_complete',False):cat='first_party_source_reviewed_inline_tests_pending' if r.get('review_status')=='production_reviewed_inline_tests_pending' else 'first_party_source_reviewed'
 else:cat='first_party_source_partial' if status=='partial_remainder_unexamined' else 'first_party_source_unread'
 r['audit_work_category']=cat;allgroups[cat]+=1;bytegroups[cat]+=r['bytes']
 if not complete and not r.get('production_review_complete',False):
  rr={k:r[k] for k in ['path','git_blob','source_sha256','bytes','review_status','audit_work_category']};rr['work_kind']='unreconciled';rr['reason']=('Generated provider numeric data classified by exact literal-only manifest; actual generator/provider/input parity remains unresolved, no manual tuple-semantic read or provider acceptance inferred.' if cat=='fixed_data_or_provider_manifest_only' else 'Unread or only bounded partial source; no content-derived migration disposition is inferred.')
  if path in idx:rr['production_review_aid_bytes']=idx[path]['production_review_bytes'];rr['embedded_cfg_test_line_ranges']=idx[path]['omitted_cfg_test_line_ranges']
  if path in tm:rr['assertion_body_count']=tm[path]['test_function_count'];rr['helper_source_path']='compiler-test-helpers/'+path;rr['actual_parent_cfg_test_checked']=tm[path].get('actual_parent_cfg_test_checked',False)
  remaining.append(rr)
remaining.sort(key=lambda r:({'first_party_source_partial':0,'first_party_source_unread':1,'operational_harness_pending':2,'cfg_test_child_operational_helpers_pending':3,'cfg_test_child_inline_operational_setup_pending':4}.get(r['audit_work_category'],4),r['path']))
back={'baseline':c['baseline'],'generated_utc':now,'whole_scope_complete':False,'note':'Exact untouched operational/source backlog. Raw fixed data and pure assertion extents are separate from helper/source work. Manifest classification never means source body review or provider provenance acceptance.','categories':{k:{'files':v,'raw_bytes':bytegroups[k]} for k,v in sorted(allgroups.items())},'remaining_files':len(remaining),'inline_test_operational_annex':'compiler-inline-test-operational-backlog.json','remaining':remaining}
c['summary']={'assigned_files':len(c['rows']),'full_or_production_source_reviewed_files':sum(x.get('review_status') in ['source_reviewed','production_reviewed_inline_tests_pending'] for x in c['rows']),'test_source_classified_files':0,'test_child_external_helpers_read_inline_operations_pending':sum(x.get('review_status')=='test_operational_inline_pending' for x in c['rows']),'targeted_files_remainder_unexamined':sum(x.get('review_status')=='partial_remainder_unexamined' for x in c['rows']),'manifest_grouped_fixture_files':sum(x.get('review_status')=='manifest_classified_fixture' for x in c['rows']),'fully_unexamined_files':sum(x.get('review_status')=='unexamined' for x in c['rows'])}
(P/'compiler-file-coverage.json').write_text(json.dumps(c,indent=2)+'\n');(P/'compiler-consumers.json').write_text(json.dumps(d,indent=2)+'\n');(P/'compiler-test-source-manifest.json').write_text(json.dumps(m,indent=2)+'\n');(P/'compiler-canonical-sites.json').write_text(json.dumps({'baseline':c['baseline'],'generated_utc':now,'groups':list(G.values()),'summary':d['summary']},indent=2)+'\n');(P/'compiler-production-census.json').write_text(json.dumps(back,indent=2)+'\n');print(json.dumps({'categories':back['categories'],'remaining':len(remaining),'sites':d['summary']},indent=2))
