import json,pathlib,re,hashlib,os
root=pathlib.Path('/workspace/name-session/full-consumer-audit'); x=json.load(open(root/'runtime-work/db-runtime-harness07-reservation.json'))
configs={14:('IndexedBinaryRow','INDEXED_BINARY_ROWS',list('dialect case stream_sha input omit binary_subject binary_replacement shared resident_subject resident_replacement argument_types result_type resident output'.split())),16:('Row','ROWS','dialect case stream_sha input range producer materialise shared alias_first alias_last code argument_types result_type resident alias_subject output subject_output'.split()),17:('CliRow','CLI_ROWS','dialect case stream_sha256 fields'.split()),19:('Row','ROWS','dialect case command error real index unique count stride input returned effect return_effect code result stream_sha256'.split()),21:('Row','ROWS','dialect case stride code result kind resident stream_sha256'.split()),22:('Row','ROWS','dialect case stream_sha input omit alias_first alias_last alias_replacement code output subject_output argument_types result_type resident alias_subject count'.split())}
rows=[]
for index,(kind,const,fields) in configs.items():
 r=x['files'][index];raw=pathlib.Path(r['local_source']).read_bytes();assert hashlib.sha256(raw).hexdigest()==r['sourceSHA'];s=raw.decode();start=re.search(r'^(?:const|static) '+const+r': &\['+kind+r'\] = &\[',s,re.M);assert start
 bodybegin=start.end();end=re.search(r'^\s*\];',s[bodybegin:],re.M).start()+bodybegin;body=s[bodybegin:end];tokens=[];p=0
 tok=re.compile(r'\s+|//[^\n]*|"(?:[^"\\]|\\[^\n])*"|-?[0-9]+|[A-Za-z_][A-Za-z0-9_]*|[{}\[\](),:]')
 while p<len(body):
  m=tok.match(body,p);assert m,(index,p,body[p:p+50]);t=m.group();p=m.end()
  if t.isspace() or t.startswith('//'):continue
  tokens.append((t,bodybegin+m.start(),bodybegin+m.end()))
 pos=0
 def expect(t):
  global pos
  assert tokens[pos][0]==t,(index,pos,t,tokens[pos]);pos+=1
 def value():
  global pos
  t=tokens[pos][0];pos+=1
  if t.startswith('"') or re.fullmatch(r'-?[0-9]+',t) or t in ('true','false','None'):return
  if t=='Some':expect('(');value();expect(')');return
  if t in ('[','('):
   close=']' if t=='[' else ')'
   if tokens[pos][0]!=close:
    value()
    while tokens[pos][0]==',':
     pos+=1
     if tokens[pos][0]==close:break
     value()
   expect(close);return
  raise AssertionError((index,pos,t))
 spans=[]
 while pos<len(tokens):
  begin=tokens[pos][1];expect(kind);expect('{')
  for j,field in enumerate(fields):
   expect(field);expect(':');value()
   if j+1<len(fields) or tokens[pos][0]==',':expect(',')
  expect('}');finish=tokens[pos-1][2];expect(',');spans.append({'byte_span':[begin,finish],'physical_LF_span':[s.count('\n',0,begin)+1,s.count('\n',0,finish)+1],'sha256':hashlib.sha256(s[begin:finish].encode()).hexdigest()})
 rows.append({'index':index,'path':r['path'],'blob':r['blob'],'source_sha256':r['sourceSHA'],'row_type':kind,'constant':const,'fields_in_exact_order':fields,'literal_body_physical_LF_span':[s.count('\n',0,bodybegin)+1,s.count('\n',0,end)+1],'literal_body_byte_span':[bodybegin,end],'literal_body_sha256':hashlib.sha256(body.encode()).hexdigest(),'records':len(spans),'record_spans':spans,'strict_grammar':'Rows contain only exact declared field labels/order; scalar quoted strings, signed decimal literals, true/false, None, Some(literal), nested literal arrays/tuples; no calls other than Some literal variant, macros, computed names, includes or operators. Whole body tokenized with full consumption.','classification':'fixed_original_observation_rows_strict_source_grammar_not_semantic_validation'})
out={'baseline':x['baseline'],'reviewer':'/root/db','canonical_owner':'/root/runtime','reservation_sha256':hashlib.sha256((root/'runtime-work/db-runtime-harness07-reservation.json').read_bytes()).hexdigest(),'status':'strict_fixed_row_source_classification_only','rows':rows,'limits':['This proves fixed-data syntactic membership/full body closure, not observed-value equality/provider pairing or production migration acceptance.','Declarations and every executable/helper region are separately actually read; no test-body purity assumption.','No imported fixture code was executed.']};p=root/'db-runtime-harness07-fixed-rows.json';tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(out,indent=2)+'\n');os.replace(tmp,p);print(hashlib.sha256(p.read_bytes()).hexdigest());print([(z['index'],z['records'],z['literal_body_physical_LF_span']) for z in rows])
