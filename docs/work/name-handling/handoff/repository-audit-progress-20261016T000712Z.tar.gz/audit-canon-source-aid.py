from pathlib import Path
import subprocess,re,hashlib,json
B=Path('/workspace/name-session/full-consumer-audit');d=subprocess.check_output(['git','cat-file','blob','792ce2ce9c05e6a85bf0a1d55589f3d57764a6a7'],cwd='/workspace/tcl-lsp');s=d.decode();pat=re.compile(r'''impl crate::canonical::Canon for (\w+) \{\s*fn canon_type\(&self\) -> &'static str \{\s*("[^"\n]*")\s*\}\s*fn canon_fields\(&self\) -> serde_json::Value \{\s*let mut o = serde_json::Map::new\(\);(?P<body>.*?)\s*serde_json::Value::Object\(o\)\s*\}\s*\}''',re.S)
records=[];cursor=s.index('impl ');error=[]
for m in pat.finditer(s):
 if s[cursor:m.start()].strip():error.append({'start':cursor,'text':s[cursor:m.start()]})
 cursor=m.end();body=m['body'];i=0;fields=[]
 while i<len(body):
  while i<len(body) and body[i].isspace():i+=1
  if i==len(body):break
  assert body.startswith('o.insert(',i),(m[1],body[i:i+100]);start=i;i+=len('o.insert(');depth=1;quote=False;escape=False
  while depth:
   ch=body[i]
   if quote:
    if escape:escape=False
    elif ch=='\\':escape=True
    elif ch=='"':quote=False
   elif ch=='"':quote=True
   elif ch=='(':depth+=1
   elif ch==')':depth-=1
   i+=1
  assert body[i]==';';i+=1;raw=body[start:i];arg=raw[len('o.insert('):-2];f=re.match(r'\s*("[^"\n]*")\.to_owned\(\),\s*(.*)',arg,re.S);assert f,(m[1],raw);expr=f[2].strip().removesuffix(',').strip();fields.append({'key':f[1],'expression':expr,'line':s[:m.start('body')+start].count('\n')+1})
 records.append({'type':m[1],'canon_type_literal':m[2],'line':s[:m.start()].count('\n')+1,'fields':fields})
if s[cursor:].strip():error.append({'start':cursor,'text':s[cursor:]})
assert not error,error
p=B/'audit-canon-complete-shape-records.json';p.write_text(json.dumps({'blob':'792ce2ce9c05e6a85bf0a1d55589f3d57764a6a7','source_sha256':hashlib.sha256(d).hexdigest(),'original_lines':len(s.splitlines()),'source_header':s[:s.index('impl ')],'template':'Exact full-source match: impl Canon/type; literal canon_type; canon_fields new Map + only o.insert(actual key.to_owned, complete actual expression) statements + Value::Object(o). All arguments preserved, no semantic branch elision. Generator/projection parity unknown.','records':records,'unmatched_source':error},indent=2)+'\n');aid=B/'audit-canon-complete-source-aid.txt';aid.write_text('\n'.join([f"{r['line']} {r['type']} type={r['canon_type_literal']} : "+'; '.join(f"{f['line']} {f['key']} => "+' '.join(f['expression'].split()) for f in r['fields']) for r in records])+'\n');print(len(records),sum(len(r['fields']) for r in records),len(s.splitlines()),aid.stat().st_size,hashlib.sha256(aid.read_bytes()).hexdigest())
