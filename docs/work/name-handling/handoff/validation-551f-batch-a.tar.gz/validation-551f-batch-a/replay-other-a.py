from pathlib import Path
import concurrent.futures
import hashlib
import json
import os
import subprocess

base = Path('/workspace/name-session')
build_dir = base / 'batch-a-build-ordinary'
build = json.loads((build_dir / 'result.json').read_text())
assert build['exit_code'] == 0 and not build['changed_sources'] and not build['errors']
plans = base / 'validation-plans/ordinary'
packages = {'core': 'tcl-lsp-core', 'db': 'tcl-lsp-db', 'syntax': 'tcl-syntax',
            'source': 'xtask', 'studio': 'tcl-spec-studio', 'spectcl': 'tcl-spectcl',
            'registry': 'tcl-registry', 'mcp': 'tcl-mcp', 'server': 'tcl-lsp-server',
            'lexer': 'tcl-lexer', 'irules': 'tcl-irules'}
additions = {
    'core': ['minify::tests::string_alias_inventory_keeps_data_braces_inert_and_real_body_geometry',
             'minify::tests::string_alias_reference_preserves_original_six_provider_suffix_values',
             'minify::tests::string_alias_reference_rejects_escaped_insertion_and_split_unicode'],
    'db': ['tests::project_direct_logical_headers_do_not_restore_deleted_local_slots',
           'tests::project_direct_logical_headers_preserve_source_occupants'],
    'registry': ['value_transfer::reference_body::tests::expression_references_use_the_original_lexer_grammar'],
}
def run(label):
    package = packages[label]
    plan = json.loads((plans / (label + '-plan.json')).read_text())
    for name in additions.get(label, []):
        assert name not in plan['exact']
        plan['exact'].append(name)
    plan_path = base / (label + '-a-plan.json')
    plan_path.write_text(json.dumps(plan, indent=2) + '\n')
    target = package.replace('-', '_')
    artifacts = [a for a in build['test_artifacts'] if Path(a['path']).name.startswith(target + '-')]
    assert len(artifacts) == 1, (label, artifacts)
    artifact = artifacts[0]
    assert hashlib.sha256(Path(artifact['path']).read_bytes()).hexdigest() == artifact['sha256']
    command = ['python3', str(base / 'replay-frozen-a.py'), '--package', package,
               '--plan', str(plan_path), '--out', str(base / ('replay-a-' + label)),
               '--binary', artifact['path'], '--expected-source', str(build_dir / 'source-before.json.gz'),
               '--timeout', '180', '--jobs', '1', '--label',
               'Frozen551f3b2c1 selected ordinary replay; every original272 selector and budget retained plus reviewed additions; Native/full-codebase acceptance separate']
    with (base / (label + '-a-runner.log')).open('wb') as log:
        code = subprocess.run(command, cwd='/workspace/name-validation', stdout=log, stderr=subprocess.STDOUT).returncode
    path = base / ('replay-a-' + label) / 'result.json'
    result = json.loads(path.read_text()) if path.exists() else {}
    runs = result.get('runs', [])
    row = {'label': label, 'runner_exit': code, 'selected': len(result.get('selected_tests', [])),
           'runs': len(runs), 'pass': sum(r['exit_code'] == 0 for r in runs),
           'fail': sum(r['exit_code'] != 0 and not r['timed_out'] for r in runs),
           'timeout': sum(r['timed_out'] for r in runs), 'source_drift': result.get('changed_sources'),
           'binary_unchanged': result.get('binary_unchanged'), 'missing': result.get('missing_exact'),
           'empty_filters': result.get('empty_filters'), 'result': str(path)}
    print(json.dumps(row), flush=True)
    return row
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    results = list(pool.map(run, packages))
(base / 'replay-a-other-summary.json').write_text(json.dumps(results, indent=2) + '\n')
