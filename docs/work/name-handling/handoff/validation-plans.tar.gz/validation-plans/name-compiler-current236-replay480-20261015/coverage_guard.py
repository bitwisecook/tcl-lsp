from pathlib import Path
import argparse,hashlib,json
p=argparse.ArgumentParser();p.add_argument('--source-root',type=Path);p.add_argument('--test-list',type=Path);p.add_argument('--receipt',type=Path);a=p.parse_args();out=Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();m=json.loads((out/'manifest.json').read_text());plans={}
for name,digest in m['plans'].items():
 assert sha((out/name).read_bytes())==digest;plans[name]=json.loads((out/name).read_text());assert len(plans[name]['exact'])==len(set(plans[name]['exact']))==480
for name,row in m['predecessor'].items():assert sha(Path(row['path']).read_bytes())==row['sha256']
old=json.loads(Path(m['predecessor']['plan.json']['path']).read_text());oldrun=json.loads(Path(m['predecessor']['execution-plan.json']['path']).read_text());new={r['selector'] for r in m['additions']};assert len(new)==2;assert plans['plan.json']['exact'][:478]==old['exact'];assert [x for x in plans['execution-plan.json']['exact'] if x not in new]==oldrun['exact'];assert plans['execution-plan.json']['exact'][0]==oldrun['exact'][0]
for plan in plans.values():assert plan['test_timeouts']==old['test_timeouts'];assert not plan['filters']
assert sha((out/'source-audit.json').read_bytes())==m['source_audit_sha256'];audit=json.loads((out/'source-audit.json').read_text());assert {x['selector'] for x in audit}==set(plans['plan.json']['exact'])
snap=m['compiler_source_closure'];assert sha(Path(snap['path']).read_bytes())==snap['sha256'];source=json.loads(Path(snap['path']).read_text());assert len(source)==snap['files'];assert all(source[x['path']]==x['source_sha256'] for x in audit)
if a.source_root:
 actual={str(path.relative_to(a.source_root)):sha(path.read_bytes()) for path in (a.source_root/'rust/tcl-compiler/src').rglob('*.rs')};assert actual==source,sorted(path for path in set(actual)|set(source) if actual.get(path)!=source.get(path))
if a.test_list:
 available={x.removesuffix(': test').strip() for x in a.test_list.read_text().splitlines() if x.endswith(': test')};assert not set(plans['plan.json']['exact'])-available
if a.receipt:
 r=json.loads(a.receipt.read_text());assert r['selected_tests']==plans['execution-plan.json']['exact'];assert not r['missing_exact'];assert not r['changed_sources'];assert r['binary_unchanged'];assert len(r['runs'])==480;assert [x['test'] for x in r['runs']]==r['selected_tests'];assert all(x['running_counts']==['1'] for x in r['runs'])
print(json.dumps({'planned_exact':480,'all478_retained':True,'all_three_original180_budgets_retained':True,'source_checked':bool(a.source_root),'ELF_list_checked':bool(a.test_list),'receipt_checked':bool(a.receipt)}))
