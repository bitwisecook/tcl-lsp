from pathlib import Path
import json,hashlib,gzip,re,collections
root=Path('/workspace/tcl-lsp');out=Path(__file__).parent;pred=Path('/tmp/name-compiler-current221-replay478-20261015');sha=lambda b:hashlib.sha256(b).hexdigest();new=['body_analysis_capsule::readonly_authored_coverage::tests::readonly_authored_coverage_preserves_both_actual_analysis_inventories','body_analysis_capsule::readonly_authored_coverage::tests::readonly_authored_coverage_refuses_missing_foreign_and_mismatched_owners'];plans={}
for name in ['plan.json','execution-plan.json']:
 d=json.loads((pred/name).read_text());old=d['exact'];assert len(old)==478 and not set(new)&set(old);d['exact']=old+new if name=='plan.json' else [old[0],*new,*old[1:]];d['scope']='Complete ordinary Compiler480 over all478: actual226 readonly Authored coverage two source controls added, all prior478 selectors retained. #2286 first180, new two next, complete478 relative order and three original180 budgets unchanged. Source membership/hash bound to actual ordinary236; Root fresh ordinary full closure/ELF/list/exact runs decide acceptance. No TEMP bytes or replay acceptance from planning.';plans[name]=d;(out/name).write_text(json.dumps(d,indent=2)+'\n')
# Bind every actual Compiler source file, plus explicit adopted deltas, without taking any TEMP afterimage.
source={};names=collections.defaultdict(list)
for rel,flag in [('rust/tcl-compiler/src/analyser/scope.rs','macro_rules! original_variable_source_stage'),('rust/tcl-compiler/src/command_binding/declaration_layout.rs','TCL_LSP_TRACE_DECLARATION_SOURCE_ISSUER')]:
 assert flag not in (root/rel).read_text(),(rel,'TEMP overlay active; use Root exact ordinary restore beforeimage instead')
for p in (root/'rust/tcl-compiler/src').rglob('*.rs'):
 rel=str(p.relative_to(root));b=p.read_bytes();source[rel]=sha(b);s=b.decode()
 for f in re.finditer(r'\bfn\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(',s):names[f[1]].append((rel,s.count('\n',0,f.start())+1,s[max(0,f.start()-500):f.start()]))
audit=[]
for selector in plans['plan.json']['exact']:
 rows=names[selector.split('::')[-1]];assert len(rows)==1,(selector,len(rows));rel,line,prefix=rows[0];assert '#[test]' in prefix;audit.append({'selector':selector,'path':rel,'line':line,'source_sha256':source[rel]})
(out/'source-audit.json').write_text(json.dumps(audit,indent=2)+'\n');(out/'compiler-source236.json').write_text(json.dumps(source,indent=2,sort_keys=True)+'\n');updates=[]
for path in ['/tmp/name-profiled-standalone-declaration-body-layout-20261015','/tmp/name-authored-readonly-coverage-projection-20261015']:
 d=json.loads(Path(path,'manifest.json').read_text())
 for r in d['files']:
  assert source[r['path']]==r['after_sha256'];updates.append({'path':r['path'],'before_sha256':r['before_sha256'],'after_sha256':r['after_sha256'],'patch_sha256':d['patch_sha256']})
m={'count':480,'source_epoch':236,'predecessor_count':478,'canonical478_ordered_prefix':True,'execution478_relative_order_preserved':True,'actual258467_retained':True,'all_three_original180_budgets_unchanged':True,'plans':{n:sha((out/n).read_bytes()) for n in plans},'source_audit_sha256':sha((out/'source-audit.json').read_bytes()),'compiler_source_closure':{'path':str(out/'compiler-source236.json'),'sha256':sha((out/'compiler-source236.json').read_bytes()),'files':len(source),'TEMP_overlays_excluded':True},'explicit_actual_adopted_successors':updates,'predecessor':{n:{'path':str(pred/n),'sha256':sha((pred/n).read_bytes())} for n in ['plan.json','execution-plan.json','manifest.json']},'additions':[x for x in audit if x['selector'] in new],'validation':'All480 actual current236 unique fn/test attributes/file hashes verified; complete actual Compiler source closure retained. Earlier full ordinary source snapshots remain immutable; Root fresh whole authored/runtime/experiments/provider closure determines execution acceptance. No Cargo/list/run/provider execution.'};(out/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps({'count':480,'plans':m['plans'],'manifest_sha256':sha((out/'manifest.json').read_bytes())},indent=2))
