from pathlib import Path
import datetime,gzip,hashlib,json,os,re,subprocess,concurrent.futures
root=Path('/workspace/tcl-lsp');out=Path('/workspace/name-captures/temp270-source-firstguards-20261015');out.mkdir(exist_ok=False);scratch=out/'composition';scratch.mkdir()
packets=json.loads(Path('/tmp/name-temp270-packets-20261015.json').read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def snap():
 names=subprocess.check_output(['rg','--files','--hidden',*[n for n in ['rust','runtime','data','scripts','specs','experiments/name-handling','.cargo'] if(root/n).exists()]],cwd=root,text=True).splitlines()+['Cargo.toml','Cargo.lock','rust-toolchain.toml']
 return {n:sha(root/n) for n in sorted(set(names)) if(root/n).is_file()}
def save(n,r):
 with gzip.open(out/n,'wt') as f:json.dump(r,f,sort_keys=True)
paths=set();specs=[]
for name,h in packets:
 p=Path('/tmp')/name/'diagnostic.patch';assert sha(p)==h;names=set(re.findall(r'^\+\+\+ b/(.+)$',p.read_text(),re.M));assert names
 for n in names:
  q=scratch/n
  if not q.exists():q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes((root/n).read_bytes())
 subprocess.run(['git','apply','--check',str(p)],cwd=scratch,check=True);subprocess.run(['git','apply',str(p)],cwd=scratch,check=True);paths|=names;specs.append({'patch':str(p),'sha256':h,'paths':sorted(names)})
assert len(paths)==3
before=snap();save('ordinary-before.json.gz',before)
for n in paths:q=out/'restore'/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes((root/n).read_bytes());assert sha(q)==before[n]
(out/'restoration-plan.json').write_text(json.dumps({'utc':now(),'source_epoch':238,'packets':specs,'files':[{'path':n,'before':before[n],'temporary_after':sha(scratch/n)} for n in sorted(paths)],'source_count':len(before),'scope':'Primitive first-refusal diagnostics only. All3 complete files backed up; actual238 production preimages compose reviewed log-only hunks. No ordinary/Native conformance.'},indent=2)+'\n')
code=None;build=None
try:
 for n in paths:(root/n).write_bytes((scratch/n).read_bytes())
 temp=snap();save('temp-before.json.gz',temp);env=dict(os.environ);env.update({n:'1' for n in ['TCL_LSP_TRACE_DECLARATION_SOURCE_ISSUER','TCL_LSP_TRACE_VARIABLE_SOURCE_STAGES','TCL_LSP_TRACE_PROJECT_SOURCE_APPLICABILITY']})
 cmd=['cargo','test','--offline','--no-run','--message-format=json','-j2','-p','tcl-compiler','-p','tcl-lsp-db','--lib']
 with (out/'build.jsonl').open('wb') as f:build=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
 artifacts={};errors=[]
 for l in (out/'build.jsonl').read_text().splitlines():
  try:r=json.loads(l)
  except ValueError:continue
  if r.get('reason')=='compiler-message' and r['message']['level']=='error':errors.append(r['message'])
  if r.get('reason')=='compiler-artifact' and r.get('profile',{}).get('test') and r.get('executable'):artifacts[r['target']['name']]={'path':r['executable'],'sha256':sha(Path(r['executable']))}
 (out/'build-result.json').write_text(json.dumps({'exit_code':build,'errors':errors,'artifacts':artifacts,'scope':'Temporary diagnostic build only; zero test outcomes from build.'},indent=2)+'\n');print('TEMP270build',build,'errors',len(errors),flush=True)
 if build==0:
  plans=json.loads(Path('/tmp/name-temp270-plans-20261015.json').read_text())
  def run(item):
   label,(package,target,tests)=item;plan=out/(label+'-plan.json');plan.write_text(json.dumps({'exact':tests,'temporary_diagnostics':True,'scope':'TEMP270 original first-refusal primitive diagnostics, not ordinary acceptance.'},indent=2)+'\n');a=artifacts[target];assert sha(Path(a['path']))==a['sha256'];cmd=['python3','/workspace/name-failclosed-replay253-20261015.py','--package',package,'--plan',str(plan),'--binary',a['path'],'--expected-source',str(out/'temp-before.json.gz'),'--out',str(out/label),'--timeout','180','--jobs','1','--label','TEMP270 exact primitive guards on actual source238 plus3 explicitly temporary fullfiles; no ordinary/Native conformance']
   with (out/(label+'-runner.log')).open('wb') as f:r=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
   return {'label':label,'runner_exit_code':r}
  with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(run,plans.items()))
  (out/'diagnostic-completion.json').write_text(json.dumps(results,indent=2)+'\n');code=0 if all(x['runner_exit_code']==0 for x in results) else 1
finally:
 for n in paths:(root/n).write_bytes((out/'restore'/n).read_bytes())
 after=snap();save('ordinary-after.json.gz',after);changed={n:{'before':before.get(n),'after':after.get(n)} for n in before.keys()|after.keys() if before.get(n)!=after.get(n)};r={'finished_utc':now(),'build_exit_code':build,'diagnostic_runner_exit_code':code,'restored_paths':sorted(paths),'changed_authored_inputs':changed,'source_count':len(before),'scope':'Full source restoration receipt only, no ordinary/Native acceptance.'};(out/'restoration-result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
 if changed:raise RuntimeError('Full restoration mismatch; no ordinary build permitted')
