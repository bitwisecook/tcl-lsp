from pathlib import Path
import json,hashlib,gzip,os,collections,csv,io
R=Path(__file__).parent;P=Path('/workspace/tcl-lsp');H=lambda b:hashlib.sha256(b).hexdigest();L=lambda n:json.loads((R/n).read_bytes())
def write(n,o):
 p=R/n;t=p.with_suffix('.tmp');b=(json.dumps(o,separators=(',',':'),ensure_ascii=True)+'\n').encode();t.write_bytes(b);os.replace(t,p);return {'path':n,'sha256':H(b),'bytes':len(b)}
def compressed(n,b):
 z=gzip.compress(b,compresslevel=6,mtime=0);assert gzip.decompress(z)==b;p=R/n;t=p.with_suffix('.tmp');t.write_bytes(z);os.replace(t,p);return {'path':n,'sha256':H(z),'bytes':len(z),'expanded_sha256':H(b),'expanded_bytes':len(b)}
res=L('audit-lsp-final-role-cohort-reservation.json');j=L('lsp-audit-final-role-cohort-progress.json');si=L('lsp-audit-final-role-cohort-schema-index.json');by={x['path']:x for x in res['files']};assert len(by)==2326
assert len(j['records'])==2326 and not j['unmatched'];assert {x['path'] for x in j['records']}==set(by)
for sid,node in si['schemas'].items():
 assert H(json.dumps(node['schema_node'],separators=(',',':')).encode())==sid
 n=node['schema_node']
 if isinstance(n,list):
  children=[q[1] for q in n[1]] if n[0]=='object' else n[1]
  assert all(c in si['schemas'] for c in children)
for i,x in enumerate(j['records']):
 assert x['source_sha256']==by[x['path']]['source_sha256'];assert x['complete_schema_fingerprint'] in si['schemas'];assert H(Path(x['actual_source']).read_bytes())==x['source_sha256']
 x['reservation_inventory_state']={'review_status':x.pop('review_status'),'review_mode':x.pop('review_mode'),'reservation':x.pop('reservation')};x['review_status']='examined_original_source_or_inert_data_role';x['review_mode']=x['read_mode'];x['detail_record_index']=i
 if 'inert_authored_data_map_semantic_domain_unverified' in x['role_families']:
  x['limitations']=['Precise semantic meaning/origin/current admission purpose remains unknown; complete examined DATA-role status does not assert that domain or an originating/current runner.']
# Distinct maintained manifest readers, actual schema/field contracts only, no runtime invocation.
tab=[]
for n in ['scripts/dev/rust-test-binary-shards.tsv','scripts/dev/smoke-targets.tsv','samples/wasm/budgets.tsv']:
 t=(P/n).read_text();rows=[q.split('\t') for q in t.split('\n') if q and not q.startswith('#')]
 if n.endswith('rust-test-binary-shards.tsv'):
  directives=[q for q in rows if q[0].startswith('@')];data=[q for q in rows if not q[0].startswith('@')];assert directives[0][0]=='@partitions' and all(len(q)==2 for q in directives);assert all(len(q)==5 and q[0].isdigit() and q[2] in ['lib','bin','test'] for q in data);contract='Verifier _manifest170–255: explicit directives then SHARD/BINARY_ID/KIND/PACKAGE/TARGET records; target metadata partition proof not run.'
 elif n.endswith('smoke-targets.tsv'):
  assert all(len(q)==4 for q in rows);data=rows;contract='smoke_targets::read_manifest680–714: source/package/kind/target tuple rows; validate_manifest target/source coverage not run.'
 else:
  assert rows[0]==['tier','sample','plan','eval_code','expr_bool','invoke_argv','native_i64_f64'];data=rows[1:];assert all(len(q)==7 and q[2] in ['default','analysis','native'] and all(z.isdecimal() for z in q[3:]) for q in data);contract='wasm_tiers::render_budgets535–570 produces this seven-column golden; framing_budgets_match_the_committed_golden580–618 compares full output. No compile, regeneration, oracle or golden comparison performed.'
 tab.append({'path':n,'sha256':by[n]['source_sha256'],'physical_rows':len(rows),'data_rows':len(data),'contract':contract,'structural_role_errors':0,'semantic_acceptance':False})
# Exact configuration/derived source provenance references; these are bound field-role readers, never target execution.
supplemental=[
 {'path':'scripts/dev/check-name-resolution-proofs.py','actual_read_ranges':[[1,90],[530,715]],'purpose':'proof closed schema/record/source-evidence fields and structural reader'},
 {'path':'scripts/dev/update-name-resolution-proof-index.py','actual_read_ranges':[[1,138]],'purpose':'classification proposals, record/index/render source fields'},
 {'path':'rust/xtask/src/callback_inventory.rs','actual_read_ranges':[[25,175]],'purpose':'InventoryRow/Seed/run input and output roles'},
 {'path':'rust/xtask/src/callback_coverage.rs','actual_read_ranges':[[40,170]],'purpose':'Manifest/Requirement/Imprecision/Baseline/KnownGap field roles'},
 {'path':'scripts/perf/bench.py','actual_read_ranges':[[990,1032]],'purpose':'result dictionary/write source'},
 {'path':'scripts/perf/report.py','actual_read_ranges':[[285,347]],'purpose':'parse_run performance schema reader'},
 {'path':'experiments/mro_eval/gen_labels.py','actual_read_ranges':[[55,90]],'purpose':'CSV observation/label-input role; truth comparison not executed'},
 {'path':'experiments/mro_eval/score_labels.py','actual_read_ranges':[[85,120]],'purpose':'label score reporting role, no correctness acceptance'},
 {'path':'samples/for_f5_query/multitier/generate.py','actual_read_ranges':[[302,317]],'purpose':'fixed JSON sample output'},
 {'path':'scripts/dev/verify-nextest-binary-shards.py','actual_read_ranges':[[1,135],[160,255]],'purpose':'manifest row grammar; metadata/list partition gate not executed'},
 {'path':'rust/xtask/src/smoke_targets.rs','actual_read_ranges':[[665,725]],'purpose':'four-column manifest row reader'},
 {'path':'rust/tcl-compiler/tests/wasm_tiers.rs','actual_read_ranges':[[1,115],[535,620]],'purpose':'golden generation/whole text comparison role only'}]
cover={x['path']:x for x in L('audit-file-coverage.json')['files']};cover.update({x['path']:x for x in L('compiler-file-coverage.json')['rows']})
for x in supplemental:
 b=(P/x['path']).read_bytes();x['source_sha256']=H(b);old=cover[x['path']];assert x['source_sha256']==old['source_sha256'];x['baseline_match']=True;x['prior_whole_owner_review_not_donated']='Existing owner coverage; only the listed bounded source ranges are this loan\u2019s supplemental actual reads.'
# Actual baseline proof schema and manifest are themselves reserved and exact current bytes.
proofpins=[{'path':n,'source_sha256':by[n]['source_sha256'],'blob':by[n]['blob']} for n in ['docs/design/analysis/name-resolution-proofs/schema.json','docs/design/analysis/name-resolution-proofs/manifest.json']]
# Lossless compressed complete detailed records/schema; compact human/index view keeps one row per path.
b=(json.dumps(j,separators=(',',':'))+'\n').encode();details=compressed('lsp-audit-final-role-cohort-details.json.gz',b)
sb=(json.dumps(si,separators=(',',':'))+'\n').encode();schema=compressed('lsp-audit-final-role-cohort-schema-index.json.gz',sb)
summary=[]
for x in j['records']:
 keys=['path','blob','source_sha256','source_bytes','review_status','review_mode','detail_record_index','role_families','complete_schema_fingerprint','all_key_vocabulary_sha256','whole_value_type_counts']
 q={k:x[k] for k in keys};q.update({'all_key_count':len(x['all_key_vocabulary']),'paired_reference_count':len(x['paired_declared_references']),'source_member_count':len(x['source_member_roles']),'non_json_process_line_count':len(x['non_json_process_lines']),'role_schema_error_count':len(x['schema_role_errors']),'semantic_or_runtime_acceptance':False});summary.append(q)
compact={'baseline':j['baseline'],'reservation_sha256':j['reservation_sha256'],'counts':j['counts'],'records':summary,'unmatched':[],'complete_record_details':details,'complete_schema_dag':schema,'schema_child_and_root_integrity_errors':0,'limits':j['limits']}
summaryref=write('lsp-audit-final-role-cohort-progress.json',compact)
schemaref=write('lsp-audit-final-role-cohort-schema-index.json',{'complete_schema_dag':schema,'node_count':len(si['schemas']),'child_and_root_integrity_errors':0,'scope':si['scope']})
# Remove only superseded draft compression owned by this loan; complete final detail+schema remain above.
p=R/'lsp-audit-final-role-cohort-progress.json.gz'
if p.exists():p.unlink()
ref=write('lsp-audit-final-role-cohort-source-receipt.json',{
 'baseline':j['baseline'],'reservation':{'path':'audit-lsp-final-role-cohort-reservation.json','sha256':j['reservation_sha256']},'status':'complete_examined_original_source_and_data_role_partition_pending_primary_admission',
 'counts':j['counts'],'artifacts':[summaryref,schemaref,details,schema],'source_reader_contexts':supplemental,'proof_reader_schema_pins':proofpins,'validation_manifest_structural_roles':tab,
 'whole_actual_source_paths':[x['path'] for x in j['records'] if x['review_mode'] in ['whole_actual_configuration_source_read','whole_actual_operational_yaml_source_read','whole_actual_schema_source_and_configured_reader_review']],
 'whole_actual_sample_data_paths':[x['path'] for x in j['records'] if x['review_mode']=='whole_actual_fixed_sample_data_read'],
 'unknown_domain_maps':{'count':294,'disposition':'examined finite inert DATA role with complete nested key/type/cardinality projection; precise semantic domain/current admission/creator provenance unavailable, not promoted to implementation or accepted observation'},
 'historical_producer_limit':'Actual maintained/retained capture producers have separate whole-source receipts, but this projection does not infer a unique originating producer or current invocation from matching record fields. Historical source/setup/provider limitations remain original evidence questions.',
 'input_role_limit':'Commands, source snippets, expected values, path labels, digests, statuses and answers remain inert exact original data. No opaque source-code-bearing helper was imported/executed or admitted as current code.',
 'baseline_blob_exceptions':[{'path':n,'local_path':str(R/f),'source_sha256':by[n]['source_sha256'],'blob':by[n]['blob'],'authorization':'Root explicitly authorized exact readonly git cat-file for these two blobs; bytes match reservation; no Git mutation'} for n,f in [('docs/work/name-handling/handoff/packets.json','lsp-audit-role-baseline-packets.json'),('docs/work/name-handling/outstanding-consumer-audit.json','lsp-audit-role-baseline-outstanding-consumer-audit.json')]],
 'proofs_limit':'Actual record schema and manifest membership reviewed, zero structural schema errors in this own projection. No checker/update gate execution; no current generated document/body parity (earlier gate matched zero rendered pages); no original C/Jim/F5/runtime answer acceptance.',
 'role_projection':'Every reserved original byte is bound by source SHA/blob. JSON/JSONL/TOML/CSV/TSV complete parse and recursive all-field/value-type schema; nonJSON physical JSONL lines retain byte hash/length as opaque original process output; actual operational YAML/config source read separately. No extension/prefix/marker-only exemption.',
 'required_new_migration_units':0,'new_mandatory_migration_reason':'No new live product/validation defect established by inert data role inspection; existing proof/provider/schema/provenance questions remain explicit and unchanged.',
 'actions_performed':'Artifact-only source reads/parsing/hashing/compression; two exact authorized readonly baseline blob reads. No source edits, audited code/module import, shell recipes, tests, build, gate, provider, Tcl/VM, network/SSH or Git mutation.',
 'manual_read_claim_limit':'This is not a manual semantic reading of 262 MB of claims. Every scalar belongs to its retained typed original data role; complete structural projection is explicit. Whole actual operative source and supplemental callee extents are named separately.'})
print(json.dumps({'receipt':ref,'summary':summaryref,'details':details,'schema':schema,'schema_nodes':len(si['schemas']),'counts':j['counts']},separators=(',',':')))
