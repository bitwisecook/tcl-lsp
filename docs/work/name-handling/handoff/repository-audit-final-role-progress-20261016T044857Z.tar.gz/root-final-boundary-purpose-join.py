from pathlib import Path
import json,hashlib,datetime
D=Path(__file__).parent;inp=D/'root-global-reconciliation-input.json';j=json.loads(inp.read_bytes());gpath=D/'root-global-same-anchor-current-candidates.json';groups=json.loads(gpath.read_bytes());explanations=[
'Constructing replacement target literal data and selecting original assignment extent require separate changed ingress and edit-owner purposes.',
'Original assignment command extent and newly constructed scalar destination word are separate edit/container and target-construction duties.',
'Original variable-read component transport and enclosing quoted-word edit geometry are separate evidence purposes.',
'Dynamic variable SSA taint identity and nested command source coordinates select different actual operand/source owners.',
'Native preload OsStr pathname transport and exclusive temporary fixture ownership/lifetime are independent validation duties at run.',
'Native preload OsStr pathname transport and exclusive temporary fixture ownership/lifetime are independent validation duties at run_capture_host.',
'Pack source path identity in cache keys and full include dependency invalidation are different cache inputs.',
'Initializer prefix selection policy and mapping the selected prefix into exported initializer ABI symbol are different missing declaration facets.',
'Actual selected Jim child member inventory, limit option grammar, debug option grammar and generated interpreter command-name publication have distinct selected protocol purposes.',
'TclOO stock bootstrap installation role and fresh anonymous object/namespace name issuance have distinct owner facets.',
'Package unknown-handler source invocation and native direct-load candidate source constructor are different selected invocations.',
'Chan selected ensemble member inventory, seek origin grammar and puts immediate option grammar are three distinct actual declarations. Runtime seek/puts actual changed adapters stay separate.',
'Filesystem platform attribute-name policy and stat/lstat result-field schema are distinct selected API domains.',
'OO variable pattern input inventory adopts the pattern owner; qualified namespace/component pattern matching repairs the owner once.',
'BPF final instruction mixed-template source origins and original CFG script/procedure frame purpose require independent owner transport.',
'HCL quoted literal construction and complete comment-line construction have independent target grammars; shared comment facet counted once.',
'Issued HCL policy reference label and cross-format load-balancer object-name/label identity concern distinct target objects/roles.',
'Issued JSON policy reference and load-balancer object key across formats concern distinct selected target objects.',
'Encoding actual requested target name in original configuration source and selecting scoped identity-edit role are different constructor and authority duties.',
'Unique source/side alias admission under Query grammar and actual current cross-source mutation state are distinct ingress/state duties.',
'Unknown reference coverage barriers and dependency closure of explicitly retained objects are independent cleanup preconditions.',
'Bounded cleanup result wording and target script comment-source encoding are separate output truth/grammar purposes.',
'Typed endpoint/member destination fields and monitor expression references use different actual values/source roles.',
'Conditional orphan status and attached-rule partition/folder association are independent Python consumer projections.',
'Certificate/profile reference association and private-key object reference selection concern different object identities.',
'Forensic archive inventory availability and bounded negative report language are distinct source-fact and output duties.',
'Persisted authentic fuzz input source transport and failed scratch setup result preservation are different replay input/completion duties.',
'Complete value-transfer input inventory and actual native path used for ratchet/exemption correspondence are separate admission/identity duties.',
'Selected reference value/cardinality and declared nested section reference coverage are distinct validator metadata facets.',
'One shared Applies-to tag parser owner and an actual KCS adopter change are counted separately; no duplicate semantic parser.',
'Keyed pool member original body/name/offset source and symbolic node/service identity transport are distinct parser/reference purposes.',
'Four missing simulator host exposure facets are expression lexical plans, original script/list geometry, selected command/body roles, and original config model. Existing semantic owners are dependencies, not counted again.'
];assert len(groups)==len(explanations)==32
ids={r['id']for r in j['units']}
for g,e in zip(groups,explanations):
 assert all(u['id']in ids for u in g['units']);g.update(disposition='RETAIN_DISTINCT_ACTUAL_PURPOSE_BOUNDARIES',rationale=e,count_delta=0)
joinfiles=['lsp-audit-final-crossowner-map.json','lsp-audit-final-crossowner-owner-pin-refresh.json','runtime-audit-final-crossowner-join-current.json','vm-external-owner-final-sealed-catalogue-join-annex.json','db-audit-final-boundary-join-qa.json','compiler-vm-new-operational-validation17-qa.json','audit-crosshost-source-facet-decisions.json']
refs=[]
for name in joinfiles:
 p=D/name;b=p.read_bytes();json.loads(b);refs.append({'path':name,'sha256':hashlib.sha256(b).hexdigest()})
out={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'COMPLETE_SEMANTIC_BOUNDARY_PURPOSE_RECONCILIATION_PENDING_SOURCE_ROLE_CLOSURE','input_sha256':hashlib.sha256(inp.read_bytes()).hexdigest(),'candidate_source_sha256':hashlib.sha256(gpath.read_bytes()).hexdigest(),'count_contract':j['count_contract'],'same_anchor_groups':groups,'cross_owner_joins':refs,'count_delta':0,'duplicate_required_boundaries_remaining':0,'historical_withdrawals':'Earlier provider aggregate duplicate and mixed Runtime chan479 were explicitly withdrawn before current catalogue assembly; seek and puts own separate actual consumers. Root URI golden adopters are separate from the once Syntax Python exposure owner; host path conversion is a distinct OS target purpose. Compiler old data_transfer dependency withdrawn; actual SCCP body-touch adopter retained. Existing generic prefix/numeric/glob owners and unchanged callers are dependencies, not inferred migrations.','limits':'Explicit semantic dispositions over source-reviewed canonical units and current exact owner/adopter maps; no automatic dedup by filename, family, caller count, rendered name or shared source anchor. Exact source role coverage and catalogue/raw bindings must still be sealed before final total.'};p=D/'root-final-boundary-purpose-join.json';p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'groups':len(groups),'crossowner_receipts':len(refs),'count_delta':0,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}))
