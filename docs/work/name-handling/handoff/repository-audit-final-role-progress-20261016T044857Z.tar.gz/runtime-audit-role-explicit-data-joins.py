from pathlib import Path,PurePosixPath
import runpy,json,hashlib,re,collections
P=Path('/workspace/name-session/full-consumer-audit');H=lambda b:hashlib.sha256(b).hexdigest();x=runpy.run_path(str(P/'runtime-audit-role-cohort-census.py'));wanted=x['wanted'];by=x['by'];raw=x['raw'];admitted={};source_candidates=[]
def visit(v,path,ptr=''):
 if isinstance(v,dict):
  par=PurePosixPath(path).parent
  # Exact literal output-field path, not guessed case/filename transformation.
  if any(k in v for k in ['exit','exit_code','returncode','rc','process_exit_code']):
   for field in ['stdout','stderr','log','output','stdout_file','stderr_file','stdout_path','stderr_path']:
    val=v.get(field)
    if not isinstance(val,str):continue
    for address in [val.removeprefix('/workspace/tcl-lsp/'),(par/val).as_posix(),(par/PurePosixPath(val).name).as_posix()]:
     f=wanted.get(address)
     if not f or not address.endswith(('.log','.txt','.stdout','.stderr')):continue
     if not any(k in v for k in ['command','argv','selector','test','binary','executable','provider','shell','oracle']):continue
     digest=v.get(field+'_sha256',v.get(field.removesuffix('_file').removesuffix('_path')+'_sha256'))
     if digest is not None and digest!=f['source_sha256']:continue
     admitted[address]={'path':address,'blob':f['blob'],'source_sha256':f['source_sha256'],'classification':'explicit referenced retained output DATA','proof':{'metadata':path,'metadata_sha256':by[path]['source_sha256'],'pointer':ptr,'field':field,'literal_member':val,'node_keys':sorted(v),'recorded_digest':digest,'body_bytes':len(raw[address]),'body_physical_lf':raw[address].count(b'\n'),'association':'exact retained member named in adjacent complete output record; no original relocation/authenticity assumed'},'limits':['No recorded status/value/currentness/execution acceptance','Byte provenance unresolved where original digest absent']}
  # Hash-bound exact historical excerpt/reference descriptor. No source semantics
  # or production coverage is donated by retaining source as packet data.
  for field,val in v.items():
   if not isinstance(val,str):continue
   dig=v.get(field+'_sha256')
   if dig is None and field in ['path','file','retained_path','patch','diff','snapshot','excerpt']:dig=v.get('sha256')
   if not(isinstance(dig,str)and re.fullmatch('[0-9a-f]{64}',dig)):continue
   for address in [val.removeprefix('/workspace/tcl-lsp/'),(par/val).as_posix()]:
    f=wanted.get(address)
    if not f or f['source_sha256']!=dig:continue
    if field in ['excerpt','snapshot','retained_path','source_snapshot'] and any(k in v for k in ['source','source_path','original_source','first_line','original_source_sha256']):
     admitted[address]={'path':address,'blob':f['blob'],'source_sha256':f['source_sha256'],'classification':'hash-bound archived source excerpt/snapshot DATA','proof':{'metadata':path,'metadata_sha256':by[path]['source_sha256'],'pointer':ptr,'field':field,'literal_member':val,'node_keys':sorted(v),'original_source':v.get('source',v.get('source_path')),'first_line':v.get('first_line'),'last_line':v.get('last_line'),'digest_field':field+'_sha256','whole_digest':dig},'limits':['Historical retained source aid only; no current source/provider/implementation review donated']}
    elif address.endswith(('.patch','.diff','.before','.after')):source_candidates.append({'member':address,'metadata':path,'pointer':ptr,'field':field,'node':v})
  for k,z in v.items():visit(z,path,ptr+'/'+str(k).replace('~','~0').replace('/','~1'))
 elif isinstance(v,list):
  for i,z in enumerate(v):visit(z,path,ptr+'/'+str(i))
for path in x['meta']:
 b=raw.get(path)
 if b is None:continue
 try:v=json.loads(b)
 except(ValueError,UnicodeError):continue
 visit(v,path)
out={'reservation_sha256':H(x['rb']),'status':'exact explicit record role joins; no execution or current source acceptance','admitted':list(admitted.values()),'source_candidate_questions':source_candidates,'counts':{'admitted':len(admitted),'classes':dict(collections.Counter(z['classification']for z in admitted.values())),'source_candidate_questions':len(source_candidates)}}
p=P/'runtime-audit-role-explicit-data-joins.json';p.write_text(json.dumps(out,separators=(',',':'))+'\n');print('EXPLICIT',out['counts'],H(p.read_bytes()))
