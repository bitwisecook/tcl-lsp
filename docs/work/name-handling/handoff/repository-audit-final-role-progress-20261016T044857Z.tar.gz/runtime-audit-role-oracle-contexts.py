from pathlib import Path,PurePosixPath
import runpy,json,hashlib,collections,re,itertools
P=Path('/workspace/name-session/full-consumer-audit');H=lambda b:hashlib.sha256(b).hexdigest();x=runpy.run_path(str(P/'runtime-audit-role-cohort-census.py'));by=x['by'];wanted=x['wanted'];raw=x['raw'];contexts=[]
idkeys=['provider','version','patchlevel','oracle','engine','case','case_id','operand_case','kind','name','tag','selector','label','release','interpreter','key','argv_input_stem','declared_input_stem','metadata_case_label']
ctxkeys=idkeys+['executable','executable_sha256','provider_path','provider_sha256','shell','shell_sha256','script','script_sha256','source_sha256','command','argv']
def walk(v,path,ptr='',inherited=None):
 inherited=inherited or {}
 if isinstance(v,dict):
  ctx=dict(inherited)
  for k in ctxkeys:
   if k in v:ctx[k]=v[k]
  for field in ['script_sha256','source_sha256']:
   dig=ctx.get(field)
   inputs=[PurePosixPath(z['path']).stem for z in x['parents'][str(PurePosixPath(path).parent)]if z['path'].endswith('.tcl')and z['source_sha256']==dig]
   if len(inputs)==1:ctx['declared_input_stem']=inputs[0]
  for suffix in ['.result.json','-oracle-records.json','-capture.json']:
   if PurePosixPath(path).name.endswith(suffix):ctx['metadata_case_label']=PurePosixPath(path).name.removesuffix(suffix)
  argv=ctx.get('argv',ctx.get('command'))
  if isinstance(argv,list):
   inputs=[PurePosixPath(a).stem for a in argv if isinstance(a,str)and a.endswith('.tcl')]
   if len(inputs)==1:ctx['argv_input_stem']=inputs[0]
  if any(k in v for k in ['exit','exit_code','returncode','process_exit_code']) and any(k in ctx for k in ['executable','provider_path','shell','command','argv','provider','version','oracle','patchlevel']):contexts.append((path,ptr,ctx,sorted(v)))
  for k,z in v.items():walk(z,path,ptr+'/'+str(k).replace('~','~0').replace('/','~1'),ctx)
 elif isinstance(v,list):
  for i,z in enumerate(v):walk(z,path,ptr+'/'+str(i),inherited)
for path in x['meta']:
 b=raw.get(path)
 if b is None:continue
 try:v=json.loads(b)
 except(ValueError,UnicodeError):continue
 walk(v,path)
match=collections.defaultdict(list)
for path,ptr,ctx,keys in contexts:
 ids={k:str(v)for k,v in ctx.items()if k in idkeys and isinstance(v,(str,int))and '/'not in str(v)and str(v)}
 values=list(dict.fromkeys(ids.values()));names={v:('exact record identity',v)for v in values}
 for count in [2,3]:
  for parts in itertools.permutations(values,count):
   for sep in ['-','.','_']:names[sep.join(parts)]=('literal joined tuple',list(parts))
 # Fixed record label explicitly differs from filename's optional observed
 # wrapper prefix. This is candidate association only, not writer proof.
 for name,derivation in list(names.items()):
  for prefix in ['oracle-','c-','C','c']:names[prefix+name]=('unverified retained label prefix '+prefix,derivation)
 par=PurePosixPath(path).parent
 for name,derive in names.items():
  f=wanted.get((par/(name+'.stdout')).as_posix())or wanted.get((par/(name+'.stdout.txt')).as_posix())
  if not f:continue
  versions=[ctx[k]for k in ['version','patchlevel']if isinstance(ctx.get(k),str)]
  b=raw[f['path']]
  try:s=b.decode('utf8')
  except UnicodeError:continue
  head=s.splitlines()[:2]
  observed=[line for line in head if any(line.startswith(prefix)for prefix in ['VERSION ','PROVIDER ','version ','interpreter ','patchlevel '])]
  version_match=any(v in line for v in versions for line in observed)
  match[f['path']].append({'metadata':path,'metadata_sha256':by[path]['source_sha256'],'pointer':ptr,'process_context':ctx,'leaf_keys':keys,'association_derivation':derive,'body_prefix_lines':head,'recorded_version_body_correspondence':version_match,'whole_body_sha256':H(b),'body_bytes':len(b),'body_lf':b.count(b'\n')})
admitted=[];ambiguous=[]
for address,proofs in match.items():
 # Multiple retained manifests may name the same candidate; preserve every
 # schema/context rather than assert one authenticated historical writer.
 tuples={tuple((k,str(v))for k,v in z['process_context'].items()if k in ['version','patchlevel','provider','case','operand_case','kind'])for z in proofs}
 f=wanted[address]
 if len(tuples)>1:
  # A version-only top-level record and a more specific child do not establish
  # the same case unambiguously; retain actual examined question.
  ambiguous.append({'path':address,'source_sha256':f['source_sha256'],'contexts':proofs});continue
 for ch in ['stdout','stderr']:
  member=address.replace('.stdout.txt','.'+ch+'.txt')if address.endswith('.stdout.txt')else address.removesuffix('.stdout')+'.'+ch;z=wanted.get(member)
  if not z:continue
  b=raw[member]
  try:encoding='strict UTF8';text=b.decode('utf8');lfcount=len(text.splitlines())
  except UnicodeError:encoding='counted opaque stream bytes';lfcount=None
  admitted.append({'path':member,'blob':z['blob'],'source_sha256':z['source_sha256'],'classification':'examined retained candidate observation-channel DATA','proofs':proofs,'channel':ch,'pair':address,'body_bytes':len(b),'body_lf':b.count(b'\n'),'complete_text_line_count':lfcount,'encoding':encoding,'limits':['Exact retained record identity association only; optional fixed label prefix unverified','No original stream digest/writer/byte-origin authentication','No process status/provider/output-value semantics acceptance']})
out={'reservation_sha256':H(x['rb']),'status':'candidate observation DATA roles with explicit unresolved producer/byte provenance','counts':{'admitted':len(admitted),'candidate_stdout_members':len(match),'ambiguous_context_members':len(ambiguous)},'admitted':admitted,'ambiguous':ambiguous}
p=P/'runtime-audit-role-oracle-contexts.json';p.write_text(json.dumps(out,separators=(',',':'))+'\n');print('CONTEXT',out['counts'],H(p.read_bytes()))
