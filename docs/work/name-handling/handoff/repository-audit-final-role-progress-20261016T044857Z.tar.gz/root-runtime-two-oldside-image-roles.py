from pathlib import Path
import hashlib,json,re,datetime
D=Path(__file__).parent;P=Path('/workspace/tcl-lsp');out=[]
for dirname,before_name,patch_name,target,after_name in [('experiments/name-handling/results/command-trace-selected-binding-20261013/name-command-trace-binding-adoption','cmd_trace.rs.before','implementation.patch','runtime/rust/src/cmd_trace.rs','cmd_trace.rs.proposed'),('experiments/name-handling/results/vm-oo-root-namespace-creation/repair-01','cmd_oo.rs.before','patch.diff','rust/tcl-vm/src/cmd_oo.rs',None)]:
 d=P/dirname;old=(d/before_name).read_bytes();patch=(d/patch_name).read_text();ls=patch.splitlines(True);begin=next(i for i,s in enumerate(ls)if s.rstrip()=='--- a/'+target);end=next((i for i in range(begin+2,len(ls))if ls[i].startswith('--- ')),len(ls));ls=ls[begin+2:end];original=old.decode().splitlines(True);result=[];cursor=0;i=0;hs=[]
 while i<len(ls):
  m=re.match(r'^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',ls[i])
  if not m:i+=1;continue
  start=int(m[1])-1;oldn=int(m[2]if m[2]is not None else 1);newn=int(m[4]if m[4]is not None else 1);result+=original[cursor:start];a=[];b=[];i+=1
  while i<len(ls)and not ls[i].startswith(('@@ ','--- ','diff --git ')):
   line=ls[i]
   if line.startswith('\\ No newline'):i+=1;continue
   if line.startswith((' ','-')):a.append(line[1:])
   if line.startswith((' ','+')):b.append(line[1:])
   i+=1
  assert len(a)==oldn and len(b)==newn;assert original[start:start+oldn]==a,(target,start);result+=b;cursor=start+oldn;hs.append({'old_start':start+1,'old_count':oldn,'new_count':newn,'old_side_exact':True})
 result+=original[cursor:];new=''.join(result).encode();sha=hashlib.sha256(new).hexdigest();oldgit=hashlib.sha1(b'blob '+str(len(old)).encode()+b'\0'+old).hexdigest()
 if after_name:
  assert new==(d/after_name).read_bytes();binding={'path':str((d/after_name).relative_to(P)),'sha256':sha,'entire_afterimage_byte_equal':True}
 else:
  maps={n:json.loads((d/n).read_bytes())[target]for n in ['vm-source-before.json','vm-source-after.json']};assert set(maps.values())=={sha};ready=(d/'ready-source.sha256').read_text().split()[0];assert sha==ready;assert 'index '+oldgit[:9]in patch;binding={'expected_sha256':sha,'recorded_compiled_input_maps':maps,'ready_source_sha256':ready,'old_git_object_prefix_verified':oldgit[:9]}
 out.append({'path':str((d/before_name).relative_to(P)),'sha256':hashlib.sha256(old).hexdigest(),'git_blob':oldgit,'bytes':len(old),'patch':{'path':str((d/patch_name).relative_to(P)),'sha256':hashlib.sha256((d/patch_name).read_bytes()).hexdigest()},'exact_patch_target':target,'hunks':hs,'old_source_entire_byte_extent_consumed':len(old),'in_memory_reconstructed_afterimage':binding,'role':'Exact whole old-side historical source input for the retained patch. Every unchanged byte and old/context line matches, reconstructing the separately retained/recorded full afterimage. No patch is applied to the checkout or treated as current implementation.'})
o={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'COMPLETE_EXACT_HISTORICAL_OLD_SIDE_INPUT_ROLE','files':out,'errors':[],'count_delta':0,'limits':'In-memory original patch-input correspondence only; no semantic source review, currentness, source/provider/build/test execution or edit authority. Original source bytes/patches unchanged.'};p=D/'root-runtime-two-oldside-image-roles.json';p.write_text(json.dumps(o,indent=2)+'\n');print(json.dumps({'images':2,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}))
