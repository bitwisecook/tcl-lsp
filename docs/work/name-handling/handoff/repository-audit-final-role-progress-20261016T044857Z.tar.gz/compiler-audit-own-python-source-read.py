from pathlib import Path
import json,hashlib,os,ast
D=Path(__file__).parent;R=Path('/workspace/tcl-lsp');H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();q=json.loads((D/'compiler-audit-own-python-read-queue.json').read_text())['rows'];indices=list(range(63))+list(range(116,144));out=[]
for i in indices:
 r=q[i];p=R/r['path'];b=p.read_bytes();assert H(p)==r['source_sha256'];tree=ast.parse(b,filename=r['path']);imports=[];contexts=[]
 for n in ast.walk(tree):
  if isinstance(n,(ast.Import,ast.ImportFrom)):imports.append({'line':n.lineno,'source':ast.get_source_segment(b.decode(),n)})
  if isinstance(n,(ast.Assign,ast.AnnAssign)):
   src=ast.get_source_segment(b.decode(),n) or ''
   if any(z in src for z in ['__file__','ROOT','root=','repo =','OUT =','out=','HERE','Path(\'/workspace','Path("/workspace']):contexts.append({'line':n.lineno,'source':src[:1200]})
 role=('exact owned image/selector admission and frozen-source execution protocol' if i<12 else 'actual retained producer/admission/helper source; independent original probe data or proposed source edits retain their actual parent role')
 if i in [5]:role='actual authored source/module/test selector census producer; lexical approximation reviewed, no Rust macro/whole-closure acceptance inferred'
 if i in [29,30]:role='actual sanitised retained-evidence projection/descriptor refresh producer; projected deployment source is not original executed bytes'
 if i in [35,36,42,46,47,48,49,52,53,54,55,123,124,126,136]:role='actual historical source-proposal/patch/fixture transformation producer; source snapshots/patch strings are historical inputs and outputs, not current production implementation'
 if i in [43,116,117]:role='actual retained log identity/primitive-phase reader; bounded display extraction gives no semantic/original provider acceptance'
 if i==137:role='actual original-suite admission test controls; real setup/temp/path/mock/callee code reviewed; original synthetic control data remains distinct from genuine provider observations'
 if i>=138:role='actual external HTTP evidence/traffic helper body at retained path; source byte aliases do not equate __file__/import/caller or physical network execution'
 out.append({**{k:r[k] for k in ['path','blob','source_sha256','source_bytes','line_count']},'whole_source_actually_read':True,'own_queue_index':i,'purpose':role,'imports':imports,'actual_static_path_bindings':contexts,'actual_file_binding':str(p),'actual_parent_binding':str(p.parent)})
record={'baseline':'cc24c394004fc187378ba0eefb6c2c5b2615fb00','scope':'Actual whole Python source review at exact source/path, without executing/importing reviewed scripts. First oversized display elision was recovered by bounded reads of6..24;25..28 whole visible tail retained. All0..62 and116..143 actually read.','source_queue_sha256':H(D/'compiler-audit-own-python-read-queue.json'),'rows':out,'count':len(out),'physical_source_lines':sum(r['line_count'] for r in out),'unexamined_reserved':0,'new_confirmed_required_units':[],'requirements_questions':['Historical process/image guards do not certify current image, dependency or provider acceptance; stored run outcomes remain unaccepted.','Same-body archived helpers retain distinct actual __file__/ROOT/import/cwd/caller bindings.','Captured/sanitised transport/source projections must retain original-input versus stored-source hash distinction.'],'limits':'No source/build/provider/target execution, Git mutation, original oracle/assertion rewrites, current Native/source permission or full transitive import review is donated. Compiler341 final catalogue/seal unchanged.'}
p=D/'compiler-audit-own-python-source-read.json';t=p.with_suffix('.tmp');t.write_text(json.dumps(record,indent=2)+'\n');os.replace(t,p);print(len(out),record['physical_source_lines'],H(p))
