from pathlib import Path
import json,re,hashlib,datetime,collections
D=Path(__file__).parent;P=Path('/workspace/tcl-lsp');rp=D/'runtime-audit-root-source-snapshot-reservation.json';j=json.loads(rp.read_bytes());out=[];questions=[];cache={}
def walk(o,k=''):
 if isinstance(o,dict):
  for a,b in o.items():yield from walk(b,k+'/'+a)
 elif isinstance(o,list):
  for i,v in enumerate(o):yield from walk(v,k+'/'+str(i))
 elif isinstance(o,str):yield k,o
for r in j['files']:
 p=P/r['path'];b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==r['source_sha256'];s=b.decode();ls=s.splitlines();i=0;targets=[];hunks=[];meta=[];errors=[]
 while i<len(ls):
  line=ls[i]
  if line.startswith('--- '):
   before=line[4:];assert i+1<len(ls)and ls[i+1].startswith('+++ '),(p,i);after=ls[i+1][4:];targets.append({'original':before,'proposed':after,'header_line':i+1});meta.extend([i+1,i+2]);i+=2;continue
  m=re.match(r'^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@(.*)$',line)
  if m:
   start=i;oldn=int(m[2]if m[2]is not None else 1);newn=int(m[4]if m[4]is not None else 1);a=c=0;i+=1;body=[]
   while i<len(ls)and (a<oldn or c<newn):
    v=ls[i]
    if v.startswith('\\ No newline at end of file'):body.append(i+1);i+=1;continue
    if not v or v[0]not in ' +-':errors.append({'hunk_line':start+1,'body_line':i+1,'kind':'invalid_or_truncated_body'});break
    if v[0]in ' -':a+=1
    if v[0]in ' +':c+=1
    body.append(i+1);i+=1
   if i<len(ls)and ls[i].startswith('\\ No newline at end of file'):body.append(i+1);i+=1
   h={'header_line':start+1,'old_start':int(m[1]),'old_count':oldn,'new_start':int(m[3]),'new_count':newn,'old_body_lines':a,'new_body_lines':c,'body_line_count':len(body),'target_index':len(targets)-1,'body_sha256':hashlib.sha256(('\n'.join(ls[start+1:i])+('\n'if i<len(ls)or s.endswith('\n')else '')).encode()).hexdigest()};hunks.append(h)
   if a!=oldn or c!=newn:errors.append({'hunk_line':start+1,'kind':'count_mismatch','old_actual':a,'new_actual':c})
   continue
  if not line or any(line.startswith(x)for x in ['diff --git ','index ','new file mode ','deleted file mode ','old mode ','new mode ','similarity index ','rename from ','rename to ']):meta.append(i+1);i+=1;continue
  errors.append({'line':i+1,'kind':'outside_patch_protocol','text':line[:200]});i+=1
 assert hunks and targets,r['path'];refs=[]
 for pa in list(p.parents)[:4]:
  if pa in [P/'experiments/name-handling/results',P/'experiments/name-handling',P/'experiments']:break
  for q in pa.glob('*.json'):
   if q not in cache:
    try:cache[q]=(hashlib.sha256(q.read_bytes()).hexdigest(),list(walk(json.loads(q.read_bytes()))))
    except Exception:cache[q]=None
   v=cache[q]
   if v:
    hit=[{'field':k,'value':x}for k,x in v[1]if x==r['source_sha256']]
    if hit:refs.append({'path':str(q.relative_to(P)),'sha256':v[0],'matches':hit})
 x={**r,'review_status':'reviewed','review_mode':'complete_typed_retained_unified_patch_source_input_role','role':'Historical proposed source-change serialization: every byte read and parsed as original/proposed file target, hunk coordinate, old/new/context payload or explicit patch metadata. Old/new bodies are patch data to the patching tool, not current compiler/runtime implementation and not Tcl evaluation.','patch_targets':targets,'hunks':hunks,'metadata_lines':meta,'exact_recorded_digest_references':refs,'serialization_questions':errors,'required_change':None,'count_delta':0,'semantic_acceptance':False,'limits':'No patch applied or target implementation read claimed. Individual reviewed hunks must be rebased against actual current source; syntax/count defects and incomplete retention stay explicit, never treated as current valid implementation or accepted replay.'};out.append(x)
 if errors:questions.append({'path':r['path'],'questions':errors})
assert len(out)==343
o={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'COMPLETE_EXACT_HISTORICAL_PATCH_INPUT_ROLE_REVIEW','reservation_sha256':hashlib.sha256(rp.read_bytes()).hexdigest(),'files':out,'counts':{'paths':343,'bytes':sum(r['source_bytes']for r in out),'targets':sum(len(x['patch_targets'])for x in out),'hunks':sum(len(x['hunks'])for x in out),'with_explicit_digest_record':sum(bool(x['exact_recorded_digest_references'])for x in out),'serialization_question_files':len(questions)},'examined_questions':questions,'unexamined_sources':0,'new_confirmed_units':[],'limits':'Complete field/byte payload role check, not semantic source review, validity, currentness, test, Native/provider, edit authority or acceptance. Exact failed/incomplete proposal structures retained. Source/producer implementations remain separately audited; no path-prefix/suffix-only exemption.'};p=D/'root-runtime-patch-role-review.json';p.write_text(json.dumps(o,indent=2)+'\n');print(json.dumps({'counts':o['counts'],'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}))
