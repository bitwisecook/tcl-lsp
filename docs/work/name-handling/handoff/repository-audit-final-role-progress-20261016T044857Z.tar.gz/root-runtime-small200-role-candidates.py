from pathlib import Path
import json,hashlib,collections,re
D=Path(__file__).parent;P=Path('/workspace/tcl-lsp');j=json.load(open(D/'runtime-audit-root-small-text-role-reservation.json'));cache={};out=[]
def walk(o,k='',parent=None):
 if isinstance(o,dict):
  for a,b in o.items():yield from walk(b,k+'/'+a,o)
 elif isinstance(o,list):
  for i,b in enumerate(o):yield from walk(b,k+'/'+str(i),parent)
 elif isinstance(o,(str,int)):yield k,o,parent
for r in j['files']:
 p=P/r['path'];b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==r['source_sha256'];refs=[];channel='stderr'if'stderr'in p.name else 'stdout'if 'stdout'in p.name else None
 for pa in list(p.parents)[:5]:
  if pa in [P/'experiments/name-handling/results',P/'experiments/name-handling/oracles',P/'experiments/name-handling/patterns',P/'docs/design/analysis/name-resolution-proofs/rust-validation',P/'rust',P]:break
  for q in pa.glob('*.json'):
   if q not in cache:
    try:cache[q]=(hashlib.sha256(q.read_bytes()).hexdigest(),list(walk(json.loads(q.read_bytes()))))
    except Exception:cache[q]=None
   v=cache[q]
   if not v:continue
   for k,val,par in v[1]:
    if isinstance(val,str)and val==r['source_sha256']and (channel and channel in k.lower()or p.name in k or r['path']in k):refs.append({'path':str(q.relative_to(P)),'sha256':v[0],'field':k,'kind':'exact_digest_field'})
    elif channel and k.rsplit('/',1)[-1]==channel and isinstance(val,str)and val.encode()==b:refs.append({'path':str(q.relative_to(P)),'sha256':v[0],'field':k,'kind':'exact_inline_channel_bytes'})
    elif not channel and isinstance(val,str)and p.name in val:refs.append({'path':str(q.relative_to(P)),'sha256':v[0],'field':k,'kind':'explicit_filename_or_path','value':val})
 out.append({**r,'record_role_candidates':refs})
(D/'root-runtime-small200-role-candidates.json').write_text(json.dumps({'files':out,'limit':'Candidates only; no automatic empty-byte/signature/prefix acceptance.'},indent=2)+'\n')
print('matched',sum(bool(r['record_role_candidates'])for r in out),'of',len(out))
for i,r in enumerate(out):
 if not r['record_role_candidates']:print(i,r['path'])
