from pathlib import Path
import json,re,hashlib,collections
P=Path('/workspace/name-session/full-consumer-audit');ROOT=Path('/workspace/tcl-lsp');H=lambda b:hashlib.sha256(b).hexdigest();r=json.loads((P/'audit-runtime-final-role-cohort-reservation.json').read_text());admitted=[];unmatched=[]
reader=P/'lsp-audit-live-smoke-source-receipt.json';d=json.loads(reader.read_text());owner=next(z for z in d['whole_source_files']if z['path']=='rust/xtask/src/smoke_targets.rs');assert owner['source_sha256']=='a46b26a369fae5f6144b630accfa52ee541e08fd271aa8aa039e664006708f03'
name=r'[^\s\x00]+';entry=re.compile(r'('+name+r'): (test|benchmark)');footer=re.compile(r'(\d+) tests?, (\d+) benchmarks?');start=re.compile(r'running (\d+) tests?');test=re.compile(r'test (.+?) \.\.\. (ok|FAILED|ignored(?:, .*)?|bench: .*)');result=re.compile(r'test result: (ok|FAILED)\. \d+ passed; \d+ failed; \d+ ignored; \d+ measured;(?: \d+ filtered out;)? finished in [^\s]+')
for f in r['files']:
 path=f['path']
 if not path.endswith(('.txt','.log','.list','.stdout','.stderr'))or path.endswith(('.py.txt','.rs.txt')):continue
 b=(ROOT/path).read_bytes();assert H(b)==f['source_sha256']
 try:s=b.decode('utf8')
 except UnicodeError:continue
 lines=s.splitlines();non=[(i+1,z)for i,z in enumerate(lines)if z.strip()];kind=None;proof={}
 if non and all(entry.fullmatch(z)or footer.fullmatch(z)for _,z in non)and any(entry.fullmatch(z)for _,z in non):
  ents=[entry.fullmatch(z).groups()for _,z in non if entry.fullmatch(z)];foot=[footer.fullmatch(z).groups()for _,z in non if footer.fullmatch(z)];kind='complete retained libtest listing protocol DATA';proof={'entries':len(ents),'entry_name_sequence_sha256':H(json.dumps(ents,separators=(',',':')).encode()),'declared_footer':foot,'exact_reader':{'path':owner['path'],'source_sha256':owner['source_sha256'],'actual_read_ranges':[[2015,2024],[2059,2120]],'receipt':reader.name,'receipt_sha256':H(reader.read_bytes())},'schema':'every nonblank line is complete name: test/benchmark or terminal numeric inventory; no discarded executable/opaque lines'}
 elif non and start.fullmatch(non[0][1])and any(test.fullmatch(z)for _,z in non)and result.fullmatch(non[-1][1]):
  starts=[{'line':i,'count':int(start.fullmatch(z).group(1))}for i,z in non if start.fullmatch(z)];tests=[{'line':i,'name':test.fullmatch(z).group(1),'status_field_unapproved':test.fullmatch(z).group(2)}for i,z in non if test.fullmatch(z)];ends=[{'line':i,'text':z}for i,z in non if result.fullmatch(z)];payload=[i for i,z in non if not(start.fullmatch(z)or test.fullmatch(z)or result.fullmatch(z))];kind='complete retained libtest invocation/result transcript DATA';proof={'invocations':starts,'selected_case_fields':tests,'terminal_result_fields':ends,'opaque_diagnostic_payload_lines':payload,'schema':'whole start/test/result transcript with intervening data under libtest captured stdout; status unaccepted','reader_contract':{'path':owner['path'],'source_sha256':owner['source_sha256'],'ranges':[[2059,2120]],'receipt':reader.name}}
 else:
  parsed=[];trailing=[]
  for i,z in non:
   try:v=json.loads(z)
   except(ValueError,UnicodeError):trailing.append((i,z));continue
   if not isinstance(v,dict):break
   parsed.append((i,v))
  else:
   if parsed:
    cargo=all(v.get('reason')in ['compiler-artifact','compiler-message','build-script-executed','build-finished']for _,v in parsed)
    proc=all(any(k in v for k in ['command','argv','selector','test','ordinal','image_sha256_before','owned_image','operation'])and any(k in v for k in ['exit','exit_code','timeout','timed_out','selectors','passed','log_sha256'])for _,v in parsed)
    if cargo and all(re.fullmatch(r'\s*Finished `[^`]+` profile .*',z)for _,z in trailing):kind='complete retained Cargo JSON event stream DATA'
    elif proc and not trailing:kind='complete retained process-result JSON-lines DATA'
    if kind:proof={'records':len(parsed),'complete_node_key_shapes':dict(collections.Counter('|'.join(sorted(v))for _,v in parsed)),'trailing_protocol_lines':[{'line':i,'text':z}for i,z in trailing],'schema':'each full nonblank JSON line validated as typed Cargo event or explicit process-result node; no execution acceptance'}
 if kind:admitted.append({**f,'classification':kind,'proof':proof,'complete_body_bytes':len(b),'physical_lf':b.count(b'\n'),'limits':['Original producer/origin/recorded status/outcome unaccepted','A stored protocol observation is data, not a current test or provider validation result']})
out={'baseline':r['baseline'],'reservation_sha256':H((P/'audit-runtime-final-role-cohort-reservation.json').read_bytes()),'status':'complete retained protocol DATA roles only','admitted':admitted,'counts':dict(collections.Counter(x['classification']for x in admitted))};q=P/'runtime-audit-role-protocol-data.json';q.write_text(json.dumps(out,separators=(',',':'))+'\n');print(len(admitted),out['counts'],H(q.read_bytes()))
