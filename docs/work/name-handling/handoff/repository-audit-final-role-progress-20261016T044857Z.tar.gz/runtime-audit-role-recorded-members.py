from pathlib import Path,PurePosixPath
import runpy,json,hashlib,re,collections
P=Path('/workspace/name-session/full-consumer-audit');R=Path('/workspace/tcl-lsp');H=lambda b:hashlib.sha256(b).hexdigest()
x=runpy.run_path(str(P/'runtime-audit-role-cohort-census.py'));wanted=x['wanted'];by=x['by'];raw=x['raw'];meta=x['meta'];records=x['records'];admitted={};questions=[]
def describe(b):
 try:s=b.decode('utf8');encoding='strict UTF-8'
 except UnicodeError:s=None;encoding='opaque counted output bytes'
 counts=collections.Counter()
 if s is not None:
  for line in s.splitlines():
   kind='empty'if not line else 'libtest footer'if re.fullmatch(r'test result: .*',line)else 'libtest start'if re.fullmatch(r'running \d+ tests?',line)else 'version observation'if line.startswith(('VERSION ','PATCHLEVEL '))else 'counted output text'
   counts[kind]+=1
 return {'whole_sha256':H(b),'bytes':len(b),'physical_lf':b.count(b'\n'),'encoding':encoding,'complete_line_class_counts':dict(counts),'interpretation':'all bytes retained as inert recorded output; no status/value/producer execution acceptance'}
# Explicit logs: original old absolute path remains unapproved relocation, never
# a samehash fanout. One literal filename in one adjacent metadata record.
for path,ptr,node in records:
 val=node.get('log')
 if not(isinstance(val,str)and any(k in node for k in ['command','argv','binary','selector','test'])and any(k in node for k in ['exit_code','exit','returncode','rc'])):continue
 address=(PurePosixPath(path).parent/PurePosixPath(val).name).as_posix();f=wanted.get(address)
 if not f or not address.endswith(('.log','.txt','.stdout','.stderr')):continue
 b=raw[address]
 dig=node.get('log_sha256',node.get('sha256'))
 if dig is not None and dig!=f['source_sha256']:continue
 proof={'metadata':path,'metadata_sha256':by[path]['source_sha256'],'pointer':ptr,'recorded_log':val,'association':'literal log basename in exact adjacent retained record; original path/relocation not authenticated'if not dig else 'literal adjacent log member plus recorded whole digest','recorded_digest':dig,'node_keys':sorted(node),'selected_test':node.get('test',node.get('selector')),'command':node.get('command',node.get('argv')),'recorded_exit':node.get('exit_code',node.get('exit')),'body':describe(b)}
 admitted[address]={'path':address,'blob':f['blob'],'source_sha256':f['source_sha256'],'classification':'retained referenced process log DATA','proof':proof,'unresolved':['producer execution and outcome not accepted','original byte origin and relocation unverified'if not dig else 'original producer provenance/currentness unverified']}
# Complete oracle candidate records without stream digests. Association is an
# explicit examined provider/case tuple, not a verified writer recipe.
def walk(v,path,ptr=''):
 if isinstance(v,dict):
  if isinstance(v.get('provider'),str)and isinstance(v.get('case'),str)and isinstance(v.get('executable'),str)and any(k in v for k in ['exit','exit_code']):
   provider=v['provider'];case=v['case'];par=PurePosixPath(path).parent
   if '/'not in provider and '/'not in case:
    context=[]
    for source in [case+'.tcl',v.get('source')]:
     if not isinstance(source,str):continue
     q=par/source
     z=by.get(q.as_posix())
     if z and z['source_sha256']==v.get('source_sha256'):context.append({'path':q.as_posix(),'blob':z['blob'],'source_sha256':z['source_sha256'],'purpose':'exact recorded original test input; original bytes not executed/reinterpreted'})
    for ch in ['stdout','stderr']:
     address=(par/(provider+'-'+case+'.'+ch)).as_posix();f=wanted.get(address)
     if not f:continue
     admitted[address]={'path':address,'blob':f['blob'],'source_sha256':f['source_sha256'],'classification':'retained candidate oracle observation-channel DATA; byte origin unavailable','proof':{'metadata':path,'metadata_sha256':by[path]['source_sha256'],'pointer':ptr,'provider':provider,'case':case,'executable':v['executable'],'exit_field':v.get('exit',v.get('exit_code')),'association':'unique complete provider/case tuple plus literal same-directory candidate channel, exact assigned member hash','input_context':context,'body':describe(raw[address])},'unresolved':['exact original writer recipe unavailable','original stream bytes not bound by captured digest','no recorded outcome/provider/expected observation acceptance']}
  for k,z in v.items():walk(z,path,ptr+'/'+str(k).replace('~','~0').replace('/','~1'))
 elif isinstance(v,list):
  for i,z in enumerate(v):walk(z,path,ptr+'/'+str(i))
for path,f in meta.items():
 b=raw.get(path)
 if b is None:continue
 try:v=json.loads(b)
 except (ValueError,UnicodeError):continue
 walk(v,path)
out={'baseline':x['r']['baseline'],'reservation_sha256':H(x['rb']),'status':'source-role admission only; original producer/byte provenance and execution claims unaccepted','rules':['literal exact adjacent log association with complete command/test/exit record','complete exact provider/case/executable/exit oracle tuple with unique retained channel association; omitted original digest explicit'],'admitted':list(admitted.values()),'counts':{'admitted':len(admitted),'classes':dict(collections.Counter(z['classification']for z in admitted.values()))},'limits':['No original producer has been executed, no recorded pass/status/results accepted.','Source/helper bodies and source beforeimages are not admitted by this output schema.','No equal empty-hash fanout or filename prefix-only admission.']}
p=P/'runtime-audit-role-recorded-members.json';p.write_text(json.dumps(out,separators=(',',':'))+'\n');print('SUPPLEMENT',out['counts'],H(p.read_bytes()))
