import json,hashlib,datetime,subprocess,posixpath,re
from pathlib import Path,PurePosixPath
D=Path('/workspace/name-session/full-consumer-audit');R=Path('/workspace/tcl-lsp');c=json.load(open(D/'audit-file-coverage.json'));by={r['path']:r for r in c['files']};q=json.load(open(D/'audit-current-residual-role-queue.json'));held={r['path'] for r in json.load(open(D/'audit-lsp-final-authored-text80-reservation.json'))['files']};targets={r['path']:by[r['path']] for r in q['cohorts']['authored_or_historical_record_text_role_not_yet_bound'] if by[r['path']]['review_status']!='reviewed' and r['path'] not in held};records=[];hits={};H=re.compile('[a-f0-9]{64}')
def raw(r):
 p=R/r['path'];b=p.read_bytes() if p.is_file() else b''
 if hashlib.sha256(b).hexdigest()!=r['source_sha256']:b=subprocess.check_output(['git','cat-file','blob',r['blob']],cwd=R)
 assert hashlib.sha256(b).hexdigest()==r['source_sha256'];return b
def refs(v,at=()):
 if isinstance(v,dict):
  for k,z in v.items():
   if isinstance(z,str) and H.fullmatch(z) and ('.' in k or '/' in k):yield at+(k,),k,z
   yield from refs(z,at+(k,))
 elif isinstance(v,list):
  for i,z in enumerate(v):yield from refs(z,at+(i,))
for r in c['files']:
 if not r['path'].endswith('.json') or r['source_bytes']>40000000:continue
 try:v=json.loads(raw(r))
 except (ValueError,UnicodeError):continue
 links=[]
 for at,p,h in refs(v):
  ps=[posixpath.normpath(PurePosixPath(r['path']).parent.as_posix()+'/'+p),posixpath.normpath(p)]
  for z in dict.fromkeys(ps):
   if z not in targets or targets[z]['source_sha256']!=h:continue
   raw(targets[z]);links.append({'path':z,'source_sha256':h,'recorded_member_path':p,'field_path':list(at),'role':'Explicit exact retained document/license/source-artifact member digest; source/prose/currentness claims unaccepted.'})
 if links:
  ix=len(records);records.append({'record':r['path'],'record_source_sha256':r['source_sha256'],'members':links})
  for j,z in enumerate(links):hits.setdefault(z['path'],(ix,j))
out={'baseline':c['baseline'],'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'records':records,'admitted_paths':sorted(hits),'count':len(hits),'positive_role':'Exact actual artifact/source-retention member full-relative path key and completeSHA binds retained document/license bytes, not current API guidance merely appearing in a historical source copy.','limits':'No manual old prose/semantic read or current generated parity, original producer/patch/source/execution/provider/answer acceptance. Current authored API guide source and actual maintained helpers separately reviewed.'};p=D/'audit-retained-text-hashmap-member-role.json';p.write_text(json.dumps(out,indent=2)+'\n');h=hashlib.sha256(p.read_bytes()).hexdigest()
for path,(i,j) in hits.items():by[path].update(review_status='reviewed',review_mode='exact_retained_artifact_member_path_key_and_wholeSHA_text_role',classification='retained_document_or_legal_text_artifact_source_bytes',reason='Exact recorded retention artifact member path and wholeSHA identifies fixed source/prose bytes; current original document/producer semantics remain separate, no old API guidance acceptance.',evidence=[{'receipt':p.name,'receipt_sha256':h,'json_pointer':f'/records/{i}/members/{j}'}])
t=D/'audit-file-coverage.json.tmp';t.write_text(json.dumps(c,separators=(',',':'))+'\n');t.replace(D/'audit-file-coverage.json');print(len(hits),h)
