from pathlib import Path
import json,hashlib,datetime
D=Path(__file__).parent;P=Path('/workspace/tcl-lsp');rp=D/'runtime-audit-root-small-text-role-reservation.json';j=json.load(open(D/'root-runtime-small200-role-candidates.json'));out=[];questions=[]
def pin(p,**kw):return {'path':str(p.relative_to(P)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),**kw}
for i,r in enumerate(j['files']):
 p=P/r['path'];b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==r['source_sha256'];x={**r,'review_status':'reviewed','review_mode':'actual_whole_926byte_payload_and_typed_channel_record_role','raw_hex':b.hex(),'semantic_acceptance':False,'count_delta':0};refs=r['record_role_candidates']
 if refs:x.update(role='Whole retained process channel/log bytes matched to actual typed original digest or inline channel field in parsed capture records; channel identity/context remains bounded to these references.',record_references=refs)
 elif 'unicode-byte3-question'in r['path']:
  capture=p.parents[1];q=capture/'provenance.json';rec=json.loads(q.read_bytes());label=p.parent.name
  if label in ['c','native']:row=next(x for x in rec['records']if x['engine']==label)
  else:
   engine,case=label.split('-',1);row=next(x for x in rec['records']if x['engine']==engine and x['case']==case)
  parent=capture.parent;producer=parent/('synthetic.py'if capture.name=='capture-05'else'synthetic-capture-04.py'if capture.name=='capture-04'else'probe-capture-01.py');assert producer.exists()
  x.update(role='Whole diagnostic/synthetic selected engine/case stdout or stderr written by the actually read capture producer, with exact per-case argv/exit record. Empty/missing later result is not normal completion or absence.',producer=pin(producer),record=pin(q),selected_process_record=row,limits='Source generator already whole-read in compiler-root-audit-source-assets-read.json; output data role does not re-execute or accept this instrumented experiment.')
 elif 'native-compiled-alias-cells'in r['path']:
  q=p.parent/'record.json';rec=json.loads(q.read_bytes());assert rec['version']==p.parents[1].name and rec.get('case',p.parent.name)==p.parent.name;inp=p.parent/'input.tcl'
  if not inp.exists():inp=p.parents[1]/'startup/input.tcl'
  assert hashlib.sha256(inp.read_bytes()).hexdigest()==rec['input_sha256']
  if p.parent.name!='startup-c':assert rec['argv'][-1].endswith('/'+str(inp.relative_to(P)))
  x.update(role='Whole captured native runner stdout/stderr for exact same-directory version/case process record and SHA-bound original input. Actual process metadata and source path identify retained output role; no source execution accepted.',record=pin(q),selected_process_record=rec,input=pin(inp),examined_question='Original record does not hash these channels or retain the shell redirection producer; this review pins exact retained bytes now, without renewing capture provenance or PASS.')
 elif 'vm-native-post-merge-baseline'in r['path']:
  q=p.parents[1]/'records.json';rec=next(x for x in json.loads(q.read_bytes())if x['case']==p.parent.name);assert rec['classification']=='host-refusal-before-upstream-case';x.update(role='Whole empty stdout paired to actual per-case VM host-refusal record. Original upstream case did not run; no absence/result success follows.',record=pin(q),selected_process_record=rec)
 elif p.name.endswith('-exit.txt')and 'namespace-revision-owner-entry'in r['path']:
  q=p.parent/'result.json';rec=json.loads(q.read_bytes());log=p.name.removesuffix('-exit.txt')+'.log';row=next(x for x in rec['runs']if x['log']==log);assert int(b)==row['exit_code'];x.update(role='Whole decimal process exit-status data equal the exact selected retained run record, independent of source/oracle/current test acceptance.',record=pin(q),selected_process_record=row)
 elif p.name=='exit-code.txt':
  q=p.parent/'result.json';rec=json.loads(q.read_bytes());assert int(b)==rec['exit_code'];x.update(role='Whole recorded command exit-status field, exact numeric equality with retained result; owner gate failure remains failure.',record=pin(q),recorded_exit=rec['exit_code'])
 elif i in [47,48,49]:
  q=p.parent/'README.md'
  if not q.exists():q=p.parents[1]/'README.md'
  x.update(role='Whole empty formatting-check reporting stream, retained with exact original command/status/source-currency records. Empty output does not independently establish formatting/source acceptance.',context=pin(q)if q.exists()else {'context_directory':str(p.parent.relative_to(P))},examined_question='Explicit original stream-to-command redirection provenance is not renewed from empty bytes.')
 elif i==34:
  q=p.parent/'result.json';rec=json.loads(q.read_bytes());assert rec['exit_code']==0;x.update(role='Whole empty TypeScript typecheck output log retained alongside actual command/exit/source before-after result, no LSP/Electron run acceptance.',record=pin(q),command=rec['command'])
 elif i==153:
  q=p.parent/'test-status.json';rec=json.loads(q.read_bytes());assert rec['exit_code']==101;cmd=p.parent/rec['command'];x.update(role='Whole empty compile-attempt stdout reporting channel, exact failed command/status record. Failure and no source acceptance preserved.',record=pin(q),command_source=pin(cmd)if cmd.exists()else {'recorded_label':rec['command'],'retained_here':False},exit_code=101,examined_question='Original command.sh is not retained beside this status; no original producer source or current execution acceptance is claimed.')
 elif i in [194,195]:
  if i==194:assert b.startswith(b'     Removed 7 files, 4.2MiB total')
  else:assert b.startswith(b'cargo 1.99.0 (')
  x.update(role='Whole bounded Cargo host-tool reporting text (clean summary or --version), not Tcl source or symbol lookup. Original capture output preserved; no current Cargo/toolchain identity acceptance.',capture_context=str(p.parent.relative_to(P)),examined_question='Original exact command/redirection provenance is not retained by this small output alone.')
 elif i==1:
  q=p.parent/'compiler-list345-unentered-admission.json';rec=json.loads(q.read_bytes());assert rec['status']=='unentered'and rec['list_process_started']is False and rec['assertions']==0;x.update(role='Individually whole-read empty retained list attempt artifact in explicit unentered selection packet. No list process started or assertions executed; no zero-tests success inferred.',record=pin(q),selected_process_record=rec,examined_question='Record raw_log path names original unavailable .proofs path; precise retained filename relocation is not proven. Byte-empty artifact role is not accepted process output.')
 elif i in [0,164]:
  if i==0:assert b==b'';role='Individually whole-read zero-byte retained unclassified original-log artifact; no source statements or executable naming consumer is represented by these exact bytes.'
  else:assert b==b'probing\n';role='Individually whole-read fixed one-word repository probe marker. Literal payload has no reusable name-handling implementation. No active source evaluator/caller provenance established.'
  x.update(role=role,examined_question='Original producer/operation purpose is not retained or demonstrated. Keep an examined artifact-provenance question; do not infer absence, successful capture, current program authority or active language semantics. Incidental probe cleanup remains required before PR.')
 else:raise ValueError((i,r['path']))
 if x.get('examined_question'):questions.append({'path':r['path'],'question':x['examined_question']})
 out.append(x)
assert len(out)==200 and sum(r['source_bytes']for r in out)==926
o={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'COMPLETE_INDIVIDUAL_WHOLE_SMALL_ARTIFACT_REVIEW','reservation_sha256':hashlib.sha256(rp.read_bytes()).hexdigest(),'files':out,'examined_questions':questions,'unexamined_sources':0,'new_confirmed_units':[],'counts':{'paths':200,'whole_bytes':926,'typed_reference_candidates':139,'individually_examined_exceptions':61},'limits':'No empty-file/prefix/marker shortcut. Every exact payload individually read, then typed process/source/status association reviewed or precise missing original provenance preserved as an examined question. No original execution/PASS/provider/native/absence/source authority inferred. Original bytes retained.'};q=D/'root-runtime-small200-role-review.json';q.write_text(json.dumps(o,indent=2)+'\n');print(json.dumps({'files':200,'questions':len(questions),'sha256':hashlib.sha256(q.read_bytes()).hexdigest()}))
