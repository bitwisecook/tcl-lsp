from pathlib import Path,PurePosixPath
import json,hashlib,collections,re
P=Path('/workspace/name-session/full-consumer-audit');ROOT=Path('/workspace/tcl-lsp');H=lambda b:hashlib.sha256(b).hexdigest()
R=P/'audit-runtime-final-role-cohort-reservation.json';rb=R.read_bytes();assert H(rb)=='de4fa48da61260b86e33efda988ae1363c4e579ecf6c77eab43652bfe48b1f92';r=json.loads(rb);C=json.loads((P/'audit-file-coverage.json').read_text());by={x['path']:x for x in C['files']};wanted={x['path']:x for x in r['files']};parents=collections.defaultdict(list)
for f in C['files']:parents[str(PurePosixPath(f['path']).parent)].append(f)
raw={};problems=[]
def content(f):
 if f['path']in raw:return raw[f['path']]
 q=ROOT/f['path'];b=q.read_bytes()if q.is_file()else None
 if b is None or H(b)!=f['source_sha256']:
  problems.append({'path':f['path'],'problem':'exact retained source aid required; current workspace differs/missing'});return None
 raw[f['path']]=b;return b
for f in r['files']:content(f)
# Discover actual retained neighbouring metadata records by finite ancestor joins,
# not arbitrary global equal hashes or basename-only output acceptance.
meta={}
for f in r['files']:
 par=PurePosixPath(f['path']).parent
 for level in range(5):
  for q in parents[str(par)]:
   if q['path'].endswith('.json')and q['source_bytes']<12000000:meta[q['path']]=q
  par=par.parent
records=[]
def walk(v,path,pointer=''):
 if isinstance(v,dict):
  if any('stdout'in k or 'stderr'in k or k in ['log','log_sha256','output_sha256']for k in v):records.append((path,pointer,v))
  for k,z in v.items():walk(z,path,pointer+'/'+str(k).replace('~','~0').replace('/','~1'))
 elif isinstance(v,list):
  for i,z in enumerate(v):walk(z,path,pointer+'/'+str(i))
for path,f in meta.items():
 b=content(f)
 if b is None:continue
 try:d=json.loads(b)
 except (ValueError,UnicodeError):continue
 walk(d,path)
candidates=collections.defaultdict(list); schemas=collections.Counter(); log_candidates={}; member_index=collections.defaultdict(list)
for f in r['files']:
 for channel in ['stdout','stderr']:
  if channel in PurePosixPath(f['path']).name:member_index[(str(PurePosixPath(f['path']).parent),f['source_sha256'],channel)].append(f)
for path,ptr,node in records:
 par=PurePosixPath(path).parent
 processkeys=[k for k in ['argv','command','exit','exit_code','returncode','rc','executable','provider','engine','case','label','name','tag']if k in node]
 schemas[tuple(sorted(node))]+=1

 # Complete typed capture descriptors explicitly name their retained transcript
 # or channel and its whole digest. Recorded status/exit are data, not approval.
 if any(k in node for k in ['exit','exit_code','returncode','rc']):
  for ch in ['stdout','stderr','transcript']:
   descriptor=node.get(ch)
   if not isinstance(descriptor,dict):continue
   val=descriptor.get('path');dig=descriptor.get('sha256')
   if not(isinstance(val,str)and isinstance(dig,str)and re.fullmatch('[0-9a-f]{64}',dig)):continue
   literal=val.removeprefix('/workspace/tcl-lsp/')
   for address in [literal,(par/PurePosixPath(val)).as_posix()]:
    f=wanted.get(address)
    if f and f['source_sha256']==dig:
     candidates[address].append({'metadata':path,'metadata_sha256':by[path]['source_sha256'],'pointer':ptr,'channel':ch,'field':ch+'/sha256','exact_digest':dig,'process_context_keys':processkeys,'metadata_node_keys':sorted(node),'relative_member':address,'member_identity_fields':[ch+'/path',val],'fixed_channel_basename':False,'admission':'explicit typed retained capture descriptor exact path and whole digest; recorded outcome and original producer execution remain unaccepted'})
 # Exact retained explicit capture or channel-file member addresses; no fuzzy
 # output search, no case-insensitive or path normalization authority.
 if any(k in node for k in ['argv','command','executable','provider','binary','provider_label','shell','oracle'])and any(k in node for k in ['exit','exit_code','returncode','rc','process_exit_code']):
  for ch in ['stdout','stderr']:
   dig=node.get(ch+'_sha256');datum=node.get(ch)
   if not(isinstance(dig,str)and re.fullmatch('[0-9a-f]{64}',dig)):dig=H(datum.encode())if isinstance(datum,str)else None
   if dig is None:continue
   addresses=[]
   for field in [ch+'_file',ch+'_path']:
    val=node.get(field)
    if isinstance(val,str):
     pp=PurePosixPath(val)
     addresses.append((field,val,(par/pp).as_posix()if not pp.is_absolute()else val.removeprefix('/workspace/tcl-lsp/')))
     addresses.append((field+' explicit relocated basename',val,(par/pp.name).as_posix()))
   cap=node.get('capture')
   if isinstance(cap,str):
    cp=cap.removeprefix('/workspace/tcl-lsp/');addresses.append(('capture exact retained directory',cap,(PurePosixPath(cp)/(ch+'.txt')).as_posix()))
   for fld,val,address in addresses:
    f=wanted.get(address)
    if f and f['source_sha256']==dig:
     candidates[address].append({'metadata':path,'metadata_sha256':by[path]['source_sha256'],'pointer':ptr,'channel':ch,'field':ch+'_sha256'if isinstance(node.get(ch+'_sha256'),str)else ch,'exact_digest':dig,'process_context_keys':processkeys,'metadata_node_keys':sorted(node),'relative_member':address,'member_identity_fields':[fld,val],'fixed_channel_basename':False,'admission':'exact explicit recorded process channel member address plus whole bytes/digest; no producer execution/currentness approval'})
 # Positive nested stream directory from recorded relative name, matching the
 # actually read execute(name) dest=OUT/name retention contract.
 process_node=any(k in node for k in ['argv','command','executable','provider','binary','shell','oracle'])and any(k in node for k in ['exit','exit_code','returncode','rc','process_exit_code'])
 relative_name=node.get('name')
 if process_node and isinstance(relative_name,str) and '/' in relative_name and not PurePosixPath(relative_name).is_absolute()and '..'not in PurePosixPath(relative_name).parts:
  for ch in ['stdout','stderr']:
   dig=node.get(ch+'_sha256')
   exact=(par/relative_name/(ch+'.txt')).as_posix();f=wanted.get(exact)
   if f and f['source_sha256']==dig:
    candidates[exact].append({'metadata':path,'metadata_sha256':by[path]['source_sha256'],'pointer':ptr,'channel':ch,'field':ch+'_sha256','exact_digest':dig,'process_context_keys':processkeys,'metadata_node_keys':sorted(node),'relative_member':str(PurePosixPath(exact).relative_to(par)),'member_identity_fields':['name exact relative directory'],'fixed_channel_basename':True,'admission':'exact recorded relative process output directory and digest; original execution/provenance not accepted'})

 if isinstance(node.get('log'),str)and isinstance(node.get('log_sha256',node.get('sha256')),str) and any(k in node for k in ['argv','command','binary','executable','selector','test']) and any(k in node for k in ['exit','exit_code','returncode','rc']):
  candidate=(par/PurePosixPath(node['log']).name).as_posix();f=wanted.get(candidate)
  if f and f['source_sha256']==node.get('log_sha256',node.get('sha256')):
   log_candidates[candidate]={'metadata':path,'metadata_sha256':by[path]['source_sha256'],'pointer':ptr,'field':'log_sha256'if 'log_sha256'in node else 'sha256','recorded_log':node['log'],'actual_member':candidate,'digest':f['source_sha256'],'process_node_keys':sorted(node),'recorded_producer_argv':node.get('argv',node.get('command')),'status':'positive exact stored process descriptor output role; no recorded status/provider execution accepted'}

 for channel in ['stdout','stderr']:
  digest=node.get(channel+'_sha256');datum=node.get(channel)
  if not(isinstance(digest,str)and re.fullmatch('[0-9a-f]{64}',digest)):
   digest=H(datum.encode())if isinstance(datum,str)else None
  if digest is None:continue
  for f in member_index.get((str(par),digest,channel),[]):
   fp=PurePosixPath(f['path']);name=fp.name;rel=fp.relative_to(par)
   tail='.'+channel
   stem=name.split(tail,1)[0]if tail in name else ''
   actual_keys=[k for k in ['name','label','case','provider','version','tag','selector','engine','key','oracle','release','patchlevel','interpreter']if isinstance(node.get(k),str)and node[k]==stem]
   standard=name in [channel,channel+'.txt',channel+'.log']
   unique_nonempty=len(member_index.get((str(par),digest,channel),[]))==1 and bool(raw[f['path']])
   if not (actual_keys or standard or unique_nonempty):continue
   if not (any(k in node for k in ['argv','command','executable','provider','binary','shell','oracle'])and any(k in node for k in ['exit','exit_code','returncode','rc','process_exit_code'])):continue
   if len(candidates[f['path']])>=3:continue
   candidates[f['path']].append({'metadata':path,'metadata_sha256':by[path]['source_sha256'],'pointer':ptr,'channel':channel,'field':channel+'_sha256'if isinstance(node.get(channel+'_sha256'),str)else channel,'exact_digest':digest,'process_context_keys':processkeys,'metadata_node_keys':sorted(node),'relative_member':str(rel),'member_identity_fields':actual_keys or (['unique nonempty exact adjacent channel digest; no spelling alias inferred']if unique_nonempty else []),'fixed_channel_basename':standard,'admission':'strict typed record output candidate; actual recorded data purpose only, not process/provider acceptance'})
out={'reservation':R.name,'reservation_sha256':H(rb),'counts':{'requested':len(wanted),'verified_requested':sum(x in raw for x in wanted),'candidate_members':len(candidates),'exact_log_members':len(log_candidates),'neighbour_json_records':len(meta),'stream_nodes':len(records),'source_aid_problems':len(problems)},'stream_candidates':dict(candidates),'log_candidates':log_candidates,'schema_counts':[{'keys':list(k),'count':v}for k,v in schemas.most_common(70)],'unmatched':[f for f in r['files']if f['path']not in candidates],'source_aid_problems':problems,'status':'UNADMITTED finite census; no primary changes or producer execution'}
o=P/'runtime-audit-role-cohort-stream-candidates.json';o.write_text(json.dumps(out,separators=(',',':'))+'\n');print(out['counts']);print(out['schema_counts'][:12])
