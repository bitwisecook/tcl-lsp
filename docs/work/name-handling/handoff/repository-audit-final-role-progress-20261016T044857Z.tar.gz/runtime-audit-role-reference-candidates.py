from pathlib import Path,PurePosixPath
import json,hashlib,collections,runpy
P=Path('/workspace/name-session/full-consumer-audit');x=runpy.run_path(str(P/'runtime-audit-role-cohort-census.py'));wanted=x['wanted'];left={z['path']for z in json.loads((P/'runtime-audit-role-cohort-unmatched-working.json').read_text())};reserved=set()
for q in ['runtime-audit-root-small-text-role-reservation.json','runtime-audit-lsp-residual-text-role-reservation.json']:
 reserved|={z['path']for z in json.loads((P/q).read_text())['files']}
found=collections.defaultdict(list)
def walk(v,path,ptr='',parent=None):
 if isinstance(v,dict):
  for k,z in v.items():walk(z,path,ptr+'/'+str(k).replace('~','~0').replace('/','~1'),v)
 elif isinstance(v,list):
  for i,z in enumerate(v):walk(z,path,ptr+'/'+str(i),parent)
 elif isinstance(v,str):
  if len(v)>1000 or '\n'in v:return
  par=PurePosixPath(path).parent;value=PurePosixPath(v)
  for address in [v.removeprefix('/workspace/tcl-lsp/'),(par/value).as_posix(),(par/value.name).as_posix()]:
   if address not in left or address in reserved:continue
   found[address].append({'metadata':path,'metadata_sha256':x['by'][path]['source_sha256'],'pointer':ptr,'literal':v,'node_keys':sorted(parent)if isinstance(parent,dict)else [],'node':parent})
for path in x['meta']:
 b=x['raw'].get(path)
 if b is None:continue
 try:walk(json.loads(b),path)
 except(ValueError,UnicodeError):continue
out={'reference_members':dict(found),'counts':{'members':len(found),'fields':dict(collections.Counter(z['pointer'].split('/')[-1]for ps in found.values()for z in ps))}};q=P/'runtime-audit-role-reference-candidates.json';q.write_text(json.dumps(out,separators=(',',':'))+'\n');print(out['counts'])
for k,ps in list(found.items())[:20]:print(k,[(z['metadata'],z['pointer'])for z in ps[:2]])
