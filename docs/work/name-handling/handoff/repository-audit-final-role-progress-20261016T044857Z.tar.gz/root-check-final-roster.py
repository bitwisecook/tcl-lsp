from pathlib import Path
import json,subprocess,hashlib,collections,re,datetime
D=Path(__file__).parent;P=Path('/workspace/tcl-lsp');base='cc24c394004fc187378ba0eefb6c2c5b2615fb00';raw=subprocess.check_output(['git','ls-tree','-rz','--full-tree',base],cwd=P);tree={}
for s in raw.split(b'\0'):
 if not s:continue
 a,path=s.split(b'\t',1);mode,typ,blob=a.decode().split();tree[path.decode()]={'mode':mode,'type':typ,'blob':blob}
seen={};errs=[];inputs={};areas={}
for area in ['compiler','db','lsp','runtime','vm','root','audit']:
 p=D/(area+'-file-coverage.json');b=p.read_bytes();j=json.loads(b);rs=j.get('rows',j.get('files',[]));inputs[area]={'path':p.name,'sha256':hashlib.sha256(b).hexdigest()};areas[area]={'paths':len(rs),'review_statuses':dict(collections.Counter(str(r.get('review_status',r.get('reviewstatus',r.get('status'))))for r in rs))}
 for r in rs:
  name=r['path'];s=r.get('source_sha256',r.get('sourceSHA',r.get('sha256')));blob=r.get('git_blob',r.get('blob'))
  if name in seen:errs.append({'path':name,'kind':'duplicate_assignment','first':seen[name],'second':area})
  seen[name]=area
  if name not in tree:errs.append({'path':name,'kind':'outside_baseline'});continue
  if blob and blob!=tree[name]['blob']:errs.append({'path':name,'kind':'baseline_blob_mismatch','coverage':blob,'baseline':tree[name]['blob']})
  if not s or not re.fullmatch('[0-9a-f]{64}',s):errs.append({'path':name,'kind':'missing_original_sha256'})
missing=sorted(set(tree)-set(seen));extra=sorted(set(seen)-set(tree));o={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseline':base,'status':'INDEPENDENT_EXACT_BASELINE_ROSTER_BINDING_CHECK','tracked_paths':len(tree),'assigned_paths':len(seen),'areas':areas,'inputs':inputs,'errors':errs,'missing':missing,'extra':extra,'limits':'Exact baseline path/blob/digest-presence check, not source review, role admission or whole-codebase remaining-change acceptance. Final source-role seal remains independent.'};p=D/'root-final-roster-binding-check.json';p.write_text(json.dumps(o,indent=2)+'\n');print(json.dumps({'tracked':len(tree),'assigned':len(seen),'errors':len(errs),'missing':len(missing),'extra':len(extra),'first_errors':errs[:7]}))
