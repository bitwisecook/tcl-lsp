from pathlib import Path
import json,hashlib,concurrent.futures,datetime
D=Path(__file__).parent;H=Path('/workspace/tcl-lsp/docs/work/name-handling/handoff');p=H/'packets.json';raw=p.read_bytes();j=json.loads(raw);s=H/'SHA256SUMS';sm={}
for line in s.read_text().splitlines():
 if not line.strip():continue
 sha,n=line.split('  ',1);assert n not in sm;sm[n]=sha
assert len({r['file']for r in j})==len(j)
def one(r):
 q=H/r['file'];h=hashlib.sha256();n=0
 with q.open('rb')as f:
  while b:=f.read(8*1024*1024):h.update(b);n+=len(b)
 assert h.hexdigest()==r['sha256']==sm[r['file']],r['file'];return {'path':r['file'],'sha256':h.hexdigest(),'bytes':n}
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as e:rs=list(e.map(one,j))
assert set(sm)=={r['file']for r in j},set(sm)^{r['file']for r in j}
o={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'COMPLETE_OUTER_PACKET_INDEX_AND_DIGEST_VERIFICATION','index_sha256':hashlib.sha256(raw).hexdigest(),'checksum_index_sha256':hashlib.sha256(s.read_bytes()).hexdigest(),'members':rs,'errors':[],'limits':'Outer bytes, exact inventory and index consistency only. Internal member proofs retain their own sealed manifests. Portable old proposals retain blockers; no code/provider/current acceptance follows.'};q=D/'root-current-handoff-packet-verification.json';q.write_text(json.dumps(o,indent=2)+'\n');print(json.dumps({'packets':len(rs),'bytes':sum(r['bytes']for r in rs),'sha256':hashlib.sha256(q.read_bytes()).hexdigest()}))
