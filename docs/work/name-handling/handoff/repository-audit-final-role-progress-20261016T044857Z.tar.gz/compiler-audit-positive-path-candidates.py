from pathlib import Path
import json,hashlib
D=Path(__file__).parent;R=Path('/workspace/tcl-lsp');H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rows=json.loads((D/'compiler-audit-source-asset-candidates.json').read_text())['rows'];out=[]
for r in rows:
 if Path(r['path']).suffix not in ['.c','.h','.rs']:continue
 ps=[]
 for c in r['sha_reference_candidates']:
  m=R/c['metadata'];v=c['record'];ptr=c['json_pointer']; fields=[]
  if isinstance(v,dict):
   for k,z in v.items():
    if isinstance(z,str) and k in ['retained','retained_path','copy','artifact','proposed_source','excerpt_path','excerpt_file','source_file','selection','before_test','source','path']:
     fields.append((k,z))
   if len(ptr)>1:fields.append(('exact_map_key',str(ptr[-2])))
   elif ptr:fields.append(('exact_map_key',str(ptr[-1])))
  for k,z in fields:
   p=Path(z)
   options=[p] if p.is_absolute() else [m.parent/p,R/p]
   matches=[str(p.relative_to(R)) for p in options if p.is_relative_to(R) and str(p.relative_to(R))==r['path']]
   if matches:ps.append(dict(c,physical_path_field=k,physical_path_value=z))
 out.append(dict(r,exact_physical_path_references=ps))
p=D/'compiler-audit-positive-path-candidates.json';p.write_text(json.dumps({'rows':out,'count':len(out),'exact_physical_path_candidates':sum(bool(r['exact_physical_path_references']) for r in out),'limits':'Exact path/hash reference candidates; actual role admission separate.'},indent=2)+'\n');print(len(out),sum(bool(r['exact_physical_path_references']) for r in out))
for r in out:
 if not r['exact_physical_path_references']:print(r['path'])
