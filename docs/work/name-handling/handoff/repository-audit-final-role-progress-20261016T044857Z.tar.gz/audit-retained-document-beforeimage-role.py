import json,hashlib,datetime,subprocess,re,collections
from pathlib import Path,PurePosixPath
D=Path('/workspace/name-session/full-consumer-audit');R=Path('/workspace/tcl-lsp');c=json.load(open(D/'audit-file-coverage.json'));by={r['path']:r for r in c['files']};q=json.load(open(D/'audit-current-residual-role-queue.json'));held={r['path'] for r in json.load(open(D/'audit-lsp-final-authored-text80-reservation.json'))['files']};targets={z['path']:by[z['path']] for z in q['cohorts']['authored_or_historical_record_text_role_not_yet_bound'] if by[z['path']]['review_status']!='reviewed' and z['path'] not in held};hs=collections.defaultdict(list)
for r in targets.values():hs[r['source_sha256']].append(r)
records=[];hits={};hkeys=['sha256','source_sha256','before_sha256','after_sha256','snapshot_sha256','original_sha256','proposed_sha256','current_sha256']
def raw(r):
 p=R/r['path'];b=p.read_bytes() if p.is_file() else b''
 if hashlib.sha256(b).hexdigest()!=r['source_sha256']:b=subprocess.check_output(['git','cat-file','blob',r['blob']],cwd=R)
 assert hashlib.sha256(b).hexdigest()==r['source_sha256'];return b
def refs(v,at=()):
 if isinstance(v,dict):
  for pk in ['path','file','source','document','relative_path','original_path','source_path','retained_path']:
   p=v.get(pk)
   if not isinstance(p,str):continue
   for hk in hkeys:
    h=v.get(hk)
    if isinstance(h,str) and h in hs:yield at+(pk,),p,h,hk
  for k,z in v.items():yield from refs(z,at+(k,))
 elif isinstance(v,list):
  for i,z in enumerate(v):yield from refs(z,at+(i,))
for r in c['files']:
 if not r['path'].endswith('.json') or r['source_bytes']>40000000:continue
 b=raw(r)
 if not any(h.decode() in hs for h in re.findall(rb'[a-f0-9]{64}',b)):continue
 try:v=json.loads(b)
 except (ValueError,UnicodeError):continue
 links=[]
 for at,p,h,hk in refs(v):
  p=p.removeprefix('/workspace/tcl-lsp/');
  for z in hs[h]:
   if z['path']!=p and not z['path'].endswith('/'+p):continue
   raw(z);links.append({'path':z['path'],'source_sha256':h,'recorded_original_path':p,'field_path':list(at),'digest_field':hk,'role':'Exact stored bytes equal explicitly named original/proposed/measured document source field; original fullpath suffix retained, no inferred storage codec/uniqueorigin/current directive acceptance.'})
 if links:
  i=len(records);records.append({'record':r['path'],'record_source_sha256':r['source_sha256'],'source_members':links})
  for j,z in enumerate(links):hits.setdefault(z['path'],(i,j))
out={'baseline':c['baseline'],'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'records':records,'admitted_paths':sorted(hits),'count':len(hits),'positive_role':'Exact before/after/source snapshot path+whole SHA descriptor binds retained full original-path document bytes; not current authored API guide merely because old code/prose occurs. Original maintained guide reviewed separately.','limits':['No current source applicability, original storage filename codec, actual patchapplication or historical source/generator/provider/semantic acceptance.','All before/after/source claims and conflicting snapshot digests retained as data; no automatic current-guidance advice or proposed repair count.','No manual original document body semantic read claimed by byte correspondence role. Actual maintained producer/admission source remains separate source review.']};p=D/'audit-retained-document-beforeimage-role.json';p.write_text(json.dumps(out,indent=2)+'\n');h=hashlib.sha256(p.read_bytes()).hexdigest()
for path,(i,j) in hits.items():by[path].update(review_status='reviewed',review_mode='explicit_full_original_path_and_whole_SHA_document_beforeimage_role',classification='retained_original_measured_or_proposed_document_source_beforeimage',reason='Complete retained bytes equal explicit source/before/after full original document path descriptor. Current guide source and semantic/proposed acceptance remain separate, no manual old prose read claimed.',evidence=[{'receipt':p.name,'receipt_sha256':h,'json_pointer':f'/records/{i}/source_members/{j}'}])
t=D/'audit-file-coverage.json.tmp';t.write_text(json.dumps(c,separators=(',',':'))+'\n');t.replace(D/'audit-file-coverage.json');print(len(hits),h)
