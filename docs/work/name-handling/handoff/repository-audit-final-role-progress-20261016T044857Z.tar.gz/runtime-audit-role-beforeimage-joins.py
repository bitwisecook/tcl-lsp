from pathlib import Path,PurePosixPath
import runpy,json,hashlib,re,collections
P=Path('/workspace/name-session/full-consumer-audit');H=lambda b:hashlib.sha256(b).hexdigest();x=runpy.run_path(str(P/'runtime-audit-role-cohort-census.py'));fs=[f for f in x['r']['files']if f['path'].endswith(('.before','.after'))];proofs=collections.defaultdict(list)
def walk(v,path,ptr='',target=None):
 if isinstance(v,dict):
  actual=v.get('path',v.get('source',v.get('source_path',target)))
  if isinstance(actual,str)and actual.endswith(('.rs','.py','.c','.h')):
   for field,dig in v.items():
    if field not in ['before_sha256','after_sha256','preimage_sha256','proposed_sha256','original_sha256','source_sha256','current_sha256','before','after']:continue
    if not isinstance(dig,str):continue
    for f in fs:
     fp=PurePosixPath(f['path']);par=PurePosixPath(path).parent
     if fp.parent!=par or f['source_sha256']!=dig:continue
     phase=fp.suffix[1:]
     if phase=='before'and field not in ['before_sha256','preimage_sha256','original_sha256','source_sha256','before']:continue
     if phase=='after'and field not in ['after_sha256','proposed_sha256','current_sha256','after']:continue
     stem=fp.name.removesuffix('.'+phase);forms=[PurePosixPath(actual).name,actual.replace('/','__'),actual.replace('/','--')]
     if not any(stem==form or form.endswith('/'+stem)or form.endswith('--'+stem)for form in forms):continue
     proofs[f['path']].append({'metadata':path,'metadata_sha256':x['by'][path]['source_sha256'],'pointer':ptr,'original_target':actual,'phase':phase,'field':field,'whole_digest':dig,'retained_name':fp.name,'role':'historical exact source preimage/afterimage retained for proposed/diagnostic packet; not a live implementation source'})
  for k,z in v.items():
   if k.endswith(('.rs','.py','.c','.h'))and isinstance(z,str)and re.fullmatch('[0-9a-f]{64}',z)and 'before'in PurePosixPath(path).name:
    for f in fs:
     fp=PurePosixPath(f['path'])
     if fp.parent==PurePosixPath(path).parent and f['source_sha256']==z and fp.name.removesuffix('.before')in [PurePosixPath(k).name,k.replace('/','__'),k.replace('/','--')]:
      proofs[f['path']].append({'metadata':path,'metadata_sha256':x['by'][path]['source_sha256'],'pointer':ptr+'/'+k.replace('/','~1'),'original_target':k,'phase':'before','field':'exact source path to digest in explicit before inventory','whole_digest':z,'role':'historical source preimage packet data; no current-source implementation grant'})
   walk(z,path,ptr+'/'+str(k).replace('~','~0').replace('/','~1'),k if k.endswith(('.rs','.py','.c','.h'))else actual)
 elif isinstance(v,list):
  for i,z in enumerate(v):walk(z,path,ptr+'/'+str(i),target)
for path in x['meta']:
 b=x['raw'].get(path)
 if b is None:continue
 try:v=json.loads(b)
 except(ValueError,UnicodeError):continue
 walk(v,path)
admitted=[{**f,'classification':'hash-bound historical source preimage/afterimage DATA','proofs':proofs[f['path']],'limits':['Exact archived packet source role only; no source semantic/currentness/provider/execution acceptance','Current production source coverage remains independently required']}for f in fs if proofs[f['path']]]
out={'status':'historical exact source data-role closure only','reservation_sha256':H(x['rb']),'admitted':admitted,'unmatched':[f for f in fs if not proofs[f['path']]],'counts':{'admitted':len(admitted),'unmatched':len(fs)-len(admitted)}};q=P/'runtime-audit-role-beforeimage-joins.json';q.write_text(json.dumps(out,separators=(',',':'))+'\n');print('BEFORE',out['counts'],H(q.read_bytes()))
