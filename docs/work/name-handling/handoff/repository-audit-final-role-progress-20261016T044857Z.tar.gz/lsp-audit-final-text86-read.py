from pathlib import Path
import json,sys
R=Path(__file__).parent;j=json.loads((R/'audit-lsp-final-authored-text-remainder-reservation.json').read_bytes());p=json.loads((R/'lsp-audit-final-text86-progress.json').read_bytes());c=p['chunks'][int(sys.argv[1])]
for q in c['ranges']:
 x=j['files'][q['file_index']];print('\nFILE',q['file_index'],x['path'])
 for n,l in enumerate(Path(x['aid']).read_text().splitlines(),1):
  if q['start_line']<=n<=q['end_line']:print(f'{n}: {l}')
