import json,datetime,collections,re,hashlib
from pathlib import Path
P=Path('/workspace/name-session/full-consumer-audit');d=json.load(open(P/'compiler-consumers.json'));cov={x['path']:x for x in json.load(open(P/'compiler-file-coverage.json'))['rows']};by={x['key']:x for x in d['rows']};w=json.load(open(P/'compiler-migration-unit-decisions-wave1.json'));q=json.load(open(P/'compiler-required-boundary-reconciliation-queue.json'))['rows'];f=json.load(open(P/'compiler-required-boundary-family-decisions.json'));fp={x['original_row_id']:x for x in f['rows']};native=json.load(open(P/'compiler-cross-owner-required-native-facets.json'));sourcefacets=json.load(open(P/'compiler-cross-owner-required-source-facets.json'));units=[];mapping={};sourcecache={}
def lines(p):
 if p not in sourcecache:sourcecache[p]=(P/'compiler-baseline'/p).read_text().splitlines()
 return sourcecache[p]
def site(p,line,symbol):
 ss=lines(p);assert 1<=line<=len(ss),(p,line,len(ss));return dict(path=p,line=line,symbol=symbol,source_sha256=cov[p]['source_sha256'],git_blob=cov[p]['git_blob'],source_line=ss[line-1])
def enrich_sites(u,rows):
 sites=u['code_change_sites'];seen={(x['path'],x['line']) for x in sites}
 for r in rows:
  if (r['path'],r['line']) not in seen:sites.append(site(r['path'],r['line'],r['symbol']));seen.add((r['path'],r['line']))
  # Mechanical declaration location for actual functions already explicitly named by the reviewed purpose. Not another counted consumer.
  names=set(re.findall(r'\b[a-z_][a-z_0-9]+\b',r['symbol']))-{'new','apply','capture','run','get','calls','children','report','context','for_module'}
  for name in names:
   found=[i+1 for i,s in enumerate(lines(r['path'])) if re.search(r'\bfn\s+'+re.escape(name)+r'\s*(?:<|\()',s)]
   if found:
    at=min(found,key=lambda n:abs(n-r['line']))
    if (r['path'],at) not in seen:sites.append(site(r['path'],at,name));seen.add((r['path'],at))
 for i,s in enumerate(sites):
  sites[i]={**site(s['path'],s['line'],s.get('symbol',u['purpose'])),**s}
 u['code_change_sites']=sorted(sites,key=lambda x:(x['path'],x['line']))
def keep(u):
 assert not any(x['id']==u['id'] for x in units),u['id']
 for k in u['original_row_ids']:
  assert k not in mapping,(k,mapping.get(k),u['id']);mapping[k]=u['id']
 units.append(u)
for original in w['units']:
 u=dict(original);u['aliases']=[]
 matched=next((x for x in native['units'] if x['family_id']==u['family_id']),None)
 if matched and matched['id']!=u['id']:u['aliases'].append(u['id']);u['id']=matched['id']
 enrich_sites(u,[by[k] for k in u['original_row_ids']]);keep(u)
parents={i:i for i in range(len(q))}
for merge in f['merges']:
 first=merge['indices'][0]
 for index in merge['indices']:parents[index]=first
skip={x['index'] for x in f['dependency_only']}
for i,r in enumerate(q):
 if i in skip or parents[i]!=i:continue
 members=[q[j] for j in range(len(q)) if parents[j]==i];plan=fp[r['key']];fam=plan['family_id'];uid='compiler.'+fam+':'+str(r['line']);same=next((x for x in units if x['id']==uid),None)
 if same:uid+=':'+r['path'].rsplit('/',1)[-1].removesuffix('.rs')
 nativeowner=next((x for x in native['units'] if x['family_id']==fam),None)
 if nativeowner:uid=nativeowner['id']
 kinds=plan['work_kind'];changeclass='owner_extension' if kinds=='shared_owner_repair' else 'metadata/schema_repair' if kinds=='metadata_schema_repair' else 'existing_api_adoption'
 u=dict(id=uid,aliases=[],original_row_ids=[x['key'] for x in members],family_id=fam,work_kind=kinds,change_class=changeclass,effort=plan['effort'],code_change_sites=[],purpose=r['site_purpose'],representation_and_context=r['actual_shared_api'],existing_shared_api=r['actual_shared_api'],required_change='\n'.join(dict.fromkeys(x['missing_integration'] for x in members if x.get('missing_integration'))),source_evidence=[e for x in members for e in x.get('evidence',[])],affected_callers=[e for x in members for e in x.get('affected_callers',[])],control_obligations=[e for x in members for e in x.get('control_obligations',[])],state='required_source_review_confirmed',validation='Controls unexecuted. Source establishes actual change duty, not measured semantics, successful Native execution, complete absence, edit acceptance or provider parity.')
 if not u['control_obligations']:u['control_obligations']=['Retain the actual input/source allocation/full configuration/selected original operand or receiver purpose stated in evidence; unknown/foreign/cooked/unsupported alternatives stay unavailable or conservative.', 'Validate this actual boundary with discriminating current-versus-foreign/source-role/data cases, preserving independent evaluation/observer/Normal/frame/Native/result or source-action requirements. No expected oracle answer is inferred from local code.']
 if nativeowner:u['affected_callers']+=nativeowner['affected_callers'];u['control_obligations']+=nativeowner['control_obligations']
 enrich_sites(u,members);keep(u)
for dep in f['dependency_only']:
 r=q[dep['index']];target=next(x for x in units if x['family_id']=='source.logical-variable-scope-transport');target['original_row_ids'].append(r['key']);target.setdefault('unchanged_affected_callers',[]).append(dict(path=r['path'],line=r['line'],symbol=r['symbol'],reason=dep['reason']));mapping[r['key']]=target['id']
for original in sourcefacets['units']:
 u=dict(original);u['aliases']=[];u['representation_and_context']=u['existing_shared_api'];u['change_class']='owner_extension';enrich_sites(u,[by[k] for k in u['original_row_ids']]);keep(u)
# Exact semantic alias normalization from existing key contract, only where demonstrated same actual changed boundary.
contract=json.load(open(P/'compiler-purpose-stable-key-contract.json'))
merged_aliases=[]
for group in contract['canonical_aliases']:
 actual=set(mapping[k] for k in group['members'] if k in mapping)
 if len(actual)>1:
  # Exact prior demonstrated one actual Uplevel list-builder reconstruction boundary, not merely same family.
  assert set(group['members'])==set([q[39]['key'],q[43]['key']]),group
  selected=[x for x in units if x['id'] in actual];target=next(x for x in selected if x['id']==mapping[q[43]['key']]);other=next(x for x in selected if x is not target)
  target['aliases']+=other.get('aliases',[])+[other['id']];target['original_row_ids']+=other['original_row_ids'];target['code_change_sites']+=other['code_change_sites'];target['source_evidence']+=other['source_evidence'];target['required_change']+='\n'+other['required_change'];target['same_boundary_merge_reason']=group['reason'];target['code_change_sites'].append(site('rust/tcl-compiler/src/analyser/handlers.rs',4547,'handle_uplevel_command actual list-built script guard'));units.remove(other)
  for key in other['original_row_ids']:mapping[key]=target['id']
missing=[r['key'] for r in d['rows'] if r['disposition']=='needs_migration' and r['key'] not in mapping];assert not missing,missing
rowmaps=[];validation=[];questions=[]
for r in d['rows']:
 if r['key'] in mapping:rowmaps.append(dict(original_row_id=r['key'],disposition='required_unit_or_unchanged_dependency',unit_id=mapping[r['key']]))
 elif r['disposition'] in ['pending_audit','pending_validation']:
  z=dict(original_row_id=r['key'],path=r['path'],line=r['line'],symbol=r['symbol'],purpose=r['site_purpose'],source_sha256=r['source_sha256'],question=r['missing_integration'],evidence=r.get('evidence',[]),state=r['disposition'],required_code_change_established=False);questions.append(z);rowmaps.append(dict(original_row_id=r['key'],disposition='unresolved_question',question_index=len(questions)-1))
 elif r['disposition']=='migrated_validation_pending':
  z=dict(original_row_id=r['key'],path=r['path'],line=r['line'],symbol=r['symbol'],purpose=r['site_purpose'],actual_shared_api=r['actual_shared_api'],source_sha256=r['source_sha256'],source_evidence=r.get('evidence',[]),limitations=r['missing_integration'],state='established_integration_validation_unexecuted');validation.append(z);rowmaps.append(dict(original_row_id=r['key'],disposition='validation_only',validation_index=len(validation)-1))
 else:rowmaps.append(dict(original_row_id=r['key'],disposition='no_new_code_change',actual_source_disposition=r['disposition'],reason=r.get('work_kind_reason') or r['missing_integration']))
for u in units:
 if u['work_kind']=='consumer_api_adoption':u['work_kind']='consumer_integration'
 if u['work_kind']=='metadata_schema':u['work_kind']='metadata_schema_repair'
 u.setdefault('change_class','owner_extension' if u['work_kind']=='shared_owner_repair' else 'metadata/schema_repair' if u['work_kind']=='metadata_schema_repair' else 'existing_api_adoption')
 if u['family_id']=='source.selected-list-escape-rules':u.setdefault('unchanged_affected_callers',[]).append(dict(scope='Existing source_index, const_dispatch, source_warnings, dictionary/list and selected source consumers already calling WordValueRules with full config remain unchanged owner dependencies, not extra adoptions.'))
 if u['family_id']=='source.definition-member-body-disposition':u.setdefault('required_dependencies',[]).append('Compiler linked-member129/347 actual changed adapter and frozen LSP formatting/body consumers; central disposition facet only once.')
 for s in u['code_change_sites']:assert s['source_sha256']==cov[s['path']]['source_sha256']
a=dict(baseline=d['baseline'],utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='production_source_confirmed_boundary_catalogue_semantic_alias_QA' if merged_aliases else 'production_source_confirmed_boundary_catalogue_complete_operational_annex_pending',count_contract='Actual changed integration boundary + distinct purpose. Named helper functions are changed code sites, not extra counted consumers. Owner repair once; unchanged dependents explicitly excluded. Unresolved questions and unexecuted controls are separate.',units=units,row_mapping=rowmaps,validation_only=validation,unresolved_questions=questions,semantic_alias_QA=merged_aliases,counts=dict(required_code_change_units=len(units),by_work_kind=dict(collections.Counter(x['work_kind'] for x in units)),by_change_class=dict(collections.Counter(x['change_class'] for x in units)),by_effort=dict(collections.Counter(x['effort'] for x in units)),repair_families=len(set(x['family_id'] for x in units)),distinct_changed_source_sites=len(set((s['path'],s['line']) for u in units for s in u['code_change_sites'])),original_required_rows=len(mapping),all_original_purpose_rows=len(d['rows']),validation_only_purposes=len(validation),unresolved_questions=len(questions)),limits='Whole assigned production source reviewed at exact baseline. Operational setup/provider/test-source roles and two generated parity obligations remain distinct finite audit annex, not claimed complete here. No code/tests/provider execution or semantic acceptance donated.')
t=P/'compiler-migration-units.json.tmp';t.write_text(json.dumps(a,indent=2)+'\n');t.replace(P/'compiler-migration-units.json');print(json.dumps(a['counts'],indent=2));print('semantic alias QA',json.dumps(merged_aliases,indent=2))
