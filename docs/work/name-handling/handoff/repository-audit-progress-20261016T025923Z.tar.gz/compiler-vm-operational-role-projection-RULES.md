# Operational source-role aid contract

Baseline is the exact source SHA in `compiler-exact-operational-closure-queue.json`.
The queue is a retained snapshot; its pending labels may have since been closed
by actual readers. Generating this aid does not read the source semantically or
change a coverage, classification, migration, test or provider admission.

The tool lexes complete quoted/raw/byte/character literals and nested comments,
then checks balanced Rust token groups. This is a narrow lexical/group owner,
not a Rust parser, compiler, resolver or arbitrary macro interpreter. A failed
source hash, literal or group check produces no aid admission for that file.

The first version recognizes only complete literal, negative number, boolean,
recursive tuple and array data arguments in the first two operands of a
comparison macro labelled `assert_eq!` or `assert_ne!`. Numbers and punctuation
are never projected. Calls, paths, constructors, casts, operators, field access,
indexing, blocks, closures, `vec!`, `format!`, include macros and all diagnostic
arguments remain visible. No assertion statement or function body is removed.
`assert!` and even apparent standard macros under an enclosing macro stay
visible. No arbitrary function or constructor whitelist exists.

A label alone does not establish that a macro is the standard macro. An actual
reviewer must supply a source-SHA-bound record for each exact macro byte site,
with the actual macro resolution and actual parent cfg/Cargo/context evidence.
The admission file is a reviewer input, not an independently verified compiler
macro-resolution certificate. No such admissions were supplied for the pilot.
Consequently all real source bytes remain visible; there are zero certified
omissions. Recorded candidate pure-data arguments are not completed reads.

Only after that specific source/parent contract is admitted may a complete
multiline or >256-byte literal token in such a pure-data operand be replaced by
an explicit fixed-data marker. The full immutable source token, exact byte and
line extent, SHA, parent operand SHA, and macro argument/site remain recorded.
Every original nonliteral/noncomment token must remain byte-identical and in
order; every original newline must remain. Unknown literal bodies stay visible.
Long literals outside this narrow operand grammar are inventoried with exact
extent/SHA and a lexical group/item prefix only. That prefix is not a resolved
API, an AST statement or evidence of an input-only loader contract. Their
source, provider, normalizer, constructor, path and artifact roles still require
actual caller/helper review.

The pilot and synthetic artifact-integrity controls prove only these mechanics.
The controls do not issue real source, macro, provider or execution admission.
Original C/Jim script/API inputs and their intentionally adversarial bytes are
independent oracle inputs; no expected answer may be generated from a shared
product recipe. Raw input/fixture classification, current provider/source/build
identity and complete actual control/helper reads remain separate obligations.
