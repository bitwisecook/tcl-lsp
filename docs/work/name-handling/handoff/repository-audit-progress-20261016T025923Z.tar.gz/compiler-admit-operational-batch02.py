from pathlib import Path
import json,hashlib,datetime
P=Path('/workspace/name-session/full-consumer-audit');c=json.load(open(P/'compiler-file-coverage.json'));cov={x['path']:x for x in c['rows']};b=json.load(open(P/'compiler-inline-test-operational-backlog.json'));bm={x['path']:x for x in b['rows']};idx={x['path']:x for x in json.load(open(P/'compiler-production-index.json'))};now=datetime.datetime.now(datetime.timezone.utc).isoformat();records=[]
pins={
'root-compiler-handlers-operational-part01.json':'e6293e30d0988a699c1352ccd7b5eb8455a59167354b0ca8900a6e7a1f0a0836',
'compiler-vm-handlers-operational-part02-read.json':'7020a77fd03e85dc4eeec61c867c90c3721abcefac9ce546710966433b364b33',
'compiler-vm-ssa-operational-read.json':'c42a725c52479390794ce3c43095e92daf16e0a0b789f5a229d57e06838e52cd',
'root-compiler-taint-operational-read.json':'28cdfc10a40074501c989e4307a62dacf13cfef7263ceb875cd0be904c18af7a',
'compiler-db-operational-helper-review.json':'21d2b4ea2977d99c4037eaca8e6f234ec25bf81a0c0ac80078c2b661867d84f3',
'compiler-db-operational-native-inline-review.json':'ea323d4a536d6f31c968aec872fb2633cd28b6ca128ef9e14fd0315cc6117f09',
'compiler-db-operational-fp-review.json':'8cacb93c491ec1871b4c6a60309d4440ca6d0058bcc0f0ab0153b86e31be258d',
'lsp-audit-compiler-word-geometry-operational-receipt.json':'3783bb06343f4e0ff7532ef219098afd7d075db23583e2c535fdba4535339da2',
'lsp-audit-compiler-naming-operational-receipt.json':'dd41f0dff1979c3a88bb55f56dfc38999ee415a54dd30a43b978f125f87ebd23',
'compiler-vm-operational-support-read.json':'b7359cb99ec6632e24cbea7b79aacb1485927c55cfddd4f568fc4273f0256cfb',
'compiler-vm-operational-regex-read.json':'585cd0dfe96e6eadcbf4d9138901e330d69c6c96b2b456c6ced92685e6865cd3'}
peers={}
for name,sha in pins.items():
 pp=P/name;assert hashlib.sha256(pp.read_bytes()).hexdigest()==sha,name;peers[name]=json.load(open(pp));records.append(dict(peer_receipt=name,peer_sha256=sha))
def rangeset(rs):
 out=set()
 for e in rs:
  a,z=(e.get('lines',e.get('original_line_range')) if isinstance(e,dict) else e);out.update(range(a,z+1))
 return out
def admit(path,receipts,whole=False):
 r=cov[path];assert hashlib.sha256((P/'compiler-baseline'/path).read_bytes()).hexdigest()==r['source_sha256'];r.update(review_complete=True,review_status='source_reviewed',embedded_cfg_test_operational_review_complete=True,operational_review_complete=True,operational_review_receipts=receipts,operational_review_utc=now,operational_review_limits='Actual executable Rust/setup/helpers/config/control/constructor/provider/path/admission source reviewed. Exact fixed input/expected payloads may be role-classified by source extent/SHA+actual parent operation. No execution or provider/fixture semantic acceptance.')
 r['review_mode']='whole_operational_source_role_read_fixed_payloads_classified' if whole else 'whole_production_and_all_exact_inline_operational_source_reviewed'
 if not whole:r['production_review_complete']=True
 if path in bm:
  rr=bm[path];rr.update(kind='complete_operational_source_role_review',operational_review_complete=True,receipts=receipts)
  for m in rr.get('members',[]):m.update(body_review_mode='executable_setup_and_control_source_reviewed_fixed_payload_roles_classified',operational_setup_disposition='Actual setup/custom expressions/helpers/constructors reviewed; fixed payload/assertion data exact-role classified, no test/provider execution.')
# Exact raw omission union for whole handler root/VM split.
path='rust/tcl-compiler/src/analyser/handlers.rs';rs=[]
for n in list(pins)[:2]:
 x=peers[n];assert x['path']==path and x['source_sha256']==cov[path]['source_sha256'];rs += [z['original_line_range'] for z in x['read_ranges']]
assert rangeset(rs)==rangeset(idx[path]['omitted_cfg_test_line_ranges']);admit(path,list(pins)[:2])
path='rust/tcl-compiler/src/ssa.rs';x=peers['compiler-vm-ssa-operational-read.json'];assert x['source_sha256']==cov[path]['source_sha256'];assert rangeset(z['original_line_range'] for z in x['read_ranges'])==rangeset(idx[path]['omitted_cfg_test_line_ranges']);admit(path,['compiler-vm-ssa-operational-read.json'])
x=peers['root-compiler-taint-operational-read.json'];path=x['source']['path'];assert x['source']['source_sha256']==cov[path]['source_sha256'];assert rangeset(x['original_ranges'])==rangeset(idx[path]['omitted_cfg_test_line_ranges']);admit(path,['root-compiler-taint-operational-read.json'])
for name in list(pins)[4:]:
 x=peers[name]
 for f in x['files']:
  path=f['path'];sha=f.get('source_sha256',f.get('source_sha256_before_and_after'));assert sha==cov[path]['source_sha256'],(name,path,sha)
  is_inline='actual_operational_ranges' in f
  if is_inline:assert rangeset(f['actual_operational_ranges'])==rangeset(idx[path]['omitted_cfg_test_line_ranges']),(name,path)
  admit(path,[name],whole=not is_inline)
receipt=dict(baseline=c['baseline'],utc=now,scope='Exact source-only completed operational peer batch; whole root/VM handler8261 union, SSA6555/taint6035; DB5+2+6 whole files, LSP6+19 inline ranges, VM6+8 whole external sources.',peer_receipts=records,source_files_admitted=3+5+2+6+6+19+6+8,source_role_rule='All executable setup/custom constructors/config/provider/path/artifact/currentness logic actual-read. Fixed original input/expected literal payload role classification is not a tested semantics migration or provider acceptance.',new_required_operational_duties='Actual VM support OSargv/env path and Regex2 oracle runner duties separately enter compiler-operational-migration-units annex; no automatic production count delta.',omitted_child_scope='External cfgtest submodules remain separately tracked; parent declaration never donates their source coverage.',validation='No Cargo/tests/providers/source execution.')
for n,o in [('compiler-file-coverage.json',c),('compiler-inline-test-operational-backlog.json',b),('compiler-operational-batch02-admission.json',receipt)]:
 t=P/(n+'.tmp');t.write_text(json.dumps(o,indent=2)+'\n');t.replace(P/n)
print('Admitted',receipt['source_files_admitted'],'operational source scopes; exact range unions and fixture/constructor roles retained, no execution.')
