"""Artifact-only Rust literal/group projection. Not a Rust resolver or coverage issuer.
Default has NO macro admissions: unqualified/qualified labels alone cannot prove std.
An actual reviewer may admit exact macro byte sites at exact source SHA, preserving
its parent cfg/Cargo and macro-resolution proof. Unknown/custom expressions remain.
"""
import argparse, bisect, hashlib, json, os, re
from pathlib import Path
R=Path('/workspace/name-session/full-consumer-audit')
PFX='compiler-vm-operational-role-projection'
def digest(b):return hashlib.sha256(b).hexdigest()
def atom(p,b):
 p.parent.mkdir(parents=True,exist_ok=True);t=p.with_name(p.name+'.tmp');t.write_bytes(b);os.replace(t,p)
def js(p,x):atom(p,(json.dumps(x,indent=2)+'\n').encode())
def lex(b):
 t=[];i=0;n=len(b)
 while i<n:
  a=i;c=b[i]
  if c in b' \t\r\n':i+=1;continue
  if b.startswith(b'//',i):
   j=b.find(b'\n',i);i=n if j<0 else j;t.append(('comment',a,i));continue
  if b.startswith(b'/*',i):
   i+=2;depth=1
   while i<n and depth:
    if b.startswith(b'/*',i):depth+=1;i+=2
    elif b.startswith(b'*/',i):depth-=1;i+=2
    else:i+=1
   if depth:raise ValueError(('unclosed block comment',a))
   t.append(('comment',a,i));continue
  m=re.match(rb'(?:br|cr|r)(#*)"',b[i:])
  if m:
   close=b'"'+m[1];j=b.find(close,i+len(m[0]))
   if j<0:raise ValueError(('unclosed raw literal',a))
   i=j+len(close);t.append(('literal',a,i));continue
  m=re.match(rb'(?:b|c)?"',b[i:])
  if m:
   i+=len(m[0]);closed=False
   while i<n:
    if b[i]==92:i+=2
    elif b[i]==34:i+=1;closed=True;break
    else:i+=1
   if not closed:raise ValueError(('unclosed quoted literal',a))
   t.append(('literal',a,i));continue
  # Character literals vs lifetimes; exact one scalar/escape + closer only.
  m=re.match(rb"(?:b)?'(?:[^'\\\r\n]|[\xc2-\xf4][\x80-\xbf]{1,3}|\\(?:[nrt0\\\"']|x[0-9a-fA-F]{2}|u\{[0-9a-fA-F_]+\}))'",b[i:])
  if m:
   token=m[0]
   try:
    z=token[(2 if token.startswith(b"b'") else 1):-1]
    if not z.startswith(b'\\') and len(z.decode('utf8'))!=1:m=None
   except UnicodeDecodeError:m=None
  if m:i+=len(m[0]);t.append(('literal',a,i));continue
  if c in b'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_' or c>=128:
   i+=1
   while i<n and(b[i]in b'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_0123456789' or b[i]>=128):i+=1
   t.append(('ident',a,i));continue
  if c in b'0123456789':
   i+=1
   while i<n and b[i]in b'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_0123456789.':i+=1
   t.append(('number',a,i));continue
  if b.startswith(b'::',i):i+=2;t.append(('punct',a,i));continue
  i+=1;t.append(('punct',a,i))
 return t

def token_text(b,t):return b[t[1]:t[2]]
def groups(b,ts):
 pairs={b'(':b')',b'[':b']',b'{':b'}'};stack=[];matches={}
 for k,t in enumerate(ts):
  s=token_text(b,t)
  if s in pairs:stack.append((k,pairs[s]))
  elif s in(b')',b']',b'}'):
   if not stack or stack[-1][1]!=s:raise ValueError(('unbalanced group',t[1]))
   a,_=stack.pop();matches[a]=k
 if stack:raise ValueError(('unclosed group',ts[stack[-1][0]][1]))
 return matches

def args(b,ts,g,a,z):
 out=[];start=a;i=a
 while i<z:
  if i in g:i=g[i]+1;continue
  if token_text(b,ts[i])==b',':
   if start<i:out.append((start,i))
   elif i!=z-1:return None
   start=i+1
  i+=1
 if start<z:out.append((start,z))
 return out

def pure_data(b,ts,g,a,z):
 """Recognize only constant literals, signed numbers, recursively pure tuples/arrays.
 No paths/ident constants/structs/constructors, casts, operators, indexing,
 closures, format/include/custom macros or arbitrary calls. vec! not admitted:
 even a label matching vec can be shadowed. Empty tuple/array are pure data.
 """
 if a>=z:return False
 if z-a==1:return ts[a][0]in('literal','number') or token_text(b,ts[a])in(b'true',b'false')
 if z-a==2 and token_text(b,ts[a])==b'-' and ts[a+1][0]=='number':return True
 if token_text(b,ts[a])in(b'(',b'[') and g.get(a)==z-1:
  inner=args(b,ts,g,a+1,z-1)
  return inner is not None and all(pure_data(b,ts,g,u,v)for u,v in inner)
 return False

def line_of(starts,p):return bisect.bisect_right(starts,p)
def whole_ranges(row,b):
 return row.get('raw_omitted_ranges',[[1,len(b.splitlines())]])
def in_scope(starts,a,z,ranges):
 la,lz=line_of(starts,a),line_of(starts,max(a,z-1))
 return any(x<=la and lz<=y for x,y in ranges)
def selected_admissions(admit,path,sha):
 x=admit.get(path,{})
 if not x:return {}
 if x.get('source_sha256')!=sha:raise ValueError(('admission source mismatch',path))
 sites={}
 for q in x.get('sites',[]):
  assert q.get('actual_macro_resolution_proof') and q.get('parent_context_proof') and q.get('reviewer')
  assert q['macro'] in('assert_eq','assert_ne')
  sites[q['macro_start_byte']]=q
 return sites

def project(row,admit,outdir):
 b=Path(row['source']).read_bytes();sh=digest(b)
 if sh!=row['source_sha256']:raise ValueError(('pinned source mismatch',row['path']))
 starts=[0]+[m.end()for m in re.finditer(b'\n',b)]
 raw=lex(b);ts=[q for q in raw if q[0]!='comment'];g=groups(b,ts);ranges=whole_ranges(row,b);admitted=selected_admissions(admit,row['path'],sh)
 candidates=[];unknowns=[];repls=[];literal_parents={};macro_sites=[];data_arguments=[]
 parents={};stack=[]
 for k,t in enumerate(ts):
  parents[k]=stack[-1]if stack else None
  if k in g:stack.append(k)
  elif stack and g[stack[-1]]==k:stack.pop()
 def context(k):
  op=parents[k];start=0 if op is None else op+1;end=len(ts)if op is None else g[op];same=[j for j in range(start,end)if parents[j]==op and token_text(b,ts[j])in(b';',b',')]
  left=max([j+1 for j in same if j<k],default=start);right=min([j+1 for j in same if j>=k],default=end)
  a=ts[left][1]if left<len(ts)else ts[k][1];z=ts[right-1][2]if right>left else ts[k][2]
  prefix=b[a:ts[k][1]][-160:].decode('utf8',errors='replace')
  return {'classification':'lexical_group_item_only_not_resolved_API_or_Rust_AST','byte_range':[a,z],'sha256':digest(b[a:z]),'prefix_preview':prefix,'group_open_byte':ts[op][1]if op is not None else None}
 intervals=[(tt[1],ts[g[k+2]][2])for k,tt in enumerate(ts)if tt[0]=='ident'and k+2<len(ts)and token_text(b,ts[k+1])==b'!'and k+2 in g]
 for i,t in enumerate(ts):
  word=token_text(b,t)
  if t[0]!='ident' or i+2>=len(ts) or token_text(b,ts[i+1])!=b'!' or i+2 not in g:continue
  a=i+2;z=g[a];ma=t[1];mz=ts[z][2]
  if not in_scope(starts,ma,mz,ranges):continue
  aa=args(b,ts,g,a+1,z);ms={'name':word.decode('utf8'),'macro_start_byte':ma,'byte_range':[ma,mz],'line_range':[line_of(starts,ma),line_of(starts,mz-1)],'sha256':digest(b[ma:mz])};macro_sites.append(ms)
  if word not in(b'assert_eq',b'assert_ne'):
   unknowns.append({**ms,'reason':'not a purpose-admitted standard comparison macro; entire macro and literals retained'})
   continue
  contract=admitted.get(ma)
  if any(u<ma and mz<v for u,v in intervals):contract=None
  if contract and contract['macro']!=word.decode():raise ValueError(('admission macro mismatch',ma))
  if aa is None or len(aa)<2:
   unknowns.append({**ms,'reason':'unavailable macro argument geometry; retained'});continue
  for ordinal,(u,v)in enumerate(aa):
   expr=b[ts[u][1]:ts[v-1][2]]
   for k in range(u,v):
    if ts[k][0]=='literal':literal_parents.setdefault(ts[k][1],[]).append({'macro':word.decode(),'argument':ordinal,'macro_start_byte':ma,'pure_data_argument':pure_data(b,ts,g,u,v)})
   if ordinal>=2 or not pure_data(b,ts,g,u,v):
    unknowns.append({'macro_start_byte':ma,'argument':ordinal,'byte_range':[ts[u][1],ts[v-1][2]],'line_range':[line_of(starts,ts[u][1]),line_of(starts,ts[v-1][2]-1)],'reason':'format/diagnostic argument or executable/unknown expression; all original bytes retained'})
    continue
   data_arguments.append({'macro_start_byte':ma,'argument':ordinal,'byte_range':[ts[u][1],ts[v-1][2]],'bytes':len(expr),'sha256':digest(expr),'macro_contract_admitted':bool(contract),'grammar':'recursive pure literal/tuple/array only; no executable expressions'})
   # Replace only entire literal tokens, never punctuation/code/data aggregate.
   for k in range(u,v):
    lt=ts[k]
    if lt[0]!='literal':continue
    la,lz=lt[1:];lb=b[la:lz]
    if len(lb)<=256 and b'\n'not in lb:continue
    entry={'id':len(candidates)+1,'byte_range':[la,lz],'line_range':[line_of(starts,la),line_of(starts,lz-1)],'sha256':digest(lb),'bytes':len(lb),'macro':word.decode(),'macro_start_byte':ma,'argument':ordinal,'parent_argument_range':[ts[u][1],ts[v-1][2]],'parent_argument_sha256':digest(expr),'grammar':'complete literal token within recursively pure tuple/array/literal comparison operand; no calls/constructors/macros/casts/operators','role':'fixed Rust comparison operand data; not provider, source, execution or naming admission','macro_contract_status':'actual_review_admitted'if contract else'pending_macro_resolution_and_parent_context','projected':bool(contract)}
    candidates.append(entry)
    if contract:
     marker=('/* FIXED_COMPARISON_DATA id='+str(entry['id'])+' bytes='+str(len(lb))+' sha256='+digest(lb)+' */').encode()+b'\n'*lb.count(b'\n')
     repls.append((la,lz,marker))
 # Reject overlap; nested unknown macros are never pure-data, but verify explicitly.
 repls.sort();assert all(repls[i-1][1]<=repls[i][0]for i in range(1,len(repls)))
 parts=[];pos=0
 for a,z,marker in repls:parts.extend([b[pos:a],marker]);pos=z
 parts.append(b[pos:]);projected=b''.join(parts)
 # Every nonliteral/noncomment Rust token must remain byte-identical and ordered.
 before=[b[q[1]:q[2]]for q in raw if q[0]not in('literal','comment')]
 after=[projected[q[1]:q[2]]for q in lex(projected)if q[0]not in('literal','comment')]
 assert before==after,'executable/control token preservation failed'
 assert b.count(b'\n')==projected.count(b'\n'),'source line geometry changed'
 # All long/multiline unprojected literal bodies remain visible with parent known/unknown.
 literals=[];projected_ranges={tuple(q['byte_range'])for q in candidates if q['projected']}
 for t in raw:
  if t[0]!='literal' or not in_scope(starts,t[1],t[2],ranges):continue
  a,z=t[1:];lb=b[a:z]
  if len(lb)<=256 and b'\n'not in lb:continue
  if(a,z)in projected_ranges:continue
  literals.append({'byte_range':[a,z],'line_range':[line_of(starts,a),line_of(starts,z-1)],'bytes':len(lb),'sha256':digest(lb),'known_parent_macro_operands':literal_parents.get(a,[]),'lexical_parent_item':context(ts.index(t)),'status':'retained_visible_candidate_fixed_literal_only; actual input/loader/helper/source/provider role pending review'})
 # Write exact operational interval aid, line geometry retained, no production gaps relabelled.
 pls=projected.splitlines(keepends=True);aid=b''
 for a,z in ranges:
  aid+=('/* ORIGINAL_SOURCE_RANGE '+str(a)+'..'+str(z)+' */\n').encode()
  aid+=b''.join(str(j+1).encode()+b': '+pls[j]for j in range(a-1,min(z,len(pls))))
 ap=outdir/row['path'];atom(ap,aid)
 manifest={'path':row['path'],'source_sha256':sh,'git_blob':row.get('git_blob'),'queue_role':row['kind'],'original_operational_ranges':ranges,'source_bytes':len(b),'source_operational_lines':sum(z-a+1 for a,z in ranges),'aid':{'path':str(ap.relative_to(R)),'sha256':digest(aid)},'projected_source_sha256':digest(projected),'projected_literal_tokens':sum(q['projected']for q in candidates),'projected_literal_bytes':sum(q['bytes']for q in candidates if q['projected']),'pure_data_macro_argument_candidates':data_arguments,'candidate_comparison_data_tokens':candidates,'retained_long_literal_candidates':literals,'retained_unknown_macro_or_executable_arguments':unknowns,'all_operational_macro_sites':macro_sites,'integrity':{'all_nonliteral_noncomment_tokens_identical':True,'all_original_line_breaks_retained':True,'all_unknown_literal_bodies_visible':True},'coverage_complete':False,'source_actually_read':False,'execution':False}
 js(ap.with_name(ap.name+'.manifest.json'),manifest)
 return manifest

def main():
 pa=argparse.ArgumentParser();pa.add_argument('--limit',type=int,default=10);pa.add_argument('--admissions');a=pa.parse_args()
 qp=R/'compiler-exact-operational-closure-queue.json';qb=qp.read_bytes();q=json.loads(qb);admit=json.load(open(a.admissions))if a.admissions else{}
 rows=sorted(q['rows'],key=lambda z:z.get('raw_omitted_line_count',z.get('whole_raw_line_count',0)),reverse=True)[:a.limit if a.limit else None]
 outdir=R/(PFX+'-aids');results=[];fail=[]
 for row in rows:
  try:results.append(project(row,admit,outdir))
  except Exception as e:fail.append({'path':row['path'],'source_sha256':row['source_sha256'],'failure':repr(e),'status':'no aid role/admission issued; retain raw original source'})
 manifest={'baseline':q['baseline'],'queue':{'path':qp.name,'sha256':digest(qb),'recorded_utc':q.get('utc'),'scope':'Immutable queue snapshot only; admission may have progressed elsewhere, no coverage freshness inferred.'},'tool_sha256':digest(Path(__file__).read_bytes()),'phase':'pilot'+str(a.limit),'admissions':{'path':a.admissions,'sha256':digest(Path(a.admissions).read_bytes())if a.admissions else None},'files':results,'fail_closed_files':fail,'summary':{'selected_files':len(rows),'aids_generated':len(results),'fail_closed_files':len(fail),'operational_lines':sum(z['source_operational_lines']for z in results),'candidate_data_tokens':sum(len(z['candidate_comparison_data_tokens'])for z in results),'pure_data_argument_candidates':sum(len(z['pure_data_macro_argument_candidates'])for z in results),'certified_projected_literal_tokens':sum(z['projected_literal_tokens']for z in results),'certified_projected_literal_bytes':sum(z['projected_literal_bytes']for z in results),'retained_long_literal_candidates':sum(len(z['retained_long_literal_candidates'])for z in results),'coverage_promotions':0},'scope':'Artifact-only lexical/group/proof aid, never manual source read, macro resolution, source coverage, migration verification or execution. Every original Rust call/control/helper/provider/config/path/artifact/unknown expression retained; no whole assertion body is removed.'}
 js(R/(PFX+'-pilot-manifest.json'),manifest);print(json.dumps(manifest['summary']))
if __name__=='__main__':main()
