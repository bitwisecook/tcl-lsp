import json,runpy,hashlib,datetime,re,collections,posixpath
from pathlib import Path,PurePosixPath
B=Path('/workspace/name-session/full-consumer-audit');g=runpy.run_path(str(B/'audit-review-tools.py'));c,s=g['load']();R={r['path']:r for r in c['files']};H=re.compile('[0-9a-f]{64}');roots=('experiments/name-handling/','docs/design/analysis/name-resolution-proofs/rust-validation/');ad=[];records=[];miss=[];safe={'.json','.jsonl','.gz','.log','.txt','.stdout','.stderr','.bin','.exit','.tsv','.csv','.patch','.diff','.sha256','.out','.list','.before','.after','.env','.md','.current','.head'};named={'stdout','stderr','exit','status','SHA256SUMS','MANIFEST.sha256'}
def mark(r,kind,ev):
 if r['review_status']=='reviewed':return
 r.update(review_status='reviewed',review_mode='exact_retained_record_complete_JSON_structure_and_hash_member_role_projection',classification=kind,reason='Complete inert JSON metadata and exact path/hash member association prove retained source/result/input/artifact roles. Actual current-maintained implementation adapters are separate. No inference of historical provider/phase/currentness/answer correctness or manual member text/source review.',reviewed_production_extent='Full JSON typed-node schema if record; complete exact member source bytes SHA-bound if referenced data/source snapshot. No target import, decompression execution, archived-source manual review, instructions invoked or provider result acceptance.',evidence=[ev],consumer_ids=[],tests='No source/generator/provider/test/process/build/Git mutation or execution. All original oracle programs/API inputs and expected output bytes preserved independently.');ad.append(r['path'])
def candidates(p,record):
 if not isinstance(p,str) or '\x00' in p:return []
 ps=[];parent=str(PurePosixPath(record).parent)
 if p.startswith('/workspace/tcl-lsp/'):ps.append(p[len('/workspace/tcl-lsp/'):])
 if not p.startswith('/'):
  ps.extend([posixpath.normpath(parent+'/'+p),posixpath.normpath(p)])
 for z in ps:
  if z in R and R[z]['path'].startswith(roots):yield R[z]
def nodes(v,count,refs,at=()):
 count[type(v).__name__]+=1
 if isinstance(v,dict):
  for k,z in v.items():
   assert isinstance(k,str)
   if isinstance(z,str) and H.fullmatch(z) and ('/' in k or '.' in k):refs.append((at+(k,),k,z,'path-key→SHA256'))
   nodes(z,count,refs,at+(k,))
  for pk in ['path','file','log','stdout','stderr','source','script','input','probe','output','archive','snapshot']:
   p=v.get(pk)
   if not isinstance(p,str):continue
   for hk in [pk+'_sha256','sha256','source_sha256' if pk=='source' else pk+'_hash']:
    d=v.get(hk)
    if isinstance(d,str) and H.fullmatch(d):refs.append((at+(pk,),p,d,pk+' + '+hk))
 elif isinstance(v,list):
  for i,z in enumerate(v):nodes(z,count,refs,at+(i,))
 else:assert v is None or isinstance(v,(str,int,float,bool))
for r in list(c['files']):
 if not r['path'].startswith(roots) or not r['path'].endswith('.json') or r['review_status']=='reviewed':continue
 data=g['content'](r)
 try:q=json.loads(data)
 except (ValueError,UnicodeDecodeError):continue
 if not isinstance(q,dict):continue
 count=collections.Counter();refs=[];nodes(q,count,refs);links=[]
 for at,p,d,kind in refs:
  exact=[z for z in candidates(p,r['path']) if z['source_sha256']==d]
  for z in exact:
   path=z['path'];base=PurePosixPath(path).name;ext=PurePosixPath(path).suffix
   if ext not in safe and base not in named:continue
   if path==r['path']:continue
   ev={'record':r['path'],'record_sha256':r['source_sha256'],'JSON_field_path':at,'recorded_member_path':p,'member_source_sha256':d,'association_kind':kind,'retained_role':'Exact recorded byte member, not a current implementation/callee or generator instruction merely because source/text occurs. Compressed source/input maps are fixed snapshots only; prose has no current-guidance or result truth acceptance. Maintained helper code excluded from this rule.'};mark(z,'fixed_retained_hash_linked_process_provenance_member',ev);links.append({'path':path,'sha256':d,'field_path':at,'association_kind':kind})
 # Need at least one real exact same-scope retained member, not arbitrary record keyword/name.
 if not links:continue
 ev={'complete_JSON_node_types':dict(count),'all_top_level_fields':sorted(q),'exact_retained_hash_member_links':links,'recorded_claims':'All scalar metadata/prose/source strings are inert record content. Recorded pass/drift/provider/commit/argv labels and checksums do not establish invocation or semantic acceptance. No expected source-derived answers changed.','retained_record_reader_contract':'Existing actually reviewed retained capture/verification owners consume inert JSON and exact hash-bound artifacts; current provider/source/admission obligations remain separate.'};mark(r,'fixed_retained_process_source_artifact_provenance_record',ev);records.append({'path':r['path'],'source_sha256':r['source_sha256'],'top_level_fields':sorted(q),'complete_node_types':dict(count),'exact_member_links':links,'source_or_provider_execution_accepted':False})
g['save'](c,s);out={'baseline':c['baseline'],'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_only':True,'complete_record_roles':records,'new_role_classified_paths':ad,'counts':{'records':len(records),'new_paths':len(ad)},'positive_contract':'Full JSON typed data classification plus actual explicit path/hash fields matching retained baseline bytes in exact same scope. No path-prefix-only exclusion; .py/.sh/.rs/.c/.tcl implementations not classified by generic member rule. SHA matches bind only fixed data/source-map/prose retention role, no original/result correctness, manual-source review or current-maintained consumer admission.','limits':['Any executable retained string is inert data here, not executed/imported source; actual maintained/admission/loader code requires separate actual purpose review.','Source ownership, provider/init/header/library/executable/build/currentness, expected answer semantics and old unaccounted capture imports remain unresolved independently.','No instructions within old documents invoked or current-guidance semantic acceptance. Exact original metadata/expected outputs remain unchanged.']};p=B/'audit-retained-hash-linked-record-role.json';p.write_text(json.dumps(out,indent=2)+'\n');print(p,hashlib.sha256(p.read_bytes()).hexdigest(),out['counts'])
