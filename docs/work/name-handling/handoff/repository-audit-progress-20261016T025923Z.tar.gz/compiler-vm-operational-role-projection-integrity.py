import importlib.util,json,hashlib
from pathlib import Path
R=Path('/workspace/name-session/full-consumer-audit');p=R/'compiler-vm-operational-role-projection-tool.py';sp=importlib.util.spec_from_file_location('projection',p);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
# Trusted finite artifact-tool controls only, not repository Rust tests or source admission.
long='original fixed data '*25
text='''fn control() {
 assert_eq!(callback(construct(getter("live"))), r##"'''+long+'''\nfixture"##);
 assert_eq!(left, (r#"'''+long+'''"#, [b"'''+long+'''", "short"]));
 assert_eq!(foo(), vec![r#"'''+long+'''"#]);
 assert_eq!(foo(), Value::from_bytes(r#"'''+long+'''"#));
 custom! { assert_eq!(left, r#"'''+long+'''"#); }
 assert_eq!(foo(), format!(r#"{}'''+long+'''"#, callback()));
 let source = r#"'''+long+'''"#; run_provider(source);
 // foo! { "comment (" }
 let unicode = 'é'; let label = 'x';
}
'''
b=text.encode();q=R/'compiler-vm-operational-role-projection-control.rs.txt';q.write_bytes(b);row={'path':q.name,'source':str(q),'source_sha256':m.digest(b),'git_blob':None,'kind':'trusted_artifact_tool_integrity_control','raw_omitted_ranges':[[1,len(b.splitlines())]]};out=R/'compiler-vm-operational-role-projection-controls'
default=m.project(row,{},out);assert default['projected_literal_tokens']==0
lex=[z for z in m.lex(b)if z[0]!='comment'];sites=[t[1]for i,t in enumerate(lex)if m.token_text(b,t)==b'assert_eq'and m.token_text(b,lex[i+1])==b'!']
assert len(sites)==6
admit={q.name:{'source_sha256':m.digest(b),'sites':[{'macro_start_byte':n,'macro':'assert_eq','actual_macro_resolution_proof':'synthetic artifact-control input, not real source admission','parent_context_proof':'synthetic control only','reviewer':'artifact-tool-integrity-control'}for n in sites]}}
actual=m.project(row,admit,out);assert actual['projected_literal_tokens']==3
assert all(z['macro_start_byte']in sites[:2]for z in actual['candidate_comparison_data_tokens']if z['projected'])
# First real getter expression, vec!/Value/format constructors, nested custom
# macro and standalone source/provider literal stay byte-for-byte visible.
assert len(actual['retained_long_literal_candidates'])==5
bad={q.name:{'source_sha256':'0'*64,'sites':[]}}
try:m.project(row,bad,out);raise AssertionError('wrong source admission accepted')
except ValueError:pass
try:m.groups(b'fn x(){',m.lex(b'fn x(){'));raise AssertionError('unclosed syntax accepted')
except ValueError:pass
receipt={'tool':{'path':p.name,'sha256':m.digest(p.read_bytes())},'control_source':{'path':q.name,'sha256':m.digest(b)},'default_no_macro_contract_projected_tokens':0,'explicit_control_admission_projected_pure_literal_tokens':3,'all_custom_constructor_getter_format_provider_and_nested_macro_literal_tokens_retained':True,'retained_long_literal_tokens':5,'wrong_source_admission_refused':True,'unbalanced_token_tree_refused':True,'line_breaks_and_all_executable_tokens_preserved':True,'scope':'Only execution of newly authored trusted artifact lex/group transform on finite synthetic controls. No repository Rust tests, original script/provider, source coverage or macro-resolution admission.'}
m.js(R/'compiler-vm-operational-role-projection-integrity.json',receipt);print(json.dumps(receipt))
