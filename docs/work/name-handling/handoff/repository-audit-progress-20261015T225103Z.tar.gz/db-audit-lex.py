from pathlib import Path
import re,json,collections
OUT=Path('/workspace/name-session/full-consumer-audit'); SNAP=OUT/'db-baseline'
def mask(s):
 o=list(s);n=len(s);i=0
 def blank(a,b):
  for j in range(a,b):
   if o[j]!='\n':o[j]=' '
 while i<n:
  if s.startswith('//',i):
   e=s.find('\n',i);e=n if e<0 else e;blank(i,e);i=e;continue
  if s.startswith('/*',i):
   a=i;i+=2;depth=1
   while i<n and depth:
    if s.startswith('/*',i):depth+=1;i+=2
    elif s.startswith('*/',i):depth-=1;i+=2
    else:i+=1
   blank(a,i);continue
  m=re.compile(r'(?:br|cr|r)(#*)"').match(s,i)
  if m:
   a=i;close='"'+m.group(1);e=s.find(close,m.end());i=n if e<0 else e+len(close);blank(a,i);continue
  if s[i]=='"':
   a=i;i+=1
   while i<n:
    if s[i]=='\\':i+=2
    elif s[i]=='"':i+=1;break
    else:i+=1
   blank(a,min(i,n));continue
  if s[i]=="'":
   m=re.compile(r"'(?:\\(?:u\{[^}]+\}|x..|.)|[^'\n\\])'").match(s,i)
   if m:blank(i,m.end());i=m.end();continue
  i+=1
 return ''.join(o)
def item_end(masked,start):
 b=masked.find('{',start);e=masked.find(';',start)
 if e>=0 and (b<0 or e<b):return e+1
 if b<0:return len(masked)
 depth=1;i=b+1
 while i<len(masked) and depth:
  if masked[i]=='{':depth+=1
  elif masked[i]=='}':depth-=1
  i+=1
 return i
def production(s):
 m=mask(s);ranges=[]
 for a in re.finditer(r'#\[\s*(?:cfg\(\s*(?:test\b|all\(\s*test\b)[^\]]*\)|test)\s*\]',m):
  ranges.append((a.start(),item_end(m,a.end())))
 for a,b in sorted(ranges,reverse=True):s=s[:a]+''.join('\n' if c=='\n' else ' ' for c in s[a:b])+s[b:]
 return s
if __name__=='__main__':
 coverage=json.loads((OUT/'db-file-coverage.json').read_text());queue=[];metadata=[]
 for row in coverage['files']:
  if row['review_status']!='unexamined':continue
  p=SNAP/row['path'];s=p.read_text(errors='replace');prod=production(s) if p.suffix=='.rs' else s;masked=mask(prod) if p.suffix=='.rs' else prod
  q=OUT/'db-production'/row['path'];q.parent.mkdir(parents=True,exist_ok=True);q.write_text(prod)
  functions=re.findall(r'\bfn\s+(\w+)',masked)
  forbidden=re.findall(r'\b(?:if|match|for|while|loop|let|unsafe)\b|(?:format|concat)!|\.\s*(?:replace|trim\w*|split\w*|strip\w*|to_lowercase|to_uppercase)\s*\(',masked)
  pure=row['path'].startswith('rust/tcl-registry/src/commands/') and set(functions)<= {'spec','specs','subcommands'} and not forbidden and not re.search(r'=>|\|[^|\n]*\|',masked)
  if pure:
   fields=collections.Counter(re.findall(r'\b([A-Za-z_]\w*)\s*:',masked)); fields={k:v for k,v in fields.items() if k not in ['crate','self','super','std','tcl_dialect','tcl_registry']}
   names=re.findall(r'\bname:\s*"((?:\\.|[^"\\])*)"',prod)
   metadata.append({'path':row['path'],'source_sha256':row['source_sha256'],'functions':functions,'fields':fields,'literal_names':names,'production_lines':len(prod.splitlines()),'method':'complete production token/schema enumeration; no imperative/control/closure or text-normalization token outside literals/comments; metadata constructors only'})
   row.update(review_mode='full_declarative_schema_inspection',review_status='reviewed',classification='registry_declarative_metadata',justification='Complete fixed-metadata production token/schema enumeration retained in db-metadata-inventory.json. No executable consumer-local name transformation/lookup; selected registry/availability semantics and runtime backing owners require independent source review. Static registered names do not grant Native lookup or dispatch.')
  else:queue.append({'path':row['path'],'bytes':row['bytes'],'production_bytes':len(prod.encode()),'functions':functions,'classification':row['classification']})
 (OUT/'db-metadata-inventory.json').write_text(json.dumps({'baseline':coverage['baseline'],'metadata':metadata},indent=2)+'\n')
 (OUT/'db-review-queue.json').write_text(json.dumps({'baseline':coverage['baseline'],'files':queue},indent=2)+'\n')
 (OUT/'db-file-coverage.json').write_text(json.dumps(coverage,indent=2)+'\n')
 print(json.dumps({'metadata_inspected':len(metadata),'remaining_files':len(queue),'remaining_bytes':sum(x['production_bytes'] for x in queue)}))
