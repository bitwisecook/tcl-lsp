exec(open('/workspace/name-session/full-consumer-audit/compiler-record-optimiser-source.py').read().split("root='rust/tcl-compiler/src/'")[0])
import hashlib
peer=json.load(open(P/'root-compiler-small-packet-peer.json'));assert peer['baseline']=='cc24c394004fc187378ba0eefb6c2c5b2615fb00'
checked=[]
for f in peer['files']:
 path=f['path'];r=next(x for x in c['rows']if x['path']==path)
 assert hashlib.sha256((P/'compiler-baseline'/path).read_bytes()).hexdigest()==r['source_sha256']==f['source_sha256']
 assert hashlib.sha256((P/'compiler-production'/path).read_bytes()).hexdigest()==f['aid_sha256']
 assert len((P/'compiler-production'/path).read_text().splitlines())==f['aid_lines']
 r.update(review_status='production_reviewed_inline_tests_pending',production_review_complete=True,review_complete=False,review_mode='full_production_source_read_by_root_peer_exact_hash_receipt',classification='source_purpose_consumer_reviewed',justification='Disjoint Root full production read, all original/aid hashes independently verified on admission. Actual caller/owner qualification retained per purpose; omitted test/setup operations unfinished.',peer_review_receipt='root-compiler-small-packet-peer.json',peer_read_aid_line_ranges=f['actual_read_aid_line_ranges'],embedded_cfg_test_operational_review_complete=False,reviewed_utc=now)
 checked.append(path)
for f in peer['targeted_caller_and_owner_reads']:
 assert hashlib.sha256((P/'compiler-baseline'/f['path']).read_bytes()).hexdigest()==f['source_sha256']
 r=next(x for x in c['rows']if x['path']==f['path']);r.setdefault('supplemental_root_peer_reads',[]).append(dict(receipt='root-compiler-small-packet-peer.json',source_sha256=f['source_sha256'],ranges=f['actual_targeted_read_ranges']))
 # Targeted reads cannot close whole production or test source.
 if r.get('review_status')=='unexamined':r.update(review_status='partial_remainder_unexamined',review_complete=False,production_review_complete=False,review_mode='bounded_actual_caller_trace_by_root_peer_remainder_unexamined',classification='partial_naming_consumer_trace',justification='Only hash-bound ranges in root-compiler-small-packet-peer.json actually read by Root; remainder unfinished.')
for f in peer['purpose_proposals']:
 r=next(x for x in c['rows']if x['path']==f['path']);key=f['path']+'#'+f['symbol']+'#'+f['work_kind']
 kind='consumer_integration'if f['disposition']=='needs_migration'else'validation_only'if f['disposition']=='migrated_validation_pending'else'intentional/exclusion'
 if f['symbol']=='comment_out':kind='shared_owner_extension'
 d['rows']=[x for x in d['rows']if x['key']!=key]+[dict(key=key,canonical_site_key=key,path=f['path'],symbol=f['symbol'],line=f['line'],site_purpose=f['work_kind'],source_sha256=r['source_sha256'],git_blob=r['git_blob'],actual_shared_api=f['actual_shared_api'],missing_integration=f['missing_integration'],disposition=f['disposition'],work_kind=kind,work_kind_reason='Independent exact-source/aid peer admission; purpose/actual caller guards retained. Metadata labels are not distinct repair units by themselves.',evidence=[f['evidence'],'Exact baseline original/aid and 13 targeted caller/owner hashes independently verified. Root receipt source-only; omitted tests not reviewed.'],tests=[],validation='Unexecuted source-only audit. No Rust/Cargo/provider tests or source mutations; no complete upstream erasure proof inferred.')]
 r.setdefault('consumer_keys',[])
 if key not in r['consumer_keys']:r['consumer_keys'].append(key)
c['summary']={'assigned_files':len(c['rows']),'full_or_production_source_reviewed_files':sum(x.get('review_status') in ['source_reviewed','production_reviewed_inline_tests_pending'] for x in c['rows']),'test_source_classified_files':0,'test_child_external_helpers_read_inline_operations_pending':sum(x.get('review_status')=='test_operational_inline_pending' for x in c['rows']),'targeted_files_remainder_unexamined':sum(x.get('review_status')=='partial_remainder_unexamined' for x in c['rows']),'manifest_grouped_fixture_files':sum(x.get('review_status')=='manifest_classified_fixture' for x in c['rows']),'fully_unexamined_files':sum(x.get('review_status')=='unexamined' for x in c['rows'])}
(P/'compiler-file-coverage.json').write_text(json.dumps(c,indent=2)+'\n');(P/'compiler-consumers.json').write_text(json.dumps(d,indent=2)+'\n')
(P/'compiler-root-small-packet-admission.json').write_text(json.dumps(dict(baseline=peer['baseline'],reviewed_utc=now,receipt='root-compiler-small-packet-peer.json',receipt_sha256=hashlib.sha256((P/'root-compiler-small-packet-peer.json').read_bytes()).hexdigest(),independently_verified_files=checked,proposed_purpose_rows_admitted=13,whole_scope_complete=False,omitted_tests_operationally_reviewed=False,limits=peer['limitations']),indent=2)+'\n')
print(c['summary'])
