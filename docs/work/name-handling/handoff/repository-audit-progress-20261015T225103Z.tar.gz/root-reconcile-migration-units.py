from pathlib import Path
import json,hashlib,datetime,collections,subprocess
D=Path('/workspace/name-session/full-consumer-audit');R=Path('/workspace/tcl-lsp');p=D/'root-consumers.json';raw=p.read_bytes();j=json.loads(raw);rows=j['consumers'];assert len(rows)==329
# Explicit reviewed purpose assignments, never keyword-based defect inference.
spec='''
host.native-cli-argv|M|consumer_api_adoption|0,245,266
source.document-normalisation|M|consumer_api_adoption|7
host.source-inventory|S|consumer_api_adoption|8,148
xc.issued-target-keys|L|shared_owner_repair|19
xc.issued-hcl-resource-labels|L|shared_owner_repair|20
xc.hcl-literal-source|M|shared_owner_repair|21
xc.hcl-comment-source|M|consumer_api_adoption|22,23
xc.issued-policy-references|M|consumer_api_adoption|24,25
xc.issued-target-keys|M|consumer_api_adoption|26,27
registry.xc-operation-descriptors|M|consumer_api_adoption|35-51
registry.event-candidate-inventory|S|consumer_api_adoption|61
source.xc-supplied-input|L|consumer_api_adoption|64
host.bigip-native-loader|S|consumer_api_adoption|66,139,140,146,147,161,231,238,240
query.scalar-source-construction|M|consumer_api_adoption|67
registry.bigip-emitter-kind-roster|S|consumer_api_adoption|74
mcp.datagroup-source-operations|M|consumer_api_adoption|76
mcp.typed-entrypoint-key|M|consumer_api_adoption|79
mcp.typed-branch-kind|M|consumer_api_adoption|80
registry.command-guidance|M|consumer_api_adoption|81,82,92
registry.event-profile-requirements|M|consumer_api_adoption|85
registry.command-event-scheduling-advice|M|consumer_api_adoption|86
source.mcp-generated-script-container|L|consumer_api_adoption|87,88,93
registry.event-scenario-advice|M|consumer_api_adoption|89
source.scalar-literal-constructor|M|consumer_api_adoption|90
registry.original-header-hint|M|consumer_api_adoption|91
spectcl.hook-family-schema|S|metadata_schema|96
spectcl.original-hook-reads|M|consumer_api_adoption|97,98
spectcl.original-hook-operations|M|consumer_api_adoption|99
spectcl.hook-input-members|S|metadata_schema|100
spectcl.target-availability-closure|L|consumer_api_adoption|101
ai.translation-coverage-authority|S|documentation|106
ai.actual-flow-provider|S|documentation|112,138,295
ai.conditional-source-graph|S|documentation|114
ai.datagroup-extraction-authority|S|documentation|116
ai.reference-closure|S|documentation|117
ai.event-command-applicability|S|documentation|127
source.bigip-mixed-grammar-geometry|L|consumer_api_adoption|149
host.partition-output-catalogue|L|shared_owner_repair|156
source.explorer-held-registry|M|consumer_api_adoption|160
bigip.actual-tmsh-target-emitter|M|consumer_api_adoption|162,171
bigip.original-remote-locator|M|shared_owner_repair|170
host.gui-asset-roster|M|validation_infrastructure|173
mcp.naming-context-status|S|consumer_api_adoption|176-178
source.mcp-held-registry|M|consumer_api_adoption|179,180,182-186
mcp.extract-variable-dialect-schema|S|metadata_schema|192
source.cli-symbols-held-input|M|consumer_api_adoption|196
pkg.dockerfile-source-values|L|shared_owner_repair|201
pkg.release-tag-source|M|consumer_api_adoption|202
pkg.extension-package-source-admission|M|consumer_api_adoption|203
pkg.issued-package-destination|L|shared_owner_repair|209
host.extracted-source-inventory|M|consumer_api_adoption|213
pkg.separate-git-url-revision|M|consumer_api_adoption|214
pkg.fish-activation-source|L|shared_owner_repair|217
host.toml-host-alias-input|M|consumer_api_adoption|219
host.environment-presence|S|consumer_api_adoption|220
host.remote-authority-components|M|consumer_api_adoption|221
source.remote-scf-byte-ingress|M|consumer_api_adoption|224
host.capture-output-catalogue|L|shared_owner_repair|226
host.query-retained-source-path|L|consumer_api_adoption|227,228
query.binding-identifier-input|M|consumer_api_adoption|229
source.sarif-artifact-occurrence|M|consumer_api_adoption|232
source.pcapng-config-byte-ingress|M|consumer_api_adoption|233
host.pcapng-native-argv|M|consumer_api_adoption|234
bigip.typed-generic-object-key|M|consumer_api_adoption|235
bigip.typed-field-equality|M|consumer_api_adoption|236
source.irule-diff-geometry|M|consumer_api_adoption|237
bigip.contextual-reference-selection|M|consumer_api_adoption|239,278
host.actual-browser-authority|S|consumer_api_adoption|241
registry.selected-extension-inventory|M|consumer_api_adoption|243
host.venv-report-currentness|S|consumer_api_adoption|244
source.package-probe-construction|M|consumer_api_adoption|248
source.namespace-array-snapshot-key|L|shared_owner_repair|250
source.spec-report-framing|M|consumer_api_adoption|251
pkg.issued-package-destination|M|consumer_api_adoption|260,261,263
source.package-advice-correspondence|L|consumer_api_adoption|268
source.package-candidate-word|M|consumer_api_adoption|270
host.issued-rule-output-file|L|shared_owner_repair|272
source.irule-input-owner|L|consumer_api_adoption|273
source.irule-output-comment|M|consumer_api_adoption|274
registry.event-multiplicity|S|consumer_api_adoption|275
source.irule-event-and-reference-context|L|consumer_api_adoption|276
bigip.typed-flow-destination|M|consumer_api_adoption|277
bigip.policy-reference-vs-report|M|consumer_api_adoption|279
registry.conditional-event-order|M|consumer_api_adoption|280
source.actual-flow-hud-occurrences|M|consumer_api_adoption|281
bigip.contextual-simulation-roster|L|consumer_api_adoption|282
host.flow-config-native-paths|M|consumer_api_adoption|283
pkg.tcllibpath-list-ingress|M|consumer_api_adoption|284
validation.spec-completion-roster|M|validation_infrastructure|285
validation.pack-environment-census|M|validation_infrastructure|286
gui.source-result-currentness|M|consumer_api_adoption|291,299
host.native-cli-schema|M|metadata_schema|293,294
gui.instruction-correspondence|L|shared_owner_repair|296
gui.event-source-navigation|M|consumer_api_adoption|301
validation.query-fixture-source|M|validation_infrastructure|302
validation.fixture-source-uri|S|validation_infrastructure|303,317,318
validation.report-source-field-normalisation|S|validation_infrastructure|304
validation.tcllibpath-list|M|validation_infrastructure|311
validation.native-wrapper-source|M|validation_infrastructure|312
validation.manifest-path-source|M|validation_infrastructure|313
validation.original-provider-paths|M|validation_infrastructure|314
source.package-manifest-value-admission|M|consumer_api_adoption|319
host.symbol-map-output-path|S|consumer_api_adoption|321
gui.original-source-coordinates|M|consumer_api_adoption|323-328
'''
families={};assign={}
def nums(s):
 for t in s.split(','):
  if '-' in t:
   a,b=map(int,t.split('-'));yield from range(a,b+1)
  else:yield int(t)
for line in spec.strip().splitlines():
 fam,effort,kind,ix=line.split('|');families.setdefault(fam,{'id':fam,'relative_scope':effort,'scope_explanation':{'S':'One local adapter/schema field with a supported owner.','M':'Several adapters or one shared facet; original context and source proof required.','L':'Producer/owner or lifecycle transport crossing multiple boundaries with broader controls.'}[effort],'unit_ids':[]})
 for i in nums(ix):
  assert i not in assign,i;assert rows[i]['disposition']=='needs_migration',(i,rows[i]['disposition']);assign[i]=(fam,effort,kind)
# A genuine unchanged caller is dependency evidence for the owner, not another migration.
unchanged={262:dict(reason='Actual sync_one_package1154 calls installer::materialise and consumes only Ok/Error; changing the existing owner retains this signature and propagates refusal. No independent destination reconstruction is present at this caller. It supplies authentic unrestricted locked-name/version evidence to owner209, not another required caller code change.',family='pkg.issued-package-destination',source_line_ranges=[[1103,1162]])}
needed={i for i,r in enumerate(rows) if r['disposition']=='needs_migration'};assert needed==set(assign)|set(unchanged),sorted(needed-set(assign)-set(unchanged))
groups={g['id']:g for g in json.loads((D/'root-grouped-sites-review.json').read_text())['groups']}
# Explicit integration-boundary decomposition. Helpers on one inseparable boundary
# remain listed code sites; independent consumers are separate units.
def site(symbol,line):return {'symbol':symbol,'line':line}
overrides={
 229:[[s] for s in groups[rows[229]['id']]['sites']],
 234:[[s] for s in groups[rows[234]['id']]['sites']],
 248:[groups[rows[248]['id']]['sites']],
 251:[[s] for s in groups[rows[251]['id']]['sites']],
 272:[[groups[rows[272]['id']]['sites'][0]]]+[[s] for s in groups[rows[272]['id']]['sites'][1:]],
 277:[groups[rows[277]['id']]['sites']],
 278:[[s] for s in groups[rows[278]['id']]['sites']],
 280:[groups[rows[280]['id']]['sites']],
 281:[[s] for s in groups[rows[281]['id']]['sites']],
 283:[[s] for s in groups[rows[283]['id']]['sites']],
 291:[groups[rows[291]['id']]['sites']],
 293:[[s] for s in groups[rows[293]['id']]['sites']],
 294:[[s] for s in groups[rows[294]['id']]['sites']],
 296:[groups[rows[296]['id']]['sites']],
 299:[groups[rows[299]['id']]['sites']],
 302:[[s] for s in groups[rows[302]['id']]['sites']],
 314:[groups[rows[314]['id']]['sites']],
}
units=[];mapping=[];nochange=[];questions=[];checks=[];source_cache={}
def original_site(r,s):
 path=r['path'];b=source_cache.setdefault(path,(D/'root-source'/path).read_bytes());assert hashlib.sha256(b).hexdigest()==r['source_sha256'];lines=b.decode().splitlines();n=s['line'];assert 1<=n<=len(lines),(path,n);return dict(path=path,symbol=s['symbol'],line=n,source_line=lines[n-1],source_sha256=r['source_sha256'])
for i,r in enumerate(rows):
 rid=r['id'];out={'original_index':i,'original_row_id':rid,'original_disposition':r['disposition']}
 if i in unchanged:
  q={'row_id':rid,'disposition':'unchanged_affected_caller','original':r,'evidence':unchanged[i]};nochange.append(q);out.update(disposition=q['disposition'],family_id=unchanged[i]['family'],unit_ids=[])
 elif i in assign:
  fam,effort,kind=assign[i];boundaries=overrides.get(i,[[site(r['symbol'],r['line'])]])
  ids=[]
  for k,sites in enumerate(boundaries):
   uid='root:'+fam+':'+str(i)+':'+str(k);ids.append(uid)
   ukind=kind
   if i==272 and k>0:ukind='consumer_api_adoption'
   u=dict(id=uid,source_owner='root',work_kind=ukind,family_id=fam,purpose=r.get('purpose') or r.get('site'),code_change_sites=[original_site(r,s) for s in sites],representation_and_context=r.get('actual_input_context') or r.get('shared_api'),existing_shared_api=r.get('shared_api'),required_change=r.get('missing_integration'),source_evidence=r.get('evidence',[]),original_row_ids=[rid],relative_effort=effort,state='source_confirmed_change_required_unimplemented',control_obligations=r.get('tests',[]),affected_unchanged_callers=[],limitations='Source review only; original tests/provider/regression/gate acceptance remains separate. Relative effort describes scope, not duration.')
   if i==89:
    u['required_change']='Migrate actual local event-category selection to shared Registry metadata. The actual event producer constrains accepted labels; the bare event source word is not claimed to permit an arbitrary unsafe event. Retain configured whole generated-script construction as a separate shared container obligation.'
   if i==209:u['affected_unchanged_callers']=[rows[262]['id']]
   units.append(u);families[fam]['unit_ids'].append(uid)
  out.update(disposition='confirmed_required_change',unit_ids=ids)
 elif r['disposition']=='pending_audit':
  q={'row_id':rid,'purpose':r.get('purpose'),'path':r['path'],'line':r['line'],'question':r.get('missing_integration'),'evidence':r.get('evidence',[]),'state':'source_or_domain_classification_unresolved','not_counted_as_confirmed_change':True};questions.append(q);out.update(disposition=q['state'],unit_ids=[])
 elif r['disposition'] in ['migrated_validation_pending','pending_validation']:
  checks.append({'row_id':rid,'path':r['path'],'line':r['line'],'state':'existing_scoped_integration_or_validation_obligation_unaccepted','missing_or_limit':r.get('missing_integration'),'shared_api':r.get('shared_api'),'tests':r.get('tests',[]),'whole_consumer_completion':False});out.update(disposition='validation_obligation_no_new_code_change_established',unit_ids=[])
 else:
  nochange.append({'row_id':rid,'disposition':r['disposition'],'purpose':r.get('purpose'),'path':r['path'],'line':r['line'],'reason':r.get('missing_integration') or r.get('evidence') or r.get('work_kind_reason')});out.update(disposition='no_additional_code_change_established_for_this_purpose',unit_ids=[])
 mapping.append(out)
assert len(mapping)==329;assert len({u['id'] for u in units})==len(units)
# Count physical edits by actual source anchor and exact purpose. Multiple required
# purposes may share a function; report both rather than claim function-count census.
counts=dict(collections.Counter(u['work_kind'] for u in units));eff=dict(collections.Counter(u['relative_effort'] for u in units));physical={(s['path'],s['line']) for u in units for s in u['code_change_sites']}
o=dict(baseline=j['baseline'],utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='Root source/canonical-purpose proposal complete; independent canonical boundary/category/family QA requested before cross-owner totals. Exact329 original rows mapped. Not a complete repository migration count.',source_rows_sha256=hashlib.sha256(raw).hexdigest(),remaining_consumer_total=None,area_counts={'confirmed_change_units':len(units),'by_work_kind':counts,'distinct_edit_anchors':len(physical),'scope_by_unit':eff,'unresolved_source_domain_questions':len(questions),'existing_integration_or_validation_obligations':len(checks),'no_change_or_unchanged_caller_records':len(nochange),'families':len(families)},units=units,families=list(families.values()),original_row_mapping=mapping,no_additional_change=nochange,unresolved_questions=questions,validation_obligations=checks,explicit_corrections=[{'original_index':262,**unchanged[262]},{'original_index':89,'narrowing':'Actual constrained event source is not arbitrary-word-injection proof; concrete local event-category metadata integration retained.'}],count_contract='COUNT-UNITS.md',limitations=['Canonical local helper/consumer boundaries require independent peer QA; cross-owner shared families are not summed until reconciliation.','Additional shared Registry/target API extensions are dependencies owned by their true lane; unchanged delegates not extra repairs.','Source questions may add/remove concrete obligations after original source/provider/domain evidence; no manufactured oracle expected answers.','Documentation/generator outputs are linked dependencies of authored changes; do not count identical generated copies as independent owner repairs.'])
p=D/'root-migration-units.json';p.write_text(json.dumps(o,indent=2)+'\n');print(json.dumps({'file':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),**o['area_counts']}))
