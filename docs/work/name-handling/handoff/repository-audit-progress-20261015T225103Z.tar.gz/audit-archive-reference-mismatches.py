import runpy,json
x=runpy.run_path('/workspace/name-session/full-consumer-audit/audit-review-tools.py');c,s=x['load']();rows={r['path']:r for r in c['files']};roots=('experiments/name-handling/','docs/design/analysis/name-resolution-proofs/rust-validation/','scripts/dev/bigip-probes/resolution-2286/evidence/','docs/work/name-handling/handoff/');bad=[];count=0
for p,r in rows.items():
 if not(p.startswith(roots) and p.endswith('.json')):continue
 try:obj=json.loads(x['content'](r))
 except (ValueError,UnicodeDecodeError):continue
 stack=[('',obj)]
 while stack:
  pointer,node=stack.pop()
  if isinstance(node,dict):
   path=node.get('path');digest=node.get('sha256')
   if isinstance(path,str):
    if path.startswith('/workspace/tcl-lsp/'):path=path[len('/workspace/tcl-lsp/'):]
    if path.startswith(roots) and path in rows and isinstance(digest,str) and len(digest)==64 and digest!=rows[path]['source_sha256']:bad.append({'metadata':p,'metadata_sha256':r['source_sha256'],'json_pointer':pointer,'target':path,'historical_sha256':digest,'baseline_sha256':rows[path]['source_sha256'],'disposition':'Not grouped by this historical reference; independently current exact provenance required. No silent checksum refresh or execution acceptance.'})
   stack.extend((pointer+'/'+str(k).replace('~','~0').replace('/','~1'),v) for k,v in node.items())
  elif isinstance(node,list):stack.extend((pointer+'/'+str(i),v) for i,v in enumerate(node))
 count+=1
out={'baseline':c['baseline'],'metadata_examined':count,'historical_reference_mismatches':bad,'scope':'Explicit retained JSON path/sha256 references only; historical bytes remain historical and source/script/prose excluded from grouping.'};(x['BASE']/'audit-archive-reference-mismatches.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
