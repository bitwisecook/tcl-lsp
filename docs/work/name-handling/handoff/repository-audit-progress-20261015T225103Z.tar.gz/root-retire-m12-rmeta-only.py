from pathlib import Path
import datetime,hashlib,json,os,shutil
D=Path('/workspace/name-validation/target/debug/deps')
O=Path('/workspace/name-session/m12-rmeta-cache-retirement.json')
assert not O.exists()
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
elfs=[]
for p in sorted(D.iterdir()):
 if not p.is_file():continue
 with p.open('rb') as f:magic=f.read(4)
 if magic==b'\x7fELF':elfs.append(p)
before={str(p):sha(p) for p in elfs}
metadata=[p for p in sorted(D.glob('*.rmeta')) if p.is_file() and not p.is_symlink()]
records=[{'path':str(p),'size':p.stat().st_size,'sha256':sha(p)} for p in metadata]
receipt={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'prepared','reason':'Inactive Rust metadata cache only; M12 source, full retained execution capture, selected test binaries and original providers are already sealed. No Cargo lease active. Fresh required gates regenerate missing compile metadata.','preserved_elf_sha256':before,'metadata_cache_files':records,'bytes_to_retire':sum(r['size'] for r in records),'free_before':shutil.disk_usage(D).free,'preserve':['All ELF executables and shared objects','All .rlib/.a libraries and build/provider inputs','Every original toolchain/source/library/harness','All source, experiments, failed runs, review drafts and beforeimages','Tracked files and unrelated VSCode cache'],'verification':'No semantic/test/provider execution is performed or accepted by this operation.'}
O.write_text(json.dumps(receipt,indent=2)+'\n')
for p,r in zip(metadata,records):
 assert p.stat().st_size==r['size'] and sha(p)==r['sha256']
 p.unlink()
after={str(p):sha(p) for p in elfs}
assert before==after
receipt.update(status='complete',unchanged_elfs=len(before),free_after=shutil.disk_usage(D).free)
O.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k not in ['metadata_cache_files','preserved_elf_sha256']}))
