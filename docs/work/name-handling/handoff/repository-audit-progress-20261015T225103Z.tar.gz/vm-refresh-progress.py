import json,hashlib,collections,datetime,re
from pathlib import Path
r=Path('/workspace/name-session/full-consumer-audit');d=json.loads((r/'vm-file-coverage.json').read_text());c=json.loads((r/'vm-consumers.json').read_text());rows=d['rows'];lookup={x['path']:x for x in rows};bad=[];ranges=[]
for x in rows:
 b=(r/'vm-source'/x['path']).read_bytes()
 if hashlib.sha256(b).hexdigest()!=x['source_sha256']:bad.append(x['path'])
 n=len(b.splitlines())
 for a,z in x.get('review_ranges',[]):
  if a<1 or z>n or a>z:ranges.append([x['path'],a,z,n])
cbad=[x['id'] for x in c['consumers'] if x['source_sha256']!=lookup[x['path']]['source_sha256'] or x['blob']!=lookup[x['path']]['blob']]
p={'baseline':d['baseline'],'updated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'file_modes':dict(collections.Counter(x['review_mode'] for x in rows)),'full_read_classifications':dict(collections.Counter(x['classification'] for x in rows if x['review_mode']=='production_body_read')),'consumer_count':len(c['consumers']),'dispositions':dict(collections.Counter(x['disposition'] for x in c['consumers'])),'snapshot_sha_mismatches':bad,'consumer_sha_mismatches':cbad,'review_range_errors':ranges,'scope':'in_progress; production_body_read excludes recorded cfg(test) ranges; inline/external operational helpers/setup/guards remain separate actual-read obligations; targeted ranges/lexical candidates/test_source_classified never migration/semantic execution acceptance; no build/list/test/provider execution'}
(r/'vm-progress.json').write_text(json.dumps(p,indent=2)+'\n')
tests={x['path']:x for x in json.loads((r/'vm-test-source-census.json').read_text())['rows']}
pend=[]
for x in rows:
 if x['review_mode'] not in ['unexamined','partial_production_read']:continue
 t=tests.get(x['path']);pend.append({'path':x['path'],'bytes':x['bytes'],'source_sha256':x['source_sha256'],'blob':x['blob'],'review_mode':x['review_mode'],'scope':'actual test-only operational/helper/provider/setup/guard read pending' if t else 'first-party source/config/harness actual read pending','test_context_chain':t.get('test_context_chain',[]) if t else [],'known_partial_ranges':x.get('review_ranges',[])})
(r/'vm-operational-pending.json').write_text(json.dumps({'baseline':d['baseline'],'status':'unfinished actual reads, not lexical candidate completion; known excluded inline test ranges additionally tracked in vm-inline-test-operational-census.json','rows':pend},indent=2)+'\n')
old=json.loads((r/'vm-inline-test-operational-census.json').read_text());oldmap={(x['path'],x['known_actual_cfg_test_exclusion']['start'],x['known_actual_cfg_test_exclusion']['end']):x for x in old['rows']};out=[]
for x in rows:
 for e in x.get('excluded_ranges',[]):
  if 'test' not in e.get('rule',''):continue
  key=(x['path'],e['start'],e['end'])
  if key in oldmap:out.append(oldmap[key]);continue
  lines=(r/'vm-source'/x['path']).read_text().splitlines();fns=[];ops=[]
  for i in range(e['start']-1,min(e['end'],len(lines))):
   line=lines[i];m=re.match(r'\s*(?:(?:pub(?:\([^)]*\))?|async|unsafe|const)\s+)*fn\s+([\w]+)',line)
   if m:fns.append({'name':m.group(1),'line':i+1,'test_attribute_nearby':any('#[test]' in q for q in lines[max(0,i-5):i]),'mode':'candidate_only; actual body/setup review pending'})
   if re.search(r'\b(include_str!|include_bytes!|std::process|Command::new|native_fixture|with_native_core|set_native_engine_profile|register_written_command|sha256|SHA256|verify|provider)',line):ops.append(i+1)
  out.append({'path':x['path'],'source_sha256':x['source_sha256'],'blob':x['blob'],'known_actual_cfg_test_exclusion':e,'functions':fns,'operational_setup_or_guard_candidate_lines':ops,'status':'unfinished actual test body/setup/provider/guard read; not covered by production_body_read'})
old['rows']=out;old['scope']='Finite audit of known cfg(test) exclusions, actual source reads explicitly marked where performed; candidate rows remain unfinished. Source reading is not provider/test execution or migration acceptance. Inline regions in unexamined/partial files additionally unfinished.'
(r/'vm-inline-test-operational-census.json').write_text(json.dumps(old,indent=2)+'\n');print(json.dumps(p,indent=2));print('known inline regions',len(out),'pending paths',len(pend))
