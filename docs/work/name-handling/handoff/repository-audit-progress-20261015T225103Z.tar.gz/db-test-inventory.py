from pathlib import Path
import json,re,runpy
root=Path('/workspace/name-session/full-consumer-audit');lex=runpy.run_path(str(root/'db-audit-lex.py'));mask=lex['mask'];coverage=json.loads((root/'db-file-coverage.json').read_text());rows=[]
for r in coverage['files']:
 p=root/'db-baseline'/r['path']
 if p.suffix!='.rs' or not p.is_file():continue
 s=p.read_text();m=mask(s)
 for a in re.finditer(r'#\[\s*(?:(?:tokio|async_std)::)?test(?:\([^\]]*\))?\s*\]',m):
  f=re.search(r'\bfn\s+([A-Za-z_]\w*)',m[a.end():a.end()+1500])
  if f:rows.append(dict(path=r['path'],symbol=f.group(1),line=s.count('\n',0,a.end()+f.start())+1,source_sha256=r['source_sha256'],attribute=s[a.start():a.end()],status='retained test source inventory; not executed and not a crate-qualified --exact invocation'))
(root/'db-test-selectors.json').write_text(json.dumps({'baseline':coverage['baseline'],'tests':rows},indent=2)+'\n')
a=json.loads((root/'db-consumers.json').read_text())
for r in a['consumers']:
 paths=[r['path']];parent=Path(r['path']);sibling=str(parent.with_suffix('')/'tests.rs')
 if (root/'db-baseline'/sibling).is_file():paths.append(sibling)
 r['test_source_inventory']={'artifact':'db-test-selectors.json','paths':paths,'exact_source_controls':sum(x['path'] in paths for x in rows),'status':'source inventory only; purpose-specific acceptance remains independently stated'}
(root/'db-consumers.json').write_text(json.dumps(a,indent=2)+'\n')
print(json.dumps({'test_source_rows':len(rows)}))
