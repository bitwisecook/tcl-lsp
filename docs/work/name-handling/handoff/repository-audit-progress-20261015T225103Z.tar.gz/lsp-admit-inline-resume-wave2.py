import json
from pathlib import Path
r=Path('/workspace/name-session/full-consumer-audit');p=r/'lsp-inline-reviewed-regions.json';d=json.loads(p.read_text());w=json.load(open(r/'lsp-inline-next-wave2.json'));seen={(x['path'],x['start_line'],x['end_line'],x['source_sha256'])for x in d['regions']}
notes={
('expr_context.rs',484):'Whole actual standalone fixed Registry/source cursor helper and partial Expr/argv command index controls read. Fixedtcl8.6 ingress is explicit test purpose, not document custom input transport or genuine partial expression issuer.',
('inline_proc.rs',1567):'Whole actual inline body syntax helper controls read: retained parent/quoted closer/source config/BOM and parameter mutation refusal. Original body geometry only, no complete motion/cell/edit permission.',
('references.rs',8804):'Whole constructed compatibility source/colon/Unicode and actual positioned alias terminal refusal controls read; explicitly ownerless metadata fixtures remain distinct from actual original selected call.',
('definition.rs',8128):'Whole actual synthetic Registry spec/context source builder and captured next target/selected availability/shadow/dynamic/source-currentness controls read; fixed trait injection tests data, no live next dispatch grant.',
('document_floor.rs',205):'Whole actual original package/source requirements/foreign metadata/conditional floor controls read. Deliberately mutated report Strings cannot replace retained original units; current requirements advise metadata only, no installed runtime package.',
('brace_expr.rs',120):'Whole actual lexical source analysis/UTF16 cursor and expected Logical expression source actions read; source output assertions do not establish independent substitution/trace/semantic transform equivalence (existing production repair stays unfinished).',
('source_subject.rs',318):'Whole fixed six-domain scalar grammar/original NativeWord/source span controls read. Names are expected test data, no copied test parser or physical variable place; no interpreter provider executed.',
('references.rs',8425):'Whole original opaque declarations/source currentness and actual method candidate/no report tuple fallback controls read. Positive reference/highlight inventory not full rename census.',
('lib.rs',60027):'Whole actual injected definer family/Registry/input/WorkspaceIndex tests read, retained source family versus nominal profile and missing context refusals. No actual Backend server/provider launch or entered receiver proof.',
('completion.rs',6879):'Whole actual original instance candidate/retained source/current completion geometry/fuzzy projection and captured selector negative read. Expected display/source edit proposal is not method installation/dispatch/rename equivalence.'}
for x in w['regions']:
 key=(x['path'],x['start_line'],x['end_line'],x['source_sha256']);assert key not in seen;seen.add(key)
 d['regions'].append({key:x[key]for key in ['path','start_line','end_line','source_sha256']}|{'review_status':'reviewed_source_only','classification':'actual_whole_inline_source_and_owner_controls','reason':notes[(Path(x['path']).name,x['start_line'])]+' Entire exact statements/helpers/imports read; no test-attribute purity inference or test/build/helper/provider/source mutation. All original selectors/assertions/budgets preserved; no migration execution acceptance.'})
p.write_text(json.dumps(d,indent=2)+'\n')
