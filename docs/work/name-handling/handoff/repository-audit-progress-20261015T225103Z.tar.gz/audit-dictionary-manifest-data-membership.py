import runpy,json,re,posixpath,datetime,collections
from pathlib import Path
B=Path('/workspace/name-session/full-consumer-audit');x=runpy.run_path(str(B/'audit-review-tools.py'));c,s=x['load']();R={r['path']:r for r in c['files']};candidates=json.loads((B/'audit-dictionary-manifest-candidates.json').read_text());members=[];bad=[];admitted_manifests=[]
# Only raw record/data roles. No code, authored prose, Tcl specimens, provider source, generated guidance, or arbitrary JSON configuration.
raw_suffixes={'.stdout','.stderr','.log','.exit','.status','.out','.bin','.elf','.hex','.gz','.xz','.zip','.tgz','.patch','.diff','.tsv','.csv','.bytes','.dat'}
raw_basenames={'stdout','stderr','exit','status','execution.stdout','execution.stderr'}
json_names={'receipt.json','outcomes.json','results.json','result.json','validation.json','artifacts.json','binary.json','inputs-before.json','inputs-after.json','provider-inputs-before.json','provider-inputs-after.json','baseline.json'}
authority=['experiments/name-handling/README.md','experiments/name-handling/results/README.md']
for a in candidates:
 manifest=a['path'];mr=R[manifest];d=json.loads(x['content'](mr));assert isinstance(d,dict) and d and all(isinstance(k,str) and re.fullmatch('[0-9a-f]{64}',v or '') for k,v in d.items())
 count=0
 for rel,sha in d.items():
  if rel.startswith('/') or '\\' in rel:continue
  p=posixpath.normpath(posixpath.join(posixpath.dirname(manifest),rel));r=R.get(p)
  if not r or not p.startswith(posixpath.dirname(manifest)+'/'):continue
  if r['source_sha256']!=sha:bad.append(dict(manifest=manifest,member=rel,path=p,declared=sha,baseline=r['source_sha256']));continue
  name=Path(p).name;ext=Path(p).suffix
  if ext not in raw_suffixes and name not in raw_basenames and name not in json_names and not name.endswith('.invocation.json'):continue
  count+=1
  if r['review_status']=='reviewed':continue
  r.update(review_status='reviewed',review_mode='explicit_dictionary_checksum_raw_record_membership',classification='retained_historical_raw_output_or_snapshot',group_rule='dictionary-checksum-explicit-raw-data',reason='Exact explicit relative path/whole baseline SHA in retained dictionary checksum manifest; actual strict entire manifest schema is String→64hex. Admitted path is raw captured channel/status, binary/snapshot/archive/proposal patch, or named receipt/result record; every code/Tcl/source/prose/unknown JSON role excluded. This records original retained input identity, not semantic success or active-tool correctness.',reviewed_production_extent='Historical raw data provenance only. Active harness, generators, admission guards, current provider/input context, semantic guidance and original answer meaning remain separate.',evidence=[dict(path=manifest,sha256=mr['source_sha256'],manifest_member=rel)]+[dict(path=p0,sha256=R[p0]['source_sha256'],scope='Previously read repository retained-capture index authority, not provider/original validation.') for p0 in authority if p0 in R],consumer_ids=[],tests='No execution or current acceptance; exact retained data linkage only.');members.append(dict(path=p,blob=r['blob'],source_sha256=sha,manifest=manifest,member=rel))
 if mr['review_status']!='reviewed':mr.update(review_status='reviewed',review_mode='fixed_shape_explicit_checksum_dictionary_inventory',classification='retained_capture_delivery_checksum_metadata',reason='Complete actual checksum map schema/keys/value shapes and strict path/SHA correspondence inventoried; operational scripts, source/prose/unknown metadata not admitted by this grouping.',reviewed_production_extent='Entire checksum dictionary shape and explicit member inventory, not manual review of target file semantics or claims.',consumer_ids=[],evidence=[],tests='No providers/test/generator execution or checksum refresh.')
 admitted_manifests.append(dict(path=manifest,source_sha256=mr['source_sha256'],entries=len(d),raw_roles_exact_members=count))
c['group_rules'].append(dict(id='dictionary-checksum-explicit-raw-data',rule='Actual complete strict dictionary relative-path/checksum membership + exact baseline SHA; raw output/snapshot roles only. No path-only archive exemption. Unknown semantics and active adapters remain unfinished.',manifest_count=len(admitted_manifests),new_members=len(members)))
x['save'](c,s);out=dict(baseline=c['baseline'],utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),manifests=admitted_manifests,new_members=members,mismatches_unadmitted=bad,limits='Metadata/raw role/source identity only; no current semantic/Native/provider/generator/test acceptance. Script/Tcl/source/prose/guidance and unknown JSON data not excluded.');(B/'audit-dictionary-manifest-data-membership.json').write_text(json.dumps(out,indent=2)+'\n');print(dict(manifests=len(admitted_manifests),new_members=len(members),mismatches=len(bad)))
