import runpy,collections,datetime,json,hashlib
x=runpy.run_path('/workspace/name-session/full-consumer-audit/audit-review-tools.py');c,s=x['load']();groups=collections.defaultdict(list)
for r in s['consumers']:groups[r['path'],r['symbol']].append(r)
# Independently reviewed, genuinely different purposes inside same function.
keep_multi={('rust/bigip-report-gen/rust/src/graph.rs','build_graph'),('rust/tcl-bigip/src/cleanup.rs','compute_cleanup'),('rust/tcl-bigip/src/cleanup.rs','format_tmsh_script'),('rust/tcl-bigip/src/convert.rs','convert_pool'),('rust/tcl-bigip/src/convert.rs','scf_to_as3'),('rust/tcl-irule-test/src/sim.rs','simulate_rules')}
removed=set();receipt=[];rank={'needs_migration':5,'migrated_validation_pending':4,'migrated_verified':3,'shared_owner':2,'display_only':1,'out_of_scope':0}
for key,a in groups.items():
 if len(a)<2 or key in keep_multi:continue
 if key==('rust/tcl-bigip-query/src/runner.rs','run_query'):
  a=[r for r in a if r['purpose']!='perfile source URI uniqueness']
 if len(a)<2:continue
 canonical=a[0];strong=max(a,key=lambda r:rank[r['disposition']]);before=dict(canonical)
 aliases=[];evidence=[];notes=[]
 for r in a:
  if r['id']!=canonical['id']:removed.add(r['id']);aliases.append({'id':r['id'],'purpose':r['purpose'],'disposition':r['disposition']})
  for ev in r.get('source_evidence',[]):
   if ev not in evidence:evidence.append(ev)
  notes.append({'id':r['id'],'actual_input_context':r.get('actual_input_context'),'shared_api':r.get('shared_api'),'missing_integration':r.get('missing_integration'),'relevant_original_assertions':r.get('relevant_original_assertions')})
 canonical['disposition']=strong['disposition'];canonical['missing_integration']=strong.get('missing_integration','');canonical['source_evidence']=evidence;canonical['semantic_aliases']=canonical.get('semantic_aliases',[])+aliases;canonical['reconciled_source_notes']=canonical.get('reconciled_source_notes',[])+notes
 canonical['reconciliation']='Whole-source review confirmed these alternate labels describe the same integration purpose, not independent remaining consumers. Stable first ID retained; strongest actual obligation retained; all source notes/aliases preserved. No validation donated.'
 receipt.append({'canonical_id':canonical['id'],'aliases':aliases,'before_disposition':before['disposition'],'after_disposition':canonical['disposition']})
s['consumers']=[r for r in s['consumers'] if r['id'] not in removed]
# Challenge two new overclaims against the actual standalone format/data purpose.
challenges=[]
for r in s['consumers']:
 if r['path']=='rust/tcl-bigip-query/src/inputs.rs' and r['symbol'] in {'parse_csv','read_csv_records'}:
  challenges.append({'id':r['id'],'before':r['disposition'],'prior_missing_integration':r.get('missing_integration')})
  r['disposition']='shared_owner';r['missing_integration']='Standalone CSV-to-map owner intentionally follows default/lenient record policy and map last-key semantics. No actual separate namespace identity or strict RFC acceptance requirement demonstrated. Duplicate columns/malformed-field behavior is source-format contract validation debt, not a proved naming migration. No original CSV implementation oracle executed.';r['site_kind']='shared_format_owner';r['purpose_challenge']='Removed overbroad strictness/unique-field requirement invented from general format prose. Actual consumers may impose stronger schema requirements independently; none demonstrated in this review.'
# Refresh exact file->row links, including reviewed distinct purposes lost by repeated helper replacement.
for r in c['files']:r['consumer_ids']=[q['id'] for q in s['consumers'] if q['path']==r['path']]
x['save'](c,s)
out={'baseline':c['baseline'],'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Semantic alias reconciliation after resumed completed-review artifacts exceeded compacted summary. Baseline whole-file coverage unchanged. Counts not repository remaining total. No tests/provider/build executed.','aliases_removed':len(removed),'canonical_groups':receipt,'actual_purpose_challenges':challenges,'remaining_rows':len(s['consumers']),'explicit_distinct_same_function_groups':[list(q) for q in sorted(keep_multi)]+[['rust/tcl-bigip-query/src/runner.rs','run_query','perfile source URI uniqueness distinct from current-source freshness']]}
p=x['BASE']/'audit-semantic-alias-reconciliation.json';p.write_text(json.dumps(out,indent=2)+'\n');print(len(removed),'aliases removed; rows',len(s['consumers']),'sha',hashlib.sha256(p.read_bytes()).hexdigest())
