from pathlib import Path
import subprocess,json,hashlib,collections
BASE='cc24c394004fc187378ba0eefb6c2c5b2615fb00'
ROOT=Path('/workspace/tcl-lsp'); OUT=Path('/workspace/name-session/full-consumer-audit'); SNAP=OUT/'db-baseline'
assigned=json.loads((OUT/'db-assigned-files.json').read_text()); assert assigned['baseline']==BASE
rules=[{'id':'registry-original-evidence','prefix':'rust/tcl-registry/tests/data/','classification':'retained_oracle_evidence','review_mode':'explicit_manifest_group','justification':'Pinned original-provider source/binary/harness captures, oracle inputs, raw channels and verification records under the dedicated tests/data evidence tree. These files are retained test evidence, not production naming consumers. Production include consumers are audited separately; grouping supplies no semantic or execution acceptance.'},{'id':'regression-golden','patterns':['/tests/golden/','/tests/fixtures/'],'classification':'regression_fixture','review_mode':'explicit_manifest_group','justification':'Expected golden data and test fixture payloads; production loader/renderer or test driver owning the interpretation is reviewed separately. Exact content is retained and hash bound, not rewritten or treated as a live resolver.'}]
proc=subprocess.Popen(['git','cat-file','--batch'],cwd=ROOT,stdin=subprocess.PIPE,stdout=subprocess.PIPE)
rows=[]
for item in assigned['files']:
 p=item['path'];proc.stdin.write((item['blob']+'\n').encode());proc.stdin.flush();header=proc.stdout.readline().decode().strip().split();assert header[0]==item['blob'] and header[1]=='blob';n=int(header[2]);data=proc.stdout.read(n);assert len(data)==n and proc.stdout.read(1)==b'\n';assert n==item['bytes']
 sha=hashlib.sha256(data).hexdigest();gitsha=hashlib.sha1(b'blob '+str(n).encode()+b'\0'+data).hexdigest();assert gitsha==item['blob']
 rule=next((r for r in rules if p.startswith(r.get('prefix','!')) or any(x in p for x in r.get('patterns',[]))),None)
 row={'path':p,'blob':item['blob'],'source_sha256':sha,'bytes':n,'baseline':BASE,'review_mode':'unexamined','review_status':'unexamined','classification':'first_party_source_or_metadata','justification':'Not yet reviewed; remains unfinished.'}
 if rule:row.update(review_mode=rule['review_mode'],review_status='classified_by_explicit_manifest_rule',classification=rule['classification'],justification=rule['justification'],manifest_rule=rule['id'])
 else:
  q=SNAP/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(data)
 rows.append(row)
proc.stdin.close();proc.wait();assert proc.returncode==0
(OUT/'db-group-rules.json').write_text(json.dumps({'baseline':BASE,'rules':rules},indent=2)+'\n')
(OUT/'db-file-coverage.json').write_text(json.dumps({'baseline':BASE,'scope':'complete assigned roster; unfinished file reviews remain explicit','files':rows},indent=2)+'\n')
(OUT/'db-consumers.json').write_text(json.dumps({'baseline':BASE,'status':'in_progress; no unexamined consumer inferred migrated','consumers':[]},indent=2)+'\n')
print(json.dumps({'files':len(rows),'classified_groups':collections.Counter(r['classification'] for r in rows),'unexamined':sum(r['review_status']=='unexamined' for r in rows),'snapshot_bytes':sum(r['bytes'] for r in rows if r['review_status']=='unexamined')},default=dict))
