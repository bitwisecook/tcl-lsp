from pathlib import Path
exec(Path('/workspace/name-session/full-consumer-audit/lsp-audit.py').read_text())
p='editors/sublime-text/plugin.py'
consumer('lsp-sublime-extension-association',p,'_assign_builtin_tcl_syntax','def _assign_builtin_tcl_syntax(', 'Explicit host filename suffix→fallback syntax, preserving user-selected syntax.', 'Generated TCL_FILE_EXTENSIONS via rust/xtask/src/editor_extensions.rs actual EnvironmentRegistry/bundled pack extensions, Sublime actual view/file basename.', 'Shared metadata projection already integrated; extension lowercasing is host classification only, not Tcl name normalization. Drift check unexecuted. Native server artifact path/release naming remains separate fixed host vocabulary.', 'migrated_validation_pending', [], ['Entire production plugin read; generated owner trace previously inspected, no network/host execution.'])
review(p,'generated_metadata_consumer','Full production plugin read; host artifact downloads/hash/actual argv separate from Tcl source naming; genuine generated extension list used.',ids=['lsp-sublime-extension-association'])
p='editors/sublime-text/LSP-Tcl.sublime-settings'
consumer('lsp-sublime-token-vocabulary',p,'semantic_tokens mapping','"interface": "entity.name.tag.interface.lsp"', 'IDE display of actual server semantic-token legend.', 'Static Sublime palette; server legend_token_types owns exported token vocabulary.', 'Static map has interface while actual Core legend exports bigipInterface (semantic_tokens309); needs shared generated legend projection/drift owner. Pure display defect, no Tcl command/namespace/physical identity grant.', 'needs_migration', [], ['Entire settings file read and exact actual legend entry source checked.'])
review(p,'display_metadata_needs_migration','Entire settings read; explicit default standalone configuration, custom token vocabulary drift remains.',mode='full_file_source',ids=['lsp-sublime-token-vocabulary'])
for leaf,reason in [
('Default.sublime-commands','Fixed built-in edit_settings palette command and base asset path; no Tcl/source action.'),
('Main.sublime-menu','Fixed host settings menu and asset path, no Tcl names.'),
('README.md','Explicit installation/standalone dialect settings and feature documentation. Generated dialect region traces gen_editor_configs; drift unexecuted. No evaluated name/source-action authority.'),
('SUBMITTING.md','Host package publishing instructions and release metadata only, no Tcl naming consumer.'),
('messages/install.txt','Installation/feature guidance only; does not define name handling.'),
('messages.json','Fixed install message path metadata only.'),
('.ruff.toml','Python host formatter/linter version config only.'),
('sublime-package.json','Entire JSON read; user setting schema/generated dialect enum and actual feature toggles, no Tcl name normalization/lookup. gen_editor_configs projection source traced; source-value admission belongs server config owner, not JSON descriptions.')]:
 review('editors/sublime-text/'+leaf,'out_of_scope' if 'Generated' not in reason and 'gen_editor_configs' not in reason else 'generated_metadata', 'Entire file read. '+reason,mode='full_file_source')
p='editors/sublime-text/.python-version';assert (BASE/p).read_text().strip()=='3.8';review(p,'out_of_scope','Complete4byte host Python version pin read; no naming consumer.',mode='full_file_source')
