from pathlib import Path
import hashlib,json
exec(Path('/workspace/name-session/full-consumer-audit/lsp-audit.py').read_text())
root='rust/tcl-lsp-core/tests/data/'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
groups=[]
for variant in ['file','stdin']:
 directory=BASE/root/'native_inline_variable_semantics'/variant
 receipt=json.loads((directory/'receipts.json').read_text());paths={root+'native_inline_variable_semantics/'+variant+'/receipts.json'}
 for row in receipt['records']:
  source=directory/row['source'];assert source.read_bytes().hex()==row['source_hex'];assert sha(source)==row['source_sha256'];paths.add(str(source.relative_to(BASE)))
  for stream in ['stdout','stderr']:
   file=directory/row[stream];assert file.read_bytes().hex()==row[stream+'_hex'];paths.add(str(file.relative_to(BASE)))
  assert row['version_exit']==0
 groups.append(dict(id='inline-variable-'+variant,paths=sorted(paths),rule='EXACT manifest references source/stdout/stderr plus receipts.json; all source hex+sha and stream hex crosschecked. Fixed literal oracle inputs/retained channels, not a production naming consumer.',records=len(receipt['records']),claims='No interpreter launch/version/hash/current upstream validation or Rust acceptance. Unique source programs read separately.'))
 for p in paths:review(p,'retained_oracle_fixture','Exact inline-variable '+variant+' manifest group; source/stream association integrity read-checked, scalar fixture programs reviewed. No new provider/semantics execution.',mode='explicit_fixture_manifest_and_byte_association')
p=root+'native_inline_variable_semantics/replay.py'
consumer('lsp-inline-variable-retained-runner',p,'original_rows / main','def original_rows(', 'Fixed original provider source/stream replay, not a runtime name implementation.', 'Actual Path/source hex/hash/provider equality and finite explicit argv; exact source filename rewrite only in retained file stderr.', 'Original provider pins are mandatory; this audit reads retained byte associations only. External original support provenance/current Jim and fresh execution remain separate obligations.', 'out_of_scope', [], ['Entire runner source read; integrity script reads manifests/streams without executing replay or providers.'])
review(p,'retained_oracle_harness','Full Python harness read; fixed source controls using original providers, no consumer-local semantic expectation creation.',mode='full_file_source',ids=['lsp-inline-variable-retained-runner'])
directory=BASE/root/'native_minifier_script_role';aggregate=json.loads((directory/'receipt.json').read_text());paths={str(p.relative_to(BASE)) for p in [directory/'receipt.json',directory/'queue.json',directory/'inputs.json']}
for receipt in aggregate:
 provider=directory/receipt['provider'];assert json.loads((provider/'receipt.json').read_text())==receipt;paths.add(str((provider/'receipt.json').relative_to(BASE)))
 for name,field in [('probe.c','probe_sha256'),('inputs.json','inputs_sha256'),('queue.json','queue_sha256'),('capture.py','runner_sha256')]:assert sha(directory/name)==receipt[field]
 for name,field in [('stdout.tsv','stdout_sha256'),('stderr','stderr_sha256'),('compile.stdout','compile_stdout_sha256'),('compile.stderr','compile_stderr_sha256')]:
  assert sha(provider/name)==receipt[field];paths.add(str((provider/name).relative_to(BASE)))
 assert (provider/'stdout.tsv').read_text().splitlines()==receipt['rows']
groups.append(dict(id='minifier-script-role',paths=sorted(paths),rule='EXACT aggregate six-provider receipt rows + inputs/queue manifests and explicitly hash-linked retained streams; all local hashes+row equality read-checked.',claims='Fresh execution, unavailable external providers, Tcl libraries and current Jim not checked; observed records remain bounded historical evidence.'))
for p in paths:review(p,'retained_oracle_fixture','Exact script-role fixture manifest/stream group; local hash+row association checked, input sources read. No Native replay or Rust acceptance.',mode='explicit_fixture_manifest_and_byte_association')
for leaf in ['capture.py','replay.py','probe.c','README.md']:
 p=root+'native_minifier_script_role/'+leaf
 review(p,'retained_oracle_harness' if leaf!='README.md' else 'retained_oracle_documentation','Entire file read. Fixed actual-provider dispatch/body-separator experiment with explicit Script/Direct/Jim modes and preserved handler/results; no application resolver. Archival absolute provider paths/provenance are explicit, not assumed currently usable.',mode='full_file_source')
for stem in ['original_index_filenames','standalone_index_keys']:
 directory=BASE/root/stem;manifest=json.loads((directory/'manifest.json').read_text());assert sha(directory/'probe.tcl')==manifest['probe_sha256'];paths={str((directory/'manifest.json').relative_to(BASE))}
 for provider in manifest['providers']:
  p=directory/(provider['provider']+'.stdout');assert sha(p)==provider['stdout_sha256'];paths.add(str(p.relative_to(BASE)))
 if stem=='original_index_filenames':
  p=directory/'controlled-files.json';files=json.loads(p.read_text());expected={x['relative']:x['sha256'] for x in manifest['files']}
  for f in files:assert expected[bytes.fromhex(f['relative_path_hex']).decode()]==f['sha256']==hashlib.sha256(bytes.fromhex(f['contents_hex'])).hexdigest()
  paths.add(str(p.relative_to(BASE)))
 groups.append(dict(id=stem,paths=sorted(paths),rule='EXACT named six-provider stdout members hash-linked by manifest, probe source hash and controlled file bytes where present checked.',claims='Retained source-loading/name DATA observations only; no new executable/library/provider run or Native/Rust acceptance.'))
 for p in paths:review(p,'retained_oracle_fixture','Exact '+stem+' original-shell manifest group; retained local hash associations checked, no original provider run.',mode='explicit_fixture_manifest_and_byte_association')
 p=root+stem+'/probe.tcl';review(p,'retained_oracle_harness','Entire source read; original shell performs finite exact source filename/scalar array-key controls using list/linsert/file join, no fake source handler or application naming resolver.',mode='full_file_source')
(ROOT/'lsp-fixture-groups.json').write_text(json.dumps(dict(baseline='cc24c394004fc187378ba0eefb6c2c5b2615fb00',groups=groups,scope='Only exact paths from explicit retained fixture manifests; production harnesses separately read. Integrity checks only, zero provider/build/test launches.'),indent=2)+'\n')
print(json.dumps({g['id']:len(g['paths']) for g in groups}))
