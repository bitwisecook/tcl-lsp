import json,os,hashlib
from pathlib import Path
R=Path('/workspace/name-session/full-consumer-audit');p=R/'vm-consumers.json';raw=p.read_bytes();D=json.loads(raw)
mapping={
'vm-0054':('consumer_integration','Completion projection already has actual InvocationMetadataContext and shared schema; missing actual lexical operand join is consumer transport, with availability still pending audit.'),
'vm-0095':('consumer_integration','Existing actual original invocation admission owner is available; unowned specialization callers must preserve or explicitly decline that purpose.'),
'vm-0156':('consumer_integration','Substitution arena exists; concrete deferred driver must transport retained operation/frame/provider currency rather than grant authority from state.'),
'vm-0195':('consumer_integration','Actual full LexerConfig is retained, but condition parser reselects profile; use existing configured expression owner at this consumer.'),
'vm-0196':('consumer_integration','Existing SourceBpfModuleContext/phase original owner must be joined at child source borrow; no new general resolver is justified.'),
'vm-0246':('consumer_integration','Actual RegistrySnapshot already exists; CLI-to-Explorer selected generation is dropped at public dialect-string seam.'),
'vm-0285':('consumer_integration','Existing actual table/member inventory must drive conversion; missing representation cannot establish absent entries. Transition availability remains pending audit.'),
'vm-0374':('consumer_integration','Existing original NativeWord/variable operand APIs must reach surviving compiled-word consumer; shared decomposition alone does not restore source purpose.'),
'vm-0419':('consumer_integration','Shared actual native command and array operation owners exist; source-profile role facade must not replace reached original target/trace receipt.'),
'vm-0453':('consumer_integration','Existing CompiledUnitNamespace/NamespaceExecutionContext and currency owners need actual entered incarnation join at activation; exact Native reachability still pending audit.'),
'vm-0471':('consumer_integration','Existing Script backing/context must retain and compare actual selected parsing configuration; fixed physical grammar invariant remains unproved.'),
'vm-0516':('consumer_integration','Existing physical teardown provider and selected actual dialect must flow into OO cleanup; no local resolver replacement needed.'),
'vm-0583':('consumer_integration','Actual NativeDictionarySearch and iterator slots exist; missing iterator receiver must remain unavailable versus actual exhaustion.'),
'vm-0592':('consumer_integration','Existing actual string/class/regex/numeric owners must reach op adapter; raw class ID/name metadata is not actual operand/caller capability.'),
'vm-0618':('consumer_integration','Actual source/IR condition owner must reach Emit clauses; missing slice cannot prove empty condition or completion.'),
'vm-0620':('consumer_integration','Existing Jim previous-node owner returns optional selected node, but adapter must preserve unavailable versus absence at actual callers.'),
'vm-0627':('consumer_integration','Existing Native regexp owner must receive actual original object/context from opcode; Unicode display is insufficient for Native purpose.'),
'vm-0675':('consumer_integration','Existing original expression source/config owner must feed actual fallback; model AST rendering remains separate explicit purpose.'),
'vm-0687':('consumer_integration','Actual instruction metadata already exists; POP trimming must preserve complete provenance or prove actual producer invariant.'),
'vm-0719':('consumer_integration','Actual Jim expression term objects are retained by value owner and interp preparation, but normal variable consumer reads report bytes; selected provider API requirement remains pending audit.'),
'vm-0735':('consumer_integration','Existing CompiledNamespaceContext/source operation selection owner is present; actual replay consumer must retain incarnation and command-boundary purpose.'),
'vm-0742':('consumer_integration','Actual original Switch tokens and NativeSwitchInstruction owners exist; fallback must not manufacture canonical head/lossy operand authority.'),
'vm-0793':('consumer_integration','Actual interpreter preparation now full-read confirms genuine JimExpressionObjects issuance; normal ExprEval variable consumer join remains distinct unfinished work.'),
'vm-0808':('consumer_integration','Existing caller-aware original-name ingress/materialization APIs are available; self-only consumers require exact caller inventory and purpose transport.'),
'vm-0820':('consumer_integration','Actual source/body occurrence owners exist; debugger suppression keyed by line/span needs genuine occurrence association if required by hook purpose.'),
'vm-0837':('consumer_integration','Existing original table-key inventory/result owner and fallible command lookup are available; compatibility Option consumers need honest purpose join.'),
'vm-0843':('consumer_integration','Actual native namespace/context and command binding owners exist; path-based match cannot reconstruct incarnation where physical recipe requires it.'),
'vm-0845':('consumer_integration','Actual original formal/body/header owners exist; physical optimized binding consumer must not rely on Unicode report equality.'),
'vm-0853':('consumer_integration','Existing authentic current holder/token and checked original-byte namespace APIs should reach native callers instead of Unicode current_ns facade.'),
'vm-0858':('consumer_integration','Existing strict namespace token/path APIs must replace missing-to-root compatibility projection at physical consumers.'),
'vm-0862':('consumer_integration','Existing original holder/token namespace context must be transported into OO/replay frame entry; constructed RuntimeSelected coordinate remains separate.'),
'vm-0870':('consumer_integration','Existing original export/pattern/header/namespace owners should reach forget/export consumer; expect/root fallback cannot supply unavailable provider evidence.'),
'vm-0889':('consumer_integration','Existing original procedure/key inventory and typed OO errors must be preserved by public enumeration facade instead of silent omission.'),
'vm-0894':('consumer_integration','Actual original first-key/member/backing/header owners are available; statics constructor currently clones Vec and inserts NameBytes without authentic physical role join.'),
'vm-0901':('consumer_integration','Existing original increment/captured cell/error owners must carry actual protocol/header/caller and full first cause through consumer.'),
'vm-0905':('consumer_integration','Existing actual original Value invoked-head path exists; remaining legacy String caller purposes require explicit generated/stock versus original joins.'),
'vm-0931':('consumer_integration','Actual command token dispatch is retained; frame alias facade still needs original header/frame-birth purpose. Component integration does not prove full argv0/frame parity.')}
before='vm-work-kind-before-resumed-'+hashlib.sha256(raw).hexdigest()[:12]+'.json';(R/before).write_bytes(raw)
reviewed=[]
for r in D['consumers']:
 if r.get('work_kind')!='unclassified_pending_owner_trace':continue
 old=r['work_kind']
 if r['id'] in mapping:r['work_kind'],r['work_kind_reason']=mapping[r['id']]
 else:r['work_kind_reason']='Individually reviewed, requirement still unresolved: '+r['missing_integration']+' Existing owner listed does not establish actual provider/domain/caller invariant, so no integration or extension category is guessed.'
 r['work_kind_review']='Individual frozen-source purpose review resumed; no disposition or execution acceptance donated.'
 reviewed.append({'id':r['id'],'before':old,'after':r['work_kind'],'reason':r['work_kind_reason']})
save=lambda n,d:(R/n).write_text(json.dumps(d,indent=2)+'\n')
t=p.with_suffix('.tmp');t.write_text(json.dumps(D,indent=2)+'\n');os.replace(t,p)
save('vm-work-kind-reconciliation-resumed-01.json',{'baseline':D['baseline'],'beforeimage':before,'beforeimage_sha256':hashlib.sha256(raw).hexdigest(),'reviewed':reviewed,'limit':'Clear consumer joins classified without declaring implementation or Native semantics. Unresolved API/provider/domain/producer facts remain explicitly unclassified_pending_owner_trace; these are audit obligations, not estimated owner extensions.'})
print(len(reviewed),len(mapping))
