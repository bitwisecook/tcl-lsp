import json
from pathlib import Path
r=Path('/workspace/name-session/full-consumer-audit');p=r/'lsp-inline-reviewed-regions.json';d=json.loads(p.read_text());w=json.load(open(r/'lsp-inline-next-wave.json'));existing={(x['path'],x['start_line'],x['end_line'],x['source_sha256'])for x in d['regions']}
notes={
'original_invocation.rs':'Actual configured Logical known-word advice vs unavailable executable constant, whole actual unit/body/word source guards and missing/stale/foreign metadata controls read.',
'source_graph.rs':'Actual native Path source-association unique declared base, unsupported path forms and source literal generation controls read. No filesystem I/O, root identity or runtime cwd assertion follows.',
'original_oo.rs':'Actual analysis/selector receipt, configured separators/continuation gaps and complete generated original word Unicode equality checks read; no insertion performed.',
'file_uri.rs':'Actual Path/OsString invalid bytes, actual platform gates and separate standalone Windows geometry controls read. No filesystem/provider execution or Windows conformance observed.',
'original_declaration.rs':'Actual original own-object declaration and wire registry/current URI/source identity controls read, including report-map erase and readonly lens/reference projection.',
'original.rs':'Actual package nested body image/config/leading-BOM and malformed braced variable configured lexical vector controls read, no loader execution or absence proof.',
'hover.rs':'Whole test-only compatibility helper body read: catalogue/import/frame/package advice and report formatting, not production owner or generic absence/current binding proof.',
'source_command.rs':'Actual six-engine source advice/source erasure, complete prefix before unavailable tail, lambda/substitution and quoted body geometry controls read. No original interpreter oracle launched.',
'switch_to_dict.rs':'Actual source-context builder, BOM/input/source currency and expected source rewrite tests read. Expected enabled Logical action does not close independent transform/freshness authority obligations already recorded for production.',
'completion.rs':'Actual scoped body/current source metadata, injected legacy report roster/shadow/deletion refusal controls and static environment helper read. No positive source candidate→Native/physical frame grant.'}
for x in w['regions']:
 key=(x['path'],x['start_line'],x['end_line'],x['source_sha256']);assert key not in existing;existing.add(key);d['regions'].append({key:x[key]for key in ['path','start_line','end_line','source_sha256']}|{'review_status':'reviewed_source_only','classification':'actual_whole_inline_source_and_owner_controls','reason':notes[Path(x['path']).name]+' Entire exact region actually read; no #[test]-based purity assumption, test/provider/Cargo/process/helper execution or source/assertion mutation. Source review only, no migration acceptance.'})
p.write_text(json.dumps(d,indent=2)+'\n')
