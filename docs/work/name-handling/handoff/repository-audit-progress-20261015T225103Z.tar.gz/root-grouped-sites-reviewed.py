from pathlib import Path
import datetime,hashlib,json,re
D=Path(__file__).resolve().parent
j=json.loads((D/'root-consumers.json').read_text()); rows=j['consumers']
q=json.loads((D/'root-grouped-site-location-candidates.json').read_text())['groups']
records=[]
for group in q:
    row=next(r for r in rows if r['id']==group['id'])
    sites=[]
    for location in group['locations']:
        if len(location['declarations'])==1:
            sites.append({'symbol':location['symbol'],'line':location['declarations'][0][0],'evidence':location['declarations'][0][1]})
    overrides={
      251:[('PRELUDE::__spec_test::say',160,'proc ::__spec_test::say'),('parse_report',528,'pub fn parse_report')],
      272:[('flatten_rule_path',278,'fn flatten_rule_path'),('write_irule_outputs',349,'let stem = flatten_rule_path'),('run_irule_context',834,'let flat = rule_path.trim_start_matches'),('run_extract',1107,'let flat = rule_path.trim_start_matches')],
      274:[('write_irule_outputs',373,'let label = entry'),('run_minify',1258,'let label = entry'),('run_minify',1274,'let map_str = map_path.to_string_lossy')],
      277:[('match_virtual',176,'let dest_text = vs'),('parse_destination',145,'fn parse_destination')],
      280:[('expected_event_sequence',423,'fn expected_event_sequence')],
      283:[('explain_flow_value.keylog',1717,'to_string_lossy'),('explain_flow_value.configs',1725,'to_string_lossy'),('run_explain_flow.keylog',1772,'to_string_lossy'),('run_explain_flow.configs',1779,'to_string_lossy')],
      293:[('PkgCommand::Run.extra',1116,'extra: Vec<String>'),('VenvCommand::Run.command',1274,'command: Vec<String>')],
      294:[('Command::Rename.path',249,'path: String'),('Command::Convert.path',340,'path: String'),('Command::Redact.path',473,'path: String'),('Command::Unredact.map_file',505,'map_file: String'),('Command::Unredact.path',507,'path: String'),('Command::EncryptSecrets.path',518,'path: String'),('Command::DecryptSecrets.path',538,'path: String'),('Command::Pull.output',585,'output: Option<String>'),('Command::Push.payload',600,'payload: String'),('Command::RegistryDump.output',770,'output: String'),('IruleInputArgs.paths',793,'pub paths: Vec<String>'),('IruleInputArgs.output',806,'pub output: String'),('IruleCommand::EventInfo.output',878,'output: String'),('IruleCommand::Extract.paths',908,'paths: Vec<String>')],
    }
    if group['index'] in overrides:
        sites=[{'symbol':a,'line':b,'evidence':c} for a,b,c in overrides[group['index']]]
    source=(D/'root-source'/row['path']).read_bytes();assert hashlib.sha256(source).hexdigest()==row['source_sha256']
    lines=source.decode().splitlines()
    for site in sites:
        # Exact source sites below were reread. If a nearby site was recorded,
        # resolve its actual unique evidence occurrence rather than retaining a guess.
        at=site['line']-1
        if site['evidence'] not in lines[at]:
            candidates=[n for n,line in enumerate(lines) if site['evidence'] in line and abs(n-at)<=8]
            assert len(candidates)==1,(row['id'],site,candidates)
            site['line']=candidates[0]+1
        site['source_line']=lines[site['line']-1]
        site['source_sha256']=row['source_sha256']
        site['source_line_sha256']=hashlib.sha256(lines[site['line']-1].encode()).hexdigest()
    assert sites
    row['integration_sites']=sites
    row['semantic_unit_status']='actual_call_sites_listed_but_independent_atomic_purpose_reconciliation_pending'
    records.append({'id':row['id'],'path':row['path'],'purpose':row['purpose'],'work_kind':row['work_kind'],'sites':sites,'status':'Actual source/declarations and operational callers inspected; purpose group is not a published consumer unit.'})
(D/'root-consumers.json').write_text(json.dumps(j,indent=2)+'\n')
out={'baseline':j.get('baseline'),'reviewed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'Grouped remaining Root purposes now list actual physical sites. Semantic duplication, purpose granularity and cross-owner dependency review remain explicit. Counts are not a remaining-consumer total.','groups':records,'remaining_consumer_total':None,'deliberate_exclusions':['Command::Query.input contains a compound KIND NAME=PATH grammar and already has its own Query binding-identifier row; it is not a simple native path field.','Command::Cleanup.keep, Query expression strings, iRule source/dialect and remote object names are Unicode logical data, not automatically native Path fields.','EVENT_ORDER is a metadata producer dependency of expected_event_sequence, not a second executed resolver.','call-site evidence does not establish original provider behavior, transform eligibility or green gates.']}
(D/'root-grouped-sites-review.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'groups_with_actual_sites':len(records),'listed_sites':sum(len(x['sites']) for x in records),'remaining_consumer_total':None}))
