import runpy,json,datetime
from pathlib import Path
B=Path('/workspace/name-session/full-consumer-audit');x=runpy.run_path(str(B/'audit-review-tools.py'));c,s=x['load']();changes=[]
for r in s['consumers']:
 if r['path']!='rust/bigip-report-gen/python/python/f5report/graph.py':continue
 if r['symbol'] not in {'_pattern_matches','pattern_reaches'}:continue
 before={k:r[k] for k in ['id','disposition','missing_integration']}
 if r['symbol']=='_pattern_matches':
  r['disposition']='shared_owner';r['missing_integration']='Actual predicate only matches a retained conditional source pattern DTO; no demonstrated runtime/absence/Native authority is issued here. Parallel Python implementation by itself is not a migration defect. Cross-language parity and provider applicability remain unexecuted validation; downstream negative closure is recorded at attach_matches and report orphan sink.'
 else:
  r['disposition']='migrated_validation_pending';r['missing_integration']='This is an explicit conditional source visibility policy, matching the already-reviewed Rust graph purpose. Its docstring describes a provider premise requiring actual F5 answers; no contrary provider observation establishes an implementation defect here. Do not count duplication alone as a consumer migration. Unknown/direct-call-context and definite orphan closure defects remain at build_rule_contexts/attach_matches/sink.'
 r['semantic_correction']='Independent comparison to actual Rust graph::pattern_reaches shared-owner disposition; same recipe is not sufficient evidence of duplicate semantic resolver requiring migration.';r.pop('repair_group',None)
 changes.append({'before':before,'after':{k:r[k] for k in ['id','disposition','missing_integration']}})
x['save'](c,s);(B/'audit-python-pattern-purpose-correction.json').write_text(json.dumps({'baseline':c['baseline'],'reviewed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'changes':changes,'remaining_consumer_total':None,'validation':'Source-purpose challenge only; no provider/Python/Rust execution.'},indent=2)+'\n')
print(len(changes))
