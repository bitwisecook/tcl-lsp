import runpy,hashlib,json,xml.etree.ElementTree as ET,zipfile
m=runpy.run_path('/workspace/name-session/full-consumer-audit/lsp-audit.py');r=m['ROOT'];c,k=m['load']();groups=[]
rules={
 'host_lock_data':['editors/vscode/package-lock.json','editors/zed/Cargo.lock','rust/tcl-lsp-server-wasi/Cargo.lock','rust/tcl-lsp-server-wasm/Cargo.lock'],
 'license_text':['editors/vscode/LICENSE.txt','editors/zed/LICENSE'],
 'vendor_gradle_wrapper':['editors/jetbrains/gradlew','editors/jetbrains/gradlew.bat','editors/jetbrains/gradle/wrapper/gradle-wrapper.jar'],
 'tracked_ide_cache_metadata':['editors/jetbrains/.intellijPlatform/localPlatformArtifacts/IU-241.14494.240/bundledPlugin-org.jetbrains.plugins.textmate-IU-241.14494.240.xml','editors/jetbrains/.intellijPlatform/sandbox/IU-2024.1/config/disabled_plugins.txt','editors/jetbrains/.intellijPlatform/sandbox/IU-2024.1/config/options/updates.xml'],
 'static_vector_icon':['editors/jetbrains/src/main/resources/META-INF/pluginIcon.svg','editors/jetbrains/src/main/resources/META-INF/pluginIcon_dark.svg'],
}
for rule,paths in rules.items():
 files=[]
 for p in paths:
  f=next(x for x in c['files']if x['path']==p);raw=(m['BASE']/p).read_bytes();reason={
   'host_lock_data':'Exact dependency lock data: npm/Cargo package-manager identities/versions/hashes for host builds, not Tcl names, source parsing, dispatch, editor implementation or generated Tcl guidance. Not excluded by extension globally.',
   'license_text':'Exact standard GPLv3 legal license document, header identified; no implementation, Tcl syntax example guidance or dynamic source consumer.',
   'vendor_gradle_wrapper':'Exact third-party Gradle wrapper bootstrap, Apache-2.0 generated upstream launcher/binary. Identified original header/JAR manifest/class roster, not first-party Tcl naming consumer. No launcher/provider execution.',
   'tracked_ide_cache_metadata':'Exact tracked IDE SDK/sandbox artifact metadata inspected as empty/plugin dependency/update config. Not the unrelated untracked VSCode cache and no production Tcl naming/source actions.',
   'static_vector_icon':'Exact SVG structural asset inspected XML elements/attributes; only SVG geometry/filters/local fragment references, no script/event/external source. No Tcl/source naming implementation.',
  }[rule]
  extra={}
  if rule=='static_vector_icon':
   root=ET.fromstring(raw);tags={e.tag.rsplit('}',1)[-1]for e in root.iter()};assert tags<={'svg','defs','linearGradient','stop','filter','feGaussianBlur','feOffset','feComponentTransfer','feFuncA','feMerge','feMergeNode','path','g','circle','use'}
   assert not any(a.lower().startswith('on') for e in root.iter()for a in e.attrib)
   href=[v for e in root.iter()for a,v in e.attrib.items()if a.rsplit('}',1)[-1]=='href'];assert all(v.startswith('#')for v in href)
   extra=dict(tags=sorted(tags),references=sorted(set(href)))
  if p.endswith('.jar'):
   with zipfile.ZipFile(m['BASE']/p)as z:extra=dict(manifest=z.read('META-INF/MANIFEST.MF').decode(),members=z.namelist())
  f.update(review_status='reviewed',review_mode='explicit_exact_nonproduction_manifest',classification='out_of_scope_'+rule,reason=reason,consumer_ids=[])
  files.append(dict(path=p,blob=f['blob'],source_sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw),reason=reason,inspection=extra))
 groups.append(dict(rule=rule,exact_paths_only=True,files=files))
for p in ['editors/jetbrains/.gitignore','editors/vscode/.gitignore','editors/vscode/.prettierignore','editors/zed/.gitignore','rust/tcl-lsp-server-wasi/.gitignore','rust/tcl-lsp-server-wasm/.gitignore']:
 f=next(x for x in c['files']if x['path']==p);f.update(review_status='reviewed',review_mode='full_file_source',classification='out_of_scope_build_ignore_configuration',reason='Full tiny config read. Build/cache/generated asset ignore paths only, no runtime Tcl name or source authority. Untracked VSCode test cache untouched.',consumer_ids=[])
m['save'](c,k);(r/'lsp-exact-nonproduction-manifest.json').write_text(json.dumps(dict(baseline='cc24c394004fc187378ba0eefb6c2c5b2615fb00',groups=groups,limitation='Exact listed files only. No production implementation file or test operational body is omitted by these rules.'),indent=2)+'\n')
