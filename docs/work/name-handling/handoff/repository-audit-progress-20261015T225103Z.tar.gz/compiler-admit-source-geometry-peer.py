exec(open('/workspace/name-session/full-consumer-audit/compiler-record-optimiser-source.py').read().split("root='rust/tcl-compiler/src/'")[0])
import hashlib,subprocess
peer=json.load(open(P/'root-compiler-source-geometry-peer.json'));assert peer['baseline']=='cc24c394004fc187378ba0eefb6c2c5b2615fb00'
for f in peer['files']:
 path=f['path'];r=next(x for x in c['rows']if x['path']==path)
 assert hashlib.sha256((P/'compiler-baseline'/path).read_bytes()).hexdigest()==r['source_sha256']==f['source_sha256']
 assert hashlib.sha256((P/'compiler-production'/path).read_bytes()).hexdigest()==f['aid_sha256']
 assert len((P/'compiler-production'/path).read_text().splitlines())==f['aid_lines']
 has_tests=bool(f['omitted_cfg_test_line_ranges']);r.update(review_status='production_reviewed_inline_tests_pending'if has_tests else'source_reviewed',production_review_complete=True,review_complete=not has_tests,review_mode='full_production_source_read_by_root_peer_exact_hash_receipt',classification='source_purpose_consumer_reviewed',justification='Root disjoint full production aid read, independently original/aid SHA verified. Actual stronger caller/source/getter guards preserved; omitted test/setup operations unfinished.',peer_review_receipt='root-compiler-source-geometry-peer.json',peer_read_aid_line_ranges=f['actual_read_aid_line_ranges'],embedded_cfg_test_operational_review_complete=False if has_tests else None,reviewed_utc=now)
for f in peer['targeted_caller_and_owner_reads']:
 path=f['path'];local=P/'compiler-baseline'/path
 data=local.read_bytes()if local.exists()else subprocess.check_output(['git','show',peer['baseline']+':'+path],cwd='/workspace/tcl-lsp')
 assert hashlib.sha256(data).hexdigest()==f['source_sha256']
 r=next((x for x in c['rows']if x['path']==path),None)
 if r is None:continue
 r.setdefault('supplemental_root_peer_reads',[]).append(dict(receipt='root-compiler-source-geometry-peer.json',source_sha256=f['source_sha256'],ranges=f['actual_targeted_read_ranges'],scope=f['scope']))
 if path=='rust/tcl-compiler/src/registry_invocation/authored_source_bodies.rs':
  assert len(data.splitlines())==381
  r.update(review_status='source_reviewed',production_review_complete=True,review_complete=True,review_mode='full_file_read',classification='shared_original_body_owner_reviewed',justification='Root actual supplemental read1-381 includes complete original file and all inline test/setup bodies; exact SHA independently verified. No execution or provider acceptance.',peer_review_receipt='root-compiler-source-geometry-peer.json',embedded_cfg_test_operational_review_complete=True)
 elif r.get('review_status')=='unexamined':r.update(review_status='partial_remainder_unexamined',production_review_complete=False,review_complete=False,review_mode='bounded_actual_caller_trace_by_root_peer_remainder_unexamined',classification='partial_naming_consumer_trace',justification='Only exact supplemental peer source ranges read; full remainder and omitted inline operations unexamined.')
for f in peer['purpose_proposals']:
 r=next(x for x in c['rows']if x['path']==f['path']);key=f['path']+'#'+f['symbol']+'#'+f['work_kind'];pending=f['disposition']=='pending_audit';disp='migrated_validation_pending'if pending else f['disposition']
 d['rows']=[x for x in d['rows']if x['key']!=key]+[dict(key=key,canonical_site_key=key,path=f['path'],symbol=f['symbol'],line=f['line'],site_purpose=f['work_kind'],source_sha256=r['source_sha256'],git_blob=r['git_blob'],actual_shared_api=f['actual_shared_api'],missing_integration=f['missing_integration'],disposition=disp,work_kind='validation_only'if pending or disp=='migrated_validation_pending'else'intentional/exclusion',work_kind_reason='Root complete hash-bound production/caller trace with independently verified source; no migration inferred from API name, report String, or unsupported hypothetical input.',pending_actual_caller_or_provider_review=pending,evidence=[f['evidence'],'Exact original/aid plus16 supplemental source hashes independently verified. Root corrections withdraw NativeCompilerWords-name Logical refusal and authored prefix ordinal speculation after actual admission guards.'],tests=[],validation='Unexecuted cc24 source-only audit. All omitted tests operationally unfinished except separately explicit whole authored_source_bodies supplemental read; no Native grant or conformance donation.')]
 r.setdefault('consumer_keys',[])
 if key not in r['consumer_keys']:r['consumer_keys'].append(key)
(P/'compiler-file-coverage.json').write_text(json.dumps(c,indent=2)+'\n');(P/'compiler-consumers.json').write_text(json.dumps(d,indent=2)+'\n');(P/'compiler-source-geometry-peer-admission.json').write_text(json.dumps(dict(baseline=peer['baseline'],receipt='root-compiler-source-geometry-peer.json',receipt_sha256=hashlib.sha256((P/'root-compiler-source-geometry-peer.json').read_bytes()).hexdigest(),full_reserved_files_admitted=16,full_supplemental_files_admitted=1,purpose_rows=20,new_confirmed_needs_migration=0,corrections=peer['corrections'],whole_scope_complete=False),indent=2)+'\n');print('admitted16+1 supplemental,20purposes')
