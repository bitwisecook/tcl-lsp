import json,sys,hashlib,re
from pathlib import Path
R=Path('/workspace/name-session/full-consumer-audit')
def record_file(path,reason,classification='production',end=None):
 p=R/'vm-file-coverage.json';d=json.loads(p.read_text());r=next(x for x in d['rows'] if x['path']==path);s=(R/'vm-source'/path).read_text();lines=s.splitlines();end=end or len(lines)
 r.update(review_mode='production_body_read',classification=classification,reason=reason,review_ranges=[[1,end]])
 if end<len(lines):r['excluded_ranges']=[{'start':end+1,'end':len(lines),'rule':'inline #[cfg(test)] module; test-only conformance carrier, not production; no execution acceptance'}]
 p.write_text(json.dumps(d,indent=2)+'\n')
def consumer(path,symbol,site,line,context,api,missing,disposition,tests=[],evidence=[]):
 p=R/'vm-consumers.json';d=json.loads(p.read_text());f=next(x for x in json.loads((R/'vm-file-coverage.json').read_text())['rows'] if x['path']==path)
 d['consumers'].append({'id':'vm-'+str(len(d['consumers'])+1).zfill(4),'path':path,'symbol':symbol,'site':site,'line':line,'source_sha256':f['source_sha256'],'blob':f['blob'],'context':context,'shared_api':api,'missing_integration':missing,'disposition':disposition,'tests':tests,'evidence':evidence,'validation':'No execution performed by audit. A test/evidence path is scoped evidence, not an assertion it ran on this baseline.'})
 p.write_text(json.dumps(d,indent=2)+'\n')
def record_production(path,reason,classification='production'):
 s=(R/'vm-source'/path).read_text();m=re.search(r'(?m)^#\[cfg\((?:all\()?test[^\n]*\)\]\n(?:#\[path[^\n]*\]\n)?mod tests[; {]',s);end=s[:m.start()].count('\n') if m else len(s.splitlines());record_file(path,reason,classification,end=end)
if __name__=='__main__':exec(sys.stdin.read())
