import json,hashlib,os
from pathlib import Path
R=Path('/workspace/name-session/full-consumer-audit');p=R/'vm-consumers.json';raw=p.read_bytes();d=json.loads(raw)
rs=[r for r in d['consumers'] if r['disposition']=='migrated_validation_pending' and not r.get('status_review')][:40]
assert rs[0]['id']=='vm-0413' and rs[-1]['id']=='vm-0500'
changes={
'vm-0417':('pending_audit','Actual cache producer present, but live command incarnation/name-invalidation correspondence for display_oo_bytes is explicitly unestablished; do not classify as fully integrated naming publication.'),
'vm-0429':('pending_audit','Actual global observer/original variable recipe is implemented, but retained original wait caller/name/header across yielded event callbacks remains an unresolved integration-purpose trace.'),
'vm-0433':('pending_audit','Original argument getter transport exists; exact trace CString/object API subject flags and actual cell/token registration join remain separately unestablished. No requirement for object cache is guessed.'),
'vm-0469':('shared_owner','Actual neutral retained-data/backing owner intentionally permits parent shimmer/retirement with independently live children; strict header/window is separate API purpose. This is existing owner, not a remaining consumer migration.'),
'vm-0475':('pending_audit','Source EventRegistry/rule epoch policy exists but genuine reached framework event/rule origin needed for execution permission is not established by helper spelling; no TMM permission inferred.'),
'vm-0478':('shared_owner','This is actual exact/resident command observation currentness owner with lifetime/header checks; unchanged caller adoption is counted separately.'),
'vm-0481':('shared_owner','Existing Value primary storage owner retains actual Weak name/owned index and documents no guest callback; consumer compliance is independent purpose, storage owner itself not a migration.'),
'vm-0486':('shared_owner','Existing host/guest error metadata projection preserves typed refusal and resident bytes; no remaining naming consumer change identified at this bounded adapter.')}
out=[]
for r in rs:
 old=r['disposition']
 if r['id'] in changes:new,why=changes[r['id']];r['disposition']=new
 else:new=old;why='Bounded implemented component retained: '+r['context']+' Independent limit remains: '+r['missing_integration']
 r['status_review']={'receipt':'vm-status-reconciliation-resumed-04.json','previous':old,'current':new,'reason':why,'basis':'Individual actual source-purpose review; complete production file reads do not grant execution or unresolved outer currentness.'}
 out.append({'id':r['id'],'path':r['path'],'symbol':r['symbol'],'previous':old,'current':new,'reason':why})
(R/('vm-consumers-before-status04-'+hashlib.sha256(raw).hexdigest()[:12]+'.json')).write_bytes(raw)
for name,obj in [('vm-consumers.json',d),('vm-status-reconciliation-resumed-04.json',{'baseline':d['baseline'],'reviewed_rows':out,'scope':'40 individual legacy status rereviews; no tests/providers executed'})]:
 q=R/name;t=q.with_suffix('.tmp');t.write_text(json.dumps(obj,indent=2)+'\n');os.replace(t,q)
