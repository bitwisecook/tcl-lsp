import json,collections,datetime
from pathlib import Path
r=Path('/workspace/name-session/full-consumer-audit');p=r/'lsp-consumers.json';d=json.loads(p.read_text());by={x['id']:x for x in d['consumers']}
# Explicit adjudications from actual source evidence, not enum/work-kind inference.
changes={
'lsp-generated-editor-event-catalogue':('needs_migration','Generated projection exists, but exact cc24 HTTP_REQUEST introduction metadata is statically stale against the actual retained Registry row. This is demonstrated generated descriptor parity work, not merely execution pending.','descriptor_metadata_target_schema'),
'lsp-extract-proc-original-transform-abstention':('pending_validation','Actual intentional refusal boundary is implemented. Successful extraction/semantic transform is explicitly unavailable; calling this a migrated transform would overstate scope. Validate this refusal purpose independently; other extraction requirements remain separately needs_migration.',None),
'lsp-wasi-operational-test-host-source-purpose':('pending_validation','Whole actual operational test source is reviewed, but no naming-consumer migration is established by test setup itself. Exact WASI module/provider/artifact/source execution remains unperformed.',None),
'lsp-wasm-operational-test-store-purpose':('pending_validation','Whole actual Node operational test source is reviewed, but no naming-consumer migration is established by test setup itself. Node transport execution and actual browser host conformance remain distinct and unperformed.',None),
'lsp-editor-test-runner-manifest-census':('pending_validation','Actual existing complete test-roster/result census source is reviewed. This is validation infrastructure awaiting actual current compiled-manifest/provider execution, not a Tcl naming migration.',None)
}
receipt=[]
for id,(disp,why,kind) in changes.items():
 x=by[id];before=x['disposition'];x['disposition']=disp;x['review_state']='actual_source_review_complete';x['implementation_state_reason']=why
 if kind:x['work_kind']=kind;x['work_kind_reason']=why;x['work_kind_evidence']='Exact cc24 generated source versus actual same-baseline Registry EventProps lifecycle and directly traced generator; no drift command executed.'
 x['disposition_correction']={'previous':before,'reason':why,'baseline':d['baseline']};receipt.append({'id':id,'previous':before,'current':disp,'reason':why,'path':x['path'],'source_sha256':x['source_sha256']})
d['work_kind_contract']['rows_classified']=len(d['consumers']);d['limitations'].append('Disposition correction annex lsp-disposition-corrections.json distinguishes actual source review from implementation state. All123 owner_requirement_unresolved rows were individually retained needs_migration; they were never treated as migrated_validation_pending. Existing migrated_validation_pending rows describe only their bounded implemented/shared-owner projection, not unimplemented dependent domains or whole-surface closure.')
p.write_text(json.dumps(d,indent=2)+'\n')
(r/'lsp-disposition-corrections.json').write_text(json.dumps({'baseline':d['baseline'],'kind':'explicit_evidence_adjudication_not_bulk_enum_reclassification','changes':receipt,'unresolved_owner_requirement_rows':123,'unresolved_rows_disposition':'needs_migration','no_execution':True},indent=2)+'\n')
(r/'lsp-work-kind-summary.json').write_text(json.dumps({'baseline':d['baseline'],'rows':len(d['consumers']),'counts':dict(collections.Counter(x['work_kind'] for x in d['consumers'])),'needs_migration_counts':dict(collections.Counter(x['work_kind'] for x in d['consumers'] if x['disposition']=='needs_migration')),'unknown_is_unfinished':True,'no_execution':True,'classification_limit':'Purpose rows, not patch counts; unresolved owner requirements remain unfinished.'},indent=2)+'\n')
