from pathlib import Path
import re,json,hashlib
ROOT=Path('/workspace/name-session/full-consumer-audit')
BASE=ROOT/'lsp-baseline'
def masked(raw):
    s=raw.decode(); m=list(s); i=0
    def hide(a,b): m[a:b]=' '*(b-a)
    while i<len(s):
        if s.startswith('//',i):
            j=s.find('\n',i); j=len(s) if j<0 else j; hide(i,j); i=j; continue
        if s.startswith('/*',i):
            j=i+2; depth=1
            while j<len(s) and depth:
                if s.startswith('/*',j): depth+=1;j+=2
                elif s.startswith('*/',j): depth-=1;j+=2
                else:j+=1
            hide(i,j);i=j;continue
        raw_start=re.compile(r'r(#{0,255})"').match(s,i)
        if raw_start:
            end='"'+raw_start.group(1);j=s.find(end,i+len(raw_start.group(0)))
            assert j>=0
            j+=len(end);hide(i,j);i=j;continue
        if s[i]=='"':
            j=i+1
            while j<len(s):
                if s[j]=='\\':j+=2
                elif s[j]=='"':j+=1;break
                else:j+=1
            hide(i,j);i=j;continue
        if s[i]=="'":
            if i+2<len(s) and s[i+2]=="'":j=i+3
            elif i+1<len(s) and s[i+1]=='\\':
                end=s.find("'",i+2,min(i+20,len(s)));j=end+1 if end>=0 else i
            else:j=i
            if j>i:hide(i,j);i=j;continue
        i+=1
    return ''.join(m)

def production(path):
 raw=(BASE/path).read_bytes();s=raw.decode();m=masked(raw);ranges=[]
 for match in re.finditer(r'#\s*\[\s*cfg\s*\(\s*test\s*\)\s*\]',m):
  start=match.start()
  tail=m[match.end():]
  # Only whole cfg(test) items can be omitted. Variant/match-arm attributes
  # remain visible rather than consuming the next unrelated production item.
  if not re.match(r'\s*(?:#\[[^\]]*\]\s*)*(?:pub(?:\([^)]*\))?\s+)?(?:(?:async|unsafe)\s+)*(?:fn|mod|struct|enum|impl|const|static|use|type)\b',tail):
   continue
  brace=m.find('{',match.end());semi=m.find(';',match.end())
  if semi>=0 and (brace<0 or semi<brace):end=semi+1
  else:
   assert brace>=0,path
   end=brace+1;depth=1
   while depth:
    assert end<len(m),path
    if m[end]=='{':depth+=1
    elif m[end]=='}':depth-=1
    end+=1
  ranges.append((start,end))
 a=list(s)
 for start,end in ranges:
  for i in range(start,end):
   if a[i]!='\n':a[i]=' '
 return ''.join(a),ranges

def load():return json.loads((ROOT/'lsp-file-coverage.json').read_text()),json.loads((ROOT/'lsp-consumers.json').read_text())
def save(coverage,consumers):
 (ROOT/'lsp-file-coverage.json').write_text(json.dumps(coverage,indent=2)+'\n');(ROOT/'lsp-consumers.json').write_text(json.dumps(consumers,indent=2)+'\n')
def review(path,classification,reason,mode='full_production_source',ids=()):
 c,k=load();row=next(r for r in c['files'] if r['path']==path);row.update(review_status='reviewed',review_mode=mode,classification=classification,reason=reason,consumer_ids=list(ids));save(c,k)
def consumer(id,path,symbol,needle,context,api,missing,disposition,tests,evidence):
 c,k=load();raw=(BASE/path).read_bytes();s=raw.decode();line=s[:s.index(needle)].count('\n')+1
 row=dict(id=id,path=path,symbol=symbol,site=needle,line=line,source_sha256=hashlib.sha256(raw).hexdigest(),context=context,shared_api=api,missing_integration=missing,disposition=disposition,tests=tests,evidence=evidence)
 assert not any(x['id']==id for x in k['consumers']);k['consumers'].append(row);save(c,k)
