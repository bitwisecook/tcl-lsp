from pathlib import Path
import json,datetime,os
R=Path('/workspace/name-session/full-consumer-audit')
def atomic(path,text):
 tmp=path.with_name(path.name+'.db-tmp');tmp.write_text(text);tmp.replace(path)
def record(batch,items):
 p=R/'db-file-coverage.json';c=json.loads(p.read_text());by={x['path']:x for x in c['files']};paths={x[0]for x in items};receipts=[]
 for path,parent,detail in items:
  x=by[path];lines=len((R/'db-baseline'/path).read_text().splitlines());x.update(review_status='reviewed',review_mode='complete_original_test_source_read_including_operational_setup_and_assertions',classification='retained_test_control_and_operational_setup',justification='Complete original source actual-read, every helper/setup/config/provider/namespace/argv/guard/serialization and assertion included; no test-membership purity inference. '+detail+' Test-only actual parent owner: '+parent+'. No execution or migration acceptance.')
  receipts.append({'path':path,'blob':x['blob'],'source_sha256':x['source_sha256'],'lines_read':[1,lines],'ownership':parent,'classification':detail,'execution':'unexecuted'})
 atomic(p,json.dumps(c,indent=2)+'\n')
 for fn,key in [('db-inline-operational-test-census.json','tests'),('db-test-helper-inventory.json','helpers')]:
  p=R/fn;x=json.loads(p.read_text())
  for a in x[key]:
   if a['path']in paths:a['review_status']='complete_original_body_source_read';a['actual_read_receipt']=batch
  atomic(p,json.dumps(x,indent=2)+'\n')
 atomic(R/batch,json.dumps({'baseline':c['baseline'],'as_of_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'method':'All original source actual-read; operational setup/helper/guard/serialization and assertions included, no execution; no omitted bodies inferred pure.','files':receipts},indent=2)+'\n')
