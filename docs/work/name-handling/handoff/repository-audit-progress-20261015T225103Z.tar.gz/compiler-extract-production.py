from pathlib import Path
import json,re,hashlib
RAW=re.compile(r'(?:b|c)?r(#{0,255})"')
ROOT=Path('/workspace/name-session/full-consumer-audit');BASE=ROOT/'compiler-baseline'
def mask(s):
 out=list(s); n=len(s); i=0
 def erase(a,b):
  for k in range(a,b):
   if out[k]!='\n':out[k]=' '
 while i<n:
  if s.startswith('//',i):
   j=s.find('\n',i);j=n if j<0 else j;erase(i,j);i=j
  elif s.startswith('/*',i):
   j=i+2;depth=1
   while j<n and depth:
    if s.startswith('/*',j):depth+=1;j+=2
    elif s.startswith('*/',j):depth-=1;j+=2
    else:j+=1
   erase(i,j);i=j
  else:
   m=RAW.match(s,i)
   if m:
    term='"'+m.group(1);j=s.find(term,m.end());j=n if j<0 else j+len(term);erase(i,j);i=j
   elif s[i]=='"' or (s[i] in 'bc' and i+1<n and s[i+1]=='"'):
    j=i+(2 if s[i]!='"' else 1)
    while j<n:
     if s[j]=='\\':j+=2
     elif s[j]=='"':j+=1;break
     else:j+=1
    erase(i,min(j,n));i=j
   elif s[i]=="'" and i+2<n and (s[i+2]=="'" or s[i+1]=='\\'):
    j=i+1
    if s[j]=='\\':
     j+=2
     if j<n and s[j]=='{':
      j=s.find('}',j);j=n if j<0 else j+1
    else:j+=1
    if j<n and s[j]=="'":j+=1;erase(i,j);i=j
    else:i+=1
   else:i+=1
 return ''.join(out)
rows=[]
for f in json.load(open(ROOT/'compiler-assigned-files.json'))['files']:
 if not f['path'].endswith('.rs'):continue
 p=BASE/f['path'];s=p.read_text();m=mask(s);spans=[]
 for a in re.finditer(r'#\s*\[\s*cfg\s*\(\s*test\s*\)\s*\]',m):
  if any(x<=a.start()<y for x,y in spans):continue
  i=a.end();stack=[];j=i
  while j<len(m):
   c=m[j]
   if c in '([':stack.append(c)
   elif c in ')]' and stack:stack.pop()
   elif not stack and c==';':j+=1;break
   elif not stack and c=='{':
    depth=1;j+=1
    while j<len(m) and depth:
     if m[j]=='{':depth+=1
     elif m[j]=='}':depth-=1
     j+=1
    break
   j+=1
  spans.append((a.start(),j))
 lines=s.splitlines(True);omitted=[]
 for a,b in spans:omitted.append((s.count('\n',0,a)+1,s.count('\n',0,b)+1))
 result=[]
 for n,l in enumerate(lines,1):
  if any(a<=n<=b for a,b in omitted):continue
  result.append(f'{n}: {l}')
 dst=ROOT/'compiler-production'/f['path'];dst.parent.mkdir(parents=True,exist_ok=True);dst.write_text(''.join(result))
 rows.append({'path':f['path'],'source_sha256':hashlib.sha256(s.encode()).hexdigest(),'original_bytes':len(s.encode()),'production_review_bytes':sum(len(x.encode()) for x in result),'omitted_cfg_test_line_ranges':omitted,'note':'review aid only; no automatic file review or semantic classification'})
(ROOT/'compiler-production-index.json').write_text(json.dumps(rows,indent=2)+'\n')
print('Rust files',len(rows),'rawbytes',sum(r['original_bytes'] for r in rows),'productionreviewbytes',sum(r['production_review_bytes'] for r in rows))
print('\n'.join(str(r['production_review_bytes'])+' '+r['path'] for r in sorted(rows,key=lambda r:r['production_review_bytes'],reverse=True)[:20]))
