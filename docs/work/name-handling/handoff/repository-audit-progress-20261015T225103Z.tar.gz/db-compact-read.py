from pathlib import Path
import sys
R=Path('/workspace/name-session/full-consumer-audit');p=sys.argv[1];a=(R/'db-production'/p).read_text().splitlines();first=int(sys.argv[2]) if len(sys.argv)>2 else 1;last=int(sys.argv[3]) if len(sys.argv)>3 else len(a)
print('FILE',p,'original line range',first,last,'DISPLAY: every nonblank original production-aid line joined in10line blocks; only leading/trailing line indentation removed; strings/comments not excluded. Not executable source.')
for n in range(first-1,last,10):print(f'{n+1}–{min(n+10,last)}: '+' '.join(x.strip() for x in a[n:min(n+10,last)] if x.strip()))
