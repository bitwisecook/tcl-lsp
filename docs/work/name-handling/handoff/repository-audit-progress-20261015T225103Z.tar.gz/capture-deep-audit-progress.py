from pathlib import Path
import datetime,hashlib,io,json,tarfile
D=Path('/workspace/name-session/full-consumer-audit');H=Path('/workspace/tcl-lsp/docs/work/name-handling/handoff')
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');name=f'repository-audit-deep-progress-{stamp}.tar.gz';members=[]
paths=sorted(p for p in D.rglob('*') if p.is_file() and p.parent!=D and '__pycache__' not in p.parts)
with tarfile.open(H/name,'w:gz') as t:
 for p in paths:
  b=p.read_bytes();rel=str(p.relative_to(D));members.append(dict(path=rel,size=len(b),sha256=hashlib.sha256(b).hexdigest()))
  i=tarfile.TarInfo(rel);i.size=len(b);t.addfile(i,io.BytesIO(b))
 b=json.dumps(dict(status='Exact nested audit artifacts and source snapshots retained, no semantic acceptance inferred.',members=members),indent=2).encode();i=tarfile.TarInfo('DEEP-CAPTURE-MEMBERS.json');i.size=len(b);t.addfile(i,io.BytesIO(b))
with tarfile.open(H/name) as t:
 for m in members:assert hashlib.sha256(t.extractfile(m['path']).read()).hexdigest()==m['sha256']
with (H/name).open('rb') as f:sha=hashlib.file_digest(f,'sha256').hexdigest()
size=(H/name).stat().st_size;parts=[]
if size>=90*1024*1024:
 with (H/name).open('rb') as src:
  k=0
  while True:
   b=src.read(40*1024*1024)
   if not b:break
   k+=1;part=name+f'.part{k:02}';(H/part).write_bytes(b);parts.append(dict(file=part,size=len(b),sha256=hashlib.sha256(b).hexdigest()))
 (H/name).unlink()
else:parts=[dict(file=name,size=size,sha256=sha)]
manifest=dict(baseline='cc24c394004fc187378ba0eefb6c2c5b2615fb00',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='Paused source audit; exact nested artifacts retained, not a completed migration census.',archive_name=name,archive_sha256=sha,archive_bytes=size,parts=parts,verified_members=len(members),uncompressed_bytes=sum(m['size'] for m in members),members=members)
(D/'deep-artifact-capture.json').write_text(json.dumps(manifest,indent=2)+'\n')
j=json.loads((H/'packets.json').read_text())
for p in parts:
 j.append(dict(file=p['file'],sha256=p['sha256'],status=f'Exact nested audit snapshots/receipts, {len(members)} verified members; archive SHA256 {sha}; concatenate ordered parts if split. Source/provenance retention only, no review or execution acceptance.'))
(H/'packets.json').write_text(json.dumps(j,indent=2)+'\n')
with (H/'SHA256SUMS').open('a') as f:
 for p in parts:f.write(p['sha256']+'  '+p['file']+'\n')
print(json.dumps({k:v for k,v in manifest.items() if k!='members'}))
