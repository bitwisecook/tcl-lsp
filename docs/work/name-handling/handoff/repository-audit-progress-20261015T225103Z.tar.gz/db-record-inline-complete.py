from pathlib import Path
import runpy,json,datetime
R=Path('/workspace/name-session/full-consumer-audit'); atomic=runpy.run_path(str(R/'db-record.py'))['atomic']
def record(batch,paths):
 p=R/'db-file-coverage.json';c=json.loads(p.read_text());idx={x['path']:x for x in c['files']}; receipts=[]
 for path in paths:
  x=idx[path]; x['prior_review_status']=x['review_status'];x.update(review_status='reviewed',review_mode='complete_production_and_original_inline_operational_source_read',justification=x['justification']+' All original omitted cfg(test)/test/helper/module contents now separately actual-read line-completely; source/config/argv/environment/provider/serialization/assertion purposes inspected, no purity inference or execution acceptance.')
  receipts.append({'path':path,'blob':x['blob'],'source_sha256':x['source_sha256'],'production':'prior exact complete production receipt retained','inline':'Every nonblank original line omitted from production aid actually read, including helper/test/module ownership; original fixed controls unchanged','execution':'unexecuted'})
 atomic(p,json.dumps(c,indent=2)+'\n')
 for fn,key in [('db-inline-operational-test-census.json','tests'),('db-test-helper-inventory.json','helpers')]:
  p=R/fn;x=json.loads(p.read_text())
  for a in x[key]:
   if a['path']in paths:a.update(review_status='complete_original_body_source_read',actual_read_receipt=batch)
  atomic(p,json.dumps(x,indent=2)+'\n')
 atomic(R/batch,json.dumps({'baseline':c['baseline'],'as_of_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':receipts},indent=2)+'\n')
