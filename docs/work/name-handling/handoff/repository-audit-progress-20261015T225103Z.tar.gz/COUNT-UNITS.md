# Audit count and scale units

Consumer unit: one actual source integration boundary with one distinct naming purpose; grouped functions must list separate authentic sites when distinct code changes are needed.

Owner repair: one shared semantic owner change, counted separately from unchanged affected consumers. List downstream callers; count their migrations only if their code must change.

Keep existing API adoption, shared-owner extension, metadata/target schema, validation infrastructure and documentation work distinct.

Remaining code migrations exclude existing owners/display/fixed oracle data. Actual test/provider transport changes remain validation work, not accepted semantics.

Provenance-classified original oracle source/data must retain independence; do not migrate original Tcl/Jim C APIs into the implementation under test.

Every provisional record must map to an actual canonical unit, a no-change disposition or an explicit unfinished source/provider question. Do not infer semantic uniqueness from IDs/hash checks.

Final effort categories describe change scope, not invented duration: S=local adapter;M=multiple adapters/shared facet;L=owner+producer/lifetime transport;XL=cross-engine/context architecture with broad proof closure.

Each owner provide canonical migration-units JSON with exact source sites, representation/context, current shared API, required code change, family ID, affected callers, actual evidence, control obligations, state/work kind and relative effort. Include original-row mapping and unresolved questions explicitly.
