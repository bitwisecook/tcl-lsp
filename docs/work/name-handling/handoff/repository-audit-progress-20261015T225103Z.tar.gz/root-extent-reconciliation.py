from pathlib import Path
import collections,datetime,hashlib,json
D=Path(__file__).resolve().parent
census=json.loads((D/'root-inline-operational-census.json').read_text())
assert all(x['review_status'] in {'actual_complete_region_source_read','actual_complete_source_read'} for x in census['regions'])
queue=json.loads((D/'root-inline-read-queue.json').read_text())
assert all(x['status']=='actual_source_read' for x in queue['chunks'])
p=D/'root-file-coverage.json';j=json.loads(p.read_text());changes=[]
for r in j['files']:
    if r['review_status']!='production_reviewed':continue
    data=(D/'root-source'/r['path']).read_bytes()
    assert hashlib.sha256(data).hexdigest()==r['sha256']
    # Root's full production/operational source read and actual known inline
    # setup read have both finished. Preserve the earlier narrower production
    # receipt instead of implying it already covered the inline bodies.
    extent=[1,len(data.decode().splitlines())]
    if r.get('reviewed_lines')!=extent:
        changes.append({'path':r['path'],'source_sha256':r['sha256'],'previous_reviewed_lines':r.get('reviewed_lines'),'complete_actual_read_lines':extent})
        r['previous_production_reviewed_lines']=r.get('reviewed_lines')
        r['reviewed_lines']=extent
    r['complete_source_read_receipt']='root-extent-reconciliation.json'
    r['operational_review_status']='Actual source/setup/provider construction/guards read; external callee obligations and execution remain independent.'
p.write_text(json.dumps(j,indent=2)+'\n')
out={'baseline':j['baseline'],'reviewed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_scope':203,'known_inline_regions_actual_read':len(census['regions']),'additional_composite_regions':census.get('additional_composite_cfg_regions',[]),'changes':changes,'evidence':['root-inline-operational-census.json','root-inline-read-queue.json','root-inline-actual-read-admissions.json','root-operational-review-01.py','root-operational-review-02.py','root-host-peer-reconciliation.json'],'limitations':['Actual file/region reading does not close external provider/callee operations.','No original test selector/assertion/source changed or executed by the audit.','Generated drift, successor review, independent semantic unit reconciliation and required repository gates remain unfinished.'],'remaining_consumer_total':None}
(D/'root-extent-reconciliation.json').write_text(json.dumps(out,indent=2)+'\n')
s=D/'root-scope-status.json';q=json.loads(s.read_text());q['status']='All344 assigned paths have source/provenance dispositions and Root203 actual complete production/operational reads.321 provisional purposes have work-kind;22 grouped remaining purposes list66 physical sites; independent atomic reconciliation remains unfinished, not migration completion.';q['reserved_compiler_peer']='Four reserved Compiler production aids fully read and SHA-verified; Compiler admitted its own primary rows. Omitted tests remain unexamined in that packet.';q.pop('next_reserved_peer_packet',None);q['extent_receipt']='root-extent-reconciliation.json';s.write_text(json.dumps(q,indent=2)+'\n')
print(json.dumps({'whole_source_extents_reconciled':len(changes),'source_scope':203,'remaining_consumer_total':None}))
