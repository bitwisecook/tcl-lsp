from pathlib import Path
import runpy,json
R=Path('/workspace/name-session/full-consumer-audit');record=runpy.run_path(str(R/'db-record.py'))['record']
def completed(items):
 rows=[];files=[]
 for path,end,symbol,line,detail in items:
  files.append((path,'shared_command_metadata_and_semantic_owner',f'Complete production actual-read through original line{end}; all unmasked metadata, comments and actual helper bodies inspected. '+detail+' Inline operational test review remains separate when masked.'))
  rows.append(dict(id='registry.command.'+Path(path).stem+'-descriptor',path=path,symbol=symbol,line=line,context=detail,shared_api='CommandSpec/SubCommand; typed actual implementation paths, selected source-role/format owners',missing_integration=None,disposition='shared_owner',work_kind='owner_contract',tests=['Existing command tests retained; inline setup/operational review tracked separately.'],evidence=[f'All production source through{end} actual-read at pinned baseline; no execution or Native owner admission inferred from metadata.']))
 record(files,rows);p=R/'db-file-coverage.json';x=json.loads(p.read_text());paths={a[0] for a in items}
 for r in x['files']:
  if r['path'] in paths:
   t=(R/'db-baseline'/r['path']).read_text()
   if '#[cfg(test)]' in t or '#[test]' in t:r.update(review_status='production_reviewed_inline_tests_pending',review_mode='complete_production_source_read_inline_operational_tests_pending')
 p.write_text(json.dumps(x,indent=2)+'\n')
if __name__=='__main__':
 b='rust/tcl-registry/src/commands/tcl/'
 completed([(b+'binary_.rs',605,'encoding_path / decoding_path / binary_scan_arg_roles / spec',58,'Central original public/nested encoding worker path descriptors retain command/prepended coordinates and C8.6 phase; actual Native/compiler/currentness prerequisites remain independent. Scan target positions are cardinality-only and selected handler/may-write descriptors retain conditional writes.'),(b+'clock_.rs',676,'clock_*_registration / clock_bootstrap_ensemble / spec',43,'Measured C8.6 constructor geometry is explicitly independent of handler effects; central private worker names/ensemble dependencies stay metadata requiring actual producer. Calendar context domains remain conservative, selected format/scan roles and per-release option availability are separate.'),(b+'format_.rs',637,'fold_format / Conversion / spec',74,'Shared Syntax format grammar owns actual specifier parsing; local versioned renderers deliberately decline size/star/positional/unavailable forms and nonASCII width/precision. Format output is evaluated value data, not source/name identity or construction authority.')])
