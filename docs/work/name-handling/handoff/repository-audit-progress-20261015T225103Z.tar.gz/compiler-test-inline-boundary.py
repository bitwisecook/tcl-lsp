import json,datetime,hashlib
from pathlib import Path
P=Path('/workspace/name-session/full-consumer-audit');c=json.loads((P/'compiler-file-coverage.json').read_text());m=json.loads((P/'compiler-test-source-manifest.json').read_text());idx={r['path']:r for r in json.loads((P/'compiler-production-index.json').read_text())};now=datetime.datetime.now(datetime.timezone.utc).isoformat();annex=[]
for a in m['rows']:
 r=next(x for x in c['rows'] if x['path']==a['path']);full=r.get('review_mode')=='full_file_read';helpersread=bool(a.get('helpers_reviewed_utc')) or r.get('review_complete',False)
 if a['path'].endswith('/tcl-version/src/git_inputs.rs'):
  a['production_include_also_present']=True;a['note']='Actual production build.rs includes git_inputs.rs; cfg(test) child path does not exclude this source from production. Whole file was read.'
 a['non_test_operational_helpers_reviewed']=helpersread
 a['inline_test_operational_setup_review_complete']=full or not a['test_functions']
 for t in a['test_functions']:
  t['body_review_mode']='full_file_read' if full else 'exact_membership_sha_only_inline_operations_unexamined'
  t['operational_setup_disposition']='reviewed_unexecuted' if full else 'unexamined; fixed assertion purity not inferred from #[test]'
 a['disposition']='full_file_read_unexecuted' if full else 'non_test_helpers_read_inline_test_operations_pending' if helpersread else 'test_parent_membership_only_all_operational_helpers_pending'
 if a['test_functions'] and not full:
  if r.get('review_status') in ['test_source_classified','source_reviewed']:
   r['prior_review_status']=r['review_status'];r['review_status']='test_operational_inline_pending';r['review_complete']=False;r['external_operational_helpers_reviewed']=helpersread;r['review_mode']='exact_test_membership_with_external_helpers_read_inline_operations_unexamined';r['classification']='test_only_inline_operational_setup_unexamined';r['justification']+=' Correction: #[test] membership/SHA only classifies body extent; inline setup/provider/source/artifact guards inside these bodies were not manually read and remain pending. No assertion-only purity assumed.'
  annex.append({'path':a['path'],'source_sha256':a['source_sha256'],'git_blob':a['git_blob'],'kind':'test_child_inline_operations_pending','test_function_count':a['test_function_count'],'non_test_helpers_reviewed':helpersread,'members':a['test_functions']})
for r in c['rows']:
 i=idx.get(r['path']);ranges=i.get('omitted_cfg_test_line_ranges',[]) if i else []
 if not ranges:continue
 data=(P/'compiler-baseline'/r['path']).read_bytes();lines=data.splitlines(keepends=True);members=[]
 for start,end in ranges:
  raw=b''.join(lines[start-1:end]);members.append({'start_line':start,'end_line':end,'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'review_status':'unexamined inline operational/test item; no purity assumed'})
 r['embedded_cfg_test_operational_review_complete']=False;r['embedded_cfg_test_review_manifest']='compiler-inline-test-operational-backlog.json'
 # Retain the completed production read independently; do not call the entire file completed.
 if r.get('review_status')=='source_reviewed' and r.get('review_mode')!='full_file_read':
  r['production_review_complete']=True;r['review_complete']=False;r['review_status']='production_reviewed_inline_tests_pending'
 annex.append({'path':r['path'],'source_sha256':r['source_sha256'],'git_blob':r['git_blob'],'kind':'embedded_cfg_test_items_operational_pending','production_source_review_complete':r.get('production_review_complete',False),'members':members})
c['summary']={'assigned_files':len(c['rows']),'full_or_production_source_reviewed_files':sum(x.get('review_status') in ['source_reviewed','production_reviewed_inline_tests_pending'] for x in c['rows']),'test_source_classified_files':0,'test_child_external_helpers_read_inline_operations_pending':sum(x.get('review_status')=='test_operational_inline_pending' for x in c['rows']),'targeted_files_remainder_unexamined':sum(x.get('review_status')=='partial_remainder_unexamined' for x in c['rows']),'manifest_grouped_fixture_files':sum(x.get('review_status')=='manifest_classified_fixture' for x in c['rows']),'fully_unexamined_files':sum(x.get('review_status')=='unexamined' for x in c['rows'])}
(P/'compiler-inline-test-operational-backlog.json').write_text(json.dumps({'baseline':c['baseline'],'generated_utc':now,'rule':'Exact cfg(test)/#[test] membership never establishes purity or operational setup review; all uninspected bodies remain pending, even when assertions may later be classified by manifest.','rows':annex,'whole_scope_complete':False},indent=2)+'\n');(P/'compiler-file-coverage.json').write_text(json.dumps(c,indent=2)+'\n');(P/'compiler-test-source-manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(c['summary']);print('pending inline test item groups',len(annex))
