import json,hashlib,os
from pathlib import Path
R=Path('/workspace/name-session/full-consumer-audit');p=R/'vm-consumers.json';raw=p.read_bytes();d=json.loads(raw)
rs=[r for r in d['consumers'] if r['disposition']=='migrated_validation_pending' and not r.get('status_review')][:55]
assert rs[0]['id']=='vm-0320' and rs[-1]['id']=='vm-0410'
changes={
'vm-0322':('pending_audit','Actual backend ABI/seed selection is supplied, but row explicitly lacks original table/provider configuration correspondence. Preserve owner/provider question rather than treating physical order adoption as complete.'),
'vm-0328':('out_of_scope','Explicit standalone compatibility/inspection entry has no source Module/native entry; it is not itself a migrated Native naming consumer. Actual admitted module route and separate missing-token trust question retain their own records.'),
'vm-0334':('pending_audit','Typed diagnostic context and actual placed-label offsets are present, but required versus optional target omission and upstream loop context role-prefix remain unresolved owner-purpose questions.'),
'vm-0352':('pending_audit','Recipe delegation exists, but actual interpreter constant birth/allocation resource is lazy and original lifecycle correspondence remains unestablished. Not merely an unexecuted complete integration.'),
'vm-0376':('pending_audit','Shared compiled compatibility parser exists; genuine surviving-word convention producer/caller correspondence is still unresolved. No ordinary source or Native authority inferred.'),
'vm-0397':('pending_audit','Actual selected program and source/config arena are individually retained; exact scheduler correspondence remains untraced, so this is an explicit owner question rather than integrated validation pending.'),
'vm-0403':('pending_audit','Actual InterpId traversal is genuine; whether fresh report-name Values reproduce the provider original-key/result construction purpose remains unestablished. No name inverse or reproduced bug inferred.')}
out=[]
for r in rs:
 old=r['disposition']
 if r['id'] in changes:new,why=changes[r['id']];r['disposition']=new
 else:new=old;why='Bounded implemented component retained: '+r['context']+' Independent limit remains: '+r['missing_integration']
 r['status_review']={'receipt':'vm-status-reconciliation-resumed-03.json','previous':old,'current':new,'reason':why,'basis':'Individual recorded actual source-purpose review, not execution or whole-method acceptance.'}
 out.append({'id':r['id'],'path':r['path'],'symbol':r['symbol'],'previous':old,'current':new,'reason':why})
(R/('vm-consumers-before-status03-'+hashlib.sha256(raw).hexdigest()[:12]+'.json')).write_bytes(raw)
for name,obj in [('vm-consumers.json',d),('vm-status-reconciliation-resumed-03.json',{'baseline':d['baseline'],'reviewed_rows':out,'scope':'55 individual legacy status rereviews; no tests/providers executed'})]:
 q=R/name;t=q.with_suffix('.tmp');t.write_text(json.dumps(obj,indent=2)+'\n');os.replace(t,q)
