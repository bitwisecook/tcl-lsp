from pathlib import Path
import json,hashlib,datetime,collections
D=Path('/workspace/name-session/full-consumer-audit');p=D/'root-consumers.json';before=p.read_bytes();j=json.loads(before);rows=j.get('consumers',j.get('rows',[]))
changes={
206:('pending_audit','Provider schema/completeness unresolved; malformed-record skip policy intentional, no established completed integration.'),
223:('pending_audit','Actual finite remote name domain inspected, but reusable issuer/template requirement unresolved; no live injection allegation or completed migration.'),
246:('pending_audit','Standalone versus document configuration/store producer correspondence requires final trace; no completed integration established.'),
249:('pending_audit','Pack supported-name schema restriction needs owner contract disposition; local alphabet is not by itself a proved missing migration.'),
252:('pending_audit','Recorded actual full-source API transport remains unfinished; existing strong allocation identity must stay. Prior API integration label did not mean completed consumer migration.'),
255:('pending_audit','Actual decode faithfulness/report comparison purpose requires explicit admission; shared selected-left dialect is intentional.'),
265:('pending_audit','Locked dependency parsing duplication is recorded, but best-effort malformed discovery policy needs owner-purpose disposition; not completed migration.'),
287:('pending_audit','GitHub URI component/domain/owner integration still unresolved, not completed source-locator migration.'),
300:('pending_validation','Actual copied provider asset/hash/build correspondence is unestablished; cache key alone is not a provider receipt.'),
305:('pending_validation','Test provider/outcome attribution gap, not an implemented production consumer integration.'),
306:('pending_validation','Lossy golden byte comparison needs exact claim/domain validation, not a completed consumer migration.'),
307:('pending_validation','Structural wasm import/function index test guard still requires selected module proof, not completed migration.'),
308:('pending_validation','Bounded browser stub only supplies renderer/wiring evidence; worker currentness validation remains separate.'),
309:('pending_validation','Existing body-key wire test is validation infrastructure, not a migrated consumer by virtue of test membership.'),
315:('pending_validation','Historical smoke provider selection is not conformance provenance or completed naming consumer migration.'),
316:('pending_validation','Exact original library/ZIPFS/provider pairing validation remains unfinished, not a migrated consumer.')}
receipt=[]
for i,(state,reason) in changes.items():
 r=rows[i];assert r['disposition']=='migrated_validation_pending'
 original=json.loads(json.dumps(r));r['disposition']=state;r['review_state_reason']=reason
 receipt.append(dict(index=i,id=r['id'],before=original,after=json.loads(json.dumps(r)),reason=reason))
out=json.dumps(j,indent=2)+'\n';p.with_suffix('.json.tmp').write_text(out);p.with_suffix('.json.tmp').replace(p)
c=dict(baseline=j['baseline'],utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),before_sha256=hashlib.sha256(before).hexdigest(),after_sha256=hashlib.sha256(out.encode()).hexdigest(),status='Individually evidence-reviewed state correction only; all original source/purpose/API/guards retained. No implementation or execution acceptance.',changes=receipt,unchanged_migrated_pending=46,remaining_consumer_total=None)
(D/'root-review-state-correction.json').write_text(json.dumps(c,indent=2)+'\n')
protocol=D/'PROTOCOL.md';s=protocol.read_text();s+='\nExplicit review-state correction (2026-10-15): pending_audit means an actual owner/domain/integration question remains unanswered; pending_validation means a check/provider/guard obligation remains without an established completed consumer migration. migrated_validation_pending is reserved for actual identified integrated code whose acceptance is unfinished. Work kind and disposition are separate axes. Existing provisional rows require individual evidence review; no automatic count or status promotion follows. consolidate.py accepts both explicit pending states.\n';protocol.write_text(s)
print(json.dumps(dict(changed=len(receipt),dispositions=dict(collections.Counter(r['disposition'] for r in rows)),remaining_consumer_total=None)))
