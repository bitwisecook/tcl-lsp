# Repository naming-consumer audit

Baseline: `cc24c394004fc187378ba0eefb6c2c5b2615fb00`.

The baseline tree contains 110,709 unique tracked paths. All paths have exactly one assigned reviewer, independently checked with no omissions or overlaps. This is a file census, not a consumer count.

A consumer is an integration site with a specific naming purpose. Identify it by baseline path, symbol, site and purpose; do not equate files, functions, matching text, proof questions, failing tests or issue reports with consumers. Keep distinct purposes when one function contains several, and cross-reference one shared site reached by several callers. Reconcile duplicates before publishing totals.

File coverage records baseline blob, SHA256, classification, review mode, reviewed production extent, evidence and justified exclusions. Inventory/hash/keyword scanning alone never means reviewed. Test data and original provider trees may be grouped using explicit provenance manifests and path membership; harnesses, adapters, generators and production metadata still require review. Generated artifacts trace their actual generator and input, with drift verification separate.

Consumer rows record actual inputs/context, current shared API, missing owner transport or local interpretation, disposition, source evidence, related issue, relevant original assertions and exact validation result. Use needs_migration, migrated_validation_pending, migrated_verified, shared_owner, display_only or out_of_scope. Missing representation is not absence. No Native, identity, edit or completion authority can be inferred from source advice.

Unexamined files/purposes remain unfinished. A reviewed implementation without fresh applicable tests remains validation pending. Report coverage gaps and unknown totals until complete source review and independent reconciliation. Source changes after this baseline require explicit invalidation/review annexes and cannot inherit baseline verification.

Root owns consolidation, shared tracking, Git and the only build lease. Reviewers write disjoint artifacts.

Explicit review-state correction (2026-10-15): pending_audit means an actual owner/domain/integration question remains unanswered; pending_validation means a check/provider/guard obligation remains without an established completed consumer migration. migrated_validation_pending is reserved for actual identified integrated code whose acceptance is unfinished. Work kind and disposition are separate axes. Existing provisional rows require individual evidence review; no automatic count or status promotion follows. consolidate.py accepts both explicit pending states.
