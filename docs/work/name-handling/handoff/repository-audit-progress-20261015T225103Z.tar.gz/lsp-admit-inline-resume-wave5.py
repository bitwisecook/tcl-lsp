import json
from pathlib import Path
r=Path('/workspace/name-session/full-consumer-audit');p=r/'lsp-inline-reviewed-regions.json';d=json.loads(p.read_text());w=json.load(open(r/'lsp-inline-next-wave5.json'));seen={(x['path'],x['start_line'],x['end_line'],x['source_sha256'])for x in d['regions']}
notes=[
'Whole original SSA/type hint helper and opaque cells/report map erasure/local frame-alias/current-source/missing-symbol controls read; no Native value/read proof from type display.',
'Actual positioned Logical method command syntax distinguishes inert braced source from effectful command/variable argv; unknown mutation envelope retained in resolved/unresolved reporting controls, not Normal/callee certainty.',
'Whole actual expanded source children/formal topology/default/captured-prefix inlay coordinates and source currentness controls read. Unanchored capture never given a caller-written label.',
'Whole own-object candidate cursor UTF16 helper, actual allocation/canonical worker/per-object generation/private/unknown/current-config controls read. Source declaration owner distinct from live object dispatch.',
'Actual edit order application and registry-selected proc/Apply body versus formal-data/reindent source geometry controls read; helper test_registry independent fixed domain. Historical C comment no current runtime equivalence.',
'Whole original export-event/opaque namespace/source slot/policy and intermediate import source advice controls read. RunOrder observation does not certify source executed or physical export absence.',
'Whole docstring tag parser/sample/render/JSON tests inspected. Fixed documentation tag spelling/case and parameter display fields have no source variable identity; no process/fs/env/provider setup.',
'Whole Zed fixed OS/architecture triples, filename suffix/download URL/release tag syntax controls inspected. Host asset labels are explicit distribution domain; no download/process operations inside these bodies.',
'Whole own-object completion helper and actual original method source constructor byte-roundtrip, sibling isolation/unknown generation/canonical metadata refusal read; advice remains per-object source declaration candidate.',
'Whole formatter profile/source grammar/availability range/default aliases/unknown fallback tests read. Explicit fixed profile configuration, no borrowed actual document context or unknown dialect availability claim.',
'Whole constructed report compatibility rows and authentic selected current proc/site guard controls read. Synthesized legacy tuples only test representation; actual Native source minify refuses MissingAlphaRenameContract. Output truncation37tokens explicitly reread5374–5395 before admission.',
'Whole configured receiver/rename hazard helper and scalar-versus-compound/array/untracked/FirstClose/Tcl9Nesting/stale-source controls read. Absence of one known hazard not independently complete rename transform proof.',
'Whole MemoryStore read/write/URI-alias/implicit directories controls and actual NativeStore temp_dir create/write/read/list/remove lifecycle read. No filesystem operations executed; typed paths not Tcl name inverse.',
'Whole cfgtest instance_method_at_cursor implementation read: UTF16-to-char cursor, private legacy line/depth/split head scanner and configured whole_var_ref. Explicit test helper representation retains weaker syntax admission, not a production naming migration or Native receiver.',
'Whole actual Logical method source candidate helper, absolute-head report erasure, unknown residual preservation and duplicate header/class occupancy controls read. Positive roster does not close runtime lookup/absence or command mutation obligations.'
]
for x,n in zip(w['regions'],notes):
 key=(x['path'],x['start_line'],x['end_line'],x['source_sha256']);assert key not in seen;seen.add(key)
 d['regions'].append({key:x[key]for key in ['path','start_line','end_line','source_sha256']}|{'review_status':'reviewed_source_only','classification':'actual_whole_inline_source_and_owner_controls','reason':n+' Exact entire region statements/imports/helpers read, no attribute-purity assumption. Original source/assertions/budgets retained; no providers/tests/fs/env/helper/build executed; no migration acceptance.'})
p.write_text(json.dumps(d,indent=2)+'\n')
