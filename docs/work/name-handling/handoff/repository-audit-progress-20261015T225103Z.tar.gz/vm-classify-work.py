"""Purpose classification of already source-reviewed VM audit rows; no disposition changes."""
import json, pathlib, collections, datetime
root=pathlib.Path('/workspace/name-session/full-consumer-audit')
p=root/'vm-consumers.json'; doc=json.loads(p.read_text())
def ids(s): return {f'vm-{int(n):04d}' for n in s.split()}
# Actual missing target/catalogue/format representation or selector schema, not a
# claim that a fresh generic naming architecture is required.
metadata=ids('1 2 3 4 5 10 13 14 16 17 24 27 28 38 45 55 58 90 91 104 120 124 173 174 176 184 185 201 209 211 212 242 247 271 299 300 301 302 303 304 306 307 308 309 314 330 347 351 358 361 367 379 384 390 396 408 409 415 416 418 423 427 430 474 505 508 513 525 530 531 536 537 538 540 560 566 568 585 592 608 612 621 624 633 640 644 645 647 658 659 660 662 683 684 699 704 713 715 716 717 725 737 751 753 760 762 765 767 770 773 776 778 787 803 813 816 827 839 840 883')
host=ids('7 12 37 48 49 71 72 205 207 214 215 278 279 359 360 362 377 378 380 382 398 402 451 601 641 643 656 814 815 819 830 838 847 850')
# Demonstrated requirement not represented by existing API purpose; deliberately
# small. A request to use an existing checked API is consumer integration instead.
extensions=ids('41 142 143 144 464 507 613 649 655 689 690 783 866 874')
# Requirement/actual reached producer is not yet established by the reviewed
# source chain; retain that uncertainty instead of inventing an owner extension.
unknown=ids('54 95 156 167 195 196 246 285 374 419 453 471 490 516 576 579 583 592 618 620 627 649 675 687 719 735 742 793 807 808 811 820 824 837 843 845 852 853 857 858 862 869 870 881 889')
validation=ids('313 312 718')
for c in doc['consumers']:
 i=c['id']; d=c['disposition']; api=c['shared_api']; site=c['site']
 if d in ('display_only','out_of_scope'):
  kind='display_or_exclusion'; detail='This reviewed purpose is a report or explicit exclusion; it does not select naming/execution identity.'
 elif d=='shared_owner':
  kind='existing_shared_owner'; detail='This row records an existing shared owner and its purpose/currentness contract; it is not a request for another owner.'
 elif i in unknown:
  kind='unclassified_pending_owner_trace'; detail='The reviewed site is concrete, but the stated actual provider/producer/caller-purpose uncertainty must be resolved before assigning an owner extension or completed integration.'
 elif i in validation:
  kind='validation_only'; detail='This operational fixture/provider provenance work concerns honest test admission rather than a production naming consumer migration.'
 elif i in extensions:
  kind='shared_owner_extension'; detail='The reviewed requirement needs a distinct purpose/representation in the existing owner; the cited current API does not supply it.'
 elif i in host:
  kind='host_abi'; detail='This purpose crosses an actual host/path/interpreter/ABI boundary; original units and physical context must survive that boundary.'
 elif i in metadata:
  kind='metadata_schema'; detail='This purpose concerns an actual catalogue, target symbol/encoding namespace, generated spelling, selector table, or diagnostic schema.'
 else:
  kind='consumer_integration'; detail='This purpose joins an actual consumer to existing source/object/context/name owners; it does not itself justify a competing resolver.'
 c['work_kind']=kind
 c['work_kind_reason']=f'{detail} Reviewed site: {site}. Existing API: {api}. Remaining scope/limit: {c["missing_integration"]}'
 c['work_kind_basis']='Classification of this row\'s already recorded source-purpose review at cc24; no extra execution or migration acceptance. Source rows, repair groups, and physical call sites are separate counts.'
# Ensure every explicit override really points to a reviewed row.
known={c['id'] for c in doc['consumers']}
assert not (metadata|host|extensions|unknown|validation)-known
p.write_text(json.dumps(doc,indent=2,ensure_ascii=False)+'\n')
counts=collections.Counter(c['work_kind'] for c in doc['consumers'])
summary={'baseline':doc['baseline'],'owner':'vm','recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'rows':len(doc['consumers']),'work_kind_counts':dict(sorted(counts.items())),'disposition_cross_tab':{k:dict(collections.Counter(c['disposition'] for c in doc['consumers'] if c['work_kind']==k)) for k in sorted(counts)},'limits':['Per reviewed purpose; not whole-codebase migration completion.','existing_shared_owner does not mean an extension is requested.','No disposition changed by classification.','Unexamined files remain unexamined; tests/evidence are not claimed executed.','Source rows, distinct repair groups, and physical call sites have different cardinalities.']}
(root/'vm-work-kind-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
