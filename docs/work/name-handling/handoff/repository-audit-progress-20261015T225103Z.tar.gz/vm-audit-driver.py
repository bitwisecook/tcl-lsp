import json,hashlib,subprocess,re
from pathlib import Path
ROOT=Path('/workspace/name-session/full-consumer-audit');REPO=Path('/workspace/tcl-lsp')
a=json.loads((ROOT/'vm-assigned-files.json').read_text());base=a['baseline']
snapshot=ROOT/'vm-source';snapshot.mkdir(exist_ok=True)
rows=[]
proc=subprocess.Popen(['git','cat-file','--batch'],cwd=REPO,stdin=subprocess.PIPE,stdout=subprocess.PIPE)
for f in a['files']:
 p=f['path'];proc.stdin.write((base+':'+p+'\n').encode());proc.stdin.flush()
 header=proc.stdout.readline().decode().split();blob,kind,length=header;data=proc.stdout.read(int(length));assert proc.stdout.read(1)==b'\n';assert blob==f['blob'] and kind=='blob'
 q=snapshot/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(data)
 row={'path':p,'blob':blob,'source_sha256':hashlib.sha256(data).hexdigest(),'baseline':base,'bytes':len(data),'review_mode':'unexamined','classification':'unexamined','reason':'Assigned baseline blob captured exactly; semantic review not yet performed.','review_ranges':[]}
 if '/tests/data/' in p:
  row.update(review_mode='fixture_manifest',classification='test_fixture',reason='Exact tracked path in Cargo integration-test data subtree; retained provider/input/expected/capture artifact, not first-party production. Group rule VM-FIXTURE-01; no semantic or execution acceptance from fixture presence.')
 elif '/tests/' in p and not p.endswith('.rs'):
  row.update(review_mode='fixture_manifest',classification='test_fixture',reason='Exact tracked non-Rust input/expected/oracle artifact under Cargo tests subtree. Group rule VM-FIXTURE-02; no production registration or semantic acceptance inferred.')
 elif p.endswith('Cargo.lock'):
  row.update(review_mode='generated_manifest',classification='dependency_lock',reason='Cargo dependency lock for standalone wasm workspace, not a naming implementation. Group rule VM-METADATA-01; dependency/host construction checked through Cargo.toml separately.')
 rows.append(row)
proc.stdin.close();assert proc.wait()==0
(ROOT/'vm-file-coverage.json').write_text(json.dumps({'baseline':base,'owner':'vm','group_rules':{'VM-FIXTURE-01':'path contains /tests/data/; every member enumerated with exact blob and SHA; fixture/data/probe artifact only, not production','VM-FIXTURE-02':'non-Rust path under /tests/; each enumerated exact tracked artifact, excludes Rust harnesses requiring separate review','VM-METADATA-01':'standalone Cargo.lock exact generated dependency resolution'},'rows':rows,'status':'in_progress; unexamined means unfinished'},indent=2)+'\n')
(ROOT/'vm-consumers.json').write_text(json.dumps({'baseline':base,'owner':'vm','consumers':[],'status':'in_progress; no completeness claim'},indent=2)+'\n')
print(len(rows),'tracked files snapshotted',sum(r['classification']=='unexamined' for r in rows),'unexamined')
