from pathlib import Path
import re,json,hashlib
P=Path('/workspace/name-session/full-consumer-audit'); B=P/'compiler-baseline'; ns={};exec((P/'compiler-extract-production.py').read_text().split('rows=[]')[0],ns);mask=ns['mask']
assigned={x['path']:x for x in json.load(open(P/'compiler-assigned-files.json'))['files']};index={x['path']:x for x in json.load(open(P/'compiler-production-index.json'))}; edges={}; pending=[]
def resolve(parent,name,explicit=None):
 q=Path(parent); base=q.parent if q.name in ('lib.rs','main.rs','mod.rs') else q.parent/q.stem
 cand=[q.parent/explicit] if explicit else [base/(name+'.rs'),base/name/'mod.rs']
 return next((str(x) for x in cand if str(x) in assigned),None)
for path,r in index.items():
 s=(B/path).read_text()
 for a,b in r['omitted_cfg_test_line_ranges']:
  lines=s.splitlines(True);txt=''.join(lines[a-1:b]);m=re.search(r'\bmod\s+([A-Za-z_][A-Za-z_0-9]*)\s*;',mask(txt))
  if m:
   vicinity=''.join(lines[max(0,a-4):b]);pa=re.findall(r'#\[path\s*=\s*"([^"]+)"\]',vicinity);target=resolve(path,m.group(1),pa[-1] if pa else None)
   if target:
    edges.setdefault(target,dict(parent=path,parent_line=a,kind='cfg(test) module',chain=[]));pending.append(target)
while pending:
 path=pending.pop();s=(B/path).read_text();m=mask(s)
 for match in re.finditer(r'\bmod\s+([A-Za-z_][A-Za-z_0-9]*)\s*;',m):
  vicinity=s[max(0,match.start()-180):match.end()];pa=re.findall(r'#\[path\s*=\s*"([^"]+)"\]',vicinity);target=resolve(path,match.group(1),pa[-1] if pa else None)
  if target and target not in edges:
   edges[target]=dict(parent=path,parent_line=s.count('\n',0,match.start())+1,kind='inherited test-only module',chain=[]);pending.append(target)
 for match in re.finditer(r'include!\s*\(\s*"([^"]+)"\s*\)',s):
  target=str(Path(path).parent/match.group(1))
  if target in assigned and target not in edges:
   edges[target]=dict(parent=path,parent_line=s.count('\n',0,match.start())+1,kind='inherited test-only include',chain=[]);pending.append(target)
rows=[]
for path,e in sorted(edges.items()):
 s=(B/path).read_text();m=mask(s); spans=[];functions=[]
 for a in re.finditer(r'#\s*\[\s*test\s*\]',m):
  f=re.match(r'\s*(?:#\[[^\]]*\]\s*)*(?:pub\s+)?(?:async\s+)?fn\s+(\w+)',m[a.end():]);
  if not f:continue
  st=a.end()+f.end();op=m.find('{',st)
  if op<0:continue
  depth=1;end=op+1
  while end<len(m) and depth:
   if m[end]=='{':depth+=1
   elif m[end]=='}':depth-=1
   end+=1
  spans.append((a.start(),end));functions.append(dict(symbol=f.group(1),line=s.count('\n',0,a.start())+1,end_line=s.count('\n',0,end)+1,sha256=hashlib.sha256(s[a.start():end].encode()).hexdigest()))
 line_ranges=[(s.count('\n',0,a)+1,s.count('\n',0,b)+1) for a,b in spans]
 aid=[]
 for line,text in enumerate(s.splitlines(True),1):
  if any(a<=line<=b for a,b in line_ranges):continue
  aid.append(f'{line}: {text}')
 target=P/'compiler-test-helpers'/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(''.join(aid));chain=[];q=path;seen=set()
 while q in edges and q not in seen:seen.add(q);chain.append(dict(path=q,**{k:v for k,v in edges[q].items() if k!='chain'}));q=edges[q]['parent']
 rows.append(dict(path=path,source_sha256=assigned[path].get('sha256',hashlib.sha256(s.encode()).hexdigest()),git_blob=assigned[path].get('git_blob',assigned[path].get('blob')),test_only_chain=chain,test_functions=functions,test_function_count=len(functions),non_assertion_review_aid=str(target),non_assertion_review_bytes=sum(len(x.encode()) for x in aid),disposition='requires_manual_non_assertion_helper_item_read',note='Exact parent gates classify only test-function bodies; helpers/setup/producers/guards/non-test items not classified as reviewed. No execution.'))
(P/'compiler-test-source-manifest.json').write_text(json.dumps(dict(baseline='cc24c394004fc187378ba0eefb6c2c5b2615fb00',rule='exact cfg(test) inherited-module/include plus per-test function extent/hash; helper obligations retained',rows=rows),indent=2)+'\n');print('gated child files',len(rows),'test functions',sum(x['test_function_count'] for x in rows),'helpers bytes',sum(x['non_assertion_review_bytes'] for x in rows));print('\n'.join(str(x['non_assertion_review_bytes'])+' '+x['path'] for x in sorted(rows,key=lambda x:x['non_assertion_review_bytes'],reverse=True)[:15]))
