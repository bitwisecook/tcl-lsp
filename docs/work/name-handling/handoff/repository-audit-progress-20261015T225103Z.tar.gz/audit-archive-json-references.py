import runpy,json,pathlib,collections
x=runpy.run_path('/workspace/name-session/full-consumer-audit/audit-review-tools.py');c,s=x['load']();rows={r['path']:r for r in c['files']};roots=('experiments/name-handling/','docs/design/analysis/name-resolution-proofs/rust-validation/','scripts/dev/bigip-probes/resolution-2286/evidence/','docs/work/name-handling/handoff/');outputs={'.json','.jsonl','.log','.txt','.tsv','.csv','.gz','.zip','.tgz','.bin','.out','.stdout','.stderr','.status','.exit','.hex','.sha256','.png','.svg','.dat','.bytes','.patch','.diff','.xz','.elf'};stats=collections.Counter();examples=[];seen=set();memberrefs={}
def pathof(raw):
 if not isinstance(raw,str):return None
 if raw.startswith('/workspace/tcl-lsp/'):raw=raw[len('/workspace/tcl-lsp/'):]
 if raw.startswith(roots) and raw in rows:return raw
 return None
def walk(node,pointer,metadata):
 if isinstance(node,dict):
  p=pathof(node.get('path'));digest=node.get('sha256')
  if p and isinstance(digest,str) and len(digest)==64:
   r=rows[p];stats['exact_path_digest_references']+=1
   if digest!=r['source_sha256']:stats['historical_digest_mismatches']+=1
   elif r['review_status']!='reviewed' and (pathlib.Path(p).suffix in outputs or '.tar.gz.part-' in p):
    r.update(review_status='reviewed',review_mode='provenance_manifest_membership',classification='retained_capture_fixture_or_metadata',group_rule='archive-explicit-json-path-digest',reason='Exact repository-relative or original /workspace/tcl-lsp path and whole SHA256 in actual retained archive JSON record. Only data/log/receipt/binary/archive output types admitted. No source harness, adapter, executable script, production metadata or prose was grouped.',reviewed_production_extent='Archived data provenance only; not manual prose review, source ownership, original provider execution/admission or current test validation.',evidence=[{'path':metadata,'sha256':rows[metadata]['source_sha256'],'json_pointer':pointer}],tests='No execution; hash/explicit record linkage only.',consumer_ids=[]);stats['new_grouped']+=1;memberrefs[p]={'metadata':metadata,'pointer':pointer}
  for k,v in node.items():walk(v,pointer+'/'+str(k).replace('~','~0').replace('/','~1'),metadata)
 elif isinstance(node,list):
  for i,v in enumerate(node):walk(v,pointer+'/'+str(i),metadata)
for p,r in rows.items():
 if p.startswith(roots) and p.endswith('.json'):
  try:obj=json.loads(x['content'](r))
  except (ValueError,UnicodeDecodeError):stats['non_json_or_non_utf8']+=1;continue
  stats['structured_metadata_files_examined']+=1;walk(obj,'',p)
c['group_rules'].append({'id':'archive-explicit-json-path-digest','rule':'Strict path+sha256 object reference to exact existing assigned archive data file, path already repository-relative or absolute original /workspace/tcl-lsp; no guessed base, labels, byte fragments or directory exclusions. SHA equals complete baseline. Source/scripts/prose/production metadata excluded. References prove retained artifact provenance only.','counts':dict(stats),'members':memberrefs});x['save'](c,s);print(dict(stats));print(c['summary'])
