from pathlib import Path
import json,hashlib,datetime
root=Path('/workspace/name-session/full-consumer-audit');p=root/'db-consumers.json';before=p.read_bytes();x=json.loads(before);rows={r['id']:r for r in x['consumers']}
changes={
'db.declaration-source-call-evidence':('pending_audit','consumer_integration','Original target slicing exists, but the row itself leaves complete cross-file coverage and semantic alias transport unresolved; source scanner/caller correspondence requires further evidence before implementation can be called complete.'),
'db.isolated-body-source-context':('pending_audit','consumer_integration','The original whole-source/card/frame graft and per-item caller purpose have not been established. A typed body memo with labels is not evidence that the missing transport is implemented.'),
'spectcl.backing.syntax-owner':('pending_audit','owner_extension','Typed backing list syntax exists, but this row explicitly leaves loader outer-source and receiver-grammar integration unresolved. Requires concrete complete caller proof before migrated status.'),
'db.original-procedure-facts':('shared_owner','owner_contract','Existing partial original declaration projection and its documented incomplete inventory purpose are established by source; no separate migration is demonstrated by this row.'),
'hooks.actual-engine-hook-dispatch':('shared_owner','owner_contract','Existing typed Engine/HookSlot handle dispatch retains actual owner; source review establishes owner purpose, not a newly implemented migration or execution acceptance.'),
'hooks.sandbox-list-output':('shared_owner','owner_contract','Existing fold/list delegation is a shared owner consumer; receiver grammar dependency is tracked at the actual fold owner, not implemented by this adapter.'),
'hooks.pack-runtime-vocabulary-ingress':('shared_owner','owner_contract','Existing actual VM Unicode callback ingress and transactional vocabulary dispatch are owner contracts; no newly implemented migration is established in this row.'),
'registry.private-written-namespace-advice':('shared_owner','owner_contract','Existing written-source advisory classifier already delegates shared geometry and explicitly limits advice; this is owner contract source review.'),
'studio.wasm.archive-source-view':('shared_owner','owner_contract','Existing archive preview/unsupported-encoding reporting purpose is source-reviewed; no filesystem identity or migration acceptance is inferred.'),
'studio.wasm-authoring-facade':('shared_owner','owner_contract','Facade delegates current source data to existing render/store owners. Their separate concrete gaps do not establish a migration implemented by this forwarding layer.'),
'studio.sample-original-source-preview':('shared_owner','owner_contract','Existing sample schema explanation is nominal source preview; retained original words do not alone establish a newly implemented migration.'),
'studio.store.registry-publication':('shared_owner','owner_contract','Existing pack registry publication delegates nominal install owner; renderer/edit gaps remain separate consumers.'),
'spectcl.install.nominal-registry-overlay':('shared_owner','owner_contract','Existing descriptor overlay installation retains metadata/security gates. Separate PackSet/environment owner debts are not fixed by this existing consumer.'),
'spectcl.package.reference-source':('shared_owner','owner_contract','Existing checked source read holds actual text; lexical containment and filesystem race limitations are not claimed fixed or identified as naming migrations here.'),
'registry.runtime-context.overlay-pin':('shared_owner','owner_contract','Existing held ContextRegistry pin preserves release/build/overlay purpose; separately tracked ingress snapshot question is not implemented by this consumer.')}
receipt=[]
for key,(disp,kind,reason) in changes.items():
 r=rows[key];assert r['disposition']=='migrated_validation_pending',key
 receipt.append({'id':key,'before':dict(r),'after_disposition':disp,'after_work_kind':kind,'reason':reason})
 r['disposition']=disp;r['work_kind']=kind;r.setdefault('evidence',[]).append('Audit disposition correction: '+reason)
name='db-consumers-before-purpose-status-correction.json';(root/name).write_bytes(before)
p.write_text(json.dumps(x,indent=2)+'\n')
(root/'db-disposition-purpose-correction.json').write_text(json.dumps({'baseline':x['baseline'],'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'beforeimage':name,'before_sha256':hashlib.sha256(before).hexdigest(),'after_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'rule':'Individual source-purpose classification; no bulk inferred migration state, no code/test/guard changes and no execution acceptance. Remaining migrated_validation_pending rows retain explicitly implemented owner/consumer changes from prior source review.','changes':receipt},indent=2)+'\n')
print(len(receipt),'individual corrections; remaining',sum(r['disposition']=='migrated_validation_pending' for r in rows.values()))
