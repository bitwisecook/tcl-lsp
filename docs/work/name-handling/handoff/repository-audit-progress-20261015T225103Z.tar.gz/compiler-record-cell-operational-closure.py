import json,hashlib,datetime
from pathlib import Path
P=Path('/workspace/name-session/full-consumer-audit');c=json.load(open(P/'compiler-file-coverage.json'));d=json.load(open(P/'compiler-consumers.json'));idx={r['path']:r for r in json.load(open(P/'compiler-production-index.json'))};now=datetime.datetime.now(datetime.timezone.utc).isoformat();rows=[]
for name in ['captured_cell','cell_state_ssa','allocated_instance']:
 path='rust/tcl-compiler/src/'+name+'.rs';r=next(r for r in c['rows'] if r['path']==path);raw=(P/'compiler-baseline'/path).read_bytes();assert hashlib.sha256(raw).hexdigest()==r['source_sha256'];n=len(raw.splitlines());old={k:r.get(k) for k in ['review_status','review_mode','review_complete','embedded_cfg_test_operational_review_complete']}
 r.update(review_status='source_reviewed',review_mode='full_file_read',review_complete=True,production_review_complete=True,embedded_cfg_test_operational_review_complete=True,reviewed_source_ranges=[[1,n]],reviewed_utc=now)
 r['justification']+=' All omitted inline test/setup/helper bodies now actually read through EOF: in-memory Registry/ResolveContext/CFG/CU and synthetic receipt/identity fixtures; no original interpreter/provider invocation or fs/env/Command setup. No tests executed; fixture construction does not certify provider equivalence.'
 for site in d['rows']:
  if site['path']==path: site['validation']='Whole exact cc24 source including all inline test/setup/helper bodies actually read. In-memory/synthetic fixtures only; no tests/builds/provider execution by this agent.'
 rows.append(dict(path=path,source_sha256=r['source_sha256'],git_blob=r['git_blob'],whole_read_range=[1,n],previous_state=old,omitted_ranges_actually_read=idx[path]['omitted_cfg_test_line_ranges'],operational_setup='Actual in-memory static Registry, ResolveContext, CFG/CompilationUnit and synthetic NativeInterpreterIdentity/namespace token fixtures; no provider binary, environment, filesystem or command execution. Fixed expectations read, not accepted as oracle.',execution='unexecuted'))
(P/'compiler-cell-operational-read-receipt.json').write_text(json.dumps(dict(baseline='cc24c394004fc187378ba0eefb6c2c5b2615fb00',generated_utc=now,rows=rows),indent=2)+'\n')
(P/'compiler-file-coverage.json').write_text(json.dumps(c,indent=2)+'\n');(P/'compiler-consumers.json').write_text(json.dumps(d,indent=2)+'\n')
