import json,runpy
from pathlib import Path
R=Path('/workspace/name-session/full-consumer-audit');record=runpy.run_path(str(R/'db-record.py'))['record'];prefix='rust/tcl-registry/tests/data/'
paths=set(json.loads((R/'db-next-driver-batch.json').read_text()))
f=R/'db-file-coverage.json';c=json.loads(f.read_text());idx={x['path']:x for x in c['files']}
for p in paths:
 idx[p].update(review_mode='complete_historical_driver_source_read',review_status='historical_harness_reviewed',classification='immutable_original_oracle_capture_or_replay_harness',justification='Read actual complete original Python source, including every setup/helper, provider source/header/library/config input, compile/argv/env, stream capture, completion/error, receipt/hash and expected-result branch. Historical provider purposes retained exactly; hardcoded temporary paths/old Jim revision and differing guard completeness are bounded original capture evidence, not current portable execution admission. No driver/providers/network/build/tests executed.')
f.write_text(json.dumps(c,indent=2)+'\n')
s=R/'db-oracle-driver-schemas.json';x=json.loads(s.read_text())
for g in x['groups']:
 reviewed=[m['path'] for m in g['members'] if idx[m['path']]['review_status']=='historical_harness_reviewed']
 if len(reviewed)==len(g['members']):
  g['status']='historical_capture_harness_source_reviewed';g['evidence']='All actual member sources reviewed or existing byte/AST-equivalent group/source review retained. Exact source/blob and directory inputs held; no current execution/provider admission.'
 elif reviewed:g['reviewed_members']=reviewed
s.write_text(json.dumps(x,indent=2)+'\n')
record([], [dict(id='oracle.driver.'+p.removeprefix(prefix),path=p,symbol='original capture/replay provider and receipt entrypoint',line=1,context='Retained original oracle driver source, actual setup/provider pairing/hash/argv/channel/completion scope distinct from product naming consumers.',shared_api='Original per-packet request/queue/receipt and provider source/library/header/executable owners; exact original driver semantics kept unchanged',missing_integration=None,disposition='out_of_scope',work_kind='retained_historical_evidence',tests=['Historical retained captures/rows and exact input assertions, not re-executed'],evidence=['All actual helper/setup/serialize/compile/run/guard branches source read. Different historical provider pin completeness and setup dependencies remain bounded evidence; latest Jim recheck and original tcltest pairing not manufactured from these scripts. No runner/provider/network/build/test execution.']) for p in sorted(paths)])
