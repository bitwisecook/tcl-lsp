from pathlib import Path
import json,runpy,sys,re
R=Path('/workspace/name-session/full-consumer-audit');lex=runpy.run_path(str(R/'db-audit-lex.py'));inv=json.loads((R/'db-test-helper-inventory.json').read_text())['helpers']
for path in sys.argv[1:]:
 s=(R/'db-baseline'/path).read_text();m=lex['mask'](s)
 print('\nFILE',path)
 for x in inv:
  if x['path']!=path or x['review_status']!='unexamined_test_helper':continue
  lines=s.splitlines(keepends=True);start=sum(len(z) for z in lines[:x['line']-1]);a=re.search(r'\bfn\s+'+re.escape(x['symbol'])+r'\b',m[start:]);assert a
  pos=start+a.start();end=lex['item_end'](m,pos)
  print('\nHELPER',x['symbol'],x['line'])
  for n,z in enumerate(s[start:end].splitlines(),x['line']):print(f'{n}: {z}')
