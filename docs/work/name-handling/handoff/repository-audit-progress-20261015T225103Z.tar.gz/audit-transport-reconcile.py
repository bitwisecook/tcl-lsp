import runpy,re,collections
x=runpy.run_path('/workspace/name-session/full-consumer-audit/audit-review-tools.py');c,s=x['load']();rows={r['path']:r for r in c['files']};p='scripts/dev/bigip-probes/resolution-2286/evidence/CURRENT_TRANSPORT_SHA256SUMS';b='scripts/dev/bigip-probes/resolution-2286/';mapped={};bad=[]
for line in x['content'](rows[p]).decode().splitlines():
 m=re.fullmatch(r'([a-f0-9]{64})\s+\*?(.+)',line)
 if m and b+m[2] in rows:
  q=b+m[2];mapped[q]=m[1]
  if rows[q]['source_sha256']!=m[1]:bad.append(q)
old=c['additional_provenance_checks']['mismatches']
covered=[d['path'] for d in old if mapped.get(d['path'])==rows[d['path']]['source_sha256']]
c['additional_provenance_checks']['transport_reconciliation']={'current_manifest':p,'manifest_sha256':rows[p]['source_sha256'],'assigned_members':len(mapped),'current_manifest_mismatches':bad,'older_inventory_mismatches':len(old),'older_inventory_mismatches_with_exact_current_projection':len(covered),'unexplained_older_mismatches':[d for d in old if d['path'] not in covered],'disposition':'Current projection documented separately from historical executed bytes; earlier inventory/seal mismatch records retained. No original result or current implementation acceptance.'}
x['save'](c,s);print(c['additional_provenance_checks']['transport_reconciliation'])
