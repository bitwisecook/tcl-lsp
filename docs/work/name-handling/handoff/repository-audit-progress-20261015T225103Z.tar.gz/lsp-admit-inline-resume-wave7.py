import json
from pathlib import Path
r=Path('/workspace/name-session/full-consumer-audit');p=r/'lsp-inline-reviewed-regions.json';d=json.loads(p.read_text());w=json.load(open(r/'lsp-inline-next-wave7.json'));seen={(x['path'],x['start_line'],x['end_line'],x['source_sha256'])for x in d['regions']}
notes=[
'Whole selected F5 source-object operand structured-value/unknown item versus unknown reference/cardinality/configuration/captured attachment purpose controls read. Static RowLoader descriptor schema not actual TMM action/Normal.',
'Whole original package registration source scan/name decode helper and current selected control/completion options/return override/source+config+Registry refusal controls read. FixedV8.6 Native name decoder is explicit helper purpose, no runtime package loading.',
'Whole original math declaration/Expr allocation navigation/reference/hierarchy and opaque source currentness/duplicate provider/independent URI owner controls read; no live math override execution.',
'Whole standalone index actual filename/value/raw wrappers/list syntax/current path predicate and malformed loader/refusal controls read. Six include_str captured original stdout expectations explicitly retained, provider provenance class independent of running implementation/test here.',
'Whole custom Registry definer source/hazard span helper and selected source member grammar/namespace move/alias capture/replacement/current image/own class guards read. Readonly source metadata explicitly no Native table/worker/edit grant.',
'Whole snippet context/template/filter/tabstop/variable-choice and iRules event presence/top-level controls read. Fixed new authoring trigger domain separate from existing Tcl identifier grammar; raw supplied reference source safety production gap remains independently catalogued.',
'Whole when_blocks source context/top-level/normal global spellings/rebound when/inert brace+quote/deferred and unavailable F5 mutator controls read. F5 K36322151 comment attribution not appliance proof; no runtime activation/entry grant.',
'Whole FrameWalk variable/index/expression/inert literal/nested command/source currency/full-document NativeWord extent and independent metadata profile tests read. Exact lexical census/selected phase does not grant actual cell/read/transform authority.',
'Whole original command/switch completion escaped/quoted/braced/incomplete container/UTF16 surrogate/data/comment/expansion/missing config controls read. Exact wholecontainer textEdit expected geometry not runtime dispatch/lookup or semantic edit grant.',
'Whole actual compiled BodyId/source allocation and report collision/opaque declaration graph/canonical edge/missing summary-source guards read. Pure/effect fields require independent real interproc summary; display strings cannot reconstruct allocation.',
'Whole original command rename source application helper,6domain opaque names and current owner/duplicate providers/collision/read-only callback/alias/mathfunc refusal controls read. Retained source/identity/strong transform contract separate from source coverage and expected strings.',
'Whole type hierarchy fixed Tcl8.6 analysis/ASCII pos_of and expected class namespace/mixin/super/sub/unknown nonself controls read. Name-string expected reports not actual class identity/call entry; production typed hierarchy owner gaps remain separate.'
]
for x,n in zip(w['regions'],notes):
 key=(x['path'],x['start_line'],x['end_line'],x['source_sha256']);assert key not in seen;seen.add(key)
 d['regions'].append({key:x[key]for key in ['path','start_line','end_line','source_sha256']}|{'review_status':'reviewed_source_only','classification':'actual_whole_inline_source_and_owner_controls','reason':n+' Exact full statements/helpers/imports inspected, no test-attribute purity inference. Original source/selectors/assertions/budgets unchanged; no provider/helper/test/fs/env/build executed and no migration acceptance.'})
p.write_text(json.dumps(d,indent=2)+'\n')
p=r/'lsp-root-external-wave2-reservation.json';d=json.loads(p.read_text());d['status']='released_to_lsp_serial_unexamined';d['limitation']='Root released proposed reservation; no actual-read/source coverage credit. Eight files remain primary lane unexamined until independently read.'
for x in d['files']:x['review_status']='unexamined_released_to_lsp'
p.write_text(json.dumps(d,indent=2)+'\n')
