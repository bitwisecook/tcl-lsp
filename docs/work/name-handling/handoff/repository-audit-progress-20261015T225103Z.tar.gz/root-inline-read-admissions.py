from root_audit_support import *
import hashlib
P=OUT
admitted={
'rust/f5-cli/src/commands/fetch.rs':[(260,289)],
'rust/f5-cli/src/commands/remote/object_io.rs':[(347,384)],
'rust/f5-xc/src/names.rs':[(118,179)],
'rust/f5-xc/src/terraform.rs':[(595,648)],
'rust/f5-xc/src/translator.rs':[(36,37),(41,42),(82,106),(108,114),(118,121),(123,126),(128,147),(149,157),(161,182),(2153,2184)],
'rust/tcl-cli-support/src/chrome.rs':[(104,129)],
'rust/tcl-cli-support/src/environment.rs':[(88,137)],
'rust/tcl-cli/src/commands/diag.rs':[(733,756)],
'rust/tcl-cli/src/commands/graphs.rs':[(146,157)],
'rust/tcl-cli/src/commands/pkg.rs':[(1812,1834)],
'rust/tcl-mcp/src/tools.rs':[(3581,3642),(3842,3871),(3873,3909)],
'rust/tcl-pkg-model/src/json.rs':[(100,129)],
'rust/tcl-pkg/src/registry.rs':[(290,348)],
'rust/tcl-pkg/src/ui.rs':[(118,149)],
'rust/tcl-pkg/src/venv/config.rs':[(136,189)],
'rust/tcl-pkg/src/venv/posix_source.rs':[(188,199),(205,258),(259,314)],
}
save('root-inline-actual-read-admissions.json',dict(baseline=load('root-file-coverage.json')['baseline'],admitted=[dict(path=path,ranges=ranges,note='Actual original body read including operational setup; fixed inputs/assertions distinct from generic helpers; no execution or Native authority. Test-only source helpers retain explicit test purpose, not production resolver acceptance.') for path,ranges in admitted.items()]))
j=load('root-inline-operational-census.json')
for r in j['regions']:
 if (r['first_line'],r['last_line']) in admitted.get(r['path'],[]):r['review_status']='actual_complete_region_source_read'
save('root-inline-operational-census.json',j)
tasks=[]
for r in j['regions']:
 if r['review_status'].startswith('unexamined'):
  for a in range(r['first_line'],r['last_line']+1,330):tasks.append(dict(path=r['path'],first_line=a,last_line=min(a+329,r['last_line']),region_sha256=r['region_sha256'],status='pending_actual_read'))
save('root-inline-read-queue.json',dict(status='READ QUEUE ONLY, not review or semantic closure',chunks=tasks))
print('pending chunks',len(tasks))
for i,t in enumerate(tasks):print(i,t['path'],t['first_line'],t['last_line'])
