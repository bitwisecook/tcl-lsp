import pathlib,json,re,hashlib,datetime,runpy,collections
x=runpy.run_path('/workspace/name-session/full-consumer-audit/audit-review-tools.py');c,s=x['load']();rows={r['path']:r for r in c['files']};repo=x['REPO'];groups=[];matches={};bad=[]
# Only original captured/evidence roots whose maintainer indexes were read.
roots=('experiments/name-handling/','docs/design/analysis/name-resolution-proofs/rust-validation/','scripts/dev/bigip-probes/resolution-2286/evidence/','docs/work/name-handling/handoff/')
authorities=[{'path':p,'sha256':rows[p]['source_sha256'],'scope':'Retained original provider/input/results or historical execution archives; no current implementation/semantic acceptance.'} for p in ['experiments/name-handling/README.md','experiments/name-handling/results/README.md','experiments/name-handling/f5/answers/README.md','docs/design/analysis/name-resolution-proofs/README.md','docs/design/analysis/name-resolution-proofs/rust-validation/README.md'] if p in rows]
seal_names={'SHA256SUMS','MANIFEST.sha256','checksums.sha256','SHA256SUMS.txt','SHA256SUMS.sha256','sha256sums.txt'}
for path,r in rows.items():
 if not path.startswith(roots) or pathlib.Path(path).name not in seal_names:continue
 data=x['content'](r);entries=[]
 for line in data.decode('utf-8','replace').splitlines():
  m=re.match(r'^([0-9a-fA-F]{64})[ \t]+\*?(.+?)\s*$',line)
  if not m:continue
  raw=m[2];p=pathlib.Path(raw)
  if p.is_absolute():continue
  selected=(repo/pathlib.Path(path).parent/p).resolve()
  try:relative=selected.relative_to(repo).as_posix()
  except ValueError:continue
  target=rows.get(relative)
  if target is None:continue
  if target['source_sha256']!=m[1].lower():bad.append({'seal':path,'path':relative,'declared':m[1].lower(),'actual':target['source_sha256']});continue
  matches.setdefault(relative,[]).append(path);entries.append(relative)
 if entries:groups.append({'id':'seal:'+path,'rule':'Exact relative-path membership in retained checksum inventory AND complete baseline source SHA equality; role filtering below excludes every harness/adapter/generator and maintained source/docs.','manifest':path,'manifest_sha256':r['source_sha256'],'matched_members':len(set(entries)),'authorities':authorities})
code={'.py','.sh','.rs','.js','.ts','.c','.h','.cpp','.java','.kt','.el','.lua','.fish','.bat','.cmd','.ps1'}
outputs={'.stdout','.stderr','.log','.exit','.headers','.bin','.body','.status','.gz','.hex','.out','.patch','.diff','.before','.tsv','.txt','.json','.jsonl','.conf','.csv','.sha256','.tgz','.zip','.tar','.xz','.png','.svg','.dat','.bytes'}
rawnames={'stdout','stderr','exit','status','execution.stdout','execution.stderr','probe','observer','driver','tclsh','jimsh','SHA256SUMS','MANIFEST.sha256'}
counts=collections.Counter()
for p,seals in matches.items():
 r=rows[p];suffix=pathlib.Path(p).suffix;name=pathlib.Path(p).name
 if r['review_status']=='reviewed' or suffix in code or suffix=='.md':continue
 fixture=suffix in {'.tcl','.test'} and (name in {'input.tcl','setup.tcl','program.tcl','cases.tcl','source.tcl','fixture.tcl'} or '/inputs/' in p or '/cases/' in p or '/fixtures/' in p)
 if suffix not in outputs and name not in rawnames and not fixture:continue
 # JSON checker schemas and source lists are archive metadata only here, not production registries.
 r.update(review_status='reviewed',review_mode='provenance_manifest_membership',classification='retained_capture_fixture_or_metadata',group_rule='seal:'+seals[0],reason='Exact baseline bytes occur in the named retained capture checksum closure. This path is data/output/explicit fixture, not an active naming harness, adapter, generator or production module. Provider answers, failed stages and execution acceptance remain independent and unclassified by this grouping.',reviewed_production_extent='No production code at this data/fixture path; artifact-purpose scope only.',evidence=[{'path':q,'sha256':rows[q]['source_sha256']} for q in seals],tests='No execution/current-source acceptance; capture role and baseline hash only.')
 counts[suffix or '<none>']+=1
c['group_rules'].extend(g for g in groups if g['id'] not in {a['id'] for a in c['group_rules']});c['archive_membership_checks']={'matched_paths':len(matches),'grouped_this_run':sum(counts.values()),'grouped_extensions':dict(counts),'checksum_mismatches':bad,'excluded_roles':'All code/harness extensions, Markdown guidance/reports and unproven paths remain unexamined. No blanket root/package exclusion.'};x['save'](c,s);print(c['archive_membership_checks']);print('remaining',c['summary'])
