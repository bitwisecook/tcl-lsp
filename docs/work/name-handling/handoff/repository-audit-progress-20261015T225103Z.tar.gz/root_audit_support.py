from pathlib import Path
import json,re,datetime
OUT=Path('/workspace/name-session/full-consumer-audit')
def load(name):return json.loads((OUT/name).read_text())
def save(name,x):(OUT/name).write_text(json.dumps(x,indent=2)+'\n')
def reviewed(path,reason,classification='first_party_production',end=None):
 j=load('root-file-coverage.json');row=next(x for x in j['files'] if x['path']==path);s=(OUT/'root-source'/path).read_text();lines=s.splitlines();test=re.search(r'^#\[cfg\(test\)\]\s*\nmod tests',s,re.M)
 if end is None:end=len(s[:test.start()].splitlines()) if test else len(lines)
 row.update(review_status='production_reviewed',classification=classification,review_mode='direct_source_read',reviewed_lines=[1,end],test_body_review='separate_validation_scope' if end<len(lines) else 'none_separated',justification=reason)
 save('root-file-coverage.json',j)
def consumer(path,symbol,site,line,purpose,api,missing,disposition,tests=None,evidence=None):
 j=load('root-consumers.json');r=next(x for x in load('root-file-coverage.json')['files'] if x['path']==path)
 key=path+'::'+symbol+'::'+site
 assert not any(x['id']==key for x in j['consumers']),key
 j['consumers'].append(dict(id=key,path=path,symbol=symbol,site=site,line=line,source_sha256=r['sha256'],purpose=purpose,shared_api=api,missing_integration=missing,disposition=disposition,verification_status='source_review_only',tests=tests or [],evidence=evidence or [],reviewed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
 save('root-consumers.json',j)
