from pathlib import Path
from collections import Counter
import json,hashlib,datetime,os
r=Path('/workspace/name-session/full-consumer-audit');f=json.loads((r/'db-file-coverage.json').read_text());c=json.loads((r/'db-consumers.json').read_text());by={x['path']:x for x in f['files']};assert len(by)==17486
assert len({x['id'] for x in c['consumers']})==len(c['consumers'])
for x in c['consumers']:
 assert x['path'] in by,x['id'];assert x['source_sha256']==by[x['path']]['source_sha256'],x['id'];assert x['blob']==by[x['path']]['blob'],x['id'];assert x['baseline']==f['baseline'],x['id']
checked=0; manifest_only=[]
for x in f['files']:
 p=r/'db-baseline'/x['path']
 if not p.is_file():
  manifest_only.append({'path':x['path'],'review_status':x['review_status'],'blob':x['blob'],'source_sha256':x['source_sha256']});continue
 assert hashlib.sha256(p.read_bytes()).hexdigest()==x['source_sha256'],x['path'];checked+=1
now=datetime.datetime.now(datetime.timezone.utc).isoformat();status=Counter(x['review_status'] for x in f['files']);disp=Counter(x['disposition'] for x in c['consumers']);work=Counter(x.get('work_kind','unspecified') for x in c['consumers'])
p={'baseline':f['baseline'],'as_of_utc':now,'assigned_files':len(f['files']),'file_statuses':dict(status),'consumers':len(c['consumers']),'consumer_dispositions':dict(disp),'work_kinds':dict(work),'status':'PAUSED at user request. Incomplete exhaustive source audit; all actual completed reads flushed. Production reads, pending inline operational bodies, historical evidence and schema classifications remain separate. No source/build/provider/test execution or migration acceptance.','production_paths_actual_read':status['production_reviewed']+status['production_reviewed_inline_tests_pending'],'backlog':{'assigned_unexamined_files':status['unexamined'],'production_files_with_inline_tests_pending':status['production_reviewed_inline_tests_pending'],'test_helper_files_with_inline_tests_pending':status['test_helpers_reviewed_inline_tests_pending'],'coarse_test_census_bodies':3387,'coarse_test_census_note':'Census retains all3387 as pending; actual complete source/inline review exceptions live in exact db-complete-test-source-read-batch*.json and db-complete-inline-source-read-batch1.json receipts. No net body completion total inferred from regex or #[test] membership.','helper_inventory_functions':884,'helper_inventory_module_include_sites':2264,'helper_inventory_note':'Candidate inventory, not remaining operational count or completed source review.','partially_started_production_file':None,'schema_only_unexamined_files':['rust/tcl-spec-studio-wasm/Cargo.lock','rust/tcl-spec-studio/web/package-lock.json']},'correction_receipt':'db-disposition-purpose-correction.json','validation':f'Artifact integrity only: {checked} available extracted baseline files sourceSHA verified; {len(manifest_only)} other assigned blobs retain explicit manifest classifications and source hashes (not freshly re-read). Unique consumer IDs, all purpose rows rejoined exact baseline/path/blob/sourceSHA. No tests/providers/builds invoked.'}
def atomic(path,data):
 t=path.with_suffix(path.suffix+'.tmp');t.write_text(json.dumps(data,indent=2)+'\n');os.replace(t,path)
atomic(r/'db-progress.json',p)
atomic(r/'db-pause-receipt.json',{'baseline':f['baseline'],'created_utc':now,'state':'paused incomplete','progress':p,'last_complete_reads':['fconfigure_.rs production1–371','subst_.rs production1–351','glob_.rs production1–297'],'pending_question':'registry.substitution.taint-gate-selected-context pending_audit; actual Compiler whole taint caller review still outstanding.','no_source_edits':True,'no_execution':True})
names=['db-file-coverage.json','db-consumers.json','db-progress.json','db-pause-receipt.json','db-disposition-purpose-correction.json','db-consumers-before-purpose-status-correction.json','db-partial-reads.json']
seal={n:hashlib.sha256((r/n).read_bytes()).hexdigest() for n in names};atomic(r/'db-pause-artifact-integrity.json',{'baseline':f['baseline'],'checked_utc':now,'files':seal,'status':'PASS available source hashes+row pairing+JSON parse; audit incomplete paused','extracted_source_files_checked':checked,'other_manifest_entries':manifest_only})
print(json.dumps(p,indent=2));print('seal',hashlib.sha256((r/'db-pause-artifact-integrity.json').read_bytes()).hexdigest())
