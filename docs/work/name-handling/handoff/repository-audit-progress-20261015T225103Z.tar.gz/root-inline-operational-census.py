from root_audit_support import *
import hashlib
ns={};exec((OUT/'compiler-extract-production.py').read_text().split('rows=[]')[0],ns);mask=ns['mask']
rows=[];coverage=load('root-file-coverage.json')
def extent(m,start):
 op=m.find('{',start)
 if op<0:return len(m)
 depth=1;i=op+1
 while i<len(m) and depth:
  if m[i]=='{':depth+=1
  elif m[i]=='}':depth-=1
  i+=1
 return i
for row in coverage['files']:
 path=row['path']
 if not path.endswith('.rs') or row.get('classification')=='fixed_test_input_or_golden':continue
 s=(OUT/'root-source'/path).read_text();m=mask(s);regions=[]
 for a in re.finditer(r'#\s*\[\s*cfg\s*\(\s*test\s*\)\s*\]',m):
  end=extent(m,a.end());semi=m.find(';',a.end())
  if 0<=semi<m.find('{',a.end()):end=semi+1
  regions.append((a.start(),end,'cfg_test_item'))
 for a in re.finditer(r'#\s*\[\s*test\s*\]',m):
  if any(lo<=a.start()<hi for lo,hi,_ in regions):continue
  regions.append((a.start(),extent(m,a.end()),'test_function'))
 if not regions:continue
 complete=row.get('classification')=='operational_test_harness' and row.get('review_status')=='production_reviewed'
 for lo,hi,kind in regions:
  text=s[lo:hi];first=s.count('\n',0,lo)+1;last=s.count('\n',0,hi)+1
  candidates=[{'line':first+n,'text':line.strip()} for n,line in enumerate(text.splitlines()) if re.search(r'Command|std::env|std::fs|\.env\(|\.output\(|\.spawn\(|provider|sha256|artifact|tclsh|native|fs::',line)]
  rows.append(dict(path=path,source_sha256=row['sha256'],git_blob=row['blob'],kind=kind,first_line=first,last_line=last,region_sha256=hashlib.sha256(text.encode()).hexdigest(),review_status='actual_complete_source_read' if complete else 'unexamined_inline_operational_content',candidates=candidates,note='Lexical candidate list is screening only. Zero candidates proves no purity; source review never grants execution acceptance.'))
 if not complete:
  row['production_review_status']=row['review_status']
  row['whole_file_review_status']='unfinished_inline_operational_tests_and_helpers'
  row['test_body_review']='unexamined_regions_bound_in_root-inline-operational-census.json'
save('root-file-coverage.json',coverage)
save('root-inline-operational-census.json',dict(baseline=coverage['baseline'],status='Exact source extents; inline operational work remains explicit, not closed by attributes or candidate absence',regions=rows))
print('Root exact inline/test regions',len(rows),'pending',sum(r['review_status'].startswith('unexamined') for r in rows))
