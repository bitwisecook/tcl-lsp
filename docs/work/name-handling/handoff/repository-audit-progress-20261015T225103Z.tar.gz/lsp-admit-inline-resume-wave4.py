import json
from pathlib import Path
r=Path('/workspace/name-session/full-consumer-audit');p=r/'lsp-inline-reviewed-regions.json';d=json.loads(p.read_text());w=json.load(open(r/'lsp-inline-next-wave4.json'));seen={(x['path'],x['start_line'],x['end_line'],x['source_sha256'])for x in d['regions']}
notes=[
'Actual vendor declaration/event source cards, cleared report maps, unknown Unicode-unit refusal, stale-image and Native-purpose separation controls read.',
'Whole configured ExecutablePartArena variable-root helper plus original root-only edit wrapper/index/currentness controls read. C lexical empty-root observation explicitly separate from editor geometry; source edit output is not semantic rename acceptance.',
'Actual original class/method declarations after report erasure and distinct surrogate names, configured inserted-word byte roundtrip/complete grouped selector and own-self noninheritance controls read.',
'Whole configured method-head UTF16 helper plus FirstClose/Tcl9Nesting/scalar-versus-compound variable and actual navigation source controls read. No receiver execution or live storage grant.',
'Actual selected document-link handlers, POSIX literal backslash URI, stale source/report erasure/source-option release floors and literal package data controls read; no filesystem load.',
'Whole selected configured expression topology/or-chain/strict completed literal values and source action expected DG keys/type controls read. Standalone proposal remains distinct from actual transform/observer authority.',
'Actual original procedure role inventory, opaque counted names, report erasure, whole-input/current source and namespace shadow/source operand refusal controls read.',
'Whole fixed authoring declaration outline source/profiles, nested actual grammar block labels and script-document negative read. Labels are explicit outline display, no declaration runtime identity.',
'Whole genuine cursor declaration join helper and current image/actual VarDef allocation/same symbol controls read; conditional alias templates retain obligations and distinct local frame/report-link erasure.',
'Whole configured inserted-source selector decode helper and actual original inheritance/mixin/property projection controls read. Source declaration advice explicitly differs from live method installation/dispatch.',
'Actual positioned retained namespace export events/clear order, counted opaque names/import query point and foreign policy Unknown controls read. RunOrder source execution assumptions remain separate production repair.',
'Whole original receiver reference/current Editor input/config/Registry counterfactual controls read; raw authored ledger presence does not bootstrap method target/rename/ref API after missing current input.',
'Whole Sslic loader diagnostic/source-span/producer/severity and policy-layer presentation controls read; fixed authoring codes/values not live Tcl command/variable identities.',
'Whole injected Registry/current-input method hierarchy helper and selected dispatch floor/same frame versus deferred body/report head controls read. Reporting collection not complete runtime call graph.',
'Whole configured actual callback variable source/UTF16/reference helper and brace modes/static whole-name versus compound/array/escaped negatives read. Stored callback source reference not proof of invocation/Normal.'
]
for x,n in zip(w['regions'],notes):
 key=(x['path'],x['start_line'],x['end_line'],x['source_sha256']);assert key not in seen;seen.add(key)
 d['regions'].append({key:x[key]for key in ['path','start_line','end_line','source_sha256']}|{'review_status':'reviewed_source_only','classification':'actual_whole_inline_source_and_owner_controls','reason':n+' Exact full region imports/helpers/statements inspected, not test-attribute purity inference. Original fixtures/assertions/budgets preserved; no helper/provider/fs/env/build/test execution or implementation acceptance.'})
p.write_text(json.dumps(d,indent=2)+'\n')
