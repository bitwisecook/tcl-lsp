import json,os,hashlib
from pathlib import Path
R=Path('/workspace/name-session/full-consumer-audit')
def save(n,d):
 p=R/n;t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(d,indent=2)+'\n');os.replace(t,p)
p=R/'vm-consumers.json';raw=p.read_bytes();D=json.loads(raw)
before='vm-consumers-before-resumed-status-'+hashlib.sha256(raw).hexdigest()[:12]+'.json';(R/before).write_bytes(raw)
rows=[r for r in D['consumers'] if r['disposition']=='migrated_validation_pending'][:60]
for r in rows:
 r['status_review']={'state':'individually_reconciled_existing_component','basis':'Actual frozen implementation already read; selected shared API transport at this named site is implemented. Independently stated issuer/downstream/provider/Native stage limits do not confer whole-method acceptance. No validation result inferred.','retained_disposition':r['disposition']}
 if r['id']=='vm-0008':
  r['disposition']='display_only';r['work_kind']='display_or_exclusion';r['work_kind_reason']='Terminal host diagnostic presentation via fallible message_bytes / typed Host Display; no identity or execution selection.';r['status_review']['retained_disposition']='display_only';r['status_review']['basis']='Actual append_failure purpose is terminal diagnostic output, not consumer migration or physical result admission.'
for r in D['consumers']:
 if r['id']=='vm-0119':r['missing_integration']='Actual no-argument holder selection in cmd_namespace.rs was subsequently fully source-read and is separately recorded at vm-0122. Prior133 frozen8df Parent controls passed; current cc24 physical getter/refcount/callback schedule not inferred.'
 if r['id']=='vm-0121':r['missing_integration']='Actual shared parser/helper delegation source read. Specials (-help/-commands/missing) and actual mutable diagnostic stages retain separate explicit implementation gaps at their owner rows; actual provider versus authored NamePolicy remains independent.'
save('vm-consumers.json',D)
save('vm-status-reconciliation-resumed-01.json',{'baseline':D['baseline'],'beforeimage':before,'beforeimage_sha256':hashlib.sha256(raw).hexdigest(),'reviewed_ids':[r['id'] for r in rows],'changed':[{'id':'vm-0008','before':'migrated_validation_pending','after':'display_only','reason':'Terminal display purpose, no identity migration.'}],'cross_reference_updates':['vm-0119','vm-0121'],'limits':'Remaining legacy statuses still require individual reconciliation; no mass disposition changes or validation acceptance.'})
