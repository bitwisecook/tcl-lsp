from pathlib import Path
import json,hashlib,runpy,re
m=runpy.run_path('/workspace/name-session/full-consumer-audit/lsp-audit.py');r=m['ROOT'];c,k=m['load']();rows=[]
receipts=json.loads((r/'lsp-inline-reviewed-regions.json').read_text())['regions'] if (r/'lsp-inline-reviewed-regions.json').exists() else []
receipt_map={(x['path'],x['start_line'],x['end_line'],x['source_sha256']):x for x in receipts}
patterns={
 'process_or_provider':r'\b(?:Command|spawn|exec|wait_with_output|tclsh|jimsh|tcltest|run_oracle|oracle|provider|toolchain)\b',
 'environment':r'\b(?:std::env|env::|set_var|remove_var|current_dir|set_current_dir|var_os)\b',
 'filesystem_or_artifact':r'\b(?:std::fs|fs::|tempfile|TempDir|write_all|write_to|read_to_string|read_to_end|include_str|include_bytes|File::|OpenOptions|PathBuf|metadata|symlink)\b',
 'network_or_transport':r'\b(?:TcpStream|TcpListener|reqwest|hyper|tokio::process|Child|http_client|download|socket)\b',
}
for f in c['files']:
 if not f['path'].endswith('.rs') or f['review_status'] not in ('reviewed','partially_reviewed'):continue
 raw=(m['BASE']/f['path']).read_bytes();s=raw.decode();_,ranges=m['production'](f['path']);merged=[]
 for a,b in sorted(ranges):
  if merged and a<=merged[-1][1]:merged[-1][1]=max(b,merged[-1][1])
  else:merged.append([a,b])
 if not merged:
  f['production_review_status']='complete' if f['review_status']=='reviewed' else 'partial';f['inline_test_review_status']='no_whole_cfg_test_item_omitted';continue
 regions=[]
 for a,b in merged:
  t=s[a:b];hits=[]
  for kind,pat in patterns.items():
   for match in re.finditer(pat,t):
    line=s[:a+match.start()].count('\n')+1
    hits.append(dict(kind=kind,line=line,lexeme=match.group()))
  regions.append(dict(start_line=s[:a].count('\n')+1,end_line=s[:b].count('\n')+1,source_sha256=hashlib.sha256(t.encode()).hexdigest(),review_status='unexamined_inline_region',classification='unfinished_including_possible_operational_helpers',operational_lexical_candidates=hits,limitation='Lexical candidates are triage only; no absence of hits or test attribute proves purity. All omitted region statements/helpers remain actual-read pending.'))
 for region in regions:
  receipt=receipt_map.get((f['path'],region['start_line'],region['end_line'],region['source_sha256']))
  if receipt:
   region.update(review_status=receipt['review_status'],classification=receipt['classification'],review_reason=receipt['reason'],limitation='Actual source read only; no execution or naming conformance acceptance.')
 f['production_review_status']='complete' if f['review_status']=='reviewed' else 'partial'
 pending=any(x['review_status']=='unexamined_inline_region' for x in regions)
 f['inline_test_review_status']='unexamined_omitted_regions' if pending else 'all_regions_source_reviewed'
 f['whole_file_review_status']='unfinished_inline_tests_and_helpers' if pending else 'complete_source_read_no_execution'
 rows.append(dict(path=f['path'],blob=f['blob'],source_sha256=f['source_sha256'],regions=regions))
(r/'lsp-inline-operational-census.json').write_text(json.dumps(dict(baseline='cc24c394004fc187378ba0eefb6c2c5b2615fb00',scope='Every reviewed/partially reviewed Rust file with whole cfg(test) regions omitted by production extractor. Separate source census only; no test purity or operational review acceptance.',files=rows),indent=2)+'\n')
m['save'](c,k)
print('files',len(rows),'regions',sum(len(x['regions']) for x in rows),'candidatehits',sum(len(y['operational_lexical_candidates'])for x in rows for y in x['regions']))
