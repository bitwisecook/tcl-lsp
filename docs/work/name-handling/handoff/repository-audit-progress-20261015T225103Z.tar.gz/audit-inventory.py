import json, pathlib, hashlib, datetime, collections, os
BASE=pathlib.Path('/workspace/name-session/full-consumer-audit')
REPO=pathlib.Path('/workspace/tcl-lsp')
b=json.loads((BASE/'baseline-files.json').read_text())
assigned=json.loads((BASE/'audit-assigned-files.json').read_text())
seen={};duplicates=[];partitions=[]
for p in sorted(BASE.glob('*-assigned-files.json')):
 m=json.loads(p.read_text()); partitions.append({'file':p.name,'baseline':m['baseline'],'files':len(m['files']),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
 for f in m['files']:
  if f['path'] in seen: duplicates.append({'path':f['path'],'first':seen[f['path']],'second':p.name})
  seen[f['path']]=p.name
baseline={f['path']:f for f in b['files']}
report={'baseline':b['baseline'],'captured_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseline_manifest_sha256':hashlib.sha256((BASE/'baseline-files.json').read_bytes()).hexdigest(),'partitions':partitions,'baseline_rows':len(b['files']),'baseline_unique':len(baseline),'assigned_unique':len(seen),'missing':sorted(set(baseline)-set(seen)),'extra':sorted(set(seen)-set(baseline)),'duplicate_assignments':duplicates,'schema_errors':[],'execution':'Read-only inventory, no build/provider/generator.'}
for f in b['files']:
 if f.get('owner') not in {'audit','compiler','db','lsp','runtime','vm','root'} or not isinstance(f.get('blob'),str) or len(f['blob'])!=40 or f.get('git_type')!='blob':report['schema_errors'].append(f['path'])
for p in BASE.glob('*-assigned-files.json'):
 m=json.loads(p.read_text())
 for f in m['files']:
  if f != baseline.get(f['path']):report['schema_errors'].append({'path':f['path'],'reason':'assignment row differs from baseline'})
(BASE/'audit-partition-check.json').write_text(json.dumps(report,indent=2)+'\n')
rows=[];drift=[];total=0
for i,f in enumerate(assigned['files']):
 p=REPO/f['path'];h=hashlib.sha256();git=hashlib.sha1();git.update(f"blob {p.stat().st_size}\0".encode());n=0
 with p.open('rb') as stream:
  for chunk in iter(lambda:stream.read(1024*1024),b''):h.update(chunk);git.update(chunk);n+=len(chunk)
 match=(git.hexdigest()==f['blob'])
 if not match:drift.append(f['path'])
 rows.append({'path':f['path'],'blob':f['blob'],'baseline':b['baseline'],'source_sha256':h.hexdigest(),'source_bytes':n,'worktree_blob_matches_baseline':match,'owner':'audit','review_status':'unexamined','review_mode':'inventory_only','classification':'unexamined','group_rule':None,'reason':'Exact file hashed; assigned purpose/content review not yet completed. Hashing is not consumer acceptance.','consumer_ids':[],'evidence':[],'tests':'unexamined/unexecuted'})
 total+=n
 if i and i%10000==0:print('hashed',i,'bytes',total,flush=True)
out={'schema_version':1,'baseline':b['baseline'],'captured_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'All75753 Audit-assigned paths; pending direct production review and explicit provenance-based archive grouping.','assigned_manifest_sha256':hashlib.sha256((BASE/'audit-assigned-files.json').read_bytes()).hexdigest(),'status':'IN_PROGRESS','summary':{'files':len(rows),'source_bytes':total,'baseline_drift':drift,'reviewed':0,'unexamined':len(rows)},'group_rules':[],'files':rows}
(BASE/'audit-file-coverage.json').write_text(json.dumps(out,indent=2)+'\n')
(BASE/'audit-consumers.json').write_text(json.dumps({'schema_version':1,'baseline':b['baseline'],'status':'IN_PROGRESS','allowed_dispositions':['needs_migration','migrated_validation_pending','migrated_verified','shared_owner','display_only','out_of_scope'],'scope':'Audit-owned files only; predecessor samples never imply completion.','consumers':[]},indent=2)+'\n')
print('DONE',len(rows),total,'drift',drift,flush=True)
