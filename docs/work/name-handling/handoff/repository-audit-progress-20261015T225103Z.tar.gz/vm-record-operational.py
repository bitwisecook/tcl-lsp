import json,os,sys
from pathlib import Path
R=Path('/workspace/name-session/full-consumer-audit')
def save(n,d):
 p=R/n;t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(d,indent=2)+'\n');os.replace(t,p)
def external(paths,reason):
 d=json.loads((R/'vm-file-coverage.json').read_text());c=json.loads((R/'vm-test-source-census.json').read_text())
 for p in paths:
  r=next(x for x in d['rows'] if x['path']==p); n=len((R/'vm-source'/p).read_text().splitlines());r.update(review_mode='test_operational_body_read',classification='test_harness',reason=reason,review_ranges=[[1,n]])
  for x in c['rows']:
   if x['path']==p:x['actual_read_status']='actual complete frozen source body/setup/operational helper read; not execution';x['operational_review_reason']=reason
 save('vm-file-coverage.json',d);save('vm-test-source-census.json',c)
def inline(path,start,end,reason):
 d=json.loads((R/'vm-inline-test-operational-census.json').read_text());r=next(x for x in d['rows'] if x['path']==path and x['known_actual_cfg_test_exclusion']['start']==start)
 assert r['known_actual_cfg_test_exclusion']['end']==end
 r['status']='actual source/body/setup read; no execution';r['operational_review_reason']=reason
 for f in r['functions']: f['mode']='actual source read; no execution or Native conformance acceptance'
 save('vm-inline-test-operational-census.json',d)
if __name__=='__main__':exec(sys.stdin.read())
