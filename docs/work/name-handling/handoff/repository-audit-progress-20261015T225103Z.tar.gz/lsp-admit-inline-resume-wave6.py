import json
from pathlib import Path
r=Path('/workspace/name-session/full-consumer-audit');p=r/'lsp-inline-reviewed-regions.json';d=json.loads(p.read_text());w=json.load(open(r/'lsp-inline-next-wave6.json'));seen={(x['path'],x['start_line'],x['end_line'],x['source_sha256'])for x in d['regions']}
notes=[
'Whole fixed Tcl8.6 source analyser/pos_of helper and variable/class/method/lattice/namespace type-definition controls read. Helper byte-column math confined ASCII fixedfixtures, not general source geometry.',
'Whole genuine selected variable/member source geometry colour helper with UTF16 positions and escaped/quoted/static/compound/wrapper/inline/inert/shadow/missingctx controls read. Colour does not certify OO variable validity/member identity/cell.',
'Whole Logical class selector lineage rename/alias/captured/replacement/tombstone/Unicode/currentinput and cross-domain refusal controls read; reference roster not transform or actual Alias execution.',
'Whole ExitSignal async byte readers/EOF repeated/condvar/shutdown/exact fixed protocol method controls read. No process exits invoked; source of async input is retained in-memory fixed bytes, not actual transport/runtime names.',
'Whole docstring action helper with actual original source declaration/formal/source currency and computed-body/prelude/body-style controls read. Comments/source construction inspect exact edit text; no generic source semantic rewrite proof.',
'Whole selected custom Registry next-chain/Name role/availability/current schema and alias captured-target source controls read. Source topology/value only, not actual next invocation or entered receiver.',
'Whole authentic Logical namespace/class/import/extension-stub navigation controls read, currentinput/stale-source refusal and expected original class count retained. Source declaration index is not live command identity.',
'Whole original source-variable selection and UTF16 edit application helper plus opaque sibling/scalar versus array/index/local frame/collision/global/upvar alias expected controls read. Edited text alone cannot supply independent complete semantic rename authorization.',
'Whole actual Native original class/object fuzzy candidate helper and source/config/foreigninput/nominal widget report counterfactual read. Missing real receiver metadata cannot be restored by display maps; candidate advice not installation.',
'Whole typed export snapshot/opaque namespace import and UI-lossy/policy/unknown operand refusal controls read. Unknown preserves unavailable source inventory; no physical export absence proof.',
'Whole injected independent Logical profile/context/Registry store helper and indexed class family/actual metadata store replacement/slot reuse/currentness controls read. Truncated output explicitly reread14280–14398 before admission.',
'Whole CurrentSourceContext source/config/context/foreign/missing/reportlabel and public editor positive/refusal helpers read. Source currency remains independent of naming purpose; truncated portion explicitly reread57–176.',
'Whole original method implementation/declaration inventory and duplicate/foreign source/instance-versus-class side controls read. Distinct URI/provider/source owner retained; no whole-runtime method MRO proof or rename authority.',
'Whole authentic syntax compaction region helper and selected script versus unknown conditional advisory/source-owned bracket/body-word and argument-replacement counterfactual controls read. Closed syntax purpose not Native role/Normal grant.'
]
for x,n in zip(w['regions'],notes):
 key=(x['path'],x['start_line'],x['end_line'],x['source_sha256']);assert key not in seen;seen.add(key)
 d['regions'].append({key:x[key]for key in ['path','start_line','end_line','source_sha256']}|{'review_status':'reviewed_source_only','classification':'actual_whole_inline_source_and_owner_controls','reason':n+' Exact complete region/imports/helpers/statements actually inspected. No test-attribute purity inference; original fixtures/assertions/budgets unchanged. No async/fs/env/helper/provider/tests/build executed or migration acceptance.'})
p.write_text(json.dumps(d,indent=2)+'\n')
