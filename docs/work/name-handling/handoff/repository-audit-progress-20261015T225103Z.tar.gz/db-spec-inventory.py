from pathlib import Path
import json,collections,hashlib
R=Path('/workspace/name-session/full-consumer-audit'); C=json.loads((R/'db-file-coverage.json').read_text());rows=[]
# Audit-only byte-preserving lexical boundary inventory, not a Tcl evaluator,
# name normaliser, shared production API, or conformance parser.
BLOCKS={'speclib','command','subcommand','hover','environment','semantics','state_transitions','iterate','dialect'}
DYNAMIC={'arg_role_resolver','command_prefix_resolver','script_timing_resolver','const_fold','context_gate','taint_sink_gate','literal_argument_validator','clause_shape_check','option_arity','facts','hook'}
def words(s,a,b):
 out=[];i=a;cmd=[]
 def emit():
  nonlocal cmd
  if cmd:out.append(cmd);cmd=[]
 while i<b:
  ch=s[i]
  if ch in ' \t\r':i+=1;continue
  if ch in '\n;':emit();i+=1;continue
  if ch=='#' and not cmd:
   n=s.find('\n',i);i=b if n<0 else n;continue
  start=i;kind='bare'
  if ch=='{':
   kind='braced';i+=1;depth=1
   while i<b and depth:
    if s[i]=='\\':i+=2
    elif s[i]=='{':depth+=1;i+=1
    elif s[i]=='}':depth-=1;i+=1
    else:i+=1
   if depth:raise ValueError(('unclosed',start))
  elif ch=='"':
   kind='quoted';i+=1
   while i<b:
    if s[i]=='\\':i+=2
    elif s[i]=='"':i+=1;break
    else:i+=1
   else:raise ValueError(('unclosedquote',start))
  else:
   while i<b and s[i] not in ' \t\r\n;':
    if s[i]=='\\':i+=2
    else:i+=1
  raw=s[start:i];cmd.append(dict(start=start,end=i,line=s.count('\n',0,start)+1,kind=kind,raw=raw))
 emit();return out
for x in C['files']:
 if not(x['path'].startswith('specs/') and x['path'].endswith('.tclspec')):continue
 s=(R/'db-baseline'/x['path']).read_text();allrows=[];dynamic=[];unknown=[]
 def visit(a,b,scope):
  for ws in words(s,a,b):
   head=ws[0]['raw'];record=dict(scope=scope,head=head,line=ws[0]['line'],words=ws);allrows.append(record)
   if head in DYNAMIC and any(w['kind']=='braced' for w in ws[1:]):dynamic.append(record)
   if head in BLOCKS:
    w=ws[-1]
    if w['kind']=='braced':visit(w['start']+1,w['end']-1,scope+[head]+([ws[1]['raw']] if head in {'speclib','command','subcommand','option','environment','dialect'} and len(ws)>1 else []))
 visit(0,len(s),[])
 rows.append(dict(path=x['path'],source_sha256=x['source_sha256'],blob=x['blob'],bytes=x['bytes'],method='complete byte-preserving authored DSL directive/word/known-block schema inventory; raw words retain exact source spans; no evaluation or decoded-name assertion',directive_counts=dict(collections.Counter(z['head'] for z in allrows)),statements=allrows,dynamic_bodies=dynamic,review_status='schema_inventory_pending_naming_review'))
(R/'db-spec-metadata-inventory.json').write_text(json.dumps(dict(baseline=C['baseline'],purpose='audit-only source/schema inventory; not parser acceptance, Native lookup, complete dynamic effects or original provider execution',files=rows),indent=2)+'\n')
for x in rows:print(x['path'],len(x['statements']),x['directive_counts'], 'dynamic',[(z['head'],z['line']) for z in x['dynamic_bodies']])
