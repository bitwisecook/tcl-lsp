import runpy,json,re,pathlib,collections
x=runpy.run_path('/workspace/name-session/full-consumer-audit/audit-review-tools.py');c,s=x['load']();rows={r['path']:r for r in c['files']}; added=collections.Counter();checks=[]
code={'.py','.sh','.rs','.js','.ts','.c','.h','.cpp','.java','.kt','.el','.lua','.fish','.bat','.cmd','.ps1','.md','.html','.css','.toml','.yaml','.yml','.wasm'}
def add(path,digest,rule,evidence,reason):
 r=rows.get(path)
 if r is None:return
 if r['source_sha256']!=digest:checks.append({'rule':rule,'path':path,'status':'digest_mismatch','expected':digest,'baseline':r['source_sha256']});return
 if pathlib.Path(path).suffix in code:return
 if r['review_status']=='reviewed':return
 r.update(review_status='reviewed',review_mode='provenance_manifest_membership',classification='retained_capture_fixture_or_metadata',group_rule=rule,reason=reason,reviewed_production_extent='Data/fixture membership only; no production code or Native/source-currentness authority.',evidence=evidence,tests='No execution or current semantic acceptance.');added[rule]+=1
transport='scripts/dev/bigip-probes/resolution-2286/evidence/CURRENT_TRANSPORT_SHA256SUMS';base='scripts/dev/bigip-probes/resolution-2286/'
for line in x['content'](rows[transport]).decode().splitlines():
 m=re.fullmatch(r'([a-f0-9]{64})\s+\*?(.+)',line)
 if m:add(base+m[2],m[1],'current-transport-projection',[{'path':transport,'sha256':rows[transport]['source_sha256']},{'path':base+'evidence/TRANSPORT_PROJECTION.md'}],'Exact current projected transport bytes are pinned by the explicit current manifest. Earlier execution manifests remain historical and their mismatches remain retained; this is not the executed original input or new appliance observation.')
corpus='docs/design/analysis/name-resolution-proofs/corpus-inventory.json';d=json.loads(x['content'](rows[corpus]));corpus_class=collections.Counter()
for item in d['files']:
 if item['path'] in rows:
  corpus_class[item.get('classification','unclassified')]+=1
  add(item['path'],item['sha256'],'retained-corpus-inventory',[{'path':corpus,'sha256':rows[corpus]['source_sha256']}],'Exact baseline fixture/output/metadata membership in the explicit maintained corpus inventory. Existing candidate classification, unresolved questions and provider observation scope are not promoted into an accepted implementation outcome.')
ledger='docs/design/analysis/name-resolution-proofs/rust-validation/ledger.json';d=json.loads(x['content'](rows[ledger]));seen=0
for v in d['validations']:
 for k in ['receipt','log']:
  item=v.get(k,{})
  if 'path' in item and 'sha256' in item:seen+=1;add(item['path'],item['sha256'],'retained-rust-validation-ledger',[{'path':ledger,'sha256':rows[ledger]['source_sha256'],'validation_id':v['id']}],'Exact retained receipt/log bytes identified by the frozen validation ledger. This establishes historical data provenance only; changed source, different images, failed/unentered selectors, external Native scopes and unexecuted assertions remain independent.')
for rule,n in added.items():
 c['group_rules'].append({'id':rule,'rule':'Exact baseline path and SHA256 equality with explicit metadata membership; all executable/harness/source/docs/production-metadata extensions excluded.','added_members':n})
c['additional_provenance_checks']={'added':dict(added),'mismatches':checks,'ledger_references_examined':seen,'corpus_retained_classifications':dict(corpus_class),'prior_execution_mismatches_preserved':c['archive_membership_checks']['checksum_mismatches']}
x['save'](c,s);print(json.dumps(c['additional_provenance_checks'],indent=2)[:3000]);print(c['summary'])
