import runpy,json
from pathlib import Path
r=runpy.run_path('/workspace/name-session/full-consumer-audit/db-record.py')['record'];b='rust/tcl-registry/src/'
items=[
('native_jim_local.rs','InvocationDialect::native_jim_local_protocol',9,'Pinned Jim local-command previous-node/cleanup recipe selection','native_jim_lookup_protocol; Syntax NativeJimLocalProtocol'),
('native_jim_switch.rs','InvocationDialect::native_jim_switch_protocol',7,'Pinned original Jim switch option/matching protocol','native_string_protocol Jim084; Syntax NativeJimSwitchProtocol'),
('script_lookup_scope.rs','ScriptLookupScope::ALL',8,'Explicit metadata callback lookup-frame vocabulary; no entered frame supplied','single ScriptLookupScope enum owner'),
('native_list_index.rs','InvocationDialect::list_index_usage',10,'Selected native usage diagnostic presentation only','InvocationDialect selected version/core point'),
('native_regex.rs','native_regex_protocol / native_jim_regex_protocol',11,'Independent C/Jim selected original regex implementation recipes','native_string_protocol; Syntax NativeRegexpRecipe/JimRegexpRecipe'),
('native_encoding.rs','native_encoding_name_protocol / native_source_file_protocol',11,'Selected encoding-name and source-channel default protocols; no actual file or conversion grant','Family/selected tcl_version; cmd-core encoding owner'),
('native_info_version.rs','native_info_version_source',19,'Original engine member-specific version report source selection','actual Family/core_point; fixed original global key or core release report'),
('pack_origin.rs','PackOrigin',30,'Installed nominal descriptor provenance stamp distinct from authored metadata fields','install::pack_origin and CommandRegistry::pack_origin'),
('native_handler_path.rs','NativeHandlerLookupPaths::select',31,'Original static argv selector chooses descriptor dependency path; no live implementation proof','InvocationArguments::exact_argv_len/literal_at; NativeCompilerImplementationLookup'),
('source_path.rs','SourcePathOperation / SourcePathInvocation',11,'Conditional authored source slash-path algebra and effective argument ordinal range','same source algebra owner; actual consumer original source/argv owner remains separate'),
('native_procedure_body.rs','NativeProcedureBodyCreationProtocol::action / native_procedure_body_creation_protocol',33,'Original body object retention/counted-string-copy rule based on actual sharing observation','native_string_protocol; held actual native sharing and value owner required'),
('native_each_loop.rs','native_each_loop_protocol',29,'Selected generic registered loop implementation engine/collection recipe','native Family/tcl_version or pinned Jim point; runtime-api NativeEachLoopRecipe'),
('native_error_objects.rs','native_error_objects_protocol / has_return_options / has_error_stack',46,'Original C private error-object storage recipe and version-specific members','native_string_protocol C gate; actual caller private header owner independent'),
('native_variable_destruction.rs','array_unset_member_lookup / variable_destruction_protocol',15,'Native variable-container destruction phase/lookup selection','actual native_family and VariableContainerModel; runtime-api destruction protocol'),
('native_lambda.rs','NativeLambdaDiagnosticProtocol::select / wraps_list_failure / conversion_error / parameter_error_frame',18,'Original engine lambda-conversion failure presentation from actual getter bytes','native_string_protocol; actual ValueError NativeListParse protocol; c_string_extent'),
('native_tcloo_method_cache.rs','NativeTclOoMethodCacheProtocol::reusable / native_tcloo_method_cache_protocol',36,'Actual original receiver birth/epoch/flag cache reuse recipe','native_string_protocol C86+; retained creation/foundation/object stamp'),
('native_compiled_variables.rs','native_compiled_variable_protocol / authored_logical_compiled_variable_protocol / compiled_variable_protocol',23,'Distinct actual Native compiler-local and explicitly selected F5 authored simulation recipe ingress','execution_point and existing NativeCompiledVariableProtocol; authored_f5_tcl84_core explicit provider'),
('channel_configuration.rs','ChannelConfigurationSpec::project',21,'Closed selected source option-run encoding/translation operand advice','AuthoredSourceOptionScan; availability/complete one-value topology; no runtime configuration grant'),
('native_compiler_pass.rs','native_compiler_replays',37,'Original selected compiler second-pass replay policy with actual interpreter/procedure namespace environment','NativeCompilerPassEnvironment::is_current_for; actual namespace full-name byte rule; typed hazards')]
files=[];cs=[]
for p,s,l,ctx,api in items:
 files.append((b+p,'shared_purpose_specific_naming_protocol_owner','Complete production source read; actual module export in Registry lib.rs retained. '+ctx+'. Caller allocation/frame/currentness and Native admission remain independent; tests and prior captures do not provide baseline execution acceptance.'))
 cs.append(dict(id='registry.owner.'+p[:-3],path=b+p,symbol=s,line=l,context=ctx,shared_api=api,missing_integration=None,disposition='shared_owner',tests=[p+' exact source test inventory; downstream Runtime/VM ordinary/Native replay requirements remain separate'],evidence=['Complete production file read at pinned baseline; no local resolver/String identity inverse; selected recipe alone grants no live cell/frame/command or Normal.']))
r(files,cs)
root=Path('/workspace/name-session/full-consumer-audit');p=root/'db-file-coverage.json';d=json.loads(p.read_text());x=next(x for x in d['files'] if x['path']==b+'native_test_provider.rs');x.update(review_status='test_source_classified',review_mode='complete_test_helper_source_read_and_parent_cfg_proof',classification='test_only_native_provider_ingress_helper',justification='Full source4-8 read; exact parent lib.rs557 #[cfg(test)] mod native_test_provider proves test-only compilation. Helper reuses resolve_known_environment(...).expect(...).unit_profile; known-environment observation gap separately recorded, no guard widening/source execution.');p.write_text(json.dumps(d,indent=2)+'\n')
a=root/'db-test-helper-inventory.json';v=json.loads(a.read_text());
for x in v['helpers']:
 if x['path']==b+'native_test_provider.rs':x.update(review_status='test_helper_source_reviewed',evidence='Exact lib.rs557 positive cfg(test) parent and full body read; shared known-provider ingress, no independent selector or invented defaults.')
a.write_text(json.dumps(v,indent=2)+'\n')
