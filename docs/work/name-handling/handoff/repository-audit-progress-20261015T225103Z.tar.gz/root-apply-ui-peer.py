from pathlib import Path
import json,hashlib,subprocess,copy,datetime
D=Path(__file__).resolve().parent;R=Path('/workspace/tcl-lsp');B='cc24c394004fc187378ba0eefb6c2c5b2615fb00';p=D/'root-consumers.json';before=p.read_bytes();j=json.loads(before);rows=j['consumers'];peer=D/'lsp-root-ui-geometry-peer.json';q=json.loads(peer.read_text());assert q['baseline']==B
keys=[('rust/tcl-cli/gui/explorer-core.js','wasmSourceSnippet / renderCallouts / offsetToLineCol'),('rust/tcl-cli/gui/index.html','buildOptDiffView / buildShimmerLinesView / highlightSourceRanges')];old=[]
for path,symbol in keys:
 hits=[r for r in rows if r['path']==path and r['symbol']==symbol];assert len(hits)==1;old+=hits
reads=[]
for path,ranges in {
'rust/tcl-cli/gui/explorer-core.js':[[225,260],[1304,1340],[1575,1605],[2395,2525]],
'rust/tcl-cli/gui/index.html':[[1165,1245],[1600,1850]],
'rust/tcl-spec-studio/web/src/monacoHost.ts':[[463,515],[715,765]],
'rust/tcl-explorer/src/formatters.rs':[[75,130]],
'rust/tcl-explorer/src/serialise.rs':[[20,70],[3545,3595],[3720,3768]]}.items():
 b=subprocess.check_output(['git','show',f'{B}:{path}'],cwd=R);assert b==(R/path).read_bytes();reads.append(dict(path=path,source_sha256=hashlib.sha256(b).hexdigest(),actual_targeted_read_ranges=ranges))
def site(path,symbol):
 lines=(R/path).read_text().splitlines();hits=[(i+1,s) for i,s in enumerate(lines) if s.startswith('function '+symbol+'(')];assert len(hits)==1;(line,text)=hits[0]
 return dict(symbol=symbol,line=line,source_line=text,source_sha256=hashlib.sha256((R/path).read_bytes()).hexdigest(),source_line_sha256=hashlib.sha256(text.encode()).hexdigest())
new=[]
for f in q['findings']:
 parent=next(r for r in old if r['path']==f['path']);r=copy.deepcopy(parent);r['symbol']=f['symbol'];r['site']=f['purpose'];r['purpose']=f['purpose'];r['id']=r['canonical_site_key']=f"{r['path']}::{r['symbol']}::{r['site']}";r['prior_group_id']=parent['id'];r['integration_sites']=[site(r['path'],s.strip()) for s in f['symbol'].split(' / ')];r['line']=r['integration_sites'][0]['line'];r['missing_integration']=f['missing_integration'];r['shared_api']='Existing retained range_dict(startLine/startColUtf16/endLine/endColUtf16), sourceRangeAttrs data-sl/sc/el/ec; actual current-source Monaco/JS UTF16 transport. Source/Registry/result generation currency remains separate.';r['evidence']=[{'receipt':peer.name,'receipt_sha256':hashlib.sha256(peer.read_bytes()).hexdigest(),'finding':f['evidence']}];r['repair_group']='actual-original-source-range-unit-transport';r['semantic_unit_status']='bounded_independent_peer_purpose_split; repository canonical count still unfinished';r['work_kind_reason']='Actual backend byte extents reach JS UTF16 slicing/line counters/Monaco offsets. Existing proper UTF16 fields and generated row extents retained; no missing source projection API invented.';r['reviewed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();new.append(r)
# The actual WASM renderer bypasses the correct shared attribute constructor.
# Keep this as a producer site of the same clipboard/highlight consumer purpose,
# not a seventh distinct migration count.
r=next(r for r in new if 'AI clipboard' in r['purpose']);r['integration_sites'].append(site(r['path'],'renderWasmInstruction'));r['evidence'].append({'actual_source':'renderWasmInstruction1595..1605 manually emits data-start/end from byte range only; reuse existing sourceRangeAttrs to retain proper UTF16 fields where this renderer contributes selectable items. This is a producer endpoint, not a separate resolver.'})
old_ids={r['id'] for r in old};j['consumers']=[r for r in rows if r['id'] not in old_ids]+new;assert len(j['consumers'])==329
p.write_text(json.dumps(j,indent=2)+'\n')
receipt=dict(baseline=B,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='Bounded independent six-purpose UI peer admitted with Root actual producer/endpoint reread. Two prior grouped rows split; source code unchanged. No published remaining total.',prior_primary_sha256=hashlib.sha256(before).hexdigest(),new_primary_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),peer_receipt=peer.name,peer_sha256=hashlib.sha256(peer.read_bytes()).hexdigest(),previous_rows=old,new_ids=[r['id'] for r in new],actual_targeted_rereads=reads,exact_anchor_corrections=[{'symbol':'setupOptDiffHover','peer_line':1744,'actual_declaration_line':1745}],preserved_correct_projections=q['preserved_correct_projections'],remaining_consumer_total=None,limitations=['329 provisional Root purpose rows, not remaining consumer count.','Actual field/endpoint mismatch source evidence, no JS/browser/Rust/provider tests or generator drift execution.','Common geometry repair family groups endpoints; physical sites, consumer purposes and patches remain different units.','Source/current result association is independently unfinished.'])
(D/'root-ui-peer-admission.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'old_groups':len(old),'admitted_provisional_purposes':len(new),'root_provisional_rows':len(j['consumers']),'receipt':'root-ui-peer-admission.json','sha256':hashlib.sha256((D/'root-ui-peer-admission.json').read_bytes()).hexdigest()}))
