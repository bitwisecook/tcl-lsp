from pathlib import Path
import datetime,hashlib,io,json,shutil,subprocess,tarfile,tempfile
D=Path(__file__).resolve().parent
H=Path('/workspace/tcl-lsp/docs/work/name-handling/handoff')
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');name=f'repository-audit-progress-{stamp}.tar.gz'
staged=Path(tempfile.mkdtemp(prefix='naming-audit-inputs-',dir='/tmp'))
# Freeze exactly the primary reconciliation inputs; auxiliary evidence is separately
# hash-bound in the archive, never used to certify the consumer total.
required=['baseline-files.json','consolidate.py']+[f'{who}-{kind}.json' for who in ['compiler','db','lsp','runtime','vm','root','audit'] for kind in ['file-coverage','consumers']]
for n in required:
 b=(D/n).read_bytes()
 if n.endswith('.json'):json.loads(b)
 (staged/n).write_bytes(b)
r=subprocess.run(['python3',str(staged/'consolidate.py'),str(staged)],check=True,stdout=subprocess.PIPE)
(staged/'consolidate-latest-summary.json').write_bytes(r.stdout)
c=json.loads((staged/'consolidated-in-progress.json').read_text());assert not c['binding_errors'] and not c['duplicate_site_candidates']
paths={p.name:p for p in D.iterdir() if p.is_file() and p.suffix in ('.json','.md','.py')}
paths.update({p.name:p for p in staged.iterdir()})
members=[]
with tarfile.open(H/name,'w:gz') as a:
 for n,p in sorted(paths.items()):
  b=p.read_bytes()
  if p.suffix=='.json':json.loads(b)
  members.append({'path':n,'sha256':hashlib.sha256(b).hexdigest(),'size':len(b),'primary_reconciliation_input':n in required})
  info=tarfile.TarInfo(n);info.size=len(b);a.addfile(info,io.BytesIO(b))
 b=json.dumps({'status':'INCOMPLETE; exact frozen primary inputs reconciled; auxiliaries independently hash-bound','members':members},indent=2).encode();info=tarfile.TarInfo('CHECKPOINT-MEMBERS.json');info.size=len(b);a.addfile(info,io.BytesIO(b))
with tarfile.open(H/name) as a:
 for m in members:assert hashlib.sha256(a.extractfile(m['path']).read()).hexdigest()==m['sha256']
packet={'file':name,'sha256':hashlib.sha256((H/name).read_bytes()).hexdigest(),'status':f"INCOMPLETE cc24 source audit: {len(c['consumers'])} provisional purpose rows; exact frozen primary partitions/source SHA/schema reconcile, no same-key duplicate candidates. Semantic aliases have independent reconciliation receipts but remaining work-kind/purpose/unit reconciliation and unexamined production/harness/guidance remain. Shared owners/display/metadata/exclusions included; NOT remaining-consumer total. No test/provider/generator/gate acceptance."}
p=H/'packets.json';j=json.loads(p.read_text());j.append(packet);p.write_text(json.dumps(j,indent=2)+'\n')
p=H/'SHA256SUMS';p.write_text(p.read_text()+packet['sha256']+'  '+name+'\n')
shutil.rmtree(staged)
print(json.dumps({**packet,'verified_members':len(members)}))
