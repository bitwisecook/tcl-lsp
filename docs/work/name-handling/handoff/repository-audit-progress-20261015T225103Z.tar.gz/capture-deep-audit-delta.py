from pathlib import Path
import datetime,hashlib,io,json,tarfile
D=Path('/workspace/name-session/full-consumer-audit');H=Path('/workspace/tcl-lsp/docs/work/name-handling/handoff');base=json.loads((D/'deep-artifact-capture.json').read_text());old={m['path']:m for m in base['members']};stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');name=f'repository-audit-deep-delta-{stamp}.tar.gz';changed=[];present=set();stable=0
with tarfile.open(H/name,'w:gz') as t:
 for p in sorted(D.rglob('*')):
  if not p.is_file() or p.parent==D or '__pycache__' in p.parts:continue
  rel=str(p.relative_to(D));present.add(rel);b=p.read_bytes();sha=hashlib.sha256(b).hexdigest()
  if rel in old and old[rel]['sha256']==sha:stable+=1;continue
  m=dict(path=rel,size=len(b),sha256=sha);changed.append(m);i=tarfile.TarInfo(rel);i.size=len(b);t.addfile(i,io.BytesIO(b))
 manifest=dict(baseline=base['baseline'],utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),base_archive=base['archive_name'],base_archive_sha256=base['archive_sha256'],changed_members=changed,unchanged_members=stable,deleted_members=sorted(set(old)-present),status='Exact nested source/receipt delta against retained full base; source/hash retention only, no source-review or semantic acceptance. Restore into a separate audit evidence tree; do not overwrite working implementation.')
 b=json.dumps(manifest,indent=2).encode();i=tarfile.TarInfo('DEEP-DELTA-MEMBERS.json');i.size=len(b);t.addfile(i,io.BytesIO(b))
with tarfile.open(H/name) as t:
 for m in changed:assert hashlib.sha256(t.extractfile(m['path']).read()).hexdigest()==m['sha256']
sha=hashlib.sha256((H/name).read_bytes()).hexdigest();manifest.update(archive_name=name,archive_sha256=sha,archive_bytes=(H/name).stat().st_size,verified_members=len(changed));(D/'deep-artifact-delta-capture.json').write_text(json.dumps(manifest,indent=2)+'\n');p=H/'packets.json';j=json.loads(p.read_text());j.append(dict(file=name,sha256=sha,status=f'Exact nested audit delta against {base["archive_name"]} SHA{base["archive_sha256"]}; {len(changed)} changed/new verified members,{len(manifest["deleted_members"])} deletions; source retention only, no review/execution acceptance.'));p.write_text(json.dumps(j,indent=2)+'\n');p=H/'SHA256SUMS';p.write_text(p.read_text()+sha+'  '+name+'\n');print(json.dumps({k:v for k,v in manifest.items() if k not in ['changed_members','deleted_members']}))
