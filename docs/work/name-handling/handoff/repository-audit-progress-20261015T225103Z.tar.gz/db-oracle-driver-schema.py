from pathlib import Path
import ast,json,hashlib,collections
R=Path('/workspace/name-session/full-consumer-audit');q=json.loads((R/'db-oracle-driver-review-queue.json').read_text());groups=collections.defaultdict(list)
class PathsOnly(ast.NodeTransformer):
 def visit_Constant(self,node):
  # Only original request/capture directory literal inputs are abstracted.
  # Provider versions, field keys, compile flags, assertion/error text and all
  # callable/operator/currentness structure remain byte-exact AST content.
  if isinstance(node.value,str) and (node.value.startswith('native-') or node.value.startswith('/workspace/.proofs/native-')):
   self.literals.append(dict(line=node.lineno,value=node.value));return ast.copy_location(ast.Constant(value='<original-request-directory>'),node)
  return node
for f in q['files']:
 s=(R/'db-baseline'/f['path']).read_text();tree=ast.parse(s,filename=f['path']);n=PathsOnly();n.literals=[];normal=n.visit(tree);dump=ast.dump(normal,include_attributes=False);key=hashlib.sha256(dump.encode()).hexdigest()
 groups[key].append(dict(path=f['path'],source_sha256=f['source_sha256'],blob=f['blob'],request_directory_literals=n.literals))
out=dict(baseline=q['baseline'],method='complete per-file Python AST comparison with only original native-* request/capture directory input literals abstracted; all provider versions/field keys/flags/guard/call structure preserved. Exact original source SHA/blobs and every abstracted input retained. No execution or review acceptance from grouping.',groups=[dict(schema_sha256=k,representative=v[0]['path'],members=v,status='unexamined_schema') for k,v in groups.items()]);(R/'db-oracle-driver-schemas.json').write_text(json.dumps(out,indent=2)+'\n')
print('schemas',len(groups),'files',sum(map(len,groups.values())))
for k,v in sorted(groups.items(),key=lambda z:-len(z[1]))[:12]:print(len(v),v[0]['path'])
