import json,pathlib,hashlib,subprocess,datetime,re,collections
BASE=pathlib.Path('/workspace/name-session/full-consumer-audit');REPO=pathlib.Path('/workspace/tcl-lsp')
def load():return json.loads((BASE/'audit-file-coverage.json').read_text()),json.loads((BASE/'audit-consumers.json').read_text())
def save(c,s):
 c['summary']['reviewed']=sum(r['review_status']=='reviewed' for r in c['files']);c['summary']['unexamined']=sum(r['review_status']!='reviewed' for r in c['files']);c['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();s['updated_utc']=c['updated_utc'];(BASE/'audit-file-coverage.json').write_text(json.dumps(c,indent=2)+'\n');(BASE/'audit-consumers.json').write_text(json.dumps(s,indent=2)+'\n')
def content(row):return subprocess.check_output(['git','cat-file','blob',row['blob']],cwd=REPO)
def review(c,s,path,classification,reason,entries=(),evidence=(),mode='whole_production_read',extent='Whole production file including data/type contracts; test sources read separately where stated.'):
 row=next(r for r in c['files'] if r['path']==path);data=content(row);h=hashlib.sha256(data).hexdigest();assert h==row['source_sha256'];lines=data.decode().splitlines();ids=[]
 for symbol,purpose,disposition,api,missing,tests in entries:
  text=data.decode(); method=symbol.rsplit('::',1)[-1]; line=None
  spans=[(0,len(text))]
  if '::' in symbol:
   owner=symbol.rsplit('::',1)[0]; spans=[]
   implementations=list(re.finditer(r'(?m)^impl[^\n{]*\b'+re.escape(owner)+r'(?=[\s{<])',text))
   all_impl=list(re.finditer(r'(?m)^impl\b',text))
   for im in implementations:
    stop=next((q.start() for q in all_impl if q.start()>im.start()),len(text));spans.append((im.start(),stop))
  for start,stop in spans:
   match=re.search(r'(?m)^.*\bfn '+re.escape(method)+r'(?:\(|<)',text[start:stop])
   if match:
    line=text[:start+match.start()].count('\n')+1;break
  assert line is not None,(path,symbol)
  cid='audit:'+path+':'+symbol+':'+purpose
  ids.append(cid);s['consumers']=[x for x in s['consumers'] if x['id']!=cid];s['consumers'].append({'id':cid,'path':path,'blob':row['blob'],'source_sha256':h,'symbol':symbol,'site':purpose,'line':line,'purpose':purpose,'actual_input_context':api,'shared_api':api,'missing_integration':missing,'disposition':disposition,'source_evidence':list(evidence)+[{'path':path,'extent':extent}],'related_issues':[],'relevant_original_assertions':tests,'validation_result':'Not executed on this baseline; source review only.','unexamined':'All transitive implementation not explicitly reviewed at its assigned owner.'})
 row.update(review_status='reviewed',review_mode=mode,classification=classification,reason=reason,reviewed_production_extent=extent,evidence=list(evidence),tests='Source assertions inspected where stated; no baseline execution acceptance.',consumer_ids=ids)
if __name__=='__main__':
 c,s=load();ann=[]
 for r in c['files']:
  if not r['worktree_blob_matches_baseline'] and 'worktree_source_sha256' not in r:
   before=r['source_sha256'];data=content(r);r['worktree_source_sha256']=before;r['worktree_bytes']=r['source_bytes'];r['source_sha256']=hashlib.sha256(data).hexdigest();r['source_bytes']=len(data);ann.append({'path':r['path'],'baseline_blob':r['blob'],'baseline_sha256':r['source_sha256'],'worktree_sha256':before,'reason':'Held authorized Docs3 refresh after baseline; not reviewed as baseline bytes.'})
 c['postbaseline_annex']=ann;save(c,s);print('baseline SHA correction',ann)
