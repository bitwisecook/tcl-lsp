from pathlib import Path
import collections,datetime,hashlib,json,re
D=Path(__file__).resolve().parent
p=D/'root-consumers.json';before=p.read_bytes();j=json.loads(before);rows=j['consumers']
assert len(rows)==319
# Indexes refer to this Root-owned immutable purpose roster, never another owner's rows.
# The receipt retains its complete beforeimage hash and every resulting ID.
special={
 **{n:('target_owner_extension','A shared target-key/label/literal issuance owner must retain complete input/target context; this is not a Tcl resolver.') for n in range(19,24)},
 **{n:('consumer_integration_with_metadata_extension','Actual source selection exists; a demonstrated selected semantic/operand descriptor is missing from this consumer. Extend the existing owner, then consume its issued plan.') for n in range(35,52)},
 64:('owner_api_extension_and_consumer_integration','Existing XC producer needs a supplied-input purpose preserving complete document input; standalone default remains intentional.'),
 67:('owner_api_extension_and_consumer_integration','Demonstrated Query scalar-source construction belongs to the existing DSL owner; current local escape correctness is not refuted.'),
 74:('consumer_integration','Actual emitter owns the same default kind catalogue; no intentional subset/order difference was found.'),
 90:('consumer_integration','Replace the consumer-local scalar-source construction with the existing purpose-specific shared source owner, retaining target fragment proof.'),
 96:('metadata_schema_integration','Hook family spelling is shared schema metadata; no new runtime identity resolver is needed.'),
 100:('metadata_schema_integration','Actual host context-member contract should provide the member catalogue; this is separate from dict key/value identity.'),
 **{n:('guidance_metadata_repair','Authored guidance must preserve demonstrated applicability, provider/reached phase or completeness boundaries; not a separate executable resolver.') for n in [106,112,114,116,117,127,138]},
 149:('owner_api_extension_and_consumer_integration','Mixed-source original region/config/body-role owner must replace private structural reconstruction.'),
 156:('target_owner_extension','Logical partition to native output child requires shared complete target issuance/collision policy.'),
 171:('consumer_integration_with_target_owner_extension','Use the existing model/emitter owner for actual SCF stanza field/source roles; extend only missing requirements.'),
 173:('build_inventory_repair','Incomplete native asset enumeration must not publish a complete generated roster; generated drift is independent.'),
 **{n:('consumer_metadata_transport','Return the real missing-analysis-context status already supplied by the analysis owner.') for n in [176,177,178]},
 192:('metadata_schema_repair','Tool schema advertises an already supported dialect field; no input refusal or default target loss is asserted.'),
 201:('target_owner_extension','Dockerfile, POSIX and Tcl-list phases require distinct genuine source construction, within existing package target ownership.'),
 202:('target_owner_extension','Release tag, URL and shell/Dockerfile data need target-specific construction; preserve release checksum checks.'),
 203:('consumer_integration_with_target_owner_extension','Move demonstrated extension/package source admission to its existing shared target owner; actual failure unobserved.'),
 206:('provider_schema_review','Malformed record skipping is intentional per retained test; remaining top-level/provider completeness questions do not establish a naming consumer migration.'),
 209:('target_owner_extension','Existing installer must issue a single native package child using actual name/version and complete target inventory; caller traces are separate integration sites.'),
 213:('host_inventory_repair','Retain errors from actual extracted native path inventory rather than infer a complete singleton root.'),
 217:('target_owner_extension','Fish activation source and nested Tcl-library list require separate constructors under the existing venv target owner.'),
 219:('consumer_integration','Actual TOML grammar owner should parse aliases/values; private line parser cannot preserve quoted names.'),
 226:('target_owner_extension','Issue actual endpoint/capture output identity once; punctuation sanitisation and seconds timestamp are not an injective allocation.'),
 229:('owner_api_extension_and_consumer_integration','One purpose-specific Query binding parser should retain actual NAME/PATH/header components, without inventing a strict CSV duplicate contract.'),
 244:('consumer_metadata_transport','Unavailable native canonical identities cannot compare equal as active state; this affects reporting, not destructive authority.'),
 248:('consumer_integration_with_target_owner_extension','Current restrictive package alphabet prevents demonstrated active injection; migrate the actual public probe constructor purpose.'),
 250:('shared_owner_repair_with_consumer_trace','C5 retained oracle demonstrates a shared array snapshot operand construction error; CLI route is a consumer trace, not a second owner defect.'),
 285:('validation_harness_repair','Exact original selected command identities/completion, not counts alone, must establish accepted conformance output.'),
 286:('validation_inventory_metadata_repair','Full before/after identity/cardinality and registered environment axes are proof census work; not evidence that all commands preserve behavior.'),
 293:('native_cli_schema_transport','CLI Vec<String> rejects opaque native argv; migrate native-unit ingress without inventing silent wrong-target execution.'),
 294:('native_cli_schema_transport','Separate actual filesystem Path roles from Unicode names/expression fields; current clap rejects opaque String fields.'),
 295:('guidance_metadata_repair','CLI help must describe actual embedded VM provider and bounded static event annotations.'),
 304:('validation_harness_integration','Actual harness loader paths need shared Query literal construction/native Path handling; this is not production Query resolution.'),
 305:('validation_harness_integration','Expected fixture source URI must come from actual source owner, with cross-test callers reconciled.'),
 306:('validation_harness_repair','Exact known fixture/source fields should be normalised; arbitrary same-shaped report substrings are not source identity.'),
 **{n:('validation_harness_integration','Actual setup/provider path needs its existing purpose-specific native path/source/list owner; no test semantics were observed by this source audit.') for n in [313,314,315,316]},
 **{n:('validation_review','Existing bounded assertion/provider/setup scope is retained; fresh source/provider/control acceptance remains separate.') for n in range(307,312)},
 **{n:('provider_pairing_validation','Select actual binary/library/harness pairing before accepting provider conformance; generic smoke scope is intentional.') for n in [317,318]},
}
receipt=[]
for n,r in enumerate(rows):
    old={k:r.get(k) for k in ['work_kind','work_kind_reason','canonical_site_key','semantic_unit_status']}
    if n in special:kind,reason=special[n]
    elif r['disposition']=='needs_migration':
        kind='consumer_integration';reason='Actual source-reviewed purpose retains a demonstrated local interpretation or missing owner transport described in missing_integration; owner extensions/dependencies are separately named.'
    elif r['disposition']=='migrated_validation_pending':
        kind='integration_validation_review';reason='Shared API use is source-reviewed; applicable proof/provider/regression acceptance remains unfinished. This status does not claim whole implementation completion.'
    elif r['disposition']=='shared_owner':
        kind='delegated_shared_owner';reason='Existing owner/delegating consumer purpose is retained; downstream owner migration and fresh tests are not certified by delegation.'
    elif r['disposition']=='display_only':
        kind='display_projection';reason='Inspected use is presentation without selecting a unique live target, cell, source edit or original execution authority.'
    else:
        kind='explicit_scope_exclusion';reason='Specific source-reviewed purpose excludes an independent naming migration; justification remains in the original row.'
    grouped=any(t in r['symbol'] for t in [' / ','/', ';', ','])
    r.update(work_kind=kind,work_kind_reason=reason,canonical_site_key=r['path']+'::'+r['symbol']+'::'+r['site'],semantic_unit_status='grouped_call_sites_require_atomic_reconciliation' if grouped else 'single_anchor_candidate_requires_independent_reconciliation',counts_towards_published_remaining_total=False)
    receipt.append({'id':r['id'],'previous':old,'work_kind':kind,'semantic_unit_status':r['semantic_unit_status']})
p.write_text(json.dumps(j,indent=2)+'\n')
out={'baseline':j.get('baseline'),'before_sha256':hashlib.sha256(before).hexdigest(),'after_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'reviewed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'319 purpose rows source-reviewed and work-kind classified; grouped sites and independent canonical-unit QA explicitly unfinished. No published remaining count. No original assertions/source changed.','work_kinds':dict(collections.Counter(r['work_kind'] for r in rows)),'grouped_rows':sum('grouped' in r['semantic_unit_status'] for r in rows),'remaining_consumer_total':None,'changes':receipt}
(D/'root-semantic-unit-review.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='changes'}))
