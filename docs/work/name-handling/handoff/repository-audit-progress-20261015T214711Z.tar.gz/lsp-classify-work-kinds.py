from pathlib import Path
import json,collections
r=Path('/workspace/name-session/full-consumer-audit');p=r/'lsp-consumers.json';k=json.loads(p.read_text())
# Explicit source-purpose adjudications against the already read row evidence.
metadata={84,86,88,90,92,93,94,97,212,214,215,216,565}
owner_extensions={51,102,109,123,135,139,174,188,218,221,229,243,244,246,288,290,301,308,310,312,334,469,473,481,506}
# Missing issuer/purpose has been demonstrated; its exact existing owner/API
# adaptation has not. Do not manufacture an extension or count as simple adoption.
unresolved={10,13,191,193,223,319,394,526,531,568,3,16,39,42,54,55,62,120,121,129,175,176,198,230,235,239,257,265,269,275,294,296,297,298,303,305,306,314,320,321,324,325,326,335,336,337,341,342,346,347,348,367,372,376,379,380,381,382,384,385,387,388,391,393,397,398,399,400,401,402,407,408,413,415,431,440,452,453,454,455,456,458,461,464,465,467,480,482,484,485,486,498,499,500,502,505,514,516,517,518,520,521,522,524,525,527,534,543,546,548,555,557,558,560,570,581,584,592,596,599,601,604,606}
cleanup={201,330}
validation_infrastructure={375,421,492}
for i,x in enumerate(k['consumers']):
 d=x['disposition'];detail=x['missing_integration']
 if d=='migrated_validation_pending':
  kind='validation_only';reason='This bounded source-purpose integration is already present at the recorded site; its listed owner/currentness restrictions remain. Required scoped/provider/drift/repository execution is unverified. '+detail
 elif d=='shared_owner':
  kind='shared_owner';reason='The recorded site is the existing central owner for its explicit bounded purpose, rather than another migration count. Caller adoption and any broader owner requirement are separate rows. '+detail
 elif d=='display_only':
  kind='display_only';reason='The inspected site only renders or carries the stated report/catalogue domain; no stronger naming identity/action purpose is admitted. '+detail
 elif d=='out_of_scope':
  kind='exclusion';reason='Actual inspected operational/domain exclusion, not a production filename or test-annotation exclusion. '+detail
 else:
  assert d=='needs_migration'
  if i in cleanup:kind='documentation_cleanup';reason='Actual obsolete generator/owner guidance, separate from a live naming resolver. '+detail
  elif i in metadata:kind='descriptor_metadata_target_schema';reason='The concrete remaining work is shared/generated metadata or target-language/schema projection, not substituting an evaluated name resolver. '+detail
  elif i in validation_infrastructure:kind='validation_infrastructure';reason='Actual retained control/harness/source-evidence association needs repair; not execution acceptance and not a production name resolver. '+detail
  elif i in unresolved:kind='owner_requirement_unresolved';reason='The missing authentic role/purpose/correspondence is demonstrated, but exact reuse versus extension of the shared owner remains unresolved. This row is not counted as a proved simple consumer adoption or a proved new owner API. '+detail
  elif i in owner_extensions:kind='shared_owner_extension';reason='The existing owner lacks the precise purpose/disposition/completeness projection identified by actual source review; extend that owner before stronger callers can adopt it. '+detail
  else:kind='consumer_integration';reason='The row identifies an actual caller losing/reconstructing data or purpose despite an existing shared owner/provider/host snapshot seam; migrate that transport/adoption. Any new missing API discovered during integration must be reviewed separately. '+detail
 x['work_kind']=kind;x['work_kind_reason']=reason
 x['work_kind_evidence']='Pinned source/site/context/shared_api/evidence fields in this row; purpose adjudication only, no execution or new API admission.'
k['work_kind_contract']={'status':'initial_full_610_row_purpose_classification','baseline':k.get('baseline'),'meaning':'Kinds are purpose-distinct work, not distinct patch counts. Unknown owner requirements remain explicit; shared-owner/display/exclusion rows are not remaining consumer migrations. Validation-only rows retain all execution limits.','source_review':'All actual production rows source-reviewed. Operational/inline file backlog remains unfinished independently.'}
p.write_text(json.dumps(k,indent=2)+'\n')
report={'baseline':k.get('baseline'),'rows':len(k['consumers']),'counts':dict(collections.Counter(x['work_kind'] for x in k['consumers'])),'needs_migration_counts':dict(collections.Counter(x['work_kind'] for x in k['consumers'] if x['disposition']=='needs_migration')),'unknown_is_unfinished':True,'no_execution':True,'classification_limit':'Initial purpose adjudication; owner_requirement_unresolved is explicitly not assigned to consumer or extension counts. Distinct rows can share the same eventual issuer/consumer patch; do not sum as patch count.'}
(r/'lsp-work-kind-summary.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
