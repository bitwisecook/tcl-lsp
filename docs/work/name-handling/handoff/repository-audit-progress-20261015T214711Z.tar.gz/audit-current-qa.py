import json,pathlib,hashlib,subprocess,collections,datetime,runpy,re
B=pathlib.Path('/workspace/name-session/full-consumer-audit');R=pathlib.Path('/workspace/tcl-lsp');x=runpy.run_path(str(B/'audit-review-tools.py'));c,s=x['load']();by={r['path']:r for r in c['files']};errors=[];drift=[];cache={};seen=set()
for z in s['consumers']:
 p=z['path'];r=by.get(p)
 if not r:errors.append(['foreign-path',p]);continue
 if z['id'] in seen:errors.append(['duplicate-id',z['id']])
 seen.add(z['id'])
 if z['source_sha256']!=r['source_sha256'] or z['blob']!=r['blob']:errors.append(['source-reference',z['id']])
 if p not in cache:
  d=x['content'](r);cache[p]=d
  if hashlib.sha256(d).hexdigest()!=r['source_sha256']:errors.append(['baseline-sha',p])
 if not 1<=z['line']<=len(cache[p].decode().splitlines()):errors.append(['line',z['id'],z['line']])
 if z['disposition'] not in {'needs_migration','migrated_validation_pending','migrated_verified','shared_owner','display_only','out_of_scope'}:errors.append(['disposition',z['id']])
for r in c['files']:
 if r['review_mode'].startswith('whole_'):
  d=cache.get(r['path'])
  if d is None:d=x['content'](r);cache[r['path']]=d
  if hashlib.sha256(d).hexdigest()!=r['source_sha256']:errors.append(['baseline-sha',r['path']])
  w=R/r['path']
  if not w.is_file() or hashlib.sha256(w.read_bytes()).hexdigest()!=r['source_sha256']:drift.append(r['path'])
 for cid in r['consumer_ids']:
  if cid not in seen:errors.append(['dangling-file-consumer',r['path'],cid])
q={'baseline':c['baseline'],'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':len(c['files']),'modes':dict(collections.Counter(r['review_mode'] for r in c['files'])),'purpose_rows':len(s['consumers']),'dispositions':dict(collections.Counter(r['disposition'] for r in s['consumers'])),'errors':errors,'whole_review_current_worktree_drift':drift,'scope':'Artifact consistency and exact original baseline-byte source correspondence only; no source compilation/provider/generator execution, semantic uniqueness or runtime acceptance.'};(B/'audit-artifact-qa.json').write_text(json.dumps(q,indent=2)+'\n')
known={
 **{p:('independent_inline_operational_peer_read','Root exact whole-source peer root-xtask-peer.json includes every actual inline operational test/setup/publication guard. Audit admitted exact blob/SHA/line anchors and bounded kernel challenge; no inferred purity or execution.') for p in ['rust/xtask/src/gen_editor_dialects.rs','rust/xtask/src/gen_vscode_package.rs','rust/xtask/src/gen_jetbrains.rs','rust/xtask/src/util.rs']},
 'rust/tcl-fuzz/src/engine.rs':('actual_inline_setup_read','All5 tests fixed args/labels and explicit nonexistent Path override; actual search not invoked, no external setup.'),
 'rust/tcl-fuzz/src/characterize.rs':('actual_inline_setup_read','Both synthetic Outcome relationship tests and helpers actual read; no process/provider setup.'),
 'rust/tcl-fuzz/src/version.rs':('actual_inline_setup_read','Both literal version parsing/skew tests actual read; probe/fs/process not invoked.'),
 'rust/tcl-fuzz/src/harness.rs':('actual_inline_setup_read','All11 synthetic Outcome policy tests/helpers actual read; operational launch/write helper not invoked by tests.'),
 'rust/xtask/src/catalogue_callers.rs':('actual_inline_setup_read','All4 literal snippets/map/allowlist tests actually read, no external file/provider setup invoked.'),
 'rust/xtask/src/tzdata_bundle.rs':('actual_inline_setup_read','All3 literal byte-vector/format tests actually read; actual zoneinfo build not invoked, no external file/provider setup.'),
 'rust/xtask/src/resolution_drift.rs':('actual_inline_setup_read','All5 actual literal snippet/scanner/waiver tests read, no fs/env/process setup.'),
 'rust/xtask/src/diag_tables.rs':('actual_inline_operational_setup_read','Single actual test reads3 repository generated outputs and complete central-descriptor renders through repo_root; unexecuted.'),
 'rust/xtask/src/runtime_stdlib.rs':('actual_inline_setup_read','Both synthetic manifest/digest/literal FILES tests and helpers read; no external IO invoked.'),
 'rust/xtask/src/diag_emission.rs':('actual_inline_operational_setup_read','All8 tests read; final test calls run(), actually recursively reads repository source roots. Other lexical detector tests in-memory; unexecuted.'),
 'rust/bigip-report-gen/rust/src/model.rs':('actual_inline_operational_setup_read','All10 inline tests and helpers actually read, in-memory parser/Registry/model/validator and generated version metadata; collect_model test reaches actual clock::now_epoch_seconds. No external fs/env/process/provider fixture setup or execution by audit.'),
 'rust/bigip-report-gen/rust/src/forensics.rs':('actual_inline_setup_read','All7 test bodies/helpers fully read: in-memory JSON/file text through actual Regex/record policy; no external Command/env/fs/provider setup, no execution.'),
 'rust/bigip-report-gen/rust/src/apm.rs':('actual_inline_operational_setup_read','All4 inline test bodies/helpers read; actual include_str1137-line fixture only truncated excerpt, whole fixture remains unfinished. Private parser/JSON graph setup, no external process/env/provider execution.'),
 'rust/bigip-report-gen/rust/src/security.rs':('actual_inline_operational_setup_read','All27 tests/helpers fully read; actual in-memory config/JSON plus real shared parser/crypt hashing/secret scan. No external process/env/fs mutation, no execution by audit.'),
 'rust/tcl-bigip-query/src/builtins/time_dt.rs':('actual_inline_operational_setup_read','Both tests fully read: now test reaches actual Utc::now clock; strftime test actual in-memory formatter. No environment/provider mutation or execution by audit.'),
 'rust/tcl-bigip-query/src/builtins/regex_str.rs':('actual_inline_setup_read','All3 tests and helpers fully read: actual in-memory Values/Regex/string only; no Command/env/fs/provider setup.'),
 'rust/bigip-report-gen/rust/src/certs.rs':('actual_inline_setup_read','All3 cn tests actual literal DN strings/assertions only, all bodies read; no fs/env/Command/provider/cryptographic setup.'),
 'rust/tcl-bigip-query/src/architecture.rs':('actual_inline_setup_read','Both tests use actual in-memory JSON and static authored source through shared lexer; all bodies/helpers read, no process/env/fs/provider setup.'),
 'rust/tcl-bigip/src/apl/parser.rs':('actual_inline_setup_read','Both test bodies/helpers and actual include_str20line sample read. Compile-time source fixture only; no process/env/fs/provider setup.'),
 'rust/tcl-bigip/src/apl/tokens.rs':('actual_inline_setup_read','All15 test bodies/helpers and actual include_str112line sample read; in-memory lexing/nonoverlap checks, no external process/env/fs/provider setup.'),
 'rust/tcl-bigip-query/src/builtins/f5profile.rs':('actual_inline_setup_read','All7 tests actual in-memory profile maps/values/static shared registry setup; no Command/env/fs/provider process.'),
 'rust/tcl-bigip-query/src/builtins/value2.rs':('actual_inline_setup_read','Both tests actual typed values and assertions only.'),
 'rust/tcl-bigip/src/flow/sessions.rs':('actual_inline_setup_read','All4 tests actual in-memory Flow/IndexMap construction/pairing assertions.'),
 'rust/tcl-bigip/src/flow/tshark.rs':('actual_inline_setup_read','All6 tests actual JSON/Flow maps only; external production Command worker not reached by test calls.'),
 'rust/tcl-bigip-query/src/special.rs':('actual_inline_operational_setup_read','Two tests/helpers read; deep test actually spawns std::thread Builder256MiB stack and joins worker. Unexecuted; not classified pure.'),
 'rust/bigip-report-gen/rust/src/lifecycle.rs':('actual_inline_setup_read','All3 tests actual static date/assertion data; production current clock not called.'),
 'rust/bigip-report-gen/rust/src/enrich.rs':('actual_inline_setup_read','Both tests actual in-memory JSON/network-annotation calculation.'),
 'rust/bigip-report-gen/rust/src/tls.rs':('actual_inline_operational_setup_read','Both tests read; multi-SNI test invokes actual shared parser/TLS importer/embedded trust dataset. Operational internal provider setup; no fresh execution.')}
rows=[]
for r in c['files']:
 if not r['review_mode'].startswith('whole_production') or not r['path'].endswith('.rs'):continue
 d=cache[r['path']].decode();markers=[i for i,t in enumerate(d.splitlines(),1) if '#[test]' in t or '#[tokio::test]' in t or '#[cfg(test)]' in t]
 if not markers:continue
 status,reason=known.get(r['path'],('operational_classification_unresolved','Production source review retained independently. Prior extent/test notes may record body reads, but #[test] or absence of lexical Command matches does not establish purity; actual operational setup/guards require explicit body-evidence classification.'))
 rows.append({'path':r['path'],'blob':r['blob'],'source_sha256':r['source_sha256'],'markers':markers,'marker_mode':'lexical inventory only, not test-body/operational proof','status':status,'reason':reason,'existing_review_extent':r.get('reviewed_production_extent'),'existing_test_notes':r.get('tests'),'validation':'No test executed by audit.'})
out={'baseline':c['baseline'],'created_utc':q['checked_utc'],'scope':'Inline test/harness operational review annex for fully production-read Rust paths. Explicit unresolved statuses remain unfinished; not all test functions are pure, not a count of consumers or tests executed. External test files remain their own unexamined coverage rows.','files':rows,'summary':dict(collections.Counter(z['status'] for z in rows))};(B/'audit-inline-operational-census.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'whole':q['modes'].get('whole_production_read'),'whole_peer':q['modes'].get('whole_production_peer_read'),'rows':q['purpose_rows'],'errors':len(errors),'drift':drift,'inline_operational':out['summary']}))
