from pathlib import Path
import json,hashlib,datetime,difflib,subprocess,collections
D=Path(__file__).parent;P=Path('/workspace/tcl-lsp');j=json.load(open(D/'root811-asset-role-progress.json'));rs={r['path']:r for r in json.load(open(D/'audit-root-final-source-asset-role-reservation.json'))['files']};out=j['files'];ex=[]
def pin(p,**kw):return {'path':str(p.relative_to(P)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),**kw}
for name in j['pending']:
 r=rs[name];p=P/name;b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==r['source_sha256'];x={**r,'review_status':'reviewed','review_mode':'positive_exact_asset_input_output_role','semantic_acceptance':False}
 if p.name in ['.vscode-ext-host-pid','.vscode-main-pid']:
  assert b.strip().isdigit();x.update(role='Whole numeric process-ID marker from editor screenshot host capture, consumed only as OS process/window selector.',reader=pin(P/'scripts/screenshots.sh',lines=[139,315,316,319]))
 elif p.name=='JIM-LICENSE':x.update(role='Whole manually read Jim redistribution/copyright licence retained with original provider source, no program input or resolver.',full_text=b.decode())
 elif p.suffix=='.proposed':
  q=p.parent/'implementation.patch';patch=q.read_text();target='runtime/rust/src/cmd_trace'+('/native_command_tests.rs'if p.name.startswith('native_')else '.rs');assert '+++ b/'+target in patch
  x.update(role='Historical proposed source afterimage paired to explicit target in exact retained unified patch, including actual generation/slot trace repair and regression. Current Runtime source/catalogue owns migration; no afterimage may overwrite it.',patch=pin(q),target=target,limits='Historical draft role only; no review/currentness/native-source acceptance. Full rebase and current validation required before any use.')
 elif p.name=='report.ts':
  q=P/'rust/bigip-report-gen/frontend/src/pages/report.ts';a=q.read_text().splitlines(True);c=b.decode().splitlines(True);assert a[1:]==c[1:];x.update(role='Historical documentation-only delivery beforeimage; all executable source bytes equal the separately audited current report.ts. Only first prose comment differs.',current_source=pin(q),exact_code_match_after_first_line=True,old_first_line=c[0],current_first_line=a[0])
 elif p.suffix=='.status':
  code=int(b);q=p.parent/'README.md';assert p.name in q.read_text();x.update(role='Whole decimal shell command exit-status capture, explicitly linked from original fixture README, not Tcl source. Original 0/101 values retained.',status_code=code,reader=pin(q))
 elif p.name=='list.rs.repaired':
  q=P/'runtime/rust/src/list.rs';diff=''.join(difflib.unified_diff(q.read_text().splitlines(True),b.decode().splitlines(True),fromfile=str(q.relative_to(P)),tofile=name));assert '+pub(crate) use native_list_storage::native_list_range;'in diff and '-    pub(crate) fn check_original_header('in diff
  m=p.parent/'manifest.json';rec=json.loads(m.read_bytes())['inputs']['runtime/rust/src/list.rs'];x.update(role='Historical source-repair draft for the exact list.rs manifest input, with full byte comparison to current separately audited list.rs and actual changed hunks read. Retains old test-only re-export and lacks newer original-header liveness/backing check; must not overwrite current source.',manifest=pin(m),current_source=pin(q),whole_file_diff=diff,examined_question={'kind':'retained_afterimage_provenance_mismatch','recorded_after_sha256':rec['after'],'retained_afterimage_sha256':r['source_sha256'],'disposition':'Do not accept as exact recorded compiled input or apply complete afterimage; original mismatch preserved. Not a new active code consumer.'})
 elif p.name=='sentinel':
  assert b==b'actual directory';q=P/'experiments/name-handling/results/tcllibpath-original-c5/original/run.py';t=P/'experiments/name-handling/results/tcllibpath-original-c5/original/probe.tcl';x.update(role='Exact fixed payload written by original path/list probe as physical filesystem occupancy control, checked by file isfile. Not a Tcl variable/member name or source constructor.',producer=pin(q,line=9),reader=pin(t,line=24))
 elif p.suffix=='.wasm':
  assert b[:8]==b'\0asm\1\0\0\0';pos=8;sections=[]
  def leb(i):
   v=0;s=0
   while True:
    c=b[i];i+=1;v|=(c&127)<<s
    if c<128:return v,i
    s+=7;assert s<64
  while pos<len(b):
   sid=b[pos];n,start=leb(pos+1);end=start+n;assert end<=len(b);sections.append({'id':sid,'offset':pos,'payload_bytes':n,'payload_sha256':hashlib.sha256(b[start:end]).hexdigest()});pos=end
  assert pos==len(b)
  x.update(role='Embedded generated WebAssembly query/report backend. Complete ordered section envelope and bytes checked; actual build/embed/copy owners identify generated output role. Source/backend callers are audited separately; opaque code is not treated as authoritative Rust source.',sections=sections,producer=pin(P/'rust/bigip-query-wasm/build-wasm.sh'),native_reader=pin(P/'rust/bigip-report-gen/rust/src/render.rs',line=55),copy_owner=pin(P/'rust/bigip-report-gen/frontend/build.mjs',line=82),contract=pin(P/'rust/bigip-report-gen/assets/README.md'),examined_question='Committed binary-to-source parity and reproducible regeneration remain unexecuted generated-drift/build validation, not inferred from module header or filenames.')
 elif p.suffix=='.pem':
  assert b.startswith(b'# [REDACTED CERTIFICATE MATERIAL]');x.update(role='Whole certificate-material redaction placeholder consumed as fixed test fixture bytes by X509 parser tests. Not Tcl naming grammar.',readers=[pin(P/'rust/tcl-sslictcl/tests/golden.rs',line=39),pin(P/'rust/tcl-bigip/src/tls.rs',line=1187)],examined_question='Fixture generation/readiness must follow certificate-generation.md; current X509 success is not asserted.')
 elif p.suffix=='.expected':
  x.update(role='Whole original fixed stdout golden for paired Tcl9 smoke script; generic runner reads raw bytes then compares captured stdout. Preserve original expected bytes, do not migrate/derive semantics from implementation.',raw_hex=b.hex(),paired_script=pin(p.with_suffix('.tcl')),reader=pin(P/'runtime/rust/tests/tcl9_smoke.rs',lines=[150,159,170,181,188]))
 elif p.suffix=='.ndjson':
  records=[json.loads(s)for s in b.splitlines()if s.strip()];assert all({'stem','tier','outcome','passed','skipped','failed','duration_s'}<=r.keys()for r in records);x.update(role='Complete original cached C test-suite scoreboard records. Typed reader deserializes Record and uses suite stem as report key; preserves original suite names and counts. Not command resolution.',record_count=len(records),records=records,reader=pin(P/'rust/xtask/src/tcltest_sweep.rs',lines=[180,475,489,498,499]),limits='No original binary/harness pairing, current suite execution, or comparison acceptance added.')
 else:raise ValueError(name)
 out.append(x);ex.append(x)
assert len(out)==759 and len({x['path']for x in out})==759
j.update(status='COMPLETE_EXACT_SOURCE_INPUT_OUTPUT_ROLE_REVIEW',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),files=out,reviewed_count=len(out),pending=[],count_delta=0,unexamined_sources=0,source_exception_count=len(ex),source_exceptions=ex)
(D/'root811-final-asset-roles.json').write_text(json.dumps(j,indent=2)+'\n');print(json.dumps({'reviewed':759,'pending':0,'count_delta':0,'sha256':hashlib.sha256((D/'root811-final-asset-roles.json').read_bytes()).hexdigest()}))
