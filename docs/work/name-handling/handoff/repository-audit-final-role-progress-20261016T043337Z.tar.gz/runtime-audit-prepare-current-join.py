from pathlib import Path
p=Path('/workspace/name-session/full-consumer-audit');s=(p/'runtime-audit-final-crossowner-join-build.py').read_text()
insert="""
# Successor-only final gate requires exact settled lane inputs.
import sys
assert len(sys.argv)==2, 'Pass final settled pin JSON; no implicit live-input seal'
settled_path=Path(sys.argv[1]); settled=json.loads(settled_path.read_text())
for entry in settled['settled_inputs']:
 assert H((P/entry['path']).read_bytes())==entry['sha256'], ('unsettled input',entry['path'])
historical_path=P/'runtime-audit-final-crossowner-join376.json'
assert H(historical_path.read_bytes())=='f1a44b3b2afe3a6328c5d6f19e00170c78673f07be21b12ff1a5d89cf938d75e'
historical=json.loads(historical_path.read_text())
"""
s=s.replace('files={x:read',insert+'\nfiles={x:read',1)
needle="raw=(json.dumps(out,indent=2,ensure_ascii=False)+'\\n').encode();path=P/'runtime-audit-final-crossowner-join376.json'"
replacement="""
# Retain exact actual target IDs and semantic source joins; never family-text dedup.
def joined_targets(value,found):
 if isinstance(value,dict):
  if 'id' in value and 'lane' in value and 'sites' in value:found[value['id']]=value
  for v in value.values():joined_targets(v,found)
 elif isinstance(value,list):
  for v in value:joined_targets(v,found)
old_targets={};new_targets={};joined_targets(historical,old_targets);joined_targets(out,new_targets)
assert set(old_targets)==set(new_targets), ('target IDs changed',set(old_targets)^set(new_targets))
rechecks=[]
for uid,old in old_targets.items():
 now=new_targets[uid]
 oldsites=[{k:v for k,v in x.items() if k!='actual_pinned_source_aid'} for x in old['sites']]
 newsites=[{k:v for k,v in x.items() if k!='actual_pinned_source_aid'} for x in now['sites']]
 assert oldsites==newsites, ('actual target source anchors changed',uid)
 rechecks.append({'id':uid,'lane':now['lane'],'unchanged_exact_source_anchors':True,'previous_actual_purpose_review_retained':True,'current_required_change':now['required_change']})
assert not errors,errors
for entry in settled['settled_inputs']:
 assert H((P/entry['path']).read_bytes())==entry['sha256'], ('input changed during join',entry['path'])
out['historical_join_preserved']={'path':historical_path.name,'sha256':H(historical_path.read_bytes())}
out['settled_input_notice']={'path':str(settled_path),'sha256':H(settled_path.read_bytes())}
out['unchanged_actual_target_source_rechecks']=rechecks
out['status']='FROZEN current postseal semantic owner/adopter join; immutable historical376 retained; no implementation/execution acceptance'
out['counts']['unchanged_actual_target_ids']=len(rechecks)
raw=(json.dumps(out,indent=2,ensure_ascii=False)+'\\n').encode();path=P/'runtime-audit-final-crossowner-join-current.json'
""".strip()
assert needle in s;s=s.replace(needle,replacement)
compile(s,'runtime-audit-final-crossowner-current-build.py','exec')
(p/'runtime-audit-final-crossowner-current-build.py').write_text(s)
print('Prepared parse-checked successor generator only; current JSON not written.')
