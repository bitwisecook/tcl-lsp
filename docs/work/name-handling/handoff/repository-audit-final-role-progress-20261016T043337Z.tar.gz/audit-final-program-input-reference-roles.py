import json,hashlib,datetime,re,posixpath,subprocess,collections
from pathlib import Path,PurePosixPath
D=Path('/workspace/name-session/full-consumer-audit');R=Path('/workspace/tcl-lsp');c=json.load(open(D/'audit-file-coverage.json'));by={r['path']:r for r in c['files']};q=json.load(open(D/'audit-current-residual-role-queue.json'));targets={r['path']:by[r['path']] for r in q['cohorts']['original_or_generated_program_input_role_not_yet_bound'] if by[r['path']]['review_status']!='reviewed'};H=re.compile('[a-f0-9]{64}');wanted={r['source_sha256'] for r in targets.values()};records=[];members={}
def raw(r):
 p=R/r['path'];b=p.read_bytes() if p.is_file() else b''
 if hashlib.sha256(b).hexdigest()!=r['source_sha256']:b=subprocess.check_output(['git','cat-file','blob',r['blob']],cwd=R)
 assert hashlib.sha256(b).hexdigest()==r['source_sha256'];return b
def refs(v,at=()):
 if isinstance(v,dict):
  for k,z in v.items():
   if isinstance(z,str) and H.fullmatch(z) and z in wanted and ('/' in k or '.' in k):yield at+(k,),k,z,'explicit full path key→whole SHA256'
   yield from refs(z,at+(k,))
  for pk in ['path','file','source','script','input','probe','snapshot','original','retained_path','archive_path','configuration','program']:
   p=v.get(pk)
   if isinstance(p,str):
    for hk in [pk+'_sha256','sha256','source_sha256' if pk=='source' else pk+'_hash']:
     h=v.get(hk)
     if isinstance(h,str) and H.fullmatch(h) and h in wanted:yield at+(pk,),p,h,pk+'+'+hk
 elif isinstance(v,list):
  for i,z in enumerate(v):yield from refs(z,at+(i,))
def resolve(p,r):
 xs=[]
 if p.startswith('/workspace/tcl-lsp/'):xs.append(p[len('/workspace/tcl-lsp/'):])
 if not p.startswith('/'):xs.extend([posixpath.normpath(PurePosixPath(r['path']).parent.as_posix()+'/'+p),posixpath.normpath(p)])
 return dict.fromkeys(xs)
for r in c['files']:
 if not r['path'].endswith('.json') or r['source_bytes']>40000000:continue
 b=raw(r)
 if not any(h.decode() in wanted for h in re.findall(rb'[a-f0-9]{64}',b)):continue
 try:v=json.loads(b)
 except (ValueError,UnicodeError):continue
 links=[]
 for at,p,h,kind in refs(v):
  # Only source/input/configuration/original/snapshot/artifact membership; no output/code authority inferred.
  for z in resolve(p,r):
   if z not in targets or targets[z]['source_sha256']!=h:continue
   raw(targets[z]);link={'path':z,'source_sha256':h,'recorded_path':p,'field_path':list(at),'association':kind,'role':'exact_retained_original_or_adapted_program_or_config_input_bytes'};links.append(link)
 if links:
  ix=len(records);records.append({'record':r['path'],'source_sha256':r['source_sha256'],'complete_JSON_type':type(v).__name__,'exact_input_members':links})
  for j,z in enumerate(links):members.setdefault(z['path'],(ix,j))
out={'baseline':c['baseline'],'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'producer_consumer_role':'Complete inert original measurement/source-snapshot/provenance metadata with explicit full path/source hash references. Exact input/config/probe bytes remain independent programs, not current executable implementation helpers. Actual maintained capture/retention/readers reviewed separately in runner69 and existing VM/LSP source loans.','records':records,'admitted_paths':sorted(members),'count':len(members),'limits':['All original inputs, expectations, status/provider/reached/source/currentness claims remain unchanged and unaccepted.','Exact byte membership proves recorded original/adapted input role only; no manual whole original program semantics or historical runtime import/call proved.','No basename-only, directory-only or generated-marker exemption; every admitted path has explicit record field and whole SHA equal baseline.']};p=D/'audit-final-program-input-reference-roles.json';p.write_text(json.dumps(out,indent=2)+'\n');sha=hashlib.sha256(p.read_bytes()).hexdigest()
for path,(i,j) in members.items():
 r=by[path];r.update(review_status='reviewed',review_mode='exact_explicit_record_program_input_path_and_whole_SHA_role',classification='retained_independent_original_or_adapted_measurement_program_input',reason='Explicit full path and whole input SHA in complete retained metadata record, original program/config bytes preserved independently. Not a current helper implementation or current semantic/provider acceptance.',evidence=[{'receipt':p.name,'receipt_sha256':sha,'json_pointer':f'/records/{i}/exact_input_members/{j}'}])
c.setdefault('postbaseline_annexes',[]).append({'receipt':'audit-namespace-array-snapshot-postbaseline-annex.json','sha256':'6ce0169c7b2b66a6668b4bedd765a87d0cb3cb006e4d0d66fa517e55958aa883','scope':'43 postbaseline source/input/output/failedsetup/init snapshot roles; source and opaque roles explicit; no execution acceptance.'})
c['updated_utc']=out['utc'];tmp=D/'audit-file-coverage.json.tmp';tmp.write_text(json.dumps(c,separators=(',',':'))+'\n');tmp.replace(D/'audit-file-coverage.json');print('admitted',len(members),'records',len(records),'receipt',sha)
