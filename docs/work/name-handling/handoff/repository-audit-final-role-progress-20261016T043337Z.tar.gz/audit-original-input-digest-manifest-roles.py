import json,hashlib,datetime,re,posixpath,subprocess
from pathlib import Path,PurePosixPath
D=Path('/workspace/name-session/full-consumer-audit');R=Path('/workspace/tcl-lsp');c=json.load(open(D/'audit-file-coverage.json'));by={r['path']:r for r in c['files']};q=json.load(open(D/'audit-current-residual-role-queue.json'));targets={r['path']:by[r['path']] for r in q['cohorts']['original_or_generated_program_input_role_not_yet_bound'] if by[r['path']]['review_status']!='reviewed'};records=[];hits={}
def raw(r):
 p=R/r['path'];b=p.read_bytes() if p.is_file() else b''
 if hashlib.sha256(b).hexdigest()!=r['source_sha256']:b=subprocess.check_output(['git','cat-file','blob',r['blob']],cwd=R)
 assert hashlib.sha256(b).hexdigest()==r['source_sha256'];return b
for r in c['files']:
 if not any(x in PurePosixPath(r['path']).name.lower() for x in ['sha256','sha256sum','checksums']) or r['source_bytes']>15000000:continue
 try:lines=raw(r).decode().splitlines()
 except UnicodeError:continue
 links=[];other=[];parsed=0
 for ln,line in enumerate(lines,1):
  if not line.strip():continue
  m=re.fullmatch(r'([a-f0-9]{64}) [ *](.+)',line)
  if not m:other.append(ln);continue
  parsed+=1;h,p=m.groups();ps=[posixpath.normpath(PurePosixPath(r['path']).parent.as_posix()+'/'+p),posixpath.normpath(p)]
  if p.startswith('/workspace/tcl-lsp/'):ps.append(p[len('/workspace/tcl-lsp/'):])
  for z in dict.fromkeys(ps):
   if z in targets and targets[z]['source_sha256']==h:raw(targets[z]);links.append({'path':z,'source_sha256':h,'manifest_line':ln,'recorded_path':p,'role':'exact_retained_independent_original_or_measurement_input_member'})
 if links:
  ix=len(records);records.append({'manifest':r['path'],'manifest_source_sha256':r['source_sha256'],'strict_digest_lines':parsed,'non_digest_lines_explicit':other,'input_members':links})
  for j,z in enumerate(links):hits.setdefault(z['path'],(ix,j))
out={'baseline':c['baseline'],'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'records':records,'admitted_paths':sorted(hits),'count':len(hits),'positive_role':'Explicit digest manifest source member path resolves exact baseline original Tcl/test/driver/config/license input bytes. No fuzzy basename or prefix-only exemption; retained original APIs/program expectations remain independent.','limits':['Only input member roles admitted; non-digest manifest lines remain explicit unclassified text, no whole manifest schema or original provenance parity assertion.','No measured source/current caller/import/SDK/provider/library/runtime/conformance acceptance.','Actual maintained producer/admission helpers remain separate full-source review; original fixed interpreter/test-driver/source programs are not centralised into implementation APIs.']};p=D/'audit-original-input-digest-manifest-roles.json';p.write_text(json.dumps(out,indent=2)+'\n');h=hashlib.sha256(p.read_bytes()).hexdigest()
for path,(i,j) in hits.items():by[path].update(review_status='reviewed',review_mode='exact_digest_manifest_original_input_member_role',classification='retained_independent_original_measurement_or_provider_program_input',reason='Exact retained digest manifest full path and whole SHA match; original interpreter/test/probe input role retained without executing or changing original APIs/expected answers.',evidence=[{'receipt':p.name,'receipt_sha256':h,'json_pointer':f'/records/{i}/input_members/{j}'}])
t=D/'audit-file-coverage.json.tmp';t.write_text(json.dumps(c,separators=(',',':'))+'\n');t.replace(D/'audit-file-coverage.json');print(len(hits),h)
