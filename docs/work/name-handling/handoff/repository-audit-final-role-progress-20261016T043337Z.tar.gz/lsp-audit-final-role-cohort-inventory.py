from pathlib import Path
import json,hashlib,collections,csv,tomllib,os
R=Path(__file__).parent;P=Path('/workspace/tcl-lsp');H=lambda b:hashlib.sha256(b).hexdigest();res=json.loads((R/'audit-lsp-final-role-cohort-reservation.json').read_bytes());rows=[];groups={};errors=[]
def no_dupes(pairs):
 d={}
 for k,v in pairs:
  if k in d:raise ValueError('duplicate key '+k)
  d[k]=v
 return d
for x in res['files']:
 p=P/x['path']
 if not p.exists():errors.append({'path':x['path'],'error':'current_file_missing'});continue
 b=p.read_bytes()
 if H(b)!=x['source_sha256']:errors.append({'path':x['path'],'error':'current_sha_mismatch','actual_sha256':H(b)});continue
 try:
  if p.suffix=='.json':v=json.loads(b,object_pairs_hook=no_dupes);kind='json'
  elif p.suffix=='.jsonl':v=[json.loads(l,object_pairs_hook=no_dupes) for l in b.splitlines() if l.strip()];kind='jsonl'
  elif p.suffix=='.toml':v=tomllib.loads(b.decode());kind='toml'
  else:v=None;kind=p.suffix
  leaves=collections.Counter();shapes=collections.Counter();string_fields=collections.defaultdict(list)
  def walk(v,path=''):
   leaves[type(v).__name__]+=1
   if isinstance(v,dict):
    shapes[tuple(sorted(v))]+=1
    for k,q in v.items():walk(q,path+'/'+k)
   elif isinstance(v,list):
    for q in v:walk(q,path+'/*')
   elif isinstance(v,str):
    if len(string_fields[path])<2:string_fields[path].append(v[:160])
  if v is not None:walk(v)
  top=(sorted(v) if isinstance(v,dict) else sorted({k for z in v if isinstance(z,dict) for k in z}) if isinstance(v,list) else [])
  key=kind+'|'+','.join(top);g=groups.setdefault(key,{'kind':kind,'top_keys':top,'paths':[],'top_value_types':{},'container_shapes':{},'string_field_samples':{}});g['paths'].append(x['path'])
  if len(g['paths'])==1:
   g['top_value_types']={k:type(q).__name__ for k,q in v.items()} if isinstance(v,dict) else {};g['container_shapes']={','.join(k):n for k,n in shapes.items()};g['string_field_samples']=dict(string_fields)
  rows.append({**x,'actual_source':str(p),'parse_kind':kind,'top_shape':top,'value_type_counts':dict(leaves),'whole_shape_count':sum(shapes.values()),'status':'parsed_source_schema_inventory_not_role_admitted'})
 except Exception as e:errors.append({'path':x['path'],'error':repr(e)})
out={'baseline':res['baseline'],'reservation_sha256':H((R/'audit-lsp-final-role-cohort-reservation.json').read_bytes()),'rows':rows,'groups':groups,'errors':errors,'limits':'Inventory only, not admitted role or meaning; actual grouping/schema/producer contract review still required.'};q=R/'lsp-audit-final-role-cohort-inventory.json';q.write_text(json.dumps(out,separators=(',',':'))+'\n');print('rows',len(rows),'groups',len(groups),'errors',len(errors));print(json.dumps(errors)[:5000]);print('bytes',sum(x['source_bytes'] for x in rows));print(H(q.read_bytes()))
