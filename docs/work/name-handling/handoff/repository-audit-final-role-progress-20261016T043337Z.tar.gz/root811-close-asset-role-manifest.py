from pathlib import Path
import json,hashlib,subprocess,re,datetime,collections,tomllib
D=Path(__file__).parent;P=Path('/workspace/tcl-lsp');g=json.load(open(D/'root811-role-groups.json'));cand={r['path']:r for r in json.load(open(D/'root811-positive-role-candidates.json'))['files']};inline={r['path']:r for r in json.load(open(D/'root811-channel-inline-roles.json'))['files']};media={r['path']:r for r in json.load(open(D/'root811-media-decoded-roles.json'))['files']};xz={r['path']:r for r in json.load(open(D/'root811-xz-retained-stream-roles.json'))['files']};out=[];pending=[]
def pin(p):return {'path':str(p.relative_to(P)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def source(r):
 b=(P/r['path']).read_bytes()
 if hashlib.sha256(b).hexdigest()!=r['source_sha256']:b=subprocess.check_output(['git','cat-file','blob',r['blob']],cwd=P)
 assert hashlib.sha256(b).hexdigest()==r['source_sha256'];return b
def lines(p,term):
 return [{**pin(p),'line':i,'source_line':s}for i,s in enumerate(p.read_text().splitlines(),1)if term in s]
for kind,rows in g.items():
 for r in rows:
  p=P/r['path'];b=source(r);x={**r,'review_status':'reviewed','review_mode':'positive_exact_asset_input_output_role','role_group':kind,'semantic_acceptance':False};z=cand[r['path']];strictrefs=[]
  for ref in z['positive_reference_candidates']:
   ms=[m for m in ref['matches']if m['value']==r['source_sha256']]
   if ms:strictrefs.append({**ref,'matches':ms})
  if kind=='ignore_config':x.update(role='Actual complete Git ignore patterns read as Git path-selection configuration, not Tcl command lookup.',lines=b.decode().splitlines(),reader='Git ignore pattern evaluator; preserved finite path globs only.')
  elif kind=='media':x.update(role=media[r['path']]['role'],decoded_record=media[r['path']],reader='Documentation/editor screenshot image rendering; parsed complete image/XML payload without source-evaluator execution elements.')
  elif kind=='traffic_sentinel':
   assert b==b'';inv=p.parent/'invocation.sh';a=[]
   if inv.exists():a+=lines(inv,'traffic-ready')
   for pa in list(p.parents)[1:4]:
    for n in ['capture.py','runner.py']:
     q=pa/n
     if q.exists():a+=lines(q,p.name)
    if a:break
   if not a:pending.append(r['path']);continue
   x.update(role='Zero-byte external traffic coordination filesystem event, created/observed by retained exact invocation/capture source; no interpreter name evaluation and no proof of reached TMM event.',producer_reader_anchors=a)
  elif kind=='checksums':
   entries=[]
   for s in b.decode().splitlines():
    if not s.strip()or s.startswith('#'):continue
    m=re.match(r'^([0-9a-fA-F]{64})\s+\*?(.*)$',s)
    if not m:raise ValueError((r['path'],s))
    entries.append({'sha256':m[1].lower(),'member':m[2]})
   x.update(role='Fully parsed exact digest/member lookup table used by retained artifact validation. Entries describe bytes and paths; not a Tcl namespace/command resolver.',entries=entries,reader_contract=pin(P/'experiments/name-handling/results/tcllibpath-original-c5/verify.py'),limits='No blanket seal acceptance; provider setup, listed-member availability, changed current tracking indexes and current source acceptance remain separately checked.')
  elif kind=='process_channels':
   channel='stdout'if 'stdout'in p.name else 'stderr';ir=inline.get(r['path'],{}).get('inline_channel_record_matches',[])
   if strictrefs:x.update(role='Exact retained process output bytes bound by channel SHA field in a structurally parsed original capture/result record.',record_references=strictrefs)
   elif ir:x.update(role='Exact retained process output bytes equal the original typed channel field in a fully parsed capture/result record.',record_references=ir)
   elif 'tcltest-original-program-explicit-libraries-20261014'in r['path']:
    version=p.parent.name;old=P/'experiments/name-handling/oracles/tcltest-original-program-20261014'/version/channel;assert old.read_bytes()==b
    q=p.parents[1]/'result.json';recs=json.loads(q.read_bytes());rec=next(a for a in recs if a['release']==version);assert rec['same_original_stdout']is True
    x.update(role='Retained explicit-library process channel, equal byte-for-byte to the separately retained original-version channel; original result records same_original_stdout and full command/library inputs.',record_reference={**pin(q),'record':rec},exact_original_channel=pin(old),limits='Byte equality closes data role; original harness pairing and result acceptance are not rerun.')
   elif 'event-availability/http-request-'in r['path']:
    q=p.parent/'initial-fetch.json';rec=json.loads(q.read_bytes());h=p.parent/'HTTP_REQUEST.html';assert hashlib.sha256(h.read_bytes()).hexdigest()==rec['sha256']
    if channel=='stdout':s=json.loads(b);assert s['artifact_sha256']==rec['sha256']and s['bytes']==rec['bytes']and s['status']==rec['status']
    else:assert b==b''
    x.update(role='Fetch driver reporting channel for retained official documentation HTTP response, exact artifact digest/status/size joined to initial-fetch record; not appliance execution.',record_reference={**pin(q),'record':rec})
   elif 'preliminary-c86'in r['path']:
    q=p.parent/'input.tcl';assert b.startswith(b'PATCHLEVEL 8.6.18\n');x.update(role='Whole manually read preliminary trace output from matching retained complete114-line original Tcl probe. Output ends inside destination-replace; no completion/exit/provider provenance acceptance.',input=pin(q),producer_lines=[1,6,9,12,15,73,81,102],examined_question='Original preliminary runner/exit/library pairing is not retained; do not use this output as accepted oracle evidence.')
   else:pending.append(r['path']);continue
  elif kind=='multipart':
   if strictrefs:x.update(role='Exact binary member of ordered retained archive/log serialization; manifest binds member digest, original stream and explicit archived validation/proof role.',record_references=strictrefs)
   else:pending.append(r['path']);continue
  elif r['path']in xz:x.update(role=xz[r['path']]['role'],decoded_record=xz[r['path']])
  elif strictrefs:
   role='Retained historical source/build-input beforeimage or proposed afterimage, identified by explicit full input/source/executable/source-excerpt/digest field; not a current maintained implementation.'
   if p.suffix in ['.lock']:tomllib.loads(b.decode());role='Full parsed historical Cargo dependency lock input before/after image; exact receipt before/after hashes preserve build provenance, not name resolution.'
   elif p.suffix=='.d':role='Retained rustc dep-info build output; exact capture manifest SHA binds dependency-path report, not a language naming consumer.'
   elif p.suffix in ['.elf']or p.name in ['observer','probe']:role='Retained compiled original-provider probe artifact, joined to exact recorded executable hash and build/run argv. No binary execution or source/provider acceptance.'
   elif p.suffix=='.nul':role='NUL-separated test selector stdout capture joined to exact artifact digest; labels are harness identities, not Tcl command lookup.'
   elif p.name=='HTTP_REQUEST.html':role='Retained official HTTP documentation response body; exact initial fetch byte count/digest, a documentation input without appliance execution acceptance.'
   x.update(role=role,record_references=strictrefs)
  else:
   pending.append(r['path']);continue
  out.append(x)
o={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_reservation_sha256':'4fc982d65e4570a65ec4ab6461e8af9f3eaa19f55d758c75396c5ad8cc1d438a','status':'IN_PROGRESS_EXPLICIT_POSITIVE_ROLE_JOINS','files':out,'reviewed_count':len(out),'pending':pending,'count_delta':0,'limits':'Roles are source/input/output ownership dispositions, not original semantics, currentness, Native availability, generated parity, test/Oracle acceptance or readiness. Beforeimages must be rebased individually; original bytes retained.'};(D/'root811-asset-role-progress.json').write_text(json.dumps(o,indent=2)+'\n');print(json.dumps({'reviewed':len(out),'pending':pending},indent=2))
