from pathlib import Path
import json,hashlib,collections,re,subprocess
D=Path(__file__).parent;P=Path('/workspace/tcl-lsp');g=json.load(open(D/'root811-role-groups.json'));rows=sum(g.values(),[]);cache={};out=[]
def parse(p):
 if str(p)not in cache:
  try:cache[str(p)]=(hashlib.sha256(p.read_bytes()).hexdigest(),json.loads(p.read_bytes()))
  except Exception:cache[str(p)]=None
 return cache[str(p)]
def walk(o,k=''):
 if isinstance(o,dict):
  for a,b in o.items():yield from walk(b,k+'/'+a)
 elif isinstance(o,list):
  for i,b in enumerate(o):yield from walk(b,k+'/'+str(i))
 elif isinstance(o,str):yield k,o
for typ,rs in g.items():
 for r in rs:
  p=P/r['path'];b=p.read_bytes()
  if hashlib.sha256(b).hexdigest()!=r['source_sha256']:b=subprocess.check_output(['git','cat-file','blob',r['blob']],cwd=P)
  assert hashlib.sha256(b).hexdigest()==r['source_sha256'],r['path'];refs=[]
  for pa in list(p.parents)[:7]:
   if pa in [P,P/'experiments',P/'experiments/name-handling',P/'experiments/name-handling/results',P/'docs',P/'docs/design']:break
   for c in pa.glob('*.json'):
    v=parse(c)
    if v:
     matches=[{'field':k,'value':val}for k,val in walk(v[1])if val==r['source_sha256']or val==r['path']or (len(val)>12 and val.endswith('/'+p.name))]
     if matches:refs.append({'path':str(c.relative_to(P)),'sha256':v[0],'matches':matches[:15]})
  out.append({**r,'role_group':typ,'positive_reference_candidates':refs})
(D/'root811-positive-role-candidates.json').write_text(json.dumps({'files':out,'limit':'Reference candidates only; source hash integrity is not semantic audit or role acceptance.'},indent=2)+'\n')
for typ in g:
 a=[r for r in out if r['role_group']==typ];print(typ,len(a),'withrefs',sum(bool(r['positive_reference_candidates'])for r in a))
print('unmatched other')
for r in out:
 if r['role_group']=='other'and not r['positive_reference_candidates']:print(r['path'])
