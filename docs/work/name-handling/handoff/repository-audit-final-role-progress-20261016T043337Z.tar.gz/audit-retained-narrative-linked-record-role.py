import json,hashlib,datetime,re,posixpath,subprocess,collections
from pathlib import Path,PurePosixPath
D=Path('/workspace/name-session/full-consumer-audit');R=Path('/workspace/tcl-lsp');c=json.load(open(D/'audit-file-coverage.json'));by={r['path']:r for r in c['files']};q=json.load(open(D/'audit-current-residual-role-queue.json'));targets={f['path']:by[f['path']] for f in q['cohorts']['authored_or_historical_record_text_role_not_yet_bound'] if by[f['path']]['review_status']!='reviewed'};records=[];hits={};jcache={}
def raw(r):
 p=R/r['path'];b=p.read_bytes() if p.is_file() else b''
 if hashlib.sha256(b).hexdigest()!=r['source_sha256']:b=subprocess.check_output(['git','cat-file','blob',r['blob']],cwd=R)
 assert hashlib.sha256(b).hexdigest()==r['source_sha256'];return b
def resolve(p,r):
 if not isinstance(p,str) or any(x in p for x in ['\0','\n']):return []
 p=p.split('#',1)[0]
 if not p:return []
 xs=[]
 if p.startswith('/workspace/tcl-lsp/'):xs.append(p[len('/workspace/tcl-lsp/'):])
 elif not p.startswith('/') and '://' not in p:xs.extend([posixpath.normpath(PurePosixPath(r['path']).parent.as_posix()+'/'+p),posixpath.normpath(p)])
 return [by[x] for x in dict.fromkeys(xs) if x in by]
fields={'records','runs','provider','providers','source_sha256','source_sha256_before','selector','argv','command','cmd','exit_code','captures','capture','results','artifacts','binary_sha256','input_sha256','retention','entries','files','source_snapshot','counts','status','tests','questions'}
for r in targets.values():
 if not r['path'].endswith('.md'):continue
 b=raw(r);text=b.decode();lines=text.splitlines();heads=[{'line':i,'text':l} for i,l in enumerate(lines,1) if re.match(r'^#{1,6} ',l)];links=[]
 for m in list(re.finditer(r'\[[^\]\n]*\]\(([^)\n]+)\)',text))+list(re.finditer(r'`([^`\n]+)`',text)):
  p=m.group(1).strip()
  for z in resolve(p,r):
   if not z['path'].endswith('.json') or z['source_bytes']>15000000:continue
   if z['path'] not in jcache:
    try:jcache[z['path']]=json.loads(raw(z))
    except (ValueError,UnicodeError):jcache[z['path']]=None
   v=jcache[z['path']];ks=set(v) if isinstance(v,dict) else set().union(*(set(x) for x in v if isinstance(x,dict))) if isinstance(v,list) else set()
   if not (ks&fields):continue
   links.append({'record_path':z['path'],'source_sha256':z['source_sha256'],'referenced_spelling':p,'narrative_byte_offset':len(text[:m.start()].encode()),'record_root_type':type(v).__name__,'all_record_top_keys':sorted(ks),'recognized_record_fields':sorted(ks&fields)})
 if not heads or not links:continue
 # Account complete document structure without claiming manual prose, command or expected-answer correctness.
 fence=[];active=None;classes=collections.Counter()
 for i,line in enumerate(lines,1):
  fm=re.match(r'^\s*(```+|~~~+)(.*)$',line)
  if fm:
   if active is None:active=(i,fm.group(1)[0],fm.group(2).strip())
   elif fm.group(1)[0]==active[1]:fence.append({'start':active[0],'end':i,'language':active[2],'source_sha256':hashlib.sha256(('\n'.join(lines[active[0]-1:i])).encode()).hexdigest()});active=None
  classes['inert_code_fence_line' if active else 'narrative_or_structure_line']+=1
 if active:fence.append({'start':active[0],'end':len(lines),'language':active[2],'unclosed':True})
 ix=len(records);records.append({'path':r['path'],'source_sha256':r['source_sha256'],'complete_bytes':len(b),'whole_lines':len(lines),'section_headers':heads,'all_code_fence_extents':fence,'complete_line_class_counts':dict(classes),'explicit_record_links':links,'role':'Retained source/capture/validation record attachment narrative with actual exact linked typed records; source snippets/replay recipes inert historical descriptions, claims not accepted.'});hits[r['path']]=ix
out={'baseline':c['baseline'],'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'records':records,'admitted_paths':sorted(hits),'count':len(hits),'positive_reader_role':'Exact source/capture/result typed metadata records explicitly linked from retained narrative; every document byte sourceSHA and complete header/fence/line structure accounted. Linked records are parsed inert data, not verified provider or outcome. Existing actual capture/retention/proof source readers reviewed separately.','limits':['Not whole manual authored guidance/API correctness read. Active304 API guides were independently whole read; this cohort is retained record attachment text, not implementation/code/helper admission.','No original expected-answer/replay source command execution; code fences remain inert records. Current source/ELF/provider/reached/conformance/proof gate acceptance remains unverified.','Links establish record-attachment role, not truth of prose/generation or arbitrary current-maintained liveness. No prefix/marker-only admission.']};p=D/'audit-retained-narrative-linked-record-role.json';p.write_text(json.dumps(out,indent=2)+'\n');h=hashlib.sha256(p.read_bytes()).hexdigest()
for path,i in hits.items():by[path].update(review_status='reviewed',review_mode='complete_Markdown_structure_and_explicit_typed_record_attachment_role',classification='retained_capture_source_validation_record_narrative_data',reason='Complete document structure and explicit exact linked stored process/provenance records establish retained measurement narrative role. Prose/result/generation/replay acceptance unverified; current API guides and executable helpers remain separately reviewed.',evidence=[{'receipt':p.name,'receipt_sha256':h,'json_pointer':f'/records/{i}'}])
t=D/'audit-file-coverage.json.tmp';t.write_text(json.dumps(c,separators=(',',':'))+'\n');t.replace(D/'audit-file-coverage.json');print(len(hits),h)
