from pathlib import Path
import json,re,hashlib,os
D=Path(__file__).parent;H=lambda b:hashlib.sha256(b).hexdigest();load=lambda n:json.loads((D/n).read_bytes())
m=load('compiler-root-operational-role-matcher-packet03.json');progress=load('lsp-audit-compiler-operational-packet03-progress.json');helpers={};pins=m['helper_receipts']+[{'path':'compiler-helper04-source-review.json','sha256':'040beec3d8f77e1b229c0857ee62790ba19d354a16e1459cd3d30535d65b594a'}]
def scan(v,pin):
 if isinstance(v,dict):
  if all(k in v for k in ('path','source_sha256','start_byte','end_byte','full_item_sha256')):helpers[(v['path'],v['source_sha256'],v['start_byte'],v['end_byte'])]=(v,pin)
  for x in v.values():scan(x,pin)
 elif isinstance(v,list):
  for x in v:scan(x,pin)
for pin in pins:
 b=(D/pin['path']).read_bytes();assert H(b)==pin['sha256'];scan(json.loads(b),pin)
aid=(D/m['aid']).read_bytes();assert H(aid)==m['aid_sha256'];visible={};path=None
for l in aid.decode().splitlines():
 if l.startswith('ACTUAL SOURCE '):path=l.split()[2];visible[path]={}
 elif re.match(r'^\d+:',l):n,s=l.split(':',1);assert int(n) not in visible[path];visible[path][int(n)]=s.strip()
rows=[];gaps=[];mismatches=[]
for f in m['files']:
 b=Path(f['source']).read_bytes();assert H(b)==f['source_sha256'];lines=b.splitlines(keepends=True);off=[0]
 for l in lines:off.append(off[-1]+len(l))
 hs=[(a,z,v,pin) for (p,h,a,z),(v,pin) in helpers.items() if p==f['path'] and h==H(b)]
 for a,z,v,pin in hs:assert H(b[a:z])==v['full_item_sha256']
 ls=[x for x in progress['literal_roles'] if x['path']==f['path']]
 for x in ls:assert H(b[x['start_byte']:x['end_byte']])==x['literal_sha256']
 hidden=[(a,z) for a,z,_,_ in hs]+[(x['start_byte'],x['end_byte']) for x in ls]
 missing=[]
 for first,last in f['ranges']:
  for n in range(first,last+1):
   a,z=off[n-1],off[n];rest=bytes(c for i,c in enumerate(b[a:z],a) if not any(x<=i<y for x,y in hidden))
   if rest.strip() and n not in visible[f['path']]:gaps.append({'path':f['path'],'line':n,'start_byte':a,'end_byte':z,'raw':b[a:z].decode().rstrip(),'unaccounted':rest.decode().rstrip()});missing.append(n)
   if n in visible[f['path']]:
    masked=bytearray(b[a:z])
    for i in range(a,z):
     if any(x<=i<y for x,y in hidden) and masked[i-a]!=10:masked[i-a]=32
    for x in ls:
     if a<=x['start_byte']<z:
      k=x['start_byte']-a;label=('L'+str(x['ordinal'])).encode();masked[k:k+len(label)]=label
    if masked.decode().strip()!=visible[f['path']][n]:mismatches.append({'path':f['path'],'line':n,'source_masked':masked.decode().strip(),'aid':visible[f['path']][n]})
 rows.append({'path':f['path'],'source_sha256':H(b),'scope_ranges':f['ranges'],'visible_lines':len(visible[f['path']]),'exact_prior_helpers':len(hs),'literal_count':len(ls),'missing_original_lines':missing})
out={'baseline':m['baseline'],'reservation_sha256':H((D/'compiler-root-operational-role-matcher-packet03.json').read_bytes()),'algorithm':'Independent byte subtraction of exact actually reviewed helper/literal intervals, then check every original scoped nonblank remainder has matching numbered visible aid line; compare every visible line to its original bytes with ONLY those exact intervals masked and placeholder inserted. Whitespace-only remainder admitted as formatting. No projection builder imported or executed.','rows':rows,'missing_raw_lines':gaps,'mismatches':mismatches,'target_execution':False}
p=D/'lsp-audit-compiler-operational-packet03-integrity.json';p.write_text(json.dumps(out,separators=(',',':'))+'\n');print('paths',len(rows),'missing',len(gaps),'mismatches',len(mismatches),'sha',H(p.read_bytes()));print(json.dumps(gaps)[:15000]);print(json.dumps(mismatches)[:3000])
