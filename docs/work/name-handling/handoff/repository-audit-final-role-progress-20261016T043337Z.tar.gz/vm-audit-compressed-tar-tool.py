from pathlib import Path
import json,tarfile,hashlib,os
r=Path('/workspace/name-session/full-consumer-audit');d=json.loads((r/'vm-audit-compressed-role-stream-inventory.json').read_text());out=[]
for x in d['rows']:
 if not x['path'].endswith('.tar.gz'):continue
 members=[]
 with tarfile.open(x['local_path'],'r|gz') as t:
  for m in t:
   row={'name':m.name,'type':m.type.decode('ascii','backslashreplace'),'bytes':m.size,'linkname':m.linkname}
   if m.isfile():
    h=hashlib.sha256();f=t.extractfile(m)
    while b:=f.read(1048576):h.update(b)
    row['sha256']=h.hexdigest()
   members.append(row)
 out.append({'path':x['path'],'source_sha256':x['source_sha256'],'whole_decoded_sha256':x['whole_decoded_sha256'],'members':members,'nonregular_nondirectory_members':[m for m in members if m['type'] not in ['0','\0','5']]});print(x['path'],len(members),flush=True)
p=r/'vm-audit-compressed-tar-member-inventory.json';tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps({'status':'member/schema role inventory only; no extraction/execution','archives':out,'limits':['All archive file members streamed and hashed. Contents are not manually source reviewed or accepted as current source/provider.']},indent=2)+'\n');os.replace(tmp,p);print(hashlib.sha256(p.read_bytes()).hexdigest())
