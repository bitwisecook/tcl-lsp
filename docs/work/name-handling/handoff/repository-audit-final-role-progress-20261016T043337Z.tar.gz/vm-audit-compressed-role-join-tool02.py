from pathlib import Path
import json,gzip,hashlib,re,os,collections,datetime
r=Path('/workspace/name-session/full-consumer-audit');repo=Path('/workspace/tcl-lsp');d=json.loads((r/'vm-audit-compressed-role-joins-progress.json').read_text());rows={x['path']:x for x in d['rows']};meta={};schemas=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def doc(p):
 raw=p.read_bytes();v=json.loads(gzip.decompress(raw) if p.suffix=='.gz' else raw);meta[str(p.relative_to(repo))]={'sha256':sha(raw),'bytes':len(raw),'read_mode':'complete structural role schema/member projection; no semantic source/provider acceptance'};return v
def h(x):return isinstance(x,str) and re.fullmatch('[0-9a-f]{64}',x) is not None
def fmap(v):return isinstance(v,dict) and all(isinstance(k,str) and h(a) for k,a in v.items())
def admit(p,role,basis,questions=None):
 x=rows[p];x['role_state']='positive_role_proven';x['role']=role;x['role_basis']=basis;x['examined_provenance_or_context_questions']=questions or [{'question':'Retained recorded role only; original producer run/source/provider/build/parity assertions are not accepted.'}]
# Exact original-source manifest fields retain independent original APIs/corpus; no calls replaced.
for n in ['logical-source-seed-20261014','runtime-visibility-slot-20261014','vm-expose-slot-20261014']:
 root=repo/'experiments/name-handling/results'/n/'oracles';mp=doc(root/'original-source-manifest.json')
 for m in mp:
  p=str((root/m['retained_path']).relative_to(repo))
  if p in rows:
   x=rows[p];assert x['source_sha256']==m['gzip_sha256'];assert x['whole_decoded_sha256']==m['sha256']
   admit(p,'retained_original_provider_source_or_license_input',{'manifest':str((root/'original-source-manifest.json').relative_to(repo)),'exact_member_record':m,'contract':'exact explicit retained_path+container SHA+full original source_path+decoded SHA; provider source/license storage role, not producer API migration'})
# Explicit full provider source root + per-file digest binds recorded original test/library/license inputs.
for stamp in ['20261012T192755Z','20261012T193042Z','20261012T193343Z']:
 root=repo/'experiments/name-handling/results/runtime-c86-real-suites'/stamp;v=doc(root/'provenance.json');mp=v['source_sha256'];assert fmap(mp);prefix=str(root.relative_to(repo))+'/originals/'
 for p,x in rows.items():
  if p.startswith(prefix):
   orig=v['source_root']+'/'+p[len(prefix):-3];assert mp.get(orig)==x['whole_decoded_sha256']
   admit(p,'retained_recorded_original_suite_library_test_or_license_input',{'provenance':str((root/'provenance.json').relative_to(repo)),'source_field':'source_sha256','actual_full_original_source_path':orig,'exact_source_digest':mp[orig],'recorded_capture_sha256':v['capture_sha256'],'contract':'every complete decoded input equals explicit recorded original full path digest; interpreter source APIs remain independent'})
# Complete recognized data schemas for compressed records; no bool acceptance claim promoted.
for p,x in list(rows.items()):
 if not p.endswith('.json.gz'):continue
 v=doc(repo/p);basis={'complete_top_level_keys':list(v),'json_root':'object','whole_decoded_sha256':x['whole_decoded_sha256']};role=None
 if isinstance(v.get('source'),dict) and fmap(v['source']) and set(v)<=set(['source','head','compile_source_root','immutable_source_archive','rule','byte_identical_immutable_reference','reference_reused_leaf_count']):
  role='recorded_nested_source_digest_snapshot';basis.update(source_field='source',source_members=len(v['source']),context_fields={k:a for k,a in v.items() if k!='source'})
 elif 'source'in v and fmap(v['source']) and set(v)==set(['label','command','exit','seconds','source','uniform_source','summaries','log_sha256']):
  assert isinstance(v['command'],list) and all(isinstance(a,str) for a in v['command']) and isinstance(v['exit'],int) and h(v['log_sha256']);role='recorded_process_operation_with_source_digest_inventory';basis.update(source_members=len(v['source']),command=v['command'],label=v['label'],log_sha256=v['log_sha256'],recorded_exit=v['exit'])
 elif 'files'in v and isinstance(v['files'],dict):
  mp=v['files']
  if fmap(mp):role='recorded_file_digest_inventory';basis.update(file_members=len(mp),context_fields={k:a for k,a in v.items() if k!='files'})
  elif all(isinstance(a,dict) and set(a)=={'bytes','sha256'} and isinstance(a['bytes'],int) and h(a['sha256']) for a in mp.values()):role='recorded_cache_retirement_size_digest_inventory';basis.update(file_members=len(mp),context_fields={k:a for k,a in v.items() if k!='files'})
 elif set(v)=={'tcl8.4.20','tcl8.5.19','tcl8.6.18','tcl9.0.4','tcl9.1.0','jim'}:
  def good(a):return a is None or h(a) or isinstance(a,dict) and all(isinstance(k,str) and good(z) for k,z in a.items())
  assert good(v);role='recorded_provider_input_digest_inventory';basis.update(provider_members=len(v),provider_fields={k:list(a) for k,a in v.items()})
 elif p.endswith('/dep-info-files.json.gz'):
  assert all(isinstance(k,str) and k.endswith('.d') and isinstance(a,str) for k,a in v.items());role='recorded_build_dependency_text_by_exact_artifact_path';basis.update(members=len(v),content_purpose='Opaque exact .d textual payload; no source closure/dynamic dependency correctness claimed')
 elif p.endswith('/generated-compiled-inputs.json.gz'):
  assert all(isinstance(k,str) and isinstance(a,str) and re.fullmatch('(?:[0-9a-f]{2})*',a) for k,a in v.items());role='recorded_build_generated_source_bytes_by_exact_artifact_path';basis.update(members=len(v),decoded_embedded_members=[{'path':k,'bytes':len(bytes.fromhex(a)),'sha256':sha(bytes.fromhex(a))} for k,a in v.items()],content_purpose='Hex bytes retained as original build input artifact; not a current generated-source implementation donor')
 if role:admit(p,role,basis);schemas.append({'path':p,'role':role,'complete_schema_validated':True})
# Frozen352 explicit actual stored/original metadata checks; never ownership acceptance from name or bool.
root=repo/'docs/design/analysis/name-resolution-proofs/rust-validation/frozen352';v=doc(root/'experiment-index.json');refs=[]
def walk(a,ptr=''):
 if isinstance(a,dict):
  if isinstance(a.get('stored'),str) and h(a.get('stored_sha256')):refs.append((ptr,a))
  for k,z in a.items():walk(z,ptr+'/'+k)
 elif isinstance(a,list):
  for i,z in enumerate(a):walk(z,ptr+'/'+str(i))
walk(v)
for ptr,m in refs:
 p=m['stored']
 if p not in rows:continue
 x=rows[p];assert x['source_sha256']==m['stored_sha256'];assert x['source_bytes']==m['stored_bytes']
 if 'original_sha256'in m:assert x['whole_decoded_sha256']==m['original_sha256'];assert x['whole_decoded_bytes']==m['original_bytes']
 if p.endswith('.elf.gz'):admit(p,'retained_compiled_image_bytes_with_explicit_reference_digest',{'experiment_index':str((root/'experiment-index.json').relative_to(repo)),'member_pointer':ptr,'exact_stored_original_record':m,'actual_magic':x.get('decoded_magic_hex')},[{'question':'Image ownership, fresh source/build/provider/currentness and execution are separate. No Native authority from ELF shape or recorded complete_roundtrip flag.'}])
 elif p.endswith('.tar.gz'):
  tar=next(a for a in json.loads((r/'vm-audit-compressed-tar-member-inventory.json').read_text())['archives'] if a['path']==p);snap=doc(root/'source-snapshot.json.gz')['source'];assert all(snap.get(m['name'])==m['sha256'] for m in tar['members']);assert len(tar['members'])==m['original_source_count']
  admit(p,'retained_exact_fullpath_original_Rust_source_archive',{'experiment_index':str((root/'experiment-index.json').relative_to(repo)),'member_pointer':ptr,'member_count':len(tar['members']),'all_member_fullpaths_match_snapshot_source_sha':True,'tar_member_inventory':'vm-audit-compressed-tar-member-inventory.json','contract':'all 4679 tar file names/full decoded member SHA joined to explicit snapshot source map; storage only, no whole-source human-read promotion'})
out={**d,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'role_join_phase02_exact_positive_and_unmatched_partition','rows':list(rows.values()),'phase02_metadata_role_inputs':meta,'phase02_schema_contracts':schemas,'counts':dict(collections.Counter(x['role_state'] for x in rows.values()))};p=r/'vm-audit-compressed-role-joins-phase02.json';t=p.with_suffix('.tmp');t.write_text(json.dumps(out,indent=2)+'\n');os.replace(t,p);print(sha(p.read_bytes()),out['counts'])
