import json,hashlib,datetime,re,subprocess,collections
from pathlib import Path,PurePosixPath
D=Path('/workspace/name-session/full-consumer-audit');R=Path('/workspace/tcl-lsp');c=json.load(open(D/'audit-file-coverage.json'));by={r['path']:r for r in c['files']};q=json.load(open(D/'audit-current-residual-role-queue.json'));targets={r['path']:by[r['path']] for r in q['cohorts']['original_or_generated_program_input_role_not_yet_bound'] if by[r['path']]['review_status']!='reviewed'};hs=collections.defaultdict(list)
for r in targets.values():hs[r['source_sha256']].append(r)
records=[];hits={};keys={'script_sha256','input_sha256','probe_sha256','original_input_sha256','original_init_sha256','init_sha256','actual_init_sha256'}
def raw(r):
 p=R/r['path'];b=p.read_bytes() if p.is_file() else b''
 if hashlib.sha256(b).hexdigest()!=r['source_sha256']:b=subprocess.check_output(['git','cat-file','blob',r['blob']],cwd=R)
 assert hashlib.sha256(b).hexdigest()==r['source_sha256'];return b
def refs(v,at=()):
 if isinstance(v,dict):
  for k,z in v.items():
   if k in keys and isinstance(z,str) and z in hs:yield at+(k,),k,z
   yield from refs(z,at+(k,))
 elif isinstance(v,list):
  for i,z in enumerate(v):yield from refs(z,at+(i,))
for r in c['files']:
 if not r['path'].endswith('.json') or r['source_bytes']>15000000:continue
 b=raw(r)
 if not any(k.encode() in b for k in keys):continue
 try:v=json.loads(b)
 except (ValueError,UnicodeError):continue
 links=[];parent=PurePosixPath(r['path']).parent
 for at,key,h in refs(v):
  exact=[z for z in hs[h] if PurePosixPath(z['path']).parent==parent]
  # Deliberately no subtree/basename inference: same-directory exact input checksum descriptor only.
  for z in exact:
   raw(z);links.append({'path':z['path'],'source_sha256':h,'field_path':list(at),'descriptor':key,'association':'Explicit typed program/input checksum, exact same-directory original program bytes; no actual historical filename/execution claim'})
 if links:
  i=len(records);records.append({'record':r['path'],'record_source_sha256':r['source_sha256'],'input_members':links})
  for j,z in enumerate(links):hits.setdefault(z['path'],(i,j))
out={'baseline':c['baseline'],'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'records':records,'admitted_paths':sorted(hits),'count':len(hits),'scope':'Stored script/input/probe/original-init digest data role joined exact same-directory reserved program bytes, complete original program identity hash. No any-SHA fanout or directory-only exemption; source called from actual capture remains unproved.','limits':['No actual historical filename/import/execution/provider/library/source-currentness or expected result acceptance.','Original source/program expected semantics remain independent; maintained helper implementations are excluded from this reserved original-input role.']};p=D/'audit-original-input-typed-digest-roles.json';p.write_text(json.dumps(out,indent=2)+'\n');h=hashlib.sha256(p.read_bytes()).hexdigest()
for path,(i,j) in hits.items():by[path].update(review_status='reviewed',review_mode='typed_original_input_digest_exact_sibling_byte_role',classification='retained_recorded_independent_program_input_bytes',reason='Explicit typed original program digest exactly matches complete sibling program bytes; recorded input role only, not historical execution/source call acceptance.',evidence=[{'receipt':p.name,'receipt_sha256':h,'json_pointer':f'/records/{i}/input_members/{j}'}])
t=D/'audit-file-coverage.json.tmp';t.write_text(json.dumps(c,separators=(',',':'))+'\n');t.replace(D/'audit-file-coverage.json');print(len(hits),h)
