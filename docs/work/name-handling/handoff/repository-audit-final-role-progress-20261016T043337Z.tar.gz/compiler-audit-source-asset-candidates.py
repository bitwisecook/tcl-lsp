from pathlib import Path
import json,hashlib,collections,subprocess,re
D=Path(__file__).parent;R=Path('/workspace/tcl-lsp');H=lambda b:hashlib.sha256(b).hexdigest();q=json.loads((D/'audit-compiler-final-source-asset-role-reservation.json').read_bytes());fs=q['files'];byhash=collections.defaultdict(list)
for f in fs:byhash[f['source_sha256']].append(f['path'])
cache={};manifests={}
for f in fs:
 p=R/f['path'];b=p.read_bytes()
 if H(b)!=f['source_sha256']:b=subprocess.check_output(['git','-C',str(R),'cat-file','blob',f['blob']])
 assert H(b)==f['source_sha256'];cache[f['path']]=b
 for a in list(p.parents):
  if a==R or not a.is_relative_to(R) or len(a.relative_to(R).parts)<4:break
  for m in a.glob('*.json'):
   if m.stat().st_size>2_000_000:continue
   rp=str(m.relative_to(R))
   if rp not in manifests:manifests[rp]=m
refs=collections.defaultdict(list)
def walk(v,ptr,mp,msha):
 if isinstance(v,dict):
  for k,z in v.items():
   if isinstance(z,str) and z in byhash:
    for path in byhash[z]:
     if path.startswith(str(Path(mp).parent)+'/') and len(refs[path])<12:refs[path].append({'metadata':mp,'metadata_sha256':msha,'json_pointer':ptr+[k],'record':v})
   walk(z,ptr+[k],mp,msha)
 elif isinstance(v,list):
  for i,z in enumerate(v):walk(z,ptr+[i],mp,msha)
for mp,m in manifests.items():
 raw=m.read_bytes()
 try:jj=json.loads(raw)
 except:continue
 walk(jj,[],mp,H(raw))
rows=[]
for f in fs:
 row=dict(f,sha_reference_candidates=refs[f['path']],line_count=cache[f['path']].count(b'\n')+(not cache[f['path']].endswith(b'\n')),exact_same_body_members=byhash[f['source_sha256']]);rows.append(row)
out={'reservation_sha256':H((D/'audit-compiler-final-source-asset-role-reservation.json').read_bytes()),'rows':rows,'metadata_candidates':len(manifests),'source_integrity_errors':0,'counts':{'files':len(rows),'exact_hash_reference_candidates':sum(bool(r['sha_reference_candidates']) for r in rows)},'limits':'Candidate producer/record links only; no source role or manual body review inferred from hash/path/prefix alone.'};p=D/'compiler-audit-source-asset-candidates.json';p.write_text(json.dumps(out,indent=2)+'\n');print(out['counts']);print('unmatched rs/c',[(r['path'],r['line_count']) for r in rows if not r['sha_reference_candidates'] and Path(r['path']).suffix in ['.rs','.c','.h']][:35])
