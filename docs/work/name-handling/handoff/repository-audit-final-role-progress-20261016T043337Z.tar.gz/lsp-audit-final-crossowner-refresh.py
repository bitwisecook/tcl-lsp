from pathlib import Path
import json,hashlib,sys,datetime,os
D=Path(__file__).parent;H=lambda b:hashlib.sha256(b).hexdigest();load=lambda n:json.loads((D/n).read_bytes());expected=sys.argv[1];cp=D/'compiler-migration-units.json';assert H(cp.read_bytes())==expected
mp=D/'lsp-audit-final-crossowner-map.json';oldb=mp.read_bytes();assert H(oldb)=='809eb7673fdb33fa6a04a4386cdf9f173852a60b0f7afdb0ab2b48aa07818dd5';out=json.loads(oldb);primary=load('lsp-migration-units.json');val=load('lsp-audit-validation-boundary-units.json');pre=load('lsp-audit-final-crossowner-preflight.json');assert not pre['errors'];assert H((D/'lsp-migration-units.json').read_bytes())==out['primary_sha256']==pre['primary_sha256'];assert H((D/'lsp-audit-validation-boundary-units.json').read_bytes())==pre['validation_sha256'];cu=load('compiler-migration-units.json');by={u['id']:u for u in cu['units']};assert len(by)==len(cu['units']);changes=[]
compiler_ids={
'compiler.owner.source.definition-member-body-disposition:843',
'compiler.source.typed-declaration-member-identity:798',
'compiler.owner.source.logical-procedure-declaration-catalogue:204',
'compiler.owner.source.configured-partial-expression-cursor:449',
'compiler.owner.source.lambda-decoded-field-source:1279',
'compiler.oo.linked-member.executable-region-inventory:129'}
current={'Compiler':('compiler-migration-units.json',cu),'DB':('db-migration-units.json',load('db-migration-units.json')),'Audit':('audit-migration-units.json',load('audit-migration-units.json')),'Root':('root-migration-units.json',load('root-migration-units.json'))}
allrows=out['confirmed_external_owner_links']+out['pending_shared_facet_links'];owner_ids=[]
for x in allrows:
 owner=x.get('owner_id')
 if not owner:continue
 lane=('Compiler' if owner in compiler_ids else x.get('owner_lane'))
 if lane not in current:continue
 name,cat=current[lane];matches=[u for u in cat['units'] if u['id']==owner];assert len(matches)==1,(owner,len(matches));u=matches[0]
 oldsites=x.get('owner_change_sites',[]);sites=u.get('code_change_sites',[]);assert {(s['path'],s['line'],s['source_sha256']) for s in oldsites}<={(s['path'],s['line'],s['source_sha256']) for s in sites},owner
 x.update(owner_catalogue=str(D/name),owner_catalogue_sha256=H((D/name).read_bytes()),owner_change_sites=sites,owner_api_or_extension=u.get('existing_api',u.get('existing_shared_api',x.get('owner_api_or_extension'))),required_owner_change=u.get('required_change',x.get('required_owner_change')),owner_current_canonical_state=u.get('state'),owner_current_work_kind=u.get('work_kind'))
 if owner in compiler_ids:x['status']='canonical_owner_unit_source_confirmed_final_catalogue_pinned'
 if owner=='db.unit.spectcl.loader.original-rejected-subject':x['status']='canonical_owner_id_confirmed_in_frozen_db184'
 changes.append({'link_id':x.get('link_id',x.get('id')),'owner_id':owner,'owner_lane':lane,'catalogue':name,'catalogue_sha256':x['owner_catalogue_sha256'],'actual_lsp_adopter_ids':x.get('actual_lsp_adopter_ids',x.get('adopters',[])),'source_anchors_unchanged':True});owner_ids.append(owner)
assert len(owner_ids)==len(set(owner_ids)), 'same shared owner represented twice'
units={u['id']:u for u in primary['code_migration_units']};assert len(units)==203
for x in out['code_units']:
 u=units[x['id']];assert [(s['path'],s['line'],s['source_sha256']) for s in x['sites']]==[(s['path'],s['line'],s['source_sha256']) for s in u['code_change_sites']]
for x in changes:
 for a in x['actual_lsp_adopter_ids']:
  if a not in units:assert any(a in str(u) for u in primary['unresolved_owner_or_domain_requirements']),a
out['scope']='Final source-confirmed crossowner join for frozen LSP203 (201 semantic+2 docs) plus122 actual validation boundaries. Historical26 validation families retained only as family provenance; not code-unit count. No source/execution/API implementation acceptance.'
out['current_canonical_counts']={'semantic_product_units':201,'documentation_units':2,'validation_code_boundaries':122,'pending_validation_questions_excluded':2,'oracle_validation_obligation_excluded':1,'crossowner_pin_updates':len(changes)}
out['validation_boundary_catalogue']={'path':str(D/'lsp-audit-validation-boundary-units.json'),'sha256':H((D/'lsp-audit-validation-boundary-units.json').read_bytes()),'count':122,'root_peer':{'path':str(D/'root-lsp-validation122-peer.json'),'sha256':'7eacea208f4973f8a3c7c94c122a8700850859eab2f58b92deee996048404cc6'}}
out['validation_boundaries']=[{'id':u['id'],'family_id':u['family_id'],'work_kind':u['work_kind'],'state':u['state'],'actual_boundary':u['actual_boundary'],'code_change_sites':u['code_change_sites'],'raw_bindings':u['raw_bindings'],'unchanged_affected_callers':u.get('unchanged_affected_callers'),'scope':'Validation code obligation only, not additional product semantic integration or executed control acceptance.'} for u in val['validation_boundary_units']]
for lane,(name,cat) in current.items():out['source_snapshots'][lane]={'path':str(D/name),'sha256':H((D/name).read_bytes()),'scope':'Exact selected owner-ID/source-anchor join only; no whole-lane source or execution acceptance donated.'}
out['compiler_stable_unit_binding']['final_compiler_catalogue_seal']=expected;out['source_snapshots']['Compiler_stable_unit_join']={'path':str(cp),'sha256':expected,'scope':'Final exact six existing owner units (five missing facets+linked-member inventory) joined; no global Compiler count adopted.'}
prepath=D/'lsp-audit-final-crossowner-map-before-final-owner-pins-809eb767.json';assert not prepath.exists();prepath.write_bytes(oldb)
receipt={'baseline':out['baseline'],'predecessor':str(prepath),'predecessor_sha256':H(oldb),'primary_sha256':out['primary_sha256'],'validation122_sha256':H((D/'lsp-audit-validation-boundary-units.json').read_bytes()),'preflight':{'path':str(D/'lsp-audit-final-crossowner-preflight.json'),'sha256':H((D/'lsp-audit-final-crossowner-preflight.json').read_bytes())},'current_owner_pin_updates':changes,'source_anchors_unchanged':True,'code_unit_counts_unchanged':True,'no_invented_pending_owners':'Specific existing Core census/action owner requirements remain Core boundaries; no universal transform permission or speculative crossowner repair added. DB project-role adopter remains genuine pending question excluded confirmed203.','source_and_target_execution':False,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
out['final_owner_pin_refresh']={'receipt':str(D/'lsp-audit-final-crossowner-owner-pin-refresh.json'),'predecessor_sha256':H(oldb),'compiler_final_sha256':expected,'validation122_catalogue_unchanged':True,'scope':'Owner catalogues are updated only after exact unique ID/source-anchor matches; actual LSP adopter/source anchors and frozen203/122 semantic scope remain byte-exact.'}
rp=D/'lsp-audit-final-crossowner-owner-pin-refresh.json';rp.write_text(json.dumps(receipt,separators=(',',':'))+'\n');out['final_owner_pin_refresh']['receipt_sha256']=H(rp.read_bytes());t=mp.with_suffix('.tmp');t.write_text(json.dumps(out,separators=(',',':'))+'\n');os.replace(t,mp);print('map',H(mp.read_bytes()),'receipt',H(rp.read_bytes()),'joins',len(changes),'ownersUnique',len(owner_ids))
