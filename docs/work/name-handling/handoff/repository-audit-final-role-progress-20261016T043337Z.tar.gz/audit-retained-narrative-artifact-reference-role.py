import json,hashlib,datetime,re,posixpath,subprocess,collections
from pathlib import Path,PurePosixPath
D=Path('/workspace/name-session/full-consumer-audit');R=Path('/workspace/tcl-lsp');c=json.load(open(D/'audit-file-coverage.json'));by={r['path']:r for r in c['files']};q=json.load(open(D/'audit-current-residual-role-queue.json'));targets={f['path']:by[f['path']] for f in q['cohorts']['authored_or_historical_record_text_role_not_yet_bound'] if by[f['path']]['review_status']!='reviewed'};records=[];hits={};hs=collections.defaultdict(list)
for r in c['files']:
 if r['review_status']=='reviewed' and any(t in (r.get('classification','')+' '+r.get('review_mode','')) for t in ['retained','original','record','input','capture','provenance','measurement']):hs[r['source_sha256']].append(r)
def raw(r):
 p=R/r['path'];b=p.read_bytes() if p.is_file() else b''
 if hashlib.sha256(b).hexdigest()!=r['source_sha256']:b=subprocess.check_output(['git','cat-file','blob',r['blob']],cwd=R)
 assert hashlib.sha256(b).hexdigest()==r['source_sha256'];return b
safe={'.json','.jsonl','.stdout','.stderr','.log','.txt','.out','.tsv','.csv','.exit','.bin','.gz','.pcap','.pcapng','.sha256'}
for r in targets.values():
 if not r['path'].endswith('.md'):continue
 b=raw(r);text=b.decode();lines=text.splitlines();heads=[{'line':i,'heading':l} for i,l in enumerate(lines,1) if re.match(r'^#{1,6} ',l)];links=[]
 # Exact full path or local explicitly spelled recorded artifact, independent of prose claim validity.
 for m in re.finditer(r'(?:/workspace/tcl-lsp/)?[A-Za-z0-9_./-]+\.(?:jsonl?|stdout|stderr|log|txt|out|tsv|csv|exit|bin|gz|pcapng?|sha256)\b',text):
  p=m.group();xs=[p[len('/workspace/tcl-lsp/'):] if p.startswith('/workspace/tcl-lsp/') else p,posixpath.normpath(PurePosixPath(r['path']).parent.as_posix()+'/'+p)]
  for x in dict.fromkeys(xs):
   z=by.get(x)
   if not z or PurePosixPath(x).suffix not in safe or z['review_status']!='reviewed':continue
   if not any(t in (z.get('classification','')+' '+z.get('review_mode','')) for t in ['retained','original','record','input','capture','provenance','measurement']):continue
   links.append({'kind':'exact_spelled_record_artifact_path','path':x,'source_sha256':z['source_sha256'],'text_byte_offset':len(text[:m.start()].encode()),'existing_role':z['classification']})
 for m in re.finditer(r'\b[a-f0-9]{64}\b',text):
  h=m.group()
  if h=='e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855':continue
  zs=hs.get(h,[])
  if zs:links.append({'kind':'explicit_whole_SHA_reference_to_previously_bound_retained_artifact_bytes','source_sha256':h,'text_byte_offset':len(text[:m.start()].encode()),'matching_retained_paths':[z['path'] for z in zs],'limits':'Exact byte identity only; no unique original producer/path chosen where aliases exist.'})
 if not heads or not links:continue
 # Whole text is retained as prose/table/fence payload, no code or directive invoked.
 ix=len(records);records.append({'path':r['path'],'source_sha256':r['source_sha256'],'complete_bytes':len(b),'whole_lines':len(lines),'section_headers':heads,'explicit_record_artifact_references':links,'role':'Retained source/process/capture measurement narrative attachment citing exact already-role-bound records or bytes; not current API correctness/semantic acceptance.'});hits[r['path']]=ix
out={'baseline':c['baseline'],'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'records':records,'admitted_paths':sorted(hits),'count':len(hits),'positive_role':'Complete retained narrative bytes/source SHA and actual exact referenced artifact-path/hash membership to independently reviewed retained source/process/input records; no prefix/filename/keyword exemption.','limits':['Not whole manual prose/API guideline validation, generator parity, historical execution, original answer or current source/provider acceptance.','All tables/code/replay recipes remain inert record text; active304 APIguides were actually whole read separately.','Matching hash aliases establish exact byte correspondence only, not original unique path/producer identity or current-maintained liveness.']};p=D/'audit-retained-narrative-artifact-reference-role.json';p.write_text(json.dumps(out,indent=2)+'\n');h=hashlib.sha256(p.read_bytes()).hexdigest()
for path,i in hits.items():by[path].update(review_status='reviewed',review_mode='complete_retained_narrative_and_exact_artifact_path_or_hash_reference_role',classification='retained_measurement_source_process_record_narrative',reason='Complete source-bound inert narrative explicitly references exact previously reviewed recorded input/output/provenance artifacts. Role classification does not accept prose/API/result/current source claims or executed recipes.',evidence=[{'receipt':p.name,'receipt_sha256':h,'json_pointer':f'/records/{i}'}])
t=D/'audit-file-coverage.json.tmp';t.write_text(json.dumps(c,separators=(',',':'))+'\n');t.replace(D/'audit-file-coverage.json');print(len(hits),h)
