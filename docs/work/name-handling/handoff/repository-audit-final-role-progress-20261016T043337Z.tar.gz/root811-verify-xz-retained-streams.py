from pathlib import Path
import lzma,json,hashlib,concurrent.futures,datetime
D=Path(__file__).parent;P=Path('/workspace/tcl-lsp');rs=[r for r in json.load(open(D/'root811-role-groups.json'))['other']if r['path'].endswith('.xz')]
def one(r):
 p=P/r['path'];h=hashlib.sha256();n=0
 with lzma.open(p,'rb')as f:
  while b:=f.read(8*1024*1024):h.update(b);n+=len(b)
 sha=h.hexdigest();q=p.parent/'lossless-log-retention.json';refs=[]
 if q.exists():
  for o in json.load(open(q)):
   if o['retained_log']==p.name:
    assert o.get('retained_xz_sha256',o.get('retained_sha256'))==r['source_sha256'];assert o['raw_sha256']==sha;assert o['raw_bytes']==n
    refs.append({'path':str(q.relative_to(P)),'sha256':hashlib.sha256(q.read_bytes()).hexdigest(),'record':o})
 else:
  q=p.parent/'interruption.json';o=json.load(open(q));assert o['compressed_log']==p.name;assert o['raw_log_sha256']==sha;assert o['raw_log_bytes']==n;refs.append({'path':str(q.relative_to(P)),'sha256':hashlib.sha256(q.read_bytes()).hexdigest(),'record':o})
 return {**r,'decoded_sha256':sha,'decoded_bytes':n,'role':'Exact losslessly retained historical runner stdout/stderr diagnostic output, selected by original result/interruption record. No current source acceptance or manual diagnostic trace interpretation.','references':refs}
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as e:
 out=[]
 for x in e.map(one,rs):out.append(x);print(x['path'],x['decoded_bytes'],flush=True)
o={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'POSITIVE_HISTORICAL_OUTPUT_ROLE_VERIFIED','files':out,'errors':[],'limits':'Streams decoded in full for exact envelope/digest equality. Not source reading, test replay, diagnostics interpretation, provider identity, or semantic acceptance.'};(D/'root811-xz-retained-stream-roles.json').write_text(json.dumps(o,indent=2)+'\n')
