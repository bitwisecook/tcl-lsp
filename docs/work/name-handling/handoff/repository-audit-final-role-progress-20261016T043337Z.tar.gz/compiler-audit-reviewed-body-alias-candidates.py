from pathlib import Path
import json,collections,re
D=Path(__file__).parent;q=json.loads((D/'audit-compiler-final-source-asset-role-reservation.json').read_bytes());wanted={f['source_sha256'] for f in q['files']};matches=collections.defaultdict(list)
p=D/'audit-file-coverage.json';dec=json.JSONDecoder()
with p.open() as f:
 s=f.read(1048576);k=re.search(r'"files":\s*\[',s).end();s=s[k:]
 while True:
  s=s.lstrip()
  if s.startswith(']'):break
  if s.startswith(','):s=s[1:].lstrip()
  try:row,n=dec.raw_decode(s)
  except json.JSONDecodeError:
   z=f.read(1048576)
   if not z:raise
   s+=z;continue
  s=s[n:]
  if row.get('source_sha256') in wanted and row.get('review_status')=='reviewed':matches[row['source_sha256']].append({k:row.get(k) for k in ['path','source_sha256','review_mode','classification','reason','reviewed_production_extent','evidence','consumer_ids']})
r={'same_source_sha_reviewed_candidates':dict(matches),'limits':'Exact byte equality only. Reviewer must establish actual whole source body extent and actual new path/import/ROOT/__file__/caller contract before reborrow; data roles not source body credit.'};(D/'compiler-audit-reviewed-body-alias-candidates.json').write_text(json.dumps(r,indent=2)+'\n');print('hashes',len(matches),'paths',sum(f['source_sha256'] in matches for f in q['files']));print([(m['path'],m['review_mode']) for a in matches.values() for m in a][:15])
