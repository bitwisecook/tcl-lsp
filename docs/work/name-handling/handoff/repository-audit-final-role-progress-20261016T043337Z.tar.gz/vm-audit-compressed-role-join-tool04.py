from pathlib import Path
import json,gzip,hashlib,re,os,collections,datetime
r=Path('/workspace/name-session/full-consumer-audit');repo=Path('/workspace/tcl-lsp');d=json.loads((r/'vm-audit-compressed-role-joins-phase03.json').read_text());rows={x['path']:x for x in d['rows']};meta={}
def sha(b):return hashlib.sha256(b).hexdigest()
def h(v):return isinstance(v,str) and re.fullmatch('[0-9a-f]{64}',v)
def read(p):
 b=p.read_bytes();meta[str(p.relative_to(repo))]={'sha256':sha(b),'bytes':len(b),'review_mode':'complete structural retained member/source-reference schema projection'};return json.loads(gzip.decompress(b) if p.suffix=='.gz' else b)
def admit(p,role,basis,questions=None):
 x=rows[p];x['role_state']='positive_role_proven';x['role']=role;x['role_basis']=basis;x['examined_provenance_or_context_questions']=questions or [{'question':'Original runs/provider/source/physical currentness/build/output semantics are not accepted from stored record role.'}]
# Nested original source snapshot inside each original operation receipt.
for p,x in rows.items():
 if p.startswith('docs/design/analysis/name-resolution-proofs/rust-validation/frozen352/operations/') and p.endswith('.json.gz'):
  v=read(repo/p);assert set(v)=={'label','command','exit','seconds','source','uniform_source','summaries','log_sha256'};snap=v['source'];assert isinstance(snap,dict) and isinstance(snap['source'],dict) and all(isinstance(k,str) and h(a) for k,a in snap['source'].items());assert isinstance(v['command'],list) and all(isinstance(a,str) for a in v['command']) and h(v['log_sha256'])
  admit(p,'recorded_process_receipt_with_nested_fullpath_source_digest_snapshot',{'complete_operation_fields':list(v),'nested_source_fields':list(snap),'source_members':len(snap['source']),'recorded_command':v['command'],'recorded_log_sha256':v['log_sha256'],'contract':'all source-map fullpath digest leaves and every operation field validated; nested shape not mistaken for flat source map; exit/summaries/uniform_source remain recorded unaccepted claims'})
# Original-specific full-path snapshots with explicit before/proposed/applied hash fields.
keys={'sha256','source_sha256','before_sha256','ready_sha256','preimage_sha256','proposed_sha256','applied_sha256','scratch_sha256','original_source_sha256','proposal_sha256'}
def refs(v,ptr='',parent_path=None):
 out=[]
 if isinstance(v,dict):
  actual=[v.get(k) for k in ['path','source','source_path','source_owner','owner'] if isinstance(v.get(k),str) and '/' in v[k]]
  if parent_path:actual.append(parent_path)
  for path in actual:
   for k in keys:
    if h(v.get(k)):out.append({'pointer':ptr+'/'+k,'declared_source_fullpath':path,'declared_digest_field':k,'sha256':v[k]})
  for k,a in v.items():
   if isinstance(a,(dict,list)):out+=refs(a,ptr+'/'+k,k if '/'in k else None)
 elif isinstance(v,list):
  for i,a in enumerate(v):out+=refs(a,ptr+'/'+str(i),parent_path)
 return out
for p,x in list(rows.items()):
 if x['role_state']=='positive_role_proven' or not p.endswith(('.rs.gz','.before.gz','.proposed.gz','.rs-before.gz','.rs-proposed.gz')):continue
 parent=(repo/p).parent;maps=set(parent.glob('*.json'))|set(parent.parent.glob('*.json'));matches=[]
 for m in maps:
  v=read(m)
  for z in refs(v):
   if z['sha256']==x['whole_decoded_sha256']:matches.append({'metadata':str(m.relative_to(repo)),**z})
 if matches:admit(p,'retained_explicit_before_proposed_or_applied_source_bytes',{'all_exact_declared_source_field_matches':matches,'full_decoded_sha256':x['whole_decoded_sha256'],'contract':'immutable source-byte side of recorded proposal/measurement; full source path + particular before/proposed/applied digest fields retained, no basename inverse or live code authority'},[{'question':'Stored artifact target publisher/name codec not established solely by these source field byte matches; all matching candidate origins retained.'}])
# Explicit retained original fixture-source map adds artifact target filename as well.
p='experiments/name-handling/results/vm-expose-slot-20261014/oracles/original-vm-visibility-fixture-source.rs.gz';m=(repo/p).parent/'fixture-expectation-correction.json';v=read(m);assert v['retained_original_source']==Path(p).name;assert v['original_source_sha256']==rows[p]['whole_decoded_sha256']
admit(p,'retained_original_fixture_source_beforeimage',{'manifest':str(m.relative_to(repo)),'full_original_source_path':v['path'],'retained_original_source':v['retained_original_source'],'original_source_sha256':v['original_source_sha256'],'contract':'actual retained-target + original source full path + decoded full SHA; corrected/old expected literals remain distinct recorded data, not an expected-answer approval'})
# Exact complete Cargo message schema plus explicitly bounded harness output, no producer execution.
for p,x in rows.items():
 if not p.endswith('.jsonl.gz'):continue
 raw=gzip.decompress(Path(x['local_path']).read_bytes());counts=collections.Counter();other=[]
 for i,line in enumerate(raw.splitlines()):
  if not line.strip():continue
  try:v=json.loads(line)
  except ValueError:
   text=line.decode('utf8');assert (re.fullmatch(r'running \d+ tests?',text) or re.fullmatch(r'test [A-Za-z0-9_:]+ \.\.\. (ok|FAILED)',text) or text=='failures:' or re.fullmatch(r'    [A-Za-z0-9_:]+',text) or re.fullmatch(r'test result: (ok|FAILED)\. \d+ passed; \d+ failed; \d+ ignored; \d+ measured; \d+ filtered out; finished in [0-9.]+s',text)),(p,text)
   other.append({'line':i+1,'text':text});continue
  reason=v.get('reason');assert reason in {'compiler-artifact','build-script-executed','compiler-message','build-finished'}
  if reason=='compiler-artifact':assert isinstance(v['target'],dict) and isinstance(v['filenames'],list)
  elif reason=='build-script-executed':assert isinstance(v['package_id'],str)
  elif reason=='compiler-message':assert isinstance(v['message'],dict)
  elif reason=='build-finished':assert isinstance(v['success'],bool)
  counts[reason]+=1
 basis={'complete_JSON_message_counts':dict(counts),'complete_other_harness_lines':other,'contract':'every nonblank line matches known actual Cargo output object shape or explicit bounded test-harness line; captured output data, not executable source','read_build_consumer':'experiments/name-handling/results/vm-c86-mathfunc-bootstrap/build-and-run.py (actual whole source read) selects compiler-artifact original output records; no original build executed'}
 if 'get-date-fields-runtime'in p:
  m=(repo/p).parent/'validation.json';v=read(m);assert v['build']['messages_sha256']==x['whole_decoded_sha256'];basis['exact_build_record']={'metadata':str(m.relative_to(repo)),'field':'build.messages_sha256','original_messages_sha256':v['build']['messages_sha256'],'command':v['build']['argv']}
 else:
  m=(repo/p).parent/'checks.json';v=read(m);basis['recorded_build_command_context']=v['commands'][1];target=(repo/p).parent/'integration-build.jsonl'
  if target.exists() and sha(target.read_bytes())==x['whole_decoded_sha256']:basis['exact_uncompressed_recorded_log_alias']=str(target.relative_to(repo))
 admit(p,'retained_Cargo_build_and_test_output_message_stream',basis,[{'question':'First/second/final original generation and exact command association remain historical context unless explicit original messages digest/alias joins. Message schema is not proof that an executable was built or tests ran.'}])
out={**d,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'role_join_phase04_exact_positive_and_unmatched_partition','rows':list(rows.values()),'phase04_metadata_role_inputs':meta,'counts':dict(collections.Counter(x['role_state'] for x in rows.values()))};p=r/'vm-audit-compressed-role-joins-phase04.json';t=p.with_suffix('.tmp');t.write_text(json.dumps(out,indent=2)+'\n');os.replace(t,p);print(sha(p.read_bytes()),out['counts'])
for x in rows.values():
 if x['role_state']!='positive_role_proven':print(x['path'])
