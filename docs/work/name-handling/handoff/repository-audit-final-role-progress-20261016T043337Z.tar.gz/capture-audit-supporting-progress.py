from pathlib import Path
import datetime,hashlib,io,json,tarfile
D=Path(__file__).parent;B=Path('/workspace/tcl-lsp/docs/work/name-handling');H=B/'handoff'
names=['root-compiler-packet06-prefix-review.json','compiler-root-operational-role-matcher-packet06-progress.json','root-frozen-role-aid-build-provenance.json','compiler-root-operational-role-matcher-build-v1.py','compiler-root-operational-role-matcher06-raw-templates.txt','compiler-root-operational-role-matcher06-raw-templates.json','compiler-root-operational-role-matcher-literals.json','compiler-root-operational-role-matcher-dispatch.json','compiler-helper-v2-complete-source-admission.json','compiler-helper04-source-review.json','compiler-role-packet01-final-review.json','compiler-role-packet01-source-admission.json','compiler-role-packet01-byte-partition.json','compiler-role-packet01-include-roles.json','runtime-compiler-operational04-source-review.json','audit-final-operational6-admission.json','audit-original-suite-produced-data-role.json','audit-crosshost-source-facet-decisions.json','audit-historical-selector-execution-record-role.json','root-audit-final-operational4-read.json','root-audit-top-level-naming-harness-read.json','compiler-root-operational-role-matcher-strict-receipt.json','compiler-root-operational-role-matcher-strict-results.json']
for i in range(1,7):
 names.extend([f'compiler-root-operational-role-matcher-packet{i:02}.json',f'compiler-root-operational-role-matcher-packet{i:02}.txt'])
missing=[n for n in names if not (D/n).is_file()]
# Optional strict matcher receipts have separately retained exact names.
names=[n for n in names if (D/n).is_file()]
blobs={n:(D/n).read_bytes() for n in names}
for n,b in blobs.items():
 if n.endswith('.json'):json.loads(b)
members=[{'path':n,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}for n,b in sorted(blobs.items())]
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');name=f'repository-audit-closure-progress-{stamp}.tar.gz'
manifest={'status':'SUPPORTING_ACTUAL_SOURCE_REVIEW_PROGRESS_NOT_FINAL_CATALOGUE','members':members,'optional_names_not_present':missing,'limits':'Source/role evidence only. Canonical source closure and semantic owner/adopter reconciliation remain required; no execution or migration acceptance.'}
blobs['CHECKPOINT-MEMBERS.json']=(json.dumps(manifest,indent=2)+'\n').encode()
with tarfile.open(H/name,'w:gz')as a:
 for n,b in sorted(blobs.items()):
  t=tarfile.TarInfo(n);t.size=len(b);a.addfile(t,io.BytesIO(b))
with tarfile.open(H/name)as a:
 for m in members:assert hashlib.sha256(a.extractfile(m['path']).read()).hexdigest()==m['sha256']
sha=hashlib.sha256((H/name).read_bytes()).hexdigest();p=H/'packets.json';j=json.loads(p.read_text());j.append({'file':name,'sha256':sha,'status':manifest['status']+'; '+str(len(members))+' exact hash-verified members; complete Compiler01/Runtime04, Root06 prefix27000, frozen six source aids, final operational/source-host facets. No final count or execution acceptance.'});p.write_text(json.dumps(j,indent=2)+'\n');p=H/'SHA256SUMS';p.write_text(p.read_text()+sha+'  '+name+'\n')
msg=f'Final source-role review continues: Compiler packet01 and Runtime packet04 are complete; Root packet06 prefix1–27,000 is complete and its tail is independently reserved. All304 active guides are reviewed. The supporting `{name}` (SHA256 `{sha}`) retains {len(members)} verified members, including the six frozen source aids and exact parent-role receipts. Canonical final joins are still required; this is not a remaining-migration total or execution acceptance.'
for n in ['audit-status.md','current-state.md']:
 p=B/n;s=p.read_text();parts=s.split('\n\n');parts.insert(1,msg);p.write_text('\n\n'.join(parts))
print(json.dumps({'file':name,'sha256':sha,'bytes':(H/name).stat().st_size,'verified_members':len(members),'missing_optional_names':missing}))
