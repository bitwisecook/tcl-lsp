from pathlib import Path,PurePosixPath
import json,hashlib,re,datetime
P=Path('/workspace/name-session/full-consumer-audit');ROOT=Path('/workspace/tcl-lsp');H=lambda b:hashlib.sha256(b).hexdigest();res=P/'audit-runtime-final-role-cohort-reservation.json';r=json.loads(res.read_text());cov=json.loads((P/'audit-file-coverage.json').read_text());by={x['path']:x for x in cov['files']};ad=[];un=[]
reader='rust/tcl-compiler/tests/wasm_tiers.rs';source=P/'compiler-baseline'/reader;sb=source.read_bytes();assert H(sb)=='e790276eae4bf006581ed31f7c9d0cce172cb5adb7326ff50294b8a5f9868754'
for f in r['files']:
 path=f['path'];b=(ROOT/path).read_bytes();assert H(b)==f['source_sha256']
 if path.startswith('samples/wasm/expected/')and path.endswith('.out'):
  rel=PurePosixPath(path).relative_to('samples/wasm/expected');sample=(PurePosixPath('samples/wasm')/rel.parent/(rel.stem+'.tcl')).as_posix();sr=by.get(sample)
  if sr is None or not re.fullmatch(r't[0-9].*',rel.parts[0]):un.append({'path':path,'reason':'No exact actual samples() tier/source member'});continue
  original=(ROOT/sample).read_bytes();assert H(original)==sr['source_sha256'];b.decode('utf8')
  ad.append({**f,'classification':'fixed_independent_sample_expected_output_data','role_status':'admitted_by_actual_exact_reader_source_and_input_pair','reader':{'path':reader,'source_sha256':H(sb),'ranges':[[300,367],[426,505]],'purpose':'samples selects actual tN tier directory and .tcl stem; exact expected/tier/stem.out path. check_plan reads this UTF8 file as expected stdout before run_linked; no actual run performed.'},'actual_sample_member':{'path':sample,'source_sha256':sr['source_sha256'],'blob':sr['blob']},'scope':'Complete byte/hash/path/schema fixture role; retained expected values remain independent and unapproved, no producer execution or current runtime/compiler parity.'})
 if path.endswith('.sha256'):
  rows=[];bad=[]
  for n,line in enumerate(b.decode('utf8').splitlines(),1):
   if not line:continue
   m=re.fullmatch(r'([0-9a-f]{64}) [ *](.+)',line)
   if not m:bad.append({'line':n,'text':line});continue
   digest,name=m.groups();pp=PurePosixPath(name);candidate=(PurePosixPath(path).parent/pp).as_posix()if not pp.is_absolute()else name.removeprefix('/workspace/tcl-lsp/');member=by.get(candidate)
   rows.append({'line':n,'literal_retained_member':name,'recorded_sha256':digest,'exact_assigned_member':candidate if member and member['source_sha256']==digest else None,'member_match':'Exact inventory/hash correspondence only; no member source-role or original process/source acceptance donated.'})
  if rows and not bad:ad.append({**f,'classification':'complete_typed_retained_sha256_inventory_data','role_status':'admitted_complete_record_schema_only','schema':'Every nonblank physical record is exactly64lowercasehex+two-column checksum member string; all lines parsed inertly, no commands evaluated or files rewritten. Literal members and digests retained unchanged.','records':rows,'not_claimed':'File membership/digest values do not authenticate producer/source/provider/currentness and do not close executable/helper member roles.'})
  else:un.append({'path':path,'reason':'Checksum record schema incomplete/unrecognised','bad':bad})
out={'baseline':r['baseline'],'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reservation_sha256':H(res.read_bytes()),'status':'POSITIVE_COMPLETE_DATA_ROLE_JOINS_ONLY_PRIMARY_UNCHANGED','admitted':ad,'unmatched':un,'counts':{'admitted':len(ad),'sample_expected_outputs':sum(x['classification']=='fixed_independent_sample_expected_output_data'for x in ad),'checksum_inventory_records':sum(x['classification']=='complete_typed_retained_sha256_inventory_data'for x in ad),'unmatched':len(un)},'limits':['No producer/test/provider/build execution.','No blanket expected-directory or .sha256 extension exemption: actual exact reader/sample pair or complete strict record grammar required.','Original values remain independent; file roles supply no runtime acceptance.']};o=P/'runtime-audit-role-fixture-manifest-joins.json';raw=(json.dumps(out,separators=(',',':'))+'\n').encode();o.write_bytes(raw);print(H(raw),out['counts'])
