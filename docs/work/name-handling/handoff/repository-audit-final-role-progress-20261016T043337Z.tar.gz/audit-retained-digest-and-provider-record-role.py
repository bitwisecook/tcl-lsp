import pathlib,json,hashlib,gzip,datetime,re,subprocess,collections
D=pathlib.Path('/workspace/name-session/full-consumer-audit');R=pathlib.Path('/workspace/tcl-lsp');c=json.loads((D/'audit-file-coverage.json').read_text());sha64=re.compile('[a-f0-9]{64}\\Z');records=[];skip=collections.Counter()
def raw(r):
 w=R/r['path'];b=w.read_bytes() if w.is_file() else b''
 if hashlib.sha256(b).hexdigest()!=r['source_sha256']:b=subprocess.check_output(['git','cat-file','blob',r['blob']],cwd=R)
 assert hashlib.sha256(b).hexdigest()==r['source_sha256'];return b
def digestmap(d):return isinstance(d,dict) and d and all(isinstance(k,str) and isinstance(v,str) and sha64.fullmatch(v) for k,v in d.items())
for r in c['files']:
 if r['review_status']=='reviewed':continue
 ext=pathlib.PurePosixPath(r['path']).suffix
 if ext not in ['.json','.gz']:continue
 if ext=='.json' and r['source_bytes']>20000000:continue
 b=raw(r)
 if ext=='.gz':
  import io
  try:
   with gzip.GzipFile(fileobj=io.BytesIO(b)) as f:
    first=f.read(1)
    if first not in [b'{',b'[']:skip['compressed_non_json_role_unexamined']+=1;continue
    b=first+f.read(32000000)
    if len(b)>32000000:skip['decompressed_json_size_limit_pending']+=1;continue
  except (OSError,EOFError):skip['gzip_parse_unavailable']+=1;continue
 try:d=json.loads(b)
 except (UnicodeError,json.JSONDecodeError):skip['not_complete_json']+=1;continue
 kind=None;detail={}
 if digestmap(d):kind='complete_inert_digest_inventory_map';detail={'entries':len(d),'schema':'Every complete member is a String-key→lowercaseSHA256 pair. Whole full-input JSON consumed; no code or executable data interpreted.','key_domain':'Stored source/provider/artifact path/name labels; actual existence/path correspondence/generation/build completeness not inferred.'}
 elif isinstance(d,dict) and {'binary_path','binary_sha256','ldd_exit','ldd_stdout','ldd_stderr','linked_files'}<=d.keys() and isinstance(d['binary_path'],str) and isinstance(d['binary_sha256'],str) and sha64.fullmatch(d['binary_sha256']) and isinstance(d['ldd_stdout'],str) and isinstance(d['ldd_stderr'],str) and isinstance(d['linked_files'],dict) and (not d['linked_files'] or digestmap(d['linked_files'])):
  kind='typed_recorded_provider_binary_and_link_map';detail={'whole_keys':list(d),'linked_file_count':len(d['linked_files']),'schema':'Recorded binary path/digest, ldd output/status and complete linked file digest map; no actual loading/provider execution or current pairing.'}
 elif isinstance(d,dict) and {'executable','sha256','build_receipt','build_receipt_sha256','source_snapshot_sha256'}<=d.keys() and isinstance(d['executable'],str) and all(isinstance(d[k],str) and sha64.fullmatch(d[k]) for k in ['sha256','build_receipt_sha256','source_snapshot_sha256']) and isinstance(d['build_receipt'],str):
  kind='typed_retained_compiled_artifact_reference_record';detail={'whole_keys':list(d),'schema':'Complete recorded executable/build receipt/source snapshot digest references only; ELF ownership/source/gate/runtime facts not promoted.'}
 elif isinstance(d,dict) and {'packages','workspace_members','resolve','target_directory'}<=d.keys() and isinstance(d['packages'],list) and isinstance(d['workspace_members'],list) and isinstance(d['target_directory'],str) and (d['resolve'] is None or isinstance(d['resolve'],dict)):
  kind='recorded_cargo_metadata_standard_dependency_graph';detail={'whole_keys':list(d),'package_count':len(d['packages']),'schema':'Complete stored Cargo dependency/target graph data, not Tcl identity or original selected build completeness. All nested objects/arrays/literal values parsed as metadata; no Cargo execution.'}
 if kind:
  nodes=collections.Counter()
  def walk(v):
   nodes[type(v).__name__]+=1
   if isinstance(v,dict):
    for k,z in v.items():assert isinstance(k,str);walk(z)
   elif isinstance(v,list):
    for z in v:walk(z)
   else:assert v is None or isinstance(v,(str,int,float,bool))
  walk(d);records.append({'path':r['path'],'blob':r['blob'],'source_sha256':r['source_sha256'],'compressed':ext=='.gz','whole_decoded_bytes':len(b),'decoded_bytes_sha256':hashlib.sha256(b).hexdigest(),'role':kind,'complete_value_type_counts':dict(nodes),**detail})
now=datetime.datetime.now(datetime.timezone.utc).isoformat();out={'baseline':c['baseline'],'utc':now,'records':records,'counts':dict(collections.Counter(r['role'] for r in records)),'unparsed_or_nonmatching_roles':dict(skip),'positive_role_basis':'Complete strict stored metadata/digest/dependency/provider/artifact-reference schema, all bytes and JSON values consumed. No filename/prefix/generated marker exclusion. This classifies data role, not described facts.','limits':['Stored filenames/argv/provider/build/source hashes do not prove files existed, correct original build selected or pass statuses accepted.','No source-code/helper/config/guidance body exemption or semantic/current/generator/provider execution acceptance through these metadata roles.','Nonmatching/oversized/nonJSON compressed source and opaque ELF bytes remain separate unadmitted roles, never blanket gzip exemption.']};p=D/'audit-retained-digest-and-provider-record-role.json';p.write_text(json.dumps(out,indent=2)+'\n');h=hashlib.sha256(p.read_bytes()).hexdigest();by={r['path']:r for r in c['files']}
for i,q in enumerate(records):
 r=by[q['path']];r.update(review_status='reviewed',review_mode='strict_full_input_stored_metadata_schema_role_projection',classification=q['role'],reason='Complete JSON and declared metadata schema all-node roles checked; stored claims unaccepted, no source/helper exemption.',evidence=[{'receipt':p.name,'receipt_sha256':h,'record_pointer':f'/records/{i}','source_sha256':r['source_sha256'],'limits':'No current source/build/provider/generator/semantic acceptance.'}])
c['updated_utc']=now;c['summary'].update(reviewed=sum(r['review_status']=='reviewed' for r in c['files']),unexamined=sum(r['review_status']!='reviewed' for r in c['files']));p=D/'audit-file-coverage.json';t=D/'audit-file-coverage.json.tmp';t.write_text(json.dumps(c,separators=(',',':'))+'\n');t.replace(p);print(len(records),out['counts'],h)
