from pathlib import Path
import json,gzip,hashlib,os,datetime,collections
r=Path('/workspace/name-session/full-consumer-audit');repo=Path('/workspace/tcl-lsp');res=r/'audit-vm-final-role-cohort-reservation.json';d=json.loads(res.read_text());rows=[]
def sha(b):return hashlib.sha256(b).hexdigest()
for i,x in enumerate(d['files']):
 p=repo/x['path'];raw=p.read_bytes();assert sha(raw)==x['source_sha256'],x['path']
 h=hashlib.sha256();chunks=[];total=0;lf=0;prefix=b'';keep=bytearray();keep_ok=True
 try:
  with gzip.open(p,'rb') as f:
   while b:=f.read(8*1024*1024):
    h.update(b);chunks.append({'index':len(chunks),'bytes':len(b),'sha256':sha(b)});total+=len(b);lf+=b.count(b'\n')
    if len(prefix)<2000:prefix+=b[:2000-len(prefix)]
    if keep_ok and total<=32*1024*1024:keep.extend(b)
    else:keep_ok=False;keep.clear()
  row={**x,'local_path':str(p),'compressed_sha_verified':True,'whole_decoded_bytes':total,'whole_decoded_sha256':h.hexdigest(),'decoded_lf_count':lf,'ordered_8MiB_chunks':chunks,'role_state':'not_yet_admitted_pending_actual_producer_schema_join'}
  if b'\0' not in prefix:row['decoded_prefix_for_role_triage']=prefix.decode('utf-8','backslashreplace')
  else:row['decoded_magic_hex']=prefix[:32].hex()
  if x['path'].endswith('.json.gz') and keep_ok:
   try:
    obj=json.loads(keep);row['json_root_type']=type(obj).__name__;row['json_root_size']=len(obj) if isinstance(obj,(dict,list)) else None
    if isinstance(obj,dict):row['json_top_level_keys']=list(obj)[:50];row['json_top_level_types']=dict(collections.Counter(type(v).__name__ for v in obj.values()))
   except Exception as e:row['json_parse_error']=str(e)
  rows.append(row)
 except Exception as e: rows.append({**x,'compressed_sha_verified':True,'decode_error':str(e),'role_state':'unmatched_decode_error'})
 if (i+1)%200==0: print('streamed',i+1,flush=True)
out={'baseline':d['baseline'],'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reservation':{'path':str(res),'sha256':sha(res.read_bytes())},'status':'complete gzip byte-stream integrity inventory only; NO role admissions','rows':rows,'counts':{'paths':len(rows),'compressed_bytes':sum(x['source_bytes'] for x in rows),'decoded_bytes':sum(x.get('whole_decoded_bytes',0) for x in rows),'decode_errors':sum('decode_error'in x for x in rows)},'limits':['No suffix/path archive exemption or original provider/build/runtime acceptance.','Prefixes are triage only, not a whole-source actual-read claim. Full decoded SHA and ordered chunks certify bytes, not semantic role.','JSON metadata shape alone is not producer/schema admission.']};p=r/'vm-audit-compressed-role-stream-inventory.json';t=p.with_suffix('.tmp');t.write_text(json.dumps(out,indent=2)+'\n');os.replace(t,p);print('DONE',sha(p.read_bytes()),out['counts'])
