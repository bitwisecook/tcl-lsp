from pathlib import Path
import json,hashlib,gzip,os,re,datetime,collections
r=Path('/workspace/name-session/full-consumer-audit');repo=Path('/workspace/tcl-lsp');inv=json.loads((r/'vm-audit-compressed-role-stream-inventory.json').read_text());rows={x['path']:dict(x) for x in inv['rows']};proofs={};issues=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def doc(p):
 raw=p.read_bytes();d=json.loads(gzip.decompress(raw) if p.suffix=='.gz' else raw);proofs[str(p.relative_to(repo))]={'sha256':sha(raw),'bytes':len(raw),'read_mode':'complete structured role/member projection; not manual semantic source review'};return d
def admit(path,role,basis,questions=[]):
 x=rows[path];x['role_state']='positive_role_proven';x['role']=role;x['role_basis']=basis;x['examined_provenance_or_context_questions']=questions
# Explicit actual process record output fields; exact association not path-prefix exemption.
base=repo/'experiments/name-handling/results'
for name in ['consumer204-compiler-20261014','compiler-production146-20261014','compiler-diagnostic33-20261014','compiler-production114-20261014','compiler-production119-20261014']:
 root=base/name;d=doc(root/'result.json');start=doc(root/'start.json');refs=[]
 for key in ['build','run']:
  if isinstance(d.get(key),dict):refs.append((key,d[key]))
 refs += [('runs/'+str(i),x) for i,x in enumerate(d.get('runs',[]))]
 mapping=doc(root/'log-retention-map.json') if (root/'log-retention-map.json').exists() else None
 for pointer,run in refs:
  if not isinstance(run.get('log'),str) or not isinstance(run.get('command'),list) or not all(isinstance(c,str) for c in run['command']):continue
  namefield=run['log'];target=str((root/namefield).relative_to(repo));extra=[]
  if target not in rows and mapping:
   matches=[m for m in mapping['logs'] if m['original']==namefield]
   if len(matches)!=1:continue
   m=matches[0];target=str((root/m['retained']).relative_to(repo))
   if target not in rows:continue
   x=rows[target];assert x['source_sha256']==m['retained_sha256'];assert x['whole_decoded_sha256']==m['original_sha256'];assert x['whole_decoded_bytes']==m['original_bytes'];extra.append({'retention_map':str((root/'log-retention-map.json').relative_to(repo)),'record':m})
  if target not in rows:continue
  assert Path(namefield).name==namefield
  sourceproof={'path':'experiments/name-handling/results/compiler-production114-20261014/capture.py','sha256':'484b813ef91201deed03f728181ee10915a612e7d95470bfc7c9669270a73a47','read_mode':'actual whole source read','contract':'run captures actual stdout+stderr into exact log; test stage gzip writer then records returned log name'}
  qs=[]
  if start.get('runner_sha256')!=sourceproof['sha256']:qs.append({'question':'exact original capture source unavailable in tracked same-byte Python roster; recorded output role independently proven by explicit result+retention fields','runner_sha256':start.get('runner_sha256')});sourceproof={'path':'experiments/name-handling/results/compiler-diagnostic33-20261014/read-original-log.py','read_mode':'actual whole source read','contract':'unique original result log member -> exact retained container SHA -> exact complete decoded byte SHA+length'}
  admit(target,'retained_recorded_process_stdout_stderr_stream',{'record_path':str((root/'result.json').relative_to(repo)),'record_pointer':pointer,'actual_log_field':namefield,'command':run['command'],'selected_test':run.get('test'),'source_proof':sourceproof,'retention_joins':extra},qs)
# One exact stage-result schema and four exact explicit logfile digest records.
for name in ['named-owner114-stage-replay-20261014','tcltest-production201-20261014','tcltest-production202-trace-20261014','tcltest-temp178-20261014','tcltest-temp199-20261014']:
 root=base/name;d=doc(root/'result.json');namefield='test.log.gz' if name.startswith('named-owner') else 'run.log.gz';target=str((root/namefield).relative_to(repo));x=rows[target]
 key='gzip_sha256' if name.startswith('named-owner') else 'log_sha256';assert d[key]==x['source_sha256']
 if 'raw_log_bytes'in d:assert d['raw_log_bytes']==x['whole_decoded_bytes']
 admit(target,'retained_recorded_process_output_with_exact_container_digest',{'record_path':str((root/'result.json').relative_to(repo)),'container_digest_field':key,'actual_digest':d[key],'actual_selector':d.get('selector'),'actual_command':d.get('command'),'contract':'whole exact container digest + actual process command/selector/capture fields identifies recorded output member; no original outcome accepted'},[{'question':'capture provenance, executable/source and actual execution acceptance remain independent; recorded source_channel/receipt_valid claims not promoted'}])
# Full actual repo path + SHA selected source-beforeimage inventories.
for name in ['frozen347','frozen349','frozen350']:
 root=repo/'docs/design/analysis/name-resolution-proofs/rust-validation'/name;snap=doc(root/'source-snapshot.json.gz');mp=snap['source'];assert isinstance(mp,dict) and all(isinstance(k,str) and re.fullmatch('[0-9a-f]{64}',v) for k,v in mp.items())
 for path,x in rows.items():
  prefix=str(root.relative_to(repo))+'/selected-original-sources/'
  if path.startswith(prefix):
   original=path[len(prefix):-3]
   if mp.get(original)==x['whole_decoded_sha256']:
    admit(path,'retained_exact_original_source_beforeimage',{'source_snapshot':str((root/'source-snapshot.json.gz').relative_to(repo)),'source_field':'source','actual_full_repo_path':original,'declared_source_sha256':mp[original],'whole_decoded_sha256':x['whole_decoded_sha256'],'contract':'complete decoded bytes equal explicit fullpath-keyed original source digest; storage role only'},[{'question':'historical source is not current live compiler/Native/provider authority; no semantic whole-file read claimed'}])
# Dump partial exact partition, no claims for remaining members.
out={'baseline':inv['baseline'],'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'role_join_in_progress_exact_positive_and_unmatched_partition','stream_inventory':{'path':'vm-audit-compressed-role-stream-inventory.json','sha256':sha((r/'vm-audit-compressed-role-stream-inventory.json').read_bytes())},'rows':list(rows.values()),'metadata_role_inputs':proofs,'counts':dict(collections.Counter(x['role_state'] for x in rows.values())),'limits':['Role classification only; no provider/runtime/original output/source semantic acceptance.','No historical suffix/path exemption; every positive carries actual structured member/producers or exact fullpath digest join.','Unmatched entries remain unfinished pending further exact source/schema evidence.']};p=r/'vm-audit-compressed-role-joins-progress.json';t=p.with_suffix('.tmp');t.write_text(json.dumps(out,indent=2)+'\n');os.replace(t,p);print(sha(p.read_bytes()),out['counts'])
