from pathlib import Path
import json,hashlib,re,datetime,os,collections
D=Path(__file__).parent;H=lambda b:hashlib.sha256(b).hexdigest();load=lambda n:json.loads((D/n).read_bytes())
m=load('compiler-root-operational-role-matcher-packet03.json');p=load('lsp-audit-compiler-operational-packet03-progress.json');qa=load('lsp-audit-compiler-operational-packet03-content-integrity.json')
assert len(p['completed_file_scopes'])==len(m['files'])==91 and p['read_aid_ranges']==[[1,41306]] and not p['remaining_aid_ranges'] and not qa['independent_content_failures']
helpers={}
def scan(v,pin):
 if isinstance(v,dict):
  if all(k in v for k in ('path','source_sha256','start_byte','end_byte','full_item_sha256')):helpers[(v['path'],v['source_sha256'],v['start_byte'],v['end_byte'])]=(v,pin)
  for x in v.values():scan(x,pin)
 elif isinstance(v,list):
  for x in v:scan(x,pin)
for pin in m['helper_receipts']:
 b=(D/pin['path']).read_bytes();assert H(b)==pin['sha256'];scan(json.loads(b),pin)
idx={f['path']:f for f in load('compiler-vm-operational-function-inventory-v2-manifest.json')['files']};rows=[];includes=[];lits=[];marks={};aid=(D/m['aid']).read_text().splitlines()
for n,line in enumerate(aid,1):
 if line.startswith('ACTUAL SOURCE '):marks[line.split()[2]]=n
messages={20,208,212,376,508,522,584,592,595,597,601,603,1057,1257,1575,1576,1589,1590,1591}
for f in m['files']:
 b=Path(f['source']).read_bytes();assert H(b)==f['source_sha256'];off=[0]+[i+1 for i,x in enumerate(b) if x==10];selected=[(off[a-1],off[z] if z<len(off) else len(b)) for a,z in f['ranges']];hs=[(a,z,v,pin) for (path,h,a,z),(v,pin) in helpers.items() if path==f['path'] and h==H(b)];ls=[dict(x) for x in p['literal_roles'] if x['path']==f['path']];fn=[]
 if f['path'] in idx:
  q=idx[f['path']];ib=Path(q['function_index']).read_bytes();assert H(ib)==q['sha256'];fi=json.loads(ib);assert fi['source_sha256']==H(b);fn=fi['functions']
 for x in ls:
  assert H(b[x['start_byte']:x['end_byte']])==x['literal_sha256'];parent=[v for v in fn if v['start_byte']<=x['start_byte'] and x['end_byte']<=v['end_byte']];parent=min(parent,key=lambda v:v['end_byte']-v['start_byte']) if parent else None
  x['exact_enclosing_function']=({k:parent[k] for k in ('name','start_byte','end_byte','full_item_sha256','fn_line','end_line')} if parent else None)
  x['parent_role_review']='Actual parent/callee/control read in complete operational aid, and this exact literal expanded from pinned original source and actually read after aid completion. Test annotation and enclosing function do not infer source role.'
  x['role_status']='actual_literal_source_read_role_classified_no_semantic_acceptance'
  if x['ordinal'] in messages:x['role']='fixed diagnostic/assertion/debug report text; no generated Tcl/host command or semantic expected-value derivation'
  elif x['ordinal'] in [1566,1567]:x['role']='actual operative WAT bootstrap source; imports/calls/counter or trap assertions and finite module-name/numeric interpolation actually read; no compile/run performed'
  elif x['ordinal']==1580:x['role']='fixed original Tcl query supplied to linked bootstrap; info body/string equality expected observer, no fresh original/provider measurement'
  else:x['role']='fixed original Tcl/stub source or finite source format fixture passed to actual reviewed analysis/codegen/taint/test helper; original independent input retained, no shell/provider execution here'
  x['actual_parent_source_excerpt']='\n'.join(b.decode().split('\n')[max(0,x['start_line']-4):x['end_line']+3]);lits.append(x)
 atoms=[]
 for a,z in selected:
  cuts={a,z}
  for x,y,_,_ in hs:
   if x<z and a<y:cuts.update((max(a,x),min(z,y)))
  for x in ls:
   if x['start_byte']<z and a<x['end_byte']:cuts.update((max(a,x['start_byte']),min(z,x['end_byte'])))
  cc=sorted(cuts)
  for x,y in zip(cc,cc[1:]):
   hp=next(((v,pin) for h,j,v,pin in hs if h<=x and y<=j),None);lit=next((l for l in ls if l['start_byte']<=x and y<=l['end_byte']),None)
   row={'start_byte':x,'end_byte':y,'sha256':H(b[x:y]),'role':('prior_actual_helper_source' if hp else 'expanded_actual_literal_source_and_parent_role' if lit else 'actual_reviewed_source_code_comments_structure_whitespace')}
   if hp:assert H(b[hp[0]['start_byte']:hp[0]['end_byte']])==hp[0]['full_item_sha256'];row['helper_receipt']=hp[1];row['full_item_sha256']=hp[0]['full_item_sha256']
   if lit:row['literal_ordinal']=lit['ordinal']
   atoms.append(row)
 assert sum(v['end_byte']-v['start_byte'] for v in atoms)==sum(z-a for a,z in selected)
 note=next(x['purpose_note'] for x in p['completed_file_scopes'] if x['path']==f['path'])
 rows.append({'path':f['path'],'source_sha256':H(b),'source':f['source'],'scope_line_ranges':f['ranges'],'scope_bytes':sum(z-a for a,z in selected),'byte_partition':atoms,'actual_source_purpose':note,'read_mode':'complete_reserved_operational_source_actual_read_with_exact_prior_helpers_reborrowed_and_all_long_literals_expanded_actual_read','unexamined_reserved_bytes':0,'literal_ordinals':[x['ordinal'] for x in ls]})
 for z in re.finditer(rb'include_(str|bytes)!\s*\(\s*"([^"\n]+)"',b):
  n=b[:z.start()].count(b'\n')+1
  if not any(a<=n<=e for a,e in f['ranges']):continue
  rel=z.group(2).decode();target=(Path(f['source']).parent/rel).resolve();raw=target.read_bytes();lines=raw.decode().splitlines();kind='retained_expected_observation_table';schema='';count=0;mode='strict complete fixed-data row role projection after actual parent/parser read; no expected answer/parity acceptance'
  if target.suffix=='.tcl':kind='independent_original_Tcl_program_input';mode='whole actual original input source read';schema='original fixed Tcl program source, including actual version guard; never executed';count=len(lines)
  elif 'package_version_oracle.txt' in rel:
   schema='every noncomment row exactly vcompare4fields or vsatisfies4fields or malformed-version3fields or malformed-req4fields; expected status lexical-only'
   for line in lines:
    if not line or line.startswith('#'):continue
    v=line.split('\t');assert ((v[0] in ['vcompare','vsatisfies'] and len(v)==4) or (v[0]=='malformed-version' and len(v)==3) or (v[0]=='malformed-req' and len(v)==4));count+=1
  elif 'package_select_oracle.txt' in rel:
   schema='every noncomment row select5fields, prefer fixed enum, provider/require literal fields and recorded loaded-version or ERROR; no derived semantic answer'
   for line in lines:
    if not line or line.startswith('#'):continue
    v=line.split('\t');assert len(v)==5 and v[0]=='select' and v[1] in ['default','stable','latest'];count+=1
  elif 'double_string_vectors.txt' in rel:
   schema='every noncomment row four tab fields: explicit engine enum, decimal precision, original input, retained result; no formatter used to generate answers'
   for line in lines:
    if not line or line.startswith('#'):continue
    v=line.split('\t');assert len(v)==4 and v[0] in ['8.4','8.5','8.6','9.0','9.1','jim'] and v[1].isdigit();count+=1
  elif 'native_nonfinite_double' in rel:
   schema='six rows each case ordinal0..5 and even lowercase hex expected native result bytes'
   for line in lines:
    v=line.split('\t');assert len(v)==2 and v[0].isdigit() and int(v[0])<6 and re.fullmatch(r'(?:[0-9a-f]{2})*',v[1]);count+=1
   assert count==6
  elif 'native_empty_compound_updaters' in rel:
   schema='two selected-case rows: explicit unavailable marker on C8.4 only, else6Jim or7C fields, fixed list/dict/current count/cache/storage observations'
   for line in lines:
    v=line.split('\t');assert (len(v)==2 and v==['1','unavailable'] and target.name=='8.4.20.tsv') or (len(v)==(6 if target.name=='jim.tsv' else 7) and v[0] in ['0','1'] and v[1] in ['list','dict']);count+=1
   assert count==2
  elif 'native_original_jim_text' in rel or 'native_expanded_head' in rel:
   schema='exact prior retained-data-role supplement4d341e75; whole fixture bytes and strict row schema/source parser linked there';count=len(lines)
  else:raise AssertionError(rel)
  includes.append({'parent_path':f['path'],'parent_source_sha256':H(b),'line':n,'target':str(target),'sha256':H(raw),'bytes':len(raw),'role':kind,'read_mode':mode,'schema':schema,'rows':count,'provider_generation_currentness_original_answers':'not accepted; retained cited provenance is separate from source-role classification'})
findings=[{'id':'packet03.validation.wasm-stage2-owned-artifact','path':'rust/tcl-compiler/tests/wasm_codegen.rs','symbol':'wasmtime_validates_emitted_modules','lines':[1032,1088],'work_kind':'validation_infrastructure','state':'needs_migration','family':'validation.fixture-path-lifetime','reason':'Actual temp_dir fixed per-case wasm/cwasm paths are written and removed without creating an exclusively owned container; concurrent same-case processes can alias or overwrite outputs. Actual process/source validation adapter boundary, not product Tcl semantic resolver.','unchanged_helpers':'have_wasmtime/helper validation source prior receipt does not cover this independent inline adapter.','execution':False},{'id':'packet03.validation.native-refusal-owned-artifact','path':'rust/tcl-compiler/tests/wasm_codegen.rs','symbol':'native_host_refusal_preserves_out_parameter_and_effect_order','lines':[1280,1299],'work_kind':'validation_infrastructure','state':'needs_migration','family':'validation.fixture-path-lifetime','reason':'Actual pid+refuse temp stem writes host/user/boot files and removes them without exclusively owned creation or same-process test invocation nonce; filename intent is not retained ownership. Preserve actual refusal/out-parameter original assertions.','execution':False}]
def write(name,obj):
 q=D/name;t=q.with_suffix('.tmp');t.write_text(json.dumps(obj,separators=(',',':'))+'\n');os.replace(t,q);return {'path':name,'sha256':H(q.read_bytes())}
parts=write('lsp-audit-compiler-operational-packet03-byte-partition.json',{'baseline':m['baseline'],'reservation_sha256':H((D/'compiler-root-operational-role-matcher-packet03.json').read_bytes()),'files':rows,'scope':'Complete disjoint exact original-byte partition WITHIN reserved operational scopes only. Prior production scope remains independently reviewed; no whole-file/helper donation.','independent_content_check':{'path':'lsp-audit-compiler-operational-packet03-content-integrity.json','sha256':H((D/'lsp-audit-compiler-operational-packet03-content-integrity.json').read_bytes()),'content_omissions':0,'line_label_limitation':'Aid L#### placeholder can overwrite the opening literal newline and shift subsequent numbered labels. Source byte coordinates and actual source context control final receipt; line-number apparent gaps are not omitted content. Complete nonwhitespace original code stream equals actual aid content after exact helper/literal subtraction.'}})
litpin=write('lsp-audit-compiler-operational-packet03-literal-roles.json',{'literal_count':len(lits),'literal_bytes':sum(x['bytes'] for x in lits),'literal_roles':lits,'scope':'All exact long literal bytes actually expanded and read, actual parent/callee roles separate from expected semantics/original provider acceptance.'})
incpin=write('lsp-audit-compiler-operational-packet03-include-roles.json',{'includes':includes,'unmatched_includes':0,'limits':'Original source and retained expected data roles only; no imports, provider execution, original answers or parity accepted.'})
receipt={'baseline':m['baseline'],'reservation':{'path':'compiler-root-operational-role-matcher-packet03.json','sha256':H((D/'compiler-root-operational-role-matcher-packet03.json').read_bytes())},'actual_read_aid_ranges':[[1,41306]],'source_scopes':91,'unexamined_reserved_operational_bytes':0,'byte_partition':parts,'literal_roles':litpin,'include_roles':incpin,'progress':{'path':'lsp-audit-compiler-operational-packet03-progress.json','sha256':H((D/'lsp-audit-compiler-operational-packet03-progress.json').read_bytes())},'helper_receipts':m['helper_receipts'],'supplemental_source':p['supplemental_peer_contracts'],'fixed_retained_data':p['retained_data_roles'],'new_required_product_semantic_units':[],'validation_boundary_candidates':findings,'actual_bounded_limitations':['No source/tests/providers/build/Git executed.','All original assertions, Tcl examples, codegen fixtures and expected oracle answers preserved independently; source review is no run/parity/Native/currentness or edit authority.','Cited historical Tcl/F5/Jim behavior in comments remains cited provenance, not a new measured observation. Optional provider skips do not certify conformance.','WASM linked-runtime helper original source admitted separately; actual target/runtime/binary/library pairing not executed here.','Exact original byte source coordinates supersede lossy aid line-label shifts; independent content integrity comparison closed actual operative omission question.'],'primary_lsp_catalogue_unchanged_sha256':H((D/'lsp-migration-units.json').read_bytes()),'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
print(write('lsp-audit-compiler-operational-packet03-source-receipt.json',receipt));print('bytes',sum(x['scope_bytes'] for x in rows),'literals',len(lits),'includes',len(includes))
