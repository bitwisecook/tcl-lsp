"""Independent original-byte census, read-only. No coverage/semantic classifier."""
from pathlib import Path
import json,hashlib,re,bisect
R=Path(__file__).parent
H=lambda b:hashlib.sha256(b).hexdigest()
p=json.loads((R/'compiler-root-operational-role-matcher-packet05.json').read_bytes())
progress=json.loads((R/'compiler-vm-operational-role-packet05-progress.json').read_bytes())
literals={x['ordinal']:x for x in json.loads((R/p['literal_manifest']).read_bytes())['literals']}
errors=[]; helpers={}; receipt_pins=[]
for pin in p['helper_receipts']:
 b=(R/pin['path']).read_bytes();assert H(b)==pin['sha256'];receipt_pins.append(pin)
 def visit(v):
  if isinstance(v,dict):
   if all(k in v for k in ['path','source_sha256','start_byte','end_byte','full_item_sha256']):
    key=(v['path'],v['source_sha256'],v['start_byte'],v['end_byte']);helpers[key]={**v,'receipt':pin}
   for a in v.values():visit(a)
  elif isinstance(v,list):
   for a in v:visit(a)
 visit(json.loads(b))
# Parse source-numbered aid independently; source ranges themselves are authoritative.
visible={};current=None
ab=(R/p['aid']).read_bytes();assert H(ab)==p['aid_sha256']
for aidline,line in enumerate(ab.decode().splitlines(),1):
 if line.startswith('ACTUAL SOURCE '):
  _,_,current,sha=line.split();visible[current]={};continue
 m=re.fullmatch(r'(\d+): (.*)',line)
 if m:
  n=int(m[1]);assert n not in visible[current];visible[current][n]={'text':m[2].encode(),'aid_line':aidline}
 elif line.strip():errors.append({'aid_line':aidline,'unexpected':line})
def independent_literal(b):
 # Validate ONE exact Rust string token; no parser/callname whitelist used.
 raw=re.match(rb'(?:br|cr|r)(#*)"',b)
 if raw:
  end=b'"'+raw[1];return b.find(end,raw.end())==len(b)-len(end)
 m=re.match(rb'(?:b|c)?"',b)
 if not m:return False
 i=m.end()
 while i<len(b):
  if b[i]==92:i+=2;continue
  if b[i]==34:return i==len(b)-1
  i+=1
 return False
out=[];missing=[];white=lambda b:bytes(c for c in b if c not in b' \t\r\n\v\f')
for f in p['files']:
 b=Path(f['source']).read_bytes();assert H(b)==f['source_sha256'];lines=b.splitlines(keepends=True);starts=[0]
 for line in lines:starts.append(starts[-1]+len(line))
 hs=[v for (path,sha,a,z),v in helpers.items() if path==f['path'] and sha==f['source_sha256']]
 assert len(hs)==f['already_read_helper_items']
 exclusions=[];source_helpers=[];source_literals=[]
 for v in hs:
  a,z=v['start_byte'],v['end_byte'];assert H(b[a:z])==v['full_item_sha256'];exclusions.append((a,z,'helper',v))
  source_helpers.append({k:v[k] for k in ['start_byte','end_byte','full_item_sha256','receipt']})
 for ordinal in f['projected_literal_ordinals']:
  v=literals[ordinal];a,z=v['start_byte'],v['end_byte'];assert H(b[a:z])==v['literal_sha256'];assert v['path']==f['path'];assert independent_literal(b[a:z]),('not_one_literal',v)
  assert str(ordinal) in progress['projected_literal_roles'];exclusions.append((a,z,'literal',v));source_literals.append({**v,'reviewed_parent_role':progress['projected_literal_roles'][str(ordinal)]})
 counts={'selected_nonblank_lines':0,'visible_aid_lines':0,'fully_prior_helper_lines':0,'fully_parent_classified_literal_lines':0,'missing_or_mismatched':0}
 for lo,hi in f['ranges']:
  for n in range(lo,hi+1):
   raw=lines[n-1];a,z=starts[n-1],starts[n];parts=[];cursor=a;line_ex=[]
   for x,y,kind,rec in sorted(exclusions,key=lambda x:x[0]):
    if x>=z or y<=a:continue
    x=max(x,a);y=min(y,z)
    if x>cursor:parts.append(b[cursor:x])
    cursor=max(cursor,y);line_ex.append((kind,rec))
   if cursor<z:parts.append(b[cursor:z])
   actual=visible[f['path']].get(n)
   if not raw.strip():continue
   counts['selected_nonblank_lines']+=1
   uncovered=b''.join(parts)
   if actual:
    counts['visible_aid_lines']+=1;v=actual['text']
    for kind,rec in line_ex:
     if kind=='literal' and n==rec['start_line']:v=v.replace(('L'+str(rec['ordinal'])).encode(),b'',1)
    if white(uncovered)!=white(v):
     missing.append({'path':f['path'],'line':n,'reason':'visible aid bytes differ beyond exact exclusions','raw':raw.decode(),'visible':actual['text'].decode()});counts['missing_or_mismatched']+=1
   elif white(uncovered):
    missing.append({'path':f['path'],'line':n,'reason':'nonblank executable/source bytes absent without exact helper/literal join','raw':raw.decode()});counts['missing_or_mismatched']+=1
   elif any(kind=='helper' for kind,_ in line_ex):counts['fully_prior_helper_lines']+=1
   else:counts['fully_parent_classified_literal_lines']+=1
 out.append({'path':f['path'],'source_sha256':f['source_sha256'],'source':f['source'],'ranges':f['ranges'],'counts':counts,'prior_helper_items':source_helpers,'literals':source_literals,'source_note':progress['source_notes'][f['path']]})
record={'baseline':p['baseline'],'purpose':'independent original reserved nonblank byte/line correspondence, not same-builder regeneration or semantic coverage','packet':{'path':'compiler-root-operational-role-matcher-packet05.json','sha256':H((R/'compiler-root-operational-role-matcher-packet05.json').read_bytes())},'aid':{'path':p['aid'],'sha256':H(ab)},'actual_read_aid_ranges':progress['actual_read_aid_ranges'],'helper_receipts':receipt_pins,'files':out,'missing_original_source':missing,'errors':errors,'source_execution':False,'coverage_promotions':0,'limits':['Every nonwhitespace byte outside exact helper and independently validated literal token spans is compared in order against actual source-numbered aid, including otherwise absent lines.','Whitespace-only/comments remain visible except exact previously reviewed helper items; all projected literal roles individually assigned only after actual parent caller read.','No current implementation, external provider, original expected-answer or test execution acceptance.']}
recovery_path=R/'compiler-vm-operational-role-packet05-raw-recovery.json'
recovery=json.loads(recovery_path.read_bytes());assert recovery['actual_read'] is True
rb=(R/recovery['aid']).read_bytes();assert H(rb)==recovery['aid_sha256']
rvisible={};current=None
for text in rb.decode().split('\n'):
 if text.startswith('ACTUAL RAW SOURCE '):
  current=text.split()[3];rvisible[current]={}
  continue
 m=re.fullmatch(r'(\d+): (.*)',text)
 if m:rvisible[current][int(m[1])]=m[2].encode()
recovered=[];unresolved=[]
by_path={f['path']:f for f in out}
for m in missing:
 f=by_path[m['path']];raw=Path(f['source']).read_bytes().split(b'\n')[m['line']-1]
 if rvisible.get(m['path'],{}).get(m['line'])==raw:recovered.append(m)
 else:unresolved.append(m)
record['initial_aid_number_or_byte_mismatches']=record.pop('missing_original_source')
record['raw_recovery']={'path':recovery_path.name,'sha256':H(recovery_path.read_bytes()),'aid':recovery['aid'],'aid_sha256':recovery['aid_sha256'],'actual_read_aid_ranges':recovery['actual_read_aid_ranges']}
record['recovered_mismatch_count']=len(recovered)
record['unresolved_original_source']=unresolved
record['status']='complete_original_byte_correspondence_after_actual_raw_recovery' if not unresolved and not errors else 'unresolved'
(R/'compiler-vm-operational-role-packet05-byte-census.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'files':len(out),'initial_mismatches':len(missing),'raw_recovered':len(recovered),'unresolved':len(unresolved),'errors':errors,'counts':{k:sum(f['counts'][k] for f in out) for k in out[0]['counts']}}))
