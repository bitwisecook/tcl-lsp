import json,hashlib,datetime,collections
from pathlib import Path
P=Path('/workspace/name-session/full-consumer-audit');ROOT=Path('/workspace/tcl-lsp');H=lambda b:hashlib.sha256(b).hexdigest()
def read(n):return json.loads((P/n).read_text())
def pin(n):return {'path':n,'sha256':H((P/n).read_bytes())}

# Successor-only final gate requires exact settled lane inputs.
import sys
assert len(sys.argv)==2, 'Pass final settled pin JSON; no implicit live-input seal'
settled_path=Path(sys.argv[1]); settled=json.loads(settled_path.read_text())
for entry in settled['settled_inputs']:
 assert H((P/entry['path']).read_bytes())==entry['sha256'], ('unsettled input',entry['path'])
historical_path=P/'runtime-audit-final-crossowner-join376.json'
assert H(historical_path.read_bytes())=='f1a44b3b2afe3a6328c5d6f19e00170c78673f07be21b12ff1a5d89cf938d75e'
historical=json.loads(historical_path.read_text())

files={x:read(x+'-migration-units.json')for x in ('runtime','db','compiler','vm')};reg=read('runtime-audit-required-owner-facets-successor375.json');core=read('runtime-audit-core-immediate-owner-annex375.json');split=read('runtime-audit-channel-adapter-split376.json');global_input=read('root-global-reconciliation-input.json')
rt=[x for x in files['runtime']['units']if x['id']not in split['withdrawn_effective_unit_ids']]+core['added_owner_units']+split['added_replacement_units'];assert len(rt)==376
units={u['id']:(lane,u)for lane,d in files.items()for u in d['units']};units.update({u['id']:('runtime',u)for u in rt})
errors=[];cache={};checks=[]
def source(site):
 path=site['path'];sha=site.get('source_sha256',site.get('sourceSHA'));line=site.get('line',site.get('source_line_number'))
 if not sha:return {'path':path,'status':'source_hash_not_in_site'}
 key=(path,sha)
 if key not in cache:
  candidates=[ROOT/path,P/'compiler-baseline'/path,P/'db-production'/path,P/'lsp-baseline'/path]
  b=None;aid=None
  for q in candidates:
   if q.exists():
    bb=q.read_bytes()
    if H(bb)==sha:b=bb;aid=str(q);break
  if b is None:errors.append({'kind':'pinned_source_aid_missing','path':path,'sha256':sha});return {'path':path,'error':'pinned source unavailable'}
  cache[key]=(b.decode().splitlines(),aid)
 ls,aid=cache[key]
 if line and isinstance(site.get('source_line'),str) and ls[line-1]!=site['source_line']:errors.append({'kind':'complete_source_line_mismatch','path':path,'line':line,'expected':site['source_line'],'actual':ls[line-1]})
 return {'path':path,'source_sha256':sha,'line':line,'source_line':ls[line-1]if line else None,'actual_pinned_source_aid':aid,'check':'exact pinned source SHA and complete anchor line; existing bounded/full semantic source receipts remain independent'}
def unit(id):
 if id not in units:errors.append({'kind':'missing_actual_unit_id','id':id});return {'id':id,'error':'missing'}
 lane,u=units[id];return {'id':id,'lane':lane,'purpose':u.get('purpose',u.get('naming_purpose')),'work_kind':u['work_kind'],'representation_context':u.get('representation_and_context',u.get('representation_context')),'required_change':u.get('required_change'),'sites':[source(s)for s in u['code_change_sites']]}
def replace_adapters(ids,owner):
 out=[]
 for id in ids:
  if id=='runtime:metadata.channel-original-member-table:479':
   if owner=='db.unit.registry.channel-puts-immediate-declaration':id+=':puts'
   elif owner=='db.unit.registry.channel-seek-origin-declaration':id+=':seek'
   else:errors.append({'kind':'unpartitioned_mixed_adopter','owner':owner,'id':id})
  if owner=='db.unit.registry.channel-puts-immediate-declaration' and id=='runtime:metadata.channel-original-member-table:475':id='runtime:metadata.channel-original-member-table:479:puts'
  out.append(id)
 return list(dict.fromkeys(out))
rows=[]
for x in reg['records']:
 a=x.get('postseal_admission',x.get('external_admission',{}));owners=[]
 for k in ('owner_unit_id','owner_id','external_requirement_key'):
  if a.get(k):owners.append((a[k],x['actual_runtime_adapters']))
 for o in a.get('owners',[]):owners.append((o['id'],o['actual_external_adopter_ids']))
 if x['id']=='metadata.array-default-declaration':owners=[('runtime:metadata.array-selected-option-and-stock-roster:668',[])]
 if x['id']=='native.string-class-and-option-declarations':owners=[('runtime:native.string-class-and-option-declarations:owner-string-is',x['actual_runtime_adapters'])]
 row={'requirement_group':x['id'],'required_purpose':x['required_facet'],'state':'known_required_owner_and_actual_changed_adapters_bound'if owners else 'examined_actual_domain_question_no_new_owner','owner_edges':[],'source_admission':a,'count_rule':'Count exact semantic owner once, actual changed adapter unit separately; same family text does not merge independent operation/table/representation/caller purposes. Metadata/DTO does not issue Native identity or execution.'}
 for oid,adapters in owners:
  row['owner_edges'].append({'owner':unit(oid),'actual_changed_adapters':[unit(i)for i in replace_adapters(adapters,oid)],'unchanged_callers':'Other existing pure/source/Unicode facades and physical worker algorithms are unchanged unless an exact separately counted adapter is listed. No fanout by family inferred.'})
 rows.append(row)
# All explicit local owner→adapter fields, not just the external requirement groups.
local=collections.defaultdict(list)
for u in rt:
 if u.get('required_shared_owner_unit'):local[u['required_shared_owner_unit']].append(u['id'])
local_rows=[{'owner':unit(o),'actual_changed_adapters':[unit(i)for i in ids],'role':'Actual local declaration/transport/result owner and distinct changed callers; source/Native/header roles remain as recorded.'}for o,ids in local.items()]
# Distinct external public VM entry facets are NOT duplicates of Engine ABI or concrete Engine bridges.
embedding=[]
for family,api,vm,bridges,reason in [
 ('embedding.original-variable-name-door','runtime:embedding.original-variable-name-door:facet-original-variable-door-owner','vm-unit-embedding-original-variable-name-door',['runtime:embedding.original-variable-name-door:facet-vm-original-variable-'+op for op in ('read','store','unset')],'Engine trait6 declaration seams versus VM public checked facade versus three actual TclVmEngine read/store/unset bridges. RuntimeEngine unsupported variable defaults are pending contract questions, not three invented confirmed adapters.'),
 ('embedding.original-package-name-door','runtime:embedding.original-package-name-door:facet-package-byte-door-owner','vm-unit-embedding-original-package-name-door',['runtime:embedding.original-package-name-door:facet-runtime-package-byte-publication','runtime:embedding.original-package-name-door:facet-vm-package-byte-publication'],'Selected finished package bytes, not original Obj cache. Engine trait door, actual Runtime/TclVm engine publication bridges and VM public byte publication facade are distinct source seams. Private VM worker is not ready public API.'),
 ('embedding.original-script-source-door','runtime:embedding.original-script-source-door:facet-original-script-door-owner','vm-unit-embedding-original-script-source-door',['runtime:embedding.original-script-source-door:facet-runtime-original-script-eval','runtime:embedding.original-script-source-door:facet-vm-original-script-eval'],'Original source/header/cache purpose differs legitimate public Unicode/source bytes. Engine door, actual Runtime/TclVm bridges, VM public original evaluator facet distinct, existing begin/finish embedding mandatory.'),
 ('embedding.actual-original-command-vector','runtime:embedding.actual-original-command-vector:359','vm-unit-host-invoked-object-vector',['runtime:embedding.actual-original-command-vector:'+v for v in ('348','354','363')],'One Engine authentic headed invocation owner, real VM retained head→host callback projection and three actual Runtime/Cshim/Engine adapters. Ordinary original argument API intentionally excludes head; no registration-name reconstruction or implicit rewrite of all NativeCommand callers.')]:
 embedding.append({'family':family,'owner':unit(api),'vm_public_or_dispatch_facet':unit(vm),'actual_runtime_engine_adapters':[unit(i)for i in bridges],'semantic_dedup_basis':reason})
# Producer/snapshot/publication are distinct actual seams; valid Unicode façade stays outside.
env_ids=['runtime:host.native-environment-inventory:69','runtime:host.native-environment-inventory:facet-native-env-inventory-provider','runtime:host.native-environment-inventory:facet-native-core-environment-publication','runtime:host.native-environment-inventory:facet-native-host-environment-refresh']
env={'units':[unit(i)for i in env_ids],'semantic_dedup_basis':'Selected Native inventory/snapshot capability and byte provider are not Unicode Env::vars. Actual constructor and refresh publication paths change separately; ordinary Unicode snapshot/facade unchanged. No absence from refusal.'}
# Validate exact unit uniqueness and effective counts without changing historical artifacts.
assert len({u['id']for u in rt})==376
counts={'effective_runtime_units':376,'work_kind':dict(collections.Counter(u['work_kind']for u in rt)),'effort':dict(collections.Counter(u.get('relative_effort',u.get('effort'))for u in rt)),'registered_requirement_groups':len(rows),'external_or_local_register_unique_owner_ids':len({e['owner']['id']for r in rows for e in r['owner_edges']}),'local_explicit_owner_edges':len(local_rows),'domain_question_groups':[r['requirement_group']for r in rows if not r['owner_edges']],'checked_pinned_source_files':len(cache),'source_or_target_errors':len(errors)}
all_sites={(s['path'],s['line'])for u in rt for s in u['code_change_sites']};counts.update(changed_files=len({p for p,l in all_sites}),distinct_code_change_sites=len(all_sites),unit_site_memberships=sum(len(u['code_change_sites'])for u in rt))
out={'baseline':reg['baseline'],'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'FROZEN postseal semantic owner/adopter join; historical catalogue unchanged; no implementation/execution acceptance','input_pins':{lane:pin(lane+'-migration-units.json')for lane in files},'raw_pins':{lane:pin(lane+'-consumers.json')for lane in files},'supplements':[pin(n)for n in ('runtime-audit-core-immediate-owner-annex375.json','runtime-audit-required-owner-facets-successor375.json','runtime-audit-channel-adapter-split376.json','db-runtime-final-owner-partition-annex184.json','compiler-cross-owner-required-native-facets.json','vm-embedding-owner-facet-annex.json')],'root_reconciliation_input':pin('root-global-reconciliation-input.json'),'root_reconciliation_scope':'Exact read-only input snapshot, not asserted final global total; Root must project376 replacements and any later separately admitted lane supplements.','counts':counts,'requirement_groups':rows,'explicit_local_owner_adopter_edges':local_rows,'embedding_source_seam_separation':embedding,'environment_source_seam_separation':env,'known_mapping_corrections':split['DB184_mapping_corrections'],'semantic_duplicate_policy':['DB shared Object/Class primary Info declaration one kind-parameterized owner with actual two adapters.','NamespaceCode direct870 and compiled571 share only proven two controlled prefix literals; handler/compile admissions stay independent.','Core Array default668 is ONE internal repair; no withdrawn DB ArrayDefault owner reintroduced and existing callers unchanged.','Core StringIs/declaration, syntax private literal, detached completion schema, export ABI, known completion key, mathop ordered stock roster and channel diagnostic facets each have actual independent same-purpose source seam.','Existing mathop operation_for_handler_identity stays correct shared attested handler consumer; no Registry relocation repair.','Each DB184 generated child/OO/coroutine/name constructor carries actual selected domain; no general package scaffold or report→resource inversion.','IO seek origin vs puts immediate split two actual adapters to two already counted distinct owners; chan475 stays separate.','No missing owner count or extra adopter inferred from two unresolved Native mask/build or generated channel-provider domains.'],'unchanged_exclusion_rules':['Legitimate Unicode interfaces remain independently valid.','Neutral retained data/headers not automatically denied when live execution purpose is absent.','Actual frame/namespace/key/incarnation and physical table/cache ownership cannot be supplied by reports, source DTOs or shared descriptor labels.','Generic numeric/List/payload parity outside concrete naming duty remains excluded or explicit question; no family-string bulk merge.'],'errors':errors,'execution':{'source_changes':0,'cargo_tests_provider_interpreter_network_git':0},'limits':['Exact source anchors/hashes and previously actual-reviewed required purposes checked, not a repeated whole-source read or executed control.','No final repository-wide remaining total asserted by this Runtime-only crossowner join.','All original controls/Native/public Import guards and pending acceptance limits preserved.']}
# Retain exact actual target IDs and semantic source joins; never family-text dedup.
def joined_targets(value,found):
 if isinstance(value,dict):
  if 'id' in value and 'lane' in value and 'sites' in value:found[value['id']]=value
  for v in value.values():joined_targets(v,found)
 elif isinstance(value,list):
  for v in value:joined_targets(v,found)
old_targets={};new_targets={};joined_targets(historical,old_targets);joined_targets(out,new_targets)
assert set(old_targets)==set(new_targets), ('target IDs changed',set(old_targets)^set(new_targets))
rechecks=[]
for uid,old in old_targets.items():
 now=new_targets[uid]
 oldsites=[{k:v for k,v in x.items() if k!='actual_pinned_source_aid'} for x in old['sites']]
 newsites=[{k:v for k,v in x.items() if k!='actual_pinned_source_aid'} for x in now['sites']]
 assert oldsites==newsites, ('actual target source anchors changed',uid)
 rechecks.append({'id':uid,'lane':now['lane'],'unchanged_exact_source_anchors':True,'previous_actual_purpose_review_retained':True,'current_required_change':now['required_change']})
assert not errors,errors
for entry in settled['settled_inputs']:
 assert H((P/entry['path']).read_bytes())==entry['sha256'], ('input changed during join',entry['path'])
out['historical_join_preserved']={'path':historical_path.name,'sha256':H(historical_path.read_bytes())}
out['settled_input_notice']={'path':str(settled_path),'sha256':H(settled_path.read_bytes())}
out['unchanged_actual_target_source_rechecks']=rechecks
out['status']='FROZEN current postseal semantic owner/adopter join; immutable historical376 retained; no implementation/execution acceptance'
out['counts']['unchanged_actual_target_ids']=len(rechecks)
raw=(json.dumps(out,indent=2,ensure_ascii=False)+'\n').encode();path=P/'runtime-audit-final-crossowner-join-current.json';tmp=path.with_suffix('.json.tmp');tmp.write_bytes(raw);tmp.replace(path);print(json.dumps({'sha256':H(raw),'counts':counts,'errors':errors[:15]},indent=2))
