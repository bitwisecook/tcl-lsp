import json,hashlib,datetime,subprocess,posixpath,re
from pathlib import Path,PurePosixPath
D=Path('/workspace/name-session/full-consumer-audit');R=Path('/workspace/tcl-lsp');c=json.load(open(D/'audit-file-coverage.json'));by={r['path']:r for r in c['files']};q=json.load(open(D/'audit-current-residual-role-queue.json'));targets={f['path']:by[f['path']] for f in q['cohorts']['original_or_generated_program_input_role_not_yet_bound'] if by[f['path']]['review_status']!='reviewed'};hits={};records=[]
def raw(r):
 p=R/r['path'];b=p.read_bytes() if p.is_file() else b''
 if hashlib.sha256(b).hexdigest()!=r['source_sha256']:b=subprocess.check_output(['git','cat-file','blob',r['blob']],cwd=R)
 assert hashlib.sha256(b).hexdigest()==r['source_sha256'];return b
def paths(p,record,cwd=None):
 if not isinstance(p,str) or '\0' in p:return []
 out=[]
 if p.startswith('/workspace/tcl-lsp/'):out.append(p[len('/workspace/tcl-lsp/'):])
 elif not p.startswith('/'):
  out.extend([posixpath.normpath(PurePosixPath(record).parent.as_posix()+'/'+p),posixpath.normpath(p)])
  if isinstance(cwd,str):
   cp=posixpath.normpath(cwd+'/'+p)
   if cp.startswith('/workspace/tcl-lsp/'):out.append(cp[len('/workspace/tcl-lsp/'):])
 return dict.fromkeys(out)
def walk(v,at=()):
 if isinstance(v,dict):
  # A complete stored process-command vector or explicit retained input descriptor; not parsed/evaluated source.
  for key in ['argv','command','cmd']:
   z=v.get(key)
   if isinstance(z,list) and z and all(isinstance(x,str) for x in z):
    for i,p in enumerate(z):yield at+(key,i),p,v.get('cwd'),key
  for key in ['input','input_file','script','source_file','probe','probe_file','original_input','actual_init_file']:
   z=v.get(key)
   if isinstance(z,str):yield at+(key,),z,v.get('cwd'),'explicit '+key
  for k,z in v.items():yield from walk(z,at+(k,))
 elif isinstance(v,list):
  for i,z in enumerate(v):yield from walk(z,at+(i,))
for r in c['files']:
 if not r['path'].endswith('.json') or r['source_bytes']>40000000:continue
 b=raw(r)
 if not any(x in b for x in [b'argv',b'command',b'input',b'script',b'probe',b'source_file']):continue
 try:v=json.loads(b)
 except (ValueError,UnicodeError):continue
 links=[]
 for at,p,cwd,kind in walk(v):
  for path in paths(p,r['path'],cwd):
   if path not in targets:continue
   raw(targets[path]);links.append({'path':path,'source_sha256':targets[path]['source_sha256'],'field_path':list(at),'recorded_input_path':p,'recorded_cwd':cwd,'role':kind+' recorded intended program input, no actual execution accepted'})
 if links:
  i=len(records);records.append({'record':r['path'],'record_sha256':r['source_sha256'],'complete_JSON_root_type':type(v).__name__,'exact_members':links})
  for j,l in enumerate(links):hits.setdefault(l['path'],(i,j))
out={'baseline':c['baseline'],'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'records':records,'admitted_paths':sorted(hits),'count':len(hits),'positive_role':'Explicit complete recorded argv or input path field resolves exact repository path or exact stored cwd+relative path; baseline program bytes pinned independently. Whole original/measurement program input role, not actual historical executed bytes. No fuzzy basename match.','limits':['A captured intended input path is a retained process/measurement input role; no actual import/execution/library/provider/conformance acceptance.','Original expected values/program APIs remain independent. No current maintained producer/helper closes by this rule; only explicitly reserved original-program/config inputs.']};p=D/'audit-final-program-argv-roles.json';p.write_text(json.dumps(out,indent=2)+'\n');h=hashlib.sha256(p.read_bytes()).hexdigest()
for path,(i,j) in hits.items():by[path].update(review_status='reviewed',review_mode='exact_recorded_process_vector_or_explicit_program_input_path_role',classification='independent_recorded_original_program_or_probe_input_bytes',reason='Complete retained command-vector/input record directly names this exact input path; baseline bytes SHA pinned; intended original measurement program role only, no actual execution or semantic acceptance.',evidence=[{'receipt':p.name,'receipt_sha256':h,'json_pointer':f'/records/{i}/exact_members/{j}'}])
t=D/'audit-file-coverage.json.tmp';t.write_text(json.dumps(c,separators=(',',':'))+'\n');t.replace(D/'audit-file-coverage.json');print('admitted',len(hits),'records',len(records),h)
