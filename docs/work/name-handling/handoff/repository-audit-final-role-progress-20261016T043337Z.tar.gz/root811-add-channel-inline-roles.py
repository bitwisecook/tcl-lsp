from pathlib import Path
import json,hashlib
D=Path(__file__).parent;P=Path('/workspace/tcl-lsp');j=json.load(open(D/'root811-positive-role-candidates.json'));out=[]
def walk(o,k=''):
 if isinstance(o,dict):
  for a,b in o.items():yield from walk(b,k+'/'+a)
 elif isinstance(o,list):
  for i,b in enumerate(o):yield from walk(b,k+'/'+str(i))
 elif isinstance(o,str):yield k,o
for r in j['files']:
 if r['role_group']!='process_channels' or r['positive_reference_candidates']:continue
 p=P/r['path'];channel='stdout'if 'stdout'in p.name else 'stderr';raw=p.read_bytes();refs=[]
 for pa in list(p.parents)[:5]:
  if pa in [P/'experiments/name-handling',P/'experiments/name-handling/results',P/'experiments/name-handling/oracles',P/'experiments']:break
  for q in pa.glob('*.json'):
   try:o=json.loads(q.read_bytes())
   except Exception:continue
   for k,v in walk(o):
    if channel in k.split('/')[-1]and v.encode()==raw:refs.append({'path':str(q.relative_to(P)),'sha256':hashlib.sha256(q.read_bytes()).hexdigest(),'field':k,'exact_channel_bytes':True})
 r['inline_channel_record_matches']=refs;out.append(r)
(D/'root811-channel-inline-roles.json').write_text(json.dumps({'files':out},indent=2)+'\n')
for r in out:
 if not r['inline_channel_record_matches']:print(r['path'])
print('matched',sum(bool(r['inline_channel_record_matches'])for r in out),'of',len(out))
