from pathlib import Path
import json,hashlib,collections,datetime,subprocess
D=Path(__file__).parent;R=Path('/workspace/tcl-lsp');BASE='cc24c394004fc187378ba0eefb6c2c5b2615fb00'
p=D/'root-global-reconciliation-input.json';raw=p.read_bytes();j=json.loads(raw);manifest=json.loads((D/'baseline-files.json').read_text());blobs={x['path']:x['blob']for x in manifest['files']};paths=sorted({s['path']for u in j['units']for s in u['sites']});errors=[];warnings=[];oidlist=sorted({blobs[x]for x in paths if x in blobs});allbytes=subprocess.check_output(['git','cat-file','--batch'],input=('\n'.join(oidlist)+'\n').encode(),cwd=R);at=0;content={}
for oid in oidlist:
 end=allbytes.index(b'\n',at);header=allbytes[at:end].split();assert header[0].decode()==oid;size=int(header[2]);b=allbytes[end+1:end+1+size];assert allbytes[end+1+size:end+2+size]==b'\n';content[oid]=b;at=end+2+size
anchors=0
for u in j['units']:
 for s in u['sites']:
  anchors+=1;path=s['path'];line=s.get('line');ctx={'unit':u['id'],'path':path,'line':line}
  if path not in blobs:errors.append({**ctx,'error':'no baseline path'});continue
  b=content[blobs[path]];sha=hashlib.sha256(b).hexdigest();lines=b.split(b'\n')
  if not isinstance(line,int)or line<1 or line>len(lines):errors.append({**ctx,'error':'line outside actual original source'});continue
  for k in ['source_sha256','sourceSHA']:
   if s.get(k)and s[k]!=sha:errors.append({**ctx,'error':'sourceSHA differs from actual baseline','field':k})
  for k in ['blob','git_blob','baseline_blob']:
   if s.get(k)and s[k]!=blobs[path]:errors.append({**ctx,'error':'blob differs from actual baseline','field':k})
  text=lines[line-1].decode('utf-8',errors='strict')
  if not text.strip():warnings.append({**ctx,'warning':'actual anchor line is blank','symbol':s.get('symbol')})
  declared=s.get('source_line')
  if declared and declared.strip()!=text.strip():warnings.append({**ctx,'warning':'declared source_line differs','declared':declared,'actual':text})
out={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'input':p.name,'input_sha256':hashlib.sha256(raw).hexdigest(),'baseline':BASE,'status':'MECHANICAL_EXACT_BASELINE_ANCHORS_ONLY','anchors_checked':anchors,'source_files':len(paths),'errors':errors,'anchor_questions':warnings,'limits':'Actual source hash/blob/line binding only. Semantic owner/adopter join, original source-role completion and current successor annex remain independent. No count/implementation/provider acceptance from hashing.'};f=D/'root-all-catalogue-source-anchor-check.json';f.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k not in ['anchor_questions']}));print('anchor_questions',len(warnings));print(json.dumps(warnings[:12]))
