from pathlib import Path
import json,gzip,hashlib,re,os,datetime,collections
r=Path('/workspace/name-session/full-consumer-audit');repo=Path('/workspace/tcl-lsp');d=json.loads((r/'vm-audit-compressed-role-joins-phase02.json').read_text());rows={x['path']:x for x in d['rows']};docs={};meta={}
def sha(b):return hashlib.sha256(b).hexdigest()
def h(a):return isinstance(a,str) and re.fullmatch('[0-9a-f]{64}',a) is not None
def read(p):
 if p not in docs:
  raw=p.read_bytes();docs[p]=json.loads(gzip.decompress(raw) if p.suffix=='.gz' else raw);meta[str(p.relative_to(repo))]={'sha256':sha(raw),'bytes':len(raw),'review_mode':'complete structural source-reference member projection, not executable source read'}
 return docs[p]
def admit(p,role,basis,qs=None):
 x=rows[p];x['role_state']='positive_role_proven';x['role']=role;x['role_basis']=basis;x['examined_provenance_or_context_questions']=qs or [{'question':'Exact retained byte role only; no current source, implementation, provider/build/execution or whole-source read acceptance.'}]
# Two manifest-backed tar storage roles, every member and complete correspondence checked.
ars=json.loads((r/'vm-audit-compressed-tar-member-inventory.json').read_text())['archives']
for a in ars:
 p=a['path']
 if rows[p]['role_state']=='positive_role_proven':continue
 if p.endswith('/pinned-inputs.tar.gz'):
  parent=(repo/p).parent;m=read(parent/'retention.json');pins=m['whole_input_pins'];assert all(h(v) for v in pins.values());assert m['input_archive_sha256']==rows[p]['source_sha256'];assert len(a['members'])==len(set(pins.values()))
  assert all(z['name']=='sha256/'+z['sha256'] and z['sha256'] in pins.values() for z in a['members'])
  admit(p,'retained_exact_compiler_source_and_tool_input_bytes_archive',{'retention_map':str((parent/'retention.json').relative_to(repo)),'archive_sha256':m['input_archive_sha256'],'member_count':len(a['members']),'member_to_original_fullpaths':[{'member':z['name'],'sha256':z['sha256'],'declared_original_fullpaths':[k for k,v in pins.items() if v==z['sha256']]} for z in a['members']],'contract':'every content-addressed member full payload SHA matches complete declared input pins; rustc/library bytes are storage, not executed compiler/provider acceptance'})
 elif p.endswith('/literal-query-fixtures.tar.gz'):
  parent=(repo/p).parent;m=read(parent/'literal-query-fixtures-manifest.json');assert len(m)==len(a['members']);assert all(m.get(z['name'])==z['sha256'] for z in a['members'])
  admit(p,'retained_exact_fullpath_query_program_and_observation_archive',{'manifest':str((parent/'literal-query-fixtures-manifest.json').relative_to(repo)),'member_count':len(a['members']),'all_fullpath_members_and_decoded_SHA_match':True,'tar_inventory':'vm-audit-compressed-tar-member-inventory.json','contract':'all original program, source excerpt, record/stdout/stderr bytes are explicit manifest entries; original APIs/answers remain independent and unaccepted'})
# Exact declared snapshot records include BOTH artifact path and decoded original path hash.
root=repo/'experiments/name-handling/clock-bootstrap-epoch/registration-repair'
for file in ['before-lazy-build-selected-sources.json','build-selected-sources.json']:
 m=read(root/file)
 for z in m:
  p=str((root/z['snapshot']).relative_to(repo))
  if p not in rows:continue
  x=rows[p];assert x['source_sha256']==z['snapshot_sha256'];assert x['whole_decoded_sha256']==z['source_sha256']
  admit(p,'retained_explicitly_mapped_original_source_snapshot',{'manifest':str((root/file).relative_to(repo)),'exact_member':z,'contract':'explicit full source path + snapshot target + full compressed and decoded hashes; no filename-codec inverse'})
# Remaining source-like stored bytes: exact declared input/source-field maps in actual nearby capture context.
# Full path keys and full decoded hashes, never filename inverses or a suffix alone as admission.
source_rows=[x for x in rows.values() if x['role_state']!='positive_role_proven' and x['path'].endswith(('.rs.gz','.rs-before.gz','.rs-proposed.gz','.before.gz','.proposed.gz','.c.gz','.tcl.gz','.toml.gz','.lock.gz'))]
def source_refs(v,ptr=''):
 found=[]
 if isinstance(v,dict):
  # A declared map of file identities is identified by ALL values being digest strings and path keys.
  if v and all(isinstance(k,str) and h(a) for k,a in v.items()):
   for k,a in v.items():
    if '/' in k or k in ['Cargo.toml','Cargo.lock','rust-toolchain.toml']:found.append((ptr+'/'+k,k,a,'complete_path_digest_map'))
  for k in ['source','source_path','original','path']:
   path=v.get(k)
   if isinstance(path,str) and ('/'in path or path in ['Cargo.toml','Cargo.lock']):
    for hk in ['source_sha256','sha256','original_sha256']:
     if h(v.get(hk)):found.append((ptr,path,v[hk],'explicit_source_path_digest_fields'))
  for k,z in v.items():
   if isinstance(z,(dict,list)):found+=source_refs(z,ptr+'/'+k)
 elif isinstance(v,list):
  for i,z in enumerate(v):found+=source_refs(z,ptr+'/'+str(i))
 return found
for x in source_rows:
 p=repo/x['path'];parents=[p.parent]
 # Exact nearest two capture contexts, plus their direct captured record subdirectory.
 for _ in range(2):
  if parents[-1]==repo:break
  parents.append(parents[-1].parent)
 candidates=set()
 for parent in parents:
  candidates.update(parent.glob('*.json'));candidates.update(parent.glob('*.json.gz'))
  if (parent/'captured').is_dir():candidates.update((parent/'captured').glob('*.json'))
 matches=[]
 for m in sorted(candidates):
  try:v=read(m)
  except (ValueError,OSError):continue
  for ptr,original,digest,contract in source_refs(v):
   if digest==x['whole_decoded_sha256']:matches.append({'metadata':str(m.relative_to(repo)),'field_pointer':ptr,'declared_full_source_or_input_path':original,'sha256':digest,'schema_contract':contract})
 if matches:
  origins=sorted({z['declared_full_source_or_input_path'] for z in matches});admit(x['path'],'retained_bytes_equal_explicit_original_source_or_input_fields',{'complete_metadata_matches':matches,'all_candidate_declared_fullpaths':origins,'whole_decoded_sha256':x['whole_decoded_sha256'],'contract':'Storage-byte correspondence only. Exact source field fullpath and decoded hash, not basename/flattening inverse; all matching path candidates preserved.'},[{'question':'Original snapshot publisher/name codec/intended target and source phase remain unproven where no explicit artifact-target mapping exists. Matching bytes grants no current build/Native identity.'}])
out={**d,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'role_join_phase03_exact_positive_and_unmatched_partition','rows':list(rows.values()),'phase03_metadata_role_inputs':meta,'counts':dict(collections.Counter(x['role_state'] for x in rows.values()))};p=r/'vm-audit-compressed-role-joins-phase03.json';t=p.with_suffix('.tmp');t.write_text(json.dumps(out,indent=2)+'\n');os.replace(t,p);print(sha(p.read_bytes()),out['counts'])
for x in rows.values():
 if x['role_state']!='positive_role_proven':print(x['path'])
