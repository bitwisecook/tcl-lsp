from pathlib import Path
import json,re,hashlib,bisect
D=Path(__file__).parent;H=lambda b:hashlib.sha256(b).hexdigest();load=lambda n:json.loads((D/n).read_bytes());q=load('compiler-root-operational-role-matcher-packet06.json');helpers={}
def scan(v,pin):
 if isinstance(v,dict):
  if all(k in v for k in ('path','source_sha256','start_byte','end_byte','full_item_sha256')):helpers[(v['path'],v['source_sha256'],v['start_byte'],v['end_byte'])]=(v,pin)
  for w in v.values():scan(w,pin)
 elif isinstance(v,list):
  for w in v:scan(w,pin)
for pin in q['helper_receipts']:scan(load(pin['path']),pin)
ls=load('compiler-root-operational-role-matcher-literals.json')['literals'];aidlines=(D/q['aid']).read_text().splitlines();seen={};cur=None
for aidline,s in enumerate(aidlines,1):
 m=re.match(r'ACTUAL SOURCE (.+) ([a-f0-9]{64})$',s)
 if m:cur=m[1]
 m=re.match(r'(\d+): (.*)$',s)
 if m and cur:seen.setdefault(cur,{})[int(m[1])]=(aidline,m[2])
missing=[];files=[]
for f in q['files']:
 b=Path(f['source']).read_bytes();assert H(b)==f['source_sha256'];starts=[0]+[i+1 for i,c in enumerate(b) if c==10];hs=[(a,z,v,p) for (path,sha,a,z),(v,p) in helpers.items() if path==f['path'] and sha==H(b)];fl=[l for l in ls if l['path']==f['path'] and l['source_sha256']==H(b) and l['ordinal'] in f['projected_literal_ordinals']];masked=bytearray(b)
 for a,z,_,_ in hs:
  for i in range(a,z):
   if masked[i]!=10:masked[i]=32
 for l in fl:
  a,z=l['start_byte'],l['end_byte']
  for i in range(a,z):
   if masked[i]!=10:masked[i]=32
  label=('L'+str(l['ordinal'])).encode();masked[a:a+len(label)]=label
 # EXACT historic splitlines geometry, preserving byte source locations.
 ml=bytes(masked).decode().splitlines(keepends=True);spans=[];at=0
 for s in ml:
  n=len(s.encode());spans.append((at,at+n,s));at+=n
 actual=[]
 for n,(aidline,text) in seen.get(f['path'],{}).items():
  a,z,s=spans[n-1];assert s.strip()==text,(f['path'],n)
  actual.append((a,z,aidline))
 covered=bytearray(len(b))
 for a,z,_ in actual:covered[a:z]=b'\1'*(z-a)
 for a,z,_,_ in hs:covered[a:z]=b'\1'*(z-a)
 for l in fl:covered[l['start_byte']:l['end_byte']]=b'\1'*(l['end_byte']-l['start_byte'])
 omitted=[]
 for a,z in f['ranges']:
  for line in range(a,z+1):
   x=starts[line-1];y=starts[line] if line<len(starts) else len(b);remaining=bytes(c if not covered[x+i] else 32 for i,c in enumerate(b[x:y]))
   if remaining.strip():
    row={'path':f['path'],'line':line,'start_byte':x,'end_byte':y,'source_sha256':H(b),'source_line':b[x:y].decode().rstrip('\n'),'uncovered_source':remaining.decode().rstrip('\n')};missing.append(row);omitted.append(row)
 files.append({'path':f['path'],'source_sha256':H(b),'actual_projected_byte_spans':[[a,z,al] for a,z,al in actual],'missing_nonblank_count':len(omitted)})
r={'packet_sha256':H((D/'compiler-root-operational-role-matcher-packet06.json').read_bytes()),'geometry':'Exact historic masked.decode().splitlines(keepends=True) reconstructed and every visible line matched, source bytes preserved. LF line labels in original projection may drift after alternate line separators; actual byte spans are authoritative.','files':files,'missing_nonblank':missing}
p=D/'compiler-root-packet06-exact-reconstruct.json';p.write_text(json.dumps(r,indent=2)+'\n')
print('missing',len(missing),'files',len(files),'sha',H(p.read_bytes()))
for row in missing:print(row['path'],row['line'],row['uncovered_source'])
