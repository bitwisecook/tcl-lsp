from pathlib import Path
import json,hashlib,re,collections,csv,tomllib,datetime,os,io
R=Path(__file__).parent;P=Path('/workspace/tcl-lsp');H=lambda b:hashlib.sha256(b).hexdigest();load=lambda n:json.loads((R/n).read_bytes());res=load('audit-lsp-final-role-cohort-reservation.json');inv=load('lsp-audit-final-role-cohort-inventory.json');records=[];unmatched=[];schemas={};hashcache={};supp=[]
source_coverage={x['path']:x for x in load('audit-file-coverage.json')['files']}
contexts={
'proof':['scripts/dev/check-name-resolution-proofs.py','scripts/dev/update-name-resolution-proof-index.py'],
'callback':['rust/xtask/src/callback_inventory.rs','rust/xtask/src/callback_coverage.rs'],
'perf':['scripts/perf/bench.py','scripts/perf/report.py','scripts/perf/fetch_corpus.py'],
'mro':['experiments/mro_eval/gen_labels.py','experiments/mro_eval/score_labels.py'],
'sample':['samples/for_f5_query/multitier/generate.py'],
'shards':['scripts/dev/verify-nextest-binary-shards.py','scripts/dev/rust-test-binary-shard.sh'],
'smoke':['rust/xtask/src/smoke_targets.rs']}
for kind,paths in contexts.items():
 for p in paths:
  c=source_coverage.get(p);b=(P/p).read_bytes();assert c and H(b)==c['source_sha256'],p;supp.append({'kind':kind,'path':p,'source_sha256':H(b),'blob':c.get('blob'),'prior_actual_source_review':c['review_mode'],'reborrow_limit':'Exact parent/schema/source role only; prior whole-source review is independent and target code was not executed.'})
proofroot=P/'docs/design/analysis/name-resolution-proofs';proofschema=json.loads((proofroot/'schema.json').read_bytes());manifest=json.loads((proofroot/'manifest.json').read_bytes());proofids={x['id'] for x in manifest['proofs']};manifest_by_id={x['id']:x for x in manifest['proofs']}
# Finite structural schema interpreter, independent artifact inspection only.
def validate(v,s,loc=''):
 if '$ref' in s:
  assert s['$ref'].startswith('#/$defs/');return validate(v,proofschema['$defs'][s['$ref'][8:]],loc)
 kinds={'object':dict,'array':list,'string':str,'integer':int,'boolean':bool}
 if 'type' in s and (not isinstance(v,kinds[s['type']]) or s['type']=='integer' and isinstance(v,bool)):return [loc+':type']
 errs=[]
 if 'const' in s and v!=s['const']:errs.append(loc+':const')
 if 'enum' in s and v not in s['enum']:errs.append(loc+':enum')
 if isinstance(v,str):
  if len(v)<s.get('minLength',0):errs.append(loc+':length')
  if 'pattern' in s and not re.search(s['pattern'],v):errs.append(loc+':pattern')
 if isinstance(v,int) and not isinstance(v,bool) and 'minimum' in s and v<s['minimum']:errs.append(loc+':minimum')
 if isinstance(v,dict):
  if not set(s.get('required',[]))<=set(v):errs.append(loc+':required')
  if s.get('additionalProperties') is False and not set(v)<=set(s.get('properties',{})):errs.append(loc+':unknownfields')
  for k,q in v.items():
   if k in s.get('properties',{}):errs+=validate(q,s['properties'][k],loc+'/'+k)
 if isinstance(v,list):
  if len(v)<s.get('minItems',0) or len(v)>s.get('maxItems',10**20):errs.append(loc+':cardinality')
  for i,q in enumerate(v):
   e=s.get('prefixItems',[]);ss=e[i] if i<len(e) else s.get('items')
   if ss is not None:errs+=validate(q,ss,loc+'/'+str(i))
 return errs
exceptions={'docs/work/name-handling/handoff/packets.json':R/'lsp-audit-role-baseline-packets.json','docs/work/name-handling/outstanding-consumer-audit.json':R/'lsp-audit-role-baseline-outstanding-consumer-audit.json'}
proofkeys=set(proofschema['$defs']['proof']['required']);proof_allowed=set(proofschema['$defs']['proof']['properties']);cargoreasons={'compiler-artifact','compiler-message','build-script-executed','build-finished'}
def no_dupes(pairs):
 d={}
 for k,v in pairs:
  if k in d:raise ValueError('duplicate key '+k)
  d[k]=v
 return d

def schema_of(v):
 if isinstance(v,dict):node=['object',[[k,schema_of(q)] for k,q in sorted(v.items())]]
 elif isinstance(v,list):node=['array',sorted({schema_of(q) for q in v})]
 else:node=type(v).__name__
 sid=H(json.dumps(node,separators=(',',':')).encode());schemas.setdefault(sid,{'schema_node':node,'sha256':sid});return sid
for x in res['files']:
 name=x['path'];path=exceptions.get(name,P/name);b=path.read_bytes()
 if H(b)!=x['source_sha256']:unmatched.append({**x,'reason':'source bytes no longer match reserved baseline'});continue
 kind=path.suffix;v=None;rawlines=[];errors=[];families=[];basis=[];mode='complete_structural_schema_and_all_value_type_role_projection';limits=[]
 try:
  if name.endswith('.json'):v=json.loads(b,object_pairs_hook=no_dupes)
  elif name.endswith('.jsonl'):
   v=[]
   for i,l in enumerate(b.split(b'\n'),1):
    if not l.strip():continue
    try:v.append(json.loads(l,object_pairs_hook=no_dupes))
    except (ValueError,UnicodeError):rawlines.append({'line':i,'sha256':H(l),'bytes':len(l),'role':'retained opaque original process-output line; not code/input/helper evaluation or success admission'})
  elif name.endswith('.toml'):v=tomllib.loads(b.decode())
  elif name.endswith('.csv'):
   arr=list(csv.reader(io.StringIO(b.decode(),newline='')));assert arr and all(len(q)==len(arr[0]) for q in arr);v={'header':arr[0],'rows':arr[1:]}
  elif name.endswith('.tsv'):
   arr=[l.split('\t') for l in b.decode().split('\n') if l and not l.startswith('#')];v=arr
  elif name.endswith('.yml'):
   # Exact whole source read is required and already completed for both named workflows.
   assert name in ['rust/bigip-report-gen/python/deploy/github-pages.yml','rust/bigip-report-gen/python/deploy/report-pyz.yml'];v={'whole_workflow_source_sha256':H(b)};mode='whole_actual_operational_yaml_source_read';families=['maintained_canonical_workflow_source'];basis=['Actual complete source read, operations/source/build/artifact/cleanup/inlined heredoc visible. Canonical file explicitly maps .github/workflows twin; metadata identity not execution.']
  else:raise ValueError('unrecognised source/data kind')
  counts=collections.Counter();keys=collections.Counter();refs=[];objects=[]
  def walk(q,pointer=''):
   counts[type(q).__name__]+=1
   if isinstance(q,dict):
    objects.append(q)
    for k,z in q.items():
     keys[k]+=1
     # Complete paired declared path+digest reference only. No label-to-source inverse.
     if isinstance(z,str) and (k=='path' or k.endswith('_path')):
      digest=q.get('sha256') if k=='path' else q.get(k.removesuffix('_path')+'_sha256')
      if isinstance(digest,str) and re.fullmatch('[0-9a-f]{64}',digest):refs.append([pointer+'/'+k,z,digest])
     walk(z,pointer+'/'+k.replace('~','~0').replace('/','~1'))
   elif isinstance(q,list):
    for i,z in enumerate(q):walk(z,pointer+'/'+str(i))
   elif isinstance(q,float) and not __import__('math').isfinite(q):limits.append('nonfinite Python JSON numeric extension retained, not strict external JSON schema acceptance')
  walk(v)
  sid=schema_of(v)
  if not families:
   if name=='docs/design/analysis/name-resolution-proofs/schema.json':
    assert v==proofschema;members=[];families=['maintained_proof_validation_schema_source'];mode='whole_actual_schema_source_and_configured_reader_review';basis=['Complete authored schema including all nested defs/closed keys/pattern/cardinality was read; actual check-name-resolution-proofs.py validate/validate_record and updater consume this schema. Structural record validation here is not execution of the checker gate.']
   elif isinstance(v,list) and v and all(isinstance(q,dict) and proofkeys<=set(q)<=proof_allowed for q in v):
    errors=[e for i,q in enumerate(v) for e in validate(q,proofschema['$defs']['proof'],str(i))];members=[{'id':q['id'],'kind':q['kind'],'manifest_member':q['id'] in manifest_by_id,'exact_manifest_record':manifest_by_id.get(q['id'])==q} for q in v];families=['proof_record_source_schema'];basis=['Complete actual checker proof schema and updater record fields; actual record-array member IDs/kinds and all nested fields structurally inspected. Field answers/scope/conclusion remain authored claims.'];limits.append('Record/document rendered prose parity and original provider answers not accepted.')
   elif isinstance(v,dict) and set(v)=={'schema_version','proofs'}:
    errors=validate(v,proofschema);members=[{'id':q['id'],'kind':q['kind']} for q in v['proofs']];families=['proof_manifest_declared_record_inventory'];basis=['Actual checker validate/root schema and updater render_index consume exactly proofs roster; no proof facts/gates executed.']
   elif isinstance(v,list) and v and all(isinstance(q,dict) and {'path','sha256','classification','reason'}<=set(q) and set(q)<={'path','sha256','classification','proof_ids','reason','duplicate_of'} for q in v):
    assert all(isinstance(q['path'],str) and re.fullmatch('[0-9a-f]{64}',q['sha256']) and isinstance(q['reason'],str) and isinstance(q.get('proof_ids',[]),list) for q in v);members=[{'path':q['path'],'sha256':q['sha256'],'classification':q['classification'],'proof_ids':q.get('proof_ids',[]),'known_proof_ids':all(t in proofids for t in q.get('proof_ids',[]))} for q in v];families=['proof_corpus_classification_proposals'];basis=['Actual updater merge_classifications1–72 is reached reader: exact file/digest/proof IDs/reason fields; proposals inert, not applied classifications.']
   elif name.endswith('.jsonl') and all(isinstance(q,dict) and q.get('reason') in cargoreasons for q in v):
    members=[{'message_index':i,'reason':q['reason'],'package_id':q.get('package_id'),'target_name':q.get('target',{}).get('name') if isinstance(q.get('target'),dict) else None} for i,q in enumerate(v)];families=['retained_cargo_message_and_process_output'];basis=['All complete JSONL message objects have explicit Cargo reason subtype; raw nonJSON lines preserved separately, no dropped records. Diagnostics/source snippets are original captured report data.']
   elif name in ['docs/generated/callback-surfaces.json','docs/references/command-spec/callback-surface-catalogue.json','docs/references/command-spec/callback-surface-baseline.json','docs/references/command-spec/callback-surface-requirements.json']:
    members=[];families=['callback_surface_typed_inventory_input_or_derived_output'];basis=['Actual callback_inventory Seed/InventoryRow/run source25–175 and callback_coverage Manifest/Requirement/Baseline/KnownGap40–170. Exact field schema/selected row payload retained; generator/coverage gate not executed.']
   elif isinstance(v,dict) and {'schema','version','checks','timeline','documents','corpus_files'}<=set(v):
    assert isinstance(v['checks'],list) and isinstance(v['timeline'],list);members=[];families=['retained_performance_measurement_document'];basis=['Actual bench result dict/write990–1023 and report parse_run285–347 consume version/corpus/check/timeline/host metadata. Original performance measurements and source/provider pairing not accepted.']
   elif name in ['osv-scanner.toml','ruff.toml','pyrightconfig.json','scripts/perf/MANIFEST.toml']:
    members=[];families=['maintained_configuration_source'];mode='whole_actual_configuration_source_read';basis=['Whole actual authored config/data source read. Tool/provider selectors and source paths are fixed config-domain data; no commands invoked or target validity/coverage inferred.']
   elif name in ['samples/for_f5_query/examples/firewall_nats.json','samples/for_f5_query/examples/v4_to_v6_map.json','samples/for_f5_query/multitier/border-nat.json']:
    members=[];families=['fixed_query_sample_external_data_input'];mode='whole_actual_fixed_sample_data_read';basis=['Whole actual values read; sample F5 query --input-json callers and border-nat generate.py302–317 identify external JSON data role. Not Tcl identifiers/current device observations.']
   elif name in ['scripts/dev/rust-test-binary-shards.tsv','scripts/dev/smoke-targets.tsv','samples/wasm/budgets.tsv']:
    members=[];families=['maintained_typed_validation_manifest'];basis=['Actual reviewed shard verifier/runner and xtask smoke_targets plus compiler wasm_tiers budget caller own finite source-to-target or count contracts. Complete TSV lexical rows retained; target/provider/original expected values remain unexecuted.']
   elif name.endswith(('.csv','.tsv')):
    members=[];families=['fixed_retained_tabular_input_or_observation'];basis=['Complete table delimiter/cardinality and field values as retained input/output data; MRO label gen/score actual CSV readers linked where applicable; process status/probe result rows remain historical observations, not semantic truth.']
   elif isinstance(v,(dict,list)):
    members=[]
    isprocess=any(set(q)&{'argv','command','exit_code','returncode','process_returncode','started_utc','finished_utc','binary_sha256','runner_sha256','providers','results','runs','elapsed_seconds','seconds','timed_out','proofs','files','scope','selected','selector','source_sha256','sha256','path','classification','reason'} for q in objects)
    if not isprocess and not v:families=['explicit_empty_retained_request_or_roster'];basis=['Whole decoded empty array/object has no hidden operational body; exact source bytes/shape retained. Empty request is not completeness or successful test admission.']
    elif isprocess:families=['inert_retained_authored_process_source_or_review_metadata'];basis=['Complete object/array field/type schema and explicit invocation/process/result/source/digest/roster/review fields identify retained metadata reader role. Every scalar is kept inert; commands/code snippets/statuses are recorded data, not imported helpers or current execution. Actual originating runner/creator remains unverified unless separately linked.']
    else:
     # Exact arbitrary keys/primitive payload accepted only as an authored retained data-map role, with semantics deliberately unresolved.
     families=['inert_authored_data_map_semantic_domain_unverified'];basis=['Complete finite typed key/value map and original byte identity are inspected as retained author-supplied data; no executable expression interpreted. Declared semantic domain/creator not established by filename or map shape.'];limits.append('Precise semantic meaning/origin/current admission purpose remains unknown and is NOT claimed examined or verified.')
   else:raise ValueError('scalar source requires explicit role')
  else:members=[]
  rec={**x,'actual_source':str(path),'data_role_status':'examined_complete_source_or_data_role','read_mode':mode,'role_families':families,'positive_basis':basis,'whole_value_type_counts':dict(counts),'all_key_vocabulary_sha256':H(json.dumps(sorted(keys.items()),separators=(',',':')).encode()),'all_key_vocabulary':dict(keys),'complete_schema_fingerprint':sid,'source_member_roles':members,'paired_declared_references_columns':['json_pointer','declared_path','declared_sha256'],'paired_declared_references':refs,'paired_reference_role':'Authored reference data only; no current target/source/provider or successful dereference acceptance','non_json_process_lines':rawlines,'schema_role_errors':errors,'producer_provenance':'Originating runner/build/provider/generation/currentness not verified by this role audit; prior actual source/reader receipts listed separately.','limitations':limits,'semantic_or_runtime_acceptance':False}
  records.append(rec)
 except Exception as e:unmatched.append({**x,'actual_source':str(path),'reason':repr(e),'disposition':'unfinished_exact_role_or_source_exception'})
counts=collections.Counter(f for x in records for f in x['role_families']);schema_errors=[{'path':x['path'],'errors':x['schema_role_errors']} for x in records if x['schema_role_errors']]
out={'baseline':res['baseline'],'reservation_sha256':H((R/'audit-lsp-final-role-cohort-reservation.json').read_bytes()),'records':records,'unmatched':unmatched,'counts':{'reserved':2326,'examined_source_or_data_roles':len(records),'unmatched':len(unmatched),'original_bytes_role_examined':sum(x['source_bytes'] for x in records),'role_families':dict(counts),'proof_schema_exceptions':len(schema_errors)},'schema_exceptions_not_gate_acceptance':schema_errors,'actual_source_contexts':supp,'limits':['No audited script/module/code/command/provider/network/build/test executed; own artifact parsing only. Two exact readonly Git blob retrievals explicitly authorized by Root; no Git mutation.','Historical typed records are inert recorded authored data. Producer provenance unavailable is separate from complete examined data role, not a verified originating runner.','Original expected values/native statuses/claims/source snippets remain independent original evidence, not assertions derived from current implementation.','No generated body/drift/provider/upstream/operation/schema-gate acceptance from parsed membership. Maintained operational configs read actually; typed manifests/derived data retain actual reader/source contracts.','Unknown semantic domain maps are explicit unknown; no current code/helper purpose inferred from JSON extension. All schema/error exceptions retained.']}
for n,obj in [('lsp-audit-final-role-cohort-schema-index.json',{'schemas':schemas,'scope':'Hash-consed complete nested object key/value-type and array member-shape schemas from every parsed value. Every child hash resolves within this index; every parent/source is bound in progress. Scalar values remain original source bytes, not semantic acceptance.'}),('lsp-audit-final-role-cohort-progress.json',out)]:
 p=R/n;t=p.with_suffix('.tmp');t.write_text(json.dumps(obj,separators=(',',':'),default=str)+'\n');os.replace(t,p);print(n,H(p.read_bytes()),p.stat().st_size)
print(out['counts']);print('unmatched',json.dumps(unmatched)[:2500])
