from pathlib import Path
import json,re,hashlib
D=Path(__file__).parent;H=lambda b:hashlib.sha256(b).hexdigest();load=lambda p:json.loads((D/p).read_bytes());q=load('compiler-root-operational-role-matcher-packet06.json');helpers=[]
def scan(v,receipt):
 if isinstance(v,dict):
  if all(k in v for k in ('path','source_sha256','start_byte','end_byte','full_item_sha256')):helpers.append((v,receipt))
  for z in v.values():scan(z,receipt)
 elif isinstance(v,list):
  for z in v:scan(z,receipt)
for pin in q['helper_receipts']+[{'path':'compiler-helper04-source-review.json','sha256':H((D/'compiler-helper04-source-review.json').read_bytes())}]:
 assert H((D/pin['path']).read_bytes())==pin['sha256'];scan(load(pin['path']),pin)
ls=load('compiler-root-operational-role-matcher-literals.json')['literals'];seen={};cur=None
for i,s in enumerate((D/'compiler-root-operational-role-matcher-packet06.txt').read_text().splitlines(),1):
 m=re.match(r'ACTUAL SOURCE (.+) ([a-f0-9]{64})$',s)
 if m:cur=m[1]
 m=re.match(r'(\d+):',s)
 if m and cur:seen.setdefault(cur,{})[int(m[1])]=i
out=[];missing=[]
for f in q['files']:
 b=Path(f['source']).read_bytes();assert H(b)==f['source_sha256'];starts=[0]+[i+1 for i,c in enumerate(b) if c==10];raw=b.splitlines(keepends=True);hs=[(v,r) for v,r in helpers if v['path']==f['path'] and v['source_sha256']==H(b)];fl=[l for l in ls if l['path']==f['path'] and l['source_sha256']==H(b)];atoms=[]
 for a,z in f['ranges']:
  for line in range(a,z+1):
   x=starts[line-1];y=x+len(raw[line-1]);h=next(((v,r) for v,r in hs if v['start_byte']<=x and y<=v['end_byte']),None);lit=next((l for l in fl if l['start_byte']<=x and y<=l['end_byte']),None)
   role='actual_visible_source_line' if line in seen.get(f['path'],{}) else ('prior_actual_helper' if h else ('projected_literal' if lit else ('whitespace_only' if not raw[line-1].strip() else 'MISSING_NONBLANK')))
   atom={'line':line,'start_byte':x,'end_byte':y,'sha256':H(raw[line-1]),'role':role}
   if role=='MISSING_NONBLANK':
    # Permit source line parts outside actual helper/literal to be whitespace only.
    intervals=[(max(x,v['start_byte']),min(y,v['end_byte'])) for v,r in hs if v['start_byte']<y and x<v['end_byte']]+[(max(x,l['start_byte']),min(y,l['end_byte'])) for l in fl if l['start_byte']<y and x<l['end_byte']]
    mask=bytearray(b[x:y])
    for i,j in intervals:mask[i-x:j-x]=b' '*(j-i)
    if not mask.strip():atom['role']='prior_helper_or_literal_boundary_and_whitespace'
    else:missing.append({'path':f['path'],'source_sha256':H(b),'line':line,'source_line':raw[line-1].decode().rstrip('\n'),'uncovered_bytes':bytes(mask).decode().rstrip('\n')})
   atoms.append(atom)
 out.append({'path':f['path'],'source_sha256':H(b),'ranges':f['ranges'],'line_partition':atoms})
r={'packet_sha256':H((D/'compiler-root-operational-role-matcher-packet06.json').read_bytes()),'files':out,'missing_nonblank':missing,'limits':'Structural lossless scope-line/byte partition; actual read receipts remain independent. No automatic coverage from token processing.'}
p=D/'compiler-root-packet06-partition-check.json';p.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'missing':missing,'files':len(out),'sha256':H(p.read_bytes())}))
