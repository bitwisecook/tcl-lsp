from pathlib import Path
import json,hashlib,datetime,collections
D=Path(__file__).parent
KINDS={
'consumer_api_adoption':'caller_migration','adoption':'caller_migration','consumer_integration':'caller_migration','host_abi_transport':'caller_migration',
'shared_owner_repair':'shared_owner_repair','owner_repair':'shared_owner_repair','shared_owner_extension':'shared_owner_extension','owner_extension':'shared_owner_extension',
'metadata_schema_repair':'metadata_or_target_schema','metadata_schema':'metadata_or_target_schema','descriptor_metadata_target_schema':'metadata_or_target_schema','target_schema':'metadata_or_target_schema','shared_metadata_integration':'metadata_or_target_schema',
'validation_infrastructure':'validation_code_repair','validation_only':'validation_code_repair','validation':'validation_code_repair',
'documentation':'authored_documentation','documentation_cleanup':'authored_documentation','documentation_guidance':'authored_documentation'}
inputs={};rows=[];errs=[]
for area in ['compiler','db','lsp','runtime','vm','root','audit']:
 p=D/f'{area}-migration-units.json'
 if not p.exists():inputs[area]={'status':'MISSING_CANONICAL_CATALOGUE'};continue
 b=p.read_bytes();j=json.loads(b);raw=D/f'{area}-consumers.json';rawsha=hashlib.sha256(raw.read_bytes()).hexdigest();bound=j.get('source_rows_sha256',j.get('source_records_sha256'));us=j.get('units',j.get('code_migration_units',[]));inputs[area]={'path':p.name,'sha256':hashlib.sha256(b).hexdigest(),'raw_sha256':rawsha,'catalogue_bound_raw_sha256':bound,'matches_raw':bound==rawsha,'area_unit_count':len(us),'local_status':j.get('status',j.get('scope'))}
 if bound!=rawsha:errs.append({'area':area,'error':'catalogue/raw capture mismatch'})
 for u in us:
  k=u['work_kind'];kind=KINDS.get(k)
  if not kind:errs.append({'unit':u['id'],'unmapped_work_kind':k})
  rows.append({'area':area,'id':u['id'],'original_work_kind':k,'report_work_kind':kind,'effort':u.get('relative_effort',u.get('effort')),'family':u.get('family_id',u.get('repair_family_id')),'purpose':u.get('purpose',u.get('naming_purpose',u.get('integration_purpose'))),'sites':u['code_change_sites'],'api':u.get('existing_shared_api',u.get('existing_api',u.get('shared_api'))),'required_change':u.get('required_change'),'links':{key:value for key,value in u.items() if any(t in key for t in ['shared_owner','dependency','cross_owner','prerequisite'])}})
for area,name,key in [('runtime','runtime-audit-core-immediate-owner-annex375.json','added_owner_units'),('lsp','lsp-audit-validation-boundary-units.json','validation_boundary_units')]:
 p=D/name;b=p.read_bytes();j=json.loads(b);us=j[key];primary=D/(area+'-migration-units.json');pin=j.get('primary_sha256',j.get('historical_catalogue',{}).get('sha256'))
 actual=hashlib.sha256(primary.read_bytes()).hexdigest()
 inputs[name]={'path':name,'sha256':hashlib.sha256(b).hexdigest(),'area':area,'unit_count':len(us),'primary_sha256':pin,'matches_primary':pin==actual}
 if pin!=actual:errs.append({'area':area,'annex':name,'error':'primary binding mismatch'})
 for u in us:
  k=u['work_kind'];kind=KINDS.get(k)
  if not kind:errs.append({'unit':u['id'],'unmapped_work_kind':k})
  rows.append({'area':area,'id':u['id'],'original_work_kind':k,'report_work_kind':kind,'effort':u.get('relative_effort',u.get('effort')),'family':u.get('family_id',u.get('repair_family_id')),'purpose':u.get('purpose',u.get('canonical_integration_purpose')),'sites':u['code_change_sites'],'api':u.get('existing_shared_api',u.get('current_owner_or_api')),'required_change':u.get('required_change'),'links':{'source_annex':name,'source_sha256':inputs[name]['sha256']}})
# Immutable Runtime post-seal split replaces one mixed-purpose adapter with
# the two actual selected seek/puts boundaries, preserving historical inputs.
p=D/'runtime-audit-channel-adapter-split376.json';b=p.read_bytes();j=json.loads(b)
primary=D/'runtime-migration-units.json';actual=hashlib.sha256(primary.read_bytes()).hexdigest()
assert j['historical374']['sha256']==actual
withdrawn=set(j['withdrawn_effective_unit_ids']);matched=[r for r in rows if r['id'] in withdrawn]
assert len(matched)==len(withdrawn)
rows=[r for r in rows if r['id'] not in withdrawn]
inputs[p.name]={'path':p.name,'sha256':hashlib.sha256(b).hexdigest(),'primary_sha256':actual,'withdrawn_effective_unit_ids':sorted(withdrawn),'added_unit_count':len(j['added_replacement_units']),'matches_primary':True}
for u in j['added_replacement_units']:
 k=u['work_kind'];kind=KINDS[k]
 rows.append({'area':'runtime','id':u['id'],'original_work_kind':k,'report_work_kind':kind,'effort':u.get('relative_effort',u.get('effort')),'family':u.get('family_id',u.get('repair_family_id')),'purpose':u.get('purpose',u.get('canonical_integration_purpose')),'sites':u['code_change_sites'],'api':u.get('existing_shared_api',u.get('current_owner_or_api')),'required_change':u['required_change'],'links':{'source_annex':p.name,'source_sha256':inputs[p.name]['sha256']}})
# Immutable source-coordinate corrections retain the sealed area catalogues.
for area in ['root','db']:
 p=D/(area+'-final-source-anchor-correction-annex.json')
 if not p.exists(): continue
 b=p.read_bytes();j=json.loads(b);primary=D/j['primary_catalogue']
 assert hashlib.sha256(primary.read_bytes()).hexdigest()==j['primary_sha256']
 assert j['count_change']==0
 inputs[p.name]={'path':p.name,'sha256':hashlib.sha256(b).hexdigest(),'primary_sha256':j['primary_sha256'],'count_change':0,'corrected_sites':len(j['corrections'])}
 for c in j['corrections']:
  unit=next(r for r in rows if r['id']==c['unit_id'])
  ix=[i for i,x in enumerate(unit['sites'])if x['path']==c['old_site']['path'] and x['line']==c['old_site']['line']]
  assert len(ix)==1,(c['unit_id'],ix)
  unit['sites'][ix[0]]=c['new_site']
  unit['links'].setdefault('source_anchor_correction_annexes',[]).append({'path':p.name,'sha256':inputs[p.name]['sha256'],'original_site':c['old_site']})
ids=[r['id'] for r in rows]
if len(ids)!=len(set(ids)):errs.append({'error':'duplicate cross-area IDs'})
o={'baseline':'cc24c394004fc187378ba0eefb6c2c5b2615fb00','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'HASH_BOUND_REVIEW_INPUT_ONLY','count_contract':'Actual changed integration boundary plus distinct purpose. Genuine missing semantic owner facet once; actual changed callers separate; unchanged dependencies not migrations. Implementation, validation repairs, existing unexecuted validation and docs separate.','inputs':inputs,'units':rows,'mechanical_binding_errors':errs,'missing_lanes':[a for a,j in inputs.items() if j.get('status')=='MISSING_CANONICAL_CATALOGUE'],'repository_remaining_total':None,'semantic_join_complete':False,'source_role_closure_complete':False,'limit':'No count acceptance from arithmetic or equal family labels. Primary explicit semantic owner/adopter join and exact source-role closure required before final report. Required original validation remains separate after source audit.'}
p=D/'root-global-reconciliation-input.json';p.write_text(json.dumps(o,indent=2)+'\n');print(json.dumps({'source_bound_lanes':list(inputs),'missing_lanes':o['missing_lanes'],'binding_errors':errs,'semantic_join_complete':False,'remaining_total':None}))
