from pathlib import Path
import json,hashlib,re,datetime
P=Path('/workspace/name-session/full-consumer-audit');H=lambda b:hashlib.sha256(b).hexdigest()
prior=P/'runtime-compiler-operational04-source-review.json';pb=prior.read_bytes();assert H(pb)=='15445f6272a935df6de122e062b21cc4011fb5f450c256f86373ccff0afa8ebc';old=json.loads(pb)
r=json.loads((P/old['reservation']['path']).read_text());progress=json.loads((P/old['progress']['path']).read_text());parts={x['path']:x for x in old['files']}
aid=(P/r['aid']).read_bytes();assert H(aid)==r['aid_sha256'];visible={};path=None
for aidrow,s in enumerate(aid.decode().splitlines(),1):
 if s.startswith('ACTUAL SOURCE '):path=s.split()[2];visible[path]=[]
 elif path and re.match(r'^\d+: ',s):n,text=s.split(': ',1);visible[path].append((aidrow,int(n),text))
files=[];coordinate_files=[];mapped=0;shifted=0;total=0;exact_remaining_bytes=0
for f in r['files']:
 b=Path(f['source']).read_bytes();assert H(b)==f['source_sha256'];mask=bytearray(b)
 intervals=[x for x in parts[f['path']]['partition']if x['role']in ('actual_exact_peer_helper_item','exact_literal_parent_role')]
 for x in intervals:
  for i in range(x['start_byte'],x['end_byte']):
   if mask[i]!=10:mask[i]=32
 # Do NOT insert labels: original builder overwrote literal-internal LF bytes
 # when a label was longer than the opening physical line. Those LF bytes are
 # fixed literal data, but shifted subsequent printed line labels.
 placeholder=re.compile(r'\bL(?:'+ '|'.join(str(x) for x in f['projected_literal_ordinals']) +r')\b') if f['projected_literal_ordinals'] else None
 # Deliberately independent physical-LF traversal: no splitlines reconstruction.
 raw_lines=b.split(b'\n');masked_lines=bytes(mask).split(b'\n');offset=0;expected=[];physical_spans=[]
 for n,(line,ml)in enumerate(zip(raw_lines,masked_lines),1):
  end=offset+len(line);physical_spans.append((offset,min(end+1,len(b))))
  if any(a<=n<=z for a,z in f['ranges'])and ml.strip():expected.append((n,offset,end,ml.decode().strip()))
  offset=end+1
 actual=[(row,printed,placeholder.sub(lambda m:' '*len(m.group()),text).strip() if placeholder else text)for row,printed,text in visible[f['path']]];actual=[x for x in actual if x[2]];assert len(expected)==len(actual),(f['path'],'unmapped nonblank source',len(expected),len(actual))
 mapping=[];drift=[]
 for (n,a,z,text),(row,printed,seen)in zip(expected,actual):
  assert text==seen,(f['path'],n,row,'actual nonblank source remainder absent or changed')
  mapping.append([n,a,z,row,printed]);mapped+=1
  if n!=printed:drift.append([n,row,printed]);shifted+=1
 # Physical LF requested bounds, clipped only at authentic EOF for whole files.
 spans=[]
 for a,z in f['ranges']:
  assert a<=len(physical_spans),(f['path'],'start beyond EOF')
  spans.append((physical_spans[a-1][0],physical_spans[min(z,len(physical_spans))-1][1]))
 cuts=[]
 for sa,sz in spans:
  points=sorted({sa,sz}|{max(sa,min(sz,v))for x in intervals for v in [x['start_byte'],x['end_byte']]})
  for a,z in zip(points,points[1:]):
   cover=[x for x in intervals if x['start_byte']<=a and z<=x['end_byte']]
   role=min(cover,key=lambda x:x['bytes'])['role']if cover else 'actual_visible_remaining_source_or_inert_whitespace'
   cuts.append([a,z,role]);total+=z-a
   if not cover:exact_remaining_bytes+=z-a
 assert sum(z-a for a,z,role in cuts)==sum(z-a for a,z in spans)
 files.append({'path':f['path'],'source_sha256':f['source_sha256'],'requested_physical_lf_byte_ranges':spans,'exact_nonblank_original_lf_to_actual_aid_mapping_schema':['original_physical_lf_line','original_start_byte','original_end_byte_exclusive_without_LF','actual_aid_row','printed_projection_line_label'],'mapping':mapping,'mapping_sha256':H(json.dumps(mapping,separators=(',',':')).encode()),'byte_partition_schema':['start_byte','end_byte_exclusive','role'],'byte_partition':cuts,'unexamined_bytes':0,'omitted_nonblank_original_contents':0,'printed_line_coordinate_drift_count':len(drift)})
 if drift:coordinate_files.append({'path':f['path'],'source_sha256':f['source_sha256'],'drift_count':len(drift),'reason':'Projection placeholder labels overwrite literal-internal LF when an opening physical line is short; original physical LF coordinate differs. Ordered exact nonblank source contents remain visible and actually read. Use original-byte mapping, never printed projection labels as original anchors.'})
missing=json.loads((P/'runtime-compiler-operational04-independent-gap-check.json').read_text())['missing']
correction={'baseline':r['baseline'],'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'COMPLETE_INDEPENDENT_ORIGINAL_PHYSICAL_LF_BYTE_ROLE_CORRESPONDENCE','supersedes_closure_proof_not_actual_read':{'path':prior.name,'sha256':H(pb),'correction':'Prior closure reconstructed the original projection; that alone did not independently prove every original nonblank source line. This successor checks exact ordered original physical-LF remainders against each actually read aid row, independently of builder splitlines numbering. Historical receipt unchanged.'},'reservation':old['reservation'],'aid':old['actual_read'],'helper_receipts':old['helper_receipts'],'literal_roles':old['progress'],'counts':{'paths':len(files),'requested_physical_lf_bytes':total,'mapped_original_nonblank_lines':mapped,'shifted_printed_line_coordinates':shifted,'coordinate_drift_files':len(coordinate_files),'raw_supplement_actual_read_lines':len(missing),'omitted_nonblank_contents':0,'unexamined_bytes':0,'integrity_errors':0},'coordinate_drift_files':coordinate_files,'raw_supplement_actual_read':{'path':'runtime-compiler-operational04-independent-gap-check.json','sha256':H((P/'runtime-compiler-operational04-independent-gap-check.json').read_bytes()),'status':'All80 initially flagged raw lines actually reread in full; source constructors/calls/assertions/comments/braces retained as prior bounded parent purposes. These flags were coordinate differences, not missing aid contents.'},'files':files,'questions':old['questions'],'limits':old['limits']+['Printed projection line labels in three files are not original source anchors. Exact physical LF/byte-to-aid correspondence in this successor governs. No original nonblank executable/assertion source is exempted by test membership.']}
O=P/'runtime-compiler-operational04-source-coordinate-correction.json';raw=(json.dumps(correction,separators=(',',':'),ensure_ascii=False)+'\n').encode();t=O.with_suffix('.json.tmp');t.write_bytes(raw);t.replace(O);print(json.dumps({'path':O.name,'sha256':H(raw),'counts':correction['counts'],'drift_files':coordinate_files}))
