import json,pathlib,hashlib,subprocess,collections,datetime,runpy,re
B=pathlib.Path('/workspace/name-session/full-consumer-audit');R=pathlib.Path('/workspace/tcl-lsp');x=runpy.run_path(str(B/'audit-review-tools.py'));c,s=x['load']();by={r['path']:r for r in c['files']};errors=[];drift=[];cache={};seen=set()
for z in s['consumers']:
 p=z['path'];r=by.get(p)
 if not r:errors.append(['foreign-path',p]);continue
 if z['id'] in seen:errors.append(['duplicate-id',z['id']])
 seen.add(z['id'])
 if z['source_sha256']!=r['source_sha256'] or z['blob']!=r['blob']:errors.append(['source-reference',z['id']])
 if p not in cache:
  d=x['content'](r);cache[p]=d
  if hashlib.sha256(d).hexdigest()!=r['source_sha256']:errors.append(['baseline-sha',p])
 if not 1<=z['line']<=len(cache[p].decode().splitlines()):errors.append(['line',z['id'],z['line']])
 if z['disposition'] not in {'needs_migration','migrated_validation_pending','migrated_verified','shared_owner','display_only','out_of_scope'}:errors.append(['disposition',z['id']])
for r in c['files']:
 if r['review_mode'].startswith('whole_'):
  d=cache.get(r['path'])
  if d is None:d=x['content'](r);cache[r['path']]=d
  if hashlib.sha256(d).hexdigest()!=r['source_sha256']:errors.append(['baseline-sha',r['path']])
  w=R/r['path']
  if not w.is_file() or hashlib.sha256(w.read_bytes()).hexdigest()!=r['source_sha256']:drift.append(r['path'])
 for cid in r['consumer_ids']:
  if cid not in seen:errors.append(['dangling-file-consumer',r['path'],cid])
q={'baseline':c['baseline'],'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':len(c['files']),'modes':dict(collections.Counter(r['review_mode'] for r in c['files'])),'purpose_rows':len(s['consumers']),'dispositions':dict(collections.Counter(r['disposition'] for r in s['consumers'])),'errors':errors,'whole_review_current_worktree_drift':drift,'scope':'Artifact consistency and exact original baseline-byte source correspondence only; no source compilation/provider/generator execution, semantic uniqueness or runtime acceptance.'};(B/'audit-artifact-qa.json').write_text(json.dumps(q,indent=2)+'\n')
known={
 'rust/tcl-bigip-query/src/architecture.rs':('actual_inline_setup_read','Both tests use actual in-memory JSON and static authored source through shared lexer; all bodies/helpers read, no process/env/fs/provider setup.'),
 'rust/tcl-bigip/src/apl/parser.rs':('actual_inline_setup_read','Both test bodies/helpers and actual include_str20line sample read. Compile-time source fixture only; no process/env/fs/provider setup.'),
 'rust/tcl-bigip/src/apl/tokens.rs':('actual_inline_setup_read','All15 test bodies/helpers and actual include_str112line sample read; in-memory lexing/nonoverlap checks, no external process/env/fs/provider setup.'),
 'rust/tcl-bigip-query/src/builtins/f5profile.rs':('actual_inline_setup_read','All7 tests actual in-memory profile maps/values/static shared registry setup; no Command/env/fs/provider process.'),
 'rust/tcl-bigip-query/src/builtins/value2.rs':('actual_inline_setup_read','Both tests actual typed values and assertions only.'),
 'rust/tcl-bigip/src/flow/sessions.rs':('actual_inline_setup_read','All4 tests actual in-memory Flow/IndexMap construction/pairing assertions.'),
 'rust/tcl-bigip/src/flow/tshark.rs':('actual_inline_setup_read','All6 tests actual JSON/Flow maps only; external production Command worker not reached by test calls.'),
 'rust/tcl-bigip-query/src/special.rs':('actual_inline_operational_setup_read','Two tests/helpers read; deep test actually spawns std::thread Builder256MiB stack and joins worker. Unexecuted; not classified pure.'),
 'rust/bigip-report-gen/rust/src/lifecycle.rs':('actual_inline_setup_read','All3 tests actual static date/assertion data; production current clock not called.'),
 'rust/bigip-report-gen/rust/src/enrich.rs':('actual_inline_setup_read','Both tests actual in-memory JSON/network-annotation calculation.'),
 'rust/bigip-report-gen/rust/src/tls.rs':('actual_inline_operational_setup_read','Both tests read; multi-SNI test invokes actual shared parser/TLS importer/embedded trust dataset. Operational internal provider setup; no fresh execution.')}
rows=[]
for r in c['files']:
 if r['review_mode']!='whole_production_read' or not r['path'].endswith('.rs'):continue
 d=cache[r['path']].decode();markers=[i for i,t in enumerate(d.splitlines(),1) if '#[test]' in t or '#[tokio::test]' in t or '#[cfg(test)]' in t]
 if not markers:continue
 status,reason=known.get(r['path'],('operational_classification_unresolved','Production source review retained independently. Prior extent/test notes may record body reads, but #[test] or absence of lexical Command matches does not establish purity; actual operational setup/guards require explicit body-evidence classification.'))
 rows.append({'path':r['path'],'blob':r['blob'],'source_sha256':r['source_sha256'],'markers':markers,'marker_mode':'lexical inventory only, not test-body/operational proof','status':status,'reason':reason,'existing_review_extent':r.get('reviewed_production_extent'),'existing_test_notes':r.get('tests'),'validation':'No test executed by audit.'})
out={'baseline':c['baseline'],'created_utc':q['checked_utc'],'scope':'Inline test/harness operational review annex for fully production-read Rust paths. Explicit unresolved statuses remain unfinished; not all test functions are pure, not a count of consumers or tests executed. External test files remain their own unexamined coverage rows.','files':rows,'summary':dict(collections.Counter(z['status'] for z in rows))};(B/'audit-inline-operational-census.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'whole':q['modes'].get('whole_production_read'),'rows':q['purpose_rows'],'errors':len(errors),'drift':drift,'inline_operational':out['summary']}))
