import json,pathlib,datetime,collections
B=pathlib.Path('/workspace/name-session/full-consumer-audit');s=json.loads((B/'audit-consumers.json').read_text());p=B/'audit-consumer-repair-groups.json';old=json.loads(p.read_text());prior={r['consumer_id']:r for r in old['rows']};out=[]
mp={
 ('web.py','_parse_multipart'):('shared_grammar_owner_repair','shared:report-multipart-original-source-transport'),
 ('graph.py','_split_rd'):('integration_site','integration:report-typed-route-domain-admission'),
 ('graph.py','parse_listener'):('integration_site','integration:report-positive-listener-typed-state'),
 ('graph.py','_pattern_matches'):('integration_site','integration:report-shared-conditional-attach-pattern'),
 ('graph.py','pattern_reaches'):('integration_site','integration:report-shared-conditional-attach-pattern'),
 ('graph.py','build_rule_contexts'):('integration_site','integration:bigip-contextual-object-reference-policy'),
 ('graph.py','attach_matches'):('integration_site','integration:report-orphan-source-closure'),
 ('graph.py','_resolve_rule'):('integration_site','integration:bigip-contextual-object-reference-policy'),
 ('graph.py','irule_dynamic_actions'):('integration_site','integration:report-original-effect-source-inventory'),
 ('graph.py','build_graph'):('integration_site','integration:report-kind-scoped-member-association'),
 ('graph.py','_split_monitors'):('integration_site','integration:report-actual-monitor-expression-owner'),
 ('report.py','_default_object_paths'):('integration_site','integration:archive-member-default-object-provenance'),
 ('report.py','_clean_path'):('integration_site','integration:report-original-reference-value'),
 ('report.py','_split_dest'):('integration_site','integration:report-typed-endpoint-before-display'),
 ('model.rs','split_dest'):('integration_site','integration:report-typed-endpoint-before-display'),
 ('report.py','_shape_rule'):('integration_site','integration:report-original-event-source-inventory'),
 ('report.py','_device_name'):('integration_site','integration:report-selected-hostname-metadata'),
 ('render.py','_TOPO_TYPES'):('shared_metadata_integration','integration:report-topology-legend-schema'),
 ('architecture.rs','tcl_commands'):('integration_site','integration:architecture-literal-word-source-value'),
 ('parser.rs','find_brace_end'):('shared_grammar_owner_repair','shared:apl-structural-source-geometry'),
 ('parser.rs','name_range'):('integration_site','integration:apl-original-utf16-name-extent'),
 ('parser.rs','parse_fields_in_block'):('shared_owner_repair','shared:apl-declaration-type-attribute-metadata'),
 ('tokens.rs','embedded_tcl_regions'):('integration_site','integration:apl-configured-tcl-body-geometry'),
 ('generate-certificate-ucs.py','generate'):('validation_setup_gap','validation:certificate-openssl-config-path-source'),
 ('projection.rs','stanza_slot_for'):('integration_site','integration:query-source-byte-edit-geometry'),
 ('projection.rs','collect_field_slots'):('integration_site','integration:query-source-byte-edit-geometry'),
 ('projection.rs','iter_top_level_scalar_slots'):('shared_grammar_owner_repair','shared:bigip-original-property-geometry'),
 ('projection.rs','parse_scalar_slot_line'):('shared_grammar_owner_repair','shared:bigip-original-property-geometry'),
 ('projection.rs','brace_depth_after_line'):('shared_grammar_owner_repair','shared:bigip-original-property-geometry'),
 ('projection.rs','Container::lookup'):('integration_site','integration:bigip-contextual-object-reference-policy'),
 ('projection.rs','path_ref'):('integration_site','integration:query-pathref-origin-context'),
 ('projection.rs','resolve_pathref'):('shared_owner_repair','shared:query-unsupported-projection-distinction'),
 ('edit_plan.rs','apply_identity_rename'):('integration_site','integration:query-writable-field-identity-role'),
 ('f5profile.rs','order_profiles_with_types'):('integration_site','integration:bigip-contextual-object-reference-policy'),
 ('extras.rs','bi_env'):('integration_site','integration:query-os-string-value-admission'),
 ('packets.rs','split_http_headers'):('shared_owner_repair','shared:packet-octet-simulation-value-projection'),
 ('packets.rs','peek_http'):('shared_owner_repair','shared:packet-octet-simulation-value-projection'),
 ('tshark.rs','run_tshark'):('shared_owner_repair','shared:tshark-execution-and-decoding-outcome'),
 ('tshark.rs','enrich_with_tshark'):('integration_site','shared:tshark-execution-and-decoding-outcome'),
 ('tshark.rs','extract_flows_via_tshark'):('integration_site','shared:tshark-execution-and-decoding-outcome'),
 ('editor.ts','reportId'):('integration_site','integration:report-authored-manifest-source-association')}
for z in s['consumers']:
 if z['disposition']!='needs_migration':continue
 a=prior.get(z['id'],{'consumer_id':z['id'],'path':z['path'],'symbol':z['symbol'],'purpose':z['purpose'],'source_sha256':z['source_sha256'],'finding_kind':'integration_site','repair_group':z['id'],'known_production_reachability':'See exact actual caller/input evidence on consumer row; not inferred from lexical source match.','validation':'No baseline execution accepted.'})
 k=(pathlib.Path(z['path']).name,z['symbol'])
 if k in mp:a['finding_kind'],a['repair_group']=mp[k]
 if z['path'].endswith('/report.py') and z['symbol']=='_collect_device':
  a['repair_group']='integration:report-orphan-source-closure' if 'confirmed orphan' in z['purpose'] else 'integration:bigip-contextual-object-reference-policy'
 if z['symbol']=='render' and '/gen_bundled_environments.rs' in z['path']:a['finding_kind']='proof_gate_metadata_repair';a['repair_group']='proof:bundled-environment-complete-load-status'
 if z['symbol']=='run' and '/pack_goldens.rs' in z['path']:a['finding_kind']='proof_gate_metadata_repair';a['repair_group']='proof:pack-golden-complete-orphan-inventory'
 out.append(a)
old.update(updated_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),rows=out,summary={'purpose_rows':len(out),'finding_kind':dict(collections.Counter(r['finding_kind'] for r in out)),'not_a_remaining_consumer_total':'Groups coordinate distinct purposes; no semantic defect or repository-wide/live-remaining count inferred.'});p.write_text(json.dumps(old,indent=2)+'\n');print(old['summary'])
