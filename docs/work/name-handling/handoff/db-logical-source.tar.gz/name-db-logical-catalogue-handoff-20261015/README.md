# Unadopted Logical direct-call catalogue work

This packet is scratch work, not a production change or passing validation.
Root is the sole adopter/build owner. The user requested status, a push and a
continuation prompt; no further production adoption was authorised for this
checkpoint. Main source238 includes the separately reviewed Parent/Text fixes.

The actual ordinary265 DB result is 63 PASS and 13 FAIL across all 76 retained
selectors, with four gains and no prior PASS regressions against258. Source,
binary, exact-once, missing/empty and timeout guards passed. TEMP270 was still
in flight when this packet was sealed; its eventual exact logs and full source
restoration receipt must be read before claiming any new diagnosis.

## Contents

- `implementation.patch` is the sealed three-file shared catalogue facade,
  SHA256 `9b4b21b179172d33b1dffc9126b9822f04bf138d8032c00e7f563b9faac1a6d8`.
- `manifest.json` is the unchanged original sealed manifest, SHA256
  `c06c2a7eed6425cbe0e97991552994a6bbe645923d3690a13494102d4d570afe`.
  Its original `/tmp` paths are historical scratch locations; all required
  files are carried here at the same relative paths.
- `before/` holds exact original source preimages, including the DB preimage
  for the separate consumer draft. Do not overwrite current source with them.
- `consumer-draft/rust/tcl-lsp-db/src/lib.rs` is a complete, unready DB draft,
  SHA256 `8314ca5e8dd71d9958232f9f970c0319251937ad432fde5c1483da231977776a`.
  It is NOT included in `implementation.patch` and has no final source peer.
- `design-original.json` is the earlier design, superseded where this README
  states the stronger source-occupancy requirement.
- `reviews/temp3b29-lsp.json` approves only the separate temporary logger's
  source/control flow, not this production facade or consumer.

## Genuine owner and remaining work

`project_source_diagnostics_for_analysis` currently inventories Logical direct
calls from `AnalysisResult::unresolved_command_sites`. That ledger is populated
by independently selected Absent/W123 lookup evidence. It cannot inventory all
conditional Logical source calls.

The facade reuses existing immutable `logical_navigation` tape receipts by
actual map key through `logical_navigation_at`, the current complete-input/
image/configuration Realm cache, and the common Logical source-context join.
It introduces no namespace/frame owner. Its result is partial: unavailable
commands, method frames and grammar are omitted, and an empty result proves
neither a command census nor absence. A new fixed Compiler control checks
original per-occurrence equality, namespace distinctions and source/input/
configuration refusal. Scratch rustfmt passed; Cargo and tests were not run.

The consumer draft is intentionally incomplete. Before strict external project
arity, a separate genuine source-selected occupancy/applicability facet must
preserve terminality for an actual selected builtin, local declaration, alias
or other stronger source state. Readonly coordinate candidates alone cannot
replace those owners. Compiler identifies actual `AdviceGraph::cells`,
`lookup_head_key`, `resolve` and `blocks_registry_source` as the relevant owner.
A Registry lookup by spelling is insufficient. Missing graph representation
means unknown, never command absence. Do not restore the Absent-ledger gate.

Read actual TEMP270 DB4 applicability traces first. Then finish and peer the
combined typed owner and consumer; preserve earlier-unknown mutation, current
operand effects, exact original words/head/cardinality, ordered first-occupied
project slots, complete source/header configuration, and independent Native
terminal purposes. Missing project data must never create W123. Preserve all
original assertions, cache counts, Arc checks and all76 DB replay selectors.
The new root/missing-namespace fixture's W123 premise remains unresolved; do
not weaken its assertion or fabricate an absence witness.

Compiler independently owns a narrow variable-scope projection on the same
`logical_navigation.rs` file. Compose exact hunks with its actual final
preimages, never copy an older complete afterimage over its changes. The
shared facade's LSP source peer was requested but remained pending when this
packet was sealed. No production or acceptance approval is implied.

The actual Compiler source-input/child declaration-site issue is separate:
`module_original_words=false` in TEMP267 was the whole original metadata API
returning None, not evidence of missing word bytes. Compiler's71af source
recipe and d89 issuer trace own that investigation. Authored readonly coverage
preserves separate Authored and Installed inventories; it does not deduplicate
or convert Installed authority.
