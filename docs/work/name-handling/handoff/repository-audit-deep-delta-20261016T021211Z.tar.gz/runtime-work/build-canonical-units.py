from record import *
import runpy
C=runpy.run_path(str(ROOT/'runtime-work/canonical-decisions.py'))
FAMILIES,MERGES,KIND_OVERRIDES,EXTERNAL_SHARED_REPAIRS=[C[k] for k in ['FAMILIES','MERGES','KIND_OVERRIDES','EXTERNAL_SHARED_REPAIRS']]
from collections import Counter
from datetime import datetime,timezone
import re

def key(r):return r['path']+'::'+r['symbol']+'::'+r['site']
d=load();rows=d['consumers'];mapped={};units=[];family_rows=[];decided=set()
for family,effort,indices in FAMILIES:
 ids=[]
 for index in indices:
  assert index not in decided,(index,family);decided.add(index);r=rows[index];assert r['disposition']=='needs_migration',(index,r['symbol'],r['disposition']);originals=[index]+MERGES.get(index,[])
  for other in originals[1:]:assert rows[other]['disposition']=='needs_migration';assert rows[other]['path']==r['path'] and rows[other]['line']==r['line'];decided.add(other)
  kind=KIND_OVERRIDES.get(index,{'consumer_integration':'consumer_api_adoption','owner_extension':'shared_owner_repair','descriptor_metadata_or_target_schema':'metadata_schema','validation_only':'validation_infrastructure'}[r['work_kind']])
  uid='runtime:'+family+':'+str(index);ids.append(uid);sites=[]
  for i in originals:
   q=rows[i];s={'path':q['path'],'symbol':q['symbol'],'line':q['line'],'source_line':(SRC/q['path']).read_text().splitlines()[q['line']-1],'semantic_anchor':q['site'],'source_sha256':q['sourceSHA']}
   if not any(z['path']==s['path'] and z['line']==s['line'] for z in sites):sites.append(s)
  u={'id':uid,'source_owner':'runtime','work_kind':kind,'family_id':family,'purpose':r['symbol'],'code_change_sites':sites,'representation_and_context':r['context'],'existing_shared_api':r['sharedAPI'],'required_change':r['missingintegration'],'source_evidence':r['evidence'],'original_row_ids':[key(rows[i]) for i in originals],'original_indices':originals,'relative_effort':effort,'state':'source_confirmed_change_required_unimplemented','control_obligations':r['tests'] or ['Preserve original selectors/assertions/budgets and fail-closed source/provider/artifact guards. Exact original constructor/caller/frame/namespace/key/currentness/lifetime purpose must be tested before semantic acceptance.'],'affected_unchanged_callers':[],'limitations':'Explicit source-purpose proposal; not execution or migration acceptance. Family groups related shared owners, units retain actual separately changed boundaries; no duration implied.'}
  if family in ['metadata.generated-identifier-scaffold','report.selected-command-variable-qualification']:u['control_obligations']=['Preserve actual selected counter/home/token/generation/lifecycle independently of rendered bytes; shared construction/report serializer parity and source configuration controls.']+r['tests']
  if r.get('native_gap_countable') is False:u['native_gap_countable']=False
  if index==132:u['deduplication_reason']='Rows132/852 are exact same state_traits1370 namespace-variable report constructor; no second repair.'
  if index==65:u['scope_note']='Existing Unicode Env/Filesystem/Process interfaces may remain purpose-limited; add actual OS/selected encoding facets only for genuine Native consumers. Provider adapters and original executable lifetime remain separate actual sites; no blanket Unicode-wrapper rewrite.'
  if index==6:u['affected_source_methods']=['exists','metadata','symlink_metadata','read','write','rename','copy','link','set_times'];u['scope_note']='One NativeFs actual native-path producer facet; listed Unicode methods are existing extension seams, not nine independently proved Native encoding recipes or nine owner repairs.'
  if kind=='validation_infrastructure':u['control_obligations']=['Genuine fresh/context/ownership discriminator and unchanged independent original observations; no source-only setup success or process0-to-Guest success inference.']+r['tests']
  units.append(u)
  for i in originals:mapped[key(rows[i])]={'row_index':i,'canonical_state':'requires_code_change','unit_ids':[uid]}
 family_rows.append({'id':family,'unit_ids':ids,'relative_scope':effort})
# Individually reviewed mixed source rows expand into actual distinct boundaries.
SPLITS=runpy.run_path(str(ROOT/'runtime-work/canonical-splits.py'))['SPLITS']
SPLITS.update(runpy.run_path(str(ROOT/'runtime-work/canonical-splits04.py'))['SPLITS'])
expanded=[]
for u in units:
 index=u['original_indices'][0]
 if index not in SPLITS:expanded.append(u);continue
 ids=[]
 for suffix,purpose,kind,site_inputs,requirement,family in SPLITS[index]:
  v=dict(u);v.update(id=u['id']+':'+suffix,purpose=purpose,work_kind=kind,family_id=family,required_change=requirement,code_change_sites=[],split_from_original_row=index,scope_note='Distinct actual changed source boundary; shared descriptor/transport owner requirements still separate. Source-only proposal, no final count.');ids.append(v['id'])
  for path,line in site_inputs:
   raw=(SRC/path).read_bytes();v['code_change_sites'].append({'path':path,'line':line,'symbol':purpose,'source_line':raw.decode().splitlines()[line-1],'source_sha256':hashlib.sha256(raw).hexdigest(),'semantic_anchor':raw.decode().splitlines()[line-1].strip()})
  v['source_evidence']=u['source_evidence']+['runtime-work/canonical-splits.py: exact pinned per-purpose source-site recheck; no tests executed']
  expanded.append(v)
 for original in u['original_indices']:mapped[key(rows[original])]['unit_ids']=ids
units=expanded
# Explicit owner-facet and concrete adapter reconciliation; no inferred API authority.
FACET_DATA=runpy.run_path(str(ROOT/'runtime-work/canonical-owner-facets.py'))
for index,inputs in FACET_DATA['EXTRA_SITES'].items():
 for u in units:
  if u['original_indices'][0]!=index:continue
  for path,line in inputs:
   raw=(SRC/path).read_bytes();text=raw.decode();site={'path':path,'line':line,'symbol':u['purpose'],'source_line':text.splitlines()[line-1],'source_sha256':hashlib.sha256(raw).hexdigest(),'semantic_anchor':text.splitlines()[line-1].strip()}
   if not any(z['path']==path and z['line']==line for z in u['code_change_sites']):u['code_change_sites'].append(site)
  u['scope_note']='Existing owner declaration/producer sites are explicit. Ordinary Unicode APIs and unheaded object interfaces remain independently valid; concrete new adapters are separately counted. Source-only proposal pending semantic peer.'
for f in FACET_DATA['FACETS']:
 origins=f['rows'];uid='runtime:'+f['family']+':facet-'+f['suffix'];sites=[]
 for path,line in f['sites']:
  raw=(SRC/path).read_bytes();line_text=raw.decode().splitlines()[line-1];sites.append({'path':path,'line':line,'symbol':f['purpose'],'source_line':line_text,'semantic_anchor':line_text.strip(),'source_sha256':hashlib.sha256(raw).hexdigest()})
 u={'id':uid,'source_owner':'runtime','work_kind':f['kind'],'family_id':f['family'],'purpose':f['purpose'],'code_change_sites':sites,'representation_and_context':'Existing selected actual provider/engine/entered invocation; exact original operands and current physical context are required independently of Unicode data/report APIs. '+f['purpose'],'existing_shared_api':f['api'],'required_change':f['change'],'source_evidence':['Full pinned production source admission; runtime-work/canonical-owner-facets.py bounded actual declaration/caller recheck. Root50 category peer requires missing owners and actual adapters to be counted separately. No execution.'],'original_row_ids':[key(rows[i]) for i in origins],'original_indices':origins,'relative_effort':f['effort'],'state':'source_confirmed_change_required_unimplemented','control_obligations':[],'affected_unchanged_callers':['Ordinary Unicode name/source and head-excluded argument APIs retain their existing purposes. Default unsupported entries remain refused unless a genuine selected producer exists; no blanket rewrite of every implementor.'],'limitations':'Derived actual missing facet or changed adapter, not an additional raw-source observation and not implementation/provider acceptance. Bounded semantic peer pending.','category_review':{'canonical_work_kind':f['kind'],'decision_reason':f['change'],'state':'explicit_actual_owner_adapter_reconciliation_pending_independent_peer'}}
 units.append(u)
 for i in origins:
  m=mapped[key(rows[i])];assert m['canonical_state']=='requires_code_change';m['unit_ids'].append(uid)
# Exact family IDs group one shared requirement; repeated source declaration rows
# never create multiple family records.
family_map={}
for u in units:family_map.setdefault(u['family_id'],[]).append(u['id'])
family_rows=[{'id':family,'unit_ids':ids,'relative_scope':'Explicit per-unit S/M/L/XL scope; family membership is not a patch or completion count.'} for family,ids in family_map.items()]
category_file=ROOT/'runtime-work/canonical-owner-category-review.json'
category_reviews={x['row']:x for x in json.loads(category_file.read_text())['interpretations']} if category_file.exists() else {}
for u in units:
 index=u['original_indices'][0]
 if index in category_reviews and 'category_review' not in u:u['category_review']=dict(category_reviews[index])
 if index==604:u['category_review'].update(canonical_work_kind='shared_owner_repair',subsequent_peer_correction='root-runtime-category-peer.json SHA3c2124aa: reference checked_add is not epoch issuance; actual cell epoch owner repair remains required.')
 # Existing named controls remain source references only. Generic future guard
 # requirements must not be presented as retained/executed exact selectors.
 u['retained_control_references']=rows[index]['tests'];u['control_obligations']=[]
 u['required_validation_purpose']=u['representation_and_context']+' Genuine actual original provider/context/getter/constructor/currentness/lifetime controls required; selector/evidence not supplied here unless listed separately.'
 u['validation_claim']='No execution or original-provider semantic acceptance donated by this source/canonical proposal.'
# Independently challenged actual boundaries; precise unresolved findings remain open.
DB_REVIEW=json.loads((ROOT/'runtime-work/db-runtime-canonical01-admission.json').read_text())
for u in units:
 hit=next((x for x in DB_REVIEW['reviews'] if x['row']==u['original_indices'][0]),None)
 if hit:
  u['independent_boundary_review']=hit
  if hit['peer_verdict']=='bounded_current_boundary_supported':u['category_review']={'canonical_work_kind':u['work_kind'],'decision_reason':hit['recommendation'],'state':'bounded_exact_source_boundary_admitted_no_execution'}
  elif hit['peer_verdict']=='classification_correction_shared_owner_repair':u['category_review']={'canonical_work_kind':u['work_kind'],'decision_reason':hit['recommendation'],'state':'actual_shared_owner_kind_corrected_epoch_or_additional_caller_reconciliation_may_remain'}
runpy.run_path(str(ROOT/'runtime-work/canonical-final-reconciliations.py'))['apply'](units,mapped,decided,rows,key,SRC)
family_map={}
for u in units:family_map.setdefault(u['family_id'],[]).append(u['id'])
family_rows=[{'id':family,'unit_ids':ids,'relative_scope':'Explicit actual change units; family is not a patch/completion count.'} for family,ids in family_map.items()]
nochange=[];questions=[];validation=[];pending=[]
for i,r in enumerate(rows):
 k=key(r)
 if k in mapped:continue
 if r['disposition']=='needs_migration':pending.append({'index':i,'row_id':k,'sourceSHA':r['sourceSHA'],'context':r['context'],'requirement':r['missingintegration'],'state':'canonical_boundary_family_sites_not_yet_individually_mapped'});continue
 if r['disposition'] in ['pending_audit','pending_validation']:
  q={'row_id':k,'row_index':i,'source_sha256':r['sourceSHA'],'state':r['disposition'],'question':r['missingintegration'],'context':r['context'],'existing_api':r['sharedAPI']};questions.append(q);mapped[k]={'row_index':i,'canonical_state':'explicit_unresolved_source_or_provider_requirement'}
 elif r['disposition']=='migrated_validation_pending':
  assert r.get('legacy_state_review');validation.append({'row_id':k,'row_index':i,'source_sha256':r['sourceSHA'],'implemented_purpose':r['context'],'remaining_validation_or_separate_boundary':r['missingintegration'],'individual_interpretation':r['legacy_state_review'],'controls':r['tests'],'execution':'none donated'});mapped[k]={'row_index':i,'canonical_state':'implemented_existing_purpose_execution_validation_pending'}
 else:
  nochange.append({'row_id':k,'row_index':i,'source_sha256':r['sourceSHA'],'disposition':r['disposition'],'actual_purpose':r['context'],'reason':r['missingintegration']});mapped[k]={'row_index':i,'canonical_state':'existing_shared_owner_or_display_or_excluded_purpose_no_additional_code_change'}
out={'baseline':d['baseline'],'utc':datetime.now(timezone.utc).isoformat(),'status':'IN_PROGRESS canonical proposed units: all confirmed source rows mapped, individual category/shared-owner/split/edit-site QA remain; all operational source closure complete. No accepted remaining total.','source_rows_sha256':hashlib.sha256((ROOT/'runtime-consumers.json').read_bytes()).hexdigest(),'remaining_consumer_total':None,'area_counts':None,'selected_scope_counts':{'proposed_change_units':len(units),'original_needs_rows_mapped':len(decided),'remaining_needs_rows_unmapped':len(pending),'by_work_kind':dict(Counter(u['work_kind'] for u in units))},'scope_qa_complete':False,'remaining_count_blockers':['Source scope502/287 is closed; canonical semantic owner-facet/split/site reconciliation remains incomplete.','Genuine required shared owner facets must become explicit single units at authentic source declarations/producers, not hidden dependency prose.','Mixed caller/metadata/owner purposes and exact changed sites require further split reconciliation (Root50peer/OOsite decisions retained).','No current Native/original provider execution or semantic acceptance donated by source/control references.'],'units':units,'families':family_rows,'external_shared_repairs':EXTERNAL_SHARED_REPAIRS,'additional_capability_duty_questions':json.loads((ROOT/'runtime-work/runtime-original-variable-duty-questions.json').read_text())['questions'],'original_row_mapping':mapped,'no_additional_change':nochange,'unresolved_questions':questions,'validation_obligations':validation,'unmapped_confirmed_change_rows':pending,'count_contract':'COUNT-UNITS.md','limits':'Source-only audit; no source/test/provider/build/Git mutation. Actual fixed or original oracle data remain independent; no Native/source/absence/frame/key/Normal authority from reports, receipts, tests, or unexecuted controls.'}
atomic_write(ROOT/'runtime-migration-units.json',json.dumps(out,indent=2)+'\n');print(out['selected_scope_counts'])
