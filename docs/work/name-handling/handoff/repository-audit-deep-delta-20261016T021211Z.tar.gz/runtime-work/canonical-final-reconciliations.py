import json,hashlib
from pathlib import Path
R=Path('/workspace/name-session/full-consumer-audit')
def apply(units,mapped,decided,rows,key,SRC):
 def site(path,line,symbol):
  b=(SRC/path).read_bytes();text=b.decode().splitlines()[line-1];return dict(path=path,line=line,symbol=symbol,source_line=text,semantic_anchor=text.strip(),source_sha256=hashlib.sha256(b).hexdigest())
 def addsite(u,path,line):
  if not any(s['path']==path and s['line']==line for s in u['code_change_sites']):u['code_change_sites'].append(site(path,line,u['purpose']))
 # Three observations are actual ingresses of ONE cell incarnation owner repair.
 epoch=next(u for u in units if u['original_indices']==[604])
 epoch['family_id']='native.array-search-mutation-epoch';epoch['purpose']='Actual CellContents array/search nonreviving incarnation issuance';epoch['work_kind']='shared_owner_repair'
 for i in [530,599]:
  old=next((u for u in units if u['original_indices']==[i]),None)
  if old:units.remove(old)
  epoch['original_indices'].append(i);epoch['original_row_ids'].append(key(rows[i]));mapped[key(rows[i])]={'row_index':i,'canonical_state':'requires_code_change','unit_ids':[epoch['id']]};decided.add(i)
  addsite(epoch,rows[i]['path'],rows[i]['line'])
 for line in [419,425,427]:addsite(epoch,'runtime/rust/src/frame.rs',line)
 epoch['required_change']='Repair one actual CellContents nonreviving rmw_array_epoch/array_search_epoch issuance/exhaustion owner and all demonstrated mutation ingresses in rmw/materialisation/destruction. Current checked reference counts are unrelated. Preserve actual retained cell identity, retirement ordering and mandatory cleanup. No portable/original overflow answer is claimed.'
 epoch['deduplication_reason']='530/599/604 are the same actual epoch-field/issuance contract at three mutation ingresses, not three distinct owner facets.'
 # Original broad Core observation697 names the same three actual adapters
 # already recorded838/839/840. No new generic List payload rewrite is inferred.
 same=[(838,[399,403,408,419]),(839,[440,444,449,462]),(840,[480,484,489,501])]
 ids=[]
 for index,lines in same:
  u=next(u for u in units if u['original_indices'][0]==index)
  for line in lines:addsite(u,'runtime/rust/src/cmd_list.rs',line)
  u['deduplication_reason']='Original broad observation697 maps to these existing actual variable-name read/store adapters; no duplicated Core physical payload mutation unit.'
  ids.append(u['id'])
 mapped[key(rows[697])]={'row_index':697,'canonical_state':'requires_code_change','unit_ids':ids};decided.add(697)
 # Exact overlooked ingress/caller sites from the full-source and peer review.
 for u in units:
  i=u['original_indices'][0]
  if i==429:addsite(u,'runtime/rust/src/cmd_dict.rs',610);addsite(u,'runtime/rust/src/cmd_dict.rs',631)
  if i==671:addsite(u,'runtime/rust/src/cmd_array.rs',570)
  if i==196:addsite(u,'rust/tcl-cshim/src/load.rs',254);u['family_id']='embedding.extension-loader-entry-policy'
  if i==784:addsite(u,'runtime/rust/src/typed_value.rs',372);u['shared_owner_dependency']='runtime:native.actual-original-string-stages:611'
  if i==805:u['affected_unchanged_callers']=['Generated eval/eval_code literal source ABI callers use this common helper; their fresh rc0 literal input remains a legitimate separate source purpose.']
 # Exact peer annotations preserve open missing-facet/split questions.
 p=json.loads((R/'root-runtime-canonical02-peer.json').read_text())
 for u in units:
  hit=next((x for x in p['unit_boundary_checks'] if x['original_indices'][0]==u['original_indices'][0]),None)
  if hit:
   u['root_canonical02_review']=hit
   if hit['decision'] in ['supported','supported_with_purpose_precision','category_correction','owner_category_correction','anchor_and_duty_correction']:
    u['category_review']={'canonical_work_kind':u['work_kind'],'decision_reason':hit['evidence'],'state':'bounded_actual_naming_boundary_reconciled_no_execution'}
   else:u['category_review']={'canonical_work_kind':u['work_kind'],'decision_reason':hit['evidence'],'state':'independently_examined_requires_exact_owner_or_split_reconciliation'}
 # Cross-owner extension links are exact counted owner units, not assumed ready APIs.
 links={
 212:'db.unit.registry.jim-info-physical-parser',808:'db.unit.registry.jim-info-physical-parser',730:'db.unit.registry.jim-package-physical-subcommand-parser',283:'db.unit.registry.encoding-member-declaration',196:'db.unit.registry.load-entry-prefix-policy',544:'compiler existing Syntax native-variable diagnostic ArraySet extension (annex pending exact owner unit id)'}
 for u in units:
  i=u['original_indices'][0]
  if i in links:u['required_external_owner_unit']=links[i]
  if i==197 and u.get('split_from_original_row')==197 and u['id'].endswith(':grammar'):u['required_external_owner_unit']='db.unit.registry.load-invocation-policy'
  if 'facet-' in u['id']:
   family=u['family_id'];vm={'embedding.original-package-name-door':'vm-unit-embedding-original-package-name-door','embedding.original-variable-name-door':'vm-unit-embedding-original-variable-name-door','embedding.original-script-source-door':'vm-unit-embedding-original-script-source-door'}.get(family)
   if vm:u['cross_owner_requirement']=vm
   u['category_review']={'canonical_work_kind':u['work_kind'],'decision_reason':u['required_change'],'state':'root_actual13_owner_adapter_boundary_peer_admitted_cross_owner_public_visibility_linked'}
   u['independent_peer']='root-runtime-owner-facets-peer.json SHA1cbccbe33c3fdf370dfd83fcd867d3300a24edea40a69efcf63c706158f1c618'
 # Individually interpreted own actual naming source boundaries, with exact
 # historical full-source admission plus fresh bounded canonical rechecks.
 import runpy
 own=runpy.run_path(str(R/'runtime-work/canonical-semantic-review06.py'))['REVIEWS']
 for u in units:
  i=u['original_indices'][0]
  if i in own:
   kind,reason=own[i]
   u['category_review']={'canonical_work_kind':u['work_kind'],'decision_reason':reason,'state':'individual_actual_naming_purpose_site_reconciliation_complete_no_execution'}
   u['semantic_review_source']='runtime-work/canonical-semantic-review06.py: exact per-purpose decision; full-source coverage and bounded peer/source receipts retained independently.'
 # Genuine missing stock name/roster facet at the existing shared mathop
 # semantic owner. Handler identity recipe40 remains unchanged and shared.
 base=next(u for u in units if u['original_indices']==[265])
 import copy
 owner=copy.deepcopy(base);owner.update(id='runtime:metadata.mathop-installed-operation:owner-stock-descriptor',source_owner='runtime',work_kind='shared_owner_repair',family_id='metadata.mathop-installed-operation',purpose='Shared selected mathop stock-name and ordered operation-roster facet',code_change_sites=[site('rust/tcl-cmd-core/src/mathop.rs',35,'Existing shared mathop module extension seam')],original_indices=[265,226,116],original_row_ids=[key(rows[i]) for i in [265,226,116]],required_change='Extend existing shared Core mathop owner with selected stock namespace/qualified-name and ordered de-duplicated supported operation descriptor facet. Existing operation_for_handler_identity40 is already genuine shared attested-handler consumption and stays unchanged. Actual engine registration/availability remain independent. Do not substitute package scaffold or source expression parsing for physical registration.',relative_effort='M',state='source_confirmed_change_required_unimplemented',category_review={'canonical_work_kind':'shared_owner_repair','decision_reason':'Runtime and VM repeat the actual stock roster/name construction; complete shared Core module contains no ready roster/name facet. Existing attested identity worker remains legitimate.','state':'individual_required_owner_facet_source_bound_no_execution'},affected_unchanged_callers=['Existing operation_for_handler_identity users preserve real attestation purpose; no code change to that worker required.'])
 owner.pop('root_canonical02_review',None);owner.pop('semantic_review_source',None);units.append(owner)
 for i in [265,226,116]:mapped[key(rows[i])]['unit_ids'].append(owner['id'])
 for u in units:
  if u['original_indices'][0]==265 and u['id']!=owner['id']:u['work_kind']='consumer_api_adoption';u['required_shared_owner_unit']=owner['id']
  if u['original_indices'][0]==226:u['family_id']='metadata.mathop-installed-operation';u['required_shared_owner_unit']=owner['id']
  if u['original_indices'][0]==116 and u['id'].endswith(':mathop'):u['required_shared_owner_unit']=owner['id']
 # Generic Namespaces currently exposes rendered name_bytes only; that is
 # not a constructed C path or retained Jim flat input for the report owner.
 template=next(u for u in units if u['original_indices']==[243])
 for suffix,kind,purpose,sites,change in [
 ('owner','shared_owner_repair','Shared selected namespace report-parts transport facet',[('rust/tcl-runtime-api/src/lib.rs',1807),('rust/tcl-runtime-api/src/lib.rs',2053)],'Extend existing Namespaces report capability with selected immutable report parts (actual constructed C namespace path versus actual reached Jim flat namespace bytes), distinct from legacy Unicode/report name_bytes. Report data conveys no namespace/cell/callable identity or Native entry. Default unavailable stays explicit; real producer validates actual selected namespace/context before issuing. Existing source facades remain legitimate.'),
 ('runtime-provider','consumer_api_adoption','Runtime actual namespace report-parts producer',[('runtime/rust/src/state_traits.rs',1115),('runtime/rust/src/state_traits.rs',1449)],'Implement the new selected report-parts facet from actual Runtime namespace storage/path or genuine held Jim namespace, preserving existing Namespace lifecycle/currentness. Do not parse ns_qualified_name output to reconstruct path or grant a new live namespace. Shared pure report serializers and Core inventory adapters remain separate changes.')]:
  u=copy.deepcopy(template);u.update(id='runtime:report.native-namespace-parts:'+suffix,family_id='report.native-namespace-parts',work_kind=kind,purpose=purpose,code_change_sites=[site(path,line,purpose) for path,line in sites],required_change=change,original_indices=[243,244],original_row_ids=[key(rows[i]) for i in [243,244]],relative_effort='M',category_review={'canonical_work_kind':kind,'decision_reason':change,'state':'actual_missing_report_parts_owner_and_producer_source_bound_no_execution'})
  u.pop('root_canonical02_review',None);units.append(u)
  for i in [243,244]:mapped[key(rows[i])]['unit_ids'].append(u['id'])
 for u in units:
  i=u['original_indices'][0]
  if i in [133,243]:u['required_external_owner_unit']='compiler.owner.native.jim-flat-command-report'
  if i in [128,129,132,244]:u['required_external_owner_unit']='compiler.owner.report.namespace-variable-name'
  if i==544:u['required_external_owner_unit']='compiler.owner.native.variable-array-set-diagnostic'
  if i in [243,244] and u['family_id']!='report.native-namespace-parts':u['required_shared_owner_unit']='runtime:report.native-namespace-parts:owner';u['required_runtime_provider']='runtime:report.native-namespace-parts:runtime-provider'
  if i==132:
   addsite(u,'runtime/rust/src/state_traits.rs',1396);addsite(u,'runtime/rust/src/state_traits.rs',1429)
  if i==133:addsite(u,'runtime/rust/src/namespace.rs',1606)
  if i==127:u['family_id']='native.constructed-command-address';u['required_change']='Use existing selected C constructed_command_address_bytes from the actual retained native namespace path and actual simple member for this unmapped ensemble target. The worker authenticates native_namespace_token_at; do not parse full_name report into a path. Mapped original prefixes and actual table/currentness lifecycle remain unchanged.'
 # Specific List/COW payload semantics are not broadly naming requirements.
 for u in units:
  if u['original_indices'][0]==742:
   u['purpose']='Regsub actual replacement command-prefix invocation';u['code_change_sites']=[site('runtime/rust/src/cmd_regex.rs',n,u['purpose']) for n in [398,401,403,404]];u['required_change']='Transport authentic actual caller/prefix/header/selected member lifetime through existing checked List conversion and ordinary mutable dispatch. Generic result String/duplicate/append payload parity is a separate non-naming scope question, not additional required work in this unit.'
