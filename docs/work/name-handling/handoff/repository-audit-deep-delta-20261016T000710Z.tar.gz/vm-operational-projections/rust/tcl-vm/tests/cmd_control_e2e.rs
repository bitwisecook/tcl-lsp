// tcl-lsp — a language server and toolchain for Tcl
// Copyright (C) 2026 James Deucker (bitwisecook) <https://github.com/bitwisecook>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.
//
// SPDX-License-Identifier: AGPL-3.0-or-later

//! End-to-end coverage of the control-flow command implementations:
//! `try`/`throw` (`cmd_try.rs`), the `if`/`while`/`for`/`foreach`/`lmap`
//! runtime fallbacks (`cmd_control.rs`), and `switch`'s runtime path
//! (`cmd_switch.rs`).
//!
//! Each test compiles real Tcl via `tcl-compiler` and runs it through `tcl-vm`,
//! asserting the observable behaviour (result value, captured `puts` output, or
//! caught error message). Every expected value is the output of real `tclsh`
//! (8.6 and 9.0, which agree on all of these) — differential testing with tclsh
//! as the oracle. The `// tclsh:` comments cite that reference output.
//!
//! DRIVING THE RUNTIME PATH. The compiler inlines the static literal forms of
//! these constructs (e.g. `if {...} {...}`, `switch x {...}`, and — see the BUG
//! note on `try_literal_form_*` below — even some `try` forms compile to the
//! unimplemented `beginCatch` opcode). To exercise the *runtime command*
//! implementations in the three target files, every test invokes the command
//! through a computed name (`set c if; $c ...`), which defeats the inline fast
//! path and routes through the registered builtin. This is the same technique
//! the existing `run_script.rs`/`builtins_e2e.rs` suites use for fallback paths.

use std::cell::RefCell;
use std::io::Write;
use std::rc::Rc;

use tcl_compiler::cfg_builder::build_cfg_codegen;
use tcl_compiler::codegen::codegen_module;
use tcl_compiler::compile_service::BytecodeCompileService;
// Compile the way the real VM runtime does (`tcl-vm-cli`): the bytecode lowering
// turns constructs the backend can't compile correctly — a literal `try` with
// handlers, nested complex `foreach`/`lmap` — into runtime-command barriers,
// where the analysis-oriented `lower_to_ir` would instead emit `beginCatch`
// exception ranges the VM does not implement. Using the analysis lowering here
// would test bytecode the VM never actually runs.
use tcl_compiler::lowering::lower_to_ir_for_bytecode as lower_to_ir;
use tcl_registry::CommandRegistry;
use tcl_runtime_api::{CompileError, CompileService, ScriptCommandPlan};
use tcl_vm::Vm;

/// A `Write` sink backed by a shared buffer the test can read afterwards.
#[derive(Clone)]
struct Capture(Rc<RefCell<Vec<u8>>>);

impl Write for Capture {
    fn write(&mut self, buf: &[u8]) -> std::io::Result<usize> {
        self.0.borrow_mut().extend_from_slice(buf);
        Ok(buf.len())
    }
    fn flush(&mut self) -> std::io::Result<()> {
        Ok(())
    }
}

/// Compile and run `src`; return `(ok, result-string, captured-stdout)`.
fn run(src: &str) -> (bool, String, String) {
    let registry = CommandRegistry::build_default();
    let ir = lower_to_ir(src, &registry);
    let cfg = build_cfg_codegen(&ir, false);
    let asm = codegen_module(&cfg, &ir, &registry).expect("original source namespace");

    let buf = Rc::new(RefCell::new(Vec::new()));
    let mut vm = Vm::with_output(Box::new(Capture(Rc::clone(&buf))));
    vm.set_compiler(Box::new(BytecodeCompileService::default()));
    let completion = vm.run_module(&asm);

    let out = String::from_utf8(buf.borrow().clone()).expect("utf-8 output");
    (
        completion.code.is_ok(),
        completion.result.to_str().to_string(),
        out,
    )
}

#[test]
fn runtime_loop_break_after_an_inner_compiled_loop_exits_the_outer_loop() {
    let source = r"
interp alias {} scan_loop {} while
set pos 0
set len 2
scan_loop {$pos < $len} {
    while {$pos < $len} {incr pos}
    if {$pos >= $len} {break}
}
set pos
";
    let (ok, result, _) = run(source);
    assert!(ok, "{result}");
    assert_eq!(result, "2");
}

#[test]
fn runtime_loop_continue_after_an_inner_compiled_loop_resumes_the_outer_loop() {
    let source = r"
interp alias {} scan_loop {} while
set n 0
scan_loop {$n < 2} {
    set inner 0
    while {$inner < 1} {incr inner}
    incr n
    continue
    error UNREACHABLE
}
set n
";
    let (ok, result, _) = run(source);
    assert!(ok, "{result}");
    assert_eq!(result, "2");
}

#[test]
fn replaced_loop_jump_commands_keep_their_normal_continuation() {
    for command in ["break", "continue"] {
        let source = format!(
            "proc {command} {{}} {{return NORMAL}}; set i 0; set count 0; \
             while {{$i < 2}} {{incr i; {command}; incr count}}; list $i $count"
        );
        let (ok, result, _) = run(&source);
        assert!(ok, "{command}: {result}");
        assert_eq!(result, "2 2", "{command}");
    }
}

#[test]
fn replacing_a_loop_jump_during_argument_evaluation_keeps_the_continuation() {
    for command in ["break", "continue"] {
        let source = format!(
            "proc install {{}} {{rename {command} original_jump; \
             proc {command} args {{return NORMAL}}; return ARG}}; \
             set i 0; set count 0; while {{$i < 1}} \
             {{incr i; {command} [install]; incr count}}; list $i $count"
        );
        let (ok, result, _) = run(&source);
        assert!(ok, "{command}: {result}");
        assert_eq!(result, "1 1", "{command}");
    }
}

#[test]
fn native_option_loop_breaks_through_an_aliased_if() {
    let script = r#"
rename while native_while
interp alias {} while {} native_while
rename if native_if
interp alias {} if {} native_if
proc parse_options {args} {
    set idx 0
    set n [llength $args]
    while {$idx < $n} {
        set tok [lindex $args $idx]
        if {$tok eq "--"} {incr idx; break}
        if {[string index $tok 0] eq "-"} {incr idx} else {break}
    }
    return [lindex $args $idx]
}
list [parse_options api.example.com equals hosts] [parse_options -nocase -- api.example.com equals hosts]
"#;
    assert_eq!(
        run(script),
        (
            true,
            "api.example.com api.example.com".into(),
            String::new()
        )
    );
}

/// Runtime compiler which deliberately emits ordinary command dispatch for
/// every dynamic script. This isolates the generic/plain `catch` and `try`
/// path without relying on execution-trace side effects to select it.
struct PlainRuntimeCompiler(BytecodeCompileService);

impl CompileService for PlainRuntimeCompiler {
    type Module = tcl_bytecode::ModuleAsm;
    fn compile_script_bytes_for_profile(
        &self,
        target: tcl_runtime_api::ScriptCompileTargetBytes<'_>,
        profile: &'static tcl_dialect::DialectProfile,
    ) -> Result<Self::Module, tcl_runtime_api::CompileError> {
        self.0
            .compile_plain_script_bytes_for_profile(target, profile)
    }
    fn compile_substitution_with_entry(
        &self,
        target: tcl_runtime_api::native_substitution::NativeSubstitutionTarget<'_>,
        profile: &'static tcl_dialect::DialectProfile,
        entry: tcl_runtime_api::native_substitution::NativeSubstitutionCompilationEntry<'_>,
    ) -> Result<Self::Module, tcl_runtime_api::CompileError> {
        self.0
            .compile_substitution_with_entry(target, profile, entry)
    }

    fn compile_script_bytes_with_entry(
        &self,
        target: tcl_runtime_api::ScriptCompileTargetBytes<'_>,
        profile: &'static tcl_dialect::DialectProfile,
        entry: &tcl_runtime_api::NativeCompilationEntry,
    ) -> Result<Self::Module, tcl_runtime_api::CompileError> {
        self.0
            .compile_plain_script_bytes_with_entry(target, profile, entry)
    }
    fn compile_plain_script_bytes_for_profile(
        &self,
        target: tcl_runtime_api::ScriptCompileTargetBytes<'_>,
        profile: &'static tcl_dialect::DialectProfile,
    ) -> Result<Self::Module, tcl_runtime_api::CompileError> {
        self.0
            .compile_plain_script_bytes_for_profile(target, profile)
    }
    fn compile_plain_script_bytes_with_entry(
        &self,
        target: tcl_runtime_api::ScriptCompileTargetBytes<'_>,
        profile: &'static tcl_dialect::DialectProfile,
        entry: &tcl_runtime_api::NativeCompilationEntry,
    ) -> Result<Self::Module, tcl_runtime_api::CompileError> {
        self.0
            .compile_plain_script_bytes_with_entry(target, profile, entry)
    }
    fn compile_procedure_bytes_for_profile(
        &self,
        target: tcl_runtime_api::ProcedureCompileTargetBytes<'_>,
        profile: &'static tcl_dialect::DialectProfile,
        _dispatch: tcl_runtime_api::ProcedureDispatch,
    ) -> Result<Self::Module, tcl_runtime_api::CompileError> {
        self.0.compile_procedure_bytes_for_profile(
            target,
            profile,
            tcl_runtime_api::ProcedureDispatch::Plain,
        )
    }
    fn compile_procedure_bytes_with_entry(
        &self,
        target: tcl_runtime_api::ProcedureCompileTargetBytes<'_>,
        profile: &'static tcl_dialect::DialectProfile,
        entry: &tcl_runtime_api::NativeCompilationEntry,
        _dispatch: tcl_runtime_api::ProcedureDispatch,
    ) -> Result<Self::Module, tcl_runtime_api::CompileError> {
        self.0.compile_procedure_bytes_with_entry(
            target,
            profile,
            entry,
            tcl_runtime_api::ProcedureDispatch::Plain,
        )
    }
    fn script_command_plan_bytes_for_profile(
        &self,
        source: &tcl_runtime_api::SourceImage,
        profile: &'static tcl_dialect::DialectProfile,
    ) -> Result<tcl_runtime_api::ScriptCommandPlan, tcl_runtime_api::CompileError> {
        self.0
            .script_command_plan_bytes_for_profile(source, profile)
    }
    fn script_command_plan_bytes_with_entry(
        &self,
        source: &tcl_runtime_api::SourceImage,
        profile: &'static tcl_dialect::DialectProfile,
        entry: &tcl_runtime_api::NativeCompilationEntry,
    ) -> Result<tcl_runtime_api::ScriptCommandPlan, tcl_runtime_api::CompileError> {
        self.0
            .script_command_plan_bytes_with_entry(source, profile, entry)
    }

    fn compile(&self, src: &str) -> Result<Self::Module, CompileError> {
        self.0.compile_traced(src)
    }

    fn compile_for_profile(
        &self,
        src: &str,
        profile: &'static tcl_dialect::DialectProfile,
    ) -> Result<Self::Module, CompileError> {
        self.0.compile_traced_for_profile(src, profile)
    }

    fn compile_traced(&self, src: &str) -> Result<Self::Module, CompileError> {
        self.0.compile_traced(src)
    }

    fn compile_traced_for_profile(
        &self,
        src: &str,
        profile: &'static tcl_dialect::DialectProfile,
    ) -> Result<Self::Module, CompileError> {
        self.0.compile_traced_for_profile(src, profile)
    }

    fn script_command_plan_for_profile(
        &self,
        src: &str,
        profile: &'static tcl_dialect::DialectProfile,
    ) -> Result<ScriptCommandPlan, CompileError> {
        self.0.script_command_plan_for_profile(src, profile)
    }
}

fn run_with_plain_runtime_compiler(src: &str) -> (bool, String, String) {
    let registry = CommandRegistry::build_default();
    let ir = lower_to_ir(src, &registry);
    let cfg = build_cfg_codegen(&ir, false);
    let asm = codegen_module(&cfg, &ir, &registry).expect("original source namespace");

    let buf = Rc::new(RefCell::new(Vec::new()));
    let mut vm = Vm::with_output(Box::new(Capture(Rc::clone(&buf))));
    vm.set_compiler(Box::new(PlainRuntimeCompiler(
        BytecodeCompileService::default(),
    )));
    let completion = vm.run_module(&asm);
    let out = String::from_utf8(buf.borrow().clone()).expect("utf-8 output");
    (
        completion.code.is_ok(),
        completion.result.to_str().to_string(),
        out,
    )
}

/// A literal `catch` in a procedure may inline its exception range, but its
/// body is still a complete Tcl script. Commands after a separator must not be
/// folded into the first command's argument list; the first command's local
/// write is visible to the later error-producing command.
#[test]
fn literal_catch_multicommand_proc_body_executes_in_order() { /* PURE_ASSERTION_BODY_literal_catch_multicommand_proc_body_executes_in_order */ }

/// The catch argument parser already removes its own outer word delimiters.
/// Braces at the beginning and end of the resulting script value belong to
/// command words and must survive inline lowering.
#[test]
fn literal_catch_preserves_braced_first_and_last_words() { /* PURE_ASSERTION_BODY_literal_catch_preserves_braced_first_and_last_words */ }

/// Each command in a segmented inline body owns its own replay text. If the
/// first command mutates the command table, deoptimising the second must not
/// replay the enclosing catch expression or run the mutation twice.
#[test]
fn literal_catch_replays_only_the_stale_nested_command_after_mutation() { /* PURE_ASSERTION_BODY_literal_catch_replays_only_the_stale_nested_command_after_mutation */ }

/// Diagnostic line metadata changes as a multiline inline body advances, but
/// returning from its final nested command to the synthetic catch epilogue is
/// not a new execution of the enclosing source command. Only explicit command
/// boundaries may trigger stale-bytecode replay.
#[test]
fn multiline_catch_epilogue_does_not_replay_the_enclosing_command() { /* PURE_ASSERTION_BODY_multiline_catch_epilogue_does_not_replay_the_enclosing_command */ }

#[test]
fn literal_catch_reports_incomplete_body_before_substitution_side_effects() { /* PURE_ASSERTION_BODY_literal_catch_reports_incomplete_body_before_substitution_side_effects */ }

#[test]
fn literal_catch_executes_complete_prefix_before_later_parse_error() { /* PURE_ASSERTION_BODY_literal_catch_executes_complete_prefix_before_later_parse_error */ }

#[test]
fn nested_try_executes_complete_phase_prefix_before_later_parse_error() { /* PURE_ASSERTION_BODY_nested_try_executes_complete_phase_prefix_before_later_parse_error */ }

/// A computed top-level `catch` reaches the ordinary builtin rather than the
/// procedure-only inline emitter. Its runtime compiler must preserve Tcl's
/// command-at-a-time parse boundary too.
#[test]
fn generic_top_level_catch_executes_prefix_before_fatal_tail() { /* PURE_ASSERTION_BODY_generic_top_level_catch_executes_prefix_before_fatal_tail */ }

/// The forced plain runtime compiler keeps every body command on ordinary
/// dispatch. The catch result must not depend on registry-specialised lowering.
#[test]
fn plain_dispatch_catch_executes_prefix_before_fatal_tail() { /* PURE_ASSERTION_BODY_plain_dispatch_catch_executes_prefix_before_fatal_tail */ }

/// A computed top-level `try` uses the generic state machine. Its error
/// handler observes the side effect from the complete prefix and the exact Tcl
/// 9.0.4 parse message from the fatal tail.
#[test]
fn generic_top_level_try_executes_prefix_before_fatal_tail() { /* PURE_ASSERTION_BODY_generic_top_level_try_executes_prefix_before_fatal_tail */ }

/// Plain-dispatch runtime compilation and ordinary `try` dispatch consume the
/// same compiler-owned command-prefix plan as the optimised generic path.
#[test]
fn plain_dispatch_try_executes_prefix_before_fatal_tail() { /* PURE_ASSERTION_BODY_plain_dispatch_try_executes_prefix_before_fatal_tail */ }

/// Eval executes completed commands before a later fatal parse boundary.
#[test]
fn eval_executes_prefix_before_fatal_tail() { /* PURE_ASSERTION_BODY_eval_executes_prefix_before_fatal_tail */ }

/// A procedure body is compiled when the procedure is **called**, so a body
/// that does not parse neither refuses the definition nor runs with the
/// lenient lowering's invented meaning (#1829).
///
/// The single asserted value pins all three facts at once: the procedure is
/// defined (`info procs` sees it), its clean prefix runs on entry (`::side`
/// reaches 1), and the parse error is raised after that prefix rather than at
/// `proc` time.
#[test]
fn a_procedure_body_that_does_not_parse_raises_on_entry_not_at_definition() { /* PURE_ASSERTION_BODY_a_procedure_body_that_does_not_parse_raises_on_entry_not_at_definition */ }

/// The deferred parse error becomes an error *before* the activation's
/// completion processing, not after it.
///
/// Raising it late would let the error-context frames, the procedure
/// boundary and leave traces all run against the prefix's `ok` completion,
/// so `-errorinfo` would carry no trace and a leave trace would observe
/// code 0 while the caller received code 1.
#[test]
fn a_deferred_parse_error_is_raised_before_the_activation_is_torn_down() { /* PURE_ASSERTION_BODY_a_deferred_parse_error_is_raised_before_the_activation_is_torn_down */ }

/// The narrow nested `catch {try ... on error ...}` compiler specialisation
/// keeps distinct live ranges for the try body and handler. Both are complete
/// scripts: body errors reach the handler, successful handler results reach the
/// outer catch, and body success bypasses the handler.
#[test]
fn nested_catch_try_multicommand_phases_preserve_results() { /* PURE_ASSERTION_BODY_nested_catch_try_multicommand_phases_preserve_results */ }

/// The nested inline shape uses Tcl's list grammar for `variableList` and
/// binds the body's result and options separately, like Tcl 9.0.4.
#[test]
fn nested_catch_try_binds_result_and_options_variables() { /* PURE_ASSERTION_BODY_nested_catch_try_binds_result_and_options_variables */ }

/// Substituted catch/try phase words must retain Tcl's pre-invocation word
/// substitution. The literal specialisers decline these shapes and the shared
/// explicit-stack runtime commands evaluate their resulting script values.
#[test]
fn catch_and_nested_try_decline_dynamic_phase_words() { /* PURE_ASSERTION_BODY_catch_and_nested_try_decline_dynamic_phase_words */ }

/// A braced handler body may still contain a dynamic variable-name word. The
/// handler's typed `set` lowering hook is not enough to use `STORE_SCALAR1`:
/// Tcl substitutes `$target` before selecting the variable to write.
#[test]
fn nested_try_handler_declines_dynamic_set_target() { /* PURE_ASSERTION_BODY_nested_try_handler_declines_dynamic_set_target */ }

/// A quoted catch body has already undergone Tcl's word substitution. It must
/// stay on the generic command path even when its current text happens to be
/// static.
#[test]
fn catch_declines_unbraced_script_body() { /* PURE_ASSERTION_BODY_catch_declines_unbraced_script_body */ }

// try / throw  (cmd_try.rs)
//
// Driven through a computed command name `set t try; $t ...` so the construct
// routes through the registered `cmd_try`/`cmd_throw` builtins. (The literal
// `try { ... } on ... { ... }` form is mis-compiled — see `try_literal_form_*`.)

/// `try body` with no handlers returns the body result; an unmatched error
/// propagates.
#[test]
fn try_body_only_passes_through() {
    // tclsh: `2`
    assert_eq!(run("set t try; $t { expr {1+1} }").1, "2");
    // No matching handler: the error propagates.
    // tclsh: error "boom"
    let (ok, msg, _) = run("set t try; $t { error boom }");
    assert!(!ok);
    assert_eq!(msg, "boom");
}

/// `on code varList script`: an `on ok` handler binds the body result and runs;
/// an `on error` handler binds `[resultVar optionsVar]` and the options dict
/// carries `-code`/`-errorcode`.
#[test]
fn try_on_ok_and_on_error() { /* PURE_ASSERTION_BODY_try_on_ok_and_on_error */ }

/// `on` matches the numeric completion code: `on 7` matches a `return -code 7`
/// body; the symbolic word `break` (code 3) matches a `break` body.
#[test]
fn try_on_numeric_and_symbolic_codes() { /* PURE_ASSERTION_BODY_try_on_numeric_and_symbolic_codes */ }

/// `trap pattern varList script`: matches an error whose `-errorcode` has the
/// given leading sublist. An empty pattern matches any error.
#[test]
fn try_trap_errorcode_prefix() { /* PURE_ASSERTION_BODY_try_trap_errorcode_prefix */ }

/// A `trap` whose pattern is not a prefix of the error's `-errorcode` does NOT
/// match, so the error propagates.
#[test]
fn try_trap_no_match_propagates() {
    // errorcode is {MY ERR}; `trap OTHER` does not match → propagate.
    // tclsh: error "boom" (rc 1)
    let (ok, msg, _) = run("set t try; $t { throw {MY ERR} boom } trap OTHER {} { set r x }");
    assert!(!ok);
    assert_eq!(msg, "boom");
}

/// `finally` always runs; an ok finally leaves the prior outcome, a throwing
/// finally overrides it.
#[test]
fn try_finally_runs_and_can_override() {
    // finally runs for its side effect; the on-error result is preserved.
    // tclsh stdout: "FIN\n", and the `try` result is "got".
    assert_eq!(
        run("set t try; puts [$t { error e } on error {} { set r got } finally { puts FIN }]").2,
        "FIN\ngot\n",
    );
    // A throwing finally overrides the handler's result/outcome.
    // tclsh: `finerr`
    let (ok, msg, _) =
        run("set t try; $t { error e } on error {} { set x ok } finally { error finerr }");
    assert!(!ok);
    assert_eq!(msg, "finerr");
}

/// `finally` runs even when the body succeeds and no handler matches.
#[test]
fn try_finally_runs_on_success() { /* PURE_ASSERTION_BODY_try_finally_runs_on_success */ }

/// A handler that itself throws supersedes the body's exception and chains it
/// via `-during` (TIP 329 exception chaining): the body's options ride along.
#[test]
fn try_handler_throws_chains_during() {
    let (ok, _msg, _) = run("set t try; $t { error body } on error {} { error handler }");
    assert!(!ok);
    // The propagated error's options carry a `-during` link to the body error,
    // whose own `-code` is 1.
    // tclsh: `1`
    assert_eq!(
        run(concat!(
            "set t try\n",
            "catch {$t { error body } on error {} { error handler }} m o\n",
            "dict get [dict get $o -during] -code"
        ))
        .1,
        "1",
    );
}

/// An `on error -` (dash body) falls through to the next clause's body.
#[test]
fn try_dash_fallthrough() { /* PURE_ASSERTION_BODY_try_dash_fallthrough */ }

/// `try`'s handler-type word is a `Tcl_GetIndexFromObj(…,
/// "handler type", 0)` table, so the three types abbreviate and the empty word
/// — a prefix of all three — is `ambiguous handler type ""`, not `bad`.
///
/// tclsh 8.6.16 / 9.0.4:
///   try {} o error {} {}  -> {}       ;  try {} f {}      -> {}
///   try {} t {} {} {}     -> {}
///   try {} {} error {} {} -> ambiguous handler type "": must be finally, on, or trap
///   try {} x error {} {}  -> bad handler type "x": must be finally, on, or trap
///   try {} x              -> bad handler type "x": … (the type precedes the arity)
#[test]
fn try_handler_type_resolves_like_tcl_get_index_from_obj() {
    const MUST: &str = "must be finally, on, or trap";
    // Unique prefixes resolve to their clause grammar.
    assert_eq!(run("set t try; $t {set x ok} o error {} {set x h}").1, "ok");
    assert_eq!(run("set t try; $t {set x ok} f {set y 1}").1, "ok");
    assert_eq!(run("set t try; $t {set x ok} t {} {} {set x h}").1, "ok");
    // The empty word prefixes all three ⇒ ambiguous.
    assert_eq!(
        run("set t try; catch {$t good {} error {} {x}} e; set e").1,
        format!("ambiguous handler type \"\": {MUST}"),
    );
    // The type is resolved before the clause's arity.
    assert_eq!(
        run("set t try; catch {$t good x} e; set e").1,
        format!("bad handler type \"x\": {MUST}"),
    );
}

/// `try` grammar errors are raised before the body runs (validated by
/// `parse_clauses`).
#[test]
fn try_grammar_errors() { /* PURE_ASSERTION_BODY_try_grammar_errors */ }

/// A `trap` pattern that is not a well-formed list errors (the `as_list` Err arm
/// in `parse_clauses`). The VM reports a `must be a list` prefix error.
#[test]
fn try_trap_bad_pattern_list() {
    // An unbalanced brace makes the pattern an invalid list; the parse error is
    // caught. The VM's `parse_clauses` rejects it with a "must be a list" wording.
    let (ok, m, _) = run("set t try; catch {$t good trap \"a b \\{\" {} {x}} e; set e");
    assert!(ok, "the catch should complete: {m}");
    assert!(
        m.contains("must be a list"),
        "expected a 'must be a list' prefix error, got: {m}",
    );
}

/// A completion code outside the signed 32-bit range is not a valid `on` code
/// word (error-20.2): `code_word_to_int` rejects it.
#[test]
fn try_on_code_out_of_int_range() { /* PURE_ASSERTION_BODY_try_on_code_out_of_int_range */ }

/// `throw type message` raises an error with `-errorcode type`. The type must be
/// a non-empty list; `throw` arity is exactly 2.
#[test]
fn throw_command() {
    // tclsh: `boom {MY ERR}`
    assert_eq!(
        run("set th throw; catch {$th {MY ERR} boom} m o; list $m [dict get $o -errorcode]").1,
        "boom {MY ERR}",
    );
    // tclsh: `type must be non-empty list`
    let (ok, msg, _) = run("set th throw; $th {} msg");
    assert!(!ok);
    assert_eq!(msg, "type must be non-empty list");
    // tclsh: `wrong # args: should be "throw type message"`
    let (ok, msg, _) = run("set th throw; $th");
    assert!(!ok);
    assert_eq!(msg, "wrong # args: should be \"throw type message\"");
}

/// The LITERAL `try { body } on error {vars} { handler }` form must route
/// through `cmd_try`. The analysis lowering emits the bytecode exception-range
/// opcode (`beginCatch`) for it, which the VM does not implement; the *bytecode*
/// lowering the real VM runtime uses (`lower_to_ir_for_bytecode`, mirrored by
/// this file's `run`) instead drops it to a runtime-command barrier, so the
/// handler runs. Both literal and dynamic forms must preserve the handler
/// and `finally` completion semantics.
///
/// tclsh 8.6/9.0:  `try { error oops } on error {m o} { set m }`  ->  result "oops" (rc 0)
///
#[test]
fn try_literal_form_on_error_handler() {
    // tclsh: `oops` (the handler runs and returns the body's message)
    let (ok, msg, _) = run("try { error oops } on error {m o} { set m }");
    assert!(
        ok,
        "literal try/on-error should run the handler, got error: {msg}",
    );
    assert_eq!(msg, "oops");
}

// if  (cmd_control.rs, runtime fallback via computed command name)

/// The runtime `if` fallback: then/elseif/else chains, the optional `then`/
/// `else` keywords, and the implicit (bare) else body.
#[test]
fn if_runtime_then_elseif_else() { /* PURE_ASSERTION_BODY_if_runtime_then_elseif_else */ }

/// Later conditions in an `if` chain are NOT evaluated once a branch matches
/// (their side effects are skipped) — `then_body` records the first true branch
/// but the chain keeps scanning without re-evaluating conditions.
#[test]
fn if_runtime_later_conditions_not_evaluated() { /* PURE_ASSERTION_BODY_if_runtime_later_conditions_not_evaluated */ }

/// The runtime `if` grammar errors: no expression, no script after a token, and
/// extra words after the else clause.
#[test]
fn if_runtime_grammar_errors() { /* PURE_ASSERTION_BODY_if_runtime_grammar_errors */ }

/// A condition expression error in the runtime `if` propagates — a *syntax*
/// error from the parse, and a boolean-coercion error from a parsable condition.
#[test]
fn if_runtime_condition_error() {
    // `Tcl_IfObjCmd` runs the condition through `Tcl_ExprBooleanObj`, so it is
    // parsed as an expression first: an unquoted word is a bareword, never a
    // string to coerce (`tclCompExpr.c:766`; parseExpr-21.3).
    // tclsh: `invalid bareword "notbool"` …
    let (ok, msg, _) = run("set c if; $c {notbool} {set r 1}");
    assert!(!ok);
    assert_eq!(
        msg,
        "invalid bareword \"notbool\"\nin expression \"notbool\";\n\
         should be \"$notbool\" or \"{notbool}\" or \"notbool(...)\" or ..."
    );
    // Quoted, it *is* a string operand, and the boolean coercion is what fails
    // (expr-old-28.12: `if {"abc"} {}`).
    // tclsh: `expected boolean value but got "notbool"`
    let (ok, msg, _) = run("set c if; $c {\"notbool\"} {set r 1}");
    assert!(!ok);
    assert_eq!(msg, "expected boolean value but got \"notbool\"");
}

// while  (cmd_control.rs)

/// The runtime `while` fallback loops while the condition holds, then returns
/// empty.
#[test]
fn while_runtime_loops() { /* PURE_ASSERTION_BODY_while_runtime_loops */ }

/// `while` arity is exactly 2.
#[test]
fn while_runtime_arity() { /* PURE_ASSERTION_BODY_while_runtime_arity */ }

/// `break`/`continue` inside the runtime `while` body control the loop.
#[test]
fn while_runtime_break_continue() { /* PURE_ASSERTION_BODY_while_runtime_break_continue */ }

/// A `return` out of the runtime `while` body propagates (the `_ => return c`
/// arm).
#[test]
fn while_runtime_return_propagates() { /* PURE_ASSERTION_BODY_while_runtime_return_propagates */ }

/// An error in the runtime `while` body adds the `("while" body line N)` frame
/// to `errorInfo` (the `append_body_frame` path).
#[test]
fn while_runtime_error_adds_body_frame() { /* PURE_ASSERTION_BODY_while_runtime_error_adds_body_frame */ }

/// A condition expression error in the runtime `while` propagates — the
/// condition is parsed as an expression, so an unquoted word is a bareword
/// (`tclCompExpr.c:766`), and only a quoted one reaches the boolean coercion.
#[test]
fn while_runtime_condition_error() {
    // tclsh: `invalid bareword "notbool"` …
    let (ok, msg, _) = run("set c while; $c {notbool} {set x 1}");
    assert!(!ok);
    assert_eq!(
        msg,
        "invalid bareword \"notbool\"\nin expression \"notbool\";\n\
         should be \"$notbool\" or \"{notbool}\" or \"notbool(...)\" or ..."
    );
    // tclsh: `expected boolean value but got "notbool"`
    let (ok, msg, _) = run("set c while; $c {\"notbool\"} {set x 1}");
    assert!(!ok);
    assert_eq!(msg, "expected boolean value but got \"notbool\"");
}

// for  (cmd_control.rs)

/// The runtime `for` fallback runs init once, then loops test/body/next.
#[test]
fn for_runtime_basic() { /* PURE_ASSERTION_BODY_for_runtime_basic */ }

/// `for` arity is exactly 4.
#[test]
fn for_runtime_arity() { /* PURE_ASSERTION_BODY_for_runtime_arity */ }

/// `continue` in the runtime `for` body still runs the `next` clause.
#[test]
fn for_runtime_continue_runs_next() { /* PURE_ASSERTION_BODY_for_runtime_continue_runs_next */ }

/// `break` in the runtime `for` body ends the loop.
#[test]
fn for_runtime_break_in_body() { /* PURE_ASSERTION_BODY_for_runtime_break_in_body */ }

/// A `break` in the runtime `for` *next* clause ends the loop cleanly (C's
/// `Tcl_ForObjCmd` maps `TCL_BREAK` from the step to `TCL_OK`).
#[test]
fn for_runtime_break_in_next() { /* PURE_ASSERTION_BODY_for_runtime_break_in_next */ }

/// An error in the runtime `for` body adds the `("for" body line N)` frame.
#[test]
fn for_runtime_body_error_adds_frame() { /* PURE_ASSERTION_BODY_for_runtime_body_error_adds_frame */ }

/// An error in the runtime `for` init / next / condition clause propagates.
#[test]
fn for_runtime_clause_errors() {
    // init error propagates immediately.
    // tclsh: `initerr`
    let (ok, msg, _) = run("set c for; $c {error initerr} {1} {x} {y}");
    assert!(!ok);
    assert_eq!(msg, "initerr");
    // next-clause error propagates.
    // tclsh: `nexterr`
    let (ok, msg, _) = run("set c for; $c {set i 0} {$i<3} {error nexterr} {incr i}");
    assert!(!ok);
    assert_eq!(msg, "nexterr");
    // condition error propagates. The clause is an expression, so a bare `x` is
    // C's bareword syntax error (`tclCompExpr.c:766`), not a string to coerce.
    // tclsh: `invalid bareword "x"` …
    let (ok, msg, _) = run("set c for; $c {set i 0} {x} {incr i} {set z 1}");
    assert!(!ok);
    assert_eq!(
        msg,
        "invalid bareword \"x\"\nin expression \"x\";\n\
         should be \"$x\" or \"{x}\" or \"x(...)\" or ..."
    );
    // A parsable condition that is not a boolean still reports the coercion.
    // tclsh: `expected boolean value but got "x"`
    let (ok, msg, _) = run("set c for; $c {set i 0} {\"x\"} {incr i} {set z 1}");
    assert!(!ok);
    assert_eq!(msg, "expected boolean value but got \"x\"");
}

/// A `return` out of the runtime `for` body propagates.
#[test]
fn for_runtime_return_propagates() { /* PURE_ASSERTION_BODY_for_runtime_return_propagates */ }

// foreach / lmap  (cmd_control.rs)

/// The runtime `foreach` fallback: single var, multiple vars per group, and
/// multiple groups (short groups pad with empty).
#[test]
fn foreach_runtime_variants() { /* PURE_ASSERTION_BODY_foreach_runtime_variants */ }

/// A **braced** list word is a literal in every direction.
/// `TclFindElement`'s brace semantics keep `$` and `[…]` inert both for the
/// word itself and for any braced element inside it, so the compiled
/// `foreach` header must push it verbatim. Pushing an ordinary literal
/// instead, with the VM's `subst_word` running the substitution at loop
/// entry, would raise `invalid command name "b"` for `foreach e {{a[b]c} x}`.
///
/// Every expectation below is byte-exact against real tclsh 8.6.16 and 9.0.4
/// (the answers are identical at both, the rule is unchanged across the
/// releases).
#[test]
fn braced_foreach_list_word_is_never_substituted() { /* PURE_ASSERTION_BODY_braced_foreach_list_word_is_never_substituted */ }

/// The other half of that contract: a list word that is *not* braced must
/// still substitute. Flipping the new guard on unconditionally would silence
/// the bug by breaking these, so they are asserted beside it.
#[test]
fn unbraced_foreach_list_word_still_substitutes() { /* PURE_ASSERTION_BODY_unbraced_foreach_list_word_still_substitutes */ }

/// A whole-word array element is a dynamic list source, including when its
/// index contains substitutions.  The header must evaluate that word at loop
/// entry instead of iterating its source spelling.  These outputs match
/// Tcl 9.0.4.
#[test]
fn foreach_dynamic_array_element_list_source_matches_tcl9() { /* PURE_ASSERTION_BODY_foreach_dynamic_array_element_list_source_matches_tcl9 */ }

/// A direct nested iterator routes the outer literal `foreach` through the
/// runtime command boundary. That gives the inner loop a fresh activation;
/// inlining both loops into one CFG would leave only the final outer item.
#[test]
fn nested_foreach_preserves_every_outer_iteration() { /* PURE_ASSERTION_BODY_nested_foreach_preserves_every_outer_iteration */ }

/// `foreach`/`lmap` arity: name-stripped argv must be an odd count >= 3.
#[test]
fn foreach_lmap_runtime_arity() { /* PURE_ASSERTION_BODY_foreach_lmap_runtime_arity */ }

/// An empty var-list for a group errors with the command name.
#[test]
fn foreach_lmap_runtime_empty_varlist() { /* PURE_ASSERTION_BODY_foreach_lmap_runtime_empty_varlist */ }

/// `lmap` collects each non-`continue` body result; `continue` skips collection;
/// `break` ends the loop.
#[test]
fn lmap_runtime_collects() { /* PURE_ASSERTION_BODY_lmap_runtime_collects */ }

/// `break` in the runtime `foreach` body.
#[test]
fn foreach_runtime_break() { /* PURE_ASSERTION_BODY_foreach_runtime_break */ }

/// A `return` out of the runtime `foreach` body propagates.
#[test]
fn foreach_runtime_return_propagates() { /* PURE_ASSERTION_BODY_foreach_runtime_return_propagates */ }

/// An error in the runtime `foreach`/`lmap` body adds the body frame.
#[test]
fn foreach_runtime_body_error_adds_frame() { /* PURE_ASSERTION_BODY_foreach_runtime_body_error_adds_frame */ }

/// The runtime loop must log its invoking command after the body frame even
/// when `error` supplies explicit errorInfo (Tcl 9.0.4).
#[test]
fn foreach_lmap_runtime_explicit_error_info_logs_invocation() {
    for name in ["foreach", "lmap"] {
        let script = format!("set c {name}; catch {{$c x 1 {{error direct EI}}}}; set ::errorInfo");
        let expected = format!(
            "EI\n    (\"{name}\" body line 1)\n    invoked from within\n\"$c x 1 {{error direct EI}}\""
        );
        assert_eq!(run(&script).1, expected, "{name}");
    }
}

#[test]
fn tailcalled_each_loop_retains_its_entered_error_invocation() {
    // Exact errorInfo from Tcl 9.0.4, including the tailcall's replacement
    // invocation rather than the removed procedure's source instruction.
    for name in ["foreach", "lmap"] {
        let source = format!(
            "proc p {{}} {{set c {name}; tailcall $c x 1 {{error direct EI}}}}; catch {{p}}; set ::errorInfo"
        );
        let expected = format!(
            "EI\n    (\"{name}\" body line 1)\n    invoked from within\n\"{name} x 1 {{error direct EI}}\"\n    invoked from within\n\"p\""
        );
        assert_eq!(run(&source).1, expected, "{name}");
    }
}

#[test]
fn foreach_in_package_ifneeded_logs_invocation_before_loader_frame() { /* PURE_ASSERTION_BODY_foreach_in_package_ifneeded_logs_invocation_before_loader_frame */ }

/// A malformed list as the value list errors (the `as_list` Err arm).
#[test]
fn foreach_runtime_bad_list_value() {
    // An unbalanced brace in the value list errors.
    // tclsh: `unmatched open brace in list`
    let (ok, msg, _) = run("set c foreach; $c x \"a b \\{\" {set z 1}");
    assert!(!ok);
    assert_eq!(msg, "unmatched open brace in list");
}

// switch  (cmd_switch.rs, runtime path via -glob/-regexp/-nocase/dynamic)

/// `-glob` matching with a `default` fall-through clause.
#[test]
fn switch_glob_with_default() { /* PURE_ASSERTION_BODY_switch_glob_with_default */ }

/// `-regexp` matching, including the `-` fall-through across pattern/body pairs
/// and a trailing `default`.
#[test]
fn switch_regexp_fallthrough_and_default() { /* PURE_ASSERTION_BODY_switch_regexp_fallthrough_and_default */ }

/// `-nocase` exact matching, and combined with `-glob`.
#[test]
fn switch_nocase() { /* PURE_ASSERTION_BODY_switch_nocase */ }

/// `--` ends option processing so a value starting with `-` is treated as the
/// string, not an option.
#[test]
fn switch_double_dash() { /* PURE_ASSERTION_BODY_switch_double_dash */ }

/// `-matchvar` captures the regexp match + submatches; `-indexvar` captures the
/// match index pairs (TIP #75). Both are written before the body runs.
#[test]
fn switch_matchvar_indexvar() { /* PURE_ASSERTION_BODY_switch_matchvar_indexvar */ }

/// A multi-step `-` fall-through chain resolves to the next real body.
#[test]
fn switch_multi_dash_fallthrough() { /* PURE_ASSERTION_BODY_switch_multi_dash_fallthrough */ }

/// The inline (non-brace-list) pattern/body form: pattern/body words given as
/// separate args rather than a single braced list.
#[test]
fn switch_inline_pairs_form() { /* PURE_ASSERTION_BODY_switch_inline_pairs_form */ }

/// No pattern matches and there is no `default`: `switch` returns empty.
#[test]
fn switch_no_match_returns_empty() { /* PURE_ASSERTION_BODY_switch_no_match_returns_empty */ }

/// `switch` options abbreviate like tclsh (`Tcl_GetIndexFromObj`, flags 0):
/// `-gl`/`-e`/`-noc` resolve to their options in both the direct form (the
/// compiler bails to the runtime for a non-exact option word) and the
/// runtime-dispatch form. Probed tclsh 8.6.14.
#[test]
fn switch_option_abbreviation() { /* PURE_ASSERTION_BODY_switch_option_abbreviation */ }

/// `switch` error paths: bad option, empty body list, odd pattern/body count
/// (both brace-list and inline), a trailing `-` with nothing to fall to, and the
/// misplaced-comment heuristic.
#[test]
fn switch_error_paths() { /* PURE_ASSERTION_BODY_switch_error_paths */ }

/// A `switch` body that is `return`/`break` propagates that code.
#[test]
fn switch_body_control_propagates() { /* PURE_ASSERTION_BODY_switch_body_control_propagates */ }

// try / throw — additional error-path coverage  (cmd_try.rs)

/// A hard *parse* error in a `try` body (not just a runtime error) is mapped to
/// an error completion that a handler can catch — the `eval_body` `Err(e)` arm.
#[test]
fn try_body_parse_error_is_catchable() { /* PURE_ASSERTION_BODY_try_body_parse_error_is_catchable */ }

/// A handler's variable bind that *fails* (here: binding into a constant, a Tcl
/// 9 feature the VM targets) becomes the handler outcome (skipping the body) and
/// chains the body's exception via `-during` (C's `handlerFailed`).
#[test]
fn try_handler_var_bind_failure_chains_during() {
    // Binding the result var into a constant `c` fails.
    // tclsh 9.0: `can't set "c": variable is a constant`
    let (ok, msg, _) = run("const c 1; set t try; $t { error body } on error {c} { set r ran }");
    assert!(!ok);
    assert_eq!(msg, "can't set \"c\": variable is a constant");
    // The bind failure chains the body's exception as `-during` (-code 1).
    // tclsh 9.0: `1`
    assert_eq!(
        run(concat!(
            "const c 1; set t try\n",
            "catch {$t { error body } on error {c} { set r ran }} m o\n",
            "dict get [dict get $o -during] -code"
        ))
        .1,
        "1",
    );
}

/// `add_during` REPLACES an existing `-during` rather than duplicating it: a
/// handler throws (chaining the body as `-during`), then a `finally` throws,
/// whose `add_during` over the same options must overwrite the link. The
/// surviving `-during` still resolves to the body's `-code` (1).
#[test]
fn try_add_during_replaces_existing() { /* PURE_ASSERTION_BODY_try_add_during_replaces_existing */ }

/// `exit` inside a `try` body is not catchable (C's `Tcl_Exit`): the unwind
/// propagates *without* running any handler or the `finally` clause.
#[test]
fn try_exit_skips_handlers_and_finally() {
    // The finally must NOT run (no "FIN" on stdout) and an on-error handler must
    // not catch the exit. (tclsh actually terminates the process here with the
    // exit code; the VM models the unwind, but the observable — finally skipped —
    // matches.)
    let (ok, _msg, out) =
        run("set t try; $t { exit 3 } on error {} { set r h } finally { puts FIN }");
    assert!(!ok, "exit should propagate as a non-ok completion");
    assert_eq!(
        out, "",
        "neither the handler nor finally should run on exit"
    );
}

/// `throw` whose `type` is not a well-formed list errors (the `ty.as_list()` Err
/// arm in `cmd_throw`).
#[test]
fn throw_bad_type_list() {
    // An unbalanced brace makes the type an invalid list.
    // tclsh: `unmatched open brace in list`
    let (ok, msg, _) = run("set th throw; $th \"a \\{ b\" msg");
    assert!(!ok);
    assert_eq!(msg, "unmatched open brace in list");
}

// cmd_control.rs / cmd_switch.rs — additional error-path coverage

/// A `foreach`/`lmap` loop-variable write that fails propagates the set error
/// (the `set_var` Err arm in `each_loop`). Binding the loop var to a constant
/// (Tcl 9) fails.
#[test]
fn foreach_runtime_var_write_failure() {
    // tclsh 9.0: `can't set "c": variable is a constant`
    let (ok, msg, _) = run("const c 1; set f foreach; $f c {1 2 3} {set z 1}");
    assert!(!ok);
    assert_eq!(msg, "can't set \"c\": variable is a constant");
}

/// A malformed list as a `foreach` var-list errors (the `pair[0].as_list()` Err
/// arm in `each_loop`).
#[test]
fn foreach_runtime_bad_varlist_list() {
    // An unbalanced brace makes the var-list an invalid list.
    // tclsh: `unmatched open brace in list`
    let (ok, msg, _) = run("set f foreach; $f \"a \\{\" {1 2} {set z 1}");
    assert!(!ok);
    assert_eq!(msg, "unmatched open brace in list");
}

/// A malformed brace-list body errors (the `rest[0].as_list()` Err arm in
/// `cmd_switch`).
#[test]
fn switch_runtime_bad_body_list() {
    // An unbalanced brace in the body list.
    // tclsh: `unmatched open brace in list`
    let (ok, msg, _) = run("set s switch; $s -glob x \"a 1 \\{\"");
    assert!(!ok);
    assert_eq!(msg, "unmatched open brace in list");
}

/// A `-regexp` switch whose pattern does not compile errors (the
/// `core_switch::select` Err arm in `cmd_switch`). The VM targets the Tcl 9.0
/// wording (8.6 phrases it differently).
#[test]
fn switch_runtime_bad_regexp() {
    // tclsh 9.0: `cannot compile regular expression pattern: invalid quantifier operand`
    // (tclsh 8.6: `couldn't compile regular expression pattern: quantifier operand invalid`)
    let (ok, msg, _) = run("set s switch; $s -regexp -- abc {* {set z 1}}");
    assert!(!ok);
    assert_eq!(
        msg,
        "cannot compile regular expression pattern: invalid quantifier operand",
    );
}

/// A `-matchvar`/`-indexvar` write that fails propagates the set error (the
/// `set_var` Err arm in `cmd_switch`). Writing into a constant (Tcl 9) fails.
#[test]
fn switch_runtime_matchvar_write_failure() {
    // tclsh 9.0: `can't set "c": variable is a constant`
    let (ok, msg, _) =
        run("const c 1; set s switch; $s -regexp -matchvar c -- abc {a.. {set z 1}}");
    assert!(!ok);
    assert_eq!(msg, "can't set \"c\": variable is a constant");
}

/// A hard *parse* error in the chosen `switch` body is mapped to an error (the
/// `eval_source` Err arm in `cmd_switch`).
#[test]
fn switch_runtime_body_parse_error() {
    // tclsh: `extra characters after close-quote`
    let (ok, msg, _) = run("set s switch; $s -glob abc {a* {set \"q\"zzz 1}}");
    assert!(!ok);
    assert_eq!(msg, "extra characters after close-quote");
}

/// `add_during` REPLACES (does not duplicate) a `-during` key that is already
/// present in the options dict it is given. Three nested `try`s: the outer body
/// errors; the outer handler runs a nested `try` whose own handler throws
/// (yielding an error that already carries `-during`); chaining that as the
/// outer outcome's `-during` must overwrite the inner link in place. The
/// surviving `-during` still resolves to the body's `-code` (1).
#[test]
fn try_add_during_replaces_in_nested_chain() { /* PURE_ASSERTION_BODY_try_add_during_replaces_in_nested_chain */ }

/// A hard *parse* error in a runtime control-flow body is mapped to an error
/// (the `eval_body` `Err(e)` arm in `cmd_control.rs`), uniformly across
/// `if`/`while`/`for`/`foreach`.
#[test]
fn control_runtime_body_parse_errors() {
    // `set "q"zzz` is a hard parse error (text after a close-quote).
    // tclsh: `extra characters after close-quote`
    let m = "extra characters after close-quote";
    assert_eq!(
        run("set c while; set i 0; $c {[incr i]<2} {set \"q\"zzz 1}").1,
        m,
    );
    assert_eq!(
        run("set c for; $c {set i 0} {$i<2} {incr i} {set \"q\"zzz 1}").1,
        m,
    );
    assert_eq!(run("set c foreach; $c x {1} {set \"q\"zzz 1}").1, m);
    assert_eq!(run("set c if; $c 1 {set \"q\"zzz 1}").1, m);
}

/// A hard *parse* error in a runtime control-flow condition is mapped to an
/// error (the `cond_bool` → `eval_expr` `Err(e)` arm in `cmd_control.rs`). The
/// VM surfaces the bare parse message (its `cond_bool` forwards `e.message`); C
/// Tcl additionally appends an `in expression "..."` context line, so we assert
/// the leading message only.
#[test]
fn control_runtime_condition_parse_error() {
    // tclsh leading line: `extra characters after close-quote`
    let (ok, msg, _) = run("set c while; $c {[set \"q\"zzz 1]} {set z 1}");
    assert!(!ok);
    assert!(
        msg.starts_with("extra characters after close-quote"),
        "got: {msg}",
    );
}

// The VM must not diverge from tclsh on the following, each asserting the
// correct tclsh behaviour.

/// `Vm::set_var`, via `cmd_try`'s `bind_handler_vars`: binding a
/// `try` handler's result/options variable into an *array element whose base is
/// a scalar* (`x(y)` while `x` is a scalar) should fail with
/// `can't set "x(y)": variable isn't array` (C's `handlerFailed` → the bind
/// error becomes the handler outcome, skipping the body). The `set` *command*
/// already enforces this (a bare `set x(y) 5` errors correctly — verified), but
/// the internal `Vm::set_var` that `bind_handler_vars` calls does not, so the
/// bind silently succeeds and the handler body runs.
///
/// tclsh 8.6/9.0:  result is the error `can't set "x(y)": variable isn't array`.
///
/// Fixed: `bind_handler_vars` now writes through `Vm::var_set`, which resolves
/// `x(y)` to the array element and fails on a scalar base (guards regression).
#[test]
fn try_handler_var_bind_array_on_scalar_should_fail() {
    let (ok, msg, _) = run("set t try; set x 1; $t { error e } on error {x(y)} { set r ran }");
    assert!(
        !ok,
        "binding handler result into x(y) while x is scalar should fail, got ok with: {msg}",
    );
    assert_eq!(msg, "can't set \"x(y)\": variable isn't array");
}

/// Dynamic controls retain their continuations on the VM activation stack.
/// All five C Tcl references and Jim 0.84 complete this fixed nesting with 1.
#[test]
fn deeply_nested_dynamic_if_uses_retained_vm_continuations() {
    const DEPTH: usize = 100;
    let mut src = "set c if\n".to_owned();
    for _ in 0..DEPTH {
        src.push_str("$c {1} {\n");
    }
    src.push_str("set done 1\n");
    for _ in 0..DEPTH {
        src.push_str("}\n");
    }
    let (ok, result, _) = run(&src);
    assert!(ok, "{result}");
    assert_eq!(result, "1");
}

#[test]
fn dynamic_controls_preserve_the_configured_procedure_recursion_limit() {
    let source = r"
interp recursionlimit {} 40
proc walk {n} {
    set c if
    $c {$n > 0} {walk [expr {$n - 1}]} else {return done}
}
catch {walk 100} message
set message
";
    // Real C Tcl 8.4–9.1 all reject this invocation with the same message.
    let (ok, result, _) = run(source);
    assert!(ok, "{result}");
    assert_eq!(result, "too many nested evaluations (infinite loop?)");
}

/// A shallow dynamic-dispatch `if` follows the same continuation path.
#[test]
fn shallow_dynamic_if_still_runs() { /* PURE_ASSERTION_BODY_shallow_dynamic_if_still_runs */ }

/// `CONTROL_FALLBACK_DEPTH_LIMIT` is scoped to `cmd_control.rs`'s runtime
/// fallback specifically (see that constant's doc comment) — ordinary
/// nested `[…]` command substitution, unrelated to this file's fallback
/// commands, must not be affected by it. Capping `Vm::eval_source` itself
/// (the shared mechanism command substitution also uses) would break exactly
/// this: 45 real nested substitutions is far more than any realistic iRule
/// needs, comfortably past what a low, uniform cap would allow, and
/// nowhere near where pure substitution recursion actually becomes
/// dangerous (empirically safe to at least depth 1000 on a 2 MiB thread).
#[test]
fn deeply_nested_command_substitution_is_unaffected() {
    const DEPTH: usize = 45;
    let mut src = String::new();
    for _ in 0..DEPTH {
        src.push_str("[subst {");
    }
    src.push('1');
    for _ in 0..DEPTH {
        src.push_str("}]");
    }
    assert_eq!(run(&format!("set x {src}\n")).1, "1");
}

/// A deferred parse error names the command that failed to parse, the way an
/// ordinary runtime error in the same position does.
///
/// C compiles the failure through `Tcl_LogCommandInfo`, so `-errorinfo`
/// carries a `while executing` / `"<command>"` pair. `tclvm` raised the bare
/// message (#2172).
#[test]
fn a_deferred_parse_error_names_the_malformed_command() { /* PURE_ASSERTION_BODY_a_deferred_parse_error_names_the_malformed_command */ }

/// The quoted text stops at the character that opened the unterminated
/// construct, not at the end of the source.
///
/// C slices `source[commandStart ..= parsePtr->term]`, and for an unterminated
/// quote `ParseQuotedString` sets `term` to the opening `"` itself — so the
/// `abc\ndef` after it is not quoted. Reading the whole remainder instead (the
/// obvious implementation, and what #2172 first proposed) is wrong for every
/// row here but the first.
#[test]
fn the_named_command_stops_at_the_unterminated_delimiter() {
    // All five verified against tclsh 8.6.18 and 9.0.4, which agree.
    //
    // The body is passed braced where it is brace-balanced and quoted where it
    // is not — an unbalanced `{` cannot survive a braced wrapper, which is the
    // same reason C never sees that command as a word either.
    let cases = [
        // Construct opens last and nothing follows: whole remainder is right.
        (
            "set c catch; $c {set a 1; set x \"} m o; dict get $o -errorinfo",
            "missing \"",
            "set x \"",
        ),
        // Text after the opening quote is *not* quoted.
        (
            "set c catch; $c \"set a 1\\nset x \\\"abc\\ndef\" m o; dict get $o -errorinfo",
            "missing \"",
            "set x \"",
        ),
        // Same for a bracket, whose body would otherwise be included.
        (
            "set c catch; $c {set a 1; set x [foo bar} m o; dict get $o -errorinfo",
            "missing close-bracket",
            "set x [",
        ),
        // And a brace.
        (
            "set c catch; $c \"set a 1\\nset x {abc def\" m o; dict get $o -errorinfo",
            "missing close-brace",
            "set x {",
        ),
        // Reported in place rather than at an opener: the term is the
        // offending byte, and the frame stops there.
        (
            "set c catch; $c {set a 1; set x {a}b tail} m o; dict get $o -errorinfo",
            "extra characters after close-brace",
            "set x {a}b",
        ),
        // An earlier *complete* quoted word survives verbatim: the cut is at
        // the delimiter that failed, not the first one seen.
        (
            "set c catch; $c {set a 1; set x \"a\" y \"} m o; dict get $o -errorinfo",
            "missing \"",
            "set x \"a\" y \"",
        ),
    ];
    for (script, message, named) in cases {
        assert_eq!(
            run(script).1,
            format!("{message}\n    while executing\n\"{named}\""),
            "script: {script:?}",
        );
    }
}

/// Where the term cannot be pinned to the construct that failed, no frame is
/// logged at all — the bare message, as before the frame existed.
///
/// A failure inside a `[…]` is reported by the cut owner at the bracket,
/// because the word-part decomposition carries no extent for the inner
/// construct. So `set x [list "oops]` yields `missing "` with the term on the
/// `[`, a pair that cannot be C's: C quotes `set x [list "`. Quoting `set x [`
/// (the term as given) or `set x [list "oops]` (the rest of the source) would
/// both be wrong, and wrong in a way that reads as right.
///
/// The check is that the byte the term points at opens the construct the
/// message names. When it does not, the text is dropped.
#[test]
fn an_unpinnable_term_logs_no_frame_rather_than_a_wrong_one() { /* PURE_ASSERTION_BODY_an_unpinnable_term_logs_no_frame_rather_than_a_wrong_one */ }

/// A straight-line `catch` body compiles into the enclosing procedure rather
/// than being dispatched whole (#2207), so its variables are real locals.
///
/// Verified against tclsh 9.0.4: `proc f {} { catch {set x 42}; return $x }`
/// is `42` on both, and the disassembly agrees instruction for instruction —
/// `beginCatch4`, `loadScalar1`, `storeScalar1`, where before the whole body
/// was one `invokeStk1` and `x` never reached the local table.
#[test]
fn a_catch_body_write_is_visible_after_the_catch() { /* PURE_ASSERTION_BODY_a_catch_body_write_is_visible_after_the_catch */ }

/// The body still runs inside the exception range: a failure is caught, and
/// nothing the body did not reach is defined.
#[test]
fn an_inlined_catch_still_catches() { /* PURE_ASSERTION_BODY_an_inlined_catch_still_catches */ }

/// `catch`'s own value is its return code, in every position.
#[test]
fn catch_returns_its_code_wherever_it_sits() { /* PURE_ASSERTION_BODY_catch_returns_its_code_wherever_it_sits */ }

/// A `catch` outside a procedure keeps the dispatched form, as C does: there
/// is no local variable table to hold the result variable's slot, and tclsh
/// compiles a top-level `catch {set a 1} m o` to a plain `invokeStk`.
#[test]
fn a_top_level_catch_is_not_inlined() { /* PURE_ASSERTION_BODY_a_top_level_catch_is_not_inlined */ }

/// `info exists` in statement position compiles inline in a procedure, so the
/// name it tests becomes a compiled local (#2207).
///
/// tclsh 9.0.4 emits `existScalar %v0` for a bare `info exists pub` in a
/// procedure, against our previous `invokeStk1`.
#[test]
fn statement_position_info_exists_answers_like_tclsh() { /* PURE_ASSERTION_BODY_statement_position_info_exists_answers_like_tclsh */ }

/// A name the inline form cannot address keeps the dispatched path: outside a
/// procedure there is no slot, and a qualified name is not a frame local.
#[test]
fn info_exists_without_a_slot_stays_dispatched() { /* PURE_ASSERTION_BODY_info_exists_without_a_slot_stays_dispatched */ }

/// Only the last statement of a `catch` body is its result; the earlier ones
/// are discarded as ordinary script execution discards them.
///
/// Without that, `catch {set x 1; set y 2}` leaves `1` beneath the result and
/// a loop around it grows the operand stack without bound. The bytecode is
/// byte-identical to tclsh 9.0.4, which pops after each non-final command.
#[test]
fn a_multi_command_catch_body_discards_all_but_its_last_result() { /* PURE_ASSERTION_BODY_a_multi_command_catch_body_discards_all_but_its_last_result */ }

/// A destination word that is not a literal scalar local keeps the dispatched
/// path, because lowering has already normalised it: `$dst` arrives as `dst`
/// and `a(key)` as `a`, so the inline store would write the wrong variable.
#[test]
fn catch_destinations_that_need_resolving_are_not_inlined() {
    assert_eq!(
        run("proc f {} { set dst m; catch {set x ok} $dst; return \"[info exists m] $dst\" }; f").1,
        "1 m"
    );
    // `catch script ?result? ?options?` and no more — C raises this before
    // running the body, so the body must not run.
    let (ok, result, _) = run("proc f {} { catch {set ran 1} r o extra }; f");
    assert!(!ok, "over-arity catch must fail, got {result}");
    assert!(
        result.contains("wrong # args"),
        "and fail the way C does: {result}"
    );
}

/// A braced `return` value is literal text: `return {[id 9]}` returns the six
/// characters `[id 9]` and runs nothing.
///
/// `Terminator::Return` carries `braced`, but both bytecode emitters read only
/// the flattened `value`, whose braces are already stripped — so a proc-body
/// return treated `{[id 9]}` as the whole-word substitution `[id 9]` and
/// inlined the call, and any other braced value went through interpolation.
/// tclsh 8.4.20, 8.5.19, 8.6.18, 9.0.4 and 9.1b0 all return the literal; tclvm
/// ran `id` at every `--tcl-version` (#2228).
#[test]
fn a_braced_return_value_runs_no_substitution() {
    for (why, src, want) in [
        (
            "a whole-word bracket pair",
            "proc id {v} {return RAN}; proc m {} {return {[id 9]}}; m",
            "[id 9]",
        ),
        (
            "brackets inside a longer braced word",
            "proc id {v} {return RAN}; proc m {} {return {a [id 9] b}}; m",
            "a [id 9] b",
        ),
        (
            "a return that is not the proc's only command",
            "proc id {v} {return RAN}; proc m {} {set z 1; return {[id 9]}}; m",
            "[id 9]",
        ),
        (
            "a return inside a branch",
            "proc id {v} {return RAN}; proc m {} {if {1} {return {[id 9]}}}; m",
            "[id 9]",
        ),
        (
            "a variable reference",
            "set x GLOBAL; proc m {} {return {$x}}; m",
            "$x",
        ),
    ] {
        assert_eq!(run(src).1, want, "{why}");
    }

    // Precision: an unbraced return still substitutes.
    assert_eq!(
        run("proc id {v} {return RAN}; proc m {} {return [id 9]}; m").1,
        "RAN"
    );
}
