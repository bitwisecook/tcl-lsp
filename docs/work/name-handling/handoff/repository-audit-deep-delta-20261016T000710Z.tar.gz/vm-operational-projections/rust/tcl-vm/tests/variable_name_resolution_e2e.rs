// tcl-lsp — a language server and toolchain for Tcl
// Copyright (C) 2026 James Deucker (bitwisecook) <https://github.com/bitwisecook>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.
//
// SPDX-License-Identifier: AGPL-3.0-or-later

//! Variable-name resolution on the compiled path.
//!
//! One rule underlies the first two hazards below: **a variable name is the
//! name word's substituted *value*, resolved exactly once.** A naive
//! compiled path can get it wrong in both directions — leaving a quoted
//! word's backslash escapes undecoded so the table key is the source
//! spelling, or pushing an already-resolved name back through the VM's
//! runtime word substitution so it is substituted a *second* time (`set
//! {{a}} V` would then create `a` rather than `{a}`, `set {a[bogus]} V`
//! would run `bogus`, `set {${x}} V` would read `x`).
//!
//! Two corollaries of that rule are pinned here too: the resolved name must
//! also be pushed *byte-exactly*, because a `\<newline>` inside a resolved name
//! is name content and not a word continuation; and the `incr` generic-invoke
//! fallback must build its word from the resolved halves rather than hand the
//! VM a name whose decoded base would substitute again.
//!
//! A related hazard is not a name bug at all: the CFG builder's opaque
//! caller-frame widening names the *callee* on its `Statement::Barrier`, and
//! codegen dispatches a barrier that names a command — so a naive
//! implementation emits the call site twice and runs the callee's body
//! twice. The same defect would reach the VM as `invalid command name
//! "<global-frame-script>"` for the `uplevel #0` widening, whose marker
//! codegen must filter it too. Synthetic identity is the typed
//! `ir::SyntheticMarker`, because every reserved spelling is a legal Tcl
//! command name a script may define and call — matching on the name alone
//! would silently drop such a call, which is the vector below.
//!
//! A separate hazard: C's `Tcl_ArrayObjCmd` set path resolves its target
//! through the standard variable lookup, which parses the name — so an
//! element-form target (`array set (x) …`, `array set arr(k) …`) is refused
//! before the value list is even looked at. The VM must not element-parse it.
//!
//! Every vector runs through the matching physical core and source compiler
//! for all five pinned C releases and through the strict shared native roster.
//! The `${{}}` columns retain the 8.x first-close versus 9.x nesting rule;
//! separate measured rows cover older upvar errors and C8.4's catch arity.

mod common;

use std::fmt::Write as _;

use tcl_dialect::TclVersion;
use tcl_test_support::required_tclshs;

fn vm_output(source: &str, version: TclVersion) -> String {
    common::vm_output(source, version.dialect_name())
}

/// One behaviour vector: the script prints its observations; `want_8x` and
/// `want_90` are the original pinned 8.6/9.0 stdout; older overrides follow.
struct Vector {
    name: &'static str,
    script: &'static str,
    want_8x: &'static str,
    want_90: &'static str,
}

const VECTORS: &[Vector] = &[
    // The name half: a resolved name is never substituted again.
    Vector {
        name: "a braced name keeps its own braces (set {{zz}} names `{zz}`)",
        script: r"set {{zz}} V
set n [lindex [info vars *zz*] 0]
puts [info exists {{zz}}]:[set {{zz}}]:$n:[string length $n]
",
        want_8x: "1:V:{zz}:4",
        want_90: "1:V:{zz}:4",
    },
    Vector {
        name: "a `[…]` inside a braced name is data, not a command to run",
        script: r"set {zc[bogus]} V
set n [lindex [info vars zc*] 0]
puts [info exists {zc[bogus]}]:$n:[string length $n]
",
        want_8x: "1:zc[bogus]:9",
        want_90: "1:zc[bogus]:9",
    },
    Vector {
        name: "a `${…}` inside a braced name is data, not a variable to read",
        script: r"set {zd${nope}} V
set n [lindex [info vars zd*] 0]
puts [info exists {zd${nope}}]:$n:[string length $n]:[info exists nope]
",
        want_8x: "1:zd${nope}:9:0",
        want_90: "1:zd${nope}:9:0",
    },
    Vector {
        name: "a braced array key keeps its braces too",
        script: r"set za({k}) V
set k [lindex [array names za] 0]
puts $k:[string length $k]:[set za($k)]
",
        want_8x: "{k}:3:V",
        want_90: "{k}:3:V",
    },
    Vector {
        // The *read* side of the vector above: a key the compiler has already
        // resolved must reach the VM byte-exactly, or `subst_word` strips its
        // braces and the load looks up `zb(k)`. Storing the key correctly while
        // reading it through a substituting push is worse than getting both
        // wrong — the round-trip stops working — so the two sides are pinned
        // together.
        name: "an escape-braced array key round-trips through a `$` read",
        script: r"set zb(\{k\}) V
set k [lindex [array names zb] 0]
puts $k:[string length $k]:$zb(\{k\}):[set zb(\{k\})]
",
        want_8x: "{k}:3:V:V",
        want_90: "{k}:3:V:V",
    },
    Vector {
        // Same rule inside a composite key: the parser has decoded the literal
        // halves, so they are finished too and only the `$i` still substitutes.
        name: "a composite array key keeps its decoded literal half byte-exact",
        script: r"set i K
set zd(\{k\}$i) V
set d [lindex [array names zd] 0]
puts $d:[string length $d]:$zd(\{k\}$i):[set zd(\{k\}$i)]
",
        want_8x: "{k}K:4:V:V",
        want_90: "{k}K:4:V:V",
    },
    Vector {
        name: "a `${{}}` load follows the release's `${…}` close rule",
        script: r"set {{}} Z
puts [info exists {{}}]:[catch {set r ${{}}} m]:$m
",
        want_8x: "1:1:can't read \"{\": no such variable",
        want_90: "1:0:Z",
    },
    Vector {
        name: "a `${{}}` array key follows the same release rule",
        script: r"set {{}} Z
set za(Z) hit
puts [catch {set r $za(${{}})} m]:$m
",
        want_8x: "1:can't read \"{\": no such variable",
        want_90: "0:hit",
    },
    Vector {
        name: "a proc-local braced name round-trips through a compiled read",
        script: r"proc pl {} { set {{loc}} L ; return [set {{loc}}] }
puts [pl]
",
        want_8x: "L",
        want_90: "L",
    },
    // The negative boundary for the whole name half: names that legitimately
    // hold parens and braces must keep working, and a *live* `$` in a key must
    // still substitute.
    Vector {
        name: "ordinary and substituted array keys are untouched; a braced key stays literal",
        script: r"set i K
set za($i) 1
set za(lit) 2
set {zb($x)} 3
puts [lsort [array names za]]:[lsort [array names zb]]:[info exists {zb($x)}]:[info exists x]
",
        want_8x: "K lit:{$x}:1:0",
        want_90: "K lit:{$x}:1:0",
    },
    Vector {
        name: "escapes decide where the element starts; an escaped `$` key stays literal",
        script: r"set i IDX
set q\(b\) 1
set r(\$i) 2
set s($i) 3
puts [array names q]:[array names r]:[array names s]
puts [set q(b)]:[set r(\$i)]:[set s(IDX)]
",
        want_8x: "b:{$i}:IDX\n1:2:3",
        want_90: "b:{$i}:IDX\n1:2:3",
    },
    // The barrier half: a synthetic marker must never be dispatched.
    Vector {
        name: "a braced-name upvar runs the proc body once, not twice",
        script: r#"set {a b} OUTER
proc p {} { upvar 1 {a b} v ; puts "u=$v" }
p
puts done
"#,
        want_8x: "u=OUTER\ndone",
        want_90: "u=OUTER\ndone",
    },
    Vector {
        name: "a callee that runs an unreadable global-frame script is invoked once",
        script: r#"proc setter {body} { uplevel #0 $body }
setter {set q 1}
puts "q=$q"
set y [setter {set r 2}]
puts "r=$r y=$y"
"#,
        want_8x: "q=1\nr=2 y=2",
        want_90: "q=1\nr=2 y=2",
    },
    Vector {
        name: "the same callee inside an `if` / `while` condition stays dispatch-free",
        script: r#"proc setter {body} { uplevel #0 $body }
if {[setter {set q 1}] eq "1"} { puts if-yes } else { puts if-no }
set i 0
while {[setter {set w 2}] eq "2" && $i < 1} { incr i }
puts "i=$i w=$w q=$q"
"#,
        want_8x: "if-yes\ni=1 w=2 q=1",
        want_90: "if-yes\ni=1 w=2 q=1",
    },
    // The name is the word's value, not its source spelling.
    Vector {
        name: "a quoted / bare name word is backslash-substituted; a braced one is not",
        script: r#"set "z1\\" A
set "z2\}" B
set "z3\ x" C
set z4\\ D
set {z5\\} E
set "z6\x41" F
set "z7\t" G
foreach n [lsort [info vars z*]] { puts "[string length $n]:$n:[set $n]" }
"#,
        want_8x: "3:z1\\:A\n3:z2}:B\n4:z3 x:C\n3:z4\\:D\n4:z5\\\\:E\n3:z6A:F\n3:z7\t:G",
        want_90: "3:z1\\:A\n3:z2}:B\n4:z3 x:C\n3:z4\\:D\n4:z5\\\\:E\n3:z6A:F\n3:z7\t:G",
    },
    // `array set` refuses an element-form target.
    Vector {
        name: "array set rejects an element-form target before it parses the list",
        script: r"puts [catch {array set (x) {a 1}} m]:$m
puts [catch {array set (x) {}} m]:$m
puts [catch {array set zarr(k) {a 1}} m]:$m
puts [catch {array set {zarr(k)} {a 1}} m]:$m
puts [catch {array set zodd {a}} m]:$m
puts [catch {array set {z)b} {a 1}} m]:$m
puts [catch {array set {z(b} {a 1}} m]:$m
puts [catch {array set zok {a 1}} m]:$m
puts [array get zok]:[array get {z)b}]:[array names {z(b}]
",
        want_8x: "1:can't set \"(x)\": variable isn't array\n\
                  1:can't set \"(x)\": variable isn't array\n\
                  1:can't set \"zarr(k)\": variable isn't array\n\
                  1:can't set \"zarr(k)\": variable isn't array\n\
                  1:list must have an even number of elements\n\
                  0:\n0:\n0:\na 1:a 1:a",
        want_90: "1:can't set \"(x)\": variable isn't array\n\
                  1:can't set \"(x)\": variable isn't array\n\
                  1:can't set \"zarr(k)\": variable isn't array\n\
                  1:can't set \"zarr(k)\": variable isn't array\n\
                  1:list must have an even number of elements\n\
                  0:\n0:\n0:\na 1:a 1:a",
    },
    // A marker is typed, and a resolved
    // name is pushed once and byte-exact.
    Vector {
        name: "a proc named like a CFG marker is still a command, not a marker",
        script: r#"proc <cond> {} { puts "hit-cond" }
proc <caller-frame-opaque> {} { puts "hit-cfo" }
proc <global-frame-script> {} { puts "hit-gfs" }
proc <word-effects> {} { puts "hit-we" }
proc <empty_clause> {} { puts "hit-ec" }
<cond>
<caller-frame-opaque>
<global-frame-script>
<word-effects>
<empty_clause>
puts done
"#,
        want_8x: "hit-cond\nhit-cfo\nhit-gfs\nhit-we\nhit-ec\ndone",
        want_90: "hit-cond\nhit-cfo\nhit-gfs\nhit-we\nhit-ec\ndone",
    },
    Vector {
        name: "the incr fallback keeps a resolved base literal and substitutes only the key",
        script: r#"proc b {} { puts "BOOM-b-ran" ; return 7 }
set i K
set a\133b\135(K) 5
incr a\133b\135($i) 999
foreach n [lsort [info vars a*]] {
    if {[array exists $n] && [string length $n] <= 6} {
        puts "array <$n> len=[string length $n] : [array get $n]"
    }
}
"#,
        want_8x: "array <a[b]> len=4 : K 1004",
        want_90: "array <a[b]> len=4 : K 1004",
    },
    Vector {
        name: "a resolved name keeps its backslash-newline bytes (no brace-word collapse)",
        script: r"set n [format a%c%cb 92 10]
set $n VALUE
set {a b} COLLAPSED
set out ${a\
b}
puts assign=$out
puts ${a\
b}
",
        want_8x: "assign=VALUE\nVALUE",
        want_90: "assign=VALUE\nVALUE",
    },
    // The negative boundary for that one: a braced or quoted *word* really does
    // collapse `\<newline>`, so the name it spells is the collapsed one.
    Vector {
        name: "a braced or quoted name word still collapses its continuation",
        script: r#"set {z1\
y} BRACED
set "z2\
y" QUOTED
foreach n [lsort [info vars z*]] {
    puts "[string length $n]:[string map [list { } _SP_] $n]:[set $n]"
}
"#,
        want_8x: "4:z1_SP_y:BRACED\n4:z2_SP_y:QUOTED",
        want_90: "4:z1_SP_y:BRACED\n4:z2_SP_y:QUOTED",
    },
    Vector {
        name: "a proc-local braced continuation name agrees with its local-variable slot",
        script: r#"proc p {} {
    set {z1\
y} LOCAL
    return "[lsort [info locals]]:[set {z1\
y}]"
}
puts [p]
"#,
        want_8x: "{z1 y}:LOCAL",
        want_90: "{z1 y}:LOCAL",
    },
    // Array element access keeps `(base, key)` as a pair.
    Vector {
        name: "array commands preserve bases containing parentheses",
        script: r#"foreach name [list {z(b} {z)b} {z(b)c}] {
    array set $name {a 1 b 2}
    puts "$name get=[array get $name] names=[array names $name] size=[array size $name]"
    array unset $name a
    puts "$name after=[array get $name]"
}
set r(\$i) 2
puts "literal-key=[lindex [array names r] 0]"
"#,
        want_8x: "z(b get=a 1 b 2 names=a b size=2\n\
                  z(b after=b 2\n\
                  z)b get=a 1 b 2 names=a b size=2\n\
                  z)b after=b 2\n\
                  z(b)c get=a 1 b 2 names=a b size=2\n\
                  z(b)c after=b 2\n\
                  literal-key=$i",
        want_90: "z(b get=a 1 b 2 names=a b size=2\n\
                  z(b after=b 2\n\
                  z)b get=a 1 b 2 names=a b size=2\n\
                  z)b after=b 2\n\
                  z(b)c get=a 1 b 2 names=a b size=2\n\
                  z(b)c after=b 2\n\
                  literal-key=$i",
    },
    // Explicit-frame names use the target frame's namespace.
    Vector {
        name: "relative-qualified upvar targets use the caller frame namespace",
        script: r#"namespace eval A {
    namespace eval rel { variable x A; variable arr; set arr(k) AK }
    proc outer {} { ::B::inner }
}
namespace eval B {
    namespace eval rel { variable x B; variable arr; set arr(k) BK }
    proc inner {} {
        upvar 1 rel::x scalar rel::arr(k) element
        set scalar AS
        set element AE
        list $scalar $element
    }
}
puts [list [::A::outer] $::A::rel::x $::A::rel::arr(k) $::B::rel::x $::B::rel::arr(k)]
namespace eval C { proc middle {} { ::B::deep } }
namespace eval A { proc deep_outer {} { ::C::middle } }
namespace eval B { proc deep {} { upvar 2 rel::x target; append target -DEEP } }
puts [list [::A::deep_outer] $::A::rel::x $::B::rel::x]
namespace eval A2 { proc outer {} { ::B2::inner } }
namespace eval B2 {
    namespace eval rel { variable x B }
    proc inner {} { upvar 1 rel::x y }
}
puts "missing=[catch {::A2::outer} message]:$message:$::errorCode"
"#,
        // Tcl 9.0.4 exact oracle; this frame rule is release-invariant.
        want_8x: "{AS AE} AS AE B BK\n\
                  AS-DEEP AS-DEEP B\n\
                  missing=1:can't access \"rel::x\": parent namespace doesn't exist:TCL LOOKUP VARNAME rel::x",
        want_90: "{AS AE} AS AE B BK\n\
                  AS-DEEP AS-DEEP B\n\
                  missing=1:can't access \"rel::x\": parent namespace doesn't exist:TCL LOOKUP VARNAME rel::x",
    },
    // `upvar` resolves semantic homes before shape checks.
    Vector {
        name: "upvar validates namespace targets and rejects inverted proc links",
        script: r#"namespace eval x { variable ok READY }
puts "control=[catch {upvar #0 ::x::ok top} m opts]:[set top]"
proc p {} {
    set proc_local 1
    puts "inverted=[catch {upvar 0 proc_local ::x::link(k)} m]:$m:$::errorCode"
}
p
puts "target=[catch {upvar #0 ::missing::x local} m]:$m:$::errorCode"
proc compiled_target {} { upvar #0 ::missing::compiled local }
puts "compiled-target=[catch {compiled_target} m]:$m:$::errorCode"
puts "local=[catch {upvar #0 x ::missing::local} m]:$m:$::errorCode"
puts "element=[catch {upvar #0 x local(k)} m]:$m:$::errorCode"
"#,
        want_8x: "control=0:READY\n\
                  inverted=1:bad variable name \"::x::link(k)\": can't create namespace variable that refers to procedure variable:TCL UPVAR INVERTED\n\
                  target=1:can't access \"::missing::x\": parent namespace doesn't exist:TCL LOOKUP VARNAME ::missing::x\n\
                  compiled-target=1:can't access \"::missing::compiled\": parent namespace doesn't exist:TCL LOOKUP VARNAME ::missing::compiled\n\
                  local=1:can't create \"::missing::local\": parent namespace doesn't exist:TCL LOOKUP VARNAME ::missing::local\n\
                  element=1:bad variable name \"local(k)\": can't create a scalar variable that looks like an array element:TCL UPVAR LOCAL_ELEMENT",
        want_90: "control=0:READY\n\
                  inverted=1:bad variable name \"::x::link(k)\": can't create namespace variable that refers to procedure variable:TCL UPVAR INVERTED\n\
                  target=1:can't access \"::missing::x\": parent namespace doesn't exist:TCL LOOKUP VARNAME ::missing::x\n\
                  compiled-target=1:can't access \"::missing::compiled\": parent namespace doesn't exist:TCL LOOKUP VARNAME ::missing::compiled\n\
                  local=1:can't create \"::missing::local\": parent namespace doesn't exist:TCL LOOKUP VARNAME ::missing::local\n\
                  element=1:bad variable name \"local(k)\": can't create a scalar variable that looks like an array element:TCL UPVAR LOCAL_ELEMENT",
    },
    Vector {
        name: "upvar preserves defined and traced locals while reusing undefined shells",
        script: r"set ::one 1
set ::two 2
proc p {} {
    set x value
    set c1 [catch {upvar #0 one x} m]
    set r1 [list $c1 $m $::errorCode]
    unset x
    trace add variable x unset {apply {{n1 n2 op} {}}}
    set c2 [catch {upvar #0 one x} m]
    set r2 [list $c2 $m $::errorCode]
    upvar #0 one y
    upvar #0 two y
    variable z
    upvar #0 one z
    list $r1 $r2 $y $z
}
puts [p]
",
        want_8x: "{1 {variable \"x\" already exists} {TCL UPVAR EXISTS}} {1 {variable \"x\" has traces: can't use for upvar} {TCL UPVAR TRACED}} 2 1",
        want_90: "{1 {variable \"x\" already exists} {TCL UPVAR EXISTS}} {1 {variable \"x\" has traces: can't use for upvar} {TCL UPVAR TRACED}} 2 1",
    },
];

// Exact original-source observations from the pinned C8.4–C9.1 roster.
// A failed whole-script evaluation keeps its prior output and first error.
fn expected_outcome(
    case: usize,
    vector: &Vector,
    version: TclVersion,
) -> (&'static str, Option<&'static str>) {
    match (case, version) {
        (22, TclVersion::V8_4 | TclVersion::V8_5) => (
            "{AS AE} AS AE B BK\nAS-DEEP AS-DEEP B\nmissing=1:can't access \"rel::x\": parent namespace doesn't exist:NONE",
            None,
        ),
        (23, TclVersion::V8_4) => (
            "",
            Some("wrong # args: should be \"catch command ?varName?\""),
        ),
        (23, TclVersion::V8_5) => (
            "control=0:READY\ninverted=1:bad variable name \"::x::link(k)\": can't create namespace variable that refers to procedure variable:NONE\ntarget=1:can't access \"::missing::x\": parent namespace doesn't exist:NONE\ncompiled-target=1:can't access \"::missing::compiled\": parent namespace doesn't exist:NONE\nlocal=1:can't create \"::missing::local\": parent namespace doesn't exist:NONE\nelement=1:bad variable name \"local(k)\": can't create a scalar variable that looks like an array element:NONE",
            None,
        ),
        (24, TclVersion::V8_4 | TclVersion::V8_5) => (
            "{1 {variable \"x\" already exists} NONE} {1 {variable \"x\" has traces: can't use for upvar} NONE} 2 1",
            None,
        ),
        _ => (
            if version < TclVersion::V9_0 {
                vector.want_8x
            } else {
                vector.want_90
            },
            None,
        ),
    }
}

// Catch only the measured failing original scripts: interactive tclsh stdin
// would otherwise continue past their first error while VM evaluation stops.
fn outcome_source(source: &str, error: Option<&str>) -> String {
    if error.is_none() {
        return source.to_owned();
    }
    let mut hex = String::new();
    for byte in source.as_bytes() {
        write!(hex, "{byte:02x}").expect("write original source hex");
    }
    format!(
        "set __fixture_code [catch [binary format H* {hex}] __fixture_result]\n\
         puts \"__FIXTURE_COMPLETION__$__fixture_code:$__fixture_result\"\n"
    )
}

fn outcome_output(stdout: &str, error: Option<&str>) -> String {
    match error {
        Some(message) => format!("{stdout}\n__FIXTURE_COMPLETION__1:{message}")
            .trim()
            .to_owned(),
        None => stdout.to_owned(),
    }
}

#[test]
fn vm_matches_the_pinned_variable_name_vectors() {
    for v in VECTORS {
        assert_eq!(
            vm_output(v.script, TclVersion::V8_6),
            v.want_8x,
            "[8.6] {}",
            v.name
        );
        assert_eq!(
            vm_output(v.script, TclVersion::V9_0),
            v.want_90,
            "[9.0] {}",
            v.name
        );
    }
}

/// Check every older/newer release against its native-measured outcome.
#[test]
fn release_invariant_vectors_hold_at_every_release() {
    for (case, vector) in VECTORS.iter().enumerate() {
        for version in TclVersion::ALL {
            let (stdout, error) = expected_outcome(case, vector, version);
            assert_eq!(
                vm_output(&outcome_source(vector.script, error), version),
                outcome_output(stdout, error),
                "[{version:?}] {}",
                vector.name
            );
        }
    }
}

/// Missing or wrongly-versioned native interpreters fail this suite.
#[test]
fn vectors_match_real_tclsh() {
    for oracle in required_tclshs(&TclVersion::ALL).expect("all five pinned C Tcl oracles") {
        for (case, vector) in VECTORS.iter().enumerate() {
            let (stdout, error) = expected_outcome(case, vector, oracle.version);
            assert_eq!(
                common::oracle_output(&oracle.path, &outcome_source(vector.script, error)),
                outcome_output(stdout, error),
                "[{}] {}",
                oracle.patchlevel,
                vector.name
            );
        }
    }
}
