// tcl-lsp — a language server and toolchain for Tcl
// Copyright (C) 2026 James Deucker (bitwisecook) <https://github.com/bitwisecook>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.
//
// SPDX-License-Identifier: AGPL-3.0-or-later

//! End-to-end `TclOO` tests for the bytecode VM.
//!
//! Every expectation is the output of the same script under a locally-built
//! **tclsh 9.0.4** (the truth oracle): classes, methods, inheritance (`next`),
//! `self`/`my`, constructors/destructors, `oo::define`/`oo::objdefine`, and the
//! `info object`/`info class` introspection subset.

use std::cell::RefCell;
use std::io::Write;
use std::rc::Rc;

use tcl_compiler::cfg_builder::build_cfg_codegen;
use tcl_compiler::codegen::codegen_module;
use tcl_compiler::compile_service::BytecodeCompileService;
use tcl_compiler::lowering::lower_to_ir;
use tcl_registry::CommandRegistry;
use tcl_vm::{CompileService, Vm};

#[derive(Clone)]
struct Capture(Rc<RefCell<Vec<u8>>>);

impl Write for Capture {
    fn write(&mut self, buf: &[u8]) -> std::io::Result<usize> {
        self.0.borrow_mut().extend_from_slice(buf);
        Ok(buf.len())
    }
    fn flush(&mut self) -> std::io::Result<()> {
        Ok(())
    }
}

/// Compile and run `src`; return `(ok, result-string, captured-stdout)`.
fn run(src: &str) -> (bool, String, String) {
    let registry = CommandRegistry::build_default();
    let ir = lower_to_ir(src, &registry);
    let cfg = build_cfg_codegen(&ir, false);
    let asm = codegen_module(&cfg, &ir, &registry).expect("original source namespace");

    let buf = Rc::new(RefCell::new(Vec::new()));
    let mut vm = Vm::with_output(Box::new(Capture(Rc::clone(&buf))));
    vm.set_compiler(Box::new(BytecodeCompileService::default()));
    let completion = vm.run_module(&asm);

    let out = String::from_utf8(buf.borrow().clone()).expect("utf-8 output");
    (
        completion.code.is_ok(),
        completion.result.to_str().to_string(),
        out,
    )
}

/// Compile a self-contained module, then run it in a VM with no runtime
/// `CompileService`. Used to prove bodyless OO forwards do not compile a fake
/// procedure body during definition or invocation.
fn run_without_compiler(src: &str) -> (bool, String) {
    let module = BytecodeCompileService::default()
        .compile(src)
        .expect("self-contained module compiles");
    let mut vm = Vm::new();
    let completion = vm.run_module(&module);
    (
        completion.code.is_ok(),
        completion.result.to_str().to_string(),
    )
}

/// The trimmed result string of a script expected to succeed.
fn result(src: &str) -> String {
    let (ok, res, _) = run(src);
    assert!(ok, "script errored: {res}");
    res
}

// Classes, methods, construction

#[test]
fn basic_class_and_method() { /* PURE_ASSERTION_BODY_basic_class_and_method */ }

/// TIP 500 private instance variables (#1933).
///
/// This is upstream Tcl 9.0.4 `var.test` **var-29.3** transcribed, with its
/// `-result` verbatim: a private variable reads back, rejects a write and an
/// unset because it is a constant, answers `info constant`, and is listed by a
/// method that does not itself reference it.
#[test]
fn private_instance_variable_on_a_class_matches_var_29_3() { /* PURE_ASSERTION_BODY_private_instance_variable_on_a_class_matches_var_29_3 */ }

/// Upstream `var.test` **var-29.6**: the same contract for a *per-object*
/// private declared through `oo::objdefine`, where the declaring provider is
/// the object itself rather than a class.
#[test]
fn private_instance_variable_on_an_object_matches_var_29_6() { /* PURE_ASSERTION_BODY_private_instance_variable_on_an_object_matches_var_29_6 */ }

/// The point of mangling the storage name: two classes in one hierarchy may
/// each declare a private `X` without sharing a slot.
///
/// Without the per-provider storage this collapses to one variable and the
/// derived constructor's write is visible from the base's method — which is
/// why the assertion reads both back rather than only checking that the
/// declaration was accepted.
#[test]
fn same_named_private_variables_do_not_collide_across_a_hierarchy() {
    // tclsh 9.0.4 / 9.1b0: `base derived P`
    assert_eq!(
        result(concat!(
            "oo::class create Base { private variable X; variable pub; ",
            "constructor {} {set X base; set pub P}; ",
            "method bx {} {return $X}; method bpub {} {return $pub} }; ",
            "oo::class create Derived { superclass Base; private variable X; ",
            "constructor {} {next; set X derived}; method dx {} {return $X} }; ",
            "set o [Derived new]; list [$o bx] [$o dx] [$o bpub]"
        )),
        "base derived P",
    );
    // The two privates occupy distinct mangled slots in the object namespace
    // while the public declaration keeps its plain name. The creation ids are
    // implementation-specific, so match the shape rather than the numbers.
    // tclsh 9.0.4: `{::oo::Obj24::20 : X} {::oo::Obj24::22 : X} ::oo::Obj24::pub`
    let (_, vars, _) = run(concat!(
        "oo::class create B2 { private variable X; variable pub; ",
        "constructor {} {set X b; set pub P} }; ",
        "oo::class create D2 { superclass B2; private variable X; ",
        "constructor {} {next; set X d} }; ",
        "set o [D2 new]; ",
        "lsort [info vars [info object namespace $o]::*]"
    ));
    let mangled: Vec<&str> = vars.split('{').filter(|p| p.contains(" : X")).collect();
    assert_eq!(mangled.len(), 2, "two distinct private slots: {vars}");
    assert!(
        vars.ends_with("::pub"),
        "public keeps its plain name: {vars}"
    );
}

/// `info class|object variables` hides privates; the `-private` form reports
/// only them.
#[test]
fn info_variables_separates_public_and_private_declarations() { /* PURE_ASSERTION_BODY_info_variables_separates_public_and_private_declarations */ }

/// `variable` is a `TclOO` *slot*, not an accumulator: a leading `-set`,
/// `-append`, `-remove` or `-clear` selects the operation.
///
/// Its default for bare names is `-append`, which is what makes a second
/// `variable` call add rather than replace — and which differs from the TIP
/// 558 property slots, whose default is `-set`. The private form shares the
/// same slot machinery.
#[test]
fn variable_declarations_honour_slot_operations() {
    // tclsh 9.0.4 / 9.1b0, one row per operation.
    for (body, expect) in [
        ("variable a b; variable c", "a b c"),      // bare names append
        ("variable a b; variable -set c d", "c d"), // -set replaces
        ("variable a; variable -append b", "a b"),
        ("variable a b c; variable -remove b", "a c"),
        ("variable a b; variable -clear", ""),
        ("variable a; variable a", "a"), // duplicates collapse
    ] {
        assert_eq!(
            result(&format!(
                "oo::class create C {{ {body} }}; info class variables C"
            )),
            expect,
            "public slot op in `{body}`",
        );
    }
    // The private slot answers the same way through `-private`.
    // tclsh 9.0.4 / 9.1b0: `{}` then `a c`
    assert_eq!(
        result(concat!(
            "oo::class create C { private variable a b; private variable -clear }; ",
            "oo::class create D { private variable a b c; private variable -remove b }; ",
            "list [info class variables C -private] [info class variables D -private]"
        )),
        "{} {a c}",
    );
}

/// TIP 500's block form: a lone argument to `private` is a definition
/// *script*, so the declarations inside it are private.
#[test]
fn private_block_form_declares_privately() { /* PURE_ASSERTION_BODY_private_block_form_declares_privately */ }

/// `my variable` and `my varname` must reach the same slot ordinary `$X`
/// access does.
///
/// Targeting the unmangled `{ns}::X` instead would let `my variable X`
/// replace the private mapping with a public one, and `my varname X` hand
/// back a path to a different variable — so this reads the value back through
/// both routes rather than only checking that they succeed.
#[test]
fn my_variable_and_varname_reach_a_private_slot() {
    // tclsh 9.0.4 / 9.1b0: `priv priv`
    assert_eq!(
        result(concat!(
            "oo::class create C { private variable X; ",
            "constructor {} {set X priv}; ",
            "method viaLink {} {my variable X; return $X}; ",
            "method viaName {} {set n [my varname X]; return [set $n]} }; ",
            "set o [C new]; list [$o viaLink] [$o viaName]"
        )),
        "priv priv",
    );
    // The name `my varname` reports is the mangled slot. The creation id is
    // implementation-specific, so match the shape.
    // tclsh 9.0.4: `::oo::Obj22::20 : X`
    let (_, name, _) = run(concat!(
        "oo::class create C { private variable X; ",
        "constructor {} {set X priv}; method n {} {my varname X} }; ",
        "[C new] n"
    ));
    assert!(
        name.ends_with(" : X") && name.contains("::oo::"),
        "mangled private slot, got {name}"
    );
}

#[test]
fn class_method_bodies_compile_per_object_private_namespace() { /* PURE_ASSERTION_BODY_class_method_bodies_compile_per_object_private_namespace */ }

#[test]
fn tcl_oo_package_and_version_vars() { /* PURE_ASSERTION_BODY_tcl_oo_package_and_version_vars */ }

#[test]
fn tip558_core_property_slots() { /* PURE_ASSERTION_BODY_tip558_core_property_slots */ }

#[test]
fn tip558_property_slot_ops_and_writable() { /* PURE_ASSERTION_BODY_tip558_property_slot_ops_and_writable */ }

#[test]
fn tip558_property_all_walks_superclasses() { /* PURE_ASSERTION_BODY_tip558_property_all_walks_superclasses */ }

// TIP 558 configurable layer: oo::configurable, property, configure

#[test]
fn tip558_configurable_configure_get_set_list() { /* PURE_ASSERTION_BODY_tip558_configurable_configure_get_set_list */ }

#[test]
fn tip558_configurable_inheritance_and_next() { /* PURE_ASSERTION_BODY_tip558_configurable_inheritance_and_next */ }

#[test]
fn tip558_configurable_per_object_property() { /* PURE_ASSERTION_BODY_tip558_configurable_per_object_property */ }

#[test]
fn tip558_configurable_kind_readable_and_writable() {
    // ooProp-2.7/2.8: `-kind writable` rejects reads; `-kind readable` rejects
    // writes, with C's exact directionality messages.
    let (ok, msg, _) = run(
        "oo::configurable create P { property x -kind writable; constructor {} {my configure -x 0} }\n\
         [P new] configure -x",
    );
    assert!(!ok);
    assert_eq!(msg, "property \"-x\" is write only");
    let (ok, msg, _) = run(
        "oo::configurable create P { property x -kind readable; constructor {} {variable x 1} }\n\
         [P new] configure -x 9",
    );
    assert!(!ok);
    assert_eq!(msg, "property \"-x\" is read only");
}

#[test]
fn tip558_configurable_bad_property() {
    // ooProp-2.4/2.5: an unknown property lists the valid ones (Oxford comma).
    let (ok, msg, _) = run("oo::configurable create Point { property x y }\n\
         [Point new] configure gorp");
    assert!(!ok);
    assert_eq!(msg, "bad property \"gorp\": must be -x or -y");
    let (ok, msg, _) = run("oo::configurable create Point { property x y z }\n\
         [Point new] configure gorp");
    assert!(!ok);
    assert_eq!(msg, "bad property \"gorp\": must be -x, -y, or -z");
}

/// `configure`'s property word is resolved by C's
/// `oo::configuresupport` through `tcl::prefix match -message property`, so an
/// abbreviation resolves and a word prefixing several — `""` and a lone `-`
/// included — is `ambiguous property`. This matched exactly and hand-joined
/// the enumeration.
///
/// tclsh 9.0.4 (`oo::configurable create Q { property yellow zed }`):
///   q configure -zz   -> bad property "-zz": must be -yellow or -zed
///   q configure {}    -> ambiguous property "": must be -yellow or -zed
///   q configure -     -> ambiguous property "-": must be -yellow or -zed
///   q configure -ye 1 -> {}      ;  q configure -ye -> 1
#[test]
fn tip558_configurable_property_abbreviates() {
    const MUST: &str = "must be -yellow or -zed";
    let setup = "oo::configurable create Q { property yellow zed\n\
                     constructor {} { my configure -yellow 0 -zed 0 } }\n\
                 set q [Q new]\n";
    let msg = |tail: &str| {
        let (ok, result, _) = run(&format!("{setup}$q configure {tail}"));
        assert!(!ok, "expected an error for `configure {tail}`");
        result
    };
    assert_eq!(msg("-zz"), format!("bad property \"-zz\": {MUST}"));
    assert_eq!(msg("{}"), format!("ambiguous property \"\": {MUST}"));
    assert_eq!(msg("-"), format!("ambiguous property \"-\": {MUST}"));
    // A unique prefix resolves — and the *canonical* property is written.
    assert_eq!(
        run(&format!("{setup}$q configure -ye 1\n$q configure -yellow")).1,
        "1"
    );
    assert_eq!(
        run(&format!("{setup}$q configure -ye 1\n$q configure -ye")).1,
        "1"
    );
}

/// The other half of `info object isa`'s dispatch: once the category
/// resolves, C checks an **exact** argument count per category
/// (`InfoObjectIsACmd`, tclOOInfo.c) — two trailing words for
/// `class`/`metaclass`/`object`, three for `mixin`/`typeof`. Resolving the
/// category by prefix without that second stage answers `0` for
/// `info object isa t $obj` (a missing class name) and `1` for
/// `info object isa ob $obj extra` (a word C refuses).
///
/// The noun is C's `Tcl_WrongNumArgs(interp, 2, objv, …)`, so it carries the
/// *resolved* category word — an index-typed argument prints as its table
/// entry, which is why `isa t o` reports `typeof`. The two-words-missing case
/// is checked before the category is resolved, so `info object isa object` is
/// the generic message.
///
/// tclsh 8.6.16 and 9.0.4, byte-identical:
///   info object isa               -> wrong # args: should be "info object isa
///                                    category objName ?arg ...?"
///   info object isa object        -> <same>
///   info object isa t o           -> wrong # args: should be "info object isa
///                                    typeof objName className"
///   info object isa ob o extra    -> … "info object isa object objName"
///   info object isa cl o extra    -> … "info object isa class objName"
///   info object isa metaclass o e -> … "info object isa metaclass objName"
///   info object isa mi o          -> … "info object isa mixin objName className"
///   info object isa mixin o C x   -> <same>
///   info object isa ty o C x      -> … "info object isa typeof objName className"
#[test]
fn info_object_isa_enforces_the_per_category_arity() {
    const SETUP: &str = "oo::class create C { method m {} {return 1} }\nC create o\n";
    const GENERIC: &str = "wrong # args: should be \"info object isa category objName ?arg ...?\"";
    let msg = |tail: &str| {
        let (ok, result, _) = run(&format!("{SETUP}{tail}"));
        assert!(!ok, "expected an error for {tail}");
        result
    };
    assert_eq!(msg("info object isa"), GENERIC);
    assert_eq!(msg("info object isa object"), GENERIC);
    for (tail, want) in [
        ("info object isa t o", "typeof objName className"),
        ("info object isa mi o", "mixin objName className"),
        ("info object isa mixin o C extra", "mixin objName className"),
        ("info object isa ty o C extra", "typeof objName className"),
        ("info object isa ob o extra", "object objName"),
        ("info object isa cl o extra", "class objName"),
        ("info object isa metaclass o extra", "metaclass objName"),
    ] {
        assert_eq!(
            msg(tail),
            format!("wrong # args: should be \"info object isa {want}\"")
        );
    }
    // The exact counts still answer.
    assert_eq!(
        run(&format!("{SETUP}info object isa object nosuchobj")).1,
        "0"
    );
    assert_eq!(run(&format!("{SETUP}info object isa typeof o C")).1, "1");
    assert_eq!(run(&format!("{SETUP}info object isa mixin o C")).1, "0");
}

/// `info object isa`'s category is a
/// `Tcl_GetIndexFromObj(…, "category", 0)` table (`tclOOInfo.c`), so `cl`/`ob`/
/// `t` abbreviate, `m` is ambiguous (metaclass/mixin), and the enumeration
/// keeps the Oxford comma the *method* lists drop.
///
/// tclsh 8.6.16 / 9.0.4:
///   info object isa x o  -> bad category "x": must be class, metaclass,
///                           mixin, object, or typeof
///   info object isa {} o -> ambiguous category "": must be <same>
///   info object isa m o  -> ambiguous category "m": must be <same>
///   info object isa cl o -> 0 ; ob o -> 1 ; me o -> 0 ; t o C -> 1
///   o x                  -> unknown method "x": must be destroy or m
#[test]
fn info_object_isa_category_resolves_like_tcl_get_index_from_obj() {
    const MUST: &str = "must be class, metaclass, mixin, object, or typeof";
    const SETUP: &str = "oo::class create C { method m {} {return 1} }\nC create o\n";
    let msg = |tail: &str| {
        let (ok, result, _) = run(&format!("{SETUP}{tail}"));
        assert!(!ok, "expected an error for {tail}");
        result
    };
    assert_eq!(
        msg("info object isa x o"),
        format!("bad category \"x\": {MUST}")
    );
    assert_eq!(
        msg("info object isa {} o"),
        format!("ambiguous category \"\": {MUST}")
    );
    assert_eq!(
        msg("info object isa m o"),
        format!("ambiguous category \"m\": {MUST}")
    );
    assert_eq!(run(&format!("{SETUP}info object isa cl o")).1, "0");
    assert_eq!(run(&format!("{SETUP}info object isa ob o")).1, "1");
    assert_eq!(run(&format!("{SETUP}info object isa me o")).1, "0");
    assert_eq!(run(&format!("{SETUP}info object isa t o C")).1, "1");
    // The method list keeps TclOO's own join, which drops the Oxford comma the
    // option tables above keep.
    //
    // tclsh 8.6.16 / 9.0.4:
    //   o3 zz -> unknown method "zz": must be a, b, c or destroy
    assert_eq!(msg("o x"), "unknown method \"x\": must be destroy or m");
    assert_eq!(msg("o {}"), "unknown method \"\": must be destroy or m");
    let (ok, four, _) = run(
        "oo::class create C3 { method a {} {}; method b {} {}; method c {} {} }\n\
         C3 create o3\no3 zz",
    );
    assert!(!ok);
    assert_eq!(four, "unknown method \"zz\": must be a, b, c or destroy");
}

#[test]
fn tip558_configurable_custom_get_set() { /* PURE_ASSERTION_BODY_tip558_configurable_custom_get_set */ }

#[test]
fn tip558_configurable_property_name_validation() {
    // ooProp-3.3..3.7: property names must be simple, dash-free, unqualified.
    for (spec, want) in [
        ("-x", "bad property name \"-x\": must not begin with -"),
        ("{x y}", "bad property name \"x y\": must be a simple word"),
        (
            "::x",
            "bad property name \"::x\": must not contain namespace separators",
        ),
        (
            "x(",
            "bad property name \"x(\": must not contain parentheses",
        ),
    ] {
        let (ok, msg, _) = run(&format!(
            "oo::configurable create P {{ superclass oo::object }}\n\
             oo::define P {{ property {spec} }}"
        ));
        assert!(!ok, "{spec} should error");
        assert_eq!(msg, want, "for property {spec}");
    }
}

#[test]
fn tip558_configurable_option_abbreviation() { /* PURE_ASSERTION_BODY_tip558_configurable_option_abbreviation */ }

#[test]
fn tip558_property_and_info_options_match_tcl_prefix_diagnostics() {
    for (script, want) in [
        (
            "oo::configurable create P {property x -}",
            "ambiguous option \"-\": must be -get, -kind, or -set",
        ),
        (
            "oo::configurable create Q {property x -kind r}",
            "ambiguous kind \"r\": must be readable, readwrite, or writable",
        ),
    ] {
        let (ok, message, _) = run(script);
        assert!(!ok, "{script} should error");
        assert_eq!(message, want);
    }

    assert_eq!(
        result(
            "oo::configurable create C {property x}\n\
             set o [C new]\n\
             list [info class properties C -a] [info object properties $o -a]"
        ),
        "-x -x"
    );
    for (script, want) in [
        (
            "oo::configurable create C {property x}; info class properties C {}",
            "ambiguous option \"\": must be -all, -readable, or -writable",
        ),
        (
            "oo::configurable create C {property x}; set o [C new]; info object properties $o -",
            "ambiguous option \"-\": must be -all, -readable, or -writable",
        ),
    ] {
        let (ok, message, _) = run(script);
        assert!(!ok, "{script} should error");
        assert_eq!(message, want);
    }
}

#[test]
fn tip558_configurable_not_on_plain_class() {
    // ooProp T12/T28: `property` is not a command in a non-configurable define
    // body, but a plain subclass's *instances* still inherit `configure`.
    let (ok, msg, _) = run("oo::class create NC {}\noo::define NC { property x }");
    assert!(!ok);
    assert_eq!(msg, "invalid command name \"property\"");
    assert_eq!(
        result(
            "oo::configurable create P { property x; constructor {} {my configure -x 7} }\n\
             oo::class create Q { superclass P }\n\
             [Q new] configure -x"
        ),
        "7"
    );
}

#[test]
fn tip558_configurable_define_errorinfo_frame() { /* PURE_ASSERTION_BODY_tip558_configurable_define_errorinfo_frame */ }

#[test]
fn destroying_a_class_cascades_to_instances_and_subclasses() { /* PURE_ASSERTION_BODY_destroying_a_class_cascades_to_instances_and_subclasses */ }

#[test]
fn constructor_and_instance_variables() { /* PURE_ASSERTION_BODY_constructor_and_instance_variables */ }

#[test]
fn create_with_explicit_name() { /* PURE_ASSERTION_BODY_create_with_explicit_name */ }

#[test]
fn instances_have_independent_state() { /* PURE_ASSERTION_BODY_instances_have_independent_state */ }

#[test]
fn empty_constructor_body_ignores_extra_args() { /* PURE_ASSERTION_BODY_empty_constructor_body_ignores_extra_args */ }

// Inheritance, next, nextto

#[test]
fn single_inheritance_next() { /* PURE_ASSERTION_BODY_single_inheritance_next */ }

#[test]
fn multilevel_next_chain() { /* PURE_ASSERTION_BODY_multilevel_next_chain */ }

#[test]
fn diamond_inheritance_linearisation() { /* PURE_ASSERTION_BODY_diamond_inheritance_linearisation */ }

#[test]
fn nextto_resumes_at_named_class() { /* PURE_ASSERTION_BODY_nextto_resumes_at_named_class */ }

#[test]
fn next_past_end_errors() {
    // tclsh 9.0.4: -> no next method implementation
    let (ok, msg, _) = run("oo::class create C { method m {} { next } }; [C new] m");
    assert!(!ok);
    assert_eq!(msg, "no next method implementation");
}

#[test]
fn constructor_next_chains_to_superclass() {
    // tclsh 9.0.4: prints "B\nS", derived constructor runs after next.
    let (ok, _, out) = run("oo::class create Base { constructor {} {puts B} }; \
         oo::class create Sub { superclass Base; constructor {} {next; puts S} }; \
         Sub new");
    assert!(ok);
    assert_eq!(out, "B\nS\n");
}

// self / my

#[test]
fn self_returns_object_name() { /* PURE_ASSERTION_BODY_self_returns_object_name */ }

#[test]
fn self_class_and_method() { /* PURE_ASSERTION_BODY_self_class_and_method */ }

#[test]
fn self_class_reports_declaring_class_via_inheritance() { /* PURE_ASSERTION_BODY_self_class_reports_declaring_class_via_inheritance */ }

#[test]
fn my_calls_unexported_method() {
    // tclsh 9.0.4: an uppercase-initial method is unexported; `my` reaches it.
    assert_eq!(
        result(
            "oo::class create C { method Helper {} {return secret}; method use {} {return [my Helper]} }; \
             [C new] use"
        ),
        "secret"
    );
    // But it is not publicly callable.
    let (ok, msg, _) = run("oo::class create C { method Helper {} {return h} }; [C new] Helper");
    assert!(!ok);
    assert_eq!(msg, "unknown method \"Helper\": must be destroy");
}

#[test]
fn my_variable_links_instance_state() { /* PURE_ASSERTION_BODY_my_variable_links_instance_state */ }

#[test]
fn automatic_instance_variable_link_yields_to_a_formal_local() {
    // Exact Tcl 9.0.4 transcript. Declaring x as an instance variable does not
    // replace the method's already-bound formal x.
    assert_eq!(
        result("oo::class create C {variable x; method m {x} {return $x}}; [C new] m ARG"),
        "ARG"
    );

    // Explicit linking is different: it still reaches the shared upvar
    // collision check and refuses to replace the formal.
    let (ok, message, _) =
        run("oo::class create D {variable x; method m {x} {my variable x}}; [D new] m ARG");
    assert!(!ok);
    assert_eq!(message, "variable \"x\" already exists");
}

// Export / unexport, unknown-method errors

#[test]
fn export_default_is_lowercase_initial() {
    // tclsh 9.0.4: alpha (public) listed, _priv / Cap not -> lists exported set.
    let (ok, msg, _) = run(
        "oo::class create C { method beta {} {}; method alpha {} {}; method _priv {} {} }; \
         [C new] zzz",
    );
    assert!(!ok);
    assert_eq!(
        msg,
        "unknown method \"zzz\": must be alpha, beta or destroy"
    );
}

#[test]
fn unexport_hides_from_public_dispatch() { /* PURE_ASSERTION_BODY_unexport_hides_from_public_dispatch */ }

#[test]
fn class_factory_names_in_unknown_error() {
    // tclsh 9.0.4: a class exposes create/new/destroy; oo::class hides new.
    let (_, msg, _) = run("oo::class new");
    assert_eq!(msg, "unknown method \"new\": must be create or destroy");
}

// Destruction

#[test]
fn destroy_runs_destructor_and_removes_command() {
    // tclsh 9.0.4: destructor prints, then the command is gone.
    let (ok, _, out) = run("oo::class create C { destructor {puts bye} }; C create o; o destroy");
    assert!(ok);
    assert_eq!(out, "bye\n");
}

#[test]
fn destructor_next_chains() {
    // tclsh 9.0.4: -> "B-d\nD-d" wait: derived destructor calls next first.
    let (ok, _, out) = run("oo::class create B { destructor {puts B-d} }; \
         oo::class create D { superclass B; destructor {next; puts D-d} }; \
         D create o; o destroy");
    assert!(ok);
    assert_eq!(out, "B-d\nD-d\n");
}

#[test]
fn rename_preserves_object_and_class_identity() { /* PURE_ASSERTION_BODY_rename_preserves_object_and_class_identity */ }

#[test]
fn renamed_object_destroy_removes_the_destination_command() { /* PURE_ASSERTION_BODY_renamed_object_destroy_removes_the_destination_command */ }

#[test]
fn namespace_teardown_destroys_tcloo_commands() { /* PURE_ASSERTION_BODY_namespace_teardown_destroys_tcloo_commands */ }

#[test]
fn retained_and_recreated_tcloo_commands_have_distinct_identity() { /* PURE_ASSERTION_BODY_retained_and_recreated_tcloo_commands_have_distinct_identity */ }

#[test]
fn replacing_tcloo_commands_runs_their_delete_lifecycle() { /* PURE_ASSERTION_BODY_replacing_tcloo_commands_runs_their_delete_lifecycle */ }

#[test]
fn relative_qualified_object_publication_uses_the_resolved_slot() { /* PURE_ASSERTION_BODY_relative_qualified_object_publication_uses_the_resolved_slot */ }

#[test]
fn destroying_a_hidden_object_unlinks_its_hidden_command_token() { /* PURE_ASSERTION_BODY_destroying_a_hidden_object_unlinks_its_hidden_command_token */ }

#[test]
fn exposing_a_hidden_object_does_not_rename_its_public_identity() { /* PURE_ASSERTION_BODY_exposing_a_hidden_object_does_not_rename_its_public_identity */ }

#[test]
fn retained_tcloo_self_destroy_retires_the_exact_command_token() { /* PURE_ASSERTION_BODY_retained_tcloo_self_destroy_retires_the_exact_command_token */ }

#[test]
fn colon_colliding_object_slots_keep_distinct_identity() { /* PURE_ASSERTION_BODY_colon_colliding_object_slots_keep_distinct_identity */ }

// oo::define / oo::objdefine

#[test]
fn oo_define_adds_method_later() { /* PURE_ASSERTION_BODY_oo_define_adds_method_later */ }

#[test]
fn oo_objdefine_per_instance_method() { /* PURE_ASSERTION_BODY_oo_objdefine_per_instance_method */ }

#[test]
fn oo_define_change_superclass() { /* PURE_ASSERTION_BODY_oo_define_change_superclass */ }

// Method-context commands outside a method

#[test]
fn context_commands_outside_method_are_invalid() {
    // tclsh 9.0.4: self/my/next/nextto are only defined inside a method body.
    for cmd in ["self", "my", "next", "nextto"] {
        let (ok, msg, _) = run(&format!("catch {{{cmd}}} e; set e"));
        assert!(ok);
        assert_eq!(
            msg,
            format!("invalid command name \"{cmd}\""),
            "cmd = {cmd}"
        );
    }
}

// info object / info class

#[test]
fn info_object_class_and_isa() { /* PURE_ASSERTION_BODY_info_object_class_and_isa */ }

#[test]
fn info_class_introspection() { /* PURE_ASSERTION_BODY_info_class_introspection */ }

#[test]
fn info_class_methods_lists_only_exported() { /* PURE_ASSERTION_BODY_info_class_methods_lists_only_exported */ }

// forward, mixin

#[test]
fn forward_delegates_to_prefix() { /* PURE_ASSERTION_BODY_forward_delegates_to_prefix */ }

#[test]
fn bodyless_forward_needs_no_runtime_procedure_compiler() {
    let (ok, value) = run_without_compiler(
        "oo::class create C; oo::define C forward len string length; C create o; o len hello",
    );
    assert!(ok, "forward failed without compiler: {value}");
    assert_eq!(value, "5");
}

#[test]
fn forward_requires_a_target_command() {
    let (ok, value, _) = run("oo::class create C {forward missing}");
    assert!(!ok);
    assert_eq!(
        value,
        "wrong # args: should be \"forward name cmdName ?arg ...?\""
    );
}

#[test]
fn mixin_adds_methods() { /* PURE_ASSERTION_BODY_mixin_adds_methods */ }

// A realistic object: a stack

#[test]
fn realistic_stack_object() { /* PURE_ASSERTION_BODY_realistic_stack_object */ }

// Recursive method dispatch: native-stack safety.

/// A recursive method call (or `next`/mixin chain) is a genuine native Rust
/// call per level (`TclOO` method dispatch bypasses the proc trampoline that
/// makes ordinary recursive `proc` calls native-stack-free) — empirically,
/// unguarded recursion overflowed the native stack (SIGABRT) between depth
/// 45 and 48 on a 2 MiB thread (`cargo test`'s per-test default).
/// `OO_DISPATCH_DEPTH_LIMIT` (20) now turns that into a catchable error
/// well before the crash floor.
#[test]
fn deeply_recursive_method_errors_instead_of_crashing() {
    let (ok, res, _) = run("oo::class create C { \
           method go {n} { if {$n <= 0} { return done }; return [my go [expr {$n-1}]] } \
         }; \
         C create obj; obj go 1000");
    assert!(!ok, "expected a catchable error, got {res:?}");
    assert!(
        res.contains("too many nested evaluations"),
        "unexpected error: {res:?}"
    );
}

/// A moderately recursive method (well under `OO_DISPATCH_DEPTH_LIMIT`)
/// still runs normally — the safety net must not fire on realistic
/// recursion depths.
#[test]
fn moderately_recursive_method_still_runs() { /* PURE_ASSERTION_BODY_moderately_recursive_method_still_runs */ }
