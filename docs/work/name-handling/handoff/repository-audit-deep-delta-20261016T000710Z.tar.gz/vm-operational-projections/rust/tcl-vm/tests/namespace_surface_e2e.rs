// tcl-lsp — a language server and toolchain for Tcl
// Copyright (C) 2026 James Deucker (bitwisecook) <https://github.com/bitwisecook>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.
//
// SPDX-License-Identifier: AGPL-3.0-or-later

//! `namespace` command-surface regression vectors.
//!
//! Every expectation is pinned byte-for-byte against tclsh 8.6.16 *and*
//! tclsh 9.0.4 unless a `9.0:` comment records a deliberate release
//! difference. The governing C functions are named per group.

use std::cell::RefCell;
use std::io::Write;
use std::rc::Rc;

use tcl_compiler::compile_service::BytecodeCompileService;
use tcl_vm::{CompileService, Vm};

/// A `Write` sink backed by a shared buffer the test can read afterwards.
#[derive(Clone, Default)]
struct Capture(Rc<RefCell<Vec<u8>>>);

impl Write for Capture {
    fn write(&mut self, buf: &[u8]) -> std::io::Result<usize> {
        self.0.borrow_mut().extend_from_slice(buf);
        Ok(buf.len())
    }
    fn flush(&mut self) -> std::io::Result<()> {
        Ok(())
    }
}

/// Compile and run `src` on a VM pinned to `release`; return the result
/// string (an uncaught error leaves its message there), or the compile
/// rejection.
fn run_at(src: &str, release: &str) -> String {
    let profile = tcl_registry::model::ingress::resolve_environment(release).analyser_profile();
    let svc = BytecodeCompileService::for_profile(profile);
    let asm = match svc.compile(src) {
        Ok(asm) => asm,
        Err(e) => return e.to_string(),
    };
    let mut vm = Vm::with_output(Box::new(Capture::default()));
    vm.set_dialect_profile(profile);
    vm.set_compiler(Box::new(BytecodeCompileService::for_profile(profile)));
    vm.run_module(&asm).result.to_str().to_string()
}

/// [`run_at`] at the VM's default release (9.0), for the vectors tclsh 8.6.16
/// and 9.0.4 agree on.
fn run(src: &str) -> String {
    run_at(src, "tcl9.0")
}

/// Run each `(release, script)` step on **one** VM, re-pinning its profile
/// between steps; the last step's result is returned. Real tclsh cannot change
/// release mid-session, so this exists only for invariants about what the
/// emulated surface must do when an embedder re-pins it.
fn run_flipping(steps: &[(&str, &str)]) -> String {
    let mut vm = Vm::with_output(Box::new(Capture::default()));
    let mut last = String::new();
    for (release, src) in steps {
        let profile = tcl_registry::model::ingress::resolve_environment(release).analyser_profile();
        vm.set_dialect_profile(profile);
        vm.set_compiler(Box::new(BytecodeCompileService::for_profile(profile)));
        match BytecodeCompileService::for_profile(profile).compile(src) {
            Ok(asm) => last = vm.run_module(&asm).result.to_str().to_string(),
            Err(e) => return e.to_string(),
        }
    }
    last
}

// `namespace which -variable` never answers with a call frame
// (`NamespaceWhichCmd` → `Tcl_FindNamespaceVar`, tclNamesp.c:4657)

#[test]
fn which_variable_ignores_proc_locals() { /* PURE_ASSERTION_BODY_which_variable_ignores_proc_locals */ }

#[test]
fn which_variable_resolves_real_namespace_variables() { /* PURE_ASSERTION_BODY_which_variable_resolves_real_namespace_variables */ }

#[test]
fn which_variable_global_fallback_is_a_release_axis() {
    // `ObjFindNamespaceVar` hands `TclGetNamespaceForQualName` two candidate
    // namespaces; Tcl 9.0 added `flags |= TCL_NAMESPACE_ONLY`
    // (tcl9.0.4 tclVar.c:5951), blanking the second.
    let src = "set ::gv 1\nnamespace eval n {}\nnamespace eval n {namespace which -variable gv}";
    // tclsh 8.6.16: ::gv
    assert_eq!(run_at(src, "tcl8.6"), "::gv");
    // tclsh 9.0.4: {}
    assert_eq!(run_at(src, "tcl9.0"), "");
}

#[test]
fn declared_but_unset_namespace_variables_are_introspectable() { /* PURE_ASSERTION_BODY_declared_but_unset_namespace_variables_are_introspectable */ }

#[test]
fn namespace_which_validates_its_positional_option_shape() {
    let usage = "wrong # args: should be \"namespace which ?-command? ?-variable? name\"";
    assert_eq!(run("catch {namespace which -zork puts} m; set m"), usage);
    assert_eq!(
        run("catch {namespace which -command puts extra} m; set m"),
        usage
    );
    // With one word there is no option position: even an option-looking word
    // is the command name, and an unresolved command produces the empty value.
    assert_eq!(run("namespace which -command"), "");
}

#[test]
fn origin_follows_import_chains() { /* PURE_ASSERTION_BODY_origin_follows_import_chains */ }

/// The `Namespaces::command_origin` contract: `None` means "not an imported
/// command" (C's `cmdPtr->deleteProc == DeleteImportedCmd`), so a shared core
/// can tell the two apart. Answering `Some(self)` for every command would be
/// invisible through `namespace origin` — it folds both onto the same
/// answer — leaving the trait unusable for anything that needs the
/// distinction, and disagreeing with the WASM runtime's implementation.
#[test]
fn command_origin_reports_none_for_a_command_that_was_not_imported() {
    use tcl_runtime_api::Namespaces;

    let profile = tcl_registry::model::ingress::resolve_environment("tcl9.0").analyser_profile();
    let svc = BytecodeCompileService::for_profile(profile);
    let asm = svc
        .compile(
            "namespace eval src {namespace export p; proc p {} {return P}}\n\
             namespace eval dst {namespace import ::src::p}",
        )
        .expect("setup compiles");
    let mut vm = Vm::with_output(Box::new(Capture::default()));
    vm.set_dialect_profile(profile);
    vm.set_compiler(Box::new(BytecodeCompileService::for_profile(profile)));
    assert!(vm.run_module(&asm).code.is_ok());

    let cur = Namespaces::current(&vm);
    let imported = vm.find_command(cur, "::dst::p").expect("the import exists");
    let source = vm.find_command(cur, "::src::p").expect("the source exists");
    let builtin = vm.find_command(cur, "set").expect("a builtin exists");

    let origin = vm
        .command_origin(imported)
        .expect("an import has an origin");
    assert_eq!(vm.command_name(origin).as_deref(), Some("::src::p"));
    assert_eq!(
        vm.command_origin(source),
        None,
        "a plain proc is not an import"
    );
    assert_eq!(
        vm.command_origin(builtin),
        None,
        "a builtin is not an import"
    );
}

// `namespace export` / `import` leading-option handling
// (`NamespaceExportCmd`/`Tcl_Export`, `NamespaceImportCmd`/`Tcl_Import`)

#[test]
fn export_query_form_reports_the_pattern_list() { /* PURE_ASSERTION_BODY_export_query_form_reports_the_pattern_list */ }

#[test]
fn export_clear_really_clears() { /* PURE_ASSERTION_BODY_export_clear_really_clears */ }

#[test]
fn only_the_first_word_is_the_export_flag() { /* PURE_ASSERTION_BODY_only_the_first_word_is_the_export_flag */ }

#[test]
fn only_the_first_word_is_the_import_flag() {
    let setup = "namespace eval s3 {namespace export q; proc q {} {return Q}}\n";
    // A trailing `-force` is an ordinary pattern, and an unqualified pattern
    // names no source namespace (tclsh 8.6.16 / 9.0.4).
    assert_eq!(
        run(&format!(
            "{setup}namespace eval t3 {{catch {{namespace import ::s3::q -force}} m; set m}}"
        )),
        "no namespace specified in import pattern \"-force\""
    );
    // The import that preceded the bad pattern still happened, as in C.
    assert_eq!(
        run(&format!(
            "{setup}namespace eval t3 {{catch {{namespace import ::s3::q -force}}}}\n\
             info commands ::t3::*"
        )),
        "::t3::q"
    );
    // A *leading* -force is the flag.
    assert_eq!(
        run(&format!(
            "{setup}namespace eval t4 {{namespace import -force ::s3::q}}\n\
             info commands ::t4::*"
        )),
        "::t4::q"
    );
    // The introspection form lists the current namespace's imports.
    assert_eq!(
        run(&format!(
            "{setup}namespace eval t5 {{namespace import ::s3::q; namespace import}}"
        )),
        "q"
    );
}

#[test]
fn namespace_import_rejects_self_and_unknown_sources() { /* PURE_ASSERTION_BODY_namespace_import_rejects_self_and_unknown_sources */ }

// Namespace teardown (`TclTeardownNamespace`, tclNamesp.c:1084)

/// A rename whose destination lands in the caller's *retained* namespace — one
/// the running proc deleted out from under itself — leaves nothing publicly
/// addressable at the new key: `register_command` ends in
/// `absorb_retained_binding`, which moves the fresh binding into the retained
/// namespace's own table. Anything on the rename path that expects to read the
/// command back out of the live map afterwards is therefore wrong. tclsh
/// 8.6.16 and 9.0.4 both complete the rename and invoke the ensemble.
#[test]
fn renaming_an_ensemble_into_a_retained_namespace_still_dispatches() { /* PURE_ASSERTION_BODY_renaming_an_ensemble_into_a_retained_namespace_still_dispatches */ }

#[test]
fn deleting_a_namespace_clears_paths_in_both_directions() { /* PURE_ASSERTION_BODY_deleting_a_namespace_clears_paths_in_both_directions */ }

#[test]
fn deleting_a_namespace_clears_its_own_path_and_unknown_handler() { /* PURE_ASSERTION_BODY_deleting_a_namespace_clears_its_own_path_and_unknown_handler */ }

#[test]
fn an_unset_namespace_unknown_is_empty_outside_the_global_namespace() { /* PURE_ASSERTION_BODY_an_unset_namespace_unknown_is_empty_outside_the_global_namespace */ }

#[test]
fn deleting_a_namespace_deletes_its_ensembles() { /* PURE_ASSERTION_BODY_deleting_a_namespace_deletes_its_ensembles */ }

#[test]
fn namespace_owned_ensemble_trace_precedes_the_dying_marker() { /* PURE_ASSERTION_BODY_namespace_owned_ensemble_trace_precedes_the_dying_marker */ }

#[test]
fn namespace_owned_ensembles_retire_live_heads_in_creation_order() { /* PURE_ASSERTION_BODY_namespace_owned_ensembles_retire_live_heads_in_creation_order */ }

#[test]
fn parent_teardown_reaches_each_child_after_parent_commands() { /* PURE_ASSERTION_BODY_parent_teardown_reaches_each_child_after_parent_commands */ }

#[test]
fn child_namespace_teardown_uses_tcl_string_hash_order() { /* PURE_ASSERTION_BODY_child_namespace_teardown_uses_tcl_string_hash_order */ }

#[test]
fn namespace_teardown_uses_command_table_tcl_string_hash_order() { /* PURE_ASSERTION_BODY_namespace_teardown_uses_command_table_tcl_string_hash_order */ }

#[test]
fn command_table_hash_order_records_table_growth() { /* PURE_ASSERTION_BODY_command_table_hash_order_records_table_growth */ }

#[test]
fn command_table_hash_order_retains_capacity_across_deletions() { /* PURE_ASSERTION_BODY_command_table_hash_order_retains_capacity_across_deletions */ }

#[test]
fn command_table_hash_order_moves_a_redefined_command() { /* PURE_ASSERTION_BODY_command_table_hash_order_moves_a_redefined_command */ }

#[test]
fn namespace_teardown_visits_a_callback_created_command_in_the_next_pass() { /* PURE_ASSERTION_BODY_namespace_teardown_visits_a_callback_created_command_in_the_next_pass */ }

#[test]
fn namespace_teardown_defers_a_callback_recreated_command_to_the_next_pass() { /* PURE_ASSERTION_BODY_namespace_teardown_defers_a_callback_recreated_command_to_the_next_pass */ }

#[test]
fn namespace_teardown_skips_a_command_a_callback_already_deleted() { /* PURE_ASSERTION_BODY_namespace_teardown_skips_a_command_a_callback_already_deleted */ }

#[test]
fn namespace_teardown_places_imports_at_their_hash_positions() {
    // An imported redirect occupies an ordinary cmdTable entry, so it retires
    // at its own hash position rather than in a separate pass over the
    // namespace's imports. Exact Tcl 9.0.4 oracle result.
    let imports = "set log {}
             proc rec {old new op} {lappend ::log [namespace tail $old]}
             namespace eval S {proc s1 {} {}; proc s2 {} {}; namespace export s*}
             namespace eval N {namespace import ::S::s1 ::S::s2}
             foreach n {one two three four five six seven eight} {proc ::N::$n {} {}}
             foreach n [info commands ::N::*] {trace add command $n delete rec}
             namespace delete ::N
             set log";
    assert_eq!(
        run(imports),
        "six four three s1 eight seven s2 five two one"
    );
    // `namespace forget` deletes the entry and the re-import creates a new one
    // at the same bucket head, so the order is unchanged.
    assert_eq!(
        run("set log {}
             proc rec {old new op} {lappend ::log [namespace tail $old]}
             namespace eval S {proc s1 {} {}; proc s2 {} {}; namespace export s*}
             namespace eval N {
                 namespace import ::S::s1 ::S::s2
                 namespace forget ::S::s1
                 namespace import ::S::s1
             }
             foreach n {one two three four five six seven eight} {proc ::N::$n {} {}}
             foreach n [info commands ::N::*] {trace add command $n delete rec}
             namespace delete ::N
             set log"),
        "six four three s1 eight seven s2 five two one"
    );
}

#[test]
fn namespace_teardown_retires_each_sources_import_tree_before_the_next_entry() { /* PURE_ASSERTION_BODY_namespace_teardown_retires_each_sources_import_tree_before_the_next_entry */ }

#[test]
fn a_delete_callbacks_own_trace_dies_with_the_dying_token() {
    // `Tcl_DeleteCommandFromToken` frees the whole `cmdPtr->tracePtr` list
    // after `CallCommandTraces`. A trace the callback registers on the command
    // being deleted attaches to that same dying token, so it never fires — not
    // in this walk (`CallCommandTraces` follows `active.nextTracePtr`), and not
    // for a later command that takes the vacated name. Exact Tcl 9.0.4 oracle
    // results (identical on 8.6.16).
    let recorders = "set log {}
             proc inner {old new op} {lappend ::log inner:$old}
             proc outer {old new op} {lappend ::log outer:$old
                 trace add command $old delete inner}\n";
    // `rename cmd {}`.
    assert_eq!(
        run(&format!(
            "{recorders}
             proc p {{}} {{}}
             trace add command ::p delete outer
             rename ::p {{}}
             set a $log
             proc p {{}} {{}}
             rename ::p {{}}
             list $a $log"
        )),
        "outer:::p outer:::p"
    );
    // Redefinition (`TclCreateObjCommandInNs` deletes the old token first).
    assert_eq!(
        run(&format!(
            "{recorders}
             proc p {{}} {{}}
             trace add command ::p delete outer
             proc p {{}} {{}}
             set a $log
             proc p {{}} {{}}
             set b $log
             rename ::p {{}}
             list $a $b $log"
        )),
        "outer:::p outer:::p outer:::p"
    );
    // Namespace teardown.
    assert_eq!(
        run(&format!(
            "{recorders}
             namespace eval N {{proc q {{}} {{}}}}
             trace add command ::N::q delete outer
             namespace delete ::N
             set a $log
             namespace eval N {{proc q {{}} {{}}}}
             namespace delete ::N
             list $a $log"
        )),
        "outer:::N::q outer:::N::q"
    );
}

#[test]
fn a_replacements_trace_survives_the_deletion_that_created_it() {
    // The other half of the same rule: a callback that *binds* a replacement
    // at the vacated name registers on that new token, whose own trace list C
    // never touches. Only the dying token's list is freed. Exact Tcl 9.0.4
    // oracle results (identical on 8.6.16).
    let recorders = "set log {}
             proc inner {old new op} {lappend ::log inner:$old}
             proc mk {old new op} {lappend ::log mk:$old
                 proc ::p {} {}
                 trace add command ::p delete inner}\n";
    assert_eq!(
        run(&format!(
            "{recorders}
             proc p {{}} {{}}
             trace add command ::p delete mk
             rename ::p {{}}
             set a [list $log [llength [info commands ::p]]]
             rename ::p {{}}
             list $a $log [llength [info commands ::p]]"
        )),
        "{mk:::p 1} {mk:::p inner:::p} 0"
    );
    // A trace the callback adds *before* the replacement still belongs to the
    // dying token and goes with it; only the one added after survives.
    assert_eq!(
        run("set log {}
             proc early {old new op} {lappend ::log early:$old}
             proc late {old new op} {lappend ::log late:$old}
             proc mk {old new op} {lappend ::log mk:$old
                 trace add command $old delete early
                 proc ::p {} {}
                 trace add command ::p delete late}
             proc p {} {}
             trace add command ::p delete mk
             rename ::p {}
             set a $log
             rename ::p {}
             list $a $log"),
        "mk:::p {mk:::p late:::p}"
    );
}

#[test]
fn a_refused_alias_rename_keeps_the_command_tables_growth() {
    // `TclRenameCommand` creates the destination hash entry *before*
    // `TclPreventAliasLoop` and deletes it again on a refusal, so the transient
    // twelfth entry rebuilds the eleven-command table from 4 buckets to 16 and
    // the grown array outlives the rejected rename. Exact Tcl 9.0.4 oracle
    // results (identical on 8.6.16).
    let eleven = "set log {}
             proc rec {old new op} {lappend ::log [namespace tail $old]}
             namespace eval N {}
             foreach n {one two three four five six seven eight nine ten eleven} {
                 proc ::N::$n {} {}
             }\n";
    let trace_and_delete = "foreach n [info commands ::N::*] {trace add command $n delete rec}
             namespace delete ::N\n";
    assert_eq!(
        run(&format!("{eleven}{trace_and_delete} set log")),
        "six four three eight seven nine five two one eleven ten"
    );
    assert_eq!(
        run(&format!(
            "{eleven}
             interp alias {{}} ::a {{}} ::N::b
             set c [catch {{rename ::a ::N::b}} m]
             {trace_and_delete}
             list $c $m [llength [info commands ::a]] $log"
        )),
        "1 {cannot define or rename alias \"b\": would create a loop} 1 \
         {three seven one two four eleven eight five nine six ten}"
    );
}

#[test]
fn deleting_a_namespace_fully_retires_its_visible_ensemble_once() { /* PURE_ASSERTION_BODY_deleting_a_namespace_fully_retires_its_visible_ensemble_once */ }

#[test]
fn deleting_a_namespace_fully_retires_ordinary_commands_once() { /* PURE_ASSERTION_BODY_deleting_a_namespace_fully_retires_ordinary_commands_once */ }

#[test]
fn namespace_delete_marks_the_namespace_dying_before_command_traces() { /* PURE_ASSERTION_BODY_namespace_delete_marks_the_namespace_dying_before_command_traces */ }

#[test]
fn namespace_exists_uses_namespace_name_canonicalisation() { /* PURE_ASSERTION_BODY_namespace_exists_uses_namespace_name_canonicalisation */ }

#[test]
fn namespace_delete_retires_callback_created_hidden_ensemble_imports() { /* PURE_ASSERTION_BODY_namespace_delete_retires_callback_created_hidden_ensemble_imports */ }

#[test]
fn namespace_path_checks_that_every_entry_exists() { /* PURE_ASSERTION_BODY_namespace_path_checks_that_every_entry_exists */ }

#[test]
fn namespace_delete_accepts_the_global_root() { /* PURE_ASSERTION_BODY_namespace_delete_accepts_the_global_root */ }

#[test]
fn namespace_origin_reports_its_own_usage_for_both_bad_arities() {
    let usage = "wrong # args: should be \"namespace origin name\"";
    assert_eq!(run("catch {namespace origin} m; set m"), usage);
    assert_eq!(run("catch {namespace origin set extra} m; set m"), usage);
}

#[test]
fn namespace_children_matches_tcls_string_hash_iteration_order() {
    let setup = "namespace eval order {}
                 foreach n {one two three four five six seven eight nine ten} {
                     namespace eval ::order::$n {}
                 }\n";
    assert_eq!(
        run(&format!("{setup}namespace children ::order")),
        "::order::six ::order::four ::order::three ::order::eight \
         ::order::seven ::order::nine ::order::five ::order::two \
         ::order::one ::order::ten"
    );
    assert_eq!(
        run(&format!("{setup}namespace children ::order ::order::t*")),
        "::order::three ::order::two ::order::ten"
    );
}

#[test]
fn namespace_children_retains_tcls_hash_capacity_after_deletion() { /* PURE_ASSERTION_BODY_namespace_children_retains_tcls_hash_capacity_after_deletion */ }

// Ensemble option tables and subcommand resolution
// (`TclNamespaceEnsembleCmd` + `NsEnsembleImplementationCmd`, tclEnsemble.c)

#[test]
fn ensemble_create_options_abbreviate() { /* PURE_ASSERTION_BODY_ensemble_create_options_abbreviate */ }

#[test]
fn ensemble_create_has_no_namespace_option() { /* PURE_ASSERTION_BODY_ensemble_create_has_no_namespace_option */ }

#[test]
fn ensemble_create_accepts_parameters_and_threads_them() { /* PURE_ASSERTION_BODY_ensemble_create_accepts_parameters_and_threads_them */ }

#[test]
fn ensemble_wrong_args_list_quotes_the_command_and_parameters() { /* PURE_ASSERTION_BODY_ensemble_wrong_args_list_quotes_the_command_and_parameters */ }

#[test]
fn ensemble_create_checks_pair_arity_before_option_words() {
    // C: `if (objc & 1)` fires before any `Tcl_GetIndexFromObj`
    // (tclEnsemble.c:192), so an odd tail is `wrong # args`, never `bad option`.
    let usage = "wrong # args: should be \"namespace ensemble create ?option value ...?\"";
    assert_eq!(
        run("catch {namespace ensemble create -command} m; set m"),
        usage
    );
    assert_eq!(
        run("catch {namespace ensemble create -command ::zz -sub} m; set m"),
        usage
    );
    assert_eq!(
        run("catch {namespace ensemble create -bogus} m; set m"),
        usage
    );
}

/// Configuring an ensemble through a `namespace import` alias configures the
/// ORIGIN: both spellings then observe the one config, and the alias stays an
/// alias so `namespace origin` still answers the source (tclsh 9.0.4-pinned).
#[test]
fn configuring_an_imported_ensemble_updates_the_origin() {
    let setup = "namespace eval S {namespace export ens\n\
                 proc impl {} {return ORIG}\n\
                 proc impl2 {} {return NEW}\n\
                 namespace ensemble create -command ::S::ens -map {go impl}}\n\
                 namespace eval T {namespace import ::S::ens}\n\
                 namespace eval S {namespace ensemble configure ::T::ens -map {go impl2}}\n";
    // Both spellings dispatch the new target.
    assert_eq!(run(&format!("{setup}::T::ens go")), "NEW");
    assert_eq!(run(&format!("{setup}::S::ens go")), "NEW");
    // Both spellings read back the new config.
    assert_eq!(
        run(&format!(
            "{setup}namespace ensemble configure ::T::ens -map"
        )),
        "go ::S::impl2"
    );
    assert_eq!(
        run(&format!(
            "{setup}namespace ensemble configure ::S::ens -map"
        )),
        "go ::S::impl2"
    );
    // The alias is still an alias — configuring it did not fork a new ensemble.
    assert_eq!(
        run(&format!("{setup}namespace origin ::T::ens")),
        "::S::ens"
    );
}

#[test]
fn imported_ensemble_tracks_atomic_replacement_but_not_true_deletion() { /* PURE_ASSERTION_BODY_imported_ensemble_tracks_atomic_replacement_but_not_true_deletion */ }

#[test]
fn transitive_import_tracks_an_intermediate_replacement_and_deletion() { /* PURE_ASSERTION_BODY_transitive_import_tracks_an_intermediate_replacement_and_deletion */ }

#[test]
fn deleting_an_imported_intermediate_retires_its_downstream_imports() { /* PURE_ASSERTION_BODY_deleting_an_imported_intermediate_retires_its_downstream_imports */ }

#[test]
fn import_delete_trace_can_reimport_the_same_origin_at_the_same_name() { /* PURE_ASSERTION_BODY_import_delete_trace_can_reimport_the_same_origin_at_the_same_name */ }

#[test]
fn import_delete_retires_the_exact_generation_after_trace_relocation() { /* PURE_ASSERTION_BODY_import_delete_retires_the_exact_generation_after_trace_relocation */ }

#[test]
fn source_deletion_refollows_generation_after_import_callbacks() { /* PURE_ASSERTION_BODY_source_deletion_refollows_generation_after_import_callbacks */ }

#[test]
fn import_tree_refollows_parent_generation_after_child_callbacks() { /* PURE_ASSERTION_BODY_import_tree_refollows_parent_generation_after_child_callbacks */ }

#[test]
fn real_delete_retires_the_exact_generation_after_trace_relocation() { /* PURE_ASSERTION_BODY_real_delete_retires_the_exact_generation_after_trace_relocation */ }

#[test]
fn import_cascade_retires_the_relocated_generation_once() { /* PURE_ASSERTION_BODY_import_cascade_retires_the_relocated_generation_once */ }

#[test]
fn interp_hide_and_expose_failures_keep_typed_tcl_identities() { /* PURE_ASSERTION_BODY_interp_hide_and_expose_failures_keep_typed_tcl_identities */ }

#[test]
fn interp_visibility_qualifier_validation_is_shared_by_every_entry_form() { /* PURE_ASSERTION_BODY_interp_visibility_qualifier_validation_is_shared_by_every_entry_form */ }

#[test]
fn imported_binding_delete_trace_runs_before_unlink_and_is_reentrant() { /* PURE_ASSERTION_BODY_imported_binding_delete_trace_runs_before_unlink_and_is_reentrant */ }

#[test]
fn import_delete_traces_are_depth_first_with_visible_ancestors() { /* PURE_ASSERTION_BODY_import_delete_traces_are_depth_first_with_visible_ancestors */ }

#[test]
fn namespace_import_rejects_a_cycle_before_mutating_the_graph() { /* PURE_ASSERTION_BODY_namespace_import_rejects_a_cycle_before_mutating_the_graph */ }

#[test]
fn dying_namespace_handles_are_rejected_during_command_delete_traces() { /* PURE_ASSERTION_BODY_dying_namespace_handles_are_rejected_during_command_delete_traces */ }

#[test]
fn retained_namespace_handle_remains_dead_after_deletion_returns() { /* PURE_ASSERTION_BODY_retained_namespace_handle_remains_dead_after_deletion_returns */ }

#[test]
fn recreated_namespace_does_not_revive_a_retained_dead_token() { /* PURE_ASSERTION_BODY_recreated_namespace_does_not_revive_a_retained_dead_token */ }

#[test]
fn import_created_by_a_source_delete_trace_joins_the_old_token_cascade() { /* PURE_ASSERTION_BODY_import_created_by_a_source_delete_trace_joins_the_old_token_cascade */ }

#[test]
fn imported_ensemble_keeps_source_identity_across_hide_and_expose() {
    let setup = "proc tgt_old args {return OLD}
                 namespace eval S {
                     namespace ensemble create -command ::E -map {x ::tgt_old}
                 }
                 namespace export E
                 namespace eval I {namespace import ::E}
                 interp hide {} ::E held
                 proc ::E args {return REPLACEMENT}\n";
    // A visible same-name replacement must not capture the import whose real
    // source is the hidden token. Exact Tcl 9.0.4 oracle result.
    assert_eq!(
        run(&format!(
            "{setup}list [::I::E x] [namespace origin ::I::E] \
             [namespace ensemble configure ::I::E -map] \
             [namespace ensemble exists ::I::E]"
        )),
        "OLD ::held {x ::tgt_old} 1"
    );
    assert_eq!(
        run(&format!(
            "{setup}interp expose {{}} held E2
             list [::I::E x] [namespace origin ::I::E] \
                  [namespace ensemble configure ::I::E -map] [::E2 x]"
        )),
        "OLD ::E2 {x ::tgt_old} OLD"
    );
}

#[test]
fn command_lookup_codes_are_attached_only_by_real_lookup_failures() { /* PURE_ASSERTION_BODY_command_lookup_codes_are_attached_only_by_real_lookup_failures */ }

#[test]
fn lookup_error_codes_quote_dynamic_names_as_list_elements() { /* PURE_ASSERTION_BODY_lookup_error_codes_quote_dynamic_names_as_list_elements */ }

/// Reconfiguring an ensemble reaches every importer in the chain, not just the
/// direct ones. C hands each import the *source's* command token, so a
/// two-hop chain (`::S::e` imported and re-exported by `::A`, imported again
/// by `::B`) observes one shared definition; the VM clones the dispatcher, so
/// the refresh has to follow provenance to its ultimate origin. Every
/// expectation below is tclsh 9.0.4- and 8.6.16-pinned.
#[test]
fn reconfiguring_an_ensemble_reaches_transitive_importers() {
    let setup = "namespace eval S {\n\
                     namespace export e\n\
                     proc impl1 {args} {return OLD}\n\
                     proc impl2 {args} {return NEW}\n\
                     namespace ensemble create -command ::S::e -map {go ::S::impl1}}\n\
                 namespace eval A {namespace import ::S::e; namespace export e}\n\
                 namespace eval B {namespace import ::A::e}\n\
                 namespace ensemble configure ::S::e -map {go ::S::impl2}\n";
    // Dispatch: all three spellings run the new target.
    assert_eq!(run(&format!("{setup}::S::e go")), "NEW");
    assert_eq!(run(&format!("{setup}::A::e go")), "NEW");
    assert_eq!(run(&format!("{setup}::B::e go")), "NEW");
    // Config query agrees with dispatch at every spelling — the pair that
    // diverged while only direct edges were refreshed.
    for spelling in ["::S::e", "::A::e", "::B::e"] {
        assert_eq!(
            run(&format!(
                "{setup}namespace ensemble configure {spelling} -map"
            )),
            "go ::S::impl2",
            "{spelling}"
        );
    }
    // Provenance is untouched: both imports still answer the original source.
    assert_eq!(run(&format!("{setup}namespace origin ::A::e")), "::S::e");
    assert_eq!(run(&format!("{setup}namespace origin ::B::e")), "::S::e");
}

/// A namespace-scoped link (`namespace upvar`, or an `upvar` at the global
/// level) is a real cell in the namespace's table, so `namespace which
/// -variable` and `info vars` both see it. A *proc*-local alias is a
/// `CompiledLocal` in C and stays invisible. Both directions tclsh-pinned.
#[test]
fn namespace_scoped_links_are_namespace_variables() { /* PURE_ASSERTION_BODY_namespace_scoped_links_are_namespace_variables */ }

/// `-map` is a dict, so the read-back preserves the order the pairs were given
/// (never sorted) and a repeated key keeps its first position while taking the
/// last value. All three expectations are tclsh 9.0.4-pinned.
#[test]
fn ensemble_map_preserves_dict_order_and_collapses_repeats() {
    let setup = "namespace eval M {namespace export *\n\
                 proc zeta {} {return Z}\n\
                 proc alpha {} {return A}\n\
                 proc mid {} {return M}\n\
                 namespace ensemble create -command ::E -map {zz zeta aa alpha}}\n";
    // Insertion order, not sorted — `aa` would sort first.
    assert_eq!(
        run(&format!("{setup}namespace ensemble configure ::E -map")),
        "zz ::M::zeta aa ::M::alpha"
    );
    // A later `configure` replaces the map wholesale, in its own order.
    assert_eq!(
        run(&format!(
            "{setup}namespace eval M {{namespace ensemble configure ::E \
             -map {{mm mid zz zeta aa alpha}}}}\n\
             namespace ensemble configure ::E -map"
        )),
        "mm ::M::mid zz ::M::zeta aa ::M::alpha"
    );
    // A repeated key: last value wins, first position kept.
    assert_eq!(
        run(&format!(
            "{setup}namespace eval M {{namespace ensemble configure ::E \
             -map {{zz zeta aa alpha zz mid}}}}\n\
             namespace ensemble configure ::E -map"
        )),
        "zz ::M::mid aa ::M::alpha"
    );
    // Dispatch follows the collapsed entry, not the stale first one.
    assert_eq!(
        run(&format!(
            "{setup}namespace eval M {{namespace ensemble configure ::E \
             -map {{zz zeta aa alpha zz mid}}}}\n\
             ::E zz"
        )),
        "M"
    );
}

#[test]
fn ensemble_configure_reads_and_writes_the_config_table() {
    let setup = "namespace eval e5 {namespace export *; proc go {} {return G}\n\
                 namespace ensemble create -command ::ab5 -subcommands go}\n";
    // The query dict, in C's option order.
    assert_eq!(
        run(&format!("{setup}namespace ensemble configure ::ab5")),
        "-map {} -namespace ::e5 -parameters {} -prefixes 1 -subcommands go -unknown {}"
    );
    // A single (abbreviated) option reads its value.
    assert_eq!(
        run(&format!("{setup}namespace ensemble configure ::ab5 -sub")),
        "go"
    );
    // `-namespace` is readable but never writable.
    assert_eq!(
        run(&format!(
            "{setup}catch {{namespace ensemble configure ::ab5 -namespace ::e5}} m o
             list $m [dict get $o -errorcode]"
        )),
        "{option -namespace is read-only} {TCL ENSEMBLE READ_ONLY}"
    );
    // `-command` is create-only, so it is not in the configure table.
    assert_eq!(
        run(&format!(
            "{setup}catch {{namespace ensemble configure ::ab5 -command ::zz}} m; set m"
        )),
        "bad option \"-command\": must be -map, -namespace, -parameters, \
         -prefixes, -subcommands, or -unknown"
    );
    // An odd tail longer than one word is `wrong # args`.
    assert_eq!(
        run(&format!(
            "{setup}catch {{namespace ensemble configure ::ab5 -subcommands go -prefixes}} m; set m"
        )),
        "wrong # args: should be \"namespace ensemble configure cmdname \
         ?-option value ...? ?arg ...?\""
    );
    // A write takes effect.
    assert_eq!(
        run(&format!(
            "{setup}namespace ensemble configure ::ab5 -prefixes 0\n\
             namespace ensemble configure ::ab5 -prefixes"
        )),
        "0"
    );
}

#[test]
fn ensemble_dispatch_messages_match_c() {
    // `NsEnsembleImplementationCmd`'s three miss shapes. Note the ensemble
    // enumeration keeps its comma before `or` for two entries.
    let two = "namespace eval e7 {namespace export *; proc bar {} {}; proc baz {} {}\n\
               namespace ensemble create -command ::ab8}\n";
    assert_eq!(
        run(&format!("{two}catch {{::ab8 ba}} m; set m")),
        "unknown or ambiguous subcommand \"ba\": must be bar, or baz"
    );
    assert_eq!(
        run(&format!("{two}catch {{::ab8 zz}} m; set m")),
        "unknown or ambiguous subcommand \"zz\": must be bar, or baz"
    );
    assert_eq!(
        run(&format!(
            "{two}catch {{::ab8 zz}} m o; list $m [dict get $o -errorcode]"
        )),
        "{unknown or ambiguous subcommand \"zz\": must be bar, or baz} \
         {TCL LOOKUP SUBCOMMAND zz}"
    );
    // `-prefixes 0` drops the "or ambiguous" half.
    let exact = "namespace eval e9 {namespace export *; proc bar {} {}; proc baz {} {}\n\
                 namespace ensemble create -command ::ab10 -prefixes 0}\n";
    assert_eq!(
        run(&format!("{exact}catch {{::ab10 ba}} m; set m")),
        "unknown subcommand \"ba\": must be bar, or baz"
    );
    // An ensemble over a namespace that exports nothing has its own message.
    assert_eq!(
        run(
            "namespace eval e8 {namespace ensemble create -command ::ab9}\n\
             catch {::ab9 zz} m; set m"
        ),
        "unknown subcommand \"zz\": namespace ::e8 does not export any commands"
    );
}

#[test]
fn ensemble_subcommand_scan_matches_c_on_the_empty_word() { /* PURE_ASSERTION_BODY_ensemble_subcommand_scan_matches_c_on_the_empty_word */ }

#[test]
fn ensemble_map_validation_matches_tcl_dict_and_target_errors() { /* PURE_ASSERTION_BODY_ensemble_map_validation_matches_tcl_dict_and_target_errors */ }

#[test]
fn ensemble_unknown_result_is_redispatched_as_a_command_prefix() { /* PURE_ASSERTION_BODY_ensemble_unknown_result_is_redispatched_as_a_command_prefix */ }

#[test]
fn ensemble_unknown_nonempty_prefix_uses_live_parameter_count() { /* PURE_ASSERTION_BODY_ensemble_unknown_nonempty_prefix_uses_live_parameter_count */ }

#[test]
fn ensemble_unknown_exceptional_codes_and_malformed_results_match_c() { /* PURE_ASSERTION_BODY_ensemble_unknown_exceptional_codes_and_malformed_results_match_c */ }

#[test]
fn ensemble_unknown_retains_the_live_command_token() { /* PURE_ASSERTION_BODY_ensemble_unknown_retains_the_live_command_token */ }

#[test]
fn ensemble_unknown_deleted_seeds_the_handler_errorinfo_frame() { /* PURE_ASSERTION_BODY_ensemble_unknown_deleted_seeds_the_handler_errorinfo_frame */ }

#[test]
fn ensemble_default_target_miss_names_the_rewritten_subcommand() { /* PURE_ASSERTION_BODY_ensemble_default_target_miss_names_the_rewritten_subcommand */ }

// The availability gate covers the TclOO root object commands

#[test]
fn tcloo_roots_follow_their_introducing_release() {
    // Real tclsh 8.4/8.5 have no TclOO at all.
    for release in ["tcl8.4", "tcl8.5"] {
        assert_eq!(
            run_at("catch {oo::class create C {}} m; set m", release),
            "invalid command name \"oo::class\"",
            "{release}"
        );
        assert_eq!(
            run_at("catch {oo::object new} m; set m", release),
            "invalid command name \"oo::object\"",
            "{release}"
        );
    }
    // 8.6 has oo::class but not TIP 558's oo::configurable.
    assert_eq!(
        run_at("catch {oo::configurable create C {}} m; set m", "tcl8.6"),
        "invalid command name \"oo::configurable\""
    );
    assert_eq!(run_at("oo::class create D {}", "tcl8.6"), "::D");
    assert_eq!(run_at("oo::configurable create C {}", "tcl9.0"), "::C");
}

#[test]
fn a_script_created_object_is_release_invariant() { /* PURE_ASSERTION_BODY_a_script_created_object_is_release_invariant */ }

#[test]
fn a_hidden_tcloo_root_cannot_be_renamed_back_into_view() { /* PURE_ASSERTION_BODY_a_hidden_tcloo_root_cannot_be_renamed_back_into_view */ }

/// A renamed engine-installed root keeps its **registry identity**, so it is
/// still dated by the name the registry knows rather than by the name it now
/// answers to. Real tclsh cannot switch release mid-session, so this pins the
/// invariant the gate exists to enforce rather than a tclsh transcript: the
/// same command, re-pinned to a release that has no such builtin, must
/// disappear exactly as it would have under its original name.
#[test]
fn a_renamed_tcloo_root_still_gates_by_its_registry_identity() { /* PURE_ASSERTION_BODY_a_renamed_tcloo_root_still_gates_by_its_registry_identity */ }

// A deleted namespace outlives its last active frame.

#[test]
fn deleting_the_running_namespace_retains_it_for_the_frame() { /* PURE_ASSERTION_BODY_deleting_the_running_namespace_retains_it_for_the_frame */ }

#[test]
fn a_namespace_eval_frame_defers_its_own_deletion() { /* PURE_ASSERTION_BODY_a_namespace_eval_frame_defers_its_own_deletion */ }

#[test]
fn inscope_and_apply_frames_defer_their_own_deletion() { /* PURE_ASSERTION_BODY_inscope_and_apply_frames_defer_their_own_deletion */ }

#[test]
fn a_recreated_namespace_is_a_distinct_token_from_the_retained_one() { /* PURE_ASSERTION_BODY_a_recreated_namespace_is_a_distinct_token_from_the_retained_one */ }

#[test]
fn a_retained_token_takes_relative_definitions_only() { /* PURE_ASSERTION_BODY_a_retained_token_takes_relative_definitions_only */ }

#[test]
fn an_absolute_proc_definition_targets_the_live_recreation() { /* PURE_ASSERTION_BODY_an_absolute_proc_definition_targets_the_live_recreation */ }

#[test]
fn a_retained_token_keeps_its_children() { /* PURE_ASSERTION_BODY_a_retained_token_keeps_its_children */ }

#[test]
fn a_retained_token_keeps_its_variables() { /* PURE_ASSERTION_BODY_a_retained_token_keeps_its_variables */ }

#[test]
fn retained_and_recreated_namespace_variables_have_distinct_cells() { /* PURE_ASSERTION_BODY_retained_and_recreated_namespace_variables_have_distinct_cells */ }

#[test]
fn retained_and_recreated_namespace_variable_traces_are_isolated() { /* PURE_ASSERTION_BODY_retained_and_recreated_namespace_variable_traces_are_isolated */ }

#[test]
fn a_suspended_coroutine_releases_its_retained_namespace_on_completion() { /* PURE_ASSERTION_BODY_a_suspended_coroutine_releases_its_retained_namespace_on_completion */ }

#[test]
fn namespace_teardown_fires_trace_only_undefined_cells() { /* PURE_ASSERTION_BODY_namespace_teardown_fires_trace_only_undefined_cells */ }

#[test]
fn namespace_teardown_removes_one_cell_then_purges_its_recreation() { /* PURE_ASSERTION_BODY_namespace_teardown_removes_one_cell_then_purges_its_recreation */ }

#[test]
fn a_retained_token_reports_its_own_name_and_commands() { /* PURE_ASSERTION_BODY_a_retained_token_reports_its_own_name_and_commands */ }

#[test]
fn an_active_child_defers_while_its_parent_tears_down() { /* PURE_ASSERTION_BODY_an_active_child_defers_while_its_parent_tears_down */ }

#[test]
fn command_delete_traces_wait_for_the_last_activation() { /* PURE_ASSERTION_BODY_command_delete_traces_wait_for_the_last_activation */ }

#[test]
fn a_deferred_namespace_is_unpublished_for_every_caller() { /* PURE_ASSERTION_BODY_a_deferred_namespace_is_unpublished_for_every_caller */ }

#[test]
fn an_owned_ensemble_dies_while_its_namespace_is_retained() { /* PURE_ASSERTION_BODY_an_owned_ensemble_dies_while_its_namespace_is_retained */ }

#[test]
fn a_deferred_teardown_keeps_tcl_hash_order() { /* PURE_ASSERTION_BODY_a_deferred_teardown_keeps_tcl_hash_order */ }

#[test]
fn a_command_deleted_from_a_retained_frame_reports_its_own_namespace() { /* PURE_ASSERTION_BODY_a_command_deleted_from_a_retained_frame_reports_its_own_namespace */ }

// A retained token is entered by identity, never by spelling.

#[test]
fn a_retained_procedure_runs_in_its_own_token_not_the_recreations() { /* PURE_ASSERTION_BODY_a_retained_procedure_runs_in_its_own_token_not_the_recreations */ }

#[test]
fn a_relative_namespace_eval_enters_the_retained_child() { /* PURE_ASSERTION_BODY_a_relative_namespace_eval_enters_the_retained_child */ }

#[test]
fn retained_teardown_does_not_unlink_a_recreated_namespace_path_target() { /* PURE_ASSERTION_BODY_retained_teardown_does_not_unlink_a_recreated_namespace_path_target */ }

#[test]
fn a_retained_token_keeps_its_namespace_path() { /* PURE_ASSERTION_BODY_a_retained_token_keeps_its_namespace_path */ }

#[test]
fn a_live_path_keeps_an_exact_retained_target_token() { /* PURE_ASSERTION_BODY_a_live_path_keeps_an_exact_retained_target_token */ }

#[test]
fn a_retained_path_reaches_its_retained_child_target() { /* PURE_ASSERTION_BODY_a_retained_path_reaches_its_retained_child_target */ }

#[test]
fn finalising_a_path_target_unlinks_live_and_retained_owners() { /* PURE_ASSERTION_BODY_finalising_a_path_target_unlinks_live_and_retained_owners */ }

#[test]
fn a_retained_token_loses_its_unknown_handler_and_keeps_its_exports() { /* PURE_ASSERTION_BODY_a_retained_token_loses_its_unknown_handler_and_keeps_its_exports */ }

#[test]
fn relative_qualified_rename_projects_the_resolved_procedure_slot() { /* PURE_ASSERTION_BODY_relative_qualified_rename_projects_the_resolved_procedure_slot */ }

#[test]
fn retained_command_rename_mutates_the_exact_token_table() { /* PURE_ASSERTION_BODY_retained_command_rename_mutates_the_exact_token_table */ }

#[test]
fn retained_command_replacement_retires_the_old_token() { /* PURE_ASSERTION_BODY_retained_command_replacement_retires_the_old_token */ }

#[test]
fn retained_import_query_and_forget_use_the_token_table() { /* PURE_ASSERTION_BODY_retained_import_query_and_forget_use_the_token_table */ }

#[test]
fn retained_namespace_rejects_new_import_publication_without_panicking() { /* PURE_ASSERTION_BODY_retained_namespace_rejects_new_import_publication_without_panicking */ }

#[test]
fn retained_import_graph_retargets_with_its_source_token() { /* PURE_ASSERTION_BODY_retained_import_graph_retargets_with_its_source_token */ }

#[test]
fn retained_import_graph_retires_with_its_source_token() { /* PURE_ASSERTION_BODY_retained_import_graph_retires_with_its_source_token */ }

#[test]
fn namespace_upvar_keeps_the_resolved_retained_namespace_token() { /* PURE_ASSERTION_BODY_namespace_upvar_keeps_the_resolved_retained_namespace_token */ }
