// tcl-lsp — a language server and toolchain for Tcl
// Copyright (C) 2026 James Deucker (bitwisecook) <https://github.com/bitwisecook>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.
//
// SPDX-License-Identifier: AGPL-3.0-or-later

//! End-to-end coroutine tests for the bytecode VM.
//!
//! Every expectation is the output of the same script under a locally-built
//! **tclsh 9.0.4** (the truth oracle). Coroutines are implemented by capturing
//! the explicit activation stack (no OS threads); a `yield` crosses the compiled
//! stack (proc bodies, inline loops, nested proc calls) **and command
//! substitution** — the `set arg [yield $result]` resume-value idiom and
//! `cmd [yield]` argument position both stay on the explicit stack (a whole-word
//! `[…]` compiles to an inline `INVOKE`, not a runtime `subst_word` re-entry).
//!
//! `yield` also crosses `eval`, `uplevel 0`, `catch`, a straight-line `lmap`,
//! `subst`, `try` (body/handler/`finally`, each its own explicit-stack
//! phase), a value-consuming `lmap`/`foreach` runtime fallback (the
//! `each_loop` activation), and a bare `apply` call (bound to a temporary
//! proc run via `pending_eval`, mirroring how `coroutine … apply {lambda}`
//! already runs the lambda on the coroutine's own stack). Each of these runs
//! its body on the explicit stack (a transparent script / catch / try-phase /
//! each-loop activation, the inline collecting loop, or the scanner-driven
//! subst frame) rather than through a nested `Vm::eval_source` drive on the
//! native Rust stack. A `yield` reached across a genuine host re-entry
//! (`lsort -command`'s comparator, an `invoke_command` re-entry from outside
//! the trampoline) still errors `cannot yield: C stack busy` — C Tcl refuses
//! that one too, so `lsort -command` is parity, not a gap.

use std::cell::RefCell;
use std::io::Write;
use std::rc::Rc;

use tcl_compiler::cfg_builder::build_cfg_codegen;
use tcl_compiler::codegen::codegen_module;
use tcl_compiler::compile_service::BytecodeCompileService;
// `lower_to_ir_for_bytecode`, not the analysis-oriented `lower_to_ir` (which
// e.g. emits `beginCatch`-shaped IR for `try` instead of the runtime-call
// shape `tcl-vm-cli` actually compiles). The analysis-oriented lowering does
// not matter for eval/lmap/subst/catch's IR shape, but gives a *different,
// wrong* compiled shape for `try`'s handler/`finally` phases:
// `yield_across_try_handler` would silently run the whole coroutine to
// completion in one resume instead of suspending in the handler, because
// that lowering does not go through `cmd_try` the way the real VM does. See
// `cmd_control_e2e.rs`'s identical import for the precedent.
use tcl_compiler::lowering::lower_to_ir_for_bytecode as lower_to_ir;
use tcl_registry::CommandRegistry;
use tcl_vm::Vm;

#[derive(Clone)]
struct Capture(Rc<RefCell<Vec<u8>>>);

impl Write for Capture {
    fn write(&mut self, buf: &[u8]) -> std::io::Result<usize> {
        self.0.borrow_mut().extend_from_slice(buf);
        Ok(buf.len())
    }
    fn flush(&mut self) -> std::io::Result<()> {
        Ok(())
    }
}

/// Compile and run `src`; return `(ok, result-string, captured-stdout)`.
fn run(src: &str) -> (bool, String, String) {
    let registry = CommandRegistry::build_default();
    let ir = lower_to_ir(src, &registry);
    let cfg = build_cfg_codegen(&ir, false);
    let asm = codegen_module(&cfg, &ir, &registry).expect("original source namespace");

    let buf = Rc::new(RefCell::new(Vec::new()));
    let mut vm = Vm::with_output(Box::new(Capture(Rc::clone(&buf))));
    vm.set_compiler(Box::new(BytecodeCompileService::default()));
    let completion = vm.run_module(&asm);

    let out = String::from_utf8(buf.borrow().clone()).expect("utf-8 output");
    (
        completion.code.is_ok(),
        completion.result.to_str().to_string(),
        out,
    )
}

/// The trimmed result string of a script expected to succeed.
fn result(src: &str) -> String {
    let (ok, res, _) = run(src);
    assert!(ok, "script errored: {res}");
    res
}

// Generators / yield round-trip

#[test]
fn proc_generator() { /* PURE_ASSERTION_BODY_proc_generator */ }

#[test]
fn native_control_conditions_and_expression_requests_suspend() {
    // C Tcl 8.6.18, 9.0.4 and 9.1.0 agree. Dynamic heads force generic
    // command dispatch; expressions never call a potentially shadowed expr.
    let cases = [
        (
            r"proc g {} {set w while; set i 0; $w {[yield condition]} {yield body; incr i}; return $i}; list [coroutine c g] [c 1] [c] [c 0]",
            "condition body condition 1",
        ),
        (
            r"proc h {} {set f for; $f {set i 0} {[yield test]} {incr i} {yield $i}; return $i}; list [coroutine c h] [c 1] [c] [c 0]",
            "test 0 test 1",
        ),
        (
            r"proc k {} {set f if; $f {[yield first]} {return yes} elseif {[yield second]} {return later} else {return no}}; list [coroutine c k] [c 0] [c 1]",
            "first second later",
        ),
        (
            r"proc tcl::mathfunc::pause {x} {yield math; return $x}; proc e {} {set exprcmd expr; $exprcmd {pause(6) + [yield command]}}; list [coroutine c e] [c] [c 4]",
            "math command 10",
        ),
        (
            r#"proc q {} {set exprcmd expr; $exprcmd {"prefix[yield string]" eq {prefixDONE}}}; list [coroutine c q] [c DONE]"#,
            "string 1",
        ),
    ];
    for (script, expected) in cases {
        assert_eq!(result(script), expected, "{script}");
    }
}

#[test]
fn expression_array_indices_and_nested_subst_suspend_without_replaying() {
    // C Tcl 8.6.18, 9.0.4 and 9.1.0: index scripts suspend; a braced
    // variable name keeps its index text literal; abrupt codes propagate.
    for (script, expected) in [
        (
            r#"set ::a(k) VALUE; proc g {} {set e expr; $e {$::a([yield INDEX]) eq "VALUE"}}; list [coroutine c g] [c k]"#,
            "INDEX 1",
        ),
        (
            r#"set ::outer(v) YES; set ::inner(k) v; proc h {} {set e expr; $e {$::outer($::inner([yield NESTED])) eq "YES"}}; list [coroutine c h] [c k]"#,
            "NESTED 1",
        ),
        (
            r#"set {::a([yield])} BRACED; proc q {} {set e expr; $e {${::a([yield])} eq "BRACED"}}; coroutine c q"#,
            "1",
        ),
        (
            r"set ::a(k) VALUE; proc r {} {set s subst; $s {$::a([yield SUBST])}}; list [coroutine c r] [c k]",
            "SUBST VALUE",
        ),
        (
            r"proc bad {} {return -code break}; set e expr; list [catch {$e {$::a([bad])}} msg] $msg",
            "3 {}",
        ),
        (
            r#"proc bad {} {return -code break}; set e expr; list [catch {$e {"before[bad]after"}} msg] $msg"#,
            "3 {}",
        ),
    ] {
        assert_eq!(result(script), expected, "{script}");
    }
}

#[test]
fn native_control_bodies_suspend_on_the_interpreter_stack() { /* PURE_ASSERTION_BODY_native_control_bodies_suspend_on_the_interpreter_stack */ }

#[test]
fn yield_in_while_loop_with_state() { /* PURE_ASSERTION_BODY_yield_in_while_loop_with_state */ }

#[test]
fn yield_across_nested_proc_call() { /* PURE_ASSERTION_BODY_yield_across_nested_proc_call */ }

#[test]
fn yield_resume_value_via_command_substitution() { /* PURE_ASSERTION_BODY_yield_resume_value_via_command_substitution */ }

#[test]
fn accumulator_generator_yield_expression() { /* PURE_ASSERTION_BODY_accumulator_generator_yield_expression */ }

// yield across `catch`

#[test]
fn yield_inside_catch_body_round_trips() { /* PURE_ASSERTION_BODY_yield_inside_catch_body_round_trips */ }

#[test]
fn yield_in_catch_inside_a_generator_loop() { /* PURE_ASSERTION_BODY_yield_in_catch_inside_a_generator_loop */ }

#[test]
fn catch_captures_a_post_resume_error_across_yield() { /* PURE_ASSERTION_BODY_catch_captures_a_post_resume_error_across_yield */ }

#[test]
fn nested_catch_try_multicommand_phases_survive_yields() { /* PURE_ASSERTION_BODY_nested_catch_try_multicommand_phases_survive_yields */ }

#[test]
fn dynamic_catch_try_phase_words_survive_yields_on_runtime_path() { /* PURE_ASSERTION_BODY_dynamic_catch_try_phase_words_survive_yields_on_runtime_path */ }

// yield across `lmap`

#[test]
fn yield_across_lmap_generator_collects() { /* PURE_ASSERTION_BODY_yield_across_lmap_generator_collects */ }

#[test]
fn yield_across_multivar_lmap_generator() { /* PURE_ASSERTION_BODY_yield_across_multivar_lmap_generator */ }

#[test]
fn yield_across_value_consumed_lmap_generator() { /* PURE_ASSERTION_BODY_yield_across_value_consumed_lmap_generator */ }

// yield across `subst`

#[test]
fn yield_across_subst_command_substitutions() { /* PURE_ASSERTION_BODY_yield_across_subst_command_substitutions */ }

#[test]
fn subst_generator_of_bracket_values() { /* PURE_ASSERTION_BODY_subst_generator_of_bracket_values */ }

#[test]
fn catch_absorbs_subst_bracket_error_across_yield() { /* PURE_ASSERTION_BODY_catch_absorbs_subst_bracket_error_across_yield */ }

#[test]
fn yield_in_command_argument_position() { /* PURE_ASSERTION_BODY_yield_in_command_argument_position */ }

// coroutine … apply {lambda}

#[test]
fn coroutine_apply_generator() { /* PURE_ASSERTION_BODY_coroutine_apply_generator */ }

#[test]
fn coroutine_apply_with_parameter() { /* PURE_ASSERTION_BODY_coroutine_apply_with_parameter */ }

#[test]
fn coroutine_apply_lambda_proc_is_cleaned_up() { /* PURE_ASSERTION_BODY_coroutine_apply_lambda_proc_is_cleaned_up */ }

#[test]
fn yield_across_bare_apply_call() { /* PURE_ASSERTION_BODY_yield_across_bare_apply_call */ }

// yield across `try`

#[test]
fn yield_across_try_body() { /* PURE_ASSERTION_BODY_yield_across_try_body */ }

#[test]
fn yield_across_try_handler() { /* PURE_ASSERTION_BODY_yield_across_try_handler */ }

#[test]
fn yield_across_try_finally() { /* PURE_ASSERTION_BODY_yield_across_try_finally */ }

#[test]
fn independent_coroutines_interleave() { /* PURE_ASSERTION_BODY_independent_coroutines_interleave */ }

// Introspection: coroprobe / coroinject / corotype, and multi-arg yieldto

#[test]
fn coroprobe_reads_suspended_context() { /* PURE_ASSERTION_BODY_coroprobe_reads_suspended_context */ }

#[test]
fn coroinject_runs_at_next_resume() { /* PURE_ASSERTION_BODY_coroinject_runs_at_next_resume */ }

#[test]
fn corotype_reports_suspend_kind() {
    // tclsh 9.0.4: `::tcl::unsupported::corotype` reports how a coroutine is
    // parked; a bare `yield` reads "yield".
    assert_eq!(
        result(
            "coroutine c apply {{} { yield; yield 1 }}; c; \
             ::tcl::unsupported::corotype c"
        ),
        "yield"
    );
    let (ok, msg, _) = run("catch {::tcl::unsupported::corotype nope} e; set e");
    assert!(ok);
    assert_eq!(msg, "can only get coroutine type of a coroutine");
}

#[test]
fn yieldto_delivers_all_resume_args_as_a_list() { /* PURE_ASSERTION_BODY_yieldto_delivers_all_resume_args_as_a_list */ }

// info coroutine

#[test]
fn info_coroutine_inside_and_outside() { /* PURE_ASSERTION_BODY_info_coroutine_inside_and_outside */ }

// Errors / guards

#[test]
fn yield_outside_coroutine_errors() {
    // tclsh 9.0.4.
    let (ok, msg, _) = run("catch {yield} e; set e");
    assert!(ok);
    assert_eq!(msg, "yield can only be called in a coroutine");
}

#[test]
fn yieldto_outside_coroutine_errors() {
    let (ok, msg, _) = run("catch {yieldto set x 1} e; set e");
    assert!(ok);
    assert_eq!(msg, "yieldto can only be called in a coroutine");
}

#[test]
fn resuming_a_running_coroutine_errors() { /* PURE_ASSERTION_BODY_resuming_a_running_coroutine_errors */ }

// Teardown: completion, delete, rename

#[test]
fn completed_coroutine_command_is_removed() { /* PURE_ASSERTION_BODY_completed_coroutine_command_is_removed */ }

#[test]
fn coroutine_replaces_a_proc_and_removes_its_command_on_completion() { /* PURE_ASSERTION_BODY_coroutine_replaces_a_proc_and_removes_its_command_on_completion */ }

#[test]
fn coroutine_replacing_its_initial_command_detects_self_resume() {
    // Tcl 9.0.4: the newly-published coroutine command is what its body resolves
    // `foo` to, so the initial call attempts to resume itself while running.
    let (ok, msg, _) = run("coroutine foo foo");
    assert!(!ok);
    assert_eq!(msg, "coroutine \"foo\" is already running");
}

#[test]
fn coroutine_replacing_a_specialised_builtin_deopts_before_self_resume() { /* PURE_ASSERTION_BODY_coroutine_replacing_a_specialised_builtin_deopts_before_self_resume */ }

#[test]
fn completed_hidden_coroutine_is_retired_from_hidden_state() { /* PURE_ASSERTION_BODY_completed_hidden_coroutine_is_retired_from_hidden_state */ }

#[test]
fn completed_hidden_coroutine_fires_its_delete_trace_once() { /* PURE_ASSERTION_BODY_completed_hidden_coroutine_fires_its_delete_trace_once */ }

#[test]
fn equal_visible_and_hidden_tokens_keep_distinct_traces_and_coroutines() { /* PURE_ASSERTION_BODY_equal_visible_and_hidden_tokens_keep_distinct_traces_and_coroutines */ }

#[test]
fn equal_hidden_tokens_hold_independent_coroutines_in_distinct_interpreters() { /* PURE_ASSERTION_BODY_equal_hidden_tokens_hold_independent_coroutines_in_distinct_interpreters */ }

#[test]
fn errored_hidden_coroutine_retires_without_touching_equal_visible_command() { /* PURE_ASSERTION_BODY_errored_hidden_coroutine_retires_without_touching_equal_visible_command */ }

#[test]
fn hidden_alias_to_equal_visible_coroutine_uses_target_domain() { /* PURE_ASSERTION_BODY_hidden_alias_to_equal_visible_coroutine_uses_target_domain */ }

#[test]
fn deleting_a_suspended_coroutine() { /* PURE_ASSERTION_BODY_deleting_a_suspended_coroutine */ }

#[test]
fn renaming_a_coroutine_keeps_it_working() { /* PURE_ASSERTION_BODY_renaming_a_coroutine_keeps_it_working */ }

#[test]
fn body_returning_a_custom_code_propagates_it() { /* PURE_ASSERTION_BODY_body_returning_a_custom_code_propagates_it */ }

#[test]
fn info_coroutine_is_empty_after_self_deletion() { /* PURE_ASSERTION_BODY_info_coroutine_is_empty_after_self_deletion */ }

#[test]
fn completing_coroutine_fires_local_unset_traces() { /* PURE_ASSERTION_BODY_completing_coroutine_fires_local_unset_traces */ }

#[test]
fn deleting_a_suspended_coroutine_fires_local_unset_traces() { /* PURE_ASSERTION_BODY_deleting_a_suspended_coroutine_fires_local_unset_traces */ }

#[test]
fn coroutine_cleanup_preserves_a_callback_created_replacement() { /* PURE_ASSERTION_BODY_coroutine_cleanup_preserves_a_callback_created_replacement */ }

#[test]
fn coroutine_cleanup_retires_a_callback_renamed_generation() { /* PURE_ASSERTION_BODY_coroutine_cleanup_retires_a_callback_renamed_generation */ }

#[test]
fn retained_namespace_teardown_retires_its_suspended_coroutine() { /* PURE_ASSERTION_BODY_retained_namespace_teardown_retires_its_suspended_coroutine */ }

#[test]
fn initial_command_resolves_in_the_creation_namespace() { /* PURE_ASSERTION_BODY_initial_command_resolves_in_the_creation_namespace */ }

#[test]
fn resume_validates_a_coroutine_against_its_parked_namespace() { /* PURE_ASSERTION_BODY_resume_validates_a_coroutine_against_its_parked_namespace */ }

#[test]
fn yield_across_eval() { /* PURE_ASSERTION_BODY_yield_across_eval */ }

#[test]
fn yield_across_uplevel_0() { /* PURE_ASSERTION_BODY_yield_across_uplevel_0 */ }
