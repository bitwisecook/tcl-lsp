// tcl-lsp — a language server and toolchain for Tcl
// Copyright (C) 2026 James Deucker (bitwisecook) <https://github.com/bitwisecook>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.
//
// SPDX-License-Identifier: AGPL-3.0-or-later

//! M16.3 — command traces (`rename`/`delete`) and execution traces
//! (`enter`/`leave`/`enterstep`/`leavestep`) fire with C-faithful shapes.
//!
//! Every vector's stdout is compared against the matching physical-core VM and
//! both pinned C8.6/C9.0 engines through the shared strict oracle runner, so
//! the shapes cannot drift from C Tcl: fully-qualified names in command
//! traces, `{cmd-string op}` / `{cmd-string code result op}` argument forms,
//! an enter-trace error aborting the command, a leave-trace error replacing
//! its result, traces following `rename`, and redefinition firing `delete`.
//!
//! The table also carries the *variable*-trace shapes that depend on which
//! opcode a command compiled to — the operation set an in-proc `lappend` or
//! `unset` reports — since this is the file that owns the differential harness
//! those shapes have to be pinned against.

mod common;

use std::rc::Rc;
use tcl_compiler::compile_service::BytecodeCompileService;
use tcl_dialect::TclVersion;
use tcl_test_support::{JimCapability, require_jimsh, required_tclshs};
use tcl_vm::{Code, Completion, NativeCommand, Value, Vm};

fn vm_output(source: &str) -> String {
    common::vm_output(source, "tcl9.0")
}

struct Vector {
    name: &'static str,
    script: &'static str,
    want: &'static str,
}

const VECTORS: &[Vector] = &[
    // `trace info command|execution` resolves the name with `TCL_LEAVE_ERR_MSG`
    // before reporting (`TraceCommandObjCmd` `tclTrace.c` 9.0.4:661,
    // `TraceExecutionObjCmd` :454), so a command that does not exist is an
    // error carrying the name *as written* — unlike `trace info variable`,
    // which answers the empty list for an untraced or absent variable.
    Vector {
        name: "trace info on a nonexistent command errors, as add and remove do",
        script: "puts [catch {trace info command nosuch} m]|$m\n\
                 puts [catch {trace info execution nosuch} m]|$m\n\
                 puts [catch {trace info variable nosuch} m]|$m\n\
                 puts [catch {trace add command nosuch delete foo} m]|$m\n\
                 puts [catch {trace remove execution nosuch enter foo} m]|$m\n\
                 puts [catch {trace remove variable nosuch write foo} m]|$m\n\
                 puts [catch {trace info command ns::nosuch} m]|$m\n\
                 puts [catch {trace info command nosuch::nosuch} m]|$m\n\
                 proc real {} {}\n\
                 puts [catch {trace info command real} m]|$m\n\
                 namespace eval nn { proc q {} {} }\n\
                 puts [catch {trace info command nn::q} m]|$m\n",
        want: "1|unknown command \"nosuch\"\n\
               1|unknown command \"nosuch\"\n\
               0|\n\
               1|unknown command \"nosuch\"\n\
               1|unknown command \"nosuch\"\n\
               0|\n\
               1|unknown command \"ns::nosuch\"\n\
               1|unknown command \"nosuch::nosuch\"\n\
               0|\n\
               0|",
    },
    Vector {
        name: "command traces: fully-qualified rename/delete shapes, following the rename",
        script: "proc tracer args { puts \"T:[join $args |]\" }\n\
                 proc victim {} {return V}\n\
                 trace add command victim {rename delete} tracer\n\
                 rename victim victim2\n\
                 rename victim2 {}\n",
        want: "T:::victim|::victim2|rename\nT:::victim2||delete",
    },
    Vector {
        name: "trace add command requires the command to exist",
        script: "proc tracer args {}\n\
                 puts [catch {trace add command missing {delete} tracer} m]:$m\n",
        want: "1:unknown command \"missing\"",
    },
    Vector {
        name: "redefining a traced command fires its delete trace",
        script: "proc tracer args { puts \"T:[join $args |]\" }\n\
                 proc dup {} {}\n\
                 trace add command dup delete tracer\n\
                 proc dup {} {return NEW}\n\
                 puts after-redef:[dup]\n",
        want: "T:::dup||delete\nafter-redef:NEW",
    },
    // The `rename` trace window. C creates the destination hash entry, fires
    // the traces, and only then deletes the source one (`tclBasic.c` 9.0.4
    // `TclRenameCommand`), and the traces themselves hang off the shared
    // `Command` rather than off either entry — so a callback resolves *both*
    // names and reaches one trace list through either of them.
    Vector {
        name: "a rename callback still resolves the vacating name",
        script: "proc victim {} { return V }\n\
                 proc et args {}\n\
                 proc tracer args {\n\
                     puts \"live:[llength [info commands ::victim]]|\
                 [llength [info commands ::victim2]]|[victim]|[victim2]\"\n\
                     puts \"cmd:[trace info command victim]|\
                 [trace info command victim2]\"\n\
                     puts \"exec:[trace info execution victim]|\
                 [trace info execution victim2]\"\n\
                 }\n\
                 trace add command victim rename tracer\n\
                 trace add execution victim enter et\n\
                 rename victim victim2\n\
                 puts \"after:[llength [info commands ::victim]]|\
                 [llength [info commands ::victim2]]\"\n",
        want: "live:1|1|V|V\n\
               cmd:{rename tracer}|{rename tracer}\n\
               exec:{enter et}|{enter et}\n\
               after:0|1",
    },
    Vector {
        name: "a rename callback's trace remove through the old name is honoured",
        script: "proc victim {} {}\n\
                 proc c1 args {\n\
                     trace remove command victim rename c1\n\
                     puts \"c1:[trace info command victim]\"\n\
                 }\n\
                 proc c2 args { puts \"c2:[trace info command victim2]\" }\n\
                 trace add command victim rename c2\n\
                 trace add command victim rename c1\n\
                 rename victim victim2\n\
                 puts \"after:[trace info command victim2]\"\n",
        want: "c1:{rename c2}\nc2:{rename c2}\nafter:{rename c2}",
    },
    Vector {
        name: "a rename callback's trace add through the old name follows the command",
        script: "proc victim {} {}\n\
                 proc d1 args { puts \"D:[join $args |]\" }\n\
                 proc r1 args { trace add command victim delete d1 }\n\
                 trace add command victim rename r1\n\
                 rename victim victim2\n\
                 puts \"info:[trace info command victim2]\"\n\
                 rename victim2 {}\n",
        want: "info:{delete d1} {rename r1}\nD:::victim2||delete",
    },
    // Both entries reference one `Command`, so a callback that renames or
    // deletes through *either* name moves or destroys that one command — and
    // C's `CMD_TRACE_ACTIVE` keeps the remaining callbacks of the pass from
    // re-firing when it does.
    Vector {
        name: "a rename callback renaming the vacating name moves the one command",
        script: "proc victim {} { return V }\n\
                 proc c1 args { puts c1; rename victim victim3 }\n\
                 proc c2 args { puts c2 }\n\
                 trace add command victim rename c2\n\
                 trace add command victim rename c1\n\
                 rename victim victim2\n\
                 puts \"live:[llength [info commands ::victim]]|\
                 [llength [info commands ::victim2]]|\
                 [llength [info commands ::victim3]]\"\n\
                 puts \"info:[trace info command victim3]|[victim3]\"\n",
        want: "c1\nc2\n\
               live:0|0|1\n\
               info:{rename c1} {rename c2}|V",
    },
    Vector {
        name: "a rename callback deleting the vacating name destroys the one command",
        script: "proc victim {} {}\n\
                 proc cb args { rename victim {} }\n\
                 trace add command victim rename cb\n\
                 rename victim victim2\n\
                 puts \"live:[llength [info commands ::victim]]|\
                 [llength [info commands ::victim2]]\"\n",
        want: "live:0|0",
    },
    Vector {
        name: "a nested rename keeps the vacating name pointed at the command",
        script: "proc victim {} {}\n\
                 proc dd args { puts \"D:[join $args |]\" }\n\
                 proc cb args {\n\
                     rename victim2 victim3\n\
                     puts \"in:[trace info command victim]|\
                 [trace info command victim3]\"\n\
                     trace add command victim delete dd\n\
                 }\n\
                 trace add command victim rename cb\n\
                 rename victim victim2\n\
                 puts \"after:[trace info command victim3]\"\n\
                 rename victim3 {}\n",
        want: "in:{rename cb}|{rename cb}\n\
               after:{delete dd} {rename cb}\n\
               D:::victim3||delete",
    },
    // `INTERP_TRACE_IN_PROGRESS` belongs to execution traces alone. C sets it
    // in exactly one place — `TraceExecutionProc` (tclTrace.c 9.0.4:1765),
    // around an `enter`/`leave`/`enterstep`/`leavestep` callback — and reads
    // it in exactly one place, `TclCheckInterpTraces` (:1426), the step
    // machinery. `CallCommandTraces` sets nothing, so a command a
    // `rename`/`delete` callback dispatches is traced like any other.
    Vector {
        name: "a command-trace callback does not untrace what it dispatches",
        script: "proc a {} { return A }\n\
                 proc E args { puts \"E:[join $args |]\" }\n\
                 trace add execution a enter E\n\
                 proc victim {} {}\n\
                 proc D args { puts \"D:[a]\" }\n\
                 trace add command victim delete D\n\
                 rename victim {}\n\
                 proc victim2 {} {}\n\
                 proc R args { puts \"R:[a]\" }\n\
                 trace add command victim2 rename R\n\
                 rename victim2 victim3\n",
        want: "E:a|enter\nD:A\nE:a|enter\nR:A",
    },
    Vector {
        name: "a step scope steps a delete callback's own commands",
        script: "proc st args { puts \"S:[lindex $args 0]\" }\n\
                 proc victim {} {}\n\
                 proc cb args { set q 1 }\n\
                 trace add command victim delete cb\n\
                 proc driver {} { rename victim {} }\n\
                 trace add execution driver enterstep st\n\
                 driver\n",
        want: "S:rename victim {}\nS:cb ::victim {} delete\nS:set q 1",
    },
    // The other side of the same gate, which must keep holding: an execution
    // callback does raise it, so its own commands are never step-observed —
    // while the traced command's body still is.
    Vector {
        name: "an execution callback's own commands are not step-observed",
        script: "proc st args { puts \"S:[lindex $args 0]\" }\n\
                 proc b {} { return B }\n\
                 proc eb args { set z 9; puts eb }\n\
                 trace add execution b enter eb\n\
                 proc driver {} { b }\n\
                 trace add execution driver enterstep st\n\
                 driver\n",
        want: "S:b\neb\nS:return B",
    },
    // The gate is read only by the step machinery: `TclCheckExecutionTraces`
    // (tclTrace.c 9.0.4:1301) never consults `INTERP_TRACE_IN_PROGRESS`, only
    // `TclCheckInterpTraces` (:1426) does. So a command dispatched from inside
    // an execution callback still fires its own `enter`/`leave` traces, and
    // what bounds the recursion is C's *per-trace* `TCL_TRACE_EXEC_IN_PROGRESS`
    // (:1655) — the VM's `CmdTraceEntry::firing`.
    Vector {
        name: "an execution callback does not untrace what it dispatches",
        script: "proc b {} { return B }\n\
                 proc EB args { puts EB }\n\
                 proc LB args { puts \"LB:[lindex $args 1]\" }\n\
                 trace add execution b enter EB\n\
                 trace add execution b leave LB\n\
                 proc a {} { return A }\n\
                 proc ea args { puts \"in:[b]\" }\n\
                 trace add execution a enter ea\n\
                 puts \"out:[a]\"\n",
        want: "EB\nLB:0\nin:B\nout:A",
    },
    Vector {
        name: "suppression during a callback is per trace, not per command",
        script: "proc a {} { return A }\n\
                 proc E1 args {\n\
                     puts E1\n\
                     if {![info exists ::d]} { set ::d 1; puts \"in:[a]\" }\n\
                 }\n\
                 proc E2 args { puts E2 }\n\
                 trace add execution a enter E2\n\
                 trace add execution a enter E1\n\
                 puts \"out:[a]\"\n",
        want: "E1\nE2\nin:A\nE2\nout:A",
    },
    Vector {
        name: "a leave trace fires while its command's enter callback runs",
        script: "proc a {} { return A }\n\
                 proc LA args { puts LA }\n\
                 trace add execution a leave LA\n\
                 proc EA args {\n\
                     puts EA\n\
                     if {![info exists ::d]} { set ::d 1; puts \"in:[a]\" }\n\
                 }\n\
                 trace add execution a enter EA\n\
                 puts \"out:[a]\"\n",
        want: "EA\nLA\nin:A\nLA\nout:A",
    },
    // The step half stays gated for the whole callback evaluation.
    Vector {
        name: "a step-traced command called from a callback is not stepped",
        script: "proc st args { puts \"S:[lindex $args 0]\" }\n\
                 proc s {} { set q 1; return S }\n\
                 trace add execution s enterstep st\n\
                 proc a {} { return A }\n\
                 proc ea args { puts \"in:[s]\" }\n\
                 trace add execution a enter ea\n\
                 puts \"out:[a]\"\n",
        want: "in:S\nout:A",
    },
    // Dispatching through the vacating name reaches the one command's
    // execution traces too: they have already moved to the destination key by
    // the time the callbacks run, so the lookup follows the window. The
    // callback's own words stay the spelling the caller invoked, which is why
    // the first pair says `victim` and the later ones `victim2`.
    Vector {
        name: "the vacating name still fires the command's execution traces",
        script: "proc victim {} { return V }\n\
                 proc E args { puts \"E:[join $args |]\" }\n\
                 proc L args { puts \"L:[lindex $args 0]\" }\n\
                 trace add execution victim enter E\n\
                 trace add execution victim leave L\n\
                 proc R args { puts \"old:[victim]\"; puts \"new:[victim2]\" }\n\
                 trace add command victim rename R\n\
                 rename victim victim2\n\
                 puts \"out:[victim2]\"\n",
        want: "E:victim|enter\nL:victim\nold:V\n\
               E:victim2|enter\nL:victim2\nnew:V\n\
               E:victim2|enter\nL:victim2\nout:V",
    },
    // C re-homes the one `Command` (`cmdPtr->nsPtr = newNsPtr`) *before* it
    // fires, and both hash entries reference it, so during the window a proc
    // invoked through the vacating name reports the destination's `namespace
    // current` and resolves `variable` there. The VM registered the re-homed
    // command at the destination only, leaving the surviving source entry
    // pointing at the un-re-homed one.
    Vector {
        name: "the vacating name reports the destination's namespace",
        script: "namespace eval a { variable v A\n\
                     proc p {} { variable v; return \"[namespace current] $v\" } }\n\
                 namespace eval b { variable v B }\n\
                 proc R {old new op} { puts \"old: [a::p]\"; puts \"new: [b::q]\" }\n\
                 trace add command a::p rename R\n\
                 rename a::p ::b::q\n\
                 puts \"after: [b::q]\"\n",
        want: "old: ::b B\nnew: ::b B\nafter: ::b B",
    },
    Vector {
        name: "namespace-qualified names arrive fully qualified",
        script: "proc tracer args { puts \"T:[join $args |]\" }\n\
                 namespace eval ns { proc inner {} {} }\n\
                 trace add command ns::inner rename tracer\n\
                 rename ns::inner ns::inner2\n",
        want: "T:::ns::inner|::ns::inner2|rename",
    },
    Vector {
        name: "execution enter/leave shapes: cmd-string, code, result",
        script: "proc etracer args { puts \"E:[join $args |]\" }\n\
                 proc p {a b} { return [list $a $b] }\n\
                 trace add execution p {enter leave} etracer\n\
                 p one {t w o}\n",
        want: "E:p one {t w o}|enter\nE:p one {t w o}|0|one {t w o}|leave",
    },
    Vector {
        name: "leave fires on error with code 1, and the error still propagates",
        script: "proc etracer args { puts \"E:[join $args |]\" }\n\
                 proc boom {} { error BOOM }\n\
                 trace add execution boom {enter leave} etracer\n\
                 puts catch:[catch {boom} m]:$m\n",
        want: "E:boom|enter\nE:boom|1|BOOM|leave\ncatch:1:BOOM",
    },
    Vector {
        name: "catch leave observes the absorbed command result",
        script: "proc etracer args { puts \"E:[join $args |]\" }\n\
                 trace add execution catch {enter leave} etracer\n\
                 puts result:[catch {error BOOM}]\n",
        want: "E:catch {error BOOM}|enter\n\
               E:catch {error BOOM}|0|1|leave\n\
               result:1",
    },
    Vector {
        name: "catch leave failure escapes rather than being caught by itself",
        script: "proc fail args {\n\
                     if {[lindex $args 0] eq {catch {error BOOM}}} { error LEAVEFAIL }\n\
                 }\n\
                 trace add execution catch leave fail\n\
                 set code [catch {catch {error BOOM}} result]\n\
                 puts [list $code $result]\n",
        want: "1 LEAVEFAIL",
    },
    Vector {
        name: "try leave observes the final handled result",
        script: "proc etracer args { puts \"E:[join $args |]\" }\n\
                 trace add execution try {enter leave} etracer\n\
                 puts result:[try {error BOOM} on error m {set m HANDLED}]\n",
        want: "E:try {error BOOM} on error m {set m HANDLED}|enter\n\
               E:try {error BOOM} on error m {set m HANDLED}|0|HANDLED|leave\n\
               result:HANDLED",
    },
    Vector {
        name: "try leave failure escapes rather than entering its own handler",
        script: "proc fail args { error LEAVEFAIL }\n\
                 trace add execution try leave fail\n\
                 set code [catch {try {error BOOM} on error m {set m HANDLED}} result]\n\
                 puts [list $code $result]\n",
        want: "1 LEAVEFAIL",
    },
    Vector {
        name: "an enter-trace error aborts the traced command",
        script: "proc q {} { return Q }\n\
                 proc failtrace args { error TRACEFAIL }\n\
                 trace add execution q enter failtrace\n\
                 puts qcatch:[catch {q} m]:$m\n",
        want: "qcatch:1:TRACEFAIL",
    },
    Vector {
        name: "execution traces follow a rename and report the invoked name",
        script: "proc etracer args { puts \"E:[join $args |]\" }\n\
                 proc r {} { return R }\n\
                 trace add execution r {enter leave} etracer\n\
                 rename r r2\n\
                 r2\n",
        want: "E:r2|enter\nE:r2|0|R|leave",
    },
    Vector {
        name: "step traces fire per dispatched inner command, and trace info reports pairs",
        script: "proc st args { puts \"S:[join $args |]\" }\n\
                 proc stepped {} { format %s x }\n\
                 trace add execution stepped {enterstep leavestep} st\n\
                 stepped\n\
                 puts info:[trace info execution stepped]\n",
        want: "S:format %s x|enterstep\nS:format %s x|0|x|leavestep\n\
               info:{{enterstep leavestep} st}",
    },
    Vector {
        name: "a leave-trace error replaces the command's result",
        script: "proc q {} { return Q }\n\
                 proc ft args { error LEAVEFAIL }\n\
                 trace add execution q leave ft\n\
                 puts [catch {q} m]:$m\n",
        want: "1:LEAVEFAIL",
    },
    Vector {
        name: "a leavestep-trace error replaces the result too",
        script: "proc r {} { format %s R }\n\
                 proc st args { error STEPFAIL }\n\
                 trace add execution r leavestep st\n\
                 puts [catch {r} m]:$m\n",
        want: "1:STEPFAIL",
    },
    Vector {
        name: "trace remove stops the firing",
        script: "proc s {} { return S }\n\
                 proc et args { puts FIRED }\n\
                 trace add execution s enter et\n\
                 s\n\
                 trace remove execution s enter et\n\
                 s\n\
                 puts removed-ok\n",
        want: "FIRED\nremoved-ok",
    },
    // Firing order. Every trace list is prepended in C
    // (`TraceVarEx` tclTrace.c:3090-3092, `Tcl_TraceCommand` :1016-1018), and
    // each firing loop walks it head→tail — so the newest registration fires
    // first everywhere except the `leave`/`leavestep` reverse scan.
    Vector {
        name: "command rename/delete traces fire newest-first",
        script: "proc c1 args { puts \"c1:[join $args |]\" }\n\
                 proc c2 args { puts \"c2:[join $args |]\" }\n\
                 proc victim {} {}\n\
                 trace add command victim {rename delete} c1\n\
                 trace add command victim {rename delete} c2\n\
                 rename victim victim2\n\
                 rename victim2 {}\n",
        want: "c2:::victim|::victim2|rename\n\
               c1:::victim|::victim2|rename\n\
               c2:::victim2||delete\n\
               c1:::victim2||delete",
    },
    Vector {
        name: "execution enter fires newest-first, leave oldest-first",
        script: "proc e1 args { puts \"e1:[lindex $args end]\" }\n\
                 proc e2 args { puts \"e2:[lindex $args end]\" }\n\
                 proc target {} { return T }\n\
                 trace add execution target {enter leave} e1\n\
                 trace add execution target {enter leave} e2\n\
                 target\n",
        want: "e2:enter\ne1:enter\ne1:leave\ne2:leave",
    },
    Vector {
        name: "a leave trace added by an enter callback joins this invocation",
        script: "set log {}\n\
                 proc late args { lappend ::log late-[lindex $args end] }\n\
                 proc add args { lappend ::log add-enter; trace add execution target leave late }\n\
                 proc target {} { lappend ::log body; return T }\n\
                 trace add execution target enter add\n\
                 set result [target]\n\
                 puts [list $result $log]\n",
        want: "T {add-enter body late-leave}",
    },
    Vector {
        name: "a body-added leave trace joins when the owner was traced at entry",
        script: "set log {}\n\
                 proc late args { lappend ::log late-[lindex $args end] }\n\
                 proc entered args { lappend ::log entered-[lindex $args end] }\n\
                 proc target {} {\n\
                     lappend ::log body\n\
                     trace add execution target leave late\n\
                     return T\n\
                 }\n\
                 trace add execution target enter entered\n\
                 set result [target]\n\
                 puts [list $result $log]\n",
        want: "T {entered-enter body late-leave}",
    },
    Vector {
        name: "a builtin snapshots leave traces after its enter callbacks",
        script: "set log {}\n\
                 proc late args { lappend ::log late-[lindex $args end] }\n\
                 proc add args {\n\
                     lappend ::log add-enter\n\
                     trace remove execution list enter add\n\
                     trace add execution list leave late\n\
                 }\n\
                 trace add execution list enter add\n\
                 set result [list OK]\n\
                 puts [list $result $log]\n",
        want: "OK {add-enter late-leave}",
    },
    Vector {
        name: "enter-time rename and replacement cancel the old leave owner",
        script: "set log {}\n\
                 proc trace_target args {\n\
                     set op [lindex $args end]\n\
                     lappend ::log $op\n\
                     if {$op eq {enter}} {\n\
                         rename target moved\n\
                         proc target {} { lappend ::log new; return NEW }\n\
                     }\n\
                 }\n\
                 proc target {} { lappend ::log old; return OLD }\n\
                 trace add execution target {enter leave} trace_target\n\
                 set result [target]\n\
                 puts [list $result $log]\n",
        want: "NEW {enter new}",
    },
    Vector {
        name: "enter-time rename away cancels the old leave owner",
        script: "set log {}\n\
                 proc trace_target args {\n\
                     set op [lindex $args end]\n\
                     lappend ::log $op\n\
                     if {$op eq {enter}} { rename target moved }\n\
                 }\n\
                 proc target {} { return OLD }\n\
                 trace add execution target {enter leave} trace_target\n\
                 set code [catch {target} result]\n\
                 puts [list $code $result $log]\n",
        want: "1 {invalid command name \"target\"} enter",
    },
    Vector {
        name: "body-time self rename retains the command's leave owner",
        script: "set log {}\n\
                 proc trace_target args { lappend ::log [lindex $args end] }\n\
                 proc target {} { rename target moved; return OLD }\n\
                 trace add execution target {enter leave} trace_target\n\
                 set result [target]\n\
                 puts [list $result $log]\n",
        want: "OLD {enter leave}",
    },
    Vector {
        name: "enterstep fires newest-first, leavestep oldest-first",
        script: "proc s1 args { puts \"s1:[lindex $args end]\" }\n\
                 proc s2 args { puts \"s2:[lindex $args end]\" }\n\
                 proc stepped {} { format %s x }\n\
                 trace add execution stepped {enterstep leavestep} s1\n\
                 trace add execution stepped {enterstep leavestep} s2\n\
                 stepped\n",
        want: "s2:enterstep\ns1:enterstep\ns1:leavestep\ns2:leavestep",
    },
    Vector {
        name: "variable write/read/unset traces fire newest-first",
        script: "proc t1 args { puts 1 }\n\
                 proc t2 args { puts 2 }\n\
                 proc t3 args { puts 3 }\n\
                 trace add variable v {read write unset} t1\n\
                 trace add variable v {read write unset} t2\n\
                 trace add variable v {read write unset} t3\n\
                 set v x\n\
                 puts -nonewline \"\"\n\
                 set ignore $v\n\
                 unset v\n",
        want: "3\n2\n1\n3\n2\n1\n3\n2\n1",
    },
    Vector {
        name: "whole-array traces fire before element traces, either registration order",
        script: "proc W args { puts \"W:[join $args |]\" }\n\
                 proc E args { puts \"E:[join $args |]\" }\n\
                 array set a {}\n\
                 trace add variable a write W\n\
                 trace add variable a(k) write E\n\
                 set a(k) 1\n\
                 array set b {}\n\
                 trace add variable b(k) write E\n\
                 trace add variable b write W\n\
                 set b(k) 2\n",
        want: "W:a|k|write\nE:a|k|write\nW:b|k|write\nE:b|k|write",
    },
    // `trace remove` breaks at the first match walking C's list head→tail, and
    // that head is the newest registration — so among identical duplicates the
    // NEWEST goes, which the surviving firing order and `trace info` both show.
    Vector {
        name: "trace remove drops the newest of several identical registrations",
        script: "proc cb1 args { puts c1 }\n\
                 proc cb2 args { puts c2 }\n\
                 trace add variable v write cb1\n\
                 trace add variable v write cb2\n\
                 trace add variable v write cb1\n\
                 trace remove variable v write cb1\n\
                 puts [trace info variable v]\n\
                 set v 1\n",
        want: "{write cb2} {write cb1}\nc2\nc1",
    },
    Vector {
        name: "the same newest-first removal rule for command and execution traces",
        script: "proc d1 args { puts d1 }\n\
                 proc d2 args { puts d2 }\n\
                 proc p {} {}\n\
                 trace add command p delete d1\n\
                 trace add command p delete d2\n\
                 trace add command p delete d1\n\
                 trace remove command p delete d1\n\
                 puts [trace info command p]\n\
                 proc q {} {}\n\
                 trace add execution q enter d1\n\
                 trace add execution q enter d2\n\
                 trace add execution q enter d1\n\
                 trace remove execution q enter d1\n\
                 puts [trace info execution q]\n",
        want: "{delete d2} {delete d1}\n{enter d2} {enter d1}",
    },
    // `trace info` renders the stored op set in the order each C `TRACE_INFO`
    // arm tests the flag bits — `array read write unset` and `rename delete`,
    // neither of which is the `opStrings[]` table order.
    Vector {
        name: "trace info renders ops in C's fixed per-kind order",
        script: "proc cb args {}\n\
                 proc p {} {}\n\
                 trace add command p {delete rename} cb\n\
                 trace add execution p {leavestep leave enterstep enter} cb\n\
                 trace add variable q {unset write read array} cb\n\
                 puts [trace info command p]\n\
                 puts [trace info execution p]\n\
                 puts [trace info variable q]\n",
        want: "{{rename delete} cb}\n\
               {{enter leave enterstep leavestep} cb}\n\
               {{array read write unset} cb}",
    },
    // Row 8 (command / execution): the same live-list rule as the variable
    // half. `CallCommandTraces` walks `nextPtr` (`tclBasic.c` 9.0.4:3972-3993)
    // and `Tcl_UntraceCommand` unlinks at once, so a trace a callback removes
    // does not fire in that pass — for `enter` and `delete`, which walk
    // newest-first, for `leave`, which C scans in reverse and so reaches the
    // *oldest* first, and for `rename`, whose callback reaches the list
    // through the name the command is vacating.
    Vector {
        name: "a callback's trace remove is honoured mid-firing for command and execution traces",
        script: "proc target {} { return T }\n\
                 proc e1 args { trace remove execution target enter e2\n\
                 puts \"e1 info: [trace info execution target]\" }\n\
                 proc e2 args { puts \"e2 fired\" }\n\
                 trace add execution target enter e2\n\
                 trace add execution target enter e1\n\
                 target\n\
                 puts ---\n\
                 proc victim {} {}\n\
                 proc d1 args { trace remove command victim delete d2\n\
                 puts \"d1 info: [trace info command victim]\" }\n\
                 proc d2 args { puts \"d2 fired\" }\n\
                 trace add command victim delete d2\n\
                 trace add command victim delete d1\n\
                 rename victim {}\n\
                 puts ---\n\
                 proc lt {} { return L }\n\
                 proc l1 args { puts \"l1 fired\" }\n\
                 proc l2 args { trace remove execution lt leave l1\n\
                 puts \"l2 info: [trace info execution lt]\" }\n\
                 trace add execution lt leave l2\n\
                 trace add execution lt leave l1\n\
                 lt\n\
                 puts ---\n\
                 proc rv {} {}\n\
                 proc r1 args { trace remove command rv rename r2\n\
                 puts \"r1 info: [trace info command rv]\" }\n\
                 proc r2 args { puts \"r2 fired\" }\n\
                 trace add command rv rename r2\n\
                 trace add command rv rename r1\n\
                 rename rv rv2\n",
        want: "e1 info: {enter e1}\n\
               ---\n\
               d1 info: {delete d1}\n\
               ---\n\
               l2 info: {leave l2}\n\
               ---\n\
               r1 info: {rename r1}",
    },
    // A **delete** walk is handed the dying token's own trace list
    // (`CallCommandTraces`, `tclBasic.c` 9.0.4:3972-3993), so a callback that
    // re-creates the command under the same name takes the *name-keyed* entry
    // over while the rest of that list still fires. Only an explicit
    // `trace remove` cancels a pending callback — and once a replacement holds
    // the name, `trace remove` reaches the replacement's (empty) list instead,
    // so it cancels nothing. Measured on tclsh 8.6.16 and 9.0.4; deciding
    // liveness by table membership instead would let a re-creation silently
    // empty it, skipping every older callback.
    Vector {
        name: "a delete callback that re-creates the command does not cancel the rest of the walk",
        script: "proc foo {} { return FOO }\n\
                 proc OLD {old new op} { puts \"OLD $old $new $op\" }\n\
                 proc NEW {old new op} { puts \"NEW $old $new $op\"\n\
                 proc foo {} { return FOO2 } }\n\
                 trace add command foo delete OLD\n\
                 trace add command foo delete NEW\n\
                 rename foo {}\n\
                 puts \"exists:[info commands foo] call:[foo] traces:[trace info command foo]\"\n\
                 puts ---\n\
                 proc A1 {o n op} { puts A1 }\n\
                 proc A2 {o n op} { puts A2\n\
                 trace remove command a delete A1 }\n\
                 proc a {} {}\n\
                 trace add command a delete A1\n\
                 trace add command a delete A2\n\
                 rename a {}\n\
                 puts ---\n\
                 proc B1 {o n op} { puts B1 }\n\
                 proc B2 {o n op} { puts B2\n\
                 proc b {} {}\n\
                 trace remove command b delete B1 }\n\
                 proc b {} {}\n\
                 trace add command b delete B1\n\
                 trace add command b delete B2\n\
                 rename b {}\n\
                 puts \"b-exists:[info commands b] b-traces:[trace info command b]\"\n",
        want: "NEW ::foo  delete\n\
               OLD ::foo  delete\n\
               exists:foo call:FOO2 traces:\n\
               ---\n\
               A2\n\
               ---\n\
               B2\n\
               B1\n\
               b-exists:b b-traces:",
    },
    // The *execution* walk answers the opposite way, and this pins the
    // difference. `TclCheckExecutionTraces` follows the list of whatever
    // command the name holds now, so a callback that redefines the traced
    // command stops the rest of that walk — `E1` and `L1` never run — where the
    // delete walk above keeps firing the dying token's list. Measured on tclsh
    // 8.6.16 and 9.0.4. The two loops therefore ask different questions: the
    // execution one re-reads the name-keyed table, the delete one consults each
    // registration's own untraced mark.
    Vector {
        name: "an execution callback redefining the command stops the rest of that walk",
        script: "proc t {} { return T }\n\
                 proc E1 args { puts E1 }\n\
                 proc E2 args { puts E2\n\
                 proc t {} { return T2 } }\n\
                 trace add execution t enter E1\n\
                 trace add execution t enter E2\n\
                 puts \"call:[t] traces:[trace info execution t]\"\n\
                 puts ---\n\
                 proc u {} { return U }\n\
                 proc L1 args { puts L1 }\n\
                 proc L2 args { puts L2\n\
                 proc u {} { return U2 } }\n\
                 trace add execution u leave L2\n\
                 trace add execution u leave L1\n\
                 puts \"call:[u] traces:[trace info execution u]\"\n",
        want: "E2\n\
               call:T2 traces:\n\
               ---\n\
               L2\n\
               call:U traces:",
    },
    // Row 9: `Tcl_DeleteCommandFromToken` marks the command `CMD_DYING`
    // (`tclBasic.c` 9.0.4:3760), fires the delete traces while its hash entry
    // still exists (:3793), and removes that entry only through
    // `cmdPtr->hPtr` if it is still non-NULL (:3865-3873). A callback that
    // re-creates the command under the same name has taken the entry over, so
    // the new command stands — trace-less, since the traces went with the old
    // token. A redefinition still beats the callback's own, `rename` fires no
    // delete trace, and an `interp alias` replacing a traced proc fires one.
    Vector {
        name: "a delete trace that re-creates the command leaves the new one standing",
        script: "proc foo {} { return foo }\n\
                 proc delcb {old new op} { puts \"in-trace: [info commands foo]\"\n\
                 proc foo {} { return foo2 } }\n\
                 trace add command foo delete delcb\n\
                 rename foo {}\n\
                 puts \"exists: [info commands foo]\"\n\
                 puts [catch {foo} m]\n\
                 puts $m\n\
                 puts \"traces: [trace info command foo]\"\n\
                 puts ---\n\
                 proc bar {} { return bar1 }\n\
                 proc delbar {old new op} { proc bar {} { return bar2 } }\n\
                 trace add command bar delete delbar\n\
                 proc bar {} { return bar3 }\n\
                 puts [bar]\n\
                 puts \"traces: [trace info command bar]\"\n\
                 puts ---\n\
                 proc baz {} {}\n\
                 proc renbaz {old new op} { puts \"ren: $old -> $new ($op)\" }\n\
                 namespace eval ns {}\n\
                 trace add command baz delete renbaz\n\
                 rename baz ns::baz\n\
                 puts \"baz: [info commands baz] ns::baz: [info commands ::ns::baz]\"\n\
                 puts ---\n\
                 proc qux {} { return q }\n\
                 proc delqux {old new op} { puts \"delqux $op\" }\n\
                 trace add command qux delete delqux\n\
                 interp alias {} qux {} puts\n\
                 qux hi\n\
                 puts [catch {trace info command qux} m2]\n",
        want: "in-trace: foo\n\
               exists: foo\n\
               0\n\
               foo2\n\
               traces: \n\
               ---\n\
               bar3\n\
               traces: \n\
               ---\n\
               baz:  ns::baz: ::ns::baz\n\
               ---\n\
               delqux delete\n\
               hi\n\
               0",
    },
    // Which *operations* a variable trace sees depends on the opcode the
    // command compiled to, and inside a procedure body that is the specialised
    // form. C's `INST_LAPPEND_{SCALAR,ARRAY}` read the old value without
    // `TCL_TRACE_READS` (`tclExecute.c`), so a single-value `lappend` fires
    // `write` alone. C's `INST_UNSET_ARRAY` passes a two-part access, so the
    // callback is told `name1 = a`, `name2 = k`, not `name1 = a(k)`.
    //
    // Compiling every proc body as a top-level *script* instead of using its
    // LVT-aware forms would mean none of those arms ever ran.
    Vector {
        name: "in-proc lappend/unset report the operations the compiled forms report",
        script: "proc log {n1 n2 op} { puts \"$op|$n1|$n2\" }\n\
                 proc p {} {\n\
                     set l {a b}\n\
                     trace add variable l {read write} log\n\
                     lappend l z\n\
                     trace remove variable l {read write} log\n\
                     array set arr {k {1 2}}\n\
                     trace add variable arr {read write} log\n\
                     lappend arr(k) z\n\
                     trace remove variable arr {read write} log\n\
                     set a(k) 1\n\
                     trace add variable a {read write unset} log\n\
                     unset a(k)\n\
                     trace remove variable a {read write unset} log\n\
                     return \"$l|$arr(k)\"\n\
                 }\n\
                 puts [p]\n",
        want: "write|l|\n\
               write|arr|k\n\
               unset|a|k\n\
               a b z|1 2 z",
    },
];

/// Step traces observing only **dispatched** commands (procs, non-inlined
/// builtins) would diverge from C: commands the compiler lowers to inline
/// opcodes (`set`, `incr`, `return`, …) never reach the dispatcher, so they
/// would not step. C Tcl forces a
/// step-traced proc "out of bytecode" (`DONT_COMPILE_CMDS_INLINE`,
/// `tclTrace.c`) so every inner command fires transitively — this recompiles
/// the traced proc trace-visible on its next entry (and reverts the same way
/// once the last step-capable trace is removed), matching tclsh 8.6/9.0
/// exactly (tclsh9.0.3-verified).
#[test]
fn step_traces_observe_inlined_commands_too() {
    let out = vm_output(
        "proc st args { puts \"S:[join $args |]\" }\n\
         proc stepped2 {} { helperp }\n\
         proc helperp {} { return H }\n\
         trace add execution stepped2 {enterstep leavestep} st\n\
         stepped2\n",
    );
    assert_eq!(
        out,
        "S:helperp|enterstep\n\
         S:return H|enterstep\n\
         S:return H|2|H|leavestep\n\
         S:helperp|0|H|leavestep",
        "the dispatched proc call steps, AND its inlined `return` body steps too"
    );
}

#[test]
fn vm_matches_the_pinned_trace_vectors() {
    for version in [TclVersion::V8_6, TclVersion::V9_0] {
        for vector in VECTORS {
            assert_eq!(
                common::vm_output(vector.script, version.dialect_name()),
                vector.want,
                "{version:?}: {}",
                vector.name
            );
        }
    }
}

#[test]
fn replacement_retires_a_generation_moved_by_its_delete_trace() { /* PURE_ASSERTION_BODY_replacement_retires_a_generation_moved_by_its_delete_trace */ }

struct NativeTarget;

impl NativeCommand for NativeTarget {
    fn invoke(&self, _vm: &mut Vm, _args: &[Value]) -> Completion<Value> {
        Completion::new(Code::Ok, Value::string("NATIVE"), Value::empty())
    }
}

/// The embedder/native entry point shares the same post-enter owner snapshot
/// as bytecode dispatch: an enter callback can add this invocation's leave
/// trace, while replacing the native command cancels its old leave ownership
/// before the generic name is re-resolved.
#[test]
fn native_invoke_uses_the_post_enter_trace_owner_snapshot() {
    let profile = tcl_registry::model::resolve_environment("tcl9.0").unit_profile();
    let mut vm = Vm::with_native_core(
        Box::new(std::io::sink()),
        Rc::new(tcl_vm::host_native::NativeHost::new()),
        profile,
        tcl_registry::special_vars::NativeBootstrapInputs::default(),
    )
    .expect("actual C9.0 core before native callback registration");
    vm.set_compiler(Box::new(BytecodeCompileService::for_profile(profile)));
    vm.register_native_command("target", Rc::new(NativeTarget));
    let setup = vm
        .eval_source(
            "set log {}; \
             proc late args {lappend ::log late-[lindex $args end]}; \
             proc add args {lappend ::log add-enter; trace add execution target leave late}; \
             trace add execution target enter add",
        )
        .expect("setup compiles");
    assert_eq!(setup.code, Code::Ok);

    let result = vm.invoke_command("target", &[]);
    assert_eq!(result.code, Code::Ok);
    assert_eq!(result.result.to_str().as_ref(), "NATIVE");
    let log = vm.eval_source("set log").expect("log lookup compiles");
    assert_eq!(log.code, Code::Ok);
    assert_eq!(log.result.to_str().as_ref(), "add-enter late-leave");

    vm.register_native_command("target2", Rc::new(NativeTarget));
    let setup = vm
        .eval_source(
            "set log {}; \
             proc replace args {rename target2 moved; proc target2 {} {return NEW}}; \
             trace add execution target2 {enter leave} replace",
        )
        .expect("replacement setup compiles");
    assert_eq!(setup.code, Code::Ok);

    let result = vm.invoke_command("target2", &[]);
    assert_eq!(result.code, Code::Ok);
    assert_eq!(result.result.to_str().as_ref(), "NEW");
}

/// The table itself is pinned to C Tcl (8.6 and 9.0 agree on every shape).
#[test]
fn vectors_match_real_tclsh() {
    let oracles = required_tclshs(&[TclVersion::V8_6, TclVersion::V9_0])
        .expect("both pinned command-trace engines");
    for oracle in oracles {
        for vector in VECTORS {
            assert_eq!(
                common::oracle_output(&oracle.path, vector.script),
                vector.want,
                "{}: {}",
                oracle.patchlevel,
                vector.name
            );
        }
    }
}

#[test]
fn command_trace_rename_and_retirement_match_all_five_native_engines() {
    const SOURCE: &str = "set log {}\nproc cb {old new op} {lappend ::log [list $old $new $op]}\nproc p {} {return OLD}\ntrace add command p {rename delete} cb\nrename p moved\nrename moved {}\nputs $log\n";
    const EXPECTED: &str = "{::p ::moved rename} {::moved {} delete}";
    for oracle in required_tclshs(&TclVersion::ALL).expect("all five pinned command-trace engines")
    {
        assert_eq!(
            common::oracle_output(&oracle.path, SOURCE),
            EXPECTED,
            "{}",
            oracle.patchlevel
        );
        assert_eq!(
            common::vm_output(SOURCE, oracle.version.dialect_name()),
            EXPECTED,
            "{:?}",
            oracle.version
        );
    }
}

#[test]
fn jim_command_traces_are_explicitly_unsupported() {
    let oracle = require_jimsh().expect("pinned Jim command-trace surface");
    assert!(!oracle.supports(JimCapability::CommandTrace));
    let source = "puts [catch {trace add command p delete list} message]\nputs $message\n";
    let expected = "1\ninvalid command name \"trace\"";
    assert_eq!(common::oracle_output(&oracle.path, source), expected);
    assert_eq!(common::vm_output(source, "jim"), expected);
}
