from record import *
from collections import Counter
p=ROOT/'runtime-inline-operational-census.json';d=json.loads(p.read_text());done={
'runtime/rust/src/test_storage.rs':'Actual entire609-byte file inspected: readonly existing actual global table scalar observation, no process/env/fs/provider/artifact ingress. It grants no lookup/getter/native role. Lexical license hit is irrelevant.',
'rust/tcl-cshim/tests/c/index_cache.c':'Entire original C extension control inspected: fixed original C API table/object/flag commands and intentionally mutable table. Caller is existing reviewed cshim build.rs35/45 actual selected C test fixture compilation. Fixed command/table strings are independent controls, not product name resolver copies. No original-provider conformance grant.',
'rust/tcl-runtime-api/src/checked_counter.rs':'Entire file and local test read: local AtomicU64 boundary assertions only, no process/env/fs/provider/fixture effects or hidden interpreter setup.',
'runtime/rust/tests/expr_operand_substitution.rs':'Entire file read: literal independent regression programs→Interp::new/eval_str; lossy result text is test assertion presentation. No external process/env/fs/provider artifact operation; original-version comment is unverified provenance, not execution acceptance.',
'runtime/rust/src/interp/native_alias_roles.rs':'Entire file read: production actual alias neutral lifetime and separately withdrawable Native role previously audited. Only cfg(test) as_ptr observation, no operational setup/process/provider effects.',
'runtime/rust/src/cmd_oo/native_eval_tests.rs':'Entire actual test read: fixed inputs, actual Native core factory and original List/object eval/header assertions. No external process/fs/env/oracle launch or output serializer. Internal product owner behavior remains separately unexecuted; source proof comment is not provider acceptance.',
'runtime/rust/src/cmd_trace/selected_member_tests.rs':'Entire test read: local actual VarTable/member destruction/trace-registration identity assertions; no executable/provider/host/global process setup, fixture or serialization.',
'rust/tcl-runtime-api/src/command_identity.rs':'Entire production+test read: local display-collision/injective encoding inputs/assertions only; no provider/process/env/fs/artifact effects.'}
pending={
'runtime/rust/tests/native_array_search_unset.rs':'Entire test+both included Tcl programs read: actual native core/env selection and compile-time external oracle stdout fixtures. No provider launched by test. Original output captures/source/executable/harness pairing and serialization provenance not re-admitted here; retained pending provider closure.',
'runtime/rust/src/cmd_array/original_list_conversion_tests.rs':'Entire actual test body read: imports cmd_control::original_list_conversion_tests custom getter/context fixture; real setup/free/ref/header/currency effects require its actual callee fixture inspection. No claim of pure fixed assertions from test membership.'}
receipts=[]
for r in d['files']:
 path=r['path']
 if path not in done and path not in pending:continue
 status='source_local_operational_ingress_reviewed' if path in done else 'local_body_read_callee_and_fixture_review_pending'
 reason=done.get(path,pending.get(path))
 r.update(inline_or_test_support_status=status,whole_file_operational_review=('complete_for_operational_ingress_no_execution_claim' if path in done else 'unfinished_callee_fixture_provider_closure'),reason=reason)
 for site in r['candidate_operational_sites']:site['review_status']='actual_source_reviewed';site['disposition']='Independent fixed input/control or actual internal product owner; no source/API rewriting or execution acceptance inferred.'
 receipts.append({'path':path,'sourceSHA':r['sourceSHA'],'reviewmode':'full_source_manual_operational_review','status':status,'reason':reason})
d['counts']['status_counts']=dict(Counter(r['inline_or_test_support_status'] for r in d['files']))
atomic_write(p,json.dumps(d,indent=2)+'\n')
atomic_write(ROOT/'runtime-work/inline-review01.json',json.dumps({'baseline':d['baseline'],'source_only':True,'receipts':receipts},indent=2)+'\n')
# Annexes record the same operational status; production coverage remains independent.
f=ROOT/'runtime-file-coverage.json';x=json.loads(f.read_text())
for r in x['files']:
 if r['path'] in done or r['path'] in pending:
  r['operational_review_receipt']='runtime-work/inline-review01.json'
  r['whole_file_operational_status']='source_local_operational_ingress_reviewed' if r['path'] in done else 'local_body_read_callee_and_fixture_review_pending'
atomic_write(f,json.dumps(x,indent=2)+'\n')
