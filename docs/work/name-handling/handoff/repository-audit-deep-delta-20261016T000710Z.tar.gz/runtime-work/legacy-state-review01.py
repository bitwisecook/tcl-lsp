from record import *
# Individually interpreted actual purposes, not a disposition-based bulk map.
notes={
9:'Actual Unix byte environment ingress preserves original name/value bytes under NativeEnvironmentBytes; remaining scoped host/source/callback execution is validation.',
10:'Actual byte Filesystem read is implemented with native OsStr and checked nonUnix unsupported boundary; no lossy path in this purpose.',
11:'Actual original open path/handle occurs before source read; implemented SourceFile issuer, full platform/provider matrix remains validation.',
12:'Recursive copy keeps actual OsString child paths/link PathBuf; existing host owner integration present, not rendered-path relookup.',
22:'Profile ingress delegates central registry resolved environment; no independent local name table in this purpose.',
23:'Pin/context issuer uses registry model owner and actual runtime context invalidation; unexecuted context controls remain validation.',
24:'Store selection for actual profile delegates shared model; no missing separate naming resolver demonstrated.',
25:'Surface availability point shared registry owner implemented; no physical Native grant inferred from authored metadata.',
27:'Existing embedded library declared-command catalogue is report/source correspondence metadata; it does not grant native script provider installation.',
28:'Existing embedded source file catalogue is the shared embedded provider owner, not consumer-local variable/command normalization.',
29:'Actual seed mounts known authored files into MemFs; native library selection/context remains distinct caller obligation.',
43:'Finite entered-Proc/Source/Rest/frame capture/check bookkeeping implemented, public entry still strict refusal. This validates existing unreachable owner, not complete Import migration.',
44:'Actual each-loop assignment/Break/full-exhaustion hooks implemented; no public entry or Normal grant; semantic controls remain unexecuted.',
45:'Actual Source while condition/prefix continuation bookkeeping implemented; whole positive Import route remains separate missing integration.',
46:'Resident exact alias operand finite seen-set issuer implemented with actual lookup; no extra String stage. Publication/callback execution matrix remains validation.',
47:'Actual retained prefix/header and Source continuation correspondence implemented; no string-derived physical prefix grant.',
48:'Actual alias publication hook records genuine argv before/after reached operation; complete traversal acceptance still absent and not counted code-complete Import.',
49:'Actual namespace holder/frame/context+caller check is transported through checked nested getter; this specific materializer integrated.',
50:'Actual Jim current namespace object returns held original holder/root context empty object; not report parsing.',
52:'Actual Text getter and typed result construction integrated; retained Runtime plan unexecuted at pinned source, no Native completion claim.',
53:'Actual Parent holder/immediate table/typed result integrated for bounded purpose; current Native Parent validation still pending.',
54:'Actual published refcount1 unshared parent result uses shared borrowed append with qualifier lifecycle checks; execution/count parity pending.',
55:'Actual namespace body original object/purpose/Nsholder entry transports present; full callback/source/frame controls remain validation.',
56:'Actual Namespace ParseSubCmd cache-before-getter/actual ordinal/arity install owner integrated; other package/Info parsers are separate gaps.',
57:'Actual mutable lsort diagnostic dispatch + original result/List/private join owner integrated; no whole parser/helper acceptance inferred.',
58:'Actual original usage head getter after genuine result publication uses checked shared append; validation remains physical lifecycle scope.',
61:'Actual C token and Jim original holder Parent routes integrated; original replay pending, not new owner implementation debt here.',
62:'Actual Qualifiers/Tail original getters + typed Text owner integrated; this is text construction, no namespace/cell identity.',
64:'Installed Source helper body selection strictly prevents artifact/compiled bypass; genuine body/currentness issuer implemented, entry guard separate.',
88:'Actual reopened doors source read confirms ObjSetVar2/get/unset ingress projected into combined Unicode &str door. Checked shared bridge is implemented but original separate/header/name/cache purpose cannot pass this API; genuine existing-door extension and actual producer transport remain code work.',
90:'Actual reopened provide_package_bytes source confirms exact input bytes exist but open CommandRegistrar door requires UTF8 &str before actual package publication. Extend existing door purpose for selected original byte-name input; do not claim this complete merely because unsupported input refuses.',
93:'Actual engine-prepared slot key/current binding and static initializer lifetime are retained across command publication; no report identity donation.',
94:'Actual trusted init and prepared publication service implemented with deferred change/lifetime; physical callbacks/unwind remain validation.',
95:'EngineDoor delegates actual prepared command receiver and counted original name sibling; original variable/package API missing purposes recorded separately88/90.',
96:'Full state map production read confirms actual prepared key/entry and original registration bytes, before callback mutation; execution pending.',
97:'Actual checked unit counter delegates shared compiled procedure name owner and runtime unit receipt; integration implemented.',
98:'Actual byte create/remove current instance root-replay owner implemented, nonroot replay terminal explicit supported-purpose boundary.',
99:'Actual current unit receipt owns invocation operand separately from FQN display; keep fresh-instance/withdrawal tests as validation.',
101:'Existing actual create/remove_with_context exports select real receipt/root context; root-only replay is explicit, not inferred arbitrary namespace authority.',
102:'Actual export inventory decode paired before/after interpreter identity implemented; transported data never itself supplies installed command grant.',
103:'Actual host-authored parameter/body/name construction plus publication/restriction uses command receipt owners; source declarations are not reconstructed.',
104:'Full production bridge source now reviewed, so prior wording not-audited is stale. Existing explicit root replay context/input owner implemented; physical external execution remains pending.',
105:'Actual runtime-export identity/current owner joins retained instance/generation + independently retained operand; complete source read does not execute it.',
106:'Actual create/remove/defined exports allocate/bind/retire under genuine context/refusal transport; all source read, physical replay pending.',
107:'Root source spelling accepted only if exact actual producer root_operand after slot/generation source inventory; report-only spelling grants no fresh binding.',
}
d=load();before=[]
for i,note in notes.items():
 r=d['consumers'][i];assert r['disposition']=='migrated_validation_pending',(i,r['symbol'],r['disposition']);old=dict(r)
 if i in [88,90]:
  r['disposition']='needs_migration';r['work_kind']='owner_extension';r['work_kind_reason']=note;r['missingintegration']=note+' Preserve actual current invocation/interpreter, original bytes/header separation, finite lifetime/currentness guards; original provider conformance unexecuted.'
 if i in [104,105,106]:r['missingintegration']=note+' No fresh WASM/native execution accepted by this audit.'
 r['legacy_state_review']={'batch':'runtime-work/legacy-state-review01.json','decision':r['disposition'],'reason':note}
 before.append({'index':i,'path':r['path'],'symbol':r['symbol'],'sourceSHA':r['sourceSHA'],'site':r['site'],'before_disposition':old['disposition'],'after_disposition':r['disposition'],'old_missingintegration':old['missingintegration'],'decision_reason':note})
atomic_write(ROOT/'runtime-consumers.json',json.dumps(d,indent=2)+'\n');atomic_write(ROOT/'runtime-work/legacy-state-review01.json',json.dumps({'baseline':d['baseline'],'scope':'45 explicit prior migrated_validation_pending purposes, individually interpreted against actual completed production review; not status/regex inference','rows':before,'execution':'None; original controls pending, no verified admission'},indent=2)+'\n');print(len(before),'reviewed,2 corrected code gaps')
