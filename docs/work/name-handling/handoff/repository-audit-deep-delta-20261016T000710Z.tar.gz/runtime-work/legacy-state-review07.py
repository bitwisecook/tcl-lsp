from record import *
notes={
642:'Actual capturedIncrement realoriginalname/cell/compiledslot and sharedRMWread/reporting owner integrated; exact callback/inputproducer validation separate.',
644:'Actual compiledArray instruction maps source/expanded/local slots to realreceiver/frame; iteration privatepayload placeholders do not issue nativeauxauthority.',
645:'Actual compiledDict mutation selects realLVTcell/header and terminalNameProtocolUnavailable beforeguestmissing; .ok predicate notautomaticabsencegrant.',
646:'Actual compiledCoroutineliterals/namespace/List/stack/currentoperation integrated; parent cmd_coro production nowreviewed, suspendedowner/providervalidation separate.',
647:'CompiledSwitch exact/source/literal geometry transport exists; genericprimitive nestedoperation gap is distinct648 and notcertified bythisboundedpurpose.',
649:'Actual compiledSubst cache uses sameheader/flags/stamp and genuine sourcearena/local/literal producer beforeprimaryadopt; parentproduction nowread, noSourceNativegrant.',
652:'Actual engine restriction checkedUnicode originalList and release-length/name ingress integrated; policycompatibilitynotopaqueoriginalNameidentity.',
653:'Actual commandreceipt stores trueinterpreter+neverreusedgeneration independentqualifiedaddressdata; underlying publication/retirement production nowread, nofreshNativeacceptance.',
655:'Actual fresh replaycontext operation/purpose buildsnewnamespace undermatchingprotocol/rootinterpreter thenrestores savedcontext; nevergrantsoldincarnation/generation.',
656:'Actual independent enginevaluefacts createfreshphysicalobjects with selectedscalar/receiverstorage checks; DTOcannotrestoreSource/frame/cell/nameidentity.',
657:'Actual result/options owners are integrated but this live completion construction still hardcodes -options constructor spelling; existing Return option metadata owner must supply that exact input purpose. This is metadata/adoption code work, not only fullrefcountvalidation.',
658:'Actual compilerpass keeps selected trueNstoken/Proc/limits and realLVT through firstpass executable/literalaux retirement; source/reportcannotissuepermission. Parentproduction nowread.',
660:'Actual compiledEach instruction/frame/trueLVT setter transport uses realListworkers and genuinefreshmissingmember cleanup; privateiterationemulationnotnativeauxheaderproof.',
661:'Counter .ok fallback cannot donateabsencebecause actualreceiver/store revalidatescell andterminalrefusesunavailable role. Causeprecision separate fromsuccessgrant.',
663:'Actual compiledTry protectedrealstack/anonymouscells/results/options/headerpairs survivehandlers/finally undergenuineoperation; .ok branches requireexactpairorterminalrefusal.',
665:'Actual compiledLappend realreceiver/header/primary/backing/member checks and read/write/COW store transport integrated; retaineddata/currentview purpose independent.',
668:'Actual sharedArray defaultoption names appear in separate pure/original declarations; consolidating selected descriptor/table metadata still code work. Correct table/cacheidentity must remain purpose-specific; regexp capabilityrefusalnotpositivecompletion.',
671:'Actual ArraySet original C/Jim producers are integrated, but actual ArrayFor still uses default ValueOps::list_elements without same outer originalcaller through nestedstages. Only ArrayFor needs this code adoption, unchanged setcallers must notinflate unitcount.',
673:'Actual codegen frame ledger pairs genuineinterpreter/activation and failedentrymarker cannotgrantframe; completedrecords retireoutsideborrow. Parentcodegenproduction nowread, generatedexecution unvalidated.',
674:'Actual precision name/trace/rootframe/binding identity fromselecteddoublepolicy integrated; outcome/callbackhandling code gaps separately675/676.',
677:'Actual selected Jim tailcall commandallocation retains exact physicalworker/token even afterslotretirement, distinctgenericcurrentlyinstalledquery; sharedcleanuporder and firstcause preserved.',
679:'Actual compiledList operation geometry/local/originalliteral/index/constructor/store and realframe/header pipeline integrated; metadata notoldheader/cellgrant, parentartifactproduction nowread.',
680:'Actual compiledDictionaryScope realLVTroot/targetcell/originalheader and preparedkey/path trace/COW/writeback retainsphysicalplace; .okselectedheaderchecks do notgrantNativeabsence.',
683:'Actual MethodTable records own realname/key headers and selectedpayload, replacement/rename retirement separate; parentOOproduction nowreviewed, originalprovider/lifecyclepending.',
684:'Actual methodcache worldbirth/OriginalOoTarget/stamp/Weakrecords versus enteredchain retainsALL actualrecords, no displayrebuild; FromVecnoNativecontext. ParentOOmutation/callchain source nowreviewed.',
690:'Actual prepared_compare caller sends preparedkeys to generic sort::key_compare without per-provider string/dictionary/case recipe. Shared comparison owner repair538 exists but this caller still needs explicit selected-recipe adoption, a distinct integration site in samefamily, not a second semantic comparatorbug.',
695:'Shared Cexact/glob/analysis-runtimeRegex selection owner implemented; declined/resourceoutcome nevermissingarm and purealgorithmdoesnot grantheaderauthority.',
699:'Shared nativesplit delegation and neutralcheckedUnicode fallback/sourceC86 geometry integrated; plannedrangesneveractualheader/reusegrant.',
700:'Actual compilerliteral partition/priming retains trueframe/sourceheader/commandtoken/Nspath/epoch and postprimarychange binding checks; bytesnotidentity.',
703:'Actual Return instruction keeps sameoriginaloptionsheader/incarnation/memberleases with selectedrealcaller/frame/sourcechecks throughpublication; testconvenience notNativeissuer.',
705:'Actual Jim dictionaryincrement captures realcell/frame/alias/key/parentheader and performs preparedCOW/immediateparentpublication; noInfoDataorImport/Normalgrant.',
712:'Actual procdefinition outer name/body/source storage owner integrated; innerformal/default/static/gettercurrency code issue is separate713 and originalnamespace/physicalbody source purposes remain distinct.',
719:'Actual generated variable countedinputs deliberatelyconstruct fresh evaluatednameobjects and invoke realinstalledworker/cellstore; nohistoricalsource/header reconstruction.',
721:'Actual generated scalargetter/completionoutput uses genuine originalprimitive and rechecks CodegenOperationbeforewrite; magnitudesnotsemanticnames or frameauthority.',
725:'Actual coroutine map/continuation selectedbygeneration, mutable reportbytes independent; source/script currentness/lifetime acceptance stillpending.',
728:'Actual wasmcoroutine capabilityexplicitlyunavailable, notsource/report-derivedcontinuation. Futureexplicitstackfeature notnewnamingresolver; noabsencegrant.',
729:'Actual CPackage immutablememberIndex/getter and opaqueevaluatedpackage/versionlabeldomain sharedowners; commandnamespace normalizer inappropriate.',
732:'Actual selectedpackageentry ledger/hashprotocol plus realversion/fileList resultowners integrated; exact originalkey/hashABI/source/cache behavior remains independentprovidercontrols, nolabelidentitygrant.',
734:'Actual privateerrorStack/carriedoptions realheader/incarnationTicket/currentoperation/checkedmutation owners integrated; Source/instructionlabels separatemetadata.',
737:'Actual runtime source lowerer retains countedbytes/fullconfig/rawspans/variablegeometry/executablearena and sharedscanners; NativeSourceImage geometry notinstalledheader/frame/permission.',
738:'Actual parseerror memo keyincludes fullLexerConfig and clearsonchange; truncateddepthanswersnotcached, nocallable/namespace/absenceidentity.',
739:'Actual byteListcodec delegates sharedgrammar/escape/messagerecipe with explicitambientTLSselection; doesnotissue originalheader/backing/memberrole.',
740:'Actual regex pattern/range/outputsetter producers exist but whole sameauthenticinvocation/frame/Ns/header acrossnestedgetters and regsubpublication is still missing integration. Recipe selection or genericIndexoperation alone cannot grant naming output-target frame/cell authority.',
746:'Actual C86ClockDateOps purpose-specificadapter/fieldmetadata integrated; ValueOpsparent wholeproduction nowread, date/provider/fulloriginalcallbacks unexecuted.',
751:'Actual binaryroot/wrapped originalarguments integrated, but missing native binary_root_dispatch mappedtoGuest diagnostic has unresolved actualregistration/providerreachability. This question cannot be called migrated-validation-pending; no genericHost-vsGuest verdict untilactualpurpose trace.'
}
d=load();out=[]
for i,n in notes.items():
 r=d['consumers'][i];assert r['disposition']=='migrated_validation_pending',(i,r['symbol']);old=dict(r)
 if i in [657,668,671,690,740]:
  r['disposition']='needs_migration';r['work_kind']='descriptor_metadata_or_target_schema' if i in [657,668] else 'consumer_integration';r['work_kind_reason']=n;r['missingintegration']=n+' Preserve actual original inputs/currentness/refusal/lifetimes and selected provider purposes; source review is not external semantic acceptance.'
 if i==751:r['disposition']='pending_audit';r['work_kind']='consumer_integration';r['work_kind_reason']=n;r['missingintegration']=n;r['native_gap_countable']=False
 if i in [646,649,653,658,673,679,683,684,746]:r['missingintegration']=n+' Actual provider/original Native controls remain unexecuted by audit.'
 if i==690:r['shared_repair_family_hint']='selected-native-string-sort-comparison';r['related_owner_row']=538
 r['legacy_state_review']={'batch':'runtime-work/legacy-state-review07.json','decision':r['disposition'],'reason':n};out.append({'index':i,'path':r['path'],'symbol':r['symbol'],'site':r['site'],'sourceSHA':r['sourceSHA'],'before_disposition':old['disposition'],'after_disposition':r['disposition'],'old_missingintegration':old['missingintegration'],'decision_reason':n})
atomic_write(ROOT/'runtime-consumers.json',json.dumps(d,indent=2)+'\n');atomic_write(ROOT/'runtime-work/legacy-state-review07.json',json.dumps({'baseline':d['baseline'],'scope':'45 individually interpreted prior states; metadata/adoption unresolved code distinguished from integrated physical subpurpose','rows':out,'execution':'None'},indent=2)+'\n');print(len(out),'reviewed,5codegaps/1providerquestion corrected')
