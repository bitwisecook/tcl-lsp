// tcl-lsp — a language server and toolchain for Tcl
// Copyright (C) 2026 James Deucker (bitwisecook) <https://github.com/bitwisecook>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.
//
// SPDX-License-Identifier: AGPL-3.0-or-later

//! `binary` byte transforms — pure codecs (`encode`/`decode` hex/base64/
//! uuencode) and the `format` pack grammar, shared by both runtimes' `binary`
//! adapters.
//!
//! These are deliberately **value-model-free**: the two runtimes carry binary
//! data differently (the WASM runtime as the object's raw bytes; the bytecode
//! VM as a byte-array string, one `U+00xx` scalar per byte), so each adapter
//! converts its value to/from `&[u8]`/`Vec<u8>` in its own convention and the
//! codec in between is identical. Decoders report the offending byte + position
//! ([`DecodeError`]); the adapter renders the Tcl message and sets the
//! `TCL BINARY DECODE` error code, which differs by codec.

use tcl_syntax::list::split_list;

use crate::error::CmdError;

/// A decode failure: the offending input byte and its position. The adapter
/// turns this into the codec-specific Tcl message (`invalid hexadecimal digit`
/// / `invalid base64 character`) plus the `TCL BINARY DECODE INVALID` code.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct DecodeError {
    /// The offending byte.
    pub byte: u8,
    /// Its zero-based position in the input.
    pub pos: usize,
}

const B64: &[u8; 64] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

#[inline]
fn hex_digit(n: u8) -> u8 {
    if n < 10 { b'0' + n } else { b'a' + (n - 10) }
}

#[inline]
fn hex_nib(c: u8) -> Option<u8> {
    match c {
        b'0'..=b'9' => Some(c - b'0'),
        b'a'..=b'f' => Some(c - b'a' + 10),
        b'A'..=b'F' => Some(c - b'A' + 10),
        _ => None,
    }
}

#[inline]
fn b64_val(c: u8) -> Option<u8> {
    match c {
        b'A'..=b'Z' => Some(c - b'A'),
        b'a'..=b'z' => Some(c - b'a' + 26),
        b'0'..=b'9' => Some(c - b'0' + 52),
        b'+' => Some(62),
        b'/' => Some(63),
        _ => None,
    }
}

// encode

/// `binary encode hex` — each byte as two lowercase hex digits.
#[must_use]
pub fn hex_encode(data: &[u8]) -> Vec<u8> {
    let mut out = Vec::with_capacity(data.len() * 2);
    for &b in data {
        out.push(hex_digit(b >> 4));
        out.push(hex_digit(b & 0xf));
    }
    out
}

/// `binary encode base64` — RFC 4648 with `=` padding; `maxlen > 0` wraps each
/// line at `maxlen` output characters with `wrap`.
#[must_use]
pub fn base64_encode(data: &[u8], maxlen: usize, wrap: &[u8]) -> Vec<u8> {
    let mut out = Vec::new();
    let mut line = 0usize;
    let mut emit = |out: &mut Vec<u8>, c: u8| {
        if maxlen > 0 && line >= maxlen {
            out.extend_from_slice(wrap);
            line = 0;
        }
        out.push(c);
        line += 1;
    };
    for chunk in data.chunks(3) {
        let b0 = u32::from(chunk[0]);
        let b1 = u32::from(*chunk.get(1).unwrap_or(&0));
        let b2 = u32::from(*chunk.get(2).unwrap_or(&0));
        let n = (b0 << 16) | (b1 << 8) | b2;
        emit(&mut out, B64[(n >> 18) as usize & 63]);
        emit(&mut out, B64[(n >> 12) as usize & 63]);
        emit(
            &mut out,
            if chunk.len() > 1 {
                B64[(n >> 6) as usize & 63]
            } else {
                b'='
            },
        );
        emit(
            &mut out,
            if chunk.len() > 2 {
                B64[n as usize & 63]
            } else {
                b'='
            },
        );
    }
    out
}

/// `binary encode uuencode` — each line is a length byte (`count + 0x20`) then
/// groups of 4 chars per 3 data bytes (`value + 0x20`, `` ` `` for 0). `maxlen`
/// caps data bytes per line (default 45).
#[must_use]
#[allow(clippy::cast_possible_truncation)] // 6-bit groups / line counts fit a byte by construction
pub fn uu_encode(data: &[u8], maxlen: usize, wrap: &[u8]) -> Vec<u8> {
    let per_line = if maxlen >= 5 {
        (maxlen - 1) / 4 * 3
    } else {
        45
    };
    let mut out = Vec::new();
    let uc = |v: u8| -> u8 { if v == 0 { b'`' } else { 0x20 + v } };
    for line in data.chunks(per_line.max(1)) {
        out.push(uc(line.len() as u8));
        for chunk in line.chunks(3) {
            let b0 = u32::from(chunk[0]);
            let b1 = u32::from(*chunk.get(1).unwrap_or(&0));
            let b2 = u32::from(*chunk.get(2).unwrap_or(&0));
            let n = (b0 << 16) | (b1 << 8) | b2;
            out.push(uc((n >> 18) as u8 & 63));
            out.push(uc((n >> 12) as u8 & 63));
            out.push(uc((n >> 6) as u8 & 63));
            out.push(uc(n as u8 & 63));
        }
        out.extend_from_slice(wrap);
    }
    out
}

// decode

/// Native decoder operand layout after the selected codec command head.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct DecodeArguments {
    /// Reject characters outside the codec's strict input grammar.
    pub strict: bool,
    /// Position of the data object in the original evaluated operands.
    pub data: usize,
}

/// Decoder option admission, before the data object is converted.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum DecodeArgumentsError {
    /// The selected codec accepts exactly one or two operands.
    WrongArity,
    /// The optional operand is not the exact native `-strict` switch.
    UnknownOption(Vec<u8>),
    /// A two-operand query omitted the actual first operand's value.
    UnresolvedOption,
}

impl DecodeArgumentsError {
    /// Exact native bad-option presentation; arity uses the invocation's
    /// separately retained public/private usage rewrite.
    #[must_use]
    pub fn option_message(&self) -> Option<Vec<u8>> {
        let Self::UnknownOption(option) = self else {
            return None;
        };
        let mut message = b"bad option \"".to_vec();
        message.extend_from_slice(option);
        message.extend_from_slice(b"\": must be -strict");
        Some(message)
    }
}

/// Select the measured C8.6+ hex/base64/uuencode decoder layout. This parser
/// neither establishes codec availability nor evaluates/converts the data.
pub fn decode_argument_layout(
    argument_count: usize,
    option: Option<&[u8]>,
) -> Result<DecodeArguments, DecodeArgumentsError> {
    match (argument_count, option) {
        (1, _) => Ok(DecodeArguments {
            strict: false,
            data: 0,
        }),
        (2, Some(b"-strict")) => Ok(DecodeArguments {
            strict: true,
            data: 1,
        }),
        (2, Some(option)) => Err(DecodeArgumentsError::UnknownOption(option.to_vec())),
        (2, None) => Err(DecodeArgumentsError::UnresolvedOption),
        _ => Err(DecodeArgumentsError::WrongArity),
    }
}

/// `binary decode hex` — pairs of hex digits to bytes; ASCII whitespace is
/// skipped, any other non-hex byte is a [`DecodeError`].
pub fn hex_decode(s: &[u8]) -> Result<Vec<u8>, DecodeError> {
    hex_decode_with_strict(s, false)
}

/// Native hex decoder with exact `-strict` whitespace rejection. Nonstrict
/// calls retain the existing odd trailing-nibble and whitespace behavior.
pub fn hex_decode_with_strict(s: &[u8], strict: bool) -> Result<Vec<u8>, DecodeError> {
    let mut out = Vec::with_capacity(s.len() / 2);
    let mut hi: Option<u8> = None;
    for (pos, &c) in s.iter().enumerate() {
        let v = match hex_nib(c) {
            Some(v) => v,
            None if !strict && c.is_ascii_whitespace() => continue,
            None => return Err(DecodeError { byte: c, pos }),
        };
        match hi.take() {
            None => hi = Some(v),
            Some(h) => out.push((h << 4) | v),
        }
    }
    Ok(out)
}

/// Native base64 decoding, including implicit final padding and exact strict
/// rejection at the last consumed input byte.
pub fn base64_decode(s: &[u8], strict: bool) -> Result<Vec<u8>, DecodeError> {
    let mut out = Vec::new();
    let mut cursor = 0;
    let mut cut = 0;
    let mut last = 0;
    while cursor < s.len() {
        let mut value = 0u32;
        let mut index = 0;
        while index < 4 {
            let byte = if cursor < s.len() {
                last = s[cursor];
                cursor += 1;
                last
            } else if index > 1 {
                b'='
            } else {
                if strict {
                    return Err(DecodeError {
                        byte: last,
                        pos: cursor.saturating_sub(1),
                    });
                }
                cut += 3;
                break;
            };
            if cut > 0 {
                if byte == b'=' && index > 1 {
                    value <<= 6;
                    cut += 1;
                } else if strict {
                    return Err(DecodeError {
                        byte: last,
                        pos: cursor.saturating_sub(1),
                    });
                } else {
                    continue;
                }
            } else if let Some(digit) = b64_val(byte) {
                value = (value << 6) | u32::from(digit);
            } else if byte == b'=' && (!strict || index > 1) {
                value <<= 6;
                cut += usize::from(index != 0);
            } else if strict {
                return Err(DecodeError {
                    byte: last,
                    pos: cursor.saturating_sub(1),
                });
            } else {
                continue;
            }
            index += 1;
        }
        let bytes = value.to_be_bytes();
        out.extend_from_slice(&bytes[1..]);
        if cut > 0 && cursor < s.len() && strict {
            return Err(DecodeError {
                byte: last,
                pos: cursor - 1,
            });
        }
    }
    out.truncate(out.len().saturating_sub(cut));
    Ok(out)
}

/// Native uuencode decoder failure.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum UuDecodeError {
    /// An invalid input byte, retaining its original source offset.
    Invalid(DecodeError),
    /// A strict input line ended before its declared payload was complete.
    Short,
}

/// Native uuencode decoding. Line headers are validated even without strict
/// mode; strict mode additionally validates body bytes and declared lengths.
pub fn uu_decode_with_strict(s: &[u8], strict: bool) -> Result<Vec<u8>, UuDecodeError> {
    let mut out = Vec::new();
    let mut cursor = 0;
    let mut remaining = None;
    while cursor < s.len() {
        if remaining.is_none() {
            let byte = s[cursor];
            cursor += 1;
            if !(32..=96).contains(&byte) {
                if strict || !byte.is_ascii_whitespace() {
                    return Err(UuDecodeError::Invalid(DecodeError {
                        byte,
                        pos: cursor - 1,
                    }));
                }
                continue;
            }
            remaining = Some(usize::from(byte.wrapping_sub(32) & 63));
        }
        let mut group = [0u8; 4];
        let mut index = 0;
        while index < 4 {
            if cursor < s.len() {
                let byte = s[cursor];
                cursor += 1;
                if !(32..=96).contains(&byte) {
                    if strict {
                        if !byte.is_ascii_whitespace() {
                            return Err(UuDecodeError::Invalid(DecodeError {
                                byte,
                                pos: cursor - 1,
                            }));
                        }
                        if byte == b'\n' {
                            return Err(UuDecodeError::Short);
                        }
                    }
                    continue;
                }
                group[index] = byte;
            }
            index += 1;
        }
        let digits = group.map(|byte| byte.wrapping_sub(32) & 63);
        let value = (u32::from(digits[0]) << 18)
            | (u32::from(digits[1]) << 12)
            | (u32::from(digits[2]) << 6)
            | u32::from(digits[3]);
        let bytes = value.to_be_bytes();
        let count = remaining.expect("line header selected").min(3);
        out.extend_from_slice(&bytes[1..=count]);
        remaining = remaining.map(|length| length - count);
        if remaining == Some(0) && cursor < s.len() {
            remaining = None;
            while cursor < s.len() {
                let byte = s[cursor];
                cursor += 1;
                if byte == b'\n' {
                    break;
                }
                if (32..=96).contains(&byte) {
                    cursor -= 1;
                    break;
                }
                if strict || !byte.is_ascii_whitespace() {
                    return Err(UuDecodeError::Invalid(DecodeError {
                        byte,
                        pos: cursor - 1,
                    }));
                }
            }
        }
    }
    if strict && remaining.is_some_and(|length| length > 0) {
        Err(UuDecodeError::Short)
    } else {
        Ok(out)
    }
}

/// Compatibility nonstrict decoder. Runtime adapters that need native errors
/// consume [`uu_decode_with_strict`] directly.
#[must_use]
pub fn uu_decode(s: &[u8]) -> Vec<u8> {
    uu_decode_with_strict(s, false).unwrap_or_default()
}

// format (the pack grammar)

/// Endianness of a multi-byte numeric field.
#[derive(Clone, Copy)]
pub enum End {
    /// Least-significant byte first.
    Little,
    /// Most-significant byte first.
    Big,
}

/// The count after a type code: an explicit number, `*` (all), or absent.
enum Count {
    Num(usize),
    Star,
    None,
}

/// One recognised `binary format`/`scan` field.  This is the shared grammar
/// view used by editor consumers; the runtime pack/unpack paths below keep
/// their value handling, but must recognise the same field letters.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Specifier {
    /// Byte offset of the field letter within the format string.
    pub letter_start: usize,
    /// Byte offset immediately after the field (including modifier/count).
    pub end: usize,
    /// Field letter (`a`, `i`, `q`, …).
    pub letter: u8,
    /// The unsigned suffix (`u`) when the field carries one.  Tcl's
    /// `GetFormatSpec` consumes a `u` after *any* field letter, so this is
    /// not restricted to the integer types; on the non-integer ones the
    /// flag is simply never read.
    pub modifier: Option<u8>,
    /// Whether the field uses `*` rather than a numeric count.
    pub star: bool,
    /// Parsed count, when present and representable.
    pub count: Option<usize>,
}

/// Return whether `letter` is a real binary field type in the shared runtime
/// grammar.  In particular, `q` and `Q` are the little-/big-endian 64-bit
/// floating-point fields; editor tables must not omit them.
#[must_use]
pub fn is_specifier(letter: u8) -> bool {
    matches!(
        letter,
        b'a' | b'A'
            | b'b'
            | b'B'
            | b'h'
            | b'H'
            | b'c'
            | b's'
            | b'S'
            | b't'
            | b'i'
            | b'I'
            | b'n'
            | b'w'
            | b'W'
            | b'm'
            | b'r'
            | b'R'
            | b'f'
            | b'd'
            | b'q'
            | b'Q'
            | b'x'
            | b'X'
            | b'@'
    )
}

use tcl_dialect::model::{SpecSurface, surface_admits};

/// The lowest Tcl release that accepts `letter` as a binary field, or
/// `None` when every modelled release accepts it.
///
/// `t n m r R q Q` arrive in Tcl 8.5 and are `bad field specifier` on
/// 8.4 — checked against tclsh 8.4.20 and 8.5.19 for both `binary
/// format` and `binary scan`, which share `GetFormatSpec`. Keep the
/// floor with the binary owner so no consumer re-derives it; this is
/// the field-letter sibling of [`signedness_available`], which gates
/// the `u` suffix.
#[must_use]
pub fn specifier_min_version(letter: u8) -> Option<tcl_dialect::TclVersion> {
    matches!(letter, b't' | b'n' | b'm' | b'r' | b'R' | b'q' | b'Q')
        .then_some(tcl_dialect::TclVersion::V8_5)
}

/// Whether Tcl's unsigned suffix (`u`) is part of the resolved
/// binary-field grammar.  Keep this decision with the binary owner so LSP
/// surfaces cannot drift or re-derive a release comparison independently.
#[must_use]
pub fn signedness_available(profile: &tcl_dialect::DialectProfile) -> bool {
    profile.runtime_base.is_some()
        && surface_admits(SpecSurface::TCL85_PLUS, Some(&profile.surface_query()))
}

/// Parse all recognised binary fields, retaining source positions for editor
/// consumers.  `allow_modifier` is the resolved dialect decision for Tcl's
/// 8.5+ unsigned suffix; when false the `u` remains ordinary text.
///
/// TIP 275 added exactly one suffix, `u`.  `s` is the short-integer field
/// letter, never a signedness modifier — `ss` is two 2-byte fields on every
/// release (checked against tclsh 8.4.20, 8.5.19, 8.6.18 and 9.0.4).  The
/// suffix follows *any* field letter, matching `GetFormatSpec` in
/// `tclBinary.c`, which consumes a `u` straight after the command character
/// without consulting the type.
#[must_use]
pub fn specifiers(fmt: &[u8], allow_modifier: bool) -> Vec<Specifier> {
    let mut out = Vec::new();
    let mut i = 0usize;
    while i < fmt.len() {
        if fmt[i].is_ascii_whitespace() {
            i += 1;
            continue;
        }
        let letter_start = i;
        let letter = fmt[i];
        if !is_specifier(letter) {
            i += 1;
            continue;
        }
        i += 1;
        let modifier = if allow_modifier && fmt.get(i) == Some(&b'u') {
            i += 1;
            Some(b'u')
        } else {
            None
        };
        let star = fmt.get(i) == Some(&b'*');
        let count = if star {
            i += 1;
            None
        } else {
            let start = i;
            let mut count = 0usize;
            while fmt.get(i).is_some_and(u8::is_ascii_digit) {
                count = count
                    .saturating_mul(10)
                    .saturating_add(usize::from(fmt[i] - b'0'));
                i += 1;
            }
            (i > start).then_some(count)
        };
        out.push(Specifier {
            letter_start,
            end: i,
            letter,
            modifier,
            star,
            count,
        });
    }
    out
}

/// Parse the optional count following a type char (advancing `i`).
fn parse_count(fmt: &[u8], i: &mut usize) -> Count {
    if fmt.get(*i) == Some(&b'*') {
        *i += 1;
        return Count::Star;
    }
    let start = *i;
    let mut n: usize = 0;
    while let Some(&c) = fmt.get(*i) {
        if c.is_ascii_digit() {
            n = n.saturating_mul(10).saturating_add(usize::from(c - b'0'));
            *i += 1;
        } else {
            break;
        }
    }
    if *i > start {
        Count::Num(n)
    } else {
        Count::None
    }
}

/// Parse a Tcl integer to a wide int — the shared grammar
/// ([`crate::sort::parse_wide`], the 9.0-first `tcl_syntax::number` integer
/// shape), narrowed by wrapping: an `i128` past `i64` wraps modulo 2⁶⁴,
/// matching C's `binary format` truncation of oversize values.
#[allow(clippy::cast_possible_truncation)] // i128 → i64 wrap matches C's `binary format`
fn parse_wide(b: &[u8]) -> Option<i64> {
    crate::sort::parse_wide(b).map(|v| v as i64)
}

/// Write `bytes` at the cursor `cur`, overwriting then extending `out`.
fn put(out: &mut Vec<u8>, cur: &mut usize, bytes: &[u8]) {
    for &b in bytes {
        if *cur < out.len() {
            out[*cur] = b;
        } else {
            out.push(b);
        }
        *cur += 1;
    }
}

/// `(byte size, endianness)` for an integer type code.
#[allow(clippy::match_same_arms)] // each Tcl code is listed explicitly for clarity
fn int_kind(ty: u8) -> (usize, End) {
    match ty {
        b'c' => (1, End::Little),
        b's' => (2, End::Little),
        b'S' => (2, End::Big),
        b't' => (2, End::Little), // native = little
        b'i' => (4, End::Little),
        b'I' => (4, End::Big),
        b'n' => (4, End::Little),
        b'w' => (8, End::Little),
        b'W' => (8, End::Big),
        _ => (8, End::Little), // m, native
    }
}

/// `(byte size, endianness)` for a float type code.
fn float_kind(ty: u8) -> (usize, End) {
    match ty {
        b'f' | b'r' => (4, End::Little),
        b'R' => (4, End::Big),
        b'd' | b'q' => (8, End::Little),
        _ => (8, End::Big), // Q
    }
}

/// `v`'s low `size` bytes in `end` order.
#[allow(clippy::cast_sign_loss)] // the bit pattern is what gets packed
fn int_bytes(v: i64, size: usize, end: End) -> Vec<u8> {
    let le = (v as u64).to_le_bytes();
    let mut b = le[..size].to_vec();
    if matches!(end, End::Big) {
        b.reverse();
    }
    b
}

/// `v` as an IEEE-754 float of `size` bytes in `end` order.
#[allow(clippy::cast_possible_truncation)] // f64 → f32 narrowing is the `f`/`r` field semantics
fn float_bytes(v: f64, size: usize, end: End) -> Vec<u8> {
    let mut b = if size == 4 {
        (v as f32).to_le_bytes().to_vec()
    } else {
        v.to_le_bytes().to_vec()
    };
    if matches!(end, End::Big) {
        b.reverse();
    }
    b
}

/// Pack `n` binary digits of `s` into ceil(n/8) bytes. `high_first` (`B`) fills
/// each byte MSB→LSB; `b` fills LSB→MSB. The consumed digits must all be `0`/`1`
/// (C errors `expected binary string but got "…" instead`); missing trailing
/// digits (when `n` exceeds the string) are zero-padded, not an error.
fn pack_bits(s: &[u8], n: usize, high_first: bool) -> Result<Vec<u8>, CmdError> {
    let mut out = vec![0u8; n.div_ceil(8)];
    for k in 0..n.min(s.len()) {
        match s[k] {
            b'0' => {}
            b'1' => {
                out[k / 8] |= if high_first {
                    0x80 >> (k % 8)
                } else {
                    1 << (k % 8)
                }
            }
            _ => return Err(expected_string("binary", s)),
        }
    }
    Ok(out)
}

/// Pack `n` hex digits of `s` into ceil(n/2) bytes. `high_first` (`H`) places
/// the first digit in the high nibble; `h` in the low nibble. The consumed
/// digits must all be hex (else C's `expected hexadecimal string but got "…"`).
fn pack_hex(s: &[u8], n: usize, high_first: bool) -> Result<Vec<u8>, CmdError> {
    let mut out = vec![0u8; n.div_ceil(2)];
    for k in 0..n.min(s.len()) {
        let Some(nib) = hex_nib(s[k]) else {
            return Err(expected_string("hexadecimal", s));
        };
        let high = (k % 2 == 0) == high_first;
        out[k / 2] |= if high { nib << 4 } else { nib };
    }
    Ok(out)
}

/// The error for a non-integer count-less integer field value: C reports a
/// multi-element value as `a list`, a single bad token verbatim.
fn int_value_error(arg: &[u8]) -> CmdError {
    let text = String::from_utf8_lossy(arg);
    if split_list(&text).is_ok_and(|e| e.len() != 1) {
        CmdError::new("expected integer but got a list".to_string())
    } else {
        CmdError::new(format!("expected integer but got \"{text}\""))
    }
}

/// C's `expected <kind> string but got "<arg>" instead` for an invalid `b`/`B`/
/// `h`/`H` `binary format` field value.
fn expected_string(kind: &str, arg: &[u8]) -> CmdError {
    CmdError::new(format!(
        "expected {kind} string but got \"{}\" instead",
        String::from_utf8_lossy(arg)
    ))
}

/// Take the next argument (each `args` element is one argument's byte rep),
/// erroring when the format string demands more than were supplied.
fn next_arg<'a, V>(args: &'a [V], ai: &mut usize) -> Result<&'a V, CmdError> {
    let a = args.get(*ai).ok_or_else(|| {
        CmdError::new("not enough arguments for all format specifiers".to_string())
    })?;
    *ai += 1;
    Ok(a)
}

/// Allocate `n` bytes filled with `fill`, returning a catchable [`CmdError`]
/// instead of panicking on a capacity overflow. A `binary format` count may be
/// a saturated out-of-range value (`usize::MAX`); `vec![fill; n]` would abort
/// the process with "capacity overflow".
fn alloc_field(n: usize, fill: u8) -> Result<Vec<u8>, CmdError> {
    let mut v: Vec<u8> = Vec::new();
    v.try_reserve_exact(n)
        .map_err(|_| CmdError::new(format!("binary format: field size {n} is too large")))?;
    v.resize(n, fill);
    Ok(v)
}

/// Runtime value coercions used by the shared binary field grammar.
/// Numeric reads must retain numeric representations instead of formatting them.
pub trait FormatValueOps {
    /// Optional original format/header stage; neutral adapters do no work.
    fn binary_format_current(&mut self) -> Result<(), CmdError> {
        Ok(())
    }
    /// One runtime-owned value.
    type Value;
    /// Convert a byte/string field through the native byte encoding policy.
    fn binary_format_bytes(&mut self, value: &Self::Value) -> Result<Vec<u8>, CmdError>;
    /// Convert an integer field through the native integer coercion policy.
    fn binary_format_integer(&mut self, value: &Self::Value) -> Result<i64, CmdError>;
    /// Read a numeric double without materialising its string representation.
    fn binary_format_double(&mut self, value: &Self::Value) -> Result<f64, CmdError>;
    /// Read counted numeric fields as a native list of retained values.
    fn binary_format_elements(&mut self, value: &Self::Value)
    -> Result<Vec<Self::Value>, CmdError>;
}

/// Coerce a binary integer through the shared native integer-width owner.
/// Bignum-capable Tcl engines reduce the magnitude modulo 2^64.
pub fn integer_value<O: tcl_syntax::value::ValueOps>(
    ops: &mut O,
    value: &O::Value,
    syntax: tcl_dialect::NumberSyntax,
) -> Result<i64, CmdError> {
    crate::format::fixed_integer_value(ops, value, syntax)
}

/// Same fixed-width projection after the caller's checked magnitude getter.
#[must_use]
pub fn integer_from_magnitude(magnitude: tcl_syntax::value::IntegerMagnitude) -> i64 {
    crate::format::fixed_integer_magnitude(magnitude)
}

struct ByteFormatOps;

impl FormatValueOps for ByteFormatOps {
    type Value = Vec<u8>;

    fn binary_format_bytes(&mut self, value: &Self::Value) -> Result<Vec<u8>, CmdError> {
        Ok(value.clone())
    }

    fn binary_format_integer(&mut self, value: &Self::Value) -> Result<i64, CmdError> {
        parse_wide(value).ok_or_else(|| int_value_error(value))
    }

    fn binary_format_double(&mut self, value: &Self::Value) -> Result<f64, CmdError> {
        let text = String::from_utf8_lossy(value);
        text.trim().parse().map_err(|_| {
            CmdError::new(format!("expected floating-point number but got \"{text}\""))
        })
    }

    fn binary_format_elements(
        &mut self,
        value: &Self::Value,
    ) -> Result<Vec<Self::Value>, CmdError> {
        Ok(split_field(value)?
            .into_iter()
            .map(|value| value.as_bytes().to_vec())
            .collect())
    }
}

/// Compatibility packing for values whose byte representation is already known.
/// Runtime adapters should use [`format_values`] to retain native numeric values.
pub fn format(fmt: &[u8], args: &[&[u8]]) -> Result<Vec<u8>, CmdError> {
    format_values(
        &mut ByteFormatOps,
        fmt,
        &args.iter().map(|value| value.to_vec()).collect::<Vec<_>>(),
    )
}

/// `binary format formatString ?arg ...?` — pack the arguments (each given as
/// its byte representation) per the format string, returning the packed bytes.
/// The cursor model (`@`/`x`/`X`) and every type code are handled here; the
/// runtime adapter only converts its argument values to/from bytes.
pub fn format_values<O: FormatValueOps>(
    ops: &mut O,
    fmt: &[u8],
    args: &[O::Value],
) -> Result<Vec<u8>, CmdError> {
    format_values_using(ops, fmt, args, &mut |field| {
        CmdError::new(format!("bad field specifier \"{}\"", field[0] as char))
    })
}

/// Pack through the same field worker with a selected diagnostic projection.
/// The original format extent and object conversions belong to the caller.
#[allow(clippy::too_many_lines)] // one match arm per Tcl field type — a flat dispatch reads best
pub fn format_values_using<O: FormatValueOps>(
    ops: &mut O,
    fmt: &[u8],
    args: &[O::Value],
    bad_field: &mut dyn FnMut(&[u8]) -> CmdError,
) -> Result<Vec<u8>, CmdError> {
    let mut ai = 0usize;
    let mut out: Vec<u8> = Vec::new();
    let mut cur = 0usize;
    let mut i = 0usize;

    while i < fmt.len() {
        ops.binary_format_current()?;
        let field_start = i;
        let ty = fmt[i];
        if ty.is_ascii_whitespace() {
            i += 1;
            continue;
        }
        i += 1;
        let count = parse_count(fmt, &mut i);
        match ty {
            b'a' | b'A' => {
                let s = ops.binary_format_bytes(next_arg(args, &mut ai)?)?;
                let n = match count {
                    Count::Star => s.len(),
                    Count::Num(n) => n,
                    Count::None => 1,
                };
                let pad = if ty == b'A' { b' ' } else { 0 };
                let mut field = alloc_field(n, pad)?;
                let take = s.len().min(n);
                field[..take].copy_from_slice(&s[..take]);
                put(&mut out, &mut cur, &field);
            }
            b'b' | b'B' => {
                let s = ops.binary_format_bytes(next_arg(args, &mut ai)?)?;
                let n = match count {
                    Count::Star => s.len(),
                    Count::Num(n) => n,
                    Count::None => 1,
                };
                put(&mut out, &mut cur, &pack_bits(&s, n, ty == b'B')?);
            }
            b'h' | b'H' => {
                let s = ops.binary_format_bytes(next_arg(args, &mut ai)?)?;
                let n = match count {
                    Count::Star => s.len(),
                    Count::Num(n) => n,
                    Count::None => 1,
                };
                put(&mut out, &mut cur, &pack_hex(&s, n, ty == b'H')?);
            }
            b'c' | b's' | b'S' | b't' | b'i' | b'I' | b'n' | b'w' | b'W' | b'm' => {
                let (size, end) = int_kind(ty);
                let arg = next_arg(args, &mut ai)?;
                if matches!(count, Count::None) {
                    // No count: the value is a *single* integer, not a list whose
                    // first element is taken (C: `binary format c {1 2}` errors).
                    let v = ops.binary_format_integer(arg)?;
                    put(&mut out, &mut cur, &int_bytes(v, size, end));
                } else {
                    let elems = ops.binary_format_elements(arg)?;
                    let n = field_count(&count, elems.len())?;
                    for e in &elems[..n] {
                        let v = ops.binary_format_integer(e)?;
                        put(&mut out, &mut cur, &int_bytes(v, size, end));
                    }
                }
            }
            b'f' | b'r' | b'R' | b'd' | b'q' | b'Q' => {
                let (size, end) = float_kind(ty);
                let arg = next_arg(args, &mut ai)?;
                if matches!(count, Count::None) {
                    let v = ops.binary_format_double(arg)?;
                    put(&mut out, &mut cur, &float_bytes(v, size, end));
                } else {
                    let elems = ops.binary_format_elements(arg)?;
                    let n = field_count(&count, elems.len())?;
                    for value in &elems[..n] {
                        let v = ops.binary_format_double(value)?;
                        put(&mut out, &mut cur, &float_bytes(v, size, end));
                    }
                }
            }
            b'x' => {
                let n = match count {
                    Count::Num(n) => n,
                    Count::Star | Count::None => 1,
                };
                put(&mut out, &mut cur, &alloc_field(n, 0)?);
            }
            b'X' => {
                let n = match count {
                    Count::Star => cur,
                    Count::Num(n) => n,
                    Count::None => 1,
                };
                cur = cur.saturating_sub(n);
            }
            b'@' => {
                let n = match count {
                    Count::Star => out.len(),
                    Count::Num(n) => n,
                    Count::None => 0,
                };
                if n > out.len() {
                    out.resize(n, 0);
                }
                cur = n;
            }
            _ => {
                return Err(bad_field(&fmt[field_start..]));
            }
        }
    }
    ops.binary_format_current()?;
    Ok(out)
}

/// An upper bound on the bytes [`format`] packs for `fmt` and `args`,
/// computed without packing anything: the widest write every field can make
/// plus the furthest absolute `@` position, saturating. A caller charges it
/// before [`format`] runs, so a count such as `x99999999999` is refused by a
/// budget rather than allocated. A counted numeric field's list has at most
/// one element per byte of its argument plus one.
#[must_use]
pub fn format_size_bound(fmt: &[u8], args: &[&[u8]]) -> u64 {
    let wide = |n: usize| u64::try_from(n).unwrap_or(u64::MAX);
    let mut next = args.iter().map(|arg| wide(arg.len()));
    let mut writes = 0u64;
    let mut furthest = 0u64;
    let mut i = 0usize;
    while i < fmt.len() {
        let ty = fmt[i];
        i += 1;
        if ty.is_ascii_whitespace() {
            continue;
        }
        let count = parse_count(fmt, &mut i);
        let span = |all: u64| match count {
            Count::Num(n) => wide(n),
            Count::Star => all,
            Count::None => 1,
        };
        let field = match ty {
            b'a' | b'A' => span(next.next().unwrap_or(0)),
            b'b' | b'B' => span(next.next().unwrap_or(0)).div_ceil(8),
            b'h' | b'H' => span(next.next().unwrap_or(0)).div_ceil(2),
            b'c' | b's' | b'S' | b't' | b'i' | b'I' | b'n' | b'w' | b'W' | b'm' => {
                span(next.next().unwrap_or(0).saturating_add(1))
                    .saturating_mul(wide(int_kind(ty).0))
            }
            b'f' | b'r' | b'R' | b'd' | b'q' | b'Q' => {
                span(next.next().unwrap_or(0).saturating_add(1))
                    .saturating_mul(wide(float_kind(ty).0))
            }
            b'x' => span(1),
            b'@' => {
                if let Count::Num(n) = count {
                    furthest = furthest.max(wide(n));
                }
                0
            }
            _ => 0,
        };
        writes = writes.saturating_add(field);
    }
    writes.saturating_add(furthest)
}

/// Split a numeric-field argument into list elements (the canonical Tcl list
/// message on a malformed value).
fn split_field(arg: &[u8]) -> Result<Vec<std::borrow::Cow<'_, str>>, CmdError> {
    let s = core::str::from_utf8(arg).map_err(|_| CmdError::new("invalid utf-8 in list"))?;
    split_list(s).map_err(|e| CmdError::new(e.message().to_string()))
}

/// Resolve a field's element count against the list length (erroring when the
/// list is too short for an explicit count).
fn field_count(count: &Count, available: usize) -> Result<usize, CmdError> {
    let n = match count {
        Count::Star => available,
        Count::Num(n) => *n,
        Count::None => 1,
    };
    if available < n {
        return Err(CmdError::new(
            "number of elements in list does not match count".to_string(),
        ));
    }
    Ok(n)
}

// scan (the unpack grammar)

/// Read `size` bytes as a sign-extended integer in `end` order.
#[allow(clippy::cast_possible_wrap)] // the unpacked bit pattern is the signed value
fn read_int(b: &[u8], size: usize, end: End) -> i64 {
    let mut buf = [0u8; 8];
    if matches!(end, End::Big) {
        for k in 0..size {
            buf[k] = b[size - 1 - k];
        }
    } else {
        buf[..size].copy_from_slice(&b[..size]);
    }
    let u = u64::from_le_bytes(buf);
    let bits = size * 8;
    if bits < 64 && (u >> (bits - 1)) & 1 == 1 {
        (u | (!0u64 << bits)) as i64
    } else {
        u as i64
    }
}

/// Read `size` bytes as an IEEE-754 float in `end` order.
fn read_float(b: &[u8], size: usize, end: End) -> f64 {
    let mut buf = [0u8; 8];
    if matches!(end, End::Big) {
        for k in 0..size {
            buf[k] = b[size - 1 - k];
        }
    } else {
        buf[..size].copy_from_slice(&b[..size]);
    }
    if size == 4 {
        f64::from(f32::from_le_bytes([buf[0], buf[1], buf[2], buf[3]]))
    } else {
        f64::from_le_bytes(buf)
    }
}

/// Unpack `n` bits from `data` into a binary-digit string.
fn unpack_bits(data: &[u8], n: usize, high_first: bool) -> Vec<u8> {
    let mut s = Vec::with_capacity(n);
    for k in 0..n {
        let byte = data.get(k / 8).copied().unwrap_or(0);
        let pos = k % 8;
        let bit = if high_first {
            (byte >> (7 - pos)) & 1
        } else {
            (byte >> pos) & 1
        };
        s.push(b'0' + bit);
    }
    s
}

/// Unpack `n` hex digits from `data`.
fn unpack_hex(data: &[u8], n: usize, high_first: bool) -> Vec<u8> {
    let mut s = Vec::with_capacity(n);
    for k in 0..n {
        let byte = data.get(k / 2).copied().unwrap_or(0);
        let nib = if (k % 2 == 0) == high_first {
            byte >> 4
        } else {
            byte & 0x0f
        };
        s.push(b"0123456789abcdef"[nib as usize]);
    }
    s
}

/// Join scanned values into a Tcl list (each is a number/string with no special
/// chars, so a space-join is a valid list).
fn join_list(vals: &[Vec<u8>]) -> Vec<u8> {
    let mut out = Vec::new();
    for (k, v) in vals.iter().enumerate() {
        if k > 0 {
            out.push(b' ');
        }
        out.extend_from_slice(v);
    }
    out
}

/// One binary scan field, retaining floating representations until the
/// adapter creates native lazy numeric objects.
#[derive(Debug, Clone, PartialEq)]
pub enum ScanValue {
    /// A byte or already encoded integer/list field.
    Bytes(Vec<u8>),
    /// One unmaterialised floating value.
    Double(f64),
    /// A counted floating field whose elements remain unmaterialised.
    Doubles(Vec<f64>),
}

/// Compatibility byte projection using Tcl 9 shortest floating strings.
/// Native adapters must use [`scan_values`] to preserve lazy conversion.
pub fn scan(data: &[u8], fmt: &[u8]) -> Result<Vec<Vec<u8>>, CmdError> {
    scan_values(data, fmt).map(|values| {
        values
            .into_iter()
            .map(|value| match value {
                ScanValue::Bytes(bytes) => bytes,
                ScanValue::Double(value) => tcl_syntax::number::format_double(value).into_bytes(),
                ScanValue::Doubles(values) => tcl_syntax::list::join_list(
                    values.into_iter().map(tcl_syntax::number::format_double),
                )
                .into_bytes(),
            })
            .collect()
    })
}

/// `binary scan string formatString` — unpack `data` per the format string,
/// returning typed values to assign to the successive
/// `varName`s, in order. Scanning stops when `data` is exhausted; the caller
/// assigns the values (erroring if it runs out of variables) and returns the
/// conversion count.
pub fn scan_values(data: &[u8], fmt: &[u8]) -> Result<Vec<ScanValue>, CmdError> {
    let mut out = Vec::new();
    scan_values_using(
        data,
        fmt,
        &mut |value| {
            out.push(value);
            Ok(())
        },
        &mut |field| CmdError::new(format!("bad field specifier \"{}\"", field[0] as char)),
    )?;
    Ok(out)
}

/// Emit each reached field before the next format item through the same
/// scanner. The caller owns assignment, continuation and diagnostic purposes.
#[allow(clippy::cast_sign_loss)] // the unsigned-mask path reinterprets the value's bits
#[allow(clippy::too_many_lines)] // one match arm per Tcl field type — a flat dispatch reads best
pub fn scan_values_using<E>(
    data: &[u8],
    fmt: &[u8],
    emit: &mut dyn FnMut(ScanValue) -> Result<(), E>,
    bad_field: &mut dyn FnMut(&[u8]) -> E,
) -> Result<usize, E> {
    let mut emitted = 0;
    let mut cur = 0usize;
    let mut i = 0usize;
    while i < fmt.len() {
        let field_start = i;
        let ty = fmt[i];
        if ty.is_ascii_whitespace() {
            i += 1;
            continue;
        }
        i += 1;
        // A `u` after an integer type code requests unsigned interpretation.
        let unsigned = matches!(
            ty,
            b'c' | b's' | b'S' | b't' | b'i' | b'I' | b'n' | b'w' | b'W' | b'm'
        ) && fmt.get(i) == Some(&b'u');
        if unsigned {
            i += 1;
        }
        let count = parse_count(fmt, &mut i);
        match ty {
            b'a' | b'A' => {
                let n = match count {
                    Count::Star => data.len().saturating_sub(cur),
                    Count::Num(n) => n,
                    Count::None => 1,
                };
                // `n` may be `usize::MAX` (a saturated out-of-range count), so
                // `cur + n` must be checked — an unchecked add panics in debug
                // and wraps in release (`1 + usize::MAX → 0`), turning the
                // bounds check into `0 > len` (false) and slicing `data[1..0]`.
                // Not enough bytes → stop, like any short read.
                let Some(end) = cur.checked_add(n).filter(|&e| e <= data.len()) else {
                    break;
                };
                let mut s = data[cur..end].to_vec();
                if ty == b'A' {
                    while matches!(s.last(), Some(b' ' | 0)) {
                        s.pop();
                    }
                }
                cur = end;
                emit(ScanValue::Bytes(s))?;
                emitted += 1;
            }
            b'b' | b'B' => {
                let n = match count {
                    Count::Star => data.len().saturating_sub(cur).saturating_mul(8),
                    Count::Num(n) => n,
                    Count::None => 1,
                };
                if cur + n.div_ceil(8) > data.len() {
                    break;
                }
                emit(ScanValue::Bytes(unpack_bits(&data[cur..], n, ty == b'B')))?;
                emitted += 1;
                cur += n.div_ceil(8);
            }
            b'h' | b'H' => {
                let n = match count {
                    Count::Star => data.len().saturating_sub(cur).saturating_mul(2),
                    Count::Num(n) => n,
                    Count::None => 1,
                };
                if cur + n.div_ceil(2) > data.len() {
                    break;
                }
                emit(ScanValue::Bytes(unpack_hex(&data[cur..], n, ty == b'H')))?;
                emitted += 1;
                cur += n.div_ceil(2);
            }
            b'c' | b's' | b'S' | b't' | b'i' | b'I' | b'n' | b'w' | b'W' | b'm' => {
                let (size, end) = int_kind(ty);
                let n = match count {
                    Count::Star => data.len().saturating_sub(cur) / size,
                    Count::Num(n) => n,
                    Count::None => 1,
                };
                // `n` comes from the format string and `parse_count` saturates it
                // to `usize::MAX`, so `n * size` (and the cursor add) can overflow
                // usize and wrap *below* the bounds check, sneaking past it (and
                // then `Vec::with_capacity(n)` would try to allocate `usize::MAX`).
                // Compute the field end with checked arithmetic; an overflow means
                // the field cannot fit in `data`, so stop scanning like the normal
                // out-of-data path does.
                let fits = n
                    .checked_mul(size)
                    .and_then(|bytes| cur.checked_add(bytes))
                    .is_some_and(|field_end| field_end <= data.len());
                if !fits {
                    break;
                }
                let mut vals: Vec<Vec<u8>> = Vec::with_capacity(n);
                for k in 0..n {
                    let off = cur + k * size;
                    let v = read_int(&data[off..off + size], size, end);
                    if unsigned {
                        let mask: u64 = if size >= 8 {
                            u64::MAX
                        } else {
                            (1u64 << (size * 8)) - 1
                        };
                        vals.push(((v as u64) & mask).to_string().into_bytes());
                    } else {
                        vals.push(v.to_string().into_bytes());
                    }
                }
                cur += n * size;
                emit(ScanValue::Bytes(scan_field_result(&count, vals)))?;
                emitted += 1;
            }
            b'f' | b'r' | b'R' | b'd' | b'q' | b'Q' => {
                let (size, end) = float_kind(ty);
                let n = match count {
                    Count::Star => data.len().saturating_sub(cur) / size,
                    Count::Num(n) => n,
                    Count::None => 1,
                };
                // As for the integer field above: a saturated `n` from the format
                // string makes `n * size` overflow usize and wrap past the bounds
                // check, so test "does the field fit" with checked arithmetic.
                let fits = n
                    .checked_mul(size)
                    .and_then(|bytes| cur.checked_add(bytes))
                    .is_some_and(|field_end| field_end <= data.len());
                if !fits {
                    break;
                }
                let vals: Vec<f64> = (0..n)
                    .map(|k| {
                        let off = cur + k * size;
                        read_float(&data[off..off + size], size, end)
                    })
                    .collect();
                cur += n * size;
                emit(if matches!(count, Count::None) {
                    ScanValue::Double(vals[0])
                } else {
                    ScanValue::Doubles(vals)
                })?;
                emitted += 1;
            }
            b'x' => {
                let n = match count {
                    Count::Num(n) => n,
                    Count::Star | Count::None => 1,
                };
                cur = (cur + n).min(data.len());
            }
            b'X' => {
                let n = match count {
                    Count::Star => cur,
                    Count::Num(n) => n,
                    Count::None => 1,
                };
                cur = cur.saturating_sub(n);
            }
            b'@' => {
                let n = match count {
                    Count::Star => data.len(),
                    Count::Num(n) => n,
                    Count::None => 0,
                };
                cur = n.min(data.len());
            }
            _ => {
                return Err(bad_field(&fmt[field_start..]));
            }
        }
    }
    Ok(emitted)
}

/// A scanned numeric field's stored value: the bare value for a countless field,
/// else the values as a Tcl list.
fn scan_field_result(count: &Count, vals: Vec<Vec<u8>>) -> Vec<u8> {
    if matches!(count, Count::None) {
        vals.into_iter().next().unwrap_or_default()
    } else {
        join_list(&vals)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn native_decoder_options_and_strict_final_groups() { /* FIXED_ASSERTION_TEST native_decoder_options_and_strict_final_groups */ }

    struct NumericValues;

    impl super::FormatValueOps for NumericValues {
        type Value = f64;

        fn binary_format_bytes(&mut self, _: &f64) -> Result<Vec<u8>, crate::CmdError> {
            panic!("numeric binary fields must not request a string representation")
        }

        fn binary_format_integer(&mut self, _: &f64) -> Result<i64, crate::CmdError> {
            panic!("floating fields must not request an integer representation")
        }

        fn binary_format_double(&mut self, value: &f64) -> Result<f64, crate::CmdError> {
            Ok(*value)
        }

        fn binary_format_elements(&mut self, value: &f64) -> Result<Vec<f64>, crate::CmdError> {
            Ok(vec![*value])
        }
    }

    #[test]
    fn packing_scalar_and_counted_doubles_never_formats_numeric_values() {
        let values = [1.0 / 3.0, -0.0];
        let packed = super::format_values(&mut NumericValues, b"dd*", &values).unwrap();
        let expected: Vec<_> = values
            .iter()
            .flat_map(|value| value.to_le_bytes())
            .collect();
        assert_eq!(packed, expected);
    }

    #[test]
    fn scan_retains_single_and_counted_floating_representations() {
        let values = [1.0 / 3.0, -0.0];
        let data: Vec<u8> = values
            .iter()
            .flat_map(|value: &f64| value.to_ne_bytes())
            .collect();
        assert_eq!(
            super::scan_values(&data, b"dd").unwrap(),
            vec![
                super::ScanValue::Double(values[0]),
                super::ScanValue::Double(values[1])
            ]
        );
        assert_eq!(
            super::scan_values(&data, b"d*").unwrap(),
            vec![super::ScanValue::Doubles(values.to_vec())]
        );
    }

    // Measured on tclsh 8.4.20 and 8.5.19: these seven are `bad field
    // specifier` on 8.4 and accepted from 8.5, for both `binary format` and
    // `binary scan`. Every other field letter exists on both.
    #[test]
    fn specifier_min_version_matches_measured_releases() {
        for letter in b"tnmrRqQ" {
            assert_eq!(
                specifier_min_version(*letter),
                Some(tcl_dialect::TclVersion::V8_5),
                "{} should be 8.5+",
                char::from(*letter)
            );
        }
        for letter in b"aAbBhHcsSiIwWfdxX@" {
            assert_eq!(
                specifier_min_version(*letter),
                None,
                "{} exists on every release",
                char::from(*letter)
            );
        }
        // Every gated letter is a real field letter in the shared grammar.
        for letter in b"tnmrRqQ" {
            assert!(is_specifier(*letter), "{}", char::from(*letter));
        }
    }

    #[test]
    fn shared_specifier_table_covers_q_and_q_and_release_gate() {
        let modern = specifiers(
            b"q Q su",
            signedness_available(
                tcl_dialect::DialectProfile::find("tcl8.6").expect("catalogue profile"),
            ),
        );
        assert_eq!(
            modern.iter().map(|s| s.letter).collect::<Vec<_>>(),
            vec![b'q', b'Q', b's']
        );
        assert_eq!(modern[2].modifier, Some(b'u'));

        let old = specifiers(
            b"su",
            signedness_available(
                tcl_dialect::DialectProfile::find("tcl8.4").expect("catalogue profile"),
            ),
        );
        assert_eq!(old[0].modifier, None);
    }

    // TIP 275 added only `u`. `s` is the short-integer field letter, so `ss`
    // is two 2-byte fields on every release — verified against tclsh 8.4.20,
    // 8.5.19, 8.6.18 and 9.0.4, all of which pack four bytes and scan back
    // two values.
    #[test]
    fn short_specifier_is_a_field_not_a_modifier() {
        let fields = specifiers(b"ss", true);
        assert_eq!(
            fields.iter().map(|f| f.letter).collect::<Vec<_>>(),
            vec![b's', b's']
        );
        assert!(fields.iter().all(|f| f.modifier.is_none()));
        assert_eq!(fields[1].end, 2);
        // Two 2-byte fields — the runtime packer agrees with the grammar view.
        let packed = format(b"ss", &[b"1".as_slice(), b"2".as_slice()]).expect("ss packs");
        assert_eq!(packed.len(), 4);
    }

    // `GetFormatSpec` in tclBinary.c consumes a `u` after the command
    // character without consulting the type, so `au` is one field on 8.5+ —
    // and `binary format au 1` is a `bad field specifier "u"` error on 8.4.
    #[test]
    fn unsigned_suffix_follows_any_field_letter() {
        let fields = specifiers(b"au", true);
        assert_eq!(fields.len(), 1);
        assert_eq!(fields[0].letter, b'a');
        assert_eq!(fields[0].modifier, Some(b'u'));
        assert_eq!(fields[0].end, 2);
        // Gated off, the `u` is ordinary text and the field ends at the letter.
        let old = specifiers(b"au", false);
        assert_eq!(old.len(), 1);
        assert_eq!(old[0].modifier, None);
        assert_eq!(old[0].end, 1);
    }

    #[test]
    fn scan_a_field_with_huge_count_does_not_panic() {
        // An out-of-range count saturates to usize::MAX; the
        // `a`/`A` bounds check must not overflow `cur + n` (debug panic / release
        // wrap → OOB slice). `@1` advances cur to 1 first to exercise the add.
        let r = scan(b"xy", b"@1 a99999999999999999999999").expect("scan returns, no panic");
        // Not enough bytes for the huge field → the variable is unset (no
        // element scanned).
        assert!(r.is_empty(), "huge field should scan nothing: {r:?}");
        // A normal `a` field still works.
        assert_eq!(scan(b"xy", b"a2").unwrap(), vec![b"xy".to_vec()]);
    }

    #[test]
    fn format_a_field_with_huge_count_errors_not_panics() {
        // A huge field width must be a catchable CmdError, not a
        // process-aborting "capacity overflow".
        let err = format(b"a99999999999999999999999", &[b"x"]).unwrap_err();
        assert!(err.to_string().contains("too large"), "{err}");
        // The `x` (null pad) path is guarded too.
        assert!(format(b"x99999999999999999999999", &[]).is_err());
        // A normal field still formats.
        assert_eq!(format(b"a3", &[b"hi"]).unwrap(), b"hi\0");
    }

    /// The size bound covers every packed output and saturates on a count
    /// no allocation could hold.
    #[test]
    fn format_size_bound_covers_the_packed_output() {
        let cases: &[(&[u8], &[&[u8]])] = &[
            (b"H*", &[b"414243444546"]),
            (b"a3 c", &[b"foo", b"65"]),
            (b"A5", &[b"ab"]),
            (b"b*", &[b"10100000101"]),
            (b"h3", &[b"abc"]),
            (b"s*", &[b"1 2 3"]),
            (b"c2 d*", &[b"1 2 3", b"1.5 2"]),
            (b"x3 X c @10 c", &[b"1", b"2"]),
            (b"c @* c", &[b"1", b"2"]),
            (b"w", &[b"-1"]),
            (b"", &[]),
        ];
        for (fmt, args) in cases {
            let packed = format(fmt, args).expect("a valid format");
            let bound = format_size_bound(fmt, args);
            assert!(
                u64::try_from(packed.len()).unwrap() <= bound,
                "{}: {} packed past the bound {bound}",
                String::from_utf8_lossy(fmt),
                packed.len()
            );
        }
        assert_eq!(
            format_size_bound(b"x99999999999999999999999", &[]),
            u64::MAX
        );
        assert_eq!(format_size_bound(b"a2 a*", &[b"xyz", b"hello"]), 7);
    }

    #[test]
    fn hex_round_trips() { /* FIXED_ASSERTION_TEST hex_round_trips */ }

    #[test]
    fn base64_round_trips() { /* FIXED_ASSERTION_TEST base64_round_trips */ }

    #[test]
    fn base64_wraps_at_maxlen() { /* FIXED_ASSERTION_TEST base64_wraps_at_maxlen */ }

    #[test]
    fn uu_round_trips() {
        let enc = uu_encode(b"Cat", 0, b"\n");
        // length byte (3 → 0x23 '#') then one 4-char group, then wrap
        assert_eq!(&enc[..1], b"#");
        assert_eq!(uu_decode(&enc), b"Cat");
    }

    #[test]
    fn format_scan_round_trip() {
        // `a3 c`: pack "foo" + a one-byte int 65 → "fooA"; scan reverses it.
        let packed = format(b"a3 c", &[b"foo", b"65"]).unwrap();
        assert_eq!(packed, b"fooA");
        assert_eq!(
            scan(b"fooA", b"a3 c").unwrap(),
            vec![b"foo".to_vec(), b"65".to_vec()]
        );
        // hex field round-trips.
        assert_eq!(format(b"H2", &[b"4d"]).unwrap(), vec![0x4d]);
        assert_eq!(scan(&[0x4d], b"H2").unwrap(), vec![b"4d".to_vec()]);
        // big-endian 16-bit (258 = 0x0102) and a `*` list count.
        assert_eq!(format(b"S", &[b"258"]).unwrap(), vec![0x01, 0x02]);
        assert_eq!(format(b"s*", &[b"1 2 3"]).unwrap(), vec![1, 0, 2, 0, 3, 0]);
        // errors: too few arguments, and a bad field specifier.
        assert!(format(b"c", &[]).is_err());
        assert!(format(b"Z", &[]).is_err());
        // scan stops when data runs out (returns the values it managed).
        assert_eq!(scan(b"ab", b"c c c").unwrap().len(), 2);
    }

    #[test]
    fn scan_huge_field_count_does_not_overflow() {
        // A field count from the format string is saturated to `usize::MAX`
        // by `parse_count`, so `n * size` must not overflow usize and wrap
        // *under* the bounds check (which would sneak past it, then try to
        // allocate `usize::MAX`). It must instead stop scanning, exactly
        // like the normal out-of-data path.
        // Both an integer field (`w`, size 8) and a float field (`d`, size 8):
        let huge = b"w99999999999999999999"; // count saturates to usize::MAX
        assert_eq!(scan(b"only-eight-bytes", huge).unwrap(), [] as [Vec<u8>; 0]);
        let huge_f = b"d99999999999999999999";
        assert_eq!(
            scan(b"only-eight-bytes", huge_f).unwrap(),
            [] as [Vec<u8>; 0]
        );
        // A field that *does* fit still scans (regression guard).
        assert_eq!(scan(&[0x01, 0x02], b"s1").unwrap(), vec![b"513".to_vec()]);
    }
}

#[cfg(test)]
mod original_field_emission_tests {
    use super::*;
    #[test]
    fn original_scan_field_is_emitted_before_later_grammar_error() {
        // naming.binary.original-object-format-grammar-extent
        // docs/design/analysis/name-resolution-proofs/binary-original-object-format-grammar-extent.md
        let mut assigned = Vec::new();
        let result = scan_values_using(
            b"AB",
            b"a1?",
            &mut |value| {
                assigned.push(value);
                Ok(())
            },
            &mut |_| CmdError::new("bad field specifier \"?\""),
        );
        assert_eq!(assigned, [ScanValue::Bytes(b"A".to_vec())]);
        assert_eq!(
            result.unwrap_err().message_bytes(),
            b"bad field specifier \"?\""
        );
        assert_eq!(
            scan_values(b"AB", b"a1?").unwrap_err().message_bytes(),
            b"bad field specifier \"?\""
        );
    }
    #[test]
    fn original_scan_refused_emission_stops_before_next_field() {
        // naming.binary.original-object-format-grammar-extent
        // docs/design/analysis/name-resolution-proofs/binary-original-object-format-grammar-extent.md
        let mut emissions = 0;
        let mut bad_fields = 0;
        let result = scan_values_using(
            b"AB",
            b"a1?",
            &mut |_| {
                emissions += 1;
                Err("original assignment refusal")
            },
            &mut |_| {
                bad_fields += 1;
                "later grammar refusal"
            },
        );
        assert_eq!(result, Err("original assignment refusal"));
        assert_eq!(emissions, 1);
        assert_eq!(bad_fields, 0);
    }
}
