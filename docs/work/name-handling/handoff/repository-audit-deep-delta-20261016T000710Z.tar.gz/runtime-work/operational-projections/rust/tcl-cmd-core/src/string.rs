// tcl-lsp — a language server and toolchain for Tcl
// Copyright (C) 2026 James Deucker (bitwisecook) <https://github.com/bitwisecook>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.
//
// SPDX-License-Identifier: AGPL-3.0-or-later

//! Portable `string` command logic, generic over [`ValueOps`].
//!
//! Each helper takes already-sliced argument values and returns
//! `Result<O::Value, CmdError>`. Physical indexed consumers select original C
//! storage/units or Jim UTF traversal through [`NativeIndexOps`]. Neutral
//! adapters use their independently authored lexical character model.
//!
//! [`dispatch`] covers the portable subcommands shared across both
//! runtimes (`length`/`index`/`range`/`map`/`match`/`replace`/`insert`/
//! `first`/`last`/`trim*`/`wordstart`/`wordend`/`to{upper,lower,title}`/
//! `reverse`/`repeat`/`cat`). It returns `None` for any subcommand a given
//! runtime still implements itself, so a host can fall back to its own
//! body for the few not routed here.

mod native_c;
pub use native_c::NativeCStringStorage;
mod native_compiled;
pub use native_compiled::{
    compiled_find, compiled_index, compiled_qualifiers, compiled_range, compiled_tail,
};
mod native_trim;
pub use native_trim::compiled_trim;

use crate::index::NativeIndexOps;
use tcl_syntax::raw_string::RawString;
use tcl_syntax::value::ValueOps;

use crate::error::CmdError;
use crate::index;

/// `string length str` — the character count.
pub fn length<O: ValueOps>(ops: &mut O, s: &O::Value) -> Result<O::Value, CmdError> {
    let n = ops.native_char_len(s)?;
    Ok(ops.new_int(i64::try_from(n).unwrap_or(i64::MAX)))
}

/// `string bytelength str` counts the original Tcl string representation.
pub fn bytelength<O: ValueOps>(ops: &mut O, s: &O::Value) -> Result<O::Value, CmdError> {
    let length = ops.native_string_bytes(s)?.len();
    Ok(ops.new_int(i64::try_from(length).unwrap_or(i64::MAX)))
}

/// `string index str charIndex` — the one-character string at `idx`, or empty
/// when out of range.
pub fn index<O: NativeIndexOps>(
    ops: &mut O,
    s: &O::Value,
    idx: &O::Value,
) -> Result<O::Value, CmdError> {
    index::run_created_index_result(ops, |ops| {
        if ops.string_character_model() == Some(tcl_dialect::StringCharacterModel::Jim084Utf8) {
            let prepared = index::prepare_jim_indices(ops, &[idx])?;
            let raw = RawString::from_bytes(ops.index_operand_bytes(s)?);
            let len = ops.index_character_count(s)?;
            let i = match prepared {
                Some(indices) => index::resolve_jim_encoding(indices[0], len),
                None => index::resolve_value(ops, idx, len)?,
            };
            return Ok(match usize::try_from(i) {
                Ok(i) => ops.new_bytes(&raw.jim084_character_bytes(i, len)?),
                Err(_) => ops.empty(),
            });
        }
        if let Some(version) = ops.index_c_version() {
            return native_c::original_index(ops, s, idx, version);
        }
        let chars: Vec<char> = ops.index_unicode(s)?.chars().collect();
        let i = index::resolve_value(ops, idx, chars.len())?;
        if i < 0 {
            return Ok(ops.empty());
        }
        match usize::try_from(i).ok().and_then(|i| chars.get(i)) {
            Some(c) => Ok(ops.new_string(c.to_string())),
            None => Ok(ops.empty()),
        }
    })
}

/// The completed Jim range recipe, borrowed before result-role transfer.
pub struct NativeJimStringRangeConstruction<'a, V> {
    original: &'a V,
    first: &'a V,
    last: &'a V,
    result: &'a index::IndexResult<V>,
}

impl<V> NativeJimStringRangeConstruction<'_, V> {
    /// The actual selected source and index operands.
    pub fn operands(&self) -> [&V; 3] {
        [self.original, self.first, self.last]
    }

    /// The actual selected borrowed or created output.
    pub fn result(&self) -> &V {
        match self.result {
            index::IndexResult::Borrowed(value)
            | index::IndexResult::Created(value)
            | index::IndexResult::Detached(value)
            | index::IndexResult::ReturnedOwnedTransport(value) => value,
        }
    }
}

/// `string range str first last` — the inclusive character slice, clamped.
pub fn range<O: NativeIndexOps>(
    ops: &mut O,
    s: &O::Value,
    first: &O::Value,
    last: &O::Value,
) -> Result<O::Value, CmdError> {
    index::run_index_result_using(ops, |ops, operation| {
        if ops.string_character_model() == Some(tcl_dialect::StringCharacterModel::Jim084Utf8) {
            let raw = RawString::from_bytes(ops.index_operand_bytes(s)?);
            let len = ops.index_character_count(s)?;
            let low = index::resolve_value(ops, first, len)?.max(0);
            let high = index::resolve_value(ops, last, len)?;
            let result = match (usize::try_from(low), usize::try_from(high)) {
                (Ok(0), Ok(last)) if last.saturating_add(1) >= len => {
                    index::IndexResult::Borrowed(s.clone())
                }
                (Ok(first), Ok(last)) => {
                    let (bytes, count) = raw.jim084_range_bytes(first, last, len)?;
                    index::IndexResult::Created(if len == raw.bytes().len() {
                        ops.new_bytes(&bytes)
                    } else {
                        ops.new_jim_string(&bytes, count)
                    })
                }
                _ => index::IndexResult::Created(ops.empty()),
            };
            let recorded = ops.check_index_operation(operation).and_then(|()| {
                ops.completed_jim_string_range(
                    operation,
                    &NativeJimStringRangeConstruction {
                        original: s,
                        first,
                        last,
                        result: &result,
                    },
                )
            });
            if let Err(first) = recorded {
                ops.retain_index_failure(&first);
                match result {
                    index::IndexResult::Created(created)
                    | index::IndexResult::Detached(created)
                    | index::IndexResult::ReturnedOwnedTransport(created) => {
                        ops.discard_owned_index_result(created);
                    }
                    index::IndexResult::Borrowed(borrowed) => drop(borrowed),
                }
                return Err(first);
            }
            return Ok(result);
        }
        if let Some(version) = ops.index_c_version() {
            return native_c::original_range(ops, s, first, last, version)
                .map(index::IndexResult::Created);
        }
        let chars: Vec<char> = ops.index_unicode(s)?.chars().collect();
        let len = chars.len();
        let lo = index::resolve_value(ops, first, len)?.max(0);
        let hi = index::resolve_value(ops, last, len)?;
        let Ok(lo) = usize::try_from(lo) else {
            return Ok(index::IndexResult::Created(ops.empty()));
        };
        if hi < 0 || lo >= len || lo > usize::try_from(hi).unwrap_or(usize::MAX) {
            return Ok(index::IndexResult::Created(ops.empty()));
        }
        let hi = usize::try_from(hi).unwrap_or(usize::MAX).min(len - 1);
        let out: String = chars[lo..=hi].iter().collect();
        Ok(index::IndexResult::Created(ops.new_string(out)))
    })
}

/// `string reverse str`.
pub fn reverse<O: ValueOps>(ops: &mut O, s: &O::Value) -> Result<O::Value, CmdError> {
    if ops.string_character_model() == Some(tcl_dialect::StringCharacterModel::Jim084Utf8) {
        let raw = RawString::from_bytes(ops.as_bytes(s)).jim084_reversed();
        return Ok(ops.new_bytes(&raw.bytes()));
    }
    let out: String = ops.try_as_str(s)?.chars().rev().collect();
    Ok(ops.new_string(out))
}

/// `string repeat str count` — `count` (clamped at 0) copies, with the result
/// size put to the allocator before anything is written.
///
/// The bound reproduces `TclStringRepeat`'s order of business (tclsh 9.0.4
/// `generic/tclStringObj.c`), which matters because the three checks disagree
/// about the same input:
///
/// 1. a zero-length string is *any* count's own answer — `string repeat {}
///    9223372036854775807` is the empty string, not an error, because C returns
///    before it ever looks at `count`;
/// 2. `count > TCL_SIZE_MAX - 1` is `max size for a Tcl value (…) exceeded`;
/// 3. anything else that will not fit is `string size overflow: unable to alloc
///    N bytes`, where `N` is `count * length` computed in `Tcl_Size` and
///    therefore **wrapping** — tclsh 9.0.4 really does report `string repeat ab
///    5000000000000000000` as `unable to alloc -8446744073709551616 bytes`, so
///    the byte count here wraps too rather than reporting the true product.
///
/// `length` is the **byte** length of the string rep, matching C's non-unichar
/// branch: tclsh 9.0.4 reports `string repeat \u00e9 100000000000` as
/// `200000000000 bytes`, two per character, not one.
pub fn repeat<O: ValueOps>(
    ops: &mut O,
    s: &O::Value,
    count: &O::Value,
) -> Result<O::Value, CmdError> {
    let count = prepare_repeat_count(ops, count)?;
    repeat_with_count(ops, s, count)
}

/// Convert a repeat count using the selected native operand grammar.
///
/// Hosts with allocation limits can retain this result, charge the actual
/// source byte length times its nonnegative count, then call
/// [`repeat_with_count`] without evaluating or coercing the operand again.
pub fn prepare_repeat_count<O: ValueOps>(ops: &mut O, count: &O::Value) -> Result<i64, CmdError> {
    // Jim_GetWideExpr is shared with increment's amount conversion. Its safe
    // expression phase cannot dispatch public commands or read variables.
    let n = if ops.string_character_model() == Some(tcl_dialect::StringCharacterModel::Jim084Utf8) {
        use tcl_syntax::value::{IntegerOperandError, IntegerOperandGrammar};
        let value = match IntegerOperandGrammar::SafeIntegerExpression.prepare(ops, count) {
            Ok(value) => value,
            Err(IntegerOperandError::Integer(error)) => return Err(error.into()),
            Err(error @ IntegerOperandError::SafeExpression) => {
                return Err(CmdError::new_bytes(
                    error
                        .safe_expression_message_bytes(&ops.as_bytes(count))
                        .expect("safe expression failure has its authored byte message"),
                ));
            }
        };
        ops.pin_value(&value);
        let integer = ops.as_int(&value);
        ops.unpin_value(&value);
        integer?
    } else {
        ops.as_int(count)?
    };
    Ok(n)
}

/// Build a repeated string from a count already converted by
/// [`prepare_repeat_count`]. Source bytes are copied without Unicode projection.
pub fn repeat_with_count<O: ValueOps>(
    ops: &mut O,
    s: &O::Value,
    n: i64,
) -> Result<O::Value, CmdError> {
    if n <= 0 {
        return Ok(ops.empty());
    }
    let src = ops.as_bytes(s);
    let len = i64::try_from(src.len()).unwrap_or(i64::MAX);
    if len == 0 {
        return Ok(ops.empty());
    }
    if n > i64::MAX - 1 {
        return Err(CmdError::new(format!(
            "max size for a Tcl value ({} bytes) exceeded",
            i64::MAX
        )));
    }
    let total = n.wrapping_mul(len);
    let overflow = || {
        CmdError::new(format!(
            "string size overflow: unable to alloc {total} bytes"
        ))
    };
    // C has no fixed ceiling here: `TclStringRepeat` *attempts* the allocation
    // and reports `string size overflow` only when the allocator refuses, so
    // its real limit is the host's memory — tclsh 9.0.4 builds `string repeat
    // ab 2000000000` (4 GB) on a large enough box. Ask the allocator the same
    // question rather than picking a cap of our own, which would turn away a
    // script C serves; `try_reserve_exact` turns the refusal into an error the
    // two embedding runtimes can report instead of an abort they cannot
    // recover from (the unbounded `str::repeat` this replaces aborted the
    // process with `memory allocation of 200000000000 bytes failed`).
    let capacity = usize::try_from(total).map_err(|_| overflow())?;
    let mut out = Vec::new();
    out.try_reserve_exact(capacity).map_err(|_| overflow())?;
    let n = usize::try_from(n).unwrap_or(0);
    for _ in 0..n {
        out.extend_from_slice(&src);
    }
    Ok(ops.new_bytes(&out))
}

/// The result form of [`compare`].
#[derive(Clone, Copy)]
pub enum CompareMode {
    /// `string equal` returns a Tcl boolean.
    Equal,
    /// `string compare` returns `-1`, `0`, or `1`.
    Compare,
}

/// `string equal`/`string compare` with `?-nocase? ?-length int?`.
///
/// Option order and prefix acceptance match Tcl's `StringCmpOpts`; integer
/// conversion is delegated to [`ValueOps::string_compare_length`] so each
/// target preserves its value-tower-specific diagnostic.
pub fn compare<O: ValueOps>(
    ops: &mut O,
    args: &[O::Value],
    mode: CompareMode,
) -> Result<O::Value, CmdError> {
    let name = match mode {
        CompareMode::Equal => "equal",
        CompareMode::Compare => "compare",
    };
    let usage = format!("string {name} ?-nocase? ?-length int? string1 string2");
    if ops.string_character_model() == Some(tcl_dialect::StringCharacterModel::Jim084Utf8) {
        return jim_compare(ops, args, mode, &usage);
    }
    if !(2..=5).contains(&args.len()) {
        return Err(CmdError::wrong_args(&usage));
    }

    // A deliberate non-`OptionTable` site: C's `StringCmpOpts`
    // hand-rolls `strncmp(…, length > 1)` instead of calling
    // `Tcl_GetIndexFromObj`, so `""` and a lone `-` are `bad`, never
    // `ambiguous`, and a one-character word never abbreviates. Routing this
    // through the shared matcher would change all three verdicts.
    //
    // tclsh 8.6.16 / 9.0.4:
    //   string compare "" a b  -> bad option "": must be -nocase or -length
    //   string compare -  a b  -> bad option "-": must be -nocase or -length
    //   string compare -n a A  -> 0
    let mut nocase = false;
    let mut length = None;
    let mut i = 0;
    let option_end = args.len() - 2;
    while i < option_end {
        let option = ops.try_as_str(&args[i])?;
        if option.len() > 1 && "-nocase".starts_with(&*option) {
            nocase = true;
            i += 1;
        } else if option.len() > 1 && "-length".starts_with(&*option) {
            if i + 1 >= option_end {
                return Err(CmdError::wrong_args(&usage));
            }
            length = ops.string_compare_length(&args[i + 1])?;
            i += 2;
        } else {
            return Err(CmdError::new(format!(
                "bad option \"{option}\": must be -nocase or -length"
            )));
        }
    }

    let key = |ops: &mut O, value: &O::Value| -> Result<Vec<char>, CmdError> {
        let mut chars: Vec<char> = ops.try_as_str(value)?.chars().collect();
        if nocase {
            chars = chars.iter().flat_map(|c| c.to_lowercase()).collect();
        }
        if let Some(n) = length {
            chars.truncate(n);
        }
        Ok(chars)
    };
    let ordering = key(ops, &args[i])?.cmp(&key(ops, &args[i + 1])?);
    Ok(match mode {
        CompareMode::Equal => ops.new_bool(ordering.is_eq()),
        CompareMode::Compare => ops.new_int(match ordering {
            core::cmp::Ordering::Less => -1,
            core::cmp::Ordering::Equal => 0,
            core::cmp::Ordering::Greater => 1,
        }),
    })
}

fn jim_compare<O: ValueOps>(
    ops: &mut O,
    args: &[O::Value],
    mode: CompareMode,
    usage: &str,
) -> Result<O::Value, CmdError> {
    if args.len() < 2 {
        return Err(CmdError::wrong_args(usage));
    }
    let option_end = args.len() - 2;
    let mut i = 0;
    let mut nocase = false;
    let mut length = None;
    while i < option_end {
        let option = ops.as_bytes(&args[i]);
        if option.len() > 1 && b"-nocase".starts_with(&option) {
            nocase = true;
            i += 1;
        } else if option.len() > 1 && b"-length".starts_with(&option) && i + 1 < option_end {
            length = usize::try_from(ops.as_int(&args[i + 1])?).ok();
            i += 2;
        } else {
            return Err(CmdError::wrong_args(usage));
        }
    }
    let left = ops.as_bytes(&args[i]);
    let right = ops.as_bytes(&args[i + 1]);
    if matches!(mode, CompareMode::Equal) && !nocase && length.is_none() {
        return Ok(ops.new_bool(left == right));
    }
    let mut left_count = ops.native_char_len(&args[i])?;
    let mut right_count = ops.native_char_len(&args[i + 1])?;
    if let Some(limit) = length {
        left_count = left_count.min(limit);
        right_count = right_count.min(limit);
    }
    let ordering = RawString::from_bytes(left).jim084_compare(
        left_count,
        &RawString::from_bytes(right),
        right_count,
        nocase,
    )?;
    Ok(match mode {
        CompareMode::Equal => ops.new_bool(ordering.is_eq()),
        CompareMode::Compare => ops.new_int(match ordering {
            core::cmp::Ordering::Less => -1,
            core::cmp::Ordering::Equal => 0,
            core::cmp::Ordering::Greater => 1,
        }),
    })
}

/// Which case conversion [`case_convert`] performs.
#[derive(Clone, Copy)]
pub enum CaseMode {
    /// `string toupper`.
    Upper,
    /// `string tolower`.
    Lower,
    /// `string totitle` — first char of the range uppercased, rest lowercased.
    Title,
}

/// `string toupper`/`tolower`/`totitle string ?first? ?last?` — convert the case
/// of the characters in `[first, last]` (default the whole string; with only
/// `first`, that single character), leaving the rest unchanged.
pub fn case_convert<O: NativeIndexOps>(
    ops: &mut O,
    args: &[O::Value],
    mode: CaseMode,
    usage: &str,
) -> Result<O::Value, CmdError> {
    index::run_created_index_result(ops, |ops| {
        if ops.string_character_model() == Some(tcl_dialect::StringCharacterModel::Jim084Utf8) {
            use tcl_syntax::raw_string::JimCaseMapping;
            let (mapping, usage) = match mode {
                CaseMode::Upper => (JimCaseMapping::Upper, "string toupper string"),
                CaseMode::Lower => (JimCaseMapping::Lower, "string tolower string"),
                CaseMode::Title => (JimCaseMapping::Title, "string totitle string"),
            };
            let [value] = args else {
                return Err(CmdError::wrong_args(usage));
            };
            let mapped =
                RawString::from_bytes(ops.index_operand_bytes(value)?).jim084_case_mapped(mapping);
            return Ok(ops.new_bytes(&mapped.bytes()));
        }
        let (s, first_spec, last_spec) = match args {
            [s] => (s, None, None),
            [s, f] => (s, Some(f), None),
            [s, f, l] => (s, Some(f), Some(l)),
            _ => return Err(CmdError::wrong_args(usage)),
        };
        let chars: Vec<char> = ops.index_unicode(s)?.chars().collect();
        let len = chars.len();
        if len == 0 {
            return Ok(ops.empty());
        }
        let first = match first_spec {
            None => 0,
            Some(f) => index::resolve_value(ops, f, len)?.max(0),
        };
        let last = match last_spec {
            Some(l) => index::resolve_value(ops, l, len)?,
            None if first_spec.is_some() => first,
            None => i64::try_from(len).unwrap_or(i64::MAX) - 1,
        };
        let mut out = String::new();
        for (idx, &c) in chars.iter().enumerate() {
            let i = i64::try_from(idx).unwrap_or(i64::MAX);
            if i < first || i > last {
                out.push(c);
                continue;
            }
            // Per-character *simple* mapping throughout ([`simple_upper`] &co), the
            // way C's `Tcl_UtfTo{Upper,Lower,Title}` do it: `string toupper ß` is
            // `ß`, not `SS`. `string totitle`'s first character uses the Unicode
            // *titlecase* mapping (`Tcl_UniCharToTitle`), which differs from
            // uppercase only for the Latin DŽ/LJ/NJ/DZ digraphs (string-17.7), and
            // its remaining characters go through `Tcl_UtfToTitle`'s
            // lowercase-with-Georgian-exception rule.
            out.push(match mode {
                CaseMode::Upper => simple_upper(c),
                CaseMode::Lower => simple_lower(c),
                CaseMode::Title if i == first => simple_title(c),
                CaseMode::Title => simple_title_rest(c),
            });
        }
        Ok(ops.new_string(out))
    })
}

/// C's `Tcl_UtfTo{Upper,Lower,Title}` length guard: the mapped character
/// replaces the original only when its UTF-8 encoding is no longer than the
/// original's — "only copy the upper case char to dst if its size is <= the
/// original char" (`tclUtf.c:1334-1346`, and the same test in the lower/title
/// loops). It keeps e.g. `ɐ` (U+0250, 2 bytes) unchanged rather than mapping it
/// to `Ɐ` (U+2C6F, 3 bytes).
fn fit(orig: char, mapped: char) -> char {
    if orig.len_utf8() < mapped.len_utf8() {
        orig
    } else {
        mapped
    }
}

/// The Unicode **simple** (1:1) case mapping of `c`, given its *full* mapping
/// iterator.
///
/// C's case conversions are strictly per-code-point — `Tcl_UtfToUpper` calls
/// `Tcl_UniCharToUpper` (`tclUtf.c:1777-1789`), a delta-encoded table with one
/// code point in and one out — whereas Rust's [`char::to_uppercase`] /
/// [`char::to_lowercase`] implement *full* mapping and can expand (`ß` → `SS`,
/// `İ` → `i` + U+0307).
///
/// An expanding mapping usually means the character has **no** simple mapping
/// (Unicode leaves `UnicodeData.txt`'s mapping field empty and puts the
/// multi-character form in `SpecialCasing.txt`), so it is left alone: `ß`,
/// `ﬁ`, `ŉ` and friends are identity under `Tcl_UniCharToUpper`. The one
/// exception is handled by [`simple_lower_exception`] — inferring identity from
/// expansion alone is wrong for it.
fn simple(c: char, mut full: impl Iterator<Item = char>) -> char {
    match (full.next(), full.next()) {
        (Some(m), None) => fit(c, m),
        _ => c,
    }
}

/// The lone character whose *full* lowercase mapping expands even though it has
/// a real 1:1 simple mapping: `İ` (U+0130) lowercases to `i` (U+0069) under
/// `Tcl_UniCharToLower`, while Rust's full mapping yields `i` + U+0307
/// (combining dot above).
///
/// U+0130 is the **only** such code point — it is the only one in Unicode whose
/// full lowercase expands at all (every other expanding lowercase in
/// `SpecialCasing.txt` is conditional on locale or final-sigma context, which C
/// does not implement either), so this exception is complete rather than a
/// sample. The expanding *uppercase* and *titlecase* mappings all do have empty
/// simple-mapping fields, so [`simple`]'s identity inference is correct there.
const fn simple_lower_exception(c: char) -> Option<char> {
    if c == '\u{0130}' { Some('i') } else { None }
}

/// `Tcl_UniCharToUpper` — the simple uppercase mapping of one character.
#[must_use]
pub fn simple_upper(c: char) -> char {
    simple(c, c.to_uppercase())
}

/// `Tcl_UniCharToLower` — the simple lowercase mapping of one character.
#[must_use]
pub fn simple_lower(c: char) -> char {
    if let Some(m) = simple_lower_exception(c) {
        return fit(c, m);
    }
    simple(c, c.to_lowercase())
}

/// The character at byte offset `i` of `bytes`, with its encoded length — one
/// `TclUtfToUCS4` step.
///
/// A byte that does not begin a well-formed UTF-8 sequence yields that byte's
/// own value as the character and advances one, as C does, so a key that is not
/// valid UTF-8 still walks (byte by byte) instead of derailing the caller.
pub(crate) fn utf8_char_at(bytes: &[u8], i: usize) -> Option<(char, usize)> {
    let b0 = *bytes.get(i)?;
    let len = match b0 {
        0xC0..=0xDF => 2,
        0xE0..=0xEF => 3,
        0xF0..=0xF7 => 4,
        // ASCII, a stray continuation byte, or an invalid lead byte: one byte,
        // valued as itself.
        _ => return Some((char::from(b0), 1)),
    };
    match bytes.get(i..i + len).map(core::str::from_utf8) {
        Some(Ok(s)) => s.chars().next().map(|c| (c, len)),
        _ => Some((char::from(b0), 1)),
    }
}

/// The `-nocase` fold of a whole UTF-8 string — `Tcl_UtfToLower`, i.e. every
/// character through [`simple_lower`], re-encoded.
///
/// This is the byte-shaped face of the crate's *one* case fold, for the
/// comparison cores that carry their keys as bytes ([`crate::sort`],
/// [`crate::lsearch`], [`crate::switch`]) rather than as `char`s. It is the
/// fold, not a second one: the per-character mapping is `simple_lower` and
/// nothing else, over the same [`utf8_char_at`] walk
/// [`crate::sort::dictionary_compare`] uses.
///
/// Folding then comparing the *encodings* is the same verdict as C's
/// `TclUtfCasecmp`, which walks characters and compares
/// `Tcl_UniCharToLower(c1) - Tcl_UniCharToLower(c2)`: UTF-8 is order-preserving,
/// so byte-lexicographic order over folded UTF-8 is code-point order over folded
/// characters.
#[must_use]
pub fn fold_lower_bytes(bytes: &[u8]) -> Vec<u8> {
    let mut out = Vec::with_capacity(bytes.len());
    let mut buf = [0u8; 4];
    let mut i = 0;
    while let Some((c, len)) = utf8_char_at(bytes, i) {
        out.extend_from_slice(simple_lower(c).encode_utf8(&mut buf).as_bytes());
        i += len;
    }
    out
}

/// `Tcl_UniCharToTitle` — the simple titlecase mapping of one character, which
/// equals the uppercase mapping except for the digraphs [`titlecase_digraph`]
/// knows about.
#[must_use]
pub fn simple_title(c: char) -> char {
    titlecase_digraph(c).map_or_else(|| simple_upper(c), |t| fit(c, t))
}

/// `Tcl_UtfToTitle`'s mapping for the characters *after* the first: lowercase,
/// except the Georgian Mtavruli block (U+1C90..U+1CBF), which C deliberately
/// leaves alone — "Special exception for Georgian Asomtavruli chars, no
/// titlecase" (`tclUtf.c:1452-1456`).
#[must_use]
pub fn simple_title_rest(c: char) -> char {
    if ('\u{1C90}'..='\u{1CBF}').contains(&c) {
        c
    } else {
        simple_lower(c)
    }
}

/// The Unicode titlecase mapping for the characters whose `Titlecase_Mapping`
/// differs from their `Uppercase_Mapping` — the Latin DŽ/LJ/NJ/DZ digraphs (all
/// three case forms of each map to the single title form). Every other character
/// titlecases to its uppercase mapping, so those return `None` (the caller falls
/// back to [`simple_upper`]).
fn titlecase_digraph(c: char) -> Option<char> {
    Some(match c {
        '\u{01C4}' | '\u{01C5}' | '\u{01C6}' => '\u{01C5}', // DŽ / Dž / dž → Dž
        '\u{01C7}' | '\u{01C8}' | '\u{01C9}' => '\u{01C8}', // LJ / Lj / lj → Lj
        '\u{01CA}' | '\u{01CB}' | '\u{01CC}' => '\u{01CB}', // NJ / Nj / nj → Nj
        '\u{01F1}' | '\u{01F2}' | '\u{01F3}' => '\u{01F2}', // DZ / Dz / dz → Dz
        _ => return None,
    })
}

/// `string replace string first last ?newstring?` — remove the characters in
/// `[first, last]` (inclusive), optionally inserting `newstring`. An empty or
/// inverted range leaves the string unchanged.
pub fn replace<O: NativeIndexOps>(ops: &mut O, args: &[O::Value]) -> Result<O::Value, CmdError> {
    index::run_index_result(ops, |ops| {
        if args.len() < 3 || args.len() > 4 {
            return Err(CmdError::wrong_args(
                "string replace string first last ?string?",
            ));
        }
        if ops.string_character_model() == Some(tcl_dialect::StringCharacterModel::Jim084Utf8) {
            // naming.string.original-counted-replacement-and-index-stages:
            // the original count precedes both original indices, including
            // when the subject itself is one of those Index headers.
            let len = ops.index_character_count(&args[0])?;
            let first = index::resolve_value(ops, &args[1], len)?.max(0);
            let last = index::resolve_value(ops, &args[2], len)?
                .min(i64::try_from(len).unwrap_or(i64::MAX) - 1);
            if last < first {
                return Ok(index::IndexResult::Borrowed(args[0].clone()));
            }
            let first = usize::try_from(first).map_err(|_| {
                tcl_syntax::value::ValueError::CommandProtocolUnavailable(
                    "original Jim replacement prefix extent",
                )
            })?;
            let last = usize::try_from(last).map_err(|_| {
                tcl_syntax::value::ValueError::CommandProtocolUnavailable(
                    "original Jim replacement after-part extent",
                )
            })?;
            let raw = RawString::from_bytes(ops.index_operand_bytes(&args[0])?);
            let (mut bytes, after) = raw.jim084_replacement_parts(first, last, len)?;
            let mut count = first;
            if let Some(replacement) = args.get(3) {
                let replacement = ops.index_operand_bytes(replacement)?;
                count += RawString::from_bytes(std::rc::Rc::clone(&replacement))
                    .jim084_characters()
                    .count();
                bytes.extend_from_slice(&replacement);
            }
            count += RawString::from_bytes(after.as_slice())
                .jim084_characters()
                .count();
            bytes.extend_from_slice(&after);
            return Ok(index::IndexResult::Created(
                ops.new_jim_string(&bytes, count),
            ));
        }
        if let Some(version) = ops.index_c_version() {
            // naming.string.original-counted-replacement-and-index-stages
            // docs/design/analysis/name-resolution-proofs/string-original-counted-replacement-and-index-stages.md
            // C84–86 reach original Unicode first. C9 reaches CharLength first
            // and defers Unicode until a range is actually replaced.
            let initial_units = if version < tcl_dialect::TclVersion::V9_0 {
                Some(ops.index_c_unicode_units(&args[0])?)
            } else {
                None
            };
            let len = match &initial_units {
                Some(units) => units.len(),
                None => ops.index_character_count(&args[0])?,
            };
            let end = i64::try_from(len).map_err(|_| {
                tcl_syntax::value::ValueError::CommandProtocolUnavailable(
                    "original C replacement character width",
                )
            })? - 1;
            let first = index::resolve_value(ops, &args[1], len)?;
            let last = index::resolve_value(ops, &args[2], len)?;
            if last < 0 || first > end || last < first {
                return Ok(index::IndexResult::Borrowed(args[0].clone()));
            }
            if version >= tcl_dialect::TclVersion::V9_0 {
                let first = usize::try_from(first.max(0)).map_err(|_| {
                    tcl_syntax::value::ValueError::CommandProtocolUnavailable(
                        "original C replacement prefix extent",
                    )
                })?;
                let after = usize::try_from(last.min(end).saturating_add(1)).map_err(|_| {
                    tcl_syntax::value::ValueError::CommandProtocolUnavailable(
                        "original C replacement suffix extent",
                    )
                })?;
                return replace_c_parsed_range_result(
                    ops,
                    &args[0],
                    first,
                    after - first,
                    args.get(3),
                    true,
                );
            }
            let units = if version == tcl_dialect::TclVersion::V8_4 {
                let units = initial_units.expect("reached original C84 Unicode");
                let snapshot = ops.native_object_snapshot(&args[0])?;
                if !matches!(snapshot.cache, tcl_syntax::native_object::NativeObjectCacheSnapshot::String {
                    protocol: tcl_syntax::native_string::NativeStringProtocol::C(tcl_dialect::TclVersion::V8_4),
                    unicode: Some(ref cached), ..
                } if std::rc::Rc::ptr_eq(cached, &units))
                {
                    return Err(tcl_syntax::value::ValueError::CommandProtocolUnavailable(
                        "retired original C84 replacement Unicode backing",
                    )
                    .into());
                }
                units
            } else {
                ops.index_c_unicode_units(&args[0])?
            };
            let first = usize::try_from(first.max(0)).map_err(|_| {
                tcl_syntax::value::ValueError::CommandProtocolUnavailable(
                    "original C replacement prefix extent",
                )
            })?;
            let after = usize::try_from(last.saturating_add(1))
                .unwrap_or(usize::MAX)
                .min(units.len());
            let prefix = units.get(..first).ok_or(
                tcl_syntax::value::ValueError::CommandProtocolUnavailable(
                    "retired original C replacement prefix extent",
                ),
            )?;
            let result = ops.index_c_unicode_result(prefix.into(), version)?;
            let reached = (|| -> Result<(), CmdError> {
                if let Some(replacement) = args.get(3) {
                    ops.index_c_append_object(&result, replacement)?;
                }
                if after < units.len() {
                    ops.index_c_append_unicode(&result, &units[after..])?;
                }
                Ok(())
            })();
            if let Err(first) = reached {
                ops.discard_owned_index_result(result);
                return Err(first);
            }
            return Ok(index::IndexResult::Created(result));
        }
        let chars: Vec<char> = ops.index_unicode(&args[0])?.chars().collect();
        let len = chars.len();
        let end = i64::try_from(len).unwrap_or(i64::MAX) - 1;
        let first = index::resolve_value(ops, &args[1], len)?;
        let last = index::resolve_value(ops, &args[2], len)?;
        if last < 0 || first > end || last < first {
            return Ok(index::IndexResult::Borrowed(args[0].clone()));
        }
        let first = first.max(0);
        let last = last.min(end);
        let lo = usize::try_from(first).unwrap_or(0);
        let hi_excl = usize::try_from(last + 1).unwrap_or(0).min(len);
        let mut out: String = chars[..lo].iter().collect();
        if args.len() == 4 {
            out.push_str(&ops.index_unicode(&args[3])?);
        }
        out.extend(chars[hi_excl..].iter());
        Ok(index::IndexResult::Created(ops.new_string(out)))
    })
}

/// Replace an already parsed, bounded range through the original C9 producer.
/// The caller supplies the actual in-place flag; original native sharing decides
/// whether equal-sized binary replacement can reuse the subject header. This
/// entry supplies neither an index-parser result nor an entered EvalObjv role.
///
/// # Errors
/// A missing actual C9 producer, invalid reached range, original storage failure,
/// or the complete first Host refusal. Nonempty NULL-source binary allocation
/// is unavailable because its initial native payload is unspecified.
pub fn replace_c_parsed_range<O: NativeIndexOps>(
    ops: &mut O,
    subject: &O::Value,
    first: usize,
    count: usize,
    replacement: Option<&O::Value>,
    in_place: bool,
) -> Result<O::Value, CmdError> {
    index::run_index_result(ops, |ops| {
        replace_c_parsed_range_result(ops, subject, first, count, replacement, in_place)
    })
}

fn replace_c_parsed_range_result<O: NativeIndexOps>(
    ops: &mut O,
    subject: &O::Value,
    first: usize,
    count: usize,
    replacement: Option<&O::Value>,
    in_place: bool,
) -> Result<index::IndexResult<O::Value>, CmdError> {
    use tcl_syntax::value::ValueError;
    let version = ops
        .index_c_version()
        .filter(|version| *version >= tcl_dialect::TclVersion::V9_0)
        .ok_or(ValueError::CommandProtocolUnavailable(
            "original C9 parsed replacement producer",
        ))?;
    if replacement.is_none() && count == 0 {
        if in_place {
            return Ok(index::IndexResult::Borrowed(subject.clone()));
        }
        return ops
            .index_c_duplicate_original(subject)
            .map(index::IndexResult::Created);
    }
    let after = first
        .checked_add(count)
        .ok_or(ValueError::CommandProtocolUnavailable(
            "original C replacement range width",
        ))?;
    if let Some(bytes) = ops.index_c_pure_binary(subject)? {
        let prefix = bytes
            .get(..first)
            .ok_or(ValueError::CommandProtocolUnavailable(
                "original C binary prefix extent",
            ))?;
        let suffix = bytes
            .get(after..)
            .ok_or(ValueError::CommandProtocolUnavailable(
                "original C binary suffix extent",
            ))?;
        if let Some(replacement) = replacement {
            // naming.string.original-binary-replacement-direct-helper-sharing
            // docs/design/analysis/name-resolution-proofs/string-original-binary-replacement-direct-helper-sharing.md
            // Whole replacement returns the exact insertPtr before its getter.
            if first == 0 && after == bytes.len() {
                return Ok(index::IndexResult::Borrowed(replacement.clone()));
            }
            if let Some(insert) = ops.index_c_pure_binary(replacement)? {
                let capacity = prefix
                    .len()
                    .checked_add(insert.len())
                    .and_then(|length| length.checked_add(suffix.len()))
                    .ok_or(ValueError::CommandProtocolUnavailable(
                        "original C binary result width",
                    ))?;
                let mut result = Vec::with_capacity(capacity);
                result.extend_from_slice(prefix);
                result.extend_from_slice(&insert);
                result.extend_from_slice(suffix);
                if count == insert.len() && in_place && !ops.index_c_original_is_shared(subject)? {
                    ops.index_c_binary_splice(subject, result.into())?;
                    return Ok(index::IndexResult::Borrowed(subject.clone()));
                }
                return Ok(index::IndexResult::Created(
                    ops.index_c_binary_result(result.into())?,
                ));
            }
        } else {
            if !prefix.is_empty() || !suffix.is_empty() {
                // naming.string.original-binary-replacement-sharing-and-result-roles
                // docs/design/analysis/name-resolution-proofs/string-original-binary-replacement-sharing-and-result-roles.md
                // Nonzero NULL-source constructor storage is not initialised.
                // No recorded allocator bytes authenticate a deterministic producer.
                return Err(ValueError::CommandProtocolUnavailable(
                    "uninitialised original C binary replacement constructor",
                )
                .into());
            }
            return Ok(index::IndexResult::Created(
                ops.index_c_binary_result(std::rc::Rc::from([]))?,
            ));
        }
    }
    let units = ops.index_c_unicode_units(subject)?;
    let prefix = units
        .get(..first)
        .ok_or(ValueError::CommandProtocolUnavailable(
            "original C Unicode prefix extent",
        ))?;
    let suffix = units
        .get(after..)
        .ok_or(ValueError::CommandProtocolUnavailable(
            "original C Unicode suffix extent",
        ))?;
    let result = ops.index_c_unicode_result(prefix.into(), version)?;
    let reached = (|| -> Result<(), CmdError> {
        if let Some(replacement) = replacement {
            ops.index_c_append_object(&result, replacement)?;
        }
        if !suffix.is_empty() {
            ops.index_c_append_unicode(&result, suffix)?;
        }
        Ok(())
    })();
    if let Err(first) = reached {
        ops.discard_owned_index_result(result);
        return Err(first);
    }
    Ok(index::IndexResult::Created(result))
}

/// `string insert string index insertString` — insert `insertString` before the
/// character at `index`. `end` denotes the position *after* the last character
/// (so it appends); the index resolves against `len + 1`.
pub fn insert<O: NativeIndexOps>(ops: &mut O, args: &[O::Value]) -> Result<O::Value, CmdError> {
    index::run_created_index_result(ops, |ops| {
        let [s, idx, ins] = args else {
            return Err(CmdError::wrong_args(
                "string insert string index insertString",
            ));
        };
        let chars: Vec<char> = ops.index_unicode(s)?.chars().collect();
        let len = chars.len();
        let at = index::resolve_value(ops, idx, len + 1)?;
        let at = if at < 0 {
            0
        } else {
            usize::try_from(at).unwrap_or(len).min(len)
        };
        let mut out: String = chars[..at].iter().collect();
        out.push_str(&ops.index_unicode(ins)?);
        out.extend(chars[at..].iter());
        Ok(ops.new_string(out))
    })
}

/// `string cat ?arg ...?` — concatenate the string reps of all arguments.
pub fn cat<O: ValueOps>(ops: &mut O, args: &[O::Value]) -> Result<O::Value, CmdError> {
    if let Some(original) = ops.native_jim_string_cat(args)? {
        return Ok(original);
    }
    let mut output = Vec::new();
    for value in args {
        output.extend_from_slice(&ops.native_string_bytes(value)?);
    }
    Ok(ops.new_bytes(&output))
}

/// The default `string trim` set — every Unicode space character plus NUL
/// (`tclDefaultTrimSet`, TIP #413).
const DEFAULT_TRIM_SET: &[char] = &[
    '\u{09}', '\u{0a}', '\u{0b}', '\u{0c}', '\u{0d}', ' ', '\u{00}', '\u{85}', '\u{a0}',
    '\u{1680}', '\u{180e}', '\u{2000}', '\u{2001}', '\u{2002}', '\u{2003}', '\u{2004}', '\u{2005}',
    '\u{2006}', '\u{2007}', '\u{2008}', '\u{2009}', '\u{200a}', '\u{200b}', '\u{2028}', '\u{2029}',
    '\u{202f}', '\u{205f}', '\u{2060}', '\u{3000}', '\u{feff}',
];

/// `string trim`/`trimleft`/`trimright` — strip `chars` (default the TIP #413
/// whitespace set) from the requested ends.
pub fn trim<O: ValueOps>(
    ops: &mut O,
    s: &O::Value,
    chars: Option<&O::Value>,
    left: bool,
    right: bool,
) -> Result<O::Value, CmdError> {
    if ops.string_character_model() == Some(tcl_dialect::StringCharacterModel::Jim084Utf8) {
        let characters = if left {
            None
        } else {
            chars
                .map(|value| ops.native_string_bytes(value))
                .transpose()?
        };
        let string = tcl_syntax::raw_string::RawString::from_bytes(ops.native_string_bytes(s)?);
        let characters = if left {
            chars
                .map(|value| ops.native_string_bytes(value))
                .transpose()?
        } else {
            characters
        };
        let characters = tcl_syntax::raw_string::RawString::from_bytes(
            characters.unwrap_or_else(|| std::rc::Rc::from(&b" \t\n\r\0"[..])),
        );
        let plan = string.jim084_trim_plan(&characters, left, right);
        return Ok(ops.jim_string_trim_result(s, plan));
    }
    let version = match ops.string_character_model() {
        Some(tcl_dialect::StringCharacterModel::BmpCharsElseUtf8Bytes) => {
            Some(tcl_dialect::TclVersion::V8_4)
        }
        Some(tcl_dialect::StringCharacterModel::Utf16CodeUnits) => {
            Some(tcl_dialect::TclVersion::V8_6)
        }
        Some(tcl_dialect::StringCharacterModel::UnicodeScalars) => {
            Some(tcl_dialect::TclVersion::V9_0)
        }
        _ => None,
    };
    if let Some(version) = version {
        return native_trim::command_trim(ops, s, chars, version, left, right);
    }
    let string = ops.try_as_str(s)?.to_string();
    let custom = chars.map(|c| ops.try_as_str(c)).transpose()?;
    let custom: Option<Vec<char>> = custom.map(|c| c.chars().collect());
    let pred = |c: char| match &custom {
        Some(set) => set.contains(&c),
        None => DEFAULT_TRIM_SET.contains(&c),
    };
    let trimmed = match (left, right) {
        (true, true) => string.trim_matches(pred),
        (true, false) => string.trim_start_matches(pred),
        (false, true) => string.trim_end_matches(pred),
        (false, false) => string.as_str(),
    };
    Ok(ops.new_string(trimmed.to_string()))
}

/// `string first needleString haystackString ?startIndex?` — the character index
/// of the first occurrence of `needle` at or after `start` (default 0), or -1.
pub fn first<O: NativeIndexOps>(
    ops: &mut O,
    needle: &O::Value,
    haystack: &O::Value,
    start: Option<&O::Value>,
) -> Result<O::Value, CmdError> {
    index::run_created_index_result(ops, |ops| {
        if ops.string_character_model() == Some(tcl_dialect::StringCharacterModel::Jim084Utf8) {
            let needle_count = ops.index_character_count(needle)?;
            let count = ops.index_character_count(haystack)?;
            let start = start
                .map(|value| index::resolve_value(ops, value, count))
                .transpose()?
                .unwrap_or(0)
                .max(0);
            let found = RawString::from_bytes(ops.index_operand_bytes(haystack)?).jim084_first(
                count,
                &RawString::from_bytes(ops.index_operand_bytes(needle)?),
                needle_count,
                usize::try_from(start).unwrap_or(usize::MAX),
            )?;
            return Ok(
                ops.new_int(found.map_or(-1, |index| i64::try_from(index).unwrap_or(i64::MAX)))
            );
        }
        let hay: Vec<char> = ops.index_unicode(haystack)?.chars().collect();
        let needle: Vec<char> = ops.index_unicode(needle)?.chars().collect();
        let start = match start {
            None => 0,
            Some(s) => {
                usize::try_from(index::resolve_value(ops, s, hay.len())?.max(0)).unwrap_or(0)
            }
        };
        if needle.is_empty() {
            return Ok(ops.new_int(-1));
        }
        let mut idx: i64 = -1;
        if needle.len() <= hay.len() {
            for i in start..=hay.len() - needle.len() {
                if hay[i..i + needle.len()] == needle[..] {
                    idx = i64::try_from(i).unwrap_or(i64::MAX);
                    break;
                }
            }
        }
        Ok(ops.new_int(idx))
    })
}

/// `string last needleString haystackString ?lastIndex?` — the character index of
/// the last occurrence ending at or before `lastIndex` (default end), or -1.
pub fn last<O: NativeIndexOps>(
    ops: &mut O,
    needle: &O::Value,
    haystack: &O::Value,
    last_index: Option<&O::Value>,
) -> Result<O::Value, CmdError> {
    index::run_created_index_result(ops, |ops| {
        if ops.string_character_model() == Some(tcl_dialect::StringCharacterModel::Jim084Utf8) {
            let needle_count = ops.index_character_count(needle)?;
            let count = ops.index_character_count(haystack)?;
            let prefix = last_index
                .map(|value| index::resolve_value(ops, value, count))
                .transpose()?
                .unwrap_or_else(|| i64::try_from(count).unwrap_or(i64::MAX))
                .max(0);
            let found = RawString::from_bytes(ops.index_operand_bytes(haystack)?).jim084_last(
                usize::try_from(prefix).unwrap_or(usize::MAX),
                &RawString::from_bytes(ops.index_operand_bytes(needle)?),
                needle_count,
            )?;
            return Ok(
                ops.new_int(found.map_or(-1, |index| i64::try_from(index).unwrap_or(i64::MAX)))
            );
        }
        let hay: Vec<char> = ops.index_unicode(haystack)?.chars().collect();
        let needle: Vec<char> = ops.index_unicode(needle)?.chars().collect();
        let last: i64 = match last_index {
            None => i64::try_from(hay.len()).unwrap_or(i64::MAX) - 1,
            Some(s) => index::resolve_value(ops, s, hay.len())?,
        };
        // An empty haystack can hold no non-empty needle — return -1 before the
        // clamp below, whose `saturating_sub(1)` would otherwise yield index 0 and
        // panic when the search slices `hay[0..needle.len()]` (e.g.
        // `string last a {} 0`).
        if needle.is_empty() || last < 0 || hay.is_empty() {
            return Ok(ops.new_int(-1));
        }
        let last = usize::try_from(last)
            .unwrap_or(0)
            .min(hay.len().saturating_sub(1));
        let mut idx: i64 = -1;
        // `needle.len() <= hay.len()` guards the `hay[i..i + needle.len()]` slice:
        // without it, an empty (or too-short) haystack with an explicit index
        // (`string last a "" 0`) drives `last` to 0, passes `last + 1 >= needle`,
        // and slices past the end. `string first` has the same guard.
        if needle.len() <= hay.len() && last + 1 >= needle.len() {
            let hi = last + 1 - needle.len();
            for i in (0..=hi).rev() {
                if hay[i..i + needle.len()] == needle[..] {
                    idx = i64::try_from(i).unwrap_or(i64::MAX);
                    break;
                }
            }
        }
        Ok(ops.new_int(idx))
    })
}

/// `string match ?-nocase? pattern string` — glob match, returning a boolean.
pub fn string_match<O: ValueOps>(ops: &mut O, args: &[O::Value]) -> Result<O::Value, CmdError> {
    if ops.string_character_model() == Some(tcl_dialect::StringCharacterModel::Jim084Utf8) {
        let (nocase, pattern, subject) = match args {
            [pattern, subject] => (false, pattern, subject),
            [option, pattern, subject]
                if {
                    let option = ops.as_bytes(option);
                    option.len() >= 2 && b"-nocase".starts_with(&option)
                } =>
            {
                (true, pattern, subject)
            }
            _ => {
                return Err(CmdError::wrong_args(
                    "string match ?-nocase? pattern string",
                ));
            }
        };
        let matched = RawString::from_bytes(ops.as_bytes(subject))
            .jim084_matches(&RawString::from_bytes(ops.as_bytes(pattern)), nocase)?;
        return Ok(ops.new_bool(matched));
    }
    let (nocase, pat, s) = match args {
        [p, s] => (false, p, s),
        [opt, p, s] if is_nocase(&ops.try_as_str(opt)?) => (true, p, s),
        // Three arguments whose first is not `-nocase` is a bad option, not a
        // wrong count (C's `StringMatchCmd`): `string match -bogus a b` and
        // `string match -- a a` both report `bad option "…": must be -nocase`
        // (string-11.x), since `--` is not an accepted option here.
        [opt, _, _] => {
            return Err(CmdError::new(format!(
                "bad option \"{}\": must be -nocase",
                ops.try_as_str(opt)?
            )));
        }
        _ => {
            return Err(CmdError::wrong_args(
                "string match ?-nocase? pattern string",
            ));
        }
    };
    let pattern = ops.try_as_str(pat)?.to_string();
    let text = ops.try_as_str(s)?.to_string();
    Ok(ops.new_bool(tcl_syntax::glob::string_case_match(&pattern, &text, nocase)))
}

/// Whether `opt` is `-nocase` or an unambiguous prefix of it (`-n`, `-no`, …).
///
/// Deliberately NOT the shared [`crate::prefix`] matcher: C's
/// `StringMatchCmd`/`StringMapCmd` hand-roll `(length > 1) && strncmp(string,
/// "-nocase", length)` instead of calling `Tcl_GetIndexFromObj`, so a lone
/// `-` is a bad option here (`string match - a b` errors in tclsh) even
/// though the table rule would accept it as a unique prefix of a one-entry
/// table.
fn is_nocase(opt: &str) -> bool {
    opt.len() >= 2 && "-nocase".starts_with(opt)
}

/// `string map ?-nocase? charMap string` — replace substrings per the
/// `key value ...` map, scanning left-to-right and taking the first matching key
/// at each position (advancing past it), else copying one character.
/// Full Unicode simple-lowercase fold of a character sequence, used by
/// `string map -nocase` to compare keys against the source the same way
/// `string equal -nocase` and `tolower` do.
fn fold_chars(cs: &[char]) -> Vec<char> {
    cs.iter().flat_map(|c| c.to_lowercase()).collect()
}

pub fn map<O: ValueOps>(ops: &mut O, args: &[O::Value]) -> Result<O::Value, CmdError> {
    let (nocase, pairs, text) = match args {
        [m, s] => (false, m, s),
        [opt, m, s] if is_nocase(&ops.try_as_str(opt)?) => (true, m, s),
        // Three arguments whose first is not `-nocase` is a bad option, not a
        // wrong count (C's `StringMapCmd`): `string map {a b} abba oops`
        // reports `bad option "a b"` (string-10.2).
        [opt, _, _] => {
            return Err(CmdError::new(format!(
                "bad option \"{}\": must be -nocase",
                ops.try_as_str(opt)?
            )));
        }
        _ => return Err(CmdError::wrong_args("string map ?-nocase? charMap string")),
    };
    let items = ops.list_elements(pairs)?;
    if items.len() % 2 != 0 {
        return Err(CmdError::new("char map list unbalanced"));
    }
    let mut map: Vec<(String, String)> = Vec::with_capacity(items.len() / 2);
    for c in items.as_chunks::<2>().0 {
        map.push((
            ops.try_as_str(&c[0])?.to_string(),
            ops.try_as_str(&c[1])?.to_string(),
        ));
    }
    let string = ops.try_as_str(text)?.to_string();

    // Case-insensitive matching folds full Unicode case (like `string equal
    // -nocase` and `tolower`), not just ASCII, and matches/advances by
    // *character* so a key whose case fold changes byte length stays aligned
    // with C's `Tcl_UniCharNcasecmp` over `length2` characters.
    let keys: Vec<(Vec<char>, Vec<char>, &str)> = map
        .iter()
        .filter(|(from, _)| !from.is_empty())
        .map(|(from, to)| {
            let chars: Vec<char> = from.chars().collect();
            let folded = if nocase {
                fold_chars(&chars)
            } else {
                Vec::new()
            };
            (chars, folded, to.as_str())
        })
        .collect();
    let src: Vec<char> = string.chars().collect();
    let mut out = String::with_capacity(string.len());
    let mut i = 0;
    'outer: while i < src.len() {
        for (key, folded_key, to) in &keys {
            let klen = key.len();
            if i + klen > src.len() {
                continue;
            }
            let region = &src[i..i + klen];
            let hit = if nocase {
                fold_chars(region) == *folded_key
            } else {
                region == key.as_slice()
            };
            if hit {
                out.push_str(to);
                i += klen;
                continue 'outer;
            }
        }
        out.push(src[i]);
        i += 1;
    }
    Ok(ops.new_string(out))
}

/// Arity-check (`string ?chars?`) wrapper shared by the three `trim` arms.
fn trim_dispatch<O: NativeIndexOps>(
    ops: &mut O,
    rest: &[O::Value],
    usage: &str,
    left: bool,
    right: bool,
) -> Result<O::Value, CmdError> {
    match rest {
        [s] => trim(ops, s, None, left, right),
        [s, c] => trim(ops, s, Some(c), left, right),
        _ => Err(CmdError::wrong_args(usage)),
    }
}

/// Dispatch a `string` subcommand whose name `sub` is **already canonical** (the
/// runtime has resolved any unique-prefix abbreviation), with `rest` being the
/// arguments after the subcommand.
///
/// Returns `Some(result)` when the subcommand is handled here, or `None` when it
/// is not handled here — letting the calling runtime fall back to its own
/// implementation. The `Some(Err(..))` case is a genuine command error (arity,
/// bad index, …).
pub fn dispatch_canon<O: NativeIndexOps>(
    ops: &mut O,
    sub: &str,
    rest: &[O::Value],
) -> Option<Result<O::Value, CmdError>> {
    let arity = |n: usize, usage: &str| -> Option<Result<O::Value, CmdError>> {
        if rest.len() == n {
            None
        } else {
            Some(Err(CmdError::wrong_args(usage)))
        }
    };
    match sub {
        "bytelength" => {
            arity(1, "string bytelength string").or_else(|| Some(bytelength(ops, &rest[0])))
        }
        "length" => arity(1, "string length string").or_else(|| Some(length(ops, &rest[0]))),
        "index" => arity(2, "string index string charIndex")
            .or_else(|| Some(index(ops, &rest[0], &rest[1]))),
        "range" => arity(3, "string range string first last")
            .or_else(|| Some(range(ops, &rest[0], &rest[1], &rest[2]))),
        "reverse" => arity(1, "string reverse string").or_else(|| Some(reverse(ops, &rest[0]))),
        "repeat" => {
            arity(2, "string repeat string count").or_else(|| Some(repeat(ops, &rest[0], &rest[1])))
        }
        "equal" => Some(compare(ops, rest, CompareMode::Equal)),
        "compare" => Some(compare(ops, rest, CompareMode::Compare)),
        "cat" => Some(cat(ops, rest)),
        "match" => Some(string_match(ops, rest)),
        "map" => Some(map(ops, rest)),
        "toupper" => Some(case_convert(
            ops,
            rest,
            CaseMode::Upper,
            "string toupper string ?first? ?last?",
        )),
        "tolower" => Some(case_convert(
            ops,
            rest,
            CaseMode::Lower,
            "string tolower string ?first? ?last?",
        )),
        "totitle" => Some(case_convert(
            ops,
            rest,
            CaseMode::Title,
            "string totitle string ?first? ?last?",
        )),
        "replace" => Some(replace(ops, rest)),
        "insert" => Some(insert(ops, rest)),
        "first" => match rest {
            [n, h] => Some(first(ops, n, h, None)),
            [n, h, s] => Some(first(ops, n, h, Some(s))),
            _ => Some(Err(CmdError::wrong_args(
                "string first needleString haystackString ?startIndex?",
            ))),
        },
        "last" => match rest {
            [n, h] => Some(last(ops, n, h, None)),
            [n, h, s] => Some(last(ops, n, h, Some(s))),
            _ => Some(Err(CmdError::wrong_args(
                "string last needleString haystackString ?lastIndex?",
            ))),
        },
        "trim" => Some(trim_dispatch(
            ops,
            rest,
            "string trim string ?chars?",
            true,
            true,
        )),
        "trimleft" => Some(trim_dispatch(
            ops,
            rest,
            "string trimleft string ?chars?",
            true,
            false,
        )),
        "trimright" => Some(trim_dispatch(
            ops,
            rest,
            "string trimright string ?chars?",
            false,
            true,
        )),
        "wordstart" => arity(2, "string wordstart string index")
            .or_else(|| Some(word_bound(ops, &rest[0], &rest[1], true))),
        "wordend" => arity(2, "string wordend string index")
            .or_else(|| Some(word_bound(ops, &rest[0], &rest[1], false))),
        // Not handled here — caller falls back to its own path (`is`, …).
        _ => None,
    }
}

/// `string wordstart|wordend str charIndex` — the bounds of the word containing
/// `charIndex` (`StringStartCmd`/`StringEndCmd`). A "word" is a maximal run of
/// word-characters, or a single non-word character. `start` selects `wordstart`
/// (the index of the word's first char) vs `wordend` (one past its last char).
pub fn word_bound<O: NativeIndexOps>(
    ops: &mut O,
    s: &O::Value,
    idx: &O::Value,
    start: bool,
) -> Result<O::Value, CmdError> {
    index::run_created_index_result(ops, |ops| {
        let chars: Vec<char> = ops.index_unicode(s)?.chars().collect();
        let index = index::resolve_value(ops, idx, chars.len())?;
        let result = if start {
            word_start(&chars, index)
        } else {
            word_end(&chars, index)
        };
        Ok(ops.new_int(i64::try_from(result).unwrap_or(i64::MAX)))
    })
}

/// The start of the word containing (clamped) `index` — walk left over word
/// chars. A non-word char at `index` is its own word start.
fn word_start(chars: &[char], index: i64) -> usize {
    let n = chars.len();
    if n == 0 {
        return 0;
    }
    let last = i64::try_from(n - 1).unwrap_or(i64::MAX);
    let i = index.min(last);
    if i <= 0 {
        return 0;
    }
    let i = usize::try_from(i).unwrap_or(0);
    if !is_word_char(chars[i]) {
        return i;
    }
    let mut j = i;
    while j > 0 && is_word_char(chars[j - 1]) {
        j -= 1;
    }
    j
}

/// The end (one past the last char) of the word containing (clamped) `index` —
/// walk right over word chars. A non-word char advances exactly one.
fn word_end(chars: &[char], index: i64) -> usize {
    let n = chars.len();
    if index >= i64::try_from(n).unwrap_or(i64::MAX) {
        return n;
    }
    let i = usize::try_from(index.max(0)).unwrap_or(0);
    let mut cur = i;
    while cur < n && is_word_char(chars[cur]) {
        cur += 1;
    }
    if cur == i { cur + 1 } else { cur }
}

/// `Tcl_UniCharIsWordChar`: letters and decimal digits (approximated by
/// `char::is_alphanumeric`) plus connector punctuation.
fn is_word_char(c: char) -> bool {
    c.is_alphanumeric() || is_connector_punct(c)
}

/// The Unicode connector-punctuation set Tcl treats as word characters
/// (underscore and friends).
fn is_connector_punct(c: char) -> bool {
    matches!(
        c,
        '\u{005F}'
            | '\u{203F}'
            | '\u{2040}'
            | '\u{2054}'
            | '\u{FE33}'
            | '\u{FE34}'
            | '\u{FE4D}'
            | '\u{FE4E}'
            | '\u{FE4F}'
            | '\u{FF3F}'
    )
}

/// Dispatch a `string` subcommand from the raw argument vector (`args[0]` is the
/// subcommand). Convenience over [`dispatch_canon`] for a runtime that does not
/// pre-resolve abbreviations; exact subcommand names only.
pub fn dispatch<O: NativeIndexOps>(
    ops: &mut O,
    args: &[O::Value],
) -> Option<Result<O::Value, CmdError>> {
    let sub = match ops.try_as_str(args.first()?) {
        Ok(sub) => sub,
        Err(error) => return Some(Err(error.into())),
    };
    dispatch_canon(ops, &sub, &args[1..])
}

#[cfg(test)]
mod tests {
    use super::*;

    fn chars(s: &str) -> Vec<char> {
        s.chars().collect()
    }

    /// A throwaway string-only `ValueOps` for the `first`/`last` index tests.
    #[derive(Default)]
    struct StrOps;

    impl crate::index::NativeIndexOps for StrOps {
        type IndexOperation = ();
        type IndexBinaryReceipt = ();
        type IndexKeyOwner = Self::Value;
        fn index_borrowed_key(
            &mut self,
            value: &Self::Value,
        ) -> Result<Self::Value, crate::CmdError> {
            Ok(value.clone())
        }
        fn index_created_key(
            &mut self,
            value: Self::Value,
        ) -> Result<Self::Value, crate::CmdError> {
            Ok(value)
        }
        fn index_key_value(owner: &Self::Value) -> &Self::Value {
            owner
        }
        fn index_hold_key_result(
            &mut self,
            owner: &Self::Value,
        ) -> Result<Self::Value, crate::CmdError> {
            Ok(owner.clone())
        }
        fn index_finish_held_key_result(
            &mut self,
            held: Self::Value,
        ) -> Result<crate::index::IndexResult<Self::Value>, crate::CmdError> {
            Ok(crate::index::IndexResult::Detached(held))
        }
        fn index_key_argument(
            &mut self,
            owner: &Self::Value,
        ) -> Result<Self::Value, crate::CmdError> {
            Ok(owner.clone())
        }
        fn index_key_result(
            &mut self,
            owner: &Self::Value,
            created: bool,
            ancestor: bool,
        ) -> Result<crate::index::IndexResult<Self::Value>, crate::CmdError> {
            Ok(if created {
                crate::index::IndexResult::Created(owner.clone())
            } else if ancestor {
                crate::index::IndexResult::Detached(owner.clone())
            } else {
                crate::index::IndexResult::Borrowed(owner.clone())
            })
        }
        fn enter_index_operation(&mut self) -> Result<(), crate::CmdError> {
            Ok(())
        }
        fn check_index_operation(&mut self, _: &()) -> Result<(), crate::CmdError> {
            Ok(())
        }
        fn retain_index_failure(&mut self, _error: &crate::CmdError) {
            // Pure neutral adapter has no interpreter first-cause owner.
        }
        fn discard_owned_index_result(&mut self, created: Self::Value) {
            drop(created);
        }
    }

    impl ValueOps for StrOps {
        fn index_syntax(&self) -> Option<tcl_dialect::IndexSyntax> {
            Some(tcl_dialect::IndexSyntax::for_version(
                tcl_dialect::TclVersion::V9_0,
            ))
        }
        type Value = String;
        fn new_str(&mut self, s: &str) -> String {
            s.to_owned()
        }
        fn new_int(&mut self, n: i64) -> String {
            n.to_string()
        }
        fn new_double(&mut self, f: f64) -> String {
            tcl_syntax::number::format_double(f)
        }
        fn new_bool(&mut self, b: bool) -> String {
            (if b { "1" } else { "0" }).to_owned()
        }
        fn new_list(&mut self, items: Vec<String>) -> String {
            items.join(" ")
        }
        fn as_bytes(&mut self, v: &String) -> std::rc::Rc<[u8]> {
            std::rc::Rc::from(v.as_bytes())
        }
        fn new_bytes(&mut self, bytes: &[u8]) -> Self::Value {
            self.new_str(std::str::from_utf8(bytes).expect("Unicode-only fixture input"))
        }

        fn as_int(&mut self, v: &String) -> Result<i64, tcl_syntax::value::ValueError> {
            v.parse()
                .map_err(|_| tcl_syntax::value::ValueError::NotInteger(v.clone()))
        }
        fn as_double(&mut self, _v: &String) -> Result<f64, tcl_syntax::value::ValueError> {
            Ok(0.0)
        }
        fn as_bool(&mut self, _v: &String) -> Result<bool, tcl_syntax::value::ValueError> {
            Ok(false)
        }
        fn list_elements(
            &mut self,
            v: &String,
        ) -> Result<Vec<String>, tcl_syntax::value::ValueError> {
            Ok(v.split_whitespace().map(str::to_owned).collect())
        }
    }

    fn last_of(needle: &str, haystack: &str, last_index: Option<&str>) -> i64 {
        let mut ops = StrOps;
        let n = needle.to_owned();
        let h = haystack.to_owned();
        let li = last_index.map(str::to_owned);
        let r = last(&mut ops, &n, &h, li.as_ref()).expect("string last");
        r.parse().unwrap()
    }

    #[test]
    fn string_last_empty_haystack_with_index_does_not_panic() { /* FIXED_ASSERTION_TEST string_last_empty_haystack_with_index_does_not_panic */ }

    #[test]
    fn string_last_basic() { /* FIXED_ASSERTION_TEST string_last_basic */ }

    #[test]
    fn string_compare_equal_share_option_and_unicode_semantics() {
        let mut ops = StrOps;
        assert_eq!(
            compare(
                &mut ops,
                &[
                    "-noc".to_owned(),
                    "-len".to_owned(),
                    "2".to_owned(),
                    "ABxx".to_owned(),
                    "abYY".to_owned(),
                ],
                CompareMode::Compare,
            )
            .unwrap(),
            "0"
        );
        // Tcl folds before applying -length: U+0130 lowercases to `i` plus a
        // combining dot, whose first character compares equal to `i`.
        assert_eq!(
            compare(
                &mut ops,
                &[
                    "-nocase".to_owned(),
                    "-length".to_owned(),
                    "1".to_owned(),
                    "\u{0130}".to_owned(),
                    "i".to_owned(),
                ],
                CompareMode::Equal,
            )
            .unwrap(),
            "1"
        );
        assert_eq!(
            compare(
                &mut ops,
                &["-bogus".to_owned(), "a".to_owned(), "b".to_owned()],
                CompareMode::Equal,
            )
            .unwrap_err()
            .message()
            .unwrap(),
            "bad option \"-bogus\": must be -nocase or -length"
        );
    }

    #[test]
    fn word_start_finds_word_boundaries() {
        // Tcl `string wordstart` semantics. "abc def" = indices a0 b1 c2 ' '3 d4 e5 f6.
        let c = chars("abc def");
        assert_eq!(word_start(&c, 1), 0); // inside "abc"
        assert_eq!(word_start(&c, 5), 4); // inside "def"
        assert_eq!(word_start(&c, 3), 3); // the space is its own word
        assert_eq!(word_start(&c, 0), 0);
        assert_eq!(word_start(&c, 100), 4); // clamps to last char of "def"
        assert_eq!(word_start(&[], 3), 0); // empty
    }

    #[test]
    fn totitle_first_char_uses_titlecase_not_uppercase() {
        let mut ops = StrOps;
        let title = |ops: &mut StrOps, s: &str| {
            case_convert(ops, &[s.to_owned()], CaseMode::Title, "u").unwrap()
        };
        // The Latin dz digraph (U+01F3) titlecases to Dž (U+01F2), not the
        // uppercase DZ (U+01F1) — string-17.7; the rest is lowercased.
        assert_eq!(title(&mut ops, "\u{01F3}BCabc"), "\u{01F2}bcabc");
        assert_eq!(title(&mut ops, "\u{01C9}x"), "\u{01C8}x"); // lj → Lj
        // A non-digraph first char still titlecases to its uppercase.
        assert_eq!(title(&mut ops, "hELLO"), "Hello");
        // `toupper` of the digraph is the uppercase form (U+01F1), not titlecase.
        assert_eq!(
            case_convert(&mut ops, &["\u{01F3}".to_owned()], CaseMode::Upper, "u").unwrap(),
            "\u{01F1}"
        );
    }

    #[test]
    fn case_mapping_is_simple_not_full() { /* FIXED_ASSERTION_TEST case_mapping_is_simple_not_full */ }

    #[test]
    fn word_end_finds_word_boundaries() {
        // Tcl `string wordend` — end is one past the last word char.
        let c = chars("abc def");
        assert_eq!(word_end(&c, 1), 3); // end of "abc" (exclusive)
        assert_eq!(word_end(&c, 4), 7); // end of "def"
        assert_eq!(word_end(&c, 3), 4); // a non-word char advances exactly one
        assert_eq!(word_end(&c, 100), 7); // past end → length
    }

    #[test]
    fn string_last_empty_haystack_is_minus_one_not_panic() { /* FIXED_ASSERTION_TEST string_last_empty_haystack_is_minus_one_not_panic */ }

    #[test]
    fn string_last_finds_last_occurrence() { /* FIXED_ASSERTION_TEST string_last_finds_last_occurrence */ }

    fn repeat_of(s: &str, count: &str) -> Result<String, CmdError> {
        let mut ops = StrOps;
        repeat(&mut ops, &s.to_owned(), &count.to_owned())
    }

    #[test]
    fn string_repeat_bounds_the_result_before_allocating() {
        // Reject the oversized result before allocating its 200 GB payload.
        // Original C9.0.4/9.1b0: string size overflow: unable to alloc 200000000000 bytes
        let err = repeat_of("ab", "100000000000").expect_err("bounded");
        assert_eq!(
            err.message().unwrap(),
            "string size overflow: unable to alloc 200000000000 bytes"
        );
        // The byte count is the *byte* length of the string rep, not the
        // character count: tclsh 9.0.4 reports `string repeat \u00e9
        // 100000000000` as 200000000000 bytes too.
        let err = repeat_of("\u{e9}", "100000000000").expect_err("bounded");
        assert_eq!(
            err.message().unwrap(),
            "string size overflow: unable to alloc 200000000000 bytes"
        );
        // `count * length` is computed in `Tcl_Size` and wraps, and C reports
        // the wrapped value verbatim — tclsh 9.0.4:
        //   % string repeat ab 5000000000000000000
        //   string size overflow: unable to alloc -8446744073709551616 bytes
        let err = repeat_of("ab", "5000000000000000000").expect_err("bounded");
        assert_eq!(
            err.message().unwrap(),
            "string size overflow: unable to alloc -8446744073709551616 bytes"
        );
        // `count > TCL_SIZE_MAX - 1` is a different message — tclsh 9.0.4:
        //   % string repeat ab 9223372036854775807
        //   max size for a Tcl value (9223372036854775807 bytes) exceeded
        let err = repeat_of("ab", "9223372036854775807").expect_err("bounded");
        assert_eq!(
            err.message().unwrap(),
            "max size for a Tcl value (9223372036854775807 bytes) exceeded"
        );
        // …but an empty string short-circuits before either check, so even that
        // count is the empty string and not an error (tclsh 9.0.4:
        // `string repeat {} 9223372036854775807` → {}).
        assert_eq!(repeat_of("", "9223372036854775807").unwrap(), "");
        // Ordinary repeats are untouched.
        assert_eq!(repeat_of("ab", "3").unwrap(), "ababab");
        assert_eq!(repeat_of("ab", "0").unwrap(), "");
        assert_eq!(repeat_of("ab", "-1").unwrap(), "");
    }
}
