from record import *
import re
joins={
'runtime/rust/tests/expanded_invoke_semantics.rs':{'peer':'/root/audit','owner':'rust/tcl-test-support/src/lib.rs','SHA':'73f8b63cb8e5bb1d7dbcf783b3baace1e8d0bdf4d20fac169a0bed76bef59adf','sites':{'locate_source_tree':667,'run_script_from_source_tree':343},'limits':'Actual matching tree/patchlevel revalidated, library and loader path configured, TCLLIBPATH cleared. Caller explicitly skips missing source/binary and asserts exact9.0.4. DiscoveryNone/setup skip is not completed comparison; full before/after provider hashes and timeout remain independent caller/replay obligations.'},
'runtime/rust/tests/native_command_lookup_bases.rs':{'peer':'/root/audit','owner':'rust/tcl-test-support/src/lib.rs','SHA':'73f8b63cb8e5bb1d7dbcf783b3baace1e8d0bdf4d20fac169a0bed76bef59adf','sites':{'required_tclshs':392,'run_script':503,'run_script_with_libraries':613,'oracle_row_progress':51},'limits':'Every requested typed release required, no silent available-subset. Raw Path/stdin/stdout/stderr/exit retained. Interactive stdin/process0 alone not Tcl success; caller strict_text/vector expected checks and outer replaydeadline separate. No internal timeout; provider source/harness closure independent.'},
'rust/tcl-cmd-core/src/encoding/native_controls.rs':{'peer':'/root/audit','owner':'rust/tcl-test-support/src/encoding_utf8.rs','SHA':'4407bf39575186be1f20d6867490dbc1d03c159ca5868a0c511d20456b41ac1b','sites':{'CONTROLS':37,'decode_hex':273,'original_input':286},'limits':'Fixed11controls55Ccolumns compile-time include membership, explicit binary/String constructor flag; strict even-count radix16. original_input takes actual INPUT row last field, not String-report inverse. Does not authenticate every included capture/provider or grant native header/currentness.'},
'runtime/rust/src/interp/native_body_artifact/object_info_tests.rs':{'peer':'self actual read','owner':'runtime/rust/src/interp/native_body_artifact.rs','SHA':None,'sites':{'tests::interpreter':[3964,3988]},'limits':'Actual helper full function read: explicit selected native core with no path inputs, checks actual source protocol/compiler epochs; no process/env/fs/provider operations in helper. Other parent tests remain unexamined.'},
}
# The one included Rust support consists of an actually read function/declarations,
# then a narrowly validated literal-only table. This classifies fixture data,
# never observes external original semantics or treats arbitrary Rust as data.
p='runtime/rust/tests/data/native_original_list_stride644/software_controls.rs';s=(SRC/p).read_text();prefix,table=s.split('static ROWS: &[Row] = &[',1);table=table.strip();assert table.endswith('];');table=table[:-2]
pattern=re.compile(r'\s*Row\s*\{\s*dialect:\s*"[a-zA-Z0-9.]+",\s*case:\s*[0-9]+,\s*stride:\s*"[0-9a-f]*",\s*code:\s*-?[0-9]+,\s*result:\s*"[0-9a-f]*",\s*kind:\s*"[a-zA-Z0-9: ]+",\s*resident:\s*(?:true|false),\s*stream_sha256:\s*"[0-9a-f]{64}",\s*\},')
at=0;count=0
while at<len(table):
 m=pattern.match(table,at)
 if not m:assert not table[at:].strip(),repr(table[at:at+100]);break
 at=m.end();count+=1
assert count==108
joins['runtime/rust/src/cmd_list/native_original_stride_controls.rs']={'peer':'self actual unhex/declaration read + exact literal table grammar','owner':p,'SHA':__import__('hashlib').sha256((SRC/p).read_bytes()).hexdigest(),'sites':{'declarations_and_unhex':[1,21],'fixed_literal_rows':108},'limits':'All remaining source parsed by narrow literal-only Row grammar, no expression/call/macro/code accepted in table. Fixed original observations classified data only, not rewritten into implementation naming owners; stream hashes displayed by reader do not themselves validate original provider closure.'}
f=ROOT/'runtime-inline-operational-census.json';d=json.loads(f.read_text());cov=json.loads((ROOT/'runtime-file-coverage.json').read_text())
for p,j in joins.items():
 r=next(x for x in d['files'] if x['path']==p);r['inline_or_test_support_status']='source_local_operational_ingress_reviewed';r['whole_file_operational_review']='local_ingress_and_reached_callees_source_reviewed';r['callee_source_receipt']=j;r['reason']+=' Reached callee source joined by bounded receipt; '+j['limits'];c=next(x for x in cov['files'] if x['path']==p);c['operational_annex']['status']=r['inline_or_test_support_status'];c['whole_file_review_status']='local_operational_and_callee_source_closed_validation_pending'
atomic_write(f,json.dumps(d,indent=2)+'\n');atomic_write(ROOT/'runtime-file-coverage.json',json.dumps(cov,indent=2)+'\n');atomic_write(ROOT/'runtime-work/operational-callee-joins.json',json.dumps({'baseline':d['baseline'],'joins':joins,'execution':'None; owner peer source receipts and exact actual caller source only'},indent=2)+'\n')
print('closed',len(joins),'literal_rows',count)
