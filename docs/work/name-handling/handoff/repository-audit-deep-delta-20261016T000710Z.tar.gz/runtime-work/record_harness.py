from record import *
def batch(number,path_batch,notes):
 qf=ROOT/'runtime-work/fixture-harness-review-queue.json';q=json.loads(qf.read_text());paths=json.loads((ROOT/f'runtime-work/harness-batch{path_batch}-paths.json').read_text());assert len(paths)==len(notes);cov=json.loads((ROOT/'runtime-file-coverage.json').read_text());out=[]
 for p,(purpose,reason) in zip(paths,notes):
  x=next(x for x in q['files'] if x['path']==p);ind=purpose=='original_source_excerpt';x.update(source_review_status='actual_full_source_read',review_representative=p,purpose=purpose,reason=reason,provider_context_status='independent_retained_excerpt_not_execution' if ind else 'capture_caller_pairing_review_pending',replay_acceptance='none');c=next(x for x in cov['files'] if x['path']==p);c.update(reviewmode='actual_full_source_read',reason=reason,source_review_status=x['source_review_status'],provider_context_status=x['provider_context_status'])
  if ind:c['classification']='retained_original_provider_source_excerpt_reviewed'
  out.append(dict(x))
 by_blob={x['blob']:x for x in q['files'] if x.get('source_review_status')=='actual_full_source_read'}
 for x in q['files']:
  if x.get('source_review_status') or x['blob'] not in by_blob:continue
  y=by_blob[x['blob']];assert (SRC/x['path']).read_bytes()==(SRC/y['path']).read_bytes();x.update({k:y[k] for k in ['purpose','reason','provider_context_status','replay_acceptance']});x.update(source_review_status='exact_blob_duplicate_of_actual_read',review_representative=y['path']);c=next(z for z in cov['files'] if z['path']==x['path']);c.update(reviewmode=x['source_review_status'],reason='Exact complete blob/byte duplicate of actual-read '+y['path']+'. '+y['reason'],source_review_status=x['source_review_status'],provider_context_status=x['provider_context_status'])
  if y['purpose']=='original_source_excerpt':c['classification']='retained_original_provider_source_excerpt_reviewed'
  out.append(dict(x))
 atomic_write(qf,json.dumps(q,indent=2)+'\n');atomic_write(ROOT/'runtime-file-coverage.json',json.dumps(cov,indent=2)+'\n');atomic_write(ROOT/f'runtime-work/harness-source-review{number}.json',json.dumps({'baseline':q['baseline'],'files':out,'execution':'None; source read only'},indent=2)+'\n');print(len(out),'new source-bound paths')
