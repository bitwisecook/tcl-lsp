from record import *
notes={
757:'Actual C91property report captures realtarget/facet/header/member owners and freezepermits historicaldata acrosslatermetadatamutation. No blanketepoch invalidation or callableaccessor fromreport.',
758:'Actual originalrequested/table/member holders and purelookup verdict exist, but physical dynamic TEMP_TABLE Index origin/getter/table recipe equivalence remains unresolved. Original335 sourcewindows actuallyshow Tcl_GetIndexFromObjStruct(...TCL_INDEX_TEMP_TABLE), notpersistentcacheinstall requirement. Keep independentoriginrefusals; pure rosters cannot establishmissingphysical API stages.',
762:'Actual originalAppend same frame/Ns/receiver/header checks transported nestedString/kernel/publication/traces; logicalappend explicitnoNativepermission.',
765:'Actual append strict physicalscalar-role checks happenbeforeemptyfallback, preservingGuest read semantics separately; no missing-rolefalseabsencegrant.',
766:'Actual compiledcontrol sourcepositions/expressionarena/LVT/protectedCatchplace transport integrated. Geometryneverinstalledbody/frame/Nativecompilegrant; wholeparent production nowread.',
772:'Actual compilerhook/stockregistration selectedbygeneration/attachedrecipe with finiteImported chain, no aliasdonatedhook; missinghookdeclinesoptimization notcommandabsence.',
774:'Actual procedure realNstoken/pushedframe/CProc versus Jimoriginalparameters/body/holder/Restbeforestore-success observation integrated; noSource/Importgrant.',
779:'Actual once-reached quietJim globalErrorCode realtopframe/centralbareoriginalname, neutralcapture and laterrawErrorheaderuse integrated; Nonefailedreadnotabsence.',
780:'Actual privateerror field/retiringheader roles takenoutsideborrow and reentrancy checkedaftercallback, mandatoryreset vssetterpurposes separate; noNormalfromcleanup.',
781:'Actual stable globalcell binding selects intrinsicerrortrace; same label elsewhere insufficient. CStringnoObjheader versus Jimoriginalname APIs remain distinct.',
782:'Actual C84borrowedglobalCString setter/flags and originalresult append roles integrated; cannot substituteJimFrame0/newnameobjects or modernprivatefield.',
783:'Actual selectedprimitive header/cache/HostABI/Guestnumericfailure and actualerrorStringstage owner integrated; namingcallerframe/cell purpose remains independent.',
786:'Expressionnumeric acceptedNumber/magnitudes are data, notsemanticname/frame/commandidentity. CommonStringnestedtransport and actualsourcecaller explicitseparate.',
787:'Actual soleallocation incarnation/retiring/live/primaryepochs/neutralpins versus realNativeholds and Source/cache/resource retire owner integrated; snapshot is notauthority.',
788:'Actual checked primaryretirement/vacatedslot/adoption and duplicate producer integrated; caller stillchoosescheckedendpoint and owns unmatchedincomingbacking onfailure.',
792:'Actual String/Unicode/rawABI checkedstorage owners exist, raw bytes_ofneutral/emptyprojection cannotproveNativeemptyname. Perpurpose originalcaller/buildguard separate.',
793:'Actual originalbody artifact stamp joins truebody/Proc/interpreter/Ns/epochs/fullgrammar/observer/math/layout beforebytecodeprimaryadopt. Sourcegeometrynotexecutionrole.',
794:'Actual selectedcommand/ensemblecompiler prerequisites use originalmappedprefix/binding/generation/trace/attachedrecipe ratherthan reportinverse. Source-vs-physicaltable correspondence separateproviderquestion.',
795:'Actual localtable/nativeLVT Weak/stamp and canonicalslot/reportoriginal operands integrated; cell/key/trace/currentness actualowners separate.',
796:'Actual compiled variable read/write originalstage/cell/trace/namespacecache/link/diagnostic owners integrated andGuestmissing distinctHostfailure; no genericnameinverse.',
798:'Actual START_CMD epoch revalidation then exact retainedsource fallback and generic retainedwords/List/argv/frame dispatch integrated; providerentry-vs-argbinding semantics requirecontrols.',
799:'Actual codegen ABI originalframeowner+TLSindependentinterpreter/currency/completion/cleanup/outputwrite and frameallocationregistry integrated; detachederrorcompletion transportonly.',
804:'Actual generated procdefiner/genericargv uses genuineoriginalhandler/storage and explicitstockbindingcaller obligation; copiedparams/bodyfreshinputs nothistoricalSource/canonicalcacheauthority.',
808:'Actual JimInfo literalScript/inventory/retained-vector routing is integrated, but pure NativeJimInfoProtocol::dispatch bytes matching has not yetbeen joinedto actual original physical Enum/ParseSubCmd selector/header/table/cache stages. Keep wholeInfo entry pendingpurposeaudit, separatelyfromknown selectedbuildtable question and genuinelyintegrated literalforwarder.',
814:'Actual InfoDefault uses true declareddefault first and neutralhold beforeoriginaldestinationstore, currentvalue/name checks and rc0cleanup; notidentityfromequalvalue.',
816:'Actual selectedplace/table/frame/root/member variableteardown and retirement preservesHostlatch; boolunsetprojection cannotindependentlyproveabsenceafterrefusal.',
817:'Actual savedcleanup Weakoriginaltableledger/receiverbinding horizon neveradoptscallbackreplacement, mandatoryretirement separatecallbacksuppressonrefusal; manualreportjoin debt independent.',
819:'Actual stockfamily publication/config/worker/Ns lifecycle exactgeneration/slot/token currentness retainsreachedbookkeeping and dropsoutsideborrow; callbackreplacementcannotinheritstockcompileridentity.',
820:'Actual missing-slot/GLOBAL selectedstatichelperSource/body/filename/params/Proc/prepublicationInfoImportmarker and originalselector dispatch integrated. Public Import stillunconditionallyrefused/manualroute unfinished, rawauthoredsource notstaticbody.',
821:'Actual retainedensembleconfig originals resolveactualbinding/compilerhook/trace/generation and finitestockimplementationpath; unknown/missinghookdecline notabsence.',
822:'Actual privateworker freshparseprefix and retainedoriginalsuffix/usageRc adapter distinctfromcommandlookup/frame/Source; metadatafixedprefixcodework separatelytracked.',
824:'Actual selectedOOframeactivation/chainWeak/targetcreation/facet/instanceNsholder observation owners integrated, report neverframeissuer. WholeOO callgraph production nowreviewed, Nativecontrols pending.',
832:'Actual genericeach copy/refetch/liveiterator schedule preserves originalgroups/backings/realsetternames and actualJimemptyobject; rawretainedview notuniversallycurrentattachedheader.',
833:'Actual Source-return/iterator/candidate/InfoImportcompletion hooks integrated, genericBreak/Continue semanticspreserved; refusedImportentry/no publicNormalpermission separate.',
843:'Actual List/index/range/sort routing plus truecomparatorresultneutralhold and actualsharedscalargetter integrated; specificoriginalframe/header/nestedconversion obligations separatelyrecorded.'
}
d=load();out=[]
for i,n in notes.items():
 r=d['consumers'][i];assert r['disposition']=='migrated_validation_pending',(i,r['symbol']);old=dict(r)
 if i in [758,808]:r['disposition']='pending_audit';r['work_kind']='consumer_integration';r['work_kind_reason']=n;r['missingintegration']=n;r['native_gap_countable']=False
 if i in [766,824]:r['missingintegration']=n+' Actual Native/provider controls unexecuted by audit.'
 r['legacy_state_review']={'batch':'runtime-work/legacy-state-review08.json','decision':r['disposition'],'reason':n};out.append({'index':i,'path':r['path'],'symbol':r['symbol'],'site':r['site'],'sourceSHA':r['sourceSHA'],'before_disposition':old['disposition'],'after_disposition':r['disposition'],'old_missingintegration':old['missingintegration'],'decision_reason':n})
atomic_write(ROOT/'runtime-consumers.json',json.dumps(d,indent=2)+'\n');atomic_write(ROOT/'runtime-work/legacy-state-review08.json',json.dumps({'baseline':d['baseline'],'scope':'35 individual states: closes original364legacy interpretations plus nextsource-purpose entry; physicalselector/originquestions explicitlypending','rows':out,'execution':'None'},indent=2)+'\n');print(len(out),'reviewed,2 pendingphysicalpurposes')
