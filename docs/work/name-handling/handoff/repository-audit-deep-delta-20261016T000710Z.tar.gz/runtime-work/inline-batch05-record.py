from record import *
files=json.loads((ROOT/'runtime-work/inline-batch05-paths.json').read_text())
notes=[
'Full Jim output-key software control body read: actual original numeric/empty output headers, Catch/Try modes incl array/linked scalar, exact observed fixture key/type/String/result membership and stale/owner assertions; no external provider launch. Fixture source/capture pairing remains independent evidence obligation.',
'Full primitive String refusal software controls read: fixed real arithseries/capacity, prior firstcause, physical unavailable crossprovider ByteArray storage probes; no external process/env/fs/provider ingress or invented expression backend.',
'Full dictionary scope fixture control and same-original header/callback tests read:64 selected C rows, fixed source/hex expected and real trace operations; no original interpreter launched. Included fixture provenance remains separate validation obligation.',
'Full Jim Info literal forwarded-command controls read: actual mutable registration/replacement/rename/currentnamespace and command argv observer,18 fixed fixture outcomes; no original provider launch. This software observer does not prove CObjType getter/native fullframe/count parity.',
'Whole shared command-retirement coordinator and local tests read: two pure enum stages in actualselected order, exact full first error propagation. Fixed callbacks append to local Vec only, no interpreter/OS/provider operation.'
]
f=ROOT/'runtime-inline-operational-census.json';d=json.loads(f.read_text());cov=json.loads((ROOT/'runtime-file-coverage.json').read_text());out=[]
for p,note in zip(files,notes):
 r=next(x for x in d['files'] if x['path']==p);r['inline_or_test_support_status']='source_local_operational_ingress_reviewed';r['whole_file_operational_review']='local_ingress_closed';r['reason']=note;r['actual_review_segments']=[[1,len((SRC/p).read_text().splitlines())]]
 for site in r['candidate_operational_sites']:site['review_status']='actual_source_read';site['disposition']='see_file_purpose_receipt'
 cr=next(x for x in cov['files'] if x['path']==p);cr['operational_annex']['status']=r['inline_or_test_support_status'];cr['whole_file_review_status']='production_and_local_operational_ingress_read';out.append({'path':p,'sourceSHA':r['sourceSHA'],'reason':note,'segments':r['actual_review_segments']})
atomic_write(f,json.dumps(d,indent=2)+'\n');atomic_write(ROOT/'runtime-file-coverage.json',json.dumps(cov,indent=2)+'\n');atomic_write(ROOT/'runtime-work/inline-review05.json',json.dumps({'baseline':d['baseline'],'files':out,'execution':'None; actual source-only review'},indent=2)+'\n')
