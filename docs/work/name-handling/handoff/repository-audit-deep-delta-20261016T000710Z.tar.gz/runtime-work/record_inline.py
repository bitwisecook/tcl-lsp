from record import *
def batch(number,notes):
 files=json.loads((ROOT/f'runtime-work/inline-batch{number}-paths.json').read_text());assert len(files)==len(notes)
 f=ROOT/'runtime-inline-operational-census.json';d=json.loads(f.read_text());cov=json.loads((ROOT/'runtime-file-coverage.json').read_text());out=[]
 for p,(status,note) in zip(files,notes):
  r=next(x for x in d['files'] if x['path']==p);r.update(inline_or_test_support_status=status,whole_file_operational_review='local_ingress_closed' if status=='source_local_operational_ingress_reviewed' else 'local_body_read_callee_pending',reason=note,actual_review_segments=[[1,len((SRC/p).read_text().splitlines())]])
  for site in r['candidate_operational_sites']:site.update(review_status='actual_source_read',disposition='see_file_purpose_receipt')
  cr=next(x for x in cov['files'] if x['path']==p);cr['operational_annex']['status']=status;cr['whole_file_review_status']='production_and_local_operational_ingress_read' if status=='source_local_operational_ingress_reviewed' else 'local_body_read_external_callee_pending';out.append({'path':p,'sourceSHA':r['sourceSHA'],'status':status,'reason':note,'segments':r['actual_review_segments']})
 atomic_write(f,json.dumps(d,indent=2)+'\n');atomic_write(ROOT/'runtime-file-coverage.json',json.dumps(cov,indent=2)+'\n');atomic_write(ROOT/f'runtime-work/inline-review{number}.json',json.dumps({'baseline':d['baseline'],'files':out,'execution':'None; actual source-only review'},indent=2)+'\n')
