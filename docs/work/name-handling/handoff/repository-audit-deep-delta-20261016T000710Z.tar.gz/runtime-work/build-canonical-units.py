from record import *
import runpy
C=runpy.run_path(str(ROOT/'runtime-work/canonical-decisions.py'))
FAMILIES,MERGES,KIND_OVERRIDES,EXTERNAL_SHARED_REPAIRS=[C[k] for k in ['FAMILIES','MERGES','KIND_OVERRIDES','EXTERNAL_SHARED_REPAIRS']]
from collections import Counter
from datetime import datetime,timezone
import re

def key(r):return r['path']+'::'+r['symbol']+'::'+r['site']
d=load();rows=d['consumers'];mapped={};units=[];family_rows=[];decided=set()
for family,effort,indices in FAMILIES:
 ids=[]
 for index in indices:
  assert index not in decided,(index,family);decided.add(index);r=rows[index];assert r['disposition']=='needs_migration',(index,r['symbol'],r['disposition']);originals=[index]+MERGES.get(index,[])
  for other in originals[1:]:assert rows[other]['disposition']=='needs_migration';assert rows[other]['path']==r['path'] and rows[other]['line']==r['line'];decided.add(other)
  kind=KIND_OVERRIDES.get(index,{'consumer_integration':'consumer_api_adoption','owner_extension':'shared_owner_repair','descriptor_metadata_or_target_schema':'metadata_schema','validation_only':'validation_infrastructure'}[r['work_kind']])
  uid='runtime:'+family+':'+str(index);ids.append(uid);sites=[]
  for i in originals:
   q=rows[i];s={'path':q['path'],'symbol':q['symbol'],'line':q['line'],'source_line':(SRC/q['path']).read_text().splitlines()[q['line']-1],'semantic_anchor':q['site'],'source_sha256':q['sourceSHA']}
   if not any(z['path']==s['path'] and z['line']==s['line'] for z in sites):sites.append(s)
  u={'id':uid,'source_owner':'runtime','work_kind':kind,'family_id':family,'purpose':r['symbol'],'code_change_sites':sites,'representation_and_context':r['context'],'existing_shared_api':r['sharedAPI'],'required_change':r['missingintegration'],'source_evidence':r['evidence'],'original_row_ids':[key(rows[i]) for i in originals],'original_indices':originals,'relative_effort':effort,'state':'source_confirmed_change_required_unimplemented','control_obligations':r['tests'] or ['Preserve original selectors/assertions/budgets and fail-closed source/provider/artifact guards. Exact original constructor/caller/frame/namespace/key/currentness/lifetime purpose must be tested before semantic acceptance.'],'affected_unchanged_callers':[],'limitations':'Explicit source-purpose proposal; not execution or migration acceptance. Family groups related shared owners, units retain actual separately changed boundaries; no duration implied.'}
  if family in ['metadata.generated-identifier-scaffold','report.selected-command-variable-qualification']:u['control_obligations']=['Preserve actual selected counter/home/token/generation/lifecycle independently of rendered bytes; shared construction/report serializer parity and source configuration controls.']+r['tests']
  if r.get('native_gap_countable') is False:u['native_gap_countable']=False
  if index==132:u['deduplication_reason']='Rows132/852 are exact same state_traits1370 namespace-variable report constructor; no second repair.'
  if index==65:u['scope_note']='Existing Unicode Env/Filesystem/Process interfaces may remain purpose-limited; add actual OS/selected encoding facets only for genuine Native consumers. Provider adapters and original executable lifetime remain separate actual sites; no blanket Unicode-wrapper rewrite.'
  if index==6:u['affected_source_methods']=['exists','metadata','symlink_metadata','read','write','rename','copy','link','set_times'];u['scope_note']='One NativeFs actual native-path producer facet; listed Unicode methods are existing extension seams, not nine independently proved Native encoding recipes or nine owner repairs.'
  if kind=='validation_infrastructure':u['control_obligations']=['Genuine fresh/context/ownership discriminator and unchanged independent original observations; no source-only setup success or process0-to-Guest success inference.']+r['tests']
  units.append(u)
  for i in originals:mapped[key(rows[i])]={'row_index':i,'canonical_state':'requires_code_change','unit_ids':[uid]}
 family_rows.append({'id':family,'unit_ids':ids,'relative_scope':effort})
nochange=[];questions=[];validation=[];pending=[]
for i,r in enumerate(rows):
 k=key(r)
 if k in mapped:continue
 if r['disposition']=='needs_migration':pending.append({'index':i,'row_id':k,'sourceSHA':r['sourceSHA'],'context':r['context'],'requirement':r['missingintegration'],'state':'canonical_boundary_family_sites_not_yet_individually_mapped'});continue
 if r['disposition'] in ['pending_audit','pending_validation']:
  q={'row_id':k,'row_index':i,'source_sha256':r['sourceSHA'],'state':r['disposition'],'question':r['missingintegration'],'context':r['context'],'existing_api':r['sharedAPI']};questions.append(q);mapped[k]={'row_index':i,'canonical_state':'explicit_unresolved_source_or_provider_requirement'}
 elif r['disposition']=='migrated_validation_pending':
  assert r.get('legacy_state_review');validation.append({'row_id':k,'row_index':i,'source_sha256':r['sourceSHA'],'implemented_purpose':r['context'],'remaining_validation_or_separate_boundary':r['missingintegration'],'individual_interpretation':r['legacy_state_review'],'controls':r['tests'],'execution':'none donated'});mapped[k]={'row_index':i,'canonical_state':'implemented_existing_purpose_execution_validation_pending'}
 else:
  nochange.append({'row_id':k,'row_index':i,'source_sha256':r['sourceSHA'],'disposition':r['disposition'],'actual_purpose':r['context'],'reason':r['missingintegration']});mapped[k]={'row_index':i,'canonical_state':'existing_shared_owner_or_display_or_excluded_purpose_no_additional_code_change'}
out={'baseline':d['baseline'],'utc':datetime.now(timezone.utc).isoformat(),'status':'IN_PROGRESS explicit Runtime canonical source-purpose mapping; all assigned production examined, operational/source-helper closure and remaining canonical mappings underway. No final remaining count.','source_rows_sha256':hashlib.sha256((ROOT/'runtime-consumers.json').read_bytes()).hexdigest(),'remaining_consumer_total':None,'area_counts':None,'selected_scope_counts':{'reviewed_change_units':len(units),'original_needs_rows_mapped':len(decided),'remaining_needs_rows_unmapped':len(pending),'by_work_kind':dict(Counter(u['work_kind'] for u in units))},'units':units,'families':family_rows,'external_shared_repairs':EXTERNAL_SHARED_REPAIRS,'original_row_mapping':mapped,'no_additional_change':nochange,'unresolved_questions':questions,'validation_obligations':validation,'unmapped_confirmed_change_rows':pending,'count_contract':'COUNT-UNITS.md','limits':'Source-only audit; no source/test/provider/build/Git mutation. Actual fixed or original oracle data remain independent; no Native/source/absence/frame/key/Normal authority from reports, receipts, tests, or unexecuted controls.'}
atomic_write(ROOT/'runtime-migration-units.json',json.dumps(out,indent=2)+'\n');print(out['selected_scope_counts'])
