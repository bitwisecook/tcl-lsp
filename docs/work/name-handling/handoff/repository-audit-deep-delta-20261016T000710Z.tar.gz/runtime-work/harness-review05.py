from record import *
qf=ROOT/'runtime-work/fixture-harness-review-queue.json';q=json.loads(qf.read_text());paths=json.loads((ROOT/'runtime-work/harness-batch07-paths.json').read_text());cov=json.loads((ROOT/'runtime-file-coverage.json').read_text());out=[]
notes=[
('original_source_excerpt','Whole9.1 configure read-all window read: real target/context, argument parity, retained original property name table, getter/current result dictionary publication. Partial original function independent source window, no executable or current Native grant.'),
('original_source_excerpt','Whole9.0 configure read-all window read: same actual target/list schedule, original version String name passed to ReadProperty. Partial original source only; not transplanted into Rust or asserted executed.'),
('original_source_excerpt','Whole9.0 single/multiple configure source window read: selected temporary property-name table, first error stop/reset/release. Original independent source with no provider/current callable authority.'),
('original_provider_probe','Whole opaque-property probe read: actual Tcl_FindExecutable/CreateInterp/Tcl_Init, unchecked initial setup Eval then checked EvalObjv counted names with FF/NUL, real q primary report. Only caller/build/environment can establish original version/library/Tcl_Init success and safe output; no execution by audit.'),
('original_provider_probe','Whole actual command-cache probe read: core CreateInterp/no Tcl_Init; actual private TclSetCmdNameObj symbol/cache struct read plus original-getter and no-getter paths, live type/cache/header reports. Private ABI/build/source purpose requires actual selected compile/provider pairing; no inferred public resolver grant.'),
('original_source_excerpt','Whole original OO export window read: genuine define context/facet, each actual original method operand, actual method flag creation/update and selected epoch bump. Independent original implementation excerpt, not a new runtime consumer.'),
('original_provider_probe','Whole upvar native callback probe read: genuine selected version callback registration/CreateInterp, actual List versus counted original alias name and ref/type snapshots across EvalObjv, true process guestcode. No Tcl_Init; provider/header/library/harness pairing remains capture caller obligation.'),
('original_source_excerpt','Whole original9.1 InfoObjectVars window read: object lookup before optional pattern getter, actual namespace var-table keys, live/namespace flags, skipped getter no-pattern and exact key List append. Independent original source; snippet contains next-function prose only, no execution acceptance.'),
('original_source_excerpt','Whole original8.6 AddObjErrorInfo function read: real legacy/private result selection, true errorCode default, COW and append only nonzero length. Independent original source evidence, not product consumer to migrate.'),
('original_source_excerpt','Whole original8.5 AddObjErrorInfo function read: original result/private errorInfo ownership, NONE default and shared-object duplicate/append. Independent original source purpose, no current selected build/execution grant.'),
('original_source_excerpt','Previously fully read original9.0 GetPropertyName window: genuine property List/cached copy, Tcl_GetIndexFromObjStruct uses TCL_INDEX_TEMP_TABLE; opposite direction miss diagnostic Save/Restore, selected actual table cleanup. Does not establish persistent enum cache install requirement.'),
('original_source_excerpt','Previously fully read original9.1 GetPropertyName window: actual same temporary table/pointer/source result schedule with version-specific type. Pure Rust roster+origin is not asserted full physical TEMP_TABLE equivalence; independent original evidence only.')
]
for p,(purpose,reason) in zip(paths,notes):
 x=next(x for x in q['files'] if x['path']==p);ind=purpose=='original_source_excerpt';x.update(source_review_status='actual_full_source_read',review_representative=p,purpose=purpose,reason=reason,provider_context_status='independent_retained_excerpt_not_execution' if ind else 'capture_caller_pairing_review_pending',replay_acceptance='none')
 c=next(x for x in cov['files'] if x['path']==p);c.update(reviewmode='actual_full_source_read',reason=reason,source_review_status=x['source_review_status'],provider_context_status=x['provider_context_status'])
 if ind:c['classification']='retained_original_provider_source_excerpt_reviewed'
 out.append(dict(x))
# Equality reuse only complete exact blob+byte correspondence to genuinely read source.
by_blob={x['blob']:x for x in q['files'] if x.get('source_review_status')=='actual_full_source_read'}
for x in q['files']:
 if x.get('source_review_status') or x['blob'] not in by_blob:continue
 y=by_blob[x['blob']];assert (SRC/x['path']).read_bytes()==(SRC/y['path']).read_bytes()
 x.update({k:y[k] for k in ['purpose','reason','provider_context_status','replay_acceptance']});x.update(source_review_status='exact_blob_duplicate_of_actual_read',review_representative=y['path']);c=next(z for z in cov['files'] if z['path']==x['path']);c.update(reviewmode=x['source_review_status'],reason='Exact complete blob/byte duplicate of actual-read '+y['path']+'. '+y['reason'],source_review_status=x['source_review_status'],provider_context_status=x['provider_context_status'])
 if y['purpose']=='original_source_excerpt':c['classification']='retained_original_provider_source_excerpt_reviewed'
 out.append(dict(x))
atomic_write(qf,json.dumps(q,indent=2)+'\n');atomic_write(ROOT/'runtime-file-coverage.json',json.dumps(cov,indent=2)+'\n');atomic_write(ROOT/'runtime-work/harness-source-review05.json',json.dumps({'baseline':q['baseline'],'files':out,'execution':'None; independent source read only'},indent=2)+'\n');print(len(out),'new source-bound paths')
