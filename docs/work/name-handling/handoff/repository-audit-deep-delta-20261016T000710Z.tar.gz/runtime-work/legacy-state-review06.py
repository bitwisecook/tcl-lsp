from record import *
notes={
532:'Actual concat real originalargv/List/header/currentoperation using workers integrated through cleanup; lexical concat selection remains separate semantic purpose.',
533:'Actual concatfirst borrower versus abstractseries fresh temporary and selected resultstorage producer exist; parentprimary/nestedgetter gap recorded separately not silentlyaccepted.',
540:'Actual Array/ArrayMake classifier preserves originalstackheader versus genuinecompiledslot and realexistinglookup; source/opcode metadata notnativepermission.',
541:'Actual C arrayset root beforeparity and C85copiedList/C84refetch keyfirstowner schedules integrated; nestedcaller transport specificgap separately542.',
543:'Actual Jim arrayset parity/List then genuine preparedunsharedDictionaryCOW/publication owner implemented; sourceInfo data notNativegrant.',
545:'Actual installed mathfunc command enters selected kernelidentity, standalone nointerp fallback separate; tail/lowercase identity debt separatelycmd_mathfunc.',
546:'Actual entered numericenvironment/scalar versus standalone magnitudes sharedowner; common nestedString seam separatelyexproriginaloperand, no doubledkernel migration.',
547:'Actual F5 predicate providerexplicit admission and checkedUnicode operand pipeline present; appliance/version/phase originals remain unavailable independentproviderproof.',
553:'Actual private indexedappend realreceiver/source/neutralLifetime/OriginalArguments composes kernelstages and retains firstcause; supportedbackend charABI notarbitraryexternalbuild.',
556:'Actual compilednamespace string consumes trueartifactoperand/poolseparator and sharedUnicodeStringowner; physical compiler/provider/freshcontrols independent.',
557:'Actual compiledtrim consumes typedRegistry instruction/defaultpool and originalsubject/result worker; no defaultliteral duplication.',
558:'Actual chronological preparation uses sharedtypedvisitplan and Builderlocal/literal/script/expression producer; Builder fullproduction nowreviewed, source metadata notgenuinecompilepermission.',
561:'Actual NativeList parse/constructor uses sharednativegrammar and checked originalbacking adoption; Jim Sourceprimary/file/line separatebodypurpose.',
563:'Actual range/backing/layout/sharing owner integrated; abstractC9slicegenuinelyunavailable, incarnationadvance repair separatelyrecorded.',
564:'Actual namedcompiled invocation uses centralrecipe, genuine privatecommandliteral and late mutable dispatch/rewrite; parentartifact production nowreviewed, notexecuted.',
565:'Actual compiledOO Next retains class/argv/List/concat/gettercallback; parentOO/nativecontext production nowreviewed, realOOmethod/callchain acceptance separate.',
566:'Actual compiledError supplies genuine literaloptionkeys/message/code and selected realDictCOW/returnapply/result owner; no local namingparser.',
567:'Actual compiledscalar retained originaloperand/frame/List/String and C84Longresult recipe integrated; magnitude/count result notnameidentity.',
568:'Actual compiledmatch sharedexact/glob kernel with originalpattern/subject and genuinebooleanresult; surroundingparent production nowreviewed, noNativeexecutionproof.',
570:'Actual typed NativeMathOperator spelling maps shared mathkernel, realanonymouslocal separate; missing arithmeticbackendrefuses and numerictruth outside naming scope.',
572:'Actual compiledintrospection uses physicaltoken/result/queryowners, namespace CodeContextactualtoken distinctreport; parent artifact production nowreviewed, originalcontrols pending.',
573:'Actual retained JimScript tokeninventory/dictionarytuple retains realname/index/context beforeoldprimaryretirement; central dictionaryextent geometry only, no variablecellgrant.',
577:'Actual C9abstractList/arithmeticseries descriptor owns cache/index/result producer; numericdata owner not Tclsemanticnamereconstruction.',
588:'Actual OO lookup follows Importedsourcegeneration under finiteseenset to realOoId and trueobjectNsresultproducer; displayobjectname notselector.',
589:'Actual declaringOOprovider/namespace resolver installed in realmethodframe, shared selectedroot matcher against retaineddeclared originals; no fabricatedlocalalias.',
592:'Actual OOvariablemapping originaltarget/frame/allargv, reentrantreplacementretirement tokens and originalfirstuniqueentry stages use checkedsharedowner. Nativecontext fullproduction nowreviewed, noexecution.',
593:'Actual containertransition physicalstorage and neutralholds present, but admitted model-switch arraybytekey→freshDictionarykey Native purpose remains unresolved. Cannot call native transition semantics implemented from source-profile change alone; explicit source/provider question.',
595:'Actual enteredtable/frame/ledger/links/cells/currentness coordinator uses selectedphysicalhome, compatibilitybytes notoriginalnamecache authority; parent classify fullproduction nowreviewed.',
597:'Actual Jim alias local/cache/frame/cell publication and late targetname roles implemented with samephysicaltable and retirementchecks; parent classifier fullsource nowreviewed, noNativeacceptance.',
598:'Actual alias/cell replacement observations retain genuine Weak/binding/pointer roles and releaseoldmetadata beforepublication; no Stringinverse or extraNativepin.',
601:'Actual retained/detached array generation identityowner implemented; historicaldetacheddata intentionally distinctcurrentattachedsearch. Epoch/order issues separate.',
605:'Actual RMW receiver/pendingrealcellhold/frame/epochticket distinguishes selectedNative from authoredcounted dynamiccells; wrappingepoch and refusal-erasure sites separateknowncodework.',
607:'Actual compiledAppend/Cat RuntimeDictionaryChecks stages realreceiver/callback/getter/cleanup integration; full ValueOps parent production nowreviewed. Genuine issuer constraints remain separate, notDTOgrant.',
609:'Actual originalBoolean vs neutralresult protocols and selected realJimcontext sharekernelstageowner; commonuncheckednestedString/List issue separate. Parentproduction nowreviewed.',
612:'Actual nativeByteArray mandatoryselectedrecipe/backing/checkedbinaryadoption owner integrated; concreteuncheckedcompatbinary routes separate actualcallerpurpose.',
624:'Actual original ListIndex checkedadapter composes realcaller/header/backing/cache/resultcleanup; commonListconverterseam separate. No blanketretainedview/header-retirementsemanticclaim.',
625:'Actual original optionview producer exists, but retainedrawarray/window versus currentoriginalheader purpose at each reached original stage remains unresolved provider/schedule question; this cannot be migrated-validation-pending semanticclosure.',
626:'Actual compiledList/index caller retains bodyoperation/frame/output and operandcleanup currentness; genuineartifact and commonconverter issues independentlytracked, parentproduction nowread.',
628:'Actual compiled containerconversion captures realOriginalArgumentFrame and exact peroperandOriginalArguments/backings through nestedusingchecks; commonnestedString seam separate.',
629:'Actual selectedanonymous temporary failure is always terminal retainedHostrefusal, notfalseabsence despite .ok predicate; exact subordinatecause precision notgrantbug.',
630:'Actual Jim index operation carries genuine OriginalArguments and optional SourceConstruction, whose check also runs at check_index_operation. Puredata operations do not universally require namespace/frame identity; real Source purpose checks independent, no blanketguarddebt.',
631:'Only completed realStringRange kernel issues Sourceconstruction underactualroot/frame/yield correspondence; this is not Infofulltraversal/ImportNormal permission.',
636:'Actual shared badIndex lexicalgrammar/inputextent versus physicalerrorpublication independently selected; no localnamingparser, provider/coreABI acceptance separate.',
637:'Actual Jim alias target/framebirth/nameheader recursion selects/restores trueframe+Ns and checksoriginaltarget; no physicaltarget fromlinktext.',
639:'Actual Jim aliaspublication physicalargv/frame/cell/header finitecycle owner integrated; nestedneutralgetters need existingcallercontinuation repair separately recorded, nofulllifecycleacceptance.'
}
d=load();out=[]
for i,n in notes.items():
 r=d['consumers'][i];assert r['disposition']=='migrated_validation_pending',(i,r['symbol']);old=dict(r)
 if i in [593,625]:r['disposition']='pending_audit';r['missingintegration']=n;r['native_gap_countable']=False;r['work_kind']='consumer_integration';r['work_kind_reason']='Actual intended provider/current-view purpose unresolved; classify source question, no guessed code defect or integrated Native migration.'
 if i in [558,564,565,568,572,592,595,597,607,609,626]:r['missingintegration']=n+' Actual Native/provider controls remain unexecuted by audit.'
 r['legacy_state_review']={'batch':'runtime-work/legacy-state-review06.json','decision':r['disposition'],'reason':n};out.append({'index':i,'path':r['path'],'symbol':r['symbol'],'site':r['site'],'sourceSHA':r['sourceSHA'],'before_disposition':old['disposition'],'after_disposition':r['disposition'],'old_missingintegration':old['missingintegration'],'decision_reason':n})
atomic_write(ROOT/'runtime-consumers.json',json.dumps(d,indent=2)+'\n');atomic_write(ROOT/'runtime-work/legacy-state-review06.json',json.dumps({'baseline':d['baseline'],'scope':'45 individually interpreted legacy actualowner purposes; independent unresolved provider/viewquestions remain pending','rows':out,'execution':'None'},indent=2)+'\n');print(len(out),'reviewed,2 pending actualpurposequestions')
