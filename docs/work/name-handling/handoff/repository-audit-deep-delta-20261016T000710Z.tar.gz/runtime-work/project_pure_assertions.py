from record import *
import runpy,re,sys
K=runpy.run_path(str(ROOT/'vm-pure-assertions.py'),run_name='runtime_lexical_contract');masked=K['masked'];end_group=K['end_group'];pure=K['pure']
def project(p):
 s=(SRC/p).read_text();m=masked(s);selected=[]
 for z in re.finditer(r'#\s*\[\s*test\s*\]',m):
  rest=m[z.end():];sig=re.match(r'\s*(?:#\s*\[[^\]]*\]\s*)*(?:pub(?:\([^)]*\))?\s+)?(?:async\s+)?fn\s+(\w+)\s*\(',rest)
  if not sig:continue
  op=m.find('{',z.end()+sig.end());end=end_group(m,op)
  if not pure(m[op+1:end-1]):continue
  selected.append({'function':sig[1],'attribute_line':s[:z.start()].count('\n')+1,'start_byte':len(s[:op].encode()),'end_byte':len(s[:end].encode()),'start_line':s[:op].count('\n')+1,'end_line':s[:end].count('\n')+1,'body_sha256':hashlib.sha256(s[op:end].encode()).hexdigest(),'call_names':sorted(set(re.findall(r'\b([A-Za-z_]\w*)\s*\(',m[op+1:end-1]))),'mode':'exact Rust #[test] full assertion-only body lexical classification; all helper calls require actual source join before closure'})
 b=s.encode()
 for r in reversed(selected):b=b[:r['start_byte']]+('{ /* FIXED_ASSERTION_TEST '+r['function']+' */ }').encode()+b[r['end_byte']:]
 out=ROOT/'runtime-work/operational-projections'/p;out.parent.mkdir(parents=True,exist_ok=True);atomic_write(out,b.decode());atomic_write(out.with_suffix(out.suffix+'.pure.json'),json.dumps({'path':p,'sourceSHA':hashlib.sha256(s.encode()).hexdigest(),'projectionSHA':hashlib.sha256(b).hexdigest(),'classified_bodies':selected,'contract':'Reuses exact VM lexical contract, builtin Rust #[test] admission only. Balanced whole assertion macros; semantic constructors/getters/mutators rejected as contract. No whole-file/read/migration/provider/execution acceptance; retained source including all helpers/control/setup must actually be read, call_names joined before closure.'},indent=2)+'\n')
 return {'path':p,'source_bytes':len(s.encode()),'projection_bytes':len(b),'bodies':len(selected),'call_names':sorted(set(n for r in selected for n in r['call_names']))}
if __name__=='__main__':
 paths=sys.argv[1:] or [x['path'] for x in json.loads((ROOT/'runtime-inline-operational-census.json').read_text())['files'] if x['inline_or_test_support_status']=='pending_actual_read']
 result=[project(p) for p in paths];atomic_write(ROOT/'runtime-work/operational-projection-index.json',json.dumps(result,indent=2)+'\n');print('files',len(result),'bytes',sum(x['source_bytes'] for x in result),'projected',sum(x['projection_bytes'] for x in result),'tests',sum(x['bodies'] for x in result))
 for x in sorted(result,key=lambda x:x['source_bytes']-x['projection_bytes'],reverse=True)[:12]:print(x)
