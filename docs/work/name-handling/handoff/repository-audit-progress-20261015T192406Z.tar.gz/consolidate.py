from pathlib import Path
import json,hashlib,collections,datetime,subprocess,sys
D=Path(sys.argv[1] if len(sys.argv)>1 else '/workspace/name-session/full-consumer-audit');BASE='cc24c394004fc187378ba0eefb6c2c5b2615fb00'
manifest=json.loads((D/'baseline-files.json').read_text());assigned={r['path']:r for r in manifest['files']};allrows=[];areas=[];errors=[];inputs=[]
def get(r,*keys,default=None):
 for k in keys:
  if k in r:return r[k]
 return default
for who in ['compiler','db','lsp','runtime','vm','root','audit']:
 area={'owner':who,'assigned_paths':sum(r['owner']==who for r in assigned.values())}
 for kind in ['file-coverage','consumers']:
  f=D/f'{who}-{kind}.json';b=f.read_bytes();inputs.append({'path':f.name,'sha256':hashlib.sha256(b).hexdigest()})
  try:j=json.loads(b)
  except ValueError as e:errors.append({'owner':who,'kind':kind,'error':str(e)});continue
  if j.get('baseline')!=BASE:errors.append({'owner':who,'error':'wrong baseline'})
  rows=j.get('files' if kind=='file-coverage' else 'consumers',j.get('rows',[]))
  if kind=='file-coverage':
   paths=[r['path'] for r in rows];expected={p for p,r in assigned.items() if r['owner']==who}
   absent=sorted(expected-set(paths));extra=sorted(set(paths)-expected);duplicates=[p for p,c in collections.Counter(paths).items() if c>1]
   if absent or extra or duplicates:errors.append({'owner':who,'missing_paths':absent,'extra_paths':extra,'duplicate_paths':duplicates})
   area['coverage_rows']=len(rows);area['reported_review_modes']=dict(collections.Counter(str(get(r,'review_mode','reviewmode',default='unspecified')) for r in rows));area['reported_review_statuses']=dict(collections.Counter(str(get(r,'review_status',default='unspecified')) for r in rows))
   for r in rows:
    p=r['path'];blob=get(r,'blob','git_blob','baseline_blob')
    if blob and assigned.get(p,{}).get('blob')!=blob:errors.append({'owner':who,'path':p,'error':'baseline blob mismatch'})
  else:
   for i,r in enumerate(rows):
    p=r.get('path');symbol=get(r,'symbol','function');site=get(r,'site','site_purpose','purpose','naming_purpose',default='unspecified');dis=r.get('disposition')
    x={'review_owner':who,'path':p,'symbol':symbol,'site':site,'line':get(r,'line','definition_line'),'source_sha256':get(r,'source_sha256','sourceSHA','sha256'),'baseline_blob':assigned.get(p,{}).get('blob'),'disposition':dis,'shared_api':get(r,'shared_api','actual_shared_api','sharedAPI','shared_api_and_context','shared_api_context'),'missing_integration':get(r,'missing_integration','missingintegration','limits_or_missing_owner'),'work_kind':r.get('work_kind','not_yet_reconciled'),'reviewer_original_row':r}
    if p not in assigned:errors.append({'owner':who,'row':i,'error':'unknown path','path':p})
    elif assigned[p]['owner']!=who:errors.append({'owner':who,'row':i,'error':'cross-partition row requires deduplication','path':p,'assigned_owner':assigned[p]['owner']})
    if dis not in {'needs_migration','migrated_validation_pending','migrated_verified','shared_owner','display_only','out_of_scope'}:errors.append({'owner':who,'row':i,'error':'unknown disposition','disposition':dis})
    if not symbol or not isinstance(x['line'],int) or not x['source_sha256']:errors.append({'owner':who,'row':i,'error':'missing exact source location/hash','path':p})
    allrows.append(x)
   area['provisional_recorded_rows']=len(rows);area['provisional_dispositions']=dict(collections.Counter(r.get('disposition') for r in rows))
 areas.append(area)
# Validate only explicitly recorded source bindings; no status is promoted by hashing.
oids=sorted({r['baseline_blob'] for r in allrows if r['baseline_blob']});payload=('\n'.join(oids)+'\n').encode();raw=subprocess.check_output(['git','cat-file','--batch'],input=payload,cwd='/workspace/tcl-lsp');pos=0;hashes={}
for oid in oids:
 e=raw.index(b'\n',pos);head=raw[pos:e].decode().split();size=int(head[2]);start=e+1;b=raw[start:start+size];assert raw[start+size:start+size+1]==b'\n';hashes[oid]=hashlib.sha256(b).hexdigest();pos=start+size+1
for i,r in enumerate(allrows):
 if r['source_sha256'] and r['baseline_blob'] and r['source_sha256']!=hashes[r['baseline_blob']]:errors.append({'row':i,'owner':r['review_owner'],'path':r['path'],'error':'source SHA differs from actual baseline blob'})
keys=collections.defaultdict(list)
for i,r in enumerate(allrows):keys[(r['path'],r['symbol'],str(r['site']))].append(i)
duplicates=[{'key':list(k),'rows':v} for k,v in keys.items() if len(v)>1]
now=datetime.datetime.now(datetime.timezone.utc).isoformat();result={'baseline':BASE,'captured_utc':now,'status':'IN_PROGRESS_NOT_A_COMPLETE_CONSUMER_CENSUS','remaining_consumer_total':None,'reason':'Semantic file/purpose coverage incomplete; grouped/multi-symbol rows and shared-owner repairs require independent reconciliation. Provisional row counts are not remaining-consumer totals.','tracked_paths':len(assigned),'areas':areas,'input_artifacts':inputs,'binding_errors':errors,'duplicate_site_candidates':duplicates,'consumers':allrows,'validation':'Source inventory/review only; no test, provider, generator or repository-gate acceptance is inferred.'};(D/'consolidated-in-progress.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'areas':areas,'recorded_rows':len(allrows),'errors':errors,'duplicate_site_candidates':duplicates},indent=2))
