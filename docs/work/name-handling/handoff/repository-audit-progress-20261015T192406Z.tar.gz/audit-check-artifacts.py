import json,collections,hashlib,pathlib,subprocess,datetime
base=pathlib.Path('/workspace/name-session/full-consumer-audit');repo=pathlib.Path('/workspace/tcl-lsp');c=json.loads((base/'audit-file-coverage.json').read_text());s=json.loads((base/'audit-consumers.json').read_text());rows={r['path']:r for r in c['files']};errors=[];ids=set();sourcecache={};allowed={'needs_migration','migrated_validation_pending','migrated_verified','shared_owner','display_only','out_of_scope'}
def source(r):
 if r['path'] not in sourcecache:sourcecache[r['path']]=subprocess.check_output(['git','cat-file','blob',r['blob']],cwd=repo)
 return sourcecache[r['path']]
for q in s['consumers']:
 if q['id'] in ids:errors.append(['duplicate',q['id']])
 ids.add(q['id']);r=rows.get(q['path'])
 if not r:errors.append(['foreign',q['path']]);continue
 if q['source_sha256']!=r['source_sha256'] or q['blob']!=r['blob']:errors.append(['source',q['id']])
 if q['disposition'] not in allowed:errors.append(['disposition',q['id']])
 if not q['source_evidence']:errors.append(['missing_evidence',q['id']])
 if not(0<q['line']<=len(source(r).decode().splitlines())):errors.append(['line',q['id']])
worktree_drift=[]
for r in c['files']:
 if r['review_mode']=='whole_production_read':
  if hashlib.sha256(source(r)).hexdigest()!=r['source_sha256']:errors.append(['whole_source',r['path']])
  actual=hashlib.sha256((repo/r['path']).read_bytes()).hexdigest()
  if actual!=r['source_sha256']:worktree_drift.append({'path':r['path'],'baseline_sha256':r['source_sha256'],'current_worktree_sha256':actual})
qa={'baseline':c['baseline'],'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':len(rows),'modes':dict(collections.Counter(r['review_mode'] for r in c['files'])),'purpose_rows':len(s['consumers']),'dispositions':dict(collections.Counter(q['disposition'] for q in s['consumers'])),'errors':errors,'whole_review_current_worktree_drift':worktree_drift,'scope':'Artifact consistency and original baseline-byte source correspondence only; no source compilation, provider/generator execution, semantic or runtime acceptance.'};(base/'audit-artifact-qa.json').write_text(json.dumps(qa,indent=2)+'\n');print(json.dumps(qa,indent=2))
