from pathlib import Path
import sys
p=Path('/workspace/name-session/full-consumer-audit/db-production')/sys.argv[1]
a=int(sys.argv[2]) if len(sys.argv)>2 else 1;b=int(sys.argv[3]) if len(sys.argv)>3 else 10**9
for n,s in enumerate(p.read_text().splitlines(),1):
 if a<=n<=b and s.strip() and not (n<=18 and s.startswith('//')):print(f'{n}: {s.rstrip()}')
