from pathlib import Path
import json,hashlib,collections,datetime
r=Path('/workspace/name-session/full-consumer-audit');c=json.loads((r/'lsp-file-coverage.json').read_text());k=json.loads((r/'lsp-consumers.json').read_text());assigned=json.loads((r/'lsp-assigned-files.json').read_text());print(type(assigned).__name__)
rows=c['files'];assert len(rows)==1203;assert len({x['path'] for x in rows})==1203
allowed={'needs_migration','migrated_validation_pending','migrated_verified','shared_owner','display_only','out_of_scope'};ids=set()
for x in k['consumers']:
 assert x['id'] not in ids;ids.add(x['id']);assert x['disposition'] in allowed
 p=r/'lsp-baseline'/x['path'];s=p.read_bytes();assert hashlib.sha256(s).hexdigest()==x['source_sha256'];assert s.decode().splitlines()[x['line']-1].find(x['site'])>=0 or s.decode().find(x['site'])>=0
for x in rows:assert hashlib.sha256((r/'lsp-baseline'/x['path']).read_bytes()).hexdigest()==x['source_sha256'];assert set(x['consumer_ids'])<=ids
v=dict(baseline=c['baseline'],status='in_progress_not_complete',completion_claim=False,updated_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),files_total=len(rows),file_review_status=dict(collections.Counter(x['review_status'] for x in rows)),file_classifications=dict(collections.Counter(x['classification'] for x in rows)),consumers_total=len(k['consumers']),consumer_dispositions=dict(collections.Counter(x['disposition'] for x in k['consumers'])),validation='Audit artifact path/hash/site/unique-ID integrity only. No source edits, builds, tests or provider launches. Reviewed fixture manifest rows are not production migration completions.',remaining='Every unexamined or partially reviewed production/test/generated/guidance file remains unfinished; migrated_validation_pending carries no Rust/execution acceptance.')
(r/'lsp-progress.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v,indent=2))
