import json,hashlib,os,sys
from pathlib import Path
b=Path('/workspace/name-session/full-consumer-audit');work=b/'vm-category-correction-work';p=work/'remaining357-review-state.json';d=json.loads(p.read_text());batch=json.loads(Path(sys.argv[1]).read_text());units={u['id']:u for u in json.loads((work/'before-vm-migration-units.json').read_text())['units']}
for r in batch:
 assert r['id'] in d['pending'];u=units[r['id']];r['original_row_ids']=u['original_row_ids'];r['old_category']=u['work_kind'];r['old_sites']=u['code_change_sites'];r['old_required_change']=u['required_change'];r['actual_semantic_anchors']=[]
 for path,symbol,line in r.pop('anchors'):
  source=b/'vm-source'/path;data=source.read_bytes();lines=data.decode().splitlines();r['actual_semantic_anchors'].append({'path':path,'symbol':symbol,'line':line,'source_sha256':hashlib.sha256(data).hexdigest(),'source_line':lines[line-1]})
 r['basis']='Individual retained source-purpose/required-change review plus exact source semantic expressions; no source/test/provider execution; earlier declaration anchors are context only.';d['reviews'].append(r);d['pending'].remove(r['id'])
d['status']=f"{len(d['reviews'])}/246 additional actual semantic associations reviewed; frozen primary unchanged";tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(d,indent=2)+'\n');os.replace(tmp,p);print(d['status'])
