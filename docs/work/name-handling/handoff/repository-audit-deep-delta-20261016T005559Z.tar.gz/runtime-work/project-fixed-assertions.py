from record import *
import re,runpy,sys
vm=runpy.run_path(str(ROOT/'vm-pure-assertions.py'));masked=vm['masked'];end_group=vm['end_group']
def project(path):
 raw=(SRC/path).read_bytes();source=raw.decode();m=masked(source);selected=[]
 for hit in re.finditer(r'#\[test\]',m):
  sig=re.search(r'\bfn\s+([A-Za-z_]\w*)\s*\(',m[hit.end():]);assert sig
  a=hit.end()+sig.end();op=m.find('{',a);end=end_group(m,op);body=m[op+1:end-1]
  if not vm['pure'](body):continue
  calls=set(re.findall(r'\b([A-Za-z_]\w*)\s*\(',body))
  if calls-{'ok','err','run','as_bytes','as_slice','starts_with','is_empty','len','is_err','is_ok'}:continue
  if re.search(r'\b(?:Interp|Owned|obj|fs|env|Command|Native\w*)\b|::',body):continue
  selected.append({'function':sig.group(1),'physical_LF_lines':[source[:op].count('\n')+1,source[:end].count('\n')+1],'start_byte':len(source[:op].encode()),'end_byte':len(source[:end].encode()),'body_sha256':hashlib.sha256(source[op:end].encode()).hexdigest(),'callee_names':sorted(calls),'classification':'fixed_assertion_payload_structurally_classified_not_manually_semantic_read'})
 out=source
 for x in reversed(selected):
  a=len(raw[:x['start_byte']].decode());b=len(raw[:x['end_byte']].decode());out=out[:a]+'{ /* FIXED_ASSERTION_PAYLOAD '+x['function']+' */ }'+out[b:]
 q=ROOT/'runtime-work/operational-projections'/path;q.parent.mkdir(parents=True,exist_ok=True);atomic_write(q,out);receipt={'baseline':load()['baseline'],'path':path,'sourceSHA':hashlib.sha256(raw).hexdigest(),'projectionSHA':hashlib.sha256(out.encode()).hexdigest(),'classified_bodies':selected,'allowlist':'Only complete assert/eq/ne macro statements; only finite run/ok/err helpers +primitive byte display methods. No source/controller/helper/setup omitted. Actual cfg/Cargo and reached helper source remain required.','execution':'none'};atomic_write(q.with_suffix('.rs.fixed.json'),json.dumps(receipt,indent=2)+'\n');print(path,len(raw),len(out.encode()),len(selected),sorted(set(c for x in selected for c in x['callee_names'])))
if __name__=='__main__':project(sys.argv[1])
