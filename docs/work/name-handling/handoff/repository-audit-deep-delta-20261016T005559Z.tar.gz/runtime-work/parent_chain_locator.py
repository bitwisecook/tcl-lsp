from record import *
import re
# Locator only: actual matched declaration excerpts are separately inspected.
def locate(paths):
 wanted=set(paths);out={p:[] for p in wanted}
 for f in SRC.rglob('*.rs'):
  text=f.read_text();lines=text.splitlines();rel=str(f.relative_to(SRC))
  for n,line in enumerate(lines):
   m=re.match(r'\s*(?:pub(?:\([^)]*\))?\s+)?mod\s+([A-Za-z_][A-Za-z_0-9]*)\s*;',line)
   if not m:continue
   attrs=[]
   for old in reversed(lines[max(0,n-8):n]):
    if re.search(r'\bmod\b.*[;{]',old):break
    attrs.append(old)
   a='\n'.join(reversed(attrs));pm=re.search(r'#\[path\s*=\s*"([^"]+)"\]',a);name=m.group(1);bases=[f.parent,f.parent/f.stem,f.parent/f.stem/'tests']
   if f.stem in ['mod','lib','main']:bases=[f.parent,f.parent/'tests']
   for base in bases:
    candidates=[base/pm.group(1)] if pm else [base/(name+'.rs'),base/name/'mod.rs']
    for cand in candidates:
     try:p=str(cand.resolve().relative_to(SRC.resolve()))
     except ValueError:continue
     if p in wanted:
      item={'parent':rel,'line':n+1,'sourceSHA':hashlib.sha256(f.read_bytes()).hexdigest(),'excerpt':'\n'.join(lines[max(0,n-4):n+1]),'resolution':'exact #[path] child resolved against real module source directory' if pm else 'exact Rust module child/path under named parent or inline tests directory'}
      if item not in out[p]:out[p].append(item)
 return out
if __name__=='__main__':
 import sys
 reservation=json.loads((ROOT/sys.argv[1]).read_text());paths=[r['path'] for r in reservation['files']];found=locate(paths);atomic_write(ROOT/sys.argv[2],json.dumps({'baseline':reservation['baseline'],'status':'mechanical_source_declaration_locator_pending_actual_excerpt_admission','files':[{'path':p,'declarations':a} for p,a in found.items()]},indent=2)+'\n')
 for p in paths:
  print(p)
  for a in found[p]:print(a['parent'],a['line'],a['excerpt'])
