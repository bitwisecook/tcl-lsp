import runpy,re,json,datetime,collections
from pathlib import Path
B=Path('/workspace/name-session/full-consumer-audit');x=runpy.run_path(str(B/'audit-review-tools.py'));c,s=x['load']();by={r['path']:r for r in c['files']};cache={};prior=json.loads((B/'audit-source-anchor-review.json').read_text());changes=prior['changes'];unresolved=[]
# These current paths received independent whole source reads in this continuation.
ps=['rust/bigip-report-gen/python/python/f5report/'+p for p in ['certs.py','graph.py','report.py','render.py','__main__.py']]+['rust/bigip-report-gen/rust/src/'+p for p in ['certs.rs','apm.rs','security.rs','forensics.rs','bin/bigip-report-gen.rs']]+['rust/bigip-report-gen/frontend/src/pages/'+p for p in ['input.ts','print.ts','topology.ts']]+['rust/tcl-bigip-query/src/builtins/'+p for p in ['regex_str.rs','time_dt.rs']]
for z in s['consumers']:
 p=z['path']
 if p not in ps:continue
 if p not in cache:cache[p]=x['content'](by[p]).decode().splitlines()
 lines=cache[p];sym=z['symbol'];leaf=sym.split('::')[-1].split('.')[-1]
 # Explicit compound source-role grouping has no fake single function declaration.
 if sym=='PROFILE_LAYER/EVENT_PHASE':patterns=[r'\bvar PROFILE_LAYER\s*=']
 elif sym in {'sections-enumeration'}:patterns=[r'\bvar sections\s*=']
 elif sym=='parkInSheets.runner':patterns=[r'\bfunction runner\s*\(']
 elif sym=='initSearch.ipMatcher':patterns=[r'\bfunction ipMatcher\s*\(']
 elif sym=='buildFlowchart/renderInto/wire':patterns=[r'\bfunction buildFlowchart\s*\(']
 else:patterns=[r'\b(?:fn|def|function)\s+'+re.escape(leaf)+r'(?:<[^>]+>)?\s*\(',r'\b(?:const|var|let)\s+'+re.escape(leaf)+r'\s*(?::[^=]+)?=',r'^'+re.escape(leaf)+r'\s*(?::[^=]+)?=']
 hits=[i for i,t in enumerate(lines,1) if any(re.search(pat,t) for pat in patterns)]
 if len(hits)==1:
  i=hits[0]
  if i!=z['line']:changes.append({'id':z['id'],'path':p,'symbol':sym,'before_line':z['line'],'after_line':i,'source_line':lines[i-1],'source_sha256':z['source_sha256']});z['line']=i
  z['source_anchor_review']='Exact actual function/constant declaration reborrowed from immutable baseline blob after whole-source semantic read; purpose/behavior disposition unchanged.'
 else:unresolved.append({'id':z['id'],'symbol':sym,'existing_line':z['line'],'hits':hits,'reason':'Actual purpose may be nested/grouped/callsite-specific; no fabricated declaration selection.'})
x['save'](c,s);out={'baseline':c['baseline'],'reviewed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Correct one-based declaration anchors for newly whole-read source purposes. Not semantics or source validation, no production changes. Existing caller-specific/grouped anchors explicitly unresolved.','changes':changes,'unresolved':unresolved,'remaining_consumer_total':None};(B/'audit-source-anchor-review.json').write_text(json.dumps(out,indent=2)+'\n');print('changes',len(changes),'unresolved',len(unresolved));print(json.dumps(unresolved,indent=2))
