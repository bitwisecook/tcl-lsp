import json,hashlib,os
from pathlib import Path
R=Path('/workspace/name-session/full-consumer-audit');p=R/'vm-consumers.json';raw=p.read_bytes();d=json.loads(raw)
rs=[r for r in d['consumers'] if r['disposition']=='migrated_validation_pending' and not r.get('status_review')][:40]
assert rs[0]['id']=='vm-0501' and rs[-1]['id']=='vm-0603'
changes={
'vm-0556':('shared_owner','Existing VarArena cursor/table ledger owner supplies physical selected array enumeration plus shared handle policy; unchanged caller context obligations separate. Not an additional remaining migration.'),
'vm-0558':('pending_audit','Actual copy allocates fresh cells and table; intended Native static initializer original key/header constructor correspondence is not established by copying scalar values. Preserve explicit owner-purpose question.'),
'vm-0600':('needs_migration','Physical original fallback selection still receives native_invocation_dialect logical axis. Retain authored source policy separately and transport actual selected execution protocol/context into fallback recipe; do not blindly collapse logical and physical purposes.'),
'vm-0602':('pending_audit','Actual argv/header vector role is implemented, but inherited versus blank original EvalObjVector script/report frame is unresolved original-provider purpose; prior limited argv evidence cannot certify it.'),
'vm-0603':('pending_audit','Original-value sibling exists, but actual legacy display-name adapter callers require individual fresh-CString versus held-original purpose trace before asserting integration or a concrete migration.')}
out=[]
for r in rs:
 old=r['disposition']
 if r['id']=='vm-0506':r['line']=319
 if r['id']=='vm-0570':r['missing_integration']='Actual private storage spelling constructor now fully read at cmd_oo.rs3379 and separately needs_migration vm-0760/vm-0408. Lookup keeps actual selected creation ID/name/header; constructor repair can leave this lookup caller unchanged. Full Native stages remain unexecuted.'
 if r['id'] in changes:new,why=changes[r['id']];r['disposition']=new
 else:new=old;why='Bounded implemented component retained: '+r['context']+' Independent limit remains: '+r['missing_integration']
 r['status_review']={'receipt':'vm-status-reconciliation-resumed-05.json','previous':old,'current':new,'reason':why,'basis':'Individual actual source-purpose review, no execution or unresolved provider grant.'}
 out.append({'id':r['id'],'path':r['path'],'symbol':r['symbol'],'previous':old,'current':new,'reason':why})
(R/('vm-consumers-before-status05-'+hashlib.sha256(raw).hexdigest()[:12]+'.json')).write_bytes(raw)
for name,obj in [('vm-consumers.json',d),('vm-status-reconciliation-resumed-05.json',{'baseline':d['baseline'],'reviewed_rows':out,'scope':'40 individual legacy status rereviews; existing private-storage producer crossref clarified, function anchor corrected; no tests/providers executed'})]:
 q=R/name;t=q.with_suffix('.tmp');t.write_text(json.dumps(obj,indent=2)+'\n');os.replace(t,q)
