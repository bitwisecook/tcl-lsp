import json,hashlib,os
from pathlib import Path
R=Path('/workspace/name-session/full-consumer-audit');p=R/'vm-consumers.json';raw=p.read_bytes();d=json.loads(raw)
rs=[r for r in d['consumers'] if r['disposition']=='migrated_validation_pending' and not r.get('status_review')][:40]
assert rs[0]['id']=='vm-0697' and rs[-1]['id']=='vm-0799'
changes={
'vm-0697':('shared_owner','Existing authored static compilation context/observer producer; deliberately bounded to selected source phase and actual storage, not Native TMM event permission.'),
'vm-0701':('shared_owner','Existing actual authored static-domain journal owns resolved address/keys and values; not a report-to-cell inverse or a remaining API adoption.'),
'vm-0736':('needs_migration','Operand transport uses actual admitted compiler owner, but Namespace Code still builds local fixed namespace/inscope command literals. Move that naming metadata into existing selected Registry compiler recipe; no new dispatcher or String identity inverse.'),
'vm-0748':('pending_audit','Actual source extent and optional namespace context are retained; refusal-to-None versus explicit ConstructedPath replay purpose/incarnation correspondence remains unresolved, not validated by source formatting.'),
'vm-0752':('needs_migration','Actual counted method key/reverse identity map is sound, but local opaque-storage prefix/counter naming policy remains consumer-owned. Centralize proposed generated storage spelling under existing shared naming generation owner while retaining table collision, counter and original byte mapping guards; no reproduced identity collapse asserted.'),
'vm-0790':('shared_owner','Existing Value snapshot/cache representation owner rejects unsupported live physical caches; representation DTO is intentionally not live identity/currentness authority. Concrete bridge consumers separate.'),
'vm-0791':('shared_owner','Existing checked original duplicate/neutral duplicate owner purposes are explicit. Actual caller selection and outer namespace/frame transport remain consumer integrations, not authority inferred from this owner.'),
'vm-0792':('shared_owner','Existing actual Jim Source body/filename/context constructor and metadata owner, distinct from caller source execution and Import traversal. No remaining owner repair established here.'),
'vm-0794':('shared_owner','Existing original String/compound updater owner accepts per-stage caller hook; caller omission is separately audited. Retained data versus current header purpose stays distinct.'),
'vm-0796':('shared_owner','Existing bytecode/Substitution storage owner requires admitted native_cache and distinct body/context roles; actual current artifact/source/frame consumer joins are separate obligations. Stored cache presence alone gives no execution grant.'),
'vm-0797':('shared_owner','Existing selected scalar/number/cache/provider getter owner; neutral variants intentionally lack interpreter/frame witness. Actual caller adoption remains independently counted.'),
'vm-0799':('shared_owner','Existing original List/Dictionary conversion/backing owner supplies scoped checked APIs; bare exported Vec is owned data. Consumers must choose authentic original window/search projection where required; no blanket extension from Vec purpose alone.')}
out=[]
for r in rs:
 old=r['disposition']
 if r['id'] in changes:new,why=changes[r['id']];r['disposition']=new
 else:new=old;why='Bounded implemented component retained: '+r['context']+' Independent limit remains: '+r['missing_integration']
 if new=='shared_owner':r['work_kind']='existing_shared_owner';r['work_kind_reason']=why
 if r['id'] in ['vm-0736','vm-0752']:r['work_kind']='metadata_schema';r['work_kind_reason']=why
 r['status_review']={'receipt':'vm-status-reconciliation-resumed-07.json','previous':old,'current':new,'reason':why,'basis':'Individual actual source-purpose review, no execution or unresolved provider grant.'}
 out.append({'id':r['id'],'path':r['path'],'symbol':r['symbol'],'previous':old,'current':new,'reason':why})
(R/('vm-consumers-before-status07-'+hashlib.sha256(raw).hexdigest()[:12]+'.json')).write_bytes(raw)
for name,obj in [('vm-consumers.json',d),('vm-status-reconciliation-resumed-07.json',{'baseline':d['baseline'],'reviewed_rows':out,'scope':'40 individual legacy status rereviews; no tests/providers executed'})]:
 q=R/name;t=q.with_suffix('.tmp');t.write_text(json.dumps(obj,indent=2)+'\n');os.replace(t,q)
