import json,hashlib,os
from pathlib import Path
R=Path('/workspace/name-session/full-consumer-audit');p=R/'vm-consumers.json';raw=p.read_bytes();d=json.loads(raw)
rs=[r for r in d['consumers'] if r['disposition']=='migrated_validation_pending' and not r.get('status_review')]
assert len(rs)==20 and rs[0]['id']=='vm-0882' and rs[-1]['id']=='vm-0934'
changes={
'vm-0900':('shared_owner','Existing actual captured variable/cell mutation and mandatory original cleanup kernel. QuietWrite/original operand purpose are provided; missing original in selected callers is an independent integration, not implicit authority in kernel.'),
'vm-0907':('shared_owner','Existing actual original Jim error-frame/command/header snapshot capture and publication-ticket owner. Its source metadata does not donate physical frame/callback/provider parity to consumers.'),
'vm-0916':('shared_owner','Existing actual fixed-function table/prerequisite producer enumerates real registrations and generations under interpreter identity; mutable ordinary command names cannot issue these entries. Original provider validation remains independent.')}
out=[]
for r in rs:
 old=r['disposition']
 if r['id'] in changes:new,why=changes[r['id']];r['disposition']=new;r['work_kind']='existing_shared_owner';r['work_kind_reason']=why
 else:new=old;why='Bounded implemented component retained: '+r['context']+' Independent limit remains: '+r['missing_integration']
 r['status_review']={'receipt':'vm-status-reconciliation-resumed-09.json','previous':old,'current':new,'reason':why,'basis':'Individual actual source-purpose review; complete interpreter actual-read closure, no execution/provider acceptance.'}
 out.append({'id':r['id'],'path':r['path'],'symbol':r['symbol'],'previous':old,'current':new,'reason':why})
(R/('vm-consumers-before-status09-'+hashlib.sha256(raw).hexdigest()[:12]+'.json')).write_bytes(raw)
for name,obj in [('vm-consumers.json',d),('vm-status-reconciliation-resumed-09.json',{'baseline':d['baseline'],'reviewed_rows':out,'scope':'Final20 individual legacy status rereviews; all current migrated_validation_pending rows now have individual status_review; no tests/providers executed'})]:
 q=R/name;t=q.with_suffix('.tmp');t.write_text(json.dumps(obj,indent=2)+'\n');os.replace(t,q)
