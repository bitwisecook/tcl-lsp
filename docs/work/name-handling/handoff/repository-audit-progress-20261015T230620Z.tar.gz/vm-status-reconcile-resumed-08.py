import json,hashlib,os
from pathlib import Path
R=Path('/workspace/name-session/full-consumer-audit');p=R/'vm-consumers.json';raw=p.read_bytes();d=json.loads(raw)
rs=[r for r in d['consumers'] if r['disposition']=='migrated_validation_pending' and not r.get('status_review')][:30]
assert rs[0]['id']=='vm-0800' and rs[-1]['id']=='vm-0877'
changes={
'vm-0800':('shared_owner','Existing selected character/Unicode/CString physical storage getter owner with explicit checked caller hooks; old logical compatibility accessors have separate contract. Actual caller choice remains independently audited.'),
'vm-0802':('shared_owner','Existing prepared List storage mutation/copy/COW kernel owns exact backing/window/header purpose. Consumers supply real receiver/provider/caller authority; kernel contract itself is not an unfinished consumer migration.')}
out=[]
for r in rs:
 old=r['disposition']
 if r['id']=='vm-0805':r['missing_integration']='Complete interpreter birth/child/reconfiguration/retirement source inventory now read at cc24; selected invalidation/resource integration remains source-only and does not re-key published names or grant physical execution from authored profile. Original lifecycle execution/reference/callback validation remains unaccepted.'
 if r['id']=='vm-0814':r['missing_integration']='Complete downstream finalizer/resource/child birth source bodies now actually read. Actual InterpId/restoration joins are source-integrated; full original provider callback/destructor/reference order remains independently unexecuted, not inferred from retained path labels.'
 if r['id'] in changes:new,why=changes[r['id']];r['disposition']=new;r['work_kind']='existing_shared_owner';r['work_kind_reason']=why
 else:new=old;why='Bounded implemented component retained: '+r['context']+' Independent limit remains: '+r['missing_integration']
 r['status_review']={'receipt':'vm-status-reconciliation-resumed-08.json','previous':old,'current':new,'reason':why,'basis':'Individual actual source-purpose review; all interpreter production source closed, no execution/provider acceptance.'}
 out.append({'id':r['id'],'path':r['path'],'symbol':r['symbol'],'previous':old,'current':new,'reason':why})
(R/('vm-consumers-before-status08-'+hashlib.sha256(raw).hexdigest()[:12]+'.json')).write_bytes(raw)
for name,obj in [('vm-consumers.json',d),('vm-status-reconciliation-resumed-08.json',{'baseline':d['baseline'],'reviewed_rows':out,'scope':'30 individual legacy status rereviews; stale actual-source-unread wording corrected, no tests/providers executed'})]:
 q=R/name;t=q.with_suffix('.tmp');t.write_text(json.dumps(obj,indent=2)+'\n');os.replace(t,q)
