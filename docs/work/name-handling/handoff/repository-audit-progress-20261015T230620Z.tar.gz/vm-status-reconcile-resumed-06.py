import json,hashlib,os
from pathlib import Path
R=Path('/workspace/name-session/full-consumer-audit');p=R/'vm-consumers.json';raw=p.read_bytes();d=json.loads(raw)
rs=[r for r in d['consumers'] if r['disposition']=='migrated_validation_pending' and not r.get('status_review')][:40]
assert rs[0]['id']=='vm-0605' and rs[-1]['id']=='vm-0694'
changes={
'vm-0631':('pending_audit','Genuine original link owner is called, but post-scope-entry early failure paths and mandatory finish/lease cleanup correspondence remain unresolved; completed integration cannot be inferred from caller presence.'),
'vm-0637':('pending_audit','Character and List materialization source/logical versus physical protocol purposes differ; exact selected indexed command purpose/context transport remains unestablished.'),
'vm-0639':('pending_audit','Fresh byte compatibility constructor is explicit, but actual callers still need fresh-input versus already-held-original/cache purpose census. No blanket Native grant or concrete missing extension asserted.'),
'vm-0652':('pending_audit','Actual key/display separation is correct; retained command generation across mandatory prior deletion callbacks remains unresolved, not an unexecuted complete batch lifecycle integration.'),
'vm-0666':('shared_owner','Existing compound/dictionary recursive currency owner checks exact original root/header and selected protocol. Consumer-specific frame/namespace belongs callers; generic currency does not pretend to supply it.'),
'vm-0668':('shared_owner','Existing selected numeric/ABI/Host stage owner; same caller frame/name joins are separate consumers. No new repair at this owner established from its intentionally narrower contract.'),
'vm-0669':('display_only','Structured byte/UTF16 source range alongside display label; no runtime naming identity or execution permission. Actual navigation correspondence separately owned.'),
'vm-0672':('display_only','UI source advice/availability rendering preserves unavailable versus no advice; no edit/execution/physical name authority. Underlying analysis/current source owner separate.'),
'vm-0688':('shared_owner','Existing ValueOps physical scalar/value ingress owner selects actual provider and keeps authored simulation explicit; consumer-specific original frame/argv contract remains separate.')}
out=[]
for r in rs:
 old=r['disposition']
 if r['id'] in changes:new,why=changes[r['id']];r['disposition']=new
 else:new=old;why='Bounded implemented component retained: '+r['context']+' Independent limit remains: '+r['missing_integration']
 r['status_review']={'receipt':'vm-status-reconciliation-resumed-06.json','previous':old,'current':new,'reason':why,'basis':'Individual actual source-purpose review, no execution or unresolved provider grant.'}
 out.append({'id':r['id'],'path':r['path'],'symbol':r['symbol'],'previous':old,'current':new,'reason':why})
(R/('vm-consumers-before-status06-'+hashlib.sha256(raw).hexdigest()[:12]+'.json')).write_bytes(raw)
for name,obj in [('vm-consumers.json',d),('vm-status-reconciliation-resumed-06.json',{'baseline':d['baseline'],'reviewed_rows':out,'scope':'40 individual legacy status rereviews; no tests/providers executed'})]:
 q=R/name;t=q.with_suffix('.tmp');t.write_text(json.dumps(obj,indent=2)+'\n');os.replace(t,q)
