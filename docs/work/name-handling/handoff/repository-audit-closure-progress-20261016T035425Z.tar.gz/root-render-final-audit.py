from pathlib import Path
import collections,hashlib,json,sys
D=Path(__file__).parent
source=Path(sys.argv[1]);raw=source.read_bytes();d=json.loads(raw)
assert d['status']=='FINAL_SOURCE_AUDIT_RECONCILED'
assert d['source_role_closure_complete'] and d['semantic_join_complete']
assert not d['mechanical_binding_errors'] and not d['missing_lanes']
assert d['counts']['all_required_changes']==len(d['units'])
data=json.dumps(d,ensure_ascii=False).replace('&','\\u0026').replace('<','\\u003c').replace('>','\\u003e')
page=r'''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Naming audit — remaining work</title>
<style>body{font:16px/1.5 system-ui,sans-serif;margin:24px auto;max-width:1400px;padding:0 20px;background:#f6f8fb;color:#172b3a}h1{font-size:2rem}aside{padding:16px;background:#fff3d9;border-left:5px solid #ac6500}.cards{display:flex;gap:14px;flex-wrap:wrap;margin:20px 0}.card{background:white;padding:14px 20px;border:1px solid #c6d1de;min-width:150px}.num{font-size:2rem;font-weight:700}.muted,small{color:#516170}label{display:inline-block;margin:10px 14px 10px 0}input,select,button{font:inherit;border:1px solid #a1afba;border-radius:4px;padding:7px}input{width:340px}button{cursor:pointer;background:white}table{border-collapse:collapse;width:100%;background:white}th,td{border:1px solid #d3dce5;padding:10px;text-align:left;vertical-align:top;overflow-wrap:anywhere}th{background:#e8eef5}nav{display:flex;gap:15px;align-items:center;margin:15px 0}pre{white-space:pre-wrap;max-height:500px;overflow:auto;font:13px/1.5 ui-monospace,monospace}summary{cursor:pointer}.pill{font-size:12px;display:inline-block;border:1px solid #bdcbd8;border-radius:3px;padding:2px 6px;margin:4px 4px 4px 0}a{color:#0769a5}.flow{display:flex;align-items:center;gap:12px;flex-wrap:wrap}.flow span{padding:10px;background:#e2edf9;border:1px solid #9db5cd}.flow b{font-size:22px}td:first-child{width:19%}td:nth-child(2){width:42%}</style>
<h1>Naming centralisation: the remaining work</h1>
<p>Every reviewed place has a recorded disposition. The counts below measure actual changes still needed. One change means one integration boundary with a distinct purpose. A shared owner change is counted once; an adopter is counted separately when its code must change.</p>
<div class="cards" id="cards"></div>
<aside><strong>Source audit complete does not mean implementation complete.</strong> Requirements that still need a provider answer or design decision are listed separately. Existing validation still needs execution. The repository gates and original #2286 acceptance remain separate.</aside>
<p id="basis"></p>
<div class="flow" aria-label="Naming integration architecture"><span>Original source or evaluated input<br><small>bytes, configuration and context</small></span><b>→</b><span>Existing shared owner<br><small>purpose-specific typed APIs</small></span><b>→</b><span>Actual consumer<br><small>retains ownership and currentness</small></span></div>
<p>Source spelling, evaluated names, namespace identities, command identities, variable cells and display labels are different things. A display string cannot recover an identity. A source receipt alone cannot authorise execution, editing, absence or normal completion.</p>
<table><thead><tr><th>Area</th><th>Semantic code changes</th><th>Validation code repairs</th><th>Authored documentation</th><th>Total changes</th></tr></thead><tbody id="areas"></tbody></table>
<p id="validation"></p>
<label>Search file, purpose or API<br><input id="search" type="search" placeholder="e.g. dialect, namespace, SSA, dictionary"></label><label>Area<br><select id="area"><option value="">All areas</option></select></label><label>Work kind<br><select id="kind"><option value="">All kinds</option></select></label><label>Relative scope<br><select id="effort"><option value="">All scopes</option></select></label>
<p id="matches" aria-live="polite"></p><nav><button id="prev">Previous</button><span id="pages"></span><button id="next">Next</button><button id="export">Export matching changes as JSON</button></nav>
<table><thead><tr><th>Area / work kind / scope</th><th>Exact boundary and purpose</th><th>Existing API / required change</th></tr></thead><tbody id="rows"></tbody></table>
<details><summary>Unresolved requirements and source/domain questions</summary><p>These have been examined. They are not silently counted as implementation migrations. Their possible changes and dependencies remain explicit.</p><pre id="questions"></pre></details>
<details><summary>Audit evidence, source coverage and validation limits</summary><pre id="evidence"></pre></details>
<p class="muted">S/M/L/XL describes relative change scope and coupling, not elapsed days. Source links use the immutable audit baseline. Later changes require rechecking the actual source and API.</p>
<script type="application/json" id="data">__DATA__</script>
<script>
const d=JSON.parse(document.getElementById('data').textContent),q=id=>document.getElementById(id),txt=x=>x==null?'':typeof x==='string'?x:JSON.stringify(x),size=50;
function el(tag,t,p){let n=document.createElement(tag);n.textContent=t;if(p)p.append(n);return n}
for(const [k,label] of [['semantic_code_changes','Semantic code changes'],['validation_code_repairs','Validation code repairs'],['authored_documentation','Documentation changes'],['all_required_changes','All required changes']]){let c=el('div','',q('cards'));c.className='card';el('div',d.counts[k].toLocaleString(),c).className='num';el('div',label,c)}
q('basis').textContent=`Baseline ${d.baseline}. Audited current source ${d.current_head}. Sealed ${d.utc}. Exact catalogue SHA256 __SHA__.`;
for(const [area,c] of Object.entries(d.counts.by_area)){let tr=el('tr','',q('areas'));for(const v of [area,c.semantic_code_changes,c.validation_code_repairs,c.authored_documentation,c.all_required_changes])el('td',String(v),tr)}
q('validation').textContent=txt(d.validation_status);
q('questions').textContent=JSON.stringify(d.unresolved_questions,null,2);q('evidence').textContent=JSON.stringify({inputs:d.inputs,source_role_closure:d.source_role_closure,owner_adopter_join:d.owner_adopter_join,limits:d.limits},null,2);
for(const k of ['area','kind','effort']){const field=k==='kind'?'report_work_kind':k;for(const v of [...new Set(d.units.map(u=>txt(u[field])))].sort()){let o=el('option',v||'(unspecified)',q(k));o.value=v}}
let matches=[],page=0;
function filter(){const term=q('search').value.toLowerCase();matches=d.units.filter(u=>(!q('area').value||u.area===q('area').value)&&(!q('kind').value||u.report_work_kind===q('kind').value)&&(!q('effort').value||u.effort===q('effort').value)&&(!term||[u.id,u.family,u.purpose,u.sites,u.api,u.required_change].map(txt).join(' ').toLowerCase().includes(term)));page=0;render()}
function render(){q('rows').replaceChildren();q('matches').textContent=`${matches.length.toLocaleString()} matching required changes.`;let pages=Math.max(1,Math.ceil(matches.length/size));q('pages').textContent=`Page ${page+1} of ${pages}`;q('prev').disabled=!page;q('next').disabled=page+1>=pages;for(const u of matches.slice(page*size,(page+1)*size)){let tr=el('tr','',q('rows')),a=el('td','',tr),b=el('td','',tr),c=el('td','',tr);el('strong',u.area,a);el('div',u.report_work_kind,a);el('span',u.effort||'scope pending',a).className='pill';el('small',u.id,a);el('strong',txt(u.purpose),b);for(const s of u.sites){let p=el('div','',b),l=el('a',`${s.path}:${s.line}`,p);l.href=`https://github.com/bitwisecook/tcl-lsp/blob/${d.baseline}/${s.path}#L${s.line}`;if(s.symbol||s.symbol_or_region)el('small',s.symbol||s.symbol_or_region,p)}el('strong','Existing shared API',c);el('div',txt(u.api),c);el('strong','Required change',c);el('div',txt(u.required_change),c);let detail=el('details','',c);el('summary','Exact source / dependency evidence',detail);el('pre',JSON.stringify(u,null,2),detail)}}
for(const k of ['search','area','kind','effort'])q(k).addEventListener(k==='search'?'input':'change',filter);q('prev').onclick=()=>{page--;render()};q('next').onclick=()=>{page++;render()};q('export').onclick=()=>{let url=URL.createObjectURL(new Blob([JSON.stringify(matches,null,2)],{type:'application/json'})),a=el('a','');a.href=url;a.download='remaining-naming-changes.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)};filter();
</script></html>'''
page=page.replace('__DATA__',data).replace('__SHA__',hashlib.sha256(raw).hexdigest())
out=Path('/workspace/naming-audit.html');out.write_text(page)
assert json.loads(page.split('<script type="application/json" id="data">',1)[1].split('</script>',1)[0])==d
print(json.dumps(dict(artifact=str(out),bytes=out.stat().st_size,sha256=hashlib.sha256(out.read_bytes()).hexdigest(),counts=d['counts'])))
