"""Lossless source-bound lexical read projection; NO coverage or semantic admission."""
from pathlib import Path
import json,hashlib,importlib.util,bisect,datetime
D=Path(__file__).parent
sp=importlib.util.spec_from_file_location('lexical',D/'compiler-vm-operational-role-projection-tool.py'); lx=importlib.util.module_from_spec(sp);sp.loader.exec_module(lx)
h=lambda b:hashlib.sha256(b).hexdigest()
qp=D/'compiler-exact-operational-closure-queue.json';qb=qp.read_bytes();q=json.loads(qb)
# Exact reviewed item source only, not arbitrary callers or callee semantics.
helper_receipts=['compiler-root-helper-packet01-review.json','compiler-vm-helper-packet02-read.json','compiler-db-helper03-review.json','lsp-audit-compiler-helper05-source-receipt.json','compiler-helper04-source-review.json']
reviewed={};pins=[]
for name in helper_receipts:
 p=D/name;b=p.read_bytes();j=json.loads(b);pins.append({'path':name,'sha256':h(b)})
 def scan(v):
  if isinstance(v,dict):
   if all(k in v for k in ['path','source_sha256','start_byte','end_byte','full_item_sha256']):reviewed[(v['path'],v['source_sha256'],v['start_byte'],v['end_byte'])]=v
   for z in v.values():scan(z)
  elif isinstance(v,list):
   for z in v:scan(z)
 scan(j)
# Lexical read projection leaves all original operational code visible, apart from
# exact actually read helper items; every source literal carries exact original
# byte bounds/hash and original provider/input answer remains unaccepted.
files=[];alllines=[];literals=[];errors=[]
for f in q['rows']:
 try:
  p=Path(f['source']);b=p.read_bytes();assert h(b)==f['source_sha256']
  starts=[0]+[i+1 for i,c in enumerate(b) if c==10]; line=lambda a:bisect.bisect_right(starts,a)
  ranges=f.get('raw_omitted_ranges',[[1,len(b.splitlines())]])
  selected=[(starts[a-1],starts[z] if z<len(starts) else len(b)) for a,z in ranges]
  hs=[(a,z) for path,sha,a,z in reviewed if path==f['path'] and sha==h(b)]
  masked=bytearray(b);covered=set()
  for a,z in hs:
   assert (f['path'],h(b),a,z) in reviewed
   assert h(b[a:z])==reviewed[(f['path'],h(b),a,z)]['full_item_sha256']
   for n in range(a,z):
    if masked[n]!=10:masked[n]=32
   covered.update(range(line(a),line(z-1)+1))
  ls=[]
  for k,(kind,a,z) in enumerate(lx.lex(b)):
   if kind!='literal' or z-a<=100 or any(x<=a and z<=y for x,y in hs):continue
   if not any(a<y and x<z for x,y in selected):continue
   rec={'path':f['path'],'source_sha256':h(b),'ordinal':len(literals),'start_byte':a,'end_byte':z,'start_line':line(a),'end_line':line(z-1),'literal_sha256':h(b[a:z]),'role_status':'unadmitted_until_actual_parent_callee_and_input_output_role_review','bytes':z-a};literals.append(rec);ls.append(rec)
   for n in range(a,z):
    if masked[n]!=10:masked[n]=32
   # An unmistakable token placeholder at its source start, no altered syntax
   # is compiled/executed. Full reconstructible source remains immutable.
   label=('L'+str(rec['ordinal'])).encode();masked[a:a+len(label)]=label
  text=masked.decode('utf8');source_lines=text.splitlines();out=[]
  for a,z in ranges:
   for n in range(a,z+1):
    if n<=len(source_lines) and source_lines[n-1].strip():out.append(f'{n}: '+source_lines[n-1].strip())
  aid='\n'.join(out)+'\n';files.append({'path':f['path'],'source_sha256':h(b),'source':str(p),'ranges':ranges,'already_read_helper_items':len(hs),'projected_literal_ordinals':[l['ordinal'] for l in ls],'projected_code_lines':len(out),'aid_sha256':h(aid.encode()),'aid':aid,'coverage_admission':False})
 except Exception as e:errors.append({'path':f['path'],'error':repr(e)})
# Disjoint whole-path balanced read packets; not semantic/cfg/role admission.
packets=[[] for _ in range(6)];weights=[0]*6
for f in sorted(files,key=lambda f:-f['projected_code_lines']):
 i=min(range(6),key=lambda i:weights[i]);packets[i].append(f);weights[i]+=f['projected_code_lines']
index=[]
for i,fs in enumerate(packets,1):
 aid='\n'.join('\nACTUAL SOURCE '+f['path']+' '+f['source_sha256']+'\n'+f['aid'] for f in sorted(fs,key=lambda f:f['path']))
 ap=D/f'compiler-root-operational-role-matcher-packet{i:02}.txt';ap.write_text(aid)
 rows=[{k:v for k,v in f.items() if k!='aid'} for f in fs];op=D/f'compiler-root-operational-role-matcher-packet{i:02}.json';out={'baseline':q['baseline'],'queue_sha256':h(qb),'status':'RESERVED_SOURCE_READ_PROJECTION_NO_ADMISSION','helper_receipts':pins,'files':rows,'aid':ap.name,'aid_sha256':h(ap.read_bytes()),'aid_lines':len(aid.splitlines()),'projected_code_lines':weights[i-1],'literal_manifest':'compiler-root-operational-role-matcher-literals.json','limits':['Every executable call/control/assertion retained. Exact previously read helper items excluded only at actual pinned byte intervals.','Long literals are NOT admitted as data merely by lexical kind. Reviewer must read actual remaining parent/callee/source-specific input/output/provider role; uncertain/dynamic/code-generating role stays unresolved.','No current production/tests, provider, macros or original harness executed. No currentness, completeness, expected-answer or positive-control credit.','Non-function imports/statics/macros/constants and comments remain visible; attributes do not exempt test bodies.']};op.write_text(json.dumps(out,indent=2)+'\n');index.append({'packet':op.name,'sha256':h(op.read_bytes()),'files':len(fs),'aid_lines':out['aid_lines'],'projected_code_lines':weights[i-1]})
(D/'compiler-root-operational-role-matcher-literals.json').write_text(json.dumps({'status':'PINNED_LITERAL_SOURCE_ONLY_NOT_ROLE_ADMISSION','literals':literals},indent=2)+'\n')
(D/'compiler-root-operational-role-matcher-dispatch.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'queue_sha256':h(qb),'packets':index,'errors':errors,'coverage_promotions':0,'limits':'Source read aid, not a Rust resolver or semantic classifier. Every literal still requires exact parent-role admission.'},indent=2)+'\n');print(json.dumps({'packets':index,'errors':errors,'literal_spans':len(literals),'reviewed_helper_items':len(reviewed)}))
