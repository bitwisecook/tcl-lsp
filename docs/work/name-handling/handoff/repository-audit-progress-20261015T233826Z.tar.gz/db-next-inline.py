import pathlib,json,runpy,sys
r=pathlib.Path('/workspace/name-session/full-consumer-audit')
prior=int(sys.argv[1]);count=int(sys.argv[2]) if len(sys.argv)>2 else 5
if prior and not (r/f'db-complete-inline-source-read-batch{prior}.json').exists():runpy.run_path(str(r/'db-record-inline-complete.py'))['record'](f'db-complete-inline-source-read-batch{prior}.json',json.loads((r/f'db-next-inline-batch{prior}.json').read_text()))
rows=[]
for x in json.loads((r/'db-file-coverage.json').read_text())['files']:
 if x['review_status']=='production_reviewed_inline_tests_pending':
  a=(r/'db-baseline'/x['path']).read_text().splitlines();b=(r/'db-production'/x['path']).read_text().splitlines();m=[(i+1,s)for i,s in enumerate(a)if s.strip()and(i>=len(b)or not b[i].strip())];rows.append((len(m),x['path'],m))
rows.sort();sel=rows[:count];atomic=runpy.run_path(str(r/'db-record.py'))['atomic'];atomic(r/f'db-next-inline-batch{prior+1}.json',json.dumps([x[1]for x in sel],indent=2)+'\n')
for n,p,lines in sel:
 print('\nFILE',p,'OMITTED',n)
 for i,s in lines:print(f'{i}:{s.strip()}')
