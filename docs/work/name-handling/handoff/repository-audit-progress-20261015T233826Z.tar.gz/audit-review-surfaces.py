import runpy,hashlib
from pathlib import Path
B=Path('/workspace/name-session/full-consumer-audit');x=runpy.run_path(str(B/'audit-review-tools.py'))
def surface(c,s,path,classification,extent,entries,mode='whole_operational_source_read'):
 r=next(z for z in c['files'] if z['path']==path);d=x['content'](r);assert hashlib.sha256(d).hexdigest()==r['source_sha256'];lines=d.decode().splitlines();ids=[]
 for symbol,line,purpose,state,context,api,missing,controls in entries:
  assert 1<=line<=len(lines),(path,line,len(lines));cid='audit:'+path+':'+symbol+':'+purpose;ids.append(cid);s['consumers']=[z for z in s['consumers'] if z['id']!=cid];s['consumers'].append(dict(id=cid,path=path,blob=r['blob'],source_sha256=r['source_sha256'],symbol=symbol,line=line,site=purpose,purpose=purpose,disposition=state,actual_input_context=context,shared_api=api,missing_integration=missing,source_evidence=[dict(path=path,extent=extent)],related_issues=[],relevant_original_assertions=controls,validation_result='No source script/build/provider/generator/test execution; artifact-only actual source review.',unexamined='Transitive caller/provider/artifact not explicitly reviewed retains separate unfinished coverage.'))
 r.update(review_status='reviewed',review_mode=mode,classification=classification,reason='Whole actual original baseline surface read with source-purpose classification; no path-only archive/generated exemption.',reviewed_production_extent=extent,evidence=[dict(path=path,extent=extent)],tests='No execution, actual operational statements and fixed data read as stated.',consumer_ids=ids)
