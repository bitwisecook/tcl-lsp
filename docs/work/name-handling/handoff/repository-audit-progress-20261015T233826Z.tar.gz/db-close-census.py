from pathlib import Path
import json,datetime,collections,hashlib
R=Path('/workspace/name-session/full-consumer-audit')
def atomic(p,x):
 t=p.with_name(p.name+'.db-tmp');t.write_text(json.dumps(x,indent=2)+'\n');t.replace(p)
c=json.loads((R/'db-file-coverage.json').read_text());by={a['path']:a for a in c['files']};test=json.loads((R/'db-inline-operational-test-census.json').read_text());helpers=json.loads((R/'db-test-helper-inventory.json').read_text());receipt='db-census-closure-reconciliation.json';fixed='rust/tcl-registry/src/commands/irules/spec_runtime_test.rs'
updates=[]
for a in test['tests']:
 if a.get('review_status')!='inline_test_body_actual_read_pending':continue
 p=a['path'];o=by[p];old=a['review_status']
 if p==fixed:
  state='fixed_constructor_inventory_classified_after_aggregator_read';ev='db-irules-test-fixed-constructor-inventory.json'
 elif o['review_status']=='test_source_classified':
  assert o['review_mode'].startswith(('complete_original_test_source_read','complete_test_source_actual_read')),(p,o['review_mode'])
  state='complete_original_body_source_read';ev=receipt+' (prior complete original source coverage receipt retained)'
 else:
  # Fresh actual original cfg(test) sources read in this closure pass, independently of schema scan.
  assert '/src/commands/'in p,p
  state='complete_original_body_source_read';ev=receipt+' (fresh actual inline source read)'
 a.update(review_status=state,actual_read_receipt=ev);updates.append({'path':p,'symbol':a.get('symbol',a.get('name')),'old':old,'new':state,'source_sha256':o['source_sha256'],'basis':ev})
for a in helpers['helpers']:
 if a.get('review_status')!='unexamined_test_helper':continue
 p=a['path'];o=by[p]
 if p=='rust/tcl-registry/src/profile_queries.rs':basis='Fresh original lines195–400 actual-read; cfg(test) LegacyProfileOracle trait and complete implementation only, no production reactivation.'
 elif o['review_status']=='test_source_classified':
  assert 'helper'in o['justification'].lower()or o['review_mode']=='complete_test_source_actual_read',p
  basis='Prior complete original helper/body source-read recorded in file coverage: '+o['justification']
 else:
  assert p in('rust/tcl-registry/src/commands/tk/tk_cmd.rs','rust/tcl-registry/src/commands/tk/ttk__notebook.rs'),p
  basis='Fresh actual complete original inline test helper and assertion module read, selected profile/package-floor/spec metadata only.'
 a.update(review_status='complete_original_body_source_read',actual_read_receipt=receipt);updates.append({'path':p,'symbol':a['symbol'],'old':'unexamined_test_helper','new':a['review_status'],'source_sha256':o['source_sha256'],'basis':basis})
for a in helpers['module_include_sites']:
 p=a['path'];o=by.get(p)
 assert o and o['review_status']not in('unexamined','production_reviewed_inline_tests_pending','test_helpers_reviewed_inline_tests_pending'),p
 a.update(review_status='source_parent_review_or_explicit_fixed_inventory_classification_complete',actual_read_receipt=receipt,scope_limitation='Parent original production/test/metadata source ownership and exact include/module census reviewed; fixed assertion/declarative inventory rules remain explicit, no execution or Native proof.')
test['status']='Closed source/operational inventory; each original body either actually source-read or explicitly fixed-constructor classified with retained test-only ownership. No execution acceptance.'
helpers['status']='Closed helper and parent module/include source inventory; prior complete reads plus exact fresh/reconciliation receipts, no test-membership purity inference.'
atomic(R/'db-inline-operational-test-census.json',test);atomic(R/'db-test-helper-inventory.json',helpers)
p=R/'db-partial-reads.json';x=json.loads(p.read_text());x['status']='Historical partial-read ranges retained; complete original source/operational closure now supersedes older pending prose, as proven by file coverage and per-batch receipts. No source/test execution acceptance.';x['closure_receipt']=receipt;x['remaining_actual_read_backlog']=[]
for pth,v in x.get('files',{}).items():
 if pth in by:v['current_coverage_status']=by[pth]['review_status'];v['historical_extent_only']=True
x['active_partials']=[];atomic(p,x)
cc=R/'db-consumers.json';x=json.loads(cc.read_text());x['status']='Assigned source and operational census closed at pinned baseline; all purpose rows reviewed. Six explicit domain/provenance questions plus canonical upstream producer/acceptance obligations remain unfinished. No migration completion or execution acceptance.';atomic(cc,x)
atomic(R/receipt,{'baseline':c['baseline'],'as_of_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reason':'Inline operational census was stale relative to previously recorded complete original test source reads and explicit fixed-data parent ownership. Remaining small declarative inline modules and legacy oracle helpers were actually original-source read in this closure pass. No source findings or expected assertions changed.','fresh_reads':{'rust/tcl-registry/src/profile_queries.rs':[[195,400]],'declarative_inline_modules':'Every pending /src/commands/ inline cfg(test) module actual-read in full. Original irules aggregator retains separately verified closed constructor inventory grammar rather than claiming manual every-row read.'},'updates':updates,'module_include_parent_rows_reconciled':len(helpers['module_include_sites']),'test_status_counts':dict(collections.Counter(a['review_status']for a in test['tests'])),'helper_status_counts':dict(collections.Counter(a['review_status']for a in helpers['helpers'])),'validation':'Artifact/source review only; no Rust, shell, provider, network, or test execution.'})
print(json.dumps({'tests':collections.Counter(a['review_status']for a in test['tests']),'helpers':collections.Counter(a['review_status']for a in helpers['helpers'])},indent=2))
