import re,hashlib,json,sys
from pathlib import Path
R=Path('/workspace/name-session/full-consumer-audit');p=sys.argv[1];lo,hi=map(int,sys.argv[2:4]);s=(R/'lsp-baseline'/p).read_text();chars=list(s);comments=[];i=0
char_pattern=re.compile(r"(?:b)?'(?:[^'\\\n]|\\(?:.|u\{[0-9a-fA-F_]+\}))'")
raw_pattern=re.compile(r'(?:br|cr|r)(#*)"')
while i<len(s):
 a=i;b=None;kind=None
 if s.startswith('//',i):
  b=s.find('\n',i);b=len(s)if b<0 else b;kind='fixed_rust_comment_prose'
 elif s.startswith('/*',i):
  j=i+2;depth=1
  while j<len(s)and depth:
   if s.startswith('/*',j):depth+=1;j+=2
   elif s.startswith('*/',j):depth-=1;j+=2
   else:j+=1
  assert depth==0;b=j;kind='fixed_rust_comment_prose'
 else:
  m=char_pattern.match(s,i)
  if m:b=i+len(m[0])
  else:
   m=raw_pattern.match(s,i)
   if m:
    end='"'+m[1];j=s.find(end,i+len(m[0]));assert j>=0;b=j+len(end)
   elif s[i]=='"':
    j=i+1
    while j<len(s):
     if s[j]=='\\':j+=2
     elif s[j]=='"':j+=1;break
     else:j+=1
    b=j
 if b is not None:
  if kind:
   first=s[:a].count('\n')+1;last=s[:b].count('\n')+1
   if first<=hi and last>=lo:comments.append(dict(start_byte=len(s[:a].encode()),end_byte=len(s[:b].encode()),start_line=first,end_line=last,sha256=hashlib.sha256(s[a:b].encode()).hexdigest(),classification=kind))
   chars[a:b]=['\n'if c=='\n'else' 'for c in s[a:b]]
  i=b
 else:i+=1
plain=''.join(chars);actual=s.splitlines(keepends=True);lines=plain.splitlines(keepends=True);assert len(actual)==len(lines)
# Keep every noncomment byte; only leading/trailing indentation and blank lines
# are presentation compacted. All strings/literals retained without substitution.
out=''.join(f'{n}: {line.strip()}\n'for n,line in enumerate(lines,1)if lo<=n<=hi and line.strip())
q=R/'lsp-inline-projections'/p;q=q.with_name(q.name+f'.{lo}-{hi}.txt');q.parent.mkdir(parents=True,exist_ok=True);q.write_text(out)
m=dict(path=p,start_line=lo,end_line=hi,source_sha256=hashlib.sha256(''.join(actual[lo-1:hi]).rstrip('\n').encode()).hexdigest(),source_line_slice_sha256=hashlib.sha256(''.join(actual[lo-1:hi]).encode()).hexdigest(),whole_file_sha256=hashlib.sha256(s.encode()).hexdigest(),projection_sha256=hashlib.sha256(out.encode()).hexdigest(),omitted_comments=comments,scope='Only complete Rust comments and blank lines omitted; surrounding ALL original calls/constructors/control/assertions/provider/env/fs/guards and complete literals retained. Original line numbers retained. Source-only projection actual-read required, no tests/provider execution.')
q.with_suffix('.manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(q);print(len(out.splitlines()),len(out.encode()))
