from pathlib import Path
import json,hashlib,subprocess,datetime,collections
D=Path('/workspace/name-session/full-consumer-audit');R=Path('/workspace/tcl-lsp');B='cc24c394004fc187378ba0eefb6c2c5b2615fb00';cache={};reports=[];anchors=collections.defaultdict(list)
for p in sorted(D.glob('*-migration-units.json')):
 raw=p.read_bytes();j=json.loads(raw);assert j['baseline']==B
 units=j.get('units',[]);errors=[];ids=[];missing_controls=[]
 for u in units:
  ids.append(u['id'])
  aliases={'family_id':'repair_family_id','purpose':'naming_purpose','existing_shared_api':'existing_api','original_row_ids':'source_rows'}
  for field in ['work_kind','family_id','purpose','existing_shared_api','required_change','relative_effort','state','original_row_ids']:
   if not u.get(field) and not u.get(aliases.get(field,'')):errors.append({'unit':u['id'],'missing_field':field})
  if not u.get('control_obligations') and not u.get('controls'):missing_controls.append(u['id'])
  if not u.get('code_change_sites'):errors.append({'unit':u['id'],'missing_field':'code_change_sites'})
  for s in u.get('code_change_sites',[]):
   b=cache.setdefault(s['path'],subprocess.check_output(['git','show',B+':'+s['path']],cwd=R))
   if hashlib.sha256(b).hexdigest()!=s.get('source_sha256'):errors.append({'unit':u['id'],'site':s,'error':'source SHA mismatch'})
   lines=b.decode().splitlines();n=s['line']
   if not (1<=n<=len(lines)) or ('source_line' in s and lines[n-1]!=s['source_line']):errors.append({'unit':u['id'],'site':s,'error':'original line mismatch'})
   if s.get('blob') and hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()!=s['blob']:errors.append({'unit':u['id'],'site':s,'error':'Git blob mismatch'})
   anchors[(s['path'],n)].append({'catalogue':p.name,'unit':u['id'],'family':u.get('family_id',u.get('repair_family_id')),'purpose':u.get('purpose',u.get('naming_purpose'))})
 if len(ids)!=len(set(ids)):errors.append({'error':'duplicate unit ids'})
 reports.append({'catalogue':p.name,'sha256':hashlib.sha256(raw).hexdigest(),'proposed_units':len(units),'by_work_kind':dict(collections.Counter(u['work_kind'] for u in units)),'errors':errors,'missing_control_selection':missing_controls,'reported_status':j['status'],'mechanical_source_binding_only':True})
cross=[{'path':p,'line':n,'units':us} for (p,n),us in anchors.items() if len({u['catalogue'] for u in us})>1]
o={'baseline':B,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'Mechanical proposal validation only; no semantic uniqueness/completeness or control/provider acceptance. Catalogue totals deliberately not summed.','remaining_consumer_total':None,'catalogues':reports,'cross_catalogue_same_anchor_candidates':cross,'review_requirements':['Independently inspect every integration boundary, actual required change, workkind, shared-owner vs unchanged caller and cross-owner family.','Select exact original retained controls and preserve source/provider/config/currentness guards before implementation acceptance. Empty control selection is a recorded follow-up, not a passing test.','Source audit must close unexamined operational/generated/guidance coverage; pending source/domain/provider questions remain separate.']}
p=D/'migration-unit-proposal-mechanical-check.json';p.write_text(json.dumps(o,indent=2)+'\n');print(json.dumps({'catalogues':[{'file':r['catalogue'],'proposed_units':r['proposed_units'],'binding_errors':len(r['errors']),'missing_control_selection':len(r['missing_control_selection'])} for r in reports],'same_anchor_cross_catalogue_candidates':len(cross),'remaining_consumer_total':None}))
