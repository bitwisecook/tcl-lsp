from pathlib import Path
import sys
r=Path('/workspace/name-session/full-consumer-audit');p=sys.argv[1];a=(r/'db-baseline'/p).read_text().splitlines();b=(r/'db-production'/p).read_text().splitlines();m=[(i+1,s.strip())for i,s in enumerate(a)if s.strip()and(i>=len(b)or not b[i].strip())];first=int(sys.argv[2]);count=int(sys.argv[3]) if len(sys.argv)>3 else 650;print(p,'OMITTED TOTAL',len(m),'SLICE',first,first+count)
for i,s in m[first:first+count]:print(f'{i}:{s}')
