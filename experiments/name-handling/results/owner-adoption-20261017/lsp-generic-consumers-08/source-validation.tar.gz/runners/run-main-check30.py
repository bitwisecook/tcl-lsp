from pathlib import Path
import os,subprocess,json,time,signal,shutil,hashlib,datetime
b=Path('/workspace/naming-work/integration-30');source=Path('/workspace/tcl-lsp');log=b/'main-check119.log';argv=['cargo','check','--offline','--locked','--tests']
for package in ['tcl-compiler','tcl-registry','tcl-lsp-core','tcl-lsp-db','tcl-lsp-server','tcl-syntax','tcl-lexer','tcl-spectcl','tcl-test-support','tcl-spec-hooks','xtask','tcl-spec-studio']:argv.extend(['-p',package])
env=os.environ.copy();env.update(PATH='/workspace/.cargo/bin:'+env['PATH'],RUSTUP_HOME='/workspace/.rustup',CARGO_HOME='/workspace/.cargo',CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1');started=datetime.datetime.now(datetime.timezone.utc).isoformat();stop=None
with log.open('wb') as out:
 p=subprocess.Popen(argv,cwd=source,env=env,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
 while p.poll() is None:
  if shutil.disk_usage(b).free<200_000_000:
   stop='disk guard below200MB';os.killpg(p.pid,signal.SIGTERM);break
  time.sleep(1)
 try:code=p.wait(timeout=20)
 except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);code=p.wait()
record={'status':'ACTUAL_MAIN_TYPECHECK','started':started,'ended':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':argv,'source':str(source),'target':str(source/'target'),'exit':code,'aborted':stop,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'composition_sha256':hashlib.sha256((b/'composition.json').read_bytes()).hexdigest(),'tests_executed':False};(b/'main-check119-result.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
