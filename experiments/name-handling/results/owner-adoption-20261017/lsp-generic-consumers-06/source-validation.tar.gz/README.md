# Capture06: actual integrations20–21 and failed ordinary1338

Immutable source-only evidence capsule; no executable/provider binaries or source trees. Complete original1024 and separate314 manifests, actual runner, all raw test/list logs and results are retained. Original826P198F3timeouts; additive214P100F0timeouts. Final full source/provider/ELF/order/log guards passed; ordinary regression acceptance failed. Nine actual library test targets plus xtask binary test target are distinct from Native34/server-process/real-host gates, which remain owed.

Cargo diagnostic records are retained with exact full-log byte sizes/SHA256; Cargo artifact-only records are omitted from these filtered views. The actual artifact binding and final guards remain separate. Three causal source repairs retain exact patch/receipt bytes. No test/assertion/selector/budget modification is performed by this capture operation; no build/test/list/provider/checker execution occurs. Existing source/pre-post digest maps contain metadata only.

Root independently pinned a locked original Compiler221 contradiction in blockers/locked-compiler-test-conflict.json: unchanged complete source/constructor/dialect/test payloads have opposite expectations. This is an exact blocker, not authorization to edit assertions. Earlier capsule bytes are preserved; this V2 adds that receipt only.
