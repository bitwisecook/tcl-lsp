from pathlib import Path
import json,hashlib,datetime,collections
b=Path('/workspace/naming-work/integration-21');root=Path('/workspace/tcl-lsp');h=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
for old,new in [('build-r2-inputs.json','ordinary-post-inputs.json'),('build-r2-providers.json','ordinary-post-providers.json')]:assert (b/old).read_bytes()==(b/new).read_bytes(),(old,new)
artifacts=json.loads((b/'ordinary-artifacts.json').read_text());actual=[]
for key,info in artifacts.items():
 digest=h(Path(info['path']));assert digest==info['sha256'],key;actual.append({'target':key,'path':info['path'],'sha256':digest})
rows=[];all_failures=[]
for sub,manifest in [('original1024',Path('/workspace/naming-work/recovered-current-capsule/source/current-actual-source1024-v3/selection.json')),('additive314',b/'additive-selection-r2.json')]:
 m=json.loads(manifest.read_text());p=b/sub/'result.json';d=json.loads(p.read_text());assert not d['errors'];runs=d['runs'];assert [(x['target'],x['selector']) for x in runs]==[(x['target'],x['selector']) for x in m['execution_order']];assert len(runs)==m['total_exact_selectors'];assert d['manifest_sha256']==h(manifest)
 for run in runs:assert h(b/sub/run['log'])==run['log_sha256']
 failures=[{'target':x['target'],'selector':x['selector'],'timed_out':x['timed_out'],'log':str(b/sub/x['log']),'log_sha256':x['log_sha256']} for x in runs if not x['test_passed']]
 rows.append({'group':sub,'manifest_sha256':h(manifest),'result_sha256':h(p),'selected':len(runs),'passed':sum(x['test_passed'] for x in runs),'failed':len(failures),'timeouts':sum(x['timed_out'] for x in runs),'per_target':{target:{'selected':sum(x['target']==target for x in runs),'passed':sum(x['target']==target and x['test_passed'] for x in runs)} for target in sorted({x['target'] for x in runs})}})
 all_failures.extend(dict(group=sub,**x) for x in failures)
record={'status':'ORDINARY_EXECUTION_FAILED_COMPLETE_RETAINED_VECTORS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_files':len(json.loads((b/'ordinary-post-inputs.json').read_text())),'source_inputs_sha256':h(b/'ordinary-post-inputs.json'),'providers_sha256':h(b/'ordinary-post-providers.json'),'providers':6,'all_ten_current_test_ELFs_unchanged':actual,'guards':'Exact full original1024 and separate314 order/membership, all raw log hashes, manifest hashes, source+sixproviders before/after and all pinned current ELF hashes retained. Original30s listing/180s singleton budgets and requiredTclsh9.0,8.6 unchanged. No semantic/proof/green acceptance from failed run.','groups':rows,'failed_selectors':all_failures,'isolated_checkout_ENOSPC':'No Cargo ran in failed temporary checkout; original test logs contain no ENOSPC text, runnererrors empty, all retained source/providers/ELFs/raw logs verified; separate current source view candidate typecheck has no ordinary acceptance.'}
p=b/'ordinary-final-postflight.json';p.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'receipt':str(p),'sha256':h(p),'groups':rows,'source_and_provider_and_ELF_guards':'PASS','semantic_test_verdict':'FAIL'}))
