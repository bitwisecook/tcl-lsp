# Independent source review: configured lowering and Registry argument roles

Disposition: SOURCE CLEAR, bounded to the three pinned source-only packets below. No build, Cargo command, test, provider, checker, or probe was run by this reviewer. This is not runtime or Native evidence and does not admit the candidate packets.

## Lowering complete-expression configuration

Candidate: `/workspace/naming-work/sol-composition/lowering-full-expression-config-v1`

- Manifest `lowering-full-expression-config-v1/manifest.json`; patch SHA-256 `b8a3190770f21923992ab483cd73e0299ac85fddff5f759128b00392a7129ab6`; evidence SHA-256 `14d93d6480bb5bce2633a84c8e00d5f91c7172a8f8c075334f5033498f0f4fd5`.
- Audit rows: `compiler.source.original-expression-materialization-config:691`, `:755`, `:482`, `:5161`.
- The production `Lowerer::with_config` owns the supplied `LexerConfig`; `Lowerer::set_source_analysis_options` applies the supplied native lexer configuration. Both production `LoweringCommand` constructors at `lowering/mod.rs` pass `self.config` directly as `lexer_config`. The hook consumers use that retained field. The structured set-read consumer and `if`/`for`/`while` consumers also use `self.config` directly.
- The replacement parser `parse_expr_for_profile_with_lexer_config` first builds context from the selected profile, overlays the actual configuration's lexer grammar, then restores the selected profile's number semantics. The nested set read walker uses the same config. This avoids synthesizing lexical rules from the profile while retaining profile expression semantics.
- The added structured-condition test is additional and unexecuted. The candidate evidence records 295 original test functions and 715 assertion macros exact, changed-Rust AST, rustfmt and fresh forward/inverse fuzz0 all passing; I did not rerun those checks. Manifest before hashes match all current source images. The patch makes only the claimed parser/config changes, docs and the additional control.

## Selected `try` list semantics

Candidate: `/workspace/naming-work/sol-try-selected-list-v1`

- Manifest `sol-try-selected-list-v1/manifest.json`; patch SHA-256 `2264509b5befe75d260a52804be0451e6954d3dfbeddc68daa964548c2eb54e2`.
- Audit row: `db.unit.registry.try.selected-list-grammar`.
- This is connected to production consumers: `script_body_flow_for_invocation` calls `selected_try_control_invocation` for the selected Try operation; Native Try compilation's operand context also calls that API. `ResolvedInvocation`'s selected Try control-arm projection is updated to use the new selected API. These paths receive actual invocation arguments, not an independently reconstructed word list.
- The selected path requires an actual dialect, complete literal values, and a valid selected clause plan. It uses the retained `InvocationDialect` list-parse and escape grammar for list-valued selectors/variable lists. Structured `Literal` values containing `$` or `[...]` are treated as already-known values; `Dynamic`, expanded, or opaque words decline. The old string-compatible parser still takes the separate legacy route and rejects dynamic spellings. The patch does not admit a Native handler or execution.
- Candidate assertions add controls for literal-vs-dynamic values and strict-vs-lenient configured list grammar. The manifest records 349 old test bodies byte-exact, AST/rustfmt/fuzz0 passing, and no execution; I did not rerun them. All manifest before images match current Main source, and `git apply --check` succeeds.

## Literal argument-role resolver dependency

Candidate: `/workspace/naming-work/sol-literal-role-dependency-v1`

- Manifest `sol-literal-role-dependency-v1/manifest.json`; patch SHA-256 `01052202cc148dba285b9e89ff5ff9cd547461122fa5e978b5fbb941affd30cb`.
- Audit row: `db.unit.registry.resolved.literal-resolver-placeholder-dependency`.
- The changed consumer is `ResolvedInvocation::arg_roles`. When authored source roles are incomplete and the legacy `arg_role_resolver` fallback is needed, the callback now receives `InvocationArguments::literal_values()` and declines if any value is unknown. This is the genuine selected `InvocationWord::Literal` projection, not placeholder empty strings. The existing layout/option gate remains, and independent count/layout resolvers are still handled through their own paths.
- The added controls pin payload-dependent literal callback behavior, decline for a dynamic payload, and retain a count-owned role with unknown ordinary operands. Candidate asserts 98 old test bodies byte-exact, changed-Rust AST/rustfmt/fuzz0 pass, and no execution; I did not rerun checks. All before hashes match current Main, and `git apply --check` succeeds.

## Shared source checks

All three patch hashes match their manifests. Every file's manifest `before_sha256` matches its current source image in `/workspace/tcl-lsp`. The documentation additions are additive. The two Registry patches both touch `resolved_invocation.rs` against the same base; their hunks are non-overlapping in the reviewed patches (Try arm around 3974 versus literal callback around 3122), but composition should still use both patches with explicit rebase/patch checks. No compatibility parser removal or historical assertion weakening is present.
