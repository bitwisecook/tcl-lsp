from pathlib import Path
import sys,json,hashlib,subprocess,shutil
sys.path.insert(0,'/workspace/naming-work/python')
from tree_sitter import Language,Parser
import tree_sitter_rust
P=Parser(Language(tree_sitter_rust.language()));c=Path(sys.argv[1]);expected=sys.argv[2];r=c.parent/(c.name+'-root-peer');r.mkdir(exist_ok=True)
h=lambda q:hashlib.sha256(q.read_bytes()).hexdigest();m=json.loads((c/'manifest.json').read_text());assert h(c/'manifest.json')==expected
patches=[q for q in c.glob('*.patch') if h(q)==m['patch_sha256']];assert len(patches)==1;patch=patches[0];count=0;changed_tests=[];assertion_count=0;base=c/('base' if (c/'base').exists() else 'before')
if not base.exists():
 base=r/'pinned-main-before';base.mkdir(exist_ok=True)
 for f in m['files']:
  if f['before_sha256']:
   src=Path('/workspace/tcl-lsp')/f['path'];assert h(src)==f['before_sha256'],f['path'];dst=base/f['path'];dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
for f in m['files']:
 b=base/f['path'];a=c/'after'/f['path'];a=a if a.exists() else c/f['path'];assert h(a)==f['after_sha256'];old=b.read_bytes() if f['before_sha256'] else b''
 if f['before_sha256']:assert h(b)==f['before_sha256']
 if a.suffix=='.rs':
  assert not P.parse(a.read_bytes()).root_node.has_error
  def walk(n):
   global count,assertion_count
   if n.type=='function_item':
    q=n.prev_named_sibling;attrs=[]
    while q and q.type=='attribute_item':attrs.append(old[q.start_byte:q.end_byte]);q=q.prev_named_sibling
    if any(b'test' in x for x in attrs):
     body=old[n.start_byte:n.end_byte]
     if body not in a.read_bytes():
      assert '--allow-test-setup' in sys.argv,body[:160]
      changed_tests.append(body.split(b'{',1)[0].decode())
      def assertions(node):
       global assertion_count
       if node.type=='macro_invocation' and old[node.start_byte:node.end_byte].startswith((b'assert!',b'assert_eq!',b'assert_ne!',b'debug_assert!')):
        macro=old[node.start_byte:node.end_byte];assert macro in a.read_bytes();assertion_count+=1
       for child in node.named_children:assertions(child)
      assertions(n)
     count+=1
   for ch in n.named_children:walk(ch)
  walk(P.parse(old).root_node)
replay=r/'replay';shutil.copytree(base,replay,dirs_exist_ok=True)
for q in [replay,*replay.rglob('*')]:
 if not q.is_symlink():q.chmod(q.stat().st_mode | (0o700 if q.is_dir() else 0o600))
for reverse in [False,True]:
 x=subprocess.run(['patch','--batch','--fuzz=0',*(['-R'] if reverse else []),'-p1','-i',str(patch)],cwd=replay,text=True,capture_output=True);assert x.returncode==0,x.stdout+x.stderr
 for f in m['files']:
  q=replay/f['path'];sha=f['before_sha256' if reverse else 'after_sha256'];assert (h(q)==sha) if sha else not q.exists()
record={'status':'SOURCE CLEAR BOUNDED','manifest_sha256':h(c/'manifest.json'),'patch_sha256':h(patch),'old_tests_checked':count,'old_test_bodies_exact':count-len(changed_tests),'changed_test_setup':changed_tests,'assertions_in_changed_tests_byteexact':assertion_count,'AST':'PASS','forward_inverse_fuzz0':'PASS','whole_source_review':sys.argv[3],'execution':'Unexecuted: no Cargo/typecheck/tests/provider probes; no efficacy or closure claim.'};f=r/'SOURCE-CLEAR-BOUNDED.json';f.write_text(json.dumps(record,indent=2)+'\n');print(h(f),count)
