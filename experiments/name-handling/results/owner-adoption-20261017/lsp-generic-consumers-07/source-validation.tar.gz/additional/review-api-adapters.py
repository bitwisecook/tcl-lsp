from pathlib import Path
import sys,json,hashlib,subprocess,shutil
sys.path.insert(0,'/workspace/naming-work/python')
from tree_sitter import Language,Parser
import tree_sitter_rust
parser=Parser(Language(tree_sitter_rust.language()));d=Path(sys.argv[1]);expected=sys.argv[2];mode=sys.argv[3];m=json.loads((d/'manifest.json').read_text());h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert h(d/'manifest.json')==expected;changes=[];count=0;base=d/('before' if (d/'before').exists() else 'base')
def leaves(n,data):
 if n.type in ['line_comment','block_comment']:return []
 if not n.children:return [data[n.start_byte:n.end_byte]]
 return [token for c in n.children for token in leaves(c,data)]
def norm(tokens):
 t=tokens[:]
 if mode=='package-floors':
  prefixes=[[b'tcl_dialect',b'::',b'model',b'::',b'PackageFloors',b'::',b'Borrowed',b'('],[b'crate',b'::',b'model',b'::',b'PackageFloors',b'::',b'Borrowed',b'(']]
  i=0
  while i<len(t):
   prefix=next((p for p in prefixes if t[i:i+len(p)]==p),None)
   if prefix:
    depth=1;j=i+len(prefix)
    while depth:
     assert j<len(t);depth+=(t[j]==b'(')-(t[j]==b')');j+=1
    t[i:j]=t[i+len(prefix):j-1];continue
   if t[i:i+5]==[b'Some',b'(',b'&',b'PackageFloor',b'::']:del t[i+2]
   i+=1
 elif mode=='memo-accessor':
  i=0
  while i<len(t):
   if t[i:i+5]==[b'.',b'original_lexical_projection',b'(',b')',b'.']:del t[i+2:i+4]
   i+=1
 else:raise AssertionError(mode)
 return t
def tests(tree,data):
 out=[]
 def walk(n):
  if n.type=='function_item':
   prev=n.prev_named_sibling;attrs=[]
   while prev and prev.type=='attribute_item':attrs.append(data[prev.start_byte:prev.end_byte]);prev=prev.prev_named_sibling
   if any(b'test' in a for a in attrs) and not any(b'debug_assertions' in a or b'feature' in a for a in attrs):out.append(n)
  for c in n.named_children:walk(c)
 walk(tree.root_node);return out
for f in m['files']:
 old=(base/f['path']).read_bytes();new=(d/'after'/f['path']).read_bytes();assert h(base/f['path'])==f['before_sha256'] and h(d/'after'/f['path'])==f['after_sha256']
 if not f['path'].endswith('.rs'):continue
 a=parser.parse(new);assert not a.root_node.has_error;b=parser.parse(old);new_tests=tests(a,new)
 for t in tests(b,old):
  count+=1;body=old[t.start_byte:t.end_byte]
  if body in new:continue
  name=t.child_by_field_name('name');name=old[name.start_byte:name.end_byte];matches=[x for x in new_tests if new[x.child_by_field_name('name').start_byte:x.child_by_field_name('name').end_byte]==name];assert len(matches)==1;after=matches[0];left=norm(leaves(t,old));right=norm(leaves(after,new))
  if left!=right:
   at=next((i for i,(x,y) in enumerate(zip(left,right)) if x!=y),min(len(left),len(right)));raise AssertionError((f['path'],name,at,left[max(0,at-8):at+12],right[max(0,at-8):at+12]))
  changes.append({'path':f['path'],'function':name.decode(),'before_body_sha256':hashlib.sha256(body).hexdigest(),'after_body_sha256':hashlib.sha256(new[after.start_byte:after.end_byte]).hexdigest(),'exception':mode})
r=d.parent/(d.name+'-root-peer');r.mkdir(exist_ok=True);replay=r/'replay';shutil.copytree(base,replay,dirs_exist_ok=True)
for q in [replay,*replay.rglob('*')]:q.chmod(q.stat().st_mode|(0o700 if q.is_dir() else 0o600))
patch=next(p for p in d.glob('*.patch') if h(p)==m['patch_sha256'])
for rev in [False,True]:
 p=subprocess.run(['patch','--batch','--fuzz=0',*(['-R'] if rev else []),'-p1','-i',str(patch)],cwd=replay,capture_output=True,text=True);assert p.returncode==0,p.stdout+p.stderr
 for f in m['files']:assert h(replay/f['path'])==f['before_sha256' if rev else 'after_sha256']
record={'status':'SOURCE CLEAR BOUNDED','manifest_sha256':h(d/'manifest.json'),'patch_sha256':m['patch_sha256'],'old_test_functions_checked':count,'exact_body_tests':count-len(changes),'explicit_API_formation_exceptions':changes,'normalised_original_test_tokens':'PASS, comments/whitespace omitted; every fixture literal, expected value and predicate preserved; only exact documented representation adapters normalised.','fresh_forward_inverse_fuzz0':'PASS','whole_source_review':sys.argv[4],'execution':'No Cargo/tests/efficacy or closure claim'};(r/'SOURCE-CLEAR-BOUNDED.json').write_text(json.dumps(record,indent=2)+'\n');print(h(r/'SOURCE-CLEAR-BOUNDED.json'),count,len(changes))
