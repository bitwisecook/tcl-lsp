# Independent source review: catalogue, variable target and Logical visibility packets

No source edits, Cargo/build/tests/checkers/probes or provider execution were performed by this reviewer. The packets remain source-only; this receipt admits nothing.

## Catalogue owner projections — bounded CLEAR

Candidate `/workspace/naming-work/sol-catalogue-owner-projections-v1`; patch SHA-256 `2c0b063f7ad03c0db62a68485cb07f8efaf7e656c27a79f573efbf575f26ecf4`.

The actual hook enum declarations now carry presentation labels and explicit historical order. Static sequence comparison matches the old Studio presentation for LoweringHookId (26), CodegenHookId (16), InlineCodegenHookId (25), AnalyserHookId (31), ReturnTypeHookId (5), and NativeEvalId keys/order (67). The candidate maps catalogue rows from those owners. For native tables, it projects actual `pack_hooks` entries and uses key text only as a fallback label; the two nonempty const-fold tables retain their prior descriptive labels and their order/key lists match the actual Registry tables (47 and 4 entries). The authored-surface picker list is moved to the dialect owner without changing its entries. The source change grants no installation, invocation or Native execution authority. F5/iRules spellings already present in the picker remain presentation only.

Manifest Rust before hashes match for hooks.rs, value_transfer/route.rs and spectcl/catalogue.rs. Root’s concurrent `OwnedPackageFloor` work changed `authored_surface.rs`, and concurrent contract additions changed both docs; the candidate's manifest before hashes therefore no longer all match this live worktree. `git apply --check` fails on the contract files after those concurrent changes. Root has been notified; composer must rebase/document-append explicitly. Manifest claims 22 old test bodies exact, AST/rustfmt/fuzz0 pass, no execution; I did not rerun them.

## Configured variable target source advice — HOLD on a lost independent warning

Candidate `/workspace/naming-work/sol-scope-variable-source-value-v1`; patch SHA-256 `86039db40e9a4ac9f0dd862599cad4daf2f96e80955b37749d15759087d989c4`.

The positive source-value path is grounded: it joins the current document image/config to the shared original written-word owner, reopens the recorded command, requires one matching `VarWrite` ordinal, and uses `original_static_word_unicode_value` plus shared array-name partitioning. Dynamic values do not become invented strings. The namespace fallback substitution is the shared byte qualification predicate and keeps existing scope/policy gates. These are appropriately bounded source facts.

The change also drops an existing W215 diagnostic the source comment expressly preserved. Previously, the array-element `)` syntax warning ran independently of `name_is_static`: the old code says the dynamic element index round-trips verbatim and the check is unaffected by an unresolved `$` or `[cmd]`. The new helper first requires a complete static value for the *whole* written word, so a source such as `set arr(foo$index)) 1` cannot reach the element check even though its literal extra `)` is independently visible. I did not execute this example. Retain the narrower authentic source-element syntax fact for this warning when value completion is unavailable, or record an intentional policy change with the owner; do not let this packet silently suppress the existing warning. The exact old test slices (107) are claimed unchanged, but that does not resolve the behavior gap. Docs have concurrently advanced, so their old manifest hash no longer matches; the Rust scope.rs before hash does match.

## Logical Unicode visibility operands — bounded CLEAR

Candidate `/workspace/naming-work/sol-logical-member-visibility-unicode-v1`; patch SHA-256 `ae5ba6e0f541f89f5e19827af9b77afe30303b30965a9b5d76b85c7716a76f42`.

The change removes the ASCII-only gate from the existing String convenience query and uses the shared configured static Unicode value when validating retained `oo::define`/`oo::objdefine` visibility operands. The existing ledger still requires a positively selected Logical member statement, exact full input and image/config match, actual visibility effect and matching whole-word operand; NUL, dynamic, foreign and ambiguity refusals remain in place. This supports Unicode source visibility operands without granting method dispatch, publication or Native authority. The added control pins unchanged Unicode positive selection and stale configuration/image/NUL refusal. The two Rust before hashes match current source; docs have concurrently advanced. Manifest claims 162 old test slices exact, AST/rustfmt/fuzz0 pass and no execution; I did not rerun them.

## Shared basis notes

Patch hashes match the three manifests. The contract file and `authored_surface.rs` are shared concurrent composition sites; exact current replay is not established by this peer because those files advanced while I was reviewing. Scope’s specific behavior hold was sent to the source author and Root. Root should compose the two bounded clear packets with explicit documentation/source-surface rebasing and await the W215 correction before treating the scope packet as complete.
