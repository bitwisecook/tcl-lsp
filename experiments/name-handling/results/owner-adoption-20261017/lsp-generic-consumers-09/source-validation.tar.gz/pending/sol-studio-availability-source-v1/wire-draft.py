from pathlib import Path
import re
from tree_sitter import Language,Parser
import tree_sitter_rust
P=Path('/workspace/naming-work/sol-studio-availability-source-v1/after/rust/tcl-spec-studio/src/draft.rs');b=P.read_bytes();t=Parser(Language(tree_sitter_rust.language())).parse(b);nodes=[]
def walk(n):
 nodes.append(n)
 for c in n.children:walk(c)
walk(t.root_node);macros=[n for n in nodes if n.type=='macro_invocation' and b[n.start_byte:n.start_byte+6]==b'json!('];funcs=[n for n in nodes if n.type=='function_item'];edits={}
for m in re.finditer(rb'dialects\((\w+\.\w+)\)',b):
 arg=m[1].decode();cont=[n for n in macros if n.start_byte<=m.start()<n.end_byte]
 if cont:
  n=min(cont,key=lambda n:n.end_byte-n.start_byte);assert (n.start_byte,n.end_byte)not in edits;edits[(n.start_byte,n.end_byte)]=b'with_surface('+b[n.start_byte:n.end_byte]+b', "surface", '+m[1]+b')'
 else:
  start=b.rfind(b'    d.insert(',0,m.start());end=b.find(b';',m.end())+1;old=b[start:end];assert re.fullmatch(rb'    d.insert\("(surface|safe_on_uninit)".into\(\), dialects\('+re.escape(m[1])+rb'\)\);',old),old
  key=re.search(rb'"([^"]+)"',old)[1];f=next(n for n in funcs if n.start_byte<=m.start()<n.end_byte);name=f.child_by_field_name('name').text.decode();argd=b'&mut d' if name in ['form_spec','side_effect'] else b'd';edits[(start,end)]=b'    insert_surface('+argd+b', "'+key+b'", '+m[1]+b');'
for (a,z),v in sorted(edits.items(),reverse=True):b=b[:a]+v+b[z:]
P.write_bytes(b);print('wired',len(edits),'actual surface producer sites')
