from pathlib import Path
from tree_sitter import Language,Parser
import tree_sitter_rust,json,hashlib,difflib
P=Path(__file__).parent;parser=Parser(Language(tree_sitter_rust.language()));files=[];preserved=0
def test_functions(data):
 root=parser.parse(data).root_node;out={}
 def walk(n,path,testmod=False):
  if n.type=='mod_item':
   name=n.child_by_field_name('name');path=path+[name.text.decode()] if name else path
   z=n.prev_named_sibling;attrs=b''
   while z is not None and z.type=='attribute_item':attrs=z.text+attrs;z=z.prev_named_sibling
   testmod=testmod or b'cfg(test)' in attrs
  if n.type=='function_item':
   z=n.prev_named_sibling;attrs=b''
   while z is not None and z.type=='attribute_item':attrs=z.text+attrs;z=z.prev_named_sibling
   name=n.child_by_field_name('name').text.decode();path=path+[name]
   if testmod or b'#[test]' in attrs or b'cfg(test)' in attrs:
    key='::'.join(path);assert key not in out,key;out[key]=(attrs,n.text)
  for child in n.named_children:walk(child,path,testmod)
 walk(root,[]);return out
for before in sorted((P/'before').rglob('*')):
 if not before.is_file():continue
 r=before.relative_to(P/'before');after=P/'after'/r;b=before.read_bytes();a=after.read_bytes();assert b==(Path('/workspace/tcl-lsp')/r).read_bytes()
 if r.suffix=='.rs':
  assert not parser.parse(b).root_node.has_error and not parser.parse(a).root_node.has_error
  old=test_functions(b);new=test_functions(a)
  for k,v in old.items():assert new.get(k)==v,(r,k)
  preserved+=len(old)
 files.append({'path':str(r),'before_sha256':hashlib.sha256(b).hexdigest(),'after_sha256':hashlib.sha256(a).hexdigest()})
patch=''.join(''.join(difflib.unified_diff((P/'before'/f['path']).read_text().splitlines(keepends=True),(P/'after'/f['path']).read_text().splitlines(keepends=True),fromfile='a/'+f['path'],tofile='b/'+f['path'])) for f in files);(P/'change.patch').write_text(patch);(P/'source-check.json').write_text(json.dumps({'AST':'zero errors all4Rust','current_bases':'exact','old_attributed_or_testmodule_functions_byteexact':preserved,'RustExpr_companion_required':'render_rs::authored_surface_rows_expr from Library packet','files':files},indent=2)+'\n');print('checked',len(files),'files and',preserved,'old attributed functions')
