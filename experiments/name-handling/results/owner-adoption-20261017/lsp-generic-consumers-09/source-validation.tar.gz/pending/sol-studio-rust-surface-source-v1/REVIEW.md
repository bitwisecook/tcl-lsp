# Studio Rust availability adapter: pending independent whole review

Mandatory producer: sol-studio-availability-source-v1 manifest9246ceb8da34d6ff956b83f6594c63069e9db0f5ba6d4499bc5486885b494cbd.
This packet modifies only render_rs.rs and existing Dialect authored_surface.rs
plus canonical contract rows/appends, all based on exact current Main snapshots.
Compose pending comments/identifiers/source_value header and contract updates;
do not overlay whole afterimages. The producer's draft dialect_set_expr uses the
new shared rows constructor, replacing the now-removed old dialect_set helper.

API: pub(crate) authored_surface_expr(&AuthoredSurfaceSource)->Option<String>
returns the FULL optional source field expression: Absent=Some("None"), Rows[]=
Some("Some(&[])"), Unrepresentable=None. pub(crate) authored_surface_rows_expr(
&[AuthoredSurfaceRow])->String returns only the underlying slice source. Real
providers and ordered windows are serialized directly; field-local owning metadata
is rejoined BEFORE default omission. Unknown data remains visibly unavailable.

The old surface! macro is row-only; old generated composite slices were invalid.
concat_surface! is the same existing authored-surface owner's genuine const slice
constructor. All actual inputs must be const slices, all copied rows preserve
order/duplicates/windows, explicit empty contains no published placeholder rows.
The internal initializer is completely overwritten across exact summed length;
for length zero no row exists. No runtime allocation or leaked string is used.
Historical readable shorthand choices compare actual typed constant values and
are presentation only, without a second label/version ladder.

Own static evidence in ../sol-studio-rust-surface-source-v1-own-static/static-proof.json:
hashes/currentbases/RustAST/rustfmt/44old attributed slices/freshfuzz0 PASS.
Three added fixed controls are UNEXECUTED. One compiles the actual generated
const aggregate expression within its test body; that alone is not a whole-file
generator build proof. Root must generate a genuine complete positive module,
compile it, and run ordinary Dialect/Studio tests. No Cargo/typecheck/tests or
generator execution by this author. Source review remains pending.
