from pathlib import Path
import json,hashlib
from tree_sitter import Language,Parser
import tree_sitter_rust
P=Path('/workspace/naming-work/direct-lsp-studio-remaining-units-v3');A=P/'A-source-tu-inference-v3';B=P/'B-strict-c-escape-v3';O=Path(__file__).parent;h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();parser=Parser(Language(tree_sitter_rust.language()))
def tests(data):
 out={}
 def w(n,path,test=False):
  z=n.prev_named_sibling;attrs=b''
  while z is not None and z.type=='attribute_item':attrs=z.text+attrs;z=z.prev_named_sibling
  if n.type=='mod_item':path=path+[n.child_by_field_name('name').text.decode()];test=test or b'cfg(test)' in attrs
  if n.type=='function_item':
   path=path+[n.child_by_field_name('name').text.decode()]
   if test or b'#[test]' in attrs or b'cfg(test)' in attrs:
    key='::'.join(path);assert key not in out;out[key]=(attrs,n.text)
  for c in n.named_children:w(c,path,test)
 w(parser.parse(data).root_node,[]);return out
facts=[];preserved=0
for packet,expected in [(A,'480dd7bc604d3c975dc1ae536861dd6612a6f34cf8b8708f0ccc815c060d2240'),(B,'82ca09ef26e215febd57ac844e1d09dc64530131bf9efa9f1661ec6d60781144')]:
 assert h(packet/'manifest.json')==expected;m=json.loads((packet/'manifest.json').read_text());assert h(packet/'patch.diff')==m['patch_sha256']
 for f in m['files']:
  name=Path(f['path']).name;before=packet/'before'/name;after=packet/'after'/name;assert h(before)==f['before_sha256'];assert h(after)==f['after_sha256'];assert not parser.parse(after.read_bytes()).root_node.has_error
  original=Path('/workspace/tcl-lsp')/f['path'];old=tests(original.read_bytes());new=tests(after.read_bytes());
  for k,v in old.items():assert new.get(k)==v,(packet.name,name,k)
  preserved+=len(old)
  if packet==B:assert before.read_bytes()==(A/'after'/name).read_bytes()
 facts.append({'packet':str(packet),'manifest_sha256':expected,'patch_sha256':m['patch_sha256']})
d={'status':'HOLD','packets':facts,'checks':{'all_source_blob_pins':'exact','B3_actual_before_equals_A3_after':'all3files exact','AST':'zero errors all6afterimages','original_Main_attributed_test_function_comparisons_byteexact':preserved,'execution':'none'},'A3_source_hold':{'cause':'function_is_static inspects only definition prefix after preceding semicolon/brace; prior visible internal-linkage declarations are not retained.','concrete_source':'TU1: int Ext_Init(Tcl_Interp*i){Helper(i);return 0;} TU2: static void Helper(Tcl_Interp*); void Helper(Tcl_Interp*i){Tcl_CreateObjCommand(i,"other_static",P,0,0);}','effect':'C prior static declaration retains internal linkage for later unadorned definition. Current external_functions labels that definition external, so Scope can falsely follow TU1 call into TU2. Same issuer also supplies root admission.','required':'Retain genuine prior declaration/linkage context in existing C scanner or conservatively refuse the ambiguous attribution; preserve old positive fixtures/assertions.'},'B3_source_review':{'actual_fixes_present':'One continued string loop retains invalid state, follows escaped quotes to actual terminator, handles escaped LF/CRLF, limits octal toASCII rather than guessing Unicode. Ordinary simple escapes remain. Invalid raw token is not accepted as literal by string_of.','provenance_hold':'B3 manifest A_basis_manifest_sha256 a9971914... does not equal actual pinned A3 manifest480dd7bc...; actual before-source files do match A3. Requires distinct metadata successor, no sealed mutation.','semantic_fixture_hold':'Original escapes_in_a_name_are_decoded malformed \\x assertion remains unchanged and inconsistent with new refusal. Root has not admitted proposed expectation change; no all-tests-pass or acceptance claim.'},'scope':'Whole source afterimages and actual current owner/API producer paths read; no Cargo/C/compiler/test/provider/generator execution. No Native or runtime authority.'};p=O/'SOURCE-HOLD.json';p.write_text(json.dumps(d,indent=2)+'\n');print(h(p))
