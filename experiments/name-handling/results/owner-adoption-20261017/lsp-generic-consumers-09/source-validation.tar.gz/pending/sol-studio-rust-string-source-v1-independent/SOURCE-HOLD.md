# Source HOLD: suffixed string tokens are not string expressions

Reviewed complete V1 delta (manifest50316797736e4d0289b50adad1631e58e033c02b1e49acc3bcd0adea82165475;
patch49c83d3edb5897bd4011eea29b152e743c70841826652ee870729a25f94da52f).

The actual cached syn2.0.119 LitStr Parse delegates to Lit::Str and retains its
suffix. LitStr::value explicitly discards that suffix. Thus a complete token such
as `"data"invalid_suffix` can parse and be returned as plain string data, even
though the suffix makes it invalid as the advertised Rust string expression.
The canonical reparse only checks the discarded value, so it does not detect
this original-source problem. Require the actual original LitStr suffix to be
empty, and add cooked/raw suffixed negative controls in a distinct successor.
Actual source references: syn src/lit.rs154,273,952,1172,1383. Existing LitStr's
own parse_with also rejects suffixes, independently confirming this axis.

Parsing-only API availability was inspected in actual cached syn lib.rs442/955:
LitStr and parse_str are available without full/derive. Whole delta otherwise
keeps pure literal extraction separate from semantic variant/path/type recovery;
valid alternative literal spellings and real canonical value roundtrip are sound
for that limited purpose. No execution or Native identity follows. New own source
file should also receive the same full AGPL header as its sibling.

No Cargo/build/typecheck/tests or runtime oracle used. This is a concrete static
API/source review, not an execution result or whole packet clearance.
