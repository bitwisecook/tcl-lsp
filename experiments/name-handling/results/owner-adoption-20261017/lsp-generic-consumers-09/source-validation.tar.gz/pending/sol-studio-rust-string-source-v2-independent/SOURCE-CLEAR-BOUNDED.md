# Bounded source review: V1 plus mandatory V2 CLEAR

V1 manifest50316797736e4d0289b50adad1631e58e033c02b1e49acc3bcd0adea82165475,
patch49c83d3edb5897bd4011eea29b152e743c70841826652ee870729a25f94da52f;
V2 manifestc826d61edb0fdaefeb00fe4ae7f76f1b4d9bb81dec4c762ae974353c5c640214,
patch89dd4cbceb140da3fad47696e21cbd69860d1cfdba0cf9d0de2442e1beedf84f.

Read full chain and actual cached syn2.0.119 parser/value/feature definitions.
Mandatory V2 checks original LitStr.suffix before value extraction, closing the
concrete token-versus-string-expression HOLD recorded for V1. Complete parse
with no suffix and canonical render/reparse exact Unicode value correspondence
support valid raw/escaped/Unicode/hex forms while withholding nonliteral syntax.
The existing SpecTcl consumer delegates rather than deleting unknown escapes.
No path/variant/type resolution, executed Rust, Tcl lookup, Native identity or
complete semantic-expression-data projection follows. Other semantic inverses
remain explicitly open. The new file now uses its actual sibling's AGPL header.

Actual syn public LitStr, suffix, value and parse_str APIs are present with only
parsing enabled, inspected in cached package lib.rs442/955 and lit.rs273/952.
Precise lock addition selects the existing 2.0.119 package; no package/version
or checksum changed, and no new proc-macro2 direct dependency is introduced.

Independent hashes, Rust AST, configured rustfmt, TOML/lock parse, all 84 V1-base
attributed test slices plus V1's one new test preserved in V2, and fresh exact
forward/inverse fuzz=0 replay pass. Prospective bases independently match the
explicit identifier dependency, semantic-argv, declaration V2 docs and current
render_rs bases. Header-only render_rs hunk is disjoint from the pending comment
and identifier functions; Root must compose, not replace afterimages. Contract
rows/appends also require explicit composition. Evidence: static-proof.json.
No Cargo/build/typecheck/tests/generator/runtime execution or efficacy claim.
