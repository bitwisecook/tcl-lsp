# Bounded source review: V1 plus mandatory V2 CLEAR

V2 manifest a35c0125f3d054b64257b01b85d956a1fb87f32454352f67bcdfbb004197ab66;
patch ac73f9f1b6381239135b285c1bbb32568e2f45b2b25755c71de5ea0d25c2df19.
V1 bounded source review remains scoped as recorded in its independent receipt.

Read the entire V2 delta. Authored standalone command blocks use an explicit
AuthoredCommandFragment purpose, with no fabricated pack or original document
parent. Each child inherits that purpose and actual word/root/config/parent lineage.
The factored root collector still requires complete actual row provenance, exact
canonical header argv and unique names. DocumentPack independently requires exactly
one selected pack, so factoring does not admit multiple distinct packs. Unrelated
complete rows are preserved as source without representing evaluated registration
coverage; an empty canonical fragment roster is not runtime absence. Consumer
actual intent/currentness and complete kept-Draft validation remain required.
V2 includes the missing checked canonical shared-owner row and name contract.

Independent hashes, Rust AST, configured rustfmt, all 9 V1 attributed test slices,
and fresh exact fuzz=0 forward/inverse replay pass. Prospective base was separately
verified byte-exact: Rust V1 afterimage plus the explicitly declared stub V1 doc
afterimages. These three paths differ from current Main by those dependencies;
Root must compose the chain and parallel contract rows/appends, not overlay files.
No Cargo/build/typecheck/tests/runtime execution or efficacy claim.
