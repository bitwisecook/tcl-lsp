# Independent source review — Studio availability packets V1

Status: HOLD. This review covers only the exact immutable candidates below; it grants no admission or execution claim.

- Availability producer: `/workspace/naming-work/sol-studio-availability-source-v1/manifest.json`, SHA-256 `9246ceb8da34d6ff956b83f6594c63069e9db0f5ba6d4499bc5486885b494cbd`; patch SHA-256 `685323263dafe99923e7b5bd7a24ff221fa50000bdaec549e52db82ce865c460`.
- Rust renderer: `/workspace/naming-work/sol-studio-rust-surface-source-v1/manifest.json`, SHA-256 `1ee54cf339356e7cf7a71d450b73aca892b7713b8977abf5675e7d3c8a4b393c`; patch SHA-256 `3640c18685ac59f69701bb120e86ee8ad6fc382467c3c4e5219992e06ee18b12`.

The producer’s nonempty availability path retains exact provider/window rows with the original field and display, routes explicit edits through the existing dialect-name owner, and reparses each candidate row with `parse_row` before emitting it. Parser notices, package side effects, or row inequality cause refusal. The separate draft/Rust adapter remains a mandatory companion, as the producer manifest states; the SpecTcl renderer adapter is also still outstanding.

Two defects prevent a clear review:

1. `AuthoredSurfaceSource::Rows([])` bypasses parser round-trip validation and is spelled as `dialects {}` / `-dialects {}`. The actual loader `parse_dialects` in `rust/tcl-spectcl/src/loader.rs` returns `(!rows.is_empty()).then(...)`; an empty word list becomes `None`, not `Some(&[])`. This converts an explicit empty restriction into absence and broadens availability. Preserve explicit empty only after the actual parser has a distinct representation and round-trip controls prove it.
2. The renderer correctly makes `authored_surface_expr(Unrepresentable)` return `None`, but production callers replace that with the unresolved token `UNREPRESENTABLE_AUTHORED_SURFACE`. The new live-renderer control explicitly expects this token in emitted Rust. This does not produce valid typed Rust or a generation refusal. Propagate a real refusal/error or use the approved valid failure contract; do not omit the field or emit an unresolved identifier.

Positive source review only: `Absent` maps to `None`; `Rows([])` maps to `Some(&[])` in the Rust expression adapter; row serialization preserves provider/windows; `concat_surface!` is a const slice concatenator preserving order and duplicates. The syntax is unexecuted and this review does not claim generated-module compilation. No Cargo/build/tests/typecheck/generator/checker/provider execution was run.

Source files were read at the packet’s exact frozen before hashes. No source or packet was modified.
