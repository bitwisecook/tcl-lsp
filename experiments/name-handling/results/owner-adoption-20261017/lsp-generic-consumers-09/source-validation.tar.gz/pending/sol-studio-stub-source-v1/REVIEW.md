# Studio stub source: pending independent review

The six-file packet handles only the three existing direct-LSP Studio stub audit
purposes listed in manifest.json. The directive grammar is the actual existing
analyser stub reader, not Tcl argv syntax. Ordinary valid generated output stays
unchanged. A checked source constructor rejects command names that cannot roundtrip
as command stubs (including the reader's expression-prefix precedence), and the
caller explicitly emits an unavailable comment. Draft names remain unrestricted.
Registry's single role vocabulary now supplies both parser and authored spelling.

Comments need a purpose-specific constructor: the sidecar reader interprets comment
bodies as directives/markers. Prefixing arbitrary lines with '# ' alone is not safe.
The existing parser and marker predicates identify active lines and a nested comment
keeps them inert; ordinary lines retain their spelling. Physical CR/LF are split and
a trailing backslash receives a space before LF to avoid Tcl comment continuation.

Own static checks (not independent): ../sol-studio-stub-source-v1-own-static/static-proof.json.
126 original attributed test slices remain exact, AST parse and configured rustfmt
check pass, and fresh forward/inverse fuzz=0 replay reproduces all sealed images.
Two new fixed controls are unexecuted. No Cargo, typecheck, generator, tests or runtime
checks were run. Root must run the relevant actual gates; source review is pending.
No selected runtime command, Native identity, frame, cell, effect or execution grant.
