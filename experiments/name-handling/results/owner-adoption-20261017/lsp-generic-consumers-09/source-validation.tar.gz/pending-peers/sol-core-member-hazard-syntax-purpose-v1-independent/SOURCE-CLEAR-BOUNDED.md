# Bounded source review: CLEAR

Manifest2f9b0a3dc0f338c29c6d0a58ad8ee2d264d049a6185f8a462d19f49f12998b71;
patch6d41739ab55dbf1bdf53c6ad2a752228e171fc8c0234998fdd56b219b513c5c7.

Whole delta and surrounding collector/source owners reviewed. The caller already
requests Syntax coverage but previously iterated PotentialEvaluation bodies.
Actual source_script_bodies_for explicitly returns no bodies for a definition
parent/member under non-Syntax purpose. Both changed loops now request the same
existing Syntax purpose, preserving actual source/context/Registry/word geometry.
The unchanged definition_parent_for still requires the actual selected definition
schema or immediate-caller source inheritance, exact current source/context and
parent containment. Thus ordinary nested same-context bodies may expose lexical
member references while callable bodies cannot borrow enclosing member vocabulary.
No Native invocation, entered frame, general mutation/evaluation coverage or new
edit permission follows. Existing checked/partial bookkeeping and lexical member
body traversal remain unchanged. This is a concrete source-level causal correction;
actual failure efficacy must still be replayed by Root.

Independent current base/hashes, Rust AST, rustfmt, all 5 original attributed test
slices and exact fresh forward/inverse fuzz=0 replay pass; static-proof.json.
No Cargo/build/typecheck/tests or runtime probes. Added control is unexecuted.
