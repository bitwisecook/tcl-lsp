# Bounded source review: V1 plus mandatory V2 CLEAR

V1 manifestb97e8757a30a777b7fdd87504fbff3d62b95d53726be68c68245707eafd39f33,
patchff1c2bd292f2d00bde24d8008cc4ccd8225d2ca651561f9eb9d6c1bc641eb929;
V2 manifest4beda25cf853b66b1853053bfeb3d9ea9a1f09e3f2e2d123405a4629aa281716,
patch669936330d2d0098321467b30902672c79e752827680fdff1f6167ad8d5e4bb6.

Read full source chain, actual source-schema and definition-member producers,
Syntax coverage/currentness, existing method inventory and consumers. Complete
classification uses genuine complete SourceSyntaxCoverage plus same-source syntax
structure. Exact scoped member argv outranks global vocabulary; failed member
classification never falls back. Every other command requires a genuine Registry
source schema, with actual selected self-dispatch trait. Every such self site joins
exactly one canonical typed method/property row and every positive row is seen.
Missing tapes alone cannot yield zero: a missing row at a classified self site
refuses, unknown heads cannot produce a selected schema, and real complete source
with no self/unclassified site independently supports empty source occurrences.
Normal external object heads lacking a Registry schema refuse; V2 additionally
uses positive receiver/query receipts only as vetoes, never missing receipts as
nonobject proof. External/deep/unknown receiver completeness is not granted.

Mandatory V2 closes the merged-report proof gap: all seeded existing positive
spans must belong to the independently checked census before Complete promotion.
Thus unmatched original/captured inventory positives remain visible with Partial,
not promoted by a separate self-only proof. V1 alone is not cleared for admission.
The unchanged current identity/full source/input owner checks precede the census.
No runtime dispatch/receiver, physical absence/effect, edit or execution permission
follows from this conditional readonly source count. Existing old positive controls
remain; actual availability and regression efficacy still require Root replay.

Independent hashes, Rust AST, configured rustfmt, all 10 original V1-base test
slices and V1's new test preserved in V2, exact V2-before==V1-after, and separate
fresh forward/inverse fuzz=0 replay pass. See both independent static-proof.json
files. V2 Main drift is the explicit V1 prerequisite. New controls unexecuted;
no Cargo/build/typecheck/tests/runtime probes. Root owns composition and validation.
