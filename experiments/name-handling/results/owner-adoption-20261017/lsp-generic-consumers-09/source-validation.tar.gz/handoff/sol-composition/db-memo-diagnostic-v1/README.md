# DB memo 921–923 diagnostic only

No production change, compilation or execution performed by this packet.

Fresh actual failures: 921 worker callback count is 2 rather than 1; 922 and 923 fail neutral capsule equality before memo-key assertions. Original fixtures/assertions remain unchanged.

The probe reuses the exact 922 fixture and authentic analysis input. It reports actual procedure/body inventories, original CFG membership, source SSA symbol counts and existing closed-correspondence booleans; Debug dumps preserve existing private projection state for first-difference inspection. Root must choose current frozen rlibs and execution window. It does not claim installed and authored rows interchangeable.

Static candidate refusal: analytical_closed_projection invokes FunctionUnit::relocated_variable_proofs, which returns None when source_variable_symbols is nonempty. This physical relocation guard must remain; if the actual probe reaches it, a genuine independent source allocation correspondence is required. Erasing source identities, weakening Eq, dropping parallel bodies or admitting Native identities are not proposed fixes.
