use std::sync::Arc;
use tcl_compiler::{analyser::Analyser, compilation_unit::{CompilationUnit,UnitBuildOptions}, body_analysis_capsule::BodyAnalysisCapsule};
fn main() {
 let mut analyser=Analyser::new();
 let input=analyser.prepare_analysis_input("tcl8.6").unwrap();
 let registry=input.borrowed_context_registry().commands();
 let profile=input.unit_profile();
 let source="proc sample {value} {set length [llength $value]; puts $length}\n";
 let base=CompilationUnit::build_standalone_with_analysis_input(source,UnitBuildOptions{registry,defer_top_level:false,config:input.lexer_config(),dialect:Some(profile),external_call_sites:None,declared_commands:None},&input).unwrap();
 eprintln!("inventory procedures={} body_units={} native={} authored={} logical={} installed={}",base.procedures.len(),base.body_units.len(),base.ir_module.original_native_declaration_body_units.len(),base.ir_module.original_authored_declaration_body_units.len(),base.ir_module.original_logical_declaration_body_units.len(),base.ir_module.installed_procedure_body_units.len());
 for f in base.all_body_function_units(){eprintln!("body={:?} cfg_current={} input={} source_symbols={}",f.body_id,f.body_id.is_some_and(|id|base.original_procedure_cfg_for_body(id)==Some(&f.cfg)),f.source_metadata_input().is_some(),f.ssa.source_variable_symbols().count());}
 let current=Arc::new(base.clone().with_interprocedural(registry,Some(profile)));
 let legacy=Arc::new(base.clone().with_interprocedural_memoized(registry,Some(profile),&mut |id,_,summary|base.original_interproc_taints_for_body(Some(id),registry,summary).map(Arc::new)));
 for (label,unit) in [("legacy",legacy),("current",current)] {
  for f in unit.all_body_function_units(){if let Some(id)=f.body_id {if let Some(c)=BodyAnalysisCapsule::retain(unit.clone(),id,registry){eprintln!("capsule {} {:?}: closed={} native={}",label,id,c.has_closed_analysis_correspondence(),c.has_closed_native_correspondence());std::fs::write(format!("/workspace/naming-work/sol-composition/db-memo-diagnostic-v1/{}-{:?}.txt",label,id),format!("{:#?}",c)).unwrap();}}}
 }
}
