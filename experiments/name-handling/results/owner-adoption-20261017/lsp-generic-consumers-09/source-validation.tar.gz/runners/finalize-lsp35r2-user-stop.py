from pathlib import Path
import hashlib,json,datetime,subprocess
W=Path('/workspace/naming-work');O=W/'lsp-35r2';B=W/'lsp-build-35r2';R=Path('/workspace/tcl-lsp');h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert (O/'pre-inputs.json').read_bytes()==(O/'stop-post-inputs.json').read_bytes()
assert (O/'pre-providers.json').read_bytes()==(O/'stop-post-providers.json').read_bytes()
a=json.loads((B/'artifacts.json').read_text());arts=[]
for n,row in a.items():assert h(Path(row['path']))==row['sha256'];arts.append({'target':n,'sha256':row['sha256'],'matched':True})
m=W/'recovered-current-capsule/source/current-actual-source1024-v3/selection.json';assert h(m)=='b2ba07fcace4c53e099112488b514b1a76009235f45cd37581363f66a5ff2922';groups=json.loads(m.read_text())['groups'];counts=[]
for q in sorted(O.glob('original-*/result.json')):
 d=json.loads(q.read_text());target=q.parent.name.removeprefix('original-');rs=d['runs'];assert [r['selector'] for r in rs]==groups[target][:len(rs)];assert not d['errors'] and not d.get('artifact_drift',{});
 for row in rs:assert h(q.parent/row['log'])==row['log_sha256'];assert row['running_counts']==['1'];assert row['target']==target
 completed=len(rs)==len(groups[target]);counts.append({'target':target,'completed':len(rs),'expected':len(groups[target]),'passed':sum(r['test_passed'] for r in rs),'failed':sum(not r['test_passed'] for r in rs),'timeouts':sum(r['timed_out'] for r in rs),'complete_target':completed,'result_sha256':h(q)})
assert len(counts)==3
logs=[]
for q in sorted((O/'original-tcl_lsp_server').glob('test*.log')):
 if q.name not in {r['log'] for r in json.loads((O/'original-tcl_lsp_server/result.json').read_text())['runs']}:logs.append({'path':str(q.relative_to(O)),'sha256':h(q),'bytes':q.stat().st_size,'status':'UNFINISHED_NO_RESULT_DO_NOT_COUNT'})
r={'status':'USER_PAUSED_PARTIAL_CAPTURE_POSTSTOP_GUARDS_PASS','checked_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'user_stop_sha256':h(O/'user-stop.json'),'source_files':52881,'source_sha256':h(O/'pre-inputs.json'),'post_source_sha256':h(O/'stop-post-inputs.json'),'providers':6,'providers_sha256':h(O/'pre-providers.json'),'post_providers_sha256':h(O/'stop-post-providers.json'),'all_six_test_ELF_hashes':arts,'original_subgroups':counts,'uncompleted_logs':logs,'complete_run':False,'additive230_and_new5':'UNSTARTED','acceptance':'NONE. Original DB/Core targets complete with failures; Server is a verified prefix only. No full1085/full1024/additive314 acceptance, Compiler libtest verification, actual native server process, editor-host gate or VM/runtime migration.'}
(O/'user-stop-postflight.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
s=json.loads((O/'summary.json').read_text());s.update(status='USER_PAUSED_PARTIAL_CAPTURE',stopped_at=json.loads((O/'user-stop.json').read_text())['stopped_at'],stop_postflight_sha256=h(O/'user-stop-postflight.json'),completed_test_count=sum(c['completed'] for c in counts),passed=sum(c['passed'] for c in counts),failed=sum(c['failed'] for c in counts),full1085_complete=False);(O/'summary.json').write_text(json.dumps(s,indent=2)+'\n')
