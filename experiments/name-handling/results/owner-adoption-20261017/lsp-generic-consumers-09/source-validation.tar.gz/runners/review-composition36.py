from pathlib import Path
import json,hashlib,subprocess,sys
sys.path.insert(0,'/workspace/naming-work/python')
from tree_sitter import Language,Parser
import tree_sitter_rust
P=Parser(Language(tree_sitter_rust.language()));W=Path('/workspace/naming-work');R=Path('/workspace/tcl-lsp');B=W/'integration-36';d=json.loads((B/'composition.json').read_text());assert d['complete'] and d['outside_main'];count=0;exact=0;changed=[];rust=0
for name in d['paths']:
 a=B/'compose'/name;b=R/name
 assert hashlib.sha256(b.read_bytes()).hexdigest()==d['before_sha256'][name]
 if a.suffix!='.rs':continue
 rust+=1;old=b.read_bytes();new=a.read_bytes();assert not P.parse(new).root_node.has_error,name
 r=subprocess.run(['/workspace/.cargo/bin/rustfmt','--check','--edition','2024','--config','skip_children=true',str(a)],env={'RUSTUP_HOME':'/workspace/.rustup','CARGO_HOME':'/workspace/.cargo'},text=True,capture_output=True);assert r.returncode==0,(name,r.stdout,r.stderr)
 def walk(n):
  global count,exact
  if n.type=='function_item':
   q=n.prev_named_sibling;attrs=[]
   while q and q.type=='attribute_item': attrs.append(old[q.start_byte:q.end_byte]);q=q.prev_named_sibling
   if any(b'test' in x for x in attrs):
    count+=1;body=old[n.start_byte:n.end_byte]
    if body in new:exact+=1
    else:
     assert name=='rust/tcl-lsp-core/src/completion.rs'
     needle=b'        tcl_spectcl::core_surfaces::ensure();\n'
     assert new.count(needle)==1 and body in new.replace(needle,b''),body[:100]
     changed.append({'path':name,'function':body.split(b'{',1)[0].decode(),'exception':'genuine shipped SpecTcl core_surfaces initializer before same registry fixture; all original predicates, fixture values and assertions byteexact'})
  for c in n.named_children:walk(c)
 walk(P.parse(old).root_node)
out={'status':'COMPOSED_SOURCE_AST_FMT_OLD_TEST_PRESERVATION_PASS','applications':len(d['applied']),'paths':len(d['paths']),'rust_paths':rust,'old_test_functions':count,'byteexact':exact,'explicit_setup_exceptions':changed,'execution':'No full Core build or selector execution yet; bounded source-only. Original current35r2 failures preserved.'}
(B/'composed-source-review.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
