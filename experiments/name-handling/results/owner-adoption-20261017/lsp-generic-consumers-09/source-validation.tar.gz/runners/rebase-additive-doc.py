# Explicit pure-addition documentation composition; never source patch fallback.
import re

def apply_additions(old,chunk):
 lines=chunk.splitlines(True);hunks=[]
 for line in lines:
  if line.startswith('@@'):hunks.append([])
  elif hunks:hunks[-1].append(line)
 if not hunks:return None
 current=old
 for h in hunks:
  removed=[l[1:] for l in h if l.startswith('-')];replacements=[l[1:] for l in h if l.startswith('+')]
  if removed:
   if len(removed)!=1 or len(replacements)!=1:return None
   before_row=removed[0];after_row=replacements[0]
   if not before_row.startswith('|') or not after_row.startswith('|') or before_row.split('|')[1]!=after_row.split('|')[1] or current.count(before_row)!=1:return None
   current=current.replace(before_row,after_row,1)
   continue
  if any(l and l[0] not in ' +\\' for l in h):return None
  blocks=[];i=0
  while i<len(h):
   if not h[i].startswith('+'):i+=1;continue
   start=i
   while i<len(h) and h[i].startswith('+'):i+=1
   added=''.join(l[1:] for l in h[start:i]);before=[l[1:] for l in h[:start] if l.startswith(' ') and l[1:].strip()];after=[l[1:] for l in h[i:] if l.startswith(' ') and l[1:].strip()]
   # Table insertions use exact unique surrounding rows/marker; extra sibling
   # rows may intervene but no actual context text is reconstructed.
   if all(not l.strip() or l.startswith('|') for l in added.splitlines()):
    anchor=after[0] if after else None
    if not anchor or current.count(anchor)!=1:return None
    point=current.index(anchor)
    if not before or current.count(before[-1])!=1 or current.index(before[-1])+len(before[-1])>point:return None
    cursor=0
    for context_line in before+after:
     found=current.find(context_line,cursor)
     if found<0:return None
     cursor=found+len(context_line)
    if added in current:return None
    current=current[:point]+added+current[point:]
   # Actual EOF append: context suffix must remain complete/unique and the
   # original chunk has no following source context. Sibling EOF appends may
   # already follow that exact anchor.
   elif not after:
    context=''.join(l[1:] for l in h[:start] if l.startswith(' '))
    if not context.strip() or current.count(context)!=1 or added in current:return None
    current=current+added
   else:return None
 return current
