from pathlib import Path
import subprocess,os,json,hashlib,shutil,time,datetime,signal
W=Path('/workspace/naming-work');R=Path('/workspace/tcl-lsp');B=W/'lsp-build-34';prior=W/'ordinary-33'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert json.loads((prior/'build-result.json').read_text())['exit']==101
assert (prior/'build-inputs.json').read_bytes()==(prior/'build-post-inputs.json').read_bytes()
assert (prior/'build-providers.json').read_bytes()==(prior/'build-post-providers.json').read_bytes()
admission=json.loads((W/'integration-34/composition.json').read_text());assert admission['complete'] and not admission['outside_main']
for name in admission['paths']:assert (R/name).read_bytes()==(W/'integration-34/compose'/name).read_bytes()
B.mkdir(exist_ok=False)
(B/'prior-build-and-admission.json').write_text(json.dumps({'ordinary33_result_sha256':sha(prior/'build-result.json'),'ordinary33_status':'FAIL sole Registry libtest E0716, no tests executed; no successful-build inference','admission34_sha256':sha(W/'integration-34/composition.json'),'source_review_sha256':sha(W/'integration-34/composed-source-review.json'),'scope':'Fresh direct LSP unit-test build, plus actual Registry/SpecTcl/Studio dependencies. No Compiler libtest or VM/runtime test/migration completion claim.'},indent=2)+'\n')
env=os.environ.copy();env.update(PATH=str(W/'bin')+':/workspace/.cargo/bin:'+env['PATH'],RUSTUP_HOME='/workspace/.rustup',CARGO_HOME='/workspace/.cargo',CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_PROFILE_TEST_DEBUG='0',TCL_LSP_REQUIRE_TCLSH='9.0,8.6',TCL_LSP_JIMSH=str(R/'tmp/jimtcl-oracle/jimsh'))
assert not [k for k,v in env.items() if v and (k.startswith('TCL_LSP_TRACE') or k=='TCL_LSP_NATIVE_CODEGEN_DIAGNOSTIC')]
for script,name in [('capture-inputs.py','build-inputs.json'),('capture-providers.py','build-providers.json')]:subprocess.run(['python',str(W/script),str(B/name)],env=env,check=True)
argv=['cargo','test','--offline','--locked','--no-run','--message-format=json','--lib','--bins'];packages=['tcl-lsp-core','tcl-lsp-db','tcl-lsp-server','tcl-registry','tcl-spectcl','tcl-spec-studio']
for p in packages:argv+=['-p',p]
started=datetime.datetime.now(datetime.timezone.utc).isoformat();stop=None
with (B/'build.jsonl').open('wb') as out,(B/'build.stderr').open('wb') as err:
 process=subprocess.Popen(argv,cwd=R,env=env,stdout=out,stderr=err,start_new_session=True)
 while process.poll() is None:
  if shutil.disk_usage(B).free<200_000_000:stop='diskguard below200MB';os.killpg(process.pid,signal.SIGTERM);break
  time.sleep(1)
 try:code=process.wait(timeout=20)
 except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);code=process.wait()
record={'started':started,'ended':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':argv,'environment':{k:env[k] for k in ['CARGO_BUILD_JOBS','CARGO_INCREMENTAL','CARGO_PROFILE_TEST_DEBUG','TCL_LSP_REQUIRE_TCLSH','TCL_LSP_JIMSH']},'exit':code,'aborted':stop,'stdout_sha256':sha(B/'build.jsonl'),'stderr_sha256':sha(B/'build.stderr'),'source_root':str(R),'tests_executed':False};(B/'build-result.json').write_text(json.dumps(record,indent=2)+'\n')
for script,name in [('capture-inputs.py','build-post-inputs.json'),('capture-providers.py','build-post-providers.json')]:subprocess.run(['python',str(W/script),str(B/name)],env=env,check=True)
assert (B/'build-inputs.json').read_bytes()==(B/'build-post-inputs.json').read_bytes(),'source drift during build'
assert (B/'build-providers.json').read_bytes()==(B/'build-post-providers.json').read_bytes(),'provider drift during build'
assert code==0 and not stop,'actual direct LSP build failed'
artifacts={};extra=[];finished=[]
for line in (B/'build.jsonl').open():
 j=json.loads(line)
 if j.get('reason')=='build-finished':finished.append(j['success'])
 if j.get('reason')!='compiler-artifact' or not j.get('executable'):continue
 t=j['target'];name=t['name']
 if 'lib' not in t['kind']:extra.append(j);continue
 assert name in [x.replace('-','_') for x in packages] and name not in artifacts
 assert j['profile']['test'] is True and j['profile']['debuginfo']==0 and j['profile']['debug_assertions'] is True
 p=Path(j['executable']);assert p.resolve().is_relative_to((R/'target').resolve()) and p.read_bytes()[:4]==b'\x7fELF'
 artifacts[name]={'path':str(p),'sha256':sha(p),'target':t,'features':j['features'],'profile':j['profile'],'fresh':j['fresh']}
assert finished==[True] and len(artifacts)==6,(finished,list(artifacts));(B/'artifacts.json').write_text(json.dumps(artifacts,indent=2)+'\n');(B/'additional-test-artifact-rows.json').write_text(json.dumps(extra,indent=2)+'\n');print(json.dumps({'status':'ACTUAL_DIRECT_LSP_BUILD_SOURCE_PROVIDER_GUARDS_PASS','artifacts':len(artifacts),'build_result_sha256':sha(B/'build-result.json'),'artifacts_sha256':sha(B/'artifacts.json'),'tests_executed':False}))
