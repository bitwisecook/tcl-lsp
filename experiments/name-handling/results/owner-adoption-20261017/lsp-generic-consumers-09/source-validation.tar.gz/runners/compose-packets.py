import sys,json,hashlib,shutil,subprocess,re
import importlib.util
_spec=importlib.util.spec_from_file_location("rebase_additive_doc","/workspace/naming-work/rebase-additive-doc.py");_doc=importlib.util.module_from_spec(_spec);_spec.loader.exec_module(_doc)
from pathlib import Path
root=Path('/workspace/tcl-lsp');base=Path('/workspace/naming-work')
config=Path(sys.argv[1]);out=config.parent;dst=out/'compose'
if dst.exists():shutil.rmtree(dst)
dst.mkdir()
patches=json.loads(config.read_text());paths=set();records=[];before={}
for row in patches:
 p=base/row['path'];assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'],str(p)
 for line in p.read_text().splitlines():
  if line.startswith('+++ b/') or line.startswith('--- a/'):paths.add(line[6:])
for name in paths:
 p=root/name;q=dst/name
 before[name]=hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None
 if p.exists():q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
for row in patches:
 p=base/row['path'];logs=[];failed=False
 for index,chunk in enumerate(re.split(r'(?m)(?=^--- (?:a/|/dev/null))',p.read_text())):
  if not chunk.strip():continue
  piece=out/'piece.patch';piece.write_text(chunk)
  r=subprocess.run(['patch','--batch','--forward','--dry-run','--fuzz=0','-p1','-i',str(piece)],cwd=dst,text=True,capture_output=True)
  if r.returncode:
   lines=chunk.splitlines(True);target=next(l[6:].strip() for l in lines if l.startswith('+++ b/'))
   body=lines[next(i for i,l in enumerate(lines) if l.startswith('@@'))+1:]
   context=''.join(l[1:] for l in body if l.startswith(' '));added=''.join(l[1:] for l in body if l.startswith('+'))
   if target.startswith('docs/') and target.endswith('.md') and sum(l.startswith('@@') for l in lines)==1 and not any(l.startswith('-') for l in body) and context and (dst/target).read_text().count(context)==1:
    old=(dst/target).read_text();assert added and old.endswith('\n');(dst/target).write_text(old+added);logs.append('Explicit pure-addition documentation EOF rebase: '+target)
   elif target.startswith('docs/') and target.endswith('.md') and (rebased:=_doc.apply_additions((dst/target).read_text(),chunk)) is not None:
    (dst/target).write_text(rebased);logs.append('Explicit pure-addition documentation ordered-table/EOF rebase: '+target)
   else:print('HOLD',p,r.stdout,r.stderr);failed=True;break
  else:
   r=subprocess.run(['patch','--batch','--forward','--fuzz=0','--no-backup-if-mismatch','-p1','-i',str(piece)],cwd=dst,text=True,capture_output=True);assert r.returncode==0;logs.append(r.stdout)
 if failed:break
 records.append({'patch':str(p),'sha256':row['sha256'],'output':'\n'.join(logs)})
(out/'composition.json').write_text(json.dumps({'base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'before_sha256':before,'outside_main':True,'applied':records,'paths':sorted(paths),'complete':len(records)==len(patches)},indent=2)+'\n');print({'applied':len(records),'requested':len(patches),'files':len(paths)})
