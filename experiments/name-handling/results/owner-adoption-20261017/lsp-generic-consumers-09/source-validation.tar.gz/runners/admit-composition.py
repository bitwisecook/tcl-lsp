from pathlib import Path
import sys,json,subprocess,difflib,hashlib
r=Path('/workspace/tcl-lsp');b=Path(sys.argv[1]);d=json.loads((b/'composition.json').read_text());assert d['complete'] and d['outside_main'];parts=[]
for name in d['paths']:
 p=r/name;q=b/'compose'/name
 if 'before_sha256' in d:assert (hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None)==d['before_sha256'][name],name
 old=p.read_text() if p.exists() else '';new=q.read_text() if q.exists() else ''
 if old!=new:
  result=subprocess.run(['diff','-u','--label','a/'+name if p.exists() else '/dev/null','--label','b/'+name,str(p) if p.exists() else '/dev/null',str(q)],text=True,capture_output=True)
  assert result.returncode==1,(name,result.stderr)
  parts.append(result.stdout)
patch=b/'composed-source.patch';patch.write_text(''.join(parts));subprocess.run(['git','apply','--check',str(patch)],cwd=r,check=True);subprocess.run(['git','apply',str(patch)],cwd=r,check=True)
for name in d['paths']:assert (r/name).read_bytes()==(b/'compose'/name).read_bytes(),name
d.update(outside_main=False,composed_patch_sha256=hashlib.sha256(patch.read_bytes()).hexdigest());(b/'composition.json').write_text(json.dumps(d,indent=2)+'\n');print('Integrated',len(d['applied']),'reviewed packets',len(d['paths']),'paths')
