from pathlib import Path
import datetime,hashlib,json,os,subprocess

W=Path('/workspace/naming-work');R=Path('/workspace/tcl-lsp');B=W/'lsp-build-35r2';O=W/'lsp-35r2'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert json.loads((B/'build-result.json').read_text())['exit']==0
assert (B/'artifacts.json').is_file()
O.mkdir(exist_ok=False)
env=os.environ.copy();env.update(PATH=str(W/'bin')+':/workspace/.cargo/bin:'+env['PATH'],RUSTUP_HOME='/workspace/.rustup',CARGO_HOME='/workspace/.cargo',TCL_LSP_REQUIRE_TCLSH='9.0,8.6',TCL_LSP_JIMSH=str(R/'tmp/jimtcl-oracle/jimsh'))
artifacts=json.loads((B/'artifacts.json').read_text())
for item in artifacts.values():assert sha(Path(item['path']))==item['sha256']
for script,name,reference in [('capture-inputs.py','pre-inputs.json','build-inputs.json'),('capture-providers.py','pre-providers.json','build-providers.json')]:
 subprocess.run(['python',str(W/script),str(O/name)],env=env,check=True)
 assert (O/name).read_bytes()==(B/reference).read_bytes(),reference+' drift before LSP execution'
remote=subprocess.run(['git','ls-remote','https://github.com/msteveb/jimtcl.git','HEAD','refs/heads/master'],text=True,capture_output=True,timeout=60)
(O/'jim-remote-at-execution.json').write_text(json.dumps({'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':remote.args,'exit':remote.returncode,'stdout':remote.stdout,'stderr':remote.stderr,'scope':'Actual upstream ref observation at LSP execution; provider semantics come from exact invoked executables, not this ref read.'},indent=2)+'\n')
assert remote.returncode==0 and remote.stdout.splitlines() and all(line.split()[0]=='5bac7c99ad65864c87da513e22e2f01703fa4e03' for line in remote.stdout.splitlines())
selections=[('original',W/'recovered-current-capsule/source/current-actual-source1024-v3/selection.json','b2ba07fcace4c53e099112488b514b1a76009235f45cd37581363f66a5ff2922',['tcl_lsp_db','tcl_lsp_core','tcl_lsp_server']),('additive21',W/'integration-21/additive-selection-r2.json','8b276c87e3611ac599f0cf550eb71cf8172f3b206e15325e6b693001b9cc503d',['tcl_lsp_core','tcl_lsp_server'])]
inventory=W/'lsp-admissions22-33-extra-controls-v1/proposed-additional-lsp-selectors.json';assert sha(inventory)=='bd9f6a6a46eeb63e3eca5d7402cb118180b656fa4fbc63b21fdfe7403c20c813'
controls=json.loads(inventory.read_text())['selectors'];assert len(controls)==5 and all(row['crate']=='tcl_lsp_core' and sha(R/row['source_path'])==row['current_source_sha256'] for row in controls)
prior={(target,name) for _,manifest,pin,_ in selections for target,names in json.loads(manifest.read_text())['groups'].items() for name in names};assert all((row['crate'],row['selector']) not in prior for row in controls)
new_manifest=O/'additional33-selection.json';new_manifest.write_text(json.dumps({'group':'Five additional direct LSP source controls admissions22-33; separate from unchanged retained selections','total_exact_selectors':5,'groups':{'tcl_lsp_core':[row['selector'] for row in controls]},'expected_group_counts':{'tcl_lsp_core':5},'execution_order':[{'target':row['crate'],'selector':row['selector']} for row in controls],'test_timeout_seconds':180,'listing_timeout_seconds':30,'environment':{'set':{'TCL_LSP_REQUIRE_TCLSH':'9.0,8.6'},'unset':[]},'inventory_sha256':sha(inventory)},indent=2)+'\n')
selections.append(('additional33',new_manifest,sha(new_manifest),['tcl_lsp_core']))
runner=R/'experiments/name-handling/validation/retained-selections/replay-selection.py';assert sha(runner)=='aaa269431e0a0f3024367d0a2528b4671408e11cf7a57e801caa2429f181e6c3'
summary={'status':'RUNNING_DIRECT_LSP_SUBGROUPS_ONLY','started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_sha256':sha(O/'pre-inputs.json'),'providers_sha256':sha(O/'pre-providers.json'),'artifacts_sha256':sha(B/'artifacts.json'),'runs':[],'scope':'Explicit Core/DB/Server subgroup captures retain original selection manifests/order within each target. They do not constitute full original1024 or additive314 execution, compiler verification, or VM/runtime migration.'}
def save(): (O/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
save()
for label,manifest,pin,groups in selections:
 for group in groups:
  out=O/(label+'-'+group)
  command=['python',str(runner),'--manifest',str(manifest),'--manifest-sha256',pin,'--artifacts',str(B/'artifacts.json'),'--root',str(R),'--out',str(out),'--group',group]
  with (O/(out.name+'.runner.log')).open('wb') as log: p=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT)
  result=json.loads((out/'result.json').read_text());assert not result['errors'] and not result['artifact_drift'] and result['selected_vector_complete']
  summary['runs'].append({'selection':label,'target':group,'exit':p.returncode,'result_sha256':sha(out/'result.json'),'passed':result['passed_count'],'failed':result['failed_count'],'count':len(result['runs']),'partial_target':result['partial_target'],'full_group_complete':result['full_group_complete']});save()
for script,name,reference in [('capture-inputs.py','post-inputs.json','pre-inputs.json'),('capture-providers.py','post-providers.json','pre-providers.json')]:
 subprocess.run(['python',str(W/script),str(O/name)],env=env,check=True)
 assert (O/name).read_bytes()==(O/reference).read_bytes(),reference+' drift during LSP execution'
for item in artifacts.values():assert sha(Path(item['path']))==item['sha256']
summary.update(status='DIRECT_LSP_SUBGROUPS_EXECUTED_GUARDS_PASS',ended=datetime.datetime.now(datetime.timezone.utc).isoformat(),passed=sum(r['passed'] for r in summary['runs']),failed=sum(r['failed'] for r in summary['runs']),source_provider_artifact_drift=False);save();print(json.dumps(summary))
