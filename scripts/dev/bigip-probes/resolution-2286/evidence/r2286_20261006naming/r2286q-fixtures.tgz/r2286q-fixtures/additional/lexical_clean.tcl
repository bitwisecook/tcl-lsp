set prefix __tcl_lsp_2286_r2286q_lexclean_
set rows {}
foreach pair [list [list format_pre [format %c 233]] [list format_comb [format %c 769]] [list bytes_pre [binary format H* c3a9]] [list bytes_comb [binary format H* cc81]] [list nul [binary format H* 0042]]] {
    set label [lindex $pair 0]
    set suffix [lindex $pair 1]
    set name $prefix
    append name $suffix
    set seed_rc [catch {set $prefix SHORT_PREFIX} seed_result]
    set write_rc [catch {set $name FULL_VALUE} write_result]
    foreach form {unbraced braced} {
        set script "set observed \$"
        if {$form eq "braced"} {
            append script "\{" $name "\}"
        } else {
            append script $name
        }
        binary scan $script H* script_hex
        set rc [catch {eval $script} result]
        binary scan $result H* result_hex
        lappend rows [list $label $form seed $seed_rc write $write_rc script_hex $script_hex eval $rc result_hex $result_hex]
    }
    catch {unset $name}
    catch {unset $prefix}
    catch {unset observed}
}
set rows
