set rows {}
foreach item {patchlevel tclversion} {
    set rc [catch {info $item} result]
    lappend rows [list info $item $rc $result]
}
set rc [catch {package provide Tcl} result]
lappend rows [list package_Tcl $rc $result]
foreach command {array binary catch encoding eval format info interp namespace package proc rename set trace unset uplevel upvar} {
    set rc [catch {info commands $command} result]
    lappend rows [list command $command $rc [llength $result] $result]
}
set rc [catch {lsort [info commands]} result]
lappend rows [list all_commands $rc $result]
set rows
