when HTTP_REQUEST {
    set nul [format %c 0]
    set rows {}
    foreach spec {
        {short x}
        {long __resolution2286_context_invariance_long_ascii_prefix_0123456789}
        {different relocated_2286_key}
    } {
        set label [lindex $spec 0]
        set plain [lindex $spec 1]
        set name $plain
        append name $nul B $nul C
        catch {unset $plain}
        catch {unset $name}
        set plain_rc [catch {set $plain PLAIN} plain_result]
        set name_rc [catch {set $name COUNTED} name_result]
        foreach input [list $plain $name] {
            binary scan $input H* input_hex
            set rc [catch {set $input} result]
            binary scan $result H* result_hex
            lappend rows [list $label name_hex $input_hex write_plain $plain_rc write_counted $name_rc read $rc result_hex $result_hex]
        }
        catch {unset $name}
        set rc [catch {set $plain} result]
        binary scan $result H* result_hex
        lappend rows [list $label after_counted_unset $rc result_hex $result_hex]
        catch {unset $plain}
    }
    set inputs [list {} {()} {(k)} {A()} {A(k)} {A(k(l))} {A(k)tail} {:} {A:B} {A::B}]
    foreach input $inputs {
        binary scan $input H* input_hex
        set rc [catch {set $input GRAMMAR_VALUE} result]
        binary scan $result H* result_hex
        lappend rows [list grammar name_hex $input_hex write $rc result_hex $result_hex]
        set read_rc [catch {set $input} read_result]
        binary scan $read_result H* read_hex
        lappend rows [list grammar name_hex $input_hex read $read_rc result_hex $read_hex]
        catch {unset $input}
    }
    log local0.notice [list RESOLUTION2286_COUNTED_INPUT_BOUNDARIES tmm [TMM::cmp_unit] rows $rows]
    binary scan $rows H* rows_hex
    HTTP::respond 200 content $rows_hex X-R2286-TMM "[TMM::cmp_group]:[TMM::cmp_unit]" Connection close
}
