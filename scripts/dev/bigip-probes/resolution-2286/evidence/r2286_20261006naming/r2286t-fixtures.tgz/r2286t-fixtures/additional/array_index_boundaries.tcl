set nul [format %c 0]
set rows {}
set trace_rows {}
set root __resolution2286_r2286t_index_root
set traceproc ::__tcl_lsp_2286_r2286t_index_boundary_trace
set callback_body {upvar 1 trace_rows trace_rows; binary scan $name1 H* root_hex; binary scan $name2 H* index_hex; lappend trace_rows [list $root_hex $index_hex $op]}
catch {eval [list rename $traceproc {}]}
set trace_proc_rc [catch {eval [list proc $traceproc {name1 name2 op} $callback_body]} trace_proc_result]
lappend rows [list trace_proc $trace_proc_rc $trace_proc_result]
set grammar_indices [list {} {()} {(k)} {A()} {A(k)} {A(k(l))} {A(k)tail} {:} {A:B} {A::B}]
foreach index $grammar_indices {
    catch {unset $root}
    set trace_rows {}
    set trace_rc [catch {trace variable $root rwu $traceproc} trace_result]
    set variable $root
    append variable ( $index )
    binary scan $index H* index_hex
    set write_rc [catch {set $variable GRAMMAR_VALUE} write_result]
    set read_rc [catch {set $variable} read_result]
    binary scan $read_result H* read_hex
    set unset_rc [catch {unset $variable} unset_result]
    lappend rows [list grammar_index index_hex $index_hex trace_add $trace_rc write $write_rc $write_result read $read_rc $read_hex unset $unset_rc $unset_result traces $trace_rows]
    catch {trace vdelete $root rwu $traceproc}
    catch {unset $root}
}
set pairs {}
foreach spec {
    {short q}
    {long __resolution2286_context_invariance_long_array_index_0123456789}
    {different elsewhere_2286_array_index}
} {
    set label [lindex $spec 0]
    set plain [lindex $spec 1]
    set counted $plain
    append counted $nul B $nul C
    lappend pairs [list $label $plain $counted]
}
set leading $nul
append leading B $nul C leading_index
lappend pairs [list leading {} $leading]
set middle relocated_
append middle $nul B $nul C middle_index
lappend pairs [list middle relocated_ $middle]
foreach pair $pairs {
    set label [lindex $pair 0]
    set plain [lindex $pair 1]
    set counted [lindex $pair 2]
    binary scan $plain H* plain_hex
    binary scan $counted H* counted_hex
    foreach order {plain_first counted_first} {
        catch {unset index_alias}
        catch {trace vdelete $root rwu $traceproc}
        catch {unset $root}
        set trace_rows {}
        set trace_rc [catch {trace variable $root rwu $traceproc} trace_result]
        set plain_var $root
        append plain_var ( $plain )
        set counted_var $root
        append counted_var ( $counted )
        if {$order eq "plain_first"} {
            set writes [list [list $plain_var PLAIN] [list $counted_var COUNTED]]
            set unsets [list $counted_var $plain_var]
        } else {
            set writes [list [list $counted_var COUNTED] [list $plain_var PLAIN]]
            set unsets [list $plain_var $counted_var]
        }
        set write_rows {}
        foreach write $writes {
            set write_rc [catch {set [lindex $write 0] [lindex $write 1]} write_result]
            lappend write_rows [list $write_rc $write_result]
        }
        set read_rows {}
        foreach input [list $plain_var $counted_var] {
            set read_rc [catch {set $input} read_result]
            binary scan $read_result H* read_hex
            lappend read_rows [list $read_rc $read_hex]
        }
        set upvar_rc [catch {upvar 0 $counted_var index_alias; set index_alias COUNTED_MUTATION} upvar_result]
        set unset_rc [catch {unset [lindex $unsets 0]} unset_result]
        set survivor_rc [catch {set [lindex $unsets 1]} survivor_result]
        binary scan $survivor_result H* survivor_hex
        lappend rows [list index $label order $order plain_hex $plain_hex counted_hex $counted_hex trace_add $trace_rc writes $write_rows reads $read_rows upvar $upvar_rc $upvar_result unset_first $unset_rc $unset_result survivor $survivor_rc $survivor_hex traces $trace_rows]
    }
}
catch {unset index_alias}
catch {trace vdelete $root rwu $traceproc}
catch {unset $root}
catch {eval [list rename $traceproc {}]}
set rows
