set nul [format %c 0]
set rows {}
set trace_rows {}
set traceproc ::__tcl_lsp_2286_r2286t_root_boundary_trace
set callback_body {upvar 1 trace_rows trace_rows; binary scan $name1 H* root_hex; binary scan $name2 H* index_hex; lappend trace_rows [list $root_hex $index_hex $op]}
catch {eval [list rename $traceproc {}]}
set trace_proc_rc [catch {eval [list proc $traceproc {name1 name2 op} $callback_body]} trace_proc_result]
lappend rows [list trace_proc $trace_proc_rc $trace_proc_result]
set ns ::__resolution2286_r2286t_root_namespace
set ns_rc [catch {namespace eval $ns {}} ns_result]
lappend rows [list namespace_create $ns_rc $ns_result]
set pairs {}
foreach spec {
    {short relocated_root}
    {long __resolution2286_context_invariance_long_array_root_0123456789}
    {different elsewhere_2286_array_root}
    {colon root:colon}
    {parentheses root(k)}
} {
    set label [lindex $spec 0]
    set plain [lindex $spec 1]
    set counted $plain
    append counted $nul B $nul C
    lappend pairs [list $label $plain $counted]
}
set leading $nul
append leading B $nul C leading_root
lappend pairs [list leading {} $leading]
set middle relocated_
append middle $nul B $nul C middle_root
lappend pairs [list middle relocated_ $middle]
set qualified $ns
append qualified ::A
set qualified_counted $qualified
append qualified_counted $nul B $nul C
lappend pairs [list qualified $qualified $qualified_counted]
foreach pair $pairs {
    set label [lindex $pair 0]
    set plain [lindex $pair 1]
    set counted [lindex $pair 2]
    binary scan $plain H* plain_hex
    binary scan $counted H* counted_hex
    foreach order {plain_first counted_first} {
        catch {unset root_alias}
        catch {trace vdelete $plain rwu $traceproc}
        catch {trace vdelete $counted rwu $traceproc}
        catch {unset $plain}
        catch {unset $counted}
        set trace_rows {}
        set plain_trace_rc [catch {trace variable $plain rwu $traceproc} plain_trace_result]
        set counted_trace_rc [catch {trace variable $counted rwu $traceproc} counted_trace_result]
        set plain_var $plain
        append plain_var (k)
        set counted_var $counted
        append counted_var (k)
        if {$order eq "plain_first"} {
            set writes [list [list $plain_var PLAIN] [list $counted_var COUNTED]]
            set unsets [list $counted $plain]
        } else {
            set writes [list [list $counted_var COUNTED] [list $plain_var PLAIN]]
            set unsets [list $plain $counted]
        }
        set write_rows {}
        foreach write $writes {
            set write_rc [catch {set [lindex $write 0] [lindex $write 1]} write_result]
            lappend write_rows [list $write_rc $write_result]
        }
        set read_rows {}
        foreach input [list $plain_var $counted_var] {
            set read_rc [catch {set $input} read_result]
            binary scan $read_result H* read_hex
            lappend read_rows [list $read_rc $read_hex]
        }
        set upvar_rc [catch {upvar 0 $counted root_alias; set root_alias(k) COUNTED_MUTATION} upvar_result]
        set first_root [lindex $unsets 0]
        set survivor_root [lindex $unsets 1]
        set survivor_var $survivor_root
        append survivor_var (k)
        set unset_rc [catch {unset $first_root} unset_result]
        set survivor_rc [catch {set $survivor_var} survivor_result]
        binary scan $survivor_result H* survivor_hex
        lappend rows [list root $label order $order plain_hex $plain_hex counted_hex $counted_hex trace_add [list $plain_trace_rc $counted_trace_rc] writes $write_rows reads $read_rows upvar $upvar_rc $upvar_result unset_first $unset_rc $unset_result survivor $survivor_rc $survivor_hex traces $trace_rows]
    }
    catch {unset root_alias}
    catch {trace vdelete $plain rwu $traceproc}
    catch {trace vdelete $counted rwu $traceproc}
    catch {unset $plain}
    catch {unset $counted}
}
catch {eval [list rename $traceproc {}]}
catch {namespace delete $ns}
set rows
