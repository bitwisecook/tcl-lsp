set ns ::__tcl_lsp_2286_r2286r_qualified
set traceproc ::__tcl_lsp_2286_r2286r_qualified_trace
set rows {}
set trace_rows {}
set ns_create_rc [catch {namespace eval $ns {}} ns_create_result]
lappend rows [list namespace_create $ns_create_rc $ns_create_result]
set callback_body {upvar 1 trace_rows trace_rows; binary scan $name1 H* root_hex; binary scan $name2 H* index_hex; lappend trace_rows [list $root_hex $index_hex $op]}
catch {eval [list rename $traceproc {}]}
set trace_proc_rc [catch {eval [list proc $traceproc {name1 name2 op} $callback_body]} trace_proc_result]
lappend rows [list trace_proc $trace_proc_rc $trace_proc_result]
set plain $ns
append plain ::A
set counted $plain
append counted [binary format H* 0042]
binary scan $plain H* plain_hex
binary scan $counted H* counted_hex
lappend rows [list scalar_roots $plain_hex $counted_hex]
foreach pair [list [list $counted COUNTED] [list $plain PLAIN]] {
    set rc [catch {set [lindex $pair 0] [lindex $pair 1]} result]
    lappend rows [list scalar_write $rc $result]
}
set rc [catch {upvar 0 $counted scalar_alias; set scalar_alias COUNTED_MUTATION} result]
lappend rows [list scalar_upvar $rc $result]
set rc [catch {unset $plain} result]
lappend rows [list scalar_unset_plain $rc $result]
foreach name [list $plain $counted] {
    set rc [catch {set $name} result]
    lappend rows [list scalar_after_unset $rc $result]
}
catch {unset scalar_alias}
catch {unset $plain}
catch {unset $counted}
foreach root [list $plain $counted] {
    set rc [catch {trace variable $root rwu $traceproc} result]
    lappend rows [list array_trace_add $rc $result]
}
set plain_var $plain
append plain_var (k)
set counted_var $counted
append counted_var (k)
foreach pair [list [list $plain_var PLAIN_ARRAY] [list $counted_var COUNTED_ARRAY]] {
    set rc [catch {set [lindex $pair 0] [lindex $pair 1]} result]
    lappend rows [list array_write $rc $result]
}
set rc [catch {upvar 0 $counted array_alias; set array_alias(k) COUNTED_ARRAY_MUTATION} result]
lappend rows [list array_upvar $rc $result]
set rc [catch {unset $counted} result]
lappend rows [list array_unset_counted $rc $result]
foreach name [list $plain_var $counted_var] {
    set rc [catch {set $name} result]
    lappend rows [list array_after_unset $rc $result]
}
set index_root $ns
append index_root ::IndexRoot
set plain_index A
set counted_index $plain_index
append counted_index [binary format H* 0042]
set rc [catch {trace variable $index_root rwu $traceproc} result]
lappend rows [list index_trace_add $rc $result]
set plain_index_var $index_root
append plain_index_var ( $plain_index )
set counted_index_var $index_root
append counted_index_var ( $counted_index )
foreach pair [list [list $counted_index_var COUNTED_INDEX] [list $plain_index_var PLAIN_INDEX]] {
    set rc [catch {set [lindex $pair 0] [lindex $pair 1]} result]
    lappend rows [list index_write $rc $result]
}
set rc [catch {upvar 0 $counted_index_var index_alias; set index_alias COUNTED_INDEX_MUTATION} result]
lappend rows [list index_upvar $rc $result]
set rc [catch {unset $plain_index_var} result]
lappend rows [list index_unset_plain $rc $result]
foreach name [list $plain_index_var $counted_index_var] {
    set rc [catch {set $name} result]
    lappend rows [list index_after_unset $rc $result]
}
lappend rows [list trace_rows $trace_rows]
foreach root [list $plain $counted $index_root] {catch {trace vdelete $root rwu $traceproc}; catch {unset $root}}
catch {eval [list rename $traceproc {}]}
set ns_current_rc [catch {namespace current} ns_current_result]
set ns_which_rc [catch {namespace which -command set} ns_which_result]
lappend rows [list namespace_inventory $ns_current_rc $ns_current_result $ns_which_rc $ns_which_result]
catch {namespace delete $ns}
set rows
