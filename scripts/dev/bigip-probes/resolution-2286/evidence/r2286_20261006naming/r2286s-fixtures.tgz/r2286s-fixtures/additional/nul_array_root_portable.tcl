set trace_rows {}
set prefix __tcl_lsp_2286_r2286s_arrayroot_
set plain $prefix
append plain A
set counted $plain
append counted [binary format H* 0042]
set plain_var $plain
append plain_var (k)
set counted_var $counted
append counted_var (k)
set procname ::__tcl_lsp_2286_r2286s_nul_array_root_trace
set rows [list [list roots [string length $plain] [string length $counted]]]
set callback_body {upvar 1 trace_rows trace_rows; binary scan $name1 H* root_hex; binary scan $name2 H* index_hex; lappend trace_rows [list $root_hex $index_hex $op]}
catch {eval [list rename $procname {}]}
set rc [catch {eval [list proc $procname {name1 name2 op} $callback_body]} result]
lappend rows [list trace_proc $rc $result]
set rc [catch {foreach root [list $plain $counted] {trace variable $root rwu $procname}} result]
lappend rows [list trace_add $rc $result]
foreach item [list [list $plain_var PLAIN] [list $counted_var COUNTED]] {
    set varname [lindex $item 0]
    set rc [catch {set $varname [lindex $item 1]} result]
    lappend rows [list write [string length $varname] $rc $result]
}
foreach item [list [list plain $plain_var] [list counted $counted_var]] {
    set label [lindex $item 0]
    set varname [lindex $item 1]
    lappend rows [list exists $label [info exists $varname]]
    set rc [catch {set $varname} result]
    lappend rows [list read $label $rc $result]
}
set rc [catch {upvar 0 $counted alias; set alias(k) COUNTED_MUTATION} result]
lappend rows [list upvar_write $rc $result]
foreach item [list [list plain $plain_var] [list counted $counted_var]] {
    set rc [catch {set [lindex $item 1]} result]
    lappend rows [list after_link [lindex $item 0] $rc $result]
}
set rc [catch {unset $counted} result]
lappend rows [list unset_counted_root $rc $result]
foreach item [list [list plain $plain_var] [list counted $counted_var]] {
    set varname [lindex $item 1]
    lappend rows [list after_unset_exists [lindex $item 0] [info exists $varname]]
    set rc [catch {set $varname} result]
    lappend rows [list after_unset_read [lindex $item 0] $rc $result]
}
foreach root [list $plain $counted] {catch {trace vdelete $root rwu $procname}; catch {unset $root}}
catch {eval [list rename $procname {}]}
lappend rows [list trace_rows $trace_rows]
set rows
