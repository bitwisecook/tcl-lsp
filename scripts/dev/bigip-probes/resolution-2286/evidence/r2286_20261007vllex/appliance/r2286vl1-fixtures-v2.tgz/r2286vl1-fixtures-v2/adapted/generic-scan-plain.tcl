proc hex {s} {binary scan $s H* out; return $out}
namespace eval N {}
set n {v}
set c [catch {set h scan; $h 17 %d $n} r]
set exists [info exists $n]
set rc [catch {set $n} got]
set summary [list $c [hex $r] $exists $rc [hex $got]]
set summary
