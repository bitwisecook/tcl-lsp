when RULE_INIT {
set r2286_lbc_context RULE_INIT
set r2286_lbc_group_rc [catch {TMM::cmp_group} r2286_lbc_group]
set r2286_lbc_unit_rc [catch {TMM::cmp_unit} r2286_lbc_unit]
set r2286_lbc_identity [list $r2286_lbc_group_rc $r2286_lbc_group $r2286_lbc_unit_rc $r2286_lbc_unit]
set r2286_lbc_session init
set r2286_lbc_rows {}
for {set r2286_lbc_i 0} {$r2286_lbc_i < 261} {incr r2286_lbc_i} {
    foreach r2286_lbc_source_kind {append_source binary_source} {
        foreach r2286_lbc_form {unbraced braced} {
            if {$r2286_lbc_i < 256} {
                set r2286_lbc_factory [list binary_byte $r2286_lbc_i]
                set r2286_lbc_payload [binary format H* [format %02x $r2286_lbc_i]]
            } else {
                switch -- $r2286_lbc_i {
                    256 {
                        set r2286_lbc_factory [list format_c 233]
                        set r2286_lbc_payload [format %c 233]
                    }
                    257 {
                        set r2286_lbc_factory [list format_c 769]
                        set r2286_lbc_payload [format %c 769]
                    }
                    258 {
                        set r2286_lbc_factory [list binary_hex c3a9]
                        set r2286_lbc_payload [binary format H* c3a9]
                    }
                    259 {
                        set r2286_lbc_factory [list binary_hex e9]
                        set r2286_lbc_payload [binary format H* e9]
                    }
                    260 {
                        set r2286_lbc_factory [list binary_hex cc81]
                        set r2286_lbc_payload [binary format H* cc81]
                    }
                }
            }
            set r2286_lbc_stem "r2286_lbc_${r2286_lbc_i}_${r2286_lbc_source_kind}_${r2286_lbc_form}_v"
            set r2286_lbc_full $r2286_lbc_stem
            append r2286_lbc_full $r2286_lbc_payload Q
            set r2286_lbc_targets [list [list $r2286_lbc_stem SHORT]]
            if {$r2286_lbc_i == 258} {
                set r2286_lbc_prefix $r2286_lbc_stem
                append r2286_lbc_prefix [binary format H* c3]
                lappend r2286_lbc_targets [list $r2286_lbc_prefix PREFIX_1]
            }
            if {$r2286_lbc_i == 260} {
                set r2286_lbc_prefix $r2286_lbc_stem
                append r2286_lbc_prefix [binary format H* cc]
                lappend r2286_lbc_targets [list $r2286_lbc_prefix PREFIX_1]
            }
            lappend r2286_lbc_targets [list $r2286_lbc_full FULL]
            set r2286_lbc_setup {}
            set r2286_lbc_add {}
            set r2286_lbc_attached {}
            set r2286_lbc_callback [list lappend ::r2286_lbc_reads]
            foreach r2286_lbc_target $r2286_lbc_targets {
                set r2286_lbc_name [lindex $r2286_lbc_target 0]
                set r2286_lbc_marker [lindex $r2286_lbc_target 1]
                set r2286_lbc_rc [catch {set $r2286_lbc_name $r2286_lbc_marker} r2286_lbc_value]
                lappend r2286_lbc_setup [list $r2286_lbc_marker $r2286_lbc_rc $r2286_lbc_value]
                set r2286_lbc_rc [catch {trace variable $r2286_lbc_name r $r2286_lbc_callback} r2286_lbc_value]
                lappend r2286_lbc_add [list $r2286_lbc_marker $r2286_lbc_rc $r2286_lbc_value]
                if {$r2286_lbc_rc == 0} {
                    lappend r2286_lbc_attached $r2286_lbc_name
                }
            }
            set r2286_lbc_source {list $}
            if {$r2286_lbc_form == "braced"} {append r2286_lbc_source \{}
            append r2286_lbc_source $r2286_lbc_full
            if {$r2286_lbc_form == "braced"} {append r2286_lbc_source \}}
            set r2286_lbc_build_rc 0
            set r2286_lbc_build_result {}
            set r2286_lbc_constructor_hex {}
            if {$r2286_lbc_source_kind == "binary_source"} {
                set r2286_lbc_build_rc [catch {
                    if {$r2286_lbc_i < 256 || $r2286_lbc_i >= 258} {
                        set r2286_lbc_lead {list $}
                        if {$r2286_lbc_form == "braced"} {append r2286_lbc_lead \{}
                        binary scan $r2286_lbc_lead H* r2286_lbc_lead_hex
                        binary scan $r2286_lbc_stem H* r2286_lbc_stem_hex
                        if {$r2286_lbc_i < 256} {
                            set r2286_lbc_byte_hex [format %02x $r2286_lbc_i]
                        } else {
                            switch -- $r2286_lbc_i {
                                258 {set r2286_lbc_byte_hex c3a9}
                                259 {set r2286_lbc_byte_hex e9}
                                260 {set r2286_lbc_byte_hex cc81}
                            }
                        }
                        set r2286_lbc_constructor_hex "$r2286_lbc_lead_hex$r2286_lbc_stem_hex${r2286_lbc_byte_hex}51"
                        if {$r2286_lbc_form == "braced"} {append r2286_lbc_constructor_hex 7d}
                    } else {
                        binary scan $r2286_lbc_source H* r2286_lbc_constructor_hex
                    }
                    set r2286_lbc_source [binary format H* $r2286_lbc_constructor_hex]
                } r2286_lbc_build_result]
            }
            set ::r2286_lbc_reads {}
            set r2286_lbc_eval_rc NOT_REACHED
            set r2286_lbc_eval_result {}
            if {$r2286_lbc_build_rc == 0} {
                set r2286_lbc_eval_rc [catch {eval $r2286_lbc_source} r2286_lbc_eval_result]
            }
            set r2286_lbc_reads $::r2286_lbc_reads
            set r2286_lbc_source_hex {}
            set r2286_lbc_source_scan_rc [catch {binary scan $r2286_lbc_source H* r2286_lbc_source_hex} r2286_lbc_source_scan_result]
            set r2286_lbc_result_hex {}
            set r2286_lbc_result_scan_rc [catch {binary scan $r2286_lbc_eval_result H* r2286_lbc_result_hex} r2286_lbc_result_scan_result]
            set r2286_lbc_payload_hex {}
            set r2286_lbc_payload_scan_rc [catch {binary scan $r2286_lbc_payload H* r2286_lbc_payload_hex} r2286_lbc_payload_scan_result]
            set r2286_lbc_utf8_hex {}
            set r2286_lbc_encoding_rc [catch {
                set r2286_lbc_utf8 [encoding convertto utf-8 $r2286_lbc_source]
                binary scan $r2286_lbc_utf8 H* r2286_lbc_utf8_hex
            } r2286_lbc_encoding_result]
            set r2286_lbc_remove {}
            foreach r2286_lbc_name $r2286_lbc_attached {
                set r2286_lbc_rc [catch {trace vdelete $r2286_lbc_name r $r2286_lbc_callback} r2286_lbc_value]
                lappend r2286_lbc_remove [list $r2286_lbc_rc $r2286_lbc_value]
            }
            set r2286_lbc_cleanup {}
            foreach r2286_lbc_target $r2286_lbc_targets {
                set r2286_lbc_name [lindex $r2286_lbc_target 0]
                set r2286_lbc_rc [catch {unset $r2286_lbc_name} r2286_lbc_value]
                lappend r2286_lbc_cleanup [list $r2286_lbc_rc $r2286_lbc_value]
            }
            lappend r2286_lbc_rows [list \
                case $r2286_lbc_i factory $r2286_lbc_factory \
                source_kind $r2286_lbc_source_kind form $r2286_lbc_form constructor_hex $r2286_lbc_constructor_hex \
                payload_scan [list $r2286_lbc_payload_scan_rc $r2286_lbc_payload_hex $r2286_lbc_payload_scan_result] \
                source_build [list $r2286_lbc_build_rc $r2286_lbc_build_result] \
                source_scan [list $r2286_lbc_source_scan_rc $r2286_lbc_source_hex $r2286_lbc_source_scan_result] \
                eval_code $r2286_lbc_eval_rc \
                result_scan [list $r2286_lbc_result_scan_rc $r2286_lbc_result_hex $r2286_lbc_result_scan_result] \
                reads $r2286_lbc_reads setup $r2286_lbc_setup trace_add $r2286_lbc_add \
                utf8_diagnostic [list $r2286_lbc_encoding_rc $r2286_lbc_utf8_hex $r2286_lbc_encoding_result] \
                trace_remove $r2286_lbc_remove cleanup $r2286_lbc_cleanup]
        }
    }
}
catch {unset ::r2286_lbc_reads}
set r2286_lbc_transcript [list LBC1 $r2286_lbc_context $r2286_lbc_identity [llength $r2286_lbc_rows] $r2286_lbc_rows]
set r2286_lbc_transcript_hex {}
set r2286_lbc_export_rc [catch {binary scan $r2286_lbc_transcript H* r2286_lbc_transcript_hex} r2286_lbc_export_result]
set r2286_lbc_export [list LBC1 $r2286_lbc_export_rc $r2286_lbc_export_result $r2286_lbc_transcript_hex]
set r2286_lbc_log_hex {}
set r2286_lbc_log_rc [catch {binary scan $r2286_lbc_export H* r2286_lbc_log_hex} r2286_lbc_log_result]
if {$r2286_lbc_log_rc != 0} {
    log local0. "R2286LBC|run=r2286lex1|ctx=$r2286_lbc_context|export_refusal=$r2286_lbc_log_rc"
} else {
    set r2286_lbc_total [expr {([string length $r2286_lbc_log_hex] + 383) / 384}]
    for {set r2286_lbc_k 0} {$r2286_lbc_k < $r2286_lbc_total} {incr r2286_lbc_k} {
        set r2286_lbc_start [expr {$r2286_lbc_k * 384}]
        set r2286_lbc_chunk [string range $r2286_lbc_log_hex $r2286_lbc_start [expr {$r2286_lbc_start + 383}]]
        log local0. "R2286LBC|run=r2286lex1|ctx=$r2286_lbc_context|group_rc=$r2286_lbc_group_rc|group=$r2286_lbc_group|unit_rc=$r2286_lbc_unit_rc|unit=$r2286_lbc_unit|session=$r2286_lbc_session|seq=$r2286_lbc_k/$r2286_lbc_total|hex=$r2286_lbc_chunk"
    }
}
}

when CLIENT_ACCEPTED {
set r2286_lbc_context CLIENT_ACCEPTED
set r2286_lbc_group_rc [catch {TMM::cmp_group} r2286_lbc_group]
set r2286_lbc_unit_rc [catch {TMM::cmp_unit} r2286_lbc_unit]
set r2286_lbc_identity [list $r2286_lbc_group_rc $r2286_lbc_group $r2286_lbc_unit_rc $r2286_lbc_unit]
set r2286_lbc_session "[IP::client_addr]:[TCP::client_port]"
set r2286_lbc_rows {}
for {set r2286_lbc_i 0} {$r2286_lbc_i < 261} {incr r2286_lbc_i} {
    foreach r2286_lbc_source_kind {append_source binary_source} {
        foreach r2286_lbc_form {unbraced braced} {
            if {$r2286_lbc_i < 256} {
                set r2286_lbc_factory [list binary_byte $r2286_lbc_i]
                set r2286_lbc_payload [binary format H* [format %02x $r2286_lbc_i]]
            } else {
                switch -- $r2286_lbc_i {
                    256 {
                        set r2286_lbc_factory [list format_c 233]
                        set r2286_lbc_payload [format %c 233]
                    }
                    257 {
                        set r2286_lbc_factory [list format_c 769]
                        set r2286_lbc_payload [format %c 769]
                    }
                    258 {
                        set r2286_lbc_factory [list binary_hex c3a9]
                        set r2286_lbc_payload [binary format H* c3a9]
                    }
                    259 {
                        set r2286_lbc_factory [list binary_hex e9]
                        set r2286_lbc_payload [binary format H* e9]
                    }
                    260 {
                        set r2286_lbc_factory [list binary_hex cc81]
                        set r2286_lbc_payload [binary format H* cc81]
                    }
                }
            }
            set r2286_lbc_stem "r2286_lbc_${r2286_lbc_i}_${r2286_lbc_source_kind}_${r2286_lbc_form}_v"
            set r2286_lbc_full $r2286_lbc_stem
            append r2286_lbc_full $r2286_lbc_payload Q
            set r2286_lbc_targets [list [list $r2286_lbc_stem SHORT]]
            if {$r2286_lbc_i == 258} {
                set r2286_lbc_prefix $r2286_lbc_stem
                append r2286_lbc_prefix [binary format H* c3]
                lappend r2286_lbc_targets [list $r2286_lbc_prefix PREFIX_1]
            }
            if {$r2286_lbc_i == 260} {
                set r2286_lbc_prefix $r2286_lbc_stem
                append r2286_lbc_prefix [binary format H* cc]
                lappend r2286_lbc_targets [list $r2286_lbc_prefix PREFIX_1]
            }
            lappend r2286_lbc_targets [list $r2286_lbc_full FULL]
            set r2286_lbc_setup {}
            set r2286_lbc_add {}
            set r2286_lbc_attached {}
            set r2286_lbc_callback [list lappend ::r2286_lbc_reads]
            foreach r2286_lbc_target $r2286_lbc_targets {
                set r2286_lbc_name [lindex $r2286_lbc_target 0]
                set r2286_lbc_marker [lindex $r2286_lbc_target 1]
                set r2286_lbc_rc [catch {set $r2286_lbc_name $r2286_lbc_marker} r2286_lbc_value]
                lappend r2286_lbc_setup [list $r2286_lbc_marker $r2286_lbc_rc $r2286_lbc_value]
                set r2286_lbc_rc [catch {trace variable $r2286_lbc_name r $r2286_lbc_callback} r2286_lbc_value]
                lappend r2286_lbc_add [list $r2286_lbc_marker $r2286_lbc_rc $r2286_lbc_value]
                if {$r2286_lbc_rc == 0} {
                    lappend r2286_lbc_attached $r2286_lbc_name
                }
            }
            set r2286_lbc_source {list $}
            if {$r2286_lbc_form == "braced"} {append r2286_lbc_source \{}
            append r2286_lbc_source $r2286_lbc_full
            if {$r2286_lbc_form == "braced"} {append r2286_lbc_source \}}
            set r2286_lbc_build_rc 0
            set r2286_lbc_build_result {}
            set r2286_lbc_constructor_hex {}
            if {$r2286_lbc_source_kind == "binary_source"} {
                set r2286_lbc_build_rc [catch {
                    if {$r2286_lbc_i < 256 || $r2286_lbc_i >= 258} {
                        set r2286_lbc_lead {list $}
                        if {$r2286_lbc_form == "braced"} {append r2286_lbc_lead \{}
                        binary scan $r2286_lbc_lead H* r2286_lbc_lead_hex
                        binary scan $r2286_lbc_stem H* r2286_lbc_stem_hex
                        if {$r2286_lbc_i < 256} {
                            set r2286_lbc_byte_hex [format %02x $r2286_lbc_i]
                        } else {
                            switch -- $r2286_lbc_i {
                                258 {set r2286_lbc_byte_hex c3a9}
                                259 {set r2286_lbc_byte_hex e9}
                                260 {set r2286_lbc_byte_hex cc81}
                            }
                        }
                        set r2286_lbc_constructor_hex "$r2286_lbc_lead_hex$r2286_lbc_stem_hex${r2286_lbc_byte_hex}51"
                        if {$r2286_lbc_form == "braced"} {append r2286_lbc_constructor_hex 7d}
                    } else {
                        binary scan $r2286_lbc_source H* r2286_lbc_constructor_hex
                    }
                    set r2286_lbc_source [binary format H* $r2286_lbc_constructor_hex]
                } r2286_lbc_build_result]
            }
            set ::r2286_lbc_reads {}
            set r2286_lbc_eval_rc NOT_REACHED
            set r2286_lbc_eval_result {}
            if {$r2286_lbc_build_rc == 0} {
                set r2286_lbc_eval_rc [catch {eval $r2286_lbc_source} r2286_lbc_eval_result]
            }
            set r2286_lbc_reads $::r2286_lbc_reads
            set r2286_lbc_source_hex {}
            set r2286_lbc_source_scan_rc [catch {binary scan $r2286_lbc_source H* r2286_lbc_source_hex} r2286_lbc_source_scan_result]
            set r2286_lbc_result_hex {}
            set r2286_lbc_result_scan_rc [catch {binary scan $r2286_lbc_eval_result H* r2286_lbc_result_hex} r2286_lbc_result_scan_result]
            set r2286_lbc_payload_hex {}
            set r2286_lbc_payload_scan_rc [catch {binary scan $r2286_lbc_payload H* r2286_lbc_payload_hex} r2286_lbc_payload_scan_result]
            set r2286_lbc_utf8_hex {}
            set r2286_lbc_encoding_rc [catch {
                set r2286_lbc_utf8 [encoding convertto utf-8 $r2286_lbc_source]
                binary scan $r2286_lbc_utf8 H* r2286_lbc_utf8_hex
            } r2286_lbc_encoding_result]
            set r2286_lbc_remove {}
            foreach r2286_lbc_name $r2286_lbc_attached {
                set r2286_lbc_rc [catch {trace vdelete $r2286_lbc_name r $r2286_lbc_callback} r2286_lbc_value]
                lappend r2286_lbc_remove [list $r2286_lbc_rc $r2286_lbc_value]
            }
            set r2286_lbc_cleanup {}
            foreach r2286_lbc_target $r2286_lbc_targets {
                set r2286_lbc_name [lindex $r2286_lbc_target 0]
                set r2286_lbc_rc [catch {unset $r2286_lbc_name} r2286_lbc_value]
                lappend r2286_lbc_cleanup [list $r2286_lbc_rc $r2286_lbc_value]
            }
            lappend r2286_lbc_rows [list \
                case $r2286_lbc_i factory $r2286_lbc_factory \
                source_kind $r2286_lbc_source_kind form $r2286_lbc_form constructor_hex $r2286_lbc_constructor_hex \
                payload_scan [list $r2286_lbc_payload_scan_rc $r2286_lbc_payload_hex $r2286_lbc_payload_scan_result] \
                source_build [list $r2286_lbc_build_rc $r2286_lbc_build_result] \
                source_scan [list $r2286_lbc_source_scan_rc $r2286_lbc_source_hex $r2286_lbc_source_scan_result] \
                eval_code $r2286_lbc_eval_rc \
                result_scan [list $r2286_lbc_result_scan_rc $r2286_lbc_result_hex $r2286_lbc_result_scan_result] \
                reads $r2286_lbc_reads setup $r2286_lbc_setup trace_add $r2286_lbc_add \
                utf8_diagnostic [list $r2286_lbc_encoding_rc $r2286_lbc_utf8_hex $r2286_lbc_encoding_result] \
                trace_remove $r2286_lbc_remove cleanup $r2286_lbc_cleanup]
        }
    }
}
catch {unset ::r2286_lbc_reads}
set r2286_lbc_transcript [list LBC1 $r2286_lbc_context $r2286_lbc_identity [llength $r2286_lbc_rows] $r2286_lbc_rows]
set r2286_lbc_transcript_hex {}
set r2286_lbc_export_rc [catch {binary scan $r2286_lbc_transcript H* r2286_lbc_transcript_hex} r2286_lbc_export_result]
set r2286_lbc_export [list LBC1 $r2286_lbc_export_rc $r2286_lbc_export_result $r2286_lbc_transcript_hex]
set r2286_lbc_log_hex {}
set r2286_lbc_log_rc [catch {binary scan $r2286_lbc_export H* r2286_lbc_log_hex} r2286_lbc_log_result]
if {$r2286_lbc_log_rc != 0} {
    log local0. "R2286LBC|run=r2286lex1|ctx=$r2286_lbc_context|export_refusal=$r2286_lbc_log_rc"
} else {
    set r2286_lbc_total [expr {([string length $r2286_lbc_log_hex] + 383) / 384}]
    for {set r2286_lbc_k 0} {$r2286_lbc_k < $r2286_lbc_total} {incr r2286_lbc_k} {
        set r2286_lbc_start [expr {$r2286_lbc_k * 384}]
        set r2286_lbc_chunk [string range $r2286_lbc_log_hex $r2286_lbc_start [expr {$r2286_lbc_start + 383}]]
        log local0. "R2286LBC|run=r2286lex1|ctx=$r2286_lbc_context|group_rc=$r2286_lbc_group_rc|group=$r2286_lbc_group|unit_rc=$r2286_lbc_unit_rc|unit=$r2286_lbc_unit|session=$r2286_lbc_session|seq=$r2286_lbc_k/$r2286_lbc_total|hex=$r2286_lbc_chunk"
    }
}
}

when HTTP_REQUEST {
if {[HTTP::path] != "/r2286-lexical-byte-class"} {return}
set r2286_lbc_context HTTP_REQUEST
set r2286_lbc_group_rc [catch {TMM::cmp_group} r2286_lbc_group]
set r2286_lbc_unit_rc [catch {TMM::cmp_unit} r2286_lbc_unit]
set r2286_lbc_identity [list $r2286_lbc_group_rc $r2286_lbc_group $r2286_lbc_unit_rc $r2286_lbc_unit]
set r2286_lbc_session "[IP::client_addr]:[TCP::client_port]"
set r2286_lbc_rows {}
for {set r2286_lbc_i 0} {$r2286_lbc_i < 261} {incr r2286_lbc_i} {
    foreach r2286_lbc_source_kind {append_source binary_source} {
        foreach r2286_lbc_form {unbraced braced} {
            if {$r2286_lbc_i < 256} {
                set r2286_lbc_factory [list binary_byte $r2286_lbc_i]
                set r2286_lbc_payload [binary format H* [format %02x $r2286_lbc_i]]
            } else {
                switch -- $r2286_lbc_i {
                    256 {
                        set r2286_lbc_factory [list format_c 233]
                        set r2286_lbc_payload [format %c 233]
                    }
                    257 {
                        set r2286_lbc_factory [list format_c 769]
                        set r2286_lbc_payload [format %c 769]
                    }
                    258 {
                        set r2286_lbc_factory [list binary_hex c3a9]
                        set r2286_lbc_payload [binary format H* c3a9]
                    }
                    259 {
                        set r2286_lbc_factory [list binary_hex e9]
                        set r2286_lbc_payload [binary format H* e9]
                    }
                    260 {
                        set r2286_lbc_factory [list binary_hex cc81]
                        set r2286_lbc_payload [binary format H* cc81]
                    }
                }
            }
            set r2286_lbc_stem "r2286_lbc_${r2286_lbc_i}_${r2286_lbc_source_kind}_${r2286_lbc_form}_v"
            set r2286_lbc_full $r2286_lbc_stem
            append r2286_lbc_full $r2286_lbc_payload Q
            set r2286_lbc_targets [list [list $r2286_lbc_stem SHORT]]
            if {$r2286_lbc_i == 258} {
                set r2286_lbc_prefix $r2286_lbc_stem
                append r2286_lbc_prefix [binary format H* c3]
                lappend r2286_lbc_targets [list $r2286_lbc_prefix PREFIX_1]
            }
            if {$r2286_lbc_i == 260} {
                set r2286_lbc_prefix $r2286_lbc_stem
                append r2286_lbc_prefix [binary format H* cc]
                lappend r2286_lbc_targets [list $r2286_lbc_prefix PREFIX_1]
            }
            lappend r2286_lbc_targets [list $r2286_lbc_full FULL]
            set r2286_lbc_setup {}
            set r2286_lbc_add {}
            set r2286_lbc_attached {}
            set r2286_lbc_callback [list lappend ::r2286_lbc_reads]
            foreach r2286_lbc_target $r2286_lbc_targets {
                set r2286_lbc_name [lindex $r2286_lbc_target 0]
                set r2286_lbc_marker [lindex $r2286_lbc_target 1]
                set r2286_lbc_rc [catch {set $r2286_lbc_name $r2286_lbc_marker} r2286_lbc_value]
                lappend r2286_lbc_setup [list $r2286_lbc_marker $r2286_lbc_rc $r2286_lbc_value]
                set r2286_lbc_rc [catch {trace variable $r2286_lbc_name r $r2286_lbc_callback} r2286_lbc_value]
                lappend r2286_lbc_add [list $r2286_lbc_marker $r2286_lbc_rc $r2286_lbc_value]
                if {$r2286_lbc_rc == 0} {
                    lappend r2286_lbc_attached $r2286_lbc_name
                }
            }
            set r2286_lbc_source {list $}
            if {$r2286_lbc_form == "braced"} {append r2286_lbc_source \{}
            append r2286_lbc_source $r2286_lbc_full
            if {$r2286_lbc_form == "braced"} {append r2286_lbc_source \}}
            set r2286_lbc_build_rc 0
            set r2286_lbc_build_result {}
            set r2286_lbc_constructor_hex {}
            if {$r2286_lbc_source_kind == "binary_source"} {
                set r2286_lbc_build_rc [catch {
                    if {$r2286_lbc_i < 256 || $r2286_lbc_i >= 258} {
                        set r2286_lbc_lead {list $}
                        if {$r2286_lbc_form == "braced"} {append r2286_lbc_lead \{}
                        binary scan $r2286_lbc_lead H* r2286_lbc_lead_hex
                        binary scan $r2286_lbc_stem H* r2286_lbc_stem_hex
                        if {$r2286_lbc_i < 256} {
                            set r2286_lbc_byte_hex [format %02x $r2286_lbc_i]
                        } else {
                            switch -- $r2286_lbc_i {
                                258 {set r2286_lbc_byte_hex c3a9}
                                259 {set r2286_lbc_byte_hex e9}
                                260 {set r2286_lbc_byte_hex cc81}
                            }
                        }
                        set r2286_lbc_constructor_hex "$r2286_lbc_lead_hex$r2286_lbc_stem_hex${r2286_lbc_byte_hex}51"
                        if {$r2286_lbc_form == "braced"} {append r2286_lbc_constructor_hex 7d}
                    } else {
                        binary scan $r2286_lbc_source H* r2286_lbc_constructor_hex
                    }
                    set r2286_lbc_source [binary format H* $r2286_lbc_constructor_hex]
                } r2286_lbc_build_result]
            }
            set ::r2286_lbc_reads {}
            set r2286_lbc_eval_rc NOT_REACHED
            set r2286_lbc_eval_result {}
            if {$r2286_lbc_build_rc == 0} {
                set r2286_lbc_eval_rc [catch {eval $r2286_lbc_source} r2286_lbc_eval_result]
            }
            set r2286_lbc_reads $::r2286_lbc_reads
            set r2286_lbc_source_hex {}
            set r2286_lbc_source_scan_rc [catch {binary scan $r2286_lbc_source H* r2286_lbc_source_hex} r2286_lbc_source_scan_result]
            set r2286_lbc_result_hex {}
            set r2286_lbc_result_scan_rc [catch {binary scan $r2286_lbc_eval_result H* r2286_lbc_result_hex} r2286_lbc_result_scan_result]
            set r2286_lbc_payload_hex {}
            set r2286_lbc_payload_scan_rc [catch {binary scan $r2286_lbc_payload H* r2286_lbc_payload_hex} r2286_lbc_payload_scan_result]
            set r2286_lbc_utf8_hex {}
            set r2286_lbc_encoding_rc [catch {
                set r2286_lbc_utf8 [encoding convertto utf-8 $r2286_lbc_source]
                binary scan $r2286_lbc_utf8 H* r2286_lbc_utf8_hex
            } r2286_lbc_encoding_result]
            set r2286_lbc_remove {}
            foreach r2286_lbc_name $r2286_lbc_attached {
                set r2286_lbc_rc [catch {trace vdelete $r2286_lbc_name r $r2286_lbc_callback} r2286_lbc_value]
                lappend r2286_lbc_remove [list $r2286_lbc_rc $r2286_lbc_value]
            }
            set r2286_lbc_cleanup {}
            foreach r2286_lbc_target $r2286_lbc_targets {
                set r2286_lbc_name [lindex $r2286_lbc_target 0]
                set r2286_lbc_rc [catch {unset $r2286_lbc_name} r2286_lbc_value]
                lappend r2286_lbc_cleanup [list $r2286_lbc_rc $r2286_lbc_value]
            }
            lappend r2286_lbc_rows [list \
                case $r2286_lbc_i factory $r2286_lbc_factory \
                source_kind $r2286_lbc_source_kind form $r2286_lbc_form constructor_hex $r2286_lbc_constructor_hex \
                payload_scan [list $r2286_lbc_payload_scan_rc $r2286_lbc_payload_hex $r2286_lbc_payload_scan_result] \
                source_build [list $r2286_lbc_build_rc $r2286_lbc_build_result] \
                source_scan [list $r2286_lbc_source_scan_rc $r2286_lbc_source_hex $r2286_lbc_source_scan_result] \
                eval_code $r2286_lbc_eval_rc \
                result_scan [list $r2286_lbc_result_scan_rc $r2286_lbc_result_hex $r2286_lbc_result_scan_result] \
                reads $r2286_lbc_reads setup $r2286_lbc_setup trace_add $r2286_lbc_add \
                utf8_diagnostic [list $r2286_lbc_encoding_rc $r2286_lbc_utf8_hex $r2286_lbc_encoding_result] \
                trace_remove $r2286_lbc_remove cleanup $r2286_lbc_cleanup]
        }
    }
}
catch {unset ::r2286_lbc_reads}
set r2286_lbc_transcript [list LBC1 $r2286_lbc_context $r2286_lbc_identity [llength $r2286_lbc_rows] $r2286_lbc_rows]
set r2286_lbc_transcript_hex {}
set r2286_lbc_export_rc [catch {binary scan $r2286_lbc_transcript H* r2286_lbc_transcript_hex} r2286_lbc_export_result]
set r2286_lbc_export [list LBC1 $r2286_lbc_export_rc $r2286_lbc_export_result $r2286_lbc_transcript_hex]
log local0. "R2286LBC|run=r2286lex1|ctx=HTTP_REQUEST|group_rc=$r2286_lbc_group_rc|group=$r2286_lbc_group|unit_rc=$r2286_lbc_unit_rc|unit=$r2286_lbc_unit|session=$r2286_lbc_session|rows=[llength $r2286_lbc_rows]|export_rc=$r2286_lbc_export_rc"
HTTP::respond 200 content $r2286_lbc_export "Content-Type" "text/plain" "X-R2286-Run" "r2286lex1" "X-R2286-TMM" "$r2286_lbc_group:$r2286_lbc_unit"
}

